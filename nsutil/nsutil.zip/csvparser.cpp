// -----------------------------------------------------------------------------
// csvParser.cpp
// -----------------------------------------------------------------------------
// Parseur de fichier CSV
// CSV file parser
// -----------------------------------------------------------------------------
// $Revision: 1.5 $
// $Author: fabrice $
// $Date: 2005/07/12 10:11:39 $
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Copyright Nautilus, 2004
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � g�rer et traiter les
// informations de sant� d'une personne.
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to manage and process
// a person's health data.
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------


#include <fstream.h>

#include "partage/nsglobal.h"
#include "nautilus/nssuper.h"
// #include "pilot/NautilusPilot.hpp"
#include "nsbb/tagNames.h"
#include "nssavoir/nsgraphe.h"
#include "nsutil/attvalelem.h"
#include "nsutil/csvparser.h"
#include "nsbb/nsbbtran.h"
#include "nsbb/nspatpat.h"

#define CSVBUF_LEN                  512

#define ETABLISSEMENTCODE           "CODE ETA"
#define ETABLISSEMENTLABEL          "LABEL ETA"
#define CENTRERESPONSABILITECODE    "CODE CRESP"
#define CENTRERESPONSABILITELABEL   "LABEL CRESP"
#define SERVICECODE                 "CODE SERV"
#define SERVICELABEL                "LABEL SERV"
#define CENTREACTIVITECODE          "CODE CACT"
#define CENTREACTIVITELABEL         "LABEL CACT"
#define UFCODE                      "CODE UF"
#define UFLABEL                     "LABEL UF"
#define UFTYPE                      "TYPE"

CSVRecord::CSVRecord(const AttributeValueList& src)
{
	pAVList = new AttributeValueList() ;
  *pAVList = src ;
}


CSVRecord::CSVRecord(const CSVRecord& src)
{
	pAVList = new AttributeValueList() ;
  pAVList = src.pAVList ;
}


CSVRecord::~CSVRecord()
{
	delete pAVList ;
}


CSVRecord&
CSVRecord::operator=(const CSVRecord& src)
{
	pAVList = src.pAVList ;
  return (*this) ;
}


int
CSVRecord::operator==(const CSVRecord& src)
{
	if (pAVList == src.pAVList)
  	return 1 ;
  return 0 ;
}


CSVStructure::CSVStructure(string code, string label, CSVStructure *linkAt, string type)
{
  sCode   = code ;
  sLabel  = label ;
  pLinkAt = linkAt ;
  sFUType = type ;
}


CSVStructure::CSVStructure(const CSVStructure& src)
{
	sCode   = src.sCode ;
  sLabel  = src.sLabel ;
  pLinkAt = src.pLinkAt ;
  sFUType = src.sFUType ;
}


CSVStructure::~CSVStructure()
{
	pLinkAt = NULL ;
}


CSVStructure&
CSVStructure::operator=(const CSVStructure& src)
{
	sCode   = src.sCode ;
  sLabel  = src.sLabel ;
  pLinkAt = src.pLinkAt ;
  sFUType = src.sFUType ;
  return (*this) ;
}


int
CSVStructure::operator==(const CSVStructure& src)
{
	if ((sCode   == src.sCode)    &&
      (sLabel  == src.sLabel)   &&
      (pLinkAt == src.pLinkAt)  &&
      (sFUType == src.sFUType))
  	return 1 ;
  else
  	return 0 ;
}


bool
CSVStructure::createObjectPPT(NSContexte *pCtx, string sOType)
{
	// type des UFs :
  //   * Administratif
  //   * Court S�jour
  //   * Ecole
  //   * Ferme
  //   * Labo
  //   * Long Sejour
  //   * Moyen S�jour
  //   * Recherche
	if ((sOType == "LUNIF") && (sFUType != "Long Sejour") && (sFUType != "Court S�jour") && (sFUType != "Moyen S�jour"))
  {
  	return false ;
  }

  string sRootStructure = "" ;

	if      (sOType == "LGRPE")
  	sRootStructure = "LGRPE1" ;
  else if (sOType == "UETAB")
  	sRootStructure = "UETAB1" ;
  else if (sOType == "USERV")
  	sRootStructure = "USERV1" ;
  else if (sOType == "LUNIF")
  	sRootStructure = "LUNIF1" ;
  else
  	return false ;

	NSPatPathoArray Ppt(pCtx) ;

  Ppt.ajoutePatho(sRootStructure, 0) ;

  Ppt.ajoutePatho("LNOMA1", 1) ;
  Message Msg ;
  Msg.SetTexteLibre(sLabel) ;
  Ppt.ajoutePatho("�CL000", &Msg, 2) ;

  if ((sOType == "UETAB") || (sOType == "USERV") || (sOType == "LUNIF"))
  {
    Message Msg2 ;
    Msg2.SetComplement(sCode) ;
  	Ppt.ajoutePatho("LIDEG1", &Msg2, 1) ;
  }

  // adds type only if it is "long s�jour"
  if ((sOType == "LUNIF") && (sFUType == "Long Sejour"))
  {
		Ppt.ajoutePatho("LTYPA1", 1) ;
    Ppt.ajoutePatho("LUNLS1", 2) ;
  }

  // create the object
  string sFatherNode = "" ;
  if (pLinkAt != NULL)
  	sFatherNode = pLinkAt->sObjectID ;
	NSStructureGraphManager	*pStructureGraphManager = new NSStructureGraphManager(pCtx) ;
  pStructureGraphManager->setStructureGraph(&Ppt, sOType, sFatherNode) ;
  sObjectID = pStructureGraphManager->getRootObject() ;

/*
  // create links between structures
	if (sOType != "LGRPE")
  {
  	// un groupement d'�tablissement n'a pas de p�re
  	string  sFatherNode = pLinkAt->sObjectID ;
    string  sChildNode  = sObjectID ;

    if ((sFatherNode != "") && (sChildNode != "") && (!pStructureGraphManager->pLinkManager->etablirLien(sChildNode, NSRootLink::objectIn, sFatherNode)))
    {
      erreur("Impossible de cr�er le lien [structure -> structure m�re] de l'objet structure en cours.", standardError, 0) ;
      return false ;
    }
  }
*/

  return true ;
}


CSVStructureArray::CSVStructureArray()
	: CSVStructureVector()
{
}


CSVStructureArray::CSVStructureArray(const CSVStructureArray& src)
	: CSVStructureVector()
{
	if (!src.empty())
		for (CSVStructureCIter iter = src.begin() ; iter != src.end() ; iter++)
    	push_back(new CSVStructure(**iter)) ;
}


CSVStructureArray::~CSVStructureArray()
{
	vider() ;
}


CSVStructure *
CSVStructureArray::searchStructure(string sCode, string sLabel, CSVStructure *pLinkAt, string sType)
{
  CSVStructure  structure2search(sCode, sLabel, pLinkAt, sType) ;

	if (!empty())
  	for (CSVStructureIter iter = begin() ; iter != end() ; iter++)
    	if ((**iter) == structure2search)
        return (*iter) ;
  return NULL ;
}


CSVStructure *
CSVStructureArray::addStructure(string sCode, string sLabel, CSVStructure *plinkAt, string sType)
{
	CSVStructure *structure = searchStructure(sCode, sLabel, plinkAt, sType) ;
  if (structure == NULL)
  {
  	push_back(new CSVStructure(sCode, sLabel, plinkAt, sType)) ;
    return (*rbegin()) ;
  }
  return structure ;
}


bool
CSVStructureArray::createObjects(NSContexte *pCtx, string sOType)
{
	if (!empty())
  {
  	for (CSVStructureIter iter = begin() ; iter != end() ; iter++)
    	(*iter)->createObjectPPT(pCtx, sOType) ;
    return true ;
  }
  return false ;
}


bool
CSVStructureArray::vider()
{
	if (!empty())
  	for (CSVStructureIter iter = begin() ; iter != end() ; )
    {
    	delete (*iter) ;
      erase(iter) ;
    }
  return true ;
}



bool
NSStructureGraphManager::getStructureGraph(string sObjID, NSPatPathoArray *pPPT)
{
try
{
//	NSPatLinkArray *pLinkArray = new NSPatLinkArray() ;
//	NSLinkManager *pGraphe = pLinkManager ;
//	bool bGetSuivant = true ;

  // remise � z�ro du graphe
  pDataGraph->graphReset() ;
  string sObject = sObjID ;
  setRootObject(sObjID) ;

	NSBasicAttributeArray *pAttrList = new NSBasicAttributeArray() ;
  pAttrList->push_back(new NSBasicAttribute(OBJECT, sObjID)) ;

  bool res = pContexte->pPilot->invokeService(NautilusPilot::SERV_SEARCH_OBJECT_FROM_ID.c_str(), pDataGraph, pAttrList) ;

  delete pAttrList ;

  if (!res)
  {
  	string 	sMessage = "" ;
  	if 			(pContexte->pPilot->getErrorMessage() != "")
    	sMessage = pContexte->pPilot->getErrorMessage() ;
    else if (pContexte->pPilot->getWarningMessage() != "")
    	sMessage = pContexte->pPilot->getWarningMessage() ;
    else
    	sMessage = "Echec du service de r�cup�ration du graphe repr�sentant une Structure." ;
    erreur(sMessage.c_str(), standardError, 0) ;
    return false ;
  }

  // constitution de la patpatho contenant tous les arbres du graphe
  if (pPPT)
  {
    pPPT->vider() ;
    if (!(pDataGraph->aTrees.empty()))
    {
      for (NSDataTreeIter i = pDataGraph->aTrees.begin() ; i != pDataGraph->aTrees.end() ; i++)
      {
      	NSPatPathoArray *tempPPT = new NSPatPathoArray(pContexte) ;
        (*i)->getPatPatho(tempPPT) ;
        pPPT->ajouteVecteur(tempPPT, ORIGINE_PATH_PATHO) ;
        delete tempPPT ;
      }
    }
  }
  return true ;
}
catch (...)
{
  erreur("Exception NSStructureGraphManager::getTeamGraph", standardError, 0) ;
  return false ;
}
}


bool
NSStructureGraphManager::setStructureGraph(NSPatPathoArray *pPPT, string sOType, string sFatherID)
{
	string  sLabelTag = "" ;
  string  sIDTag    = "" ;
  string  sCodeObj  = "" ;

	if      (sOType == "LGRPE")
  {
  	sLabelTag = GRPE_LNOMA ;
    sCodeObj  = "LGRPE1" ;
  }
  else if (sOType == "UETAB")
  {
  	sLabelTag = ETAB_LNOMA ;
    sIDTag    = ETAB_LIDEG ;
    sCodeObj  = "UETAB1" ;
  }
  else if (sOType == "USERV")
  {
  	sLabelTag = SERV_LNOMA ;
    sIDTag    = SERV_LIDEG ;
    sCodeObj  = "USERV1" ;
  }
  else if (sOType == "LUNIF")
  {
  	sLabelTag = UNIF_LNOMA ;
    sIDTag    = UNIF_LIDEG ;
    sCodeObj  = "LUNIF1" ;
  }
  else
  {
  	return false ;
  }

  NSBasicAttributeArray	*pAttrList	= new NSBasicAttributeArray() ;
	string								sNodeRoot		= "" ;
  PatPathoIter					pptIter			= pPPT->begin() ;

  if ((pptIter != pPPT->end()) && ((*pptIter)->getLexique() == sCodeObj))
  {
		sNodeRoot	= setTree(pPPT, "") ;
  	setRootObject(sNodeRoot) ;
  }
  else
  {
  	erreur("L'arbre ne contient de Structure.", standardError, 0) ;
    delete pAttrList ;
    return false ;
  }

  // create links between structures
	if (sOType != "LGRPE")
  {
  	// un groupement d'�tablissement n'a pas de p�re
    if ((sFatherID != "") && (sNodeRoot != "") && (!pLinkManager->etablirLien(sNodeRoot, NSRootLink::objectIn, sFatherID)))
    {
      erreur("Impossible de cr�er le lien [structure -> structure m�re] de l'objet structure en cours.", standardError, 0) ;
      delete pAttrList ;
      return false ;
    }
  }

  // Le graphe est maintenant constitu�. on doit appeler le pilote pour
  // trouver successivement les ID de tous les arbres du graphe
  // (et r�soudre leurs d�pendances)
  NSDataGraph								*pLocalGraph	= new NSDataGraph(pContexte, graphObject) ;
  string										sTreeID				= "" ;
  string										sTreeRights		= "" ;
  NSPatPathoArray						*pPatPatho		= new NSPatPathoArray(pContexte, graphObject) ;
  NSPersonsAttributesArray	*pObjectsList = new NSPersonsAttributesArray() ;
  NSDataTreeIter						iterTree ;

  bool	bExist	= pDataGraph->aTrees.ExisteTree(sCodeObj, pContexte, &iterTree) ;
  if (bExist)
  {
  	sTreeID	= (*iterTree)->getTreeID() ;
    pLocalGraph->graphReset() ;
    pPatPatho->vider() ;
    pDataGraph->getTree(sTreeID, pPatPatho, &sTreeRights) ;

    pLocalGraph->setTree(pPatPatho, sTreeRights, sTreeID) ;

    // transfer links to pilot
    for (NSPatLinkIter linkIter = pDataGraph->aLinks.begin() ; linkIter != pDataGraph->aLinks.end() ; linkIter++)
    {
    	if (((*linkIter)->getQualifie()   == sTreeID) ||
			    ((*linkIter)->getQualifiant() == sTreeID))
    		pLocalGraph->aLinks.push_back(new NSPatLinkInfo(*(*linkIter))) ;
    }

	  pAttrList->push_back(new NSBasicAttribute("user", pContexte->getUtilisateurID())) ;
    if (sLabelTag != "")
    	pAttrList->push_back(new NSBasicAttribute(sLabelTag, getStructureName(pPatPatho))) ;
    if (sIDTag != "")
    	pAttrList->push_back(new NSBasicAttribute(sIDTag, getStructureID(pPatPatho))) ;

    // calling pilot : create local object
    bool	res	= pContexte->pPilot->createPersonOrObject(NautilusPilot::SERV_CREATE_OBJECT.c_str(), pLocalGraph, pObjectsList, pAttrList, OBJECT_TYPE, false) ;

    if (!res)
    {
    	erreur("Echec du service pilot lors de la cr�ation du graphe d'une Structure.", standardError, 0) ;
      delete pAttrList ;
      delete pLocalGraph ;
      delete pPatPatho ;
      delete pObjectsList ;
      return false ;
    }
  }

  delete pAttrList ;

  // Replace new ID in DataGraph
  NSDataTreeIter iter = pLocalGraph->aTrees.begin() ;
  string sNewTreeID = (*iter)->getTreeID() ;
  
  NSPatPathoArray Ppt(pContexte) ;
  (*iter)->getPatPatho(&Ppt) ;
  pDataGraph->replaceTree(sTreeID, sNewTreeID, &Ppt, sTreeRights) ;

	delete pLocalGraph ;
	delete pPatPatho ;
  delete pObjectsList ;

	return true ;
}


string
NSStructureGraphManager::getStructureName(NSPatPathoArray *pPPT)
{
	string	sResult	= "" ;
	for (PatPathoIter pptIter = pPPT->begin() ; pptIter != pPPT->end() ; pptIter++)
	{
  	if ((*pptIter)->getLexique() == "LNOMA1")
    {
    	PatPathoIter	labelIter = pptIter ;
      labelIter++ ;
      if ((labelIter != pPPT->end()) && ((*labelIter)->getLexique() == "�CL000"))
      {
      	sResult = (*labelIter)->getTexteLibre() ;
        break ;
      }
    }
  }
  return sResult ;
}


string
NSStructureGraphManager::getStructureID(NSPatPathoArray *pPPT)
{
	string	sResult	= "" ;
	for (PatPathoIter pptIter = pPPT->begin() ; pptIter != pPPT->end() ; pptIter++)
	{
  	if ((*pptIter)->getLexique() == "LIDEG1")
    {
    	sResult = (*pptIter)->getComplement() ;
      break ;
    }
  }
  return sResult ;
}


CSVParser::CSVParser(string file, char cField, char cItem)
{
	sFile           = file ;
	cFieldSeparator	= cField ;
  cItemSeparator  = cItem ;

  csvRecords      = new CSVRecordArray() ;
}


CSVParser::~CSVParser()
{
	delete csvRecords ;
}


bool
CSVParser::importFromFile()
{
	ifstream	inFile ;
  inFile.open(sFile.c_str()) ;
  if (!inFile)
  {
  	// erreur - l'ouverture du fichier a �chou�
    return false ;
  }

  char		szBuffer[CSVBUF_LEN] ;
  while (inFile.getline(szBuffer, CSVBUF_LEN))
  {
  	size_t	iBuff     = 0 ;
    int			index     = 0 ;
    string  sItem     = "" ;
    size_t  iBuffLen  = strlen(szBuffer) ;
    AttributeValueList	*pAVlist = new AttributeValueList() ;

    while ((iBuff < CSVBUF_LEN) && (iBuff <= iBuffLen))
    {
			if ((szBuffer[iBuff] == cFieldSeparator) || (szBuffer[iBuff] == '\0'))
      {
        iBuff++ ;

        size_t  iLen  = strlen(sItem.c_str()) ;
        sItem         = string(sItem, 1, iLen - 2) ;

        switch (index)
        {
          case  0	:	pAVlist->addElem(ETABLISSEMENTCODE,         sItem) ;  break ;
          case  1	:	pAVlist->addElem(ETABLISSEMENTLABEL,        sItem) ;  break ;
          case  2	:	pAVlist->addElem(CENTRERESPONSABILITECODE,  sItem) ;  break ;
          case  3	: pAVlist->addElem(CENTRERESPONSABILITELABEL, sItem) ;  break ;
          case  4	: pAVlist->addElem(SERVICECODE,               sItem) ;  break ;
          case  5	: pAVlist->addElem(SERVICELABEL,              sItem) ;  break ;
          case  6 : pAVlist->addElem(CENTREACTIVITECODE,        sItem) ;  break ;
          case  7 : pAVlist->addElem(CENTREACTIVITELABEL,       sItem) ;  break ;
          case  8 : pAVlist->addElem(UFCODE,                    sItem) ;  break ;
          case  9 : pAVlist->addElem(UFLABEL,                   sItem) ;  break ;
          case 10 : pAVlist->addElem(UFTYPE,                    sItem) ;  break ;
        }

      	index++ ;
        sItem = "" ;
      }
      else
      {
      	sItem += szBuffer[iBuff++] ;
      }
    }

    // c'est ce CSVRecord qu'il faut sauvegard� dans la liste
    csvRecords->push_back(new CSVRecord(*pAVlist)) ;

    delete pAVlist ;
  }

  inFile.close() ;
  return true ;
}


bool
CSVParser::run(NSContexte *pCtx)
{
	if (!importFromFile())
  	return false ;

  // create array of structures with links
  CSVStructure      *pCHU                 = new CSVStructure(string(""), string("CHU d'Amiens"), NULL) ;
  CSVStructureArray *pEtablissementsArray = new CSVStructureArray() ;
  CSVStructureArray *pServicesArray       = new CSVStructureArray() ;
  CSVStructureArray *pUFsArray            = new CSVStructureArray() ;

  for (CSVRecordIter iter = csvRecords->begin() ; iter != csvRecords->end() ; iter++)
  {
  	// �tablissement
    CSVStructure *pEtablissement  = pEtablissementsArray->addStructure((*iter)->getValWithAttr(ETABLISSEMENTCODE), (*iter)->getValWithAttr(ETABLISSEMENTLABEL), pCHU) ;
    CSVStructure *pService        = pServicesArray->addStructure((*iter)->getValWithAttr(SERVICECODE), (*iter)->getValWithAttr(SERVICELABEL), pEtablissement) ;
    CSVStructure *pUF             = pUFsArray->addStructure((*iter)->getValWithAttr(UFCODE), (*iter)->getValWithAttr(UFLABEL), pService, (*iter)->getValWithAttr(UFTYPE)) ;
  }

  // save structure in object bases
	pCHU->createObjectPPT(pCtx, "LGRPE") ;
  pEtablissementsArray->createObjects(pCtx, "UETAB") ;
  pServicesArray->createObjects(pCtx, "USERV") ;
  pUFsArray->createObjects(pCtx, "LUNIF") ;

  return true ;
}
