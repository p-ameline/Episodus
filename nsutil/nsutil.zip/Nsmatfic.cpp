//---------------------------------------------------------------------------//    NSMATFIC.CPP
//    PA   juillet 95
//  Impl�mentation des objets materiel
//---------------------------------------------------------------------------
#include <owl\applicat.h>
#include <owl\decmdifr.h>
#include <owl\docmanag.h>
#include <owl\olemdifr.h>

#include <owl\applicat.h>
#include <owl\window.h>
#include <owl\dialog.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <cstring.h>

#include "partage\nsglobal.h"
#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "nsoutil\nsoutil.h"

#include "partage\nsmatfic.h"
#include "partage\nsmatfic.rh"

#include "pilot\Pilot.hpp"
#include "pilot\JavaSystem.hpp"
#include "nsbb\tagNames.h"
//***************************************************************************
// 				Impl�mentation des m�thodes Materiel
//***************************************************************************

//---------------------------------------------------------------------------
//  Function:    NSMaterielData::NSMaterielData()
//
//  Description: Met � blanc les variables de la fiche
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSMaterielData::metAZero()
{
  //
  // Met les champs de donn�es � z�ro
  //  memset(type,        0, MAT_TYPE_LEN + 1) ;
  memset(utilisateur, 0, MAT_UTILISATEUR_LEN + 1) ;
  memset(code,        0, MAT_CODE_LEN + 1) ;
  memset(libelle,     0, MAT_LIBELLE_LEN + 1) ;
  memset(num_serie,   0, MAT_NUM_SERIE_LEN + 1) ;
  memset(mise_svce,   0, MAT_MISE_SVCE_LEN + 1) ;
  memset(actif,       0, MAT_ACTIF_LEN + 1) ;

  libelle_complet = "" ;

	sObjectID = "" ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSMaterielData::NSMaterielData(NSMaterielData& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSMaterielData::NSMaterielData(NSMaterielData& rv)
{
	strcpy(type,		    rv.type) ;
	strcpy(utilisateur,	rv.utilisateur) ;
	strcpy(code, 	  	  rv.code) ;
	strcpy(libelle, 	  rv.libelle) ;
	strcpy(num_serie, 	rv.num_serie) ;
	strcpy(mise_svce, 	rv.mise_svce) ;
	strcpy(actif, 	  	rv.actif) ;

	libelle_complet = rv.libelle_complet ;

	sObjectID = rv.sObjectID ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSMaterielData::operator=(NSMaterielData src)
//  Description:	Op�rateur =
//  Retour:			R�f�rence sur l'objet cible
//---------------------------------------------------------------------------
NSMaterielData& NSMaterielData::operator=(NSMaterielData src)
{
	if (this == &src)
		return *this ;

	strcpy(type,		    src.type) ;
	strcpy(utilisateur, src.utilisateur) ;
	strcpy(code,		    src.code) ;
	strcpy(libelle,	    src.libelle) ;
	strcpy(num_serie,	  src.num_serie) ;
	strcpy(mise_svce,	  src.mise_svce) ;
	strcpy(actif, 	  	src.actif) ;

	libelle_complet = src.libelle_complet ;

	sObjectID = src.sObjectID ;

	return *this ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSMaterielData::operator=(NSMaterielData src)
//  Description:	Op�rateur de comparaison
//  Retour:			0 ou 1
//---------------------------------------------------------------------------
int
NSMaterielData::operator == ( const NSMaterielData& o )
{
	if (sObjectID == o.sObjectID)
		return 1 ;
	else
		return 0 ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSMaterielInfo::NSMaterielInfo()
//  Description:	Constructeur par d�faut
//  Retour:			Rien
//---------------------------------------------------------------------------
NSMaterielInfo::NSMaterielInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSMaterielData() ;

	pPatPathoArray = 0 ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSMaterielInfo::~NSMaterielInfo()
//  Description:	Destructeur
//  Retour:			Rien
//---------------------------------------------------------------------------
NSMaterielInfo::~NSMaterielInfo()
{
	delete pDonnees;

	if (pPatPathoArray)
		delete pPatPathoArray ;
}

string
NSMaterielInfo::donneComplement()
{
	return pDonnees->sObjectID ;
}

bool
NSMaterielInfo::initialiseDepuisComplement(string sComplement)
{
	int iTaille = strlen(sComplement.c_str()) ;
	if (iTaille < MAT_TYPE_LEN)
		return false ;

	strcpy(pDonnees->type, string(sComplement, 0, MAT_TYPE_LEN).c_str()) ;

	if (iTaille >= MAT_TYPE_LEN + MAT_UTILISATEUR_LEN)
  	strcpy(pDonnees->utilisateur, string(sComplement, MAT_TYPE_LEN, MAT_UTILISATEUR_LEN).c_str()) ;

	if (iTaille >= MAT_TYPE_LEN + MAT_UTILISATEUR_LEN + MAT_CODE_LEN)
  	strcpy(pDonnees->code, string(sComplement, MAT_TYPE_LEN + MAT_UTILISATEUR_LEN, MAT_CODE_LEN).c_str()) ;

	return true ;
}

bool
NSMaterielInfo::initialiseDepuisObjet(NSContexte* pCtx, string sObjId, string actif)
{
  // ------------ Appel du pilote
  //
  NSDataGraph Graph(pCtx, graphObject) ;
  NSBasicAttributeArray AttrArray ;
	AttrArray.push_back(new NSBasicAttribute(OBJECT, sObjId)) ;
  bool res = pCtx->pPilot->invokeService(NautilusPilot::SERV_SEARCH_OBJECT_FROM_ID.c_str(),
                                  &Graph,  &AttrArray) ;
  if (!res)
  {
		string sErrorText = pCtx->getSuperviseur()->getText("NTIERS", "materialNotFound") ;
    erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
  }

  if (Graph.aTrees.empty())
		return false ;

	if (NULL == pPatPathoArray)
		pPatPathoArray = new NSPatPathoArray(pCtx, graphObject) ;

	NSDataTreeIter iterTree = Graph.aTrees.begin() ;
	(*iterTree)->getPatPatho(pPatPathoArray) ;

  int iColBase ;
  string sSens, sTemp ;
  string sNumSerie, sLibelle ;

  PatPathoIter iter = pPatPathoArray->begin() ;
  string sElemLex = string((*iter)->pDonnees->lexique) ;
  pCtx->getDico()->donneCodeSens(&sElemLex, &sSens) ;
  strcpy(pDonnees->type, sSens.c_str()) ;
  strcpy(pDonnees->actif, actif.c_str()) ;
  iColBase = (*iter)->pDonnees->getColonne() ;
  iter++ ;

  while ((iter != pPatPathoArray->end()) && ((*iter)->pDonnees->getColonne() > iColBase))
  {
  	sElemLex = string((*iter)->pDonnees->lexique) ;
    pCtx->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    // num�ro de s�rie
    if (sSens == string("LNUMS"))
    {
    	iter++ ;
      sNumSerie = "" ;
      while ((iter != pPatPathoArray->end()) && ((*iter)->pDonnees->getColonne() > iColBase+1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (sElemLex == string("�CL000"))
        {
        	sNumSerie = (*iter)->pDonnees->getTexteLibre() ;
          strcpy(pDonnees->num_serie, sNumSerie.c_str()) ;
        }
        iter++ ;
      }
    }
    // libelle
    else if (sSens == string("LNOMA"))
    {
    	iter++ ;
      sLibelle = "" ;
      while ((iter != pPatPathoArray->end()) && ((*iter)->pDonnees->getColonne() > iColBase+1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (sElemLex == string("�CL000"))
        {
        	sLibelle = (*iter)->pDonnees->getTexteLibre() ;
          strcpy(pDonnees->libelle, sLibelle.c_str()) ;
        }
        iter++ ;
      }
    }
    // date de mise en service
    else if (sSens == string("KSERV"))
    {
    	iter++ ;
      // int iLigneBase = (*iter)->pDonnees->getLigne() ;

    	string sUnite  = "" ;
    	string sFormat = "" ;
    	string sValeur = "" ;

      sTemp = (*iter)->getUnit() ;
      pCtx->getDico()->donneCodeSens(&sTemp, &sUnite) ;
      sTemp = (*iter)->getLexique() ;
      pCtx->getDico()->donneCodeSens(&sTemp, &sFormat) ;
      sValeur = (*iter)->getComplement() ;

    	if (sUnite == "2DA02")
      {
      	if (strlen(sValeur.c_str()) > MAT_MISE_SVCE_LEN)
        	sValeur = string(sValeur, 0, MAT_MISE_SVCE_LEN) ;

      	strcpy(pDonnees->mise_svce, sValeur.c_str()) ;
      }

      iter++ ;
    }
    else
    	iter++ ;
  }

  pDonnees->sObjectID = sObjId ;
  pDonnees->libelle_complet = pDonnees->libelle ;

  return true ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSMaterielInfo::NSMaterielInfo(NSMaterielInfo& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSMaterielInfo::NSMaterielInfo(NSMaterielInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSMaterielData() ;
	//
	// Copie les valeurs du NSMaterielInfo d'origine
	//
	*pDonnees = *(rv.pDonnees) ;

	if (rv.pPatPathoArray)
  	pPatPathoArray = new NSPatPathoArray(*(rv.pPatPathoArray)) ;
	else
  	pPatPathoArray = 0 ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSMaterielInfo::operator=(NSMaterielInfo src)
//  Description:	Op�rateur d'affectation
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
NSMaterielInfo&
NSMaterielInfo::operator=(NSMaterielInfo src)
{
	if (this == &src)
		return *this ;

	*pDonnees = *(src.pDonnees) ;

	if (src.pPatPathoArray)
	{
  	if (pPatPathoArray)
    	*pPatPathoArray = *(src.pPatPathoArray) ;
    else
    	pPatPathoArray = new NSPatPathoArray(*(src.pPatPathoArray)) ;
  }
  else
  {
  	if (pPatPathoArray)
    	delete pPatPathoArray ;
    pPatPathoArray = 0 ;
	}

	return *this ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSMaterielInfo::operator==(NSMaterielInfo src)
//  Description:	Op�rateur de comparaison
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
int NSMaterielInfo::operator == ( const NSMaterielInfo& o )
{
	return (*pDonnees == *(o.pDonnees)) ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSMaterielArray(NSMaterielArray& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSMaterielArray::NSMaterielArray(NSMaterielArray& rv)
					 :NSMatInfoArray()
{
try
{
	if (!(rv.empty()))
		for (MatosIter i = rv.begin(); i != rv.end(); i++)
			push_back(new NSMaterielInfo(*(*i))) ;
}
catch (...)
{
	erreur("Exception NSMaterielArray copy ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSMaterielArray::~NSMaterielArray()
{
	vider() ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSMaterielArray::vider()
{
	if (empty())
		return ;

	for (MatosIter i = begin(); i != end(); )
	{
  	delete *i ;
    erase(i) ;
	}
}

// -----------------------------------------------------------------
//
//  M�thodes de CreerMaterielDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(CreerMaterielDialog, NSUtilDialog)
	EV_COMMAND(IDOK, CmOk),
	EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

CreerMaterielDialog::CreerMaterielDialog(TWindow* pere, NSContexte* pCtx, NSMaterielArray* pMaterielArray,
                                         bool bMode, TModule* /* mod */)
                    :NSUtilDialog(pere, pCtx, "IDD_CREAT_MAT", pNSResModule)
{
try
{
  pLibelle  = new NSUtilEdit2(this, IDC_CM_LIBELLE, MAT_LIBELLE_LEN) ;
  pType     = new NSUtilLexique(this, IDC_CM_TYPE, pCtx->getDico()) ;
  pNumSerie = new NSUtilEdit2(this, IDC_CM_NUM_SERIE, MAT_NUM_SERIE_LEN) ;
  pMiseSvce = new NSUtilEditDate(this, IDC_CM_MISE_SVCE) ;
  pActif    = new TGroupBox(this, IDC_CM_ACTIF) ;
  pActifOui = new TRadioButton(this, IDC_CM_ACTIF_OUI, pActif) ;
  pActifNon = new TRadioButton(this, IDC_CM_ACTIF_NON, pActif) ;

  pData     = new NSMaterielData() ;
  bCreation = bMode ;

  // on r�cup�re le pointeur sur l'array des materiels
  pMatArray = pMaterielArray ;
}
catch (...)
{
	erreur("Exception CreerMaterielDialog ctor.", standardError, 0) ;
}
}

CreerMaterielDialog::~CreerMaterielDialog(){
	delete pLibelle ;
	delete pType ;
	delete pNumSerie ;
	delete pMiseSvce ;
	delete pActif ;
	delete pActifOui ;
	delete pActifNon ;
	delete pData ;
}

void
CreerMaterielDialog::SetupWindow()
{
	string sCodeLexique ;

	NSUtilDialog::SetupWindow() ;

	// on affiche dans les champ Edit les valeurs des pData
	if (strcmp(pData->type, ""))
	{
		sCodeLexique = string(pData->type) + string("1") ;
    pType->setLabel(sCodeLexique) ;
	}
	else
		pType->SetText("") ;

	if (strcmp(pData->mise_svce, ""))
  	pMiseSvce->setDate(string(pData->mise_svce)) ;

	pLibelle->SetText(pData->libelle) ;	pNumSerie->SetText(pData->num_serie) ;
	if (!strcmp(pData->actif, "0"))
  	pActifNon->Check() ;
	else
		pActifOui->Check() ;
}

void
CreerMaterielDialog::CmOk()
{
	string sTexte;
    string sCodeLexique;
    string sDate;
    char far type[MAT_TYPE_LEN + 1];

    // Saisie du code Type
    pType->GetText(type, MAT_TYPE_LEN + 1);
    if (!strcmp(type, ""))
    {
    	erreur("Le champ Type est obligatoire.", standardError, 0) ;
        return;
    }
    // on sait que le champ Type n'est pas vide
    sTexte = pType->getCode();
    if (sTexte == "�?????")		// texte libre
    {
    	erreur("Vous devez choisir le type mat�riel � partir du lexique, et non en texte libre.", standardError, 0) ;
        return;
    }

    // le type n'est pas modifiable
    if (bCreation)
    {
    	sTexte = string(sTexte,0,5);
    	strcpy(pData->type, sTexte.c_str());
    }
    else if (strncmp(pData->type, sTexte.c_str(), 5))	// si la valeur du type a chang�
    {
    	erreur("Le champ Type ne peut pas �tre modifi�, car ce mat�riel est d�j� enregistr�.", standardError, 0) ;
        if (strcmp(pData->type, ""))
    	{
    		sCodeLexique = string(pData->type) + string("1");
        	pType->setLabel(sCodeLexique);
    	}
    	else
            pType->SetText("");
        return;
    }

    // La date de mise en service est modifiable
    pMiseSvce->getDate(&sDate);
    strcpy(pData->mise_svce, sDate.c_str());

    // Le libelle n'est pas modifiable
    pLibelle->GetText(sTexte);
    if (sTexte == "")
    {
    	erreur("Le champ Libelle est obligatoire.", standardError, 0) ;
        return;
    }

    if (bCreation)
    	strcpy(pData->libelle, sTexte.c_str());
    else if (strcmp(pData->libelle, sTexte.c_str()))	// si la valeur a chang�
    {
    	erreur("Le champ Libell� ne peut pas �tre modifi�, car ce mat�riel est d�j� enregistr�.", standardError, 0) ;
        pLibelle->SetText(pData->libelle);
        return;
    }

    // Le n� de s�rie est modifiable
    pNumSerie->GetText(sTexte);
    strcpy(pData->num_serie, sTexte.c_str());

    // Le champ actif est modifiable
    if (pActifOui->GetCheck() == BF_CHECKED)
    	strcpy(pData->actif, "1");
    if (pActifNon->GetCheck() == BF_CHECKED)
    	strcpy(pData->actif, "0");

    // Contr�le du libelle : il doit etre unique pour chaque materiel
    if (bCreation)
    {
        for (MatosIter i = pMatArray->begin(); i != pMatArray->end(); i++)
        {
            if (strcmp((*i)->pDonnees->libelle, pData->libelle) == 0)
            {
                erreur("Ce nom existe d�j� dans la base des materiels. Vous devez saisir un autre nom.", standardError, 0) ;
                return;
            }
        }
    }

    NSUtilDialog::CmOk();
}

void
CreerMaterielDialog::CmCancel()
{
	NSUtilDialog::CmCancel() ;
}

// -----------------------------------------------------------------
//
//  M�thodes de ListeMaterielDialog
//
// -----------------------------------------------------------------

// ---------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(ListeMaterielDialog, NSUtilDialog)
	EV_COMMAND(IDC_LM_CREER,  CmCreer),
	EV_COMMAND(IDC_LM_SUPPR,  CmSupprimer),
  EV_COMMAND(IDC_LM_MODIF,  CmModifier),
  EV_COMMAND(IDC_LM_SETDEF, CmSetDefault),
  EV_COMMAND(IDOK, CmOk),
  EV_COMMAND(IDCANCEL, CmCancel),
  EV_LVN_GETDISPINFO(IDC_LM_LW, LvnGetDispInfo),
END_RESPONSE_TABLE;

ListeMaterielDialog::ListeMaterielDialog(TWindow* pere, NSContexte* pCtx, TModule* /* mod */)
                    :NSUtilDialog(pere, pCtx, "IDD_LISTMAT", pNSResModule)
{
try
{
  pListeMat      = new NSListeMatWindow(this, IDC_LM_LW) ;
  pMatArray      = new NSMaterielArray ;
  pMatAjoutArray = new NSMaterielArray ;
  pMatModifArray = new NSMaterielArray ;
  pMatSelect     = new NSMaterielInfo() ;

  nbMat          = 0 ;
  nbMatAjout     = 0 ;
  MaterielChoisi = -1 ;

	sDefaultEchogID = string("") ;
  readDefaultEchogID() ;
}
catch (...)
{
	erreur("Exception ListeMaterielDialog ctor.", standardError, 0) ;
}
}

ListeMaterielDialog::~ListeMaterielDialog()
{
	delete pMatSelect ;
  delete pMatAjoutArray ;
  delete pMatModifArray ;
  delete pMatArray ;
  delete pListeMat ;
}

voidListeMaterielDialog::SetupWindow()
{
	// fichiers d'aide
	sHindex = "" ;
	sHcorps = "" ;
	NSUtilDialog::SetupWindow() ;
	InitListe() ;

	if (InitMatArray())
		AfficheListe() ;
}

// Initialisation du tableau depuis la base
bool
ListeMaterielDialog::InitMatArray()
{
try
{
	pMatArray->vider() ;
	nbMat = 0 ;

	bool bResultActive   = InitMatArrayByActivity("1") ;
  bool bResultInactive = InitMatArrayByActivity("0") ;

	return bResultActive && bResultInactive ;
}
catch (...)
{
	erreur("Exception ListeMaterielDialog::InitMatArray.", standardError, 0) ;
	return false ;
}
}

bool
ListeMaterielDialog::InitMatArrayByActivity(string sActivityCode)
{
try
{
	VecteurString FoundObjects ;

	// on r�cup�re la liste des mat�riels : actifs et non-actifs
	NSPersonsAttributesArray ObjList ;
	NSBasicAttributeArray    AttrList ;
	AttrList.push_back(new NSBasicAttribute("_OMATE_LACTF", sActivityCode)) ;
	AttrList.push_back(new NSBasicAttribute(RESEARCH, CONTAIN_RESEARCH)) ;

	bool res = pContexte->pPilot->objectList(NautilusPilot::SERV_OBJECT_LIST.c_str(), &ObjList, &AttrList) ;
	if (!res)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "objectNotFound") ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return false ;
	}

	if (!(ObjList.empty()))
		for (NSPersonsAttributeIter k = ObjList.begin() ; k != ObjList.end() ; k++)
		{
			string sOIDS = (*k)->getAttributeValue(OIDS) ;
			FoundObjects.push_back(new string(sOIDS)) ;
		}

	for (EquiItemIter i = FoundObjects.begin(); i != FoundObjects.end(); i++)
	{
		NSMaterielInfo MatInfo ;
		if (MatInfo.initialiseDepuisObjet(pContexte, *(*i), sActivityCode))
		{
			pMatArray->push_back(new NSMaterielInfo(MatInfo)) ;
			nbMat++ ;
		}
	}
  
  return true ;
}
catch (...)
{
	erreur("Exception ListeMaterielDialog::InitMatArrayByActivity.", standardError, 0) ;
	return false ;
}
}

voidListeMaterielDialog::InitListe()
{
	string sLabel = pContexte->getSuperviseur()->getText("devicesManagement", "deviceLabel") ;
  string sType  = pContexte->getSuperviseur()->getText("devicesManagement", "deviceType") ;
  string sAvail = pContexte->getSuperviseur()->getText("devicesManagement", "deviceAvailable") ;

	TListWindColumn colLibelle((char*)sLabel.c_str(), 170, TListWindColumn::Left, 0) ;
  pListeMat->InsertColumn(0, colLibelle) ;
  TListWindColumn colType((char*)sType.c_str(), 230, TListWindColumn::Left, 1) ;
  pListeMat->InsertColumn(1, colType) ;
  TListWindColumn colActif((char*)sAvail.c_str(), 40, TListWindColumn::Left, 2) ;
  pListeMat->InsertColumn(2, colActif) ;
}

void
ListeMaterielDialog::AfficheListe()
{
	char libelle[255] ;

	pListeMat->DeleteAllItems() ;

	for (int i = nbMat - 1; i >= 0; i--)
	{
  	sprintf(libelle, "%s", ((*pMatArray)[i])->pDonnees->libelle) ;
    TListWindItem Item(libelle, 0) ;
    pListeMat->InsertItem(Item) ;
	}
}

void
ListeMaterielDialog::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
  const int 	BufLen = 255 ;
  static char buffer[BufLen] ;
  TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;
  int 	 index ;
  string sCodeLexique ;
  string sLibType ;

  string sLang = "";
  if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;

  index = dispInfoItem.GetIndex() ;

  // Affiche les informations en fonction de la colonne

  switch (dispInfoItem.GetSubItem())
  {
  	case 1: 	// Type
    	// si le code type existe, on r�cup�re son libell�
      if (strcmp(((*pMatArray)[index])->pDonnees->type, ""))
      {
      	sprintf(buffer, "%s1", ((*pMatArray)[index])->pDonnees->type) ;
        sCodeLexique = string(buffer) ;
        pContexte->getDico()->donneLibelle(sLang, &sCodeLexique, &sLibType) ;
        strcpy(buffer, sLibType.c_str()) ;
        if (strlen(buffer))
        	buffer[0] = pseumaj(buffer[0]) ;
      }
      else
      	strcpy(buffer, "") ;

      dispInfoItem.SetText(buffer) ;
      break ;

    case 2: 	// Actif O/N

    	string sMsg = string("") ;

    	if (!strcmp(((*pMatArray)[index])->pDonnees->actif, "0"))
      	sMsg = pContexte->getSuperviseur()->getText("generalLanguage", "no") ;
      else
      	sMsg = pContexte->getSuperviseur()->getText("generalLanguage", "yes") ;

      // Check if default device
      if (((*pMatArray)[index])->pDonnees->sObjectID == sDefaultEchogID)
      	sMsg = string("* ") + sMsg ;

      strcpy(buffer, sMsg.c_str()) ;

      dispInfoItem.SetText(buffer) ;
      break ;
  }
}

bool
ListeMaterielDialog::ExisteDansAjouts(NSMaterielInfo* pMatInfo)
{
	if (!pMatInfo)
		return false ;

	if (pMatAjoutArray->empty())
		return false ;

	for (MatosIter i = pMatAjoutArray->begin(); i != pMatAjoutArray->end(); i++)
  	if (*pMatInfo == (*(*i)))
    	return true ;

	return false ;
}

boolListeMaterielDialog::InitDataMateriel(NSMaterielInfo* pMatInfo, bool bCreer)
{
	if (!pMatInfo)
		return false ;

	CreerMaterielDialog* pMatDlg
		= new CreerMaterielDialog(pContexte->GetMainWindow(), pContexte, pMatArray, bCreer, GetModule()) ;

	// on initialise ici les donn�es du dialogue dans tous les cas
	*(pMatDlg->pData) = *(pMatInfo->pDonnees);

	if ((pMatDlg->Execute()) == IDCANCEL)
	{
  	delete pMatDlg ;
    return false ;
	}

	// on stocke les donnees du dialogue dans les Data
	*(pMatInfo->pDonnees) = *(pMatDlg->pData) ;

	delete pMatDlg ;
	return true ;
}

bool
ListeMaterielDialog::CreerMateriel(NSMaterielInfo* pMatInfo)
{
	if (!pMatInfo)
		return false ;

	NSPatPathoArray PatPatho(pContexte, graphObject) ;
	string sLexique = string(pMatInfo->pDonnees->type) + string("1") ;

	// type de mat�riel : noeud root
	PatPatho.ajoutePatho(sLexique, 0) ;

	// date de mise en service
	PatPatho.ajoutePatho("KSERV1", 1, 1) ;

	string sDateService = string(pMatInfo->pDonnees->mise_svce) + string("000000") ;
	Message Msg ;
	Msg.SetUnit("2DA021") ;
	Msg.SetComplement(sDateService.c_str()) ;
	PatPatho.ajoutePatho("�D0;10", &Msg, 2, 1) ;

	// libell�
	PatPatho.ajoutePatho("LNOMA1", 1, 1) ;
  Msg.Reset() ;
	Msg.SetTexteLibre(pMatInfo->pDonnees->libelle) ;
	PatPatho.ajoutePatho("�CL000", &Msg, 2, 1) ;

	// num�ro de s�rie
	PatPatho.ajoutePatho("LNUMS1", 1, 1) ;
  Msg.Reset() ;
	Msg.SetTexteLibre(pMatInfo->pDonnees->num_serie) ;
	PatPatho.ajoutePatho("�CL000", &Msg, 2, 1) ;

	NSObjectGraphManager GraphObject(pContexte) ;
	string sRootId = GraphObject.setTree(&PatPatho, "") ;
	GraphObject.setRootObject(sRootId) ;

	// Appel du pilote
	NSDataGraph* pGraph = GraphObject.pDataGraph ;

	//pObectsList la liste d'objects qui correspondent a ces criteres
	NSPersonsAttributesArray ObjectsList ;
	string user = "_000000" ;
	if (pContexte->getUtilisateur() != NULL)
  	user = pContexte->getUtilisateurID() ;

	string sTraitName1 = string("_OMATE_LTYPA") ;
	string sTraitName2 = string("_OMATE_LACTF") ;
	string sTraitName3 = string("_OMATE_LNOMA") ;

	NSBasicAttributeArray AttrList ;
	AttrList.push_back(new NSBasicAttribute(sTraitName1, string(pMatInfo->pDonnees->type))) ;
	AttrList.push_back(new NSBasicAttribute(sTraitName2, string(pMatInfo->pDonnees->actif))) ;
	AttrList.push_back(new NSBasicAttribute(sTraitName3, string(pMatInfo->pDonnees->libelle))) ;
	AttrList.push_back(new NSBasicAttribute("user", user)) ;

	pContexte->pPilot->createPersonOrObject(NautilusPilot::SERV_CREATE_OBJECT.c_str(),
                        pGraph, &ObjectsList, &AttrList, OBJECT_TYPE, false) ;

	if (!pGraph)
		return "" ;

	NSDataTreeIter iter ;
	if (pGraph->aTrees.ExisteTree(sLexique, pContexte, &iter))
  {
    bool bModifyDefault = false ;
  	if (pMatInfo->pDonnees->sObjectID == sDefaultEchogID)
    	bModifyDefault = true ;

		pMatInfo->pDonnees->sObjectID = (*iter)->getTreeID() ;

    if (bModifyDefault)
    	sDefaultEchogID = pMatInfo->pDonnees->sObjectID ;
  }

	return true ;
}

bool
ListeMaterielDialog::ModifierMateriel(NSMaterielInfo* pMatInfo)
{
	if (!pMatInfo)
		return false ;

	NSPatPathoArray PatPatho(pContexte, graphObject) ;
	string sLexique = string(pMatInfo->pDonnees->type) + string("1");

	// type de mat�riel : noeud root
	PatPatho.ajoutePatho(sLexique, 0) ;

	// date de mise en service
	PatPatho.ajoutePatho("KSERV1", 1, 1) ;
	string sDateService = string(pMatInfo->pDonnees->mise_svce) + string("000000") ;
	Message Msg ;
	Msg.SetUnit("2DA021") ;
	Msg.SetComplement(sDateService.c_str()) ;
	PatPatho.ajoutePatho("�D0;10", &Msg, 2, 1) ;

	// libell�
	PatPatho.ajoutePatho("LNOMA1", 1, 1) ;
  Msg.Reset() ;
	Msg.SetTexteLibre(pMatInfo->pDonnees->libelle) ;
	PatPatho.ajoutePatho("�CL000", &Msg, 2, 1) ;

	// num�ro de s�rie
	PatPatho.ajoutePatho("LNUMS1", 1, 1) ;
  Msg.Reset() ;
	Msg.SetTexteLibre(pMatInfo->pDonnees->num_serie) ;
	PatPatho.ajoutePatho("�CL000", &Msg, 2, 1) ;

	NSObjectGraphManager GraphObject(pContexte) ;
	string sRootId = GraphObject.setTree(&PatPatho, "") ;
	GraphObject.setRootObject(sRootId) ;

	// Appel du pilote
	NSDataGraph* pGraph = GraphObject.pDataGraph ;

	//pObectsList la liste d'objects qui correspondent a ces criteres
	string user = "_000000";
	if (pContexte->getUtilisateur() != NULL)
		user = pContexte->getUtilisateurID() ;
	string sTraitName1 = string("_OMATE_LTYPA") ;
	string sTraitName2 = string("_OMATE_LACTF") ;
	string sTraitName3 = string("_OMATE_LNOMA") ;

	NSBasicAttributeArray List ;
	List.push_back(new NSBasicAttribute("object", pMatInfo->pDonnees->sObjectID)) ;
	List.push_back(new NSBasicAttribute(sTraitName1, string(pMatInfo->pDonnees->type))) ;
	List.push_back(new NSBasicAttribute(sTraitName2, string(pMatInfo->pDonnees->actif))) ;
	List.push_back(new NSBasicAttribute(sTraitName3, string(pMatInfo->pDonnees->libelle))) ;
	List.push_back(new NSBasicAttribute("operator",pContexte->getUtilisateurID())) ;
	NSPersonsAttributesArray ObjectsList ;

	int res = pContexte->pPilot->modifyPersonOrObject(NautilusPilot::SERV_MODIFY_OBJECT.c_str(), pGraph, &ObjectsList, &List) ;
	if (!res)
	{
		erreur("Echec service � la modification du graphe d'un materiel.", standardError, 0) ;
    return false ;
	}

	return true ;
}

void
ListeMaterielDialog::CmCreer()
{
	NSMaterielInfo Info ;

	if (!InitDataMateriel(&Info, true))
		return ;

	// on ajoute les infos r�cup�r�es aux deux tableaux
  //
	pMatArray->push_back(new NSMaterielInfo(Info)) ;
	nbMat++ ;
	pMatAjoutArray->push_back(new NSMaterielInfo(Info)) ;
	nbMatAjout++ ;
	AfficheListe() ;
}

void
ListeMaterielDialog::CmSupprimer()
{
	MaterielChoisi = pListeMat->IndexItemSelect() ;
	if (MaterielChoisi < 0)
  {
  	string sErrMsg = pContexte->getSuperviseur()->getText("generalLanguageForLists", "anElementMustBeSelected") ;
    erreur(sErrMsg.c_str(), warningError, 0) ;
    return ;
	}

	NSMaterielInfo Info = *((*pMatArray)[MaterielChoisi]) ;

	if (!ExisteDansAjouts(&Info))
	{
		erreur("Vous ne pouvez supprimer un mat�riel d�j� enregistr�.", standardError, 0) ;
    return ;
	}

	// Le mat�riel vient d'etre cr�� : on le supprime des deux tableaux
	for (MatosIter i = pMatArray->begin(); i != pMatArray->end(); i++)
	{
  	if (Info == (*(*i)))
    {
    	delete *i ;
      pMatArray->erase(i) ;
      nbMat-- ;
      break ;
    }
  }

	for (MatosIter j = pMatAjoutArray->begin(); j != pMatAjoutArray->end(); j++)
	{
  	if (Info == (*(*j)))
    {
			delete *j ;
      pMatAjoutArray->erase(j) ;
      nbMatAjout-- ;
      break ;
    }
  }

	AfficheListe() ;
}

void
ListeMaterielDialog::CmModifier()
{
	MaterielChoisi = pListeMat->IndexItemSelect() ;
	if (MaterielChoisi < 0)
  {
  	string sErrMsg = pContexte->getSuperviseur()->getText("generalLanguageForLists", "anElementMustBeSelected") ;
    erreur(sErrMsg.c_str(), warningError, 0) ;
    return ;
	}

  NSMaterielInfo Info = *((*pMatArray)[MaterielChoisi]) ;

	if (ExisteDansAjouts(&Info))	// ce materiel vient d'etre cr��
	{
		int AjoutChoisi = -1 ;

  	// On retrouve l'index dans le tableau des ajouts
    int k = 0 ;
    for (MatosIter i = pMatAjoutArray->begin() ; i != pMatAjoutArray->end(); i++, k++)
    {
    	if (Info == (*(*i)))
      {
      	AjoutChoisi = k ;
        break ;
      }
    }

		// On lance la modif en mode cr�ation (cad qu'on autorise les modifs)
    if (!InitDataMateriel(&Info, true))
    	return ;

    // On met � jour les deux tableaux
    *((*pMatArray)[MaterielChoisi])   = Info ;
		*((*pMatAjoutArray)[AjoutChoisi]) = Info ;
  }
  else
  {
		// On lance la modif en mode modification (on interdit de modifier type et libell�)
    if (!InitDataMateriel(&Info, false))
    	return ;

    // On met � jour le tableau principal et on l'ajoute au tableau des materiels � modifier
		*((*pMatArray)[MaterielChoisi]) = Info ;
    pMatModifArray->push_back(new NSMaterielInfo(Info)) ;
	}

	// On tient � jour la liste
	AfficheListe() ;
}

void
ListeMaterielDialog::CmSetDefault()
{
	MaterielChoisi = pListeMat->IndexItemSelect() ;
	if (MaterielChoisi < 0)
  {
  	string sErrMsg = pContexte->getSuperviseur()->getText("generalLanguageForLists", "anElementMustBeSelected") ;
    erreur(sErrMsg.c_str(), warningError, 0) ;
    return ;
	}

  sDefaultEchogID = ((*pMatArray)[MaterielChoisi])->pDonnees->sObjectID ;

  // On tient � jour la liste
	AfficheListe() ;
}

void
ListeMaterielDialog::CmOk()
{
	if (!(pMatModifArray->empty()))
		for (MatosIter i = pMatModifArray->begin(); i != pMatModifArray->end(); i++)
			ModifierMateriel(*i) ;

	if (!(pMatAjoutArray->empty()))
    for (MatosIter j = pMatAjoutArray->begin(); j != pMatAjoutArray->end(); j++)
			CreerMateriel(*j) ;

	string sIDtoSetDefault = sDefaultEchogID ;
  readDefaultEchogID() ;
  if (sIDtoSetDefault != sDefaultEchogID)
  {
  	sDefaultEchogID = sIDtoSetDefault ;
  	storeDefaultEchogID() ;
  }

	NSUtilDialog::CmOk() ;}

voidListeMaterielDialog::CmCancel()
{
	NSUtilDialog::CmCancel() ;
}

// fonction Click droit : menu contextuel
void
ListeMaterielDialog::EvRButtonDown(uint /* modkeys */, NS_CLASSLIB::TPoint& point)
{
	// cr�ation d'un menu popup
	NS_CLASSLIB::TPoint lp = point ;

	TPopupMenu *menu = new TPopupMenu() ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	string sCrea = pSuper->getText("generalLanguageForLists", "add") ;
	string sModi = pSuper->getText("generalLanguageForLists", "modify") ;
	string sSupp = pSuper->getText("generalLanguageForLists", "remove") ;
	string sDefa = pSuper->getText("generalLanguageForLists", "setDefault") ;

	menu->AppendMenu(MF_STRING, IDC_LM_CREER,  sCrea.c_str()) ;
  menu->AppendMenu(MF_STRING, IDC_LM_MODIF,  sModi.c_str()) ;
	menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
	menu->AppendMenu(MF_STRING, IDC_LM_SUPPR,  sSupp.c_str()) ;
	menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
  menu->AppendMenu(MF_STRING, IDC_LM_SETDEF, sDefa.c_str()) ;

	ClientToScreen(lp) ;
	menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow) ;
	delete menu ;
}

void
ListeMaterielDialog::EvRButtonDownOut(uint /* modkeys */, NS_CLASSLIB::TPoint& point)
{
	// cr�ation d'un menu popup
	NS_CLASSLIB::TPoint lp = point ;

	TPopupMenu *menu = new TPopupMenu();

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	string sCrea = pSuper->getText("generalLanguageForLists", "add") ;

	menu->AppendMenu(MF_STRING, IDC_LM_CREER,  sCrea.c_str()) ;

	ClientToScreen(lp) ;
	menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow) ;
	delete menu ;
}

void
ListeMaterielDialog::readDefaultEchogID()
{
	//
	//  ------------------- Ouverture de KE.LUS -------------------
	//
	string sFichierAspect = pContexte->PathName("FGLO") + string("KE.LUS") ;

	bool tourner = true ;

	ifstream inFile ;
	inFile.open(sFichierAspect.c_str()) ;
	//
	// Ouverture impossible
	if (!inFile)
		return ;

	char 		 buffer[201] ;
	string	 commande, parametre ;

	inFile.unsetf(ios::skipws) ;
	while (tourner && (inFile.getline(buffer, 200)))
	{
		commande = "" ;
		parametre = "" ;
		//
		//  -------------- S�paration Commande/Param�tres ---------------
		//
		for (int i = 0; i < 11; i++)
			commande += pseumaj(buffer[i]) ;
		for (int i = 0; buffer[i+12] != '\0'; i++)
			parametre += buffer[i+12] ;
		//
		// On enl�ve les blancs
    while ((strlen(commande.c_str()) > 0) && (commande[strlen(commande.c_str())-1] == ' '))
    	commande = string(commande, 0, strlen(commande.c_str()) - 1) ;
    while ((strlen(parametre.c_str()) > 0) && (parametre[strlen(parametre.c_str())-1] == ' '))
    	parametre = string(parametre, 0, strlen(parametre.c_str()) - 1) ;
    //commande.strip(commande.Both, ' ');
		//parametre.strip(parametre.Both, ' ');
		//
		//  --------------- Interpr�tation de la commande ---------------
    //  ATTENTION : Les commandes sont converties en MAJUSCULES
		//
		//  --------------------- Type d'Echographe ---------------------
		//
		if ((commande == "ECHOGDEFAU") && (parametre != ""))
    {
    	sDefaultEchogID = string(parametre) ;
      tourner = false;
    }
  }
  //
  //  --------------------- Fermeture du fichier ----------------------
  //
  inFile.close() ;
  return ;
}

void
ListeMaterielDialog::storeDefaultEchogID()
{
	//
	//  ------------------- Ouverture de KE.LUS -------------------
	//
	string sFichierAspect = pContexte->PathName("FGLO") + string("KE.LUS") ;

  //
	// Reading
  //

	ifstream inFile ;
	inFile.open(sFichierAspect.c_str()) ;
	if (!inFile)
		return ;

	VectString aStrings ;
  string     line ;

  while (!inFile.eof())
	{
  	getline(inFile, line) ;
    aStrings.push_back(new string(line)) ;
	}

  inFile.close() ;

  //
  // Modifying
  //

  bool bLineFound = false ;

  if (!(aStrings.empty()))
  {
  	for (IterString itStr = aStrings.begin() ; itStr != aStrings.end() ; itStr++)
    {
    	string sLine = **itStr ;

      // EchogDefau :OECHO___001
      // 01234567890123456789012

      string sField = string(sLine, 0, 11) ;
      string sValue = string(sLine, 12, strlen(sLine.c_str()) - 12) ;

      strip(sField, stripBoth) ;
      pseumaj(&sField) ;

      if (sField == string("ECHOGDEFAU"))
      {
      	**itStr = string(**itStr, 0, 12) + sDefaultEchogID ;
        bLineFound = true ;
        break ;
      }
    }
	}

  if (!bLineFound)
  {
  	string sLine = string("EchogDefau :") + sDefaultEchogID ;
    aStrings.push_back(new string(sLine)) ;
  }

  //
  // Storing
  //

  ofstream outFile ;

  outFile.open(sFichierAspect.c_str(), ios::out) ;
  if (!outFile)
  	return ;

  for (IterString itStr = aStrings.begin() ; itStr != aStrings.end() ; itStr++)
  	outFile << ((**itStr) + string("\n")) ;

  outFile.close() ;
}

// -----------------------------------------------------------------
//
//  M�thodes de NSListeMatWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSListeMatWindow, TListWindow)
	EV_WM_LBUTTONDBLCLK,
  EV_WM_RBUTTONDOWN,
END_RESPONSE_TABLE;

//---------------------------------------------------------------------------
//  Function: NSListeMatWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListeMatWindow::EvLButtonDblClk(uint /* modKeys */, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point) ;

	HitTest(info) ;

	if (info.GetFlags() & LVHT_ONITEM)
		pDlg->CmModifier() ;
}

void
NSListeMatWindow::EvRButtonDown(uint modkeys, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point) ;

  int indexItem = HitTest(info) ;
  if (info.GetFlags() & LVHT_ONITEM)  {  	SetItemState(indexItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED) ;    Invalidate() ;    pDlg->EvRButtonDown(modkeys, point) ;
  }
  else
  	pDlg->EvRButtonDownOut(modkeys, point) ;
}

//---------------------------------------------------------------------------
//  Function: NSListeMatWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListeMatWindow::IndexItemSelect()
{
	int count = GetItemCount() ;
	int index = -1 ;

	for (int i = 0; i < count; i++)
  	if (GetItemState(i, LVIS_SELECTED))
    {
    	index = i ;
      break ;
    }

	return index ;
}

// -----------------------------------------------------------------
//
//  M�thodes de ChoixMaterielDialog
//
// -----------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(ChoixMaterielDialog, TDialog)
	EV_CHILD_NOTIFY_AND_CODE(IDC_MATERIELBOX, LBN_SELCHANGE, CmSelectMateriel),
	EV_CHILD_NOTIFY_AND_CODE(IDC_MATERIELBOX, LBN_DBLCLK, 	 CmMaterielDblClk),
	EV_COMMAND(ID_ELARGIR, CmElargir),
END_RESPONSE_TABLE;

ChoixMaterielDialog::ChoixMaterielDialog(TWindow* pere, NSContexte* pCtx,
					                     string* pMaterType, string* pMatUtili,
                                         NSMaterielInfo* pMatChoix)
                    :TDialog(pere, "IDD_MATERIEL", pNSResModule),
                     NSRoot(pCtx)
{
try
{
	pMatBox 	      = new TListBox(this, IDC_MATERIELBOX) ;
	MaterielChoisi  = 0 ;
	pMaterielChoisi = pMatChoix ;

	pMatType		    = pMaterType ;
	pMatUtilisateur = pMatUtili ;

	sTypeEnCours    = *pMaterType ;

	pFoundedObj     = new NSPersonsAttributesArray() ;
}
catch (...)
{
	erreur("Exception ChoixMaterielDialog ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  Function: ChoixMaterielDialog::~ChoixMaterielDialog()
//
//  Description: Destructeur.
//--------------------------------------------------------------------------
ChoixMaterielDialog::~ChoixMaterielDialog()
{
	//
	// Choix "Non pr�cis�"
	//
	if (MaterielChoisi == 1)
		pMaterielChoisi->pDonnees->metAZero() ;
	else if ((MaterielChoisi > 1) && (!pFoundedObj->empty()) )
	{
  	NSPersonsAttributeIter iterObj = pFoundedObj->begin() ;
    int count = 2 ; // MaterielChoisi 2 = first object on the list
    while ((iterObj != pFoundedObj->end()) && (count < MaterielChoisi))
    {
    	iterObj++ ;
      count++ ;
    }
    string oids = "" ;
    if (iterObj != pFoundedObj->end())
    	oids = (*iterObj)->getAttributeValue(OIDS) ;
    pMaterielChoisi->initialiseDepuisObjet(pContexte, oids) ;
	}
	delete pFoundedObj ;
	delete pMatBox ;
}

//---------------------------------------------------------------------------//  Initialise la boite de liste des mat�riels
//---------------------------------------------------------------------------
void
ChoixMaterielDialog::SetupWindow()
{
	TDialog::SetupWindow() ;

	initialiserListe() ;
	//
	// Si un appareil avait d�j� �t� s�lectionn�, on le coche
	//
#ifndef N_TIERS
	if ((pMaterielChoisi->pDonnees->code[0] != '\0') && (!(pMatArray->empty())))
	{
        int iNumApp = 0;
        MatosIter i;
   	    for (i = pMatArray->begin(); (i != pMatArray->end()) &&
      		(strcmp((*i)->pDonnees->code, pMaterielChoisi->pDonnees->code) != 0);
       		i++, iNumApp++);
        if (i != pMatArray->end())
            pMatBox->SetSelIndex(iNumApp+1);
	}
#endif
}

voidChoixMaterielDialog::CmElargir()
{
	string sNouvType = "" ;
	if (sTypeEnCours != "")
		sNouvType = pContexte->getSuperviseur()->getFilGuide()->PremierVrai(sTypeEnCours,
                                                                    "ES",
                                                                    "FLECHE");
	if (sTypeEnCours != sNouvType)
	{
  	sTypeEnCours = sNouvType ;
    initialiserListe() ;
	}
}

void
ChoixMaterielDialog::initialiserListe()
{
try
{
	string sLang = "";
	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang();
	//
  // Affichage du titre
  //
  string sLibelleType;
  if (sTypeEnCours != "")
  {
  	string sTypeComplet = sTypeEnCours + "1";
    pContexte->getSuperviseur()->getDico()->donneLibelle(sLang, &sTypeComplet, &sLibelleType);
    sLibelleType[0] = pseumaj(sLibelleType[0]);
  }
  else
  	sLibelleType = "Tous les mat�riels";

  if (sLang == "en")
      sLibelleType = "MATERIELS CHOICE : " + sLibelleType;
  else
      sLibelleType = "CHOIX DES MATERIELS : " + sLibelleType;
  SetCaption(sLibelleType.c_str());

#ifndef N_TIERS
	//
	// Mise � z�ro de l'array et de la boite de liste
	//
	pMatArray->vider();
#endif

	int listeCount = pMatBox->GetCount() ;
	if (listeCount < 0)
  	erreur("Boite de liste d�fectueuse.", standardError, 0) ;
  if (listeCount > 0)
  	pMatBox->ClearList() ;

	pMatBox->AddString("Non pr�cis�") ;

	//
	// On cherche tous les mat�riels qui sont un sTypeEnCours
	//
	VecteurString vecteurString;
	if (sTypeEnCours != "")
		pContexte->getSuperviseur()->getFilGuide()->chercheEquivalent(sTypeEnCours,
                                            &vecteurString, "ES", "ENVERS") ;

	NSPersonsAttributesArray ObjList ;
	NSBasicAttributeArray    AttrList ;
  if (!(vecteurString.empty()))
  {
  	for (IterString iterVectString = vecteurString.begin(); iterVectString != vecteurString.end(); iterVectString++)
    {
    	AttrList.push_back(new NSBasicAttribute("_OMATE_LACTF", "1")) ;
      AttrList.push_back(new NSBasicAttribute(string("_OMATE_LTYPA"), *(*iterVectString))) ;
      bool res = pContexte->pPilot->objectList(NautilusPilot::SERV_OBJECT_LIST_WITH_TRAITS.c_str(), &ObjList, &AttrList) ;
      if (!res)
      {
      	string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "objectNotFound") ;
        erreur(sErrorText.c_str(), standardError, 0, 0) ;
      }
      else
      {
      	if (!(ObjList.empty()))
        	for (NSPersonsAttributeIter iterObj = ObjList.begin() ; iterObj != ObjList.end() ; iterObj++)
          	//string sOIDS = (*iterObj)->getAttributeValue(OIDS) ;
            pFoundedObj->push_back(new NSBasicAttributeArray(**iterObj)) ;
      }
      AttrList.vider() ;
    }
	}

	for (NSPersonsAttributeIter iterObj = pFoundedObj->begin() ; iterObj != pFoundedObj->end() ; iterObj++)
  	pMatBox->AddString((*iterObj)->getAttributeValue("_OMATE_LNOMA").c_str()) ;

	return ;
}
catch (...)
{
	erreur("Exception ChoixMaterielDialog::initialiserListe.", standardError, 0) ;
}
}


//---------------------------------------------------------------------------//  Prend acte de la s�lection du mat�riel
//---------------------------------------------------------------------------
void ChoixMaterielDialog::CmSelectMateriel(WPARAM /* Cmd */)
{
	//
	// R�cup�ration de l'indice de la chemise s�lectionn�e
	//
	MaterielChoisi = pMatBox->GetSelIndex() + 1 ;
}

//---------------------------------------------------------------------------//  S�lectionne un mat�riel
//---------------------------------------------------------------------------
void ChoixMaterielDialog::CmMaterielDblClk(WPARAM /* Cmd */)
{
	MaterielChoisi = pMatBox->GetSelIndex() + 1 ;
	TDialog::CmOk() ;
}

//---------------------------------------------------------------------------//  Annule MaterielChoisi et appelle Cancel()
//---------------------------------------------------------------------------
void ChoixMaterielDialog::CmCancel()
{
	MaterielChoisi = 0 ;
	TDialog::CmCancel() ;
}

//***************************************************************************
// 				Impl�mentation des m�thodes Protocole
//***************************************************************************

//---------------------------------------------------------------------------//  Fonction:		NSProtocoleArray(NSProtocoleArray& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSProtocoleArray::NSProtocoleArray(NSProtocoleArray& rv)
					  :NSProtInfoArray()
{
try
{
    if (!(rv.empty()))
	    for (IterProto i = rv.begin(); i != rv.end(); i++)
   	        push_back(new NSProtocoleInfo(*(*i)));
}
catch (...)
{
    erreur("Exception NSProtocoleArray copy ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSProtocoleArray::~NSProtocoleArray()
{
	vider();
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSProtocoleArray::vider()
{
    if (empty())
        return ;

	for (IterProto i = begin(); i != end(); )
    {
   	    delete *i;
        erase(i);
    }
}

// -----------------------------------------------------------------//
//  M�thodes de ChoixProtocole
//
// -----------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(ChoixProtocole, TDialog)
	EV_CHILD_NOTIFY_AND_CODE(IDC_PROTOCOLBOX, LBN_SELCHANGE, CmSelectProto),
	EV_CHILD_NOTIFY_AND_CODE(IDC_PROTOCOLBOX, LBN_DBLCLK, 	CmProtoDblClk),
END_RESPONSE_TABLE;

ChoixProtocole::ChoixProtocole(TWindow* pere, NSContexte* pCtx,
                               string* pRotType, string* pRotoUtili,
                               NSProtocoleInfo* pProtChoix)
               :TDialog(pere, "IDD_PROTOCOL", pNSResModule), NSRoot(pCtx)
{
try
{
	pRotocolBox 	    = new TListBox(this, IDC_PROTOCOLBOX) ;
	pProtocoleChoisi  = pProtChoix ;
	ProtocoleChoisi   = 0 ;
	pRotocolType	    = pRotType ;
	pProtoUtilisateur = pRotoUtili ;
  pProtArray        = 0 ;
}
catch (...)
{
    erreur("Exception ChoixProtocole ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  Function: ChoixProtocole::~ChoixProtocole()
//
//  Description: Destructeur.
//---------------------------------------------------------------------------
ChoixProtocole::~ChoixProtocole()
{
	//
	// Si un protocole a �t� choisi
	//
	if (NULL != ProtocoleChoisi)
		*pProtocoleChoisi = *((*pProtArray)[ProtocoleChoisi - 1]) ;

	delete pRotocolBox ;

  if (NULL != pProtArray)
		delete pProtArray ;
}

//---------------------------------------------------------------------------
//  Initialise la boite de liste des protocoles
//---------------------------------------------------------------------------
void
ChoixProtocole::SetupWindow()
{
try
{
	TDialog::SetupWindow();

	//	// Remplissage de MaterielBox avec le protocole idoine
	//
	pProtArray = new NSProtocoleArray;

	NSPersonsAttributesArray ObjList ;
	NSBasicAttributeArray    AttrList ;

	AttrList.push_back(new NSBasicAttribute(string("_0PROT_LTYPA"), *pRotocolType)) ;
	bool res = pContexte->pPilot->objectList(NautilusPilot::SERV_OBJECT_LIST_WITH_TRAITS.c_str(), &ObjList, &AttrList) ;
	if (!res)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "objectNotFound") ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
    return ;
	}

	if (ObjList.empty())
		return ;

	for (NSPersonsAttributeIter iterObj = ObjList.begin() ; iterObj != ObjList.end() ; iterObj++)
	{
  	string sOIDS = (*iterObj)->getAttributeValue(OIDS) ;

    NSProtocoleInfo Protocole ;
    if (Protocole.initialiseDepuisObjet(pContexte, sOIDS))
    {
    	string sLib = Protocole.getLibelle() ;
    	pRotocolBox->AddString(sLib.c_str()) ;
    	pProtArray->push_back(new NSProtocoleInfo(Protocole)) ;
    }
	}

	//
	// Si un protocole avait d�j� �t� s�lectionn�, on le coche
	//
	if ((string("") != pProtocoleChoisi->pDonnees->sObjectID) && (!(pProtArray->empty())))
	{
		int iNumApp = 0 ;
		IterProto i ;
		for (i = pProtArray->begin(); (i != pProtArray->end()) &&
      		((*i)->pDonnees->sObjectID != pProtocoleChoisi->pDonnees->sObjectID);
       		i++, iNumApp++) ;
		if (i != pProtArray->end())
    	pRotocolBox->SetSelIndex(iNumApp) ;
	}
}
catch (...)
{
	erreur("Exception ChoixProtocole::SetupWindow.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Description :	Prend acte de la s�lection du protocole
//---------------------------------------------------------------------------
void ChoixProtocole::CmSelectProto(WPARAM /* Cmd */)
{
	//
	// R�cup�ration de l'indice de la chemise s�lectionn�e
	//
	ProtocoleChoisi = pRotocolBox->GetSelIndex() + 1 ;
}
//---------------------------------------------------------------------------//  Description :	S�lectionne un protocole
//---------------------------------------------------------------------------
void ChoixProtocole::CmProtoDblClk(WPARAM /* Cmd */)
{
	ProtocoleChoisi = pRotocolBox->GetSelIndex() + 1 ;
	TDialog::CmOk() ;
}

//---------------------------------------------------------------------------
//  Description :	Annule ProtocoleChoisi et appelle Cancel()
//---------------------------------------------------------------------------
void ChoixProtocole::CmCancel()
{
	ProtocoleChoisi = 0 ;
	TDialog::CmCancel() ;
}

