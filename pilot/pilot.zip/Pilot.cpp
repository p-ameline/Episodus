/*//////////////////////////////////////////////////////*/
/*														*/
/*	Created by:	Dominique Sauquet						*/
/*  Created on:	May 2003								*/
/*														*/
/*//////////////////////////////////////////////////////*/

# include <fstream.h>

#include "pilot\Pilot.hpp"

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  Pilot
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

jclass Pilot::classPilot = NULL;

// Definir des constantes de retour
// static dans Pilot.hpp
int Pilot::Init(const char* config)
//=================================
{
	ofstream outFile ;
	outFile.open("traceNau.inf", ios::app) ;
	if (!outFile)
		return -5 ;
  outFile << string("Entering Pilot init\n") ;
	outFile.close() ;

	JNIEnv* jenv = JavaSystem::jenv ;
	if (jenv == NULL)
		return -4 ;

	outFile.open("traceNau.inf", ios::app) ;
	if (!outFile)
		return -5 ;
  outFile << string("Before jenv->FindClass\n") ;
	outFile.close() ;

	classPilot = jenv->FindClass("pilot/Pilot") ;

	if (classPilot == 0)
	{
		fprintf(stderr, "Cannot locate the pilot/Pilot class. Exiting...\n") ;
    return -1 ;
	}

	outFile.open("traceNau.inf", ios::app) ;
	if (!outFile)
		return -5 ;
  outFile << string("Before jenv->GetStaticMethodID1\n") ;
	outFile.close() ;

	//=== method Pilot.setParametersFromFile
	jmethodID mid = jenv->GetStaticMethodID(classPilot, "setParametersFromFile", "(Ljava/lang/String;)V") ;
	if (mid == 0)
  {
  	fprintf(stderr, "Cannot locate the setParametersFromFile method. Exiting...\n") ;
    return -2 ;
	}
	jstring jdescr = jenv->NewStringUTF(config) ;
	jenv->CallStaticVoidMethod(classPilot, mid, jdescr) ;
	jenv->DeleteLocalRef(jdescr) ;

	outFile.open("traceNau.inf", ios::app) ;
	if (!outFile)
		return -5 ;
  outFile << string("Before jenv->GetStaticMethodID2\n") ;
	outFile.close() ;

	//=== method Pilot.init
	mid = jenv->GetStaticMethodID(classPilot, "init", "()I") ;
	if (mid == 0)
	{
  	fprintf(stderr, "Cannot locate the init method. Exiting...\n") ;
    return -3 ;
	}

	outFile.open("traceNau.inf", ios::app) ;
	if (!outFile)
		return -5 ;
  outFile << string("Before jenv->CallStaticIntMethod\n") ;
	outFile.close() ;

	jint nbAgent = jenv->CallStaticIntMethod(classPilot, mid) ;

	outFile.open("traceNau.inf", ios::app) ;
	if (!outFile)
		return -5 ;
  outFile << string("Leaving Pilot init\n") ;
	outFile.close() ;

	return nbAgent ;
}

int Pilot::AddServices(const char* serviceFile)
//=============================================
{
	JNIEnv* jenv = JavaSystem::jenv;

	//=== method Pilot.addServices
    jmethodID mid = jenv->GetStaticMethodID(classPilot, "addServices", "(Ljava/lang/String;)Z");
    if (mid == 0) {
      fprintf(stderr, "Cannot locate the addServices method. Exiting...\n");
      return 0;
    }
    jstring jdescr = jenv->NewStringUTF(serviceFile);
    jenv->CallStaticVoidMethod(classPilot, mid, jdescr);
	jenv->DeleteLocalRef(jdescr);

    //=== method Pilot.getNbServices
    mid = jenv->GetStaticMethodID(classPilot, "getNbServices", "()I");
    if (mid == 0) {
      fprintf(stderr, "Cannot locate the getNbServices method. Exiting...\n");
      return 0;
    }
    return jenv->CallStaticIntMethod(classPilot, mid);
}

int Pilot::AddServicesFromDirectory(const char* serviceDir)
//=========================================================
{
	JNIEnv* jenv = JavaSystem::jenv;

	//=== method Pilot.addServicesFromDirectory
    jmethodID mid = jenv->GetStaticMethodID(classPilot, "addServicesFromDirectory", "(Ljava/lang/String;)Z");
    if (mid == 0) {
      fprintf(stderr, "Cannot locate the addServices method. Exiting...\n");
      return 0;
    }
    jstring jdescr = jenv->NewStringUTF(serviceDir);
    jenv->CallStaticVoidMethod(classPilot, mid, jdescr);
	jenv->DeleteLocalRef(jdescr);

    //=== method Pilot.getNbServices
    mid = jenv->GetStaticMethodID(classPilot, "getNbServices", "()I");
    if (mid == 0) {
      fprintf(stderr, "Cannot locate the getNbServices method. Exiting...\n");
      return 0;
    }
    return jenv->CallStaticIntMethod(classPilot, mid);
}

int Pilot::InitFromResource(const char* resourceName)
//===================================================
{
	JNIEnv* jenv = JavaSystem::jenv;

	//=== method Pilot.initFromResource
    jmethodID mid = jenv->GetStaticMethodID(classPilot, "initFromResource", "(Ljava/lang/String;)Z");
    if (mid == 0) {
      fprintf(stderr, "Cannot locate the initFromResource method. Exiting...\n");
      return 0;
    }
    jstring jresc = jenv->NewStringUTF(resourceName);
    jenv->CallStaticVoidMethod(classPilot, mid, jresc);
	jenv->DeleteLocalRef(jresc);

    //=== method Pilot.getNbServices
    mid = jenv->GetStaticMethodID(classPilot, "getNbServices", "()I");
    if (mid == 0) {
      fprintf(stderr, "Cannot locate the getNbServices method. Exiting...\n");
      return 0;
    }
    return jenv->CallStaticIntMethod(classPilot, mid);
}

Pilot::Pilot()
//============
{
	JNIEnv* jenv = JavaSystem::jenv;

	//=== create a Pilot instance
	jmethodID mid = jenv->GetMethodID(classPilot, "<init>", "()V");
	if (mid == 0) {
      fprintf(stderr, "Cannot locate the Pilot constructor method. Exiting...\n");
	  newPilot = NULL;
    }
	else {
	  newPilot = jenv->NewObject(classPilot, mid);
	}
}

Pilot::~Pilot()
//=============
{
}

char* Pilot::Execute(char* inputData, bool ifDOMElement)
//======================================================
{
	JNIEnv* jenv = JavaSystem::jenv;

	//=== execute a Pilot instance
	jmethodID mid = jenv->GetMethodID(classPilot, "execute", "(Ljava/lang/String;Z)Ljava/lang/String;");
	if (mid == 0) {
      fprintf(stderr, "Cannot locate the Pilot execute method. Exiting...\n");
      return NULL;
    }

	jstring jdescr = jenv->NewStringUTF(inputData);
	jstring jResult = (jstring)jenv->CallObjectMethod(newPilot, mid, jdescr, ifDOMElement);

	char *result = JavaSystem::NewStringWithSpecialCharacters(jResult);
printf("Result exec : %s\n", result );
	jenv->DeleteLocalRef(jdescr);
    jenv->DeleteLocalRef(newPilot);      //??? jResult
	return result;
}
