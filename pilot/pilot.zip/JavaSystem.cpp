/*//////////////////////////////////////////////////////*/
/*														*/
/*	Created by:	Dominique Sauquet						*/
/*  Created on:	May 2003								*/
/*														*/
/*//////////////////////////////////////////////////////*/

#include "pilot/JavaSystem.hpp"
#include "partage\nsdivfct.h" 
#include <string.h>
#include <owl\module.h>

#include "nautilus\nssuper.h"

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  JavaSystem
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

JNIEnv* JavaSystem::jenv = NULL;
JavaVM* JavaSystem::jvm  = NULL;

static jint JNICALL vfprintfHook(FILE * /*fp*/, const char *format, va_list args)
{
	char buf[1024] ;
	_vsnprintf(buf, sizeof(buf), format, args) ;

	ofstream outFile ;
	outFile.open("traceNau.inf", ios::app) ;
	if (!outFile)
		return 1 ;

	outFile << string(buf) ;
  outFile << string("\n") ;

	outFile.close() ;

	return 1 ;
}

/*
* The path must contain the directory of jvm.dll
*#define JNI_OK           0                 // success
#define JNI_ERR          (-1)              //unknown error
#define JNI_EDETACHED    (-2)              // thread detached from the VM
#define JNI_EVERSION     (-3)              // JNI version error
#define JNI_ENOMEM       (-4)              // not enough memory
#define JNI_EEXIST       (-5)              // VM already created
#define JNI_EINVAL       (-6)              // invalid arguments

*/
int JavaSystem::Init(NSContexte* pContexte, const char* classPath,
					 const char* libPath,   bool verbose)
//================================================================
{
	string ps = string("JavaSystem::Init : begin") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

  //
  // First, make certain that error/warning messages won't be hidden by the
  // splash screen
  //
  HWND hWnd = 0 ;

  if (NULL != pContexte->getSuperviseur()->getApplication())
  {
  	TSplashWindow* pSplashWin = pContexte->getSuperviseur()->getApplication()->getSplashWindow() ;
    if (NULL != pSplashWin)
    	hWnd = pSplashWin->GetHandle() ;
  }

	//
  // Before calling JNI_CreateJavaVM, we make sure that there is a dll and
  // that the proper method is accessible
  //
  ps = string("JavaSystem::Init : loading jvm.dll") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

  TModule *jvmDll = 0 ;

  if (NULL != libPath)
  {
	  string sDll = string(libPath) + string("\\") + string("jvm.dll") ;
    ps = string("JavaSystem::Init : Trying to load ") + sDll ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
	  jvmDll = new TModule(sDll.c_str(), true, false /*don't throw an exception if can't load*/) ;
    if ((NULL == jvmDll) || (0 == jvmDll->GetHandle()))
    {
      if (NULL != jvmDll)
      {
        delete jvmDll ;
        jvmDll = 0 ;
      }
      ps = string("JavaSystem::Init : Failed to load ") + sDll ;
      pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    }
  }
  if ((NULL == jvmDll) || (0 == jvmDll->GetHandle()))
  {
    string sDll = string("jvm.dll") ;
    ps = string("JavaSystem::Init : Trying to load ") + sDll ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;

    jvmDll = new TModule(sDll.c_str(), true, false /*don't throw an exception if can't load*/) ;
  }
	if ((NULL == jvmDll) || (0 == jvmDll->GetHandle()))
  {
  	ps = string("JavaSystem::Init : Problem loading VM Java library (jvm.dll)") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
		erreur(ps.c_str(), standardError, 0, hWnd) ;
    return -1 ;
	}

  ps = string("JavaSystem::Init : jvm.dll loaded (") + string(jvmDll->GetName()) + string(")") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

  jint (JNICALL *JNI_CreateJavaVM)(JavaVM **pvm, void **penv, void *args) ;
  JNI_CreateJavaVM = (jint (JNICALL *)(JavaVM **, void **, void *)) jvmDll->GetProcAddress("JNI_CreateJavaVM") ;
  if (NULL == JNI_CreateJavaVM)
  {
  	ps = string("JavaSystem::Init : Could not find the JNI_CreateJavaVM function in the specified .DLL") ;
		pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    erreur(ps.c_str(), standardError, 0, hWnd) ;
    return -1 ;
  }

  //
  // Options initialization
  //
  if (classPath)
  	ps = string("- classPath : ") + string(classPath) ;
  else
  	ps = string("- classPath : NULL") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

  if (libPath)
  	ps = string("- libPath : ") + string(libPath) ;
  else
  	ps = string("- libPath : NULL") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

	JavaVMInitArgs vm_args ;
	JavaVMOption options[6] ;
	//JavaVMOption options[4];
	int optionsNb = 0;

	int len = strlen(classPath) ;
	char* classP = new char[30+len] ;
	sprintf(classP, "-Djava.class.path=%s", classPath) ;

	len = strlen(libPath) ;
	char* libP = new char[30+len] ;
	sprintf(libP, "-Djava.library.path=%s", libPath) ;

	options[optionsNb++].optionString = "-Xms16M" ;
	options[optionsNb++].optionString = "-Xmx256M" ;

	options[optionsNb++].optionString = classP ;
	options[optionsNb++].optionString = libP ;

  options[optionsNb].optionString = "vfprintf" ;
	options[optionsNb++].extraInfo = vfprintfHook ;

	if( verbose )
		options[optionsNb++].optionString = "-verbose:jni" ;
  //options[optionsNb++].optionString = "-Djava.compiler=NONE";

	vm_args.version  = JNI_VERSION_1_4 ;
	vm_args.options  = options ;
	vm_args.nOptions = optionsNb ;
	vm_args.ignoreUnrecognized = JNI_TRUE ;

  //
  // Now we can call JNI_CreateJavaVM
  //
  ps = string("JavaSystem::Init : calling JNI_CreateJavaVM") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

  //	return JNI_CreateJavaVM(&jvm, (void**)&jenv, &vm_args);
  jint err = JNI_CreateJavaVM(&jvm, (void**)&jenv, &vm_args) ;
  if (err < 0)
  {
  	ps = string("JavaSystem::Init : JNI_CreateJavaVM failed") ;
    switch (err)
    {
    	case -1 : ps += string(" (unknown error)") ; break ;
      case -2 : ps += string(" (thread detached from the VM)") ; break ;
      case -3 : ps += string(" (JNI version error)") ; break ;
      case -4 : ps += string(" (not enough memory)") ; break ;
      case -5 : ps += string(" (VM already created)") ; break ;
      case -6 : ps += string(" (invalid arguments)") ; break ;
      default : ps += string(" (unknown return error)") ; break ;
    }
		pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    erreur(ps.c_str(), standardError, 0, hWnd) ;
  }
  else
  {
  	ps = string("JavaSystem::Init : JNI_CreateJavaVM succeeded") ;
		pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;
  }

  return err ;
}

int JavaSystem::Init(NSContexte* pContexte, const char* fileName,
					 bool verbose)
//===============================================================
{
	//
  // First, make certain that error/warning messages won't be hidden by the
  // splash screen
  //
  HWND hWnd = 0 ;

  if (NULL != pContexte->getSuperviseur()->getApplication())
  {
  	TSplashWindow* pSplashWin = pContexte->getSuperviseur()->getApplication()->getSplashWindow() ;
    if (NULL != pSplashWin)
    	hWnd = pSplashWin->GetHandle() ;
  }

	FILE *file;
  string ps ;

	if ((fileName == NULL) || (fileName[0] == '\0'))
  {
  	string sErrorText = string("JavaSystem::Init : No file params. Exiting...") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, hWnd) ;
    return 1 ;
  }
  if ((file = fopen(fileName, "r")) == NULL)
  {
  	string sErrorText = string("JavaSystem::Init : Impossible to open ")
    											 + string(fileName) ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, hWnd) ;
		return 1 ;
  }

	static char * delim  = "= \t\n" ;
  static char * delim2 = "\t\n" ;
  char *rc ;
	char linebuffer[2000] ;   //big enough for classPath definition
	char *linebufferp ;

	char* classPath = NULL ;
	char* libPath   = NULL ;

	while (true)
	{
		rc = fgets(linebuffer, sizeof(linebuffer), file) ;
		if ((char *)NULL == rc)
			break ;

		if ((linebufferp = (char *)strtok(&linebuffer[0], delim)) == NULL)
			continue;   //read nextline

		if (*linebufferp == '#' ||
		    *linebufferp == 0   || *linebufferp == ' ')
			continue;   //read nextline

		if (0 == strcmp(linebufferp, "libPath"))
		{
			if ((linebufferp = (char *)strtok(NULL, delim2)) == NULL)
				continue ;
      while ((' ' == *linebufferp) || ('=' == *linebufferp))
        linebufferp++ ;

			libPath = new char[strlen(linebufferp)+1] ;
			strcpy(libPath, linebufferp) ;
		}

		if (0 == strcmp(linebufferp,"classPath"))
		{
			if ((linebufferp = (char *)strtok(NULL, delim2)) == NULL)
				continue ;
      while ((' ' == *linebufferp) || ('=' == *linebufferp))
        linebufferp++ ;

			classPath = new char[strlen(linebufferp)+1] ;
			strcpy(classPath, linebufferp) ;
		}
	}
	fclose(file) ;

  if (NULL != libPath)
    ps = string("JavaSystem::Init : Init with libpath : ") + string(libPath) ;
  else
    ps = string("JavaSystem::Init : libPath is NULL") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

  if (NULL != classPath)
    ps = string("JavaSystem::Init : Init with classPath : ") + string(classPath) ;
  else
    ps = string("JavaSystem::Init : classPath is NULL") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

	int stat = Init(pContexte, classPath, libPath, verbose) ;

	delete[] classPath ;
	delete[] libPath ;

	return stat ;
}

void JavaSystem::Close(NSContexte* /* pContexte */)
//======================
{
	jvm->DestroyJavaVM();
}

char* JavaSystem::NewStringWithSpecialCharacters(jstring myText)
//==============================================================
{
	// Using GetStringChars, ReleaseStringChars and NewString
	// GetStringChars get a UNICODE encoded string. This encoding IS supported by c++.
    // But we must do a little trick to get it right : the returned string seems to be shit when we prompt it,
    // because it's only one caracter long, but if we prompt it caracter by caracter, we see that all
    // the caracters are here, and rightly encoded. So we must make a copy of this string, by specifying
    // the fact that it is encoded in UNICODE. The copy we get is now fully usable.
    // Only bad thing : using NewString to send a string back to the java doesn't work.
	
    if( myText == NULL)
        return "";
	jboolean isCopy;
	const    jchar *str = jenv->GetStringChars(myText, &isCopy);
    jsize    sz         = jenv->GetStringLength(myText);

    char *str2 = new char[sz+1];
	for(int i=0; i<sz; i++)
	  str2[i] = (char)str[i];
	str2[sz] = '\0';

    if( isCopy == JNI_TRUE )
		jenv->ReleaseStringChars(myText, str);
    return str2;
}

string JavaSystem::NewStringObjWithSpecialCharacters(jstring myText)
//==============================================================
{
    char* str = NewStringWithSpecialCharacters(myText) ;
    string sReturn = string(str);
    delete str;
    return sReturn;

}