/*//////////////////////////////////////////////////////*/
/*														*/
/*	Created by:	Dominique Sauquet						*/
/*  Created on:	May 2003								*/
/*														*/
/*//////////////////////////////////////////////////////*/

#include "pilot\NautilusPilot.hpp"
#include "nsbb\nsmanager.h"
#include "nssavoir\nspatlnk.h"
#include "nautilus\nssuper.h"
#include "nsbb\tagNames.h"
#include "nsbb\nspatpat.h"

//tools services
string NautilusPilot::SERV_AGENTS_TEST                  = "agentsTest" ;
string NautilusPilot::SERV_GET_AGENT_LIST               = "getAgentList" ;
string NautilusPilot::SERV_GET_NEEDED_AGENT_LIST        = "getAllNeededAgentList" ;
string NautilusPilot::SERV_GET_TRAIT_LIST               = "getTraitList" ;

string NautilusPilot::SERV_SET_PARAMETERS               = "setEpisodusParameters" ;

string NautilusPilot::SERV_USER_LIST                    = "userList" ;
string NautilusPilot::SERV_USER_LIST_WITH_ROLES         = "userListWithRoles" ;
string NautilusPilot::SERV_LOGIN                        = "login" ;
string NautilusPilot::SERV_PATIENT_LIST                 = "patientList" ;
//patient list in group server
string NautilusPilot::SERV_GROUP_PATIENT_LIST           = "searchGroupPersonsFromTraits" ;
string NautilusPilot::SERV_OBJECT_LIST             	    = "searchObjectFromPartialTraits" ;
string NautilusPilot::SERV_OBJECT_LIST_WITH_TRAITS      = "getObjectListWithTraits" ;
string NautilusPilot::SERV_SEARCH_PATIENT               = "searchPatient" ;
//open group patient
string NautilusPilot::SERV_OPEN_GROUP_PATIENT           = "openPatientData" ;
//create group patient for epiPump
string NautilusPilot::SERV_CREATE_GROUP_PATIENT         = "createGroupPatient" ;
//modify group patient for epiPump
string NautilusPilot::SERV_MODIFY_GROUP_PATIENT         = "modifyGroupPerson" ;


string NautilusPilot::SERV_SEARCH_PATIENT_FROM_TRAITS   = "searchPatientFromTraits" ;
string NautilusPilot::SERV_CREATE_PATIENT               = "createPatient" ;
string NautilusPilot::SERV_CREATE_CORESPONDENT          = "createCorrespondent" ;
string NautilusPilot::SERV_CREATE_OBJECT                = "createObject" ;
string NautilusPilot::SERV_MODIFY_OBJECT                = "modifyObject" ;
string NautilusPilot::SERV_SEARCH_OBJECT                = "searchObjectFromTraits" ;
string NautilusPilot::SERV_SEARCH_OBJECT_FROM_ID        = "searchObjectFromId" ;
string NautilusPilot::SERV_SEARCH_OBJECT_HAVING_TRAITS  = "searchAllObjectsHavingTraits" ;
string NautilusPilot::SERV_CREATE_USER                  = "createUser" ;
string NautilusPilot::SERV_MODIFY_USER                  = "modifyUser" ;
string NautilusPilot::SERV_MODIFY_PERSON                = "modifyPerson" ;
string NautilusPilot::SERV_MODIFY_PERSON_TRAITS         = "modifyPersonTraits" ;
string NautilusPilot::SERV_MODIFY_PERSON_ROLE           = "modifyPersonRole" ;
string NautilusPilot::SERV_MODIFY_GRAPH_PERSON          = "modifyGraphPerson" ;
string NautilusPilot::SERV_SEARCH_PERSON                = "searchPersons" ;
string NautilusPilot::SERV_PERSON_LIST_FROM_TRAITS      = "searchPersonsFromTraits" ;
string NautilusPilot::SERV_READ_GRAPH_ADMIN             = "readTreesInGraph" ;
string NautilusPilot::SERV_READ_ADRESS_GRAPH            = "readTreesInObjectGraph" ;
string NautilusPilot::SERV_UNLOCK                       = "unlockPatient" ;
string NautilusPilot::SERV_UNLOCK_ALL_PATIENTS          = "unlockAllPatients" ;
string NautilusPilot::SERV_USER_PROPERTIES_LIST         = "getUserProperties" ;


//syncronizing services
string NautilusPilot::SERV_USER_IMPORT              = "importUser" ;
string NautilusPilot::SERV_CORRESPONDENT_IMPORT     = "importCorrespondent" ;
string NautilusPilot::SERV_CORRESPONDENT_IMPORT_ID  = "importCorrespondantWithId" ;
string NautilusPilot::SERV_PATIENT_IMPORT           = "importPatient" ;
//import group patient
string NautilusPilot::SERV_GROUP_PATIENT_IMPORT     = "importGroupPatient" ;


string NautilusPilot::SERV_CREATE_IMPORTED_PATIENT  = "createImportedPatient" ;
//create imported group patient
string NautilusPilot::SERV_CREATE_IMPORTED_GROUP_PATIENT = "createImportedGroupPatient" ;

string NautilusPilot::SERV_CREATE_IMPORTED_CORRESP  = "createImportedCorrespondent" ;
string NautilusPilot::SERV_CREATE_IMPORTED_USER     = "createImportedUser" ;
string NautilusPilot::SERV_GET_PERSON_INFORMATION   = "getPersonInformation" ;
string NautilusPilot::SERV_UPDATE_ALL_LDV_OBJECTS   = "importNewObjectsData" ;
string NautilusPilot::SERV_EXPORT_DATA              = "synchroLocalToCollective" ;
string NautilusPilot::SERV_IMPORT_DATA              = "readNewCollectiveData" ;
string NautilusPilot::SERV_ADD_MANDATE              = "addHealthTeamMembre" ;

//merging services
string NautilusPilot::SERV_MERGE_PATIENT                    = "mergePatient" ;
string NautilusPilot::SERV_OPEN_PATIENT_DATA_FROM_TRAITS    = "openPatientDataFromTraits" ;

// #define OBJECT_ID_LEN  PAT_NSS_LEN + DOC_CODE_DOCUM_LEN

jclass    NautilusPilot::classNautilusPilot   = NULL ;
jclass    NautilusPilot::classNautilusGraph   = NULL ;
jclass    NautilusPilot::classNode            = NULL ;
jclass    NautilusPilot::classMapping         = NULL ;
jclass    NautilusPilot::classDOMElement      = NULL ;
jclass    NautilusPilot::classStr             = NULL ;

jmethodID NautilusPilot::midReadGraphService  = NULL ;
jmethodID NautilusPilot::midReadGraph         = NULL ;
jmethodID NautilusPilot::midWriteGraph        = NULL ;
jmethodID NautilusPilot::midChildrenElements  = NULL ;
jmethodID NautilusPilot::midInvoke            = NULL ;
jmethodID NautilusPilot::midSimpInvoke        = NULL ;
jmethodID NautilusPilot::midNewGraph          = NULL ;
jmethodID NautilusPilot::midGetGraphId        = NULL ;
jmethodID NautilusPilot::midGetTreeId         = NULL ;

jmethodID NautilusPilot::midGetCurrentStep    = NULL ;
jmethodID NautilusPilot::midGetCurrentService = NULL ;

jmethodID NautilusPilot::midModify            = NULL ;

jfieldID NautilusPilot::jFidMnemo             = NULL ;
jfieldID NautilusPilot::jFidWarning           = NULL ;
jfieldID NautilusPilot::jFidStack             = NULL ;
jfieldID NautilusPilot::jFidStep							= NULL ;

long NSBasicAttribute::lObjectCount = 0 ;
long NSBasicAttributeArray::lObjectCount = 0 ;
long NSPersonsAttributesArray::lObjectCount = 0 ;

unsigned char* ASCIItoUNICODE (unsigned char ch)
{
  unsigned char Val[2] ;
  if ((ch < 192) && (ch != 168) && (ch != 184))
  {
    Val[0] = 0 ;
    Val[1] = ch ;
    return Val ;
  }
  if (ch == 168)
  {
    Val[0] = 208 ;
    Val[1] = 129 ;
    return Val ;
  }
  if (ch == 184)
  {
    Val[0] = 209 ;
    Val[1] = 145 ;
    return Val ;
  }
  if (ch < 240)
  {
    Val[0] = 208 ;
    Val[1] = ch - 48 ;
    return Val ;
  }
  if (ch < 249)
  {
    Val[0] = 209 ;
    Val[1] = ch - 112 ;
    return Val ;
  }
  return NULL ;
}

unsigned int* ConvertString (unsigned char *string)
{
  unsigned int size=0, *NewString;
  unsigned char* Uni;
  while (string[size++] != 0) ;
  NewString = (unsigned int*)malloc(sizeof(unsigned int)*2*size-1) ;
  NewString[0] = 2 * size - 1 ;
  size = 0 ;
  while (string[size] != 0)
  {
    Uni = ASCIItoUNICODE(string[size]) ;
    NewString[2*size+1]=Uni[0] ;
    NewString[2*size+2]=Uni[1] ;
    size++ ;
  }
  return NewString ;
}

// -----------------------------------------------------------------------------
// NautilusPilot
// -----------------------------------------------------------------------------
int
NautilusPilot::Init()
//=======================
{
try
{
	JNIEnv* jenv = JavaSystem::jenv ;

  //=== find the classes
  classNautilusPilot = jenv->FindClass("nautilus/NautilusPilot") ;
  if (classNautilusPilot == 0)
  {
  	fprintf(stderr, "Cannot locate the nautilus/NautilusPilot class. Exiting...\n") ;
    return -1 ;
	}

  classNautilusGraph = jenv->FindClass("nautilus/NautilusGraph") ;
  if (classNautilusGraph == 0)
  {
  	fprintf(stderr, "Cannot locate the nautilus/NautilusGraph class. Exiting...\n") ;
    return -2 ;
	}

  classNode = jenv->FindClass("graphServer/Node") ;
  if (classNode == 0)
  {
  	fprintf(stderr, "Cannot locate the graphServer/Node class. Exiting...\n") ;
    return -3 ;
	}

  classMapping = jenv->FindClass("graphServer/Mapping") ;
  if (classMapping == 0)
  {
  	fprintf(stderr, "Cannot locate the graphServer/Mapping class. Exiting...\n") ;
    return -4 ;
  }

  classDOMElement = jenv->FindClass("domlightwrapper/DOMElement") ;
  if (classMapping == 0)
  {
  	fprintf(stderr, "Cannot locate the domlightwrapper/DOMElement class. Exiting...\n") ;
    return -5 ;
	}

  midChildrenElements = jenv->GetMethodID(classDOMElement, "getChildrenElements",
                "(Ljava/lang/String;)[Ldomlightwrapper/DOMElement;") ;
  if (midChildrenElements == 0)
  {
  	erreur("Cannot locate the DOMElement getChildrenElements method. Exiting...\n", standardError, 0, 0) ;
    return -6 ;
	}

  //=== get method id for the NautilusPilot.readGraph method
  midReadGraph =  jenv->GetMethodID(classNautilusPilot, "readGraph",
                    "(Ljava/lang/String;)Lnautilus/NautilusGraph;") ;

	midReadGraphService = jenv->GetMethodID(classNautilusPilot, "readGraph",
                          "(Ljava/lang/String;Ljava/lang/String;)Lnautilus/NautilusGraph;") ;
	if ((midReadGraph == 0) ||(midReadGraphService == 0))
  {
  	fprintf(stderr, "Cannot locate the NautilusPilot readGraph method. Exiting...\n") ;
    return -7 ;
	}
  //=== get method id for the NautilusPilot.writeGraph method

  midWriteGraph = jenv->GetMethodID(classNautilusPilot, "writeGraph",
                    "(Lnautilus/NautilusGraph;)[LgraphServer/Mapping;") ;
	if (midWriteGraph == 0)
  {
  	fprintf(stderr, "Cannot locate the NautilusPilot writeGraph method. Exiting...\n") ;
    return -8 ;
	}
  //=== get method id for the NautilusPilot.invokeService method
  midInvoke = jenv->GetMethodID(classNautilusPilot, "invokeService",
                    "(Ljava/lang/String;Lnautilus/NautilusGraph;[Ljava/lang/String;)[LgraphServer/Mapping;") ;

	if (midInvoke == 0)
  {
		fprintf(stderr, "Cannot locate the NautilusPilot invokeService method. Exiting...\n") ;
    return -9 ;
	}

	midSimpInvoke = jenv->GetMethodID(classNautilusPilot, "invokeService",
            "(Ljava/lang/String;[Ljava/lang/String;)Lnautilus/NautilusGraph;") ;
	if (midSimpInvoke == 0)
  {
  	fprintf(stderr, "Cannot locate the NautilusPilot invokeService method. Exiting...\n") ;
    return -10 ;
	}
  jFidMnemo = jenv->GetFieldID(classNautilusPilot, "mnemo", "Ljava/lang/String;") ;
  if (jFidMnemo == 0)
  	return -11 ;

	jFidStack = jenv->GetFieldID(classNautilusPilot, "stack", "Ljava/lang/String;") ;
  if (jFidStack == 0)
  	return -12 ;

	jFidStep = jenv->GetFieldID(classNautilusPilot, "stepError", "Ljava/lang/String;") ;
  if (jFidStep == 0)
  	return -13 ;

	jFidWarning = jenv->GetFieldID(classNautilusPilot, "warningMessage", "Ljava/lang/String;") ;
  if (jFidWarning == 0)
  	return -14 ;

	//=== get method id for the NautilusGraph constructor method
  midNewGraph = jenv->GetMethodID(classNautilusGraph, "<init>",
                                    "(SLjava/lang/String;IIII)V") ;
	if (midNewGraph == 0)
  {
  	fprintf(stderr, "Cannot locate the NautilusGraph constructor method. Exiting...\n") ;
    return -15 ;
	}

	//=== get method id for the NautilusGraph getTreeId method
  midGetTreeId = jenv->GetMethodID(classNautilusGraph, "getTreeId",
                                    "(I)Ljava/lang/String;") ;
	if (midGetTreeId == 0)
  {
  	fprintf(stderr, "Cannot locate the NautilusGraph getTreeId method. Exiting...\n") ;
    return -16 ;
	}

  //=== get method id for the NautilusGraph getGraphId method
  midGetGraphId = jenv->GetMethodID(classNautilusGraph, "getGraphId",
                                    "()Ljava/lang/String;") ;
	if (midGetGraphId == 0)
  {
  	fprintf(stderr, "Cannot locate the NautilusGraph getGraphId method. Exiting...\n") ;
    return -17 ;
	}

	classStr = jenv->FindClass("java/lang/String") ;
  if (classStr == NULL)
  {
  	fprintf(stderr, "Cannot locate the java/lang/String class. Exiting...\n") ;
    return -18 ;
	}

	//=== execute method init of the NautilusPilot class
	jmethodID midInit = jenv->GetStaticMethodID(classNautilusPilot, "init", "()V") ;
	if (midInit == 0)
  {
  	fprintf(stderr, "Cannot locate the NautilusPilot init method. Exiting...\n") ;
    return -19 ;
	}

	jenv->CallStaticObjectMethod(classNautilusPilot, midInit) ;

  //=== get method id for the NautilusGraph getGraphId method
  midGetCurrentStep = jenv->GetMethodID(classNautilusPilot, "getCurrentStepName",
                                    "()Ljava/lang/String;") ;
  if (midGetCurrentStep == 0)
  {
  	fprintf(stderr, "Cannot locate the NautilusGraph getCurrentStepName method. Exiting...\n") ;
    return -20 ;
	}

  //=== get method id for the NautilusGraph getGraphId method
  midGetCurrentService = jenv->GetMethodID(classNautilusPilot, "getCurrentServiceName",
                                    "()Ljava/lang/String;") ;
  if (midGetCurrentService == 0)
  {
  	fprintf(stderr, "Cannot locate the NautilusGraph getCurrentServiceName method. Exiting...\n") ;
    return -21 ;
	}

  midModify = jenv->GetMethodID(classNautilusPilot, "invokeService",
                "(Ljava/lang/String;Lnautilus/NautilusGraph;[Ljava/lang/String;)[LgraphServer/Mapping;") ;
	if (midModify == 0)
	{
  	erreur("Cannot locate the NautilusPilot invokeService (2) method.",standardError, 0, 0) ;
		return -22 ;
	}

	return 0 ;
}
catch (...)
{
	erreur("Exception NautilusPilot::Init", standardError, 0) ;
	return -14 ;  // FIXME should be -23 ?
}
}


int NautilusPilot::jni_getNbTrees(JNIEnv* jenv, jobject jGraph)
//=============================================================
{
	if ((!jenv) || (jGraph == NULL))
  	return -1 ;

	//=== get method id for the NautilusGraph.getNumberOfTrees method
	jmethodID mid = jenv->GetMethodID(classNautilusGraph, "getNumberOfTrees", "()I") ;
	if (mid == NULL)
	{
		fprintf(stderr, "Cannot locate the NautilusGraph getNumberOfTrees method. Exiting...\n") ;
		return -1 ;
	}
	return jenv->CallIntMethod(jGraph, mid) ;
}

int NautilusPilot::jni_getNbLinks(JNIEnv* jenv, jobject jGraph)
//=============================================================
{
	if ((!jenv) || (jGraph == NULL))
  	return -1 ;

	//=== get method id for the NautilusGraph.getNumberOfLinks method
	jmethodID mid = jenv->GetMethodID(classNautilusGraph, "getNumberOfLinks", "()I") ;
	if (mid == NULL)
	{
		fprintf(stderr, "Cannot locate the NautilusGraph getNumberOfLinks method. Exiting...\n") ;
		return -1 ;
	}
	return jenv->CallIntMethod(jGraph, mid) ;
}

int NautilusPilot::jni_getNbModels(JNIEnv* jenv, jobject jGraph)
//==============================================================
{
	if ((!jenv) || (jGraph == NULL))
  	return -1 ;

	//=== get method id for the NautilusGraph.getNumberOfModels method
	jmethodID mid = jenv->GetMethodID(classNautilusGraph, "getNumberOfModels", "()I") ;
	if (mid == NULL)
	{
		fprintf(stderr, "Cannot locate the NautilusGraph getNumberOfModels method. Exiting...\n") ;
		return -1 ;
	}
	return jenv->CallIntMethod(jGraph, mid) ;
}

int
NautilusPilot::jni_getNbRights(JNIEnv* jenv, jobject jGraph)
//==============================================================
{
	if ((!jenv) || (jGraph == NULL))
  	return -1 ;

	jmethodID mid = jenv->GetMethodID(classNautilusGraph, "getNumberOfRights", "()I") ;
	if (mid == 0)
	{
		fprintf(stderr, "Cannot locate the NautilusGraph getNumberOfRights method. Exiting...\n") ;
		return -1 ;
	}
	return jenv->CallIntMethod(jGraph, mid) ;
}

char* NautilusPilot::jni_getAttribute(JNIEnv* jenv, jobject jGraph,
                                                    char* method, int i)
//======================================================================
{
	if ((!jenv) || (!method) || (jGraph == NULL))
  	return NULL ;

	//=== get method id for the NautilusGraph method
	jmethodID mid = jenv->GetMethodID(classNautilusGraph, method,
                                    "(I)Ljava/lang/String;");
	if (mid == NULL)
	{
		fprintf(stderr, "Cannot locate the NautilusGraph method. Exiting...\n");
		return NULL;
	}
	jstring jResult = (jstring)jenv->CallObjectMethod(jGraph, mid, i);
  if (jResult == NULL)
  {
  	fprintf(stderr, "NautilusPilot::jni_getAttribute : CallObjectMethod failed. Exiting...\n");
  	return NULL ;
  }

	char *result = JavaSystem::NewStringWithSpecialCharacters(jResult);

  jenv->DeleteLocalRef(jResult);
	return result;
}

string NautilusPilot::jni_getGraphId(JNIEnv* jenv, jobject jGraph)
//================================================================
{
	if ((!jenv) || (jGraph == NULL))
  	return string("") ;

	//=== execute NautilusGraph.getGraphId method
	jstring jResult = (jstring)jenv->CallObjectMethod(jGraph, midGetGraphId) ;
    if (jResult == NULL)
    {
  	    fprintf(stderr, "NautilusPilot::jni_getGraphId : CallObjectMethod failed. Exiting...\n");
  	    return string("") ;
    }

	char *result = JavaSystem::NewStringWithSpecialCharacters(jResult) ;

	jenv->DeleteLocalRef(jResult) ;
	if( result != NULL )
	{
		string id = string(result) ;
		delete[] result ;
		return id ;
	}
	return string("") ;
}

/*   Return curent step name being executed
*/
string NautilusPilot::getCurrentStepName()
//========================================
{
    JNIEnv* jenv = JavaSystem::jenv ;
	if (!jenv)
  	    return string("") ;

	//=== execute NautilusGraph.getGraphId method
	jstring jResult = (jstring)jenv->CallObjectMethod(jNautilusPilot, midGetCurrentStep) ;
    if (jResult == NULL)
    {
  	    fprintf(stderr, "NautilusPilot::getCurrentStepName : CallObjectMethod failed. Exiting...\n");
  	    return string("") ;
    }

	char *result = JavaSystem::NewStringWithSpecialCharacters(jResult) ;

	jenv->DeleteLocalRef(jResult) ;
	if( result != NULL )
	{
		string mes = string(result) ;
		delete[] result ;
		return mes ;
	}
	return string("") ;
}

/*
*   Return curent step name being executed
*/
string NautilusPilot::getCurrentServiceName()
//=======================================================
{
    JNIEnv* jenv = JavaSystem::jenv ;
	if (!jenv)
  	    return string("") ;

	//=== execute NautilusGraph.getGraphId method
	jstring jResult = (jstring)jenv->CallObjectMethod(jNautilusPilot, midGetCurrentService) ;
    if (jResult == NULL)
    {
  	    fprintf(stderr, "NautilusPilot::midGetCurrentService : CallObjectMethod failed. Exiting...\n");
  	    return string("") ;
    }

	char *result = JavaSystem::NewStringWithSpecialCharacters(jResult) ;

	jenv->DeleteLocalRef(jResult) ;
	if( result != NULL )
	{
		string mes = string(result) ;
		delete[] result ;
		return mes ;
	}
	return string("") ;
}

/**
*  Return curent step user name being executed.
* User name is defined in localisation.dat. The service name is chapter name.
*/
string NautilusPilot::getCurrentStepUserName(string stepName, string serviceName)
//==============================================================================
{
	if((stepName=="")|| (serviceName==""))
        return "";

    string sText = pContexte->getSuperviseur()->getText(serviceName, stepName);
    if( sText == "" )               //stepName message not found in the localisation file
        sText = stepName;           //keep the stepName
    return sText.c_str();
}

/**
*  Return curent step user name being executed.
* User name is defined in localisation.dat. The service name is chapter name.
*/
string NautilusPilot::getCurrentStepUserName()
//============================================
{
    string stepName =  getCurrentStepName() ;
    string serviceName = getCurrentServiceName();

	if((stepName=="")||(serviceName==""))
        return "";

    string sText = pContexte->getSuperviseur()->getText(serviceName, stepName);
    if( sText == "" )               //stepName message not found in the localisation file
        sText = stepName;           //keep the stepName
    return sText.c_str();
}

string NautilusPilot::jni_getTreeId(JNIEnv* jenv, jobject jGraph, int i)
//======================================================================
{
	if ((!jenv) || (jGraph == NULL))
		return string("") ;

	//=== execute NautilusGraph.getTreeId method
	jstring jResult = (jstring)jenv->CallObjectMethod(jGraph, midGetTreeId, i) ;
  if (jResult == NULL)
  {
  	fprintf(stderr, "NautilusPilot::jni_getTreeId : CallObjectMethod failed. Exiting...\n");
  	return string("") ;
  }

	char *result = JavaSystem::NewStringWithSpecialCharacters(jResult) ;

	jenv->DeleteLocalRef(jResult) ;
	if( result != NULL )
	{
		string id = string(result) ;
		delete[] result ;
		return id ;
	}
	return string("") ;
}

jobject NautilusPilot::jni_getTree(JNIEnv* jenv, jobject jGraph, int i)
//=====================================================================
{
	if ((!jenv) || (jGraph == NULL))
		return NULL ;

	//=== get method id for the NautilusGraph.getTree method
	jmethodID mid = jenv->GetMethodID(classNautilusGraph, "getTree",
                                    "(I)LgraphServer/Tree;");
	if (mid == 0)
	{
		fprintf(stderr, "Cannot locate the NautilusGraph method. Exiting...\n");
		return NULL;
	}

	return jenv->CallObjectMethod(jGraph, mid, i);
}

jobjectArray NautilusPilot::jni_getTreeNodes(JNIEnv* jenv, jobject jGraph, int i)
//===============================================================================
{
	if ((!jenv) || (jGraph == NULL))
		return NULL ;

	//=== get method id for the NautilusGraph.getTreeNodes method
	jmethodID mid = jenv->GetMethodID(classNautilusGraph, "getTreeNodes",
                                    "(I)[LgraphServer/Node;");
	if (mid == 0)
	{
		fprintf(stderr, "Cannot locate the NautilusGraph method. Exiting...\n");
		return NULL;
	}
	return (jobjectArray)jenv->CallObjectMethod(jGraph, mid, i);
}

char* NautilusPilot::jni_getNodeField(JNIEnv* jenv, char* fieldName, jobject aNode)
//=================================================================================
{
	if ((!jenv) || (!fieldName) || (aNode == NULL))
		return NULL ;

	//=== get method id for the NautilusGraph.getTreeId method
	jfieldID jFid = jenv->GetFieldID(classNode, fieldName, "Ljava/lang/String;") ;
	if( jFid == NULL)
  {
  	fprintf(stderr, "NautilusPilot::jni_getNodeField : GetFieldID failed. Exiting...\n");
		return NULL ;
  }
	jstring jResult = (jstring)jenv->GetObjectField(aNode, jFid) ;
	if( jResult == NULL )
  {
		fprintf(stderr, "NautilusPilot::jni_getNodeField : GetObjectField failed. Exiting...\n");
		return NULL ;
  }

	char *result = JavaSystem::NewStringWithSpecialCharacters(jResult) ;
  jenv->DeleteLocalRef(jResult) ;
	return result ;
}

char** NautilusPilot::jni_getMappingField(JNIEnv* jenv, char* fieldName,
                                        jobjectArray jMappings, jint nbMaps)
//==========================================================================
{
	if ((!jenv) || (!fieldName) || (jMappings == NULL) || (nbMaps <= 0))
		return NULL ;

	//=== get field id for a field of the graphServer.Mapping class
	jfieldID jFid = jenv->GetFieldID(classMapping, fieldName, "Ljava/lang/String;");
  if( jFid == NULL)
	{
		fprintf(stderr, "NautilusPilot::jni_getMappingField : GetFieldID failed. Exiting...\n");
		return NULL ;
	}

	char** attributes = new char*[nbMaps];
	for( int i=0; i<nbMaps; i++)
	{
		jobject obj = jenv->GetObjectArrayElement(jMappings, i) ;
		if (obj != NULL)
		{
			jstring jResult = (jstring)jenv->GetObjectField(obj, jFid);
			if( jResult != NULL )
            {
				attributes[i] = JavaSystem::NewStringWithSpecialCharacters(jResult);
                jenv->DeleteLocalRef(jResult) ; //add by non jnisien
            }
            else
      	        fprintf(stderr, "NautilusPilot::jni_getMappingField : GetObjectField failed.\n");
            jenv->DeleteLocalRef(obj) ;
		}
	}
	return attributes ;
}

const char*
NautilusPilot::getTextError(JNIEnv* jenv, string sChap, bool bNotFound)
//=====================================================================
{
	if (!jenv)
		return NULL ;

	jstring jMnemo = (jstring)jenv->GetObjectField(jNautilusPilot, jFidMnemo) ;
	if((jMnemo != NULL )    &&         // mnemo error information
  		(string(JavaSystem::NewStringWithSpecialCharacters(jMnemo)) != "") )
	{
		// jsize size = (jsize)jenv->GetStringUTFLength(jMnemo) ;
		string sMnemo = string(JavaSystem::NewStringWithSpecialCharacters(jMnemo));
    string sErrorText = pContexte->getSuperviseur()->getText(sChap, sMnemo);
		if( sErrorText == "" )              //mnemo error not found in the localisation file
			sErrorText = sMnemo;     //keep the mnemo
        return sErrorText.c_str();
	}
	else
	{                           //try to get stack information
		jstring jStack = (jstring)jenv->GetObjectField(jNautilusPilot, jFidStack) ;
		if(jStack != NULL)
			return JavaSystem::NewStringWithSpecialCharacters(jStack);
    else
		{                           //try to get a step error information
			jstring jStep = (jstring)jenv->GetObjectField(jNautilusPilot, jFidStep) ;
			if(jStep != NULL)
				return JavaSystem::NewStringWithSpecialCharacters(jStep);
		}
	}
	if(!bNotFound)
		return (pContexte->getSuperviseur()->getText(sChap, "nonInstancedError")).c_str() ;
	else
		return "";
}

/*
    if 0 -- MAPPING_RETURN
     1 -- DOMELEMENT_RETURN
     2 -- GRAPH_RETURN
used from createPatient*/
int
NautilusPilot::getReturnType(JNIEnv* jenv)
//=========================================
{
	if (!jenv)
		return -1 ;

	jfieldID jFid = jenv->GetFieldID(classNautilusPilot, "returnDataType", "I");
	int iRes = (jint)jenv->GetIntField(jNautilusPilot, jFid);

	switch (iRes)
	{
  	case 0:
    	return MAPPING_RETURN;
		case 1:
			return DOMELEMENT_RETURN;
		case 2:
			return GRAPH_RETURN;
		case 3:
			return EMPTY_RETURN;
        case 4:
            return WARNING_RETURN;
	};
	return -1;
}

string
NautilusPilot::getTextWarning(JNIEnv* jenv, string sChap)
//=======================================================
{
	if (!jenv)
		return NULL ;

	jstring jWarning = (jstring)jenv->GetObjectField(jNautilusPilot, jFidWarning) ;
	if(jWarning != NULL )             // warnings
    {
        string sWarning = string(JavaSystem::NewStringWithSpecialCharacters(jWarning));
		return pContexte->getSuperviseur()->getText(sChap, sWarning);
    }
    else
        //return "nonInstancedWarning" ;
        return pContexte->getSuperviseur()->getText(sChap, "nonInstancedWarning") ;
}


// groupeTag = la balise resultat qui groupe plusieures personnes ou objects (ex. list)
//balise = la balise qui delimite un groupe (ex. person, object)
void
NautilusPilot::transformResultFieldInAttributesArray(JNIEnv* jenv, NSPersonsAttributesArray* pList,
                                            string groupeTag, string balise)
//=================================================================================================
{
	if ((!jenv) || (!pList))
		return ;
try
{
	jstring  jName   = jenv->NewStringUTF( groupeTag.c_str() );
	jmethodID midResult = jenv->GetMethodID(classNautilusPilot, "getResultExec",
                                    "(Ljava/lang/String;)Ldomlightwrapper/DOMElement;");

	if (!midResult)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("pilotManagement", "cannotGetJniMethodId") ;
		sErrorText += string(" (fct : getResultExec)") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return ;
	}

	jobject jObject =  jenv->CallObjectMethod(jNautilusPilot, midResult, jName);
	if (!jObject)
  {
		string ps2 = string("NautilusPilot::transformResultFieldInAttributesArray : CallObjectMethod failed") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
		return ;
  }
	jstring  jNodeName   = jenv->NewStringUTF( balise.c_str() ) ;

	jobjectArray jDomElems = (jobjectArray)jenv->CallObjectMethod(jObject, midChildrenElements, jNodeName) ;
	jenv->DeleteLocalRef(jNodeName) ;
	jenv->DeleteLocalRef(jName) ;

	int count = 0;
	if (jDomElems == NULL)
	{
  	string ps2 = string("NautilusPilot::transformResultFieldInAttributesArray : CallObjectMethod failed") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
		return ;
	}
	count = jenv->GetArrayLength(jDomElems) ;

	if (balise == "*")
	{
		NSBasicAttributeArray* pIDAttributes = new NSBasicAttributeArray() ;
		for (int i=0; i<count; i++)
		{
			jobject jNodeElem = jenv->GetObjectArrayElement(jDomElems, i) ;
			if (jNodeElem != NULL)
			{
				if ((getTagName(jNodeElem) == "") /*||(getText(jNodeElem) == "")*/ )
        {
        	delete pIDAttributes ;
        	return ;
        }
				NSBasicAttribute* pAttribute = new NSBasicAttribute() ;
				pAttribute->setBalise(getTagName(jNodeElem)) ;
				pAttribute->setText(getText(jNodeElem)) ;

				pIDAttributes->push_back(pAttribute) ;

				jenv->DeleteLocalRef(jNodeElem) ;
			}
      else
      {
      	string ps2 = string("NautilusPilot::transformResultFieldInAttributesArray : GetObjectArrayElement failed");
				pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError);
      }
    }
		pList->push_back(pIDAttributes) ;
	}
	else
		for (int i=0; i<count; i++)
		{
			jobject jNodeElem = jenv->GetObjectArrayElement(jDomElems, i) ;
			if (jNodeElem)
			{
				NSBasicAttributeArray* pIDAttributes = new NSBasicAttributeArray() ;

				DOMTreeToBasicAttribute(pIDAttributes, jNodeElem) ;
        if (pIDAttributes)
					pList->push_back(pIDAttributes) ;

				jenv->DeleteLocalRef(jNodeElem) ;
			}
      else
      {
      	string ps2 = string("NautilusPilot::transformResultFieldInAttributesArray : GetObjectArrayElement failed");
				pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError);
      }
		}
}
catch (...)
{
	erreur("Exception NautilusPilot::transformResultFieldInAttributesArray", standardError, 0) ;
}
}


bool NautilusPilot::toBeChanged(string id)
//========================================
{
    if( id[0] == '#' )
      return true;
    return false;
}
bool NautilusPilot::toBeChangedForComposedId(string id)
//=====================================================
{
    //in case of Graph of type Person : the test means "new person or new document"
    //in case of Graph of type Object : the test means "new object" (condition id[PAT_NSS_LEN] always false)

    if( (id[0] == '#') || (id[PAT_NSS_LEN] == '#') )     //for a patient
      return true;
    else
        if( (id[0] == '$') && (id[1] == '#') )            //for a object
        return true;
    return false;
}

NautilusPilot::NautilusPilot(NSContexte* pCtx) : Pilot(), NSRoot(pCtx)
//====================================================================
{
	JNIEnv* jenv = JavaSystem::jenv ;
    if (!jenv)
    {
		fprintf(stderr, "NautilusPilot ctor : jenv is null. Exiting...\n");
  	    return ;
    }

	//=== execute method init of the NautilusPilot class
	jmethodID jmidNewNautPilot = jenv->GetMethodID(classNautilusPilot, "<init>",
                                    "(Lpilot/Pilot;)V");
	if (jmidNewNautPilot == 0)
    {
		fprintf(stderr, "NautilusPilot ctor : Cannot locate the NautilusGraph constructor method. Exiting...\n");
  	    return ;
    }

	jNautilusPilot = jenv->NewObject(classNautilusPilot, jmidNewNautPilot, newPilot) ;
  pAvailableAgentList = new NSAgentStatusArray() ;
  pPropertiesServicesList = new NSServiceStatusArray() ;
}

NautilusPilot::~NautilusPilot()
//=============================
{
    if(pAvailableAgentList !=NULL)
        delete pAvailableAgentList;
    if( pPropertiesServicesList != NULL)
    	delete pPropertiesServicesList ;
}

bool
NautilusPilot::readGraph( NSDataGraph* pGraph, string sServiceName)
//=================================================================
{
	JNIEnv* jenv = JavaSystem::jenv ;
	if (NULL == jenv)
  {
		string ps2 = string("NautilusPilot::readGraph : jenv is null. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    return false ;
  }

	//=== execute a NautilusGraph.readGraph method
	jstring jId  = jenv->NewStringUTF( (pGraph->getGraphID()).c_str() ) ;
	jobject jGraph ;
	if (string("") != sServiceName)
	{
		jstring jServiceName = jenv->NewStringUTF( sServiceName.c_str() ) ;
		jGraph = jenv->CallObjectMethod(jNautilusPilot, midReadGraphService, jId, jServiceName) ;
	}
	else
		jGraph = jenv->CallObjectMethod(jNautilusPilot, midReadGraph, jId) ;

	if (NULL == jGraph)
  {
  	string ps2 = string("NautilusPilot::readGraph : CallObjectMethod failed. Exiting...") ;
    pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    return false ;
	}

	// build a C graph from the java graph object
	//===========================================
	buildGraphForC(jenv, jGraph, pGraph) ;
	jenv->DeleteLocalRef(jGraph) ;
	return true ;
}

//return the admin ou Dpros graph
//input data : id person + arrays (link="HA"; link="HP")
bool
NautilusPilot::readGraphAdmin( string sServiceName, NSDataGraph* pGraph,
																							NSBasicAttributeArray *pAttrArray)
//==============================================================================
{
	if ((NULL == pGraph) || (NULL == pAttrArray))
  	return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
  if (NULL == jenv)
  {
		string ps2 = string("NautilusPilot::readGraphAdmin : jenv is null. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    return false ;
  }
	jobjectArray strArray = createJObjectArray(pAttrArray) ;
  if (NULL == strArray)
  {
  	string ps2 = string("NautilusPilot::readGraphAdmin : createJObjectArray failed. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
		return false ;
  }

	//=== execute a NautilusGraph.readGraph method
  jobject jGraph ;
	jstring jServiceName  = jenv->NewStringUTF( sServiceName.c_str() ) ;
	jGraph = jenv->CallObjectMethod(jNautilusPilot, midSimpInvoke, jServiceName, strArray) ;

	if (NULL == jGraph)
	{
  	string ps2 = string("NautilusPilot::readGraphAdmin : CallObjectMethod failed. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
		return false ;
  }
	// build a C graph from the java graph object
	//===========================================
  buildGraphForC(jenv, jGraph, pGraph) ;

	jenv->DeleteLocalRef(jGraph) ;
	return true ;
}


/* imput data  patient ancien + new patient
                console + instance
    return merge Graph
*/
bool
NautilusPilot::mergePatient( string sServiceName, NSDataGraph* pGraph, NSBasicAttributeArray *pAttrArray)
//=========================================================================================================
{
	if ((NULL == pGraph) || (NULL == pAttrArray))
  	return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
	if (NULL == jenv)
	{
		string ps2 = string("NautilusPilot::mergepatient : jenv is null. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    return false ;
	}

	jobjectArray strArray = createJObjectArray(pAttrArray) ;
	if (NULL == strArray)
	{
		string ps2 = string("NautilusPilot::mergepatient : createJObjectArray failed. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
		return false ;
	}

	//=== execute a NautilusGraph.readGraph method
	jobject jGraph ;
	jstring jServiceName  = jenv->NewStringUTF( sServiceName.c_str() ) ;
	jGraph = jenv->CallObjectMethod(jNautilusPilot, midSimpInvoke, jServiceName, strArray) ;

	if((NULL == jGraph) && (WARNING_RETURN == getReturnType(jenv))) //WARNING_RETURN
	{
  	warningMessage = string(getTextWarning(jenv, "NTIERS")) ;
    return false ;
	}
	// build a C graph from the java graph object
	//===========================================
	buildGraphForC(jenv, jGraph, pGraph) ;

	jenv->DeleteLocalRef(jGraph) ;
	return true ;
}

//return adresse graph
//input data : id from an adresse object  + arrays (link="IN")  + direction
//( FORWORD = 0; BACK = 1; DOUBLE_SENS = 2;)
bool
NautilusPilot::readAdressGraph(string sServiceName, NSDataGraph* pGraph, NSBasicAttributeArray *pAttrArray)
//=========================================================================================================
{
	if ((NULL == pGraph) || (NULL == pAttrArray))
  	return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
	if (NULL == jenv)
	{
		string ps2 = string("NautilusPilot::readAdressGraph : jenv is null. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    return false ;
	}

	jobjectArray strArray = createJObjectArray(pAttrArray);
	if (NULL == strArray)
	{
  	string ps2 = string("NautilusPilot::readAdressGraph : createJObjectArray failed. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    return false ;
	}
	//=== execute a NautilusGraph.readGraph method
	jobject jGraph ;
	jstring jServiceName  = jenv->NewStringUTF( sServiceName.c_str() ) ;

	jGraph = jenv->CallObjectMethod(jNautilusPilot, midSimpInvoke, jServiceName, strArray) ;
	jenv->DeleteLocalRef(strArray) ;
	jenv->DeleteLocalRef(jServiceName) ;
	if (NULL == jGraph)
	{
  	string ps2 = string("NautilusPilot::readAdressGraph : CallObjectMethod failed. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    return false ;
	}

	// build a C graph from the java graph object
	//===========================================
	buildGraphForC(jenv, jGraph, pGraph) ;

	jenv->DeleteLocalRef(jGraph) ;
	return true ;
}

bool NautilusPilot::writeGraph( NSDataGraph* pGraph)
//==================================================
{
	if (NULL == pGraph)
	{
		string ps2 = "NautilusPilot::writeGraph : no graph, exiting" ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;
		return false ;
	}

	JNIEnv* jenv = JavaSystem::jenv ;
	if (NULL == jenv)
	{
		string ps2 = string("NautilusPilot::writeGraph : jenv is null. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    return false ;
	}

	int nbTrees  = 0;
	int nbLinks  = 0;
	int nbModels = 0;
	int nbRights = 0;

	jobject jGraph = buildGraphForJava(jenv, pGraph, nbTrees, nbLinks, nbModels, nbRights);
	if ((nbTrees == 0) || (jGraph == NULL))
	{
  	jenv->DeleteLocalRef(jGraph) ;
    return false ;
	}

	jobjectArray jMappings = (jobjectArray)jenv->CallObjectMethod(jNautilusPilot, midWriteGraph, jGraph);
	jenv->DeleteLocalRef(jGraph) ;
	if (NULL == jMappings)
	{
		string ps2 = string("NautilusPilot::writeGraph : CallObjectMethod failed. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    jenv->DeleteLocalRef(jMappings) ;
    return false ;
	}

	applyMappings(jenv, jMappings, pGraph, nbTrees, nbLinks, nbModels, nbRights) ;
	jenv->DeleteLocalRef(jMappings) ;

	return true ;
}



//used for patient reseach
bool NautilusPilot::invokeService(const char* serviceName, NSDataGraph* pGraph,
                                    NSBasicAttributeArray *pAttrArray)
//=====================================================================================
{
	if ((NULL == serviceName) || (NULL == pGraph) || (NULL == pAttrArray))
  	return false ;

	JNIEnv* jenv = JavaSystem::jenv;
	if (NULL == jenv)
	{
  	fprintf(stderr, "NautilusPilot::invokeService : jenv is null. Exiting...") ;
    return false ;
	}

	jobjectArray strArray = createJObjectArray(pAttrArray) ;
	if (strArray == NULL)
	{
  	fprintf(stderr, "NautilusPilot::invokeService : createJObjectArray failed. Exiting...") ;
    return false ;
	}

	pGraph->graphReset() ;

	// NautilusGraph = invokeService(Pilot pilot, String serviceName, String[] data)
	//==============================================================================
	jstring jServName = jenv->NewStringUTF( serviceName ) ;
    //invokeService2
	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "invokeService",
      	"(Ljava/lang/String;[Ljava/lang/String;)Lnautilus/NautilusGraph;") ;
	if (0 == mid)
	{
		fprintf(stderr, "Cannot locate the NautilusPilot invokeService method.") ;
		return false ;
	}

	jobject jGraph = jenv->CallObjectMethod(jNautilusPilot, mid, jServName, strArray) ;

 	jenv->DeleteLocalRef(jServName) ;
	jenv->DeleteLocalRef(strArray) ;

	if (jenv->ExceptionOccurred() )
	{
  	errorMessage = string(getTextError(jenv, "NTIERS", true)) ;
		return false ;
	}

	if ((NULL == jGraph) && (WARNING_RETURN == getReturnType(jenv))) //WARNING_RETURN
	{
  	warningMessage = string(getTextWarning(jenv, "NTIERS")) ;
    return false ;
	}

	// build a C graph from the java graph object
	//===========================================
	if (NULL != jGraph)
	{
  	buildGraphForC(jenv, jGraph, pGraph) ;
    jenv->DeleteLocalRef(jGraph) ;
	}

	return true ;
}

bool NautilusPilot::searchPatient(const char* serviceName, NSDataGraph* pGraph,
                    NSPersonsAttributesArray *pList, NSBasicAttributeArray *pAttrArray)
//=====================================================================================
{
	if ((NULL == serviceName) || (NULL == pGraph) ||(NULL == pList) || (NULL == pAttrArray))
  	return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
	if (NULL == jenv)
	{
  	string ps2 = string("NautilusPilot::searchPatient : jenv is null. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    return false ;
	}

	if (!invokeService(serviceName, pGraph, pAttrArray))
		return false ;

	transformResultFieldInAttributesArray(jenv, pList, "status", "*") ;
	return true ;
}

bool
NautilusPilot::initAgentList()
{
  NSPersonsAttributesArray AgentsList ;
	pContexte->pPilot->resourceList(NautilusPilot::SERV_GET_AGENT_LIST.c_str(), &AgentsList) ;
  if (AgentsList.empty())
  	return false ;

  NSPersonsAttributeIter iterAgent = AgentsList.begin() ;
  for ( ; iterAgent != AgentsList.end(); iterAgent++)
  {
  	string agentName = string((*iterAgent)->getAttributeValue("name")) ;
			//string err = string((*iter)->getAttributeValue("textError")) ;
    NSAgentStatus *pAgent = new NSAgentStatus(agentName, "") ;

    string sProp = string((*iterAgent)->getAttributeValue("properties"))  ;
    if (string("") != sProp)
    	pAgent->setAgentProperties(sProp) ;
    VecteurString *pServList = new VecteurString() ;
    //getServiceForAgent(agentName.c_str(), pServList ) ;
    pAgent->setServiceList(pServList)  ;

    pAvailableAgentList->push_back(pAgent) ;
	}
	markIncorrectAgents() ;
	return true ;
}

bool
NautilusPilot:: markIncorrectAgents()
//===================================
{
	NSPersonsAttributesArray ErrorList ;
	bool res = agentsTest(SERV_AGENTS_TEST.c_str(), &ErrorList) ;
	if (!res)
		return false ;

  if (!(ErrorList.empty()))
		for (NSPersonsAttributeIter iter = ErrorList.begin(); iter != ErrorList.end(); iter++)
		{
			string sAgentName = string((*iter)->getAttributeValue("agent")) ;
			string err = string((*iter)->getAttributeValue("textError")) ;
      NSAgentStatus*  pAgent = pAvailableAgentList->selectAgent(sAgentName) ;
      pAgent->setError(err) ;
      pAgent->setInactive() ;
		}

	return true ;
}

// utilis� pour les tests des agents
bool
NautilusPilot::agentsTest(const char* serviceName, NSPersonsAttributesArray *pErrorList)
//======================================================================================
{
	if (NULL == serviceName)
		return false ;
try
{
	JNIEnv* jenv = JavaSystem::jenv ;
  if (NULL == jenv)
  {
  	string ps2 = string("NautilusPilot::agentsTest : jenv is null. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    return false ;
  }
  if ((NULL == pAvailableAgentList) || (pAvailableAgentList->empty()))
  	return true ;

  NSBasicAttributeArray AttrArray ;

  for (NSAgentStatusIter iterAgent = pAvailableAgentList->begin(); iterAgent != pAvailableAgentList->end() ; iterAgent++)
  	AttrArray.push_back(new NSBasicAttribute((*iterAgent)->getAgentName().c_str(), "true")) ;

  jobjectArray strArray = createJObjectArray(&AttrArray) ;
  if (strArray == NULL)
  {
  	fprintf(stderr, "NautilusPilot::invokeService : createJObjectArray failed. Exiting...");
    return false ;
  }

	jmethodID midAg = jenv->GetMethodID(classNautilusPilot, "agentsTest",
                    "(Ljava/lang/String;[Ljava/lang/String;)[Ldomlightwrapper/DOMElement;");
  if (midAg == 0)
	{
  	string ps2 = string("NautilusPilot::agentsTest method. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
		return false ;
	}
	jstring jServName = jenv->NewStringUTF( serviceName ) ;
	jobjectArray jResultTrees = (jobjectArray)jenv->CallObjectMethod(jNautilusPilot, midAg, jServName, strArray) ;
  jenv->DeleteLocalRef(jServName) ;
  jenv->DeleteLocalRef(strArray) ;
	if (jenv->ExceptionOccurred())
	{
  	string sErrorText = getTextError(jenv) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		jenv->ExceptionDescribe() ;
		return false ;
	}
	if (NULL == jResultTrees)
		return true ;

	int count = jenv->GetArrayLength(jResultTrees) ;
	for (int i = 0 ; i < count ; i++)
	{
		jobject jErrorElem = jenv->GetObjectArrayElement(jResultTrees, i) ;
    if (NULL != jErrorElem)
    {
    	NSBasicAttributeArray* pErrorAttributes = new NSBasicAttributeArray() ;
      DOMTreeToBasicAttribute(pErrorAttributes, jErrorElem) ;
      jenv->DeleteLocalRef(jErrorElem) ;
      if (NULL != pErrorList)
      	pErrorList->push_back(pErrorAttributes) ;
    }
    else
    {
    	string ps = string("NautilusPilot::errorList : GetObjectArrayElement failed.") ;
      pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    }
  }
	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::agentsTest", standardError, 0) ;
	return false ;
}
}

bool
NautilusPilot::testServiceStatus(string sServiceName)
{
	VecteurString *pAgents = pPropertiesServicesList->getAgentListForService(sServiceName) ;
  if ((NULL == pAgents) || (pAgents->empty()))
		return true ;

	for (EquiItemIter iterAgent= pAgents->begin(); iterAgent != pAgents->end(); iterAgent++)
		if (pAvailableAgentList->selectAgent(**iterAgent)->isInactive())
    	return false ;

	return true ;
}

bool
NautilusPilot::traitError(string sServiceName)
{
  VecteurString *pAgents = pPropertiesServicesList->getAgentListForService(sServiceName) ;
  
  string sError = "" ;
  if ((NULL == pAgents) || (pAgents->empty()))
  	sError = "nonInstancedWarning" ;
  else
  {
		for (EquiItemIter iterAgent= pAgents->begin(); iterAgent != pAgents->end() ; iterAgent++)
  	{
    	NSAgentStatus *pAgent = pAvailableAgentList->selectAgent(**iterAgent) ;
  		if ((NULL != pAgent) && (pAgent->isInactive()))
  		{
    		string sErr = pAvailableAgentList->selectAgent(**iterAgent)->getError() ;
      	string sErrTxt = pContexte->getSuperviseur()->getText("JavaException", pAvailableAgentList->selectAgent(**iterAgent)->getError()) ;
      	if (NULL == strstr(sError.c_str(), sErrTxt.c_str()))
      		sError = sError + "\n" + sErrTxt ;
  		}
  	}
	}
  sError = sError + "\n " + pContexte->getSuperviseur()->getText("JavaException", "msgContinue") ;
 	int returnVal = MessageBox(0, sError.c_str(), "Message Nautilus", MB_YESNO) ;
  if (returnVal == IDYES)
  	return true ;

  return false ;
}

bool
NautilusPilot::traitError(int agentType)
{
  //VecteurString *pAgents = pPropertiesServicesList->getAgentListForService( sServiceName );
  string sError = "" ;
  if ((NULL == pAvailableAgentList) || (pAvailableAgentList->empty()))
  	sError = "nonInstancedWarning" ;
	else
  {
		for (NSAgentStatusIter iterAgent = pAvailableAgentList->begin(); iterAgent != pAvailableAgentList->end() ; iterAgent++)
  	{
   		if ((*iterAgent) && ((*iterAgent)->isInactive()) && ((*iterAgent)->getAgentType() == agentType))
  		{
    		string sErr = (*iterAgent)->getError() ;
      	string sErrTxt = pContexte->getSuperviseur()->getText("JavaException", (*iterAgent)->getError()) ;
      	if (NULL == strstr(sError.c_str(), sErrTxt.c_str()))
      		sError = sError + "\n" + sErrTxt ;
  		}
  	}
	}
  if (string("") == sError)
  	sError = pContexte->getSuperviseur()->getText("JavaException", "versionProblem") ;

	sError = sError + "\n " +  pContexte->getSuperviseur()->getText("JavaException", "msgContinue") ;
  int returnVal = MessageBox(0, sError.c_str(), "Message Nautilus", MB_YESNO) ;
  if(returnVal == IDYES)
  	return true ;

  return false ;
  //erreur(sError.c_str(), standardError, 0) ;
}

bool
NautilusPilot::isOperationalLdVAgent()
{
	if ((NULL == pAvailableAgentList) || (pAvailableAgentList->empty()))
		return false ;

  bool foundAgent = false ;

  for (NSAgentStatusIter iterAgent = pAvailableAgentList->begin(); iterAgent != pAvailableAgentList->end() ; iterAgent++)
  {
   /*	if( ((*iterAgent)->isLdvTypeAgent() ) && ((*iterAgent)->isInactive()))
    	return false ;  */
		if ((*iterAgent)->isLdvTypeAgent())
    {
    	foundAgent = true ;
      if ((*iterAgent)->isInactive())
      	return false ;
    }
  }

	return foundAgent ;
}

bool
NautilusPilot::isOperationalLocalAgent()
{
	if ((NULL == pAvailableAgentList) || (pAvailableAgentList->empty()))
		return false ;

	for (NSAgentStatusIter iterAgent = pAvailableAgentList->begin(); iterAgent != pAvailableAgentList->end() ; iterAgent++)
  	if( ((*iterAgent)->isLocalTypeAgent()) && ((*iterAgent)->isInactive()))
    	return false ;

	return true ;
}

//utilis� pour les tests des agents
bool
NautilusPilot::getServiceForAgent(const char* agentName, VecteurString *pServList )
//=================================================================================
{
	if (NULL == agentName)
		return false ;
try
{
	JNIEnv* jenv = JavaSystem::jenv ;
	if (NULL == jenv)
	{
  	string ps2 = string("NautilusPilot::agentsTest : jenv is null. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    return false ;
	}
	jmethodID midAg = jenv->GetMethodID(classNautilusPilot, "getServiceList",
                    "(Ljava/lang/String;)[Ljava/lang/String;");
	if (0 == midAg)
	{
  	string ps2 = string("NautilusPilot::getServiceList method. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
		return false ;
	}
	jstring jAgentName = jenv->NewStringUTF( agentName ) ;
	jobjectArray jArrayString = (jobjectArray)jenv->CallObjectMethod(jNautilusPilot, midAg, jAgentName) ;
  jenv->DeleteLocalRef(jAgentName) ;
  if (jenv->ExceptionOccurred())
	{
  	string sErrorText = getTextError(jenv) ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
		jenv->ExceptionDescribe() ;
  	return false ;
  }

	if ((NULL == jArrayString) && (WARNING_RETURN == getReturnType(jenv)))
  {
  	jstring jWarning = (jstring)jenv->GetObjectField(jNautilusPilot, jFidWarning) ;
    if (NULL != jWarning)
    {
    	// warnings
      string sWarning = string(JavaSystem::NewStringWithSpecialCharacters(jWarning)) ;
      if (string("serviceNotFound") == sWarning)
      {
      	jenv->DeleteLocalRef(jArrayString) ;
        return true ;
      }
  	}
  }

	jint jsize = jenv->GetArrayLength(jArrayString) ;
	for (int i = 0 ; i < jsize ; i++)
	{
  	jstring jElem = (jstring)jenv->GetObjectArrayElement(jArrayString, i) ;
    if (NULL != jElem)
    {
    	pServList->push_back( new string( JavaSystem::NewStringWithSpecialCharacters(jElem) ) ) ;
      jenv->DeleteLocalRef(jElem) ;
    }
    else
    {
    	string ps2 = string("NautilusPilot::invokeService(char*, char*, VecteurString&) : GetObjectArrayElement failed.") ;
      pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    }
	}
	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::agentsTest", standardError, 0) ;
	return false ;
}
}

//utilis� pour la liste des utilisateurs
bool NautilusPilot::invokeService(const char* serviceName, const char* tagName, VecteurString& result)
//====================================================================================================
{
	if ((NULL == serviceName) || (NULL == tagName))
		return false ;
  /*  if(!pAvailableAgentList->isAvailableService(string(serviceName)))
        return false ;     */
try
{
	JNIEnv* jenv = JavaSystem::jenv ;
	if (NULL == jenv)
	{
		string ps2 = string("NautilusPilot::searchPatient : jenv is null. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
		return false ;
	}

	//=== get method id for the NautilusPilot.invokeService method
	jmethodID mid2Invoke = jenv->GetMethodID(classNautilusPilot, "invokeService",
                    "(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;") ;
	if (mid2Invoke == 0)
	{
  	string ps2 = string("NautilusPilot::invokeService(char*, char*, VecteurString&) : Cannot locate the NautilusPilot invokeService method. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
		return false ;
	}

	jstring jServName = jenv->NewStringUTF( serviceName ) ;
	jstring jTagName  = jenv->NewStringUTF( tagName ) ;

	jobjectArray jArrayString = (jobjectArray)jenv->CallObjectMethod(
                                jNautilusPilot, mid2Invoke, jServName, jTagName) ;

	jenv->DeleteLocalRef(jServName) ;
	jenv->DeleteLocalRef(jTagName) ;

	if (jenv->ExceptionOccurred())
	{
		// erreur("Erreur execution : invoke service",standardError, 0,0);
    string sErrorText = getTextError(jenv) ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
		jenv->ExceptionDescribe() ;
		return false ;
	}

	if (NULL != jArrayString)
	{
		jint jsize = jenv->GetArrayLength(jArrayString) ;
		for(int i = 0; i < jsize; i++)
		{
			jstring jElem = (jstring)jenv->GetObjectArrayElement(jArrayString, i) ;
      if (NULL != jElem)
      {
      	result.push_back( new string( JavaSystem::NewStringWithSpecialCharacters(jElem) ) ) ;
        jenv->DeleteLocalRef(jElem) ;
      }
      else
      {
      	string ps2 = string("NautilusPilot::invokeService(char*, char*, VecteurString&) : GetObjectArrayElement failed.") ;
        pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
      }
    }
	}
	jenv->DeleteLocalRef(jArrayString) ;
	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::invokeService", standardError, 0) ;
	return false ;
}
}

//used for userList
bool
NautilusPilot::personsList(const char* serviceName, string resultTagName, NSPersonsAttributesArray *pAttsList, char* first, ...)
//==============================================================================================================================
{
	if ((NULL == serviceName) || (NULL == pAttsList))
  	return false ;

try
{
	JNIEnv* jenv = JavaSystem::jenv ;
	if (NULL == jenv)
	{
  	string ps2 = string("NautilusPilot::personsList : jenv is null. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    return false ;
	}

	jobjectArray strArray = NULL ;
//	char debug[512];
	if (NULL != first)
	{
		va_list marker ;

		//=== first loop, we compute size
		int size = 0 ;
		va_start(marker, first) ;
		while( true )
		{
			size++ ;
			if( !va_arg( marker, char*) )
				break ;
		}
		va_end(marker) ;

		//jclass classStr = jenv->FindClass("java/lang/String");
		strArray = jenv->NewObjectArray(size, classStr, NULL) ;
    if (NULL == strArray)
		{
			string ps2 = string("NautilusPilot::personsList : NewObjectArray failed. Exiting...") ;
			pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
			return false ;
		}

		//=== second loop, we build a Java String Array with the strings
		char* data = new char[80] ;
		strcpy(data, first) ;
		va_start(marker, first) ;
		for (int i = 0; i < size; i++)
		{
			jstring jstr = jenv->NewStringUTF( data ) ;
			jenv->SetObjectArrayElement(strArray, i, jstr) ;
      if (jenv->ExceptionOccurred())
			{
				// erreur("Erreur execution : invoke service",standardError, 0,0);
        string sErrorText = getTextError(jenv) ;
        pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
				erreur(sErrorText.c_str(), standardError, 0, 0) ;
				jenv->ExceptionDescribe() ;
        delete[] data ;
				return false ;
			}

			jenv->DeleteLocalRef(jstr) ;

			data = va_arg( marker, char*) ;
		}
    delete[] data ;

		va_end(marker) ;
	}

	jmethodID mid2Invoke = jenv->GetMethodID(classNautilusPilot, "invokeService2String",
                    "(Ljava/lang/String;Ljava/lang/String;)Ldomlightwrapper/DOMElement;") ;

	if (NULL == mid2Invoke)
	{
  	string ps2 = string("NautilusPilot::personsList : Cannot locate the NautilusPilot invokeService2String method. Exiting...") ;
    pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
		return false ;
	}

	jstring jServName = jenv->NewStringUTF( serviceName ) ;
	jstring jTagName  = jenv->NewStringUTF( resultTagName.c_str() ) ;

	jobject jDOMElem = (jobjectArray)jenv->CallObjectMethod(jNautilusPilot, mid2Invoke, jServName, jTagName) ;

	if (jenv->ExceptionOccurred())
	{
		//erreur("Erreur execution : invoke service personsList",standardError,0, 0);
    string sErrorText = getTextError(jenv) ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
		jenv->ExceptionDescribe() ;
		return false ;
	}

	jenv->DeleteLocalRef(jServName) ;
	jenv->DeleteLocalRef(jTagName) ;
	if (NULL == jDOMElem)
	{
		string sErrorText = getTextError(jenv) ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return false ;
	}

	jstring jNodeName = jenv->NewStringUTF( resultTagName.c_str()) ;

	jobjectArray jDomElems = (jobjectArray)jenv->CallObjectMethod(jDOMElem, midChildrenElements, jNodeName) ;
	jenv->DeleteLocalRef(jNodeName) ;
	if (NULL == jDomElems)
	{
		string ps2 = string("NautilusPilot::personsList : CallObjectMethod failed. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
		return false ;
	}

	int count = jenv->GetArrayLength(jDomElems) ;
	for (int i = 0; i < count; i++)
	{
  	jobject jNodeElem = jenv->GetObjectArrayElement(jDomElems, i) ;
		if (NULL != jNodeElem)
		{
    	NSBasicAttributeArray* pElemAttributes = new NSBasicAttributeArray() ;
      DOMTreeToBasicAttribute(pElemAttributes, jNodeElem) ;
      pAttsList->push_back(pElemAttributes) ;
      jenv->DeleteLocalRef(jNodeElem) ;
    }
		else
    {
    	string ps2 = string("NautilusPilot::personsList : GetObjectArrayElement failed.") ;
			pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trError) ;
    }
  }

	jenv->DeleteLocalRef(jDomElems) ;
	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::personsList", standardError, 0) ;
	return false ;
}
}

void NautilusPilot::buildGraphForC(JNIEnv* jenv, jobject jGraph, NSDataGraph* pGraph)
//===================================================================================
{
	if (NULL == pGraph)
  	return ;
try
{
	pGraph->aTrees.vider() ;
	pGraph->aLinks.vider() ;
	pGraph->aArchs.vider() ;
	pGraph->aRights.vider() ;

	if ((NULL == jenv) || (NULL == jGraph))
		return ;

	int nbTrees  = jni_getNbTrees(jenv, jGraph) ;
	int nbLinks  = jni_getNbLinks(jenv, jGraph) ;
	int nbModels = jni_getNbModels(jenv, jGraph) ;
	int nbRights = jni_getNbRights(jenv, jGraph) ;

	char* result = NULL ;

	//=== create C++ models
	//=====================
	for (int i = 0 ; i < nbModels ; i++)
	{
		NSArcLink* pmodel = new NSArcLink(pContexte) ;

		result = jni_getAttribute(jenv, jGraph, "getModelObject", i) ;
    if (NULL != result)
    {
    	pmodel->object = string(result) ;
			delete[] result ;
    }

		result = jni_getAttribute(jenv, jGraph, "getModelNode", i) ;
    if (NULL != result)
    {
			pmodel->node = string( result ) ;
			delete[] result ;
    }

		result = jni_getAttribute(jenv, jGraph, "getModelType", i);
    if (NULL != result)
    {
			pmodel->type = string( result ) ;
			delete[] result ;
    }

		result = jni_getAttribute(jenv, jGraph, "getModelModelObject", i);
    if (NULL != result)
    {
			pmodel->model_object_id = string( result ) ;
			delete[] result ;
    }

		pGraph->aArchs.push_back( pmodel ) ;
	}

	//------------------------------------------------------------------------------
	//=== create C++ rights
	//=====================
	for (int i = 0; i < nbRights; i++)
	{
  	NSNodeRight* pRight = new NSNodeRight() ;

		result = jni_getAttribute(jenv, jGraph, "getRightNode", i);
    if (NULL != result)
    {
    	pRight->node = string(result) ;
      delete[] result ;
    }

		result = jni_getAttribute(jenv, jGraph, "getRightRight", i);
    if (NULL != result)
    {
			pRight->right = string( result ) ;
      delete[] result ;
    }

		pGraph->aRights.push_back( pRight ) ;
	}

	//------------------------------------------------------------------------------
	//=== create C++ links
	//====================
	for (int i = 0; i < nbLinks; i++)
	{
  	NSPatLinkInfo* plink = new NSPatLinkInfo() ;

		result = jni_getAttribute(jenv, jGraph, "getLinkQualified", i) ;
    if (NULL != result)
    {
			plink->setQualifie(result) ;
			delete[] result ;
    }

		result = jni_getAttribute(jenv, jGraph, "getLinkQualifier", i) ;
    if (NULL != result)
    {
    	plink->setQualifiant(result) ;
			delete[] result ;
    }

		result = jni_getAttribute(jenv, jGraph, "getLinkLink", i) ;
    if (NULL != result)
    {
    	plink->setLien(result) ;
			delete[] result ;
    }

		pGraph->aLinks.push_back( plink ) ;
	}

	string treeId = jni_getGraphId(jenv, jGraph);
	pGraph->setGraphID(treeId);

	//=== create C++ trees
	//====================
	for (int i = 0; i < nbTrees; i++)
	{
		treeId = jni_getTreeId(jenv, jGraph, i);

		NSDataTree* pDataTree = new NSDataTree(pContexte, treeId, graphPerson) ;
		NSPatPathoArray* pPatPathoArray = new NSPatPathoArray(pContexte) ;

		jobjectArray jnodes = jni_getTreeNodes(jenv, jGraph, i) ;
		if (NULL == jnodes)
    {
			string ps = string("NautilusPilot::buildGraphForC : jni_getTreeNodes failed. exiting...") ;
			pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
			return ;
    }
		jsize len = jenv->GetArrayLength(jnodes) ;
		//loop on the nodes of a tree and fill pDataTree->pPathPathoArray
		for (int j = 0 ; j < len ; j++)
		{
			jobject jnode = jenv->GetObjectArrayElement(jnodes, j) ;

			if (NULL != jnode)
			{
				NSPatPathoInfo* pPatPathoInfo = new NSPatPathoInfo() ;
				pPatPathoInfo->setTreeID(treeId) ;

				result = jni_getNodeField(jenv, "NODE", jnode) ;
				if (NULL != result)
				{
					pPatPathoInfo->setNodeID(result) ;
					delete[] result ;
				}

				result = jni_getNodeField(jenv, "LEXICON", jnode) ;
				if (NULL != result)
				{
					pPatPathoInfo->setLexique(result) ;
          delete[] result ;
        }

				result = jni_getNodeField(jenv, "COMPLEMENT", jnode) ;
				if (NULL != result)
				{
					pPatPathoInfo->setComplement(result) ;
          delete[] result ;
        }

        result = jni_getNodeField(jenv, "UNIT", jnode) ;
				if (NULL != result)
				{
					pPatPathoInfo->setUnit(result) ;
					delete[] result ;
				}

				result = jni_getNodeField(jenv, "CERTITUDE", jnode) ;
				if (NULL != result)
				{
					pPatPathoInfo->setCertitude(result) ;
          delete[] result ;
				}

				result = jni_getNodeField(jenv, "INTEREST", jnode) ;
				if (NULL != result)
				{
					pPatPathoInfo->setInteret(result) ;
					delete[] result ;
				}

				result = jni_getNodeField(jenv, "PLURAL", jnode) ;
				if (NULL != result)
				{
					pPatPathoInfo->setPluriel(result) ;
					delete[] result ;
				}

				result = jni_getNodeField(jenv, "VISIBLE", jnode) ;
				if (NULL != result)
				{
					pPatPathoInfo->setVisible(result) ;
					delete[] result ;
				}

				result = jni_getNodeField(jenv, "TYPE", jnode) ;
				if (NULL != result)
				{
					pPatPathoInfo->setType(result) ;
					delete[] result ;
				}

				result = jni_getNodeField(jenv, "FREE_TEXT", jnode) ;
				if (NULL != result)
				{
					pPatPathoInfo->setTexteLibre(result) ;
					delete[] result ;
				}

				result = jni_getNodeField(jenv, "LOCALISATION", jnode) ;
				if (NULL != result)
				{
					pPatPathoInfo->setLocalisation(result) ;
					delete[] result ;
				}

				jenv->DeleteLocalRef(jnode) ;

				pPatPathoArray->ajouteElement(pPatPathoInfo) ;
      }
    }
		jenv->DeleteLocalRef(jnodes) ;
		pDataTree->setPatPatho(pPatPathoArray, true) ;

    delete pPatPathoArray ;

		pGraph->aTrees.push_back(pDataTree) ;
	}
}
catch (...)
{
	erreur("Exception NautilusPilot::buildGraphForC", standardError, 0) ;
}
}

jobject NautilusPilot::buildGraphForJava(JNIEnv* jenv, NSDataGraph* pGraph,
                    int& nbTrees, int& nbLinks, int&  nbModels, int& nbRights)
//=============================================================================
{
	if (NULL == pGraph)
  	return NULL ;
try
{
	if (NULL == jenv)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return NULL ;
	}

	jstring jRootId = jenv->NewStringUTF( (pGraph->getGraphID()).c_str() ) ;
	nbTrees  = pGraph->aTrees.size() ;
	nbLinks  = pGraph->aLinks.size() ;
	nbModels = pGraph->aArchs.size() ;
	nbRights = pGraph->aRights.size() ;

	//dom replace graphPerson by pGraph->getType !!
	jobject jGraph = jenv->NewObject(classNautilusGraph, midNewGraph,
                          graphPerson, jRootId, nbTrees, nbLinks, nbModels, nbRights) ;
  if (jGraph == NULL)
  {
  	string ps = string("NautilusPilot::buildGraphForJava : NewObject failed. exiting...");
		pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    return NULL ;
  }
	int i ;

	//=== build a graph for the java side
	//======================================
	//loop on the trees (pGraph->aTrees)
	//==================================
	if (nbTrees > 0)
	{
		//=== get method id for the NautilusGraph.createLink method
	  jmethodID midT = jenv->GetMethodID(classNautilusGraph, "createTree",
                        "(ILjava/lang/String;I)V");
    if (NULL == midT)
  	{
  		string ps = string("NautilusPilot::buildGraphForJava : GetMethodID failed for createTree. exiting...");
			pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
      return NULL ;
  	}
		jmethodID midN = jenv->GetMethodID(classNautilusGraph, "createNode",
                        "(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V") ;
		if (NULL == midN)
  	{
  		string ps = string("NautilusPilot::buildGraphForJava : GetMethodID failed for createNode. exiting...");
			pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
      return NULL ;
  	}

		NSDataTreeIter treeIter = pGraph->aTrees.begin() ;
		i = 0 ;
		while (treeIter != pGraph->aTrees.end())     //loop on the trees
    {                                            //=================
			NSDataTree* treeInfo = *treeIter ;

			jstring jTreeId = jenv->NewStringUTF( treeInfo->sTreeID.c_str() ) ;
			int     nbNodes = treeInfo->size() ;
			jenv->CallVoidMethod(jGraph, midT, i, jTreeId, nbNodes) ;
      if (nbNodes > 0)
			{
				NSPatPathoArray PatPathoArray(pContexte) ;
				treeInfo->getPatPatho(&PatPathoArray, true) ;
				if (PatPathoArray.empty())
        {
        	string ps = string("NautilusPilot::buildGraphForJava : Empty patpatho. exiting...") ;
					pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
        	return NULL ;
        }
        PatPathoIter patIter = PatPathoArray.begin() ;
        int j = 0 ;
        while (patIter != PatPathoArray.end() )  //loop on the nodes
        {                                          //=================
        	NSPatPathoInfo* patPathoInfo = *patIter ;

          jstring jNodeId       = jenv->NewStringUTF( patPathoInfo->getNodeID().c_str() ) ;

          jstring jType         = jenv->NewStringUTF( patPathoInfo->getType().c_str() ) ;
          jstring jLexique      = jenv->NewStringUTF( patPathoInfo->getLexique().c_str() ) ;
          jstring jComplement   = jenv->NewStringUTF( patPathoInfo->getComplement().c_str() ) ;
          jstring jCertitude    = jenv->NewStringUTF( patPathoInfo->getCertitude().c_str() ) ;
          jstring jPluriel      = jenv->NewStringUTF( patPathoInfo->getPluriel().c_str() ) ;
          jstring jUnit         = jenv->NewStringUTF( patPathoInfo->getUnit().c_str() ) ;
          jstring jFreeText     = jenv->NewStringUTF( patPathoInfo->getTexteLibre().c_str() ) ;
          jstring jLocalisation = jenv->NewStringUTF( patPathoInfo->getLocalisation().c_str() ) ;
          jstring jVisible      = jenv->NewStringUTF( patPathoInfo->getVisible().c_str() ) ;
          jstring jInteret      = jenv->NewStringUTF( patPathoInfo->getInteret().c_str() ) ;

          jenv->CallVoidMethod(jGraph, midN, i, j, jTreeId, jNodeId,
                    jType, jLexique, jComplement, jCertitude, jPluriel,
                    jUnit, jFreeText,
                    jLocalisation, jVisible, jInteret) ;

          jenv->DeleteLocalRef(jNodeId) ;
          jenv->DeleteLocalRef(jType) ;
          jenv->DeleteLocalRef(jLexique) ;
          jenv->DeleteLocalRef(jComplement) ;
          jenv->DeleteLocalRef(jCertitude) ;
          jenv->DeleteLocalRef(jPluriel) ;
          jenv->DeleteLocalRef(jUnit) ;
          jenv->DeleteLocalRef(jFreeText) ;
          jenv->DeleteLocalRef(jLocalisation) ;
          jenv->DeleteLocalRef(jVisible) ;
          jenv->DeleteLocalRef(jInteret) ;

          patIter++ ;
          j++ ;
        }     //end of while
      }       //end of if( nbNodes > 0 )

      jenv->DeleteLocalRef(jTreeId) ;

      treeIter++ ;
      i++ ;
    }
  }

  //loop on the links (pGraph->aLinks)
  //==================================
  if (nbLinks > 0)
  {
  	//=== get method id for the NautilusGraph.createLink method
	  jmethodID mid = jenv->GetMethodID(classNautilusGraph, "createLink",
      "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V") ;
        //dom  "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[LgraphServer/PointOfView;)V") ;
    if (NULL == mid)
  	{
  		string ps = string("NautilusPilot::buildGraphForJava : GetMethodID failed for createLink. exiting...");
			pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
      return NULL ;
  	}
    jmethodID midPoint = jenv->GetMethodID(classNautilusGraph, "createPointOfView",
                "(IILjava/lang/String;Ljava/lang/String;)V");
    if (NULL == midPoint)
  	{
  		string ps = string("NautilusPilot::buildGraphForJava : GetMethodID failed for createPointOfView. exiting...");
			pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
      return NULL ;
  	}

    if (false == pGraph->aLinks.empty())
    {
    	NSPatLinkIter linkIter = pGraph->aLinks.begin() ;
      i = 0 ;
      while (linkIter != pGraph->aLinks.end())
      {
      	NSPatLinkInfo* linkInfo = *linkIter ;

        jstring jQualifie   = jenv->NewStringUTF( linkInfo->getQualifie().c_str() ) ;
        jstring jLien       = jenv->NewStringUTF( linkInfo->getLien().c_str() ) ;
        jstring jQualifiant = jenv->NewStringUTF( linkInfo->getQualifiant().c_str() ) ;

    //dom    jenv->CallVoidMethod(jGraph, mid, i, jQualifie, jLien, jQualifiant, jPoint);
        jenv->CallVoidMethod(jGraph, mid, i, jQualifie, jLien, jQualifiant) ;

        jstring jempty = jenv->NewStringUTF("") ;
        int j = 0 ;    //in the future j can be incremented to add a point of view
        jenv->CallVoidMethod(jGraph, midPoint, i, j, jempty,jempty) ;
        /*
        jobject jPoint = jenv->NewObject(classNautilusGraph, midPoint, i, j, "", "");
        if (jPoint == NULL)
  			{
  				ps = string("NautilusPilot::buildGraphForJava : NewObject failed. exiting...");
					pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
          return NULL ;
  			}
        jenv->CallVoidMethod(jGraph, mid, i, jQualifie, jLien, jQualifiant, jPoint);
        */

        jenv->DeleteLocalRef(jQualifie) ;
        jenv->DeleteLocalRef(jLien) ;
        jenv->DeleteLocalRef(jQualifiant) ;

        jenv->DeleteLocalRef(jempty) ;
    //dom    jenv->DeleteLocalRef(jPoint);

        linkIter++ ;
        i++ ;
      }
    }
  }

	//loop on the models (pGraph->aArchs)
	//===================================
	if (nbModels > 0)
	{
		//=== get method id for the NautilusGraph.createModel method
	  jmethodID mid = jenv->GetMethodID(classNautilusGraph, "createModel",
        "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V") ;
    if (NULL == mid)
  	{
  		string ps = string("NautilusPilot::buildGraphForJava : GetMethodID failed for createModel. exiting...") ;
			pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
      return NULL ;
  	}

		if (false == pGraph->aArchs.empty())
		{
    	NSArcLinkIter modelIter = pGraph->aArchs.begin() ;
      i = 0 ;
      while (modelIter != pGraph->aArchs.end())
      {
      	NSArcLink* modelInfo = *modelIter ;
        //manage object, node, type, name
        jstring jObject      = jenv->NewStringUTF( modelInfo->object.c_str() ) ;
        jstring jNode        = jenv->NewStringUTF( modelInfo->node.c_str() ) ;
        jstring jType        = jenv->NewStringUTF( modelInfo->type.c_str() ) ;
        jstring jModelObject = jenv->NewStringUTF( modelInfo->model_object_id.c_str() ) ;

        jenv->CallVoidMethod(jGraph, mid, i, jObject, jNode, jType, jModelObject) ;

        jenv->DeleteLocalRef(jObject) ;
        jenv->DeleteLocalRef(jNode) ;
        jenv->DeleteLocalRef(jType) ;
        jenv->DeleteLocalRef(jModelObject) ;

        modelIter++ ;
        i++ ;
      }
    }
  }

   //------------------------------------------------------------------
  //loop on the rights (pGraph->aRights)
  //==================================
  if (nbRights > 0)
  {
		//=== get method id for the NautilusGraph.createLink method
	  jmethodID mid = jenv->GetMethodID(classNautilusGraph, "createRight",
                    "(ILjava/lang/String;Ljava/lang/String;)V");
    if (NULL == mid)
  	{
  		string ps = string("NautilusPilot::buildGraphForJava : GetMethodID failed for createRight. exiting...") ;
			pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
      return NULL ;
  	}
    if (false == pGraph->aRights.empty())
    {
    	NSNodeRightIter rightIter = pGraph->aRights.begin() ;
      i = 0 ;
			while (rightIter != pGraph->aRights.end())
      {
      	NSNodeRight* rightInfo = *rightIter ;

        jstring jNode   = jenv->NewStringUTF( rightInfo->node.c_str() ) ;
        jstring jRight  = jenv->NewStringUTF( rightInfo->right.c_str() ) ;
        jsize str_size  = jenv->GetStringUTFLength(jRight) ;

        jenv->CallVoidMethod(jGraph, mid, i, jNode, jRight) ;

        jenv->DeleteLocalRef(jNode) ;
        jenv->DeleteLocalRef(jRight) ;

        rightIter++ ;
        i++ ;
      }
    }
  }

	return jGraph ;
}
catch (...)
{
	erreur("Exception NautilusPilot:: buildGraphForJava", standardError, 0) ;
	return NULL ;
}
}

void NautilusPilot::applyMappings(JNIEnv* jenv, jobjectArray jMappings, NSDataGraph* pGraph,
                                        int nbTrees, int nbLinks, int nbModels, int nbRights)
//===========================================================================================
{
	if ((NULL == pGraph) || (NULL == jMappings))
  	return ;

try
{
	if (NULL == jenv)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return ;
	}

	jint nbMaps = jenv->GetArrayLength(jMappings) ;

	if (nbMaps > 0)
  {
  	//build C++ version of the mappings
    //=================================
    char** tempNodes     = jni_getMappingField(jenv, "temporaryNODE_ID",   jMappings, nbMaps) ;
    char** tempObjects   = jni_getMappingField(jenv, "temporaryOBJECT_ID", jMappings, nbMaps) ;

    char** storedNodes   = jni_getMappingField(jenv, "storedNODE_ID",   jMappings, nbMaps) ;
    char** storedObjects = jni_getMappingField(jenv, "storedOBJECT_ID", jMappings, nbMaps) ;

    string graphId = pGraph->getGraphID() ;
    if ( toBeChangedForComposedId(graphId) )
    {
    	for(int i = 0 ; i < nbMaps ; i++)
      {
      	char idDoc[OBJECT_ID_LEN + 1] ;
        strcpy(idDoc, graphId.c_str() ) ;
        if (!strcmp(idDoc,tempObjects[i]))
        {
        	pGraph->setGraphID( string(storedObjects[i]) ) ;
          break ;
        }
      }
      pGraph->setLastTree("") ;
    }

    //loop on the trees (pGraph->aTrees)
    //==================================
    if ((nbTrees > 0) && (!(pGraph->aTrees.empty())))
    {
    	int i ;
      NSDataTreeIter treeIter = pGraph->aTrees.begin() ;
      while( treeIter != pGraph->aTrees.end() )     //loop on the trees
      {                                             //=================
      	NSDataTree* treeInfo = *treeIter ;
        char idDoc[OBJECT_ID_LEN + 1] ;
        strcpy(idDoc, treeInfo->getTreeID().c_str() ) ;
        //in case of Graph of type Person : the test means "new person or new document"
        //in case of Graph of type Object : the test means "new object"
        if( toBeChangedForComposedId(idDoc) )
        {
        	for(i = 0 ; i < nbMaps ; i++)
          {
          	if ( !strcmp(idDoc,tempObjects[i]) )
            {
            	treeInfo->setTreeID( string(storedObjects[i]) ) ;
              strcpy( idDoc, storedObjects[i] ) ;
              break ;
            }
          }
        }
        //loop on the nodes
        //=================
        NSPatPathoArray PatPathoArray(pContexte) ;
        treeInfo->getPatPatho(&PatPathoArray, true) ;

        if (!PatPathoArray.empty())
        {
        	PatPathoIter patIter = PatPathoArray.begin() ;
          while (patIter != PatPathoArray.end())
          {
          	NSPatPathoInfo* patPathoInfo = *patIter ;
            char* tempNode = patPathoInfo->pDonnees->noeud ;
            if ( toBeChanged(tempNode) ) //Node is temporary
            {
/*
							sprintf(debug,"temporary node : %s %s", tempNode, idDoc);
							ps = string(debug);
							pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails);
*/
							for (i = 0 ; i < nbMaps ; i++)
              {
              	if (!strcmp(idDoc,storedObjects[i]) && !strcmp(tempNode,tempNodes[i]))
                {
                	strcpy(patPathoInfo->pDonnees->treeID, storedObjects[i]) ;
                  strcpy(patPathoInfo->pDonnees->noeud, storedNodes[i]) ;
                  break ;
                }
              }
						} //end of if node is temporary
            patIter++ ;
          }   // end of loop on nodes
        }     // enf of if there are nodes

        treeInfo->setPatPatho(&PatPathoArray, true) ;

        treeIter++ ;
      }   // end of loop on trees
    }     // end of if( nbTrees > 0 )

		//loop on the links (pGraph->aLinks)
		//==================================
		if (nbLinks > 0)
		{
			NSPatLinkIter linkIter = pGraph->aLinks.begin() ;
      while( linkIter != pGraph->aLinks.end() )
      {
      	NSPatLinkInfo* linkInfo = *linkIter ;

        //=== modify "qualifie"
        char szQualifie[PATLINK_QUALIFIE_LEN + 1] ;
        strcpy(szQualifie, linkInfo->getQualifie().c_str()) ;

        char *idDoc  = szQualifie ;  //object + node
        char *idNode = szQualifie + OBJECT_ID_LEN ;  //node or '\0'
        if ( toBeChangedForComposedId(idDoc) )         //object : test if changed
        {
        	for (int i = 0 ; i < nbMaps ; i++)
          {
          	if (!strncmp(idDoc, tempObjects[i], OBJECT_ID_LEN))
            {
            	for(int j=0 ; j < OBJECT_ID_LEN ; j++)
              	idDoc[j]=storedObjects[i][j] ;
              break ;
            }
          }
        }
        if ( toBeChanged(idNode) )    //node
        {
        	for(int i=0; i<nbMaps; i++)
          {
          	if (!strncmp(idDoc,storedObjects[i],OBJECT_ID_LEN) &&
                !strcmp(idNode,tempNodes[i]) )
            {
            	for (int j = 0 ; j < PPD_NOEUD_LEN ; j++)
              	idNode[j] = storedNodes[i][j] ;
              break ;
            }
          }
        }
        linkInfo->setQualifie(szQualifie) ;

        //=== modify "qualifiant"
        char szQualifiant[PATLINK_QUALIFIE_LEN + 1] ;
        strcpy(szQualifiant, linkInfo->getQualifiant().c_str()) ;

        idDoc  = szQualifiant ;  //object + node
        idNode = szQualifiant + OBJECT_ID_LEN ;  //node or '\0'
        if (toBeChangedForComposedId(idDoc))     //doc
        {
        	for (int i = 0 ; i < nbMaps ; i++)
          {
          	if (!strncmp(idDoc, tempObjects[i], OBJECT_ID_LEN))
            {
            	for(int j=0; j<OBJECT_ID_LEN; j++)
              	idDoc[j] = storedObjects[i][j] ;
              break ;
            }
          }
        }
        if (toBeChanged(idNode))    //node
        {
        	for(int i = 0 ; i < nbMaps ; i++)
          {
          	if( !strncmp(idDoc,storedObjects[i],OBJECT_ID_LEN) &&
                    !strcmp(idNode,tempNodes[i]) )
            {
            	for(int j=0; j<PPD_NOEUD_LEN; j++)
              	idNode[j]=storedNodes[i][j];
              break;
            }
          }
        }
        linkInfo->setQualifiant(szQualifiant) ;

        linkIter++ ;
      }   // end of loop on links
    }     // end of if( nbLinks > 0 )

    //loop on the models (pGraph->aArchs)
    //===================================
    if (nbModels > 0)
    {
    	NSArcLinkIter modelIter = pGraph->aArchs.begin() ;
      while( modelIter != pGraph->aArchs.end() )
      {
      	NSArcLink* modelInfo = *modelIter ;

        //=== modify "object"
        const char *idObj = modelInfo->object.c_str() ;   //object
        if ( toBeChanged(idObj) )    //object
        {
        	for (int i = 0 ; i < nbMaps ; i++)
          {
          	if (!strcmp(idObj,tempObjects[i]))
            {
            	modelInfo->object = string(storedObjects[i]) ;
              break ;
            }
          }
        }

        //=== modify "node"
        const char *idNode = modelInfo->node.c_str() ;   //node
        if (toBeChanged(idNode))
        {
        	for (int i = 0 ; i < nbMaps ; i++)
          {
          	if (!strcmp(idNode,tempNodes[i]))
            {
            	modelInfo->node = string(storedNodes[i]) ;
              break ;
            }
          }
        }

        //=== modify "model_object_id"
        //=== No need to transform with mappings - The modelObject is not temporary

        modelIter++ ;
      }   // end of loop on models
    }     // end of if( nbModels > 0 )

		//------------------------------------------------------------------------------
    //loop on the rights (pGraph->aRights)
    //===================================
		if (nbRights > 0)
		{
			NSNodeRightIter rightIter = pGraph->aRights.begin() ;
      while( rightIter != pGraph->aRights.end() )
      {
      	NSNodeRight* rightInfo = *rightIter ;

        //=== modify "object"
        const char *idObj = rightInfo->node.c_str() ;   //node
        if ( toBeChanged(idObj) )    //object
        {
        	for (int i = 0 ; i < nbMaps ; i++)
          {
          	if (!strcmp(idObj,tempObjects[i]))
            {
            	rightInfo->node = string(storedObjects[i]) ;
              break ;
            }
          }
        }
        rightIter++ ;
      }   // end of loop on rights
    }     // end of if( nbRigts > 0 )

		//------------------------------------------------------------------------------

    //delete the mappings variables
    //loop on the mappings to set the new values of trees and nodes
		for( int i = 0 ; i < nbMaps ; i++)
		{
    	delete[] tempNodes[i] ;
      delete[] tempObjects[i] ;

      delete[] storedNodes[i] ;
      delete[] storedObjects[i] ;
    }
    delete[] tempNodes ;
    delete[] tempObjects ;

    delete[] storedNodes ;
    delete[] storedObjects ;
	}     //end of if nbMaps > 0
}
catch (...)
{
	erreur("Exception NautilusPilot::applyMappings", standardError, 0) ;
}
}

int
NautilusPilot::nbOfChildren(jobject jTree, string sNodeName)
{
	if (jTree == NULL)
  	return -1 ;

	JNIEnv* jenv = JavaSystem::jenv ;
	if (jenv == NULL)
	{
		fprintf(stderr, "NautilusPilot::nbOfChildren : jenv is null. Exiting...\n") ;
		return NULL ;
	}

	//=== get method id for the DOMElement getNbChildren method
	jmethodID midNoOfChildrens = jenv->GetMethodID(classDOMElement, "getNbChildren",
                "(Ljava/lang/String;)I") ;
	if (midNoOfChildrens == 0)
	{
		erreur("Cannot locate the DOMElement getNbChildren method. Exiting...\n", standardError, 0, 0) ;
		return -1 ;
	}
	jstring jNodeName = jenv->NewStringUTF( sNodeName.c_str() ) ;
	int iResult = (jint)jenv->CallObjectMethod(jTree, midNoOfChildrens, jNodeName) ;
	jenv->DeleteLocalRef(jNodeName) ;
	return iResult ;
}

string
NautilusPilot::getText(jobject jTree)
{
	if (NULL == jTree)
  	return "" ;

	JNIEnv* jenv = JavaSystem::jenv ;
	if (NULL == jenv)
	{
		fprintf(stderr, "NautilusPilot::getText : jenv is null. Exiting...\n") ;
		return "" ;
	}

	//=== get method id for the DOMElement getFirstText method
	jmethodID midText = jenv->GetMethodID(classDOMElement, "getFirstText",
                "()Ljava/lang/String;") ;
	if (midText == 0)
	{
  	erreur("Cannot locate the DOMElement getFirstText method. Exiting...\n", standardError, 0, 0) ;
    return NULL ;
	}
	jstring jResult = (jstring)jenv->CallObjectMethod(jTree, midText) ;
  string sRes = JavaSystem::NewStringObjWithSpecialCharacters(jResult) ;
  jenv->DeleteLocalRef(jResult) ;
  return sRes ;
}

string
NautilusPilot::getTagName(jobject jTree)
{
	if (NULL == jTree)
  	return "" ;

	JNIEnv* jenv = JavaSystem::jenv ;
	if (NULL == jenv)
	{
		fprintf(stderr, "NautilusPilot::getTagName : jenv is null. Exiting...\n") ;
		return "" ;
	}
	//=== get method id for the DOMElement getFirstText method
	jmethodID midTag = jenv->GetMethodID(classDOMElement, "getTagName",
                "()Ljava/lang/String;") ;
	if (0 == midTag)
	{
		erreur("Cannot locate the DOMElement getTagName method. Exiting...\n", standardError, 0, 0) ;
		return "" ;
	}
	jstring jResult = (jstring)jenv->CallObjectMethod(jTree, midTag) ;
	string sRes = JavaSystem::NewStringObjWithSpecialCharacters(jResult) ;
	jenv->DeleteLocalRef(jResult) ;
	return sRes ;
}

void
NautilusPilot::DOMTreeToBasicAttribute(NSBasicAttributeArray* pAttrElem, jobject jTree, string sNodeName)
{
	if ((NULL == pAttrElem) || (NULL == jTree))
  	return ;

	JNIEnv* jenv = JavaSystem::jenv ;
  if (NULL == jenv)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return ;
	}

	jstring jNodeName = jenv->NewStringUTF( sNodeName.c_str() ) ;
	jobjectArray jDomElems = (jobjectArray)jenv->CallObjectMethod(jTree, midChildrenElements, jNodeName, NULL) ;
	jenv->DeleteLocalRef(jNodeName) ;
	if (NULL == jDomElems)
  {
		erreur("NautilusPilot::DOMTreeToBasicAttribute : CallObjectMethod failed. Exiting...\n", standardError, 0, 0) ;
    jenv->DeleteLocalRef(jDomElems) ;
		return ;
	}
	jsize count = jenv->GetArrayLength(jDomElems) ;
	for (int i = 0 ; i < count ; i++)
	{
    jobject jNodeElem = jenv->GetObjectArrayElement(jDomElems, i) ;
    if (NULL != jNodeElem)
    {
    	if ((getTagName(jNodeElem) == "") /* || (getText(jNodeElem) == "")*/)
      {
      	jenv->DeleteLocalRef(jDomElems) ;
        jenv->DeleteLocalRef(jNodeElem) ;
        return ;
      }
      NSBasicAttribute* pAttribute = new NSBasicAttribute() ;
      pAttribute->setBalise(getTagName(jNodeElem)) ;
      pAttribute->setText(getText(jNodeElem));
      pAttrElem->push_back(pAttribute) ;
      jenv->DeleteLocalRef(jNodeElem) ;
    }
	}

  jenv->DeleteLocalRef(jDomElems) ;
}

//used from patient list
//used from all persons list
//used from person list from traits
bool
NautilusPilot::personList(const char* serviceName, NSPersonsAttributesArray *pPatList, NSBasicAttributeArray *pAttrArray)
{
	if (!serviceName || !pPatList || !pAttrArray)
  	return false ;

try
{
	JNIEnv* jenv = JavaSystem::jenv ;
  if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "personOrObjectList",
      "(Ljava/lang/String;[Ljava/lang/String;)Ldomlightwrapper/DOMElement;") ;
	if (mid == 0)
  {
    string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "personListMethodNotFound") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

  jobjectArray strArray = createJObjectArray(pAttrArray) ;
	jstring jServName = jenv->NewStringUTF( serviceName ) ;
	jobject jDOMElem = jenv->CallObjectMethod(jNautilusPilot, mid, jServName, strArray) ;
	jenv->DeleteLocalRef(strArray) ;
  jenv->DeleteLocalRef(jServName) ;
	if (jDOMElem == NULL)
	{
    if (getReturnType(jenv) == WARNING_RETURN)
    {
      jstring jWarning = (jstring)jenv->GetObjectField(jNautilusPilot, jFidWarning) ;
      if (jWarning != NULL )
      {
        // warnings
        string sWarning = string(JavaSystem::NewStringWithSpecialCharacters(jWarning)) ;
        if (sWarning == "noData")
        {
          jenv->DeleteLocalRef(jDOMElem) ;
          return true ;
        }
        else
        {
          warningMessage = pContexte->getSuperviseur()->getText("NTIERS", sWarning) ;
          jenv->DeleteLocalRef(jDOMElem) ;
          return false ;
        }
      }
    }
    else if (getTextError(jenv) != "")
    {
      errorMessage = getTextError(jenv) ;
      jenv->DeleteLocalRef(jDOMElem) ;
      return false ;
    }
    else
    {
      jenv->DeleteLocalRef(jDOMElem) ;
      return true ;
    }
	}

  jstring jNodeName = jenv->NewStringUTF("person") ;
  jobjectArray jDomElems = (jobjectArray)jenv->CallObjectMethod(jDOMElem, midChildrenElements, jNodeName) ;
  jenv->DeleteLocalRef(jNodeName) ;
  if (jDomElems == NULL)
  {
    jenv->DeleteLocalRef(jDomElems) ;
    return true ;
  }

  int count = jenv->GetArrayLength(jDomElems) ;
  for (int i = 0 ; i < count ; i++)
  {
    jobject jNodeElem = jenv->GetObjectArrayElement(jDomElems, i) ;
    if (jNodeElem != NULL)
    {
      NSBasicAttributeArray* pPersonAttributes = new NSBasicAttributeArray() ;
      DOMTreeToBasicAttribute(pPersonAttributes, jNodeElem) ;
      jenv->DeleteLocalRef(jNodeElem) ;
      pPatList->push_back(pPersonAttributes) ;
    }
    else
    {
      string ps = string("NautilusPilot::personList : GetObjectArrayElement failed.") ;
      pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    }
  }
  jenv->DeleteLocalRef(jDomElems) ;
  return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::personList", standardError, 0) ;
	return false ;
}
}


bool
NautilusPilot::getUserProperties(const char* serviceName, NSPersonsAttributesArray *pPatList,
                                                    NSBasicAttributeArray *pAttrArray)
//====================================================================================
{
	if (!serviceName || !pPatList || !pAttrArray)
  	    return false ;
    return  personList(serviceName, pPatList, pAttrArray) ;
}


//used from all object list
bool
NautilusPilot::objectList(const char* serviceName, NSPersonsAttributesArray *pObjectList,
                                                    NSBasicAttributeArray *pAttrArray)
//====================================================================================
{
	if (!serviceName || !pObjectList || !pAttrArray)
		return false ;

try
{
	JNIEnv* jenv = JavaSystem::jenv;
	if (NULL == jenv)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "personOrObjectList",
      "(Ljava/lang/String;[Ljava/lang/String;)Ldomlightwrapper/DOMElement;");
	if (mid == 0)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "objectListMethodNotFound") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}
	jobjectArray strArray = createJObjectArray(pAttrArray) ;
	jstring jServName = jenv->NewStringUTF( serviceName ) ;
	jobject jDOMElem = jenv->CallObjectMethod(jNautilusPilot, mid, jServName, strArray) ;
	jenv->DeleteLocalRef(strArray) ;
	jenv->DeleteLocalRef(jServName) ;
	if (jDOMElem == NULL)
	{
  	if (getReturnType(jenv) == WARNING_RETURN)                //WARNING_RETURN
    	warningMessage = getTextWarning(jenv, "NTIERS") ;
    else
    	errorMessage = getTextError(jenv) ;
    jenv->DeleteLocalRef(jDOMElem) ;
    return false ;
	}

  jstring jNodeName = jenv->NewStringUTF( "object" );
  jobjectArray jDomElems = (jobjectArray)jenv->CallObjectMethod(jDOMElem, midChildrenElements, jNodeName);
  jenv->DeleteLocalRef(jNodeName);
  jenv->DeleteLocalRef(jDOMElem);
  if (jDomElems == NULL)
  {
  	string ps = string("NautilusPilot::objectList : CallObjectMethod failed for midChildrenElements. exiting...") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    jenv->DeleteLocalRef(jDomElems);
    return true ;
	}
  int count = jenv->GetArrayLength(jDomElems) ;
  for (int i = 0 ; i < count ; i++)
  {
  	jobject jNodeElem = jenv->GetObjectArrayElement(jDomElems, i) ;
    if (jNodeElem != NULL)
    {
    	NSBasicAttributeArray* pobjAttributes = new NSBasicAttributeArray();
      DOMTreeToBasicAttribute(pobjAttributes, jNodeElem);
      jenv->DeleteLocalRef(jNodeElem) ;
      pObjectList->push_back(pobjAttributes) ;
    }
    else
    {
    	string ps = string("NautilusPilot::personList : GetObjectArrayElement failed.") ;
      pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    }
	}

	jenv->DeleteLocalRef(jDomElems) ;
	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::objectList", standardError, 0) ;
	return false ;
}
}

jobjectArray
NautilusPilot::createJObjectArray(NSBasicAttributeArray *pAttrArray)
//=================================================================
{
	if (NULL == pAttrArray)
		return NULL ;

	JNIEnv* jenv = JavaSystem::jenv ;
	if (NULL == jenv)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return NULL ;
	}

	uint size = pAttrArray->size() ;

	jobjectArray strArray = jenv->NewObjectArray(2*size, classStr, NULL) ;
	if (strArray == NULL)
	{
		string ps = string("NautilusPilot::createJObjectArray : NewObjectArray failed. Exiting...") ;
		pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    return NULL ;
	}

	if (pAttrArray->empty())
  	return strArray ;

	int i = 0 ;
	for (NSBasicAttributeIter iterAttr = pAttrArray->begin(); iterAttr != pAttrArray->end(); iterAttr++)
	{
		jstring jstr = jenv->NewStringUTF( ((*iterAttr)->getBalise()).c_str() ) ;
		jenv->SetObjectArrayElement(strArray, i, jstr) ;
		i++ ;
		jstring jstr2 = jenv->NewStringUTF( ((*iterAttr)->getText()).c_str() ) ;
		jenv->SetObjectArrayElement(strArray, i, jstr2) ;
		i++ ;
		jenv->DeleteLocalRef(jstr) ;
    jenv->DeleteLocalRef(jstr2) ;
	}
	return strArray ;
}

//----------------------------- create Person or Object ------------------------
//la liste des patients mont�e ici n'est pas utilis�e actuellement
//iType = 0 person
//iType = 1 object
bool
NautilusPilot::createPersonOrObject(const char* serviceName, NSDataGraph* pGraph, NSPersonsAttributesArray *pList,
                                NSBasicAttributeArray *pAttrArray, int iType, bool forcedCreate)
//================================================================================================================
{
try
{
	if ((!pAttrArray) || (!pGraph) || (!pList))
  	return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
  if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return NULL ;
	}
  int nbTrees  = 0 ;
  int nbLinks  = 0 ;
  int nbModels = 0 ;
  int nbRights = 0 ;

  // 1) build a graph for the java side
  //====================================
  jobject jGraph = buildGraphForJava(jenv, pGraph, nbTrees, nbLinks, nbModels, nbRights) ;
  if (nbTrees == 0)
  {
  	jenv->DeleteLocalRef(jGraph) ;
    return false ;
  }

  if (forcedCreate)
  	// Le contenu n'a pas d'importance, c'est l'existence de la balise qui compte
  	pAttrArray->push_back(new NSBasicAttribute("force", "true")) ;

  jobjectArray strArray = createJObjectArray(pAttrArray) ;

  if (forcedCreate)
  	pAttrArray->eraseAttributeValue("force") ;

  jmethodID mid ;
  if (iType == PERSON_TYPE )
		mid = jenv->GetMethodID(classNautilusPilot, "createPerson",
                "(Lnautilus/NautilusGraph;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Object;") ;
  else
  	if (iType == OBJECT_TYPE)
    	mid = jenv->GetMethodID(classNautilusPilot, "createObject",
                "(Lnautilus/NautilusGraph;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Object;") ;
  if (mid == 0)
  {
  	string sErrorText = "Cannot locate the NautilusPilot createPatient method." ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
    jenv->DeleteLocalRef(strArray) ;
    jenv->DeleteLocalRef(jGraph) ;
		return false ;
	}

  jstring jServName = jenv->NewStringUTF( serviceName ) ;
	jobjectArray jObjet = (jobjectArray)jenv->CallObjectMethod(jNautilusPilot, mid, jGraph,jServName, strArray) ;
	jenv->DeleteLocalRef(strArray) ;
  jenv->DeleteLocalRef(jServName);
  jenv->DeleteLocalRef(jGraph) ;

	if (jenv->ExceptionOccurred() )
	{
  	//erreur("Erreur execution: createPatient - service",standardError,0,0);
		string sErrorText = getTextError(jenv) ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
		jenv->ExceptionDescribe();
    jenv->DeleteLocalRef(jObjet);
		return false ;
	}

	if ((jObjet == NULL) && (getReturnType(jenv) == WARNING_RETURN))
	{
		string sErrorText = getTextError(jenv) ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return false ;
	}

  if (getReturnType(jenv) == DOMELEMENT_RETURN)    //DOMELEMENT_RETURN
  {
    jstring jNodeName ;
    switch(iType)
    {
      case  PERSON_TYPE :
        jNodeName  = jenv->NewStringUTF( "person" ) ;
        break ;
      case  OBJECT_TYPE :
        jNodeName  = jenv->NewStringUTF( "object" ) ;
        break ;
    }
    jobjectArray jDomElems = (jobjectArray)jenv->CallObjectMethod(jObjet, midChildrenElements, jNodeName) ;
    jenv->DeleteLocalRef(jNodeName) ;
    int count = 0 ;
    if (jDomElems == NULL)
    {
      string ps = string("NautilusPilot::createPersonOrObject : CallObjectMethod failed. Exiting...") ;
      pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
      jenv->DeleteLocalRef(jObjet);
      return false ;
    }
    count = jenv->GetArrayLength(jDomElems) ;
    for(int i=0; i<count; i++)
    {
      jobject jNodeElem = jenv->GetObjectArrayElement(jDomElems, i) ;
      NSBasicAttributeArray* pIDAttributes = new NSBasicAttributeArray() ;

      DOMTreeToBasicAttribute(pIDAttributes, jNodeElem) ;
      pList->push_back(pIDAttributes) ;
      jenv->DeleteLocalRef(jNodeElem) ;
    }
  }
  else
    if (getReturnType(jenv) == MAPPING_RETURN)             //MAPPING_RETURN
  	{
  		//si l'enregistement est effectu� pour une personne on transfer les props de bloque.
    	if (iType == PERSON_TYPE)
        transformResultFieldInAttributesArray(jenv, pList, "status", "*") ;

      applyMappings(jenv, jObjet, pGraph, nbTrees, nbLinks, nbModels, nbRights) ;
    }

  jenv->DeleteLocalRef(jObjet) ;

	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::createPersonOrObject", standardError, 0) ;
	return false ;
}
}

//-------------------------invokeService----------------------------------------
//utilis�e pour la recherche des objets
bool
NautilusPilot::invokeService(const char* serviceName, NSDataGraph* pGraph,
                    NSPersonsAttributesArray *pObjList, NSBasicAttributeArray *pAttrArray)
//========================================================================================
{
try
{
	if((!pAttrArray)||(!pGraph))
		return false;
	JNIEnv* jenv = JavaSystem::jenv;

	jobjectArray strArray = createJObjectArray(pAttrArray);

	jstring jServName = jenv->NewStringUTF( serviceName );
	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "invokeServiceReturnObject",
      "(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Object;");
	if (mid == 0)
	{
  	string sErrorText = "Cannot locate the NautilusPilot invokeService (3) method." ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return false;
	}

	jobjectArray jObject = (jobjectArray)jenv->CallObjectMethod(jNautilusPilot, mid, jServName, strArray);
  jenv->DeleteLocalRef(jServName) ;
  jenv->DeleteLocalRef(strArray) ;
	if (jenv->ExceptionOccurred() )
	{
		//erreur("Erreur execution: createPatient - service",standardError,0,0);
		string sErrorText = getTextError(jenv) ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
    jenv->ExceptionDescribe() ;
    return false ;
	}

	if (jObject == NULL)
	{
  	if ( getReturnType(jenv) == WARNING_RETURN)
    {
    	warningMessage = getTextWarning(jenv, "NTIERS") ;
      return false ;
    }
    errorMessage = getTextError(jenv) ;
		return false ;
	}
	else
	{
		if (getReturnType(jenv) == DOMELEMENT_RETURN)    //DOMELEMNT_RETURN
		{
    	jstring jNodeName = jenv->NewStringUTF( "object" ) ;
      jobjectArray jDomElems = (jobjectArray)jenv->CallObjectMethod(jObject, midChildrenElements, jNodeName) ;
      jenv->DeleteLocalRef(jNodeName) ;
      int count = 0 ;
      if (jDomElems == NULL)
			{
      	string ps = string("NautilusPilot::invokeService : CallObjectMethod failed. Exiting...") ;
				pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
        jenv->DeleteLocalRef(jDomElems) ;
        return false ;
			}
      count = jenv->GetArrayLength(jDomElems) ;
      for (int i = 0 ; i < count ; i++)
      {
				jobject jNodeElem = jenv->GetObjectArrayElement(jDomElems, i) ;
        if (jNodeElem != NULL)
        {
        	NSBasicAttributeArray* pIDAttributes = new NSBasicAttributeArray() ;

					DOMTreeToBasicAttribute(pIDAttributes, jNodeElem) ;
					pObjList->push_back(pIDAttributes) ;
          jenv->DeleteLocalRef(jNodeElem) ;
        }
        else
				{
					string ps = string("NautilusPilot::invokeService : CallObjectMethod failed.") ;
					pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
				}
			}
      jenv->DeleteLocalRef(jDomElems) ;
		}
		else
			if (getReturnType(jenv) == GRAPH_RETURN)    //GRAPH_RETURN
			{
				// build a C graph from the java graph object
				//===========================================
				buildGraphForC(jenv, jObject, pGraph) ;
				jenv->DeleteLocalRef(jObject) ;
				transformResultFieldInAttributesArray(jenv, pObjList, "list", "object") ;
			}
	}
	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::invokeService", standardError, 0) ;
	return false ;
}
}

bool
NautilusPilot::modifyPersonOrObject(const char* serviceName, NSDataGraph* pGraph,
                    NSPersonsAttributesArray *pList, NSBasicAttributeArray *pAttrArray)
//=====================================================================================
{
	string sMessage = string("NautilusPilot::modifyPersonOrObject -- begin") ;
	pContexte->getSuperviseur()->trace(&sMessage, 1, NSSuper::trSteps) ;

	if ((!pAttrArray) || (!pGraph))
		return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
	if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	int nbTrees  = 0 ;
	int nbLinks  = 0 ;
	int nbModels = 0 ;
	int nbRights = 0 ;

	// 1) build a graph for the java side
	//====================================
	jobject jGraphIn = buildGraphForJava(jenv, pGraph, nbTrees, nbLinks, nbModels, nbRights) ;

	sMessage = string("NautilusPilot::modifyPersonOrObject -- Graph4Java build") ;
	pContexte->getSuperviseur()->trace(&sMessage, 1, NSSuper::trSteps) ;

	if (nbTrees == 0)
	{
		string sErrorText = "L'arbre de votre graph ne contient pas de donn�es" ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
		jenv->DeleteLocalRef(jGraphIn) ;
		return false ;
	}
  /*	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "invokeService",
                "(Ljava/lang/String;Lnautilus/NautilusGraph;[Ljava/lang/String;)[LgraphServer/Mapping;");
	if (mid == 0)
	{
		erreur("Cannot locate the NautilusPilot invokeService (2) method.",standardError, 0, 0);
		return false;
	}  */

	jobjectArray strArray = createJObjectArray(pAttrArray) ;
	jstring jServName = jenv->NewStringUTF( serviceName ) ;

	sMessage = string("NautilusPilot::modifyPersonOrObject -- JObjectArray created") ;
	pContexte->getSuperviseur()->trace(&sMessage, 1, NSSuper::trSteps) ;

	jobjectArray jGraph = (jobjectArray)jenv->CallObjectMethod(jNautilusPilot, midModify, jServName, jGraphIn, strArray) ;

	sMessage = string("NautilusPilot::modifyPersonOrObject -- method called") ;
	pContexte->getSuperviseur()->trace(&sMessage, 1, NSSuper::trSteps) ;

	jenv->DeleteLocalRef(strArray) ;
	jenv->DeleteLocalRef(jServName) ;
	jenv->DeleteLocalRef(jGraphIn) ;
	if (jenv->ExceptionOccurred())
	{
		//erreur( getTextError(jenv), standardError, 0, 0);
		string sErrorText = getTextError(jenv) ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
		jenv->DeleteLocalRef(jGraph) ;
		return false ;
	}

	if ((jGraph == NULL) && (getReturnType(jenv) == WARNING_RETURN))        //WARNING_RETURN
	{
		warningMessage = string(getTextWarning(jenv, "NTIERS")) ;
		return false ;
	}

	applyMappings(jenv, jGraph, pGraph, nbTrees, nbLinks, nbModels, nbRights) ;

	sMessage = string("NautilusPilot::modifyPersonOrObject -- mappings applied") ;
	pContexte->getSuperviseur()->trace(&sMessage, 1, NSSuper::trSteps) ;

	jenv->DeleteLocalRef(jGraph) ;

	sMessage = string("NautilusPilot::modifyPersonOrObject -- get2call transformResultFieldInAttributesArray") ;
	pContexte->getSuperviseur()->trace(&sMessage, 1, NSSuper::trSteps) ;

	transformResultFieldInAttributesArray(jenv, pList) ;

	sMessage = string("NautilusPilot::modifyPersonOrObject -- end") ;
	pContexte->getSuperviseur()->trace(&sMessage, 1, NSSuper::trSteps) ;

	return true ;
}

bool
NautilusPilot::modifyTraitsForPersonOrObject(const char* serviceName,
                    NSPersonsAttributesArray *pList, NSBasicAttributeArray *pAttrArray)
//=====================================================================================
{
	string sMessage = string("NautilusPilot::modifyTraitsForPersonOrObject -- begin") ;
	pContexte->getSuperviseur()->trace(&sMessage, 1, NSSuper::trSteps) ;

	if (NULL == pAttrArray)
		return false ;

	return invokeSimpleService(serviceName, pAttrArray) ;

/*
	JNIEnv* jenv = JavaSystem::jenv ;
	if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jobjectArray strArray = createJObjectArray(pAttrArray) ;
	jstring jServName = jenv->NewStringUTF( serviceName ) ;

	sMessage = string("NautilusPilot::modifyTraitsForPersonOrObject -- JObjectArray created") ;
	pContexte->getSuperviseur()->trace(&sMessage, 1, NSSuper::trSteps) ;

	jobjectArray jGraph = (jobjectArray)jenv->CallObjectMethod(jNautilusPilot, midModify, jServName, NULL, strArray) ;

	sMessage = string("NautilusPilot::modifyTraitsForPersonOrObject -- method called") ;
	pContexte->getSuperviseur()->trace(&sMessage, 1, NSSuper::trSteps) ;

	jenv->DeleteLocalRef(strArray) ;
	jenv->DeleteLocalRef(jServName) ;
	if (jenv->ExceptionOccurred())
	{
		//erreur( getTextError(jenv), standardError, 0, 0);
		string sErrorText = getTextError(jenv) ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
		jenv->DeleteLocalRef(jGraph) ;
		return false ;
	}

	if (getReturnType(jenv) == WARNING_RETURN)        //WARNING_RETURN
	{
		warningMessage = string(getTextWarning(jenv, "NTIERS")) ;
		return false ;
	}

	sMessage = string("NautilusPilot::modifyTraitsForPersonOrObject -- get2call transformResultFieldInAttributesArray") ;
	pContexte->getSuperviseur()->trace(&sMessage, 1, NSSuper::trSteps) ;

	transformResultFieldInAttributesArray(jenv, pList) ;

	sMessage = string("NautilusPilot::modifyTraitsForPersonOrObject -- end") ;
	pContexte->getSuperviseur()->trace(&sMessage, 1, NSSuper::trSteps) ;

	return true ;
*/
}

//-------------------------invokeService-----------------------------------------------
//utilis�e pour login et pour la modification d'une personne
//invokeService return mapping. Il faut recuperer le DOMElement
bool
NautilusPilot::invokeService2ReturnElements(const char* serviceName, NSDataGraph* pGraph,
                    NSPersonsAttributesArray *pList, NSBasicAttributeArray *pAttrArray)
//=======================================================================================
{
	if (!serviceName || !pGraph || !pList || !pAttrArray)
  	return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
	if (NULL == jenv)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}
	jobjectArray strArray = createJObjectArray(pAttrArray) ;
  if (strArray == NULL)
	{
  	string ps = string("NautilusPilot::invokeService2ReturnElements : createJObjectArray failed. Exiting...") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    return false ;
	}

	jstring jServName = jenv->NewStringUTF( serviceName ) ;
	jobject jGraph = NULL ;
	if (string(SERV_LOGIN) == string(serviceName))
	{
		/*classNautilusPilot, "invokeService",  "(Ljava/lang/String;[Ljava/lang/String;)Lnautilus/NautilusGraph;");    */
    jGraph = (jobjectArray)jenv->CallObjectMethod(jNautilusPilot, midSimpInvoke, jServName, strArray);
	}
  else
  {
  	/*classNautilusPilot, "invokeService",  "(Ljava/lang/String;Lnautilus/NautilusGraph;[Ljava/lang/String;)[LgraphServer/Mapping;");*/
    jGraph = (jobjectArray)jenv->CallObjectMethod(jNautilusPilot, midInvoke, jServName, strArray);
	}

	jenv->DeleteLocalRef(strArray) ;
	jenv->DeleteLocalRef(jServName) ;
	if (jenv->ExceptionOccurred() )
	{
		errorMessage = getTextError(jenv) ;
    jenv->DeleteLocalRef(jGraph) ;
		return false ;
	}

  if ((NULL == jGraph) && (WARNING_RETURN == getReturnType(jenv)))        //WARNING_RETURN
	{
  	warningMessage = string(getTextWarning(jenv, "NTIERS")) ;
    jenv->DeleteLocalRef(jGraph) ;
    return false ;
	}
  buildGraphForC(jenv, jGraph, pGraph) ;
  jenv->DeleteLocalRef(jGraph) ;

	transformResultFieldInAttributesArray(jenv, pList) ;

	return true ;
}


//-------------------------invokeService-----------------------------------------------
//utilis�e pour import Ou modification object apres update avec le serveur collective
//invokeService return a graph. Il faut recuperer le DOMElement
bool
NautilusPilot::updateObjectList(const char* serviceName, NSDataGraph* pGraph, NSBasicAttributeArray *pAttrArray)
//=============================================================================================================
{
	if (!serviceName || !pGraph || !pAttrArray)
  	return false ;

	JNIEnv* jenv = JavaSystem::jenv;
  if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false;
	}

	jobjectArray strArray = createJObjectArray(pAttrArray) ;
  if (strArray == NULL)
	{
  	string ps = string("NautilusPilot::updateObjectList : createJObjectArray failed. Exiting...") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    return false ;
	}

	jstring jServName = jenv->NewStringUTF( serviceName );
	jmethodID mid;

    //modification d'une personne. Invoke service 1
    mid = jenv->GetMethodID(classNautilusPilot, "updateObjectList",
        "(Ljava/lang/String;[Ljava/lang/String;Lnautilus/NautilusGraph;)Ljava/lang/String;");
	if (mid == 0)
	{
		string sErrorText = "Cannot locate the NautilusPilot updateObjectList method." ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return false ;
	}

	jstring jWarning = (jstring)jenv->CallObjectMethod(jNautilusPilot, mid, jServName, strArray) ;

	jenv->DeleteLocalRef(strArray) ;
	jenv->DeleteLocalRef(jServName) ;
	if (jenv->ExceptionOccurred())
	{
  	errorMessage = getTextError(jenv) ;
    jenv->ExceptionDescribe() ;
		return false ;
	}
	if (jWarning == NULL)
	{
		return true ;
  }
	else
	{
  	warningMessage = string(JavaSystem::NewStringWithSpecialCharacters(jWarning)) ;
    return false ;
	}
}

//unlockPatient and  unlockAllPatients
bool
NautilusPilot::unlockPatient(const char* serviceName, NSBasicAttributeArray *pAttrArray)
{
	if (NULL == pAttrArray)
		return false ;

	return invokeSimpleService(serviceName, pAttrArray) ;
}

bool
NautilusPilot::setEpisodusVersion(string version)
{
	if (version == "")
		return false ;
	const char* serviceName = SERV_SET_PARAMETERS.c_str() ;
	NSBasicAttributeArray *pAttrArray = new NSBasicAttributeArray() ;
	pAttrArray->push_back(new NSBasicAttribute("version", version)) ;
	bool bInvoke = invokeSimpleService(serviceName, pAttrArray) ;
  delete pAttrArray ;
  return bInvoke ;
}

//modify PIDS server data
bool
NautilusPilot::modifyPIDSData(const char* serviceName, NSBasicAttributeArray *pAttrArray)
{
	if (NULL == pAttrArray)
		return false ;

	return invokeSimpleService(serviceName, pAttrArray) ;
}

bool
NautilusPilot::startAgent(string sAgentName)
{
	if (string("") == sAgentName)
  	return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
  if (NULL == jenv)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

  string service = "doConnect" + sAgentName ;
  const char* serviceName = service.c_str() ;
  jstring jServName = jenv->NewStringUTF( serviceName ) ;
	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "invokeSimpleService",
                            "(Ljava/lang/String;)Z") ;
	if (mid == 0)
	{
		fprintf(stderr, "Cannot locate the NautilusPilot invokeSimpleService method.") ;
		return false ;
	}
	jboolean jRes = (jboolean)jenv->CallObjectMethod(jNautilusPilot, mid, jServName) ;
	if (jenv->ExceptionOccurred() )
	{
		string sErrorText = getTextError(jenv) ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
		jenv->ExceptionDescribe() ;
		return false ;
	}

  jenv->DeleteLocalRef(jServName) ;
	bool bRes = (bool) jRes ;
	if ((!bRes) && ( getReturnType(jenv) == WARNING_RETURN)) // WARNING_RETURN
	{
  	jstring jWarning = (jstring)jenv->GetObjectField(jNautilusPilot, jFidWarning) ;
    string sWarning = pContexte->getSuperviseur()->getText("NTIERS", "nonInstancedWarning");
    if(jWarning != NULL )             // warnings
    	sWarning = string(JavaSystem::NewStringWithSpecialCharacters(jWarning));
    pAvailableAgentList->setAgentError( sAgentName, sWarning);
    return false ;
	}

	return true;
    //return invokeSimpleService(serviceName, pAttrArray);

}


//utilise invokeSimpleService
bool
NautilusPilot::invokeSimpleService(const char* serviceName, NSBasicAttributeArray *pAttrArray)
//===========================================================================================
{
try
{
	JNIEnv* jenv = JavaSystem::jenv ;
  if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jobjectArray strArray = createJObjectArray(pAttrArray) ;
	if (strArray == NULL)
	{
  	string ps = string("NautilusPilot::unlockPatient : createJObjectArray failed. Exiting...") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    return false ;
	}

	jstring jServName = jenv->NewStringUTF( serviceName );
	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "invokeSimpleService",
                            "(Ljava/lang/String;[Ljava/lang/String;)Z") ;
	if (mid == 0)
	{
		fprintf(stderr, "Cannot locate the NautilusPilot invokeSimpleService method.");
		return false;
	}
	jboolean jRes = (jboolean)jenv->CallObjectMethod(jNautilusPilot, mid, jServName, strArray);
	jenv->DeleteLocalRef(strArray);
    jenv->DeleteLocalRef(jServName);
	if (jenv->ExceptionOccurred() )
	{
		string sErrorText = getTextError(jenv) ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
		jenv->ExceptionDescribe() ;
		return false ;
	}
	bool bRes = (bool) jRes ;
	if (!bRes)
	{
		string sErrorText = getTextError(jenv) ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return false ;
	}
	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::personList", standardError, 0) ;
	return false ;
}
}

//login, password, personId du nouveau membre, le graph equipe de sant�
bool
NautilusPilot::addHealthTeamMember(const char* serviceName,
                NSBasicAttributeArray *pAttrArray, NSDataGraph* pGraph)
//=====================================================================
{
    if((!pAttrArray) || (!pGraph))
        return false;
    return invokeAddGraphService(serviceName, pAttrArray, pGraph);
}

//utilise invokeAddGraphService
bool
NautilusPilot::invokeAddGraphService(const char* serviceName,
                                NSBasicAttributeArray *pAttrArray, NSDataGraph* pGraph)
//======================================================================================
{
try
{
	JNIEnv* jenv = JavaSystem::jenv ;
  if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jobjectArray strArray = createJObjectArray(pAttrArray) ;
	if (strArray == NULL)
	{
  	string ps = string("NautilusPilot::invokeAddGraphService : createJObjectArray failed. Exiting...") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    return false ;
	}

	jstring jServName = jenv->NewStringUTF( serviceName );
	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "invokeAddGraphService",
                "(Ljava/lang/String;Lnautilus/NautilusGraph;[Ljava/lang/String;)Z") ;
	if (mid == 0)
	{
		fprintf(stderr, "Cannot locate the NautilusPilot invokeSimpleService method.");
		return false;
	}     
/*
    string ps2 = "NautilusPilot::writeGraph : start of buildGraphForJava" ;
    pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;
*/
    int nbTrees  = 0;
	int nbLinks  = 0;
	int nbModels = 0;
	int nbRights = 0;
	jobject jGraph = buildGraphForJava(jenv, pGraph, nbTrees, nbLinks, nbModels, nbRights);
	if ((nbTrees == 0) || (jGraph == NULL))
		return false ;

/*
    ps2 = "NautilusPilot::writeGraph : calling the Pilot" ;
    pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;
*/

	jboolean jRes = (jboolean)jenv->CallObjectMethod(jNautilusPilot, mid, jServName, jGraph, strArray) ;
	jenv->DeleteLocalRef(strArray) ;
  jenv->DeleteLocalRef(jServName) ;
	if (jenv->ExceptionOccurred())
	{
		string sErrorText = getTextError(jenv) ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
		jenv->ExceptionDescribe() ;
		return false ;
	}
	bool bRes = (bool) jRes ;
	if (!bRes)
	{
		string sErrorText = getTextError(jenv) ;
  	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return false ;
	}
	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::personList", standardError, 0) ;
	return false ;
}
}

//return the person graph (complet or patial)
//input data :  person Role (P,U or C),
//              the input Traits (login + password for patient or user, adeliNb for corresp)
bool
NautilusPilot::importPerson(const char* serviceName, NSBasicAttributeArray *pAttrArray,
                                         NSDataGraph* pGraph )
//===================================================================================
{
	if (!serviceName || !pAttrArray || !pGraph)
		return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
	if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jobjectArray strArray = createJObjectArray(pAttrArray) ;
  if (strArray == NULL)
	{
  	string ps = string("NautilusPilot::importPerson : createJObjectArray failed. Exiting...") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    return false ;
	}

	jstring jServiceName  = jenv->NewStringUTF( serviceName );
	jobject jGraph = jenv->CallObjectMethod(jNautilusPilot, midSimpInvoke, jServiceName, strArray);

  jenv->DeleteLocalRef(jServiceName);
  jenv->DeleteLocalRef(strArray);

	if (jenv->ExceptionOccurred() )
	{
  	const char* text = getTextError(jenv, "NTIERS", true) ;
    if(text != NULL)
    	errorMessage = string(text) ;
    jenv->DeleteLocalRef(jGraph) ;
    pGraph->graphReset() ;
    return false ;
  }
  else
  	if ((jGraph == NULL) && ( getReturnType(jenv) == WARNING_RETURN))                //WARNING_RETURN
    {
    	warningMessage = getTextWarning(jenv, "NTIERS") ;
      jenv->DeleteLocalRef(jGraph) ;
      return false ;
    }
    else
    	if (jGraph == NULL)
      {
      	const char* text = getTextError(jenv, "NTIERS", true) ;
        if (text != NULL)
        	errorMessage = string(text) ;
        jenv->DeleteLocalRef(jGraph) ;
        pGraph->graphReset() ;
        return false ;
      }
	pGraph->graphReset() ;
	// build a C graph from the java graph object
	//===========================================
	buildGraphForC(jenv, jGraph, pGraph) ;

	jenv->DeleteLocalRef(jGraph) ;
	return true ;
}

bool
NautilusPilot::importNewDataGraphPerson(const char* serviceName,
                            NSBasicAttributeArray *pAttrArray, NSDataGraph* pGraph )
//===================================================================================
{
	if (!serviceName || !pAttrArray || !pGraph)
  	return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
  if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jobjectArray strArray = createJObjectArray(pAttrArray);
  if (strArray == NULL)
	{
  	string ps = string("NautilusPilot::importNewDataGraphPerson : createJObjectArray failed. Exiting...") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    return false ;
	}

	//=== execute a NautilusGraph.readGraph method
	jobject jGraph ;
	jstring jServiceName  = jenv->NewStringUTF( serviceName ) ;
	jGraph = jenv->CallObjectMethod(jNautilusPilot, midSimpInvoke, jServiceName, strArray) ;
    jenv->DeleteLocalRef(jServiceName);
    jenv->DeleteLocalRef(strArray);
	if(jGraph == NULL)
	{
		string sErrorText = getTextError(jenv) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		return false ;
	}
	pGraph->graphReset() ;
	// build a C graph from the java graph object
	//===========================================
	buildGraphForC(jenv, jGraph, pGraph) ;

	jenv->DeleteLocalRef(jGraph) ;
	return true ;
}

bool
NautilusPilot::exportNewDataGraphPerson(const char* serviceName,
                                                    NSBasicAttributeArray *pAttrArray)
//====================================================================================
{
try
{
	if (!serviceName || !pAttrArray)
  	return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
  if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jobjectArray strArray = createJObjectArray(pAttrArray);
  if (strArray == NULL)
	{
  	string ps = string("NautilusPilot::exportNewDataGraphPerson : createJObjectArray failed. Exiting...") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    return false ;
	}

	jstring jServName = jenv->NewStringUTF( serviceName );
	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "invokeSimpleService",
                            "(Ljava/lang/String;[Ljava/lang/String;)Z");
	if (mid == 0)
	{
		fprintf(stderr, "Cannot locate the NautilusPilot invokeSimpleService method.") ;
		return false ;
	}
	jboolean jRes = (jboolean)jenv->CallObjectMethod(jNautilusPilot, mid, jServName, strArray);
    jenv->DeleteLocalRef(jServName);
    jenv->DeleteLocalRef(strArray);
	if(jenv->ExceptionOccurred() )
	{
		string sErrorText = getTextError(jenv) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		jenv->ExceptionDescribe();
		return false;
	}
	bool bRes = (bool) jRes ;
	if ((!bRes) && (getReturnType(jenv) == WARNING_RETURN)) //WARNING_RETURN
	{
  	warningMessage = string(getTextWarning(jenv, "NTIERS")) ;
    return false ;
	}
	if (!bRes)
	{
		errorMessage = string(getTextError(jenv, "NTIERS", true)) ;
		return false ;
	}
	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::personList", standardError, 0) ;
	return false ;
}
}

bool
NautilusPilot::getPersonInformation(const char* serviceName, NSBasicAttributeArray *pAttrArray,
                                         NSDataGraph* pGraph )
//===================================================================================
{
	if (!serviceName || !pAttrArray || !pGraph)
  	return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
    if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jobjectArray strArray = createJObjectArray(pAttrArray) ;
    if (strArray == NULL)
	{
  	    string ps = string("NautilusPilot::getPersonInformation : createJObjectArray failed. Exiting...") ;
        pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
        return false ;
	}

	jstring jServiceName  = jenv->NewStringUTF( serviceName ) ;
	jobject jGraph = jenv->CallObjectMethod(jNautilusPilot, midSimpInvoke, jServiceName, strArray) ;

	jenv->DeleteLocalRef(jServiceName) ;
  jenv->DeleteLocalRef(strArray) ;
  if (jenv->ExceptionOccurred() )
  {
  	const char* text = getTextError(jenv, "NTIERS", true) ;
    if (text != NULL)
    	errorMessage = string(text) ;
    jenv->DeleteLocalRef(jGraph) ;
    pGraph->graphReset() ;
    return false ;
	}
	else
    if ((jGraph == NULL) && ( getReturnType(jenv) == WARNING_RETURN))                //WARNING_RETURN
    {
    	warningMessage = getTextWarning(jenv, "NTIERS") ;
      jenv->DeleteLocalRef(jGraph) ;
      return false ;
    }

	pGraph->graphReset() ;
	// build a C graph from the java graph object
	//===========================================
	buildGraphForC(jenv, jGraph, pGraph) ;

	jenv->DeleteLocalRef(jGraph) ;
	return true ;
}

bool
NautilusPilot::createImportedPerson(const char* serviceName, NSDataGraph* pGraph, NSPersonsAttributesArray *pList,
                                NSBasicAttributeArray *pAttrArray)
//========================================================================================================
{
try
{
	if(!serviceName || !pAttrArray || !pGraph || !pList)
		return false ;

	JNIEnv* jenv = JavaSystem::jenv ;
  if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	int nbTrees  = 0;
	int nbLinks  = 0;
	int nbModels = 0;
	int nbRights = 0;

	// 1) build a graph for the java side
	//====================================
	jobject jGraph = buildGraphForJava(jenv, pGraph, nbTrees, nbLinks, nbModels, nbRights);
  if (jGraph == NULL)
  {
  	string ps = string("NautilusPilot::createImportedPerson : buildGraphForJava failed. Exiting...") ;
  	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
  	jenv->DeleteLocalRef(jGraph);
  	return false ;
  }

	if (nbTrees == 0)
  {
  	string ps = string("NautilusPilot::createImportedPerson : no trees after buildGraphForJava. Exiting...") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    jenv->DeleteLocalRef(jGraph);
		return false ;
	}

	//  "(Ljava/lang/String;[Ljava/lang/String;)Z");
	// 2) execute a NautilusPilot.createPatient method
	//================================================

	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "createImportedPerson",
                "(Lnautilus/NautilusGraph;Ljava/lang/String;[Ljava/lang/String;)Lnautilus/NautilusGraph;") ;
	if (mid == 0)
	{
		erreur("Cannot locate the NautilusPilot createPatient method.", standardError , 0 ,0) ;
		return false ;
	}
  jobjectArray strArray = createJObjectArray(pAttrArray) ;
  if (strArray == NULL)
	{
  	    string ps = string("NautilusPilot::createImportedPerson : createJObjectArray failed. Exiting...") ;
        pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
        return false ;
	}
  jstring jServName = jenv->NewStringUTF( serviceName ) ;

  jobjectArray jObject = (jobjectArray)jenv->CallObjectMethod(jNautilusPilot, mid, jGraph, jServName, strArray) ;
	jenv->DeleteLocalRef(strArray);
  jenv->DeleteLocalRef(jServName);

	if (jenv->ExceptionOccurred() )
	{
		//erreur("Erreur execution: createPatient - service",standardError,0,0);
		string sErrorText = getTextError(jenv) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		jenv->ExceptionDescribe() ;
    jenv->DeleteLocalRef(jObject);
		return false ;
	}
	if(getReturnType(jenv) == GRAPH_RETURN)    //GRAPH_RETURN
	{
		// build a C graph from the java graph object
		//===========================================
		buildGraphForC(jenv, jObject, pGraph) ;
		jenv->DeleteLocalRef(jObject) ;
	//	transformResultFieldInAttributesArray(jenv, pList, "list", "person") ;
  	transformResultFieldInAttributesArray(jenv, pList, "status", "*") ;
	}
	else
		if(getReturnType(jenv) == EMPTY_RETURN)
		{
			jenv->DeleteLocalRef(jObject) ;
			return true ;          //for createImportedUser
		}
		else
		{
			string sErrorText = getTextError(jenv) ;
			erreur(sErrorText.c_str(), standardError, 0, 0) ;
    	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      jenv->DeleteLocalRef(jObject) ;
			return false ;
		}

	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::createImportedPerson", standardError, 0) ;
	return false ;
}
}

void
NautilusPilot::addUnavailableAgent(string sAgentName, string error)
{
   pAvailableAgentList->push_back( new NSAgentStatus(sAgentName, error));
}
void
NautilusPilot::addUnavailableAgent(string sAgentName)
{
   pAvailableAgentList->push_back( new NSAgentStatus(sAgentName, ""));
}

//par default tag==agent
bool
NautilusPilot::resourceList(const char* serviceName, NSPersonsAttributesArray *pAgentList,
																															string tag)
//========================================================================================
{
	if (!serviceName || !pAgentList)
  	return false ;

try
{
	JNIEnv* jenv = JavaSystem::jenv;
	if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "resourceList",
      "(Ljava/lang/String;)Ldomlightwrapper/DOMElement;") ;
	if (mid == 0)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "resourceListNotFound") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jstring jServName = jenv->NewStringUTF( serviceName ) ;
	jobject jDOMElem = jenv->CallObjectMethod(jNautilusPilot, mid, jServName) ;
  jenv->DeleteLocalRef(jServName) ;
  if (jDOMElem == NULL)
  {
  	errorMessage = getTextError(jenv) ;
    jenv->DeleteLocalRef(jDOMElem) ;
    return false ;
	}

	// jstring jNodeName = jenv->NewStringUTF( "agent" );
  jstring jNodeName = jenv->NewStringUTF( tag.c_str() ) ;
  jobjectArray jDomElems = (jobjectArray)jenv->CallObjectMethod(jDOMElem, midChildrenElements, jNodeName) ;
  jenv->DeleteLocalRef(jNodeName) ;
  if (jDomElems == NULL)
  {
  	string ps = string("NautilusPilot::objectList : CallObjectMethod failed for midChildrenElements. exiting...") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    return true ;
	}
  int count = jenv->GetArrayLength(jDomElems) ;
  for (int i = 0 ; i < count ; i++)
	{
  	jobject jNodeElem = jenv->GetObjectArrayElement(jDomElems, i) ;
    if (jNodeElem != NULL)
    {
    	NSBasicAttributeArray* pAttributes = new NSBasicAttributeArray() ;
      DOMTreeToBasicAttribute(pAttributes, jNodeElem) ;
      jenv->DeleteLocalRef(jNodeElem) ;
      pAgentList->push_back(pAttributes) ;
    }
    else
    {
    	string ps = string("NautilusPilot::personList : GetObjectArrayElement failed.") ;
      pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    }
	}
	jenv->DeleteLocalRef(jDomElems) ;
	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::objectList", standardError, 0) ;
	return false ;
}
}

bool
NautilusPilot::setServiceList()
//==============================
{
  NSPersonsAttributesArray *pServiceList = new  NSPersonsAttributesArray();
	if(!resourceList(SERV_GET_NEEDED_AGENT_LIST.c_str(), pServiceList, "service"))
  	return false;

	if (pServiceList->empty())
  	return false;
    NSPersonsAttributeIter iter = pServiceList->begin() ;

    while (iter != pServiceList->end())
    {
        NSPilotService *pService ;
        string sServiceName = (*iter)->getAttributeValue("name");
        if (sServiceName != "")
        {
					pService = new NSPilotService(sServiceName) ;  
          //test sans valeur le nom est deja test�, mais.....
          if(!(*iter)->empty())
          {
            NSBasicAttributeIter iterProps = (*iter)->begin();
						for(iterProps; (iterProps != (*iter)->end()); iterProps++)
            	if( ((*iterProps)->getText() != "") &&
              		((*iter)->getAttributeValue("agent")) != "" )
              {
              	pService->getAgentList()->push_back(new string((*iterProps)->getText())) ;
              }
          } 
        }
        pPropertiesServicesList->push_back(pService) ;
        iter++ ;
    }
    return true;

}

bool
NautilusPilot::traitList(const char* serviceName, NSPersonsAttributesArray *pTraitList)
//====================================================================================
{
	if (!serviceName || !pTraitList)
  	return false ;

try
{
	JNIEnv* jenv = JavaSystem::jenv;
  if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "resourceList",
      "(Ljava/lang/String;)Ldomlightwrapper/DOMElement;");
	if (mid == 0)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "resourceListNotFound") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jstring jServName = jenv->NewStringUTF( serviceName );
  jobjectArray jDOMElems = (jobjectArray)jenv->CallObjectMethod(jNautilusPilot, mid, jServName);
  jenv->DeleteLocalRef(jServName) ;
  if (jDOMElems == NULL)
  {
  	errorMessage = getTextError(jenv) ;
    jenv->DeleteLocalRef(jDOMElems) ;
    return false ;
	}

  int count = jenv->GetArrayLength(jDOMElems) ;
  for (int i = 0 ; i < count ; i++)
  {
  	jobject jNodeElem = jenv->GetObjectArrayElement(jDOMElems, i) ;
    if (jNodeElem != NULL)
    {
    	NSBasicAttributeArray* pAttributes = new NSBasicAttributeArray() ;
      DOMTreeToBasicAttribute(pAttributes, jNodeElem) ;
      jenv->DeleteLocalRef(jNodeElem) ;
      pTraitList->push_back(pAttributes) ;
    }
    else
    {
    	string ps = string("NautilusPilot::personList : GetObjectArrayElement failed.") ;
      pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
    }
  }
  jenv->DeleteLocalRef(jDOMElems) ;
	return true ;
}
catch (...)
{
	erreur("Exception NautilusPilot::objectList", standardError, 0) ;
	return false ;
}
}

bool
NautilusPilot::runGarbageCollector()
//==================================
{
try
{
	JNIEnv* jenv = JavaSystem::jenv;
    if (jenv == NULL)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jstring jServName = jenv->NewStringUTF( "runGarbageCollector" );
	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "invokeServiceWithoutParams",
                                        "(Ljava/lang/String;)Z");
	if (mid == 0)
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "invokeServiceWithoutParams") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	jboolean jRes = (jboolean)jenv->CallObjectMethod(jNautilusPilot, mid, jServName) ;
  jenv->DeleteLocalRef(jServName) ;
  if (jenv->ExceptionOccurred() )
	{
		string sErrorText = getTextError(jenv) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		jenv->ExceptionDescribe() ;
		return false ;
	}

	return jRes ;
}
catch (...)
{
	erreur("Exception NautilusPilot::objectList", standardError, 0) ;
	return false ;
}
}


bool
NautilusPilot::fusionPatient(NSBasicAttributeArray *pAttrArray)
//=============================================================
{
try
{
	JNIEnv* jenv = JavaSystem::jenv;
    if (jenv == NULL)
	{
		errorMessage = pContexte->getSuperviseur()->getText("javaError", "NULLJVM") ;
		return false ;
	}

	jmethodID mid = jenv->GetMethodID(classNautilusPilot, "invokeSimpleServiceStringReturn",
                                        "(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;") ;
	if (mid == 0)
    {
  	    errorMessage = pContexte->getSuperviseur()->getText("NTIERS", "invokeSimpleServiceStringReturn") ;
		return false ;
	}

	jobjectArray strArray = createJObjectArray(pAttrArray) ;
    if (strArray == NULL)
	{
  	    string ps = string("NautilusPilot::createImportedPerson : createJObjectArray failed. Exiting...") ;
        pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
        return false ;
	}
    jstring jServName = jenv->NewStringUTF("fusionPatient") ;
	jstring jResult = (jstring)jenv->CallObjectMethod(jNautilusPilot, mid, jServName, strArray);
    jenv->DeleteLocalRef(strArray) ;
    jenv->DeleteLocalRef(jServName) ;
    if ((jenv->ExceptionOccurred() ) ||  (jResult == NULL))
	{
  	    errorMessage = getTextError(jenv) ;
		jenv->ExceptionDescribe() ;
		return false ;
    }

	char *result = JavaSystem::NewStringWithSpecialCharacters(jResult) ;
    jenv->DeleteLocalRef(jResult) ;
    if(result != NULL)
    {
        string res = string(result) ;
        if (res != "ok")
        {
        errorMessage = res ;
        return false ;
        }
    }
	return true ;
}
catch (...)
{
	errorMessage = "Exception NautilusPilot::objectList" ;
	return false ;
}
}


// -----------------------------------------------------------------------------
// class NSBasicAttributeArray
// -----------------------------------------------------------------------------
NSBasicAttributeArray::NSBasicAttributeArray(const NSBasicAttributeArray& rv)
	:	NSBasicAttributeVector()
{
try
{
	if (!(rv.empty()))
		for (NSBasicAttributeCIter i = rv.begin() ; i != rv.end() ; i++)
			push_back(new NSBasicAttribute(*(*i))) ;

	lObjectCount++ ;
}
catch (...)
{
	erreur("Exception NSBasicAttributeArray copy ctor", standardError, 0) ;
}
}


void
NSBasicAttributeArray::vider()
{
	if (empty())
		return ;
	for (NSBasicAttributeIter i = begin() ; i != end() ; )
	{
		delete *i ;
		erase(i) ;
	}
}


NSBasicAttributeArray::~NSBasicAttributeArray()
{
	vider() ;
	lObjectCount-- ;
}


NSBasicAttributeArray&
NSBasicAttributeArray::operator=(const NSBasicAttributeArray& src)
{
try
{
	if (this == &src)
  	return (*this) ;

	vider() ;
	if (!(src.empty()))
		for (NSBasicAttributeCIter i = src.begin() ; i != src.end() ; i++)
			push_back(new NSBasicAttribute(*(*i))) ;

	return (*this) ;
}
catch (...)
{
	erreur("Exception NSBasicAttributeArray = operator", standardError, 0) ;
	return (*this) ;
}
}


string
NSBasicAttributeArray::getAttributeValue(string sBalise)
{
	if (empty())
		return string("") ;

	NSBasicAttributeIter iter = begin();

	for(iter; ((iter != end())&& ((*iter)->getBalise() != sBalise)); iter++) ;
	if(iter != end())
		return (*iter)->getText();
	else
		return string("");
}

void
NSBasicAttributeArray::setAttributeValue(string sBalise, string sText)
{
try
{
	if (!(empty()))
	{
		NSBasicAttributeIter iter = begin();

		for(iter; ((iter != end())&& ((*iter)->getBalise() != sBalise)); iter++) ;
		if(iter != end())
		{
			(*iter)->setText(sText) ;
			return ;
		}
	}

	push_back(new NSBasicAttribute(sBalise, sText)) ;
}
catch (...)
{
	erreur("Exception NSBasicAttributeArray::setAttributeValue", standardError, 0) ;
}
}

void
NSBasicAttributeArray::changeAttributeValue(string sBalise, string sText)
{
try
{
	if (!(empty()))
	{
		NSBasicAttributeIter iter = begin() ;

		for	(iter; ((iter != end())&& ((*iter)->getBalise() != sBalise)); iter++) ;
		if (iter != end())
		{
    	// si la balise a �t� modifi�e, on la conserve
      // sinon on la supprime
      if ((*iter)->getText() == sText)
      {
      	delete (*iter) ;
        erase(iter) ;
      }
      else
      	(*iter)->setText(sText) ;
			return ;
		}
	}

    // si la balise n'existait pas, on la rajoute
	push_back(new NSBasicAttribute(sBalise, sText)) ;
}
catch (...)
{
	erreur("Exception NSBasicAttributeArray::setAttributeValue", standardError, 0) ;
}
}

void
NSBasicAttributeArray::eraseAttributeValue(string sBalise)
{
	if (empty())
		return ;

	NSBasicAttributeIter iter = begin() ;
	for	(iter; ((iter != end())&& ((*iter)->getBalise() != sBalise)); iter++) ;
	if (iter != end())
	{
  	delete (*iter) ;
  	erase(iter) ;
	}
}

//----------------------- class NSPersonsAttributesArray ---------------------

NSPersonsAttributesArray::NSPersonsAttributesArray(NSPersonsAttributesArray& rv)
                : NSBasicAttributeArrayVector()
{
try
{
	if (!(rv.empty()))
		for (NSPersonsAttributeIter i = rv.begin(); i != rv.end(); i++)
			push_back(new NSBasicAttributeArray(*(*i))) ;

	lObjectCount++ ;
}
catch (...)
{
	erreur("Exception NSPersonsAttributesArray copy ctor", standardError, 0) ;
}
}

string
NSPersonsAttributesArray::getAttributeValue(string sBalise)
{
	if (empty())
		return string("") ;

	string sResult = "" ;
	for (NSPersonsAttributeIter i = begin(); (i != end()) && (sResult == ""); i++)
		sResult = (*i)->getAttributeValue(sBalise) ;

	return sResult ;
}

void
NSPersonsAttributesArray::vider()
{
	if (empty())
		return ;
	for (NSPersonsAttributeIter i = begin(); i != end(); )
	{
		delete *i ;
		erase(i) ;
	}
}

NSPersonsAttributesArray::~NSPersonsAttributesArray()
{
	vider() ;

	lObjectCount-- ;
}

NSPersonsAttributesArray&
NSPersonsAttributesArray::operator=(NSPersonsAttributesArray src)
{
try
{
	vider() ;
	if (!(src.empty()))
		for (NSPersonsAttributeIter i = src.begin(); i != src.end(); i++)
			push_back(new NSBasicAttributeArray(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception NSPersonsAttributesArray = operator", standardError, 0) ;
	return *this ;
}
}

//----------------------------- class NSAgentStatus ----------------------------
NSAgentStatus::NSAgentStatus()
{
	sAgent 			 = "" ;
  sError  		 = "" ;
  sProperties  = "" ;
  status 			 = NSAgentStatus::active ;
  pServiceList = new VecteurString() ;
}
NSAgentStatus::NSAgentStatus(string sAgentName, string sErr )
{
	sAgent 			 = sAgentName ;
	sError  		 = sErr ;
	sProperties  = "" ;
	status 			 = NSAgentStatus::active ;
	pServiceList = new VecteurString() ;
}

NSAgentStatus::~NSAgentStatus()
{
	if (pServiceList != NULL)
  	delete pServiceList ;
}

bool
NSAgentStatus::isServiceInAgentList(string	sServiceName)
{
  if (pServiceList->empty())
    return false ;

  EquiItemIter iterStr = pServiceList->begin() ;
  for (iterStr ; ((iterStr!= pServiceList->end()) && ((**iterStr)!= sServiceName)) ; iterStr++) ;
	if (iterStr != pServiceList->end())
  	return true ;
    
  return false ;
}

bool
NSAgentStatus::isLdvTypeAgent()
{
	if (strstr(sProperties.c_str(), LDV_AGENT_TEXT) != NULL)
   	return true ;
  return false ;
}

bool
NSAgentStatus::isLocalTypeAgent()
{
  if ((sProperties == LOCAL_AGENT) ||
  		(sProperties == DIRECT_GROUP_AGENT) ||
      (sProperties == DIRECT_COLLECTIVE))
		return true ;

  return false ;
}

bool
NSAgentStatus::isUnknownTypeAgent()
{
  if(	(!isLocalTypeAgent()) ||
      (!isLdvTypeAgent()) )
  	return true ;

  return false ;
}

int
NSAgentStatus::getAgentType()
{
	if (isLocalTypeAgent())
  	return local ;
  if (isLdvTypeAgent())
  	return LdV ;
  return unknown ;
}

//------------------------- class NSAgentStatusArray --------------------------

void
NSAgentStatusArray::vider()
{
	if (empty())
		return ;
	for (NSAgentStatusIter i = begin(); i != end(); )
	{
		delete *i ;
		erase(i) ;
	}
}

NSAgentStatusArray::~NSAgentStatusArray()
{
	vider() ;
}
bool
NSAgentStatusArray::isAvailableService(string sServiceName)
{
	if (empty())
		return true ;

	for (NSAgentStatusIter iterAgent = begin(); iterAgent != end(); iterAgent++)
	{
  	if (!(*iterAgent)->getServiceList()->empty ())
    {
    	EquiItemIter iterStr = (*iterAgent)->getServiceList()->begin() ;
      for (iterStr ; ((iterStr != (*iterAgent)->getServiceList()->end()) && ((**iterStr)!= sServiceName)) ; iterStr++) ;
      if (iterStr != (*iterAgent)->getServiceList()->end())
      	return false ;
    }
	}
	return true ;
}

string
NSAgentStatusArray::getAgentError(string sAgentName)
{
	if (empty())
		return "" ;
  NSAgentStatusIter iterAgent = begin() ;
	for (iterAgent; ((iterAgent != end()) && ((*iterAgent)->getAgentName() != sAgentName)); iterAgent++) ;
    if (iterAgent != end())
        return (*iterAgent)->getError() ;

	return "" ;
}

bool
NSAgentStatusArray::setAgentError(string sAgentName, string sErr)
{
	if (empty())
		return false ;
    
  NSAgentStatusIter iterAgent = begin() ;
	for (iterAgent; ((iterAgent != end()) && ((*iterAgent)->getAgentName() != sAgentName)); iterAgent++) ;
  if (iterAgent != end())
  {
  	(*iterAgent)->setError(sErr) ;
    (*iterAgent)->setInactive() ;
    return true ;
  }

  return false ;
}

NSAgentStatus*
NSAgentStatusArray::selectAgent(string sAgentName)
{
	if (empty())
		return NULL ;

  NSAgentStatusIter iterAgent = begin() ;
	for (iterAgent; ((iterAgent != end()) && ((*iterAgent)->getAgentName() != sAgentName)); iterAgent++) ;
    if (iterAgent != end())
        return (*iterAgent) ;

	return NULL ;
}

void
NSAgentStatusArray::addAgent(string sAgentName, string sErr, VecteurString *pVect)
{
	NSAgentStatus *pNewAgent = new NSAgentStatus(sAgentName, sErr) ;
  pNewAgent->setServiceList(pVect) ;
  push_back(pNewAgent) ;
}

void
NSAgentStatusArray::addAgent(string sAgentName, string sErr)
{
	push_back(new NSAgentStatus(sAgentName, sErr)) ;
}

bool
NSAgentStatusArray::addUnavailableServiceForAgent(string sAgent, string sServiceName)
{
	if (empty())
	{
  	VecteurString *pServList = new VecteurString() ;
    pServList->push_back(&sServiceName) ;
    addAgent(sAgent, "", pServList) ;
    return true ;
	}
  NSAgentStatusIter iterAgent = begin() ;
	for (iterAgent; ((iterAgent != end()) && ((*iterAgent)->getAgentName() != sAgent)); iterAgent++) ;
  if (iterAgent != end())
  {
  	(*iterAgent)->addService(sServiceName) ; 
    return true ;
	}
	return false ;
}

void
NSAgentStatusArray::deleteAgent(string sAgentName)
{
	if (empty())
		return ;
	for (NSAgentStatusIter iter = begin(); iter != end(); iter++)
	{
  	if((*iter)->getAgentName() == sAgentName)
		{
    	delete *iter ;
      erase(iter) ;
      return ;
    }
	}
}

//*****************************services management*****************************

NSPilotService::NSPilotService()
{
	sServiceName = "" ;
  pAgentList = new VecteurString() ;
}

NSPilotService::NSPilotService(string sServ)
{
	sServiceName = sServ ;
  pAgentList = new VecteurString() ;
}

NSPilotService::~NSPilotService()
{
	if (pAgentList!= NULL)
  	delete pAgentList ;
}

bool
NSPilotService::isAgentNeededInService(string	sAgentName)
{
  if (pAgentList->empty())
    return false ;

  EquiItemIter iterStr ;
  for (iterStr= pAgentList->begin(); ((iterStr != pAgentList->end())&&((**iterStr)!= sAgentName)) ; iterStr++) ;
	if (iterStr != pAgentList->end())
  	return true ;
  return false ;
}

//------------------------- class NSServiceStatusArray --------------------------

void
NSServiceStatusArray::vider()
{
	if (empty())
		return ;
	for (NSPilotServiceStatusIter i = begin(); i != end(); )
	{
		delete *i ;
		erase(i) ;
	}
}

NSServiceStatusArray::~NSServiceStatusArray()
{
	vider() ;
}

VecteurString*
NSServiceStatusArray::getAgentListForService(string sName)
{
	if (empty())
  	return NULL ;

  NSPilotServiceStatusIter iter ;
  for ( iter = begin(); ((iter != end())&&((*iter)->getServiceName() != sName)); iter++ ) ;
  if (iter != end())
  	return (*iter)->getAgentList() ;

  return NULL ;
}

