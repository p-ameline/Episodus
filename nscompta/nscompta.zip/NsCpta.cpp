//---------------------------------------------------------------------------//    NSCPTA.CPP
//    KRZISCH PH.   janvier 92
//  Impl�mentation de objets NAUTILUS
//---------------------------------------------------------------------------
#include <utility.h>
#include <mem.h>
#include <string.h>
#include <cstring.h>

//using namespace std;

#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "nscompta\nscpta.h"
#include "nscompta\nsfseuti.h"

//***************************************************************************
// Impl�mentation des m�thodes NSCompt
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSComptData::NSComptData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero() ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSComptData::NSComptData(NSComptData& rv)
{
	strcpy(numcompt,    rv.numcompt) ;
	strcpy(numfse, 	    rv.numfse) ;
	strcpy(patient,     rv.patient) ;
	strcpy(date,        rv.date) ;
	strcpy(heure, 	    rv.heure) ;
	strcpy(duFranc,     rv.duFranc) ;
	strcpy(payeFranc,   rv.payeFranc) ;
	strcpy(depassFranc, rv.depassFranc) ;
	strcpy(duEuro, 	    rv.duEuro) ;
	strcpy(payeEuro,    rv.payeEuro) ;
	strcpy(depassEuro,  rv.depassEuro) ;
	strcpy(examen, 	    rv.examen) ;
	strcpy(synonyme,    rv.synonyme) ;
	strcpy(okPaye, 	    rv.okPaye) ;
	strcpy(prescript,   rv.prescript) ;
	strcpy(contexte,    rv.contexte) ;
	strcpy(code,        rv.code) ;
	strcpy(operateur,   rv.operateur) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSComptData::~NSComptData()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSComptData&
NSComptData::operator=(NSComptData src)
{
	if (this == &src)
		return *this ;

	strcpy(numcompt,    src.numcompt) ;
	strcpy(numfse, 	    src.numfse) ;
	strcpy(patient,     src.patient) ;
	strcpy(date,        src.date) ;
	strcpy(heure, 	    src.heure) ;
	strcpy(duFranc,     src.duFranc) ;
	strcpy(payeFranc,   src.payeFranc) ;
	strcpy(depassFranc, src.depassFranc) ;
	strcpy(duEuro, 	    src.duEuro) ;
	strcpy(payeEuro,    src.payeEuro) ;
	strcpy(depassEuro,  src.depassEuro) ;
	strcpy(examen, 	    src.examen) ;
	strcpy(synonyme,    src.synonyme) ;
	strcpy(okPaye, 	    src.okPaye) ;
	strcpy(prescript,   src.prescript) ;
	strcpy(contexte,    src.contexte) ;
	strcpy(code,        src.code) ;
	strcpy(operateur,   src.operateur) ;

	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSComptData::operator == ( const NSComptData& o )
{
	if ((strcmp(numcompt, o.numcompt) == 0))
		return 1 ;
	else
		return 0 ;
}

//---------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSComptData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(numcompt,	  0, CPTA_NUMCOMPT_LEN + 1) ;
	memset(numfse, 	    0, CPTA_NUMFSE_LEN + 1) ;
	memset(patient, 	  0, CPTA_PATIENT_LEN + 1) ;
	memset(date, 	 	    0, CPTA_DATE_LEN + 1) ;
	memset(heure, 	 	  0, CPTA_HEURE_LEN + 1) ;
	memset(duFranc, 	  0, CPTA_DUE_F_LEN + 1) ;
	memset(payeFranc,   0, CPTA_PAYE_F_LEN + 1) ;
	memset(depassFranc, 0, CPTA_DEPAS_F_LEN + 1) ;
	memset(duEuro, 	    0, CPTA_DUE_E_LEN + 1) ;
	memset(payeEuro, 	  0, CPTA_PAYE_E_LEN + 1) ;
	memset(depassEuro,  0, CPTA_DEPAS_E_LEN + 1) ;
	memset(examen, 	    0, CPTA_EXAMEN_LEN + 1) ;
	memset(synonyme,	  0, CPTA_SYNONYME_LEN + 1) ;
	memset(okPaye, 	    0, CPTA_OKPAYE_LEN + 1) ;	memset(prescript,   0, CPTA_PRESCRIPT_LEN + 1) ;
	memset(contexte, 	  0, CPTA_CONTEXTE_LEN + 1) ;
	memset(code, 	 	    0, CPTA_CODE_LEN + 1) ;
	memset(operateur,   0, CPTA_OPERATEUR_LEN + 1) ;
}

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSCompt::NSCompt(NSContexte* pCtx) : NSFiche(pCtx)
{
	//
	// Cr�e un objet de donn�es
	//
	pDonnees = new NSComptData() ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCompt::NSCompt(NSCompt& rv) : NSFiche(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//	pDonnees = new NSComptData() ;
	//
	// Copie les valeurs du NSTransaction d'origine
	//
	*pDonnees = *(rv.pDonnees) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCompt::~NSCompt()
{
	delete pDonnees ;
}

//---------------------------------------------------------------------------
//  Fonction :  	NSCompt::alimenteFiche()
//
//  Description : Transf�re le contenu de pRecBuff dans les variables de
//             	la fiche
//---------------------------------------------------------------------------
void
NSCompt::alimenteFiche()
{
	alimenteChamp(pDonnees->numcompt, 	 CPTA_NUMCOMPT_FIELD,  CPTA_NUMCOMPT_LEN) ;
	alimenteChamp(pDonnees->numfse, 	   CPTA_NUMFSE_FIELD, 	 CPTA_NUMFSE_LEN) ;
	alimenteChamp(pDonnees->patient, 	   CPTA_PATIENT_FIELD,   CPTA_PATIENT_LEN) ;
	alimenteChamp(pDonnees->date, 	 	   CPTA_DATE_FIELD, 	   CPTA_DATE_LEN) ;
	alimenteChamp(pDonnees->heure, 	 	   CPTA_HEURE_FIELD, 	   CPTA_HEURE_LEN) ;
	alimenteChamp(pDonnees->duFranc, 	   CPTA_DUE_F_FIELD, 	   CPTA_DUE_F_LEN) ;
	alimenteChamp(pDonnees->payeFranc,   CPTA_PAYE_F_FIELD, 	 CPTA_PAYE_F_LEN) ;
	alimenteChamp(pDonnees->depassFranc, CPTA_DEPAS_F_FIELD,   CPTA_DEPAS_F_LEN) ;
	alimenteChamp(pDonnees->duEuro, 	   CPTA_DUE_E_FIELD, 	   CPTA_DUE_E_LEN) ;
	alimenteChamp(pDonnees->payeEuro, 	 CPTA_PAYE_E_FIELD, 	 CPTA_PAYE_E_LEN) ;
	alimenteChamp(pDonnees->depassEuro,  CPTA_DEPAS_E_FIELD,   CPTA_DEPAS_E_LEN) ;
	alimenteChamp(pDonnees->examen, 	   CPTA_EXAMEN_FIELD, 	 CPTA_EXAMEN_LEN) ;
	alimenteChamp(pDonnees->synonyme,	   CPTA_SYNONYME_FIELD,  CPTA_SYNONYME_LEN) ;
	alimenteChamp(pDonnees->okPaye, 	   CPTA_OKPAYE_FIELD, 	 CPTA_OKPAYE_LEN) ;
	alimenteChamp(pDonnees->prescript,   CPTA_PRESCRIPT_FIELD, CPTA_PRESCRIPT_LEN) ;
	alimenteChamp(pDonnees->contexte, 	 CPTA_CONTEXTE_FIELD,  CPTA_CONTEXTE_LEN) ;
	alimenteChamp(pDonnees->code, 	 	   CPTA_CODE_FIELD, 	   CPTA_CODE_LEN) ;
	alimenteChamp(pDonnees->operateur,   CPTA_OPERATEUR_FIELD, CPTA_OPERATEUR_LEN) ;
}

//---------------------------------------------------------------------------
//  Fonction :   	NSCompt::videFiche()
//
//  Description : Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSCompt::videFiche()
{
	videChamp(pDonnees->numcompt, 	 CPTA_NUMCOMPT_FIELD,  CPTA_NUMCOMPT_LEN) ;
	videChamp(pDonnees->numfse, 	   CPTA_NUMFSE_FIELD, 	 CPTA_NUMFSE_LEN) ;
	videChamp(pDonnees->patient, 	 	 CPTA_PATIENT_FIELD,   CPTA_PATIENT_LEN) ;
	videChamp(pDonnees->date, 	 	 	 CPTA_DATE_FIELD, 	   CPTA_DATE_LEN) ;
	videChamp(pDonnees->heure, 	 	   CPTA_HEURE_FIELD, 	   CPTA_HEURE_LEN) ;
	videChamp(pDonnees->duFranc, 	 	 CPTA_DUE_F_FIELD, 	   CPTA_DUE_F_LEN) ;
	videChamp(pDonnees->payeFranc,   CPTA_PAYE_F_FIELD, 	 CPTA_PAYE_F_LEN) ;
	videChamp(pDonnees->depassFranc, CPTA_DEPAS_F_FIELD,   CPTA_DEPAS_F_LEN) ;
	videChamp(pDonnees->duEuro, 	   CPTA_DUE_E_FIELD, 	   CPTA_DUE_E_LEN) ;
	videChamp(pDonnees->payeEuro, 	 CPTA_PAYE_E_FIELD, 	 CPTA_PAYE_E_LEN) ;
	videChamp(pDonnees->depassEuro,  CPTA_DEPAS_E_FIELD,   CPTA_DEPAS_E_LEN) ;
	videChamp(pDonnees->examen, 	   CPTA_EXAMEN_FIELD, 	 CPTA_EXAMEN_LEN) ;
	videChamp(pDonnees->synonyme,	 	 CPTA_SYNONYME_FIELD,  CPTA_SYNONYME_LEN) ;
	videChamp(pDonnees->okPaye, 	   CPTA_OKPAYE_FIELD, 	 CPTA_OKPAYE_LEN) ;
	videChamp(pDonnees->prescript,   CPTA_PRESCRIPT_FIELD, CPTA_PRESCRIPT_LEN) ;
	videChamp(pDonnees->contexte, 	 CPTA_CONTEXTE_FIELD,  CPTA_CONTEXTE_LEN) ;
	videChamp(pDonnees->code, 	 	 	 CPTA_CODE_FIELD, 	   CPTA_CODE_LEN) ;
	videChamp(pDonnees->operateur,   CPTA_OPERATEUR_FIELD, CPTA_OPERATEUR_LEN) ;
}

//---------------------------------------------------------------------------
//  Fonction :  	NSCompt::getRecord()
//
//  Description : Prend l'enregistrement en cours et assigne la valeur des
//             	champs aux variables membres de la classe.
//
//  Returns:   	PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSCompt::getPatRecord()
{
	//
	// La table est-elle ouverte ?
	//
	if (!isOpen)
	  return(lastError = ERROR_TABLENOTOPEN) ;
	//
	// Appel de la classe de base pour r�cup�rer l'enregistrement.
	//
	lastError = getDbiRecord(dbiWRITELOCK) ;

	return(lastError) ;
}

//---------------------------------------------------------------------------
//  Fonction :  	NSCompt::open()
//
//  Description :	Ouvre la table primaire et les index secondaires
//
//  Returns :		PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSCompt::open()
{
	char tableName[] = "NSM_COMPT.DB" ;
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_COMPTA) ;
	return(lastError) ;
}

//---------------------------------------------------------------------------//  Function:  NSCompt::Create()
//---------------------------------------------------------------------------
bool
NSCompt::Create()
{
	return true ;
}

//---------------------------------------------------------------------------//  Function:  NSCompt::Modify()
//---------------------------------------------------------------------------
bool
NSCompt::Modify()
{
	return true ;
}

//---------------------------------------------------------------------------//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSCompt&
NSCompt::operator=(NSCompt src)
{
	if (this == &src)
		return *this ;

	*pDonnees = *(src.pDonnees) ;

	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCompt::operator == (const NSCompt& o)
{
	return (*pDonnees == *(o.pDonnees)) ;
}

//---------------------------------------------------------------------------//  Fonction:		NSComptInfo::NSComptInfo()
//
//  Description:	Constructeur par d�faut
//---------------------------------------------------------------------------
NSComptInfo::NSComptInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSComptData() ;
}

//---------------------------------------------------------------------------//  Fonction:		NSComptInfo::NSComptInfo(NSCompt*)
//
//  Description:	Constructeur � partir d'un NSTransaction
//---------------------------------------------------------------------------
NSComptInfo::NSComptInfo(NSCompt* pTransac)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSComptData() ;
	//
	// Copie les valeurs du NSCompt
	//
	*pDonnees = *(pTransac->pDonnees) ;
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSComptInfo::NSComptInfo(NSComptInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSComptData() ;
	//
	// Copie les valeurs du NSComptInfo d'origine
	//
	*pDonnees = *(rv.pDonnees) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSComptInfo::~NSComptInfo()
{
	delete pDonnees ;
}

bool
NSComptInfo::InitFse1610Array(NSFse16Array* pFseArray, int* pCounter, NSContexte* pContexte)
{
	string    sNumCompt   = string(pDonnees->numcompt) ;
	string		sNumFse1610 = sNumCompt + string("    ") ;
	NSFse1610 Fse1610(pContexte) ;

  Fse1610.lastError = Fse1610.open() ;
  if (Fse1610.lastError != DBIERR_NONE)
  {
  	erreur("Erreur � l'ouverture de la base Fse1610.", standardError, Fse1610.lastError) ;
    return false ;
  }

  Fse1610.lastError = Fse1610.chercheClef(&sNumFse1610,
      														        "",
                                          0,
																          keySEARCHGEQ,
                                          dbiWRITELOCK) ;

	if (Fse1610.lastError == DBIERR_BOF)	// cas fichier vide
  {
   	Fse1610.close() ;
    return true ;		// le tableau est vide
  }

  if ((Fse1610.lastError != DBIERR_NONE) && (Fse1610.lastError != DBIERR_EOF))
  {
   	erreur("Erreur � la recherche d'une fiche Fse1610.", standardError, Fse1610.lastError) ;
    Fse1610.close() ;
    return false ;
  }

  while (Fse1610.lastError != DBIERR_EOF)  {
  	Fse1610.lastError = Fse1610.getRecord() ;
    if (Fse1610.lastError != DBIERR_NONE)
    {
    	erreur("Erreur � la lecture d'une fiche Fse1610.", standardError, Fse1610.lastError) ;
      Fse1610.close() ;
      return false ;
    }

    // condition d'arret
    if (!(string(Fse1610.pDonnees->numcompt) == sNumCompt))
    	break ;

    // on remplit le tableau
    pFseArray->push_back(new NSBlocFse16(&Fse1610)) ;
    if (NULL != pCounter)
    	(*pCounter)++ ;

    // ... on passe au composant suivant
    Fse1610.lastError = Fse1610.suivant(dbiWRITELOCK) ;
    if ((Fse1610.lastError != DBIERR_NONE) && (Fse1610.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche Fse1610.", standardError, Fse1610.lastError) ;
      Fse1610.close() ;
      return false ;
    }
  } // fin du while

  // on ferme la base Fse1610
  Fse1610.lastError = Fse1610.close() ;
  if (Fse1610.lastError != DBIERR_NONE)
  {
  	erreur("Erreur de fermeture du fichier Fse1610.", standardError, Fse1610.lastError) ;
    return false ;
  }

	return true ;
}

bool
NSComptInfo::InitFse1620Array(NSFse16Array* pFseArray, int* pCounter, NSContexte* pContexte)
{
	string    sNumCompt   = string(pDonnees->numcompt) ;
	string 		sNumFse1620 = sNumCompt + string("    ") ;
	NSFse1620 Fse1620(pContexte) ;

	Fse1620.lastError = Fse1620.open() ;
	if (Fse1620.lastError != DBIERR_NONE)
	{
   	erreur("Erreur � l'ouverture de la base Fse1620.", standardError, Fse1620.lastError) ;
		return false ;
	}

	Fse1620.lastError = Fse1620.chercheClef(&sNumFse1620,
                                          "",
                                          0,
                                          keySEARCHGEQ,
                                          dbiWRITELOCK) ;

	if (Fse1620.lastError == DBIERR_BOF)	// cas fichier vide
	{
  	Fse1620.close() ;
		return true ;		// le tableau est vide
	}

	if ((Fse1620.lastError != DBIERR_NONE) && (Fse1620.lastError != DBIERR_EOF))
	{
		erreur("Erreur � la recherche d'une fiche Fse1620.", standardError, Fse1620.lastError) ;
		Fse1620.close() ;
		return false ;
	}

	while (Fse1620.lastError != DBIERR_EOF)
	{
		Fse1620.lastError = Fse1620.getRecord() ;
		if (Fse1620.lastError != DBIERR_NONE)
		{
    	erreur("Erreur � la lecture d'une fiche Fse1620.", standardError, Fse1620.lastError) ;
      Fse1620.close() ;
      return false ;
    }

    // condition d'arret
    if (!(string(Fse1620.pDonnees->numcompt) == sNumCompt))
    	break;

    // on remplit le tableau
    pFseArray->push_back(new NSBlocFse16(&Fse1620)) ;
    if (NULL != pCounter)
    	(*pCounter)++ ;

    // ... on passe au composant suivant
    Fse1620.lastError = Fse1620.suivant(dbiWRITELOCK) ;
    if ((Fse1620.lastError != DBIERR_NONE) && (Fse1620.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche Fse1620.", standardError, Fse1620.lastError) ;
      Fse1620.close() ;
			return false ;
    }
	} // fin du while (recherche des composants images)

	// on ferme la base Fse1620
	Fse1620.lastError = Fse1620.close() ;
	if (Fse1620.lastError != DBIERR_NONE)
	{
   	erreur("Erreur de fermeture du fichier Fse1620.", standardError, Fse1620.lastError) ;
    return false ;
	}

	return true ;
}

bool
NSComptInfo::InitFse1630Array(NSFse16Array* pFseArray, int* pCounter, NSContexte* pContexte)
{
	string    sNumCompt   = string(pDonnees->numcompt) ;
	string 		sNumFse1630 = sNumCompt + string("    ") ;
	NSFse1630 Fse1630(pContexte) ;

	Fse1630.lastError = Fse1630.open() ;
	if (Fse1630.lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture de la base Fse1630.", standardError, Fse1630.lastError) ;
    return false ;
	}

	Fse1630.lastError = Fse1630.chercheClef(&sNumFse1630,
                                          "",
                                          0,
                                          keySEARCHGEQ,
                                          dbiWRITELOCK) ;

	if (Fse1630.lastError == DBIERR_BOF)	// cas fichier vide
	{
		Fse1630.close() ;
		return true ;		// le tableau est vide
	}

	if ((Fse1630.lastError != DBIERR_NONE) && (Fse1630.lastError != DBIERR_EOF))
	{
		erreur("Erreur � la recherche d'une fiche Fse1630.", standardError, Fse1630.lastError) ;
		Fse1630.close() ;
		return false ;
	}

	while (Fse1630.lastError != DBIERR_EOF)
	{
		Fse1630.lastError = Fse1630.getRecord() ;
		if (Fse1630.lastError != DBIERR_NONE)
		{
    	erreur("Erreur � la lecture d'une fiche Fse1630.", standardError, Fse1630.lastError) ;
    	Fse1630.close() ;
      return false ;
    }

    // condition d'arret
    if (!(string(Fse1630.pDonnees->numcompt) == sNumCompt))
    	break ;

    // on remplit le tableau
    pFseArray->push_back(new NSBlocFse16(&Fse1630)) ;
    if (NULL != pCounter)
    	(*pCounter)++ ;

    // ... on passe au composant suivant    Fse1630.lastError = Fse1630.suivant(dbiWRITELOCK) ;
    if ((Fse1630.lastError != DBIERR_NONE) && (Fse1630.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche Fse1630.", standardError, Fse1630.lastError) ;
      Fse1630.close() ;
      return false ;
    }
  } // fin du while (recherche des composants images)

	// on ferme la base Fse1630
	Fse1630.lastError = Fse1630.close() ;
	if (Fse1630.lastError != DBIERR_NONE)
	{
		erreur("Erreur de fermeture du fichier Fse1630.", standardError, Fse1630.lastError) ;
    return false ;
	}

	return true ;
}

bool
NSComptInfo::InitCCAMArray(NSFse16Array* pFseArray, int* pCounter, NSContexte* pContexte)
{
	string    sNumCompt = string(pDonnees->numcompt) ;
	string		sNumCCAM  = sNumCompt ;
	NSFseCCAM FseCCAM(pContexte) ;

  FseCCAM.lastError = FseCCAM.open() ;
  if (FseCCAM.lastError != DBIERR_NONE)
  {
  	erreur("Erreur � l'ouverture de la base FseCCAM.", standardError, FseCCAM.lastError) ;
    return false ;
  }

  FseCCAM.lastError = FseCCAM.chercheClef(&sNumCCAM,
      														        "",
                                          0,
																          keySEARCHGEQ,
                                          dbiWRITELOCK) ;

	if (FseCCAM.lastError == DBIERR_BOF)	// cas fichier vide
  {
   	FseCCAM.close() ;
    return true ;		// le tableau est vide
  }

  if ((FseCCAM.lastError != DBIERR_NONE) && (FseCCAM.lastError != DBIERR_EOF))
  {
   	erreur("Erreur � la recherche d'une fiche FseCCAM.", standardError, FseCCAM.lastError) ;
    FseCCAM.close() ;
    return false ;
  }

  while (FseCCAM.lastError != DBIERR_EOF)  {
  	FseCCAM.lastError = FseCCAM.getRecord() ;
    if (FseCCAM.lastError != DBIERR_NONE)
    {
    	erreur("Erreur � la lecture d'une fiche FseCCAM.", standardError, FseCCAM.lastError) ;
      FseCCAM.close() ;
      return false ;
    }

    // condition d'arret
    if (!(string(FseCCAM.pDonnees->numcompt) == sNumCompt))
    	break ;

    // on remplit le tableau
    pFseArray->push_back(new NSBlocFse16(&FseCCAM)) ;
    if (NULL != pCounter)
    	(*pCounter)++ ;

    // ... on passe au composant suivant
    FseCCAM.lastError = FseCCAM.suivant(dbiWRITELOCK) ;
    if ((FseCCAM.lastError != DBIERR_NONE) && (FseCCAM.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche FseCCAM.", standardError, FseCCAM.lastError) ;
      FseCCAM.close() ;
      return false ;
    }
  } // fin du while

  // on ferme la base Fse1610
  FseCCAM.lastError = FseCCAM.close() ;
  if (FseCCAM.lastError != DBIERR_NONE)
  {
  	erreur("Erreur de fermeture du fichier FseCCAM.", standardError, FseCCAM.lastError) ;
    return false ;
  }

	return true ;
}

//---------------------------------------------------------------------------//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSComptInfo&
NSComptInfo::operator=(NSComptInfo src)
{
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSComptInfo::operator == (const NSComptInfo& o)
{
	return (*pDonnees == *(o.pDonnees)) ;
}

//***************************************************************************// 					Impl�mentation des m�thodes NSComptArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSComptArray::NSComptArray(NSComptArray& rv) : NSFicheComptArray()
{
	if (!rv.empty())
		for (NSComptIter i = rv.begin() ; i != rv.end() ; i++)
   		push_back(new NSComptInfo(*(*i))) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSComptArray::vider()
{
	if (empty())
		return ;

	for (NSComptIter i = begin(); i != end(); )
	{
		delete *i ;
		erase(i) ;
	}
}

NSComptArray::~NSComptArray(){
	vider() ;
}

//***************************************************************************// Impl�mentation des m�thodes NSFact
//***************************************************************************

//---------------------------------------------------------------------------//  Constructeur
//---------------------------------------------------------------------------
NSFactData::NSFactData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero();
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSFactData::NSFactData(NSFactData& rv)
{
	strcpy(numcompt,  rv.numcompt) ;
	strcpy(numero,    rv.numero) ;
	strcpy(operateur, rv.operateur) ;
	strcpy(date_paie, rv.date_paie) ;
	strcpy(organisme, rv.organisme) ;
	strcpy(libelle,   rv.libelle) ;
	strcpy(montant,   rv.montant) ;
	strcpy(unite,     rv.unite) ;
	strcpy(mode_paie, rv.mode_paie) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSFactData::~NSFactData()
{
}

//---------------------------------------------------------------------------//  Op�rateur =
//---------------------------------------------------------------------------
NSFactData&
NSFactData::operator=(NSFactData src)
{
	strcpy(numcompt, 	  	src.numcompt);
   strcpy(numero,			src.numero);
	strcpy(operateur, 	src.operateur);
	strcpy(date_paie,   	src.date_paie);
   strcpy(organisme,		src.organisme);
   strcpy(libelle,		src.libelle);
	strcpy(montant,  		src.montant);
	strcpy(unite, 			src.unite);
   strcpy(mode_paie,		src.mode_paie);

	return *this;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFactData::operator == ( const NSFactData& o )
{
	if ((strcmp(numcompt, o.numcompt) == 0) &&
   	 (strcmp(numero, o.numero) == 0))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSFactData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(numcompt, 	0, FACT_NUMCOMPT_LEN + 1);
  memset(numero,		0, FACT_NUMERO_LEN + 1);
	memset(operateur, 0, FACT_OPERATEUR_LEN + 1);
	memset(date_paie, 0, FACT_DATE_PAIE_LEN + 1);
	memset(organisme,	0, FACT_ORGANISME_LEN + 1);
  memset(libelle,	  0, FACT_LIBELLE_LEN + 1);
	memset(montant,  	0, FACT_MONTANT_LEN + 1);
	memset(unite, 		0, FACT_UNITE_LEN + 1);
  memset(mode_paie, 0, FACT_MODE_PAIE_LEN + 1);
}

//---------------------------------------------------------------------------//  Constructeur
//---------------------------------------------------------------------------
NSFact::NSFact(NSContexte* pCtx) : NSFiche(pCtx)
{
	//
	// Cr�e un objet de donn�es
	//
	pDonnees = new NSFactData();
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSFact::NSFact(NSFact& rv) : NSFiche(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFactData();
	//
	// Copie les valeurs du NSTransaction d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSFact::~NSFact()
{
	delete pDonnees ;
}


//---------------------------------------------------------------------------
//  Fonction :  	NSFact::alimenteFiche()
//
//  Description : Transf�re le contenu de pRecBuff dans les variables de
//             	la fiche
//---------------------------------------------------------------------------
void
NSFact::alimenteFiche()
{
	alimenteChamp(pDonnees->numcompt,	FACT_NUMCOMPT_FIELD,		FACT_NUMCOMPT_LEN);
   alimenteChamp(pDonnees->numero,		FACT_NUMERO_FIELD,		FACT_NUMERO_LEN);
   alimenteChamp(pDonnees->operateur, 	FACT_OPERATEUR_FIELD, 	FACT_OPERATEUR_LEN);
   alimenteChamp(pDonnees->date_paie, 	FACT_DATE_PAIE_FIELD,	FACT_DATE_PAIE_LEN);
   alimenteChamp(pDonnees->organisme,	FACT_ORGANISME_FIELD,	FACT_ORGANISME_LEN);
   alimenteChamp(pDonnees->libelle,		FACT_LIBELLE_FIELD,		FACT_LIBELLE_LEN);
   alimenteChamp(pDonnees->montant,  	FACT_MONTANT_FIELD, 		FACT_MONTANT_LEN);
   alimenteChamp(pDonnees->unite, 		FACT_UNITE_FIELD, 		FACT_UNITE_LEN);
   alimenteChamp(pDonnees->mode_paie, 	FACT_MODE_PAIE_FIELD, 	FACT_MODE_PAIE_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :   	NSFact::videFiche()
//
//  Description : Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSFact::videFiche()
{
	videChamp(pDonnees->numcompt, 	FACT_NUMCOMPT_FIELD,  	FACT_NUMCOMPT_LEN);
   videChamp(pDonnees->numero,		FACT_NUMERO_FIELD,		FACT_NUMERO_LEN);
   videChamp(pDonnees->operateur, 	FACT_OPERATEUR_FIELD, 	FACT_OPERATEUR_LEN);
   videChamp(pDonnees->date_paie, 	FACT_DATE_PAIE_FIELD,	FACT_DATE_PAIE_LEN);
	videChamp(pDonnees->organisme,	FACT_ORGANISME_FIELD,   FACT_ORGANISME_LEN);
   videChamp(pDonnees->libelle,		FACT_LIBELLE_FIELD,		FACT_LIBELLE_LEN);
   videChamp(pDonnees->montant,  	FACT_MONTANT_FIELD, 		FACT_MONTANT_LEN);
   videChamp(pDonnees->unite, 		FACT_UNITE_FIELD, 		FACT_UNITE_LEN);
   videChamp(pDonnees->mode_paie, 	FACT_MODE_PAIE_FIELD, 	FACT_MODE_PAIE_LEN);
}
//---------------------------------------------------------------------------//  Fonction :  	NSFact::open()
//
//  Description :	Ouvre la table primaire et les index secondaires
//
//  Returns :		PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSFact::open()
{
	char tableName[] = "NSM_FACT.DB";
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_COMPTA);
	return(lastError);
}

//---------------------------------------------------------------------------//  Function:  NSFact::Create()
//---------------------------------------------------------------------------
bool
NSFact::Create()
{
	return true;
}

//---------------------------------------------------------------------------
//  Function:  NSFact::Modify()
//---------------------------------------------------------------------------
bool
NSFact::Modify()
{
	return true;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSFact&
NSFact::operator=(NSFact src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFact::operator == (const NSFact& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//---------------------------------------------------------------------------
//  Fonction:		NSFactInfo::NSFactInfo()
//
//  Description:	Constructeur par d�faut
//---------------------------------------------------------------------------
NSFactInfo::NSFactInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSFactData();
}

//---------------------------------------------------------------------------
//  Fonction:		NSFactInfo::NSFactInfo(NSFact*)
//
//  Description:	Constructeur � partir d'un NSFact
//---------------------------------------------------------------------------
NSFactInfo::NSFactInfo(NSFact* pFact)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFactData();
	//
	// Copie les valeurs du NSFact
	//
	*pDonnees = *(pFact->pDonnees);
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFactInfo::NSFactInfo(NSFactInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFactData();
	//
	// Copie les valeurs du NSFactInfo d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSFactInfo::~NSFactInfo()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSFactInfo&
NSFactInfo::operator=(NSFactInfo src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFactInfo::operator == (const NSFactInfo& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//***************************************************************************
// 					Impl�mentation des m�thodes NSFactArray
//***************************************************************************

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSFactArray::NSFactArray(NSFactArray& rv) : NSFicheFactArray()
{
	if (!(rv.empty()))
		for (NSFactIter i = rv.begin(); i != rv.end(); i++)
   		push_back(new NSFactInfo(*(*i)));
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
void
NSFactArray::vider()
{
	if (!(empty()))
		for (NSFactIter i = begin(); i != end(); )
		{
			delete *i;
      erase(i);
		}
}

NSFactArray::~NSFactArray(){
	vider();
}

//***************************************************************************
// Impl�mentation des m�thodes NSTPayant
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSTPayantData::NSTPayantData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSTPayantData::NSTPayantData(NSTPayantData& rv)
{
	strcpy(numcompt, 	rv.numcompt);
	strcpy(numero,	 	rv.numero);
	strcpy(organisme,	rv.organisme);
	strcpy(libelle,		rv.libelle);
	strcpy(reste_du, 	rv.reste_du);
	strcpy(monnaie,  	rv.monnaie);
	strcpy(okpaye,	 	rv.okpaye);
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSTPayantData::~NSTPayantData()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSTPayantData&
NSTPayantData::operator=(NSTPayantData src)
{
	strcpy(numcompt, 	  	src.numcompt);
   strcpy(numero,			src.numero);
   strcpy(organisme,		src.organisme);
   strcpy(libelle,		src.libelle);
	strcpy(reste_du,  	src.reste_du);
	strcpy(monnaie, 		src.monnaie);
   strcpy(okpaye,			src.okpaye);

	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSTPayantData::operator == ( const NSTPayantData& o )
{
	if ((strcmp(numcompt, o.numcompt) == 0) &&
   	 (strcmp(numero, o.numero) == 0))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSTPayantData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(numcompt, 	0, TPAY_NUMCOMPT_LEN + 1) ;
  memset(numero,		0, TPAY_NUMERO_LEN + 1) ;
	memset(organisme,	0, TPAY_ORGANISME_LEN + 1) ;
  memset(libelle,   0, TPAY_LIBELLE_LEN + 1) ;
	memset(reste_du,  0, TPAY_RESTE_DU_LEN + 1) ;
	memset(monnaie, 	0, TPAY_MONNAIE_LEN + 1) ;
  memset(okpaye,    0, TPAY_OKPAYE_LEN + 1) ;
}

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSTPayant::NSTPayant(NSContexte* pCtx) : NSFiche(pCtx)
{
	//
	// Cr�e un objet de donn�es
	//
	pDonnees = new NSTPayantData();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------

NSTPayant::NSTPayant(NSTPayant& rv) : NSFiche(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSTPayantData();
	//
	// Copie les valeurs du NSTransaction d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSTPayant::~NSTPayant()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Fonction :  	NSTPayant::alimenteFiche()
//
//  Description : Transf�re le contenu de pRecBuff dans les variables de
//             	la fiche
//---------------------------------------------------------------------------
void
NSTPayant::alimenteFiche()
{
	alimenteChamp(pDonnees->numcompt,	TPAY_NUMCOMPT_FIELD,		TPAY_NUMCOMPT_LEN);
   alimenteChamp(pDonnees->numero,		TPAY_NUMERO_FIELD,		TPAY_NUMERO_LEN);
   alimenteChamp(pDonnees->organisme,	TPAY_ORGANISME_FIELD,	TPAY_ORGANISME_LEN);
   alimenteChamp(pDonnees->libelle,		TPAY_LIBELLE_FIELD,		TPAY_LIBELLE_LEN);
   alimenteChamp(pDonnees->reste_du,  	TPAY_RESTE_DU_FIELD, 	TPAY_RESTE_DU_LEN);
   alimenteChamp(pDonnees->monnaie, 	TPAY_MONNAIE_FIELD, 		TPAY_MONNAIE_LEN);
   alimenteChamp(pDonnees->okpaye, 		TPAY_OKPAYE_FIELD, 		TPAY_OKPAYE_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :   	NSTPayant::videFiche()
//
//  Description : Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSTPayant::videFiche()
{
	videChamp(pDonnees->numcompt,		TPAY_NUMCOMPT_FIELD,		TPAY_NUMCOMPT_LEN);
   videChamp(pDonnees->numero,		TPAY_NUMERO_FIELD,		TPAY_NUMERO_LEN);
   videChamp(pDonnees->organisme,	TPAY_ORGANISME_FIELD,	TPAY_ORGANISME_LEN);
   videChamp(pDonnees->libelle,		TPAY_LIBELLE_FIELD,		TPAY_LIBELLE_LEN);
   videChamp(pDonnees->reste_du,  	TPAY_RESTE_DU_FIELD, 	TPAY_RESTE_DU_LEN);
   videChamp(pDonnees->monnaie, 		TPAY_MONNAIE_FIELD, 		TPAY_MONNAIE_LEN);
   videChamp(pDonnees->okpaye, 		TPAY_OKPAYE_FIELD, 		TPAY_OKPAYE_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :  	NSTPayant::open()
//
//  Description :	Ouvre la table primaire et les index secondaires
//
//  Returns :		PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSTPayant::open()
{
	char tableName[] = "TPAYANT.DB";
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_COMPTA);
	return(lastError);
}

//---------------------------------------------------------------------------
//  Function:  NSTPayant::Create()
//---------------------------------------------------------------------------
bool
NSTPayant::Create()
{
	return true;
}

//---------------------------------------------------------------------------
//  Function:  NSTPayant::Modify()
//---------------------------------------------------------------------------
bool
NSTPayant::Modify()
{
	return true;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSTPayant&
NSTPayant::operator=(NSTPayant src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSTPayant::operator == (const NSTPayant& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//---------------------------------------------------------------------------
//  Fonction:		NSTPayantInfo::NSTPayantInfo()
//
//  Description:	Constructeur par d�faut
//---------------------------------------------------------------------------
NSTPayantInfo::NSTPayantInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSTPayantData();
}

//---------------------------------------------------------------------------
//  Fonction:		NSTPayantInfo::NSTPayantInfo(NSTPayant*)
//
//  Description:	Constructeur � partir d'un NSTPayant
//---------------------------------------------------------------------------
NSTPayantInfo::NSTPayantInfo(NSTPayant* pTPayant)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSTPayantData();
	//
	// Copie les valeurs du NSTPayant
	//
	*pDonnees = *(pTPayant->pDonnees);
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSTPayantInfo::NSTPayantInfo(NSTPayantInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSTPayantData();
	//
	// Copie les valeurs du NSTPayantInfo d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSTPayantInfo::~NSTPayantInfo()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSTPayantInfo&
NSTPayantInfo::operator=(NSTPayantInfo src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSTPayantInfo::operator == (const NSTPayantInfo& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//***************************************************************************
// 					Impl�mentation des m�thodes NSTPArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSTPArray::NSTPArray(NSTPArray& rv) : NSTPayantArray()
{
	for (NSTPIter i = rv.begin(); i != rv.end(); i++)
   	push_back(new NSTPayantInfo(*(*i)));
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSTPArray::vider()
{
	for (NSTPIter i = begin(); i != end(); )
   {
   	delete *i;
      erase(i);
   }
}


NSTPArray::~NSTPArray()
{
	vider();
}

//***************************************************************************
// Impl�mentation des m�thodes NSCodeOrga
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSCodeOrgaData::NSCodeOrgaData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCodeOrgaData::NSCodeOrgaData(NSCodeOrgaData& rv)
{
   strcpy(code,			rv.code);
   strcpy(lib_court,		rv.lib_court);
   strcpy(lib_long,		rv.lib_long);
   strcpy(adresse,		rv.adresse);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCodeOrgaData::~NSCodeOrgaData()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSCodeOrgaData&
NSCodeOrgaData::operator=(NSCodeOrgaData src)
{
	strcpy(code,			src.code);
   strcpy(lib_court,		src.lib_court);
   strcpy(lib_long,		src.lib_long);
   strcpy(adresse,		src.adresse);

	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCodeOrgaData::operator == ( const NSCodeOrgaData& o )
{
	if (strcmp(code, o.code) == 0)
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Met � blanc les variables de la fiche
//---------------------------------------------------------------------------
void
NSCodeOrgaData::metABlanc()
{
	//
	// Met les champs de donn�es � blanc
	//
   memset(code,		' ', ORGA_CODE_LEN);
   memset(lib_court,	' ', ORGA_LIB_COURT_LEN);
   memset(lib_long,	' ', ORGA_LIB_LONG_LEN);
   memset(adresse,	' ', ORGA_ADRESSE_LEN);
}

//---------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSCodeOrgaData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(code,		0, ORGA_CODE_LEN + 1);
   memset(lib_court,	0, ORGA_LIB_COURT_LEN + 1);
   memset(lib_long,	0, ORGA_LIB_LONG_LEN + 1);
   memset(adresse,	0, ORGA_ADRESSE_LEN + 1);
}

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSCodeOrga::NSCodeOrga(NSContexte* pCtx) : NSFiche(pCtx)
{
	//
	// Cr�e un objet de donn�es
	//
	pDonnees = new NSCodeOrgaData();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCodeOrga::NSCodeOrga(NSCodeOrga& rv) : NSFiche(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCodeOrgaData();
	//
	// Copie les valeurs du NSTransaction d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCodeOrga::~NSCodeOrga()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Fonction :  	NSCodeOrga::alimenteFiche()
//
//  Description : Transf�re le contenu de pRecBuff dans les variables de
//             	la fiche
//---------------------------------------------------------------------------
void
NSCodeOrga::alimenteFiche()
{
   alimenteChamp(pDonnees->code,			ORGA_CODE_FIELD,			ORGA_CODE_LEN);
   alimenteChamp(pDonnees->lib_court,	ORGA_LIB_COURT_FIELD,	ORGA_LIB_COURT_LEN);
   alimenteChamp(pDonnees->lib_long,	ORGA_LIB_LONG_FIELD,		ORGA_LIB_LONG_LEN);
   alimenteChamp(pDonnees->adresse,		ORGA_ADRESSE_FIELD,		ORGA_ADRESSE_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :   	NSCodeOrga::videFiche()
//
//  Description : Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSCodeOrga::videFiche()
{
	videChamp(pDonnees->code,			ORGA_CODE_FIELD,			ORGA_CODE_LEN);
   videChamp(pDonnees->lib_court,	ORGA_LIB_COURT_FIELD,	ORGA_LIB_COURT_LEN);
   videChamp(pDonnees->lib_long,		ORGA_LIB_LONG_FIELD,		ORGA_LIB_LONG_LEN);
   videChamp(pDonnees->adresse,		ORGA_ADRESSE_FIELD,		ORGA_ADRESSE_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :  	NSCodeOrga::open()
//
//  Description :	Ouvre la table primaire et les index secondaires
//
//  Returns :		PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSCodeOrga::open()
{
	char tableName[] = "CODEORGA.DB";
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_COMPTA);
	return(lastError);
}

//---------------------------------------------------------------------------
//  Function:  NSCodeOrga::Create()
//---------------------------------------------------------------------------
bool
NSCodeOrga::Create()
{
	return true;
}

//---------------------------------------------------------------------------
//  Function:  NSCodeOrga::Modify()
//---------------------------------------------------------------------------
bool
NSCodeOrga::Modify()
{
	return true;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSCodeOrga&
NSCodeOrga::operator=(NSCodeOrga src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCodeOrga::operator == (const NSCodeOrga& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//---------------------------------------------------------------------------
//  Fonction:		NSCodeOrgaInfo::NSCodeOrgaInfo()
//
//  Description:	Constructeur par d�faut
//---------------------------------------------------------------------------
NSCodeOrgaInfo::NSCodeOrgaInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSCodeOrgaData();
}

//---------------------------------------------------------------------------
//  Fonction:		NSCodeOrgaInfo::NSCodeOrgaInfo(NSCodeOrga*)
//
//  Description:	Constructeur � partir d'un NSCodeOrga
//---------------------------------------------------------------------------
NSCodeOrgaInfo::NSCodeOrgaInfo(NSCodeOrga* pCodeOrga)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCodeOrgaData();
	//
	// Copie les valeurs du NSCodeOrga
	//
	*pDonnees = *(pCodeOrga->pDonnees);
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCodeOrgaInfo::NSCodeOrgaInfo(NSCodeOrgaInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCodeOrgaData();
	//
	// Copie les valeurs du NSCodeOrgaInfo d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCodeOrgaInfo::~NSCodeOrgaInfo()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSCodeOrgaInfo&
NSCodeOrgaInfo::operator=(NSCodeOrgaInfo src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCodeOrgaInfo::operator == (const NSCodeOrgaInfo& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//***************************************************************************
// 					Impl�mentation des m�thodes NSCodeOrgaArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCodeOrgaArray::NSCodeOrgaArray(NSCodeOrgaArray& rv) : NSOrganArray()
{
	for (NSCodeOrgaIter i = rv.begin(); i != rv.end(); i++)
   	push_back(new NSCodeOrgaInfo(*(*i)));
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSCodeOrgaArray::vider()
{
	for (NSCodeOrgaIter i = begin(); i != end(); )
   {
   	delete *i;
      erase(i);
   }
}


NSCodeOrgaArray::~NSCodeOrgaArray()
{
	vider();
}

//***************************************************************************
// Impl�mentation des m�thodes NSCodeRegime
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSCodeRegimeData::NSCodeRegimeData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCodeRegimeData::NSCodeRegimeData(NSCodeRegimeData& rv)
{
   strcpy(code,			rv.code);
   strcpy(lib_court,		rv.lib_court);
   strcpy(lib_long,		rv.lib_long);
   strcpy(destinataire,	rv.destinataire);
   strcpy(centre_info,	rv.centre_info);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCodeRegimeData::~NSCodeRegimeData()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSCodeRegimeData&
NSCodeRegimeData::operator=(NSCodeRegimeData src)
{
	strcpy(code,			src.code);
   strcpy(lib_court,		src.lib_court);
   strcpy(lib_long,		src.lib_long);
   strcpy(destinataire,	src.destinataire);
   strcpy(centre_info,	src.centre_info);

	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCodeRegimeData::operator == ( const NSCodeRegimeData& o )
{
	if (strcmp(code, o.code) == 0)
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Met � blanc les variables de la fiche
//---------------------------------------------------------------------------
void
NSCodeRegimeData::metABlanc()
{
	//
	// Met les champs de donn�es � blanc
	//
   memset(code,			' ', REG_CODE_LEN);
   memset(lib_court,		' ', REG_LIB_COURT_LEN);
   memset(lib_long,		' ', REG_LIB_LONG_LEN);
   memset(destinataire,	' ', REG_DESTINATAIRE_LEN);
   memset(centre_info,	' ', REG_CENTRE_INFO_LEN);
}

//---------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSCodeRegimeData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(code,			0, REG_CODE_LEN + 1);
   memset(lib_court,		0, REG_LIB_COURT_LEN + 1);
   memset(lib_long,		0, REG_LIB_LONG_LEN + 1);
   memset(destinataire,	0, REG_DESTINATAIRE_LEN + 1);
   memset(centre_info,	0, REG_CENTRE_INFO_LEN + 1);
}

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSCodeRegime::NSCodeRegime(NSContexte* pCtx) : NSFiche(pCtx)
{
	//
	// Cr�e un objet de donn�es
	//
	pDonnees = new NSCodeRegimeData();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCodeRegime::NSCodeRegime(NSCodeRegime& rv) : NSFiche(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCodeRegimeData();
	//
	// Copie les valeurs du NSTransaction d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCodeRegime::~NSCodeRegime()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Fonction :  	NSCodeRegime::alimenteFiche()
//
//  Description : Transf�re le contenu de pRecBuff dans les variables de
//             	la fiche
//---------------------------------------------------------------------------
void
NSCodeRegime::alimenteFiche()
{
   alimenteChamp(pDonnees->code,				REG_CODE_FIELD,			REG_CODE_LEN);
   alimenteChamp(pDonnees->lib_court,		REG_LIB_COURT_FIELD,		REG_LIB_COURT_LEN);
   alimenteChamp(pDonnees->lib_long,		REG_LIB_LONG_FIELD,		REG_LIB_LONG_LEN);
   alimenteChamp(pDonnees->destinataire,	REG_DESTINATAIRE_FIELD,	REG_DESTINATAIRE_LEN);
   alimenteChamp(pDonnees->centre_info,	REG_CENTRE_INFO_FIELD,	REG_CENTRE_INFO_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :   	NSCodeRegime::videFiche()
//
//  Description : Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSCodeRegime::videFiche()
{
	videChamp(pDonnees->code,				REG_CODE_FIELD,			REG_CODE_LEN);
   videChamp(pDonnees->lib_court,		REG_LIB_COURT_FIELD,		REG_LIB_COURT_LEN);
   videChamp(pDonnees->lib_long,			REG_LIB_LONG_FIELD,		REG_LIB_LONG_LEN);
   videChamp(pDonnees->destinataire,	REG_DESTINATAIRE_FIELD,	REG_DESTINATAIRE_LEN);
   videChamp(pDonnees->centre_info,		REG_CENTRE_INFO_FIELD,	REG_CENTRE_INFO_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :  	NSCodeRegime::open()
//
//  Description :	Ouvre la table primaire et les index secondaires
//
//  Returns :		PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSCodeRegime::open()
{
	char tableName[] = "REGIMES.DB";
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL);
	return(lastError);
}

//---------------------------------------------------------------------------
//  Function:  NSCodeRegime::Create()
//---------------------------------------------------------------------------
bool
NSCodeRegime::Create()
{
	return true;
}

//---------------------------------------------------------------------------
//  Function:  NSCodeRegime::Modify()
//---------------------------------------------------------------------------
bool
NSCodeRegime::Modify()
{
	return true;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSCodeRegime&
NSCodeRegime::operator=(NSCodeRegime src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCodeRegime::operator == (const NSCodeRegime& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//---------------------------------------------------------------------------
//  Fonction:		NSCodeRegimeInfo::NSCodeRegimeInfo()
//
//  Description:	Constructeur par d�faut
//---------------------------------------------------------------------------
NSCodeRegimeInfo::NSCodeRegimeInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSCodeRegimeData();
}

//---------------------------------------------------------------------------
//  Fonction:		NSCodeRegimeInfo::NSCodeRegimeInfo(NSCodeRegime*)
//
//  Description:	Constructeur � partir d'un NSCodeRegime
//---------------------------------------------------------------------------
NSCodeRegimeInfo::NSCodeRegimeInfo(NSCodeRegime* pCodeRegime)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCodeRegimeData();
	//
	// Copie les valeurs du NSCodeRegime
	//
	*pDonnees = *(pCodeRegime->pDonnees);
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCodeRegimeInfo::NSCodeRegimeInfo(NSCodeRegimeInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCodeRegimeData();
	//
	// Copie les valeurs du NSCodeRegimeInfo d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCodeRegimeInfo::~NSCodeRegimeInfo()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSCodeRegimeInfo&
NSCodeRegimeInfo::operator=(NSCodeRegimeInfo src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCodeRegimeInfo::operator == (const NSCodeRegimeInfo& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//***************************************************************************
// 					Impl�mentation des m�thodes NSCodeRegimeArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCodeRegimeArray::NSCodeRegimeArray(NSCodeRegimeArray& rv) : NSRegimeArray()
{
	for (NSCodeRegimeIter i = rv.begin(); i != rv.end(); i++)
   	push_back(new NSCodeRegimeInfo(*(*i)));
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSCodeRegimeArray::vider()
{
	for (NSCodeRegimeIter i = begin(); i != end(); )
   {
   	delete *i;
      erase(i);
   }
}


NSCodeRegimeArray::~NSCodeRegimeArray()
{
	vider();
}

//////////////////////////// fin de nscpta.cpp

