// nsfsedlg.cpp : fichier des dialogues compt et fact/////////////////////////////////////////////////////////

#include <stdio.h>#include <classlib\date.h>
#include <classlib\time.h>

#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"
#include "nautilus\nspatdlg.h"
#include "nscompta\nscompta.h"
#include "nscompta\nscompta.rh"
#include "nscompta\nsf16dlg.h"
#include "nscompta\nsfsedlg.h"

//***************************************************************************
//
// 						M�thodes de CreerFicheComptDialog
//
//***************************************************************************

DEFINE_RESPONSE_TABLE1(CreerFicheComptDialog, NSUtilDialog)
   EV_COMMAND(IDOK, CmOk),
   EV_COMMAND(IDCANCEL, CmCancel),

   EV_LV_DISPINFO_NOTIFY(IDC_CPT_LISTFSE, LVN_GETDISPINFO, DispInfoListeFse),
   EV_LV_DISPINFO_NOTIFY(IDC_CPT_LISTFACT, LVN_GETDISPINFO, DispInfoListeFact),
   EV_LV_DISPINFO_NOTIFY(IDC_CPT_LISTTPAYANT, LVN_GETDISPINFO, DispInfoListeTP),

   EV_BN_CLICKED(IDC_CPT_PREST, Cm1610),
   EV_BN_CLICKED(IDC_CPT_IDEPL, Cm1620),
   EV_BN_CLICKED(IDC_CPT_IKM, Cm1630),
   EV_BN_CLICKED(IDC_CPT_CCAM, CmCCAM),

   // Les fonctions CmModifxxx sont appel�es par le double-click
   EV_BN_CLICKED(IDC_CPT_PAIEMENT, CmPaiement),
   EV_BN_CLICKED(IDC_CPT_LOC, SwitchFFEuro),
   EV_BN_CLICKED(IDC_CPT_EURO, SwitchFFEuro),
   EV_BN_CLICKED(IDC_CPT_PRENDCOR, CmCorresp),
   EV_BN_CLICKED(IDC_CPT_TPAYANT, CmTiersPayant),
   EV_BN_CLICKED(IDC_CPT_CONSULT, CmCodeConsult),
END_RESPONSE_TABLE;

//
// Constructeur
//
CreerFicheComptDialog::CreerFicheComptDialog(TWindow* pere, NSContexte* pCtx, NSPersonInfo* pPat, bool bCreation)
                      :NSUtilDialog(pere, pCtx, "IDD_COMPT", pNSResModule)
{
	// fichiers d'aide
	sHindex = "" ;
	sHcorps = "Fiche_Compta.html" ;

	// stockage du patient
	pPatient = new NSPersonInfo(*pPat) ;

	// Initialisation des donnees et des variables compta
	pData 	 = new NSComptData ;
	pVar     = new NSVarCompta(pCtx) ;
	pVar->bCreation = bCreation ;

	// Cr�ation de tous les "objets de contr�le"
	pDate			  = new NSEditDateC(pContexte, this, IDC_CPT_DATE) ;
	pHeure			= new NSEditHeureC(pContexte, this, IDC_CPT_HEURE) ;
	pExamen			= new NSUtilExamen(pContexte, this, IDC_CPT_EXAMEN, pCtx->getDico()) ;
	pGBMonnaie	= new TGroupBox(this, IDC_CPT_GBMONNAIE) ;
	pLocal			= new TRadioButton(this, IDC_CPT_LOC, pGBMonnaie) ;
	pEuro			  = new TRadioButton(this, IDC_CPT_EURO, pGBMonnaie) ;
	pGBContexte = new TGroupBox(this, IDC_CPT_GBCONTEXTE) ;
	pExterne		= new TRadioButton(this, IDC_CPT_EXTERNE, pGBContexte) ;
  pAmbulatoire= new TRadioButton(this, IDC_CPT_AMBULATOIRE, pGBContexte) ;
	pHospital		= new TRadioButton(this, IDC_CPT_HOSPITAL, pGBContexte) ;

	pSommeDue		= new NSEditSommeDue(pContexte, this, IDC_CPT_SOMDUE) ;
	pDepass			= new NSUtilEditSomme(pContexte, this, IDC_CPT_DEPASS) ;
	pPaye			  = new NSUtilEditSomme(pContexte, this, IDC_CPT_PAYE) ;
	pResteDu		= new NSUtilEditSomme(pContexte, this, IDC_CPT_RESTEDU) ;
	pCorresp		= new TStatic(this, IDC_CPT_PRENDCOR) ;

	pListeFse 	= new NSListFseWindow(this, IDC_CPT_LISTFSE) ;
	pListeFact	= new NSListFactWindow(this, IDC_CPT_LISTFACT) ;
	pListeTP		= new NSListTPWindow(this, IDC_CPT_LISTTPAYANT) ;

  pFseArray 	= new NSFse16Array ;
	pFactArray 	= new NSFactArray ;	pTPArray		= new NSTPArray ;

	nbPrest 		= 0 ;
	nbFact 			= 0 ;
	nbTP			  = 0 ;
	bEuro          = true ;	bCreerPaiement = true ;	sCodeAlerte    = "" ;
}

//// Destructeur
//
CreerFicheComptDialog::~CreerFicheComptDialog()
{
	delete pPatient ;
	delete pData ;
	delete pVar ;
	delete pDate ;
	delete pHeure ;
	delete pExamen ;
	delete pGBMonnaie ;
	delete pLocal ;
	delete pEuro ;
	delete pGBContexte ;
	delete pExterne ;
  delete pAmbulatoire ;
	delete pHospital ;
	delete pSommeDue ;
	delete pDepass ;
	delete pPaye ;
	delete pResteDu ;
	delete pCorresp ;
	delete pListeFse ;
	delete pListeFact ;
	delete pListeTP ;
	delete pFseArray ;
	delete pFactArray ;
	delete pTPArray ;
}

//// Fonction SetupWindow : Mise en place des data � l'�cran et initialisation
//	du tableau des Fse16xx + liste
//
void
CreerFicheComptDialog::SetupWindow()
{
	struct date dateSys ;
	struct time heureSys ;
	char	      examen[100] ;
	string      sCodeLexique ;
	string	    sTitre ;

	TDialog::SetupWindow() ;

  // en cr�ation on met la date et l'heure du jour par d�faut
  if (!strcmp(pData->date, ""))
  {
  	getdate(&dateSys) ;
    sprintf(pData->date, "%4d%02d%02d", dateSys.da_year, dateSys.da_mon, dateSys.da_day) ;
	}

  pDate->setDate(string(pData->date)) ;
  pVar->sDateC = string(pData->date) ;

  if (!strcmp(pData->heure, ""))
  {
  	gettime(&heureSys) ;
    sprintf(pData->heure, "%02d%02d", heureSys.ti_hour, heureSys.ti_min) ;
  }

  pHeure->setHeure(string(pData->heure)) ;
  pVar->sHeureC = string(pData->heure) ;

  // correction des examens �tant par erreur en texte libre
  if (!strcmp(pData->examen, "�????"))
  {
  	strcpy(pData->examen, "") ;
    strcpy(pData->synonyme, "") ;
  }

	// affichage de l'examen : cas normal
  if (strcmp(pData->examen, ""))
  {
  	sCodeAlerte = string(pData->examen) ;
    sprintf(examen, "%s%s", pData->examen, pData->synonyme) ;
    sCodeLexique = string(examen) ;
    pExamen->setLabel(sCodeLexique) ;

    if (pVar->bCreation)
    {
			if (ExisteExamen(pPatient->sPersonID, pVar->sDateC, sCodeAlerte))
			{
      	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName();
        int ret = MessageBox("Il existe d�j� le m�me examen, pour le m�me patient, � la m�me date. Voulez-vous annuler?", sCaption.c_str(), MB_YESNO);

        if (ret == IDYES)
        	CmCancel() ;
      }
		}
	}
  else
  	pExamen->SetText("") ;

	if (!strcmp(pData->contexte, "NEXTE"))
  	pExterne->Check() ;
  if (!strcmp(pData->contexte, "NAMBU"))
  	pAmbulatoire->Check() ;
  if (!strcmp(pData->contexte, "NHOST"))
  	pHospital->Check() ;
  // cas par d�faut : � placer dans Pr�f�rences
  if (!strcmp(pData->contexte, ""))
  	pExterne->Check() ;

	// on met la monnaie � FF par d�faut
  if (pVar->monnaieRef == MONNAIE_LOCALE)
  {
  	bEuro = false ;
    pLocal->SetCaption((pVar->sigle).c_str()) ;
    pLocal->Check() ;
    pSommeDue->setSomme(string(pData->duFranc)) ;
    pDepass->setSomme(string(pData->depassFranc)) ;
    pPaye->setSomme(string(pData->payeFranc)) ;
  }
  else
  {
  	bEuro = true ;
    pLocal->SetCaption("FF") ;
    pEuro->Check() ;
    pSommeDue->setSomme(string(pData->duEuro)) ;
    pDepass->setSomme(string(pData->depassEuro)) ;
    pPaye->setSomme(string(pData->payeEuro)) ;
  }

  strcpy(codeCorresp, pData->prescript) ;

  if (strcmp(codeCorresp, ""))
  {
  	RetrouveCorresp(sTitre) ;
		pCorresp->SetCaption(sTitre.c_str()) ;
  }

  if (InitFse16Array())
  {
  	InitListeFse() ;
    AfficheListeFse() ;
    AfficheSommeDue() ;
  }

  if (InitFactArray())
  {
  	InitListeFact() ;
    AfficheListeFact() ;
    AffichePaye() ;
  }

	if (InitTPArray())
  {
  	InitListeTP() ;
    AfficheListeTP() ;
  }
}

//***************************************************************************//
// 								M�thodes InitxxxArray()
//
//		Fonctions pour charger les bases rattach�es � NSCompt dans leurs
//		Arrays respectifs : base Fse16xx, Fact et TPayant.
//
//***************************************************************************

//
// 	InitFse1610Array : Charge les fiches 1610 dans NSFseArray
//
bool
CreerFicheComptDialog::InitFse1610Array()
{
	// on r�cup�re la cle
	string		sNumCompt   = string(pData->numcompt) ;
  string		sNumFse1610 = sNumCompt + string("    ") ;
	NSFse1610 Fse1610(pContexte) ;

  Fse1610.lastError = Fse1610.open() ;
  if (Fse1610.lastError != DBIERR_NONE)
  {
  	erreur("Erreur � l'ouverture de la base Fse1610.", standardError, Fse1610.lastError) ;
    return false ;
  }

  Fse1610.lastError = Fse1610.chercheClef(&sNumFse1610,
      														        "",
																          0,
																          keySEARCHGEQ,
																          dbiWRITELOCK) ;

	if (Fse1610.lastError == DBIERR_BOF)	// cas fichier vide
  {
  	Fse1610.close() ;
    return true ;		// le tableau est vide
  }

  if ((Fse1610.lastError != DBIERR_NONE) && (Fse1610.lastError != DBIERR_EOF))
  {
  	erreur("Erreur � la recherche d'une fiche Fse1610.", standardError, Fse1610.lastError) ;
    Fse1610.close() ;
    return false ;
  }

  while (Fse1610.lastError != DBIERR_EOF)
  {
  	Fse1610.lastError = Fse1610.getRecord() ;
    if (Fse1610.lastError != DBIERR_NONE)
    {
    	erreur("Erreur � la lecture d'une fiche Fse1610.", standardError, Fse1610.lastError) ;
      Fse1610.close() ;
      return false ;
    }

    // condition d'arret
    if (!(string(Fse1610.pDonnees->numcompt) == sNumCompt))
    	break ;

    // on remplit le tableau
    pFseArray->push_back(new NSBlocFse16(&Fse1610)) ;
    nbPrest++ ;

    // ... on passe au composant suivant
    Fse1610.lastError = Fse1610.suivant(dbiWRITELOCK) ;
    if ((Fse1610.lastError != DBIERR_NONE) && (Fse1610.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche Fse1610.", standardError, Fse1610.lastError) ;
      Fse1610.close() ;
      return false ;
    }
  } // fin du while (recherche des composants images)

  // on ferme la base Fse1610
  Fse1610.lastError = Fse1610.close() ;
  if (Fse1610.lastError != DBIERR_NONE)
  {
  	erreur("Erreur de fermeture du fichier Fse1610.", standardError, Fse1610.lastError) ;
    return false ;
  }

  return true ;
}

//// 	InitFse1620Array : Charge les fiches 1620 dans NSFseArray
//
bool
CreerFicheComptDialog::InitFse1620Array()
{
	// on r�cup�re la cle
	string		sNumCompt = string(pData->numcompt);
   string 		sNumFse1620 = sNumCompt + string("    ");
	NSFse1620* 	pFse1620 = new NSFse1620(pContexte);

   pFse1620->lastError = pFse1620->open();
   if (pFse1620->lastError != DBIERR_NONE)
   {
   	erreur("Erreur � l'ouverture de la base Fse1620.",standardError, pFse1620->lastError) ;
      delete pFse1620;
      return false;
   }

   pFse1620->lastError = pFse1620->chercheClef(&sNumFse1620,
      														 "",
																 0,
																 keySEARCHGEQ,
																 dbiWRITELOCK);

   if (pFse1620->lastError == DBIERR_BOF)	// cas fichier vide
   {
   	pFse1620->close();
      delete pFse1620;
      return true;		// le tableau est vide
   }

   if ((pFse1620->lastError != DBIERR_NONE) && (pFse1620->lastError != DBIERR_EOF))
   {
   	erreur("Erreur � la recherche d'une fiche Fse1620.", standardError, pFse1620->lastError) ;
      pFse1620->close();
      delete pFse1620;
      return false;
   }

   while (pFse1620->lastError != DBIERR_EOF)
   {
   	pFse1620->lastError = pFse1620->getRecord();
      if (pFse1620->lastError != DBIERR_NONE)
      {
      	erreur("Erreur � la lecture d'une fiche Fse1620.", standardError, pFse1620->lastError) ;
         pFse1620->close();
         delete pFse1620;
         return false;
      }

      // condition d'arret
      if (!(string(pFse1620->pDonnees->numcompt) == sNumCompt)) break;

      // on remplit le tableau
      pFseArray->push_back(new NSBlocFse16(pFse1620));
      nbPrest++;

      // ... on passe au composant suivant
      pFse1620->lastError = pFse1620->suivant(dbiWRITELOCK);
      if ((pFse1620->lastError != DBIERR_NONE) && (pFse1620->lastError != DBIERR_EOF))
      {
      	erreur("Erreur d'acces � une fiche Fse1620.", standardError, pFse1620->lastError) ;
         pFse1620->close();
         delete pFse1620;
         return false;
      }
   } // fin du while (recherche des composants images)

   // on ferme la base Fse1620
   pFse1620->lastError = pFse1620->close();
   if (pFse1620->lastError != DBIERR_NONE)
   {
   	erreur("Erreur de fermeture du fichier Fse1620.", standardError, pFse1620->lastError) ;
      delete pFse1620;
      return false;
   }

   delete pFse1620;
   return true;
}

//// 	InitFse1630Array : Charge les fiches 1630 dans NSFseArray
//
bool
CreerFicheComptDialog::InitFse1630Array()
{
	// on r�cup�re la cle
	string		sNumCompt = string(pData->numcompt);
   string 		sNumFse1630 = sNumCompt + string("    ");
	NSFse1630* 	pFse1630 = new NSFse1630(pContexte);

   pFse1630->lastError = pFse1630->open();
   if (pFse1630->lastError != DBIERR_NONE)
   {
   	erreur("Erreur � l'ouverture de la base Fse1630.",standardError, pFse1630->lastError) ;
      delete pFse1630;
      return false;
   }

   pFse1630->lastError = pFse1630->chercheClef(&sNumFse1630,
      														 "",
																 0,
																 keySEARCHGEQ,
																 dbiWRITELOCK);

   if (pFse1630->lastError == DBIERR_BOF)	// cas fichier vide
   {
   	pFse1630->close();
      delete pFse1630;
      return true;		// le tableau est vide
   }

   if ((pFse1630->lastError != DBIERR_NONE) && (pFse1630->lastError != DBIERR_EOF))
   {
   	erreur("Erreur � la recherche d'une fiche Fse1630.", standardError, pFse1630->lastError) ;
      pFse1630->close();
      delete pFse1630;
      return false;
   }

   while (pFse1630->lastError != DBIERR_EOF)
   {
   	pFse1630->lastError = pFse1630->getRecord();
      if (pFse1630->lastError != DBIERR_NONE)
      {
      	erreur("Erreur � la lecture d'une fiche Fse1630.", standardError, pFse1630->lastError) ;
         pFse1630->close();
         delete pFse1630;
         return false;
      }

      // condition d'arret
      if (!(string(pFse1630->pDonnees->numcompt) == sNumCompt)) break;

      // on remplit le tableau
      pFseArray->push_back(new NSBlocFse16(pFse1630));
      nbPrest++;

      // ... on passe au composant suivant
      pFse1630->lastError = pFse1630->suivant(dbiWRITELOCK);
      if ((pFse1630->lastError != DBIERR_NONE) && (pFse1630->lastError != DBIERR_EOF))
      {
      	erreur("Erreur d'acces � une fiche Fse1630.", standardError, pFse1630->lastError) ;
         pFse1630->close();
         delete pFse1630;
         return false;
      }
   } // fin du while (recherche des composants images)

   // on ferme la base Fse1630
   pFse1630->lastError = pFse1630->close();
   if (pFse1630->lastError != DBIERR_NONE)
   {
   	erreur("Erreur de fermeture du fichier Fse1630.", standardError, pFse1630->lastError) ;
      delete pFse1630;
      return false;
   }

   delete pFse1630;
   return true;
}

bool
CreerFicheComptDialog::InitFseCCAMArray()
{
	// on r�cup�re la cle
	string		sNumCompt   = string(pData->numcompt) ;
  // string 		sNumFseCCAM = sNumCompt + string("    ") ;
  string 		sNumFseCCAM = sNumCompt ;
	NSFseCCAM FseCCAM(pContexte) ;

  FseCCAM.lastError = FseCCAM.open() ;
  if (FseCCAM.lastError != DBIERR_NONE)
  {
   	erreur("Erreur � l'ouverture de la base FseCCAM.", standardError, FseCCAM.lastError) ;
    return false ;
  }

  FseCCAM.lastError = FseCCAM.chercheClef(&sNumFseCCAM,
      														        "",
																          0,
																          keySEARCHGEQ,
																          dbiWRITELOCK) ;

  if (FseCCAM.lastError == DBIERR_BOF)	// cas fichier vide
  {
  	FseCCAM.close() ;
    return true ;		// le tableau est vide
  }

  if ((FseCCAM.lastError != DBIERR_NONE) && (FseCCAM.lastError != DBIERR_EOF))
  {
  	erreur("Erreur � la recherche d'une fiche FseCCAM.", standardError, FseCCAM.lastError) ;
    FseCCAM.close() ;
    return false ;
  }

  while (FseCCAM.lastError != DBIERR_EOF)
  {
  	FseCCAM.lastError = FseCCAM.getRecord() ;
    if (FseCCAM.lastError != DBIERR_NONE)
    {
    	erreur("Erreur � la lecture d'une fiche FseCCAM.", standardError, FseCCAM.lastError) ;
      FseCCAM.close() ;
      return false ;
    }

    // condition d'arret
    if (!(string(FseCCAM.pDonnees->numcompt) == sNumCompt))
    	break ;

    // on remplit le tableau
    pFseArray->push_back(new NSBlocFse16(&FseCCAM)) ;
    nbPrest++ ;

    // ... on passe au composant suivant
    FseCCAM.lastError = FseCCAM.suivant(dbiWRITELOCK) ;
    if ((FseCCAM.lastError != DBIERR_NONE) && (FseCCAM.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche FseCCAM.", standardError, FseCCAM.lastError) ;
      FseCCAM.close() ;
      return false ;
    }
  } // fin du while (recherche des composants images)

  // on ferme la base FseCCAM
  FseCCAM.lastError = FseCCAM.close() ;
  if (FseCCAM.lastError != DBIERR_NONE)
  {
   	erreur("Erreur de fermeture du fichier FseCCAM.", standardError, FseCCAM.lastError) ;
    return false ;
  }

	return true ;
}

//// Initialise le tableau des fiches Fse16xx rattach�es au meme num�ro
// (cad � la meme fiche compt)
//
bool
CreerFicheComptDialog::InitFse16Array()
{
	if ((!pVar->bCreation) && (pFseArray->empty()))
    {
   		nbPrest = 0;

		// on remplit le tableau
   		if (!InitFse1610Array())
   			return false;

   		if (!InitFse1620Array())
   			return false;

   		if (!InitFse1630Array())
   			return false;
        if (!InitFseCCAMArray())            return false;
   		// on trie par num�ro de prestation   		sort(pFseArray->begin(), pFseArray->end(), blocInferieur);
    }

   	return true;
}

//// Initialise le tableau des fiches fact rattachees � numcompt
//
bool
CreerFicheComptDialog::InitFactArray()
{
	// on r�cup�re la cle
   string		sNumCompt = string(pData->numcompt);
	string		sNumFact =  sNumCompt + string("  ");

   if ((pVar->bCreation) || (!pFactArray->empty()))
   	return true;

   NSFact* 	pFact = new NSFact(pContexte);

   pFact->lastError = pFact->open();
   if (pFact->lastError != DBIERR_NONE)
   {
   	erreur("Erreur � l'ouverture de la base FACT.",standardError, 0) ;
      delete pFact;
      return false;
   }

   pFact->lastError = pFact->chercheClef(&sNumFact,
      														 "",
																 0,
																 keySEARCHGEQ,
																 dbiWRITELOCK);

   if (pFact->lastError == DBIERR_BOF)	// cas fichier vide
   {
   	pFact->close();
      delete pFact;
      return true;		// le tableau est vide
   }

   if ((pFact->lastError != DBIERR_NONE) && (pFact->lastError != DBIERR_EOF))
   {
   	erreur("Erreur � la recherche d'une fiche fact.", standardError, pFact->lastError) ;
      pFact->close();
      delete pFact;
      return false;
   }

   while (pFact->lastError != DBIERR_EOF)
   {
   	pFact->lastError = pFact->getRecord();
      if (pFact->lastError != DBIERR_NONE)
      {
      	erreur("Erreur � la lecture d'une fiche fact.", standardError, pFact->lastError) ;
         pFact->close();
         delete pFact;
         return false;
      }

      // condition d'arret
      if (!(string(pFact->pDonnees->numcompt) == sNumCompt)) break;

      // on remplit le tableau
      pFactArray->push_back(new NSFactInfo(pFact));
      nbFact++;

      // ... on passe au composant suivant
      pFact->lastError = pFact->suivant(dbiWRITELOCK);
      if ((pFact->lastError != DBIERR_NONE) && (pFact->lastError != DBIERR_EOF))
      {
      	erreur("Erreur d'acces � une fiche fact.", standardError, pFact->lastError) ;
         pFact->close();
         delete pFact;
         return false;
      }
   } // fin du while (recherche des composants images)

   // on ferme la base CARTE_SV2
   pFact->lastError = pFact->close();
   if (pFact->lastError != DBIERR_NONE)
   {
   	erreur("Erreur de fermeture du fichier FACT.", standardError, pFact->lastError) ;
      delete pFact;
      return false;
   }

   delete pFact;

   // on trie les fact par date
   sort(pFactArray->begin(), pFactArray->end(), factAnterieure);

   return true;
}

boolCreerFicheComptDialog::InitTPArray()
{
	// on r�cup�re la cle
   string		sNumCompt = string(pData->numcompt);
	string		sNumTPayant =  sNumCompt + string("  ");

    if ((pVar->bCreation) || (!pTPArray->empty()))
    	return true;

	NSTPayant* 	pTPayant = new NSTPayant(pContexte);

   pTPayant->lastError = pTPayant->open();
   if (pTPayant->lastError != DBIERR_NONE)
   {
   	erreur("Erreur � l'ouverture de la base TPayant.",standardError, 0) ;
      delete pTPayant;
      return false;
   }

   pTPayant->lastError = pTPayant->chercheClef(&sNumTPayant,
      														 "",
																 0,
																 keySEARCHGEQ,
																 dbiWRITELOCK);

   if (pTPayant->lastError == DBIERR_BOF)	// cas fichier vide
   {
   	pTPayant->close();
      delete pTPayant;
      return true;		// le tableau est vide
   }

   if ((pTPayant->lastError != DBIERR_NONE) && (pTPayant->lastError != DBIERR_EOF))
   {
   	erreur("Erreur � la recherche d'une fiche TPayant.", standardError, pTPayant->lastError) ;
      pTPayant->close();
      delete pTPayant;
      return false;
   }

   while (pTPayant->lastError != DBIERR_EOF)
   {
   	pTPayant->lastError = pTPayant->getRecord();
      if (pTPayant->lastError != DBIERR_NONE)
      {
      	erreur("Erreur � la lecture d'une fiche TPayant.", standardError, pTPayant->lastError) ;
         pTPayant->close();
         delete pTPayant;
         return false;
      }

      // condition d'arret
      if (!(string(pTPayant->pDonnees->numcompt) == sNumCompt)) break;

      // on remplit le tableau
      pTPArray->push_back(new NSTPayantInfo(pTPayant));
      nbTP++;

      // ... on passe au composant suivant
      pTPayant->lastError = pTPayant->suivant(dbiWRITELOCK);
      if ((pTPayant->lastError != DBIERR_NONE) && (pTPayant->lastError != DBIERR_EOF))
      {
      	erreur("Erreur d'acces � une fiche TPayant.", standardError, pTPayant->lastError) ;
         pTPayant->close();
         delete pTPayant;
         return false;
      }
   } // fin du while (recherche des composants images)

   // on ferme la base CARTE_SV2
   pTPayant->lastError = pTPayant->close();
   if (pTPayant->lastError != DBIERR_NONE)
   {
   	erreur("Erreur de fermeture du fichier TPayant.", standardError, pTPayant->lastError) ;
      delete pTPayant;
      return false;
   }

   delete pTPayant;
   return true;
}

//***************************************************************************//
// 					 M�thodes d'initialisation des ListWindows
//
//		InitListexxx 		: d�clare les items de la liste
//    AfficheListexxx 	: charge la liste � partir de l'array correspondant
//    DispInfoListexxx 	: affiche les sub-items de la liste
//
//***************************************************************************

//
// Initialise la liste (ListWindow) des fiches Fse
//
void
CreerFicheComptDialog::InitListeFse()
{
	TListWindColumn colPrest("Prestation", 80, TListWindColumn::Left);
  	pListeFse->InsertColumn(0, colPrest);
   TListWindColumn colQte("Qt�", 40, TListWindColumn::Left);
  	pListeFse->InsertColumn(1, colQte);
  	TListWindColumn colVal("Valeur", 80, TListWindColumn::Left);
  	pListeFse->InsertColumn(2, colVal);
}

//
// Affiche dans la liste les donnees du tableau
//
void
CreerFicheComptDialog::AfficheListeFse()
{
   	char prest[255];
   	char cCode[255], cCoeff[255];
   	int  coeff, divis;

	pListeFse->DeleteAllItems();

	for (int i = nbPrest - 1; i >= 0; i--)
   	{
   		switch (((*pFseArray)[i])->typePrest)
      	{
      		case 1:
         		strcpy(cCode, ((*pFseArray)[i])->p1610->pDonnees->code);

                divis = atoi(((*pFseArray)[i])->p1610->pDonnees->divis);
            	coeff = atoi(((*pFseArray)[i])->p1610->pDonnees->coeff) * divis;

                if ((coeff % 100) == 0)
                	sprintf(cCoeff, "%d", coeff/100);
                else
                	sprintf(cCoeff, "%d,%02d", coeff/100, coeff%100);

                if (divis == 1)
         			sprintf(prest, "%s %s", cCode, cCoeff);
                else
                	sprintf(prest, "%s %s/%d", cCode, cCoeff, divis);
            	break;

         	case 2:
         		sprintf(prest, "%s", ((*pFseArray)[i])->p1620->pDonnees->code_ifd);
            	break;

         	case 3:
         		sprintf(prest, "%s", ((*pFseArray)[i])->p1630->pDonnees->code_ik);
				break;

            case 4:
                sprintf(prest, "%s", ((*pFseArray)[i])->pCCAM->pDonnees->code);
                break;
         	default:         		erreur("Type de prestation erronn� dans la liste des prestations",standardError, 0) ;            	return;
      	}

   		TListWindItem Item(prest, 0);
      	pListeFse->InsertItem(Item);
   	}
}

//// DispInfoListeFse : Pour afficher les subitems (colonnes 2 � n)
// de la ListWindow des Fse
//
void
CreerFicheComptDialog::DispInfoListeFse(TLwDispInfoNotify& dispInfo)
{
	const int 	BufLen = 255;
   static char buffer[BufLen];
   TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item;
   int 			index;
   int			montant;
   index = dispInfoItem.GetIndex();
   // Affiche les informations en fonction de la colonne
   switch (dispInfoItem.GetSubItem())   {   	case 1: // quantite

      	switch (((*pFseArray)[index])->typePrest)
         {
         	case 1:
            	sprintf(buffer, "%s", ((*pFseArray)[index])->p1610->pDonnees->quantite);
               break;

            case 2:
            	sprintf(buffer, "%s", ((*pFseArray)[index])->p1620->pDonnees->quantite);
               break;

            case 3:
            	sprintf(buffer, "%s", ((*pFseArray)[index])->p1630->pDonnees->nbre_km);
               break;
            case 4:                if (!strcmp(((*pFseArray)[index])->pCCAM->pDonnees->pourcent, ""))                    strcpy(buffer, "100");                else                    sprintf(buffer, "%s", ((*pFseArray)[index])->pCCAM->pDonnees->pourcent);                strcat(buffer, "%");                break;         }

         dispInfoItem.SetText(buffer);         break;
      case 2: 	// montant
      	switch (((*pFseArray)[index])->typePrest)         {         	case 1:
            	if (!bEuro)
         			sprintf(buffer, "%s", ((*pFseArray)[index])->p1610->pDonnees->montant_f);
               else
               	sprintf(buffer, "%s", ((*pFseArray)[index])->p1610->pDonnees->montant_e);
               break;

            case 2:
            	if (!bEuro)
         			sprintf(buffer, "%s", ((*pFseArray)[index])->p1620->pDonnees->montant_ifd_f);
               else
               	sprintf(buffer, "%s", ((*pFseArray)[index])->p1620->pDonnees->montant_ifd_e);
               break;

            case 3:
            	if (!bEuro)
         			sprintf(buffer, "%s", ((*pFseArray)[index])->p1630->pDonnees->montant_ik_f);
               else
               	sprintf(buffer, "%s", ((*pFseArray)[index])->p1630->pDonnees->montant_ik_e);
               break;
            case 4:                if (!bEuro)                    strcpy(buffer, "");                else                    sprintf(buffer, "%s", ((*pFseArray)[index])->pCCAM->pDonnees->montant_e);                break;
         }

         montant = atoi(buffer);
         sprintf(buffer, "%5d,%02d", montant/100, montant%100);
         dispInfoItem.SetText(buffer);
         break;
   } // fin du switch
}

//// Initialise la liste (ListWindow) des fiches Fact
//
void
CreerFicheComptDialog::InitListeFact()
{
	TListWindColumn colDate("Date", 80, TListWindColumn::Left, 0);
  	pListeFact->InsertColumn(0, colDate);
   TListWindColumn colMontant("Montant", 80, TListWindColumn::Right, 1);
  	pListeFact->InsertColumn(1, colMontant);
   TListWindColumn colModePaie("Mode", 50, TListWindColumn::Left, 2);
  	pListeFact->InsertColumn(2, colModePaie);
  	TListWindColumn colOrga("Organisme", 80, TListWindColumn::Left, 3);
  	pListeFact->InsertColumn(3, colOrga);
}

//
// Affiche dans la liste les donnees du tableau
//
void
CreerFicheComptDialog::AfficheListeFact()
{
   char dateFact[255];

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	pListeFact->DeleteAllItems();

	for (int i = nbFact - 1; i >= 0; i--)
   {
		donne_date(((*pFactArray)[i])->pDonnees->date_paie, dateFact, sLang) ;
   	TListWindItem Item(dateFact, 0) ;
      pListeFact->InsertItem(Item) ;
   }
}

//// DispInfoListeFact : Pour afficher les subitems (colonnes 2 � n)
// de la ListWindow des Fact
//
void
CreerFicheComptDialog::DispInfoListeFact(TLwDispInfoNotify& dispInfo)
{
	const int 	BufLen = 255;
   static char buffer[BufLen];
   TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item;
   int 			index;
   int			montant;

   index = dispInfoItem.GetIndex();

   // Affiche les informations en fonction de la colonne

   switch (dispInfoItem.GetSubItem())
   {
   	case 1: // montant

         montant = atoi(((*pFactArray)[index])->pDonnees->montant);

         if (!strcmp(((*pFactArray)[index])->pDonnees->unite, "LOC"))
         {
         	if (bEuro)
            	montant = dtoi(double(montant) / (pVar->parite));
         }
         else // cas montant en euro
         {
         	if (!bEuro)
            	montant = dtoi(double(montant) * (pVar->parite));
         }

         sprintf(buffer, "%5d,%02d", montant/100, montant%100);
         dispInfoItem.SetText(buffer);
         break;

      case 2: 	// mode de paiement

         sprintf(buffer, "%s", ((*pFactArray)[index])->pDonnees->mode_paie);
         dispInfoItem.SetText(buffer);
         break;

      case 3:	// organisme

      	sprintf(buffer, "%s", ((*pFactArray)[index])->pDonnees->libelle);
         dispInfoItem.SetText(buffer);
         break;
   } // fin du switch
}

//
// Initialise la liste (ListWindow) des fiches TPayant
//
void
CreerFicheComptDialog::InitListeTP()
{
  	TListWindColumn colOrga("Organisme", 80, TListWindColumn::Left, 0);
  	pListeTP->InsertColumn(0, colOrga);
   TListWindColumn colResteDu("Reste d�", 80, TListWindColumn::Left, 1);
  	pListeTP->InsertColumn(1, colResteDu);
}

//
// Affiche dans la liste les donnees du tableau
//
void
CreerFicheComptDialog::AfficheListeTP()
{
   char orga[255];

	pListeTP->DeleteAllItems();

	for (int i = nbTP - 1; i >= 0; i--)
   {
		strcpy(orga, ((*pTPArray)[i])->pDonnees->libelle);
   	TListWindItem Item(orga, 0);
      pListeTP->InsertItem(Item);
   }
}

//
// DispInfoListeTP : Pour afficher les subitems (colonnes 2 � n)
// de la ListWindow des TPayant
//
void
CreerFicheComptDialog::DispInfoListeTP(TLwDispInfoNotify& dispInfo)
{
	const int 	BufLen = 255;
   static char buffer[BufLen];
   TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item;
   int 			index;
   int			montant;

   index = dispInfoItem.GetIndex();

   // Affiche les informations en fonction de la colonne

   switch (dispInfoItem.GetSubItem())
   {
   	case 1: // montant

         montant = atoi(((*pTPArray)[index])->pDonnees->reste_du);

         if (!strcmp(((*pTPArray)[index])->pDonnees->monnaie, "LOC"))
         {
         	if (bEuro)
            	montant = dtoi(double(montant) / (pVar->parite));
         }
         else // cas montant en euro
         {
         	if (!bEuro)
            	montant = dtoi(double(montant) * (pVar->parite));
         }

         sprintf(buffer, "%5d,%02d", montant/100, montant%100);
         dispInfoItem.SetText(buffer);
         break;

   } // fin du switch
}

//***************************************************************************
//
// 					 			M�thodes InitDataxxx
//
//			Lancement des dialogues fils Fsexxx, Fact et TPayant
//
//***************************************************************************

//
// Fonction InitDataFse1610 pour la cr�ation / modification des fiches 1610
//
bool
CreerFicheComptDialog::InitDataFse1610(NSFse1610Info* pFse1610Info, bool bCreer)
{
	CreerFse1610Dialog* pFse1610Dlg = new CreerFse1610Dialog(this, pContexte, pVar) ;

	if (!bCreer)	// on est en modification
		*(pFse1610Dlg->pData) = *(pFse1610Info->pDonnees) ;

	if ((pFse1610Dlg->Execute()) == IDCANCEL)
	{
		delete pFse1610Dlg ;
   	return false ;
	}

	// on stocke les donnees du dialogue dans les Data
	*(pFse1610Info->pDonnees) = *(pFse1610Dlg->pData) ;

	delete pFse1610Dlg ;

	return true ;
}


//
// Fonction InitDataFse1620 pour la cr�ation / modification des fiches 1620
//
bool
CreerFicheComptDialog::InitDataFse1620(NSFse1620Info* pFse1620Info, bool bCreer)
{
	CreerFse1620Dialog* pFse1620Dlg;

	pFse1620Dlg = new CreerFse1620Dialog(this, pContexte, pVar);

   if (!bCreer)	// on est en modification
   {
   	*(pFse1620Dlg->pData) = *(pFse1620Info->pDonnees);
   }

   if ((pFse1620Dlg->Execute()) == IDCANCEL)
   {
   	delete pFse1620Dlg;
   	return false;
   }

   // on stocke les donnees du dialogue dans les Data
   *(pFse1620Info->pDonnees) = *(pFse1620Dlg->pData);

   delete pFse1620Dlg;

   return true;
}

//
// Fonction InitDataFse1630 pour la cr�ation / modification des fiches 1630
//
bool
CreerFicheComptDialog::InitDataFse1630(NSFse1630Info* pFse1630Info, bool bCreer)
{
	CreerFse1630Dialog* pFse1630Dlg;

	pFse1630Dlg = new CreerFse1630Dialog(this, pContexte, pVar);

   if (!bCreer)	// on est en modification
   {
   	*(pFse1630Dlg->pData) = *(pFse1630Info->pDonnees);
   }

   if ((pFse1630Dlg->Execute()) == IDCANCEL)
   {
   	delete pFse1630Dlg;
   	return false;
   }

   // on stocke les donnees du dialogue dans les Data
   *(pFse1630Info->pDonnees) = *(pFse1630Dlg->pData);

   delete pFse1630Dlg;

   return true;
}boolCreerFicheComptDialog::InitDataFseCCAM(NSFseCCAMInfo* pFseCCAMInfo, bool bCreer){	CreerFseCCAMDialog* pFseCCAMDlg = new CreerFseCCAMDialog(this, pContexte, pVar, string(pData->examen)) ;
	if (!bCreer)	// on est en modification		*(pFseCCAMDlg->pData) = *(pFseCCAMInfo->pDonnees) ;

	if ((pFseCCAMDlg->Execute()) == IDCANCEL)	{
		delete pFseCCAMDlg ;
		return false ;
	}

	// on stocke les donnees du dialogue dans les Data	*(pFseCCAMInfo->pDonnees) = *(pFseCCAMDlg->pData) ;

	delete pFseCCAMDlg ;
	return true ;}
//// Fonction InitDataFact pour la creation / modification des fiches Fact
//
bool
CreerFicheComptDialog::InitDataFact(NSFactInfo* pFactInfo, bool bCreer)
{
	CreerFicheFactDialog* pFactDlg;

  pFactDlg = new CreerFicheFactDialog(this, pContexte, pVar);

  // on est en modification ou bien on a pr�-initialis� la fiche pour un d�biteur
  if ((false == bCreer) || (string("") != string(pFactInfo->pDonnees->organisme)))
    *(pFactDlg->pData) = *(pFactInfo->pDonnees);

  if (IDCANCEL == (pFactDlg->Execute()))
  {
    delete pFactDlg ;
   	return false ;
  }

  // on stocke les donnees du dialogue dans les Data
  *(pFactInfo->pDonnees) = *(pFactDlg->pData) ;

  delete pFactDlg ;

  return true ;
}

bool
CreerFicheComptDialog::InitDataTP(NSTPayantInfo* pTPInfo, bool bCreer)
{
	CreerTPayantDialog* pTPDlg;

	pTPDlg = new CreerTPayantDialog(this, pContexte, pVar);

    if (!bCreer)	// on est en modification
    {
   	    *(pTPDlg->pData) = *(pTPInfo->pDonnees);
    }

    if ((pTPDlg->Execute()) == IDCANCEL)
    {
   	    delete pTPDlg;
   	    return false;
    }

    // on stocke les donnees du dialogue dans les Data
    *(pTPInfo->pDonnees) = *(pTPDlg->pData);

    delete pTPDlg;

    return true;
}

//***************************************************************************
//
// 					 			M�thodes EnregxxxArray
//
//			Enregistrement des arrays dans les bases respectives
//			Fsexx, Fact et TPayant.
//
//***************************************************************************

bool
CreerFicheComptDialog::EnregFseArray(string sNumCompt)
{
	NSFse1610* 		pFse1610;
   NSFse1620* 		pFse1620;
   NSFse1630* 		pFse1630;
   NSFseCCAM*       pFseCCAM;	NSFse1610Info* pFse1610Info;
   NSFse1620Info* pFse1620Info;
   NSFse1630Info* pFse1630Info;
   NSFseCCAMInfo* pFseCCAMInfo;   string			sCodePrest;
   int				index = 0, nbPrestEnreg;
   int              nbFse1610 = 0, nbFse1620 = 0, nbFse1630 = 0, nbFseCCAM = 0;
   bool				bErreur = false;

   pFse1610 = new NSFse1610(pContexte);
   pFse1610->lastError = pFse1610->open();
   if (pFse1610->lastError != DBIERR_NONE)
   {
   	erreur("Erreur � l'ouverture de la base Fse1610.",standardError, 0) ;
      delete pFse1610;
      return false;
   }

   pFse1620 = new NSFse1620(pContexte);
   pFse1620->lastError = pFse1620->open();
   if (pFse1620->lastError != DBIERR_NONE)
   {
   	erreur("Erreur � l'ouverture de la base Fse1620.",standardError, 0) ;
      delete pFse1610;
      delete pFse1620;
      return false;
   }

   pFse1630 = new NSFse1630(pContexte);
   pFse1630->lastError = pFse1630->open();
   if (pFse1630->lastError != DBIERR_NONE)
   {
   	erreur("Erreur � l'ouverture de la base Fse1630.",standardError, 0) ;
      delete pFse1610;
      delete pFse1620;
      delete pFse1630;
      return false;
   }
   pFseCCAM = new NSFseCCAM(pContexte);   pFseCCAM->lastError = pFseCCAM->open();
   if (pFseCCAM->lastError != DBIERR_NONE)
   {

   	erreur("Erreur � l'ouverture de la base FseCCAM.",standardError, 0) ;
      delete pFse1610;
      delete pFse1620;
      delete pFse1630;      delete pFseCCAM;
      return false;
   }

   pFse1610Info = new NSFse1610Info();
   pFse1620Info = new NSFse1620Info();
   pFse1630Info = new NSFse1630Info();
   pFseCCAMInfo = new NSFseCCAMInfo();

   while ((!bErreur) && (index < nbPrest))
   {
   	switch (((*pFseArray)[index])->typePrest)
   	{
   		// cas Fse1610
      	////////////////////////////////////////////////////////////////////////////////
   		case 1:

   			*pFse1610Info = *(((*pFseArray)[index])->p1610);

            strcpy(pFse1610Info->pDonnees->numcompt, sNumCompt.c_str());

   			sCodePrest = string(pFse1610Info->pDonnees->numcompt) +
         					 string(pFse1610Info->pDonnees->numprest);

   			pFse1610->lastError = pFse1610->chercheClef(&sCodePrest,
      																	"",
																			0,
																			keySEARCHEQ,
																			dbiWRITELOCK);

   			if ((pFse1610->lastError != DBIERR_NONE) && (pFse1610->lastError != DBIERR_RECNOTFOUND))
   			{
   				erreur("Erreur � la recherche de la fiche Fse1610.", standardError, pFse1610->lastError) ;
      			bErreur = true;
            	break;
   			}

   			*(pFse1610->pDonnees) = *(pFse1610Info->pDonnees);

            if (pFse1610->lastError == DBIERR_RECNOTFOUND)
            {
            	pFse1610->lastError = pFse1610->appendRecord();
   				if (pFse1610->lastError != DBIERR_NONE)
   				{
   					erreur("Erreur � l'ajout de la fiche Fse1610.", standardError, pFse1610->lastError) ;
      				bErreur = true;
            		break;
   				}
            }
            else
            {
   				pFse1610->lastError = pFse1610->modifyRecord(TRUE);
   				if (pFse1610->lastError != DBIERR_NONE)
   				{
   					erreur("Erreur � la modification de la fiche Fse1610.", standardError, pFse1610->lastError) ;
      				bErreur = true;
            		break;
   				}
            }

            nbFse1610++;
         	break;

         // cas Fse1620
         ////////////////////////////////////////////////////////////////////////////////
      	case 2:

      		*pFse1620Info = *(((*pFseArray)[index])->p1620);

            strcpy(pFse1620Info->pDonnees->numcompt, sNumCompt.c_str());

   			sCodePrest = string(pFse1620Info->pDonnees->numcompt) +
         					 string(pFse1620Info->pDonnees->numprest);

   			pFse1620->lastError = pFse1620->chercheClef(&sCodePrest,
      																	"",
																			0,
																			keySEARCHEQ,
																			dbiWRITELOCK);

   			if ((pFse1620->lastError != DBIERR_NONE) && (pFse1620->lastError != DBIERR_RECNOTFOUND))
   			{
   				erreur("Erreur � la recherche de la fiche Fse1620.", standardError, pFse1620->lastError) ;
      			bErreur = true;
            	break;
   			}

	   		*(pFse1620->pDonnees) = *(pFse1620Info->pDonnees);

            if (pFse1620->lastError == DBIERR_RECNOTFOUND)
            {
            	pFse1620->lastError = pFse1620->appendRecord();
   				if (pFse1620->lastError != DBIERR_NONE)
   				{
   					erreur("Erreur � l'ajout de la fiche Fse1620.", standardError, pFse1620->lastError) ;
      				bErreur = true;
            		break;
   				}
            }
            else
            {
   				pFse1620->lastError = pFse1620->modifyRecord(TRUE);
   				if (pFse1620->lastError != DBIERR_NONE)
   				{
   					erreur("Erreur � la modification de la fiche Fse1620.", standardError, pFse1620->lastError) ;
      				bErreur = true;
            		break;
   				}
            }

            nbFse1620++;
         	break;

      	// cas Fse1630
      	////////////////////////////////////////////////////////////////////////////////
      	case 3:

      		*pFse1630Info = *(((*pFseArray)[index])->p1630);

            strcpy(pFse1630Info->pDonnees->numcompt, sNumCompt.c_str());

   			sCodePrest = string(pFse1630Info->pDonnees->numcompt) +
         					 string(pFse1630Info->pDonnees->numprest);

   			pFse1630->lastError = pFse1630->chercheClef(&sCodePrest,
      																	"",
																			0,
																			keySEARCHEQ,
																			dbiWRITELOCK);

   			if ((pFse1630->lastError != DBIERR_NONE) && (pFse1630->lastError != DBIERR_RECNOTFOUND))
   			{
   				erreur("Erreur � la recherche de la fiche Fse1630.", standardError, pFse1630->lastError) ;
      			bErreur = true;
           		break;
   			}

   			*(pFse1630->pDonnees) = *(pFse1630Info->pDonnees);

            if (pFse1630->lastError == DBIERR_RECNOTFOUND)
            {
            	pFse1630->lastError = pFse1630->appendRecord();
   				if (pFse1630->lastError != DBIERR_NONE)
   				{
   					erreur("Erreur � l'ajout de la fiche Fse1630.", standardError, pFse1630->lastError) ;
      				bErreur = true;
            		break;
   				}
            }
            else
            {
   				pFse1630->lastError = pFse1630->modifyRecord(TRUE);
   				if (pFse1630->lastError != DBIERR_NONE)
   				{
   					erreur("Erreur � la modification de la fiche Fse1630.",standardError,pFse1630->lastError);
      				bErreur = true;
            		break;
   				}
            }

            nbFse1630++;
         	break;        // cas FseCCAM
      	////////////////////////////////////////////////////////////////////////////////
      	case 4:

      		*pFseCCAMInfo = *(((*pFseArray)[index])->pCCAM);

            strcpy(pFseCCAMInfo->pDonnees->numcompt, sNumCompt.c_str());

   			sCodePrest = string(pFseCCAMInfo->pDonnees->numcompt) +
         					 string(pFseCCAMInfo->pDonnees->numprest);

   			pFseCCAM->lastError = pFseCCAM->chercheClef(&sCodePrest,
      																	"",
																			0,
																			keySEARCHEQ,
																			dbiWRITELOCK);

   			if ((pFseCCAM->lastError != DBIERR_NONE) && (pFseCCAM->lastError != DBIERR_RECNOTFOUND))
   			{
   				erreur("Erreur � la recherche de la fiche FseCCAM.", standardError, pFseCCAM->lastError) ;
      			bErreur = true;
           		break;
   			}

   			*(pFseCCAM->pDonnees) = *(pFseCCAMInfo->pDonnees);

            if (pFseCCAM->lastError == DBIERR_RECNOTFOUND)
            {
            	pFseCCAM->lastError = pFseCCAM->appendRecord();
   				if (pFseCCAM->lastError != DBIERR_NONE)
   				{
   					erreur("Erreur � l'ajout de la fiche FseCCAM.", standardError, pFseCCAM->lastError) ;
      				bErreur = true;
            		break;
   				}
            }
            else
            {
   				pFseCCAM->lastError = pFseCCAM->modifyRecord(TRUE);
   				if (pFseCCAM->lastError != DBIERR_NONE)
   				{
   					erreur("Erreur � la modification de la fiche FseCCAM.",standardError,pFseCCAM->lastError);
      				bErreur = true;
            		break;
   				}
            }

            nbFseCCAM++;
         	break;
   	} 		// fin du switch

      index++;
   }	// fin du while

   delete pFse1610Info;
   delete pFse1620Info;
   delete pFse1630Info;   delete pFseCCAMInfo;

   /// Suppression des FSE1610 suppl�mentaires
   sCodePrest = sNumCompt + string(FSE1610_NUMPREST_LEN, '0');

   pFse1610->lastError = pFse1610->chercheClef(&sCodePrest,
                                                    "",
													0,
													keySEARCHGEQ,
													dbiWRITELOCK);

   if ((pFse1610->lastError != DBIERR_NONE) && (pFse1610->lastError != DBIERR_EOF))
   {
        erreur("Erreur � la recherche de la fiche Fse1610.",standardError,pFse1610->lastError);
      	bErreur = true;
   }

   nbPrestEnreg = 0;

   while ((!bErreur) && (pFse1610->lastError == DBIERR_NONE))
   {
        pFse1610->lastError = pFse1610->getRecord();
		if (pFse1610->lastError != DBIERR_NONE)
		{
			erreur("Erreur de lecture dans la base Fse1610.", standardError, pFse1610->lastError);
			bErreur = true;
            break;
		}

        // condition d'arret
        if (!(string(pFse1610->pDonnees->numcompt) == sNumCompt))
            break;

        nbPrestEnreg++;

        if (nbPrestEnreg > nbFse1610)
        {
            pFse1610->lastError = pFse1610->deleteRecord();
            if (pFse1610->lastError != DBIERR_NONE)
            {
                erreur("Erreur � la destruction de la fiche Fse1610.",standardError,pFse1610->lastError);
                bErreur = true;
                break;
            }
        }

        pFse1610->lastError = pFse1610->suivant(dbiWRITELOCK);
		if ((pFse1610->lastError != DBIERR_NONE) && (pFse1610->lastError != DBIERR_EOF))
      	{
			erreur("Erreur d'acc�s � la fiche Fse1610 suivante.", standardError, pFse1610->lastError);
			bErreur = true;
            break;
      	}
   }

   /// Suppression des FSE1620 suppl�mentaires
   sCodePrest = sNumCompt + string(FSE1620_NUMPREST_LEN, '0');

   pFse1620->lastError = pFse1620->chercheClef(&sCodePrest,
                                                    "",
													0,
													keySEARCHGEQ,
													dbiWRITELOCK);

   if ((pFse1620->lastError != DBIERR_NONE) && (pFse1620->lastError != DBIERR_EOF))
   {
        erreur("Erreur � la recherche de la fiche Fse1620.",standardError,pFse1620->lastError);
      	bErreur = true;
   }

   nbPrestEnreg = 0;

   while ((!bErreur) && (pFse1620->lastError == DBIERR_NONE))
   {
        pFse1620->lastError = pFse1620->getRecord();
		if (pFse1620->lastError != DBIERR_NONE)
		{
			erreur("Erreur de lecture dans la base Fse1620.", standardError, pFse1620->lastError);
			bErreur = true;
            break;
		}

        // condition d'arret
        if (!(string(pFse1620->pDonnees->numcompt) == sNumCompt))
            break;

        nbPrestEnreg++;

        if (nbPrestEnreg > nbFse1620)
        {
            pFse1620->lastError = pFse1620->deleteRecord();
            if (pFse1620->lastError != DBIERR_NONE)
            {
                erreur("Erreur � la destruction de la fiche Fse1620.",standardError,pFse1620->lastError);
                bErreur = true;
                break;
            }
        }

        pFse1620->lastError = pFse1620->suivant(dbiWRITELOCK);
		if ((pFse1620->lastError != DBIERR_NONE) && (pFse1620->lastError != DBIERR_EOF))
      	{
			erreur("Erreur d'acc�s � la fiche Fse1620 suivante.", standardError, pFse1620->lastError);
			bErreur = true;
            break;
      	}
   }

   /// Suppression des FSE1630 suppl�mentaires
   sCodePrest = sNumCompt + string(FSE1630_NUMPREST_LEN, '0');

   pFse1630->lastError = pFse1630->chercheClef(&sCodePrest,
                                                    "",
													0,
													keySEARCHGEQ,
													dbiWRITELOCK);

   if ((pFse1630->lastError != DBIERR_NONE) && (pFse1630->lastError != DBIERR_EOF))
   {
        erreur("Erreur � la recherche de la fiche Fse1630.",standardError,pFse1630->lastError);
      	bErreur = true;
   }

   nbPrestEnreg = 0;

   while ((!bErreur) && (pFse1630->lastError == DBIERR_NONE))
   {
        pFse1630->lastError = pFse1630->getRecord();
		if (pFse1630->lastError != DBIERR_NONE)
		{
			erreur("Erreur de lecture dans la base Fse1630.", standardError, pFse1630->lastError);
			bErreur = true;
            break;
		}

        // condition d'arret
        if (!(string(pFse1630->pDonnees->numcompt) == sNumCompt))
            break;

        nbPrestEnreg++;

        if (nbPrestEnreg > nbFse1630)
        {
            pFse1630->lastError = pFse1630->deleteRecord();
            if (pFse1630->lastError != DBIERR_NONE)
            {
                erreur("Erreur � la destruction de la fiche Fse1630.",standardError,pFse1630->lastError);
                bErreur = true;
                break;
            }
        }

        pFse1630->lastError = pFse1630->suivant(dbiWRITELOCK);
		if ((pFse1630->lastError != DBIERR_NONE) && (pFse1630->lastError != DBIERR_EOF))
      	{
			erreur("Erreur d'acc�s � la fiche Fse1630 suivante.", standardError, pFse1630->lastError);
			bErreur = true;
            break;
      	}
   }   /// Suppression des FSECCAM suppl�mentaires
   sCodePrest = sNumCompt + string(FSECCAM_NUMPREST_LEN, '0');

   pFseCCAM->lastError = pFseCCAM->chercheClef(&sCodePrest,
                                                    "",
													0,
													keySEARCHGEQ,
													dbiWRITELOCK);

   if ((pFseCCAM->lastError != DBIERR_NONE) && (pFseCCAM->lastError != DBIERR_EOF))
   {
        erreur("Erreur � la recherche de la fiche FseCCAM.",standardError,pFseCCAM->lastError);
      	bErreur = true;
   }

   nbPrestEnreg = 0;

   while ((!bErreur) && (pFseCCAM->lastError == DBIERR_NONE))
   {
        pFseCCAM->lastError = pFseCCAM->getRecord();
		if (pFseCCAM->lastError != DBIERR_NONE)
		{
			erreur("Erreur de lecture dans la base FseCCAM.", standardError, pFseCCAM->lastError);
			bErreur = true;
            break;
		}

        // condition d'arret
        if (!(string(pFseCCAM->pDonnees->numcompt) == sNumCompt))
            break;

        nbPrestEnreg++;

        if (nbPrestEnreg > nbFseCCAM)
        {
            pFseCCAM->lastError = pFseCCAM->deleteRecord();
            if (pFseCCAM->lastError != DBIERR_NONE)
            {
                erreur("Erreur � la destruction de la fiche FseCCAM.",standardError,pFseCCAM->lastError);
                bErreur = true;
                break;
            }
        }

        pFseCCAM->lastError = pFseCCAM->suivant(dbiWRITELOCK);
		if ((pFseCCAM->lastError != DBIERR_NONE) && (pFseCCAM->lastError != DBIERR_EOF))
      	{
			erreur("Erreur d'acc�s � la fiche FseCCAM suivante.", standardError, pFseCCAM->lastError);
			bErreur = true;
            break;
      	}
   }

   pFse1610->lastError = pFse1610->close();
   if (pFse1610->lastError != DBIERR_NONE)
   	erreur("Erreur � la fermeture de la base Fse1610.",standardError,pFse1610->lastError);

   pFse1620->lastError = pFse1620->close();
   if (pFse1620->lastError != DBIERR_NONE)
   	erreur("Erreur � la fermeture de la base Fse1620.",standardError,pFse1620->lastError);

   pFse1630->lastError = pFse1630->close();
   if (pFse1630->lastError != DBIERR_NONE)
   	erreur("Erreur � la fermeture de la base Fse1630.",standardError,pFse1630->lastError);   pFseCCAM->lastError = pFseCCAM->close();
   if (pFseCCAM->lastError != DBIERR_NONE)
   	erreur("Erreur � la fermeture de la base FseCCAM.",standardError,pFseCCAM->lastError);

   delete pFse1610;
   delete pFse1620;
   delete pFse1630;   delete pFseCCAM;

   if (bErreur)
   	return false;

   return true;
}
boolCreerFicheComptDialog::EnregFactArray(string sNumCompt)
{
    NSFactInfo* pFactInfo = new NSFactInfo();
    string		sCodeFact;
    int 		index = 0;
    int         nbFactEnreg;
    bool		bErreur = false;

    NSFact* pFact = new NSFact(pContexte);

	// on ajoute les Data � la base des Fact
    pFact->lastError = pFact->open();
    if (pFact->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur � l'ouverture de la base Fact.",standardError, 0) ;
        delete pFact;
        delete pFactInfo;
        return false;
    }

    while (index < nbFact)
    {
   	    *pFactInfo = *((*pFactArray)[index]);

        strcpy(pFactInfo->pDonnees->numcompt, sNumCompt.c_str());

   	    sCodeFact = string(pFactInfo->pDonnees->numcompt) +
      				            string(pFactInfo->pDonnees->numero);

   	    pFact->lastError = pFact->chercheClef(&sCodeFact,
      										  "",
											  0,
											  keySEARCHEQ,
											  dbiWRITELOCK);

        if ((pFact->lastError != DBIERR_NONE) && (pFact->lastError != DBIERR_RECNOTFOUND))
        {
      	    erreur("Erreur � la recherche de la fiche Fact.", standardError, pFact->lastError);
            bErreur = true;
            break;
        }

        *(pFact->pDonnees) = *(pFactInfo->pDonnees);

        if (pFact->lastError == DBIERR_RECNOTFOUND)
        {
      	    pFact->lastError = pFact->appendRecord();
            if (pFact->lastError != DBIERR_NONE)
            {
         	    erreur("Erreur � l'ajout de la fiche Fact.", standardError, pFact->lastError);
                bErreur = true;
                break;
            }
        }
        else
        {
      	    pFact->lastError = pFact->modifyRecord(TRUE);
            if (pFact->lastError != DBIERR_NONE)
            {
         	    erreur("Erreur � la modification de la fiche Fact.", standardError, pFact->lastError);
                bErreur = true;
                break;
            }
        }

        index++;
    }  // fin du while

    /// Suppression des FACT suppl�mentaires
    sCodeFact = sNumCompt + string(FACT_NUMERO_LEN, '0');

    pFact->lastError = pFact->chercheClef(&sCodeFact,
                                          "",
                                          0,
                                          keySEARCHGEQ,
                                          dbiWRITELOCK);

    if ((pFact->lastError != DBIERR_NONE) && (pFact->lastError != DBIERR_EOF))
    {
        erreur("Erreur � la recherche de la fiche Fact.",standardError,pFact->lastError);
      	bErreur = true;
    }

    nbFactEnreg = 0;

    while ((!bErreur) && (pFact->lastError == DBIERR_NONE))
    {
        pFact->lastError = pFact->getRecord();
		if (pFact->lastError != DBIERR_NONE)
		{
			erreur("Erreur de lecture dans la base Fact.", standardError, pFact->lastError);
			bErreur = true;
            break;
		}

        // condition d'arret
        if (!(string(pFact->pDonnees->numcompt) == sNumCompt))
            break;

        nbFactEnreg++;

        if (nbFactEnreg > nbFact)
        {
            pFact->lastError = pFact->deleteRecord();
            if (pFact->lastError != DBIERR_NONE)
            {
                erreur("Erreur � la destruction de la fiche Fact.",standardError,pFact->lastError);
                bErreur = true;
                break;
            }
        }

        pFact->lastError = pFact->suivant(dbiWRITELOCK);
		if ((pFact->lastError != DBIERR_NONE) && (pFact->lastError != DBIERR_EOF))
      	{
			erreur("Erreur d'acc�s � la fiche Fact suivante.", standardError, pFact->lastError);
			bErreur = true;
            break;
      	}
    }

    pFact->lastError = pFact->close();
    if (pFact->lastError != DBIERR_NONE)
   	    erreur("Erreur � la fermeture de la base Fact.", standardError, pFact->lastError);

    delete pFact;
    delete pFactInfo;

    if (bErreur)
   	    return false;

    return true;
}

bool
CreerFicheComptDialog::EnregTPArray(string sNumCompt)
{
    NSTPayantInfo* pTPayantInfo = new NSTPayantInfo();
    string			sCodeTP;
    int 				index = 0;
    int              nbTPEnreg;
    bool				bErreur = false;

    NSTPayant* pTPayant = new NSTPayant(pContexte);

	// on ajoute les Data � la base des TPayant
    pTPayant->lastError = pTPayant->open();
    if (pTPayant->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur � l'ouverture de la base TPayant.",standardError, 0) ;
        delete pTPayant;
        delete pTPayantInfo;
        return false;
    }

    while (index < nbTP)
    {
   	    *pTPayantInfo = *((*pTPArray)[index]);

        strcpy(pTPayantInfo->pDonnees->numcompt, sNumCompt.c_str());

   	    sCodeTP = string(pTPayantInfo->pDonnees->numcompt) +
      			        string(pTPayantInfo->pDonnees->numero);

   	    pTPayant->lastError = pTPayant->chercheClef(&sCodeTP,
      												"",
													0,
													keySEARCHEQ,
													dbiWRITELOCK);

        if ((pTPayant->lastError != DBIERR_NONE) && (pTPayant->lastError != DBIERR_RECNOTFOUND))
        {
      	    erreur("Erreur � la recherche de la fiche TPayant.", standardError, pTPayant->lastError);
            bErreur = true;
            break;
        }

        *(pTPayant->pDonnees) = *(pTPayantInfo->pDonnees);

        // on met � jour okpaye
        if (atoi(pTPayant->pDonnees->reste_du) == 0)
      	    strcpy(pTPayant->pDonnees->okpaye, "1");
        else
      	    strcpy(pTPayant->pDonnees->okpaye, "0");

        if (pTPayant->lastError == DBIERR_RECNOTFOUND)
        {
      	    pTPayant->lastError = pTPayant->appendRecord();
            if (pTPayant->lastError != DBIERR_NONE)
            {
         	    erreur("Erreur � l'ajout de la fiche TPayant.", standardError, pTPayant->lastError);
                bErreur = true;
                break;
            }
        }
        else
        {
      	    pTPayant->lastError = pTPayant->modifyRecord(TRUE);
            if (pTPayant->lastError != DBIERR_NONE)
            {
         	    erreur("Erreur � la modification de la fiche TPayant.", standardError, pTPayant->lastError);
                bErreur = true;
                break;
            }
        }

        index++;
    }  // fin du while

    /// Suppression des Tiers-payants suppl�mentaires
    sCodeTP = sNumCompt + string(TPAY_NUMERO_LEN, '0');

    pTPayant->lastError = pTPayant->chercheClef(&sCodeTP,
                                                "",
											    0,
											    keySEARCHGEQ,
											    dbiWRITELOCK);

    if ((pTPayant->lastError != DBIERR_NONE) && (pTPayant->lastError != DBIERR_EOF))
    {
        erreur("Erreur � la recherche de la fiche TPayant.",standardError,pTPayant->lastError);
      	bErreur = true;
    }

    nbTPEnreg = 0;

    while ((!bErreur) && (pTPayant->lastError == DBIERR_NONE))
    {
        pTPayant->lastError = pTPayant->getRecord();
		if (pTPayant->lastError != DBIERR_NONE)
		{
			erreur("Erreur de lecture dans la base TPayant.", standardError, pTPayant->lastError);
			bErreur = true;
            break;
		}

        // condition d'arret
        if (!(string(pTPayant->pDonnees->numcompt) == sNumCompt))
            break;

        nbTPEnreg++;

        if (nbTPEnreg > nbTP)
        {
            pTPayant->lastError = pTPayant->deleteRecord();
            if (pTPayant->lastError != DBIERR_NONE)
            {
                erreur("Erreur � la destruction de la fiche TPayant.",standardError,pTPayant->lastError);
                bErreur = true;
                break;
            }
        }

        pTPayant->lastError = pTPayant->suivant(dbiWRITELOCK);
		if ((pTPayant->lastError != DBIERR_NONE) && (pTPayant->lastError != DBIERR_EOF))
      	{
			erreur("Erreur d'acc�s � la fiche TPayant suivante.", standardError, pTPayant->lastError);
			bErreur = true;
            break;
      	}
   }

   pTPayant->lastError = pTPayant->close();
   if (pTPayant->lastError != DBIERR_NONE)
   	erreur("Erreur � la fermeture de la base TPayant.", standardError, pTPayant->lastError);

   delete pTPayant;
   delete pTPayantInfo;

   if (bErreur)
   	return false;

   return true;
}

//***************************************************************************

//
// 					 	 M�thodes de gestion des champs Edit
//
//			SommeDue, Depass, Paye, DateC, HeureC
//			+ fonction SwitchFFEuro.
//
//***************************************************************************

void
CreerFicheComptDialog::AfficheSommeDue()
{
    int  total = 0, prest, dep;
    char affDepass[9] = "";
    char affSommeDue[9] = "";

    for (int index = 0; index < nbPrest; index++)
    {
   	    switch (((*pFseArray)[index])->typePrest)
        {
      	    case 1:
         	    if (pVar->monnaieRef == MONNAIE_LOCALE)
         		    prest = atoi(((*pFseArray)[index])->p1610->pDonnees->montant_f);
                else
					prest = atoi(((*pFseArray)[index])->p1610->pDonnees->montant_e);
                break;

            case 2:
         	    if (pVar->monnaieRef == MONNAIE_LOCALE)
         		    prest = atoi(((*pFseArray)[index])->p1620->pDonnees->montant_ifd_f);
                else
            	    prest = atoi(((*pFseArray)[index])->p1620->pDonnees->montant_ifd_e);
                break;

            case 3:
         	    if (pVar->monnaieRef == MONNAIE_LOCALE)
         		    prest = atoi(((*pFseArray)[index])->p1630->pDonnees->montant_ik_f);
                else
            	    prest = atoi(((*pFseArray)[index])->p1630->pDonnees->montant_ik_e);
                break;            case 4:                if (pVar->monnaieRef == MONNAIE_LOCALE)
         		    prest = 0;
                else
            	    prest = atoi(((*pFseArray)[index])->pCCAM->pDonnees->montant_e);
                break;
        }

        total = total + prest;
    }

    sommeTheorique = total;

    // on reprend le d�passement
    // mais il n'est pas recalcul�
    if (pVar->monnaieRef == MONNAIE_LOCALE)
   	    dep = atoi(pData->depassFranc);
    else
   	    dep = atoi(pData->depassEuro);

    if (pVar->monnaieRef == MONNAIE_LOCALE)
    {
        itoa(total + dep, pData->duFranc, 10);
        itoa(dtoi(double(total + dep) / pVar->parite), pData->duEuro, 10);
    }
    else // Ref : euro
    {
   	    itoa(total + dep, pData->duEuro, 10);
        itoa(dtoi(double(total + dep) * pVar->parite), pData->duFranc, 10);
    }

    if (bEuro)
    {
   	    strcpy(affSommeDue, pData->duEuro);
        strcpy(affDepass, pData->depassEuro);
    }
    else
    {
   	    strcpy(affSommeDue, pData->duFranc);
        strcpy(affDepass, pData->depassFranc);
    }

    pSommeDue->setSomme(string(affSommeDue));
    pDepass->setSomme(string(affDepass));
}

void
CreerFicheComptDialog::AfficheDepass()
{
    string 	sSommeReelle;
    int     sommeDue;
    int 	diff = 0;
    char	affDepass[9] = "";

    pSommeDue->getSomme(&sSommeReelle);
    sommeDue = atoi(sSommeReelle.c_str());

    // on ne traite pas les d�passements n�gatifs
    if (sommeDue >= sommeTheorique)
    {
        diff = sommeDue - sommeTheorique;
        itoa(diff, affDepass, 10);

        pDepass->setSomme(string(affDepass));
    }
    else
   	    pDepass->SetText("");

    // on conserve la somme due et le depassement dans les deux monnaies
    if (!bEuro)
    {
   	    itoa(sommeDue, pData->duFranc, 10);
        itoa(dtoi(double(sommeDue) / pVar->parite), pData->duEuro, 10);
        itoa(diff, pData->depassFranc, 10);
        itoa(dtoi(double(diff) / pVar->parite), pData->depassEuro, 10);
    }
    else
    {
   	    itoa(sommeDue, pData->duEuro, 10);
        itoa(dtoi(double(sommeDue) * pVar->parite), pData->duFranc, 10);
        itoa(diff, pData->depassEuro, 10);
        itoa(dtoi(double(diff) * pVar->parite), pData->depassFranc, 10);
    }
}

void
CreerFicheComptDialog::SwitchFFEuro()
{
    if (bEuro)
   	    bEuro = false;
    else
   	    bEuro = true;

    AfficheListeFse();
    AfficheListeFact();
    AfficheSommeDue();
    AffichePaye();
}
voidCreerFicheComptDialog::AffichePaye()
{
    string  sUnite;
    int		sommeLoc = 0, sommeEuro = 0;
    int 	sommeDue;
    char    paye[9] = "";
    char    reste[9] = "";

	// on parcourt l'array des fiches fact
    // et on affiche la somme dans pPaye

    for (int i = 0; i < nbFact; i++)
    {
   	    sUnite = string(((*pFactArray)[i])->pDonnees->unite);

        if (sUnite == "LOC")   // unite locale (FF ou FB)
        {
      	    sommeLoc = sommeLoc + atoi(((*pFactArray)[i])->pDonnees->montant);
        }
        else // cas Euro
        {
      	    sommeEuro = sommeEuro + atoi(((*pFactArray)[i])->pDonnees->montant);
        }
    }

    double sommeTotaleLoc  = double(sommeLoc) + (double(sommeEuro) * (pVar->parite));
    int    iTotLoc = dtoi(sommeTotaleLoc);

    double sommeTotaleEuro = double(sommeEuro) + (double(sommeLoc) / (pVar->parite));
    int    iTotEuro = dtoi(sommeTotaleEuro);

    // on met les data � jour
    itoa(iTotLoc, pData->payeFranc, 10);
    itoa(iTotEuro, pData->payeEuro, 10);

    if (!bEuro)
    {
   	    sommeDue = atoi(pData->duFranc);
        itoa(sommeDue - iTotLoc, reste, 10);
   	    strcpy(paye, pData->payeFranc);
    }
    else
    {
   	    sommeDue = atoi(pData->duEuro);
        itoa(sommeDue - iTotEuro, reste, 10);
   	    strcpy(paye, pData->payeEuro);
    }

    pPaye->setSomme(string(paye));
    pResteDu->setSomme(string(reste));

    // on affiche la liste des tiers-payant pour les reste-dus
    AfficheListeTP();
}

voidCreerFicheComptDialog::MajDateC()
{
	string sDate ;

	pDate->getDate(&sDate) ;
	strcpy(pData->date, sDate.c_str()) ;

	// on remet � jour la variable compta
	pVar->sDateC = sDate ;

	// on reporte la modif dans la fact 0
	if (nbFact)
		strcpy((*pFactArray)[0]->pDonnees->date_paie, sDate.c_str()) ;
}

voidCreerFicheComptDialog::MajHeureC()
{
	string sHeure ;

	pHeure->getHeure(&sHeure) ;
	strcpy(pData->heure, sHeure.c_str()) ;

	// on remet � jour la variable compta
	pVar->sHeureC = sHeure ;
}

voidCreerFicheComptDialog::RetrouveCorresp(string& sLibelle)
{
	NSPersonInfo* pUtil = pContexte->getPersonArray()->getPerson(codeCorresp, pidsUtilisat) ;
	sLibelle = pUtil->sCivilite ;
}

//// Decremente le reste du de l'organisme du montant sp�cifi�
//
void
CreerFicheComptDialog::DecrementeResteDu(char* codeOrga, char* montant, char* unite)
{
	int 	resteDu, paiement;
   char	uniteDu[4];

	for (NSTPIter i = pTPArray->begin(); i != pTPArray->end(); i++)
   {
   	if (!strcmp((*i)->pDonnees->organisme, codeOrga))
      {
      	resteDu = atoi((*i)->pDonnees->reste_du);
         paiement = atoi(montant);
         strcpy(uniteDu, (*i)->pDonnees->monnaie);

         if (!strcmp(uniteDu, "LOC"))
         {
         	if (!strcmp(unite, "LOC"))
            	resteDu -= paiement;
            else
            	resteDu -= dtoi(double(paiement) * pVar->parite);
         }
         else
         {
         	if (!strcmp(unite, "EUR"))
            	resteDu -= paiement;
            else
            	resteDu -= dtoi(double(paiement) / pVar->parite);
         }

         // on replace le nouveau reste du
         itoa(resteDu, (*i)->pDonnees->reste_du, 10);
         break;
      }
   }
}


//
// Incremente le reste du de l'organisme du montant sp�cifi�
//
void
CreerFicheComptDialog::IncrementeResteDu(char* codeOrga, char* montant, char* unite)
{
	int 	resteDu, paiement;
   char	uniteDu[4];

	for (NSTPIter i = pTPArray->begin(); i != pTPArray->end(); i++)
   {
   	if (!strcmp((*i)->pDonnees->organisme, codeOrga))
      {
      	resteDu = atoi((*i)->pDonnees->reste_du);
         paiement = atoi(montant);
         strcpy(uniteDu, (*i)->pDonnees->monnaie);

         if (!strcmp(uniteDu, "LOC"))
         {
         	if (!strcmp(unite, "LOC"))
            	resteDu += paiement;
            else
            	resteDu += dtoi(double(paiement) * pVar->parite);
         }
         else
         {
         	if (!strcmp(unite, "EUR"))
            	resteDu += paiement;
            else
            	resteDu += dtoi(double(paiement) / pVar->parite);
         }

         // on replace le nouveau reste du
         itoa(resteDu, (*i)->pDonnees->reste_du, 10);
         break;
      }
   }
}

int
CreerFicheComptDialog::SommeResteDu()
{
	int somme = 0;

   for (NSTPIter i = pTPArray->begin(); i != pTPArray->end(); i++)
   {
   	if (!strcmp((*i)->pDonnees->monnaie, "LOC"))
      {
      	if (!bEuro)		// calcul en francs
         	somme += atoi((*i)->pDonnees->reste_du);
         else				// calcul en Euros
         	somme += dtoi(double(atoi((*i)->pDonnees->reste_du)) / pVar->parite);
      }
      else // le reste du est en euros
      {
      	if (bEuro)		// calcul en Euros
         	somme += atoi((*i)->pDonnees->reste_du);
         else				// calcul en francs
         	somme += dtoi(double(atoi((*i)->pDonnees->reste_du)) * pVar->parite);
      }
   }

   return somme;
}

bool
CreerFicheComptDialog::ExisteExamen(string sCodePat, string sDateExam, string sCodeExam)
{
	bool 		bExiste = false;
	NSCompt* 	pCompt = new NSCompt(pContexte);
	//
	// Ouverture du fichier
	//
	pCompt->lastError = pCompt->open();
	if (pCompt->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture de la base compt.db.", standardError, pCompt->lastError);
		delete pCompt;
		return false;
	}

   	pCompt->lastError = pCompt->chercheClef(&sDateExam,
    										  "DATE_COMPT",
											  NODEFAULTINDEX,
											  keySEARCHGEQ,
											  dbiWRITELOCK);

   	if ((pCompt->lastError != DBIERR_NONE) && (pCompt->lastError != DBIERR_EOF))
	{
		erreur("Erreur de positionnement dans la base compt.db.", standardError, pCompt->lastError);
		pCompt->close();
		delete pCompt;
		return false;
	}

   	while (pCompt->lastError != DBIERR_EOF)
   	{
   		pCompt->lastError = pCompt->getRecord();
		if (pCompt->lastError != DBIERR_NONE)
		{
			erreur("Erreur de lecture dans la base compt.db.", standardError, pCompt->lastError);
			pCompt->close();
			delete pCompt;
			return false;
		}

        // si on a d�pass� la date : on sort...
      	if (atoi(pCompt->pDonnees->date) > atoi(sDateExam.c_str()))
        	break;

        if ((!strcmp(pCompt->pDonnees->date, sDateExam.c_str())) &&
        	(!strcmp(pCompt->pDonnees->patient, sCodePat.c_str())) &&
            (!strcmp(pCompt->pDonnees->examen, sCodeExam.c_str())))
        {
        	bExiste = true;
            break;
        }

      	// on se positionne sur la fiche compt suivante
      	pCompt->lastError = pCompt->suivant(dbiWRITELOCK);
		if ((pCompt->lastError != DBIERR_NONE) && (pCompt->lastError != DBIERR_EOF))
      	{
			erreur("Erreur d'acc�s � la fiche compt suivante.", standardError, pCompt->lastError);
         	pCompt->close();
			delete pCompt;
			return false;
      	}
    }

	pCompt->lastError = pCompt->close();
   	if (pCompt->lastError != DBIERR_NONE)
		erreur("Erreur de fermeture de la base compt.db.", standardError, pCompt->lastError);

	delete pCompt;

    return bExiste;
}
//***************************************************************************//
// 				  M�thodes de r�ponse aux boutons et double-clicks
//
//***************************************************************************

//
// Fonction Cm1610 : insere une nouvelle Fse1610 dans pFseArray
//
void
CreerFicheComptDialog::Cm1610()
{
	NSFse1610Info* pFse1610Info = new NSFse1610Info() ;
	string         sNumCompt = string(pData->numcompt) ;
  char           numero[FSE1610_NUMPREST_LEN + 1] ;
  char far       examen[CPTA_EXAMEN_LEN + 1] ;

	pExamen->GetText(examen, CPTA_EXAMEN_LEN + 1) ;

	// cr�ation automatique des fiches de consultation
	if ((strcmp(examen, "")) && (pExamen->getCode() == "GCONS1"))
	{
  	strcpy(pFse1610Info->pDonnees->code, (pVar->indiceConsult).c_str()) ;
    strcpy(pFse1610Info->pDonnees->coeff, "100") ;
    strcpy(pFse1610Info->pDonnees->divis, "1") ;
    strcpy(pFse1610Info->pDonnees->quantite, "1") ;
    strcpy(pFse1610Info->pDonnees->denombr, "1") ;

    // cas particulier pour tenir compte des donn�es ci-dessus
    if (!InitDataFse1610(pFse1610Info, false))
    {
    	delete pFse1610Info ;
      return ;
    }
	}
	else
	{
  	// on appelle la cr�ation d'une fiche 1610
    if (!InitDataFse1610(pFse1610Info, true))
		{
    	delete pFse1610Info ;
      return ;
    }
	}

	// on copie le num�ro de la prestation
	sprintf(numero, "%04d", nbPrest) ;
	strcpy(pFse1610Info->pDonnees->numprest, numero) ;

	// on ajoute l'�l�ment au tableau
  pFseArray->push_back(new NSBlocFse16(pFse1610Info)) ;
  nbPrest++ ;

	delete pFse1610Info ;

	// on remet la liste � jour
	AfficheListeFse() ;
	AfficheSommeDue() ;
	AffichePaye() ;
}


//
// Fonction Cm1620 : insere une nouvelle Fse1620 dans pFseArray
//
void
CreerFicheComptDialog::Cm1620()
{
	NSFse1620Info* pFse1620Info = new NSFse1620Info();
   string 		 	sNumCompt = string(pData->numcompt);
   char				numero[FSE1620_NUMPREST_LEN + 1];

   // on appelle la cr�ation d'une fiche 1620
   if (!InitDataFse1620(pFse1620Info,true))
   {
   	delete pFse1620Info;
      return;
   }

    // on copie le num�ro de la prestation
	sprintf(numero, "%04d", nbPrest);
   strcpy(pFse1620Info->pDonnees->numprest, numero);

   // on ajoute l'�l�ment au tableau
   pFseArray->push_back(new NSBlocFse16(pFse1620Info));
   nbPrest++;

   delete pFse1620Info;

   // on remet la liste � jour
   AfficheListeFse();
   AfficheSommeDue();
   AffichePaye();
}

//
// Fonction Cm1630 : insere une nouvelle Fse1630 dans pFseArray
//
void
CreerFicheComptDialog::Cm1630()
{
	NSFse1630Info* pFse1630Info = new NSFse1630Info();
   string 		 	sNumCompt = string(pData->numcompt);
   char				numero[FSE1630_NUMPREST_LEN + 1];

   // on appelle la cr�ation d'une fiche 1630
   if (!InitDataFse1630(pFse1630Info,true))
   {
   	delete pFse1630Info;
      return;
   }

    // on copie le num�ro de la prestation
	sprintf(numero, "%04d", nbPrest);
   strcpy(pFse1630Info->pDonnees->numprest, numero);

   // on ajoute l'�l�ment au tableau
   pFseArray->push_back(new NSBlocFse16(pFse1630Info));
   nbPrest++;

   delete pFse1630Info;

   // on remet la liste � jour
   AfficheListeFse();
   AfficheSommeDue();
   AffichePaye();
}voidCreerFicheComptDialog::CmCCAM(){	NSFseCCAMInfo FseCCAMInfo ;	string sNumCompt = string(pData->numcompt) ;
	char	 numero[FSECCAM_NUMPREST_LEN + 1] ;

  // On a besoin que l'examen soit en place
  setExamCode() ;

	// on appelle la cr�ation d'une fiche 1630
	if (!InitDataFseCCAM(&FseCCAMInfo, true))
		return ;

	// on copie le num�ro de la prestation
	sprintf(numero, "%04d", nbPrest) ;
	strcpy(FseCCAMInfo.pDonnees->numprest, numero) ;

	// on ajoute l'�l�ment au tableau
	pFseArray->push_back(new NSBlocFse16(&FseCCAMInfo)) ;
	nbPrest++ ;

	// on remet la liste � jour
  AfficheListeFse() ;
  AfficheSommeDue() ;
  AffichePaye() ;
}
//// Fonction CmModifFse : pour modifier la fiche Fse16xx s�lectionn�e
//
void
CreerFicheComptDialog::CmModifFse()
{
	NSFse1610Info Fse1610Info ;
  NSFse1620Info Fse1620Info ;
  NSFse1630Info Fse1630Info ;
  NSFseCCAMInfo FseCCAMInfo ;
	int index = pListeFse->IndexItemSelect() ;
	if (index == -1)
	{
  	erreur("Vous devez s�lectionner une prestation.", standardError, 0) ;
    return ;
	}

	switch (((*pFseArray)[index])->typePrest)
	{
  	// cas Fse1610
    ////////////////////////////////////////////////////////////////////////////////
   	case 1:
    	Fse1610Info = *(((*pFseArray)[index])->p1610) ;

   		if (false == InitDataFse1610(&Fse1610Info, false))
      	return ;

   		// on conserve la modif dans le tableau
   		*(((*pFseArray)[index])->p1610) = Fse1610Info ;

      break ;

    // cas Fse1620
    ////////////////////////////////////////////////////////////////////////////////
    case 2:
    	Fse1620Info = *(((*pFseArray)[index])->p1620) ;

   		if (false == InitDataFse1620(&Fse1620Info, false))
      	return ;

   		// on conserve la modif dans le tableau
   		*(((*pFseArray)[index])->p1620) = Fse1620Info ;

      break ;

    // cas Fse1630
    ////////////////////////////////////////////////////////////////////////////////
    case 3:
    	Fse1630Info = *(((*pFseArray)[index])->p1630) ;

   		if (false == InitDataFse1630(&Fse1630Info, false))
      	return ;

   		// on conserve la modif dans le tableau
   		*(((*pFseArray)[index])->p1630) = Fse1630Info ;

      break ;
    // cas FseCCAM    ////////////////////////////////////////////////////////////////////////////////
  	case 4:
    	FseCCAMInfo = *(((*pFseArray)[index])->pCCAM) ;

   		if (false == InitDataFseCCAM(&FseCCAMInfo, false))
      	return ;

   		// on conserve la modif dans le tableau
   		*(((*pFseArray)[index])->pCCAM) = FseCCAMInfo ;

      break ;
	}

	// on remet la liste � jour
	AfficheListeFse() ;
	AfficheSommeDue() ;
	AffichePaye() ;
}
//// Fonction CmModifFact : pour modifier la fiche Fact s�lectionn�e
//
void
CreerFicheComptDialog::CmModifFact()
{
	NSFactInfo factInfo ;

	int index = pListeFact->IndexItemSelect() ;
	if (-1 == index)
	{
  	erreur("Vous devez s�lectionner une fiche fact", standardError, 0) ;
    return ;
	}

	if (0 == index)
  	pVar->bFact0 = true ;
	else
  	pVar->bFact0 = false ;

	factInfo = *((*pFactArray)[index]) ;

	// on annule le pr�c�dent paiement retrouv� dans FactInfo
	// pour d�cr�menter ensuite du paiement r�el.
	IncrementeResteDu(factInfo.pDonnees->organisme,
                    factInfo.pDonnees->montant,
                    factInfo.pDonnees->unite) ;

	if (false == InitDataFact(&factInfo, false))
		return ;

	DecrementeResteDu(factInfo.pDonnees->organisme,
                    factInfo.pDonnees->montant,
                    factInfo.pDonnees->unite) ;

	*((*pFactArray)[index]) = factInfo ;

	// on remet la liste et le compteur � jour
	AfficheListeFact() ;
	AffichePaye() ;
}

//// Fonction CmModifTP : pour modifier la fiche Tiers-payant s�lectionn�e
//
void
CreerFicheComptDialog::CmModifTP()
{
	NSTPayantInfo TPayantInfo ;
  int index = pListeTP->IndexItemSelect() ;

  if (-1 == index)
  {
    erreur("Vous devez s�lectionner une fiche de tiers-payant",standardError, 0) ;
    return ;
  }

  // on modifie la fiche TPayant en m�moire

  TPayantInfo = *((*pTPArray)[index]) ;

  if (false == InitDataTP(&TPayantInfo, false))
    return ;

  *((*pTPArray)[index]) = TPayantInfo ;

  // on remet la liste � jour
  AfficheListeTP() ;
}

voidCreerFicheComptDialog::CmPaiement()
{
	NSFactInfo factInfo ;

	string sNumCompt = string(pData->numcompt) ;	char   numero[FACT_NUMERO_LEN + 1] ;
	int    resteDuOrga   = 0 ;
	int    resteDuGlobal = 0 ;

	if (pVar->bCreation)  	pVar->bFact0 = true ;
	else
  	pVar->bFact0 = false ;

	// � la creation on ne peut cr�er qu'une seule fiche de paiement (Fact0)	if (bCreerPaiement)
	{
    // S'il existe un TP qui doit tout le reste du : on le propose
    for (NSTPIter i = pTPArray->begin() ; pTPArray->end() != i ; i++)
    {
      resteDuOrga += atoi((*i)->pDonnees->reste_du) ;

      if (!strcmp((*i)->pDonnees->monnaie, "LOC"))
        resteDuGlobal = atoi(pData->duFranc) - atoi(pData->payeFranc) ;
      else
        resteDuGlobal = atoi(pData->duEuro) - atoi(pData->payeEuro) ;

      if (resteDuOrga == resteDuGlobal)
      {
        strcpy(factInfo.pDonnees->organisme, (*i)->pDonnees->organisme) ;
        strcpy(factInfo.pDonnees->montant, (*i)->pDonnees->reste_du) ;
        strcpy(factInfo.pDonnees->unite, (*i)->pDonnees->monnaie) ;
        break ;
      }
    }

    // on appelle la cr�ation d'une fiche Fact
    if (false == InitDataFact(&factInfo, true))
      return ;

    // on copie le numero de fact
    sprintf(numero, "%02d", nbFact) ;
    strcpy(factInfo.pDonnees->numero, numero) ;

    // on ajoute l'�l�ment au tableau
    pFactArray->push_back(new NSFactInfo(factInfo)) ;
    nbFact++ ;

    // on decremente le reste du si tiers-payant
    DecrementeResteDu(factInfo.pDonnees->organisme,                      factInfo.pDonnees->montant,
                      factInfo.pDonnees->unite) ;

    // on trie le tableau par date
    sort(pFactArray->begin(), pFactArray->end(), factAnterieure) ;

    // on ne peut creer qu'une fiche � la cr�ation
    if (pVar->bCreation)
      bCreerPaiement = false ;
  }
  else // on ne peut entrer dans ce cas qu'en cr�ation
  {
    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName() ;
    MessageBox("On ne peut cr�er qu'un seul paiement � la cr�ation d'une fiche compt.", sCaption.c_str(), MB_OK) ;
  }

  // on remet la liste et le compteur � jour
  AfficheListeFact() ;
  AffichePaye() ;
}

void
CreerFicheComptDialog::CmCorresp()
{
try
{
	string sTitre ;
	ChercheListePatCorDialog* pListeCorDlg ;

	pListeCorDlg = new ChercheListePatCorDialog(this, pContexte, pNSResModule) ;

	if ((pListeCorDlg->Execute() == IDOK) && (pListeCorDlg->CorrespChoisi >= 0) &&
      (NULL != pListeCorDlg->pCorrespSelect))
	{
  	strcpy(codeCorresp, pListeCorDlg->pCorrespSelect->sPersonID.c_str()) ;
    sTitre = pListeCorDlg->pCorrespSelect->sTitre + string(" ") + pListeCorDlg->pCorrespSelect->sNom + string(" ") + pListeCorDlg->pCorrespSelect->sPrenom ;
    pCorresp->SetCaption(sTitre.c_str()) ;
	}

	delete pListeCorDlg ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception CreerFicheComptDialog::CmCorresp : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
	erreur("Exception CreerFicheComptDialog::CmCorresp.", standardError, 0) ;
}
}

voidCreerFicheComptDialog::CmTiersPayant()
{
	NSTPayantInfo TPayantInfo ;
	char numero[TPAY_NUMERO_LEN + 1] ;

	// on appelle la cr�ation d'une fiche TPayant
	if (false == InitDataTP(&TPayantInfo, true))
		return ;

	// on copie le numero de la fiche TPayant
	sprintf(numero, "%02d", nbTP) ;
	strcpy(TPayantInfo.pDonnees->numero, numero) ;

	// on ajoute l'�l�ment au tableau
	pTPArray->push_back(new NSTPayantInfo(TPayantInfo)) ;
	nbTP++ ;

	// on remet la liste � jour
	AfficheListeTP() ;
}

voidCreerFicheComptDialog::CmPaiementTiersPayant(CreerTPayantDialog* pTPDlg)
{
  NSFactInfo factInfo ;
  string     sNumCompt = string(pData->numcompt) ;
  char       numero[FACT_NUMERO_LEN + 1] ;

  if (pVar->bCreation)
    pVar->bFact0 = true ;
  else
    pVar->bFact0 = false ;

  // � la creation on ne peut cr�er qu'une seule fiche de paiement (Fact0)
  if (false == pVar->bCreation)
  {
    strcpy(factInfo.pDonnees->organisme, pTPDlg->pData->organisme) ;
    strcpy(factInfo.pDonnees->montant, pTPDlg->pData->reste_du) ;
    strcpy(factInfo.pDonnees->unite, pTPDlg->pData->monnaie) ;

    // on appelle la modification d'une fiche Fact
    if (false == InitDataFact(&factInfo, false))
      return ;

    // on copie le numero de fact
    sprintf(numero, "%02d", nbFact) ;
    strcpy(factInfo.pDonnees->numero, numero) ;

    // on ajoute l'�l�ment au tableau
    pFactArray->push_back(new NSFactInfo(factInfo)) ;
    nbFact++ ;

    // on trie le tableau par date
    sort(pFactArray->begin(), pFactArray->end(), factAnterieure) ;

    // on decremente le reste du si tiers-payant
    DecrementeResteDu(factInfo.pDonnees->organisme,
                      factInfo.pDonnees->montant,
                      factInfo.pDonnees->unite) ;

    // on reporte la modif dans le dialogue
    pTPDlg->DecrementeResteDu(factInfo.pDonnees->organisme,
                              factInfo.pDonnees->montant,
                        		  factInfo.pDonnees->unite) ;
  }
  else
  {
    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName() ;
    MessageBox("Vous devez utiliser le bouton Paiement global � la cr�ation d'une fiche Compt.", sCaption.c_str(), MB_OK) ;
  }

  // on remet la liste et le compteur � jour
  AfficheListeFact() ;
  AffichePaye() ;
}

voidCreerFicheComptDialog::CmCodeConsult()
{
	// introduit "consultation" dans le code examen
	string sCodeLexique = "GCONS1" ;
	pExamen->setLabel(sCodeLexique) ;

	// on v�rifie qu'il n'existe pas deja une consultation
	if (ExisteExamen(pPatient->sPersonID, pVar->sDateC, "GCONS"))
	{
		string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName() ;		int ret = MessageBox("Il existe d�j� le m�me examen, pour le m�me patient, � la m�me date. Voulez-vous annuler?", sCaption.c_str(), MB_YESNO) ;

		if (ret == IDYES)
    	CmCancel() ;
	}
}

voidCreerFicheComptDialog::EnregDonneesCompt(string sNumCompt)
{
	EnregFseArray(sNumCompt) ;

	if ((pVar->bCreation) && (pFactArray->empty()))
	{
		// on cr�e une fact 0 fictive (montant nul)
    NSFactInfo FactInfo ;
    strcpy(FactInfo.pDonnees->numcompt,  pData->numcompt) ;
    strcpy(FactInfo.pDonnees->numero,    "00") ;
    strcpy(FactInfo.pDonnees->operateur, pContexte->getUtilisateur()->getNss().c_str()) ;
    strcpy(FactInfo.pDonnees->date_paie, (pVar->sDateC).c_str()) ;
    strcpy(FactInfo.pDonnees->montant,   "0") ;

    if (pVar->monnaieRef == MONNAIE_LOCALE)
    	strcpy(FactInfo.pDonnees->unite, "LOC") ;
    else
    	strcpy(FactInfo.pDonnees->unite, "EUR") ;

    pFactArray->push_back(new NSFactInfo(FactInfo)) ;
    nbFact = 1 ;
	}

	EnregFactArray(sNumCompt) ;
	EnregTPArray(sNumCompt) ;
}

//// Fonction CmOk : on conserve les donn�es saisies dans pData
//
void
CreerFicheComptDialog::CmOk()
{
	string   sTexte = "" ;
	string   sResteDu ;

	pResteDu->getSomme(&sResteDu) ;
	if (SommeResteDu() > atoi(sResteDu.c_str()))	{
		erreur("La somme des reste-d�s par les tiers-payant ne doit pas etre sup�rieure au reste d�.", warningError, 0) ;
		return ;
	}

	strcpy(pData->patient, pPatient->sPersonID.c_str()) ;	if (!setExamCode())
  	return ;

	if (pExterne->GetCheck() == BF_CHECKED)
		strcpy(pData->contexte, "NEXTE") ;
  if (pAmbulatoire->GetCheck() == BF_CHECKED)
		strcpy(pData->contexte, "NAMBU") ;
	if (pHospital->GetCheck() == BF_CHECKED)
		strcpy(pData->contexte, "NHOST") ;

	// la somme due, le d�passement et le champ paye
	// sont d�j� dans les data

	if (string(pData->payeFranc) < string(pData->duFranc))
		strcpy(pData->okPaye, "0") ;
	else
		strcpy(pData->okPaye, "1") ;

	strcpy(pData->prescript, codeCorresp) ;
	strcpy(pData->operateur, pContexte->getUtilisateur()->getNss().c_str()) ;

	// attention ne pas rentrer les old data
	// sinon n'enregistre pas les cartes vides (!!!)
	// - qui contiennent seulement le n� -

	TDialog::CmOk() ;
}

//// Fonction CmCancel : on supprime le tableau des nouvelles fiches Fse
// qui ont �t� cr��s par Cm16xx.
//
void
CreerFicheComptDialog::CmCancel()
{
	TDialog::CmCancel();
}

bool
CreerFicheComptDialog::setExamCode()
{
	char far examen[CPTA_EXAMEN_LEN + 1] ;

  // Saisie du code examen
	pExamen->GetText(examen, CPTA_EXAMEN_LEN + 1) ;
	if (!strcmp(examen, ""))
	{
		erreur("Le champ Examen est obligatoire.", warningError, 0) ;
		return false ;
	}

	// on sait que le champ Examen n'est pas vide	string sTexte = pExamen->getCode() ;
	if (sTexte == "�?????")		// texte libre
	{
		erreur("Vous devez choisir l'examen � partir du lexique, et non en texte libre.", warningError, 0) ;
		return false ;
	}

	string sExamen = string(sTexte, 0, 5) ;
	string sSyn    = string(sTexte, 5, 1) ;
	strcpy(pData->examen, sExamen.c_str()) ;
	strcpy(pData->synonyme, sSyn.c_str()) ;

  return true ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSUtilExamen
//
// -----------------------------------------------------------------

NSUtilExamen::NSUtilExamen(NSContexte *pCtx, CreerFicheComptDialog* pDlg, int resId, NSDico* pDico)
             :NSUtilLexique(pCtx, pDlg, resId, pDico)
{
	pDialog = pDlg ;
}

NSUtilExamen::~NSUtilExamen()
{
}

void
NSUtilExamen::ElementSelectionne()
{
	int  ret ;
	char far examen[CPTA_EXAMEN_LEN + 1] ;

	NSUtilLexique::ElementSelectionne() ;

	pDialog->pExamen->GetText(examen, CPTA_EXAMEN_LEN + 1) ;
	if (!strcmp(examen, ""))
		return ;

	// on sait que le champ Examen n'est pas vide
	string sTexte = pDialog->pExamen->getCode() ;
	string sExamen = string(sTexte, 0, 5) ;

	if (pDialog->sCodeAlerte != sExamen)
	{
		string sDate ;

		pDialog->pDate->getDate(&sDate) ;

		if (pDialog->ExisteExamen(pDialog->pPatient->sPersonID.c_str(), sDate, sExamen))
    {
    	string sCaption = string("Message ") + pDialog->pContexte->getSuperviseur()->getAppName() ;
      ret = MessageBox("Il existe d�j� le m�me examen, pour le m�me patient, � la m�me date. Voulez-vous annuler?", sCaption.c_str(), MB_YESNO) ;

      if (ret == IDYES)
      	pDialog->CmCancel() ;
    }

    pDialog->sCodeAlerte = sExamen ;
	}
}

// -----------------------------------------------------------------//
//  M�thodes de CreerFicheFactDialog
//
// -----------------------------------------------------------------

// ---------------------------------------------------------------------------DEFINE_RESPONSE_TABLE1(CreerFicheFactDialog, NSUtilDialog)
  EV_CBN_SELCHANGE(IDC_FACT_ORGA, EvOrgaChange),
  EV_COMMAND(IDOK, CmOk),
  EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

//// Constructeur
//
CreerFicheFactDialog::CreerFicheFactDialog(CreerFicheComptDialog* pere,
                                            NSContexte* pCtx,
                                            NSVarCompta* pVarCompt)
                     : NSUtilDialog(pere, pCtx, "IDD_FACT", pNSResModule)
{
  // R�cup�ration du dialogue pere
  pDlg = pere;

	// Initialisation des donnees  pData          = new NSFactData ;
  pVar           = new NSVarCompta(*pVarCompt) ;

  // Cr�ation de tous les "objets de contr�le"
  pDate          = new NSUtilEditDate(pContexte, this, IDC_FACT_DATE) ;
  pOrga          = new TComboBox(this, IDC_FACT_ORGA) ;
  pMontant       = new NSUtilEditSomme(pContexte, this, IDC_FACT_MONTANT) ;
  pUnite         = new TGroupBox(this, IDC_FACT_UNITE) ;
  pLocal         = new TRadioButton(this, IDC_FACT_LOC, pUnite) ;
  pEuro          = new TRadioButton(this, IDC_FACT_EURO, pUnite) ;
  pModePaie      = new TComboBox(this, IDC_FACT_MODEPAIE) ;
  pModePaieArray = new NSComboArray ;

  pCodeOrgaArray = new NSCodeOrgaArray ;
  nbCodeOrga = 0 ;

  if (pVar->bFact0)
    pDate->Attr.Style |= ES_READONLY ;
}

//// Destructeur
//
CreerFicheFactDialog::~CreerFicheFactDialog()
{
  delete pData ;
  delete pVar ;
  delete pDate ;
  delete pOrga ;
  delete pMontant ;
  delete pUnite ;
  delete pLocal ;
  delete pEuro ;
  delete pModePaie ;
  delete pModePaieArray ;
  delete pCodeOrgaArray ;
}

//// Fonction SetupWindow : Mise en place des data � l'�cran et initialisation
//	du tableau des Fse16xx + liste
//
void
CreerFicheFactDialog::SetupWindow()
{
  TDate			dateSys;
  NSComboIter     i;
	int 			j;
  NSCodeOrgaIter  k;

  string sFichier = pContexte->PathName("BCPT") + string("modepaie.dat");
  TDialog::SetupWindow();
  // on synchronise la date sur sDateC pour la fact 0  if (!strcmp(pData->date_paie, ""))
  {
    if (pVar->bFact0)
      strcpy(pData->date_paie, (pVar->sDateC).c_str());
    else
    {
      sprintf(pData->date_paie, "%4d%02d%02d", (int)dateSys.Year(),
                           (int)dateSys.Month(), (int)dateSys.DayOfMonth()) ;
    }
  }

  pDate->setDate(pData->date_paie) ;

  // on charge la table des organismes
	if (!InitCodeOrgaArray())
  {
    erreur("Probleme au chargement du tableau des codes organisme.",standardError, 0) ;
    return;
  }

  // s�lection du code dans la combobox
  for (k = pCodeOrgaArray->begin(), j = 0; k != pCodeOrgaArray->end(); k++,j++)
  {
    if (!strcmp((*k)->pDonnees->code, pData->organisme))
    {
      pOrga->SetSelIndex(j);
      break;
    }
  }

  if (!InitComboBox(pModePaie, pModePaieArray, sFichier))
    erreur("Pb � l'initialisation de la combobox ModePaie",standardError, 0) ;
  else
  {
    // si le mode de paiement n'est pas initialis�
    if (!strcmp(pData->mode_paie, ""))
    {
      // S'il s'agit du patient on s�lectionne "Ch�que"
      if (!strcmp(pData->organisme, ""))
        strcpy(pData->mode_paie, "C");
      else // cas d'un tiers-payant : on s�lectionne "Virement"
        strcpy(pData->mode_paie, "V");
    }

    // on positionne la combo box par rapport � mode_paie
    for (i = pModePaieArray->begin(), j = 0; i != pModePaieArray->end(); i++,j++)
    {
      if (!strcmp(((*i)->sCode).c_str(), pData->mode_paie))
      {
        pModePaie->SetSelIndex(j);
        break;
      }
    }
  }

  pLocal->SetCaption((pVar->sigle).c_str());

  if (!strcmp(pData->unite, "LOC"))
  {
    pLocal->Check();
    pEuro->Uncheck();
  }
  else if (!strcmp(pData->unite, "EUR"))
  {
    pLocal->Uncheck();
    pEuro->Check();
  }
  else
  {
    if (pVar->monnaieRef == MONNAIE_LOCALE)
    {
      pLocal->Check();
      pEuro->Uncheck();
    }
    else
    {      pLocal->Uncheck();
      pEuro->Check();
    }
  }

  if (strcmp(pData->montant, ""))
    pMontant->setSomme(string(pData->montant));
  else
  {
    if (!strcmp(pData->organisme, ""))
      AfficheResteDuPatient();
    else
      AfficheResteDuOrga(string(pData->organisme));
  }
}

bool
CreerFicheFactDialog::InitCodeOrgaArray()
{
    NSCodeOrga* 	pCodeOrga = new NSCodeOrga(pContexte);
    NSCodeOrgaInfo* pCodePatientInfo = new NSCodeOrgaInfo();

    // Le patient correspond au code orga ""
    strcpy(pCodePatientInfo->pDonnees->lib_court, "Patient");
    // on le met dans le tableau et dans la combo
    pCodeOrgaArray->push_back(new NSCodeOrgaInfo(*pCodePatientInfo));
    pOrga->AddString(pCodePatientInfo->pDonnees->lib_court);
    nbCodeOrga++;
    delete pCodePatientInfo;

    pCodeOrga->lastError = pCodeOrga->open();
    if (pCodeOrga->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur � l'ouverture de la base CodeOrga.",standardError, 0) ;
        delete pCodeOrga;
        return false;
    }

	pCodeOrga->lastError = pCodeOrga->debut(dbiWRITELOCK);
    if ((pCodeOrga->lastError != DBIERR_NONE) && (pCodeOrga->lastError != DBIERR_EOF))
    {
   	    erreur("Erreur de positionnement dans le fichier CodeOrga.db.", standardError, pCodeOrga->lastError);
        pCodeOrga->close();
        delete pCodeOrga;
        return false;
    }

    while (pCodeOrga->lastError != DBIERR_EOF)
    {
   	    pCodeOrga->lastError = pCodeOrga->getRecord();
        if (pCodeOrga->lastError != DBIERR_NONE)
        {
      	    erreur("Erreur � la lecture d'une fiche CodeOrga.", standardError, pCodeOrga->lastError);
            pCodeOrga->close();
            delete pCodeOrga;
            return false;
        }

        // on remplit le tableau et la combobox
        pCodeOrgaArray->push_back(new NSCodeOrgaInfo(pCodeOrga));
        pOrga->AddString(pCodeOrga->pDonnees->lib_court);
        nbCodeOrga++;

        // ... on passe au composant suivant
        pCodeOrga->lastError = pCodeOrga->suivant(dbiWRITELOCK);
        if ((pCodeOrga->lastError != DBIERR_NONE) && (pCodeOrga->lastError != DBIERR_EOF))
        {
      	    erreur("Erreur d'acces � une fiche CodeOrga.", standardError, pCodeOrga->lastError);
            pCodeOrga->close();
            delete pCodeOrga;
            return false;
        }
    } // fin du while (recherche des composants images)

    // on ferme la base CARTE_SV2
    pCodeOrga->lastError = pCodeOrga->close();
    if (pCodeOrga->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur de fermeture du fichier CodeOrga.", standardError, pCodeOrga->lastError);
        delete pCodeOrga;
        return false;
    }

    delete pCodeOrga;
    return true;
}

void
CreerFicheFactDialog::AfficheResteDuPatient()
{
	int 	resteDuGlobal;
    int 	totalResteDu = 0;
    char 	reste[9] = "";

    if (pVar->monnaieRef == MONNAIE_LOCALE)
    {
    	resteDuGlobal = atoi(pDlg->pData->duFranc) - atoi(pDlg->pData->payeFranc);
        pLocal->Check();
        pEuro->Uncheck();
    }
    else
    {
    	resteDuGlobal = atoi(pDlg->pData->duEuro) - atoi(pDlg->pData->payeEuro);
        pLocal->Uncheck();
        pEuro->Check();
    }

	// on calcule la somme totale des restes-du organismes
    for (NSTPIter i = pDlg->pTPArray->begin(); i != pDlg->pTPArray->end(); i++)
    {
    	if (pVar->monnaieRef == MONNAIE_LOCALE)
        {
        	// on calcule en francs
        	if (!strcmp((*i)->pDonnees->monnaie, "LOC"))
            	totalResteDu += atoi((*i)->pDonnees->reste_du);
            else
            	totalResteDu += dtoi(double(atoi((*i)->pDonnees->reste_du)) * pVar->parite);
        }
        else
        {
        	// on calcule en Euros
        	if (!strcmp((*i)->pDonnees->monnaie, "LOC"))
            	totalResteDu += dtoi(double(atoi((*i)->pDonnees->reste_du)) / pVar->parite);
            else
            	totalResteDu += atoi((*i)->pDonnees->reste_du);
        }
    }

    itoa(resteDuGlobal - totalResteDu, reste, 10);
    pMontant->setSomme(string(reste));
}

void
CreerFicheFactDialog::AfficheResteDuOrga(string sCodeOrga)
{
	for (NSTPIter i = pDlg->pTPArray->begin(); i != pDlg->pTPArray->end(); i++)
    {
    	if (!strcmp((*i)->pDonnees->organisme, sCodeOrga.c_str()))
        {
        	pMontant->setSomme(string((*i)->pDonnees->reste_du));

        	if (!strcmp((*i)->pDonnees->monnaie, "LOC"))
            {
            	pLocal->Check();
                pEuro->Uncheck();
            }
            else
            {
                pLocal->Uncheck();
            	pEuro->Check();
            }

            break;
        }
    }
}

void
CreerFicheFactDialog::EvOrgaChange()
{
    int indexOrga;

    // on affiche les restes du uniquement � la cr�ation (numcompt == "")
    if (!strcmp(pData->numcompt, ""))
    {
	    indexOrga = pOrga->GetSelIndex();
   	    if (indexOrga >= 0)
   	    {
   		    if (!strcmp((*pCodeOrgaArray)[indexOrga]->pDonnees->code, ""))
        	    AfficheResteDuPatient();
            else
        	    AfficheResteDuOrga(string((*pCodeOrgaArray)[indexOrga]->pDonnees->code));
   	    }
    }
}
voidCreerFicheFactDialog::CmOk()
{
    string sTexte;

    string sDate;
    int    indexMode;
    int    indexOrga;

    pDate->getDate(&sDate);

    if (sDate < (pVar->sDateC))
    {
   	    erreur("La date du paiement ne peut etre ant�rieure � l'examen",standardError, 0) ;
        return;
    }

    if (pVar->bFact0 && (!(sDate == pVar->sDateC)))
    {
   	    erreur("La date du premier paiement n'est pas modifiable",standardError, 0) ;
        return;
    }

    strcpy(pData->date_paie, sDate.c_str());

    strcpy(pData->operateur, pContexte->getUtilisateur()->getNss().c_str());

    indexOrga = pOrga->GetSelIndex();
    if (indexOrga > 0) // Note : le patient correspond ici � indexOrga == 0
    {
   	    strcpy(pData->organisme, (*pCodeOrgaArray)[indexOrga]->pDonnees->code);
        strcpy(pData->libelle, (*pCodeOrgaArray)[indexOrga]->pDonnees->lib_court);
    }

    pMontant->getSomme(&sTexte);
    strcpy(pData->montant, sTexte.c_str());

    if (pLocal->GetCheck() == BF_CHECKED)
   	    strcpy(pData->unite, "LOC");
    if (pEuro->GetCheck() == BF_CHECKED)
		strcpy(pData->unite, "EUR");

    indexMode = pModePaie->GetSelIndex();
    if (indexMode >= 0)
   	    strcpy(pData->mode_paie, ((*pModePaieArray)[indexMode]->sCode).c_str());

    if (strcmp(pData->montant, "") != 0)
    {
   	    if (strcmp(pData->unite, "") == 0)
        {
   		    erreur("Vous devez pr�ciser l'unit�",standardError, 0) ;
      	    return;
        }
    }
    else
   	    strcpy(pData->unite, "LOC");
    TDialog::CmOk();
}

void
CreerFicheFactDialog::CmCancel()
{
	TDialog::CmCancel();
}

// -----------------------------------------------------------------
//
//  M�thodes de CreerTPayantDialog
//
// -----------------------------------------------------------------
// ---------------------------------------------------------------------------DEFINE_RESPONSE_TABLE1(CreerTPayantDialog, NSUtilDialog)
    EV_CBN_SELCHANGE(IDC_TP_ORGA, EvOrgaChange),
    EV_BN_CLICKED(IDC_TP_PAIEMENT, CmPaiement),
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

//// Constructeur
//
CreerTPayantDialog::CreerTPayantDialog(CreerFicheComptDialog* pere, NSContexte* pCtx, NSVarCompta* pVarCompt)
                   :NSUtilDialog(pere, pCtx, "IDD_TPAYANT", pNSResModule)
{
  pComptDlg = pere ;

	// Initialisation des donnees  pData     = new NSTPayantData ;
  pVar      = new NSVarCompta(*pVarCompt) ;

  // Cr�ation de tous les "objets de contr�le"
  pOrga     = new TComboBox(this, IDC_TP_ORGA) ;
  pResteDu  = new NSUtilEditSomme(pContexte, this, IDC_TP_RESTEDU) ;
  pUnite    = new TGroupBox(this, IDC_TP_UNITE) ;
  pLocal    = new TRadioButton(this, IDC_TP_LOC, pUnite) ;
  pEuro     = new TRadioButton(this, IDC_TP_EURO, pUnite) ;

  pCodeOrgaArray = new NSCodeOrgaArray ;
  nbCodeOrga = 0 ;
}

//// Destructeur
//
CreerTPayantDialog::~CreerTPayantDialog()
{
  delete pData ;
  delete pVar ;
  delete pOrga ;
  delete pResteDu ;
  delete pUnite ;
  delete pLocal ;
  delete pEuro ;
  delete pCodeOrgaArray ;
}

//// Fonction SetupWindow : Mise en place des data � l'�cran
//
void
CreerTPayantDialog::SetupWindow()
{
  NSCodeOrgaIter k ;
  int            j ;
  int            resteDuGlobal = 0 ;
  int            resteDuOrga = 0 ;
  char           cResteDuPatient[TPAY_RESTE_DU_LEN + 1] = "" ;

	TDialog::SetupWindow() ;

    // on charge la table des organismes	if (!InitCodeOrgaArray())
  {
   	    erreur("Probleme au chargement du tableau des codes organisme.",standardError, 0) ;
        return;
    }

    // s�lection du code dans la combobox
    for (k = pCodeOrgaArray->begin(), j = 0; k != pCodeOrgaArray->end(); k++,j++)
    {
   	    if (!strcmp((*k)->pDonnees->code, pData->organisme))
        {
      	    pOrga->SetSelIndex(j);
            break;
        }
    }

    pLocal->SetCaption((pVar->sigle).c_str());
    if (!strcmp(pData->monnaie, "LOC"))   	    pLocal->Check();
    else if (!strcmp(pData->monnaie, "EUR"))
   	    pEuro->Check();
    else
    {
   	    if (pVar->monnaieRef == MONNAIE_LOCALE)
    	    pLocal->Check();
        else
    	    pEuro->Check();
    }

    // on propose comme reste du par d�faut le reste du patient    // si on ne connait pas l'organisme
    if (!strcmp(pData->organisme, ""))
    {
        // Note : on d�pend ici de la monnaie de r�f�rence pour le calcul
        // car aucune monnaie n'existe � priori pour un organisme vide
        if (pVar->monnaieRef == MONNAIE_LOCALE)
    	    resteDuGlobal = atoi(pComptDlg->pData->duFranc) - atoi(pComptDlg->pData->payeFranc);
        else
    	    resteDuGlobal = atoi(pComptDlg->pData->duEuro) - atoi(pComptDlg->pData->payeEuro);

        // on calcule la somme totale des restes-du organismes
        for (NSTPIter i = pComptDlg->pTPArray->begin(); i != pComptDlg->pTPArray->end(); i++)
        {
    	    if (pVar->monnaieRef == MONNAIE_LOCALE)
            {
        	    // on calcule en francs
        	    if (!strcmp((*i)->pDonnees->monnaie, "LOC"))
            	    resteDuOrga += atoi((*i)->pDonnees->reste_du);
                else
            	    resteDuOrga += dtoi(double(atoi((*i)->pDonnees->reste_du)) * pVar->parite);
            }
            else
            {
                // on calcule en Euros
        	    if (!strcmp((*i)->pDonnees->monnaie, "LOC"))
            	    resteDuOrga += dtoi(double(atoi((*i)->pDonnees->reste_du)) / pVar->parite);
                else
            	    resteDuOrga += atoi((*i)->pDonnees->reste_du);
            }
        }

        itoa(resteDuGlobal - resteDuOrga, cResteDuPatient, 10);

        pResteDu->setSomme(string(cResteDuPatient));
    }
    else
        pResteDu->setSomme(string(pData->reste_du));
}

void
CreerTPayantDialog::CmPaiement()
{
	if (SauveData())
		pComptDlg->CmPaiementTiersPayant(this);
}

//
// Decremente le reste du de l'organisme du montant sp�cifi�
//
void
CreerTPayantDialog::DecrementeResteDu(char* codeOrga, char* montant, char* unite)
{
	int 	resteDu, paiement;
   char	uniteDu[4];

   if (!strcmp(pData->organisme, codeOrga))
   {
   	resteDu = atoi(pData->reste_du);
      paiement = atoi(montant);
      strcpy(uniteDu, pData->monnaie);

      if (!strcmp(uniteDu, "LOC"))
      {
      	if (!strcmp(unite, "LOC"))
         	resteDu -= paiement;
         else
         	resteDu -= dtoi(double(paiement) * pVar->parite);
      }
      else
      {
      	if (!strcmp(unite, "EUR"))
         	resteDu -= paiement;
         else
         	resteDu -= dtoi(double(paiement) / pVar->parite);
      }

      // on replace le nouveau reste du
      itoa(resteDu, pData->reste_du, 10);
      pResteDu->setSomme(string(pData->reste_du));
   }
}

void
CreerTPayantDialog::EvOrgaChange()
{
    int	    indexOrga;

    indexOrga = pOrga->GetSelIndex();

    // on v�rifie que l'organisme s�lectionn� n'appartient pas d�j� aux tiers-payants
    // sauf s'il est lui-m�me dans les datas
    for (NSTPIter i = pComptDlg->pTPArray->begin(); i != pComptDlg->pTPArray->end(); i++)
    {
        if (!strcmp((*i)->pDonnees->organisme, (*pCodeOrgaArray)[indexOrga]->pDonnees->code))
        {
            if (!strcmp(pData->organisme, (*pCodeOrgaArray)[indexOrga]->pDonnees->code))
                break;
            else
            {
                erreur("Cet organisme a d�j� �t� cr��. Pour le modifier, double-cliquez sur son nom dans la liste des tiers-payants.", standardError, 0);
                for (int j = 0; j < nbCodeOrga; j++)
                {
                    if (!strcmp(pData->organisme, (*pCodeOrgaArray)[j]->pDonnees->code))
                    {
                        pOrga->SetSelIndex(j);
                        return;
                    }
                }
                pOrga->SetSelIndex(-1);
                break;
            }
        }
    }
}

bool
CreerTPayantDialog::InitCodeOrgaArray()
{
	NSCodeOrga* 	pCodeOrga = new NSCodeOrga(pContexte);

   pCodeOrga->lastError = pCodeOrga->open();
   if (pCodeOrga->lastError != DBIERR_NONE)
   {
   	erreur("Erreur � l'ouverture de la base CodeOrga.",standardError, 0) ;
      delete pCodeOrga;
      return false;
   }

	pCodeOrga->lastError = pCodeOrga->debut(dbiWRITELOCK);
   if ((pCodeOrga->lastError != DBIERR_NONE) && (pCodeOrga->lastError != DBIERR_EOF))
   {
   	erreur("Erreur de positionnement dans le fichier CodeOrga.db.", standardError, pCodeOrga->lastError);
      pCodeOrga->close();
      delete pCodeOrga;
      return false;
   }

   while (pCodeOrga->lastError != DBIERR_EOF)
   {
   	pCodeOrga->lastError = pCodeOrga->getRecord();
      if (pCodeOrga->lastError != DBIERR_NONE)
      {
      	erreur("Erreur � la lecture d'une fiche CodeOrga.", standardError, pCodeOrga->lastError);
         pCodeOrga->close();
         delete pCodeOrga;
         return false;
      }

      // on remplit le tableau et la combobox
      pCodeOrgaArray->push_back(new NSCodeOrgaInfo(pCodeOrga));
      pOrga->AddString(pCodeOrga->pDonnees->lib_court);
      nbCodeOrga++;

      // ... on passe au composant suivant
      pCodeOrga->lastError = pCodeOrga->suivant(dbiWRITELOCK);
      if ((pCodeOrga->lastError != DBIERR_NONE) && (pCodeOrga->lastError != DBIERR_EOF))
      {
      	erreur("Erreur d'acces � une fiche CodeOrga.", standardError, pCodeOrga->lastError);
         pCodeOrga->close();
         delete pCodeOrga;
         return false;
      }
   } // fin du while (recherche des composants images)

   // on ferme la base CARTE_SV2
   pCodeOrga->lastError = pCodeOrga->close();
   if (pCodeOrga->lastError != DBIERR_NONE)
   {
   	erreur("Erreur de fermeture du fichier CodeOrga.", standardError, pCodeOrga->lastError);
      delete pCodeOrga;
      return false;
   }

   delete pCodeOrga;
   return true;
}

bool
CreerTPayantDialog::SauveData()
{
    string  sTexte;
    int	    indexOrga;
    int     resteDuGlobal, resteDuOrga;
    int     totalResteDuOrga;

    indexOrga = pOrga->GetSelIndex();
    if (indexOrga >= 0)
    {
   	    strcpy(pData->organisme, (*pCodeOrgaArray)[indexOrga]->pDonnees->code);
        strcpy(pData->libelle, (*pCodeOrgaArray)[indexOrga]->pDonnees->lib_court);
    }
    else
    {
        erreur("Vous devez s�lectionner un organisme de tiers-payant.", standardError, 0);
        return false;
    }

    pResteDu->getSomme(&sTexte);
    strcpy(pData->reste_du, sTexte.c_str());

    if (pLocal->GetCheck() == BF_CHECKED)
   	    strcpy(pData->monnaie, "LOC");
    if (pEuro->GetCheck() == BF_CHECKED)
		strcpy(pData->monnaie, "EUR");

    if (strcmp(pData->reste_du, "") != 0)
    {
   	    if (strcmp(pData->monnaie, "") == 0)
        {
   		    erreur("Vous devez pr�ciser l'unit�",standardError, 0) ;
      	    return false;
        }
    }
    else
   	    strcpy(pData->monnaie, "LOC");

    // on v�rifie que le total des reste du orga ne d�passe
    // pas le reste du global
    if (pVar->monnaieRef == MONNAIE_LOCALE)
        resteDuGlobal = atoi(pComptDlg->pData->duFranc) - atoi(pComptDlg->pData->payeFranc);
    else
        resteDuGlobal = atoi(pComptDlg->pData->duEuro) - atoi(pComptDlg->pData->payeEuro);

    totalResteDuOrga = 0;

    // on calcule la somme totale des restes-du organismes
    for (NSTPIter i = pComptDlg->pTPArray->begin(); i != pComptDlg->pTPArray->end(); i++)
    {
        if (pVar->monnaieRef == MONNAIE_LOCALE)
        {
            // on calcule en francs
            if (!strcmp((*i)->pDonnees->monnaie, "LOC"))
                resteDuOrga = atoi((*i)->pDonnees->reste_du);
            else
                resteDuOrga = dtoi(double(atoi((*i)->pDonnees->reste_du)) * pVar->parite);
        }
        else
        {
            // on calcule en Euros
            if (!strcmp((*i)->pDonnees->monnaie, "LOC"))
                resteDuOrga = dtoi(double(atoi((*i)->pDonnees->reste_du)) / pVar->parite);
            else
                resteDuOrga = atoi((*i)->pDonnees->reste_du);
        }

        // si on tombe sur l'organisme en cours : on d�compte son reste du
        // car on va ajouter le reste du en cours
        if (!strcmp((*i)->pDonnees->organisme, pData->organisme))
            totalResteDuOrga -= resteDuOrga;
        else
            totalResteDuOrga += resteDuOrga;
    }

    // on ajoute au total le reste du en cours
    if (pVar->monnaieRef == MONNAIE_LOCALE)
    {
        // on calcule en francs
        if (!strcmp(pData->monnaie, "LOC"))
            totalResteDuOrga += atoi(pData->reste_du);
        else
            totalResteDuOrga += dtoi(double(atoi(pData->reste_du)) * pVar->parite);
    }
    else
    {
        // on calcule en Euros
        if (!strcmp(pData->monnaie, "LOC"))
            totalResteDuOrga += dtoi(double(atoi(pData->reste_du)) / pVar->parite);
        else
            totalResteDuOrga += atoi(pData->reste_du);
    }

    if (totalResteDuOrga > resteDuGlobal)
    {
        erreur("La somme des reste-du par tiers-payants d�passe le reste-du global.", standardError, 0) ;
        return false;
    }

    return true;
}

void
CreerTPayantDialog::CmOk()
{
	if (SauveData())
		TDialog::CmOk();
}

void
CreerTPayantDialog::CmCancel()
{
	TDialog::CmCancel();
}

// fin de nsfsedlg.cpp

