// nsimpdlg.cpp : dialogues des impayes// RS Octobre 98
//////////////////////////////////////////////////////////

#include <stdio.h>
#include <classlib\date.h>
#include <classlib\time.h>
#include <owl\eventhan.h>

#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"
#include "partage\nsperson.h"
#include "nautilus\nspatdlg.h"	// pour le code prescript
#include "nscompta\nscompta.rh"
#include "nscompta\nsfsedlg.h"   // pour le tri des tableaux Fse
#include "nscompta\nsactdlg.h"

//***************************************************************************
//  							M�thodes de NSActDocument
//***************************************************************************

// Constructeur NSActDocument
////////////////////////////////////////////////////////////////
NSActDocument::NSActDocument(TDocument* parent, NSDocumentInfo* pDocumentInfo,
										NSDocumentInfo* pDocHtmlInfo, NSContexte* pCtx)
				  :NSNoyauDocument(parent, pDocumentInfo, pDocHtmlInfo, pCtx, true)
{
	// Initialisation des donnees
  pCriteres 	   = new NSMultiCriteres ;
  pFseArray 	   = new NSFse16Array ;
  nbPrest			   = 0 ;
  pFactArray	   = new NSFactArray ;
  nbFact			   = 0 ;
  pTPArray		   = new NSTPArray ;
  nbTP				   = 0 ;
	pActArray 	   = new NSListActArray ;
  nbAct 			   = 0 ;
  pExamArray	   = new NSExamArray ;
  nbExam			   = 0 ;
  pKCodeArray	   = new NSKCodeArray ;
  nbKCode			   = 0 ;
  pCCAMCodeArray = new NSCCAMCodeArray ;
  nbCCAMCode	   = 0 ;
  pTotauxArray   = new NSTotauxArray ;
  nbTotaux		   = 0 ;
	pVar 				   = new NSVarCompta(pCtx) ;
  bImprimer		   = false ;
}

NSActDocument::NSActDocument(TDocument *parent, NSContexte *pCtx)				  :NSNoyauDocument(parent, pCtx)
{
	// Initialisation des donnees
  pCriteres 	   = new NSMultiCriteres ;
  pFseArray 	   = new NSFse16Array ;
  nbPrest			   = 0 ;
  pFactArray	   = new NSFactArray ;
  nbFact			   = 0 ;
  pTPArray		   = new NSTPArray ;
  nbTP				   = 0 ;
	pActArray 	   = new NSListActArray ;
  nbAct 			   = 0 ;
  pExamArray	   = new NSExamArray ;  nbExam			   = 0 ;
  pKCodeArray	   = new NSKCodeArray ;
  nbKCode			   = 0 ;
  pCCAMCodeArray = new NSCCAMCodeArray ;
  nbCCAMCode	   = 0 ;
  pTotauxArray   = new NSTotauxArray ;
  nbTotaux		   = 0 ;
	pVar 				   = new NSVarCompta(pCtx) ;
  bImprimer		   = false ;
}

NSActDocument::~NSActDocument()
{
	delete pVar ;
  delete pTotauxArray ;
  delete pCCAMCodeArray ;
  delete pKCodeArray ;
  delete pExamArray ;
  delete pActArray ;
  delete pTPArray ;
  delete pFactArray ;
  delete pFseArray ;
  delete pCriteres ;
}

// Ouverture du document
////////////////////////////////////////////////////////////////
bool NSActDocument::Open(int mode, LPCSTR /* path */)
{
	bool bAvecPat ;
	if (!LanceCriteres())   	return false ;

	if (mode == 0)		bAvecPat = true ;  else  	bAvecPat = false ;	if (!InitActArray(bAvecPat))
   	return false ;

	return true ;}

// Fermeture du document
////////////////////////////////////////////////////////////////
bool NSActDocument::Close()
{
	return true ;
}

bool
NSActDocument::LanceCriteres()
{
	NSMultiCriteresDialog* pCriteresDlg =
   	new NSMultiCriteresDialog(pContexte->GetMainWindow(), pContexte);

	if (pCriteresDlg->Execute() != IDOK)
	{
   	delete pCriteresDlg ;
    return false ;
  }
  *pCriteres = *(pCriteresDlg->pCriteres) ;

	delete pCriteresDlg ;
	return true ;
}

bool
NSActDocument::InitFactArray(string sNumCompt)
{
	// on r�cup�re la cle
	string sNumFact =  sNumCompt + string("  ") ;

	NSFact Fact(pContexte) ;

	pFactArray->vider() ;
  nbFact = 0 ;

  Fact.lastError = Fact.open() ;
  if (Fact.lastError != DBIERR_NONE)
  {
  	erreur("Erreur � l'ouverture de la base FACT.", standardError, Fact.lastError) ;
    return false ;
	}

	Fact.lastError = Fact.chercheClef(&sNumFact,
      														  "",
																    0,
																    keySEARCHGEQ,
																    dbiWRITELOCK) ;

	if (Fact.lastError == DBIERR_BOF)	// cas fichier vide
  {
  	Fact.close() ;
    return true ;		// le tableau est vide
  }

	if ((Fact.lastError != DBIERR_NONE) && (Fact.lastError != DBIERR_EOF))  {
  	erreur("Erreur � la recherche d'une fiche fact.", standardError, Fact.lastError) ;
    Fact.close() ;
    return false ;
	}

	while (Fact.lastError != DBIERR_EOF)
  {
  	Fact.lastError = Fact.getRecord() ;
    if (Fact.lastError != DBIERR_NONE)
    {
    	erreur("Erreur � la lecture d'une fiche fact.", standardError, Fact.lastError) ;
      Fact.close() ;
      return false ;
    }

    // condition d'arret
    if (!(string(Fact.pDonnees->numcompt) == sNumCompt))
    	break ;

    // on remplit le tableau
    pFactArray->push_back(new NSFactInfo(&Fact)) ;
    nbFact++ ;

    // ... on passe au composant suivant
    Fact.lastError = Fact.suivant(dbiWRITELOCK) ;
    if ((Fact.lastError != DBIERR_NONE) && (Fact.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche fact.", standardError, Fact.lastError) ;
      Fact.close() ;
      return false ;
    }
  } // fin du while

	// on ferme la base  Fact.lastError = Fact.close() ;
  if (Fact.lastError != DBIERR_NONE)
  {
  	erreur("Erreur de fermeture du fichier FACT.", standardError, Fact.lastError) ;
    return false ;
  }

	// on trie les fact par date	sort(pFactArray->begin(), pFactArray->end(), factAnterieure) ;

	return true ;
}

bool
NSActDocument::InitTPArray(string sNumCompt)
{
	// on r�cup�re la cle
	string sNumTPayant = sNumCompt + string("  ") ;

	NSTPayant TPayant(pContexte) ;

	pTPArray->vider() ;
  nbTP = 0 ;

	TPayant.lastError = TPayant.open() ;
  if (TPayant.lastError != DBIERR_NONE)
  {
  	erreur("Erreur � l'ouverture de la base TPayant.", standardError, TPayant.lastError) ;
    return false ;
  }

	TPayant.lastError = TPayant.chercheClef(&sNumTPayant,
      														        "",
                                          0,
																          keySEARCHGEQ,
                                          dbiWRITELOCK) ;

	if (TPayant.lastError == DBIERR_BOF)	// cas fichier vide
  {
  	TPayant.close() ;
    return true ;		// le tableau est vide
  }

  if ((TPayant.lastError != DBIERR_NONE) && (TPayant.lastError != DBIERR_EOF))
  {
  	erreur("Erreur � la recherche d'une fiche TPayant.", standardError, TPayant.lastError);
    TPayant.close() ;
    return false ;
	}

  while (TPayant.lastError != DBIERR_EOF)
  {
  	TPayant.lastError = TPayant.getRecord();
    if (TPayant.lastError != DBIERR_NONE)
    {
    	erreur("Erreur � la lecture d'une fiche TPayant.", standardError, TPayant.lastError) ;
      TPayant.close() ;
      return false ;
    }

    // condition d'arret
    if (!(string(TPayant.pDonnees->numcompt) == sNumCompt))
    	break ;

    // on remplit le tableau
    pTPArray->push_back(new NSTPayantInfo(&TPayant)) ;
    nbTP++ ;

    // ... on passe au composant suivant
    TPayant.lastError = TPayant.suivant(dbiWRITELOCK);
    if ((TPayant.lastError != DBIERR_NONE) && (TPayant.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche TPayant.", standardError, TPayant.lastError) ;
      TPayant.close() ;
      return false ;
    }
  } // fin du while

  // on ferme la base
  TPayant.lastError = TPayant.close() ;
  if (TPayant.lastError != DBIERR_NONE)
  {
  	erreur("Erreur de fermeture du fichier TPayant.", standardError, TPayant.lastError);
    return false ;
	}

	return true ;
}

boolNSActDocument::CalculeTotaux(NSComptInfo* pComptInfo)
{
	if (!pComptInfo)
		return false ;

	int     paieLoc, paieEuro;
	int		resteDuLoc, resteDuEuro;
	string  sNumCompt = string(pComptInfo->pDonnees->numcompt) ;

	if (!InitFactArray(sNumCompt))
  {
  	erreur("Erreur � l'initialisation du tableau des fiches Fact", standardError, 0) ;
    return false ;
  }

  if (!InitTPArray(sNumCompt))
  {
  	erreur("Erreur � l'initialisation du tableau des fiches Tiers-Payant", standardError, 0) ;
    return false ;
  }

	totaux.totalLoc += atoi(pComptInfo->pDonnees->duFranc);
  totaux.totalEuro += atoi(pComptInfo->pDonnees->duEuro);
  totaux.depassLoc += atoi(pComptInfo->pDonnees->depassFranc);
  totaux.depassEuro += atoi(pComptInfo->pDonnees->depassEuro);
  totaux.paieLoc += atoi(pComptInfo->pDonnees->payeFranc);
  totaux.paieEuro += atoi(pComptInfo->pDonnees->payeEuro);
  totaux.impayeLoc += (atoi(pComptInfo->pDonnees->duFranc) - atoi(pComptInfo->pDonnees->payeFranc));
  totaux.impayeEuro += (atoi(pComptInfo->pDonnees->duEuro) - atoi(pComptInfo->pDonnees->payeEuro));

  if (!(pFactArray->empty()))
	{
  	for (NSFactIter i = pFactArray->begin(); i != pFactArray->end(); i++)
		{
    	if (!strcmp((*i)->pDonnees->unite, "LOC"))
      {
      	paieLoc = atoi((*i)->pDonnees->montant);
        paieEuro = dtoi(double(paieLoc) / pVar->parite);
      }
      else
      {
      	paieEuro = atoi((*i)->pDonnees->montant);
        paieLoc = dtoi(double(paieEuro) * pVar->parite);
      }

      if (!strcmp((*i)->pDonnees->mode_paie, "E"))
      {
      	totaux.espLoc += paieLoc;
        totaux.espEuro += paieEuro;
      }
      else if (!strcmp((*i)->pDonnees->mode_paie, "C"))
      {
      	totaux.chqLoc += paieLoc;
        totaux.chqEuro += paieEuro;
      }
      else if (!strcmp((*i)->pDonnees->mode_paie, "V"))
      {
      	totaux.virLoc += paieLoc;
        totaux.virEuro += paieEuro;
      }
      else if (!strcmp((*i)->pDonnees->mode_paie, "B"))
      {
      	totaux.cbLoc += paieLoc;
        totaux.cbEuro += paieEuro;
      }
    }
	}
	resteDuLoc = 0;
  resteDuEuro = 0;

	if (!(pTPArray->empty()))
	{
    for (NSTPIter i = pTPArray->begin(); i != pTPArray->end(); i++)
    {
    	if (!strcmp((*i)->pDonnees->monnaie, "LOC"))
      {
      	resteDuLoc  += atoi((*i)->pDonnees->reste_du);
        resteDuEuro += dtoi(double(atoi((*i)->pDonnees->reste_du)) / pVar->parite);
      }
      else
      {
      	resteDuEuro += atoi((*i)->pDonnees->reste_du);
        resteDuLoc  += dtoi(double(atoi((*i)->pDonnees->reste_du)) * pVar->parite);
      }
    }
	}

  totaux.impTPLoc     +=  resteDuLoc;
  totaux.impTPEuro    +=  resteDuEuro;

  totaux.impAutreLoc  +=  atoi(pComptInfo->pDonnees->duFranc) -
                            atoi(pComptInfo->pDonnees->payeFranc) -
                            resteDuLoc;

  totaux.impAutreEuro +=  atoi(pComptInfo->pDonnees->duEuro) -
                            atoi(pComptInfo->pDonnees->payeEuro) -
                            resteDuEuro;

	return true ;
}

void
NSActDocument::InitTotauxArray()
{
	NSTotauxData data;

  data.sLibelle = "Total";
  data.montantLoc = totaux.totalLoc;
  data.montantEuro = totaux.totalEuro;
  pTotauxArray->push_back(new NSTotauxData(data));
  nbTotaux++;

	data.sLibelle = "D�passement";
  data.montantLoc = totaux.depassLoc;
  data.montantEuro = totaux.depassEuro;
  pTotauxArray->push_back(new NSTotauxData(data));
  nbTotaux++;

  data.sLibelle = "Paiement";
  data.montantLoc = totaux.paieLoc;
  data.montantEuro = totaux.paieEuro;
  pTotauxArray->push_back(new NSTotauxData(data));
  nbTotaux++;

  data.sLibelle = "Esp�ces";
  data.montantLoc = totaux.espLoc;
  data.montantEuro = totaux.espEuro;
  pTotauxArray->push_back(new NSTotauxData(data));
  nbTotaux++;

  data.sLibelle = "Ch�ques";
  data.montantLoc = totaux.chqLoc;
  data.montantEuro = totaux.chqEuro;
  pTotauxArray->push_back(new NSTotauxData(data));
  nbTotaux++;

  data.sLibelle = "Virements";
  data.montantLoc = totaux.virLoc;
  data.montantEuro = totaux.virEuro;
  pTotauxArray->push_back(new NSTotauxData(data));
  nbTotaux++;

  data.sLibelle = "Carte bancaire";
  data.montantLoc = totaux.cbLoc;
  data.montantEuro = totaux.cbEuro;
  pTotauxArray->push_back(new NSTotauxData(data));
  nbTotaux++;

  data.sLibelle = "Impay�s";
  data.montantLoc = totaux.impayeLoc;
  data.montantEuro = totaux.impayeEuro;
  pTotauxArray->push_back(new NSTotauxData(data));
  nbTotaux++;

  data.sLibelle = "Impay�s Tiers-payant";
  data.montantLoc = totaux.impTPLoc;
  data.montantEuro = totaux.impTPEuro;
  pTotauxArray->push_back(new NSTotauxData(data));
  nbTotaux++;

  data.sLibelle = "Impay�s Autres";
  data.montantLoc = totaux.impAutreLoc;
  data.montantEuro = totaux.impAutreEuro;
  pTotauxArray->push_back(new NSTotauxData(data));
  nbTotaux++;
}

boolNSActDocument::CherchePatient(string sNumSS, string& sNomPatient, NSPersonInfo& patInfo)
{
	NSPersonInfo tempInfo(pContexte, sNumSS, pidsPatient) ;

	sNomPatient = "" ;

	// on fabrique le nom long et on le stocke dans la string

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	sNomPatient = tempInfo.sCivilite ;
  patInfo = NSPersonInfo(tempInfo) ;
	// patInfo.initAdresseInfo() ;	// patInfo.initCorrespArray() ;

	return true ;
}
/*
//// 	InitFse1610Array : Charge les fiches 1610 dans NSFseArray
//
bool
NSActDocument::InitFse1610Array(string sNumCompt)
{
	string		sNumFse1610 = sNumCompt + string("    ");
	NSFse1610 Fse1610(pContexte) ;

  Fse1610.lastError = Fse1610.open() ;
  if (Fse1610.lastError != DBIERR_NONE)
  {
  	erreur("Erreur � l'ouverture de la base Fse1610.", standardError, Fse1610.lastError) ;
    return false ;
  }

  Fse1610.lastError = Fse1610.chercheClef(&sNumFse1610,
      														        "",
                                          0,
																          keySEARCHGEQ,
                                          dbiWRITELOCK) ;

	if (Fse1610.lastError == DBIERR_BOF)	// cas fichier vide
  {
   	Fse1610.close() ;
    return true ;		// le tableau est vide
  }

  if ((Fse1610.lastError != DBIERR_NONE) && (Fse1610.lastError != DBIERR_EOF))
  {
   	erreur("Erreur � la recherche d'une fiche Fse1610.", standardError, Fse1610.lastError) ;
    Fse1610.close() ;
    return false ;
  }

  while (Fse1610.lastError != DBIERR_EOF)  {
  	Fse1610.lastError = Fse1610.getRecord() ;
    if (Fse1610.lastError != DBIERR_NONE)
    {
    	erreur("Erreur � la lecture d'une fiche Fse1610.", standardError, Fse1610.lastError) ;
      Fse1610.close() ;
      return false ;
    }

    // condition d'arret
    if (!(string(Fse1610.pDonnees->numcompt) == sNumCompt))
    	break ;

    // on remplit le tableau
    pFseArray->push_back(new NSBlocFse16(&Fse1610)) ;
    nbPrest++ ;

    // ... on passe au composant suivant
    Fse1610.lastError = Fse1610.suivant(dbiWRITELOCK) ;
    if ((Fse1610.lastError != DBIERR_NONE) && (Fse1610.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche Fse1610.", standardError, Fse1610.lastError) ;
      Fse1610.close() ;
      return false ;
    }
  } // fin du while

  // on ferme la base Fse1610
  Fse1610.lastError = Fse1610.close() ;
  if (Fse1610.lastError != DBIERR_NONE)
  {
  	erreur("Erreur de fermeture du fichier Fse1610.", standardError, Fse1610.lastError) ;
    return false ;
  }

	return true ;
}

//// 	InitFse1620Array : Charge les fiches 1620 dans NSFseArray
//
bool
NSActDocument::InitFse1620Array(string sNumCompt)
{
	string 		sNumFse1620 = sNumCompt + string("    ");
	NSFse1620 Fse1620(pContexte) ;

	Fse1620.lastError = Fse1620.open() ;
	if (Fse1620.lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture de la base Fse1620.", standardError, Fse1620.lastError) ;
		return false ;
	}

	Fse1620.lastError = Fse1620.chercheClef(&sNumFse1620,
                                          "",
                                          0,
                                          keySEARCHGEQ,
                                          dbiWRITELOCK) ;

	if (Fse1620.lastError == DBIERR_BOF)	// cas fichier vide
	{
  	Fse1620.close() ;
		return true ;		// le tableau est vide
	}

	if ((Fse1620.lastError != DBIERR_NONE) && (Fse1620.lastError != DBIERR_EOF))
	{
		erreur("Erreur � la recherche d'une fiche Fse1620.", standardError, Fse1620.lastError) ;
		Fse1620.close() ;
		return false ;
	}

	while (Fse1620.lastError != DBIERR_EOF)
	{
  	Fse1620.lastError = Fse1620.getRecord() ;
		if (Fse1620.lastError != DBIERR_NONE)
		{
    	erreur("Erreur � la lecture d'une fiche Fse1620.", standardError, Fse1620.lastError) ;
      Fse1620.close() ;
      return false ;
    }

    // condition d'arret
    if (!(string(Fse1620.pDonnees->numcompt) == sNumCompt))
    	break ;

    // on remplit le tableau
    pFseArray->push_back(new NSBlocFse16(&Fse1620)) ;
    nbPrest++ ;

    // ... on passe au composant suivant
    Fse1620.lastError = Fse1620.suivant(dbiWRITELOCK) ;
    if ((Fse1620.lastError != DBIERR_NONE) && (Fse1620.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche Fse1620.", standardError, Fse1620.lastError) ;
      Fse1620.close() ;
      return false ;
    }
	} // fin du while (recherche des composants images)

	// on ferme la base Fse1620
	Fse1620.lastError = Fse1620.close() ;
	if (Fse1620.lastError != DBIERR_NONE)
	{
   	erreur("Erreur de fermeture du fichier Fse1620.", standardError, Fse1620.lastError) ;
    return false ;
	}

	return true ;
}

//// 	InitFse1630Array : Charge les fiches 1630 dans NSFseArray
//
bool
NSActDocument::InitFse1630Array(string sNumCompt)
{
	string 		sNumFse1630 = sNumCompt + string("    ");
	NSFse1630* 	pFse1630 = new NSFse1630(pContexte);

   pFse1630->lastError = pFse1630->open();
   if (pFse1630->lastError != DBIERR_NONE)
   {
   	erreur("Erreur � l'ouverture de la base Fse1630.", standardError, 0) ;
      delete pFse1630;
      return false;
   }

   pFse1630->lastError = pFse1630->chercheClef(&sNumFse1630,
      														 "",
																 0,
																 keySEARCHGEQ,
																 dbiWRITELOCK);

   if (pFse1630->lastError == DBIERR_BOF)	// cas fichier vide
   {
   	pFse1630->close();
      delete pFse1630;
      return true;		// le tableau est vide
   }

   if ((pFse1630->lastError != DBIERR_NONE) && (pFse1630->lastError != DBIERR_EOF))
   {
   	erreur("Erreur � la recherche d'une fiche Fse1630.", standardError, pFse1630->lastError) ;
      pFse1630->close();
      delete pFse1630;
      return false;
   }

   while (pFse1630->lastError != DBIERR_EOF)
   {
   	pFse1630->lastError = pFse1630->getRecord();
      if (pFse1630->lastError != DBIERR_NONE)
      {
      	erreur("Erreur � la lecture d'une fiche Fse1630.", standardError, pFse1630->lastError) ;
         pFse1630->close();
         delete pFse1630;
         return false;
      }

      // condition d'arret
      if (!(string(pFse1630->pDonnees->numcompt) == sNumCompt)) break;

      // on remplit le tableau
      pFseArray->push_back(new NSBlocFse16(pFse1630));
      nbPrest++;

      // ... on passe au composant suivant      pFse1630->lastError = pFse1630->suivant(dbiWRITELOCK);
      if ((pFse1630->lastError != DBIERR_NONE) && (pFse1630->lastError != DBIERR_EOF))
      {
      	erreur("Erreur d'acces � une fiche Fse1630.", standardError, pFse1630->lastError) ;
         pFse1630->close();
         delete pFse1630;
         return false;
      }
   } // fin du while (recherche des composants images)

   // on ferme la base Fse1630
   pFse1630->lastError = pFse1630->close();
   if (pFse1630->lastError != DBIERR_NONE)
   {
   	erreur("Erreur de fermeture du fichier Fse1630.", standardError, pFse1630->lastError) ;
      delete pFse1630;
      return false;
   }

   delete pFse1630;
   return true;
}

//
// 	InitFse1610Array : Charge les fiches 1610 dans NSFseArray
//
bool
NSActDocument::InitCCAMArray(string sNumCompt)
{
	// string		sNumCCAM = sNumCompt + string("    ") ;
  string		sNumCCAM = sNumCompt ;
	NSFseCCAM FseCCAM(pContexte) ;

  FseCCAM.lastError = FseCCAM.open() ;
  if (FseCCAM.lastError != DBIERR_NONE)
  {
  	erreur("Erreur � l'ouverture de la base FseCCAM.", standardError, FseCCAM.lastError) ;
    return false ;
  }

  FseCCAM.lastError = FseCCAM.chercheClef(&sNumCCAM,
      														        "",
                                          0,
																          keySEARCHGEQ,
                                          dbiWRITELOCK) ;

	if (FseCCAM.lastError == DBIERR_BOF)	// cas fichier vide
  {
   	FseCCAM.close() ;
    return true ;		// le tableau est vide
  }

  if ((FseCCAM.lastError != DBIERR_NONE) && (FseCCAM.lastError != DBIERR_EOF))
  {
   	erreur("Erreur � la recherche d'une fiche FseCCAM.", standardError, FseCCAM.lastError) ;
    FseCCAM.close() ;
    return false ;
  }

  while (FseCCAM.lastError != DBIERR_EOF)  {
  	FseCCAM.lastError = FseCCAM.getRecord() ;
    if (FseCCAM.lastError != DBIERR_NONE)
    {
    	erreur("Erreur � la lecture d'une fiche FseCCAM.", standardError, FseCCAM.lastError) ;
      FseCCAM.close() ;
      return false ;
    }

    // condition d'arret
    if (!(string(FseCCAM.pDonnees->numcompt) == sNumCompt))
    	break ;

    // on remplit le tableau
    pFseArray->push_back(new NSBlocFse16(&FseCCAM)) ;
    nbPrest++ ;

    // ... on passe au composant suivant
    FseCCAM.lastError = FseCCAM.suivant(dbiWRITELOCK) ;
    if ((FseCCAM.lastError != DBIERR_NONE) && (FseCCAM.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche FseCCAM.", standardError, FseCCAM.lastError) ;
      FseCCAM.close() ;
      return false ;
    }
  } // fin du while

  // on ferme la base Fse1610
  FseCCAM.lastError = FseCCAM.close() ;
  if (FseCCAM.lastError != DBIERR_NONE)
  {
  	erreur("Erreur de fermeture du fichier FseCCAM.", standardError, FseCCAM.lastError) ;
    return false ;
  }

	return true ;
}
*/

bool
NSActDocument::ChercheActes(string sNumCompt)
{
	if (NULL == pFseArray)
		return false ;

	pFseArray->vider() ;
  nbPrest = 0 ;

  NSComptInfo comptInfo ;
  strcpy(comptInfo.pDonnees->numcompt, sNumCompt.c_str()) ;

  // on remplit le tableau
	if (!comptInfo.InitFse1610Array(pFseArray, &nbPrest, pContexte))
		return false ;

	if (!comptInfo.InitFse1620Array(pFseArray, &nbPrest, pContexte))		return false ;

	if (!comptInfo.InitFse1630Array(pFseArray, &nbPrest, pContexte))		return false ;

	if (!comptInfo.InitCCAMArray(pFseArray, &nbPrest, pContexte))
		return false ;
	if (pFseArray->empty())		return true ;

	// on trie par num�ro de prestation
  sort(pFseArray->begin(), pFseArray->end(), blocInferieur) ;

	return true ;
}

void
NSActDocument::SommeActes(string& sActes)
{
	char prest[255] ;
	char cCode[255] ;
	char cCoeff[255] ;
	int  divis, coeff ;
	bool bPremier = true ;

	sActes = "" ;

	for (int i = 0; i < nbPrest; i++)
	{
		switch (((*pFseArray)[i])->typePrest)
		{
    	case 1:
      {
      	NSFse1610Info* p1610 = ((*pFseArray)[i])->p1610 ;

        if (NULL != p1610)
        {
      		strcpy(cCode, p1610->pDonnees->code) ;

        	divis = atoi(p1610->pDonnees->divis) ;
        	coeff = atoi(p1610->pDonnees->coeff) * divis ;

        	if ((coeff % 100) == 0)
        		sprintf(cCoeff, "%d", coeff/100) ;
        	else
        		sprintf(cCoeff, "%d,%02d", coeff/100, coeff%100) ;

        	if (divis == 1)
        		sprintf(prest, "%s %s", cCode, cCoeff) ;
        	else
        		sprintf(prest, "%s %s/%d", cCode, cCoeff, divis) ;
        }
      }
        break ;

      case 2:
      	sprintf(prest, "%s", ((*pFseArray)[i])->p1620->pDonnees->code_ifd) ;
        break ;

      case 3:
      	sprintf(prest, "%s", ((*pFseArray)[i])->p1630->pDonnees->code_ik) ;
				break ;

      case 4:
      {
        NSFseCCAMInfo* pCCAM = ((*pFseArray)[i])->pCCAM ;

        if (NULL != pCCAM)
        {
      		strcpy(prest, pCCAM->pDonnees->code) ;

          if (pCCAM->pDonnees->pourcent[0] != '\0')
          {
          	coeff = atoi(pCCAM->pDonnees->pourcent) ;

        		if ((coeff % 100) == 0)
            {
        			sprintf(cCoeff, "%d", coeff) ;
              strcat(prest, " ") ;
              strcat(prest, cCoeff) ;
              strcat(prest, "%") ;
            }
          }
        }
      }
      	break ;

      default:
      	erreur("Type de prestation erronn� dans la liste des prestations", standardError, 0) ;
        return ;
    }

		if (!bPremier)
    	sActes += string(" + ") ;
    else
    	bPremier = false ;

    sActes += string(prest) ;
	}
}

int
NSActDocument::EstDansExamArray(string sCode, NSExamArray* pArray)
{
	if ((!pArray) || (pArray->empty()))
		return -1 ;

	NSExamIter i ;
	int 			 j ;

	for (i = pArray->begin(), j = 0; i != pArray->end(); i++, j++)
		if ((*i)->sCodeExam == sCode)
    	return j ;

	return -1 ;
}

intNSActDocument::EstDansKCodeArray(string sKCode, NSKCodeArray* pArray)
{
	if ((!pArray) || (pArray->empty()))
		return -1 ;

	NSKCodeIter i ;
	int 			  j ;

	for (i = pArray->begin(), j = 0; i != pArray->end(); i++, j++)
  	if ((*i)->sKCode == sKCode)
    	return j ;

	return -1 ;
}

int
NSActDocument::EstDansCCAMCodeArray(string sCCAMCode, NSCCAMCodeArray* pArray)
{
	if ((!pArray) || (pArray->empty()))
		return -1 ;

	NSCCAMCodeIter i ;
	int 			  j ;

	for (i = pArray->begin(), j = 0; i != pArray->end(); i++, j++)
  	if ((*i)->sCCAMCode == sCCAMCode)
    	return j ;

	return -1 ;
}

voidNSActDocument::InitKCodes(NSComptInfo* pComptInfo)
{
	int 		j, k;
  double      coeff = 0.0, quantite = 0.0;
  string 		sCode, sCodeExam;
  NSKCodeData kcodeData;
  NSExamData  examData;

	sCodeExam = string(pComptInfo->pDonnees->examen) + string(pComptInfo->pDonnees->synonyme) ;

	j = EstDansExamArray(sCodeExam, pExamArray);

	if (j >= 0)
  	(*pExamArray)[j]->nbExam += 1;
	else
	{
  	examData.sCodeExam = sCodeExam;
    examData.nbExam = 1;

    pExamArray->push_back(new NSExamData(examData));
    nbExam++;
  }

  // on reprend j pour pouvoir ins�rer les KCodes
	j = EstDansExamArray(sCodeExam, pExamArray);

	for (NSFse16Iter i = pFseArray->begin(); i != pFseArray->end(); i++)
  {
  	switch ((*i)->typePrest)
    {
    	case 1:
      	sCode = string((*i)->p1610->pDonnees->code) ;
        coeff = atof((*i)->p1610->pDonnees->coeff) / 100 ;
        quantite = coeff * atoi((*i)->p1610->pDonnees->quantite) ;
        break ;

      case 2:
      	sCode = string((*i)->p1620->pDonnees->code_ifd) ;
        quantite = atoi((*i)->p1620->pDonnees->quantite) ;
        break ;

      case 3:
      	sCode = string((*i)->p1630->pDonnees->code_ik) ;
        quantite = atoi((*i)->p1630->pDonnees->nbre_km) ;
        break ;

      case 4:
      	sCode = string((*i)->pCCAM->pDonnees->code) ;
        break ;
    }

    if ((*i)->typePrest < 4)
    {
    	k = EstDansKCodeArray(sCode, &((*pExamArray)[j]->aKCodeArray)) ;

    	if (k >= 0)
    		((*pExamArray)[j]->aKCodeArray)[k]->occur += quantite ;
    	else
    	{
    		kcodeData.sKCode = sCode ;
      	kcodeData.occur = quantite ;

      	((*pExamArray)[j]->aKCodeArray).push_back(new NSKCodeData(kcodeData)) ;
    	}

    	k = EstDansKCodeArray(sCode, pKCodeArray) ;

    	if (k >= 0)
    		(*pKCodeArray)[k]->occur += quantite ;
    	else
    	{
    		kcodeData.sKCode = sCode ;
      	kcodeData.occur = quantite ;

      	pKCodeArray->push_back(new NSKCodeData(kcodeData)) ;
      	nbKCode++ ;
    	}
    }
    else if ((*i)->typePrest == 4)
    {
    	sCode = string((*i)->pCCAM->pDonnees->code) ;

      int iPourcent = 100 ;
      if ((*i)->pCCAM->pDonnees->pourcent[0] != '\0')
      	iPourcent = atoi((*i)->pCCAM->pDonnees->pourcent) ;
      double dQuantity = double(iPourcent) / 100 ;

      int iSomme = 0 ;
      if ((*i)->pCCAM->pDonnees->montant_e[0] != '\0')
      	iSomme = atoi((*i)->pCCAM->pDonnees->montant_e) ;
      double dSomme = double(iSomme) / 100 ;

      k = EstDansKCodeArray(sCode, &((*pExamArray)[j]->aKCodeArray)) ;

    	if (k >= 0)
    		((*pExamArray)[j]->aKCodeArray)[k]->occur += dQuantity ;
    	else
    	{
    		kcodeData.sKCode = sCode ;
      	kcodeData.occur = dQuantity ;

      	((*pExamArray)[j]->aKCodeArray).push_back(new NSKCodeData(kcodeData)) ;
    	}

      k = EstDansCCAMCodeArray(sCode, pCCAMCodeArray) ;

      if (k >= 0)
      {
      	(*pCCAMCodeArray)[k]->dNbre     += dQuantity ;
        (*pCCAMCodeArray)[k]->dSomTotal += dSomme ;
      }
      else
    	{
      	NSCCAMCodeData* pCCAMCodeData = new NSCCAMCodeData ;

        pCCAMCodeData->sCCAMCode = sCode ;
   			pCCAMCodeData->sCCAMlib  = "" ;
   			pCCAMCodeData->dNbre     = dQuantity ;
   			pCCAMCodeData->dSomTotal = dSomme ;

      	pCCAMCodeArray->push_back(pCCAMCodeData) ;
      	nbCCAMCode++ ;
    	}
    }
  }
}

boolNSActDocument::SelectionCriteres(NSComptInfo* pComptInfo)
{
	if (pCriteres->bActesPerso)
		if (strcmp(pComptInfo->pDonnees->operateur, pContexte->getUtilisateur()->getNss().c_str()))
			return false ;

	if (pCriteres->sCodeExamen != "")
  	if (!(pCriteres->sCodeExamen == string(pComptInfo->pDonnees->examen)))
    	return false ;

	if (pCriteres->sCodePrescript != "")
  	if (!(pCriteres->sCodePrescript == string(pComptInfo->pDonnees->prescript)))
    	return false ;

	if ((pCriteres->iImpayes == 1) && (strcmp(pComptInfo->pDonnees->okPaye, "0")))		return false ;

	if ((pCriteres->iImpayes == 2) && (strcmp(pComptInfo->pDonnees->okPaye, "1")))
  	return false ;

	if ((pCriteres->iContexte == 1) && (pComptInfo->pDonnees->contexte[0] != '\0'))
  	return false ;

	if ((pCriteres->iContexte == 2) && (strcmp(pComptInfo->pDonnees->contexte, "NEXTE")))
  	return false ;

	if ((pCriteres->iContexte == 4) && (strcmp(pComptInfo->pDonnees->contexte, "NHOST")))
  	return false ;

  if ((pCriteres->iContexte == 8) && (strcmp(pComptInfo->pDonnees->contexte, "NAMBU")))
  	return false ;

	return true ;}
bool
NSActDocument::InitActArray(bool bAvecPatient)
{
	NSCompt       Compt(pContexte) ;
  NSListActData ActData(pContexte) ;

  string			  sNumSS, sNomLong ;
  string 			  sCodeExam, sLibExam, sActes ;

  NSPersonInfo  patInfo(pContexte) ;

  pActArray->vider() ;
  nbAct = 0 ;

  Compt.lastError = Compt.open() ;
  if (Compt.lastError != DBIERR_NONE)
  {
  	erreur("Erreur � l'ouverture de la base Compt.", standardError, Compt.lastError) ;
    return false ;
  }

  // on cherche les Compt par date
  Compt.lastError = Compt.chercheClef(&(pCriteres->sDate1),
                                            "DATE_COMPT",
                                            NODEFAULTINDEX,
                                            keySEARCHGEQ,
                                            dbiWRITELOCK);

	if (Compt.lastError == DBIERR_BOF)	// cas fichier vide
  {
  	Compt.close() ;
    return true ;		// le tableau est vide
  }

  if ((Compt.lastError != DBIERR_NONE) && (Compt.lastError != DBIERR_EOF))
  {
  	erreur("Erreur � la recherche d'une fiche Compt.", standardError, Compt.lastError) ;
    Compt.close() ;
    return false ;
  }

  string sLang = "";
  if ((pContexte) && (pContexte->getUtilisateur()))
  	sLang = pContexte->getUtilisateur()->donneLang() ;

	CptaSearchProgressDialog progessDialog(pContexte->GetMainWindow(), pContexte) ;
	progessDialog.Create() ;
	progessDialog.Show(SW_SHOW) ;

  while (Compt.lastError != DBIERR_EOF)
  {
  	pContexte->getSuperviseur()->getApplication()->PumpWaitingMessages() ;

  	if (progessDialog.isStopped())
    {
    	pCriteres->bInterruptedProcess = true ;
    	break ;
    }

  	Compt.lastError = Compt.getRecord() ;
    if (Compt.lastError != DBIERR_NONE)
    {
    	erreur("Erreur � la lecture d'une fiche Compt.", standardError, Compt.lastError) ;
      Compt.close() ;
      return false ;
    }

    progessDialog.ClearText() ;
    progessDialog.SetNewDate(string(Compt.pDonnees->date)) ;    progessDialog.SetNewCode(string(Compt.pDonnees->numcompt)) ;    progessDialog.SetAck("Lecture OK.") ;

    // cas des fiches compt repr�sentant des recettes et non des actes
    // dans ce cas le nss patient est vide et on passe au suivant    if (strcmp(Compt.pDonnees->patient, "") != 0)    {    	// condition d'arret
      if (string(Compt.pDonnees->date) > (pCriteres->sDate2))
      	break ;

      NSComptInfo ComptInfo(&Compt) ;
      if (SelectionCriteres(&ComptInfo))      {
      	ActData.metAZero();

        if (bAvecPatient)
        {
        	if (!CherchePatient(string(Compt.pDonnees->patient), sNomLong, patInfo))          {
          	erreur("Impossible de retrouver le patient rattach� � la fiche Compt.", standardError, 0) ;
            Compt.close() ;
            return false ;
          }
        }

        if (!ChercheActes(string(Compt.pDonnees->numcompt)))        {
        	erreur("Impossible de retrouver les actes rattach�s � la fiche Compt.", standardError, 0) ;
          Compt.close() ;
          return false ;
        }

        SommeActes(sActes) ;
        // incr�mente les tableaux de K-codes        InitKCodes(&ComptInfo) ;

        // incr�mente les totaux        CalculeTotaux(&ComptInfo) ;

        sCodeExam = string(Compt.pDonnees->examen) + string(Compt.pDonnees->synonyme) ;        pContexte->getDico()->donneLibelle(sLang, &sCodeExam, &sLibExam) ;

        // initialisation des donn�es communes        strcpy(ActData.numCompt, Compt.pDonnees->numcompt);
        strcpy(ActData.dateCompt, Compt.pDonnees->date);
        if (bAvecPatient)
        	strcpy(ActData.nomPatient, sNomLong.c_str());
        strcpy(ActData.libExam, sLibExam.c_str());
        strcpy(ActData.actes, sActes.c_str());

        if (bAvecPatient)
        	ActData.patInfo = patInfo;
        pActArray->push_back(new NSListActData(ActData)) ;        nbAct++ ;
      }
    }

    // ... on passe � la fiche Compt suivante
    Compt.lastError = Compt.suivant(dbiWRITELOCK) ;
    if ((Compt.lastError != DBIERR_NONE) && (Compt.lastError != DBIERR_EOF))    {
    	erreur("Erreur d'acces � une fiche Compt.", standardError, Compt.lastError) ;
      Compt.close() ;
      return false ;
    }
  } // fin du while

  // on ferme la base COMPT
  Compt.lastError = Compt.close();
  if (Compt.lastError != DBIERR_NONE)
  	erreur("Erreur de fermeture du fichier Compt.", standardError, Compt.lastError) ;

	return true ;
}

//***************************************************************************//  							M�thodes de NSListActWindow
//***************************************************************************

DEFINE_RESPONSE_TABLE1(NSListActWindow, TListWindow)
   EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

void
NSListActWindow::SetupWindow()
{
	ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;
	TListWindow::SetupWindow() ;
}

//---------------------------------------------------------------------------
//  Function: NSListActWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListActWindow::EvLButtonDblClk(uint /* modKeys */, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point) ;

	HitTest(info) ;

	if (info.GetFlags() & LVHT_ONITEM)
		pDlg->CmModifAct() ;
}

//---------------------------------------------------------------------------//  Function: NSListActWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListActWindow::IndexItemSelect()
{
	int count = GetItemCount() ;
	int index = -1 ;

	for (int i = 0; i < count; i++)
  	if (GetItemState(i, LVIS_SELECTED))
    {
    	index = i ;
      break ;
    }

	return index ;
}

//***************************************************************************//
//  M�thodes de NSListActDialog
//
//***************************************************************************

DEFINE_RESPONSE_TABLE1(NSListActDialog, NSUtilDialog)	EV_LV_DISPINFO_NOTIFY(IDC_LA_LW, LVN_GETDISPINFO, DispInfoListeAct),
  EV_COMMAND(IDC_LA_IMPRIMER, CmImprimer),
  EV_COMMAND(IDOK, CmOk),
  EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

//// Constructeur
//
NSListActDialog::NSListActDialog(TWindow* pere, NSContexte* pCtx, NSActDocument* pActDoc)
                :NSUtilDialog(pere, pCtx, "IDD_LISTACTES", pNSResModule)
{
	pDoc      = pActDoc ;

  pLibelle  = new TStatic(this, IDC_LA_LIBELLE) ;
	pListeAct = new NSListActWindow(this, IDC_LA_LW) ;
	pVar      = new NSVarCompta(pCtx) ;
}

//// Destructeur
//
NSListActDialog::~NSListActDialog()
{
	delete pLibelle ;
	delete pListeAct ;
	delete pVar ;
}

//// Fonction SetupWindow
//
void
NSListActDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	string sLibelle = pDoc->pCriteres->getSummaryString(pContexte) ;
  pLibelle->SetText(sLibelle.c_str()) ;

	InitListeAct() ;
	AfficheListeAct() ;
}

voidNSListActDialog::InitListeAct()
{
	TListWindColumn colDate("Date", 80, TListWindColumn::Left, 0) ;
	pListeAct->InsertColumn(0, colDate) ;
	TListWindColumn colNomPat("Nom - Pr�nom", 100, TListWindColumn::Left, 1) ;
	pListeAct->InsertColumn(1, colNomPat) ;
	TListWindColumn colCode("Code", 50, TListWindColumn::Left, 2) ;
	pListeAct->InsertColumn(2, colCode) ;
	TListWindColumn colExam("Examen", 160, TListWindColumn::Left, 3) ;
	pListeAct->InsertColumn(3, colExam) ;
	TListWindColumn colActes("Actes", 150, TListWindColumn::Left, 4) ;
	pListeAct->InsertColumn(4, colActes) ;
}

voidNSListActDialog::AfficheListeAct()
{
	char cDateExam[9] = "" ;
	char dateExam[11] = "" ;

	pListeAct->DeleteAllItems() ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	for (int i = pDoc->nbAct - 1; i >= 0; i--)
	{
  	strcpy(cDateExam, ((*(pDoc->pActArray))[i])->dateCompt) ;
   	donne_date(cDateExam, dateExam, sLang) ;
   	TListWindItem Item(dateExam, 0) ;
    pListeAct->InsertItem(Item) ;
	}
}

voidNSListActDialog::DispInfoListeAct(TLwDispInfoNotify& dispInfo)
{
	const int 	BufLen = 255 ;
	static char buffer[BufLen] ;
	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;

	int index = dispInfoItem.GetIndex();

	// Affiche les informations en fonction de la colonne

	switch (dispInfoItem.GetSubItem())
	{
   	case 1: // nom long patient

    	sprintf(buffer, "%s", ((*(pDoc->pActArray))[index])->nomPatient) ;
      dispInfoItem.SetText(buffer) ;
      break ;

    case 2: // code nautilus patient

    	sprintf(buffer, "%s", ((*(pDoc->pActArray))[index])->patInfo.sPersonID.c_str()) ;
      dispInfoItem.SetText(buffer) ;      break ;

    case 3: // examen

    	sprintf(buffer, "%s", ((*(pDoc->pActArray))[index])->libExam) ;
      dispInfoItem.SetText(buffer) ;
      break ;

   	case 4: // actes

    	sprintf(buffer, "%s", ((*(pDoc->pActArray))[index])->actes) ;
      dispInfoItem.SetText(buffer) ;
      break ;

	} // fin du switch
}

voidNSListActDialog::CmModifAct()
{
	int index = pListeAct->IndexItemSelect() ;
	if (index == -1)
	{
  	erreur("Vous devez s�lectionner une fiche Act.", warningError, 0) ;
    return ;
	}

	string sNumCompt = string(((*(pDoc->pActArray))[index])->numCompt) ;

	NSCompt Compt(pContexte) ;

	Compt.lastError = Compt.open() ;
	if (Compt.lastError != DBIERR_NONE)
	{
  	erreur("Erreur � l'ouverture de la base Compt.", standardError, Compt.lastError) ;
    return ;
	}

	Compt.lastError = Compt.chercheClef(&sNumCompt,
	                                    "",
                                      0,
                                      keySEARCHEQ,
                                      dbiWRITELOCK) ;

	if (Compt.lastError != DBIERR_NONE)
	{
  	erreur("Erreur � la recherche d'une fiche compt.", standardError, Compt.lastError) ;
    Compt.close() ;
    return ;
	}

	Compt.lastError = Compt.getRecord() ;
	if (Compt.lastError != DBIERR_NONE)
	{
		erreur("Erreur � lecture du fichier Compt.db", standardError, Compt.lastError) ;
    Compt.close() ;
    return ;
	}

	// on lance la modif des infos r�cup�r�es
	NSPersonInfo PatInfo((*(pDoc->pActArray))[index]->patInfo) ;

	CreerFicheComptDialog* pComptDlg = new CreerFicheComptDialog(this, pContexte, &PatInfo, false) ;

	*(pComptDlg->pData) = *(Compt.pDonnees) ;

	if ((pComptDlg->Execute()) == IDCANCEL)
	{
  	Compt.close() ;
    delete pComptDlg ;
    return ;
	}

	// on stocke les donnees du dialogue dans les Data
	*(Compt.pDonnees) = *(pComptDlg->pData) ;

	Compt.lastError = Compt.modifyRecord(TRUE) ;
	if (Compt.lastError != DBIERR_NONE)
	{
  	erreur("Erreur � la modification de la fiche compt.", standardError, Compt.lastError) ;
    Compt.close() ;
    delete pComptDlg ;
    return ;
	}

	Compt.lastError = Compt.close() ;
	if (Compt.lastError != DBIERR_NONE)
  	erreur("Erreur � la fermeture de la base Compt.db.", standardError, Compt.lastError) ;

	// on enregistre les autres donnees sous le meme numcompt
	pComptDlg->EnregDonneesCompt(sNumCompt) ;

	delete pComptDlg ;
	// on recharge le tableau depuis la base car on a pu modifier la fiche Compt.
	pDoc->InitActArray(true) ;
	AfficheListeAct() ;
}

voidNSListActDialog::CmImprimer()
{
	pDoc->bImprimer = true ;
	CmOk() ;
}

voidNSListActDialog::CmOk()
{
	NSUtilDialog::CmOk() ;
}

voidNSListActDialog::CmCancel()
{
	NSUtilDialog::CmCancel() ;
}

//***************************************************************************//
//  M�thodes de NSSomActDialog
//
//***************************************************************************
DEFINE_RESPONSE_TABLE1(NSSomActDialog, NSUtilDialog)
	EV_LV_DISPINFO_NOTIFY(IDC_SOMACTES_EXAMENS, LVN_GETDISPINFO, DispInfoListeExam),
	EV_LV_DISPINFO_NOTIFY(IDC_SOMACTES_TOTAUX, LVN_GETDISPINFO, DispInfoListeTotaux),
	EV_LV_DISPINFO_NOTIFY(IDC_SOMACTES_KCODES, LVN_GETDISPINFO, DispInfoListeKCode),
  EV_COMMAND(IDC_SOMACTES_IMPRIMER, CmImprimer),
  EV_COMMAND(IDOK, CmOk),
  EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

//// Constructeur
//
NSSomActDialog::NSSomActDialog(TWindow* pere, NSContexte* pCtx, NSActDocument* pActDoc)
							 : NSUtilDialog(pere, pCtx, "IDD_SOMACTES", pNSResModule)
{
	pDoc = pActDoc ;

  pLibelle      = new TStatic(this, IDC_SOMACTES_LIBELLE) ;
	pListeExam 		= new TListWindow(this, IDC_SOMACTES_EXAMENS) ;
	pListeTotaux 	= new TListWindow(this, IDC_SOMACTES_TOTAUX) ;
	pListeKCode 	= new TListWindow(this, IDC_SOMACTES_KCODES) ;
	pVar          = new NSVarCompta(pCtx) ;
}

//// Destructeur
//
NSSomActDialog::~NSSomActDialog()
{
	delete pLibelle ;
	delete pListeExam ;
	delete pListeTotaux ;
	delete pListeKCode ;
	delete pVar ;
}

//
// Fonction SetupWindow
//
void
NSSomActDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	pDoc->InitTotauxArray() ;

	InitListeExam() ;
	AfficheListeExam() ;
  InitListeTotaux() ;
  AfficheListeTotaux() ;
  InitListeKCode() ;
  AfficheListeKCode() ;

  string sLibelle = pDoc->pCriteres->getSummaryString(pContexte) ;
  pLibelle->SetText(sLibelle.c_str()) ;
}

void
NSSomActDialog::InitListeExam()
{
	TListWindColumn colExam("Examen", 160, TListWindColumn::Left, 0) ;
	pListeExam->InsertColumn(0, colExam) ;
	TListWindColumn colNombre("Nombre", 50, TListWindColumn::Left, 1) ;
  pListeExam->InsertColumn(1, colNombre) ;
  TListWindColumn colCode("Code", 250, TListWindColumn::Left, 2) ;
	pListeExam->InsertColumn(2, colCode) ;
}

void
NSSomActDialog::AfficheListeExam()
{
	char cLibExam[255] = "" ;
	string sCodeExam, sLibExam ;

	pListeExam->DeleteAllItems() ;

	string sLang = "" ;
	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;

	for (int i = pDoc->nbExam - 1; i >= 0; i--)
	{
  	sCodeExam = ((*(pDoc->pExamArray))[i])->sCodeExam ;
    pContexte->getDico()->donneLibelle(sLang, &sCodeExam, &sLibExam) ;
    strcpy(cLibExam, sLibExam.c_str()) ;
    TListWindItem Item(cLibExam, 0) ;
    pListeExam->InsertItem(Item) ;
	}
}

voidNSSomActDialog::DispInfoListeExam(TLwDispInfoNotify& dispInfo)
{
	const int 	BufLen = 255 ;
	static char buffer[BufLen] ;
	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;
	int 			  index ;
	char			  cCodeExam[80] ;
	int			    occur ;

	index = dispInfoItem.GetIndex() ;

	// Affiche les informations en fonction de la colonne

	switch (dispInfoItem.GetSubItem())
	{
  	case 1: // nombre d'examens

    	sprintf(buffer, "%d", ((*(pDoc->pExamArray))[index])->nbExam) ;
      dispInfoItem.SetText(buffer) ;
      break ;

    case 2: // codes li�s aux examens

    	strcpy(buffer, "") ;

      for (NSKCodeIter i = ((*(pDoc->pExamArray))[index])->aKCodeArray.begin() ;
         					i != ((*(pDoc->pExamArray))[index])->aKCodeArray.end();
                        i++)
      {
      	occur = (*i)->occur * 100 ;
        if ((occur%100) == 0)
					sprintf(cCodeExam, " %s(%d)", ((*i)->sKCode).c_str(), occur/100) ;
        else
        	sprintf(cCodeExam, " %s(%d,%02d)", ((*i)->sKCode).c_str(), occur/100, occur%100) ;

        strcat(buffer, cCodeExam) ;
      }
      dispInfoItem.SetText(buffer) ;
      break ;
   } // fin du switch
}

void
NSSomActDialog::InitListeTotaux()
{
	char cSigle[50] ;

	strcpy(cSigle, (pVar->sigle).c_str()) ;

	TListWindColumn colValeur("Valeur", 80, TListWindColumn::Left, 0) ;
	pListeTotaux->InsertColumn(0, colValeur) ;
	TListWindColumn colLoc(cSigle, 80, TListWindColumn::Right, 1) ;
	pListeTotaux->InsertColumn(1, colLoc) ;
	TListWindColumn colEuro("Euros", 80, TListWindColumn::Right, 2) ;
	pListeTotaux->InsertColumn(2, colEuro) ;
}

voidNSSomActDialog::AfficheListeTotaux()
{
	char 	 cValeur[255] = "" ;
	string sValeur ;

	pListeTotaux->DeleteAllItems() ;

	for (int i = pDoc->nbTotaux - 1; i >= 0; i--)
	{
  	sValeur = ((*(pDoc->pTotauxArray))[i])->sLibelle ;
    strcpy(cValeur, sValeur.c_str()) ;
   	TListWindItem Item(cValeur, 0) ;
    pListeTotaux->InsertItem(Item) ;
	}
}

void
NSSomActDialog::DispInfoListeTotaux(TLwDispInfoNotify& dispInfo)
{
	const int 	BufLen = 255;
   static char buffer[BufLen];
   TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item;
   int 			index;
   int			montant;

   index = dispInfoItem.GetIndex();

   // Affiche les informations en fonction de la colonne

   switch (dispInfoItem.GetSubItem())
   {
   	case 1: // montant en monnaie locale

      	montant = ((*(pDoc->pTotauxArray))[index])->montantLoc;
         sprintf(buffer, "%d,%02d", montant/100, montant%100);
         dispInfoItem.SetText(buffer);
         break;

      case 2: // montant en Euros

      	montant = ((*(pDoc->pTotauxArray))[index])->montantEuro;
         sprintf(buffer, "%d,%02d", montant/100, montant%100);
         dispInfoItem.SetText(buffer);
         break;
   } // fin du switch
}

voidNSSomActDialog::InitListeKCode()
{
	TListWindColumn colTotal("Total", 150, TListWindColumn::Left, 0) ;
  pListeKCode->InsertColumn(0, colTotal) ;
	TListWindColumn colNombre("Nombre", 80, TListWindColumn::Left, 1) ;
  pListeKCode->InsertColumn(1, colNombre) ;
}

void
NSSomActDialog::AfficheListeKCode()
{
	char 		cTotal[255] = "" ;
	string 	sKCode ;

	pListeKCode->DeleteAllItems() ;

  for (int i = pDoc->nbCCAMCode - 1; i >= 0; i--)
  {
  	sKCode = ((*(pDoc->pCCAMCodeArray))[i])->sCCAMCode ;
    sprintf(cTotal, "%s", sKCode.c_str()) ;
   	TListWindItem Item(cTotal, 0) ;
    pListeKCode->InsertItem(Item) ;
	}

	for (int i = pDoc->nbKCode - 1; i >= 0; i--)
  {
  	sKCode = ((*(pDoc->pKCodeArray))[i])->sKCode ;
    sprintf(cTotal, "Nombre de %s", sKCode.c_str()) ;
   	TListWindItem Item(cTotal, 0) ;
    pListeKCode->InsertItem(Item) ;
	}
}

void
NSSomActDialog::DispInfoListeKCode(TLwDispInfoNotify& dispInfo)
{
	const int 	BufLen = 255 ;
	static char buffer[BufLen] ;
  static char subBuffer[BufLen] ;
	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;

	int 			  iKCodeSize = pDoc->pKCodeArray->size() ;
	int			    occur ;
	int         index = dispInfoItem.GetIndex() ;

	// Affiche les informations en fonction de la colonne

	switch (dispInfoItem.GetSubItem())
	{
		case 1: // nombre d'occurences du code

    	if (index < iKCodeSize)
      {
    		occur = ((*(pDoc->pKCodeArray))[index])->occur * 100 ;
    		if ((occur%100) == 0)
       		sprintf(buffer, "%d", occur/100) ;
    		else
      		sprintf(buffer, "%d,%02d", occur/100, occur%100) ;
      }
      else
      {
      	occur = ((*(pDoc->pCCAMCodeArray))[index-iKCodeSize])->dNbre * 100 ;

        if ((occur%100) == 0)
       		sprintf(buffer, "%d", occur/100) ;
    		else
      		sprintf(buffer, "%d,%02d", occur/100, occur%100) ;

        strcat(buffer, " (") ;

   			occur = ((*(pDoc->pCCAMCodeArray))[index-iKCodeSize])->dSomTotal * 100 ;

        if ((occur%100) == 0)
       		sprintf(subBuffer, "%d", occur/100) ;
    		else
      		sprintf(subBuffer, "%d,%02d", occur/100, occur%100) ;

        strcat(buffer, subBuffer) ;
        strcat(buffer, " Euros)") ;
      }

      dispInfoItem.SetText(buffer) ;
      break ;
	} // fin du switch
}

voidNSSomActDialog::CmImprimer(){
	pDoc->bImprimer = true ;
	CmOk() ;
}

void
NSSomActDialog::CmOk()
{
	NSUtilDialog::CmOk() ;
}

void
NSSomActDialog::CmCancel()
{
	NSUtilDialog::CmCancel() ;
}

//***************************************************************************
//  							M�thodes de NSEncaissDocument
//***************************************************************************

// Constructeur NSEncaissDocument////////////////////////////////////////////////////////////////
NSEncaissDocument::NSEncaissDocument(TDocument* parent, NSDocumentInfo* pDocumentInfo,
										NSDocumentInfo* pDocHtmlInfo, NSContexte* pCtx)
				  :NSNoyauDocument(parent, pDocumentInfo, pDocHtmlInfo, pCtx, true)
{
	// Initialisation des donnees
   pCriteres 		= new NSMultiCriteres;
   pTotaux			= new NSEncaissData;
   pPartiels		= new NSEncaissData;
   pFactArray		= new NSFactArray;
   nbFact			= 0;
	pVar 			= new NSVarCompta(pCtx);
   bImprimer		= false;
}

NSEncaissDocument::NSEncaissDocument(TDocument *parent, NSContexte *pCtx)
				  :NSNoyauDocument(parent, pCtx)
{
	// Initialisation des donnees
   pCriteres 		= new NSMultiCriteres;
   pTotaux			= new NSEncaissData;
   pPartiels		= new NSEncaissData;
   pFactArray		= new NSFactArray;
   nbFact			= 0;
	pVar 				= new NSVarCompta(pCtx);
   bImprimer		= false;
}

NSEncaissDocument::~NSEncaissDocument(){
	delete pVar;
   delete pTotaux;
   delete pPartiels;
   delete pFactArray;
   delete pCriteres;
}

// Ouverture du document
////////////////////////////////////////////////////////////////
bool NSEncaissDocument::Open(int /* mode */, LPCSTR /* path */)
{
	if (!LanceCriteres())
   	return false;

	if (!InitFactArray())
   	return false;

   CalculeTotaux();

  	return true;
}

// Fermeture du document
////////////////////////////////////////////////////////////////
bool NSEncaissDocument::Close()
{
  	return true;
}

bool
NSEncaissDocument::LanceCriteres()
{
	NSFactCriteresDialog* pCriteresDlg =
   	new NSFactCriteresDialog(pContexte->GetMainWindow(), pContexte);

   if (pCriteresDlg->Execute() != IDOK)
   {
   	delete pCriteresDlg;
      return false;
   }

   *pCriteres = *(pCriteresDlg->pCriteres);

   delete pCriteresDlg;
   return true;
}

boolNSEncaissDocument::SelectionCriteres(NSFactInfo* pFactInfo)
{
	if (pCriteres->bActesPerso)
		if (strcmp(pFactInfo->pDonnees->operateur, pContexte->getUtilisateur()->getNss().c_str()))
			return false ;

	if (pCriteres->sCodeOrga == "#A")     		// tous + patients   	return true;

	if (pCriteres->sCodeOrga == "#B")		// tous - patients	{
  	if (!strcmp(pFactInfo->pDonnees->organisme, ""))
    	return false ;
	}
  else if (pCriteres->sCodeOrga == "#C")		// patients seulement
  {
  	if (strcmp(pFactInfo->pDonnees->organisme, ""))
    	return false ;
  }
	else
	{
  	if (!(string(pFactInfo->pDonnees->organisme) == pCriteres->sCodeOrga))
    	return false ;
	}

	return true ;}

boolNSEncaissDocument::InitFactArray()
{
	NSFact* 		pFact = new NSFact(pContexte);
   NSFactInfo* pFactInfo;

   pFactArray->vider();
   nbFact = 0;

   pFact->lastError = pFact->open();
   if (pFact->lastError != DBIERR_NONE)
   {
   	erreur("Erreur � l'ouverture de la base Fact.", standardError, 0) ;
      delete pFact;
      return false;
   }

   // on cherche les Fact par date
   pFact->lastError = pFact->chercheClef(&(pCriteres->sDate1),
      														 "DATE_FACT",
																 NODEFAULTINDEX,
																 keySEARCHGEQ,
																 dbiWRITELOCK);

   if (pFact->lastError == DBIERR_BOF)	// cas fichier vide
   {
   	pFact->close();
      delete pFact;
      return true;		// le tableau est vide
   }

   if ((pFact->lastError != DBIERR_NONE) && (pFact->lastError != DBIERR_EOF))
   {
   	erreur("Erreur � la recherche d'une fiche Fact.", standardError, pFact->lastError) ;
      pFact->close();
      delete pFact;
      return false;
   }

   while (pFact->lastError != DBIERR_EOF)
   {
   	pFact->lastError = pFact->getRecord();
      if (pFact->lastError != DBIERR_NONE)
      {
      	erreur("Erreur � la lecture d'une fiche Fact.", standardError, pFact->lastError) ;
         pFact->close();         delete pFact;
         return false;
      }

      // condition d'arret      if (string(pFact->pDonnees->date_paie) > (pCriteres->sDate2)) break;

      pFactInfo = new NSFactInfo(pFact);

      if (SelectionCriteres(pFactInfo))
      {
         pFactArray->push_back(new NSFactInfo(*pFactInfo));
         nbFact++;
      }

      delete pFactInfo;

      // ... on passe � la fiche Fact suivante
      pFact->lastError = pFact->suivant(dbiWRITELOCK);
      if ((pFact->lastError != DBIERR_NONE) && (pFact->lastError != DBIERR_EOF))
      {
      	erreur("Erreur d'acces � une fiche Fact.", standardError, pFact->lastError) ;
         pFact->close();
         delete pFact;
         return false;
      }
   } // fin du while

   // on ferme la base Fact
   pFact->lastError = pFact->close();
   if (pFact->lastError != DBIERR_NONE)
   	erreur("Erreur de fermeture du fichier Fact.", standardError, pFact->lastError) ;

   delete pFact;
   return true;
}

voidNSEncaissDocument::CalculeTotaux()
{
    int montant;

	for (NSFactIter i = pFactArray->begin(); i != pFactArray->end(); i++)
    {
   	    montant = atoi((*i)->pDonnees->montant);

   	    if (!strcmp((*i)->pDonnees->mode_paie, "E"))
        {
      	    if (!strcmp((*i)->pDonnees->unite, "LOC"))
            {
         	    pTotaux->espLoc     += montant;
                pTotaux->espEuro    += dtoi(double(montant) / pVar->parite);
                pPartiels->espLoc   += montant;
            }
            else
            {
         	    pTotaux->espEuro    += montant;
                pTotaux->espLoc     += dtoi(double(montant) * pVar->parite);
                pPartiels->espEuro  += montant;
            }
        }
        else if (!strcmp((*i)->pDonnees->mode_paie, "C"))
        {
      	    if (!strcmp((*i)->pDonnees->unite, "LOC"))
            {
         	    pTotaux->chqLoc     += montant;
                pTotaux->chqEuro    += dtoi(double(montant) / pVar->parite);
                pPartiels->chqLoc   += montant;
            }
            else
            {
         	    pTotaux->chqEuro    += montant;
                pTotaux->chqLoc     += dtoi(double(montant) * pVar->parite);
                pPartiels->chqEuro  += montant;
            }
        }
        else if (!strcmp((*i)->pDonnees->mode_paie, "V"))
        {
      	    if (!strcmp((*i)->pDonnees->unite, "LOC"))
            {
         	    pTotaux->virLoc     += montant;
                pTotaux->virEuro    += dtoi(double(montant) / pVar->parite);
                pPartiels->virLoc   += montant;
            }
            else
            {
         	    pTotaux->virEuro    += montant;
                pTotaux->virLoc     += dtoi(double(montant) * pVar->parite);
                pPartiels->virEuro  += montant;
            }
        }
        else if (!strcmp((*i)->pDonnees->mode_paie, "B"))
        {
      	    if (!strcmp((*i)->pDonnees->unite, "LOC"))
            {
         	    pTotaux->cbLoc      += montant;
                pTotaux->cbEuro     += dtoi(double(montant) / pVar->parite);
                pPartiels->cbLoc    += montant;
            }
            else
            {
         	    pTotaux->cbEuro     += montant;
                pTotaux->cbLoc      += dtoi(double(montant) * pVar->parite);
                pPartiels->cbEuro   += montant;
            }
        }

        if (!strcmp((*i)->pDonnees->unite, "LOC"))
        {
      	    pTotaux->paieLoc    += montant;
            pTotaux->paieEuro   += dtoi(double(montant) / pVar->parite);
            pPartiels->paieLoc  += montant;
        }
        else
        {
      	    pTotaux->paieEuro   += montant;
            pTotaux->paieLoc    += dtoi(double(montant) * pVar->parite);
            pPartiels->paieEuro += montant;
      }
   }
}

//***************************************************************************
//
//  M�thodes de NSSomEncaissDialog
//
//***************************************************************************

DEFINE_RESPONSE_TABLE1(NSSomEncaissDialog, NSUtilDialog)
	EV_LV_DISPINFO_NOTIFY(IDC_SE_LOC, LVN_GETDISPINFO, DispInfoListeLoc),
	EV_LV_DISPINFO_NOTIFY(IDC_SE_EURO, LVN_GETDISPINFO, DispInfoListeEuro),
   EV_LV_DISPINFO_NOTIFY(IDC_SE_GLOBAL, LVN_GETDISPINFO, DispInfoListeGlobal),
   EV_COMMAND(IDC_SE_IMPRIMER, CmImprimer),
   EV_COMMAND(IDOK, CmOk),
   EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

//
// Constructeur
//
NSSomEncaissDialog::NSSomEncaissDialog(TWindow* pere, NSContexte* pCtx, NSEncaissDocument* pEncaissDoc)
							 : NSUtilDialog(pere, pCtx, "IDD_SOMENCAISS", pNSResModule)
{
	pDoc				   = pEncaissDoc ;

	pTotauxArray	 = new NSTotauxArray ;
	nbTotaux			 = 0 ;
	pPartielsArray = new NSTotauxArray ;
	nbPartiels		 = 0 ;

  pLibelle       = new TStatic(this, IDC_SE_LIBELLE) ;
	pListeLoc 		 = new TListWindow(this, IDC_SE_LOC) ;
	pListeEuro	 	 = new TListWindow(this, IDC_SE_EURO) ;
	pListeGlobal 	 = new TListWindow(this, IDC_SE_GLOBAL) ;
	pMonnaie			 = new TStatic(this, IDC_SE_MONNAIE) ;
	pVar           = new NSVarCompta(pCtx) ;
}

//// Destructeur
//
NSSomEncaissDialog::~NSSomEncaissDialog()
{
	delete pLibelle ;
	delete pTotauxArray ;
  delete pPartielsArray ;
  delete pListeLoc ;
  delete pListeEuro ;
  delete pListeGlobal ;
  delete pMonnaie ;
  delete pVar ;
}

//
// Fonction SetupWindow
//
void
NSSomEncaissDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	pMonnaie->SetCaption((pVar->sigle).c_str()) ;

	InitTotauxArrays() ;

	InitListeLoc() ;
  AfficheListeLoc() ;
  InitListeEuro() ;
  AfficheListeEuro() ;
  InitListeGlobal() ;
  AfficheListeGlobal() ;

	string sLibelle = pDoc->pCriteres->getSummaryString(pContexte) ;
  pLibelle->SetText(sLibelle.c_str()) ;
}

void
NSSomEncaissDialog::InitTotauxArrays()
{
	NSTotauxData data;

   data.sLibelle = "Paiement";
   data.montantLoc = pDoc->pTotaux->paieLoc;
   data.montantEuro = pDoc->pTotaux->paieEuro;
   pTotauxArray->push_back(new NSTotauxData(data));
   nbTotaux++;

   data.sLibelle = "Esp�ces";
   data.montantLoc = pDoc->pTotaux->espLoc;
   data.montantEuro = pDoc->pTotaux->espEuro;
   pTotauxArray->push_back(new NSTotauxData(data));
   nbTotaux++;

   data.sLibelle = "Ch�ques";
   data.montantLoc = pDoc->pTotaux->chqLoc;
   data.montantEuro = pDoc->pTotaux->chqEuro;
   pTotauxArray->push_back(new NSTotauxData(data));
   nbTotaux++;

   data.sLibelle = "Virements";
   data.montantLoc = pDoc->pTotaux->virLoc;
   data.montantEuro = pDoc->pTotaux->virEuro;
   pTotauxArray->push_back(new NSTotauxData(data));
   nbTotaux++;

   data.sLibelle = "Carte bancaire";
   data.montantLoc = pDoc->pTotaux->cbLoc;
   data.montantEuro = pDoc->pTotaux->cbEuro;
   pTotauxArray->push_back(new NSTotauxData(data));
   nbTotaux++;

   data.sLibelle = "Paiement";   data.montantLoc = pDoc->pPartiels->paieLoc;   data.montantEuro = pDoc->pPartiels->paieEuro;
   pPartielsArray->push_back(new NSTotauxData(data));
   nbPartiels++;

   data.sLibelle = "Esp�ces";
   data.montantLoc = pDoc->pPartiels->espLoc;
   data.montantEuro = pDoc->pPartiels->espEuro;
   pPartielsArray->push_back(new NSTotauxData(data));
   nbPartiels++;

   data.sLibelle = "Ch�ques";
   data.montantLoc = pDoc->pPartiels->chqLoc;
   data.montantEuro = pDoc->pPartiels->chqEuro;
   pPartielsArray->push_back(new NSTotauxData(data));
   nbPartiels++;

   data.sLibelle = "Virements";
   data.montantLoc = pDoc->pPartiels->virLoc;
   data.montantEuro = pDoc->pPartiels->virEuro;
   pPartielsArray->push_back(new NSTotauxData(data));
   nbPartiels++;

   data.sLibelle = "Carte bancaire";
   data.montantLoc = pDoc->pPartiels->cbLoc;
   data.montantEuro = pDoc->pPartiels->cbEuro;
   pPartielsArray->push_back(new NSTotauxData(data));
   nbPartiels++;
}

void
NSSomEncaissDialog::InitListeLoc()
{
	char cSigle[50];

   strcpy(cSigle, (pVar->sigle).c_str());

	TListWindColumn colValeur("Valeur", 80, TListWindColumn::Left, 0);
  	pListeLoc->InsertColumn(0, colValeur);
	TListWindColumn colLoc(cSigle, 80, TListWindColumn::Right, 1);
  	pListeLoc->InsertColumn(1, colLoc);
}

void
NSSomEncaissDialog::AfficheListeLoc()
{
	char 		cValeur[255] = "";
   string 	sValeur;

	pListeLoc->DeleteAllItems();

	for (int i = nbPartiels - 1; i >= 0; i--)
   {
   	sValeur = ((*(pPartielsArray))[i])->sLibelle;
      strcpy(cValeur, sValeur.c_str());
   	TListWindItem Item(cValeur, 0);
      pListeLoc->InsertItem(Item);
   }
}

voidNSSomEncaissDialog::DispInfoListeLoc(TLwDispInfoNotify& dispInfo)
{
	const int 	BufLen = 255;
   static char buffer[BufLen];
   TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item;
   int 			index;
   int			montant;

   index = dispInfoItem.GetIndex();

   // Affiche les informations en fonction de la colonne

   switch (dispInfoItem.GetSubItem())
   {
   	case 1: // montant en monnaie locale

      	montant = ((*(pPartielsArray))[index])->montantLoc;
         sprintf(buffer, "%d,%02d", montant/100, montant%100);
         dispInfoItem.SetText(buffer);
         break;
   } // fin du switch
}

void
NSSomEncaissDialog::InitListeEuro()
{
	TListWindColumn colValeur("Valeur", 80, TListWindColumn::Left, 0);
  	pListeEuro->InsertColumn(0, colValeur);
	TListWindColumn colEuro("Euros", 80, TListWindColumn::Right, 1);
  	pListeEuro->InsertColumn(1, colEuro);
}

void
NSSomEncaissDialog::AfficheListeEuro()
{
	char 		cValeur[255] = "";
   string 	sValeur;

	pListeEuro->DeleteAllItems();

	for (int i = nbPartiels - 1; i >= 0; i--)
   {
   	sValeur = ((*(pPartielsArray))[i])->sLibelle;
      strcpy(cValeur, sValeur.c_str());
   	TListWindItem Item(cValeur, 0);
      pListeEuro->InsertItem(Item);
   }
}

void
NSSomEncaissDialog::DispInfoListeEuro(TLwDispInfoNotify& dispInfo)
{
	const int 	BufLen = 255;
   static char buffer[BufLen];
   TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item;
   int 			index;
   int			montant;

   index = dispInfoItem.GetIndex();

   // Affiche les informations en fonction de la colonne

   switch (dispInfoItem.GetSubItem())
   {
   	case 1: // montant en monnaie locale

      	montant = ((*(pPartielsArray))[index])->montantEuro;
         sprintf(buffer, "%d,%02d", montant/100, montant%100);
         dispInfoItem.SetText(buffer);
         break;
   } // fin du switch
}

void
NSSomEncaissDialog::InitListeGlobal()
{
	char cSigle[50];

   strcpy(cSigle, (pVar->sigle).c_str());

	TListWindColumn colValeur("Valeur", 80, TListWindColumn::Left, 0);
  	pListeGlobal->InsertColumn(0, colValeur);
	TListWindColumn colLoc(cSigle, 80, TListWindColumn::Right, 1);
  	pListeGlobal->InsertColumn(1, colLoc);
   TListWindColumn colEuro("Euros", 80, TListWindColumn::Right, 2);
  	pListeGlobal->InsertColumn(2, colEuro);
}

void
NSSomEncaissDialog::AfficheListeGlobal()
{
	char 		cValeur[255] = "";
   string 	sValeur;

	pListeGlobal->DeleteAllItems();

	for (int i = nbTotaux - 1; i >= 0; i--)
   {
   	sValeur = ((*(pTotauxArray))[i])->sLibelle;
      strcpy(cValeur, sValeur.c_str());
   	TListWindItem Item(cValeur, 0);
      pListeGlobal->InsertItem(Item);
   }
}

void
NSSomEncaissDialog::DispInfoListeGlobal(TLwDispInfoNotify& dispInfo)
{
	const int 	BufLen = 255;
   static char buffer[BufLen];
   TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item;
   int 			index;
   int			montant;

   index = dispInfoItem.GetIndex();

   // Affiche les informations en fonction de la colonne

   switch (dispInfoItem.GetSubItem())
   {
   	case 1: // montant en monnaie locale

      	montant = ((*(pTotauxArray))[index])->montantLoc;
         sprintf(buffer, "%d,%02d", montant/100, montant%100);
         dispInfoItem.SetText(buffer);
         break;

      case 2: // montant en Euros

      	montant = ((*(pTotauxArray))[index])->montantEuro;
         sprintf(buffer, "%d,%02d", montant/100, montant%100);
         dispInfoItem.SetText(buffer);
         break;
   } // fin du switch
}

void
NSSomEncaissDialog::CmImprimer()
{
   pDoc->bImprimer = true;
   CmOk();
}

void
NSSomEncaissDialog::CmOk()
{
	NSUtilDialog::CmOk();
}

voidNSSomEncaissDialog::CmCancel()
{
	NSUtilDialog::CmCancel();
}

//***************************************************************************
//
//  M�thodes de NSMultiCriteresDialog
//
//***************************************************************************
DEFINE_RESPONSE_TABLE1(NSMultiCriteresDialog, NSUtilDialog)
   EV_COMMAND(IDOK, CmOk),
   EV_COMMAND(IDCANCEL, CmCancel),
   EV_BN_CLICKED(IDC_MC_PRESCRIPT, CmPrescript),
END_RESPONSE_TABLE;

//// Constructeur
//
NSMultiCriteresDialog::NSMultiCriteresDialog(TWindow* pere, NSContexte* pCtx)
							 : NSUtilDialog(pere, pCtx, "IDD_MULTICRITERES", pNSResModule)
{
	// Initialisation des donnees
	pCriteres 	= new NSMultiCriteres ;

	// Cr�ation de tous les "objets de contr�le"
	pDate1 	 		= new NSUtilEditDate(pContexte, this, IDC_MC_DATE1) ;
	pDate2			= new NSUtilEditDate(pContexte, this, IDC_MC_DATE2) ;
	pExamen			= new NSUtilLexique(pContexte, this, IDC_MC_EXAMEN, pCtx->getDico()) ;
	pPrescript	= new TStatic(this, IDC_MC_PRESCRIPT) ;
	pActes			= new TGroupBox(this, IDC_MC_ACTES) ;
	pActesPerso	= new TRadioButton(this, IDC_MC_ACTES_PERSO, pActes) ;
	pActesTous	= new TRadioButton(this, IDC_MC_ACTES_TOUS, pActes) ;
	pImp				= new TGroupBox(this, IDC_MC_IMP) ;
	pImpTous		= new TRadioButton(this, IDC_MC_IMP_TOUS, pImp) ;
	pImpImpayes	= new TRadioButton(this, IDC_MC_IMP_IMPAYES, pImp) ;
	pImpPayes		= new TRadioButton(this, IDC_MC_IMP_PAYES, pImp) ;
	pCtxt				= new TGroupBox(this, IDC_MC_CTXT) ;
	pCtxtTous		= new TRadioButton(this, IDC_MC_CTXT_TOUS, pCtxt) ;
	pCtxtNP		  = new TRadioButton(this, IDC_MC_CTXT_NP,   pCtxt) ;
  pCtxtExt		= new TRadioButton(this, IDC_MC_CTXT_EXT,  pCtxt) ;
  pCtxtAmbu		= new TRadioButton(this, IDC_MC_CTXT_AMBU, pCtxt) ;
	pCtxtHosp		= new TRadioButton(this, IDC_MC_CTXT_HOSP, pCtxt) ;
}

//// Destructeur
//
NSMultiCriteresDialog::~NSMultiCriteresDialog()
{
	delete pCriteres ;
	delete pDate1 ;
	delete pDate2 ;
	delete pExamen ;
	delete pPrescript ;
	delete pActes ;
	delete pActesPerso ;
	delete pActesTous ;
	delete pImp ;
	delete pImpTous ;
	delete pImpImpayes ;
	delete pImpPayes ;
	delete pCtxt ;
	delete pCtxtTous ;
	delete pCtxtNP ;
  delete pCtxtExt ;
  delete pCtxtAmbu ;
	delete pCtxtHosp ;
}

//// Fonction SetupWindow
//
void
NSMultiCriteresDialog::SetupWindow()
{
	// fichiers d'aide
	sHindex = "" ;	sHcorps = "Comptabilite.html" ;
	TDate	dateSys ;
	char	dateJour[9] = "" ;

	NSUtilDialog::SetupWindow() ;

	sprintf(dateJour, "%4d%02d%02d", (int)dateSys.Year(),
      				(int)dateSys.Month(), (int)dateSys.DayOfMonth()) ;

	pDate1->setDate(dateJour) ;
	pDate2->setDate(dateJour) ;

	pActesTous->Check() ;
	pImpTous->Check() ;
	pCtxtTous->Check() ;
}

voidNSMultiCriteresDialog::CmPrescript()
{
try
{
	string sTitre ;

  NSTPersonListDialog indep((TWindow *)this, pidsCorresp, false, pContexte, 0, true) ;
  int	iDialogReturn = indep.Execute() ;
  if (iDialogReturn != IDOK)
  	return ;

	NSPersonInfo *temp = indep.pPersonSelect ;
  if (string("") == temp->sPersonID)
		return ;

	string sPids = temp->sPersonID ;
	pCriteres->sCodePrescript = sPids ;

	NSPersonInfo* pPersonInfo = pContexte->getPersonArray()->getPerson(sPids, pidsCorresp) ;
  if (NULL == pPersonInfo)
  	return ;

	sTitre = pPersonInfo->sNom + " " + pPersonInfo->sPrenom ;

  pPrescript->SetCaption(sTitre.c_str()) ;
	pCriteres->sTitrePrescript = sTitre ;

/*
	ChercheListeCorDialog* pListeCorDlg ;
	pListeCorDlg = new ChercheListeCorDialog(this, pContexte, pNSResModule) ;
	if ((pListeCorDlg->Execute() == IDOK) && (pListeCorDlg->CorrespChoisi >= 0))
	{
  	pCriteres->sCodePrescript = string(pListeCorDlg->pCorrespSelect->pDonnees->code) ;
    sTitre = pListeCorDlg->pCorrespSelect->pDonnees->donneTitre() ;
    pPrescript->SetCaption(sTitre.c_str()) ;
    pCriteres->sTitrePrescript = sTitre ;
	}
	delete pListeCorDlg ;
*/

}
catch (...)
{
	erreur("Exception NSMultiCriteresDialog::CmPrescript.", standardError, 0) ;
}
}

voidNSMultiCriteresDialog::CmOk()
{	string 	sDate, sCode ;
	char far cfTexte[7] = "" ;

	pDate1->getDate(&sDate) ;

	if (sDate == "")
	{
		erreur("Vous devez saisir une date de d�but.", standardError, 0) ;
    return ;
	}
	pCriteres->sDate1 = sDate ;

	pDate2->getDate(&sDate) ;

	if (sDate == "")
	{
		erreur("Vous devez saisir une date de fin.", warningError, 0) ;
		return ;
	}
	pCriteres->sDate2 = sDate ;

	if ((pCriteres->sDate2) < (pCriteres->sDate1))
	{
		erreur("La date de d�but ne peut etre sup�rieure � la date de fin.", warningError, 0) ;
		return ;
	}

	pExamen->GetText(cfTexte, 7) ;
	if (!strcmp(cfTexte, ""))
	{
		pCriteres->sCodeExamen = "" ;
		pCriteres->sSynExamen = "" ;
	}
	else
	{
		sCode = pExamen->getCode() ;
	  pCriteres->sCodeExamen = string(sCode, 0, 5) ;
		pCriteres->sSynExamen = string(sCode, 5, 1) ;
	}

	if (pActesPerso->GetCheck() == BF_CHECKED)
		pCriteres->bActesPerso = true ;
	else if (pActesTous->GetCheck() == BF_CHECKED)
		pCriteres->bActesPerso = false ;
	else
	{
		erreur("Vous devez saisir un choix (Vos actes / Tous les actes).", warningError, 0) ;
		return ;
	}

	if (pImpTous->GetCheck() == BF_CHECKED)
		pCriteres->iImpayes = 0;
	else if (pImpImpayes->GetCheck() == BF_CHECKED)
		pCriteres->iImpayes = 1;
	else if (pImpPayes->GetCheck() == BF_CHECKED)
		pCriteres->iImpayes = 2;
	else
	{
		erreur("Vous devez choisir un critere pour les impayes.", warningError, 0) ;
		return ;
	}

	if      (pCtxtTous->GetCheck() == BF_CHECKED)
		pCriteres->iContexte = 0 ;
	else if (pCtxtNP->GetCheck()   == BF_CHECKED)
		pCriteres->iContexte = 1 ;
  else if (pCtxtExt->GetCheck()  == BF_CHECKED)
		pCriteres->iContexte = 2 ;
	else if (pCtxtHosp->GetCheck() == BF_CHECKED)
		pCriteres->iContexte = 4 ;
	else if (pCtxtAmbu->GetCheck() == BF_CHECKED)
		pCriteres->iContexte = 8 ;
	else
	{
   	erreur("Vous devez choisir un contexte.", warningError, 0) ;
		return ;
	}

	TDialog::CmOk() ;
}

voidNSMultiCriteresDialog::CmCancel()
{
	TDialog::CmCancel();
}

//***************************************************************************
//
//  M�thodes de NSFactCriteresDialog
//
//***************************************************************************

DEFINE_RESPONSE_TABLE1(NSFactCriteresDialog, NSUtilDialog)
   EV_COMMAND(IDOK, CmOk),
   EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

//// Constructeur
//
NSFactCriteresDialog::NSFactCriteresDialog(TWindow* pere, NSContexte* pCtx)
							 : NSUtilDialog(pere, pCtx, "IDD_FACTCRITERES", pNSResModule)
{
	// Initialisation des donnees
	pCriteres   = new NSMultiCriteres ;

	// Cr�ation de tous les "objets de contr�le"
	pDate1 	 		= new NSUtilEditDate(pContexte, this, IDC_FC_DATE1) ;
	pDate2			= new NSUtilEditDate(pContexte, this, IDC_FC_DATE2) ;
	pActes			= new TGroupBox(this, IDC_FC_ACTES) ;
	pActesPerso = new TRadioButton(this, IDC_FC_ACTES_PERSO, pActes) ;
	pActesTous  = new TRadioButton(this, IDC_FC_ACTES_TOUS, pActes) ;
	pOrga				= new TComboBox(this, IDC_FC_ORGA) ;

	pCodeOrgaArray = new NSCodeOrgaArray ;
	nbCodeOrga		 = 0 ;
}

//
// Destructeur
//
NSFactCriteresDialog::~NSFactCriteresDialog()
{
	delete pCriteres ;
  delete pDate1 ;
  delete pDate2 ;
  delete pActes ;
  delete pActesPerso ;
  delete pActesTous ;
  delete pOrga ;
  delete pCodeOrgaArray ;
}

//
// Fonction SetupWindow
//
void
NSFactCriteresDialog::SetupWindow()
{
	// fichiers d'aide
  sHindex = "" ;
  sHcorps = "Comptabilite.html" ;
	TDate	dateSys ;
	char	dateJour[9] = "" ;

	NSUtilDialog::SetupWindow() ;

	sprintf(dateJour, "%4d%02d%02d", (int)dateSys.Year(),
      				(int)dateSys.Month(), (int)dateSys.DayOfMonth()) ;

	pDate1->setDate(dateJour) ;
	pDate2->setDate(dateJour) ;

	pActesTous->Check() ;

	// on charge la table des organismes
	if (!InitCodeOrgaArray())
	{
		erreur("Probleme au chargement du tableau des codes organisme.", standardError, 0) ;
		return ;
	}

	pOrga->SetSelIndex(0) ;
}

bool
NSFactCriteresDialog::InitCodeOrgaArray()
{
	NSCodeOrga      CodeOrga(pContexte) ;
	NSCodeOrgaInfo* pInfoDebut = new NSCodeOrgaInfo ;

	strcpy(pInfoDebut->pDonnees->code, "#A") ;
	strcpy(pInfoDebut->pDonnees->lib_court, "Tous + patients") ;
	strcpy(pInfoDebut->pDonnees->lib_long, pInfoDebut->pDonnees->lib_court) ;
	pCodeOrgaArray->push_back(new NSCodeOrgaInfo(*pInfoDebut)) ;
	pOrga->AddString(pInfoDebut->pDonnees->lib_court) ;
	nbCodeOrga++ ;

	strcpy(pInfoDebut->pDonnees->code, "#B") ;
	strcpy(pInfoDebut->pDonnees->lib_court, "Tous - patients") ;
	strcpy(pInfoDebut->pDonnees->lib_long, pInfoDebut->pDonnees->lib_court) ;
	pCodeOrgaArray->push_back(new NSCodeOrgaInfo(*pInfoDebut)) ;
	pOrga->AddString(pInfoDebut->pDonnees->lib_court) ;
	nbCodeOrga++ ;

	strcpy(pInfoDebut->pDonnees->code, "#C") ;
	strcpy(pInfoDebut->pDonnees->lib_court, "Patients") ;
	strcpy(pInfoDebut->pDonnees->lib_long, pInfoDebut->pDonnees->lib_court) ;
	pCodeOrgaArray->push_back(new NSCodeOrgaInfo(*pInfoDebut)) ;
	pOrga->AddString(pInfoDebut->pDonnees->lib_court) ;
	nbCodeOrga++ ;

	CodeOrga.lastError = CodeOrga.open() ;
	if (CodeOrga.lastError != DBIERR_NONE)
	{
  	erreur("Erreur � l'ouverture de la base CodeOrga.", standardError, CodeOrga.lastError) ;
		return false ;
	}

	CodeOrga.lastError = CodeOrga.debut(dbiWRITELOCK) ;
	if ((CodeOrga.lastError != DBIERR_NONE) && (CodeOrga.lastError != DBIERR_EOF))
	{
		erreur("Erreur de positionnement dans le fichier CodeOrga.db.", standardError, CodeOrga.lastError) ;
		CodeOrga.close() ;
		return false ;
	}

	while (CodeOrga.lastError != DBIERR_EOF)
	{
  	CodeOrga.lastError = CodeOrga.getRecord() ;
		if (CodeOrga.lastError != DBIERR_NONE)
		{
    	erreur("Erreur � la lecture d'une fiche CodeOrga.", standardError, CodeOrga.lastError) ;
      CodeOrga.close() ;
      return false ;
    }

    // on remplit le tableau et la combobox
    pCodeOrgaArray->push_back(new NSCodeOrgaInfo(&CodeOrga)) ;
    pOrga->AddString(CodeOrga.pDonnees->lib_court) ;
    nbCodeOrga++ ;

    // ... on passe au composant suivant
    CodeOrga.lastError = CodeOrga.suivant(dbiWRITELOCK) ;
    if ((CodeOrga.lastError != DBIERR_NONE) && (CodeOrga.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche CodeOrga.", standardError, CodeOrga.lastError) ;
      CodeOrga.close() ;
      return false ;
    }
	} // fin du while (recherche des composants images)

	// on ferme la base CODEORGA
	CodeOrga.lastError = CodeOrga.close() ;
	if (CodeOrga.lastError != DBIERR_NONE)
	{		erreur("Erreur de fermeture du fichier CodeOrga.", standardError, CodeOrga.lastError) ;
		return false ;
	}

	return true ;
}

void
NSFactCriteresDialog::CmOk()
{
	string sDate, sCode ;
	int    indexOrga ;

	pDate1->getDate(&sDate) ;

	if (sDate == "")
	{
  	erreur("Vous devez saisir une date de d�but.", warningError, 0) ;
    return ;
	}
	pCriteres->sDate1 = sDate ;

	pDate2->getDate(&sDate) ;

	if (sDate == "")
	{
  	erreur("Vous devez saisir une date de fin.", warningError, 0) ;
    return ;
	}
	pCriteres->sDate2 = sDate ;

	if ((pCriteres->sDate2) < (pCriteres->sDate1))
	{
  	erreur("La date de d�but ne peut etre sup�rieure � la date de fin.", warningError, 0) ;
    return ;
	}

	if (pActesPerso->GetCheck() == BF_CHECKED)
  	pCriteres->bActesPerso = true ;
	else if (pActesTous->GetCheck() == BF_CHECKED)
		pCriteres->bActesPerso = false ;
	else
	{
  	erreur("Vous devez saisir un choix (Vos actes / Tous les actes).", warningError, 0) ;
    return ;
	}

	indexOrga = pOrga->GetSelIndex() ;
	if (indexOrga >= 0)
	{
  	pCriteres->sCodeOrga = string((*pCodeOrgaArray)[indexOrga]->pDonnees->code) ;
    pCriteres->sLibCourtOrga = string((*pCodeOrgaArray)[indexOrga]->pDonnees->lib_court) ;
    pCriteres->sLibLongOrga = string((*pCodeOrgaArray)[indexOrga]->pDonnees->lib_long) ;
	}

	TDialog::CmOk() ;
}

voidNSFactCriteresDialog::CmCancel()
{
	TDialog::CmCancel() ;
}

//***********************************************************************////							Classe NsvCheckTransferDialog
//***********************************************************************//

DEFINE_RESPONSE_TABLE1(CptaSearchProgressDialog, NSUtilDialog)	EV_COMMAND(IDC_CHECK_STOP, StopProcess),END_RESPONSE_TABLE;

CptaSearchProgressDialog::CptaSearchProgressDialog(TWindow* pere, NSContexte* pCtx)
                         :NSUtilDialog(pere, pCtx, "IDD_CPTA_SEARCH_PROCESS", pNSResModule)
{
	pCurrentDate = new TStatic(this, IDC_DISPLAY_DATE) ;
	pCurrentCode = new TStatic(this, IDC_DISPLAY_CODE) ;
	pAck = new TStatic(this, IDC_CHECK_ACK) ;

  count      = 0 ;
  num        = 0 ;
  maxNum     = 0 ;
  maxGarbage = 0 ;

  bStop = false ;
}

CptaSearchProgressDialog::~CptaSearchProgressDialog()
{
	delete pCurrentDate ;
	delete pCurrentCode ;
	delete pAck ;
}

void
CptaSearchProgressDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow();
  // centrage du dialogue � l'�cran  //  NS_CLASSLIB::TRect rectDlg = GetWindowRect() ;//coordonn�es par % � l'�cran  NS_CLASSLIB::TRect rectMain = Parent->GetWindowRect() ;  //
  // ScreenToClient converts the screen coordinates
  // of a specified point on the screen to client coordinates.
  //  NS_CLASSLIB::TPoint point(rectDlg.X(), rectDlg.Y());
  Parent->ScreenToClient(point);
  int X = point.X() ;
  int Y = point.Y() ;
  int W = rectDlg.Width() ;
  int H = rectDlg.Height() ;  X = (rectMain.Width())/2 - W/2 ;  Y = (rectMain.Height())/2 - H/2 ;  //  // fixer la nouvelle position
  //
  SetWindowPos(0, X, Y, W, H, SWP_NOZORDER) ;
}

void
CptaSearchProgressDialog::SetNewDate(string sNewDate)
{
	char cDateExam[9] = "" ;
	char dateExam[11] = "" ;

  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	strcpy(cDateExam, sNewDate.c_str()) ;
	donne_date(cDateExam, dateExam, sLang) ;

	pCurrentDate->SetText(dateExam) ;
}

void
CptaSearchProgressDialog::SetNewCode(string sNewCode)
{
	pCurrentCode->SetText(sNewCode.c_str()) ;
}

void
CptaSearchProgressDialog::SetAck(string sAck)
{
	pAck->SetText(sAck.c_str()) ;
}

void
CptaSearchProgressDialog::ClearText()
{
	pCurrentDate->SetText("") ;
	pCurrentCode->SetText("") ;
	pAck->SetText("") ;
}

void
CptaSearchProgressDialog::StopProcess()
{
	bStop = true ;
}

bool
CptaSearchProgressDialog::isStopped()
{
	return bStop ;
}

// fin de nsactdlg.cpp
///////////////////////

