// NSFseUti : Structures n�c�ssaires aux dialogues de la fiche Compt, Fact et TPayant//            + Dialogue NSListComptDialog pour les situations
// R�mi SPAAK Avril 99
/////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <classlib\date.h>
#include <classlib\time.h>

#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"
#include "nautilus\nspatdlg.h"
#include "nscompta\nscompta.h"
#include "nscompta\nscompta.rh"
#include "nscompta\nsf16dlg.h"
#include "nscompta\nsfsedlg.h"
#include "nscompta\nsfseuti.h"

//***************************************************************************
// 								Classe NSFse16Array
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFse16Array::NSFse16Array(NSFse16Array& rv) : NSFse16xxArray()
{
	if (!(rv.empty()))
		for (NSFse16Iter i = rv.begin(); i != rv.end(); i++)
   		push_back(new NSBlocFse16(*(*i))) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
void
NSFse16Array::vider()
{
	if (empty())
		return ;

	for (NSFse16Iter i = begin(); i != end(); )
	{
		delete *i ;
		erase(i) ;
	}
}

NSFse16Array::~NSFse16Array(){
	vider() ;
}

NSFse16Array&
NSFse16Array::operator=(NSFse16Array rv)
{
	vider() ;

	if (!(rv.empty()))
		for (NSFse16Iter i = rv.begin(); i != rv.end(); i++)
   		push_back(new NSBlocFse16(*(*i))) ;

	return *this ;
}

//-----------------------------------------------------------------------// fonction globale de tri des blocs Fse 16xx
//-----------------------------------------------------------------------
bool
blocInferieur(NSBlocFse16* a, NSBlocFse16* b)
{
	if ((a != NULL) && (b != NULL) && (a->sNumPrest < b->sNumPrest))
  	return true ;

	return false ;
}

//-----------------------------------------------------------------------// fonction globale de tri des FactInfo
//-----------------------------------------------------------------------
bool
factAnterieure(NSFactInfo* a, NSFactInfo* b)
{
	if ((a != NULL) && (b != NULL) &&
      (string(a->pDonnees->date_paie) < string(b->pDonnees->date_paie)))
		return true ;

	return false ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSEditDateC
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSEditDateC, NSUtilEditDate)
	EV_WM_KILLFOCUS,
END_RESPONSE_TABLE;

NSEditDateC::NSEditDateC(NSContexte *pCtx, CreerFicheComptDialog* pere, int resId, int iTextLen)
            :NSUtilEditDate(pCtx, pere, resId, iTextLen)
{
	pDlg = pere ;
}

voidNSEditDateC::EvKillFocus(HWND hWndGetFocus)
{
	NSUtilEditDate::EvKillFocus(hWndGetFocus) ;

	pDlg->MajDateC() ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSEditHeureC
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSEditHeureC, NSUtilEditHeure)
	EV_WM_KILLFOCUS,
END_RESPONSE_TABLE;

NSEditHeureC::NSEditHeureC(NSContexte *pCtx, CreerFicheComptDialog* pere, int resId, int iTextLen)             :NSUtilEditHeure(pCtx, pere, resId, iTextLen){
	pDlg = pere ;
}

voidNSEditHeureC::EvKillFocus(HWND hWndGetFocus)
{
  NSUtilEditHeure::EvKillFocus(hWndGetFocus) ;

  pDlg->MajHeureC() ;}

// -----------------------------------------------------------------//
//  M�thodes de NSEditSommeDue
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSEditSommeDue, NSUtilEditSomme)
	EV_WM_KILLFOCUS,
END_RESPONSE_TABLE;

NSEditSommeDue::NSEditSommeDue(NSContexte *pCtx, CreerFicheComptDialog* pere, int resId, int iTextLen)
               :NSUtilEditSomme(pCtx, pere, resId, iTextLen)
{
  pDlg = pere ;
}

voidNSEditSommeDue::EvKillFocus(HWND hWndGetFocus)
{
  NSUtilEditSomme::EvKillFocus(hWndGetFocus) ;

  pDlg->AfficheDepass() ;  pDlg->AfficheSommeDue() ;
  pDlg->AffichePaye() ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSListFseWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSListFseWindow, TListWindow)   EV_WM_KEYDOWN,
   EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

NSListFseWindow::NSListFseWindow(CreerFicheComptDialog* pere, int resId) :                 TListWindow(pere, resId)
{
  pDlg = pere ;

  Attr.Style |= LVS_REPORT | LVS_SHOWSELALWAYS ;  Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;
}

void
NSListFseWindow::SetupWindow()
{
  ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;

  TListWindow::SetupWindow() ;
}
// Fonction pour la suppression des fiches Fse16xx
void
NSListFseWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
  NSFse16Iter i ;
  int         j, k, indexDel, numPrest, retVal ;

  if (key == VK_DELETE)
  {
    indexDel = IndexItemSelect() ;
    if (indexDel == -1)
    {
      erreur("Vous devez s�lectionner une prestation.", standardError, 0) ;
      return;
    }

    string sCaption = string("Message ") + pDlg->pContexte->getSuperviseur()->getAppName() ;
    retVal = MessageBox("Etes-vous s�r de vouloir supprimer cette prestation ?", sCaption.c_str(), MB_YESNO) ;
    if (retVal == IDNO)
      return ;

    for (i = pDlg->pFseArray->begin(), j = 0; i != pDlg->pFseArray->end(); i++, j++)
    {
      if (j == indexDel)
      {
        delete *i ;
        pDlg->pFseArray->erase(i) ;
        pDlg->nbPrest -= 1 ;
        break ;
      }
    }

    // on remet � jour les num�ros de prestations ult�rieurs � indexDel    for (k = indexDel; k < pDlg->nbPrest; k++)
    {
      switch (((*(pDlg->pFseArray))[k])->typePrest)
      {
        case 1 :
          numPrest = atoi(((*(pDlg->pFseArray))[k])->p1610->pDonnees->numprest) ;
          sprintf(((*(pDlg->pFseArray))[k])->p1610->pDonnees->numprest, "%04d", numPrest - 1) ;
          break ;

        case 2 :
          numPrest = atoi(((*(pDlg->pFseArray))[k])->p1620->pDonnees->numprest) ;
          sprintf(((*(pDlg->pFseArray))[k])->p1620->pDonnees->numprest, "%04d", numPrest - 1) ;
          break ;

        case 3 :
          numPrest = atoi(((*(pDlg->pFseArray))[k])->p1630->pDonnees->numprest) ;
          sprintf(((*(pDlg->pFseArray))[k])->p1630->pDonnees->numprest, "%04d", numPrest - 1) ;
          break ;
        case 4 :          numPrest = atoi(((*(pDlg->pFseArray))[k])->pCCAM->pDonnees->numprest) ;
          sprintf(((*(pDlg->pFseArray))[k])->pCCAM->pDonnees->numprest, "%04d", numPrest - 1) ;
          break ;
      }
    }

    // on remet la liste � jour
    pDlg->AfficheListeFse() ;
    pDlg->AfficheSommeDue() ;
    pDlg->AffichePaye() ;
  }
}


//---------------------------------------------------------------------------
//  Function: NSListFseWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListFseWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point);

   HitTest(info);

   if (info.GetFlags() & LVHT_ONITEM)
      pDlg->CmModifFse();
}

//---------------------------------------------------------------------------
//  Function: NSListFseWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListFseWindow::IndexItemSelect()
{
	int count = GetItemCount();
   int index = -1;

   for (int i = 0; i < count; i++)
   	if (GetItemState(i, LVIS_SELECTED))
      {
      	index = i;
         break;
      }

   return index;
}

// -----------------------------------------------------------------
//
//  M�thodes de NSListFactWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSListFactWindow, TListWindow)
   EV_WM_KEYDOWN,
   EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

NSListFactWindow::NSListFactWindow(CreerFicheComptDialog* pere, int resId) :
                  TListWindow(pere, resId)
{
   	pDlg = pere;
    Attr.Style |= LVS_REPORT | LVS_SHOWSELALWAYS ;
    Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;
}voidNSListFactWindow::SetupWindow(){    ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;
    TListWindow::SetupWindow();}

// Fonction pour la suppression des fiches Fact
void
NSListFactWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
    NSFactIter  i;
    int         j, k, indexDel, numFact, retVal;

    if (key == VK_DELETE)
    {
        indexDel = IndexItemSelect();
        if (indexDel == -1)
        {
            erreur("Vous devez s�lectionner un paiement.", standardError, 0) ;
            return;
        }

        string sCaption = string("Message ") + pDlg->pContexte->getSuperviseur()->getAppName();
        retVal = MessageBox("Etes-vous s�r de vouloir supprimer ce paiement ?", sCaption.c_str(), MB_YESNO);
        if (retVal == IDNO)
            return;

        for (i = pDlg->pFactArray->begin(), j = 0; i != pDlg->pFactArray->end(); i++, j++)
        {
            if (j == indexDel)
            {
                // on annule le pr�c�dent paiement retrouv� dans FactInfo
                pDlg->IncrementeResteDu((*i)->pDonnees->organisme,
                                        (*i)->pDonnees->montant,
                                        (*i)->pDonnees->unite);

                // on supprime la fiche
                delete *i;
                pDlg->pFactArray->erase(i);
                pDlg->nbFact -= 1;
                break;
            }
        }

        // on remet � jour les num�ros de prestations ult�rieurs � indexDel
        for (k = indexDel; k < pDlg->nbFact; k++)
        {
            numFact = atoi(((*(pDlg->pFactArray))[k])->pDonnees->numero);
            sprintf(((*(pDlg->pFactArray))[k])->pDonnees->numero, "%02d", numFact - 1);
        }

        // on remet la liste � jour
        pDlg->AfficheListeFact();
        pDlg->AffichePaye();
    }
}

//---------------------------------------------------------------------------
//  Function: NSListFactWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListFactWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point);

   HitTest(info);

   if (info.GetFlags() & LVHT_ONITEM)
      pDlg->CmModifFact();
}

//---------------------------------------------------------------------------
//  Function: NSListFactWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListFactWindow::IndexItemSelect()
{
	int count = GetItemCount();
   int index = -1;

   for (int i = 0; i < count; i++)
   	if (GetItemState(i, LVIS_SELECTED))
      {
      	index = i;
         break;
      }

   return index;
}

// -----------------------------------------------------------------
//
//  M�thodes de NSListTPWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSListTPWindow, TListWindow)
   EV_WM_KEYDOWN,
   EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

NSListTPWindow::NSListTPWindow(CreerFicheComptDialog* pere, int resId) :
                TListWindow(pere, resId)
{
   	pDlg = pere;
    Attr.Style |= LVS_REPORT | LVS_SHOWSELALWAYS ;
    Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;
}
void
NSListTPWindow::SetupWindow()
{
    ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;

    TListWindow::SetupWindow();
}

// Fonction pour la suppression des fiches TPayant
void
NSListTPWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
    NSTPIter  i;
    int       j, k, indexDel, numTP, retVal;

    if (key == VK_DELETE)
    {
        indexDel = IndexItemSelect();
        if (indexDel == -1)
        {
            erreur("Vous devez s�lectionner un tiers-payant.", standardError, 0) ;
            return;
        }

        string sCaption = string("Message ") + pDlg->pContexte->getSuperviseur()->getAppName();
        retVal = MessageBox("Etes-vous s�r de vouloir supprimer ce tiers-payant ?", sCaption.c_str(), MB_YESNO);
        if (retVal == IDNO)
            return;

        for (i = pDlg->pTPArray->begin(), j = 0; i != pDlg->pTPArray->end(); i++, j++)
        {
            if (j == indexDel)
            {
                delete *i;
                pDlg->pTPArray->erase(i);
                pDlg->nbTP -= 1;
                break;
            }
        }

        // on remet � jour les num�ros de prestations ult�rieurs � indexDel
        for (k = indexDel; k < pDlg->nbTP; k++)
        {
            numTP = atoi(((*(pDlg->pTPArray))[k])->pDonnees->numero);
            sprintf(((*(pDlg->pTPArray))[k])->pDonnees->numero, "%02d", numTP - 1);
        }

        // on remet la liste � jour
        pDlg->AfficheListeTP();
    }
}

//---------------------------------------------------------------------------
//  Function: NSListTPWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListTPWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point);

   HitTest(info);

   if (info.GetFlags() & LVHT_ONITEM)
      pDlg->CmModifTP();
}

//---------------------------------------------------------------------------
//  Function: NSListTPWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListTPWindow::IndexItemSelect()
{
	int count = GetItemCount();
   int index = -1;

   for (int i = 0; i < count; i++)
   	if (GetItemState(i, LVIS_SELECTED))
      {
      	index = i;
         break;
      }

   return index;
}

// -----------------------------------------------------------------
//
//  M�thodes de NSListComptWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSListComptWindow, TListWindow)
   EV_WM_KEYDOWN,
   EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

void
NSListComptWindow::SetupWindow()
{
    ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;

    TListWindow::SetupWindow();
}

//---------------------------------------------------------------------------
//  Function: NSListComptWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListComptWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point);

   HitTest(info);

   if (info.GetFlags() & LVHT_ONITEM)
      pDlg->CmModifCompt();
}

// Fonction pour la suppression des fiches compt
void
NSListComptWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
    int indexDel, retVal;

    if (key == VK_DELETE)
    {
        indexDel = IndexItemSelect();
        if (indexDel == -1)
        {
            erreur("Vous devez s�lectionner une fiche de compta.", standardError, 0) ;
            return;
        }

        string sCaption = string("Message ") + pDlg->pContexte->getSuperviseur()->getAppName();
        retVal = MessageBox("Etes-vous s�r de vouloir supprimer cette fiche de compta ?", sCaption.c_str(), MB_YESNO);
        if (retVal == IDNO)
            return;

        pDlg->CmDeleteCompt();
    }
}

//---------------------------------------------------------------------------
//  Function: NSListComptWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListComptWindow::IndexItemSelect()
{
	int count = GetItemCount();
   int index = -1;

   for (int i = 0; i < count; i++)
   	if (GetItemState(i, LVIS_SELECTED))
      {
      	index = i;
         break;
      }

   return index;
}
// -----------------------------------------------------------------//
//  M�thodes de NSListComptDialog
//
// -----------------------------------------------------------------

// ---------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSListComptDialog, NSUtilDialog)
	EV_LV_DISPINFO_NOTIFY(IDC_LC_LW, LVN_GETDISPINFO, DispInfoListeCompt),
  EV_BN_CLICKED(IDC_LC_LOC, SwitchLocEuro),
  EV_BN_CLICKED(IDC_LC_EURO, SwitchLocEuro),
  EV_COMMAND(IDOK, CmOk),
  EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

//// Constructeur
//
NSListComptDialog::NSListComptDialog(TWindow* pere, NSContexte* pCtx, NSPersonInfo* pPat)
							    :NSUtilDialog(pere, pCtx, "IDD_LISTCOMPT", pNSResModule)
{
	pPatient		= new NSPersonInfo(*pPat) ;

	pMonnaie		= new TGroupBox(this, IDC_LC_MONNAIE) ;
	pLocal			= new TRadioButton(this, IDC_LC_LOC, pMonnaie) ;
  pEuro				= new TRadioButton(this, IDC_LC_EURO, pMonnaie) ;
	pTotalDu		= new NSUtilEdit2(pContexte, this, IDC_LC_TOTALDU, 8) ;
  pTotalPaye	= new NSUtilEdit2(pContexte, this, IDC_LC_TOTALPAYE, 8) ;

	pListeCompt = new NSListComptWindow(this, IDC_LC_LW) ;

	pComptArray = new NSComptArray ;
  nbCompt 		= 0 ;
  pVar        = new NSVarCompta(pCtx) ;

	bErreur = !InitComptArray() ;
}

//// Destructeur
//
NSListComptDialog::~NSListComptDialog()
{
	delete pPatient ;
	delete pMonnaie ;
  delete pLocal ;
  delete pEuro ;
  delete pTotalDu ;
  delete pTotalPaye ;
  delete pListeCompt ;
  delete pComptArray ;
	delete pVar ;
}

//// Fonction SetupWindow
//
void
NSListComptDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	pLocal->SetCaption((pVar->sigle).c_str()) ;

	if (pVar->monnaieRef == MONNAIE_LOCALE)
	{
		pLocal->Check() ;
		bEuro = false ;
	}
  else
  {
  	pEuro->Check() ;
    bEuro = true ;
  }

  InitListeCompt() ;
  AfficheListeCompt() ;
	AfficheTotaux() ;
}

boolNSListComptDialog::InitComptArray()
{
	NSCompt compt(pContexte) ;
	string  sCodePatient ;

	compt.lastError = compt.open() ;
	if (compt.lastError != DBIERR_NONE)	{
		erreur("Erreur � l'ouverture de la base Compt.", standardError, 0) ;
    return false ;
  }

	sCodePatient = pPatient->sPersonID ;
	compt.lastError = compt.chercheClef(&sCodePatient,
                                      "PATCOMPT",
                                      NODEFAULTINDEX,
                                      keySEARCHEQ,
                                      dbiWRITELOCK) ;

	if ((compt.lastError != DBIERR_NONE) && (compt.lastError != DBIERR_RECNOTFOUND))	{
		erreur("Erreur � la recherche de la fiche Compt du patient.", standardError, compt.lastError) ;
    compt.close() ;
		return false ;
  }

  if (compt.lastError == DBIERR_RECNOTFOUND)
  {
  	erreur("Ce patient n'a pas de fiche comptable.", standardError, 0) ;
    compt.close() ;
		return true ;
  }

  while (compt.lastError != DBIERR_EOF)
  {
  	compt.lastError = compt.getRecord() ;
    if (compt.lastError != DBIERR_NONE)
    {
    	erreur("Erreur � la lecture d'une fiche Compt.", standardError, compt.lastError) ;
      compt.close() ;
      return false ;
    }

    if (sCodePatient != string(compt.pDonnees->patient))
    	break ;

    // on remplit le tableau
    pComptArray->push_back(new NSComptInfo(&compt)) ;
    nbCompt++ ;

    // ... on passe au composant suivant
    compt.lastError = compt.suivant(dbiWRITELOCK) ;
    if ((compt.lastError != DBIERR_NONE) && (compt.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acces � une fiche Compt.", standardError, compt.lastError) ;
      compt.close() ;
      return false ;
    }
  } // fin du while (recherche des composants images)

  // on ferme la base CARTE_SV2
  compt.lastError = compt.close() ;
  if (compt.lastError != DBIERR_NONE)
  {
  	erreur("Erreur de fermeture du fichier Compt.", standardError, compt.lastError) ;
    return false ;
  }

  return true ;
}

voidNSListComptDialog::InitListeCompt()
{
	TListWindColumn colDate("Date examen", 80, TListWindColumn::Left) ;
	pListeCompt->InsertColumn(0, colDate) ;
  TListWindColumn colExam("Examen", 80, TListWindColumn::Left) ;
  pListeCompt->InsertColumn(1, colExam) ;
  TListWindColumn colSommeDue("Somme d�e", 80, TListWindColumn::Right) ;
  pListeCompt->InsertColumn(2, colSommeDue) ;
  TListWindColumn colSommePayee("Somme pay�e", 80, TListWindColumn::Right) ;
  pListeCompt->InsertColumn(3, colSommePayee) ;
}

void
NSListComptDialog::AfficheListeCompt()
{
	char dateCompt[255];

	pListeCompt->DeleteAllItems();

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	for (int i = nbCompt - 1; i >= 0; i--)
   {
		donne_date(((*pComptArray)[i])->pDonnees->date, dateCompt, sLang);
   	TListWindItem Item(dateCompt, 0);
      pListeCompt->InsertItem(Item);
   }
}

voidNSListComptDialog::DispInfoListeCompt(TLwDispInfoNotify& dispInfo)
{
    const int 	    BufLen = 255;
    static char     buffer[BufLen];
    TListWindItem&  dispInfoItem = *(TListWindItem*)&dispInfo.item;
    int 		    index;
    int			    montant;
    string		    sCodeLexique;
    string		    sBuffer;

    index = dispInfoItem.GetIndex();

    string sLang = "";    if ((pContexte) && (pContexte->getUtilisateur()))
        sLang = pContexte->getUtilisateur()->donneLang();

    // Affiche les informations en fonction de la colonne

    switch (dispInfoItem.GetSubItem())
    {
   	    case 1: 	// examen
      	    // si le code examen existe, on r�cup�re son libell�
      	    if (strcmp(((*pComptArray)[index])->pDonnees->examen, ""))
            {
         	    sprintf(buffer, "%s%s", ((*pComptArray)[index])->pDonnees->examen,
                                    ((*pComptArray)[index])->pDonnees->synonyme);
         	    sCodeLexique = string(buffer);
         	    pContexte->getDico()->donneLibelle(sLang, &sCodeLexique, &sBuffer);
         	    strcpy(buffer, sBuffer.c_str());
         	    if (strlen(buffer))
         		    buffer[0] = pseumaj(buffer[0]);
            }
            else
                strcpy(buffer, "");

            dispInfoItem.SetText(buffer);
            break;

   	    case 2: // somme due

            if (!bEuro)
         	    sprintf(buffer, "%s", ((*pComptArray)[index])->pDonnees->duFranc);
            else
         	    sprintf(buffer, "%s", ((*pComptArray)[index])->pDonnees->duEuro);

            montant = atoi(buffer);

            sprintf(buffer, "%d,%02d", montant/100, montant%100);
            dispInfoItem.SetText(buffer);
            break;

        case 3: // somme payee

            if (!bEuro)
         	    sprintf(buffer, "%s", ((*pComptArray)[index])->pDonnees->payeFranc);
            else
         	    sprintf(buffer, "%s", ((*pComptArray)[index])->pDonnees->payeEuro);

            montant = atoi(buffer);

            sprintf(buffer, "%d,%02d", montant/100, montant%100);
            dispInfoItem.SetText(buffer);
            break;

    } // fin du switch
}

voidNSListComptDialog::EvSize(uint sizeType, ClassLib::TSize& size){	TDialog::EvSize(sizeType, size) ;}
voidNSListComptDialog::AfficheTotaux()
{
	char montantDu[10] ;
  char montantPaye[10] ;

	totalDu = 0 ;
  totalPaye = 0 ;

	for (int i = 0; i < nbCompt; i++)
  {
   	if (!bEuro)
    {
    	totalDu		+= atoi(((*pComptArray)[i])->pDonnees->duFranc) ;
      totalPaye	+= atoi(((*pComptArray)[i])->pDonnees->payeFranc) ;
    }
    else
    {
    	totalDu		+= atoi(((*pComptArray)[i])->pDonnees->duEuro) ;
      totalPaye	+= atoi(((*pComptArray)[i])->pDonnees->payeEuro) ;
    }
  }

	sprintf(montantDu, "%5d,%02d", totalDu/100, totalDu%100) ;
  sprintf(montantPaye, "%5d,%02d", totalPaye/100, totalPaye%100) ;

	pTotalDu->SetText(montantDu) ;
	pTotalPaye->SetText(montantPaye) ;
}

voidNSListComptDialog::SwitchLocEuro()
{
	if (bEuro)
		bEuro = false ;
	else
		bEuro = true ;

	AfficheListeCompt() ;
	AfficheTotaux() ;
}

void
NSListComptDialog::CmModifCompt()
{
    CreerFicheComptDialog* 	pComptDlg;
	int 					index = pListeCompt->IndexItemSelect();

   	if (index == -1)
   	{
   		erreur("Vous devez s�lectionner une fiche compt.", standardError, 0) ;
      	return;
   	}

   	sNumCompt = string(((*pComptArray)[index])->pDonnees->numcompt);

   	NSCompt* pCompt = new NSCompt(pContexte);

   	pCompt->lastError = pCompt->open();
   	if (pCompt->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � l'ouverture de la base Compt.", standardError, 0) ;
      	delete pCompt;
      	return;
   	}

   	pCompt->lastError = pCompt->chercheClef(&sNumCompt,
												"",
												0,
												keySEARCHEQ,
                                                dbiWRITELOCK);

   	if (pCompt->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � la recherche d'une fiche compt.", standardError, pCompt->lastError) ;
      	pCompt->close();
      	delete pCompt;
      	return;
   	}

   	pCompt->lastError = pCompt->getRecord();
   	if (pCompt->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � lecture du fichier Compt.db", standardError, pCompt->lastError);
      	pCompt->close();
      	delete pCompt;
      	return;
   	}

   	pComptDlg = new CreerFicheComptDialog(this, pContexte, pPatient, false);

	*(pComptDlg->pData) = *(pCompt->pDonnees);

   	if ((pComptDlg->Execute()) == IDCANCEL)
   	{
    	pCompt->close();
      	delete pCompt;
   		delete pComptDlg;
   		return;
   	}

   	*(pCompt->pDonnees) = *(pComptDlg->pData);

   	pCompt->lastError = pCompt->modifyRecord(TRUE);
   	if (pCompt->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � la modification de la fiche compt.", standardError, pCompt->lastError) ;
      	pCompt->close();
      	delete pCompt;
      	delete pComptDlg;
      	return;
   	}

   	// on remet � jour l'array
   	*(((*pComptArray)[index])->pDonnees) = *(pCompt->pDonnees);

   	pCompt->lastError = pCompt->close();
   	if (pCompt->lastError != DBIERR_NONE)
   		erreur("Erreur � la fermeture de la base Compt.db.", standardError, pCompt->lastError) ;

    pComptDlg->EnregDonneesCompt(sNumCompt);

   	delete pCompt;
   	delete pComptDlg;

   	AfficheListeCompt();
   	AfficheTotaux();
}

void
NSListComptDialog::CmDeleteCompt()
{
    CreerFicheComptDialog* 	pComptDlg;
	int 					indexDel = pListeCompt->IndexItemSelect();
    NSComptIter             i;
    int                     j;

   	sNumCompt = string(((*pComptArray)[indexDel])->pDonnees->numcompt);

    // on commence par enlever la fiche compt du tableau
    for (i = pComptArray->begin(), j = 0; i != pComptArray->end(); i++, j++)
    {
        if (j == indexDel)
        {
            delete *i;
            pComptArray->erase(i);
            nbCompt -= 1;
            break;
        }
    }

    // on enleve maintenant la fiche compt de la base
   	NSCompt* pCompt = new NSCompt(pContexte);

   	pCompt->lastError = pCompt->open();
   	if (pCompt->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � l'ouverture de la base Compt.", standardError, 0) ;
      	delete pCompt;
      	return;
   	}

   	pCompt->lastError = pCompt->chercheClef(&sNumCompt,
												"",
												0,
												keySEARCHEQ,
                                                dbiWRITELOCK);

   	if (pCompt->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � la recherche de la fiche compt.", standardError, pCompt->lastError) ;
      	pCompt->close();
      	delete pCompt;
      	return;
   	}

   	pComptDlg = new CreerFicheComptDialog(this, pContexte, pPatient, false);

    // Note : on enregistre les donn�es en laissant tous les tableaux vides
    // puisqu'on ne passe pas par SetupWindow -> suppression des donn�es li�es
    // � la fiche compt
    pComptDlg->EnregDonneesCompt(sNumCompt);

   	pCompt->lastError = pCompt->deleteRecord();
   	if (pCompt->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � la destruction de la fiche compt.", standardError, pCompt->lastError) ;
      	pCompt->close();
      	delete pCompt;
      	delete pComptDlg;
      	return;
   	}

   	pCompt->lastError = pCompt->close();
   	if (pCompt->lastError != DBIERR_NONE)
   		erreur("Erreur � la fermeture de la base Compt.db.", standardError, pCompt->lastError) ;

   	delete pCompt;
   	delete pComptDlg;

    // On remet � jour la liste et les totaux
   	AfficheListeCompt();
   	AfficheTotaux();
}

voidNSListComptDialog::CmOk()
{
	NSUtilDialog::CmOk();
}

voidNSListComptDialog::CmCancel()
{
	NSUtilDialog::CmCancel();
}

// fin de nsfseuti.cpp///////////////////////////////////////////////////////

