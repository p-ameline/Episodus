//---------------------------------------------------------------------------//    NSPERSON.CPP
//    KRZISCH PH.   janvier 92
//  Impl�mentation de objets NAUTILUS
//---------------------------------------------------------------------------
#include <utility.h>
#include <mem.h>
#include <string.h>
#include <cstring.h>

//using namespace std;

#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "nscompta\nsFSE16.h"

//***************************************************************************
// Impl�mentation des m�thodes NSFse1610
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSFse1610Data::NSFse1610Data()
{

	//
	// Met les champs de donn�es � z�ro
	//
	metAZero();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFse1610Data::NSFse1610Data(NSFse1610Data& rv)
{
	strcpy(numcompt, 		rv.numcompt);
	strcpy(numprest,  		rv.numprest);
	strcpy(date, 	 		rv.date);
	strcpy(lieu,   			rv.lieu);
	strcpy(code,  			rv.code);
	strcpy(complmnt, 		rv.complmnt);
   	strcpy(montant_f,   	rv.montant_f);
   	strcpy(montant_e,   	rv.montant_e);
   	strcpy(qualif,   		rv.qualif);
   	strcpy(coeff,   		rv.coeff);
    strcpy(divis,			rv.divis);
   	strcpy(quantite,   		rv.quantite);
   	strcpy(denombr,   		rv.denombr);
   	strcpy(prix_unit_f,  	rv.prix_unit_f);
   	strcpy(prix_unit_e,  	rv.prix_unit_e);
   	strcpy(base_rmb,   		rv.base_rmb);
   	strcpy(taux,   			rv.taux);
   	strcpy(rmb_amo,   		rv.rmb_amo);
   	strcpy(rmb_amc,   		rv.rmb_amc);
   	strcpy(rmo,   			rv.rmo);
   	strcpy(code_exo,   		rv.code_exo);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSFse1610Data::~NSFse1610Data()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSFse1610Data&
NSFse1610Data::operator=(NSFse1610Data src)
{
	strcpy(numcompt, 		src.numcompt);
	strcpy(numprest,  		src.numprest);
	strcpy(date, 	 		src.date);
	strcpy(lieu,   			src.lieu);
	strcpy(code,  			src.code);
	strcpy(complmnt, 		src.complmnt);
   	strcpy(montant_f,   	src.montant_f);
   	strcpy(montant_e,   	src.montant_e);
   	strcpy(qualif,   		src.qualif);
   	strcpy(coeff,   		src.coeff);
    strcpy(divis,			src.divis);
   	strcpy(quantite,   		src.quantite);
   	strcpy(denombr,   		src.denombr);
   	strcpy(prix_unit_f,  	src.prix_unit_f);
   	strcpy(prix_unit_e,  	src.prix_unit_e);
   	strcpy(base_rmb,   		src.base_rmb);
   	strcpy(taux,   			src.taux);
   	strcpy(rmb_amo,   		src.rmb_amo);
   	strcpy(rmb_amc,   		src.rmb_amc);
   	strcpy(rmo,   			src.rmo);
   	strcpy(code_exo,   		src.code_exo);

	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFse1610Data::operator == ( const NSFse1610Data& o )
{
	if ((strcmp(numcompt, o.numcompt) == 0))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Met � blanc les variables de la fiche
//---------------------------------------------------------------------------
void
NSFse1610Data::metABlanc()
{
	//
	// Met les champs de donn�es � blanc
	//
	memset(numcompt, 	  	' ', FSE1610_NUMCOMPT_LEN);
	memset(numprest,   		' ', FSE1610_NUMPREST_LEN);
	memset(date, 	 	  	' ', FSE1610_DATE_LEN);
	memset(lieu,   			' ', FSE1610_LIEU_LEN);
	memset(code,  			' ', FSE1610_CODE_LEN);
	memset(complmnt, 		' ', FSE1610_COMPLMNT_LEN);
   	memset(montant_f, 		' ', FSE1610_MONTANT_F_LEN);
   	memset(montant_e, 		' ', FSE1610_MONTANT_E_LEN);
   	memset(qualif, 	  		' ', FSE1610_QUALIF_LEN);
   	memset(coeff, 	  		' ', FSE1610_COEFF_LEN);
    memset(divis,			' ', FSE1610_DIVIS_LEN);
   	memset(quantite, 	  	' ', FSE1610_QUANTITE_LEN);
   	memset(denombr, 	  	' ', FSE1610_DENOMBR_LEN);
   	memset(prix_unit_f,		' ', FSE1610_PRIX_UNIT_F_LEN);
   	memset(prix_unit_e, 	' ', FSE1610_PRIX_UNIT_E_LEN);
   	memset(base_rmb, 	  	' ', FSE1610_BASE_RMB_LEN);
   	memset(taux, 	  		' ', FSE1610_TAUX_LEN);
   	memset(rmb_amo, 	  	' ', FSE1610_RMB_AMO_LEN);
   	memset(rmb_amc, 	  	' ', FSE1610_RMB_AMC_LEN);
   	memset(rmo, 	  		' ', FSE1610_RMO_LEN);
   	memset(code_exo, 	  	' ', FSE1610_CODE_EXO_LEN);
}

//---------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSFse1610Data::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(numcompt, 	  	0, FSE1610_NUMCOMPT_LEN + 1);
	memset(numprest,   		0, FSE1610_NUMPREST_LEN + 1);
	memset(date, 	 	  	0, FSE1610_DATE_LEN + 1);
	memset(lieu,   			0, FSE1610_LIEU_LEN + 1);
	memset(code,  			0, FSE1610_CODE_LEN + 1);
	memset(complmnt, 		0, FSE1610_COMPLMNT_LEN + 1);
   	memset(montant_f, 		0, FSE1610_MONTANT_F_LEN + 1);
   	memset(montant_e, 		0, FSE1610_MONTANT_E_LEN + 1);
   	memset(qualif, 	  		0, FSE1610_QUALIF_LEN + 1);
   	memset(coeff, 	  		0, FSE1610_COEFF_LEN + 1);
    memset(divis,			0, FSE1610_DIVIS_LEN + 1);
   	memset(quantite, 	  	0, FSE1610_QUANTITE_LEN + 1);
   	memset(denombr, 	  	0, FSE1610_DENOMBR_LEN + 1);
   	memset(prix_unit_f,		0, FSE1610_PRIX_UNIT_F_LEN + 1);
   	memset(prix_unit_e, 	0, FSE1610_PRIX_UNIT_E_LEN + 1);
   	memset(base_rmb, 	  	0, FSE1610_BASE_RMB_LEN + 1);
   	memset(taux, 	  		0, FSE1610_TAUX_LEN + 1);
   	memset(rmb_amo, 	  	0, FSE1610_RMB_AMO_LEN + 1);
   	memset(rmb_amc, 	  	0, FSE1610_RMB_AMC_LEN + 1);
   	memset(rmo, 	  		0, FSE1610_RMO_LEN + 1);
   	memset(code_exo, 	  	0, FSE1610_CODE_EXO_LEN + 1);
}

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSFse1610::NSFse1610(NSContexte* pCtx) : NSFiche(pCtx)
{
	//
	// Cr�e un objet de donn�es
	//
	pDonnees = new NSFse1610Data();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFse1610::NSFse1610(NSFse1610& rv) : NSFiche(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFse1610Data();
	//
	// Copie les valeurs du NSTransaction d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSFse1610::~NSFse1610()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Fonction :  	NSFse1610::alimenteFiche()
//
//  Description : Transf�re le contenu de pRecBuff dans les variables de
//             	la fiche
//---------------------------------------------------------------------------
void
NSFse1610::alimenteFiche()
{
   alimenteChamp(pDonnees->numcompt, 	  	FSE1610_NUMCOMPT_FIELD,  	FSE1610_NUMCOMPT_LEN);
   alimenteChamp(pDonnees->numprest, 		FSE1610_NUMPREST_FIELD, 	FSE1610_NUMPREST_LEN);
   alimenteChamp(pDonnees->date, 	 		FSE1610_DATE_FIELD, 	  	FSE1610_DATE_LEN);
   alimenteChamp(pDonnees->lieu, 	 		FSE1610_LIEU_FIELD,			FSE1610_LIEU_LEN);
   alimenteChamp(pDonnees->code,  			FSE1610_CODE_FIELD, 		FSE1610_CODE_LEN);
   alimenteChamp(pDonnees->complmnt, 		FSE1610_COMPLMNT_FIELD, 	FSE1610_COMPLMNT_LEN);
   alimenteChamp(pDonnees->montant_f, 		FSE1610_MONTANT_F_FIELD,  	FSE1610_MONTANT_F_LEN);
   alimenteChamp(pDonnees->montant_e, 		FSE1610_MONTANT_E_FIELD,  	FSE1610_MONTANT_E_LEN);
   alimenteChamp(pDonnees->qualif, 	  		FSE1610_QUALIF_FIELD,  		FSE1610_QUALIF_LEN);
   alimenteChamp(pDonnees->coeff, 	  		FSE1610_COEFF_FIELD,  		FSE1610_COEFF_LEN);
   alimenteChamp(pDonnees->divis,			FSE1610_DIVIS_FIELD,		FSE1610_DIVIS_LEN);
   alimenteChamp(pDonnees->quantite, 		FSE1610_QUANTITE_FIELD,  	FSE1610_QUANTITE_LEN);
   alimenteChamp(pDonnees->denombr, 		FSE1610_DENOMBR_FIELD,  	FSE1610_DENOMBR_LEN);
   alimenteChamp(pDonnees->prix_unit_f,		FSE1610_PRIX_UNIT_F_FIELD, 	FSE1610_PRIX_UNIT_F_LEN);
   alimenteChamp(pDonnees->prix_unit_e, 	FSE1610_PRIX_UNIT_E_FIELD, 	FSE1610_PRIX_UNIT_E_LEN);
   alimenteChamp(pDonnees->base_rmb, 	  	FSE1610_BASE_RMB_FIELD,  	FSE1610_BASE_RMB_LEN);
   alimenteChamp(pDonnees->taux, 	  	 	FSE1610_TAUX_FIELD,  		FSE1610_TAUX_LEN);
   alimenteChamp(pDonnees->rmb_amo, 	  	FSE1610_RMB_AMO_FIELD,  	FSE1610_RMB_AMO_LEN);
   alimenteChamp(pDonnees->rmb_amc, 	  	FSE1610_RMB_AMC_FIELD,  	FSE1610_RMB_AMC_LEN);
   alimenteChamp(pDonnees->rmo, 	  	 	FSE1610_RMO_FIELD,  		FSE1610_RMO_LEN);
   alimenteChamp(pDonnees->code_exo, 	  	FSE1610_CODE_EXO_FIELD,  	FSE1610_CODE_EXO_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :   	NSFse1610::videFiche()
//
//  Description : Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSFse1610::videFiche()
{
	videChamp(pDonnees->numcompt, 	  	FSE1610_NUMCOMPT_FIELD,  	FSE1610_NUMCOMPT_LEN);
   	videChamp(pDonnees->numprest, 		FSE1610_NUMPREST_FIELD, 	FSE1610_NUMPREST_LEN);
   	videChamp(pDonnees->date, 	 		FSE1610_DATE_FIELD, 	  	FSE1610_DATE_LEN);
   	videChamp(pDonnees->lieu, 	 		FSE1610_LIEU_FIELD,			FSE1610_LIEU_LEN);
   	videChamp(pDonnees->code,  			FSE1610_CODE_FIELD, 		FSE1610_CODE_LEN);
   	videChamp(pDonnees->complmnt, 		FSE1610_COMPLMNT_FIELD, 	FSE1610_COMPLMNT_LEN);
   	videChamp(pDonnees->montant_f, 		FSE1610_MONTANT_F_FIELD,  	FSE1610_MONTANT_F_LEN);
   	videChamp(pDonnees->montant_e, 		FSE1610_MONTANT_E_FIELD,  	FSE1610_MONTANT_E_LEN);
   	videChamp(pDonnees->qualif, 	  	FSE1610_QUALIF_FIELD,  		FSE1610_QUALIF_LEN);
   	videChamp(pDonnees->coeff, 	  		FSE1610_COEFF_FIELD,  		FSE1610_COEFF_LEN);
    videChamp(pDonnees->divis,			FSE1610_DIVIS_FIELD,		FSE1610_DIVIS_LEN);
   	videChamp(pDonnees->quantite, 		FSE1610_QUANTITE_FIELD,  	FSE1610_QUANTITE_LEN);
   	videChamp(pDonnees->denombr, 		FSE1610_DENOMBR_FIELD,  	FSE1610_DENOMBR_LEN);
   	videChamp(pDonnees->prix_unit_f,	FSE1610_PRIX_UNIT_F_FIELD, 	FSE1610_PRIX_UNIT_F_LEN);
   	videChamp(pDonnees->prix_unit_e, 	FSE1610_PRIX_UNIT_E_FIELD, 	FSE1610_PRIX_UNIT_E_LEN);
   	videChamp(pDonnees->base_rmb, 	  	FSE1610_BASE_RMB_FIELD,  	FSE1610_BASE_RMB_LEN);
   	videChamp(pDonnees->taux, 	  	 	FSE1610_TAUX_FIELD,  		FSE1610_TAUX_LEN);
   	videChamp(pDonnees->rmb_amo, 	  	FSE1610_RMB_AMO_FIELD,  	FSE1610_RMB_AMO_LEN);
   	videChamp(pDonnees->rmb_amc, 	  	FSE1610_RMB_AMC_FIELD,  	FSE1610_RMB_AMC_LEN);
   	videChamp(pDonnees->rmo, 	  	 	FSE1610_RMO_FIELD,  		FSE1610_RMO_LEN);
   	videChamp(pDonnees->code_exo, 	  	FSE1610_CODE_EXO_FIELD,  	FSE1610_CODE_EXO_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :  	NSFse1610::open()
//
//  Description :	Ouvre la table primaire et les index secondaires
//
//  Returns :		PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSFse1610::open()
{
	char tableName[] = "FSE1610.DB";
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_COMPTA);
	return(lastError);
}

//---------------------------------------------------------------------------
//  Function:  NSFse1610::Create()
//---------------------------------------------------------------------------
bool
NSFse1610::Create()
{
	return true;
}

//---------------------------------------------------------------------------
//  Function:  NSFse1610::Modify()
//---------------------------------------------------------------------------
bool
NSFse1610::Modify()
{
	return true;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSFse1610&
NSFse1610::operator=(NSFse1610 src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFse1610::operator == (const NSFse1610& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//---------------------------------------------------------------------------
//  Fonction:		NSFse1610Info::NSFse1610Info()
//
//  Description:	Constructeur par d�faut
//---------------------------------------------------------------------------
NSFse1610Info::NSFse1610Info()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSFse1610Data();
}

//---------------------------------------------------------------------------
//  Fonction:		NSFse1610Info::NSFse1610Info(NSFse1610*)
//
//  Description:	Constructeur � partir d'un NSFse1610
//---------------------------------------------------------------------------
NSFse1610Info::NSFse1610Info(NSFse1610* pFse1610)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFse1610Data();
	//
	// Copie les valeurs du NSFse1610
	//
	*pDonnees = *(pFse1610->pDonnees);
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFse1610Info::NSFse1610Info(NSFse1610Info& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFse1610Data();
	//
	// Copie les valeurs du NSFse1610Info d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSFse1610Info::~NSFse1610Info()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSFse1610Info&
NSFse1610Info::operator=(NSFse1610Info src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFse1610Info::operator == (const NSFse1610Info& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//***************************************************************************
// Impl�mentation des m�thodes NSFse1620
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSFse1620Data::NSFse1620Data()
{
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFse1620Data::NSFse1620Data(NSFse1620Data& rv)
{
	strcpy(numcompt,			rv.numcompt);
	strcpy(numprest,			rv.numprest);
	strcpy(date_depl, 		rv.date_depl);
	strcpy(code_ifd,   		rv.code_ifd);
   strcpy(montant_ifd_f,	rv.montant_ifd_f);
	strcpy(montant_ifd_e,  	rv.montant_ifd_e);
	strcpy(quantite, 			rv.quantite);
   strcpy(prix_unit_f,		rv.prix_unit_f);
   strcpy(prix_unit_e,		rv.prix_unit_e);
   strcpy(base_rmb, 			rv.base_rmb);
   strcpy(taux, 				rv.taux);
   strcpy(rmb_amo, 			rv.rmb_amo);
   strcpy(rmb_amc, 			rv.rmb_amc);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSFse1620Data::~NSFse1620Data()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSFse1620Data&
NSFse1620Data::operator=(NSFse1620Data src)
{
	strcpy(numcompt,			src.numcompt);
	strcpy(numprest,			src.numprest);
	strcpy(date_depl, 		src.date_depl);
	strcpy(code_ifd,   		src.code_ifd);
   strcpy(montant_ifd_f,	src.montant_ifd_f);
	strcpy(montant_ifd_e,  	src.montant_ifd_e);
	strcpy(quantite, 			src.quantite);
   strcpy(prix_unit_f,		src.prix_unit_f);
   strcpy(prix_unit_e,		src.prix_unit_e);
   strcpy(base_rmb, 			src.base_rmb);
   strcpy(taux, 				src.taux);
   strcpy(rmb_amo, 			src.rmb_amo);
   strcpy(rmb_amc, 			src.rmb_amc);

	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFse1620Data::operator == ( const NSFse1620Data& o )
{
	if ((strcmp(numcompt, o.numcompt) == 0))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Met � blanc les variables de la fiche
//---------------------------------------------------------------------------
void
NSFse1620Data::metABlanc()
{
	//
	// Met les champs de donn�es � blanc
	//
	memset(numcompt, 	  		' ', FSE1620_NUMCOMPT_LEN);
	memset(numprest,   		' ', FSE1620_NUMPREST_LEN);
	memset(date_depl, 		' ', FSE1620_DATE_DEPL_LEN);
	memset(code_ifd,   		' ', FSE1620_CODE_IFD_LEN);
	memset(montant_ifd_f,  	' ', FSE1620_MONTANT_IFD_F_LEN);
	memset(montant_ifd_e, 	' ', FSE1620_MONTANT_IFD_E_LEN);
   memset(quantite,			' ', FSE1620_QUANTITE_LEN);
   memset(prix_unit_f,		' ', FSE1620_PRIX_UNIT_F_LEN);
   memset(prix_unit_e,		' ', FSE1620_PRIX_UNIT_E_LEN);
   memset(base_rmb,			' ', FSE1620_BASE_RMB_LEN);
   memset(taux,				' ', FSE1620_TAUX_LEN);
   memset(rmb_amo,			' ', FSE1620_RMB_AMO_LEN);
   memset(rmb_amc,			' ', FSE1620_RMB_AMC_LEN);
}

//---------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSFse1620Data::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(numcompt, 	  		0, FSE1620_NUMCOMPT_LEN + 1);
	memset(numprest,   		0, FSE1620_NUMPREST_LEN + 1);
	memset(date_depl, 		0, FSE1620_DATE_DEPL_LEN + 1);
	memset(code_ifd,   		0, FSE1620_CODE_IFD_LEN + 1);
	memset(montant_ifd_f,  	0, FSE1620_MONTANT_IFD_F_LEN + 1);
	memset(montant_ifd_e, 	0, FSE1620_MONTANT_IFD_E_LEN + 1);
   memset(quantite,			0, FSE1620_QUANTITE_LEN + 1);
   memset(prix_unit_f,		0, FSE1620_PRIX_UNIT_F_LEN + 1);
   memset(prix_unit_e,		0, FSE1620_PRIX_UNIT_E_LEN + 1);
   memset(base_rmb,			0, FSE1620_BASE_RMB_LEN + 1);
   memset(taux,				0, FSE1620_TAUX_LEN + 1);
   memset(rmb_amo,			0, FSE1620_RMB_AMO_LEN + 1);
   memset(rmb_amc,			0, FSE1620_RMB_AMC_LEN + 1);
}

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSFse1620::NSFse1620(NSContexte* pCtx) : NSFiche(pCtx)
{
	//
	// Cr�e un objet de donn�es
	//
	pDonnees = new NSFse1620Data();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFse1620::NSFse1620(NSFse1620& rv) : NSFiche(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFse1620Data();
	//
	// Copie les valeurs du NSTransaction d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSFse1620::~NSFse1620()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Fonction :  	NSFse1620::alimenteFiche()
//
//  Description : Transf�re le contenu de pRecBuff dans les variables de
//             	la fiche
//---------------------------------------------------------------------------
void
NSFse1620::alimenteFiche()
{
   alimenteChamp(pDonnees->numcompt, 	  	FSE1620_NUMCOMPT_FIELD,			FSE1620_NUMCOMPT_LEN);
   alimenteChamp(pDonnees->numprest,		FSE1620_NUMPREST_FIELD, 		FSE1620_NUMPREST_LEN);
   alimenteChamp(pDonnees->date_depl, 		FSE1620_DATE_DEPL_FIELD, 		FSE1620_DATE_DEPL_LEN);
   alimenteChamp(pDonnees->code_ifd, 	 	FSE1620_CODE_IFD_FIELD,			FSE1620_CODE_IFD_LEN);
   alimenteChamp(pDonnees->montant_ifd_f, FSE1620_MONTANT_IFD_F_FIELD, 	FSE1620_MONTANT_IFD_F_LEN);
   alimenteChamp(pDonnees->montant_ifd_e, FSE1620_MONTANT_IFD_E_FIELD, 	FSE1620_MONTANT_IFD_E_LEN);
   alimenteChamp(pDonnees->quantite,		FSE1620_QUANTITE_FIELD,			FSE1620_QUANTITE_LEN);
   alimenteChamp(pDonnees->prix_unit_f,	FSE1620_PRIX_UNIT_F_FIELD,		FSE1620_PRIX_UNIT_F_LEN);
   alimenteChamp(pDonnees->prix_unit_e,	FSE1620_PRIX_UNIT_E_FIELD,		FSE1620_PRIX_UNIT_E_LEN);
   alimenteChamp(pDonnees->base_rmb,		FSE1620_BASE_RMB_FIELD,			FSE1620_BASE_RMB_LEN);
   alimenteChamp(pDonnees->taux,				FSE1620_TAUX_FIELD,				FSE1620_TAUX_LEN);
   alimenteChamp(pDonnees->rmb_amo,			FSE1620_RMB_AMO_FIELD,			FSE1620_RMB_AMO_LEN);
   alimenteChamp(pDonnees->rmb_amc,			FSE1620_RMB_AMC_FIELD,			FSE1620_RMB_AMC_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :   	NSFse1620::videFiche()
//
//  Description : Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSFse1620::videFiche()
{
	videChamp(pDonnees->numcompt, 	  	FSE1620_NUMCOMPT_FIELD,			FSE1620_NUMCOMPT_LEN);
   videChamp(pDonnees->numprest,			FSE1620_NUMPREST_FIELD, 		FSE1620_NUMPREST_LEN);
   videChamp(pDonnees->date_depl, 		FSE1620_DATE_DEPL_FIELD, 		FSE1620_DATE_DEPL_LEN);
   videChamp(pDonnees->code_ifd, 	 	FSE1620_CODE_IFD_FIELD,			FSE1620_CODE_IFD_LEN);
   videChamp(pDonnees->montant_ifd_f, 	FSE1620_MONTANT_IFD_F_FIELD, 	FSE1620_MONTANT_IFD_F_LEN);
   videChamp(pDonnees->montant_ifd_e, 	FSE1620_MONTANT_IFD_E_FIELD, 	FSE1620_MONTANT_IFD_E_LEN);
   videChamp(pDonnees->quantite,			FSE1620_QUANTITE_FIELD,			FSE1620_QUANTITE_LEN);
   videChamp(pDonnees->prix_unit_f,		FSE1620_PRIX_UNIT_F_FIELD,		FSE1620_PRIX_UNIT_F_LEN);
   videChamp(pDonnees->prix_unit_e,		FSE1620_PRIX_UNIT_E_FIELD,		FSE1620_PRIX_UNIT_E_LEN);
   videChamp(pDonnees->base_rmb,			FSE1620_BASE_RMB_FIELD,			FSE1620_BASE_RMB_LEN);
   videChamp(pDonnees->taux,				FSE1620_TAUX_FIELD,				FSE1620_TAUX_LEN);
   videChamp(pDonnees->rmb_amo,			FSE1620_RMB_AMO_FIELD,			FSE1620_RMB_AMO_LEN);
   videChamp(pDonnees->rmb_amc,			FSE1620_RMB_AMC_FIELD,			FSE1620_RMB_AMC_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :  	NSFse1620::open()
//
//  Description :	Ouvre la table primaire et les index secondaires
//
//  Returns :		PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSFse1620::open()
{
	char tableName[] = "FSE1620.DB";
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_COMPTA);
	return(lastError);
}

//---------------------------------------------------------------------------
//  Function:  NSFse1620::Create()
//---------------------------------------------------------------------------
bool
NSFse1620::Create()
{
	return true;
}

//---------------------------------------------------------------------------
//  Function:  NSFse1620::Modify()
//---------------------------------------------------------------------------
bool
NSFse1620::Modify()
{
	return true;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSFse1620&
NSFse1620::operator=(NSFse1620 src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFse1620::operator == (const NSFse1620& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//---------------------------------------------------------------------------
//  Fonction:		NSFse1620Info::NSFse1620Info()
//
//  Description:	Constructeur par d�faut
//---------------------------------------------------------------------------
NSFse1620Info::NSFse1620Info()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSFse1620Data();
}

//---------------------------------------------------------------------------
//  Fonction:		NSFse1620Info::NSFse1620Info(NSFse1620*)
//
//  Description:	Constructeur � partir d'un NSFse1620
//---------------------------------------------------------------------------
NSFse1620Info::NSFse1620Info(NSFse1620* pFse1620)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFse1620Data();
	//
	// Copie les valeurs du NSFse1620
	//
	*pDonnees = *(pFse1620->pDonnees);
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFse1620Info::NSFse1620Info(NSFse1620Info& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFse1620Data();
	//
	// Copie les valeurs du NSFse1620Info d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSFse1620Info::~NSFse1620Info()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSFse1620Info&
NSFse1620Info::operator=(NSFse1620Info src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFse1620Info::operator == (const NSFse1620Info& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//***************************************************************************
// Impl�mentation des m�thodes NSFse1630
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSFse1630Data::NSFse1630Data()
{
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFse1630Data::NSFse1630Data(NSFse1630Data& rv)
{
	strcpy(numcompt,			rv.numcompt);
	strcpy(numprest,			rv.numprest);
	strcpy(date_depl, 		rv.date_depl);
	strcpy(code_ik,   		rv.code_ik);
   strcpy(nbre_km,			rv.nbre_km);
   strcpy(montant_ik_f,		rv.montant_ik_f);
	strcpy(montant_ik_e,  	rv.montant_ik_e);
   strcpy(prix_unit_f,		rv.prix_unit_f);
   strcpy(prix_unit_e,		rv.prix_unit_e);
   strcpy(base_rmb, 			rv.base_rmb);
   strcpy(taux, 				rv.taux);
   strcpy(rmb_amo, 			rv.rmb_amo);
   strcpy(rmb_amc, 			rv.rmb_amc);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSFse1630Data::~NSFse1630Data()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSFse1630Data&
NSFse1630Data::operator=(NSFse1630Data src)
{
	strcpy(numcompt,			src.numcompt);
	strcpy(numprest,			src.numprest);
	strcpy(date_depl, 		src.date_depl);
	strcpy(code_ik,   		src.code_ik);
   strcpy(nbre_km,			src.nbre_km);
   strcpy(montant_ik_f,		src.montant_ik_f);
	strcpy(montant_ik_e,  	src.montant_ik_e);
   strcpy(prix_unit_f,		src.prix_unit_f);
   strcpy(prix_unit_e,		src.prix_unit_e);
   strcpy(base_rmb, 			src.base_rmb);
   strcpy(taux, 				src.taux);
   strcpy(rmb_amo, 			src.rmb_amo);
   strcpy(rmb_amc, 			src.rmb_amc);

	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFse1630Data::operator == ( const NSFse1630Data& o )
{
	if ((strcmp(numcompt, o.numcompt) == 0))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Met � blanc les variables de la fiche
//---------------------------------------------------------------------------
void
NSFse1630Data::metABlanc()
{
	//
	// Met les champs de donn�es � blanc
	//
	memset(numcompt, 	  		' ', FSE1630_NUMCOMPT_LEN);
	memset(numprest,   		' ', FSE1630_NUMPREST_LEN);
	memset(date_depl, 		' ', FSE1630_DATE_DEPL_LEN);
	memset(code_ik,   		' ', FSE1630_CODE_IK_LEN);
   memset(nbre_km,			' ', FSE1630_NBRE_KM_LEN);
	memset(montant_ik_f,  	' ', FSE1630_MONTANT_IK_F_LEN);
	memset(montant_ik_e, 	' ', FSE1630_MONTANT_IK_E_LEN);
   memset(prix_unit_f,		' ', FSE1630_PRIX_UNIT_F_LEN);
   memset(prix_unit_e,		' ', FSE1630_PRIX_UNIT_E_LEN);
   memset(base_rmb,			' ', FSE1630_BASE_RMB_LEN);
   memset(taux,				' ', FSE1630_TAUX_LEN);
   memset(rmb_amo,			' ', FSE1630_RMB_AMO_LEN);
   memset(rmb_amc,			' ', FSE1630_RMB_AMC_LEN);
}

//---------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSFse1630Data::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(numcompt, 	  		0, FSE1630_NUMCOMPT_LEN + 1);
	memset(numprest,   		0, FSE1630_NUMPREST_LEN + 1);
	memset(date_depl, 		0, FSE1630_DATE_DEPL_LEN + 1);
	memset(code_ik,   		0, FSE1630_CODE_IK_LEN + 1);
   memset(nbre_km,			0, FSE1630_NBRE_KM_LEN + 1);
	memset(montant_ik_f,  	0, FSE1630_MONTANT_IK_F_LEN + 1);
	memset(montant_ik_e, 	0, FSE1630_MONTANT_IK_E_LEN + 1);
   memset(prix_unit_f,		0, FSE1630_PRIX_UNIT_F_LEN + 1);
   memset(prix_unit_e,		0, FSE1630_PRIX_UNIT_E_LEN + 1);
   memset(base_rmb,			0, FSE1630_BASE_RMB_LEN + 1);
   memset(taux,				0, FSE1630_TAUX_LEN + 1);
   memset(rmb_amo,			0, FSE1630_RMB_AMO_LEN + 1);
   memset(rmb_amc,			0, FSE1630_RMB_AMC_LEN + 1);
}

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSFse1630::NSFse1630(NSContexte* pCtx) : NSFiche(pCtx)
{
	//
	// Cr�e un objet de donn�es
	//
	pDonnees = new NSFse1630Data();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFse1630::NSFse1630(NSFse1630& rv) : NSFiche(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFse1630Data();
	//
	// Copie les valeurs du NSTransaction d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSFse1630::~NSFse1630()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Fonction :  	NSFse1630::alimenteFiche()
//
//  Description : Transf�re le contenu de pRecBuff dans les variables de
//             	la fiche
//---------------------------------------------------------------------------
void
NSFse1630::alimenteFiche()
{
   alimenteChamp(pDonnees->numcompt, 	  	FSE1630_NUMCOMPT_FIELD,			FSE1630_NUMCOMPT_LEN);
   alimenteChamp(pDonnees->numprest,		FSE1630_NUMPREST_FIELD, 		FSE1630_NUMPREST_LEN);
   alimenteChamp(pDonnees->date_depl, 		FSE1630_DATE_DEPL_FIELD, 		FSE1630_DATE_DEPL_LEN);
   alimenteChamp(pDonnees->code_ik, 	 	FSE1630_CODE_IK_FIELD,			FSE1630_CODE_IK_LEN);
   alimenteChamp(pDonnees->nbre_km, 	 	FSE1630_NBRE_KM_FIELD,			FSE1630_NBRE_KM_LEN);
   alimenteChamp(pDonnees->montant_ik_f, 	FSE1630_MONTANT_IK_F_FIELD, 	FSE1630_MONTANT_IK_F_LEN);
   alimenteChamp(pDonnees->montant_ik_e, 	FSE1630_MONTANT_IK_E_FIELD, 	FSE1630_MONTANT_IK_E_LEN);
   alimenteChamp(pDonnees->prix_unit_f,	FSE1630_PRIX_UNIT_F_FIELD,		FSE1630_PRIX_UNIT_F_LEN);
   alimenteChamp(pDonnees->prix_unit_e,	FSE1630_PRIX_UNIT_E_FIELD,		FSE1630_PRIX_UNIT_E_LEN);
   alimenteChamp(pDonnees->base_rmb,		FSE1630_BASE_RMB_FIELD,			FSE1630_BASE_RMB_LEN);
   alimenteChamp(pDonnees->taux,				FSE1630_TAUX_FIELD,				FSE1630_TAUX_LEN);
   alimenteChamp(pDonnees->rmb_amo,			FSE1630_RMB_AMO_FIELD,			FSE1630_RMB_AMO_LEN);
   alimenteChamp(pDonnees->rmb_amc,			FSE1630_RMB_AMC_FIELD,			FSE1630_RMB_AMC_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :   	NSFse1630::videFiche()
//
//  Description : Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSFse1630::videFiche()
{
	videChamp(pDonnees->numcompt, 	  	FSE1630_NUMCOMPT_FIELD,			FSE1630_NUMCOMPT_LEN);
   videChamp(pDonnees->numprest,			FSE1630_NUMPREST_FIELD, 		FSE1630_NUMPREST_LEN);
   videChamp(pDonnees->date_depl, 		FSE1630_DATE_DEPL_FIELD, 		FSE1630_DATE_DEPL_LEN);
   videChamp(pDonnees->code_ik, 	 		FSE1630_CODE_IK_FIELD,			FSE1630_CODE_IK_LEN);
   videChamp(pDonnees->nbre_km, 	 		FSE1630_NBRE_KM_FIELD,			FSE1630_NBRE_KM_LEN);
   videChamp(pDonnees->montant_ik_f, 	FSE1630_MONTANT_IK_F_FIELD, 	FSE1630_MONTANT_IK_F_LEN);
   videChamp(pDonnees->montant_ik_e, 	FSE1630_MONTANT_IK_E_FIELD, 	FSE1630_MONTANT_IK_E_LEN);
   videChamp(pDonnees->prix_unit_f,		FSE1630_PRIX_UNIT_F_FIELD,		FSE1630_PRIX_UNIT_F_LEN);
   videChamp(pDonnees->prix_unit_e,		FSE1630_PRIX_UNIT_E_FIELD,		FSE1630_PRIX_UNIT_E_LEN);
   videChamp(pDonnees->base_rmb,			FSE1630_BASE_RMB_FIELD,			FSE1630_BASE_RMB_LEN);
   videChamp(pDonnees->taux,				FSE1630_TAUX_FIELD,				FSE1630_TAUX_LEN);
   videChamp(pDonnees->rmb_amo,			FSE1630_RMB_AMO_FIELD,			FSE1630_RMB_AMO_LEN);
   videChamp(pDonnees->rmb_amc,			FSE1630_RMB_AMC_FIELD,			FSE1630_RMB_AMC_LEN);
}

//---------------------------------------------------------------------------
//  Fonction :  	NSFse1630::open()
//
//  Description :	Ouvre la table primaire et les index secondaires
//
//  Returns :		PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSFse1630::open()
{
	char tableName[] = "FSE1630.DB";
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_COMPTA);
	return(lastError);
}

//---------------------------------------------------------------------------
//  Function:  NSFse1630::Create()
//---------------------------------------------------------------------------
bool
NSFse1630::Create()
{
	return true;
}

//---------------------------------------------------------------------------
//  Function:  NSFse1630::Modify()
//---------------------------------------------------------------------------
bool
NSFse1630::Modify()
{
	return true;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSFse1630&
NSFse1630::operator=(NSFse1630 src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFse1630::operator == (const NSFse1630& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//---------------------------------------------------------------------------
//  Fonction:		NSFse1630Info::NSFse1630Info()
//
//  Description:	Constructeur par d�faut
//---------------------------------------------------------------------------
NSFse1630Info::NSFse1630Info()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSFse1630Data();
}

//---------------------------------------------------------------------------
//  Fonction:		NSFse1630Info::NSFse1630Info(NSFse1630*)
//
//  Description:	Constructeur � partir d'un NSFse1630
//---------------------------------------------------------------------------
NSFse1630Info::NSFse1630Info(NSFse1630* pFse1630)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFse1630Data();
	//
	// Copie les valeurs du NSFse1630
	//
	*pDonnees = *(pFse1630->pDonnees);
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFse1630Info::NSFse1630Info(NSFse1630Info& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFse1630Data();
	//
	// Copie les valeurs du NSFse1630Info d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSFse1630Info::~NSFse1630Info()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSFse1630Info&
NSFse1630Info::operator=(NSFse1630Info src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFse1630Info::operator == (const NSFse1630Info& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

//***************************************************************************
// Impl�mentation des m�thodes NSFseCCAM
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSFseCCAMData::NSFseCCAMData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero() ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFseCCAMData::NSFseCCAMData(NSFseCCAMData& rv)
{
	strcpy(numcompt, 		  rv.numcompt) ;
	strcpy(numprest,  		rv.numprest) ;
	strcpy(date, 	 		    rv.date) ;
	strcpy(code,  			  rv.code) ;
	strcpy(pourcent,      rv.pourcent) ;	strcpy(modificateurs, rv.modificateurs) ;	strcpy(montant_e,   	rv.montant_e) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSFseCCAMData::~NSFseCCAMData()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSFseCCAMData&
NSFseCCAMData::operator=(NSFseCCAMData src)
{
	if (this == &src)
		return *this ;

	strcpy(numcompt, 		  src.numcompt) ;
	strcpy(numprest,  		src.numprest) ;
	strcpy(date, 	 		    src.date) ;
	strcpy(code,  			  src.code) ;
	strcpy(pourcent,      src.pourcent) ;	strcpy(modificateurs, src.modificateurs) ;	strcpy(montant_e,   	src.montant_e) ;

	return *this ;}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFseCCAMData::operator == ( const NSFseCCAMData& o )
{
	if ((strcmp(numcompt, o.numcompt) == 0))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSFseCCAMData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(numcompt, 	  	0, FSECCAM_NUMCOMPT_LEN + 1) ;
	memset(numprest,   		0, FSECCAM_NUMPREST_LEN + 1) ;
	memset(date, 	 	  	  0, FSECCAM_DATE_LEN + 1) ;
	memset(code,  			  0, FSECCAM_CODE_LEN + 1) ;
	memset(pourcent,      0, FSECCAM_POURCENT_LEN + 1) ;	memset(modificateurs, 0, FSECCAM_MODIFICATEURS_LEN + 1) ;	memset(montant_e, 		0, FSECCAM_MONTANT_E_LEN + 1) ;
}

//---------------------------------------------------------------------------//  Constructeur
//---------------------------------------------------------------------------
NSFseCCAM::NSFseCCAM(NSContexte* pCtx) : NSFiche(pCtx)
{
	//
	// Cr�e un objet de donn�es
	//
	pDonnees = new NSFseCCAMData() ;
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSFseCCAM::NSFseCCAM(NSFseCCAM& rv) : NSFiche(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFseCCAMData() ;
	//
	// Copie les valeurs du NSTransaction d'origine
	//
	*pDonnees = *(rv.pDonnees) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSFseCCAM::~NSFseCCAM()
{
	delete pDonnees ;
}

//---------------------------------------------------------------------------//  Fonction :  	NSFseCCAM::alimenteFiche()
//
//  Description : Transf�re le contenu de pRecBuff dans les variables de
//             	la fiche
//---------------------------------------------------------------------------
void
NSFseCCAM::alimenteFiche()
{
	alimenteChamp(pDonnees->numcompt,      FSECCAM_NUMCOMPT_FIELD,      FSECCAM_NUMCOMPT_LEN) ;
	alimenteChamp(pDonnees->numprest,      FSECCAM_NUMPREST_FIELD,      FSECCAM_NUMPREST_LEN) ;
	alimenteChamp(pDonnees->date,          FSECCAM_DATE_FIELD,          FSECCAM_DATE_LEN) ;
	alimenteChamp(pDonnees->code,          FSECCAM_CODE_FIELD,          FSECCAM_CODE_LEN) ;
	alimenteChamp(pDonnees->pourcent,      FSECCAM_POURCENT_FIELD,      FSECCAM_POURCENT_LEN) ;	alimenteChamp(pDonnees->modificateurs, FSECCAM_MODIFICATEURS_FIELD, FSECCAM_MODIFICATEURS_LEN) ;	alimenteChamp(pDonnees->montant_e,     FSECCAM_MONTANT_E_FIELD,     FSECCAM_MONTANT_E_LEN) ;
}

//---------------------------------------------------------------------------//  Fonction :   	NSFseCCAM::videFiche()
//
//  Description : Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSFseCCAM::videFiche()
{
	videChamp(pDonnees->numcompt, 	   FSECCAM_NUMCOMPT_FIELD,  	  FSECCAM_NUMCOMPT_LEN) ;
	videChamp(pDonnees->numprest, 		 FSECCAM_NUMPREST_FIELD, 	    FSECCAM_NUMPREST_LEN) ;
	videChamp(pDonnees->date, 	 		   FSECCAM_DATE_FIELD, 	  	    FSECCAM_DATE_LEN) ;
	videChamp(pDonnees->code,  			   FSECCAM_CODE_FIELD, 		      FSECCAM_CODE_LEN) ;
	videChamp(pDonnees->pourcent,      FSECCAM_POURCENT_FIELD,      FSECCAM_POURCENT_LEN) ;	videChamp(pDonnees->modificateurs, FSECCAM_MODIFICATEURS_FIELD, FSECCAM_MODIFICATEURS_LEN) ;	videChamp(pDonnees->montant_e, 		 FSECCAM_MONTANT_E_FIELD,  	  FSECCAM_MONTANT_E_LEN) ;
}

//---------------------------------------------------------------------------//  Fonction :  	NSFseCCAM::open()
//
//  Description :	Ouvre la table primaire et les index secondaires
//
//  Returns :		PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSFseCCAM::open()
{
	char tableName[] = "FSECCAM.DB" ;
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_COMPTA) ;
	return(lastError) ;
}

//---------------------------------------------------------------------------//  Function:  NSFseCCAM::Create()
//---------------------------------------------------------------------------
bool
NSFseCCAM::Create()
{
	return true ;
}

//---------------------------------------------------------------------------//  Function:  NSFseCCAM::Modify()
//---------------------------------------------------------------------------
bool
NSFseCCAM::Modify()
{
	return true ;
}

//---------------------------------------------------------------------------//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSFseCCAM&
NSFseCCAM::operator=(NSFseCCAM src)
{
	if (this == &src)
		return *this ;

	*pDonnees = *(src.pDonnees) ;
  
	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFseCCAM::operator == (const NSFseCCAM& o)
{
	return (*pDonnees == *(o.pDonnees)) ;
}

//---------------------------------------------------------------------------//  Fonction:		NSFseCCAMInfo::NSFseCCAMInfo()
//
//  Description:	Constructeur par d�faut
//---------------------------------------------------------------------------
NSFseCCAMInfo::NSFseCCAMInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSFseCCAMData() ;
}

//---------------------------------------------------------------------------//  Fonction:		NSFseCCAMInfo::NSFseCCAMInfo(NSFseCCAM*)
//
//  Description:	Constructeur � partir d'un NSFseCCAM
//---------------------------------------------------------------------------
NSFseCCAMInfo::NSFseCCAMInfo(NSFseCCAM* pFseCCAM)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFseCCAMData() ;
	//
	// Copie les valeurs du NSFseCCAM
	//
	*pDonnees = *(pFseCCAM->pDonnees) ;
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSFseCCAMInfo::NSFseCCAMInfo(NSFseCCAMInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFseCCAMData() ;
	//
	// Copie les valeurs du NSFseCCAMInfo d'origine
	//
	*pDonnees = *(rv.pDonnees) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSFseCCAMInfo::~NSFseCCAMInfo()
{
	delete pDonnees ;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSFseCCAMInfo&
NSFseCCAMInfo::operator=(NSFseCCAMInfo src)
{
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSFseCCAMInfo::operator == (const NSFseCCAMInfo& o)
{
	 return (*pDonnees == *(o.pDonnees)) ;
}
voidNSFseCCAMInfo::initFromCCAMinfo(NSCcamInfo* pCCAMInfo){	strcpy(pDonnees->code,  		pCCAMInfo->pDonnees->code) ;	strcpy(pDonnees->montant_e, pCCAMInfo->pDonnees->prix) ;}//***************************************************************************
// Impl�mentation des m�thodes NSCodPrest
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSCodPrestData::NSCodPrestData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCodPrestData::NSCodPrestData(NSCodPrestData& rv)
{
	strcpy(code,		rv.code);
   strcpy(libelle,	rv.libelle);
   strcpy(fse16xx,	rv.fse16xx);
   strcpy(prix_f,		rv.prix_f);
   strcpy(prix_e,		rv.prix_e);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCodPrestData::~NSCodPrestData()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSCodPrestData&
NSCodPrestData::operator=(NSCodPrestData src)
{
	strcpy(code,		src.code);
   strcpy(libelle,	src.libelle);
   strcpy(fse16xx,	src.fse16xx);
   strcpy(prix_f,		src.prix_f);
   strcpy(prix_e,		src.prix_e);

	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCodPrestData::operator == ( const NSCodPrestData& o )
{
	if ((strcmp(code, o.code) == 0))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Met � blanc les variables de la fiche
//---------------------------------------------------------------------------
void
NSCodPrestData::metABlanc()
{
	//
	// Met les champs de donn�es � blanc
	//
   memset(code,			' ', CODPREST_CODE_LEN);
   memset(libelle,		' ', CODPREST_LIBELLE_LEN);
   memset(fse16xx,		' ', CODPREST_FSE16XX_LEN);
   memset(prix_f,			' ', CODPREST_PRIX_F_LEN);
   memset(prix_e,			' ', CODPREST_PRIX_E_LEN);
}

//---------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSCodPrestData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
   memset(code,			0, CODPREST_CODE_LEN + 1);
   memset(libelle,		0, CODPREST_LIBELLE_LEN + 1);
   memset(fse16xx,		0, CODPREST_FSE16XX_LEN + 1);
   memset(prix_f,			0, CODPREST_PRIX_F_LEN + 1);
   memset(prix_e,			0, CODPREST_PRIX_E_LEN + 1);
}
//---------------------------------------------------------------------------//  Constructeur
//---------------------------------------------------------------------------
NSCodPrest::NSCodPrest(NSContexte* pCtx) : NSFiche(pCtx)
{
	//
	// Cr�e un objet de donn�es
	//
	pDonnees = new NSCodPrestData();
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCodPrest::NSCodPrest(NSCodPrest& rv) : NSFiche(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCodPrestData();
	//
	// Copie les valeurs du NSTransaction d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCodPrest::~NSCodPrest()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Fonction :  	NSCodPrest::alimenteFiche()
//
//  Description : Transf�re le contenu de pRecBuff dans les variables de
//             	la fiche
//---------------------------------------------------------------------------
void
NSCodPrest::alimenteFiche()
{
  alimenteChamp(pDonnees->code,    CODPREST_CODE_FIELD,    CODPREST_CODE_LEN) ;
  alimenteChamp(pDonnees->libelle, CODPREST_LIBELLE_FIELD, CODPREST_LIBELLE_LEN) ;
  alimenteChamp(pDonnees->fse16xx, CODPREST_FSE16XX_FIELD, CODPREST_FSE16XX_LEN) ;
  alimenteChamp(pDonnees->prix_f,  CODPREST_PRIX_F_FIELD,  CODPREST_PRIX_F_LEN) ;
  alimenteChamp(pDonnees->prix_e,  CODPREST_PRIX_E_FIELD,  CODPREST_PRIX_E_LEN) ;
}

//---------------------------------------------------------------------------//  Fonction :   	NSCodPrest::videFiche()
//
//  Description : Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSCodPrest::videFiche()
{
	videChamp(pDonnees->code,    CODPREST_CODE_FIELD,    CODPREST_CODE_LEN) ;
	videChamp(pDonnees->libelle, CODPREST_LIBELLE_FIELD, CODPREST_LIBELLE_LEN) ;
	videChamp(pDonnees->fse16xx, CODPREST_FSE16XX_FIELD, CODPREST_FSE16XX_LEN) ;
	videChamp(pDonnees->prix_f,  CODPREST_PRIX_F_FIELD,  CODPREST_PRIX_F_LEN) ;
	videChamp(pDonnees->prix_e,  CODPREST_PRIX_E_FIELD,  CODPREST_PRIX_E_LEN) ;
}

//---------------------------------------------------------------------------
//  Fonction :  	NSCodPrest::open()
//
//  Description :	Ouvre la table primaire et les index secondaires
//
//  Returns :		PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSCodPrest::open()
{
	char tableName[] = "CODPREST.DB" ;
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_COMPTA) ;
	return(lastError) ;
}

//---------------------------------------------------------------------------
//  Function:  NSCodPrest::Create()
//---------------------------------------------------------------------------
bool
NSCodPrest::Create()
{
	return true ;
}

//---------------------------------------------------------------------------
//  Function:  NSCodPrest::Modify()
//---------------------------------------------------------------------------
bool
NSCodPrest::Modify()
{
	return true ;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSCodPrest&
NSCodPrest::operator=(NSCodPrest src)
{
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCodPrest::operator == (const NSCodPrest& o)
{
	return (*pDonnees == *(o.pDonnees)) ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCodPrestInfo::NSCodPrestInfo()
//
//  Description:	Constructeur par d�faut
//---------------------------------------------------------------------------
NSCodPrestInfo::NSCodPrestInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSCodPrestData() ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCodPrestInfo::NSCodPrestInfo(NSCodPrest*)
//
//  Description:	Constructeur � partir d'un NSCodPrest
//---------------------------------------------------------------------------
NSCodPrestInfo::NSCodPrestInfo(NSCodPrest* pCodPrest)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCodPrestData() ;
	//
	// Copie les valeurs du NSCodPrest
	//
	*pDonnees = *(pCodPrest->pDonnees) ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCodPrestInfo::NSCodPrestInfo(NSCodPrestInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCodPrestData() ;
	//
	// Copie les valeurs du NSCodPrestInfo d'origine
	//
	*pDonnees = *(rv.pDonnees) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCodPrestInfo::~NSCodPrestInfo()
{
	delete pDonnees ;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSCodPrestInfo&
NSCodPrestInfo::operator=(NSCodPrestInfo src)
{
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCodPrestInfo::operator == (const NSCodPrestInfo& o)
{
	return (*pDonnees == *(o.pDonnees)) ;
}

//***************************************************************************
// 					Impl�mentation des m�thodes NSCodPrestArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCodPrestArray::NSCodPrestArray(NSCodPrestArray& rv) : NSFicheCodPrestArray()
{
	for (NSCodPrestIter i = rv.begin(); i != rv.end(); i++)
		push_back(new NSCodPrestInfo(*(*i))) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSCodPrestArray::vider()
{
	for (NSCodPrestIter i = begin(); i != end(); )
	{
  	delete *i ;
    erase(i) ;
	}
}

NSCodPrestArray::~NSCodPrestArray(){
	vider() ;
}

//////////////////////////// fin du fichier NSFse.cpp

