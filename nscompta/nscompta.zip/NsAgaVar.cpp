// nsagadlg.cpp : dialogues des AGA des fiches Fact// RS Sept 98
//////////////////////////////////////////////////////////

#include <stdio.h>
#include <classlib\date.h>
#include <classlib\time.h>

#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"
#include "nscompta\nsagavar.h"

//***************************************************************************
// 								Classe NSComboArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSComboArray::NSComboArray(NSComboArray& rv) : NSComboBoxArray()
{
	if (!(rv.empty()))
		for (NSComboIter i = rv.begin(); i != rv.end(); i++)
			push_back(new NSComboItem(*(*i))) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
void
NSComboArray::vider()
{
	if (empty())
  	return ;

	for (NSComboIter i = begin(); i != end(); )
  {
  	delete *i ;
    erase(i) ;
  }
}

NSComboArray::~NSComboArray(){
	vider();
}

//-----------------------------------------------------------------------// fonction globale d'initialisation des combobox
//-----------------------------------------------------------------------
bool
InitComboBox(TComboBox* pCombo, NSComboArray* pComboArray, string sFichier)
{
  ifstream 	  inFile ;
  string 		  sData = "" ;
  string      line ;
  size_t 		  i = 0 ;
  NSComboItem tCombo ;

  inFile.open(sFichier.c_str());
	if (!inFile)
    return false ;

  while (!inFile.eof())
  {
    getline(inFile,line) ;
    if (line != "")
      sData += line + "\n" ;
  }
  inFile.close() ;

  while ((i < strlen(sData.c_str())) && (sData[i] != ';'))
  {
    tCombo.sCode  = "" ;
    tCombo.sLabel = "" ;

    while ((i < strlen(sData.c_str())) && (sData[i] != '\n') && (sData[i] != ' '))
      tCombo.sCode += sData[i++] ;
    i++ ;

    while ((i < strlen(sData.c_str())) && (sData[i] != '\n'))
      tCombo.sLabel += sData[i++] ;
    i++ ;

    pComboArray->push_back(new NSComboItem(tCombo)) ;
  }

  if (!(pComboArray->empty()))
    for (NSComboIter j = pComboArray->begin(); j != pComboArray->end(); j++)
      pCombo->AddString(((*j)->sLabel).c_str()) ;

  return true ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSVarCompta
//
// -----------------------------------------------------------------
NSVarCompta::NSVarCompta(NSContexte* pCtx)
{
	parite        = pCtx->getSuperviseur()->getParite() ;
	monnaieRef 	  = pCtx->getSuperviseur()->getMonnaieRef() ;
	sigle		      = pCtx->getSuperviseur()->getSigle() ;
	indiceConsult = pCtx->getSuperviseur()->getIndiceConsult() ;

	sDateC        = "" ;
	sHeureC       = "" ;
	bCreation     = true ;
	bFact0        = true ;
}

NSVarCompta::NSVarCompta(NSVarCompta& rv){
	parite 		    = rv.parite ;
  monnaieRef 	  = rv.monnaieRef ;
  sigle 		    = rv.sigle ;
  indiceConsult = rv.indiceConsult ;
  sDateC 		    = rv.sDateC ;
  sHeureC 	    = rv.sHeureC ;
  bCreation	    = rv.bCreation ;
  bFact0		    = rv.bFact0 ;
}

NSVarCompta&
NSVarCompta::operator=(NSVarCompta src)
{
	if (this == &src)
		return *this ;

	parite 		    = src.parite ;
  monnaieRef 	  = src.monnaieRef ;
  sigle 		    = src.sigle ;
  indiceConsult = src.indiceConsult ;
  sDateC 		    = src.sDateC ;
  sHeureC 		  = src.sHeureC ;
  bCreation	    = src.bCreation ;
  bFact0		    = src.bFact0 ;

	return *this ;
}

//***************************************************************************// Impl�mentation des m�thodes NSAgaData
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSAgaData::NSAgaData(NSContexte* pCtx)
          :patInfo(pCtx), NSRoot(pCtx)
{
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero() ;
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSAgaData::NSAgaData(NSAgaData& rv) : patInfo(rv.patInfo), NSRoot(rv.pContexte)
{
	strcpy(nomPatient, rv.nomPatient) ;
	strcpy(libelle,    rv.libelle) ;
	strcpy(numCompt,   rv.numCompt) ;
	strcpy(actes,	     rv.actes) ;
	strcpy(montant,    rv.montant) ;
	strcpy(unite, 	   rv.unite) ;
	strcpy(modePaie,   rv.modePaie) ;
	strcpy(datePaie,   rv.datePaie) ;
}
//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSAgaData::~NSAgaData()
{
}

//---------------------------------------------------------------------------//  Op�rateur =
//---------------------------------------------------------------------------
NSAgaData&
NSAgaData::operator=(NSAgaData src)
{
	if (this == &src)
		return *this ;

	strcpy(nomPatient, src.nomPatient) ;
	strcpy(libelle,    src.libelle) ;	strcpy(numCompt, 	 src.numCompt) ;
	strcpy(actes,		   src.actes) ;
	strcpy(montant,  	 src.montant) ;
	strcpy(unite, 		 src.unite) ;
	strcpy(modePaie,	 src.modePaie) ;
	strcpy(datePaie,   src.datePaie) ;

	patInfo = src.patInfo ;

	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSAgaData::operator == (NSAgaData& o)
{
	if ((strcmp(nomPatient,	o.nomPatient)   == 0) &&
        (strcmp(libelle,    o.libelle)      == 0) &&
   	    (strcmp(numCompt, 	o.numCompt) 	== 0) &&
   	    (strcmp(actes, 		o.actes) 		== 0) &&
        (strcmp(montant,	o.montant)		== 0) &&
        (strcmp(unite,		o.unite)		== 0) &&
        (strcmp(modePaie,	o.modePaie)		== 0) &&
        (strcmp(datePaie,   o.datePaie)     == 0) &&        (patInfo == o.patInfo))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSAgaData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
  memset(nomPatient,  0, PAT_NOM_LONG_LEN + 1);
  memset(libelle,     0, REC_LIBELLE_LEN + 1);	memset(numCompt,    0, FACT_NUMCOMPT_LEN + 1);
  memset(actes,       0, AGA_ACTES_LEN + 1);
	memset(montant,     0, FACT_MONTANT_LEN + 1);
	memset(unite,       0, FACT_UNITE_LEN + 1);
  memset(modePaie,    0, FACT_MODE_PAIE_LEN + 1);
  memset(datePaie,    0, AGA_DATE_PAIE_LEN + 1);

#ifndef _MUE
    patInfo.pDonnees->metAZero();#endif
}
//***************************************************************************// 					Impl�mentation des m�thodes NSAgaArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSAgaArray::NSAgaArray(NSAgaArray& rv) : NSFicheAgaArray()
{
	if (!(rv.empty()))
		for (NSAgaIter i = rv.begin(); i != rv.end(); i++)
    	push_back(new NSAgaData(*(*i))) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSAgaArray::vider()
{
	if (empty())
		return ;

	for (NSAgaIter i = begin(); i != end(); )
	{
  	delete *i ;
    erase(i) ;
	}
}

NSAgaArray::~NSAgaArray(){
	vider() ;
}

//***************************************************************************// 					Impl�mentation des m�thodes NSCriteres
//***************************************************************************

NSCriteres::NSCriteres(){
	sDateAga1       = "" ;
	sDateAga2       = "" ;
	bActesPerso     = false ;
}

NSCriteres::NSCriteres(NSCriteres& rv)
{
	sDateAga1       = rv.sDateAga1 ;
	sDateAga2       = rv.sDateAga2 ;
	bActesPerso	    = rv.bActesPerso ;
}

NSCriteres&NSCriteres::operator=(NSCriteres src)
{
	if (this == &src)
		return *this ;

	sDateAga1 	    = src.sDateAga1 ;	sDateAga2       = src.sDateAga2 ;
	bActesPerso	    = src.bActesPerso ;

	return *this ;
}

NSCriteres::~NSCriteres(){
}

//***************************************************************************
//
// Impl�mentation des m�thodes NSAffDepensData//
//***************************************************************************
//---------------------------------------------------------------------------//  Constructeur
//---------------------------------------------------------------------------

NSAffDepensData::NSAffDepensData(){
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero() ;
}
//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------

NSAffDepensData::NSAffDepensData(NSAffDepensData& rv){
	depense  = rv.depense ;
	ecriture = rv.ecriture ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------

NSAffDepensData::~NSAffDepensData(){
}

//---------------------------------------------------------------------------//  Op�rateur =
//---------------------------------------------------------------------------

NSAffDepensData&NSAffDepensData::operator=(NSAffDepensData src)
{
	if (this == &src)
		return *this ;

	depense  = src.depense ;
	ecriture = src.ecriture ;
	return *this ;}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------

intNSAffDepensData::operator == (NSAffDepensData& o)
{
	if ((depense == o.depense) &&
        (ecriture == o.ecriture))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------

voidNSAffDepensData::metAZero()
{
	depense.metAZero() ;
	ecriture.metAZero() ;
}
//***************************************************************************// 					Impl�mentation des m�thodes NSAffDepensArray
//***************************************************************************

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------

NSAffDepensArray::NSAffDepensArray(NSAffDepensArray& rv) : NSFicheAffDepensArray(){
	if (!(rv.empty()))
  	for (NSAffDepensIter i = rv.begin(); i != rv.end(); i++)
    	push_back(new NSAffDepensData(*(*i))) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------

voidNSAffDepensArray::vider()
{
    if (empty())
        return;

    for (NSAffDepensIter i = begin(); i != end(); )    {
   	    delete *i;
        erase(i);
    }
}

NSAffDepensArray::~NSAffDepensArray(){
	vider();
}

//***************************************************************************//
// Impl�mentation des m�thodes NSImpData//
//***************************************************************************
//---------------------------------------------------------------------------//  Constructeur
//---------------------------------------------------------------------------
NSImpData::NSImpData(NSContexte* pCtx) : patInfo(pCtx), NSRoot(pCtx)
{
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero() ;
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSImpData::NSImpData(NSImpData& rv) : patInfo(rv.patInfo), NSRoot(rv.pContexte)
{
	strcpy(numCompt,	   rv.numCompt) ;
	strcpy(dateCompt,	   rv.dateCompt) ;
	// strcpy(nomPatient,	 rv.nomPatient) ;
	// strcpy(libExam, 	   rv.libExam) ;
  strcpy(codePatient,	 rv.codePatient) ;
  strcpy(sommeDueLoc,	 rv.sommeDueLoc) ;
  strcpy(sommeDueEuro, rv.sommeDueEuro) ;
  strcpy(impayeLoc,	   rv.impayeLoc) ;
  strcpy(impayeEuro,	 rv.impayeEuro) ;
  strcpy(libOrga,		   rv.libOrga) ;

  sNomPatient = rv.sNomPatient ;
  sLibExam    = rv.sLibExam ;

  bPatientLoaded = rv.bPatientLoaded ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSImpData::~NSImpData()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSImpData&
NSImpData::operator=(NSImpData src)
{
	if (this == &src)
		return *this ;

	strcpy(numCompt,		 src.numCompt) ;	strcpy(dateCompt,		 src.dateCompt) ;
	// strcpy(nomPatient,	 src.nomPatient) ;
	// strcpy(libExam, 	   src.libExam) ;
  strcpy(codePatient,	 src.codePatient) ;
  strcpy(sommeDueLoc,	 src.sommeDueLoc) ;
  strcpy(sommeDueEuro, src.sommeDueEuro) ;
  strcpy(impayeLoc,		 src.impayeLoc) ;
  strcpy(impayeEuro,	 src.impayeEuro) ;
  strcpy(libOrga,		   src.libOrga) ;

  sNomPatient = src.sNomPatient ;
  sLibExam    = src.sLibExam ;

  bPatientLoaded = src.bPatientLoaded ;

  patInfo = src.patInfo ;

	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSImpData::operator == (NSImpData& o)
{
	if ((strcmp(numCompt,		 o.numCompt)		 == 0) &&
   	 (strcmp(dateCompt,		 o.dateCompt)		 == 0) &&
   	 // (strcmp(nomPatient, 	 o.nomPatient) 	 == 0) &&
   	 // (strcmp(libExam, 		 o.libExam) 		 == 0) &&
     (strcmp(codePatient,  o.codePatient)  == 0) &&
     (strcmp(sommeDueLoc,	 o.sommeDueLoc)	 == 0) &&
     (strcmp(sommeDueEuro, o.sommeDueEuro) == 0) &&
     (strcmp(impayeLoc,		 o.impayeLoc)		 == 0) &&
     (strcmp(impayeEuro,	 o.impayeEuro)	 == 0) &&
     (strcmp(libOrga,			 o.libOrga)			 == 0) &&
     (sNomPatient	== o.sNomPatient) &&
     (sLibExam	  == o.sLibExam) &&
     (patInfo     == o.patInfo))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSImpData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
  memset(numCompt,		 0, CPTA_NUMCOMPT_LEN + 1) ;
	memset(dateCompt,		 0, CPTA_DATE_LEN + 1) ;
  // memset(nomPatient,	 0, PAT_NOM_LONG_LEN + 1) ;
	// memset(libExam, 		 0, IMP_LIB_EXAM_LEN + 1) ;
  memset(codePatient,	 0, PAT_NSS_LEN + 1) ;
  memset(sommeDueLoc,	 0, CPTA_DUE_F_LEN + 1) ;
	memset(sommeDueEuro, 0, CPTA_DUE_E_LEN + 1) ;
	memset(impayeLoc, 	 0, TPAY_RESTE_DU_LEN + 1) ;
  memset(impayeEuro, 	 0, TPAY_RESTE_DU_LEN + 1) ;
  memset(libOrga,		   0, TPAY_LIBELLE_LEN + 1) ;

  sNomPatient = string("") ;
  sLibExam    = string("") ;

  bPatientLoaded = false ;

#ifndef _MUE
   patInfo.pDonnees->metAZero() ;#endif
}
bool
NSImpData::initPatientInfo()
{
  if ('\0' == codePatient[0])
    return false ;

  bPatientLoaded = true ;

  NSPersonInfo tempInfo(pContexte, string(codePatient), pidsPatient) ;

	sNomPatient = tempInfo.sCivilite ;
  patInfo     = NSPersonInfo(tempInfo) ;

	return true ;
}

//***************************************************************************// 					Impl�mentation des m�thodes NSImpArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------NSImpArray::NSImpArray(NSImpArray& rv) : NSFicheImpArray()
{
	if (!(rv.empty()))
		for (NSImpIter i = rv.begin(); i != rv.end(); i++)
   		push_back(new NSImpData(*(*i))) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSImpArray::vider()
{
	if (!(empty()))
		for (NSImpIter i = begin(); i != end(); )
   	{
   		delete *i ;
      erase(i) ;
   	}
}

NSImpArray::~NSImpArray(){
	vider() ;
}

void
NSImpArray::initAllPatientInfo()
{
  if (empty())
    return ;

  for (NSImpIter i = begin(); i != end(); )
    if (false == (*i)->bPatientLoaded)
      (*i)->initPatientInfo() ;
}

//***************************************************************************// Impl�mentation des m�thodes NSSomActData
//***************************************************************************

NSSomActData::NSSomActData()
{
	totalLoc = 0;
  totalEuro = 0;
  depassLoc = 0;
  depassEuro = 0;
  paieLoc = 0;
  paieEuro = 0;
  espLoc = 0;
  espEuro = 0;
  chqLoc = 0;
  chqEuro = 0;
  virLoc = 0;
  virEuro = 0;
  cbLoc = 0;
  cbEuro = 0;
  impayeLoc = 0;
  impayeEuro = 0;
  impTPLoc = 0;
  impTPEuro = 0;
  impAutreLoc = 0;
  impAutreEuro = 0;
}

NSSomActData::~NSSomActData(){
}

NSSomActData::NSSomActData(NSSomActData& rv){
	totalLoc = 		rv.totalLoc;
  totalEuro = 	rv.totalEuro;
  depassLoc = 	rv.depassLoc;
  depassEuro = 	rv.depassEuro;
  paieLoc = 		rv.paieLoc;
  paieEuro = 		rv.paieEuro;
  espLoc = 		rv.espLoc;
  espEuro = 		rv.espEuro;
  chqLoc = 		rv.chqLoc;
  chqEuro = 		rv.chqEuro;
  virLoc = 		rv.virLoc;
  virEuro = 		rv.virEuro;
  cbLoc = 			rv.cbLoc;
  cbEuro       = rv.cbEuro;
  impayeLoc    = rv.impayeLoc;
  impayeEuro   = rv.impayeEuro;
  impTPLoc     = rv.impTPLoc;
  impTPEuro    = rv.impTPEuro;
  impAutreLoc  = rv.impAutreLoc;
  impAutreEuro = rv.impAutreEuro;
}
NSSomActData&NSSomActData::operator=(NSSomActData src)
{
	if (this == &src)
		return *this ;

	totalLoc = 		src.totalLoc;
  totalEuro = 	src.totalEuro;
  depassLoc = 	src.depassLoc;
  depassEuro = 	src.depassEuro;
  paieLoc = 		src.paieLoc;
  paieEuro = 		src.paieEuro;
  espLoc = 		src.espLoc;
  espEuro = 		src.espEuro;
  chqLoc = 		src.chqLoc;
  chqEuro = 		src.chqEuro;
  virLoc = 		src.virLoc;
  virEuro = 		src.virEuro;
  cbLoc = 			src.cbLoc;
  cbEuro = 		src.cbEuro;
  impayeLoc = 	src.impayeLoc;
  impayeEuro = 	src.impayeEuro;
  impTPLoc = 		src.impTPLoc;
  impTPEuro = 	src.impTPEuro;
  impAutreLoc = 	src.impAutreLoc;
  impAutreEuro = src.impAutreEuro;

	return *this ;
}

//***************************************************************************// Impl�mentation des m�thodes NSTotauxData
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSTotauxData::NSTotauxData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	sLibelle = "";
   montantLoc = 0;
   montantEuro = 0;
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSTotauxData::NSTotauxData(NSTotauxData& rv)
{
	sLibelle = rv.sLibelle;
   montantLoc = rv.montantLoc;
   montantEuro = rv.montantEuro;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSTotauxData::~NSTotauxData()
{
}

//---------------------------------------------------------------------------//  Op�rateur =
//---------------------------------------------------------------------------
NSTotauxData&
NSTotauxData::operator=(NSTotauxData src)
{
	if (this == &src)
		return *this ;

	sLibelle = src.sLibelle;
  montantLoc = src.montantLoc;
  montantEuro = src.montantEuro;

	return *this ;
}

//***************************************************************************// 					Impl�mentation des m�thodes NSTotauxArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSTotauxArray::NSTotauxArray(NSTotauxArray& rv) : NSFicheTotauxArray()
{
  if (!(rv.empty()))
		for (NSTotauxIter i = rv.begin(); i != rv.end(); i++)
   		push_back(new NSTotauxData(*(*i))) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
void
NSTotauxArray::vider()
{
	if (!(empty()))
		for (NSTotauxIter i = begin(); i != end(); )
   	{
   		delete *i ;
      erase(i) ;
   	}
}

NSTotauxArray::~NSTotauxArray(){
	vider() ;
}

//***************************************************************************// Impl�mentation des m�thodes NSKCodeData
//***************************************************************************

//---------------------------------------------------------------------------//  Constructeur
//---------------------------------------------------------------------------
NSKCodeData::NSKCodeData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	sKCode = "" ;
  occur = 0.0 ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSKCodeData::NSKCodeData(NSKCodeData& rv)
{
	sKCode = rv.sKCode ;
  occur = rv.occur ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSKCodeData::~NSKCodeData()
{
}

//---------------------------------------------------------------------------//  Op�rateur =
//---------------------------------------------------------------------------
NSKCodeData&
NSKCodeData::operator=(NSKCodeData src)
{
	sKCode = src.sKCode ;
  occur = src.occur ;

	return *this ;}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSKCodeData::operator == (NSKCodeData& o)
{
	if ((sKCode == o.sKCode) &&
   	  (occur  == o.occur))
		return 1 ;
	else
		return 0 ;
}

//***************************************************************************// 					Impl�mentation des m�thodes NSKCodeArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSKCodeArray::NSKCodeArray(NSKCodeArray& rv) : NSFicheKCodeArray()
{
	if (!(rv.empty()))
		for (NSKCodeIter i = rv.begin(); i != rv.end(); i++)
   		push_back(new NSKCodeData(*(*i))) ;
}

NSKCodeArray&NSKCodeArray::operator=(NSKCodeArray src)
{
	vider() ;

	if (!(src.empty()))
		for (NSKCodeIter i = src.begin(); i != src.end(); i++)
   		push_back(new NSKCodeData(*(*i))) ;

   return *this ;
}

intNSKCodeArray::operator==(NSKCodeArray& o)
{
	NSKCodeIter i,j;

	if (size() != o.size())
   	return 0 ;

	for (i = begin(), j = o.begin(); i != end(); i++, j++)
   	if (!((*(*i)) == (*(*j)))) return 0 ;

   return 1 ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSKCodeArray::vider()
{
	if (!(empty()))
		for (NSKCodeIter i = begin(); i != end(); )
		{
   		delete *i ;
    	erase(i) ;
		}
}

NSKCodeArray::~NSKCodeArray(){
	vider() ;
}

//***************************************************************************
// Impl�mentation des m�thodes NSCCAMCodeData
//***************************************************************************

//---------------------------------------------------------------------------//  Constructeur
//---------------------------------------------------------------------------
NSCCAMCodeData::NSCCAMCodeData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	sCCAMCode = "" ;
  sCCAMlib  = "" ;
  dNbre     = 0.0 ;
  dSomTotal = 0.0 ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCCAMCodeData::NSCCAMCodeData(NSCCAMCodeData& rv)
{
	sCCAMCode = rv.sCCAMCode ;
  sCCAMlib  = rv.sCCAMlib ;
  dNbre     = rv.dNbre ;
  dSomTotal = rv.dSomTotal ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCCAMCodeData::~NSCCAMCodeData()
{
}

//---------------------------------------------------------------------------//  Op�rateur =
//---------------------------------------------------------------------------
NSCCAMCodeData&
NSCCAMCodeData::operator=(NSCCAMCodeData src)
{
	sCCAMCode = src.sCCAMCode ;
  sCCAMlib  = src.sCCAMlib ;
  dNbre     = src.dNbre ;
  dSomTotal = src.dSomTotal ;

	return *this ;}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCCAMCodeData::operator == (NSCCAMCodeData& o)
{
	if ((sCCAMCode == o.sCCAMCode) &&
      (sCCAMlib  == o.sCCAMlib)  &&
      (dNbre     == o.dNbre)     &&
   	  (dSomTotal == o.dSomTotal))
		return 1 ;
	else
		return 0 ;
}

//***************************************************************************// 					Impl�mentation des m�thodes NSKCodeArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCCAMCodeArray::NSCCAMCodeArray(NSCCAMCodeArray& rv) : NSFicheCCAMCodeArray()
{
	if (!(rv.empty()))
		for (NSCCAMCodeIter i = rv.begin(); i != rv.end(); i++)
   		push_back(new NSCCAMCodeData(*(*i))) ;
}

NSCCAMCodeArray&NSCCAMCodeArray::operator=(NSCCAMCodeArray src)
{
	if (this == &src)
		return *this ;

	vider() ;

	if (!(src.empty()))
		for (NSCCAMCodeIter i = src.begin(); i != src.end(); i++)
   		push_back(new NSCCAMCodeData(*(*i))) ;

	return *this ;
}

intNSCCAMCodeArray::operator==(NSCCAMCodeArray& o)
{
	NSCCAMCodeIter i, j ;

	if (size() != o.size())
   	return 0 ;

	for (i = begin(), j = o.begin(); i != end(); i++, j++)
   	if (!((*(*i)) == (*(*j)))) return 0 ;

   return 1 ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSCCAMCodeArray::vider()
{
	if (!(empty()))
		for (NSCCAMCodeIter i = begin(); i != end(); )
		{
   		delete *i ;
    	erase(i) ;
		}
}

NSCCAMCodeArray::~NSCCAMCodeArray(){
	vider() ;
}

//***************************************************************************
// Impl�mentation des m�thodes NSExamData
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSExamData::NSExamData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	sCodeExam = "";
   nbExam = 0;
   aKCodeArray.vider();
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSExamData::NSExamData(NSExamData& rv)
{
	sCodeExam 	= rv.sCodeExam;
   nbExam		= rv.nbExam;
   aKCodeArray = rv.aKCodeArray;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSExamData::~NSExamData()
{
}

//---------------------------------------------------------------------------//  Op�rateur =
//---------------------------------------------------------------------------
NSExamData&
NSExamData::operator=(NSExamData src)
{
	if (this == &src)
		return *this ;

	sCodeExam 	= src.sCodeExam ;
	nbExam		  = src.nbExam ;
	aKCodeArray = src.aKCodeArray ;

	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSExamData::operator == (NSExamData& o)
{
	if ((sCodeExam 	== o.sCodeExam) 	&&
   	 (nbExam  		== o.nbExam)		&&
       (aKCodeArray  == o.aKCodeArray))
		return 1;
	else
		return 0;
}

//***************************************************************************
// 					Impl�mentation des m�thodes NSExamArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSExamArray::NSExamArray(NSExamArray& rv) : NSFicheExamArray()
{
	if (!(rv.empty()))
		for (NSExamIter i = rv.begin(); i != rv.end(); i++)   		push_back(new NSExamData(*(*i))) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
void
NSExamArray::vider()
{
	if (!(empty()))
		for (NSExamIter i = begin(); i != end(); )   	{
   		delete *i ;
      erase(i) ;
   	}
}

NSExamArray::~NSExamArray()
{
	vider() ;
}

//***************************************************************************// Impl�mentation des m�thodes NSListActData
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSListActData::NSListActData(NSContexte* pCtx) : patInfo(pCtx), NSRoot(pCtx)
{
	//
	// Met les champs de donn�es � z�ro
	//	metAZero() ;
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSListActData::NSListActData(NSListActData& rv)
              :patInfo(rv.patInfo), NSRoot(rv.pContexte)
{
	strcpy(numCompt,   rv.numCompt) ;
	strcpy(dateCompt,  rv.dateCompt) ;
	strcpy(nomPatient, rv.nomPatient) ;
	strcpy(libExam,    rv.libExam) ;
	strcpy(actes,	     rv.actes) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSListActData::~NSListActData()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSListActData&
NSListActData::operator=(NSListActData src)
{
	if (this == &src)
		return *this ;

	strcpy(numCompt,	 src.numCompt) ;	strcpy(dateCompt,	 src.dateCompt) ;
	strcpy(nomPatient, src.nomPatient) ;
	strcpy(libExam, 	 src.libExam) ;
	strcpy(actes,			 src.actes) ;

	patInfo = src.patInfo ;

	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSListActData::operator == (NSListActData& o)
{
	if ((strcmp(numCompt,		o.numCompt)			== 0) &&
   	 (strcmp(dateCompt,		o.dateCompt)		== 0) &&
   	 (strcmp(nomPatient, 	o.nomPatient) 		== 0) &&
   	 (strcmp(libExam, 		o.libExam) 			== 0) &&
       (strcmp(actes,			o.actes)				== 0) &&
       (patInfo 		== 		o.patInfo))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSListActData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
   memset(numCompt,		0, CPTA_NUMCOMPT_LEN + 1);
	memset(dateCompt,		0, CPTA_DATE_LEN + 1);
   memset(nomPatient,	0, PAT_NOM_LONG_LEN + 1);
	memset(libExam, 		0, IMP_LIB_EXAM_LEN + 1);
   memset(actes,			0, AGA_ACTES_LEN + 1);

#ifndef _MUE
   patInfo.pDonnees->metAZero();#endif
}
//***************************************************************************// 					Impl�mentation des m�thodes NSListActArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSListActArray::NSListActArray(NSListActArray& rv) : NSFicheListActArray()
{
	if (!(rv.empty()))
		for (NSListActIter i = rv.begin(); i != rv.end(); i++)
   		push_back(new NSListActData(*(*i))) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
void
NSListActArray::vider()
{
	if (!(empty()))
		for (NSListActIter i = begin(); i != end(); )   	{
   		delete *i ;
      erase(i) ;
   	}
}

NSListActArray::~NSListActArray(){
	vider() ;
}

//***************************************************************************// Impl�mentation des m�thodes NSEncaissData
//***************************************************************************

//---------------------------------------------------------------------------//  Constructeur
//---------------------------------------------------------------------------
NSEncaissData::NSEncaissData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	paieLoc  = 0 ;
	paieEuro = 0 ;
  espLoc 	 = 0 ;
  espEuro  = 0 ;
  chqLoc 	 = 0 ;
  chqEuro  = 0 ;
  virLoc 	 = 0 ;
  virEuro  = 0 ;
  cbLoc 	 = 0 ;
  cbEuro 	 = 0 ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSEncaissData::NSEncaissData(NSEncaissData& rv)
{
	paieLoc  = rv.paieLoc ;
	paieEuro = rv.paieEuro ;
  espLoc 	 = rv.espLoc ;
  espEuro  = rv.espEuro ;
  chqLoc 	 = rv.chqLoc ;
  chqEuro  = rv.chqEuro ;
  virLoc 	 = rv.virLoc ;
  virEuro  = rv.virEuro ;
  cbLoc 	 = rv.cbLoc ;
  cbEuro 	 = rv.cbEuro ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSEncaissData::~NSEncaissData()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSEncaissData&
NSEncaissData::operator=(NSEncaissData src)
{
	if (this == &src)
		return *this ;

	paieLoc  = src.paieLoc ;
  paieEuro = src.paieEuro ;
  espLoc 	 = src.espLoc ;
  espEuro  = src.espEuro ;
  chqLoc 	 = src.chqLoc ;
  chqEuro  = src.chqEuro ;
  virLoc 	 = src.virLoc ;
  virEuro  = src.virEuro ;
  cbLoc 	 = src.cbLoc ;
  cbEuro 	 = src.cbEuro ;

	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSEncaissData::operator == (NSEncaissData& o)
{
	if ((paieLoc	== o.paieLoc) 	&&
   	 (paieEuro  == o.paieEuro)	&&
       (espLoc		== o.espLoc)	&&
       (espEuro	== o.espEuro)	&&
       (chqLoc		== o.chqLoc)	&&
       (chqEuro	== o.chqEuro)	&&
       (virLoc		== o.virLoc)	&&
       (virEuro	== o.virEuro)	&&
       (cbLoc		== o.cbLoc)		&&
       (cbEuro		== o.cbEuro))
		return 1;
	else
		return 0;
}

//***************************************************************************// 					Impl�mentation des m�thodes NSEncaissArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSEncaissArray::NSEncaissArray(NSEncaissArray& rv) : NSFicheEncaissArray()
{
	if (!(rv.empty()))
		for (NSEncaissIter i = rv.begin(); i != rv.end(); i++)   		push_back(new NSEncaissData(*(*i))) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
void
NSEncaissArray::vider()
{
	if (!(empty()))
		for (NSEncaissIter i = begin(); i != end(); )   	{
   		delete *i ;
      erase(i) ;
   	}
}

NSEncaissArray::~NSEncaissArray()
{
	vider() ;
}

//***************************************************************************// 					Impl�mentation des m�thodes NSMultiCriteres
//***************************************************************************

NSMultiCriteres::NSMultiCriteres()
{
	bActesPerso			= false ;
	sDate1				  = "" ;
	sDate2				  = "" ;
	sCodeExamen 		= "" ;
	sSynExamen			= "" ;
	sCodePrescript 	= "" ;
	sTitrePrescript	= "" ;
	iImpayes				= 0 ;
	iContexte			  = 0 ;
	sCodeOrga			  = "" ;
	sLibCourtOrga 	= "" ;
	sLibLongOrga		= "" ;

  bInterruptedProcess = false ;
}

NSMultiCriteres::NSMultiCriteres(NSMultiCriteres& rv){
	bActesPerso			= rv.bActesPerso ;
	sDate1				  = rv.sDate1 ;
  sDate2				  = rv.sDate2 ;
  sCodeExamen 		= rv.sCodeExamen ;
  sSynExamen			= rv.sSynExamen ;
  sCodePrescript 	= rv.sCodePrescript ;
  sTitrePrescript	= rv.sTitrePrescript ;
  iImpayes				= rv.iImpayes ;
  iContexte			  = rv.iContexte ;
  sCodeOrga			  = rv.sCodeOrga ;
  sLibCourtOrga 	= rv.sLibCourtOrga ;
  sLibLongOrga		= rv.sLibLongOrga ;

  bInterruptedProcess = rv.bInterruptedProcess ;
}

NSMultiCriteres&NSMultiCriteres::operator=(NSMultiCriteres src)
{
	if (this == &src)
		return *this ;

	bActesPerso			= src.bActesPerso ;
	sDate1				  = src.sDate1 ;
  sDate2				  = src.sDate2 ;
  sCodeExamen 		= src.sCodeExamen ;
  sSynExamen			= src.sSynExamen ;
  sCodePrescript 	= src.sCodePrescript ;
  sTitrePrescript = src.sTitrePrescript ;
  iImpayes				= src.iImpayes ;
  iContexte			  = src.iContexte ;
  sCodeOrga			  = src.sCodeOrga ;
  sLibCourtOrga		= src.sLibCourtOrga ;
  sLibLongOrga		= src.sLibLongOrga ;

  bInterruptedProcess = src.bInterruptedProcess ;

	return *this ;
}

NSMultiCriteres::~NSMultiCriteres(){
}

string
NSMultiCriteres::getSummaryString(NSContexte* pCtx)
{
	string sLang = "";
  if ((pCtx) && (pCtx->getUtilisateur()))
  	sLang = pCtx->getUtilisateur()->donneLang() ;

	string sReturnString = string("") ;
  if (bActesPerso)
		sReturnString += "vos actes" ;
	else
  	sReturnString += "actes" ;

	if ((string("") != sCodeExamen) && (string("") != sSynExamen))
	{
  	string sCodeComplet = sCodeExamen + sSynExamen ;
    string sLibExam ;
    pCtx->getDico()->donneLibelle(sLang, &sCodeComplet, &sLibExam) ;

  	if (string("") != sReturnString)
    	sReturnString += string(" ") ;
  	sReturnString += string("(") + sLibExam + string(")") ;
	}

  if (iContexte != 0)
	{
  	if (string("") != sReturnString)
    	sReturnString += string(" ") ;
    if      (1 == iContexte)
    	sReturnString += string("de contexte non pr�cis�") ;
    else if (2 == iContexte)
    	sReturnString += string("externes") ;
    else if (4 == iContexte)
    	sReturnString += string("hospitalis�s") ;
    else if (8 == iContexte)
    	sReturnString += string("ambulatoires") ;
	}

  if (iImpayes != 0)
	{
  	if (string("") != sReturnString)
    	sReturnString += string(" ") ;
    if      (1 == iImpayes)
    	sReturnString += string("impay�s") ;
    else if (2 == iImpayes)
    	sReturnString += string("pay�s") ;
	}

  if (string("") != sCodeOrga)
	{
  	if (string("") != sReturnString)
    	sReturnString += string(" ") ;
  	sReturnString += string("d�s par ") + sLibCourtOrga ;
	}

  char date[9] ;
  char message[11] ;

  if (string("") != sDate1)
  {
  	strcpy(date, sDate1.c_str()) ;
		donne_date(date, message, sLang) ;
    if (string("") != sReturnString)
    	sReturnString += string(" ") ;
    sReturnString += string("du ") + string(message) ;
  }
  if ((string("") != sDate2) && (sDate2 != sDate1))
  {
  	strcpy(date, sDate2.c_str()) ;
		donne_date(date, message, sLang) ;
    if (string("") != sReturnString)
    	sReturnString += string(" ") ;
    sReturnString += string("au ") + string(message) ;
  }

  if (string("") != sTitrePrescript)
	{
  	if (string("") != sReturnString)
    	sReturnString += string(" ") ;
  	sReturnString += string("prescrits par ") + sTitrePrescript ;
	}

  if (true == bInterruptedProcess)
    sReturnString += string(" (r�sultats partiels, processus interrompu en cours de recherche)") ;

  sReturnString[0] = pseumaj(sReturnString[0]) ;

  return sReturnString ;
}

// fin de nsagavar.cpp