#include <checks.h>
#include <owl\control.h>
#include <owl\treewind.h>
#include <owl\gdiobjec.h>

#include "nsbb\nsdico.h"
#include "nsbb\nstrewi.h"
#include "nsbb\nstrnode.h"
#include "nsbb\nstrnode.rh"

#include "nsbb\nsbb_dlg.h"
#include "nsbb\nsdlg.h"

#include "nsbb\nsbb.h"
#include "nssavoir\nspathor.h"

//
// General Controls diagnostic group
//
// DIAG_DEFINE_GROUP_INIT(OWL_INI, OwlControl, 1, 0);

#define CM_ANNULER    501   // Don't use CM_EDITUNDO
#define CM_EMPHASIZED 502
#define CM_STANDARD   503

DEFINE_RESPONSE_TABLE1(NSEditDico, NSEditDicoGlobal)
	EV_WM_CHAR,
  EV_WM_KEYDOWN,
  EV_WM_LBUTTONDOWN,
  EV_WM_LBUTTONUP,
  EV_WM_RBUTTONDOWN,
  EV_WM_KILLFOCUS,
  EV_WM_KEYUP,
  EV_WM_GETDLGCODE,
  EV_WM_PAINT,
  EV_WM_MOUSEMOVE,
  EV_WM_SETFOCUS,
  EV_COMMAND(CM_EDITPASTE,  CmEditPaste),
  EV_COMMAND(CM_ANNULER,    undoOneStep),
  EV_COMMAND(CM_EDITREDO,   redoOneStep),
  EV_COMMAND(CM_EMPHASIZED, setBold),
  EV_COMMAND(CM_STANDARD,   setRegular),
END_RESPONSE_TABLE;

NSEditDico::NSEditDico(NSContexte* pCtx, TWindow* parent, int resourceId, NSDico* pDictio,
                       string sTypeLexique, const char far* text,
                       int x, int y, int w, int h,
                       uint textLimit, bool multiline, TModule* module,
                       bool bLexiqueGeneral)
           :NSEditDicoGlobal(pCtx, parent, resourceId, pDictio, text, x, y, w, h,
                       textLimit, multiline, sTypeLexique, module)
{
	bPaint        = false ;
	bTexteLibre   = false ;
	sAmmorceLibre = "" ;
	bGeneral      = bLexiqueGeneral ;

  Attr.Style |= ES_NOHIDESEL ;

  _undoCursor   = 0 ;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSEditDico::SetupWindow()
{
	NSEditDicoGlobal::SetupWindow() ;

  // EM_FMTLINES Message
	// Sets a flag that determines whether a multiline edit control includes
  // soft line-break characters. A soft line break consists of two carriage
  // returns and a line feed and is inserted at the end of a line that is
  // broken because of wordwrapping.
	FormatLines(true) ;

	//
	//cacher les scrollbar
	//
	ShowScrollBar(SB_BOTH, FALSE) ;
}

//----------------------------------------------------------------------------
// positionner le lexique selon les coordonn�es de l'�cran et celles de la bo�te
// m�re
//----------------------------------------------------------------------------
void
NSEditDico::SetPositionLexique()
{
	if ((NULL == pDico) || (NULL == pDico->pDicoDialog))
		return ;

	//
	//coordonn�es de l'�cran en pixels
	//
  TIC* pTic = new TIC("DISPLAY",0,0) ;
  int XScreen = pTic->GetDeviceCaps(HORZRES) ;
  int YScreen = pTic->GetDeviceCaps(VERTRES) ;
  delete pTic ;

  // rect.left= rectEdit->left (Edit) par rapport � la bo�te de dialogue
  // rectPere.left (la bo�te de dialogue ) par rapport � l'�cran
  // pTree->Attr.X

	//position du lexique
	NS_CLASSLIB::TRect rectEdition = GetWindowRect() ; //rectangle d'�dition (this)

  //
  // Attr : this
  //
  NS_CLASSLIB::TRect rectBoiteMere = Parent->GetWindowRect() ; //bo�te m�re
  //
  // Attr : this
  //
  //int x = Attr.X + Attr.W + rectBoiteMere.left  + 5 ;
  int x = rectEdition.left + rectEdition.top + 50 ;
  int y = rectEdition.top ;
  int lTW_X = 10 ;
  // int lTW_Y = 10;

  NS_CLASSLIB::TRect rectLex = pDico->pDicoDialog->GetWindowRect() ;  //lexique
  if ((x + rectLex.Width()) >= XScreen)//si elle ne tient pas � droite
  {
  	// si elle tient � gauche
    if (rectEdition.left - rectLex.Width() - lTW_X >= 0)
    	x = rectEdition.left - rectLex.Width() - lTW_X ;
    // si elle ne tient pas � gauche
    else
    {
    	// on la cale � droite
      if (XScreen - rectEdition.left - rectEdition.Width() > rectEdition.left)
      	x = XScreen - rectLex.Width() ;
      else
      	x = 0 ;
    }
  }
	if ((y + rectLex.Height()) >= YScreen)
		y = YScreen - rectLex.bottom + rectLex.top ;

	/*
  SWP_DRAWFRAME	Draws a frame around the window.
	SWP_FRAMECHANGED	Sends a message to the window to recalculate the window's size.
   						If this flag is not set, a recalculate size message is sent only at
            			the time the window's size is being changed.
  SWP_HIDEWINDOW	Hides the window.
	SWP_NOACTIVATE	Does not activate the window.
   					If this flag is not set, the window is activated and moved
         			to the top of the stack of windows.
	SWP_NOCOPYBITS	Discards the entire content area of the client area of the window.
   					If this flag is not set, the valid contents are saved and copied into
                  the window after the window is resized or positioned.
	SWP_NOMOVE		Remembers the window's current position.
	SWP_NOSIZE		Remembers the window's current size. +
	SWP_NOREDRAW	Does not redraw any changes to the window.  + ok
   					If this flag is set, no repainting of any window area
                  (including client, nonclient, and any window part uncovered as a result of a move) occurs. When this flag is set, the application must explicitly indicate if any area of the window is invalid and needs to be redrawn.
	SWP_NOZORDER	Remembers the current Z-order (window stacking order).
	SWP_SHOWWINDOW	Displays the window. + pas ok
	*/
	pDico->pDicoDialog->SetWindowPos(0, x, y, rectLex.Width(), rectLex.Height(), SWP_NOSIZE) ;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSEditDico::EveilleToi(string* pTexteInitial, RECT* pRectEdit)
{
	if ((NULL == pRectEdit) || (NULL == pTexteInitial))
		return ;

	strip(*pTexteInitial) ;

	RECT rectEditeur = *pRectEdit ;
	SetPositionLexique() ;
	//
	// On fixe la position de l'Edit
	//
	if ((pRectEdit->bottom == 0) || (pRectEdit->right == 0))
	{
		// on repasse en mode texte libre
    bTexteLibre = true ;
    ShowScrollBar(SB_VERT, TRUE) ;
    sAmmorceLibre = *pTexteInitial ;
    AjusterRectangleEdition(*pTexteInitial) ;
	}
	else
		MoveWindow(rectEditeur, /*bool repaint*/ true) ;
	//
	// On d�coupe le texte en paragraphes et on le place dans l'Edit
	//
	Paragraphe(pTexteInitial) ;
	SetText(pTexteInitial->c_str()) ;
	//
	// On demande � l'Edit de se montrer
	//
	Show(SW_SHOWNORMAL) ;

	// On regarde le nombre de lignes :
	// pour 0 (texte vide) et > 1 (texte libre) on ne fait rien
	// pour 1 on se place � la fin du texte et on appelle UpdateDico
	// (lance le lexique selon la valeur de l'ammorce)
	if (GetNumLines() == 1)
	{
    int nbCars = strlen(pTexteInitial->c_str()) ;
    SetSelection(nbCars, nbCars) ;
    UpdateDico() ;

    // si le texte est un �l�ment lexique
    // on le s�lectionne dans pDicoDialog
    // (on doit r�cup�rer le code lexique du node en cours)

    bool bFocusState = bGardeFocus ;
    bGardeFocus = true ;

    NSTreeWindow* pTree = GetpTreeAEditer() ;
    TTreeNode noeud = pTree->GetSelection() ;
    NSTreeNode* pTreeNode = pTree->GetNSTreeNode(&noeud) ;
    string sCodeLex = pTreeNode->getEtiquette() ;
    if ((string("�?????") != sCodeLex) && (NULL != pDico->pDicoDialog))
    	pDico->pDicoDialog->SelectCodeLexique(sCodeLex) ;

    bGardeFocus = bFocusState ;
	}
}

//-----------------------------------------------------------------------
// Ajuster le rectangle d'�dition (selon la taille de sLabel)
//
// Cette fonction ne travaille que sur right et bottom
//-----------------------------------------------------------------------
void
NSEditDico::AjusterRectangleEdition(string sLabel)
{
	//
  // Prise d'un TIC li� � l'�cran et des caract�ristiques de la police
  //
  TIC* pIc = new TIC("DISPLAY", 0, 0) ;
  TEXTMETRIC metric ;
  pIc->GetTextMetrics(metric) ;
  // LONG largeurChar = metric.tmMaxCharWidth;
  // LONG hauteurChar = metric.tmHeight;
  int  cxScroll ;
  //
  // ?????
  //
  // int LargeurMax = (int)largeurChar*10; //10
  // int longueur  = 10;//GetTextLen();
  // int nbBloc = longueur;
  // int LargeurCalculee = nbBloc * (int)largeurChar;
  NS_CLASSLIB::TRect rectEdition   = GetWindowRect() ;
  rect = rectEdition ;
  NS_CLASSLIB::TRect rectBoiteMere = Parent->GetWindowRect() ; //bo�te m�re
  //TRect rectControle  = pTreeAEditer->GetWindowRect(); //TreeView

  rectEdition.right  = rectBoiteMere.right  - 50 ;
  rectEdition.bottom = rectBoiteMere.bottom - 80 ;
  if ((rectEdition.bottom - rectEdition.top) <= 50)
		rectEdition.bottom = rectEdition.top + 300 ;

	//rectEdition.bottom = rectEdition.top  + 20*(int)largeurChar;

	// on doit retrancher au rectEditDico la largeur de la scrollbar
	// (si la scrollbar est d�finie pour le NSEditDico)
	if (bTexteLibre)
		cxScroll = ::GetSystemMetrics(SM_CXVSCROLL) ;
	else
		cxScroll = 0 ;

	NS_CLASSLIB::TPoint point(rectEdition.left, rectEdition.top) ;
	NS_CLASSLIB::TPoint point2(rectEdition.right - cxScroll, rectEdition.bottom) ;
	Parent->ScreenToClient(point) ;
	Parent->ScreenToClient(point2) ;

  // on reporte la modif du rectangle dans rectEditDico
  // pour g�rer les changements du curseur par NSTreeWindow::EvMouseMove
  // Note : on doit passer le rectangle en coordonn�es Client
  _pTreeAEditer->rectEditDico = NS_CLASSLIB::TRect(point, point2) ;

  //
  // Positionnement du contr�le Edit (la taille inclus la scrollbar)
  //
  SetWindowPos(0, point.X(), point.Y(), rectEdition.right - rectEdition.left, rectEdition.bottom
                - rectEdition.top ,SWP_NOZORDER) ;
  delete pIc ;
}

//-----------------------------------------------------------------------
// ajuster le rectangle d'�dition chaque fois qu'on tape une lettre
//
// Cette fonction ne travaille que sur right et bottom
//-----------------------------------------------------------------------
void
NSEditDico::AjusterRectangleEdition()
{
  TIC* pIc = new TIC("DISPLAY", 0, 0) ;
  TEXTMETRIC metric ;
  pIc->GetTextMetrics(metric) ;
  LONG largeurChar = metric.tmMaxCharWidth ;
  // LONG hauteurChar = metric.tmHeight;
  int LargeurMax = (int)largeurChar*10 ; //10
  delete pIc ;
  int longueur  = 10 ; //GetTextLen();
  int nbBloc    = (longueur / 5 ) + 1 ; //nombre de blocs
  int LargeurCalculee = 5 * nbBloc * (int)largeurChar ;
  NS_CLASSLIB::TRect rectEdition   = GetWindowRect() ;
  NS_CLASSLIB::TRect rectBoiteMere = Parent->GetWindowRect() ; //bo�te m�re
  rect = rectEdition ;
  if (LargeurCalculee > LargeurMax)
  	rectEdition.right  = rectBoiteMere.right - 50 ;
  else
  	if ((rectEdition.left + LargeurCalculee) < (rectBoiteMere.right - 10))
    	rectEdition.right  = rectEdition.left + LargeurCalculee ;

  NS_CLASSLIB::TPoint point(rectEdition.left, rectEdition.top) ;
  Parent->ScreenToClient(point) ;
  //
  // Positionnement du contr�le Edit
  //
  SetWindowPos(0, point.X(), point.Y(), rectEdition.right - rectEdition.left, rectEdition.bottom
                - rectEdition.top ,SWP_NOZORDER) ;
}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
void
NSEditDico::EvChar(uint key, uint repeatCount, uint flags)
{
	pDico->pDicoDialog->setEdit(this, sTypeLexique) ;
	Invalidate() ;

  short iCtrlPressedStatus = GetAsyncKeyState(VK_CONTROL) ;
  bool  bCtrlPressed = (iCtrlPressedStatus & 0x8000) != 0 ;

	if ((VK_RETURN == key) || (VK_TAB == key))
  {
    if (false == bCtrlPressed)
			//pour enlever le Beep ne pas appliquer TEdit::EvChar(key, repeatCount, flags)
    	return ;
  }

	TEdit::EvChar(key, repeatCount, flags) ;
	UpdateDico() ;

  // Ctrl-Z -> key == 26
  if (26 != key)
    addToUndoBuffer() ;
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void
NSEditDico::EvKeyDown(uint key, uint repeatCount, uint flags)
{
	Invalidate() ;
	pDico->pDicoDialog->setEdit(this, sTypeLexique) ;
	TEdit::EvKeyDown(key, repeatCount, flags) ;
	Parent->SendNotification(Attr.Id, 200, HWindow) ;
	NSTreeWindow* pTree = GetpTreeAEditer() ;

	// fl�che basse
	//
	if (VK_DOWN == key)
	{
  	// Si on est en mode TEXTE LIBRE, passer � la ligne suivante du TL
    //
    if (bTexteLibre)
    {
    }
    // Si on n'est pas en mode TEXTE LIBRE, soit on passe au noeud suivant
    // soit on descend d'un �l�ment dans le pDicoDialog
    //
    else
    {
    	if (pTree->ModifierTexteLibre)
      {
      	if (pTree->pNSTreeNodeEnCours->sTexteGlobal == "")
        	pTree->ModifierTexteLibre = false ;
        return ;
      }
      //si ammorce vide alors passer au NStrreNode suivant
      if (pDico->pDicoDialog->sAmmorce == "")
      {
      	pTree->NStreeNodeSuivant() ;
        pTree->SortieEditionDico() ;
      }
      //sinon r�cup�rer un �l�ment dans le lexique
      else
      	pDico->pDicoDialog->ElementSuivant() ;
    }
	}
	// fl�che haute
  //
	else if (VK_UP == key)
	{
		// Si on est en mode TEXTE LIBRE, passer � la ligne pr�c. du TL
    //
    if (bTexteLibre)
    {
    }
    // Si on n'est pas en mode TEXTE LIBRE, soit on passe au noeud pr�c�dent
    // soit on monte d'un �l�ment dans le pDicoDialog
    //
    else
    {
    	//si ammorce vide alors passer au NStrreNode suivant
      if (pTree->ModifierTexteLibre)
      {
      	if (pTree->pNSTreeNodeEnCours->sTexteGlobal == "")
        	pTree->ModifierTexteLibre = false ;
        return ;
      }
      if (pDico->pDicoDialog->sAmmorce == "")
      {
      	pTree->NStreeNodePrcedent() ;
        pTree->SortieEditionDico() ;
      }
      //sinon r�cup�rer un �l�ment dans le lexique
      else
      	pDico->pDicoDialog->ElementPrecedent() ;
    }
  }
  else if ((VK_INSERT == key) || (VK_RETURN == key))
	{
  	short iCtrlPressedStatus = GetAsyncKeyState(VK_CONTROL) ;
    bool  bCtrlPressed = (iCtrlPressedStatus & 0x8000) != 0 ;
    if ((VK_RETURN == key) && (true == bCtrlPressed))
    	TEdit::EvKeyDown(key, repeatCount, flags) ;
    else
			pDico->pDicoDialog->InsererElementLexique() ;
    return ;
	}
	else if (VK_CONTROL == key)
	{
		sTypeLexique = "_" ;
    pDico->pDicoDialog->setEdit(this, sTypeLexique) ;
	}
  // Ctrl-A select all
  else if (GetKeyState(VK_CONTROL) < 0)
  {
    if (GetKeyState(VK_SHIFT) < 0)
    {
      if (('Z' == key) || ('z' == key))
        redoOneStep() ;
    }
    else
    {
      if      (('A' == key) || ('a' == key))
        CmEditSelectAll() ;
      else if (('Z' == key) || ('z' == key))
        undoOneStep() ;
      else if (('G' == key) || ('g' == key))
        setBold() ;
      else if (('N' == key) || ('n' == key))
        setRegular() ;
    }
  }
  else if (VK_DELETE == key)
    addToUndoBuffer() ;

  return ;
}

//---------------------------------------------------------------------// taper du texte libre
//---------------------------------------------------------------------
void
NSEditDico::TextLibre()
{
	int oldBuffLen = GetTextLen() ;
	char far* oldBuff = new char[oldBuffLen+1] ;
	GetText(oldBuff, oldBuffLen+1) ;
	string sContenu = string(oldBuff) ;
	delete[] oldBuff ;

  if (string("") == sContenu)
		return ;

	strip(sContenu) ;

  // It is allowed to have just a "spacer" in order to separate two chapters
  //
	if (string("") == sContenu)
		sContenu = string(" ") ;

	//
	// enlever \r\n du texte
	//
  if (NULL == _pTreeAEditer)
  {
		EnleverRetourChariot(&sContenu) ;
		strip(sContenu, stripRight) ;
	}
  else
  	RemoveSoftLineBreaks(&sContenu) ;

	// texte libre
	if (NULL != _pTreeAEditer)
    _pTreeAEditer->DicoGetTexteLibre(&sContenu) ;
}

//--------------------------------------------------------------
//enlever \n\r de pContenu et les remplacer par " "
//--------------------------------------------------------------
void
NSEditDico::EnleverRetourChariot(string* pContenu, uint* pStartSel, uint* pEndSel)
{
	//
  // enlever \r\n du texte
	//
  size_t pos = pContenu->find("\r\n") ;
  while (NPOS != pos)
	{
		if (pStartSel)
    	if ((*pStartSel) > pos)
      	(*pStartSel)-- ;

    if (pEndSel)
    	if ((*pEndSel) > pos)
      	(*pEndSel)-- ;

    pContenu->replace(pos, 2, " ") ;
    pos = pContenu->find("\r\n") ;
	}

	pos = pContenu->find("\n") ;
	while (NPOS != pos)
	{
  	pContenu->replace(pos, 1, " ") ;
    pos = pContenu->find("\n") ;
	}

	pos = pContenu->find("\r") ;
	while (NPOS != pos)
	{
		pContenu->replace(pos, 1, " ") ;
    pos = pContenu->find("\r") ;
	}
}

//--------------------------------------------------------------
//enlever les \r\r\n de pContenu et les remplacer par " "
//--------------------------------------------------------------
void
NSEditDico::RemoveSoftLineBreaks(string* pContenu, uint* pStartSel, uint* pEndSel)
{
	//
  // enlever \r\n du texte
	//
  size_t pos = pContenu->find("\r\r\n") ;
  while (NPOS != pos)
	{
		if (pStartSel)
    	if ((*pStartSel) > pos)
      	(*pStartSel) -= 2 ;

    if (pEndSel)
    	if ((*pEndSel) > pos)
      	(*pEndSel) -= 2 ;

    pContenu->replace(pos, 3, " ") ;
    pos = pContenu->find("\r\r\n") ;
	}
}

//----------------------------------------------------------------
//mettre pContenu sous forme de paragraphe
//----------------------------------------------------------------
void
NSEditDico::Paragraphe(string* pContenu)
{
	if ((NULL == pContenu) || (*pContenu == ""))
		return ;

	// uint curLine;
  int  cxScroll ;
  string sChaineSource = *pContenu ;
  TIC* pIc = new TIC("DISPLAY", 0, 0) ;
  uint   startSel, endSel ;
  GetSelection(startSel, endSel) ;

  // Pour recalculer les nouveaux sauts de ligne
  // on reprend la chaine � plat (les CRLF sont remplac�s par des espaces)
  // EnleverRetourChariot(pContenu, &startSel, &endSel) ;
  RemoveSoftLineBreaks(pContenu, &startSel, &endSel) ;
  string sChaine = *pContenu ;

  //
  // Prise de la largeur �ditable : largeur de l'Edit moins scrollbar
  //
  //TRect rectEdition   = GetWindowRect();
  NS_CLASSLIB::TRect rectEdition = GetClientRect() ;

  // largeur de la scrollbar
  if (bTexteLibre)
  	cxScroll = ::GetSystemMetrics(SM_CXVSCROLL) ;
  else
  	cxScroll = 0 ;

  int     largeurEdit = rectEdition.right - rectEdition.left - cxScroll ;
  int     longueurChaine ;
  int     longueur ;
  int     enCoursAvant ;
  size_t  debLigne = 0 ;
  size_t  enCours = 0 ;
  string sTexte ;
  //
  bool Tourner = true ;
  while (Tourner)
  {
  	longueurChaine = 0 ;
    while ((enCours < strlen(sChaine.c_str())) &&
             (longueurChaine < largeurEdit)) //on risque de d�passer le contr�le �dit
    {
    	if ((enCours < strlen(sChaine.c_str()) - 1) &&
          ('\r' == sChaine[enCours]) && ('\n' == sChaine[enCours+1]))
      {
      	enCours += 2 ;
      	break ;
      }

    	sTexte = string(sChaine, debLigne, enCours - debLigne + 1) ;
      NS_CLASSLIB::TSize size = pIc->GetTextExtent(sTexte.c_str(), strlen(sTexte.c_str())) ;
      longueurChaine = size.X() ;
      enCours++ ;
    }

    longueur = strlen(sChaine.c_str()) ;
    // Premier blanc
    if (longueurChaine >= largeurEdit)
    {
    	// on conserve la position du dernier caract�re
      // (celui qui d�passe la largeur de la zone �ditable)
      enCoursAvant = enCours - 1 ;

      // on recule jusqu'au premier blanc ou jusqu'au d�but de la ligne
      while ((enCours > debLigne) && (sTexte[enCours - debLigne] != ' '))
      	enCours-- ;

      if (enCours == debLigne) // cas de la ligne sans espace
      {
        enCours = enCoursAvant ;
        sChaine = string(sChaine, 0, enCours) + string("\r\r\n") + string(sChaine, enCours, longueur - enCours + 1) ;
        if (size_t(startSel) >= enCours)
        	startSel += 3 ;
        if (size_t(endSel) >= enCours)
        	endSel += 3 ;
      }
      else // !! dans ce cas on saute l'espace (on reprend � enCours + 1)
      {
      	sChaine = string(sChaine, 0, enCours) + string("\r\r\n") + string(sChaine, enCours + 1, longueur - enCours) ;
        if (startSel >= (enCours + 1))
        	startSel += 2 ;
        if (endSel >= (enCours + 1))
        	endSel += 2 ;
      }

      debLigne = enCours + 3 ;
      enCours = debLigne ;
    }
    else if (enCours >= strlen(sChaine.c_str()))
    	Tourner = false ;
	}
  delete pIc ;

	// on affiche le nouveau texte
	if (!(sChaine == sChaineSource))
		SetText(sChaine.c_str()) ;

	*pContenu = sChaine ;

	SetSelection(startSel, endSel) ;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSEditDico::UpdateDico()
{
  string sContenu;
  //
  // Texte total
  //
  int oldBuffLen = GetTextLen();
  char far* oldBuff = new char[oldBuffLen+1];
  GetText(oldBuff, oldBuffLen+1);
  sContenu = string(oldBuff);
  delete[] oldBuff;
  bool bCacherLexique = false;
  //
  // Mettre ce texte sous forme de paragraphe
  //
  Paragraphe(&sContenu);

  // Si on est en texte libre, on teste si le texte commence encore par
  // la chaine qui a caus� la fermeture du lexique
  //
  if (bTexteLibre)
  {
  	size_t iTailleAmmorce = strlen(sAmmorceLibre.c_str()) ;
    if ((strlen(sContenu.c_str()) >= iTailleAmmorce) &&
            (string(sContenu, 0, iTailleAmmorce) == sAmmorceLibre))
    	return ;
	}

	int OouF ;
	if (sContenu == "")
	{
  	OouF = 1 ;
    bCacherLexique = true ;
	}
	else
		OouF = pDico->pDicoDialog->DonneAmmorce(&sContenu) ;
  //
  // Code lexique
  //
  if (OouF == 1)
  {
  	if (bTexteLibre) //passage d'un edit texte libre � un edit code lexique
    	switchFromFreeToLexique(&sContenu) ;

    bTexteLibre = false ;
    if (bCacherLexique)
    {
    	bGardeFocus = false ;
      pDico->pDicoDialog->cacherDialogue() ;
    }
    else
    {
    	bGardeFocus = true ;// car pDico->pDicoDialog->ShowWindow(SW_SHOW) fait perdre le focus � this
			pDico->pDicoDialog->montrerDialogue() ;
    }
    SetFocus() ;
  }
  //
  // Texte libre
  //
  // On n'entre dans cette routine qu'au changement de mode (lexique -> TL)
  //
  else if ((OouF == 2) && (!bTexteLibre))
  {
    bTexteLibre = true ;
    //
    // Montrer les scrollbar
    //
    ShowScrollBar(SB_VERT, TRUE) ;
    //
    // Cacher pDicoDialog
    //
		pDico->pDicoDialog->cacherDialogue() ;
    //
    // On se fixe une taille statique maximum par d�faut
    //
    NS_CLASSLIB::TRect rectEdition = GetWindowRect() ;
    //
    // Ajuster le contr�le Edit � la dimension des textes libres
    //
    AjusterRectangleEdition("") ;
    //
    // Recalculer les paragraphes en fonction de la nouvelle taille
    //
    Paragraphe(&sContenu);
    //
    // Retenir l'ammorce qui a fait basculer d'un mode � l'autre
    //
    sAmmorceLibre = sContenu ;
	}
}

//-------------------------------------------------------------------------
// 					R�ponse � un message ok ou doubleClick
//-------------------------------------------------------------------------
void
NSEditDico::ElementSelectionne()
{
	_pTreeAEditer->DicoGetCodeLexique() ;
}

//fonction permettant � la touche ENTREE d'avoir le m�me effet que TAB
void
NSEditDico::EvKeyUp(uint key, uint repeatcount, uint flags)
{
	// THandle NextControl = 0;
	switch (key)
	{
  	//return
    case VK_RETURN	:
    {
    	short iCtrlPressedStatus = GetAsyncKeyState(VK_CONTROL) ;
      bool  bCtrlPressed = (iCtrlPressedStatus & 0x8000) != 0 ;
  		if ((false == bTexteLibre) || (false == bCtrlPressed))
    		TextLibre() ;
      else
      	TEdit::EvKeyUp(key, repeatcount, flags) ;
      break ;
    }
    //tabulation
    case VK_TAB	:
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // suivant pControle sinon le premier
      //
      if (NULL != _pTreeAEditer)
      {
        NSControle* pTreeControl = _pTreeAEditer->pControle ;
        if (pTreeControl)
        {
          if (pTreeControl->getNSDialog())
            pTreeControl->getNSDialog()->ActiveControlSuivant(pTreeControl) ;
          else if (pTreeControl->getMUEView())
          {
            if (GetKeyState(VK_SHIFT) < 0)
              pTreeControl->getMUEView()->SetFocusToPreviousControl((TControl*)_pTreeAEditer) ;
            else
              pTreeControl->getMUEView()->SetFocusToNextControl((TControl*)_pTreeAEditer) ;
          }
        }
      }
      break ;
    default	:
    	TEdit::EvKeyUp(key, repeatcount, flags) ;
	}
}

//fonction permettant � la touche ENTREE d'avoir le m�me effet que TAB
uint
NSEditDico::EvGetDlgCode(MSG far* /* msg */)
{
	uint retVal = (uint)DefaultProcessing() ;
  // retVal |= DLGC_WANTALLKEYS ;
	return retVal ;
}

//--------------------------------------------------------------------
//diff�rents traitements sur les textes
//--------------------------------------------------------------------
void
NSEditDico::CmEditCut()
{
	TEdit::CmEditCut() ;
  UpdateDico() ;

  addToUndoBuffer() ;
}

void
NSEditDico::CmEditCopy()
{
	TEdit::CmEditCopy() ;
}

void
NSEditDico::CmEditPaste()
{
	TEdit::CmEditPaste() ;
  UpdateDico() ;

  addToUndoBuffer() ;
}

void
NSEditDico::CmEditDelete()
{
	TEdit::CmEditDelete() ;
  UpdateDico() ;

  addToUndoBuffer() ;
}

void
NSEditDico::CmEditClear()
{
	TEdit::CmEditClear() ;

  addToUndoBuffer() ;
}

void
NSEditDico::CmEditUndo()
{
	undoOneStep() ;
}

void
NSEditDico::CmEditSelectAll()
{
  int iTextSize = GetTextLen() ;
  if (iTextSize < 1)
    return ;

  SetSelection(0, iTextSize) ;

  addToUndoBuffer() ;
}

//-----------------------------------------------------------
//curseur de la souris
//-----------------------------------------------------------
void
NSEditDico::EvLButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TEdit::EvLButtonDown(modKeys, point) ;
}

//-----------------------------------------------------------
//curseur de la souris
//-----------------------------------------------------------
void
NSEditDico::EvLButtonUp(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TEdit::EvLButtonUp(modKeys, point) ;
}

void
NSEditDico::EvRButtonDown(uint /* modKeys */, NS_CLASSLIB::TPoint& point)
{
try
{
  NS_CLASSLIB::TPoint lp = point ;

  string sCut    = string("Cut") ;
  string sCopy   = string("Copy") ;
  string sPaste  = string("Paste") ;
  string sDelete = string("Delete") ;
  string sUndo   = string("Undo") ;
  string sRedo   = string("Redo") ;
  string sEmphas = string("Emphasized") ;
  string sStanda = string("Standard") ;
  if (NULL != pDico)
  {
    NSSuper* pSuper = pContexte->getSuperviseur() ;
    sCut    = pSuper->getText("treeViewManagement", "cut") ;
    sCopy   = pSuper->getText("treeViewManagement", "copy") ;
    sPaste  = pSuper->getText("treeViewManagement", "paste") ;
    sDelete = pSuper->getText("treeViewManagement", "delete") ;
    sUndo   = pSuper->getText("treeViewManagement", "undo") ;
    sRedo   = pSuper->getText("treeViewManagement", "redo") ;
    sEmphas = pSuper->getText("treeViewManagement", "emphasized") ;
    sStanda = pSuper->getText("treeViewManagement", "standard") ;
  }

  uint startSel, endSel ;
  GetSelection(startSel, endSel) ;

  OWL::TPopupMenu *menu = new OWL::TPopupMenu() ;

  menu->AppendMenu(MF_STRING, CM_EDITCUT, sCut.c_str()) ;
  menu->AppendMenu(MF_STRING, CM_EDITCOPY, sCopy.c_str()) ;
  menu->AppendMenu(MF_STRING, CM_EDITPASTE, sPaste.c_str()) ;
  menu->AppendMenu(MF_STRING, CM_EDITDELETE, sDelete.c_str()) ;
  menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
  menu->AppendMenu(MF_STRING, CM_EMPHASIZED, sEmphas.c_str()) ;
  menu->AppendMenu(MF_STRING, CM_STANDARD, sStanda.c_str()) ;
  menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
  menu->AppendMenu(MF_STRING, CM_ANNULER, sUndo.c_str()) ;
  menu->AppendMenu(MF_STRING, CM_EDITREDO, sRedo.c_str()) ;

  ClientToScreen(lp) ;
  menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow) ;
  delete menu ;
}
catch (...)
{
  erreur("Exception NSEditDico::EvRButtonDown.", standardError, 0) ;
}
}

//-------THandle-------------------------------------------------------------
// le champ edit perd le focus
//--------------------------------------------------------------------
void
NSEditDico::EvKillFocus(THandle hWndGetFocus)
{
  char szThis[20] ;
  sprintf(szThis, "%p", HWindow) ;
  string sMsgHeader = string("EvKillFocus for EditDico ") + string(szThis) + string(" : ") ;

  char szFocus[20] ;
  sprintf(szFocus, "%p", (HWND) hWndGetFocus) ;
  string sMsg = sMsgHeader + string("Entering (focus gained by ") + string(szFocus) + string(")") ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  if (bYouMustAcceptToLooseFocus)
  {
    bYouMustAcceptToLooseFocus = false ;

    sMsg = sMsgHeader + string("Accepting the KillFocus (forced).") ;
    pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;
    TEdit::EvKillFocus(hWndGetFocus) ;
    return ;
  }

	if (hWndGetFocus == HWindow)
		return ;

  // If the treewindow is not in "editing mode", it is useless to keep the focus
  //
  if (_pTreeAEditer && (false == _pTreeAEditer->bEditionDico))
  {
    TWindow focusWnd(hWndGetFocus) ;
    string sTitle = string(focusWnd.Title) ;
    if (string("") != sTitle)
    {
      sMsg = sMsgHeader + string("Focused windows title: ") + sTitle ;
      pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;
    }

    sMsg = sMsgHeader + string("Leaving (treewindow is not in edit mode).") ;
    pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

		return ;
  }

	// if (!bGardeFocus)
  //    NSEditDicoGlobal::EvKillFocus(hWndGetFocus);

  //
	//	Quand un contr�le est activ� il re�oit :
	//								WM_SETFOCUS
	//								WM_KILLFOCUS
	//                      WM_PAINT
	//								WM_SETFOCUS
  // il faut ignorer les killFocus tant que ce contr�le n'a pas re�u WM_PAINT
  //
	if (false == bPaint)
  {
    sMsg = sMsgHeader + string("Leaving (not painted yet).") ;
    pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;
		return ;
  }

	// bPaint = false ;

	if (bGardeFocus)
	{
  	SetFocus() ;
    bGardeFocus = false ;
    sMsg = sMsgHeader + string("Keeping focus.") ;
    pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;
	}
	else
	{
  	if (hWndGetFocus != HWindow)
    {
    	if ((pDico->pDicoDialog) &&
                (hWndGetFocus != pDico->pDicoDialog->HWindow) &&
                (!(pDico->pDicoDialog->IsChild(hWndGetFocus))))
      {
        TWindow focusWnd(hWndGetFocus) ;
        string sTitle = string(focusWnd.Title) ;
        if (string("") != sTitle)
        {
          sMsg = sMsgHeader + string("Focused windows title: ") + sTitle ;
          pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;
        }

        char szDico[20] ;
        sprintf(szDico, "%p", pDico->pDicoDialog->HWindow) ;
        sMsg = sMsgHeader + string("Hidding Dico ") + string(szDico) ;
        pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

      	pDico->pDicoDialog->cacherDialogue() ;
        NSEditDicoGlobal::EvKillFocus(hWndGetFocus) ;

        if (NULL != _pTreeAEditer)
        {
          char szTree[20] ;
          sprintf(szTree, "%p", _pTreeAEditer->HWindow) ;
          sMsg = sMsgHeader + string("Sending DicoLostFocus to tree ") + string(szTree) ;
          pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;
          //
          // An asynchronous call must be done there, because this objet
          // will be killed by the tree
          //
          _pTreeAEditer->PostMessage(WM_COMMAND, IDC_DICO_LOST_FOCUS) ;
        }
      }
      else
      {
        sMsg = sMsgHeader + string("Accepting the KillFocus.") ;
        pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;
      	TEdit::EvKillFocus(hWndGetFocus) ;
      }
    }
	}
	//else
	//	pDico->pDicoDialog->cacherDialogue();

  sMsg = sMsgHeader + string("Leaving.") ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;
}

//------------------------------------------------------------------
//redimensionnement du champ �dit
//------------------------------------------------------------------
void
NSEditDico::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& rect)
{
	TWindow::Paint(dc, erase, rect) ;
	bPaint = true ;
}

//------------------------------------------------------------------
//redimensionnement du champ �dit
//------------------------------------------------------------------
void
NSEditDico::EvPaint()
{
	//TWindow::EvPaint();
	DefaultProcessing() ;
	bPaint = true ;
}

//----------------------------------------------------------------------
//----------------------------------------------------------------------
void
NSEditDico::EvSetFocus(HWND hWndLostFocus)
{
	NSEditDicoGlobal::EvSetFocus(hWndLostFocus) ;
	if (bPaint && !bTexteLibre)
	{
  	bGardeFocus = true ; // car pDico->pDicoDialog->ShowWindow(SW_SHOW) fait perdre le focus � this
    pDico->pDicoDialog->montrerDialogue() ;
	}
}

void
NSEditDico::EvMouseMove(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	// SetCursor(NULL, IDC_IBEAM);
  TEdit::EvMouseMove(modKeys, point) ;
}

void
NSEditDico::switchFromFreeToLexique(string* pContent)
{
	if (NULL == pContent)
		return ;

	TIC* pIc = new TIC("DISPLAY", 0, 0) ;
  //
  //redonner les dimensions pour un code lexique : prendre la taille du texte tap�  + ...
  //
  NS_CLASSLIB::TRect rectEdition = GetWindowRect() ;

  NS_CLASSLIB::TSize size = pIc->GetTextExtent(pContent->c_str(), strlen(pContent->c_str())) ;
  delete pIc ;

  int longueurChaine = size.X() + 5 ;
  int hauteur        = size.Y() + 5 ;

  rectEdition.right  = rectEdition.left + 268 ;
  rectEdition.bottom = rectEdition.top  + 16 ;

  if (rectEdition.right < longueurChaine)
    rectEdition.right = rectEdition.left + longueurChaine + 5 ;

  if (rectEdition.bottom < hauteur)
    rectEdition.bottom = rectEdition.top  + hauteur + 5 ;

  NS_CLASSLIB::TPoint point(rectEdition.left, rectEdition.top) ;
  NS_CLASSLIB::TPoint point2(rectEdition.right, rectEdition.bottom) ;
  Parent->ScreenToClient(point) ;
  Parent->ScreenToClient(point2) ;

  // on reporte la modif du rectangle dans rectEditDico
  // pour pouvoir g�rer les changements de curseur
  // (voir NSTreeWindow::EvMouseMove)
  // Note : ne pas oublier de prendre les coordonn�es Client
  _pTreeAEditer->rectEditDico = NS_CLASSLIB::TRect(point, point2) ;

  //
  // Positionnement du contr�le Edit
  //
  SetWindowPos(0, point.X(), point.Y(),
                     rectEdition.right - rectEdition.left,
                     rectEdition.bottom - rectEdition.top ,SWP_NOZORDER) ;
  //
  // Supprimer la scrollbar verticale
  //
  ShowScrollBar(SB_VERT, FALSE) ;

  sAmmorceLibre = "" ;
}

void
NSEditDico::setBold()
{
  string sBeforeSelection = string("") ;
  string sSelection       = string("") ;
  string sAfterSelection  = string("") ;

  bool bGotBlocks = getThreeBlocks(sBeforeSelection, sSelection, sAfterSelection) ;
  if (false == bGotBlocks)
    return ;

  // Is there a bold opening markup before the selection?
  //
  bool isBeginingBefore = false ;
  if (string("") != sBeforeSelection)
  {
    size_t iLastStart = sBeforeSelection.find_last_of(START_BOLD) ;
    size_t iLastEnd   = sBeforeSelection.find_last_of(END_BOLD) ;

    if (iLastStart > iLastEnd)
      isBeginingBefore = true ;
  }

  // Is there a bold closing markup after the selection?
  //
  bool isEndigAfter = false ;
  if (string("") != sAfterSelection)
  {
    size_t iFirstStart = sAfterSelection.find(START_BOLD) ;
    size_t iFirstEnd   = sAfterSelection.find(END_BOLD) ;

    if (iFirstEnd < iFirstStart)
      isEndigAfter = true ;
  }

  // Remove all the opening or closing markups inside the selection
  //
  size_t iStartMark = sSelection.find(START_BOLD) ;
  size_t iEndMark   = sSelection.find(END_BOLD) ;
  while ((NPOS != iStartMark) || (NPOS != iEndMark))
  {
    size_t iMark = min(iStartMark, iEndMark) ;
    int    iMarkSize = strlen(START_BOLD) ;
    if (iMark == iEndMark)
      iMarkSize = strlen(END_BOLD) ;

    string sNewSelection = string("") ;
    if (iMark > 0)
      sNewSelection = string(sSelection, 0, iMark) ;
    if (iMark < strlen(sSelection.c_str()) - iMarkSize)
      sNewSelection += string(sSelection, iMark + iMarkSize, strlen(sSelection.c_str()) - iMark - iMarkSize) ;

    sSelection = sNewSelection ;

    iStartMark = sSelection.find(START_BOLD) ;
    iEndMark   = sSelection.find(END_BOLD) ;
  }

  if (false == isBeginingBefore)
    sBeforeSelection += START_BOLD ;

  if (false == isEndigAfter)
    sAfterSelection = END_BOLD + sAfterSelection ;

  addToUndoBuffer() ;

  setThreeBlocks(sBeforeSelection, sSelection, sAfterSelection) ;
}  

void
NSEditDico::setRegular()
{
  string sBeforeSelection = string("") ;
  string sSelection       = string("") ;
  string sAfterSelection  = string("") ;

  bool bGotBlocks = getThreeBlocks(sBeforeSelection, sSelection, sAfterSelection) ;
  if (false == bGotBlocks)
    return ;

  // Is there a bold opening markup before the selection?
  //
  bool isBeginingBefore = false ;
  if (string("") != sBeforeSelection)
  {
    size_t iLastStart = sBeforeSelection.find_last_of(START_BOLD) ;
    size_t iLastEnd   = sBeforeSelection.find_last_of(END_BOLD) ;

    if (iLastStart > iLastEnd)
      isBeginingBefore = true ;
  }

  // Is there a bold closing markup after the selection?
  //
  bool isEndigAfter = false ;
  if (string("") != sAfterSelection)
  {
    size_t iFirstStart = sAfterSelection.find(START_BOLD) ;
    size_t iFirstEnd   = sAfterSelection.find(END_BOLD) ;

    if (iFirstEnd < iFirstStart)
      isEndigAfter = true ;
  }

  // Remove all the opening or closing markups inside the selection
  //
  size_t iStartMark = sSelection.find(START_BOLD) ;
  size_t iEndMark   = sSelection.find(END_BOLD) ;
  while ((NPOS != iStartMark) || (NPOS != iEndMark))
  {
    size_t iMark = min(iStartMark, iEndMark) ;
    int    iMarkSize = strlen(START_BOLD) ;
    if (iMark == iEndMark)
      iMarkSize = strlen(END_BOLD) ;

    string sNewSelection = string("") ;
    if (iMark > 0)
      sNewSelection = string(sSelection, 0, iMark) ;
    if (iMark < strlen(sSelection.c_str()) - iMarkSize)
      sNewSelection += string(sSelection, iMark + iMarkSize, strlen(sSelection.c_str()) - iMark - iMarkSize) ;

    sSelection = sNewSelection ;

    iStartMark = sSelection.find(START_BOLD) ;
    iEndMark   = sSelection.find(END_BOLD) ;
  }

  if (true == isBeginingBefore)
    sBeforeSelection += START_BOLD ;

  if (true == isEndigAfter)
    sAfterSelection = END_BOLD + sAfterSelection ;

  addToUndoBuffer() ;

  setThreeBlocks(sBeforeSelection, sSelection, sAfterSelection) ;
}

void
NSEditDico::addToUndoBuffer()
{
  Invalidate() ;

  uint iStarSel   = 0 ;
  uint iEndSel    = 0 ;
  string sContent = string("") ;

  int oldBuffLen = GetTextLen() ;
  if (oldBuffLen > 0)
  {
    GetSelection(iStarSel, iEndSel) ;
	  char far* oldBuff = new char[oldBuffLen + 1] ;
	  GetText(oldBuff, oldBuffLen+1) ;
    sContent = string(oldBuff) ;
  }

  // expand the buffer
  //
  if (_undoBuffer.empty() || (_undoBuffer.end() == _undoCursor))
  {
    _undoBuffer.push_back(new NSEditStep(sContent, iStarSel, iEndSel)) ;
    _undoCursor = _undoBuffer.end() ;
  }
  // replace a previous record
  //
  else
  {
    (*_undoCursor)->replaceStep(sContent, iStarSel, iEndSel) ;
    _undoCursor++ ;
  }
}

void
NSEditDico::undoOneStep()
{
  if (_undoBuffer.begin() == _undoCursor)
    return ;

  // If the cursor is at end, it means that current state is at back, and
  // we have to go back 2 times to get the previous state
  //
  if (_undoBuffer.end() == _undoCursor)
  {
    _undoCursor-- ;
    if (_undoBuffer.begin() == _undoCursor)
    {
      SetText("") ;
      SetSelection(0, 0) ;
    }
  }

  _undoCursor-- ;

  string sContent = (*_undoCursor)->getContent() ;
  SetText(sContent.c_str()) ;
  SetSelection((*_undoCursor)->getMinSel(), (*_undoCursor)->getMaxSel()) ;
}

void
NSEditDico::redoOneStep()
{
  if (_undoBuffer.end() == _undoCursor)
    return ;

  _undoCursor++ ;

  if (_undoBuffer.end() == _undoCursor)
    return ;

  string sContent = (*_undoCursor)->getContent() ;
  SetText(sContent.c_str()) ;
  SetSelection((*_undoCursor)->getMinSel(), (*_undoCursor)->getMaxSel()) ;
}

bool
NSEditDico::getThreeBlocks(string& sBeforeSelection, string& sSelection, string& sAfterSelection)
{
  sBeforeSelection = string("") ;
  sSelection       = string("") ;
  sAfterSelection  = string("") ;

  int oldBuffLen = GetTextLen() ;
  if (oldBuffLen <= 0)
    return false ;

  uint iStarSel ;
  uint iEndSel ;
  GetSelection(iStarSel, iEndSel) ;
  if (iStarSel == iEndSel)
    return false ;

  char far* oldBuff = new char[oldBuffLen + 1] ;
  GetText(oldBuff, oldBuffLen+1) ;
  string sContent = string(oldBuff) ;

  if (iStarSel > 0)
    sBeforeSelection = string(sContent, 0, iStarSel) ;

  if (iEndSel < strlen(sContent.c_str()) - 1)
    sAfterSelection = string(sContent, iEndSel, strlen(sContent.c_str()) - iEndSel) ;

  if (iEndSel > iStarSel)
    sSelection = string(sContent, iStarSel, iEndSel - iStarSel) ;

  return true ;
}

void
NSEditDico::setThreeBlocks(string sBeforeSelection, string sSelection, string sAfterSelection)
{
  string sContent = sBeforeSelection + sSelection + sAfterSelection ;
  SetText(sContent.c_str()) ;

  int iStartSel = strlen(sBeforeSelection.c_str()) ;
  int iEndSel   = iStartSel ;
  if (string("") != sSelection)
    iEndSel += strlen(sSelection.c_str()) ;

  SetSelection(iStartSel, iEndSel) ;
}

// -------------------------------------------------------------------------
//                               NSEditStep
// -------------------------------------------------------------------------

NSEditStep::NSEditStep(string sContent, int iMinSel, int iMaxSel)
{
  _iMinSel  = iMinSel ;
  _iMaxSel  = iMaxSel ;
  _sContent = sContent ;
}

NSEditStep::~NSEditStep()
{
}

NSEditStep::NSEditStep(const NSEditStep& rv)
{
  _iMinSel  = rv._iMinSel ;
  _iMaxSel  = rv._iMaxSel ;
  _sContent = rv._sContent ;
}

NSEditStep&
NSEditStep::operator=(const NSEditStep& src)
{
  if (&src == this)
    return *this ;

  _iMinSel  = src._iMinSel ;
  _iMaxSel  = src._iMaxSel ;
  _sContent = src._sContent ;

  return *this ;
}

void
NSEditStep::replaceStep(string sContent, int iMinSel, int iMaxSel)
{
  _iMinSel  = iMinSel ;
  _iMaxSel  = iMaxSel ;
  _sContent = sContent ;
}
