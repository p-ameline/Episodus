//---------------------------------------------------------------------------//    NSPATPAT.CPP
//    PA   juillet 94
//    Kaddachi Hafedh
//    Impl�mentation des objets de type patpatho
//---------------------------------------------------------------------------

#include "nautilus\nssuper.h"

#include "nsbb\nsbb_glo.h"
#include "partage\nsdivfct.h"
#include "nsbb\nspatpat.h"
#include "partage\stringar.h"
#include "nsbb\nsbbtran.h"
#include "nsbb\nsbbsmal.h"
#include "nsbb\nstlibre.h"
#include "nsbb\ns_objs.h"
#include "nssavoir\nsgraphe.h"

long NSPatPathoData::lObjectCount = 0 ;
long NSPatPathoInfo::lObjectCount = 0 ;
long NSPatPathoArray::lObjectCount = 0 ;
long NSVectPatPathoArray::lObjectCount = 0 ;
long NSFatheredPatPathoArray::lObjectCount = 0 ;
long NSVectFatheredPatPathoArray::lObjectCount = 0 ;

// -----------------------------------------------------------------------------// ComposeNoeudsChemin
// A partir d'un chemin "fil guide" ('/' comme seul s�parateur), compose un chemin classique
// -----------------------------------------------------------------------------

void ComposeNoeudsChemin(string sCheminBrut, string& sCheminPatho)
{
  if (!(&sCheminPatho))
  	return ;
  sCheminPatho = string("") ;

  if (string("") == sCheminBrut)
  	return ;

  bool   bCont = true ;
  size_t pos1 = 0 ;
  size_t pos2 ;
  string sCode ;

  pos2 = sCheminBrut.find("/") ;

  while (bCont)
  {
    if (pos2 == NPOS)
    	sCode = string(sCheminBrut, pos1, strlen(sCheminBrut.c_str()) - pos1) ;
    else
    	sCode = string(sCheminBrut, pos1, pos2-pos1) ;

    if ((string(sCode, 0, 3) == "WCE") ||
        (string(sCode, 0, 4) == "WPLU") ||
        ('�' == sCode[0]) || ('$' == sCode[0]))
    {
    	if ((string("") != sCheminPatho) && (string("") != sCode))
      	sCheminPatho += string(1, intranodeSeparationMARK) ;
    }
    else
    {
    	if ((string("") != sCheminPatho) && (string("") != sCode))
      	sCheminPatho += string(1, cheminSeparationMARK) ;
    }

    sCheminPatho += sCode ;

    if (pos2 == NPOS)
    	break ;

    pos1 = pos2 + 1 ;
    pos2 = sCheminBrut.find("/", pos1) ;
  }
}
// -------------------------------------------------------------------------
// -------------------- METHODES DE NSVectPatPathoArray ------------------------
// -------------------------------------------------------------------------
NSVectPatPathoArray::NSVectPatPathoArray()
                    :NSVectPatPathoInfoArray()
{
	lObjectCount++ ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSVectPatPathoArray::NSVectPatPathoArray(NSVectPatPathoArray& rv)
                    :NSVectPatPathoInfoArray()
{
try
{
	if (!(rv.empty()))
		for (PatPathoIterVect i = rv.begin(); i != rv.end(); i++)
			push_back(new NSPatPathoArray(*(*i))) ;

  lObjectCount++ ;
}
catch (...)
{
	erreur("Exception (NSVectPatPathoArray copy ctor).", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
void
NSVectPatPathoArray::vider()
{
	if (empty())
		return ;
	for (PatPathoIterVect i = begin(); i != end(); )
	{
		delete *i ;
		erase(i) ;
	}
}

NSVectPatPathoArray::~NSVectPatPathoArray()
{
	vider() ;
  
  lObjectCount-- ;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSVectPatPathoArray&NSVectPatPathoArray::operator=(NSVectPatPathoArray src)
{
try
{
	if (&src == this)
		return *this ;

	//
	// Effacement des �l�ments d�j� contenus dans le vecteur destination
	//
	vider() ;	//
	// Copie et insertion des �l�ments de la source
	//
	if (!(src.empty()))
		for (PatPathoIterVect i = src.begin(); i != src.end(); i++)
			push_back(new NSPatPathoArray(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception (op = NSVectPatPathoArray).", standardError, 0) ;
	return *this ;
}
}

//---------------------------------------------------------------------------//   NSVectPatPathoArray vide ou non dans le cas non multidialogue
//---------------------------------------------------------------------------
bool
NSVectPatPathoArray::estVide()
{
	if (empty())
		return true ;

	PatPathoIterVect iter ;
	for (iter = begin(); (iter != end()) && ((*iter)->empty()) ; iter++) ;
	if (iter == end())
		return true ;

	return false ;
}

//---------------------------------------------------------------------------
//   NSVectPatPathoArray vide ou non dans le cas multidialogue
//---------------------------------------------------------------------------
bool
NSVectPatPathoArray::MultiestVide()
{
	if (empty())
		return true ;

	PatPathoIterVect iter;
	for (iter = begin(); (iter != end()) && ((*iter)->empty()) ; iter++) ;
	if (iter == end())
		return true ;

	return false ;
}

// *************************************************************************
// -------------------- METHODES DE NSPatPathoArray ------------------------
// **************************************************************************
NSPatPathoArray::NSPatPathoArray(NSContexte* pCtx, int iType)
                :NSPatPathoInfoArray(), NSRoot(pCtx)
{
	iArrayType = iType ;
	// reserve(50) ;
	lObjectCount++ ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSPatPathoArray::NSPatPathoArray(NSPatPathoArray& rv)
                :NSPatPathoInfoArray(), NSRoot(rv.pContexte)
{
try
{
	// reserve(50) ;
	if (!(rv.empty()))
		for (PatPathoIter i = rv.begin(); i != rv.end();i++)
			push_back(new NSPatPathoInfo(*(*i))) ;

	lObjectCount++ ;
}
catch (...)
{
	erreur("Exception (NSPatPathoArray copy ctor).", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSPatPathoArray::vider()
{
	if (empty())
		return ;

	for (PatPathoIter i = begin(); i != end(); )
	{
		delete *i ;
		erase(i) ;
	}
}

void
NSPatPathoArray::clearAllIDs()
{
	if (empty())
		return ;

	for (PatPathoIter i = begin(); i != end(); i++)
	{
  	(*i)->setTreeID("") ;
		(*i)->setNodeID("") ;
	}
}

NSPatPathoArray::~NSPatPathoArray()
{
	vider() ;

	lObjectCount-- ;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSPatPathoArray&
NSPatPathoArray::operator=(NSPatPathoArray src)
{
try
{
	if (&src == this)
		return *this ;

	PatPathoIter i ;
	//
	// Effacement des �l�ments d�j� contenus dans le vecteur destination
	//
	vider() ;
	//
	// Copie et insertion des �l�ments de la source
	//

	if (!(src.empty()))
		for (i = src.begin(); i != src.end(); i++)
			push_back(new NSPatPathoInfo(*(*i))) ;

	return *this ;
}
catch (...)
{
    erreur("Exception (op = NSPatPathoArray).", standardError, 0) ;
    return *this;
}
}

//---------------------------------------------------------------------------//  Op�rateur d'�galit�
// Attention : ne compile pas si parametre const//---------------------------------------------------------------------------
intNSPatPathoArray::operator==(NSPatPathoArray& o){try{  PatPathoIter i, j ;  int egal = 1 ;  if (empty() || o.empty())  {    if (o.empty() && empty())      return 1 ;    else      return 0 ;  }  i = begin() ;  j = o.begin() ;  while ((end() != i) && (o.end() != j))  {    if (!((*(*i)) == (*(*j))))    {      egal = 0 ;      break ;    }    i++ ;    j++ ;  }  if (egal && ((end() != i) || (o.end() != j)))    egal = 0 ;  return egal ;}catch (...){
  erreur("Exception (op == NSPatPathoArray).", standardError, 0) ;
  return 0 ;
}
}//---------------------------------------------------------------------------//  Ajout d'un �l�ment � l'array
//---------------------------------------------------------------------------
bool
NSPatPathoArray::ajouteElement(NSPatPathoInfo* pPatPatho)
{
try
{
	if (!pPatPatho)
		return false ;

	push_back(pPatPatho) ;
	return true ;
}
catch (...)
{
	erreur("Exception NSPatPathoArray::ajouteElement.", standardError, 0) ;
	return false ;
}
}

//---------------------------------------------------------------------------//  Destruction d'un �l�ment de l'array
//---------------------------------------------------------------------------
bool
NSPatPathoArray::detruitElement(NSPatPathoInfo* pPatPatho)
{
	if ((empty()) || (!pPatPatho))
		return false ;

	PatPathoIter i ;	//
	// On cherche l'�l�ment de m�me ID
	//
	for (i = begin(); (i != end()) && ((*i)->ID != pPatPatho->ID); i++) ;

	//	// On supprime l'�l�ment trouv�
	//
	if (i != end())
	{
  	delete *i ;
    erase(i) ;
    return true ;
	}
	return false ;
}

//---------------------------------------------------------------------------// Ajout du patpatho du BBFilsItem
//---------------------------------------------------------------------------
void
NSPatPathoArray::ajouteVecteur(NSPatPathoArray* pPath, int decalageColonne)
{
  if ((NULL == pPath) || (pPath->empty()))
    return ;

  int ligne ;

  if (false == empty())
    ligne = (back())->getLigne() + 1 ;
  else
    ligne = ORIGINE_PATH_PATHO ;

  int LigneReference = (*(pPath->begin()))->getLigne() ;

try
{
	for (PatPathoIter i = pPath->begin() ; pPath->end() != i ; )
  {
    NSPatPathoInfo* _pPatPatho = new NSPatPathoInfo(*(*i)) ;
    string sScalaire = ((*i))->getComplement() ;
    _pPatPatho->setLigne(ligne) ;
    _pPatPatho->setColonne(_pPatPatho->getColonne() + decalageColonne) ;

    push_back(_pPatPatho) ;

    i++ ;
    if ((pPath->end() != i) && ((*i)->getLigne() > LigneReference))
    {
      ligne++ ;
      LigneReference = (*i)->getLigne() ;
    }
  }
} // try
catch (...)
{
	erreur("Exception (NSPatPathoArray ajouteVecteur).", standardError, 0) ;
}
}

//---------------------------------------------------------------------------// Ajout d'un �l�ment � la patpatho en cours
// pMessage contient les donn�es patpatho sauf le champ lexique qui est contenu
// dans sEtiquette
//---------------------------------------------------------------------------
void
NSPatPathoArray::ajoutePatho(string sEtiquette, Message* pMessage, int colonne)
{
try
{
	if ((!pMessage) || (string("") == sEtiquette) || (colonne < 0))
		return ;

	// En mode MUE, chaque ligne n'est occup�e que par un seul noeud
	int decalageLigne = 1 ;

	NSPatPathoInfo* _pPatPatho = new NSPatPathoInfo() ;
	_pPatPatho->setLexique(sEtiquette) ;

  // Pr�caution pas toujours inutile : si le noeud est compos�, ne pas faire
  // d�border pDonnees->noeud ou pDonnees->treeID
  strncpy(_pPatPatho->pDonnees->treeID, pMessage->GetTreeID().c_str(), OBJECT_ID_LEN) ;
  _pPatPatho->pDonnees->treeID[OBJECT_ID_LEN] = '\0' ;

  strncpy(_pPatPatho->pDonnees->noeud, pMessage->GetNoeud().c_str(), PPD_NOEUD_LEN) ;
  _pPatPatho->pDonnees->noeud[PPD_NOEUD_LEN] = '\0' ;

  _pPatPatho->setComplement   (pMessage->GetComplement()) ;
  _pPatPatho->setUnit         (pMessage->GetUnit()) ;
  _pPatPatho->setCertitude    (pMessage->GetCertitude()) ;
  _pPatPatho->setInteret      (pMessage->GetInteret()) ;
  _pPatPatho->setPluriel      (pMessage->GetPluriel()) ;
  _pPatPatho->setVisible      (pMessage->GetVisible()) ;
  _pPatPatho->setVisible      (pMessage->GetVisible()) ;
  _pPatPatho->setNodeRight    (pMessage->GetNodeRight()) ;

  if (pMessage->GetTemporaryLinks())
    _pPatPatho->pTemporaryLinks = new NSLinkedNodeArray(*(pMessage->GetTemporaryLinks())) ;

  _pPatPatho->setTexteLibre(pMessage->GetTexteLibre()) ;
  _pPatPatho->setArchetype(pMessage->GetArchetype()) ;
  _pPatPatho->setColonne(colonne) ;  int ligne ;
	if (!empty())
    ligne = (back())->getLigne() + decalageLigne ;
  else
    ligne = ORIGINE_PATH_PATHO ;
  _pPatPatho->setLigne(ligne) ;

  push_back(_pPatPatho) ;

} // try
catch (...)
{
	erreur("Exception (NSPatPathoArray ajoutePatho 1).", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//ajout d'un �l�ment � la patpatho
//---------------------------------------------------------------------------
void
NSPatPathoArray::ajoutePatho(string sEtiquette, int colonne)
{
try
{
	if ((string("") == sEtiquette) || (colonne < 0))
		return ;

	// En mode MUE, chaque ligne n'est occup�e que par un seul noeud
  // There is only one node per line
	int decalageLigne = 1 ;

  // Input can be of the kind: Node1/Node2...
  // L'�tiquette peut �tre du type Noeud1/Noeud2...
	//
	size_t posit = sEtiquette.find(string(1, cheminSeparationMARK)) ;
  if (NPOS != posit)
	{
    int iTaille = strlen(sEtiquette.c_str()) ;
    string sLexique = string(sEtiquette, 0, posit) ;
    string sSuite   = string(sEtiquette, posit+1, iTaille - posit - 1) ;

    if (string("") != sLexique)
      ajoutePatho(sLexique, colonne) ;

    if (string("") != sSuite)
      ajoutePatho(sSuite, colonne + 1) ;

    return ;
  }

  // Input can be of the kind: Lexique.certainty.plural
	// L'�tiquette peut �tre du type Lexique.Certitude.Pluriel
	//
	posit = sEtiquette.find(string(1, intranodeSeparationMARK)) ;
	//
	// Si c'est le cas, la m�thode la plus propre consiste
	// � passer par un Message
	//
	if (NPOS != posit)
	{
    int iTaille = strlen(sEtiquette.c_str()) ;
    string sLexique = string(sEtiquette, 0, posit) ;
    string sSuite   = string(sEtiquette, posit+1, iTaille - posit - 1) ;

    Message BufMessage("", sLexique) ;
    BufMessage.MettreAJourCertitudePluriel(sSuite) ;

    ajoutePatho(sLexique, &BufMessage, colonne) ;    return ;
  }
  //
  // Plain vanilla Lexique concept
  // Sch�ma simple
  //
  NSPatPathoInfo* _pPatPatho = new NSPatPathoInfo() ;
  _pPatPatho->setLexique(sEtiquette) ;

  _pPatPatho->setComplement   ("") ;
  _pPatPatho->setUnit         ("") ;
  _pPatPatho->setCertitude    ("") ;
  _pPatPatho->setInteret      ("A") ;
  _pPatPatho->setPluriel      ("") ;
  _pPatPatho->setVisible      ("") ;

  _pPatPatho->setTexteLibre("") ;
  _pPatPatho->setArchetype("") ;
  _pPatPatho->setColonne(colonne) ;

  int ligne ;
	if (!empty())
    ligne = (back())->getLigne() + decalageLigne ;
  else
    ligne = ORIGINE_PATH_PATHO ;
  _pPatPatho->setLigne(ligne) ;

  push_back(_pPatPatho) ;

} // try
catch (...)
{
	erreur("Exception NSPatPathoArray ajoutePatho 2", standardError, 0) ;
}
}

//-------------------------------------------------------------------------//A partir de la patpatho globale (this) extraire la patpatho de l'�l�ment
//iterPere et la mettre dans pPatpathoPere
//-------------------------------------------------------------------------
void
NSPatPathoArray::ExtrairePatPatho(PatPathoIter iterPere, NSPatPathoArray* pPatpathoPere)
{
	if ((empty()) || (NULL == pPatpathoPere))
		return ;
	if ((end() == iterPere) || (NULL == iterPere))
		return ;

	PatPathoIter itFils = begin() ;
	PatPathoIter precedent = begin() ;

	itFils = iterPere ;
	int ligneElement   = (*iterPere)->getLigne() ;
	int colonneElement = (*iterPere)->getColonne() ;
	if (itFils != end())
		itFils++ ;
	else
		return ;
	precedent = itFils ;

try
{
	int Ligne = 0 ;
	bool continuer = true ;
	while ((itFils != end()) && (continuer))
	{
  	int ligneFils   = (*itFils)->getLigne() ;
    int colonneFils = (*itFils)->getColonne() ;
    string sLexique = (*itFils)->getLexique() ;

    if ((colonneFils  > colonneElement) && (ligneFils > ligneElement))
    {
    	int colonne = colonneFils - (colonneElement + 1) ;
      NSPatPathoInfo* pPatPatho = new NSPatPathoInfo() ;
      *(pPatPatho->pDonnees) = *((*itFils)->pDonnees) ;
      pPatPatho->setColonne(colonne) ;
      if ((precedent != end())  &&
         	            ((*precedent)->getLigne() != (*itFils)->getLigne()))
      	Ligne++ ;

      pPatPatho->setLigne(Ligne) ;
      pPatpathoPere->push_back(pPatPatho) ;
      precedent = itFils ;
      if (itFils != end())
      	itFils++ ;
    }
    else
    	continuer = false ;
	}
} // try
catch (...)
{	erreur("Exception NSPatPathoArray ExtrairePatPatho 1.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------//A partir de la patpatho globale (this) extraire la patpatho de l'�l�ment
//(ligneElement, colonneElement) et la mettre dans pPatpathoPere
//-------------------------------------------------------------------------
void
NSPatPathoArray::ExtrairePatPatho(int ligneElement, int colonneElement, NSPatPathoArray* pPatpathoPere)
{
	if ((empty()) || (!pPatpathoPere))
    	return;

  PatPathoIter iterPere = ChercherItem(ligneElement, colonneElement);//chercher l'�l�ment
   																		//de coordonn�es (ligneElement, colonneElement)
  if ((iterPere == NULL) || (iterPere == end()))
    return ;

	ExtrairePatPatho(iterPere, pPatpathoPere) ;}

//-------------------------------------------------------------------------//A partir de la patpatho globale (this) extraire la patpatho de l'�l�ment
//iterPere et la mettre dans pPatpathoPere
//-------------------------------------------------------------------------
void
NSPatPathoArray::ExtrairePatPathoFreres(PatPathoIter iterRef, NSPatPathoArray* pPatpathoDest)
{
	if ((empty()) || (!pPatpathoDest))
    return ;
  if ((iterRef == NULL) || (iterRef == end()))
    return ;

try
{
  int colonneElement = (*iterRef)->getColonne() ;

	PatPathoIter itFils = begin() ;
  itFils = iterRef ;

  int Ligne = 0 ;
  bool bBonneBranche = true;
  while (itFils != end())
  {
    int colonneFils = (*itFils)->getColonne() ;
    //
    // Trop loin
    //
    if (colonneFils < colonneElement)
      break ;
    //
    // M�me niveau que iterRef, on v�rifie que c'est un noeud de m�me type
    //
    if (colonneFils == colonneElement)
    {
      if ((!strcmp((*itFils)->pDonnees->lexique,      (*iterRef)->pDonnees->lexique)) &&
          (!strcmp((*itFils)->pDonnees->complement,   (*iterRef)->pDonnees->complement)) &&
          (!strcmp((*itFils)->pDonnees->certitude,    (*iterRef)->pDonnees->certitude)) &&
          (!strcmp((*itFils)->pDonnees->pluriel,      (*iterRef)->pDonnees->pluriel)))
        bBonneBranche = true ;
      else
        bBonneBranche = false ;
    }
    //
    // Ajout du noeud
    //
    if (bBonneBranche)
    {
      string sLexique = (*itFils)->getLexique() ;

      int colonne = colonneFils - colonneElement ;

      NSPatPathoInfo* pPatPatho = new NSPatPathoInfo() ;
      *(pPatPatho->pDonnees) = *((*itFils)->pDonnees) ;

      pPatPatho->setColonne(colonne) ;
      pPatPatho->setLigne(Ligne) ;
      Ligne++ ;

      pPatpathoDest->push_back(pPatPatho) ;
    }
    itFils++ ;
  }
} // try
catch (...)
{	erreur("Exception NSPatPathoArray ExtrairePatPathoFreres.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------
// A partir de la patpatho globale (this) extraire le vecteur des freres
// de m�me colonne � partir de la colonne de r�f�rence (iterRef)
//-------------------------------------------------------------------------
void
NSPatPathoArray::ExtraireVecteurPatPathoFreres(PatPathoIter iterRef, NSVectPatPathoArray* pVect)
{
	if ((empty()) || (!pVect))
		return ;
	if (iterRef == end())
		return ;

	pVect->vider() ;

try
{
	NSPatPathoArray* pPatPathoFrere = new NSPatPathoArray(pContexte) ;
	int colonneElement = (*iterRef)->getColonne() ;

	PatPathoIter itFils = iterRef ;

	int Ligne ;
	bool bDebut = true ;

	while (itFils != end())
	{
		int colonneFils = (*itFils)->getColonne() ;
		//
		// Trop loin
		//
		if (colonneFils < colonneElement)
			break ;
		//
		// M�me niveau que iterRef, on v�rifie que c'est un noeud de m�me type
		//
		if (colonneFils == colonneElement)
		{
			if (!bDebut)
				pVect->push_back(new NSPatPathoArray(*pPatPathoFrere)) ;

			pPatPathoFrere->vider() ;
			Ligne = 0 ;
			bDebut = false ;
		}
		//
		// Ajout du noeud
		//
		if (!bDebut)
		{
			string sLexique = (*itFils)->getLexique() ;

			int colonne = colonneFils - colonneElement ;

			NSPatPathoInfo* pPatPatho = new NSPatPathoInfo() ;
			*(pPatPatho->pDonnees) = *((*itFils)->pDonnees) ;

			pPatPatho->setColonne(colonne) ;
			pPatPatho->setLigne(Ligne) ;
			Ligne++ ;

			pPatPathoFrere->push_back(pPatPatho) ;
		}

		itFils++ ;
	}

	// on push_back le dernier frere
	if (!bDebut)
		pVect->push_back(new NSPatPathoArray(*pPatPathoFrere)) ;

	delete pPatPathoFrere ;

} // try
catch (...)
{	erreur("Exception NSPatPathoArray ExtraireVecteurPatPathoFreres.", standardError, 0) ;
}
}
//-------------------------------------------------------------------------// Ins�rer dans la patpatho globale (this) la patpatho source juste
// avant l' �l�ment iterAvant
//
// ATTENTION : la colonne des �l�ments ajout�s est calcul�e en ajoutant
//             decalageColonne � la COLONNE QU'IL A DANS pPatpathoSource
//             et non pas � la colonne de iterAvant
//
// WARNING : the added element's column is set by adding decalageColonne to
//           the COLUMN HE HAD IN pPatpathoSource (and not to iterAvant's col)
//
//-------------------------------------------------------------------------
void
NSPatPathoArray::InserePatPatho(PatPathoIter iterAvant,
      										 NSPatPathoArray* pPatpathoSource,
                                             int decalageColonne,
                                             bool bWithTreeID)
{
try
{
	if ((!pPatpathoSource) || (pPatpathoSource->empty()))
		return ;

	// On ne pourra plus tester de fa�on valide si iterAvant == end() d�s
	// qu'on aura ins�r� un nouveau noeud
	//
	NSPatPathoInfo* pPathAvant = 0 ;
	bool bInsertAtEnd ;
	if ((end() == iterAvant) || (NULL == iterAvant))
		bInsertAtEnd = true ;
	else
		bInsertAtEnd = false ;

  // http://www.sgi.com/tech/stl/Vector.html
  // A vector's iterators are invalidated when its memory is reallocated.
  // Additionally, inserting or deleting an element in the middle of a vector
  // invalidates all iterators that point to elements following the insertion
  // or deletion point.
  // It follows that you can prevent a vector's iterators from being
  // invalidated if you use reserve() to preallocate as much memory as the
  // vector will ever use, and if all insertions and deletions are at the
  // vector's end.
  //
	if (false == bInsertAtEnd)
	{
  	pPathAvant = *iterAvant ;

    size_type iSourceSize  = pPatpathoSource->size() ;
    size_type iCurrentSize = size() ;
    size_type iCurrentCapa = capacity() ;
    if (iCurrentCapa < iSourceSize + iCurrentSize)
    {
    	reserve(iSourceSize + iCurrentSize) ;

      iterAvant = begin() ;
      for ( ; (iterAvant != end()) && (*iterAvant != pPathAvant); iterAvant++) ;
      if (iterAvant == end())
      {
      	erreur("Erreur lors de l'insertion d'un arbre : le noeud d'insertion n'est plus pr�sent.", standardError, 0) ;
        return ;
      }
    }
  }

  // Attention : on commence par d�caler les lignes d'iterAvant et des
  // �l�ments suivant de la "taille" de patpathoSource, comme la ligne
  // d'iterAvant reste la r�f�rence des �l�ments ins�r�s, cel� oblige ensuite
  // � ins�rer avec un d�calage de ligne - pPatpathoSource->Taille())
  //
  // Ce qu'Hafedh n'avait pas pr�vu, c'est le cas iterAvant == end()
  // dans ce cas, ce d�calage n�gatif n'a pas lieu d'�tre, il faut le
  // remplacer par un d�calage positif (ou nul) par rapport au dernier
  // �l�ment de l'Array
  // L'autre probl�me, c'est qu'il n'existe, dans ce m�me cas, aucun moyen de
  // savoir � quelle colonne ins�rer patpathoSource, on ins�re donc en
  // colonne 0 + decalageColonne
	//
	if (false == empty())
	{
  	PatPathoIter jter = begin() ;
    jter = iterAvant ;
    for ( ; jter != end(); jter++)
    	(*jter)->setLigne((*jter)->getLigne() + pPatpathoSource->Taille()) ;
	}

	PatPathoIter j = pPatpathoSource->begin() ;
	int ligne = 0 ;
	int decalFin = 0 ;
	PatPathoIter precedent = pPatpathoSource->begin() ; // utilis� pour ne pas
                                                       // incr�menter ligne
                                                       // si on est sur des
                                                       // �tiquettes compos�es
	while (pPatpathoSource->end() != j)
	{
  	Message Msg ;

    if (bWithTreeID)
    	Msg.SetTreeID((*j)->pDonnees->treeID) ;
    Msg.SetNoeud((*j)->pDonnees->noeud) ;
    Msg.SetUnit((*j)->pDonnees->unit) ;
    Msg.SetComplement((*j)->pDonnees->complement) ;
    Msg.SetCertitude((*j)->pDonnees->certitude) ;
    Msg.SetInteret((*j)->pDonnees->interet) ;
    Msg.SetPluriel((*j)->pDonnees->pluriel) ;    Msg.SetVisible((*j)->pDonnees->visible) ;
    Msg.SetType((*j)->pDonnees->type) ;
    Msg.SetTexteLibre((*j)->getTexteLibre()) ;
    Msg.SetArchetype((*j)->getArchetype()) ;
    Msg.SetNodeRight((*j)->getNodeRight()) ;
    Msg.SetTemporaryLinks((*j)->pTemporaryLinks) ;

    if ((*precedent)->getLigne() != (*j)->getLigne())
    {
    	ligne++ ;
      decalFin = 1 ;
    }
    else
    {
    	if (pPatpathoSource->begin() == j)
      	decalFin = 1 ;
      else
      	decalFin = 0 ;
    }

    if (!bInsertAtEnd)
    	ajoutePatho(iterAvant, (*j)->pDonnees->lexique, &Msg,
                        (*j)->getColonne() + decalageColonne,
                        ligne - pPatpathoSource->Taille()) ;
    else
    	ajoutePatho(end(), (*j)->pDonnees->lexique, &Msg,
                        (*j)->getColonne() + decalageColonne, decalFin);
    precedent = j ;
    j++ ;
    if (false == bInsertAtEnd)
    {
    	// Pour garantir qu'on est bien toujours sur le m�me et que
      // l'insertion n'a pas d�cal� iterAvant
      if (*iterAvant != pPathAvant)
      {
      	iterAvant = begin() ;
        for ( ; (iterAvant != end()) && (*iterAvant != pPathAvant); iterAvant++) ;
        if (iterAvant == end())
        {
        	erreur("Erreur lors de l'insertion d'un arbre : le noeud d'insertion n'est plus pr�sent.", standardError, 0) ;
          break ;
        }
      }
    }
  }
} // try
catch (...)
{
	erreur("Exception NSPatPathoArray InserePathPatho.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------
// Ins�rer dans la patpatho globale (this) la patpatho source en tant que
// fille de l'�l�ment iterPere
//-------------------------------------------------------------------------
void
NSPatPathoArray::InserePatPathoFille(PatPathoIter iterPere,
      										 NSPatPathoArray* pPatpathoSource)
{
	if ((!pPatpathoSource) || (pPatpathoSource->empty()))
		return ;
	if ((iterPere == NULL) || (iterPere == end()))
		return ;

	int iColPere = (*iterPere)->getColonne() ;

	//
	// On se positionne sur l'�l�ment qui suit le dernier fils
	//
	PatPathoIter iterFrere = iterPere ;
	iterFrere++ ;
	while ((iterFrere != end()) && ((*iterFrere)->getColonne() > iColPere))
		iterFrere++ ;

	// iDeltaCol sera ajout� � la colonne qu'� l'�l�ment dans pPatpathoSource
	// pour fournir sa colonne d�finitive ; puisqu'on veut que les �l�ments
	// soit fils de iterPere, il faut "normaliser" les choses
	//
	// iDeltaCol will be added to the column of the node inside pPatpathoSource
	// in order to get the node column ; since we want the nodes to be sons
	// of iterPere, we have to "normalise"
	//
	int iDeltaCol = iColPere + 1 - ((*(pPatpathoSource->begin()))->getColonne()) ;

	InserePatPatho(iterFrere, pPatpathoSource, iDeltaCol) ;
}

//--------------------------------------------------------------------//comparaison de 2 patpathos : this et pPatho
// Teste l'�galit� du point de vue des donn�es (ne tient pas compte du num�ro de noeud)//--------------------------------------------------------------------
bool
NSPatPathoArray::estEgal(NSPatPathoArray* pPatho)
{
	if (!pPatho)
		return false ;

	int egal = 1 ;	if (empty())	{		if (pPatho->empty())			return true ;		else			return false ;	}	PatPathoIter i = begin() ;	PatPathoIter j = pPatho->begin() ;	while ((i != end()) && (j != pPatho->end()))	{		if (!((*i)->estEgal(*j)))		{    	egal = 0 ;      	break ;    }    i++ ;    j++ ;	}	if (egal)	{  	if ((i != end()) || (j != pPatho->end()))    	egal = 0 ;	}	return egal ;}
//----------------------------------------------------------------------// savoir si dans pPatpath les �l�ments de sChaine sont en relation de
// 							descendance entre eux.
//
// 				exemple sChaine : "A/B/C/D/E/F/G/H"
//si on trouve l'encha�nement suivant A/B/C/D alors retourner l'it�rateur
//											sur D
//							pPostionItem est la position de D (4)
//----------------------------------------------------------------------
PatPathoIter
NSPatPathoArray::ChaineDansPatpatho(string sChaine, string* pLocalisation, string separateur, PatPathoIter iterFrom)
{
try
{
	if ((empty()) || (!pLocalisation))
		return NULL ;

	ClasseStringVector Vect ;
	DecomposeChaine(&sChaine, &Vect, separateur) ;

  if (Vect.empty())
		return NULL ;

	iterString  iterpVect     = Vect.begin() ;
	iterString  iterpVectTemp = Vect.begin() ;
	*pLocalisation = "" ;
	PatPathoIter  iterRetour  = begin() ;
	PatPathoIter  iterPatPath = begin() ;

	int colonneEncours ;
	int colonne ;
	string sItem ;

	bool bCanReturn = true ;
	if (iterFrom && (iterFrom != iterPatPath))
		bCanReturn = false ;

	//
  // pour chaque �l�ment de pVect, scanner toute la patpatho, et mettre � jour les champs de
  // l'�l�ment en question :
  //									colonne = sa colonne;
  //   								coche   = �l�ment d�tect� ou non;
  //   								sItem   = son lablel;
  //			(selon sa position par rapport � l �l�ment de la patpatho)
  //

  for (iterPatPath = begin(); iterPatPath != end(); iterPatPath++)
  {
  	colonneEncours = (*iterPatPath)->getColonne() ;
    for (iterpVect = Vect.begin() ; iterpVect != Vect.end(); iterpVect++)
    {
    	colonne = (*iterpVect)->colonne ;
      // D�cocher les �l�ments dont la colonne est >= colonneEncours
      if (colonne >= colonneEncours)
      	(*iterpVect)->coche = false ;
    }

    // Trouver le premier �l�ment de pVect non coch�    //
    for (iterpVectTemp = Vect.begin(); (iterpVectTemp != Vect.end()) &&
      				((*iterpVectTemp)->coche); iterpVectTemp++) ;
    if (iterpVectTemp != Vect.end())
    {
    	sItem = (*iterpVectTemp)->sItem ;

      string sCodeSens = (*iterPatPath)->getLexique() ;
      pContexte->getDico()->donneCodeSens(sCodeSens) ;

      string ssItemCodeSens = sItem ;
      pContexte->getDico()->donneCodeSens(ssItemCodeSens) ;

      if (sCodeSens == ssItemCodeSens)
      {
      	if (*pLocalisation == "")
        	*pLocalisation += (*iterpVectTemp)->sItem ;
        else
        	*pLocalisation += separateur + (*iterpVectTemp)->sItem ;
        (*iterpVectTemp)->colonne = (*iterPatPath)->getColonne() ;
        (*iterpVectTemp)->coche = true ;
        iterRetour = iterPatPath ;
        // si c'est le dernier on sort
        if (bCanReturn && ((*iterpVectTemp) == Vect.back()))
        	return iterRetour ;
      }
    }
    if (iterFrom && (iterFrom == iterPatPath))
    	bCanReturn = true ;
  }

	if ((*pLocalisation != "") && (iterFrom == NULL))  	return iterRetour ;
	else
		return end() ;

} // trycatch (...)
{
	erreur("Exception NSPatPathoArray ChaineDansPatpatho.", standardError, 0) ;
  return end() ;
}
}

/*** Ajoute un chemin � une patPatho
* Insert a path inside a patPatho
*/
void
NSPatPathoArray::AjouterChemin(string sChaine, string sValeur, bool bEcraser, string separateur)
{
try
{
	if (string("") == sChaine)
		return ;

	int Colonne = 0 ;
	int ColonnePere ;

	PatPathoIter suivant = NULL ;

	// bool bSuivant = false ;
	// bool bChaineDansPatpatho = false ;

	string  sChaineInsertion; //cha�ne � ins�rer

	if (string("") != sValeur)
		sChaineInsertion = sChaine + separateur + sValeur ;
	else
		sChaineInsertion = sChaine;

	if (false == empty())
	{
  	suivant = end() ;
		//
		// Chercher l'it�rateur dans pPatPath correspondant au dernier item
		// de la plus grande sous cha�ne de sChaine.
		//
		string sousChaine ;  // plus grande sous chaine de sChaine repr�sentant
    										 // un chemin dans pPatPath
		PatPathoIter iter = ChaineDansPatpatho(sChaine, &sousChaine, separateur) ;

		//
		//exemple : sChaine = "AVGCA1/QCINE1/QCOVG1"
		//          sValeur = "1DIMI1"
    //
		//          iter -> QCINE1
    //
		//          sousChaine       = "AVGCA1/QCINE1"
		//          sChaineInsertion = "QCOVG1/1DIMI1"
    //
		if (sousChaine == sChaine)
			sChaineInsertion = sValeur ;
		else
		{
			bEcraser = false ;
			if (sousChaine != "")
			{
				int i = strlen(sousChaine.c_str()) ;
				sChaineInsertion = string(sChaine, i + 1, strlen(sChaine.c_str()) - (i + 1)) ;
        if (string("") != sValeur)
          sChaineInsertion += separateur + sValeur ;
			}
		}
		if ((NULL != iter) && (end() != iter))
		{
			ColonnePere = (*iter)->getColonne() ;
			Colonne     = ColonnePere + 1 ;
			// bChaineDansPatpatho = true ;
			if (bEcraser)//�craser ce qui vient apr�s iter
			{
				PatPathoIter suppr = begin() ;
				suppr = iter ;
				if (end() != suppr)
					suppr++ ;
				if (end() != suppr)
				{
					if ((*suppr)->getColonne() == (*iter)->getColonne() + 1)
						SupprimerItem(suppr) ;
				}
				suivant = begin() ;
				suivant = iter ;
				if (suivant != end())
					suivant++ ;
			}
			else
				suivant = ChercherItem(iter) ; //le premier fr�re de iter
		}

		// if ((suivant != end()) && (suivant != NULL))
		// 	bSuivant = true ;
	}

	ClasseStringVector Vect ;
	DecomposeChaine(&sChaineInsertion, &Vect, separateur) ;

	if (Vect.empty())
    return ;

  NSPatPathoArray pptNewBlock(pContexte) ;
  int iNewBlockCol = 0 ;

  iterString iterpVect = Vect.begin() ;
  while (Vect.end() != iterpVect)
  {
    pptNewBlock.ajoutePathoBlock((*iterpVect)->sItem, iNewBlockCol++) ;
    iterpVect++ ;
  }

  InserePatPatho(suivant, &pptNewBlock, Colonne) ;

/*
  iterString iterpVect = Vect.begin() ;
  while (Vect.end() != iterpVect)
  {
			//traiter le cas des �tiquettes multiples
			ClasseStringVector* pVectEtiqMulti = new ClasseStringVector ;
			DecomposeChaine(&(*iterpVect)->sItem, pVectEtiqMulti, "/") ;
			iterString  iterpVectMulti  = pVectEtiqMulti->begin() ;
			int TailleEtiquette = pVectEtiqMulti->size() ;
			if (bChaineDansPatpatho)
			{
				if (bSuivant)
				{
					PatPathoIter jter = begin() ;
					jter = suivant;
					for ( ; jter != end(); jter++)
							(*jter)->setLigne((*jter)->getLigne() + TailleEtiquette) ;
					//ins�rer les �l�ments d'une �tiquette multiple dans le m�me noeud
					if (iterpVectMulti != pVectEtiqMulti->end())
					{
						string sEtiquette   = (*iterpVectMulti)->sItem ;
						string sCertitude   = "" ;
						string sPluriel     = "" ;
						string sComplement  = "" ;
						string sUnit        = "" ;

						iterpVectMulti++ ;

						if ((sEtiquette[0] == '2') && (iterpVectMulti != pVectEtiqMulti->end()))
						{
							sUnit       = sEtiquette ;
							sEtiquette  = (*iterpVectMulti)->sItem ;
							iterpVectMulti++ ;
						}

						if (iterpVectMulti != pVectEtiqMulti->end())
						{
							bool bTourner = true ;

							while (bTourner)
							{
								string sSuite = (*iterpVectMulti)->sItem ;
								if (sSuite != "")
								{
									if      (string(sSuite, 0, 1) == string("$"))
										sComplement = string(sSuite, 1, strlen(sSuite.c_str())-1) ;
									else if (string(sSuite, 0, 3) == string("WCE"))
										sCertitude = sSuite ;
									else if (string(sSuite, 0, 3) == string("WPL"))
										sPluriel = sSuite;
									else
										bTourner = false ;
								}
								else
									bTourner = false ;

								if (bTourner)
								{
									iterpVectMulti++ ;
									if (iterpVectMulti == pVectEtiqMulti->end())
										bTourner = false ;
								}
							}
						}

						Message CodeMsg ;
						CodeMsg.SetLexique(sEtiquette) ;
						CodeMsg.SetPluriel(sPluriel) ;
						CodeMsg.SetCertitude(sCertitude) ;
						CodeMsg.SetComplement(sComplement) ;
						CodeMsg.SetUnit(sUnit) ;

						ajoutePatho(suivant, sEtiquette, &CodeMsg, Colonne , -1) ;

            Colonne++ ;

						if (suivant != end())
							suivant++ ;
						if (suivant != end())
							bSuivant = true ;
						else
							bSuivant = false ;
					}
				}
				else
				{
					int ligne = 1 ;
          //ins�rer les �l�ments d'une �tiquette multiple dans le m�me noeud
          if (iterpVectMulti  != pVectEtiqMulti->end())
          {
            string sEtiquette   = (*iterpVectMulti)->sItem ;
            string sCertitude   = "" ;
            string sPluriel     = "" ;
            string sComplement  = "" ;
            string sUnit        = "" ;

            iterpVectMulti++ ;

            if ((sEtiquette[0] == '2') && (iterpVectMulti != pVectEtiqMulti->end()))
            {
              sUnit      = sEtiquette ;
              sEtiquette = (*iterpVectMulti)->sItem ;
              iterpVectMulti++ ;
            }

            if (iterpVectMulti != pVectEtiqMulti->end())
            {
              bool bTourner = true ;

              while (bTourner)
              {
                string sSuite = (*iterpVectMulti)->sItem ;
                if (sSuite != "")
                {
                  if      (string(sSuite, 0, 1) == string("$"))
                    sComplement = string(sSuite, 1, strlen(sSuite.c_str())-1) ;
                  else if (string(sSuite, 0, 3) == string("WCE"))
                    sCertitude = sSuite ;
                  else if (string(sSuite, 0, 3) == string("WPL"))
                    sPluriel = sSuite ;
                  else
                    bTourner = false ;
                }
                else
                  bTourner = false ;

                if (bTourner)
                {
                  iterpVectMulti++ ;
                  if (iterpVectMulti == pVectEtiqMulti->end())
                    bTourner = false ;
                }
              }
            }

            Message CodeMsg ;
            CodeMsg.SetLexique(sEtiquette) ;
            CodeMsg.SetPluriel(sPluriel) ;
            CodeMsg.SetCertitude(sCertitude) ;
            CodeMsg.SetComplement(sComplement) ;
            CodeMsg.SetUnit(sUnit) ;

            ajoutePatho(sEtiquette, &CodeMsg, Colonne, ligne) ;

            ligne = 0 ;
            Colonne++ ;
          }
        }
      }
      else
      {
        int ligne = 1 ;        // Ins�rer les �l�ments d'une �tiquette multiple dans le m�me noeud        if (iterpVectMulti != pVectEtiqMulti->end())
        {
          string sEtiquette  = (*iterpVectMulti)->sItem ;
          string sCertitude  = "" ;
          string sPluriel    = "" ;
          string sComplement = "" ;
          string sUnit       = "" ;

          iterpVectMulti++ ;

          if ((sEtiquette[0] == '2') && (iterpVectMulti != pVectEtiqMulti->end()))
          {
            sUnit      = sEtiquette ;
            sEtiquette = (*iterpVectMulti)->sItem ;
            iterpVectMulti++ ;
          }

          if (iterpVectMulti != pVectEtiqMulti->end())          {
            bool bTourner = true ;

            while (bTourner)            {
              string sSuite = (*iterpVectMulti)->sItem ;
              if (sSuite != "")
              {
                if      (string(sSuite, 0, 1) == string("$"))
                  sComplement = string(sSuite, 1, strlen(sSuite.c_str())-1) ;
                else if (string(sSuite, 0, 3) == string("WCE"))
                  sCertitude = sSuite ;
                else if (string(sSuite, 0, 3) == string("WPL"))
                  sPluriel = sSuite ;
                else
                  bTourner = false ;
              }
              else
                bTourner = false ;

              if (bTourner)              {                iterpVectMulti++ ;
                if (iterpVectMulti == pVectEtiqMulti->end())
                  bTourner = false ;
              }
            }
          }

          Message CodeMsg ;
          CodeMsg.SetLexique(sEtiquette) ;
          CodeMsg.SetPluriel(sPluriel) ;
          CodeMsg.SetCertitude(sCertitude) ;
          CodeMsg.SetComplement(sComplement) ;
          CodeMsg.SetUnit(sUnit) ;

          ajoutePatho(sEtiquette, &CodeMsg, Colonne, ligne) ;

          ligne = 0 ;
          Colonne++ ;        }
      }
      iterpVect++ ;
      delete pVectEtiqMulti ;
    }
*/
} // try
catch (...)
{
	erreur("Exception NSPatPathoArray AjouterChemin 1.", standardError, 0) ;
}
}

//-------------------------------------------------------------------// ajoute un chemin � une patpatho
//-------------------------------------------------------------------
void
NSPatPathoArray::AjouterChemin(string sChaine, Message* pMessage, bool bEcraser, string separateur)
{
try
{
	if (NULL == pMessage)
		return ;

	int Colonne = 0 ;
	int ColonnePere ;
	PatPathoIter suivant = end() ;
	bool sSuivant = false ;

	string sValeur = pMessage->GetLexique() ;

	//
	//chercher l'it�rateur dans pPatPath correspondant au dernier item
	//de la plus grande sous cha�ne de sChaine.
	//
	//
	string sousChaine ; //plus grande sous chaine de sChaine repr�sntant un chemin
   						        //dans pPatPath
	PatPathoIter iter = ChaineDansPatpatho(sChaine, &sousChaine, separateur) ;
	bool bChaineDansPatpatho = false ;
	string sChaineInsertion = "" ; //cha�ne � ins�rer

	//
	//exemple : sChaine = "AVGCA1|QCINE1|QCOVG1"
	//				sValeur = "1DIMI1"
	//          iter -> QCINE1
	//          sousChaine = "AVGCA1|QCINE1"
	//				sChaineInsertion = "QCOVG1|1DIMI1"

	if (sousChaine == sChaine)
		sChaineInsertion = "" ;
	else
	{
		bEcraser = false ;
		if (sousChaine != "")
		{
    	int i = strlen(sousChaine.c_str()) ;
      sChaineInsertion = string(sChaine, i + 1, strlen(sChaine.c_str()) - (i + 1)) ;
  	}
    else    	sChaineInsertion = sChaine ;
	}

	// La cha�ne m�re existe d�j� dans la patpatho
	//
	if ((iter != end()) && (iter != NULL))
	{
  	ColonnePere = (*iter)->getColonne() ;
    Colonne = ColonnePere + 1 ;
    bChaineDansPatpatho = true ;
    if (bEcraser) //�craser ce qui vient apr�s iter
    {
    	PatPathoIter suppr = begin() ;
      suppr = iter ;
      if (suppr != end())
      	suppr++ ;
      if (suppr != end())
      {
      	if ((*suppr)->getColonne() > ((*iter)->getColonne()))
        	SupprimerItem(suppr) ;
      }
      suivant = begin() ;
      suivant = iter ;
      if (suivant != end())
      	suivant++ ;
    }
    else
    	suivant = ChercherItem(iter) ; //le premier fr�re de iter
	}

	if ((suivant != end()) && (NULL != suivant))
		sSuivant = true ;

	// D�composition de la chaine m�re en fils
	//
	if (sChaineInsertion != "")
	{
  	ClasseStringVector Vect ;
    DecomposeChaine(&sChaineInsertion, &Vect, separateur) ;
    iterString iterpVect = Vect.begin() ;

    // Ajout de ces fils � la patpatho
    //
		while (iterpVect != Vect.end())
		{
    	//traiter le cas des �tiquettes multiples
      ClasseStringVector VectEtiqMulti ;
      DecomposeChaine(&(*iterpVect)->sItem, &VectEtiqMulti, "/") ;
      iterString iterpVectMulti = VectEtiqMulti.begin() ;
      int TailleEtiquette = VectEtiqMulti.size() ;

      // La cha�ne m�re existait d�j� dans la patpatho
      //
      if (bChaineDansPatpatho)
      {
      	// Si on ins�re dans une patpatho
        //
        if (sSuivant)
        {
        	PatPathoIter jter = begin() ;
          jter = suivant ;
          for ( ; jter != end(); jter++)
          	(*jter)->setLigne((*jter)->getLigne() + TailleEtiquette) ;

          //ins�rer les �l�ments d'une �tiquette multiple sur la m�me ligne
          for (; iterpVectMulti != VectEtiqMulti.end(); iterpVectMulti++)
          {
          	ajoutePatho(suivant, (*iterpVectMulti)->sItem, Colonne, -1) ;
            Colonne++ ;
            if (suivant != end())
            	suivant++;
            if (suivant != end())
            	sSuivant = true ;
            else
            	sSuivant = false ;
          }
        }
        //
        // Si on ajoute � la fin
        //
        else
        {
          //ins�rer les �l�ments d'une �tiquette multiple sur la m�me ligne
          for (; iterpVectMulti != VectEtiqMulti.end(); iterpVectMulti++)
          {          	ajoutePatho((*iterpVectMulti)->sItem, Colonne) ;
            Colonne++ ;
          }
        }
      }
      //
      // Sinon on ajoute � la fin
      //
      else
      {
        //ins�rer les �l�ments d'une �tiquette multiple sur la m�me ligne
        for (; iterpVectMulti != VectEtiqMulti.end(); iterpVectMulti++)
        {
        	ajoutePatho((*iterpVectMulti)->sItem, Colonne) ;
          Colonne++ ;
        }
      }
      iterpVect++ ;
    }
	}
	//
  // Ajout de notre message
  //
  // La cha�ne m�re existait d�j� dans la patpatho
  //
  if (bChaineDansPatpatho)
	{
  	// Si on ins�re dans une patpatho
    //
    if (sSuivant)
    {
    	PatPathoIter jter = begin() ;
      jter = suivant ;
      for ( ; jter != end(); jter++)
      	(*jter)->setLigne((*jter)->getLigne() + 1) ;

      ajoutePatho(suivant, sValeur, pMessage, Colonne , -1) ;
    }
    //
    // Si on ajoute � la fin
    //
    else
      ajoutePatho(sValeur, pMessage, Colonne) ;
  }
  //
  // Sinon on ajoute � la fin
  //
  else
  {
    ajoutePatho(sValeur, pMessage, Colonne) ;
    Colonne++ ;
	}
} // try
catch (...)
{
	erreur("Exception NSPatPathoArray AjouterChemin 2.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------// pPatPatho est une sous patpatho de this form�e par des pathos dont l'int�ret
// est >= sImportance. Exemple si sImportance coorrespond � 3+ ,
// mettre dans pPatPatho tous les �l�ments ayant pour int�ret "D" et ""
//-------------------------------------------------------------------------
void
NSPatPathoArray::donnePatpatho(NSPatPathoArray* pPatNew, string sImportance)
{
try
{
  if ((empty()) || (NULL == pPatNew))
    return ;
	//
	// Prendre l'int�ret >= sImportance
	// trouver un �l�ment dont l'int�ret est sImportance
	//

  //recopier this sans son premier �l�ment dans pPatPathoArray
  PatPathoIter iter = begin() ;
  NSPatPathoArray PatPathoArray(pContexte) ;
  ExtrairePatPatho(iter, &PatPathoArray) ;

  PatPathoIter element = PatPathoArray.begin() ; //patho � ins�rer
  int NewligneEnCours = 0 ;

	while (element != PatPathoArray.end())
  {
    int ligne = (*element)->getLigne() ;
    //
    // Si le noeud ou un de ses fils a au moins l'importance voulue
    //
    if (PatPathoArray.InteretFils(element, sImportance))
    {
      pPatNew->ajoutePatho(element, NewligneEnCours, (*element)->getColonne()) ;
      element++ ;
      //
      // On ajoute tous les �l�ments de la m�me ligne
      //
      while ((element != PatPathoArray.end()) && ((*element)->getLigne() == ligne))
      {
        pPatNew->ajoutePatho(element, NewligneEnCours, (*element)->getColonne()) ;
        element++ ;
      }
      NewligneEnCours++;
    }
    else
      element++ ;
  }
} // try
catch (...)
{
	erreur("Exception NSPatPathoArray donnePatpatho.", standardError, 0) ;
}
}

//--------------------------------------------------------------------// Retourner true si l'int�ret de iterPere ou l'un de ses descendants
// est >= sImportance
//
// ATTENTION : si sImportance est vide (""), on retourne toujours false
//
//--------------------------------------------------------------------
bool
NSPatPathoArray::InteretFils(PatPathoIter iterPere, string sImportance)
{
	if ((empty()) || (iterPere == NULL) || (iterPere == end()))
    	return false ;

	if (sImportance == "")
    	return false ;

    string sInteretPere = (*iterPere)->getInteret() ;
   	if (sInteretPere >= sImportance)
   		return true ;

	PatPathoIter iter = begin() ;
   	int ligne   = (*iterPere)->getLigne() ;
   	int colonne = (*iterPere)->getColonne() ;
   	iter = iterPere ;

   	if (iter != end())
   		iter++ ;

   	bool continuer = true ;
    while ((iter != end()) && continuer)
   	{
   		string sInteret = (*iter)->getInteret() ;
      	int ligneFils   = (*iter)->getLigne() ;
   		int colonneFils = (*iter)->getColonne() ;
      	if ((ligneFils >= ligne) && (colonneFils > colonne))
      	{
         	if (sInteret >= sImportance)
	      		return true ;
         	iter++ ;
      	}
      	else
      		continuer = false ; //on n'est plus sur les fils
   	}
   	return false ;
}

//-------------------------------------------------------------------// pPatNew est une sous patpatho de this
//-------------------------------------------------------------------
void
NSPatPathoArray::SousPatpatho(NSPatPathoArray* pPatNew, string sChaine,
                              string sValeur, string separateur)
{
try
{
	if ((NULL == pPatNew) || (pPatNew->empty()))
		return ;

  int Colonne = 0 ;
  int ColonnePere ;
  string sEtiquette ;
  PatPathoIter suivant = pPatNew->end() ;
  bool sSuivant = false ;
  //
  // Chercher l'it�rateur dans pPatPath correspondant au dernier item
  // de la plus grande sous cha�ne de sChaine.
  //
  string sousChaine ;  // Plus grande sous chaine de sChaine repr�sentant
                       // un chemin dans pPatPath
  PatPathoIter iter = pPatNew->ChaineDansPatpatho(sChaine, &sousChaine, separateur) ;
  bool bChaineDansPatpatho = false ;
  string sChaineInsertion = "" ; //cha�ne � ins�rer
  //
  //exemple : sChaine = "AVGCA1/QCINE1/QCOVG1"
  //				sValeur = "1DIMI1"
  //          iter -> QCINE1
  //          sousChaine = "AVGCA1/QCINE1"
  //				sChaineInsertion = "QCOVG1/1DIMI1"
  if (sousChaine == sChaine)
    sChaineInsertion = sValeur ;
  else
  {
    if (sousChaine != "")
    {
      int i = strlen(sousChaine.c_str()) ;
      sChaineInsertion = string(sChaine, i + 1, strlen(sChaine.c_str()) - (i + 1))
      							+ separateur + sValeur;
    }
    else
    {
      if (sValeur != "")
        sChaineInsertion = sChaine + separateur + sValeur ;
      else
        sChaineInsertion = sChaine ;
    }
  }
  if ((iter != pPatNew->end()) && (iter != NULL))
  {
    ColonnePere = (*iter)->getColonne() ;
    // LignePere   = (*iter)->getLigne() ;
    sEtiquette  = (*iter)->getLexique() ;
    Colonne = ColonnePere + 1 ;
    bChaineDansPatpatho = true ;
    suivant = pPatNew->ChercherItem(iter) ; //le premier fr�re de iter
  }

  if ((suivant != pPatNew->end()) && (suivant != NULL))
    sSuivant = true ;

  ClasseStringVector* pVect = new ClasseStringVector ;  DecomposeChaine(&sChaineInsertion, pVect, separateur) ;

  if (!(pVect->empty()))
  {
    iterString iterpVect = pVect->begin() ;
    Message* pMessage = new Message ;

    while (iterpVect != pVect->end())
    {
      //traiter le cas des �tiquettes multiples
      ClasseStringVector* pVectEtiqMulti = new ClasseStringVector ;
      DecomposeChaine(&(*iterpVect)->sItem, pVectEtiqMulti, "/") ;
      iterString  iterpVectMulti  = pVectEtiqMulti->begin() ;
      int TailleEtiquette = pVectEtiqMulti->size() ;
      if (bChaineDansPatpatho)
      {
        if (sSuivant)
        {
          PatPathoIter jter = pPatNew->begin() ;
          jter = suivant ;
          for ( ; jter != pPatNew->end(); jter++)
            (*jter)->setLigne((*jter)->getLigne() + TailleEtiquette) ;
                    //ins�rer les �l�ments d'une �tiquette multiple sur la m�me ligne
                    if (!(pVectEtiqMulti->empty()))
                    {
                        iterpVectMulti  = pVectEtiqMulti->begin() ;
                        string sItem = (*iterpVectMulti)->sItem ;
                        PatPathoIter fils = ChercherItem(sChaine + "/" + sItem, "/") ;
                        if ((fils != end()) && (fils != NULL))
                        {
                            pMessage->SetComplement((*fils)->getComplement()) ;
                            pMessage->SetCertitude((*fils)->getCertitude()) ;
                            pMessage->SetInteret((*fils)->getInteret()) ;
                            pMessage->SetPluriel((*fils)->getPluriel()) ;
                            pMessage->SetUnit((*fils)->getUnit()) ;
                            pMessage->SetVisible((*fils)->getVisible()) ;
                            pMessage->SetTexteLibre((*fils)->getTexteLibre()) ;
                            pMessage->SetNodeRight((*fils)->getNodeRight());
                        }
                        pPatNew->ajoutePatho(suivant, (*iterpVectMulti)->sItem,
                                             pMessage, Colonne , -1);

                        if ((suivant != pPatNew->end()) && (suivant != NULL))
                            suivant++;
                        if (suivant != pPatNew->end())
                            sSuivant = true;
                        else
                            sSuivant = false;
                    }
                }
                else
                {
                    //ins�rer les �l�ments d'une �tiquette multiple sur la m�me ligne
                    if (!(pVectEtiqMulti->empty()))
                    {
                        iterpVectMulti  = pVectEtiqMulti->begin() ;
                        string sItem = (*iterpVectMulti)->sItem ;
                        PatPathoIter fils = ChercherItem(sChaine + "/" + sItem, "/") ;
                        if ((fils != end()) && (fils != NULL))
                        {
                            pMessage->SetUnit((*fils)->getUnit()) ;
                            pMessage->SetComplement((*fils)->getComplement()) ;
                            pMessage->SetCertitude((*fils)->getCertitude()) ;
                            pMessage->SetInteret((*fils)->getInteret()) ;
                            pMessage->SetPluriel((*fils)->getPluriel()) ;
                            pMessage->SetVisible((*fils)->getVisible()) ;
                            pMessage->SetTexteLibre((*fils)->getTexteLibre()) ;
                            pMessage->SetNodeRight((*fils)->getNodeRight());
                        }
                        pPatNew->ajoutePatho((*iterpVectMulti)->sItem, pMessage,
                                             Colonne);
                    }
                }
            }
            else
            {
                string sItem;
                //ins�rer les �l�ments d'une �tiquette multiple sur la m�me ligne
                if (!(pVectEtiqMulti->empty()))
                {
                    iterpVectMulti  = pVectEtiqMulti->begin() ;
                    sItem = (*iterpVectMulti)->sItem;
                    PatPathoIter fils = ChercherItem(sChaine + "/" + sItem, "/");
                    if ((fils != end()) && (fils != NULL))
                    {
                        pMessage->SetUnit((*fils)->getUnit()) ;
                        pMessage->SetComplement((*fils)->getComplement()) ;
                        pMessage->SetCertitude((*fils)->getCertitude()) ;
                        pMessage->SetInteret((*fils)->getInteret()) ;
                        pMessage->SetPluriel((*fils)->getPluriel()) ;
                        pMessage->SetVisible((*fils)->getVisible()) ;
                        pMessage->SetTexteLibre((*fils)->getTexteLibre()) ;
                        pMessage->SetNodeRight((*fils)->getNodeRight());
                    }
                    pPatNew->ajoutePatho((*iterpVectMulti)->sItem, pMessage, Colonne) ;
                    Colonne++;
                }
            }
            iterpVect++;
            delete pVectEtiqMulti;
        }
        delete pMessage;
    }
    delete pVect;
} // try
catch (...)
{
	erreur("Exception NSPatPathoArray SousPatpatho.", standardError, 0) ;
}
}

string
NSPatPathoArray::donneCheminItem(PatPathoIter iter)
{
	string sChemin = "" ;

	if (empty())
		return sChemin ;
	if ((iter == NULL) || (iter == end()) || (iter == begin()))
		return sChemin ;

	int iCurCol = (*iter)->getColonne() ;
	int iCol    = 0 ;

	iter-- ;

	while (iter != begin())
	{
		iCol = (*iter)->getColonne() ;
		if (iCol < iCurCol)
    {
    	string sNode = (*iter)->getLexique() ;
      if ((*iter)->getCertitude() != "")
      	sNode += string(1, cheminSeparationMARK) + (*iter)->getCertitude() ;

      if (sChemin == "")
      	sChemin = sNode ;
      else
      	sChemin = sNode + string(1, cheminSeparationMARK) + sChemin ;

      iCurCol = iCol ;
    }
    iter-- ;
	}

	iCol = (*iter)->getColonne() ;
	if (iCol < iCurCol)
	{
  	string sNode = (*iter)->getLexique() ;
    if ((*iter)->getPluriel() != "")
    	sNode += string(1, cheminSeparationMARK) + (*iter)->getPluriel() ;
    if ((*iter)->getCertitude() != "")
    	sNode += string(1, cheminSeparationMARK) + (*iter)->getCertitude() ;

    if (sChemin == "")
    	sChemin = sNode ;
    else
    	sChemin = sNode + string(1, cheminSeparationMARK) + sChemin ;
	}

	return sChemin ;
}

// This algorithm makes no arbitration; if needed, it must be done separately
//
void
NSPatPathoArray::mergePatpatho(NSPatPathoArray* pMergingPpt, PatPathoIter* pLocalFatherIter)
{
	if ((NULL == pMergingPpt) || (pMergingPpt->empty()))
		return ;

	PatPathoIter itThis ;

  if (NULL == pLocalFatherIter)
  {
  	if (empty())
    {
    	*this = *pMergingPpt ;
      return ;
    }
		itThis = begin() ;
  }
	else
  {
		itThis = ChercherPremierFils(*pLocalFatherIter) ;
    if ((NULL == itThis) || (end() == itThis))
    {
    	InserePatPathoFille(*pLocalFatherIter, pMergingPpt) ;
      return ;
    }
	}

	PatPathoIter itInput = pMergingPpt->begin() ;
	while (itInput != pMergingPpt->end())
	{
  	PatPathoIter itInputFirstChild = pMergingPpt->ChercherPremierFils(itInput) ;

    // Not a leaf for input patho
    //
    if ((NULL != itInputFirstChild) && (pMergingPpt->end() != itInputFirstChild))
    {
    	bool bLookingForSameBranch = true ;
      PatPathoIter itLocal = itThis ;
    	while ((itLocal != end()) && bLookingForSameBranch)
      {
    		if ((*itInput)->sameContent(*itLocal))
        {
        	NSPatPathoArray subPPT(pContexte) ;
        	pMergingPpt->ExtrairePatPatho(itInput, &subPPT) ;

          // recursive call
          //
          if (!(subPPT.empty()))
          	mergePatpatho(&subPPT, &itLocal) ;

        	bLookingForSameBranch = false ;
        }
        else
        	itLocal = ChercherFrere(itLocal) ;
      }

      // not found: just add
      //
      if (bLookingForSameBranch)
      {
      	NSPatPathoArray subPPT(pContexte) ;
        pMergingPpt->ExtrairePatPatho(itInput, &subPPT) ;

        NSPatPathoArray toInsertPPT(pContexte) ;
        toInsertPPT.ajoutePatho(itInput, 0, 0) ;
        toInsertPPT.InserePatPathoFille(toInsertPPT.begin(), &subPPT) ;

        InserePatPathoFille(*pLocalFatherIter, &toInsertPPT) ;
      }
    }
    // We are on a leaf for input patho
    //
    else
    {
    	bool bLookingForSameBranch = true ;
      PatPathoIter itLocal = itThis ;
    	while ((itLocal != end()) && bLookingForSameBranch)
      {
      	PatPathoIter itLocalFirstChild = ChercherPremierFils(itLocal) ;

        // First case: local node is also a leaf
        //
        if ((end() == itLocalFirstChild) || (NULL == itLocalFirstChild))
        {
      		// If not equal, either add or replace value
        	//
    			if (!((*itInput)->sameContent(*itLocal)))
      		{
        		// The only case where we replace the node is when we find the same
          	// concept, the same unit, the same certitude and plural
      			if (((*itInput)->getLexiqueSens(pContexte)   == (*itLocal)->getLexiqueSens(pContexte))   &&
            	  ((*itInput)->getCertitudeSens(pContexte) == (*itLocal)->getCertitudeSens(pContexte)) &&
            	  ((*itInput)->getPlurielSens(pContexte)   == (*itLocal)->getPlurielSens(pContexte))   &&
            	  ((*itInput)->getTexteLibre() == string("")))
            {
            	// Same unit, we replace
              //
            	if ((*itInput)->getUnitSens(pContexte) == (*itLocal)->getUnitSens(pContexte))
              	(*itLocal)->getOtherNodeContent(*itInput) ;
              //
              // Different unit, we add
              //
              else
              {
              	NSPatPathoArray toInsertPPT(pContexte) ;
        				toInsertPPT.ajoutePatho(itInput, 0, 0) ;
        				InserePatPathoFille(*pLocalFatherIter, &toInsertPPT) ;
              }
              bLookingForSameBranch = false ;
            }
      		}
        	// If equal, do nothing
        	//
        	else
        		bLookingForSameBranch = false ;
        }
        // Second case: local node is not a leaf (means you can't modify it)
        //
        else
        {
        	if ((*itInput)->sameContent(*itLocal))
          	bLookingForSameBranch = false ;
        }

        if (bLookingForSameBranch)
        	itLocal = ChercherFrere(itLocal) ;
      }

      // not found: just add
      //
      if (bLookingForSameBranch)
      {
        NSPatPathoArray toInsertPPT(pContexte) ;
        toInsertPPT.ajoutePatho(itInput, 0, 0) ;
        InserePatPathoFille(*pLocalFatherIter, &toInsertPPT) ;
      }
    }

    // Switching to next node on the same column
    //
    itInput = pMergingPpt->ChercherFrere(itInput) ;
  }
}

//---------------------------------------------------------------------------//taille d'une patpatho : les �l�ments d'une m�me ligne comptent pour un seul �l�ment
//---------------------------------------------------------------------------
int
NSPatPathoArray::Taille()
{
   	if (empty())
   		return 0 ;

    int taille = 1 ;

   	if (size() == 1)
   		return 1 ;
   	else
   	{
   		//taille de la patpatho
   		PatPathoIter itFils    = begin() ;
   		PatPathoIter suivant   = begin() ;
        if (suivant != end())
   			suivant++ ;
   		while(suivant != end())
   		{
   			if((*suivant)->getLigne() != (*itFils)->getLigne())
      			taille++ ;
      		itFils = suivant ;
      		suivant++ ;
   		}
	}
   	return taille ;
}
//---------------------------------------------------------------------------//ajout d'un �l�ment � la patpatho juste avant l'�l�ment iterAvant
//---------------------------------------------------------------------------
void
NSPatPathoArray::ajoutePatho(PatPathoIter iterAvant, string sEtiquette,
			                 int colonne, int decalageLigne)
{
try
{
  if ((sEtiquette == "") || (colonne < 0))
    return ;

  NSPatPathoInfo* pPatPatho = new NSPatPathoInfo() ;
  pPatPatho->setLexique(sEtiquette) ;
  strcpy(pPatPatho->pDonnees->noeud,      "") ;
  strcpy(pPatPatho->pDonnees->complement, "") ;
  strcpy(pPatPatho->pDonnees->certitude,  "") ;
  strcpy(pPatPatho->pDonnees->interet,    "A") ;
  strcpy(pPatPatho->pDonnees->pluriel,    "") ;
  strcpy(pPatPatho->pDonnees->visible,    "") ;
  strcpy(pPatPatho->pDonnees->unit,       "") ;
  pPatPatho->setTexteLibre("") ;
  pPatPatho->setArchetype("") ;  pPatPatho->setNodeRight("");  pPatPatho->setColonne(colonne) ;

  int ligne ;

  if (empty())
  {
    ligne = decalageLigne ;
    push_back(pPatPatho) ;
  }
  else if ((iterAvant == end()) || (iterAvant == NULL))
  {
    PatPathoIter iter = end() ;
    iter-- ;
    ligne = (*iter)->getLigne() + decalageLigne ;
    push_back(pPatPatho) ;
  }
  else
  {
    ligne = (*iterAvant)->getLigne() + decalageLigne ;
    pPatPatho->setLigne(ligne) ;
    insert(iterAvant, pPatPatho) ;

    // D�calage des lignes suivantes
    if (decalageLigne >= 0)
    {
      PatPathoIter iter = iterAvant ;
      iter++ ;
      for ( ; iter != end(); iter++)
        (*iter)->setLigne((*iter)->getLigne() + decalageLigne + 1) ;
    }
  }
} // try
catch (...)
{
	erreur("Exception NSPatPathoArray ajoutePatho 1.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//ajout d'un �l�ment � la patpatho en changeant ses coordonn�es
//---------------------------------------------------------------------------
void
NSPatPathoArray::ajoutePatho(PatPathoIter iter, int ligne, int colonne)
{
try
{
	if ((iter == NULL) || (iter == end()))
		return ;

	NSPatPathoInfo* pPatPatho = new NSPatPathoInfo() ;
	*(pPatPatho->pDonnees) = *((*iter)->pDonnees) ;
	pPatPatho->setLigne(ligne) ;
	pPatPatho->setColonne(colonne) ;
	push_back(pPatPatho) ;
} // trycatch (...)
{
	erreur("Exception NSPatPathoArray ajoutePatho 2.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
// Ajout d'un �l�ment � la patpatho en cours avant iterAvant
// pMessage contient les donn�es patpatho sauf le champ lexique qui, lui,
// est contenu dans sEtiquette
//---------------------------------------------------------------------------
void
NSPatPathoArray::ajoutePatho(PatPathoIter iterAvant, string sEtiquette,
                   Message* pMessage, int colonne, int decalageLigne,
                   bool bPushBlock)
{
try
{
  NSPatPathoInfo* pPatPatho = new NSPatPathoInfo() ;
  pPatPatho->setLexique(sEtiquette) ;

  // Pr�caution pas toujours inutile : si le noeud est compos�, ne pas faire
  // d�border pDonnees->noeud ou pDonnees->treeID
  strncpy(pPatPatho->pDonnees->treeID, pMessage->GetTreeID().c_str(), OBJECT_ID_LEN) ;
  pPatPatho->pDonnees->treeID[OBJECT_ID_LEN] = '\0' ;

  strncpy(pPatPatho->pDonnees->noeud, pMessage->GetNoeud().c_str(), PPD_NOEUD_LEN);
  pPatPatho->pDonnees->noeud[PPD_NOEUD_LEN] = '\0';

  if (pMessage)
  {
    pPatPatho->setComplement(pMessage->GetComplement()) ;
    pPatPatho->setCertitude(pMessage->GetCertitude()) ;
    pPatPatho->setInteret(pMessage->GetInteret()) ;
    pPatPatho->setPluriel(pMessage->GetPluriel()) ;
    pPatPatho->setVisible(pMessage->GetVisible()) ;
    pPatPatho->setUnit(pMessage->GetUnit()) ;
    pPatPatho->setTexteLibre(pMessage->GetTexteLibre()) ;
    pPatPatho->setArchetype(pMessage->GetArchetype()) ;    pPatPatho->setNodeRight(pMessage->GetNodeRight()) ;    if (pMessage->GetTemporaryLinks())      pPatPatho->pTemporaryLinks = new NSLinkedNodeArray(*(pMessage->GetTemporaryLinks())) ;  }  pPatPatho->setColonne(colonne) ;

  // Si on ins�re avant un v�ritable �l�ment
  //
  if (end() != iterAvant)
  {
    int ligne = (*iterAvant)->getLigne() ;
    pPatPatho->setLigne(ligne + decalageLigne) ;

    if (bPushBlock)
    {
      PatPathoIter jter = begin() ;
      jter = iterAvant ;
      for ( ; jter != end(); jter++)
        (*jter)->setLigne((*jter)->getLigne() + 1) ;
    }

    insert(iterAvant, pPatPatho) ;
  }
  // Si on ins�re avant la fin (alors on ins�re � la fin)  //
  else
  {
    int ligne = -1 ;
    if (false == empty())
    {
      // On se place sur le dernier noeud
      iterAvant-- ;
      ligne = (*iterAvant)->getLigne() ;
    }
    pPatPatho->setLigne(ligne + decalageLigne) ;
    push_back(pPatPatho) ;
    // On se replace sur end()
    iterAvant = end() ;
  }
} // try
catch (...)
{
	erreur("Exception NSPatPathoArray ajoutePatho 3.", standardError, 0) ;
}
}

void
NSPatPathoArray::parseBlock(string sNodeBlock, Message* pMessage)
{
  if (NULL == pMessage)
    return ;

  pMessage->Reset() ;

  if (string("") == sNodeBlock)
    return ;

  ClasseStringVector VectEtiqMulti ;
  DecomposeChaine(&sNodeBlock, &VectEtiqMulti, string(1, intranodeSeparationMARK)) ;
  if (VectEtiqMulti.empty())
    return ;

  iterString iterpVectMulti = VectEtiqMulti.begin() ;

  string sEtiquette   = (*iterpVectMulti)->sItem ;
  string sCertitude   = string("") ;
  string sPluriel     = string("") ;
  string sComplement  = string("") ;
  string sUnit        = string("") ;

  iterpVectMulti++ ;

  if ((sEtiquette[0] == '2') && (VectEtiqMulti.end() != iterpVectMulti))
  {
    sUnit      = sEtiquette ;
    sEtiquette = (*iterpVectMulti)->sItem ;
    iterpVectMulti++ ;
  }

  if (VectEtiqMulti.end() != iterpVectMulti)
  {
    bool bTourner = true ;

    while (bTourner)
    {
      string sSuite = (*iterpVectMulti)->sItem ;
      if (string("") != sSuite)
      {
        if      (string(sSuite, 0, 1) == string("$"))
          sComplement = string(sSuite, 1, strlen(sSuite.c_str())-1) ;
        else if (string(sSuite, 0, 3) == string("WCE"))
          sCertitude = sSuite ;
        else if (string(sSuite, 0, 3) == string("WPL"))
          sPluriel = sSuite ;
        else
          bTourner = false ;
      }
      else
        bTourner = false ;

      if (bTourner)
      {
        iterpVectMulti++ ;
        if (VectEtiqMulti.end() == iterpVectMulti)
          bTourner = false ;
      }
    }
  }

  // Make certain codes are true codes and not semantic codes
  //
  pContexte->getDico()->donneCodeComplet(sEtiquette) ;
  pContexte->getDico()->donneCodeComplet(sUnit) ;
  pContexte->getDico()->donneCodeComplet(sCertitude) ;
  pContexte->getDico()->donneCodeComplet(sPluriel) ;

  pMessage->SetLexique(sEtiquette) ;
  pMessage->SetUnit(sUnit) ;
  pMessage->SetPluriel(sPluriel) ;
  pMessage->SetCertitude(sCertitude) ;
  pMessage->SetComplement(sComplement) ;
}

void
NSPatPathoArray::ajoutePathoBlock(string sNodeBlock, int colonne, PatPathoIter iterAvant)
{
  if (string("") == sNodeBlock)
    return ;

  Message CodeMsg ;
  parseBlock(sNodeBlock, &CodeMsg) ;

  string sEtiquette = CodeMsg.GetLexique() ;
  if (string("") == sEtiquette)
    return ;

  if (NULL != iterAvant)
    ajoutePatho(iterAvant, sEtiquette, &CodeMsg, colonne, 1) ;
  else
    ajoutePatho(sEtiquette, &CodeMsg, colonne) ;
}

//---------------------------------------------------------------------------
// Ajout du titre du compte rendu
//---------------------------------------------------------------------------
void
NSPatPathoArray::ajouteTitre(string sTitre, string sNoeud)
{
try
{
  if (sTitre == "")
    return ;

  NSPatPathoInfo* pPatPatho = new NSPatPathoInfo() ;
  pPatPatho->setLexique(sTitre) ;

  // Pr�caution pas toujours inutile : si le noeud est compos�, ne pas faire
  // d�border pDonnees->noeud
  strncpy(pPatPatho->pDonnees->noeud, sNoeud.c_str(), PPD_NOEUD_LEN) ;
  pPatPatho->pDonnees->noeud[PPD_NOEUD_LEN] = '\0' ;

  pPatPatho->setInteret("A") ;
  pPatPatho->setColonne(ORIGINE_PATH_PATHO) ;
  pPatPatho->setLigne(ORIGINE_PATH_PATHO) ;

  if (!empty())
    insert(begin(), pPatPatho) ;
  else
    push_back(pPatPatho) ;
} // try
catch (...)
{
	erreur("Exception NSPatPathoArray ajouteTitre.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------
//chercher un �l�ment dans la patpatho en cours selon son �tiquette
//-------------------------------------------------------------------------
PatPathoIter
NSPatPathoArray::ChercherItem(string sItem, bool bPrepareNext, PatPathoIter iterFrom)
{
	if ((empty()) || (sItem == ""))
		return NULL ;

	// Recherche sur le code sens ?
	//
	bool bCodeSens = false ;
	if (strlen(sItem.c_str()) < BASE_LEXI_LEN)
		bCodeSens = true ;

	PatPathoIter iterFound = end() ;
	PatPathoIter iter ;

	if (iterFrom == NULL)
		iter = begin() ;
	else
		iter = iterFrom ;

	if ((bPrepareNext) && (iter != end()))
		iter++ ;

	while (iter != end())
	{
		string sLexique = (*iter)->getLexique() ;
		if (bCodeSens)
    	pContexte->getDico()->donneCodeSens(sLexique) ;

    if (sLexique == sItem)
    {
    	iterFound = iter ;
      break ;
    }
    else
    	iter++ ;
	}

	return iterFound ;
}

//------------------------------------------------------------------------
//chercher un �l�ment dans la patpatho en cours selon son chemin
//-------------------------------------------------------------------------
PatPathoIter
NSPatPathoArray::ChercherItem(string sChemin, string separateur)
{
  string sousChaine ;
  PatPathoIter iter = ChaineDansPatpatho(sChemin, &sousChaine, separateur) ;
  return iter ;
}

//-------------------------------------------------------------------------
//chercher un �l�ment dans la patpatho en cours selon sa localisation
//-------------------------------------------------------------------------
PatPathoIter
NSPatPathoArray::ChercherItem(int ligne, int colonne)
{
	if (empty())
    	return NULL;

    PatPathoIter iter = begin();
    while(iter != end())
    {
   	    if (((*iter)->getLigne() == ligne) && ((*iter)->getColonne()  == colonne))
            return iter;
        else
      	    iter++;
    }
    return end();
}

//-------------------------------------------------------------------------
//chercher le premier fr�re de iterFrere (apr�s ce dernier) ou le premier
//�l�ment apr�s iterFrere et dont la colonne est < � celle de iterFrere
//exemple : * cas 1 (iterFrere = A)
/*            M
						A
							B
                     	C
                     D
						E
              S
              dans ce cas retourner E

             * cas 2 (iterFrere = A)
             M
             		A
                  	B
                     	C
                     D
             E
             		S

             dans ce cas retourner E
*/
//
//-------------------------------------------------------------------------
PatPathoIter
NSPatPathoArray::ChercherItem(PatPathoIter iterFrere)
{
  if ((empty()) || (iterFrere == NULL))
    return NULL ;
  if (iterFrere == end())
    return end() ;

  PatPathoIter iter = begin() ;  int ligne   = (*iterFrere)->getLigne() ;
  int colonne = (*iterFrere)->getColonne() ;

  iter = iterFrere ;
	iter++ ;
  while (iter != end())
  {
    if (((*iter)->getLigne()  > ligne) &&
            ((*iter)->getColonne() <= colonne))
      return iter ;
    else
      iter++ ;
  }
  return end() ;
}

//-------------------------------------------------------------------------
//chercher un �l�ment dans la patpatho en cours, "fils" de iterPere
//-------------------------------------------------------------------------
PatPathoIter
NSPatPathoArray::ChercherItem(string sItem, PatPathoIter iterPere)
{
	if ((empty()) || (iterPere == NULL))
		return NULL ;
	if (iterPere == end())
		return end() ;

	// Recherche sur le code sens ?
	//
	bool bCodeSens = false ;
	if (strlen(sItem.c_str()) < BASE_LEXI_LEN)
		bCodeSens = true ;

	PatPathoIter iter = begin() ;
	int ligne   = (*iterPere)->getLigne() ;
	int colonne = (*iterPere)->getColonne() ;
	iter = iterPere ;
	iter++ ;
	while ((iter != end()) && ((*iter)->getColonne() > colonne))
	{
		string sLexique = (*iter)->getLexique() ;
		if (bCodeSens)
    	pContexte->getDico()->donneCodeSens(sLexique) ;

		if (((*iter)->getLigne() > ligne  ) && (sLexique == sItem))
			return iter ;
		else
			iter++ ;
	}
	return end() ;
}

PatPathoIter
NSPatPathoArray::ChercherPere(PatPathoIter iterFils)
{
    if (empty() || (iterFils == begin()) || (iterFils == NULL))
    	return NULL;
    if (iterFils == begin())
   	    return NULL;

    PatPathoIter iter = begin();
    int colonne = (*iterFils)->getColonne();

    if (colonne == 0)
        return NULL;

    iter = iterFils;
    while (iter != begin())
    {        iter--;

        if ((*iter)->getColonne() == colonne - 1)
            return iter;
    }

    if ((*iter)->getColonne() == colonne - 1)
        return iter;
    return NULL;
}


PatPathoIterNSPatPathoArray::ChercherFrere(PatPathoIter iterFrere)
{
	if (empty() || (iterFrere == NULL))
		return NULL ;

/*
//  a priori mauvais copier/coller le frere d'un patpathoiter peut-�tre avant ou apres
    if (iterFrere == end())
   	    return end();
*/

	PatPathoIter iter = begin() ;
	int ligne   = (*iterFrere)->getLigne() ;
	int colonne = (*iterFrere)->getColonne() ;
	iter = iterFrere ;

	iter++ ;
	while ((iter != end()) && ((*iter)->getColonne() >= colonne))
	{
		if (((*iter)->getLigne() > ligne) && ((*iter)->getColonne() == colonne))
			return iter ;
		else
    	iter++ ;
	}

	return end() ;
}

PatPathoIter
NSPatPathoArray::ChercherPremierFils(PatPathoIter iterPere)
{
	if (empty() || (iterPere == NULL))
		return NULL ;
	if (iterPere == end())
		return end() ;

	PatPathoIter iter = begin() ;

	int colonne = (*iterPere)->getColonne() ;

	iter = iterPere ;
	iter++ ;

	if ((iter == end()) || ((*iter)->getColonne() != colonne + 1))
		return end() ;

	return iter ;
}

PatPathoIterNSPatPathoArray::ChercherNoeud(string sNodeId)
{
	if ((empty()) || (sNodeId == ""))
		return NULL ;

	PatPathoIter iter = begin() ;
	for (; (iter != end()) && ((*iter)->getNode() != sNodeId); iter++) ;

	return iter ;
}

//-------------------------------------------------------------------//			supprimer l'item Supprimer et tous ses descendants
// 		 		pNbSupprime : nombre d'�l�ments supprim�s
//-------------------------------------------------------------------
void
NSPatPathoArray::SupprimerItem(PatPathoIter Supprimer)
{
	if (empty())
		return ;

	if ((NULL == Supprimer) || (end() == Supprimer))
		return ;

	int NbSupprime = 1 ;
	int ligneSupprimer   = (*Supprimer)->getLigne() ;
	int colonneSupprimer = (*Supprimer)->getColonne() ;

	//
	// Enlever l'�l�ment Supprimer et tous ses descendants
	//
	PatPathoIter j = begin() ;
	j = Supprimer ;
	if (j != end())
		j++ ;

  // Deleting the sons
  //
	int lastLigne = 0 ; //derni�re ligne rencontr�e
	bool bContinuer = true ;
	while ((bContinuer) && (end() != j))
	{
  	int ligneFils = (*j)->getLigne() ;
    if (((*j)->getColonne() > colonneSupprimer) && (ligneFils >= ligneSupprimer))
    {
			if (ligneFils > lastLigne) //2 �l�ments peuvent �tre sur la m�me ligne
      	NbSupprime++ ;
      lastLigne = (*j)->getLigne() ;
      delete *j ;
      erase(j) ;
    }
    else
    	bContinuer = false ;
	}

	//	// Enlever Supprimer
  //
	delete *Supprimer ;
	erase(Supprimer) ;

	if (empty())
		return ;

	PatPathoIter element = begin() ;
	while (element != end())
	{
  	if ((*element)->getLigne() > ligneSupprimer)
    	(*element)->setLigne((*element)->getLigne() - NbSupprime ) ;
    element++ ;
	}
}

void
NSPatPathoArray::SupprimerFils(PatPathoIter iPptPere)
{
	if (empty())
    	return ;
    if ((iPptPere == NULL) || (iPptPere == end()))
        return ;

    int iColPere = (*iPptPere)->getColonne() ;

    PatPathoIter iter = iPptPere ;
    iter++ ;
    if (iter == end())
        return ;

    int iCol = (*iter)->getColonne() ;
    while ((iter != end()) && (iCol > iColPere))
    {
        SupprimerItem(iter) ;

        iter = iPptPere ;
        iter++ ;
        if (iter == end())
            return ;

        iCol = (*iter)->getColonne() ;
    }
}

//------------------------------------------------------------------//suppression d'un chemin dans une patpatho
//------------------------------------------------------------------
void
NSPatPathoArray::SupprimerChemin(string sChaine, string sValeur, string separateur )
{}

voidNSPatPathoArray::SupprimerChemin(string sChaine, string separateur)
{
	if (sChaine == "")
		return ;

	string sousChaine = "" ;
	//it�rateur correspondant au dernier �l�ment de sChaine
	PatPathoIter Supprimer = ChaineDansPatpatho(sChaine, &sousChaine) ;
	if ((Supprimer == NULL) || (Supprimer == end()))
		return ;

	int ligneSupprimer   = (*Supprimer)->getLigne() ;
	int colonneSupprimer = (*Supprimer)->getColonne() ;
	//
	// enlever l'�l�ment Supprimer et tous ses descendants
	//
	SupprimerItem(Supprimer) ;
	//supprimer �ventuellement le p�re de Supprimer
	SupprimerPere(ligneSupprimer, colonneSupprimer) ;
}

//-----------------------------------------------------------------------
//				former la localisation fil guide d'un �l�ment
//				patpatho de coordonn�es(ligneElement, colonneElement)
//			bCodeSens : mettre les codes sens ou les codes lexique
//-----------------------------------------------------------------------
void
NSPatPathoArray::FormeLocalisation(PatPathoIter Element,
                              string* pLocalisation, int ligneElement,
                              int colonneElement, bool bCodeSens, string separateur)
{
	if (empty() || (Element == NULL) || (Element == end()) || (!pLocalisation))
    	return ;

    string sCodeSens = "" ;
    PatPathoIter Temp = begin() ;
    PatPathoIter Root = begin() ;
    Root = Element ;
    bool continuer = true ;
    if ((*Element)->getColonne() == ORIGINE_PATH_PATHO)
    {
   	    if (bCodeSens)
      	    pContexte->getDico()->donneCodeSens(&((*Element)->getLexique()), &sCodeSens);
        else
      	    sCodeSens = (*Element)->getLexique() ;
        *pLocalisation = sCodeSens ; //exemple GECHY
        return ;    }

    if (continuer)
    {
   	    Temp = Element ;
   	    if (Temp == begin())
   	    {
   		    if (bCodeSens)
   			    pContexte->getDico()->donneCodeSens(&((*(begin()))->getLexique()), &sCodeSens) ;
   		    else
      		    sCodeSens = (*(begin()))->getLexique() ;
   		    *pLocalisation = sCodeSens ; //exemple GECHY
      	    return ;
   	    }
   	    Temp--;
        if (Temp == begin())
        {
      	    if (bCodeSens)
   			    pContexte->getDico()->donneCodeSens(&((*(begin()))->getLexique()), &sCodeSens) ;
   		    else
      		    sCodeSens = (*(begin()))->getLexique() ;
   		    *pLocalisation = sCodeSens ; //exemple GECHY
      	    return ;
        }
    }
    int i = 1;
    bool bPlusieursPeres = false; //chemin form� d'au moins 2 �l�ments : exemple GECHY/0CONT

    while ((Temp != begin()) && continuer)
    {
   	    if (((*Temp)->getColonne()  == (colonneElement - 1)) &&
            ((*Temp)->getLigne()    < ligneElement))
        {
            bPlusieursPeres = true;
      	    ligneElement   = (*Temp)->getLigne();
            colonneElement = (*Temp)->getColonne();

            if (bCodeSens)
         	    pContexte->getDico()->donneCodeSens(&((*Temp)->getLexique()), &sCodeSens);
            else
                sCodeSens = (*Temp)->getLexique() ;
            if (i == 1)
         	    *pLocalisation = sCodeSens ;
            else
         	    *pLocalisation = sCodeSens + separateur + *pLocalisation ;

            i++;
        }
        if ((*Temp)->getColonne() == ORIGINE_PATH_PATHO)
            continuer = false;
        else
        {
       	    Temp--;
      	    Root = Temp; //sortie
        }
    }
    if (Root == begin())
    {
   	    if (bCodeSens)
   		    pContexte->getDico()->donneCodeSens(&((*Root)->getLexique()), &sCodeSens) ;
   	    else
   		    sCodeSens = (*Root)->getLexique() ;
	    if (bPlusieursPeres)  //exemple GECHY/0CONT/0CONX
            *pLocalisation = sCodeSens + separateur + *pLocalisation ;
   	    else
   		    *pLocalisation = sCodeSens ; //exemple GECHY
    }
}

//--------------------------------------------------------------------
// supprimer le p�re de l'�l�ment de coordonn�es(ligneSupprimer, colonneSupprimer)
//						traiter le cas oas o� le p�re est actfVide ou non
//--------------------------------------------------------------------
void
NSPatPathoArray::SupprimerPere(int ligneSupprimer, int colonneSupprimer)
{
try
{
	if (empty())
    	return ;

    bool bContinuer = true ;
    PatPathoIter ancetre = begin() ; //gechy
    PatPathoIter PereSupprimer = begin() ;
    PatPathoIter iter = begin() ;
    PatPathoIter jter = begin() ;
    string sLocalisation = "" ;
    PatPathoIter autreFils = begin() ;
    //
    // commencer par chercher le p�re
    //

    bool trouve = false ;    //
    // trouver le premier candidat
    //
 	for (iter = begin(); (iter != end()) && (!trouve) ; iter++)
 	{
 		if (((*iter)->getLigne() < ligneSupprimer) &&
            ((*iter)->getColonne() == (colonneSupprimer - 1)) )
   	    {
   		    trouve = true;
      	    PereSupprimer = iter;
   	    }
    }

    // si trouv�
    if (PereSupprimer != end())
    {
        //chercher �ventuellement un autre p�re dont la ligne est < � celle du premier p�re trouv�
        jter = PereSupprimer;
        jter++;
        while (jter != end())
        {
            if (((*jter)->getLigne()    < ligneSupprimer) &&
                ((*jter)->getColonne() == (colonneSupprimer - 1)))
        	    PereSupprimer = jter;

            jter++;
        }
    }

	if ((PereSupprimer != end()) && (PereSupprimer != ancetre)) //on a trouv� le p�re
    {
        int lignePere   = (*PereSupprimer)->getLigne();
        int colonnePere = (*PereSupprimer)->getColonne();
        FormeLocalisation(PereSupprimer, &sLocalisation, lignePere, colonnePere, false, "/");

        bContinuer = true;
        //
   	    // chercher d'autres fils
        //
        autreFils = PereSupprimer;
     	autreFils++;
   	    while ((bContinuer) && (autreFils != end()))
   	    {
            if (((*autreFils)->getColonne()  > colonnePere) &&
         	    ((*autreFils)->getLigne()    > lignePere  ))
                bContinuer = false; //on a trouv� au moins un autre fils : on sort alors
            else
         	    autreFils = end();
   	    }

        if (autreFils == end())
        {
      	    //
      	    // Si le p�re de Supprimer n'a que celui_ci comme fils alors
      	    // faire une recherche s�mantique pour savoir si le p�re de Supprimer est ActifVide
      	    // ou non. sinon supprimer ce p�re. Cette �tape est r�cursive
      	    //
      	    VecteurRechercheSelonCritere* pVecteurSelonCritere = new VecteurRechercheSelonCritere(GUIDE);
      	    string sCodeSens;
      	    pContexte->getDico()->donneCodeSens(&(string((*PereSupprimer)->pDonnees->lexique)), &sCodeSens);

      	    pVecteurSelonCritere->AjouteEtiquette(sCodeSens);
      	    pContexte->getFilGuide()->chercheChemin(&sLocalisation,
                             pVecteurSelonCritere, NSFilGuide :: compReseau);

      	    //
      	    // trouver la fiche du p�re
            //
      	    bool trouve ;
      	    BBItemData* pDonnees = new BBItemData ;
      	    pContexte->getDico()->donneCodeSens(&((*PereSupprimer)->getLexique()), &sCodeSens) ;
      	    pVecteurSelonCritere->SetData(sCodeSens, &trouve, pDonnees) ;
            bool ActifVide = true;
      	    if (trouve)
      		    if (!pDonnees->actifVide())
                    ActifVide = false;

            //!trouve : pas de fiche, exemple en cas de conclusion automatique
            if (!trouve || !ActifVide)
            {
         	    delete *PereSupprimer;
                erase(PereSupprimer);
                //
                // MAJ ligbes et colonnes et des autres �l�ments patpatho
                //
                PatPathoIter element = begin();
                while ( element != end())
                {
            	    if ((*element)->getLigne() > lignePere)
	      				(*element)->setLigne((*element)->getLigne() - 1 );
                        element++;
                }
                SupprimerPere(lignePere, colonnePere);
            }
            delete pDonnees;
            delete pVecteurSelonCritere;
        }
    }
} // try
catch (...)
{
	erreur("Exception NSPatPathoArray SupprimerPere.", standardError, 0) ;
}
}

//----------------------------------------------------------------------// savoir si dans pPatpath les �l�ments de sChaine sont en relation de
// 							descendance entre eux.
//
// 				exemple sChaine : "0PREA1/A0PRM1/ABIVC1"
//----------------------------------------------------------------------
bool
NSPatPathoArray::CheminDansPatpatho(string sChaine, string separateur, PatPathoIter* pIter, PatPathoIter* pstartIter)
{
try
{
	if (pIter)
		*pIter = NULL ;

  if ((NULL != pstartIter) && (begin() != *pstartIter))
		return false ;

	if ((string("") == sChaine) || (empty()))
		return false;	ClasseStringVector Vect ;	DecomposeChaine(&sChaine, &Vect, separateur) ;

	if (Vect.empty())		return false ;	iterString iterpVect     = Vect.begin() ;	iterString iterpVectTemp = Vect.begin() ;

	PatPathoIter iterPatPath = begin() ;
	int colonneEncours ;	int colonne ;

	string sItem ;	string sCertitude ;

	//	// pour chaque �l�ment de pVect, scanner toute la patpatho, et mettre � jour les champs de
	// l'�l�ment en question :
	//									colonne = sa colonne
	//   								coche   = �l�ment d�tect� ou non;
	//   								sItem   = son lablel;
	//			(selon sa position par rapport � l �l�ment de la patpatho)
	//
	for (iterPatPath = begin(); iterPatPath != end(); iterPatPath++ )
	{
		colonneEncours = (*iterPatPath)->getColonne() ;
		for (iterpVect = Vect.begin() ; iterpVect != Vect.end(); iterpVect++)
		{
    	colonne = (*iterpVect)->colonne ;
      //d�cocher les �l�ments dont la colonne est >= colonneEncours
      if (colonne >= colonneEncours)
      	(*iterpVect)->coche = false ;
    }

    //trouver le premier �l�ment de pVect non coch�
    for (iterpVectTemp = Vect.begin() ; (iterpVectTemp != Vect.end()) &&
    	     ((*iterpVectTemp)->coche); iterpVectTemp++) ;

		if (Vect.end() != iterpVectTemp)		{
    	sItem = (*iterpVectTemp)->sItem ;
      string sCodeSens ;
      string ssItemCodeSens ;

      // on compose le noeud *iterPatPath avec ses attributs (pluriel et certitude)      //      string sEtiquette = (*iterPatPath)->getNodeLabel() ;      //
      // Si le code "Oui" a �t� pr�cis� dans la requ�te, on l'ajoute
      //
      sCertitude = (*iterPatPath)->getCertitude() ;
      if (string("") == sCertitude)
      {
      	size_t isYes = sItem.find("WCEA0") ;
        if (isYes != NPOS)
        	sEtiquette += string(1, intranodeSeparationMARK) + string("WCEA01") ;
      }

      if (pContexte)      {
      	pContexte->getDico()->donneCodeSens(&sEtiquette, &sCodeSens) ;
        pContexte->getDico()->donneCodeSens(&sItem, &ssItemCodeSens) ;
      }
      else
      {
      	ClasseStringVector Vect1 ;
        DecomposeChaine(&sEtiquette, &Vect1, string(1, intranodeSeparationMARK)) ;
        iterString iterpVect = Vect1.begin() ;
        sCodeSens = string((*iterpVect)->sItem, 0, BASE_LEXIQUE_LEN - 1) ;

        while (iterpVect != Vect1.end())        {
        	sCodeSens += string(1, intranodeSeparationMARK) + string((*iterpVect)->sItem, 0, BASE_LEXIQUE_LEN - 1) ;
          iterpVect++ ;
        }
        Vect1.vider() ;
        DecomposeChaine(&sItem, &Vect1, string(1, intranodeSeparationMARK)) ;

        iterpVect = Vect1.begin() ;
        ssItemCodeSens = string((*iterpVect)->sItem, 0, BASE_LEXIQUE_LEN - 1) ;

        while (iterpVect != Vect1.end())        {
        	ssItemCodeSens += string(1, intranodeSeparationMARK) + string((*iterpVect)->sItem, 0, BASE_LEXIQUE_LEN - 1) ;
          iterpVect++ ;
        }
      }

      if ((sCodeSens == ssItemCodeSens) || (string("�C;") == ssItemCodeSens))      {
      	(*iterpVectTemp)->colonne = (*iterPatPath)->getColonne() ;
        (*iterpVectTemp)->coche   = true ;

        //si c'est le dernier on sort        if ((*iterpVectTemp) == Vect.back())
        {
        	// on regarde si on avait un it�rateur en parametre
          if (pIter)
          	*pIter = iterPatPath ;

          return true ;        }
      }
    }
  }

	if (pIter)		*pIter = iterPatPath ;
	return false ;} // try
catch (...)
{
	erreur("Exception NSPatPathoArray CheminDansPatpatho 1.", standardError, 0) ;
	return false ;
}
}

//----------------------------------------------------------------------// savoir si dans pPatpath les �l�ments de sChaine sont en relation de
// 							descendance entre eux.
//                     pBigBoss peut �tre null
// 				exemple sChaine : "0PREA1/A0PRM1/ABIVC1"
//			  retourner �ventuellement dans sValeur la valeur chiffr�e :
//						  compl�ment de l'�l�ment patpatho
//			"correspondant � un champ �dit par exemple (fils du dernier �l�ment
//      									de sChaine)"
//                  	  ou le champ lexique de cet �l�ment
//----------------------------------------------------------------------
bool
NSPatPathoArray::CheminDansPatpatho(NSSmallBrother *pBigBoss,
                                    string sChaine, string* pValeur,
                                    string* pUnite, string separateur)
{
try
{
	if ((sChaine == "") || (empty()))
		return false;

	ClasseStringVector Vect ;	DecomposeChaine(&sChaine, &Vect, separateur) ;

	if (Vect.empty())
		return false ;

	iterString iterpVect     = Vect.begin() ;
	iterString iterpVectTemp = Vect.begin() ;

	PatPathoIter iterPatPath = begin() ;
	PatPathoIter iterValeur = begin() ;
	int colonneEncours ;
	int colonne ;
	string sItem ;
	string sEtiquette, sPluriel, sCertitude ;
	//
	// Pour chaque �l�ment de pVect, scanner toute la patpatho, et mettre � jour
	// les champs de l'�l�ment en question :
	//				                    colonne = sa colonne;
	//   								coche   = �l�ment d�tect� ou non;
	//   								sItem   = son lablel;
	//			(selon sa position par rapport � l �l�ment de la patpatho)
	//
	for (iterPatPath = begin(); iterPatPath != end(); iterPatPath++)
	{
		colonneEncours = (*iterPatPath)->getColonne() ;
		for (iterpVect = Vect.begin() ; iterpVect != Vect.end(); iterpVect++)
		{
			colonne  = (*iterpVect)->colonne ;
			// D�cocher les �l�ments dont la colonne est >= colonneEncours
			if (colonne >= colonneEncours)
				(*iterpVect)->coche = false ;
		}

		// Trouver le premier �l�ment de pVect non coch�

		for (iterpVectTemp = Vect.begin(); (iterpVectTemp != Vect.end()) &&
      				                ((*iterpVectTemp)->coche); iterpVectTemp++) ;
		if (iterpVectTemp != Vect.end())
		{
			sItem = (*iterpVectTemp)->sItem ;
			string sCodeSens ;
			string ssItemCodeSens ;

			// on compose le noeud *iterPatPath avec ses attributs (pluriel et certitude)
			sEtiquette   = (*iterPatPath)->getNodeLabel() ;

			if (pBigBoss)
			{
				NSSuper* pSup = pBigBoss->pContexte->getSuperviseur() ;
				pSup->getDico()->donneCodeSens(&sEtiquette, &sCodeSens) ;
				pSup->getDico()->donneCodeSens(&sItem, &ssItemCodeSens) ;
			}
			else if (pContexte)
			{
				pContexte->getDico()->donneCodeSens(&sEtiquette, &sCodeSens) ;
				pContexte->getDico()->donneCodeSens(&sItem, &ssItemCodeSens) ;
			}
			else
			{
				NSDico Dico(NULL) ;
				Dico.donneCodeSens(&sEtiquette, &sCodeSens) ;
				Dico.donneCodeSens(&sItem,      &ssItemCodeSens) ;
			}

			// s'il y a �galit� des deux �l�ments
			if (sCodeSens == ssItemCodeSens)
			{
				(*iterpVectTemp)->colonne = (*iterPatPath)->getColonne() ;
				(*iterpVectTemp)->coche = true ;
        //
				// Si c'est le dernier on a trouv�
        //
				if ((*iterpVectTemp) == Vect.back())
				{
        	if (NULL == pValeur)
          	return true ;

					// Si c'est un code, on regarde tout de suite s'il a un complement
					if (pContexte && (pContexte->getFilGuide()->Prend()) && (pContexte->getFilGuide()->VraiOuFaux(sCodeSens, "ES", "0CODE")))
					{
						*pValeur = (*iterPatPath)->getComplement() ;
            if (string("") != *pValeur)
              return true ;
					}
					//
					// Chercher �ventuellement le fils de iterpVectTemp ayant
					// une valeur chiffr�e
					//
					iterValeur = iterPatPath ;
					if (end() != iterValeur)
						iterValeur++ ;

					if (end() != iterValeur)
					{
						//
            // Si valeur non chiffr�e prendre iterValeur lui m�me
            // sinon le compl�ment contenu dans �N0;0..
            //
            string sLexique = (*iterValeur)->getLexique() ;

						if ('�' == sLexique[0])
						{
            	if (string("�CL") == string(sLexique, 0, 3))
              	*pValeur = (*iterValeur)->getTexteLibre() ;
              else
              {
								*pValeur = (*iterValeur)->getComplement() ;
								if (pUnite)
									*pUnite = (*iterValeur)->getUnit() ;
              }
            }
            else
            {
            	*pValeur = sLexique ;
              if (pUnite)
              	*pUnite = "" ;
            }
					}
          return true ;
				}
			}
		}
	}
	if (NULL != pValeur)
		*pValeur = "" ;

	return false ;
} // try
catch (...)
{
	erreur("Exception NSPatPathoArray CheminDansPatpatho 2.", standardError, 0) ;
	return false;
}
}

//----------------------------------------------------------------------
// Savoir si dans pPatpath les �l�ments du VecteurItem sont en relation de
// descendance entre eux, sans que la chaine ne comporte d'interdit.
//----------------------------------------------------------------------
bool
NSPatPathoArray::CheminSemantiqueDansPatpatho(PatPathoIter* pIter, VecteurItem* pVecEquivalents, VectString* /* pInterdits */)
{
try
{
	*pIter = NULL ;

	if ((NULL == pVecEquivalents) || (pVecEquivalents->empty()) || (empty()))
		return false ;  //  // Fabrication du vecteur qui nous permet de suivre o� on en est  //  ClasseStringVector Vect ;  EquiItemVectorIter itEquivalent = pVecEquivalents->begin() ;  for ( ; itEquivalent != pVecEquivalents->end() ; itEquivalent++)  {  	if ((*itEquivalent)->empty())    	Vect.push_back(new classString("")) ;    else    	Vect.push_back(new classString(*(*((*itEquivalent)->begin())))) ;  }  iterString  iterpVect     = Vect.begin() ;  iterString  iterpVectTemp = Vect.begin() ;

  itEquivalent = pVecEquivalents->begin() ;

  PatPathoIter  iterPatPath = begin() ;
  int colonneEncours ;  int colonne ;

  string sItem ;  string sCertitude ;
  string sPluriel ;

	//	// pour chaque �l�ment de pVect, scanner toute la patpatho, et mettre � jour les champs de
	// l'�l�ment en question :
	//									colonne = sa colonne
	//   								coche   = �l�ment d�tect� ou non;
	//   								sItem   = son lablel;
	//			(selon sa position par rapport � l �l�ment de la patpatho)
	//
	for (iterPatPath = begin(); iterPatPath != end(); iterPatPath++ )
	{
		colonneEncours = (*iterPatPath)->getColonne() ;

		// d�cocher les �l�ments dont la colonne est >= colonneEncours
		// uncheck all elements whose column is >= colonneEncours
		for (iterpVect = Vect.begin() ; iterpVect != Vect.end(); iterpVect++)
		{
    	colonne  = (*iterpVect)->colonne ;
      if (colonne >= colonneEncours)
      	(*iterpVect)->coche = false ;
    }

		//trouver le premier �l�ment de pVect non coch�
		for (iterpVectTemp = Vect.begin() ; (iterpVectTemp != Vect.end()) &&
      				((*iterpVectTemp)->coche); iterpVectTemp++) ;

		if (iterpVectTemp != Vect.end())		{
    	sItem = (*iterpVectTemp)->sItem ;
      string sCodeSens ;
      string ssItemCodeSens ;

      // on compose le noeud *iterPatPath avec ses attributs (pluriel et certitude)      string sEtiquette = (*iterPatPath)->getNodeLabel() ;

      if (pContexte)
      {
      	pContexte->getDico()->donneCodeSens(&sEtiquette, &sCodeSens) ;
        pContexte->getDico()->donneCodeSens(&sItem, &ssItemCodeSens) ;
      }
      else
      {
      	ClasseStringVector Vect1 ;
        DecomposeChaine(&sEtiquette, &Vect1, string(1, intranodeSeparationMARK)) ;
        iterString iterpVect = Vect1.begin() ;
        sCodeSens = string((*iterpVect)->sItem, 0, BASE_LEXIQUE_LEN - 1) ;

        while (iterpVect != Vect1.end())        {
        	sCodeSens += string(1, intranodeSeparationMARK) + string((*iterpVect)->sItem, 0, BASE_LEXIQUE_LEN - 1) ;
          iterpVect++ ;
        }

        Vect1.vider() ;
        DecomposeChaine(&sItem, &Vect1, string(1, intranodeSeparationMARK)) ;

        iterpVect = Vect1.begin() ;
        ssItemCodeSens = string((*iterpVect)->sItem, 0, BASE_LEXIQUE_LEN - 1) ;

        while(iterpVect != Vect1.end())        {
        	ssItemCodeSens += string(1, intranodeSeparationMARK) + string((*iterpVect)->sItem, 0, BASE_LEXIQUE_LEN - 1) ;
          iterpVect++ ;
        }
      }

      if (sCodeSens == ssItemCodeSens)      {
      	(*iterpVectTemp)->colonne = (*iterPatPath)->getColonne() ;
        (*iterpVectTemp)->coche   = true ;

      	//si c'est le dernier on sort        if ((*iterpVectTemp) == Vect.back())
        {
        	// on regarde si on avait un it�rateur en parametre
          if (pIter)
          	*pIter = iterPatPath ;

          return true ;        }
      }
    }
  }

	if (pIter)		*pIter = iterPatPath ;
	return false ;} // try
catch (...)
{
	erreur("Exception NSPatPathoArray CheminDansPatpatho 1.", standardError, 0) ;
	return false;
}
}

voidNSPatPathoArray::genereChaine(string* pChaine)
{
	if (!pChaine)
		return ;

	*pChaine = string("") ;

	if (empty())
		return ;

try
{
	for (PatPathoIter i = begin(); i != end(); i++)
	{
		*pChaine += string("{Fiche}") ;
		*pChaine += texteHtml((*i)->getLocalisation()) + string("|") ;
    if ((*i)->getType() != "")
    	*pChaine += texteHtml((*i)->getType()) ;
    *pChaine += string("|") ;
    *pChaine += texteHtml((*i)->getLexique()) + string("|") ;

    // cas des textes libres : on r�cup�re le texte point� par complement
    if ((*i)->getLexique() == "�?????")
    {
    	string sTexteLibre = (*i)->getTexteLibre() ;
      *pChaine += texteHtml(sTexteLibre) + string("|") ;
    }
    else
    	*pChaine += texteHtml((*i)->getComplement()) + string("|") ;

		if ((*i)->getCertitude() != "")
    	*pChaine += texteHtml((*i)->getCertitude()) ;
    *pChaine += string("|") ;
    if ((*i)->getInteret() != "")
    	*pChaine += texteHtml((*i)->getInteret()) ;
    *pChaine += string("|") ;
    if ((*i)->getPluriel() != "")
    	*pChaine += texteHtml((*i)->getPluriel()) ;
    *pChaine += string("|") ;
    if ((*i)->getUnit() != "")
    	*pChaine += texteHtml((*i)->getUnit()) ;
		*pChaine += string("{/Fiche}");
	}
} // try
catch (...)
{
	erreur("Exception NSPatPathoArray genereChaine.", standardError, 0) ;
}
}

void
NSPatPathoArray::initialiseDepuisChaine(string* pChaine)
{
	if ((NULL == pChaine) || (string("") == *pChaine) || (strlen(pChaine->c_str()) < 15))
		return ;

	//
	// La chaine doit commencer par "{PatPatho}" et se terminer par "{/PatPatho}"
	//
	if (string("{PatPatho") != string(*pChaine, 0, 9))
		return ;

	bool bOldStringFormat = false ;
	string sStringType = string(*pChaine, 10, 5) ;
  if ('3' == sStringType[3])
  	bOldStringFormat = true ;

	string sNomTag ;
	string sFiche[50] ;
	int    index ;

	int    iLastLineNumber = -1 ;

	size_t n = 10 ;
	while ((n < strlen(pChaine->c_str())) && (sNomTag != string("/PatPatho")))
	{
		// on lit le prochain tag
    sNomTag = "" ;
    while ((n < strlen(pChaine->c_str())) && ((*pChaine)[n] != '{'))
    	n++ ;
    n++ ;

    while ((n < strlen(pChaine->c_str())) && ((*pChaine)[n] != '}'))
    	sNomTag += (*pChaine)[n++] ;
    n++ ;

  	if (sNomTag == string("Fiche"))
    {
    	index = 0 ;
      sFiche[index] = "" ;

      // on lit chaque enregistrement jusqu'au tag de fin
      while ((n < strlen(pChaine->c_str())) && ((*pChaine)[n] != '{'))
      {
      	while ((n < strlen(pChaine->c_str())) &&
                			((*pChaine)[n] != '{') && ((*pChaine)[n] != '|'))
        	sFiche[index] += (*pChaine)[n++] ;

        if ((*pChaine)[n] == '|') // tag champ suivant
        {
        	index++ ;
          n++ ;
          sFiche[index] = "" ;
        }
      }

      n++ ;

      if (n >= strlen(pChaine->c_str()))
      {
      	erreur("Le fichier � importer contient une PatPatho erron�e.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
        return ;
      }
try
{
			NSPatPathoInfo* pInfo = new NSPatPathoInfo() ;

      if (NULL != pContexte->getPatient())
        pInfo->setPerson(pContexte->getPatient()->getszNss()) ;
      else
        pInfo->setPerson("") ;
      pInfo->setDocum("") ;		// ce code est mis � jour apr�s r�f�rencement      pInfo->setLocalisation(texteCourant(sFiche[0])) ;
      pInfo->setType(texteCourant(sFiche[1])) ;
      pInfo->setLexique(texteCourant(sFiche[2])) ;

      // cas des textes libres : on r�cup�re le texte situ� dans le complement
      if (!strcmp(pInfo->pDonnees->lexique, "�?????"))
      	pInfo->setTexteLibre(texteCourant(sFiche[3])) ;
      else
      	pInfo->setComplement(texteCourant(sFiche[3])) ;

      pInfo->setCertitude(texteCourant(sFiche[4])) ;
			pInfo->setInteret(texteCourant(sFiche[5])) ;
      pInfo->setPluriel(texteCourant(sFiche[6])) ;
      if (false == bOldStringFormat)
			{
      	pInfo->setUnit(texteCourant(sFiche[7])) ;
      	push_back(pInfo) ;
			}
			else
			{
				int iNewLineNumber = pInfo->getLigne() ;
				if (iNewLineNumber == iLastLineNumber)
        {
        	// Example {Fiche}0k080000|1|2MM001|||A|{/Fiche}{Fiche}0k090000|1|�N0;03|41||A|{/Fiche}
        	NSPatPathoInfo* pPreviousInfo = back() ;
          if (NULL != pPreviousInfo)
          {
          	pPreviousInfo->setUnit(pPreviousInfo->getLexique()) ;
            pPreviousInfo->setLexique(texteCourant(sFiche[2])) ;
            pPreviousInfo->setComplement(texteCourant(sFiche[3])) ;
            delete pInfo ;
          }
        }
        else
        	push_back(pInfo) ;

        iLastLineNumber = iNewLineNumber ;
			}
} // try
catch (...)
{
	erreur("Exception NSPatPathoArray::initialiseDepuisChaine.", standardError, 0) ;
	return ;
}
		}
	}
}

stringNSPatPathoArray::genereXML(){	string sXMLstring = "" ;	if (empty())		return sXMLstring ;

	int iCurCol = -1 ;
	int iLevel  = 0 ;

	for (PatPathoIter it = begin(); it != end(); it++)
	{
		int colonneEncours = (*it)->getColonne() ;

    // Closing previous nodes
    //
		while (colonneEncours <= iCurCol)
		{
    	if (iLevel > 0)
      	sXMLstring += string(2*iLevel, ' ') ;
      sXMLstring += string("</node>\r\n") ;
      iCurCol-- ;
      iLevel-- ;
    }
    iCurCol = colonneEncours ;

    if (iLevel > 0)
    	sXMLstring += string(2*iLevel, ' ') ;
    sXMLstring += string("<node") ;

    if (iArrayType == graphPerson)
    {
    	if ((*it)->getPerson() != "")
      	sXMLstring += string(" patId=\"") + texteHtml((*it)->getPerson()) + string("\"") ;
      if ((*it)->getDocum() != "")
      	sXMLstring += string(" treeId=\"") + texteHtml((*it)->getDocum()) + string("\"") ;
    }
    else
    {
    	if ((*it)->getDoc() != "")
      	sXMLstring += string(" objectId=\"") + texteHtml((*it)->getDoc()) + string("\"") ;
    }

    if ((*it)->getNodeID() != "")
    	sXMLstring += string(" nodeId=\"") + texteHtml((*it)->getNodeID()) + string("\"") ;


    sXMLstring += string(" lexique=\"") + texteHtml((*it)->getLexique()) + string("\"") ;

    if ((*it)->getUnit() != "")
    	sXMLstring += string(" unite=\"") + texteHtml((*it)->getUnit()) + string("\"") ;

    if ((*it)->getComplement() != "")
    	sXMLstring += string(" complement=\"") + texteHtml((*it)->getComplement()) + string("\"") ;
    if ((*it)->getCertitude() != "")
    	sXMLstring += string(" certitude=\"") + texteHtml((*it)->getCertitude()) + string("\"") ;
    if ((*it)->getInteret() != "")
    	sXMLstring += string(" interet=\"") + texteHtml((*it)->getInteret()) + string("\"") ;
    if ((*it)->getPluriel() != "")
    	sXMLstring += string(" pluriel=\"") + texteHtml((*it)->getPluriel()) + string("\"") ;
    if ((*it)->getVisible() != "")
    	sXMLstring += string(" visible=\"") + texteHtml((*it)->getVisible()) + string("\"") ;
    if ((*it)->getTexteLibre() != "")
    	sXMLstring += string(" freeText=\"") + texteHtml((*it)->getTexteLibre()) + string("\"") ;
    if ((*it)->getArchetype() != "")
    	sXMLstring += string(" archetype=\"") + texteHtml((*it)->getArchetype()) + string("\"") ;

    sXMLstring += string(">\r\n") ;
  	iLevel++ ;
	}

	while (iLevel > 0)
	{
		iLevel-- ;
    if (iLevel > 0)
    	sXMLstring += string(2*iLevel, ' ') ;
    sXMLstring += string("</node>\r\n") ;
  }

	return sXMLstring ;
}boolNSPatPathoArray::initialiseDepuisXML(string* pXMLstring){	vider() ;	if (*pXMLstring == string(""))		return true ;	size_t iNodePos = pXMLstring->find("<node") ;  if (iNodePos == NPOS)		return false ;	int iCol = 0 ;	while (iNodePos != NPOS)	{  	size_t iEndPos = pXMLstring->find(">", iNodePos) ;    if (iEndPos == NPOS)    	return false ;    string sNodeContent = string(*pXMLstring, iNodePos + 5, iEndPos - iNodePos - 5) ;    if (!addElementFromXMLnode(&sNodeContent, iCol))    	return false ;    iNodePos = pXMLstring->find("<node", iEndPos) ;    size_t iClosePos = pXMLstring->find("</node>", iEndPos) ;    if (iClosePos > iNodePos)    	iCol++ ;    else    {    	while (iClosePos < iNodePos)      {      	iCol-- ;        iClosePos = pXMLstring->find("</node>", iClosePos + 1) ;      }    }	}	return false ;}boolNSPatPathoArray::addElementFromXMLnode(string *pXMLnodeString, int iCol){	strip(*pXMLnodeString, stripBoth) ;	if (*pXMLnodeString == string(""))		return false ;	size_t iStartPos = 0 ;  size_t iNodeLenght = strlen(pXMLnodeString->c_str()) ;  NSPatPathoInfo pptInfo ;  string sPatId = string("") ;  while (iStartPos < iNodeLenght)  {		// Get tag  	//  	size_t iEqualChar = pXMLnodeString->find("=", iStartPos) ;    if (iEqualChar == NPOS)    	return false ;    size_t iStartQuote = pXMLnodeString->find('"', iEqualChar) ;    if (iStartQuote == NPOS)    	return false ;    size_t iEndQuote = pXMLnodeString->find('"', iStartQuote + 1) ;    if (iEndQuote == NPOS)    	return false ;    string sElement = texteCourant(string(*pXMLnodeString, iStartPos, iEqualChar - iStartPos)) ;    string sValue   = texteCourant(string(*pXMLnodeString, iStartQuote + 1, iEqualChar - iStartQuote - 1)) ;    strip(sElement, stripBoth) ;    if      (sElement == "patId")    	pptInfo.setPerson(sValue) ;    else if (sElement == "treeId")    	pptInfo.setTreeID(sValue) ;    else if (sElement == "objectId")    	pptInfo.setDocum(sValue) ;    else if (sElement == "nodeId")    	pptInfo.setNodeID(sValue) ;    else if (sElement == "lexique")    	pptInfo.setLexique(sValue) ;    else if (sElement == "unite")    	pptInfo.setUnit(sValue) ;    else if (sElement == "complement")    	pptInfo.setComplement(sValue) ;    else if (sElement == "certitude")    	pptInfo.setCertitude(sValue) ;    else if (sElement == "interet")    	pptInfo.setInteret(sValue) ;    else if (sElement == "pluriel")    	pptInfo.setPluriel(sValue) ;    else if (sElement == "visible")    	pptInfo.setVisible(sValue) ;    else if (sElement == "freeText")    	pptInfo.setTexteLibre(sValue) ;    else if (sElement == "archetype")    	pptInfo.setArchetype(sValue) ;    iStartPos = iEndQuote + 1 ;	}	pptInfo.setColonne(iCol) ;	int ligne = 0 ;
	if (!empty())
		ligne = (back())->getLigne() + 1 ;
	pptInfo.setLigne(ligne) ;

	push_back(new NSPatPathoInfo(pptInfo)) ;  return true ;}stringNSPatPathoArray::getNodeDate(PatPathoIter iNode){	string sLexique = (*iNode)->getLexique() ;	//	// Donn�e chiffr�e : on regarde si le noeud n'a pas un fr�re	//	if (string(sLexique, 0, 2) == string("�N"))	{  	int iCol = (*iNode)->getColonne() ;    PatPathoIter iNodeNext = iNode++ ;    while ((iNodeNext != end()) && ((*iNodeNext)->getColonne() == iCol))  	{			string sLexNext = (*iNodeNext)->getLexique() ;			if (pContexte)			{      	pContexte->getDico()->donneCodeSens(sLexNext) ;				if (sLexNext == "KDARE")				{        	iNodeNext++ ;          if ((iNodeNext != end()) && ((*iNodeNext)->getColonne() == iCol+1))          	return ((*iNodeNext)->getComplement()) ;				}			}      iNodeNext++ ;		}  }  return "" ;}stringNSPatPathoArray::isPatientData(PatPathoIter iNode){  return "" ;}boolNSPatPathoArray::isExpressionTrue(string sExpression, bool *pbExpressionIsValid){  strip(sExpression, stripBoth) ;  // Before operation has been analyzed, we suppose it is not valid  //  if (NULL != pbExpressionIsValid)    *pbExpressionIsValid = false ;  //  // As a convention, an empty expression is always true, but not valid  //  if (string("") == sExpression)    return true ;  // If the expression is not empty but the pathpatho is empty, then return false  //  if (empty())  {    if (NULL != pbExpressionIsValid)      *pbExpressionIsValid = true ;    return false ;  }  // Separating operator and operand: operator + blanks + operand  //  size_t posEndOperator = sExpression.find(" ") ;  if (string::npos == posEndOperator)    return false ;  string sOperator = string(sExpression, 0, posEndOperator) ;  if ('*' != sOperator[0])    return false ;  size_t posStartOperand = sExpression.find_first_not_of(' ', posEndOperator) ;  if (string::npos == posStartOperand)    return false ;  string sOperand = string(sExpression, posStartOperand, strlen(sExpression.c_str()) - posStartOperand) ;  // Operand must be in the form: value[unit] (with no space in between)  //  size_t posStartUnit = sOperand.find("[") ;  if (string::npos == posStartUnit)    return isNonNumericExpressionTrue(sOperator, sOperand, pbExpressionIsValid) ;  string sValue = string(sOperand, 0, posStartUnit) ;

  size_t posEndUnit = sOperand.find("]", posStartUnit + 1) ;
  if (string::npos == posEndUnit)
    return false ;

  string sUnit = string(sOperand, posStartUnit + 1, posEndUnit - posStartUnit - 1) ;

  return isNumericExpressionTrue(sOperator, sValue, sUnit, pbExpressionIsValid) ;
}
boolNSPatPathoArray::isNumericExpressionTrue(string sOperator, string sValue, string sUnit, bool *pbExpressionIsValid){  if (NULL != pbExpressionIsValid)    *pbExpressionIsValid = false ;  if ((string("") == sOperator) || ('*' != sOperator[0]) || (string(1, '*') == sOperator) ||      (string("") == sValue)    || (string("") == sUnit))    return false ;  sUnit = pContexte->getDico()->donneCodeSens(&sUnit) ;  if (strlen(sUnit.c_str()) != BASE_SENS_LEN)
    return false ;

  // We can now suppose that is valid
  //  if (NULL != pbExpressionIsValid)    *pbExpressionIsValid = true ;

  string sFormat  = string("") ;
  string sValeur1 = string("") ;
  string sUnite1  = string("") ;

  PatPathoIter iter = begin() ;
  while (end() != iter)
  {
    if (((*iter)->pDonnees->lexique)[0] == '�')
    {
      sFormat  = (*iter)->getLexiqueSens(pContexte) ;
      sValeur1 = (*iter)->getComplement() ;
      sUnite1  = (*iter)->getUnitSens(pContexte) ;
      break ;
    }
    iter++ ;
  }

  if ((string("") == sFormat) || (sUnite1 != sUnit))
    return false ;

  char cValueType = sFormat[1] ;

  if ('N' == cValueType)
  {
    double dValue1 = atof(sValeur1.c_str()) ;
    double dValue2 = atof(sValue.c_str()) ;

    if (string("*!=") == sOperator)
      return (dValue1 != dValue2) ;
    if (string("*<")  == sOperator)
      return (dValue1 < dValue2) ;
    if (string("*<=") == sOperator)
      return (dValue1 <= dValue2) ;
    if (string("*==") == sOperator)
      return (dValue1 == dValue2) ;
    if (string("*>")  == sOperator)
      return (dValue1 > dValue2) ;
    if (string("*>=") == sOperator)
      return (dValue1 >= dValue2) ;

    // string sErrorText = pContexte->getSuperviseur()->getText("referentialErrors", "invalidOperatorForExpressions") ;
    // sErrorText += string(" -> ") + sOper + string(" in ") + sExp ;
    // pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    // erreur(sErrorText.c_str(), standardError, 0) ;

    if (NULL != pbExpressionIsValid)
      *pbExpressionIsValid = false ;
    return false ;
  }

  return false ;
}
boolNSPatPathoArray::isNonNumericExpressionTrue(string sOperator, string sOperand, bool *pbExpressionIsValid){  return false ;}////NSFatheredPatPathoArray::NSFatheredPatPathoArray(NSContexte* pCtx, NSPatPathoInfo* pFatherNode, NSPatPathoArray* pPatPatho)                        :NSRoot(pCtx){  _pPatPatho   = pPatPatho ;  _pFatherNode = pFatherNode ;  lObjectCount++ ;}NSFatheredPatPathoArray::NSFatheredPatPathoArray(NSFatheredPatPathoArray& rv)
                        :NSRoot(rv.pContexte)
{
  if (NULL == rv._pPatPatho)
    _pPatPatho = 0 ;
  else
    _pPatPatho = new NSPatPathoArray(*(rv._pPatPatho)) ;

  if (NULL == rv._pFatherNode)
    _pFatherNode = 0 ;
  else
    _pFatherNode = new NSPatPathoInfo(*(rv._pFatherNode)) ;

  lObjectCount++ ;
}


NSFatheredPatPathoArray::~NSFatheredPatPathoArray()
{
  if (NULL != _pPatPatho)
    delete _pPatPatho ;
  if (NULL == _pFatherNode)
    delete _pFatherNode ;

  lObjectCount-- ;
}

NSFatheredPatPathoArray&
NSFatheredPatPathoArray::operator=(NSFatheredPatPathoArray src)
{
  if (&src == this)
		return *this ;

  if (NULL != _pPatPatho)
  {
    delete _pPatPatho ;
    _pPatPatho = 0 ;
  }
  if (NULL == _pFatherNode)
  {
    delete _pFatherNode ;
    _pFatherNode = 0 ;
  }

  if (NULL != src._pPatPatho)
    _pPatPatho = new NSPatPathoArray(*(src._pPatPatho)) ;

  if (NULL != src._pFatherNode)
    _pFatherNode = new NSPatPathoInfo(*(src._pFatherNode)) ;

  return *this ;
}
// -------------------------------------------------------------------------// ---------------- METHODES DE NSVectFatheredPatPathoArray ----------------
// -------------------------------------------------------------------------
NSVectFatheredPatPathoArray::NSVectFatheredPatPathoArray()
                            :NSVectFatheredPatPathoInfoArray()
{
	lObjectCount++ ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSVectFatheredPatPathoArray::NSVectFatheredPatPathoArray(NSVectFatheredPatPathoArray& rv)
                            :NSVectFatheredPatPathoInfoArray()
{
try
{
	if (!(rv.empty()))
		for (FatheredPatPathoIterVect i = rv.begin(); i != rv.end(); i++)
			push_back(new NSFatheredPatPathoArray(*(*i))) ;

  lObjectCount++ ;
}
catch (...)
{
	erreur("Exception (NSVectFatheredPatPathoArray copy ctor).", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
void
NSVectFatheredPatPathoArray::vider()
{
	if (empty())
		return ;
	for (FatheredPatPathoIterVect i = begin(); i != end(); )
	{
		delete *i ;
		erase(i) ;
	}
}

NSVectFatheredPatPathoArray::~NSVectFatheredPatPathoArray()
{
	vider() ;

  lObjectCount-- ;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSVectFatheredPatPathoArray&NSVectFatheredPatPathoArray::operator=(NSVectFatheredPatPathoArray src)
{
try
{
	if (&src == this)
		return *this ;

	//
	// Effacement des �l�ments d�j� contenus dans le vecteur destination
	//
	vider() ;	//
	// Copie et insertion des �l�ments de la source
	//
	if (!(src.empty()))
		for (FatheredPatPathoIterVect i = src.begin(); i != src.end(); i++)
			push_back(new NSFatheredPatPathoArray(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception (op = NSVectFatheredPatPathoArray).", standardError, 0) ;
	return *this ;
}
}

//---------------------------------------------------------------------------//   NSVectPatPathoArray vide ou non dans le cas non multidialogue
//---------------------------------------------------------------------------
bool
NSVectFatheredPatPathoArray::estVide()
{
	if (empty())
		return true ;

	FatheredPatPathoIterVect iter ;
	for (iter = begin(); (iter != end()) && ((*iter)->getPatPatho()->empty()) ; iter++) ;
	if (iter == end())
		return true ;

	return false ;
}

//---------------------------------------------------------------------------
//   NSVectPatPathoArray vide ou non dans le cas multidialogue
//---------------------------------------------------------------------------
bool
NSVectFatheredPatPathoArray::MultiEstVide()
{
	if (empty())
		return true ;

	FatheredPatPathoIterVect iter;
	for (iter = begin(); (iter != end()) && ((*iter)->getPatPatho()->empty()) ; iter++) ;
	if (iter == end())
		return true ;

	return false ;
}
//***************************************************************************// Impl�mentation des m�thodes NSPatPathoData
//***************************************************************************
//---------------------------------------------------------------------------//  Constructeur
//---------------------------------------------------------------------------
NSPatPathoData::NSPatPathoData() : NSPathoBaseData()
{
	metAZero() ;

  lObjectCount++ ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSPatPathoData::~NSPatPathoData()
{
  lObjectCount-- ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSPatPathoData::NSPatPathoData(NSPatPathoData& rv)
               :NSPathoBaseData(rv)
{
	// metAZero(); Don't since the NSPathoBaseData part is already set

  memset(treeID, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN + 1) ;
  memset(noeud,  0, PPD_NOEUD_LEN + 1) ;

  _sTexteLibre = string("") ;
  _sArchetype  = string("") ;  _sNodeRight  = string("") ;

	//strcpy(codePatient,  rv.codePatient);
	//strcpy(codeDocument, rv.codeDocument);
	strcpy(treeID,  rv.treeID);
	strcpy(noeud,   rv.noeud);

  if (string("") != rv._sTexteLibre)
    _sTexteLibre = rv._sTexteLibre ;

  if (string("") != rv._sArchetype)
    _sArchetype = rv._sArchetype ;

  if (string("") != rv._sNodeRight)
    _sNodeRight = rv._sNodeRight ;

/*
	if (&(rv.sArchetype) != NULL)
		sArchetype = rv.sArchetype ;
	else
		sArchetype = string("") ;
	_NodeRight  = rv._NodeRight ;
*/

  lObjectCount++ ;
}

//---------------------------------------------------------------------------//  Op�rateur =
//---------------------------------------------------------------------------
NSPatPathoData&
NSPatPathoData::operator=(NSPatPathoData src)
{
	if (&src == this)
		return *this ;

	metAZero() ;

	NSPathoBaseData* pbdata1 = this ;
	NSPathoBaseData* pbdata2 = &src ;

	*pbdata1 = *pbdata2 ;

	//strcpy(codePatient,  src.codePatient);
	//strcpy(codeDocument, src.codeDocument);
	strcpy(treeID, src.treeID) ;
	strcpy(noeud,  src.noeud) ;

  if (string("") != src._sTexteLibre)
    _sTexteLibre = src._sTexteLibre ;
  if (string("") != src._sArchetype)
    _sArchetype  = src._sArchetype ;
  if (string("") != src._sNodeRight)
    _sNodeRight  = src._sNodeRight ;	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSPatPathoData::operator == ( NSPatPathoData& o )
{
  NSPathoBaseData* pbdata1 = this ;
  NSPathoBaseData* pbdata2 = &o ;

  if ((*pbdata1 == *pbdata2) &&
    	//(strcmp(codePatient, 	  o.codePatient) 	  == 0) &&
        //(strcmp(codeDocument,   o.codeDocument) 	  == 0) &&
        (strcmp(treeID, o.treeID)   == 0) &&
        (strcmp(noeud,  o.noeud)    == 0) &&
        (_sTexteLibre == o._sTexteLibre) &&        (_sArchetype == o._sArchetype))    return 1 ;
  else
    return 0 ;
}

//---------------------------------------------------------------------------
//  Met � 0 les variables.
//---------------------------------------------------------------------------
void
NSPatPathoData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
  NSPathoBaseData::metAZero() ;

	//memset(codePatient,	 0, PAT_NSS_LEN + 1);
  //memset(codeDocument, 0, DOC_CODE_DOCUM_LEN + 1);
  memset(treeID, 		 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN + 1) ;
  memset(noeud, 		 0, PPD_NOEUD_LEN + 1) ;

  _sTexteLibre = string("") ;
  _sArchetype  = string("") ;  _sNodeRight  = string("") ;}

//---------------------------------------------------------------------------
//  Teste l'�galit� du point de vue des donn�es
//---------------------------------------------------------------------------

bool
NSPatPathoData::sameContent(NSPatPathoData* pPathoData)
{
	if (NULL == pPathoData)
		return false ;	NSPathoBaseData* pbdata1 = this ;	NSPathoBaseData* pbdata2 = pPathoData ;

	// on ne tient pas compte du num�ro de noeud  //	if ((pbdata1->sameContent(*pbdata2)) &&      (_sTexteLibre == pPathoData->_sTexteLibre) &&
      (_sArchetype  == pPathoData->_sArchetype))		return true ;
	else
		return false ;
}
bool
NSPatPathoData::estEgal(NSPatPathoData* pPathoData){	if (NULL == pPathoData)		return false ;	NSPathoBaseData* pbdata1 = this ;	NSPathoBaseData* pbdata2 = pPathoData ;

	// on ne tient pas compte du num�ro de noeud  //	if ((*pbdata1 == *pbdata2) &&    	//(strcmp(codePatient, 	  pPathoData->codePatient) 	  == 0) &&
      //(strcmp(codeDocument, 	  pPathoData->codeDocument) 	  == 0) &&
      //(strcmp(treeID, pPathoData->treeID) == 0) &&
      (_sTexteLibre == pPathoData->_sTexteLibre) &&
      (_sArchetype  == pPathoData->_sArchetype))		return true ;
	else
		return false ;
}boolNSPatPathoData::estMemeNode(NSPatPathoData* pPathoData){  NSPathoBaseData* pbdata1 = this;  NSPathoBaseData* pbdata2 = pPathoData;

  // on tient compte ici du num�ro de noeud  // mais pas des donn�es archetype et droits  if (/* (*pbdata1 == *pbdata2) */ (pbdata1->sameContent(*pbdata2)) &&        (strcmp(treeID, pPathoData->treeID) == 0) &&
        (strcmp(noeud, pPathoData->noeud) == 0) &&
        (_sTexteLibre == pPathoData->_sTexteLibre))
    return true ;
  else
		return false ;}voidNSPatPathoData::getOtherNodeContent(NSPatPathoData* pPathoData){	if ((NULL == pPathoData) || (pPathoData == this))		return ;

	// Don't overwrite the localisation
  char initialCodeLocalisation[BASE_LOCALISATION_LEN + 1] ;
  strcpy(initialCodeLocalisation, codeLocalisation) ;

	NSPathoBaseData* pbdata1 = this ;
	NSPathoBaseData* pbdata2 = pPathoData ;

	*pbdata1 = *pbdata2 ;

  strcpy(codeLocalisation, initialCodeLocalisation) ;

	_sTexteLibre = pPathoData->_sTexteLibre ;
	_sArchetype  = pPathoData->_sArchetype ;
	_sNodeRight  = pPathoData->_sNodeRight ;}//---------------------------------------------------------------------------//  Va chercher le libell� dans le fichier Patholog.
//---------------------------------------------------------------------------
DBIResult
NSPatPathoData::donneLibelle(string* pLibel, NSPatholog* pPathor)
{
  DBIResult ErrDBI = pPathor->chercheClef((unsigned char*)pLibel,
                                            "CODE_INDEX",
                                            NODEFAULTINDEX,
                                            keySEARCHEQ,
                                            dbiWRITELOCK) ;
  if (ErrDBI == DBIERR_NONE)
    *pLibel = pPathor->pDonnees->libelleLong ;
  else
    *pLibel = "Erreur" ;

  return ErrDBI ;
}

//---------------------------------------------------------------------------
//  Retourne le type de l'�l�ment : pptLex, pptNum, pptLibre
//---------------------------------------------------------------------------
int
NSPatPathoData::getType()
{
  switch (type[0])
  {
    case 'C' : return pptLex ;
		case 'N' : return pptNum ;
    case 'L' : return pptLibre ;
  }
  return pptIndef ;
}

//---------------------------------------------------------------------------
//  Impose le type de l'�l�ment : pptLex, pptNum, pptLibre
//---------------------------------------------------------------------------
void
NSPatPathoData::setType(int newType)
{
  switch (newType)
  {
    case pptLex   : strcpy(type, "C") ; break ;
		case pptNum   : strcpy(type, "N") ; break ;
    case pptLibre : strcpy(type, "L") ; break ;
  }
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
int
NSPatPathoData::getIndice(int indice)
{
  int iValeur = 0;

  // base 62 = 26 + 26 + 10
  //
  for (int i = 0; i < 2; i++)
  {
    iValeur = 62 * iValeur ;
    char caract = codeLocalisation[(2 * indice) + i] ;

    if      ((caract >= '0') && (caract <= '9'))
      iValeur += caract - '0' ;
    else if ((caract >= 'A') && (caract <= 'Z'))
      iValeur += caract + 10 - 'A' ;
    else if ((caract >= 'a') && (caract <= 'z'))
      iValeur += caract + 36 - 'a' ;
  }
  return iValeur ;
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void
NSPatPathoData::setIndice(int indice, int valeur)
{
  // base 62 = 26 + 26 + 10
  //
  int iValeur[2] ;

	iValeur[0] = valeur / 62 ;

  if (iValeur[0] > 0)
    iValeur[1] = valeur - iValeur[0] * 62 ;
  else
    iValeur[1] = valeur ;

  for (int i = 1; i >=0; i--)
  {
    if      ((iValeur[i] >= 0) && (iValeur[i] <= 9))
      codeLocalisation[(2 * indice) + i] = char(iValeur[i] + '0') ;
    else if ((iValeur[i] >= 10) && (iValeur[i] <= 35))
      codeLocalisation[(2 * indice) + i] = char(iValeur[i] - 10 + 'A') ;
    else if ((iValeur[i] >= 36) && (iValeur[i] <= 61))
      codeLocalisation[(2 * indice) + i] = char(iValeur[i] - 36 + 'a') ;
  }
}

void
NSPatPathoData::setPerson(string sPat)
{
  if (string("") == sPat)
  {
    for (size_t i = 0; i < PAT_NSS_LEN; i++)
      treeID[i] = '\0' ;
    return ;
  }

  if (strlen(sPat.c_str()) < PAT_NSS_LEN)
    return ;

  for (size_t i = 0; i < PAT_NSS_LEN; i++)
    treeID[i] = sPat[i] ;
}

void
NSPatPathoData::setDocum(string sDocum)
{
  size_t i ;

  if (string("") == sDocum)
  {
    for (i = 0; i < DOC_CODE_DOCUM_LEN; i++)
      treeID[i + PAT_NSS_LEN] = '\0' ;
    return ;
  }
  if (strlen(sDocum.c_str()) < DOC_CODE_DOCUM_LEN)
    return ;

  for (i = 0; i < DOC_CODE_DOCUM_LEN; i++)
    treeID[i + PAT_NSS_LEN] = sDocum[i] ;
  treeID[i + PAT_NSS_LEN] = '\0';
}

void
NSPatPathoData::setTreeID(string sTreeID)
{
  size_t i ;

  if (sTreeID == "")
  {
    for (i = 0; i < OBJECT_ID_LEN; i++)
      treeID[i] = '\0' ;
    return ;
  }

  if (strlen(sTreeID.c_str()) < OBJECT_ID_LEN)
    return ;

  for (i = 0; i < OBJECT_ID_LEN; i++)
    treeID[i] = sTreeID[i] ;
  treeID[i] = '\0' ;
}

void
NSPatPathoData::setNodeID(string sNodeID)
{
  size_t i ;

  if (string("") == sNodeID)
  {
    for (i = 0; i < PPD_NOEUD_LEN; i++)
      noeud[i] = '\0' ;
    return ;
  }

  if (strlen(sNodeID.c_str()) < PPD_NOEUD_LEN)
    return ;

  for (i = 0; i < PPD_NOEUD_LEN; i++)
    noeud[i] = sNodeID[i] ;
  noeud[i] = '\0' ;
}

//***************************************************************************
//          Impl�mentation des m�thodes NSPatPathoInfo
//***************************************************************************

//---------------------------------------------------------------------------//  Constructeur par d�faut
//---------------------------------------------------------------------------
NSPatPathoInfo::NSPatPathoInfo()
{
try
{
	// Cr�e l'objet de donn�es
	pDonnees        = new NSPatPathoData() ;

	ID              = -1 ;
	pTemporaryLinks = 0 ;

	for (int i=0; i< BASE_LOCALISATION_LEN + 1; i++)
		pDonnees->codeLocalisation[i] = '0' ;
	pDonnees->codeLocalisation[BASE_LOCALISATION_LEN] = '\0' ;

  lObjectCount++ ;
} // try
catch (...)
{
	erreur("Exception NSPatPathoInfo ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Constructeur � partir d'un NSSavFiche
//---------------------------------------------------------------------------
NSPatPathoInfo::NSPatPathoInfo(NSSavFiche* pSavFiche)
{
try
{
	ID              = -1 ;
	pTemporaryLinks = 0 ;
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSPatPathoData() ;
	//
	// Copie les valeurs du NSDocument
	//
	strcpy(pDonnees->codeLocalisation, pSavFiche->pDonnees->codeLocalisation) ;
	strcpy(pDonnees->type,   	 	       pSavFiche->pDonnees->type) ;
	strcpy(pDonnees->lexique, 	 	     pSavFiche->pDonnees->lexique) ;
	strcpy(pDonnees->complement, 	     pSavFiche->pDonnees->complement) ;
	strcpy(pDonnees->unit, 	           pSavFiche->pDonnees->unit) ;
	strcpy(pDonnees->certitude,  	     pSavFiche->pDonnees->certitude) ;
	strcpy(pDonnees->interet,    	     pSavFiche->pDonnees->interet) ;
	strcpy(pDonnees->pluriel,    	     pSavFiche->pDonnees->pluriel) ;
	strcpy(pDonnees->visible,    	     pSavFiche->pDonnees->visible) ;

  lObjectCount++ ;
} // try
catch (...)
{
	erreur("Exception NSPatPathoInfo ctor(NSSavFiche*).", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSPatPathoInfo::NSPatPathoInfo(NSPatPathoInfo& rv)
{
try
{
  // Make certain that this is initialized in case the exception is thrown
  //
  pDonnees        = 0 ;
  pTemporaryLinks = 0 ;
	//
	// Cr�e l'objet de donn�es par constructeur copie
	//
  if (NULL != rv.pDonnees)
	  pDonnees = new NSPatPathoData(*(rv.pDonnees)) ;
	//
	// Copie les valeurs du NSPatPathoInfo d'origine
	//
	ID = rv.ID;
	if (NULL != rv.pTemporaryLinks)
		pTemporaryLinks = new NSLinkedNodeArray(*(rv.pTemporaryLinks)) ;

	lObjectCount++ ;
} // try
catch (...)
{
	erreur("Exception NSPatPathoInfo copy ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSPatPathoInfo&
NSPatPathoInfo::operator=(NSPatPathoInfo src)
{
	if (&src == this)
		return *this ;

	// In order to get clean chars
  if (NULL != pDonnees)
  {
	  pDonnees->metAZero() ;
    if (NULL != src.pDonnees)
      *pDonnees = *(src.pDonnees) ;
    else
    {
      delete pDonnees ;
      pDonnees = 0 ;
    }
  }
  else if (NULL != src.pDonnees)
    pDonnees = new NSPatPathoData(*(src.pDonnees)) ;

	ID = src.ID ;

	if (NULL != src.pTemporaryLinks)
	{
		if (pTemporaryLinks)
    	*pTemporaryLinks = *(src.pTemporaryLinks) ;
    else
    	pTemporaryLinks = new NSLinkedNodeArray(*(src.pTemporaryLinks)) ;
	}
	else
	{
  	if (pTemporaryLinks)
    	delete pTemporaryLinks ;
    pTemporaryLinks = 0 ;
	}

	return *this ;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSPatPathoInfo::operator == ( const NSPatPathoInfo& o )
{
	// ID est devenu obsolete
	// return ((*pDonnees == *(o.pDonnees)) && (ID == o.ID));
	return (*pDonnees == *(o.pDonnees)) ;
}
string
NSPatPathoInfo::getNodeLabel()
{
  string sEtiquette = getLexique() ;
  string sUnit      = getUnit() ;
  string sPluriel   = getPluriel() ;
  string sCertitude = getCertitude() ;

  if (string("") != sUnit)
    sEtiquette = sUnit + string(1, intranodeSeparationMARK) + sEtiquette ;

  if (string("") != sPluriel)
    sEtiquette += string(1, intranodeSeparationMARK) + sPluriel ;
  if (string("") != sCertitude)
    sEtiquette += string(1, intranodeSeparationMARK) + sCertitude ;

  return sEtiquette ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison du point de vue des donn�es
//---------------------------------------------------------------------------
boolNSPatPathoInfo::sameContent(NSPatPathoInfo* pPathoInfo){	return pDonnees->sameContent(pPathoInfo->pDonnees) ;}boolNSPatPathoInfo::estEgal(NSPatPathoInfo* pPathoInfo){	return pDonnees->estEgal(pPathoInfo->pDonnees) ;}boolNSPatPathoInfo::estMemeNode(NSPatPathoInfo* pPathoInfo){	return pDonnees->estMemeNode(pPathoInfo->pDonnees) ;}
void
NSPatPathoInfo::getOtherNodeContent(NSPatPathoInfo* pPathoInfo)
{
	if (this == pPathoInfo)
		return ;

	pDonnees->getOtherNodeContent(pPathoInfo->pDonnees) ;
}

// -----------------------------------------------------------------------------
// destructeur
// -----------------------------------------------------------------------------
NSPatPathoInfo::~NSPatPathoInfo()
{
  if (NULL != pDonnees)
    delete pDonnees ;
  if (NULL != pTemporaryLinks)
  	delete pTemporaryLinks ;

	lObjectCount-- ;
}

string
NSPatPathoInfo::getLexiqueSens(NSContexte* pCtx)
{
	string sCode = getLexique() ;
  return pCtx->getDico()->donneCodeSens(&sCode) ;
}

string
NSPatPathoInfo::getUnitSens(NSContexte* pCtx)
{
	string sCode = getUnit() ;
  return pCtx->getDico()->donneCodeSens(&sCode) ;
}

string
NSPatPathoInfo::getCertitudeSens(NSContexte* pCtx)
{
	string sCode = getCertitude() ;
  return pCtx->getDico()->donneCodeSens(&sCode) ;
}

string
NSPatPathoInfo::getInteretSens(NSContexte* pCtx)
{
	string sCode = getInteret() ;
  return pCtx->getDico()->donneCodeSens(&sCode) ;
}

string
NSPatPathoInfo::getPlurielSens(NSContexte* pCtx)
{
	string sCode = getPluriel() ;
  return pCtx->getDico()->donneCodeSens(&sCode) ;
}

void
NSPatPathoInfo::setLexique(string sLexique)
{
  int iLen = strlen(sLexique.c_str()) ;
  if (iLen <= BASE_LEXIQUE_LEN)
  	strcpy(pDonnees->lexique, sLexique.c_str()) ;
  else
  {
  	string sTruncated = string(sLexique, 0, BASE_LEXIQUE_LEN) ;
    strcpy(pDonnees->lexique, sTruncated.c_str()) ;
  }
}

void
NSPatPathoInfo::setComplement(string sCplmnt)
{
  int iLen = strlen(sCplmnt.c_str()) ;
  if (iLen <= BASE_COMPLEMENT_LEN)
    strcpy(pDonnees->complement, sCplmnt.c_str()) ;
  else
  {
    string sTruncated = string(sCplmnt, 0, BASE_COMPLEMENT_LEN) ;
    strcpy(pDonnees->complement, sTruncated.c_str()) ;
  }
}

void
NSPatPathoInfo::setUnit(string sUnit)
{
  int iLen = strlen(sUnit.c_str()) ;
  if (iLen <= BASE_UNIT_LEN)
    strcpy(pDonnees->unit, sUnit.c_str()) ;
  else
  {
    string sTruncated = string(sUnit, 0, BASE_UNIT_LEN) ;
    strcpy(pDonnees->unit, sTruncated.c_str()) ;
  }
}

void
NSPatPathoInfo::setCertitude(string sCertitude)
{
  int iLen = strlen(sCertitude.c_str()) ;
  if (iLen <= BASE_CERTITUDE_LEN)
    strcpy(pDonnees->certitude, sCertitude.c_str()) ;
  else
  {
    string sTruncated = string(sCertitude, 0, BASE_CERTITUDE_LEN) ;
    strcpy(pDonnees->certitude, sTruncated.c_str()) ;
  }
}

void
NSPatPathoInfo::setInteret(string sInteret)
{
  int iLen = strlen(sInteret.c_str()) ;
  if (iLen <= BASE_INTERET_LEN)
    strcpy(pDonnees->interet, sInteret.c_str()) ;
  else
  {
    string sTruncated = string(sInteret, 0, BASE_INTERET_LEN) ;
    strcpy(pDonnees->interet, sTruncated.c_str()) ;
  }
}

void
NSPatPathoInfo::setPluriel(string sPluriel)
{
  int iLen = strlen(sPluriel.c_str()) ;
  if (iLen <= BASE_PLURIEL_LEN)
    strcpy(pDonnees->pluriel, sPluriel.c_str()) ;
  else
  {
    string sTruncated = string(sPluriel, 0, BASE_PLURIEL_LEN) ;
    strcpy(pDonnees->pluriel, sTruncated.c_str()) ;
  }
}

void
NSPatPathoInfo::setVisible(string sVisible)
{
	int iLen = strlen(sVisible.c_str()) ;
	if (iLen <= BASE_VISIBLE_LEN)
		strcpy(pDonnees->visible, sVisible.c_str()) ;
	else
	{
		string sTruncated = string(sVisible, 0, BASE_VISIBLE_LEN) ;
		strcpy(pDonnees->visible, sTruncated.c_str()) ;
	}
}

void
NSPatPathoInfo::setType(string sType)
{
	int iLen = strlen(sType.c_str()) ;
	if (iLen <= BASE_TYPE_LEN)
		strcpy(pDonnees->type, sType.c_str()) ;
	else
	{
		string sTruncated = string(sType, 0, BASE_TYPE_LEN) ;
		strcpy(pDonnees->type, sTruncated.c_str()) ;
	}
}

void
NSPatPathoInfo::setLocalisation(string sLocalisation)
{
	int iLen = strlen(sLocalisation.c_str()) ;
	if (iLen <= BASE_LOCALISATION_LEN)
		strcpy(pDonnees->codeLocalisation, sLocalisation.c_str()) ;
	else
	{
  	string sTruncated = string(sLocalisation, 0, BASE_LOCALISATION_LEN) ;
    strcpy(pDonnees->codeLocalisation, sTruncated.c_str()) ;
	}
}

void
NSPatPathoInfo::addTemporaryLink(string sNode, NSRootLink::NODELINKTYPES iLkType,
                                 NODELINKDIRECTION iLkDirection,
                                 bool bLkWithDoc)
{
try
{
	if (!pTemporaryLinks)
		pTemporaryLinks = new NSLinkedNodeArray() ;

	pTemporaryLinks->push_back(new NSLinkedNode(sNode, iLkType, iLkDirection, bLkWithDoc)) ;
}
catch (...)
{
	erreur("Exception NSPatPathoInfo::addTemporaryLink", standardError, 0) ;
}
}

void
NSPatPathoInfo::addTemporaryLink(NSPatPathoInfo* pOtherTemporaryNode,
                                 NSRootLink::NODELINKTYPES iLkType,
                                 NODELINKDIRECTION iLkDirection,
                                 bool bLkWithDoc)
{
try
{
	if (!pTemporaryLinks)
		pTemporaryLinks = new NSLinkedNodeArray() ;

	pTemporaryLinks->push_back(new NSLinkedNode(pOtherTemporaryNode, iLkType, iLkDirection, bLkWithDoc)) ;
}
catch (...)
{
	erreur("Exception NSPatPathoInfo::addTemporaryLink", standardError, 0) ;
}
}

bool
NSPatPathoInfo::numberTemporaryNodes(NSLinkManager* pLinkManager)
{
	string sNodeSource ;

	if (NULL == pTemporaryLinks)
		return false ;

	if (pTemporaryLinks->empty())
		return true ;

	if (getNodeID() == "")
	{
  	erreur("Un noeud � relier ne poss�de pas d'identifiant.", standardError, 0) ;
    return false ;
	}

	for (NSLinkedNodeIter i = pTemporaryLinks->begin(); i != pTemporaryLinks->end(); i++)
	{
  	if ((*i)->bLinkWithDoc)
    	sNodeSource = getDoc() ;
    else
    	sNodeSource = getNode() ;

    // dans le cas o� sOtherNode est instanci�, on �tablit un lien si
    // on a un pLinkManager en param�tre != NULL
    if ((*i)->sOtherNode == "")
    {
    	if (NULL == (*i)->pOtherTemporaryNode)
      	erreur("Un lien en attente ne poss�de pas d'adresse.", standardError, 0) ;
      else
      {
      	NSPatPathoInfo* pOtherInfo = (*i)->pOtherTemporaryNode ;
        bool bNotPresent = true ;

        if (pOtherInfo->pTemporaryLinks && (!pOtherInfo->pTemporaryLinks->empty()))
        {
        	for (NSLinkedNodeIter j = pOtherInfo->pTemporaryLinks->begin();
                                 j != pOtherInfo->pTemporaryLinks->end(); j++)
          {
          	if ((*j)->pOtherTemporaryNode == this)
            {
            	(*j)->sOtherNode = sNodeSource ;
              (*j)->pOtherTemporaryNode = NULL ;
              bNotPresent = false ;
            }
          }
        }
        else
        {
        	if (dirFleche == (*i)->iLinkDirection)
          	pOtherInfo->addTemporaryLink(sNodeSource, (*i)->iLinkType, dirEnvers) ;
          else
          	pOtherInfo->addTemporaryLink(sNodeSource, (*i)->iLinkType, dirFleche) ;

          bNotPresent = false ;
        }

        if (bNotPresent)
        	erreur("Un noeud � relier n'est pas pr�sent dans le noeud destination.", standardError, 0) ;
      }
    }
    else if (NULL != pLinkManager)
    {
    	bool bLinkResult ;
      if (dirFleche == (*i)->iLinkDirection)
      	bLinkResult = pLinkManager->etablirLien(sNodeSource, (*i)->iLinkType, (*i)->sOtherNode) ;
      else
      	bLinkResult = pLinkManager->etablirLien((*i)->sOtherNode, (*i)->iLinkType, sNodeSource) ;

      if (!bLinkResult)
      	erreur("Impossible d'initialiser le lien en attente.", standardError, 0) ;
    }
  }

	return true ;
}

//
// -------------------- METHODES DE NSCutPastTLArray ----------------------
//
 /*
NSCutPastTLArray::NSCutPastTLArray()
				 :NSCutPastTLIBArray()
{}

NSCutPastTLArray::NSCutPastTLArray(NSCutPastTLArray& rv)				 :NSCutPastTLIBArray()
{
try
{
	if (!(rv.empty()))
		for (CutPastTLIter i = rv.begin(); i != rv.end(); i++)
   	    	push_back(new NSCutPastTL(*(*i)));
} // try
catch (...)
{
	erreur("Exception NSCutPastTLArray copy ctor.", standardError, 0) ;
}
}

voidNSCutPastTLArray::vider()
{
	if (empty())
    	return;

	for (CutPastTLIter i = begin(); i != end(); )
    {
   	    delete *i;
        erase(i);
    }
}

NSCutPastTLArray::~NSCutPastTLArray()
{
    vider();
}

NSCutPastTLArray&
NSCutPastTLArray::operator=(NSCutPastTLArray src)
{
    // Effacement des �l�ments d�j� contenus dans le vecteur destination
	vider();
	//
    // Copie et insertion des �l�ments de la source
    //
try
{
	if (!(src.empty()))
  		for (CutPastTLIter i = src.begin(); i != src.end(); i++)
    		push_back(new NSCutPastTL(*(*i)));
} // try
catch (...)
{
	erreur("Exception NSCutPastTLArray = op.", standardError, 0) ;
}
    return *this;
}
 */
//// -------------------- METHODES DE NSCutPaste ----------------------
//

NSCutPaste::NSCutPaste(NSContexte* pCtx)
		   :NSRoot(pCtx)
{
try
{
	pPatPatho     = new NSPatPathoArray(pContexte);
  pTextesLibres = new NSCutPastTLArray();

} // try
catch (...)
{
	erreur("Exception NSCutPaste ctor.", standardError, 0) ;
}
}

NSCutPaste::NSCutPaste(NSCutPaste& rv)		   :NSRoot(rv.pContexte)
{
try
{
	pPatPatho     = new NSPatPathoArray(*(rv.pPatPatho)) ;
	pTextesLibres = new NSCutPastTLArray(*(rv.pTextesLibres)) ;
	aConcerns     = rv.aConcerns ;
} // try
catch (...)
{
	erreur("Exception NSCutPaste copy ctor.", standardError, 0) ;
}
}

NSCutPaste::~NSCutPaste(){
	delete pPatPatho ;
  delete pTextesLibres ;
}

void
NSCutPaste::vider()
{
  pPatPatho->vider() ;
  pTextesLibres->vider() ;
  aConcerns.vider() ;
}

NSCutPaste&
NSCutPaste::operator=(NSCutPaste src)
{
	if (&src == this)
		return *this ;

	pPatPatho->vider() ;
	pTextesLibres->vider() ;

	*pPatPatho     = *(src.pPatPatho) ;
	*pTextesLibres = *(src.pTextesLibres) ;
	aConcerns      = src.aConcerns ;

	return *this ;
}

//
// -------------------- METHODES DE NSLinkedNode ----------------------
//

NSLinkedNode::NSLinkedNode(string sNode, NSRootLink::NODELINKTYPES iLkType,
                           NODELINKDIRECTION iLkDirection, bool bLkWithDoc)
{
  sOtherNode          = sNode ;
  pOtherTemporaryNode = 0 ;
  iLinkType           = iLkType ;
  iLinkDirection      = iLkDirection ;
  bLinkWithDoc        = bLkWithDoc ;
}

NSLinkedNode::NSLinkedNode(NSPatPathoInfo* pTemporaryNode,
                           NSRootLink::NODELINKTYPES iLkType,
                           NODELINKDIRECTION iLkDirection, bool bLkWithDoc)
{
  sOtherNode          = "" ;
  pOtherTemporaryNode = pTemporaryNode ;
  iLinkType           = iLkType ;
  iLinkDirection      = iLkDirection ;
  bLinkWithDoc        = bLkWithDoc ;
}

NSLinkedNode::~NSLinkedNode()
{
}

NSLinkedNode::NSLinkedNode(NSLinkedNode& rv)
{
  sOtherNode          = rv.sOtherNode ;
  pOtherTemporaryNode = rv.pOtherTemporaryNode ;
  iLinkType           = rv.iLinkType ;
  iLinkDirection      = rv.iLinkDirection ;
  bLinkWithDoc        = rv.bLinkWithDoc ;
}

NSLinkedNode&
NSLinkedNode::operator=(NSLinkedNode src)
{
	if (&src == this)
		return *this ;

	sOtherNode          = src.sOtherNode ;
	pOtherTemporaryNode = src.pOtherTemporaryNode ;
	iLinkType           = src.iLinkType ;
	iLinkDirection      = src.iLinkDirection ;
	bLinkWithDoc        = src.bLinkWithDoc ;

	return *this ;
}

//
// -------------------- METHODES DE NSLinkedNodeArray ----------------------
//

NSLinkedNodeArray::NSLinkedNodeArray(NSLinkedNodeArray& rv)
                  :NSLinkedNodeVector()
{
try
{
	if (!(rv.empty()))
		for (NSLinkedNodeIter i = rv.begin(); i != rv.end(); i++)
   	    	push_back(new NSLinkedNode(*(*i)));
} // try
catch (...)
{
	erreur("Exception NSLinkedNodeArray copy ctor.", standardError, 0) ;
}
}

voidNSLinkedNodeArray::vider()
{
	if (empty())
		return ;

	for (NSLinkedNodeIter i = begin(); i != end(); )
	{
  	delete *i ;
    erase(i) ;
	}
}

NSLinkedNodeArray::~NSLinkedNodeArray()
{
	vider() ;
}

NSLinkedNodeArray&
NSLinkedNodeArray::operator=(NSLinkedNodeArray src)
{
	if (&src == this)
		return *this ;

	// Effacement des �l�ments d�j� contenus dans le vecteur destination
	vider() ;
	//
	// Copie et insertion des �l�ments de la source
	//
try
{
	if (!(src.empty()))
		for (NSLinkedNodeIter i = src.begin(); i != src.end(); i++)
			push_back(new NSLinkedNode(*(*i))) ;
} // try
catch (...)
{
	erreur("Exception NSLinkedNodeArray = op.", standardError, 0) ;
}
	return *this ;
}


