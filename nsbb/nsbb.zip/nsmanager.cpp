// -----------------------------------------------------------------------------// nsmanager.cpp
// -----------------------------------------------------------------------------
// Gestion des graphes
// -----------------------------------------------------------------------------
// $Revision: 1.193 $
// $Author: remi $
// $Date: 2005/07/08 15:25:31 $
// -----------------------------------------------------------------------------
// PA  - septembre 2003
// -----------------------------------------------------------------------------
// FLP - aout 2004
// modification de graphPrepare() - on ne fait plus de getPatho() ou appelle la
// m�thode de NSDataTree qui le trie par localisation.
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Copyright Nautilus, 2004
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � g�rer et traiter les
// informations de sant� d'une personne.
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to manage and process
// a person's health data.
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------

#include <utility.h>
#include <mem.h>
#include <string.h>
#include <cstring.h>

#include "partage\nsdivfct.h"
#include "nsbb\nsmanager.h"
#include "nsbb\nspatbd.h"
#include "nsbb\ns_objs.h"
#include "nssavoir\nsgraphe.h"
#include "nautilus\nssuper.h"
#include "nsdn\nsdn_dlg.h"
#include "nsbb\nsmpidsobj.h"
#include "nsbb\nsmpids.h"
#include "nsbb\nslistwind.h"
#include "dcodeur\decoder.h"
#include "nsbb\nsdefArch.h"

# include "pilot\NautilusPilot.hpp"
# include "nsbb\tagNames.h"
# include "nsbb\nsarc.h"
# include "nsbb\nsbbitem.h"
# include "nsbb\nsbbsmal.h"
# include "nsbb\nsbbtran.h"
# include "nssavoir\nsHealthTeam.h"

long NSDataTree::lObjectCount = 0 ;
long NSDataTreeArray::lObjectCount = 0 ;
long NSDataGraph::lObjectCount = 0 ;
long NSObjectGraphManager::lObjectCount = 0 ;
long NSPersonGraphManager::lObjectCount = 0 ;

// -----------------------------------------------------------------------------
// METHODES DE NSDataTree
// -----------------------------------------------------------------------------
NSDataTree::NSDataTree(NSContexte* pCtx, string treeID, GRAPHTYPE iType)
           :NSRoot(pCtx)
{
	iTypeTree = iType ;
	setTreeID(treeID) ;
	sModelName     = "" ;
	sModelFileName = "" ;

	pPatPathoArray = new NSPatPathoArray(pContexte, iType) ;

	lObjectCount++ ;
}

NSDataTree::NSDataTree(NSDataTree& rv) : NSRoot(rv.pContexte)
{
	iTypeTree      = rv.iTypeTree ;
	sTreeID        = rv.sTreeID ;
	sModelName     = rv.sModelName ;
	sModelFileName = rv.sModelFileName ;

	pPatPathoArray = new NSPatPathoArray(*(rv.pPatPathoArray)) ;

	lObjectCount++ ;
}

NSDataTree::~NSDataTree()
{
	if (pPatPathoArray)
		delete pPatPathoArray ;

	lObjectCount-- ;
}

NSDataTree&
NSDataTree::operator=(NSDataTree& src)
{
	if (this == &src)
  	return *this ;

  iTypeTree      = src.iTypeTree ;
  sTreeID        = src.sTreeID ;
  sModelName     = src.sModelName ;
  sModelFileName = src.sModelFileName ;

  *pPatPathoArray = *(src.pPatPathoArray) ;

	return *this ;
}

int
NSDataTree::operator==(NSDataTree& o)
{
	if ((iTypeTree == o.iTypeTree) && (sTreeID == o.sTreeID) && ((*pPatPathoArray) == (*(o.pPatPathoArray))))
		return 1 ;
	else
		return 0 ;
}

void
NSDataTree::setTreeID(string treeID)
{
	if ((iTypeTree == graphObject) && (strlen(treeID.c_str()) == OBJECT_ID_LEN))
		sTreeID = treeID ;
	else if (iTypeTree == graphPerson)
	{
		if (strlen(treeID.c_str()) == (PAT_NSS_LEN + DOC_CODE_DOCUM_LEN))
			sTreeID = treeID ;
		else
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("graphAndTreeErrors", "invalidTreeId") ;
      sErrorText += string(" setTreeID(") + treeID + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      erreur(sErrorText.c_str(), standardError, 0) ;
      sTreeID = "";
    }
	}
	else
		sTreeID = "" ;
}

void
NSDataTree::developpePatPatho(NSPatPathoArray* pPatPatho)
{
	if ((NULL == pPatPatho) || pPatPatho->empty())
		return ;

	PatPathoIter pptIt ;
	int nbFils ;
	int iLig = 0 ;
	int iCol = 0 ;

	int	iLigNext ;
	// int iColNext ;

	pptIt = pPatPatho->begin();
	while (pptIt != pPatPatho->end())
	{
    //
    // Check free texts ; replace \' with '
    //
    	/*************************************
		string sTL = (*pptIt)->getTexteLibre() ;
		size_t pos = sTL.find("\'") ;
		while (pos != string::npos)
		{
            if ((pos > 0) && (sTL[pos-1] == '\\'))
    	        sTL = string(sTL, 0, pos-1) + string(sTL, pos, strlen(sTL.c_str())-pos) ;
    	    pos = sTL.find("\'", pos+1) ;
        }
        (*pptIt)->setTexteLibre(sTL) ;
        ****************************************/

		//
		// Hidden node - Noeud cach�
		//
		if ((*pptIt)->getLexique() == "900001")
		{
			if ((*pptIt)->getUnit() == "200001")
			{
				nbFils = atoi(((*pptIt)->getComplement()).c_str()) - 1;
				if (nbFils > 0)
				{
					iLig = (*pptIt)->getLigne() ;
					iCol = (*pptIt)->getColonne() ;

					pptIt++ ;
					if (pptIt != pPatPatho->end())
					{
						iLigNext = (*pptIt)->getLigne() ;
						// iColNext = (*pptIt)->getColonne() ;
						if (nbFils != iLigNext - iLig - 1)
						{
							nbFils = iLigNext - iLig - 1 ;
							erreur("NSDataTree::developpePatPatho strange patpatho.", warningError, 0) ;
						}
					}

					for (int i = 0; i < nbFils; i++)
					{
						NSPatPathoInfo* pPatInfo = new NSPatPathoInfo ;
						pPatInfo->setLigne(iLig + i + 1) ;
						pPatInfo->setColonne(iCol + 1) ;
						pPatInfo->setLexique("900002") ;
						pPatPatho->push_back(pPatInfo) ;
					}
          //
          // We need to sort the patpatho, because if we don't do it and
          // the last node is hidden, then it will be followed by the first
          // virtual node we pushed back, and iLigNext and iColNext will be
          // wrong
          //
          sort(pPatPatho->begin(), pPatPatho->end(), infLoc) ;

					// Warning : since the patpatho will grow, we have better repositioning
					// the iterator after
					//
					pptIt = pPatPatho->ChercherItem(iLig, iCol) ;
					if (!pptIt || (pptIt == pPatPatho->end()))
					{
						erreur("NSDataTree::developpePatPatho bad patpatho.", standardError, 0) ;
						return ;
					}
				}
			}
		}
		pptIt++ ;
	}

	sort(pPatPatho->begin(), pPatPatho->end(), infLoc) ;
}

void
NSDataTree::contractePatPatho(NSPatPathoArray* pPatPatho)
{
	if ((NULL == pPatPatho) || (pPatPatho->empty()))
		return ;

	PatPathoIter pptIt = pPatPatho->begin();
	while (pptIt != pPatPatho->end())
	{
		pptIt = pPatPatho->ChercherItem("900002") ;
		if ((pPatPatho->end() != pptIt) && (NULL != pptIt))
		{
			delete (*pptIt) ;
			pPatPatho->erase(pptIt) ;
		}
	}
}

void
NSDataTree::getPatPatho(NSPatPathoArray* pPatPatho, bool bModePilot)
{
	if (NULL == pPatPatho)
		return ;

	*pPatPatho = *pPatPathoArray ;

	if (!bModePilot)
		developpePatPatho(pPatPatho) ;
}

void
NSDataTree::setPatPatho(NSPatPathoArray* pPatPatho, bool bModePilot)
{
	if (NULL == pPatPatho)
		return ;

	if (!bModePilot)
		contractePatPatho(pPatPatho) ;

	*pPatPathoArray = *pPatPatho ;
}

string
NSDataTree::genereXML()
{
  return pPatPathoArray->genereXML() ;
}

size_t
NSDataTree::size()
{
  return pPatPathoArray->size() ;
}

void
NSDataTree::sortPPTByLocalisation()
{
  sort(pPatPathoArray->begin(), pPatPathoArray->end(), infLoc) ;
}

// readParadoxTree v�rifie juste qu'il existe un ID valide
// et que la patpatho se charge correctement
bool
NSDataTree::readParadoxTree()
{
	if (sTreeID == "")
	{
		erreur("L'arbre � charger ne poss�de pas d'identifiant.", standardError, 0) ;
		return false ;
	}

	if ((iTypeTree != graphPerson) && (iTypeTree != graphObject))
	{
		erreur("L'arbre � charger ne poss�de pas un type valide.", standardError, 0) ;
		return false ;
	}

	return false ;
}

// on suppose comme pr�condition au writeParadoxTree que l'arbre
// est nouveau ou qu'il a �t� pr�alablement charg� depuis la base

bool
NSDataTree::writeParadoxTree(NSPatPathoArray* pPatPathoTree)
{
	// modification de la patpatho
	if (pPatPathoTree != 0)
  	*pPatPathoArray = *pPatPathoTree ;

	return true ;
}

/*#ifdef N_TIERS
bool
NSDataTree::prepareTree(NSPatPathoArray* pPatPathoTree)
{
     if (iTypeTree == graphObject)
    {
 //................. a ajouter ...............
    }
    else if (iTypeTree == graphPerson)
    {
        if (sTreeID == "")
        {
            if (pPatPathoTree == 0)
               // setTreeID((*(pPatPathoArray->begin()))->getDoc());
                setTreeID((*(pPatPathoArray->begin()))->getDoc());
            else
                setTreeID((*(pPatPathoTree->begin()))->getDoc());
        }
    }
    else
    {
        erreur("Type d'objet incorrect dans l'objet DataTree.", standardError, 0) ;
        return false;
    }
    // modification de la patpatho
    if (pPatPathoTree != 0)
        *pPatPathoArray = *pPatPathoTree;

    return true;
}
#endif      */


// --------------------------------------------------------------------------
// ------------------------ METHODES DE NSDataTreeArray ----------------------
// --------------------------------------------------------------------------

NSDataTreeArray::NSDataTreeArray(NSDataTreeArray& rv)
                :NSDataTreeVector()
{
try
{
	if (!(rv.empty()))
		for (NSDataTreeIter i = rv.begin(); i != rv.end(); i++)
			push_back(new NSDataTree(*(*i))) ;

	lObjectCount++ ;
}
catch (...)
{
	erreur("Exception NSDataTreeArray copy ctor.", standardError, 0) ;
}
}

voidNSDataTreeArray::vider()
{
	if (empty())
		return ;

	for (NSDataTreeIter i = begin(); i != end(); )
	{
		delete *i ;
		erase(i) ;
	}
}

NSDataTreeArray::~NSDataTreeArray()
{
	vider() ;

	lObjectCount-- ;
}

NSDataTreeArray&
NSDataTreeArray::operator=(NSDataTreeArray src)
{
try
{
	if (&src == this)
  	return *this ;

	vider() ;

	if (!(src.empty()))		for (NSDataTreeIter i = src.begin(); i != src.end(); i++)
			push_back(new NSDataTree(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception NSDataTreeArray (= operator).", standardError, 0) ;
	return *this ;
}
}

int
NSDataTreeArray::operator==(NSDataTreeArray& o)
{
try
{
    NSDataTreeIter i,j;
    int egal = 1;    if (empty())    {        if (o.empty())            return 1;        else            return 0;    }    i = begin();    j = o.begin();    while ((i != end()) && (j != o.end()))    {        if (!((*(*i)) == (*(*j))))        {            egal = 0;            break;        }        i++;        j++;    }    if (egal)    {        if ((i != end()) || (j != o.end()))            egal = 0;    }    return egal;
}
catch (...)
{
	erreur("Exception NSDataTreeArray (== operator).", standardError, 0) ;
	return 0 ;
}
}

bool
NSDataTreeArray::ExisteTreeID(string sObjectID, NSDataTreeIter* pIter)
{
	if ((sObjectID == "") || (empty()))
		return false ;

	for (NSDataTreeIter i = begin(); i != end(); i++)
	{
  	if (sObjectID == (*i)->getTreeID())
    {
    	if (pIter)
      	*pIter = i ;

      return true ;
    }
  }

	if (pIter)
		*pIter = NULL ;

	return false ;
}

bool
NSDataTreeArray::ExisteTree(string sTypeLex, NSContexte* pCtx, NSDataTreeIter* pIter)
{
	PatPathoIter iter ;
	NSPatPathoArray PatPathoArray(pCtx) ;

	if ((sTypeLex != "") && (!empty()))
	{
  	for (NSDataTreeIter i = begin(); i != end(); i++)    {
    	PatPathoArray.vider() ;
      (*i)->getPatPatho(&PatPathoArray) ;

      if (!(PatPathoArray.empty()))
      {
      	iter = PatPathoArray.begin() ;

        if (sTypeLex == (*iter)->getLexique())
        {
        	if (pIter)
          	*pIter = i ;

          return true ;
        }
      }
    }
  }

	if (pIter)
		*pIter = NULL ;

	return false ;
}

bool
NSDataTreeArray::DetruireTree(string sTypeLex, NSContexte* pCtx)
{
	PatPathoIter iter ;
	NSPatPathoArray PatPathoArray(pCtx) ;

	if ((sTypeLex != "") && (!empty()))
	{
  	for (NSDataTreeIter i = begin(); i != end(); i++)    {
    	PatPathoArray.vider();
      (*i)->getPatPatho(&PatPathoArray) ;

      if (!(PatPathoArray.empty()))
      {
      	iter = PatPathoArray.begin() ;

        if (sTypeLex == (*iter)->getLexique())
        {
        	delete *i ;
          erase(i) ;
          return true ;
        }
      }
    }
  }

	return false ;
}

// *************************************************************************
// *                          METHODES DE NSArcLink                        *
// *************************************************************************

NSArcLink::NSArcLink(NSContexte* pCtx) : NSRoot(pCtx)
{
    object = "";
    node = "";
    type = "";
    model_object_id = "";
}

NSArcLink::NSArcLink(NSContexte* pCtx, NSPatLinkInfo* pLinkInfo) : NSRoot(pCtx)
{
	NSRootLink rootLink ;
  NSRootLink::NODELINKTYPES iNodeLink = rootLink.donneRelation(pLinkInfo->getLien()) ;

	if (iNodeLink == NSRootLink::archetype)
	{
		setFullNode(pLinkInfo->getQualifie()) ;
    type = pLinkInfo->getLien() ;
    model_object_id = pLinkInfo->getQualifiant() ;
	}
  else if (iNodeLink == NSRootLink::referentialOf)
  {
  	setFullNode(pLinkInfo->getQualifiant()) ;
    type = pLinkInfo->getLien() ;
    model_object_id = pLinkInfo->getQualifie() ;
  }
  else
  {
  	erreur("Bad link (should be archetype or referentialOf)", standardError, 0) ;
    object = "" ;
    node = "" ;
    type = "" ;
    model_object_id = "" ;
	}
}

NSArcLink::NSArcLink(NSContexte* pCtx, string sObject, string sNode, string sType, string sModelID) : NSRoot(pCtx)
{
    object = sObject;
    node = sNode;
    type = sType;
    model_object_id = sModelID;
}

NSArcLink::NSArcLink(NSArcLink& rv) : NSRoot(rv.pContexte)
{
    object = rv.object;
    node = rv.node;
    type = rv.type;
    model_object_id = rv.model_object_id;
}

NSArcLink::~NSArcLink()
{
}

NSArcLink&
NSArcLink::operator=(NSArcLink src)
{
	if (&src == this)
  	return *this ;

  object = src.object ;
  node = src.node ;
  type = src.type ;
  model_object_id = src.model_object_id ;

  return *this ;
}

int
NSArcLink::operator==(NSArcLink& o)
{
    if ((object == o.object) &&
        (node == o.node) &&
        (type == o.type) &&
        (model_object_id == o.model_object_id))
        return 1;
    else
        return 0;
}

void
NSArcLink::setFullNode(string sNode)
{
    if (strlen(sNode.c_str()) > OBJECT_ID_LEN)
    {
        object = string(sNode, 0, OBJECT_ID_LEN);
        node = string(sNode, OBJECT_ID_LEN, strlen(sNode.c_str()) - OBJECT_ID_LEN);
    }
    else
    {
        object = sNode;
        node = "";
    }

}

string
NSArcLink::getFullNode()
{
    return (object + node);
}

// --------------------------------------------------------------------------
// ------------------------ METHODES DE NSArcLinkArray ----------------------
// --------------------------------------------------------------------------

NSArcLinkArray::NSArcLinkArray(NSArcLinkArray& rv)
               :NSArcLinkVector()
{
try
{
  if (!(rv.empty()))
    for (NSArcLinkIter i = rv.begin() ; rv.end() != i ; i++)
      push_back(new NSArcLink(*(*i))) ;
}
catch (...)
{
  erreur("Exception NSArcLinkArray copy ctor.", standardError, 0) ;
}
}

voidNSArcLinkArray::vider()
{
  if (empty())
    return ;

  for (NSArcLinkIter i = begin() ; end() != i ; )
  {
    delete *i ;
    erase(i) ;
  }
}

NSArcLinkArray::~NSArcLinkArray()
{
	vider() ;
}

NSArcLinkArray&
NSArcLinkArray::operator=(NSArcLinkArray src)
{
try
{
	if (&src == this)
  	return *this ;

  vider() ;

  if (!(src.empty()))  	for (NSArcLinkIter i = src.begin() ; src.end() != i ; i++)
    	push_back(new NSArcLink(*(*i))) ;

  return *this ;
}
catch (...)
{
	erreur("Exception NSArcLinkArray (= operator).", standardError, 0) ;
  return *this ;
}
}

int
NSArcLinkArray::operator==(NSArcLinkArray& o)
{
try
{
  int egal = 1 ;
  if (empty())  {    if (o.empty())      return 1 ;    else      return 0 ;  }  NSArcLinkIter i = begin() ;  NSArcLinkIter j = o.begin() ;  while ((end() != i) && (o.end() != j))  {    if (!((*(*i)) == (*(*j))))    {      egal = 0 ;      break ;    }    i++ ;    j++ ;  }  if (egal)  {    if ((end() != i) || (o.end() != j))      egal = 0;  }  return egal ;
}
catch (...)
{
  erreur("Exception NSArcLinkArray (== operator).", standardError, 0) ;
  return 0 ;
}
}

//**************************************************************************
//*               Methode de NSNodeRight                                   *
//**************************************************************************

/*
** The first element is an id which permit to find the document or the patPatho
** The second element is the right of this node or document
*/
NSNodeRight::NSNodeRight(std::string nod, std::string rig)
{
  node  = nod ;
  right = rig ;
}

NSNodeRight::NSNodeRight()
{
  node  = "" ;
  right = "" ;
}

NSNodeRight::NSNodeRight(NSNodeRight& rig)
{
  node  = rig.node ;
  right = rig.right ;
}

NSNodeRight& NSNodeRight::operator = (NSNodeRight& rig)
{
  if (&rig == this)
  	return *this ;

  node  = rig.node ;
  right = rig.right ;

  return *this ;
}

bool NSNodeRight::operator == (NSNodeRight& rig)
{
  return ((node == rig.node) && (right == rig.right)) ;
}

//**************************************************************************
//*         Array of NSNodeRight                                               *
//**************************************************************************

NSNodeRightArray::NSNodeRightArray(NSNodeRightArray& rv)
{
try
{
	if (false == rv.empty())
		for (NSNodeRightIter i = rv.begin() ; rv.end() != i ; i++)
			push_back(new NSNodeRight(*(*i))) ;
}
catch (...)
{
	erreur("Exception NSNodeRightArray copy ctor.", standardError, 0) ;
}
}

NSNodeRightArray::~NSNodeRightArray()
{
	vider() ;
}

void
NSNodeRightArray::vider()
{
	if (empty())
		return ;

	for (NSNodeRightIter i = begin() ; end() != i ; )
	{
		delete *i ;
		erase(i) ;
	}
}

NSNodeRightArray&
NSNodeRightArray::operator=(NSNodeRightArray src)
{
try
{
	if (&src == this)
  	return *this ;

  vider() ;

  if (!(src.empty()))  	for (NSNodeRightIter i = src.begin() ; src.end() != i ; i++)
    	push_back(new NSNodeRight( *(*i)) ) ;

  return *this ;
}
catch (...)
{
	erreur("Exception NSNodeRightArray (= operator).", standardError, 0) ;
	return *this ;
}
}

int
NSNodeRightArray::operator==(NSNodeRightArray& o)
{
try
{
  NSNodeRightIter i, j ;
  int egal = 1 ;  if (empty())  {  	if (o.empty())    	return 1 ;    else    	return 0 ;  }  i = begin() ;  j = o.begin() ;  while ((i != end()) && (j != o.end()))  {  	if (!((*(*i)) == (*(*j))))    {    	egal = 0 ;      break ;  	}    i++ ;    j++ ;  }  if (egal)  {  	if ((i != end()) || (j != o.end()))    	egal = 0 ;  }  return egal ;
}
catch (...)
{
	erreur("Exception NSNodeRightArray (== operator).", standardError, 0) ;
	return 0 ;
}
}

/*
**  Function that search a right for a node
**  Result : If the node is fond , we return the right
**           Else return a Null String "";
*/
std::string
NSNodeRightArray::find(std::string temp)
{
	if (empty() == true)
		return "" ;

  std::vector<NSNodeRight* >::iterator result ;
  result = find_if(begin(), end(), RightStringPredicat(&temp)) ;

  if (result != end())
    return (*result)->right ;

  return "" ;
}

/*
**  Function that search a NSRight Struct
*/
std::string
NSNodeRightArray::operator[](std::string temp)
{
  if (empty() == true)
    return "" ;
  return find(temp) ;
}

/*
**  Function that search a NSRight Struct
*/
void NSNodeRightArray::set(std::string node, std::string right)
{
	NSNodeRight* temp = new NSNodeRight(node, right) ;
	if (empty() == false)
	{
		std::vector<NSNodeRight* >::iterator result ;
		result = find_if(begin(), end(), RightTester(temp)) ;
		if (end() == result)
			push_back(temp) ;
		else
		{
			(*result)->right = right ;
			if (NULL != temp)
				delete (temp) ;
		}
	}
	else
		push_back(temp) ;
}

/*
** Remove all the document excepted the right of the document itself
*/
void NSNodeRightArray::RemoveAllTreeNodeOfDocument(std::string doc)
{
	if (empty() == true)
		return ;

	std::vector<NSNodeRight* >::iterator i ;
	for (i = begin(); end() != i ; )
	{
		if (((*i)->node.compare(0, doc.size(), doc.c_str()) == 0) && ((*i)->node.size() != doc.size()))
		{
			delete *i ;
			erase(i) ;
		}
		else
			i++ ;
	}
}

void NSNodeRightArray::RemoveDocument(std::string doc)
{
	if (empty() == true)
		return ;

	std::vector<NSNodeRight* >::iterator i;
	for (i = begin() ; end() != i ; )
	{
		if ( (*i)->node.compare(0, doc.size(), doc.c_str()) == 0)
		{
			delete *i ;
			erase(i) ;
		}
		else
			i++ ;
	}
}

// *************************************************************************
// *                          METHODES DE NSDataGraph                      *
// *************************************************************************

NSDataGraph::NSDataGraph(NSContexte* pCtx, GRAPHTYPE typeGraph) : NSRoot(pCtx)
{
	setGraphType(typeGraph) ;
	setGraphID("") ;
	setLastTree("") ;

	lObjectCount++ ;
}

NSDataGraph::NSDataGraph(NSDataGraph& rv) : NSRoot(rv.pContexte)
{
  sGraphID   = rv.sGraphID;
  iTypeGraph = rv.iTypeGraph;
  sLastTree  = rv.sLastTree;

  aTrees  = rv.aTrees ;
  aLinks  = rv.aLinks ;
  aArchs  = rv.aArchs ;
  aRights = rv.aRights ;

	lObjectCount++ ;
}

NSDataGraph::~NSDataGraph()
{
	lObjectCount-- ;
}

NSDataGraph&
NSDataGraph::operator=(NSDataGraph src)
{
	if (&src == this)
  	return *this ;

  sGraphID   = src.sGraphID ;
  iTypeGraph = src.iTypeGraph ;
  sLastTree  = src.sLastTree ;

  aTrees  = src.aTrees ;
  aLinks  = src.aLinks ;
  aArchs  = src.aArchs ;
  aRights = src.aRights ;

  return *this ;
}

int
NSDataGraph::operator==(NSDataGraph& o)
{
	return ((aTrees == o.aTrees) && (aLinks == o.aLinks) && (aArchs == o.aArchs)) ;
}

void
NSDataGraph::graphReset()
{
  sGraphID = "" ;
  setLastTree("") ;

  aTrees.vider() ;
  aLinks.vider() ;
  aArchs.vider() ;
  aRights.vider() ;
}

void
NSDataGraph::setLastTree(string sLast)
{
	if (string("") == sLast)
	{
		if (iTypeGraph == graphPerson)
		{
    	string sPerson ;
      if (sGraphID != "")
      	sPerson = string(sGraphID, 0, PAT_NSS_LEN) ;
      else
      	sPerson = string(PAT_NSS_LEN, '#') ;
      string sDocum = string(DOC_CODE_DOCUM_LEN, '0') ;
      sDocum[0] = '#' ;
      sLastTree = sPerson + sDocum ;
    }
    else
    {
    	string sObject = string(OBJECT_ID_LEN, '0') ;
      sObject[0] = '$' ;
      sObject[1] = '#' ;
      sLastTree = sObject ;
    }
	}
  else if (strlen(sLast.c_str()) == OBJECT_ID_LEN)
  {
		sLastTree = sLast ;
  }
	else
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("graphAndTreeErrors", "invalidObjectGraphCounter") + string(" setLastTree(") + sLast + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		sLastTree = "" ;
	}

	if (false == aRights.empty())
		for (NSNodeRightIter k = aRights.begin(); k != aRights.end(); )
		{
    	if ((*k)->node == "")
      {
      	delete (*k) ;
        aRights.erase(k) ;
      }
      else
      	k++ ;
		}
}

string
NSDataGraph::getLastContribution()
{
	if (aTrees.empty())
		return "" ;

	PatPathoIter iter, iterDate ;
	string sLastDate = string("000000000000") ;
	string sLastContribution, sDateContrib, sTemp ;
	NSPatPathoArray PatPathoArray(pContexte) ;

	for (NSDataTreeIter i = aTrees.begin(); i != aTrees.end(); i++)
	{
  	PatPathoArray.vider() ;
    (*i)->getPatPatho(&PatPathoArray) ;

    if (false == PatPathoArray.empty())
    {
    	iter = PatPathoArray.begin() ;

      if (string("LCTRI1") == (*iter)->getLexique())
      {
      	iterDate = PatPathoArray.ChercherItem("KOUVR1") ;
        if (iterDate != PatPathoArray.end())
        {
        	int iCol = (*iterDate)->getColonne() ;
          iterDate++ ;
          while ((iterDate != PatPathoArray.end()) && ((*iterDate)->getColonne() > iCol))
          {
          	string sUnite  = "" ;
            string sFormat = "" ;
            string sValeur = "" ;

            sTemp = (*iterDate)->getUnit() ;
            pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
            sTemp = (*iterDate)->getLexique() ;
            pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
            sValeur = (*iterDate)->getComplement() ;

            if (sUnite == "2DA02")
            	sDateContrib = sValeur ;

            iterDate++ ;
          }

          if (sDateContrib > sLastDate)
          {
          	sLastDate = sDateContrib ;
            sLastContribution = (*i)->getTreeID() ;
          }
        }
      }
    }
	}

	return sLastContribution ;
}

string
NSDataGraph::getNextTreeID()
{
	string sLast = getLastTree() ;

	if (iTypeGraph == graphPerson)
	{
  	string sPerson = string(sLast, 0, PAT_NSS_LEN) ;
    string sDocum  = string(sLast, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;
    if (!incrementeCode(sDocum))
    	return "" ;

    sLast = sPerson + sDocum ;
	}
	else
	{
  	if (!incrementeCode(sLast))
    	return "" ;
	}

	setLastTree(sLast) ;
	return getLastTree() ;
}


bool
NSDataGraph::getTree(string sTreeID, NSPatPathoArray* pPatPatho, string* psDocRosace)
{
	if (sTreeID == "")
		return false ;

	NSDataTreeIter iterTree ;
	PatPathoIter iterPatPat ;

	*psDocRosace = aRights.find(sTreeID) ;

	if (pPatPatho == NULL)
		return false ;
//  pPatPatho->empty() ;

	if (!aTrees.ExisteTreeID(sTreeID, &iterTree))
	{
		// If we are looking for a collective or a group tree, it is not an error
    // if we can't find it (we may just have the meta)
  	string sLocalTreeID = getTreeIDFromID(sTreeID) ;
    GRAPHELEMTYPE treeType = getGraphElementTypeFromID(sLocalTreeID) ;
    if ((treeType == isCollectiveID) || (treeType == isGroupID))
    	return false ;

		string sErrorText = pContexte->getSuperviseur()->getText("graphAndTreeErrors", "noTreeWithThisIdInTheGraph") ;
		sErrorText += string(" getTree(") + sTreeID + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	// on r�cup�re d'abord une copie de la patpatho de l'arbre trouv�
	(*iterTree)->getPatPatho(pPatPatho) ;
  if (pPatPatho->empty())
  	return true ;

	// on parcours l'array des mod�les pour ajouter les sArchetype
	// aux noeuds de la nouvelle patpatho
  if (false == aArchs.empty())
	{
  	string sArchetypeString = string("AR") ;

		for (NSArcLinkIter i = aArchs.begin() ; i != aArchs.end() ; i++)
		{
			if ((*i)->type == sArchetypeString)
			{
				if ((*i)->object == (*(pPatPatho->begin()))->getDoc())
				{
					string sNodeID = (*i)->getFullNode() ;
					iterPatPat = pPatPatho->ChercherNoeud(sNodeID) ;
					if ((iterPatPat != NULL) && (iterPatPat != pPatPatho->end()))
					{
						string sModelName = pContexte->getArcManager()->DonneNomArchetypeDansLibrairie(NSArcManager::archetype, (*i)->model_object_id) ;
						(*iterPatPat)->setArchetype(sModelName) ;
					}
				}
			}
		}
	}

  if (false == aRights.empty())
	  for (PatPathoIter i = pPatPatho->begin() ; i != pPatPatho->end() ; i++)
	  {
		  string rootId = (*i)->getNode() ;
		  string rightID = aRights[rootId] ;
		  if (rightID != "")
			  (*i)->setNodeRight(rightID) ;
	  }

	return true ;
}

//
// WARNING: setTree doesn't call updateNodesTL... so beware that if free texts
//          have been changed, it will not be taken into account (don't forget
//          to call updateNodesTL before, because once the tree has been set
//          into the graph, updateNodesTL can no longer work
//
string
NSDataGraph::setTree(NSPatPathoArray* pPatPatho, string sDocRosace, string sCode)
{
try
{
	if ((NULL == pPatPatho) || (pPatPatho->empty()))
		return string("") ;

	// bool bTreeIsRoot;
	bool bNewTree = true ;
	string sTreeID = "" ;
	string sLastNode = string(PPD_NOEUD_LEN, '0') ;
	sLastNode[0] = '#' ;
	string sCurrentNode ;

	NSLinkManager LinkManager(pContexte, this) ;

	// on commence par v�rifier si la patpatho est vierge
	// ou si elle d�tient d�j� un treeID
	PatPathoIter itRoot = pPatPatho->begin() ;

  if (string("") != sCode)
  	sTreeID = sCode ;
  else
  	sTreeID = (*itRoot)->getDoc() ;

  if (string("") != sTreeID)
  {
  	if (strlen(sTreeID.c_str()) != OBJECT_ID_LEN)
    {
      string sErrorText = pContexte->getSuperviseur()->getText("graphAndTreeErrors", "tryingToAddATreeWithAnInvalidId") ;
			sErrorText += string(" setTree(") + sTreeID + string(")") ;
    	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
			erreur(sErrorText.c_str(), standardError, 0) ;
      return "" ;
    }

    bNewTree = !(aTrees.ExisteTreeID(sTreeID)) ;
  }

	if (bNewTree)
	{
		// Dans ce cas, soit le graphe est vide et on r�cup�re le compteur
		// initialis� � la cr�ation du graphe. Sinon on r�cup�re le prochain
		// num�ro d'arbre � instancier
		if ((getGraphID() == "") && (sCode == ""))
		{
			sTreeID = getLastTree() ;
			setGraphID(sTreeID) ;
			// bTreeIsRoot = true ;
		}
		else if (sTreeID == "")
		{
			if( sCode == "")
				sTreeID = getNextTreeID();
			else
				// sTreeID =  pContexte->getPatient()->pGraphPerson->pDataGraph->getLastTree();
				sTreeID = sCode;
			// bTreeIsRoot = false;
		}
		// else
		//	bTreeIsRoot = false ;
	}

	// Dans tous les cas, on commence par num�roter les nouveaux noeuds
	// de la patpatho et mettre � jour leurs arrays de liens en attente.
	for (PatPathoIter i = pPatPatho->begin(); i != pPatPatho->end(); i++)
	{
		sCurrentNode = (*i)->getNodeID() ;

		if ((string("") == (*i)->getDoc()) || ((*i)->getDoc() != sTreeID))
		{
      /*** On ne force plus une erreur ici car le cas NodeId != ""
           se produit fr�quemment avec TreeId == "" dans le cas d'un InserePatPatho
           � partir d'une patpatho existante (car mal g�r� dans nspatpat).
           On choisi de remettre le noeud � "" car on doit avoir ici un nouveau noeud.
           ---------------------------------------------------------------------------
      if (sCurrentNode != "")
			{
				erreur("Un nouveau noeud poss�de d�j� un identifiant.", standardError, 0) ;
				return "" ;
			}
      ***/

    	if (string("") != sCurrentNode)
      	sCurrentNode = string("") ;

			(*i)->setTreeID(sTreeID) ;
		}

		if (string("") == sCurrentNode)
		{
			// on fournit un identifiant temporaire au nouveau noeud.
			if (false == incrementeCode(sLastNode))
			{
        string sErrorText = pContexte->getSuperviseur()->getText("graphAndTreeErrors", "errorWhenGettingAnIdForANewNode") ;
				sErrorText += string(" incrementeCode(") + sLastNode + string(")") ;
    		pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
				erreur(sErrorText.c_str(), standardError, 0) ;
				return string("") ;
			}

			sCurrentNode = sLastNode ;

			(*i)->setNodeID(sCurrentNode) ;
			(*i)->numberTemporaryNodes(&LinkManager) ;
		}
		else
		{
			// cas des anciens noeuds : Si l'archetype du noeud est vide, on le
			// retire de l'array des mod�les si il s'y trouve un autre pour ce noeud.
			if ((string("") == (*i)->getArchetype()) && (false == aArchs.empty()))
			{
      	string sArchetypeString = string("AR") ;

				for (NSArcLinkIter j = aArchs.begin(); aArchs.end() != j ; )
				{
					if (((*j)->type == sArchetypeString) && ((*j)->getFullNode() == (*i)->getNode()))
					{
						delete (*j) ;
						aArchs.erase(j) ;
					}
					else
						j++ ;
				}
			}
		}

		// Enfin, pour chaque noeud, si l'archetype est non vide, on l'ajoute � l'array des
		// mod�les s'il n'existe pas d�j� (sinon mise � jour)
		if (string("") != (*i)->getArchetype())
		{
			bool trouve = false ;

			if (false == aArchs.empty())
			{
      	string sArchetypeString = string("AR") ;

				for (NSArcLinkIter j = aArchs.begin(); aArchs.end() != j ; j++)
				{
					if ((*j)->type == sArchetypeString)
					{
						if ((*j)->getFullNode() == (*i)->getNode())
						{
							(*j)->model_object_id = pContexte->getSuperviseur()->getArcManager()->DonneNoeudArchetype(NSArcManager::archetype,
                                                                                                (*i)->getArchetype());
							trouve = true ;
							break ;
						}
					}
				}
			}

			if (!trouve)
			{
      	string sArchetypeString = string("AR") ;

      	NSSuper *pLocalSuper = pContexte->getSuperviseur() ;
      	NSArcManager *pLocalArcManager = pLocalSuper->getArcManager() ;
        string sModelID = pLocalArcManager->DonneNoeudArchetype(NSArcManager::archetype, (*i)->getArchetype()) ;
//				string sModelID = pContexte->getSuperviseur()->getArcManager()->DonneNoeudArchetype(NSArcManager::archetype, (*i)->getArchetype());
        if (string("") != sModelID)
				  aArchs.push_back(new NSArcLink(pContexte, (*i)->getDoc(), (*i)->getNodeID(), sArchetypeString, sModelID));
			}
		}
	}


	/*
	** Gestion des rosaces de droits - Management of rights rosaces
	*/
	if (bNewTree == false)
		aRights.RemoveDocument(sTreeID) ;

	if (sDocRosace != "")
		aRights.set(sTreeID, sDocRosace) ;

	for (PatPathoIter i = pPatPatho->begin(); i != pPatPatho->end(); i++)
	{
		string  rig = (*i)->getNodeRight() ;
		if (rig != "")
			aRights.set((*i)->getNode(), rig) ;
	}

	if (bNewTree)
	{
		NSDataTree* pNewTree = new NSDataTree(pContexte, sTreeID, iTypeGraph) ;
		pNewTree->setPatPatho(pPatPatho) ;
		aTrees.push_back(pNewTree) ;
	}
	else
	{
		NSDataTreeIter treeIter ;
		bool bExist = aTrees.ExisteTreeID(sTreeID, &treeIter) ;
		if (bExist && treeIter)
			(*treeIter)->setPatPatho(pPatPatho) ;
	}

	return sTreeID ;
}
catch (...)
{
	erreur("Exception NSDataGraph::setTree", standardError, 0) ;
	return "" ;
}
}

bool
NSDataGraph::updateNodesTL(NSPatPathoArray* pPatPatho, string sCode)
{
try
{
  if ((pPatPatho == NULL) || (pPatPatho->empty()))
		return false ;

	if (sCode == "")
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("generalLanguageForFunctionCall", "emptyParameter") ;
		sErrorText += string(" updateNodesTL, sCode") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	bool bNewTree = true ;
	string sTreeID = "" ;
	string sLastNode = string(PPD_NOEUD_LEN, '0') ;
	sLastNode[0] = '#' ;
	string sCurrentNode ;
	NSDataTreeIter iterTree = NULL ;

	// NSLinkManager* pLinkManager = new NSLinkManager(pContexte, this) ;

	// on commence par v�rifier si la patpatho est nouvelle
	// ou si elle appartient d�j� au graphe
	sTreeID = sCode ;
	if (strlen(sTreeID.c_str()) != OBJECT_ID_LEN)
	{
    string sErrorText = pContexte->getSuperviseur()->getText("graphAndTreeErrors", "invalidTreeId") ;
		sErrorText += string(" updateNodesTL - ") + sTreeID ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	bNewTree = !(aTrees.ExisteTreeID(sTreeID, &iterTree)) ;

	if (bNewTree)
	{
		for (PatPathoIter i = pPatPatho->begin(); i != pPatPatho->end(); i++)
		{
			sCurrentNode = (*i)->getNodeID() ;

			// Document sans Id, les noeuds n'ont pas d'identifiant, on leur en donne un
			if ((*i)->getDoc() == "")
				(*i)->setTreeID(sTreeID) ;

			// Noeud ancien
			//
			if (string("") != sCurrentNode)
			{
      	string sErrorText = pContexte->getSuperviseur()->getText("graphAndTreeErrors", "aNewNodeAlreadyOwnsAnId") ;
				sErrorText += string(" updateNodesTL - ") + sCurrentNode ;
    		pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
				erreur(sErrorText.c_str(), standardError, 0) ;
				return false;
			}
		}
		return true ;
	}

	// ATTENTION : Ici le getPatPatho ne fonctionne pas comme le getTree
	// il ne replace pas notament les sArchetype de la patpatho, qui sont donc vides.
	// Il faut donc �viter de tester les archetypes et les droits dans le changement
	// de noeud par la suite (ici juste en dessous)
	NSPatPathoArray OldPatPathoArray(pContexte) ;
	(*iterTree)->getPatPatho(&OldPatPathoArray) ;

	for (PatPathoIter i = pPatPatho->begin(); i != pPatPatho->end(); i++)
	{
		sCurrentNode = (*i)->getNodeID() ;

		// Document sans Id, les noeuds n'ont pas d'identifiant, on leur en donne un
		if ((*i)->getDoc() == "")
			(*i)->setTreeID(sTreeID) ;

		// Noeud ancien
		//
		if (sCurrentNode != "")
		{
			string sNoeud = sTreeID + sCurrentNode ;
			PatPathoIter iterNode = OldPatPathoArray.ChercherNoeud(sNoeud) ;
			if ((iterNode != OldPatPathoArray.end()) && (iterNode != NULL))
			{
				if (!((*i)->estMemeNode(*iterNode)))
				{
					// if (i == pPatPatho->begin())
					//     ::MessageBox(0, "Attention : Reset du noeud root", "Message Nautilus", MB_OK);

          // We are in the case where a node's content has changed
          // It appears to be a good idea to swap all previous links
          //
          NSLinkManager LinkManager(pContexte, this) ;
          LinkManager.swapLiens(sNoeud, *i) ;

					(*i)->setNodeID("") ;
				}

				delete *iterNode ;
				OldPatPathoArray.erase(iterNode) ;
			}
			else
			{
        string sErrorText = pContexte->getSuperviseur()->getText("graphAndTreeErrors", "aNodeDisappearedFromGraph") ;
				sErrorText += string(" updateNodesTL - ") + sNoeud ;
    		pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
				erreur(sErrorText.c_str(), standardError, 0) ;
				return false ;
			}
		}
	}

	return true ;
}
catch (...)
{
	erreur("Exception NSDataGraph::updateNodesTL", standardError, 0) ;
	return false ;
}
}

/**
* Suppression de l'arbre d'index sTreeID du graphe
* Removing tree whose index is sTreeID from graph
*/
bool
NSDataGraph::removeTree(string sTreeID)
{
try
{
	if (sTreeID == "")
		return false ;

	NSPatPathoArray PatPatho(pContexte) ;

	NSDataTreeIter iterTree ;

	if (aTrees.ExisteTreeID(sTreeID, &iterTree))
		(*iterTree)->getPatPatho(&PatPatho) ;
	else
		return false ;

	NSLinkManager LinkManager(pContexte, this) ;

	// destruction des liens
	if (false == LinkManager.detruireTousLesLiens(sTreeID))
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("graphAndTreeErrors", "cannotRemoveLinksForTree") ;
		sErrorText += string(" detruireTousLesLiens(") + sTreeID + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	// destruction des archetypes reli�s au tree
  if ((false == PatPatho.empty()) && (false == aArchs.empty()))
	{
  	string sArchetypeString = string("AR") ;

		for (PatPathoIter i = PatPatho.begin(); i != PatPatho.end(); i++)
		{
			if ((*i)->getArchetype() != "")
			{
				for (NSArcLinkIter j = aArchs.begin(); j != aArchs.end(); )
				{
					if (((*j)->type == sArchetypeString) && ((*j)->getFullNode() == (*i)->getNode()))
					{
						delete (*j) ;
						aArchs.erase(j) ;
					}
					else
						j++ ;
				}
			}
		}
	}

	// destruction des droits
	aRights.RemoveAllTreeNodeOfDocument(sTreeID);

	// on d�truit l'arbre
	delete (*iterTree) ;
	aTrees.erase(iterTree) ;

	return true ;
}
catch (...)
{
	erreur("Exception NSDataGraph::removeTree", standardError, 0) ;
	return false ;
}
}

bool
NSDataGraph::replaceTree(string sTreeID, string sNewTreeID, NSPatPathoArray* pNewPatPatho, string sNewDocRosace)
{
try
{
	NSDataTreeIter iterTree;

	if (sGraphID == sTreeID)
		setGraphID(sNewTreeID) ;

	// Remplacement de l'arbre
	if (aTrees.ExisteTreeID(sTreeID, &iterTree))
	{
		(*iterTree)->setPatPatho(pNewPatPatho) ;
		(*iterTree)->setTreeID(sNewTreeID) ;
	}
	else
		return false ;

	// Remplacement des liens
	// Attention : g�re les liens au niveau Tree pas au niveau Noeud
	if (!(aLinks.empty()))
	{
		for (NSPatLinkIter i = aLinks.begin(); i != aLinks.end(); i++)
		{
			if ((*i)->getQualifie() == sTreeID)
      	(*i)->setQualifie(sNewTreeID) ;

			if ((*i)->getQualifiant() == sTreeID)
      	(*i)->setQualifiant(sNewTreeID) ;
		}

		// Suppression des doublons
		// Note : on conserve i++ car on erase forc�ment l'�l�ment apr�s i
		for (NSPatLinkIter i = aLinks.begin() ; aLinks.end() != i ; i++)
		{
			NSPatLinkIter j = i ;
			j++ ;
			for ( ; j!= aLinks.end(); )
			{
				if ((*(*i)) == (*(*j)))
				{
					delete (*j) ;
					aLinks.erase(j) ;
				}
				else
					j++ ;
			}
		}
	}

	// Remplacement des modeles : impossible sans table de correspondance

	// Remplacement des droits : seulement au niveau tree
	aRights.RemoveDocument(sTreeID) ;

	if (sNewDocRosace != "")
		aRights.set(sNewTreeID, sNewDocRosace) ;

	return true ;
}
catch (...)
{
	erreur("Exception NSDataGraph::replaceTree", standardError, 0) ;
	return false ;
}
}

bool
NSDataGraph::signChanges(string sTreeID)
{
  if (pContexte->getPatient() == NULL)
    return false ;

  if (strlen(sTreeID.c_str()) != (PAT_NSS_LEN + DOC_CODE_DOCUM_LEN))
  {
  	erreur("TreeID de longueur non conforme.", standardError, 0) ;
    return false ;
  }

  NSLinkManager   LinkManager(pContexte, this) ;
  NSPatPathoArray PatPatho(pContexte) ;
  NSDataTreeIter  iterTree ;
  string sCurrentNode ;
  string sFatherNode ;
  bool bInMemoryTree = true;

  if (!(aTrees.ExisteTreeID(sTreeID, &iterTree)))
  	return false ;

  (*iterTree)->getPatPatho(&PatPatho) ;

  if (PatPatho.empty())
  	return false ;

  // Premi�re passe : on regarde si tous les noeuds sont nouveaux ou pas
  for (PatPathoIter i = PatPatho.begin(); i != PatPatho.end(); i++)
  {
  	sCurrentNode = (*i)->getNodeID() ;
    if (sCurrentNode[0] != INMEMORY_CHAR)
    {
    	bInMemoryTree = false ;
      break ;
    }
  }

  if (bInMemoryTree)
  {
  	// Dans ce cas on cr�e un nouveau lien contribution avec le TreeID
    if (!LinkManager.existeLien(sTreeID, NSRootLink::contributionAdded, pContexte->getPatient()->getContribution()))
    {
    	if (!LinkManager.etablirLien(sTreeID, NSRootLink::contributionAdded, pContexte->getPatient()->getContribution()))
      {
      	string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "cannotEstablishALinkWithTheContribution") ;
        pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
        erreur(sErrorText.c_str(), standardError, 0) ;
      }
    }
    return true ;
  }

  // Deuxi�me passe : on est surs ici qu'il s'agit d'un arbre � modifier
  // on regarde pour chaque noeud en # si son pere est en #. Si ce n'est pas le cas,
  // ce nouveau noeud doit etre reli� � la contribution en cours.
  for (PatPathoIter i = PatPatho.begin(); i != PatPatho.end(); i++)
  {
  	sCurrentNode = (*i)->getNodeID() ;
    if (sCurrentNode[0] == INMEMORY_CHAR)
    {
    	PatPathoIter iterPere = PatPatho.ChercherPere(i) ;
      if (iterPere == NULL)
      	sFatherNode = "" ;
      else
      	sFatherNode = (*iterPere)->getNodeID() ;

      if (sFatherNode[0] != INMEMORY_CHAR)
      {
      	if (!LinkManager.existeLien((*i)->getNode(), NSRootLink::contributionModified, pContexte->getPatient()->getContribution()))
        {
        	if (!LinkManager.etablirLien((*i)->getNode(), NSRootLink::contributionModified, pContexte->getPatient()->getContribution()))
          {
          	string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "cannotEstablishALinkWithTheContribution") ;
						pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
						erreur(sErrorText.c_str(), standardError, 0) ;
          }
        }
      }
    }
  }

  return true ;
}

string
NSDataGraph::genereXML()
{
	string sXML = string("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\r\n") ;
	sXML += string("<graph id = \"") + (*(aTrees.begin()))->getTreeID() + string("\">\r\n") ;

	for (NSDataTreeIter i = aTrees.begin(); i != aTrees.end(); i++)
  {
  	sXML += string("<tree id = \"") + (*i)->getTreeID() + string("\">\r\n") ;
    sXML += (*i)->genereXML() ;
    sXML += string("</tree>\r\n") ;
  }

  string sNodeSource, sNodeTarget ;

	for (NSPatLinkIter j = aLinks.begin(); j != aLinks.end(); j++)
  {
  	sXML += string("<link source_object_id = \"") + string((*j)->getQualifie(), 0, OBJECT_ID_LEN) + string("\" ") ;
    sNodeSource = string((*j)->getQualifie(), OBJECT_ID_LEN, strlen((*j)->getQualifie().c_str()) - OBJECT_ID_LEN) ;
    if (strlen(sNodeSource.c_str()) == PPD_NOEUD_LEN)
    	sXML += string("source_node_id = \"") + sNodeSource + string("\" ") ;

    sXML += string("lien = \"") + (*j)->getLien() + string("\" ") ;

    sXML += string("target_object_id = \"") + string((*j)->getQualifiant(), 0, OBJECT_ID_LEN) + string("\" ") ;
    sNodeTarget = string((*j)->getQualifiant(), OBJECT_ID_LEN, strlen((*j)->getQualifiant().c_str()) - OBJECT_ID_LEN);
    if (strlen(sNodeTarget.c_str()) == PPD_NOEUD_LEN)
    	sXML += string("target_node_id = \"") + sNodeTarget + string("\" ") ;
    sXML += string("/>\r\n") ;
  }

  string sNode ;

  for (NSArcLinkIter k = aArchs.begin(); k != aArchs.end(); k++)
  {
  	sXML += string("<model object_id = \"") + (*k)->object + string("\" ") ;
    sNode = (*k)->node ;
    if (strlen(sNode.c_str()) == PPD_NOEUD_LEN)
    	sXML += string("node_id = \"") + sNode + string("\" ") ;
    sXML += string("type = \"") + string((*k)->type) + string("\" ") ;
    sXML += string("mod_object_id = \"") + string((*k)->model_object_id) + string("\" />\r\n") ;
  }

  sXML += string("</graph>\r\n") ;

	return sXML ;
}

bool
NSDataGraph::incrementeCode(string& sCompteur)
{
	if (sCompteur == "")
  	return false ;

	//
	// On incr�mente le compteur
	//
	int i, j;

	int calculer = 1;
	i = strlen(sCompteur.c_str()) - 1;
	while (calculer)    {
        j = (int) sCompteur[i];
        j++;

        if (((j >= '0') && (j <= '9')) || ((j >= 'A') && (j <= 'Z')))        {
            sCompteur[i] = (char) j;
            calculer = 0;
        }
        else if ((j > '9') && (j < 'A'))
        {
            sCompteur[i] = 'A';
            calculer = 0;
        }
        else
        {
            sCompteur[i] = '0';

            // on met l'index de fin � 1 � cause de l'identifiant local : '_'
            // ou de l'identifiant temporaire : '#', plac� au d�but du compteur
            // Pour les objets, on s'arrete � 2 � cause de l'identifiant d'objet ($)
            if (((iTypeGraph == graphPerson) && (i == 1)) ||                ((iTypeGraph == graphObject) && (i == 2)))            {
                erreur("Compteur satur�.", standardError, 0) ;
                return false;
            }

            i--;        }
    }

	return true;}



// -----------------------------------------------------------------------------
// METHODES DE NSObjectGraphManager
// -----------------------------------------------------------------------------
NSObjectGraphManager::NSObjectGraphManager(NSContexte *pCtx)
	:	NSRoot(pCtx)
{
try
{
	pDataGraph   = new NSDataGraph(pContexte, graphObject) ;
  pLinkManager = new NSLinkManager(pContexte, pDataGraph) ;

  lObjectCount++ ;
}
catch (...)
{
	erreur("Exception NSObjectGraphManager ctor", standardError, 0) ;
}
}

NSObjectGraphManager::NSObjectGraphManager(NSObjectGraphManager& rv)
                     :NSRoot(rv.pContexte)
{
try
{
	pDataGraph      = new NSDataGraph(*(rv.pDataGraph)) ;
  pLinkManager    = new NSLinkManager(pContexte, pDataGraph) ;

  lObjectCount++ ;
}
catch (...)
{
	erreur("Exception NSObjectGraphManager copy ctor", standardError, 0) ;
}
}

NSObjectGraphManager::~NSObjectGraphManager()
{
	if (pDataGraph)
  	delete pDataGraph ;

  if (pLinkManager)
  	delete pLinkManager ;

  lObjectCount-- ;
}

NSObjectGraphManager&
NSObjectGraphManager::operator=(NSObjectGraphManager src)
{
	if (&src == this)
  	return *this ;

	if (pDataGraph)
  	delete pDataGraph ;
  pDataGraph = new NSDataGraph(*(src.pDataGraph)) ;

  if (pLinkManager)
  	delete pLinkManager ;
  pLinkManager = new NSLinkManager(pContexte, pDataGraph) ;

  return (*this) ;
}

/*
void
NSObjectGraphManager::graphReset()
{
	pDataGraph->graphReset() ;
}
*/


/*
void
NSObjectGraphManager::setRootObject(string sObjID)
{
	pDataGraph->setGraphID(sObjID) ;
}
*/


/*
string
NSObjectGraphManager::getRootObject()
{
	return (pDataGraph->getGraphID()) ;
}
*/


/*
bool
NSObjectGraphManager::getTree(string sObjectID, NSPatPathoArray *pPatPatho, string *psDocRosace)
{
	return pDataGraph->getTree(sObjectID, pPatPatho, psDocRosace) ;
}


string
NSObjectGraphManager::setTree(NSPatPathoArray *pPatPatho, string sDocRosace, string sCode)
{
	return pDataGraph->setTree(pPatPatho, sDocRosace, sCode) ;
}
*/


bool
NSObjectGraphManager::getGraph()
{
  // if ((sObjectID == "") || (pDataGraph == 0))
  //    return false ;

  // Prise de l'arbre de base
  // appel de getGraph
  // return pContexte->pPilot->getGraph(pDataGraph);
  return false ;
}


bool
NSObjectGraphManager::setGraph()
{
	return false;
}


bool
NSObjectGraphManager::exportXML(string sFichier)
{
	if (sFichier == "")
		return false ;

	ofstream    outFile ;
  string      sOut ;

  string sFichierOut = pContexte->PathName("EHTM") + sFichier ;
  outFile.open(sFichierOut.c_str()) ;
  if (!outFile)
  {
    erreur("Erreur d'ouverture en �criture du fichier graphtest.xml", standardError, 0) ;
    outFile.close() ;
    return false ;
  }

  sOut = pDataGraph->genereXML() ;

  for (size_t i = 0 ; i < strlen(sOut.c_str()) ; i++)
  	outFile.put(sOut[i]) ;

  outFile.close() ;
  return true ;
}

void
NSObjectGraphManager::ParseTemplate(NSPatPathoArray* pPatPathoArray, NSBasicAttributeArray *pTmplArray)
{
	if ((!pPatPathoArray) || (pPatPathoArray->empty()))
    return ;

	string sTraitType = string("_0OTPL") + string("_0TYPE") ;
  string sTraitOper = string("_0OTPL") + string("_DOPER") ;
  string sTraitCons = string("_0OTPL") + string("_LNUCO") ;
  string sTraitRoot = string("_0OTPL") + string("_0TYPC") ;
  string sTraitComp = string("_0OTPL") + string("_0COMD") ;
  string sTraitDefa = string("_0OTPL") + string("_0DEFA") ;
  string sTraitFich = string("_0OTPL") + string("_0TPL0") ;
  string sTraitEnte = string("_0OTPL") + string("_0ENTE") ;
  string sTraitLibe = string("_0OTPL") + string("_0INTI") ;

  string sTmplTypeDoc = "", sTmplUtil = "", sTmplCons = "" ;
	string sTmplLexRoot = "", sTmplCompo = "0", sTmplDefaut = "0" ;
  string sTmplFichier = "", sTmplEnTete = "", sTmplLibelle = "" ;

	string sElemLex, sSens, sType ;
	string sTemp	= ""  ;

	PatPathoIter iter = pPatPathoArray->begin() ;
	int iColBase = (*iter)->getColonne() ;
	iter++ ;

	while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase))
	{
  	sElemLex = (*iter)->getLexique() ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    // Type document
    if (sSens == string("0TYPE"))
    {
    	iter++ ;
      while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        sTmplTypeDoc = sElemLex ;
        iter++ ;
      }
    }
    // Operateur
    else if (sSens == string("DOPER"))
    {
    	iter++ ;
      while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (string(sElemLex, 0, 5) == string("�SPID"))
        	sTmplUtil = (*iter)->getComplement() ;

        iter++ ;
      }
    }
    // num�ro de console
    else if (sSens == string("LNUCO"))
    {
    	iter++ ;
      while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (string(sElemLex, 0, 3) == string("�C;"))
        	sTmplCons = (*iter)->getComplement() ;

        iter++ ;
      }
    }
    // lexique root
    else if (sSens == string("0TYPC"))
    {
    	iter++ ;
      while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        sTmplLexRoot = sElemLex ;
        iter++ ;
      }
    }
    // flag composition
    else if (sSens == string("0COMD"))
    {
    	iter++ ;
      sTmplCompo = "1" ;
    }
    // flag defaut
    else if (sSens == string("0DEFA"))
    {
    	iter++ ;
      sTmplDefaut = "1" ;
    }
    // Fichier Template
    else if (sSens == string("0TPL0"))
    {
    	iter++ ;
      while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (sElemLex == string("�?????"))
        	sTmplFichier = (*iter)->getTexteLibre() ;

        iter++ ;
      }
    }
    // Fichier En-tete
    else if (sSens == string("0ENTE"))
    {
    	iter++ ;
      while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (sElemLex == string("�?????"))
        	sTmplEnTete = (*iter)->getTexteLibre() ;

        iter++ ;
      }
    }
    // Libelle
    else if (sSens == string("0INTI"))
    {
    	iter++ ;
      while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (sElemLex == string("�?????"))
        	sTmplLibelle = (*iter)->pDonnees->getTexteLibre() ;

        iter++ ;
      }
    }
    else
    	iter++ ;
	} // boucle principale

  pTmplArray->push_back(new NSBasicAttribute(sTraitType, sTmplTypeDoc)) ;
  pTmplArray->push_back(new NSBasicAttribute(sTraitOper, sTmplUtil)) ;
  pTmplArray->push_back(new NSBasicAttribute(sTraitCons, sTmplCons)) ;
  pTmplArray->push_back(new NSBasicAttribute(sTraitRoot, sTmplLexRoot)) ;
  pTmplArray->push_back(new NSBasicAttribute(sTraitComp, sTmplCompo)) ;
  pTmplArray->push_back(new NSBasicAttribute(sTraitDefa, sTmplDefaut)) ;
  pTmplArray->push_back(new NSBasicAttribute(sTraitFich, sTmplFichier)) ;
  pTmplArray->push_back(new NSBasicAttribute(sTraitEnte, sTmplEnTete)) ;
  pTmplArray->push_back(new NSBasicAttribute(sTraitLibe, sTmplLibelle)) ;
}

string
NSAddressGraphManager::CalculeClefLieu(NSPatPathoArray *pPatPathoObject)
{
	if ((!pPatPathoObject) || (pPatPathoObject->empty()))
  	return string("") ;

	string sLang = "" ;
  if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  string sLieu = "" ;

    string sTypeLieu = "", sNomLieu = "", sEtag = "", sEsca = "", sCodp = "" ;
    string sNump = "", sCotp = "", sTele1 = "", sTele2 = "", sNpos = "", sFax = "" ;
    string sElemLex, sSens, sSens1 ;
    PatPathoIter    iter ;

    // on r�cup�re le nom du site et le num�ro dans la voie
    iter = pPatPathoObject->begin() ;
    int iColBase = (*iter)->getColonne() ;
    iter++ ;

    while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase))
    {
      sElemLex = (*iter)->getLexique() ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

      // Chapitre "nom" / name chapter
      if (sSens == string("LTYPA"))
      {
        iter++;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�C;"))
          {
            iter++ ;
            while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 2))
            {
              // on cherche ici un code lexique pour un libelle
              string sCode = (*iter)->getLexique() ;
              pContexte->getDico()->donneLibelle(sLang, &sCode, &sTypeLieu) ;
              sLieu += string("|") + sTypeLieu ;

              iter++ ;
            }
          }
          else
            iter++ ;
        }
      }
      else if (sSens == string("LNOMA"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sNomLieu = (*iter)->getTexteLibre() ;
            sLieu += string("|") + sNomLieu ;
          }

          iter++ ;
        }
      }
      else if (sSens == string("LETAG"))
      {
        iter++;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sEtag = (*iter)->getTexteLibre() ;
            sLieu += string("|") + sEtag ;
          }

          iter++ ;
        }
      }
      else if (sSens == string("LESCA"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sEsca = (*iter)->getTexteLibre() ;
            sLieu += string("|") + sEsca ;
          }

          iter++ ;
        }
      }
      else if (sSens == string("LCODP"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sCodp = (*iter)->getTexteLibre() ;
            sLieu += string("|") + sCodp ;
          }

          iter++ ;
        }
      }
      else if (sSens == string("LNUMP"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sNump = (*iter)->getTexteLibre() ;
            sLieu += string("|") + sNump ;
          }

          iter++ ;
        }
      }
      else if (sSens == string("LCOTP"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sCotp = (*iter)->getTexteLibre() ;
            sLieu += string("|") + sCotp ;
          }

          iter++ ;
        }
      }
      else if (sElemLex == string("LTELE1"))
      {
        iter++;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sTele1 = (*iter)->getTexteLibre() ;
            sLieu += string("|") + sTele1 ;
          }

          iter++ ;
        }
      }
      else if (sElemLex == string("LTELE2"))
      {
        iter++;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sTele2 = (*iter)->getTexteLibre() ;
            sLieu += string("|") + sTele2 ;
          }

          iter++ ;
        }
      }
      else if (sSens == string("LNPOS"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sNpos = (*iter)->getTexteLibre() ;
            sLieu += string("|") + sNpos ;
          }

          iter++ ;
        }
      }
      else if (sSens == string("LFAX0"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
              sFax = (*iter)->getTexteLibre() ;
              sLieu += string("|") + sFax ;
          }

          iter++ ;
        }
      }
      else
      	iter++ ;
    }

    return strpids(sLieu);
}

string
NSAddressGraphManager::CalculeClefSite(NSPatPathoArray *pPatPathoObject)
{
	string sSite = "", sLieu = "";
	string sNomSite = "", sNumVoie = "", sBati = "", sEsca = "", sCodp = "";
	string sCods = "", sBp = "", sLied = "", sTele = "", sTela = "", sTels = "", sFax = "";

	if (!pPatPathoObject->empty())
	{
        string sElemLex, sSens, sSens1;
        PatPathoIter    iter;

        // on r�cup�re le nom du site et le num�ro dans la voie
        iter = pPatPathoObject->begin();
        int iColBase = (*iter)->getColonne();
        iter++;

        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase))
        {
            sElemLex = (*iter)->getLexique();
            pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

            // Chapitre "nom" / name chapter
            if (sSens == string("LNOMA"))
            {
                iter++;
                while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                {
                    // on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                        sNomSite = (*iter)->getTexteLibre() ;
                        sSite += string("|") + sNomSite ;
                    }

                    iter++;
                }
            }
            // lieu pour les adresses simplifi�es
            else if (sSens == string("LLIEU"))
            {
                iter++;
                while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                {
                    // on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                        sLieu = (*iter)->getTexteLibre() ;
                        sSite += string("|") + sLieu;
                    }

                    iter++;
                }
            }
            else if (sSens == string("LVOIE"))
            {
                iter++;

                sElemLex = (*iter)->getLexique() ;
                pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

                if (sSens == string("LNUMA"))
                {
                    iter++;
                    while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                    {
                        // on cherche ici un texte libre
                        sElemLex = (*iter)->getLexique() ;
                        if (string(sElemLex, 0, 3) == string("�CL"))
                        {
                            sNumVoie = (*iter)->getTexteLibre();
                            sSite += string("|") + sNumVoie;
                        }

                        iter++;
                    }
                }
                else
                    iter++;
            }
            else if (sSens == string("LBATI"))
            {
                iter++;
                while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                {
                    // on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                        sBati = (*iter)->getTexteLibre();
                        sSite += string("|") + sBati;
                    }

                    iter++;
                }
            }
            else if (sSens == string("LESCA"))
            {
                iter++;
                while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                {
                    // on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                        sEsca = (*iter)->getTexteLibre();
                        sSite += string("|") + sEsca;
                    }

                    iter++;
                }
            }
            else if (sSens == string("LCODP"))
            {
                iter++;
                while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                {
                    // on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                        sCodp = (*iter)->getTexteLibre();
                        sSite += string("|") + sCodp;
                    }

                    iter++;
                }
            }
            else if (sSens == string("LCODS"))
            {
                iter++;
                while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                {
                    // on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                        sCods = (*iter)->getTexteLibre();
                        sSite += string("|") + sCods;
                    }

                    iter++;
                }
            }
            else if (sSens == string("LBPOA"))
            {
                iter++;
                while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                {
                    // on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                        sBp = (*iter)->getTexteLibre();
                        sSite += string("|") + sBp;
                    }

                    iter++;
                }
            }
            else if (sSens == string("LLIED"))
            {
                iter++;
                while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                {
                    // on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                        sLied = (*iter)->getTexteLibre();
                        sSite += string("|") + sLied;
                    }

                    iter++;
                }
            }
            // t�l�phone pour les adresses simplifi�es
            else if (sSens == string("LTELE"))
            {
                iter++;
                while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                {
                    // on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                        sTele = (*iter)->getTexteLibre();
                        sSite += string("|") + sTele;
                    }

                    iter++;
                }
            }
            else if (sSens == string("LTELA"))
            {
                iter++;
                while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                {
                    // on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                        sTela = (*iter)->getTexteLibre();
                        sSite += string("|") + sTela;
                    }

                    iter++;
                }
            }
            else if (sSens == string("LTELS"))
            {
                iter++;
                while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                {
                    // on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                        sTels = (*iter)->getTexteLibre();
                        sSite += string("|") + sTels;
                    }

                    iter++;
                }
            }
            else if (sSens == string("LFAX0"))
            {
                iter++;
                while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
                {
                    // on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                        sFax = (*iter)->getTexteLibre();
                        sSite += string("|") + sFax;
                    }

                    iter++;
                }
            }
            else
                iter++;
        }

        return strpids(sSite);
    }

    return "";
}


string
NSAddressGraphManager::CalculeClefVoie(NSPatPathoArray *pPatPathoObject)
{
	string sLang = "" ;
  if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  string sVoie = "" ;

  if (!pPatPathoObject->empty())
  {
    string sTypeVoie = "" ;
    string sNomVoie = "" ;
    string sElemLex, sSens, sSens1 ;
    PatPathoIter    iter ;

    // on r�cup�re le nom du site et le num�ro dans la voie
    iter = pPatPathoObject->begin() ;
    int iColBase = (*iter)->getColonne() ;
    iter++ ;

    while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase))
    {
      sElemLex = (*iter)->getLexique() ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

      // Chapitre "nom" / name chapter
      if (sSens == string("LTYPA"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�C;"))
          {
            iter++ ;
            while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 2))
            {
              // on cherche ici un code lexique pour un libelle
              string sCode = (*iter)->getLexique() ;
              pContexte->getDico()->donneLibelle(sLang, &sCode, &sTypeVoie) ;
              sVoie += string("|") + sTypeVoie ;
              iter++ ;
            }
          }
          else
          	iter++ ;
        }
      }
      else if (sSens == string("LNOMA"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sNomVoie = (*iter)->getTexteLibre() ;
            sVoie += string("|") + sNomVoie ;
          }
          iter++ ;
        }
      }
      else
      	iter++ ;
    }
    return strpids(sVoie) ;
  }
  return "" ;
}


string
NSAddressGraphManager::CalculeClefVille(NSPatPathoArray *pPatPathoObject)
{
  string sZip = "", sCedx = "", sComu = "", sPays = "" ;
  string sVille = "" ;

  if (!pPatPathoObject->empty())
  {
    string sElemLex, sSens, sSens1 ;
    PatPathoIter    iter ;

    // on r�cup�re le nom du site et le num�ro dans la voie
    iter = pPatPathoObject->begin() ;
    int iColBase = (*iter)->getColonne() ;
    iter++ ;

    while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase))
    {
      sElemLex = (*iter)->getLexique() ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

      // Code Postal / Zip Code
      if (sSens == string("LZIP0"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sZip = (*iter)->getTexteLibre() ;
            sVille += string("|") + sZip ;
          }
          iter++ ;
        }
      }
      else if (sSens == string("LCEDX"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sCedx = (*iter)->getTexteLibre() ;
            sVille += string("|") + sCedx ;
          }
          iter++ ;
        }
      }
      else if (sSens == string("LCOMU"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sComu = (*iter)->getTexteLibre() ;
            sVille += string("|") + sComu ;
          }
          iter++ ;
        }
      }
      else if (sSens == string("LPAYS"))
      {
        iter++ ;
        while ((iter != pPatPathoObject->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sPays = (*iter)->getTexteLibre() ;
            sVille += string("|") + sPays ;
          }
          iter++ ;
        }
      }
      else
      	iter++ ;
    }
    return strpids(sVille) ;
  }
  return "" ;
}


bool
NSAddressGraphManager::getGraphAdr(string sObjID, NSPatPathoArray *pPatPathoArray)
{
try
{
  // remise � z�ro du graphe
  pDataGraph->graphReset() ;
  string sObject = sObjID ;

  setRootObject(sObjID) ;

	NSBasicAttributeArray AttrList ;
  AttrList.push_back(new NSBasicAttribute(OBJECT, sObjID)) ;
  AttrList.push_back(new NSBasicAttribute(LINK, "OI")) ;
  AttrList.push_back(new NSBasicAttribute(DIRECTION, FORWARD)) ;
//  pAttrList->push_back(new NSBasicAttribute("user", pContexte->getUtilisateurID())) ;

  int res = pContexte->pPilot->readAdressGraph(NautilusPilot::SERV_READ_ADRESS_GRAPH.c_str(), pDataGraph, &AttrList) ;
  if (!res)
  {
  	erreur("Echec service � la r�cup�ration du graphe d'adresse.", standardError, 0) ;
    return false ;
  }

  // constitution de la patpatho contenant tous les arbres du graphe
  if (pPatPathoArray)
  {
    pPatPathoArray->vider() ;

    if (!(pDataGraph->aTrees.empty()))
    {
      for (NSDataTreeIter i = pDataGraph->aTrees.begin() ; i != pDataGraph->aTrees.end() ; i++)
      {
      	NSPatPathoArray Ppt(pContexte) ;
        (*i)->getPatPatho(&Ppt) ;
        pPatPathoArray->ajouteVecteur(&Ppt, ORIGINE_PATH_PATHO) ;
      }
    }
  }
  return true ;
}
catch (...)
{
  erreur("Exception NSObjectGraphManager::getGraphAdr", standardError, 0) ;
  return false ;
}
}

bool
NSAddressGraphManager::setGraphAdr(NSPatPathoArray *pPatPathoArray, string sOperatorID)
{
	if (!pPatPathoArray || (pPatPathoArray->empty()))
  	return false ;

  // pour cette m�thode, on suppose qu'on a une patpatho "Adresse"
  // form�e d'au plus 3 objets "adresse" distincts (lieu, site, ville).
  // La sous-patpatho de chaque objet se trouve � chaque fois en colonne 0;
  // on r�cup�re chaque sous-patpatho pour cr�er un nouvel arbre du graphe.

  NSVectPatPathoArray Vect  ;
  PatPathoIter iterRoot = pPatPathoArray->begin() ;
  pPatPathoArray->ExtraireVecteurPatPathoFreres(iterRoot, &Vect) ;

  string sTypeFrere ;
  bool bExisteLieu = false ;
  bool bExisteSite = false ;
  bool bExisteVoie = false ;
  bool bExisteVille = false ;
  string sNodeLieu = "", sNodeSite = "", sNodeVoie = "", sNodeVille = "" ;
  NSBasicAttributeArray AttrList ;

  PatPathoIterVect iterVect = Vect.begin() ;
  // Cr�ation des arbres du graphe
  while (iterVect != Vect.end())
  {
    // Le type de chaque frere est donn� par le code lexique de sa racine
    iterRoot = (*iterVect)->begin() ;
    sTypeFrere = (*iterRoot)->getLexique() ;

    if (((sTypeFrere == string("LLIEU1")) && (!bExisteLieu)) ||
        ((sTypeFrere == string("LSITE1")) && (!bExisteSite)) ||
        ((sTypeFrere == string("LVOIE1")) && (!bExisteVoie)) ||
        ((sTypeFrere == string("LVILL1")) && (!bExisteVille)))
    {
      // on regarde dans le graphe si un �l�ment de ce type
      // existe d�j�, auquel cas on doit le mettre � jour
      // NSDataTreeIter iterTree ;
      string         sNodeFrere ;

      /*
      // Note : on suppose maintenant partir d'un graphe vierge � chaque fois
      if (pDataGraph->aTrees.ExisteTree(sTypeFrere, pContexte, &iterTree))
      {
      	pDataGraph->removeTree((*iterTree)->getTreeID()) ;
      }
      */

      sNodeFrere = setTree(*iterVect, "") ;

      if (sTypeFrere == string("LLIEU1"))
      {
        sNodeLieu = sNodeFrere ;
        AttrList.push_back(new NSBasicAttribute("_LLIEU_LLIEU", CalculeClefLieu(*iterVect))) ;
        bExisteLieu = true ;
      }
      else if (sTypeFrere == string("LSITE1"))
      {
        sNodeSite = sNodeFrere ;
        AttrList.push_back(new NSBasicAttribute("_LSITE_LSITE", CalculeClefSite(*iterVect))) ;
        bExisteSite = true ;
      }
      else if (sTypeFrere == string("LVOIE1"))
      {
        sNodeVoie = sNodeFrere ;
        AttrList.push_back(new NSBasicAttribute("_LVOIE_LVOIE", CalculeClefVoie(*iterVect))) ;
        bExisteVoie = true ;
      }
      else if (sTypeFrere == string("LVILL1"))
      {
        sNodeVille = sNodeFrere ;
        AttrList.push_back(new NSBasicAttribute("_LVILL_LVILL", CalculeClefVille(*iterVect))) ;
        bExisteVille = true ;
      }
    }
    iterVect++ ;
  }

  // Si certains objets du graphe ont disparu, il faut les retirer
  /*
  // Note : obsol�te on ne g�re plus la modification
  NSDataTreeIter iterTree ;

  if ((!bExisteLieu) && (pDataGraph->aTrees.ExisteTree("LLIEU1", pContexte, &iterTree)))
  {
  	pDataGraph->removeTree((*iterTree)->getTreeID()) ;
  }

  if ((!bExisteSite) && (pDataGraph->aTrees.ExisteTree("LSITE1", pContexte, &iterTree)))
  {
  	pDataGraph->removeTree((*iterTree)->getTreeID()) ;
  }

  if ((!bExisteVoie) && (pDataGraph->aTrees.ExisteTree("LVOIE1", pContexte, &iterTree)))
  {
  	pDataGraph->removeTree((*iterTree)->getTreeID()) ;
  }

  if ((!bExisteVille) && (pDataGraph->aTrees.ExisteTree("LVILL1", pContexte, &iterTree)))
  {
  	pDataGraph->removeTree((*iterTree)->getTreeID()) ;
  }
	*/

  // Cr�ation des liens du graphe
  // on cherche quel est l'objet "root" et on reconstuit ses liens
  // avec les autres objets du graphe

  if (bExisteLieu)
  {
    // si le lieu existe, il devient le "root" du graphe
    setRootObject(sNodeLieu) ;

    // Le lieu est reli� soit � un site, soit � une ville
    if (bExisteSite)
    {
    	if (!pLinkManager->etablirLien(sNodeLieu, NSRootLink::objectIn, sNodeSite))
      {
        erreur("Impossible de cr�er le lien [lieu -> site] de l'objet adresse en cours.", standardError, 0) ;
        return false ;
      }
    }
    else if (bExisteVoie)
    {
    	if (!pLinkManager->etablirLien(sNodeLieu, NSRootLink::objectIn, sNodeVoie))
      {
        erreur("Impossible de cr�er le lien [lieu -> voie] de l'objet adresse en cours.", standardError, 0) ;
        return false ;
      }
    }
    else if (bExisteVille)
    {
			if (!pLinkManager->etablirLien(sNodeLieu, NSRootLink::objectIn, sNodeVille))
      {
        erreur("Impossible de cr�er le lien [lieu -> ville] de l'objet adresse en cours.", standardError, 0) ;
        return false ;
      }
    }
  }

  if (bExisteSite)
  {
    // on regarde s'il existe un lieu
    if (!bExisteLieu)
        setRootObject(sNodeSite) ;

    // Le site est reli� � une voie ou � une ville
    if (bExisteVoie)
    {
    	if (!pLinkManager->etablirLien(sNodeSite, NSRootLink::objectIn, sNodeVoie))
      {
        erreur("Impossible de cr�er le lien [site -> voie] de l'objet adresse en cours.", standardError, 0) ;
        return false ;
      }
    }
    else if (bExisteVille)
    {
    	if (!pLinkManager->etablirLien(sNodeSite, NSRootLink::objectIn, sNodeVille))
      {
      	erreur("Impossible de cr�er le lien [site -> ville] de l'objet adresse en cours.", standardError, 0) ;
        return false ;
      }
    }
  }

  if (bExisteVoie)
  {
    // on regarde s'il existe un lieu
    if ((!bExisteLieu) && (!bExisteSite))
    	setRootObject(sNodeVoie) ;

    // La voie est reli�e � une ville
    if (bExisteVille)
    {
      if (!pLinkManager->etablirLien(sNodeVoie, NSRootLink::objectIn, sNodeVille))
      {
        erreur("Impossible de cr�er le lien [voie -> ville] de l'objet adresse en cours.", standardError, 0) ;
        return false ;
      }
    }
  }

  // Une ville n'est reli�e � rien mais peut
  // devenir le root si elle est unique
  if ((bExisteVille) && (!bExisteVoie) && (!bExisteSite) && (!bExisteLieu))
  	setRootObject(sNodeVille) ;

  // Le graphe est maintenant constitu�. on doit appeler le pilote pour
  // trouver successivement les ID de tous les arbres du graphe
  // (et r�soudre leurs d�pendances)
  NSDataGraph LocalGraph(pContexte, graphObject) ;
  string sTreeID, sTreeRights, sElemLex, sSens ;
  string sAttr, sValue, sNewTreeID ;
  NSPatPathoArray PatPatho(pContexte, graphObject) ;
  bool res ;
  NSPersonsAttributesArray ObjectsList ;
//  pAttrList->push_back(new NSBasicAttribute("user", pContexte->getUtilisateurID())) ;
  string sPrecObjID = "" ;
  string sCodeObj = string("LVILL1") ;
  bool bExist ;
  bool tourner = true ;
  NSDataTreeIter iterTree ;

  // Premi�re passe : on cr�e l'objet pour chaque objet-m�moire ('#')
  while (tourner)
  {
    bExist = pDataGraph->aTrees.ExisteTree(sCodeObj, pContexte, &iterTree) ;
    if (bExist) // En principe (sTreeID[0] == '#')
    {
      sTreeID = (*iterTree)->getTreeID() ;
      LocalGraph.graphReset() ;
      PatPatho.vider() ;

      pDataGraph->getTree(sTreeID, &PatPatho, &sTreeRights) ;

      sElemLex = string((*(PatPatho.begin()))->getLexique()) ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;
      sAttr = string("_") + sSens + string("_") + sSens;
      sValue = AttrList.getAttributeValue(sAttr) ;
      if (sPrecObjID != "")
      {
        sValue += string("|") + sPrecObjID ;
        AttrList.setAttributeValue(sAttr, sValue) ;
      }

      LocalGraph.setTree(&PatPatho, sTreeRights, sTreeID) ;

      // Appel pilote : cr�ation de l'objet en local
      NSBasicAttributeArray List ;
      List.push_back(new NSBasicAttribute(sAttr, sValue)) ;

      // rustine EpiPump
      if (sOperatorID == "")
      	List.push_back(new NSBasicAttribute("user", pContexte->getUtilisateurID())) ;
      else
      	List.push_back(new NSBasicAttribute("user", sOperatorID)) ;

      NSPersonsAttributesArray ObjectsLocalList ;

      res = pContexte->pPilot->createPersonOrObject(NautilusPilot::SERV_CREATE_OBJECT.c_str(), &LocalGraph, &ObjectsLocalList, &List, OBJECT_TYPE, false) ;
      if (!res)
      {
        erreur("Echec service � la cr�ation du graphe d'adresse.", standardError, 0) ;
        return false ;
      }

      // cas des doublons
      if (false == ObjectsLocalList.empty())
      {
        string sOIDS = ObjectsLocalList.getAttributeValue(OIDS) ;
        LocalGraph.graphReset() ;
        List.vider() ;

        if (sOIDS != "")
        {
          //pList->push_back(new NSBasicAttribute("graphID", sOIDS)) ;
          List.push_back(new NSBasicAttribute(OBJECT, sOIDS)) ;
          res = pContexte->pPilot->invokeService(NautilusPilot::SERV_SEARCH_OBJECT_FROM_ID.c_str(), &LocalGraph,  &List) ;
          if (!res)
          {
            string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "objectNotFound") ;
            if (sErrorText == "")
              sErrorText = string("Echec service : Impossible de r�cup�rer un objet dans la base") ;
            erreur(sErrorText.c_str(), standardError, 0) ;
            return false ;
          }
        }
      }

      // Remplacement du nouvel ID dans le DataGraph
      NSDataTreeIter iter = LocalGraph.aTrees.begin() ;
      sNewTreeID = (*iter)->getTreeID() ;
      sPrecObjID = sNewTreeID ;

      NSPatPathoArray Ppt(pContexte) ;
      (*iter)->getPatPatho(&Ppt) ;
      pDataGraph->replaceTree(sTreeID, sNewTreeID, &Ppt, sTreeRights) ;

      // ajout des liens rattach�s au doublon
      // Note : pour un doublon, on doit passer TOUS SES LIENS
      // sinon le pilote effacera les liens manquants
      if (false == ObjectsLocalList.empty())
      {
        for (NSPatLinkIter j = LocalGraph.aLinks.begin() ; LocalGraph.aLinks.end() != j ; j++)
        {
          string sQualifie   = (*j)->getQualifie() ;
          string sQualifiant = (*j)->getQualifiant() ;
          NSRootLink::NODELINKTYPES iRelation = pLinkManager->donneRelation((*j)->getLien()) ;

          if (!pLinkManager->existeLien(sQualifie, iRelation, sQualifiant))
          	pDataGraph->aLinks.push_back(new NSPatLinkInfo(*(*j))) ;
        }
      }
    }

    if (sCodeObj == "LVILL1")
    	sCodeObj = string("LVOIE1") ;
    else if (sCodeObj == "LVOIE1")
    	sCodeObj = string("LSITE1") ;
    else if (sCodeObj == "LSITE1")
    	sCodeObj = string("LLIEU1") ;
    else if (sCodeObj == "LLIEU1")
    	tourner = false ;
  }

  // Deuxi�me passe : on montre les liens au pilote objet par objet
  for (NSDataTreeIter i = pDataGraph->aTrees.begin() ; i != pDataGraph->aTrees.end() ; i++)
  {
    sTreeID = (*i)->getTreeID() ;
    LocalGraph.graphReset() ;
    PatPatho.vider() ;

    pDataGraph->getTree(sTreeID, &PatPatho, &sTreeRights) ;

    sElemLex = string((*(PatPatho.begin()))->getLexique()) ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;
    sAttr = string("_") + sSens + string("_") + sSens ;
    sValue = AttrList.getAttributeValue(sAttr) ;

    // on met ici l'arbre et ses droits dans pLocalGraph
    LocalGraph.setTree(&PatPatho, sTreeRights, sTreeID) ;
    LocalGraph.setGraphID(sTreeID) ;

    // pour les liens, on prend seulement les liens de l'arbre
    for (NSPatLinkIter j = pDataGraph->aLinks.begin() ; j != pDataGraph->aLinks.end() ; j++)
    {
      if (((*j)->getQualifie() == sTreeID) || ((*j)->getQualifiant() == sTreeID))
      	LocalGraph.aLinks.push_back(new NSPatLinkInfo(*(*j))) ;

      // if (strcmp((*j)->pDonnees->qualifie, sTreeID.c_str()) == 0)
      //   pLocalGraph->aLinks.push_back(new NSPatLinkInfo(*(*j))) ;
    }

    // Appel pilote : modification de l'objet en local
    NSBasicAttributeArray List ;
    List.push_back(new NSBasicAttribute("object", sTreeID)) ;
    List.push_back(new NSBasicAttribute(sAttr, sValue)) ;

    // rustine EpiPump
    if (sOperatorID == "")
    	List.push_back(new NSBasicAttribute("operator", pContexte->getUtilisateurID())) ;
    else
    	List.push_back(new NSBasicAttribute("operator", sOperatorID)) ;

    NSPersonsAttributesArray LocalObjectsList ;

    res = pContexte->pPilot->modifyPersonOrObject(NautilusPilot::SERV_MODIFY_OBJECT.c_str(), &LocalGraph, &LocalObjectsList, &List) ;
    if (!res)
    {
      erreur("Echec service � la modification du graphe d'adresse.", standardError, 0) ;
      return false ;
    }
  }

	return true ;
}

bool
NSAddressGraphManager::trouveInfoLieuAdr(string& sNomEspace, string& sTele1, string& sTele2, string& sFax)
{
  // on consid�re ici qu'on a un graphe d'adresses charg�
  if ((getRootObject() == "") || (pDataGraph == 0))
  	return false ;

  NSDataTreeIter iterTree ;
  NSPatPathoArray* pPatPathoArray = new NSPatPathoArray(pContexte) ;
  sNomEspace = "" ;
  sTele1 = "" ;
  sTele2 = "" ;
  sFax = "" ;

  if (pDataGraph->aTrees.ExisteTree("LLIEU1", pContexte, &iterTree))
  {
    string sElemLex, sSens, sSens1 ;
    (*iterTree)->getPatPatho(pPatPathoArray) ;
    PatPathoIter    iter ;

    // on r�cup�re le nom du site et le num�ro dans la voie
    iter = pPatPathoArray->begin() ;
    int iColBase = (*iter)->getColonne() ;
    iter++ ;

    while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase))
    {
      sElemLex = (*iter)->getLexique() ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

      // Chapitre "nom" / name chapter
      if (sSens == string("LNOMA"))
      {
        iter++ ;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
          	sNomEspace = (*iter)->getTexteLibre() ;
          }
          iter++ ;
        }
      }
      // Chapitre "t�l�phone" / telephone chapter
      else if (sElemLex == string("LTELE1"))
      {
        iter++ ;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
          	sTele1 = (*iter)->getTexteLibre() ;
          }
          iter++ ;
        }
      }
      // Chapitre "t�l�phone secondaire" / second telephone chapter
      else if (sElemLex == string("LTELE2"))
      {
        iter++ ;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
          	sTele2 = (*iter)->getTexteLibre() ;
          }
          iter++ ;
        }
      }
      // Chapitre "fax" / fax chapter
      else if (sElemLex == string("LFAX01"))
      {
        iter++ ;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sFax = (*iter)->getTexteLibre() ;
          }
          iter++;
        }
      }
      else
      	iter++ ;
    }

    if ((sNomEspace != "") || (sTele1 != "") || (sTele2 != "") || (sFax != ""))
    {
      delete pPatPathoArray ;
      return true ;
    }
  }

  delete pPatPathoArray ;
  return false ;
}


bool
NSAddressGraphManager::trouveInfoSiteAdr(string& sNomSite, string& sNumVoie, string& sBat, string& sEsc, string& sBP, string& sLieuDit)
{
  // on consid�re ici qu'on a un graphe d'adresses charg�
  if ((getRootObject() == "") || (pDataGraph == 0))
  	return false ;

  NSDataTreeIter iterTree ;
  NSPatPathoArray* pPatPathoArray = new NSPatPathoArray(pContexte) ;
  sNomSite = "" ;
  sNumVoie = "" ;
  sBat = "" ;
  sEsc = "" ;
  sBP = "" ;
  sLieuDit = "" ;

  if (pDataGraph->aTrees.ExisteTree("LSITE1", pContexte, &iterTree))
  {
    string sElemLex, sSens, sSens1 ;
    (*iterTree)->getPatPatho(pPatPathoArray) ;
    PatPathoIter    iter ;

    // on r�cup�re le nom du site et le num�ro dans la voie
    iter = pPatPathoArray->begin() ;
    int iColBase = (*iter)->getColonne() ;
    iter++ ;

    while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase))
    {
      sElemLex = (*iter)->getLexique() ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

      // Chapitre "nom" / name chapter
      if (sSens == string("LNOMA"))
      {
        iter++;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
            sNomSite = (*iter)->getTexteLibre() ;
          }
          iter++ ;
        }
      }
      else if (sSens == string("LVOIE"))
      {
        iter++ ;
        sElemLex = (*iter)->getLexique() ;
        pContexte->getDico()->donneCodeSens(&sElemLex, &sSens1) ;

        if (sSens1 == string("LNUMA"))
        {
          iter++ ;
          while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 2))
          {
            // on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 3) == string("�CL"))
            {
              sNumVoie = (*iter)->getTexteLibre() ;
            }
            iter++ ;
          }
        }
        else
        	iter++ ;
      }
      // Batiment
      else if (sSens == string("LBATI"))
      {
        iter++ ;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          {
          	sBat = (*iter)->getTexteLibre() ;
          }
          iter++ ;
        }
      }
      else if (sSens == string("LESCA"))
      {
        iter++ ;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
            sEsc = (*iter)->getTexteLibre() ;
          
          iter++;
        }
      }
      else if (sSens == string("LBPOA"))
      {
        iter++;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          	sBP = (*iter)->getTexteLibre() ;
          
          iter++ ;
        }
      }
      else if (sSens == string("LLIED"))
      {
        iter++ ;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
            sLieuDit = (*iter)->getTexteLibre() ;
          
          iter++ ;
        }
      }
      else
      	iter++ ;
    }

    if ((sNomSite != "") || (sNumVoie != ""))
    {
      delete pPatPathoArray ;
      return true ;
    }
  }

  delete pPatPathoArray ;
  return false ;
}


bool
NSAddressGraphManager::trouveInfoVoieAdr(string& sVoie)
{
  // on consid�re ici qu'on a un graphe d'adresses charg�
  if ((getRootObject() == "") || (pDataGraph == 0))
  	return false ;

	string sLang = "" ;
  if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  NSDataTreeIter iterTree ;
  NSPatPathoArray* pPatPathoArray = new NSPatPathoArray(pContexte) ;

  sVoie = "" ;

  if (pDataGraph->aTrees.ExisteTree("LVOIE1", pContexte, &iterTree))
  {
    string sTypeVoie = "" ;
    string sNomVoie = "" ;
    string sElemLex, sSens, sSens1 ;
    (*iterTree)->getPatPatho(pPatPathoArray) ;
    PatPathoIter    iter ;

    // on r�cup�re le nom du site et le num�ro dans la voie
    iter = pPatPathoArray->begin() ;
    int iColBase = (*iter)->getColonne() ;
    iter++ ;

    while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase))
    {
      sElemLex = (*iter)->getLexique() ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

      // Chapitre "nom" / name chapter
      if (sSens == string("LTYPA"))
      {
        iter++ ;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�C;"))
          {
            iter++ ;
            while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 2))
            {
              // on cherche ici un code lexique pour un libelle
              string sCode = (*iter)->getLexique() ;
              pContexte->getDico()->donneLibelle(sLang, &sCode, &sTypeVoie) ;
              iter++ ;
            }
          }
          else
            iter++ ;
        }
      }
      else if (sSens == string("LNOMA"))
      {
        iter++ ;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          	sNomVoie = (*iter)->getTexteLibre() ;
          
          iter++ ;
        }
      }
      else
      	iter++ ;
    }

    // if ((sTypeVoie != "") && (sNomVoie != ""))
    // on ne controle que sur le nom temporairement
    if (sNomVoie != "")
    {
      sVoie = sTypeVoie + string(" ") + sNomVoie ;
      delete pPatPathoArray ;
      return true ;
    }
  }

  delete pPatPathoArray ;
  return false ;
}


bool
NSAddressGraphManager::trouveInfoVilleAdr(string& sVille, string& sPays, string& sZip, string& sCedex)
{
  // on consid�re ici qu'on a un graphe d'adresses charg�
  if ((getRootObject() == "") || (pDataGraph == 0))
  	return false ;

  NSDataTreeIter iterTree ;
  NSPatPathoArray* pPatPathoArray = new NSPatPathoArray(pContexte) ;
  sVille = "" ;
  sPays = "" ;
  sZip = "" ;
  sCedex = "" ;

  if (pDataGraph->aTrees.ExisteTree("LVILL1", pContexte, &iterTree))
  {
    string sElemLex, sSens, sSens1 ;
    (*iterTree)->getPatPatho(pPatPathoArray) ;
    PatPathoIter    iter ;

    // on r�cup�re le nom du site et le num�ro dans la voie
    iter = pPatPathoArray->begin() ;
    int iColBase = (*iter)->getColonne() ;
    iter++ ;

    while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase))
    {
      sElemLex = (*iter)->getLexique() ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

      // Code Postal / Zip Code
      if (sSens == string("LZIP0"))
      {
        iter++ ;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
            sZip = (*iter)->getTexteLibre() ;
          
          iter++ ;
        }
      }
      // Cedex
      else if (sSens == string("LCEDX"))
      {
        iter++ ;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          	sCedex = (*iter)->getTexteLibre() ;
          
          iter++ ;
        }
      }
      // Chapitre "ville" / city chapter
      else if (sSens == string("LCOMU"))
      {
        iter++;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          	sVille = (*iter)->getTexteLibre() ;

          iter++ ;
        }
      }
      // Pays / Country
      else if (sSens == string("LPAYS"))
      {
        iter++ ;
        while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase + 1))
        {
          // on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (string(sElemLex, 0, 3) == string("�CL"))
          	sPays = (*iter)->getTexteLibre() ;
          
          iter++ ;
        }
      }
      else
      	iter++ ;
    }

    if ((sVille != "") || (sZip != ""))
    {
      delete pPatPathoArray ;
      return true ;
    }
  }

  delete pPatPathoArray ;
  return false ;
}


string
NSAddressGraphManager::trouveLibCourtAdr()
{
  string sVille, sPays, sZip, sCedex ;
  string sSite, sNum, sVoie, sBat, sEsc, sBP, sLD ;
  string sLibelle = "" ;

  if (trouveInfoSiteAdr(sSite, sNum, sBat, sEsc, sBP, sLD))
  {
    if (sSite != "")
    	sLibelle = sSite ;
  }

  if (trouveInfoVoieAdr(sVoie))
  {
    if (sNum != "")
    	sLibelle += string(" ") + sNum + string(",") ;
    sLibelle += string(" ") + sVoie ;
  }

  if (trouveInfoVilleAdr(sVille, sPays, sZip, sCedex))
  {
    if (sVille != "")
    	sLibelle += string(" ") + sVille ;
  }
  return sLibelle;
}


string
NSAddressGraphManager::trouveLibLongAdr()
{
  string sEspace, sTele1, sTele2, sFax ;
  string sVille, sPays, sZip, sCedex ;
  string sSite, sNum, sVoie, sBat, sEsc, sBP, sLD ;
  string sLibelle = "" ;

  if (trouveInfoLieuAdr(sEspace, sTele1, sTele2, sFax))
  {
    if (sEspace != "")
    {
      sEspace[0] = pseumaj(sEspace[0]) ;
      sLibelle = sEspace ;
    }
  }

  if (trouveInfoSiteAdr(sSite, sNum, sBat, sEsc, sBP, sLD))
  {
    if (sLibelle != "")
    	sLibelle += string("\r\n") ;

    if (sSite != "")
    {
      sSite[0] = pseumaj(sSite[0]) ;
      sLibelle += sSite + string("\r\n") ;
    }

    if (sBat != "")
    {
      sLibelle += string("Bat ") + sBat ;
      if (sEsc != "")
      	sLibelle += string(" ") ;
      else
      	sLibelle += string("\r\n") ;
    }

    if (sEsc != "")
    {
      sLibelle += string("Esc ") + sEsc ;
      sLibelle += string("\r\n") ;
    }

    if (sBP != "")
    {
      sLibelle += string("BP. ") + sEsc ;
      sLibelle += string("\r\n") ;
    }

    if (sLD != "")
    {
      sLibelle += sLD ;
      sLibelle += string("\r\n") ;
    }
  }

  if (trouveInfoVoieAdr(sVoie))
  {
    if (sNum != "")
      sLibelle += sNum + string(", ") ;

    sLibelle += sVoie ;
    sLibelle += string("\r\n") ;
  }

  if (trouveInfoVilleAdr(sVille, sPays, sZip, sCedex))
  {
    if (sZip != "")
      sLibelle += sZip;

    if (sVille != "")
    {
      if (sZip != "")
        sLibelle += string(" ") ;

      sVille[0] = pseumaj(sVille[0]) ;
      sLibelle += sVille ;

      if (sCedex != "")
      {
      	sLibelle += string(" Cedex ") + sCedex ;
      }
    }

    if (sPays != "")
    {
			string sLang = "" ;
  		if (pContexte->getUtilisateur())
  			sLang = pContexte->getUtilisateur()->donneLang() ;
      if (sLang != "fr")
      {
          sPays[0] = pseumaj(sPays[0]) ;
          sLibelle += string("\r\n") + sPays ;
      }
    }
  }

  return sLibelle ;
}


string
NSAddressGraphManager::trouveTelAdr()
{
  string sEspace, sTele1, sTele2, sFax ;
  if (trouveInfoLieuAdr(sEspace, sTele1, sTele2, sFax))
  {
  	if (sTele1 != "")
    	return sTele1 ;
    else
    	return sTele2 ;
  }
  return "" ;
}


// -----------------------------------------------------------------------------
// class NSTeamGraphManager
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------
bool
NSTeamGraphManager::getTeamGraph(string sObjID, NSPatPathoArray *pPatPathoArray)
{
try
{
	// NSLinkManager *pGraphe = pLinkManager ;
	// bool bGetSuivant = true ;

  // remise � z�ro du graphe
  pDataGraph->graphReset() ;
  string sObject = sObjID ;
  setRootObject(sObjID) ;

	NSBasicAttributeArray AttrList ;
  AttrList.push_back(new NSBasicAttribute(OBJECT, sObjID)) ;
//  pAttrList->push_back(new NSBasicAttribute("user", pContexte->getUtilisateurID())) ;

  bool res = pContexte->pPilot->invokeService(NautilusPilot::SERV_SEARCH_OBJECT_FROM_ID.c_str(), pDataGraph, &AttrList) ;
  if (!res)
  {
  	string 	sMessage = "" ;
  	if 			(pContexte->pPilot->getErrorMessage() != "")
    	sMessage = pContexte->pPilot->getErrorMessage() ;
    else if (pContexte->pPilot->getWarningMessage() != "")
    	sMessage = pContexte->pPilot->getWarningMessage() ;
    else
    	sMessage = "Echec du service de r�cup�ration du graphe repr�sentant une Equipe." ;
    erreur(sMessage.c_str(), standardError, 0) ;
    return false ;
  }

  // constitution de la patpatho contenant tous les arbres du graphe
  if (pPatPathoArray)
  {
    pPatPathoArray->vider() ;
    if (!(pDataGraph->aTrees.empty()))
    {
      for (NSDataTreeIter i = pDataGraph->aTrees.begin() ; i != pDataGraph->aTrees.end() ; i++)
      {
      	NSPatPathoArray Ppt(pContexte) ;
        (*i)->getPatPatho(&Ppt) ;
        pPatPathoArray->ajouteVecteur(&Ppt, ORIGINE_PATH_PATHO) ;
      }
    }
  }
  return true ;
}
catch (...)
{
  erreur("Exception NSTeamGraphManager::getTeamGraph", standardError, 0) ;
  return false ;
}
}

// -----------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------
bool
NSTeamGraphManager::setTeamGraph(NSPatPathoArray *pPPT, string sOperatorID, bool bLocalTeam)
{
	if ((NULL == pPPT) || (true == pPPT->empty()))
		return false ;

  // TODO FIXME FLP
  // il manque la modification de l'objet - FLP

  NSBasicAttributeArray	AttrList ;
	string								sNodeRoot		= "" ;
  string								sCodeObj		= "LEQUM1" ;
  PatPathoIter					pptIter			= pPPT->begin() ;

  if ((pptIter != pPPT->end()) && ((*pptIter)->getLexique() == sCodeObj))
  {
  	// Penser � passer (*pptIter)->getDoc(), sinon l'arbre perd son num�ro de document : g�nant en cas d'�volution
    // (*pptIter)->getDoc() must be transmitted, elsewhere the tree's document ID gets lost : big problem when the team grows
		sNodeRoot	= setTree(pPPT, "", (*pptIter)->getDoc()) ;
  	setRootObject(sNodeRoot) ;
  }
  else
  {
  	erreur("L'arbre ne contient d'Equipe.", standardError, 0) ;
    return false ;
  }

  // Le graphe est maintenant constitu�. on doit appeler le pilote pour
  // trouver successivement les ID de tous les arbres du graphe
  // (et r�soudre leurs d�pendances)

  NSDataGraph								LocalGraph(pContexte, graphObject) ;
  string										sTreeID				= "" ;
  string										sTreeRights		= "" ;
  NSPatPathoArray						PatPatho(pContexte, graphObject) ;
  NSPersonsAttributesArray	ObjectsList ;
  NSDataTreeIter						iterTree ;

  bool	bExist	= pDataGraph->aTrees.ExisteTree(sCodeObj, pContexte, &iterTree) ;
  if (bExist)
  {
  	sTreeID	= (*iterTree)->getTreeID() ;
    LocalGraph.graphReset() ;
    PatPatho.vider() ;
    pDataGraph->getTree(sTreeID, &PatPatho, &sTreeRights) ;
    LocalGraph.setTree(&PatPatho, sTreeRights, sTreeID) ;

    string sNewGraphMask = "$#" ;
    bool res = false ;
    if (strncmp(sNewGraphMask.c_str(), sTreeID.c_str(), strlen(sNewGraphMask.c_str())) == 0)
    {
      // rustine EpiPump
      if (sOperatorID == "")
        AttrList.push_back(new NSBasicAttribute("user", pContexte->getUtilisateurID())) ;
      else
        AttrList.push_back(new NSBasicAttribute("user", sOperatorID)) ;

      AttrList.push_back(new NSBasicAttribute(TEAM_LNOMA, getTeamName(&PatPatho))) ;

      if (bLocalTeam)
        AttrList.push_back(new NSBasicAttribute(LOCALTEAM, "1")) ;

      // Appel pilot : cr�ation de l'objet en local
      // calling pilot : create local object
      res	= pContexte->pPilot->createPersonOrObject(NautilusPilot::SERV_CREATE_OBJECT.c_str(), &LocalGraph, &ObjectsList, &AttrList, OBJECT_TYPE, false) ;
    }
    else
    {
      AttrList.push_back(new NSBasicAttribute(OBJECT, sTreeID)) ;
      if (sOperatorID == "")
        AttrList.push_back(new NSBasicAttribute(OPERATOR, pContexte->getUtilisateurID())) ;
      else
        AttrList.push_back(new NSBasicAttribute(OPERATOR, sOperatorID)) ;
      res = pContexte->pPilot->modifyPersonOrObject(NautilusPilot::SERV_MODIFY_OBJECT.c_str(), &LocalGraph, &ObjectsList, &AttrList) ;
    }

    if (!res)
    {
      erreur("Echec du service pilot lors de la cr�ation/modification du graphe d'une Equipe.", standardError, 0) ;
      return false ;
    }
  }

  // Remplacement du nouvel ID dans le DataGraph
  NSDataTreeIter iter = LocalGraph.aTrees.begin() ;
  string sNewTreeID = (*iter)->getTreeID() ;
  NSPatPathoArray Ppt(pContexte) ;
  (*iter)->getPatPatho(&Ppt) ;
  pDataGraph->replaceTree(sTreeID, sNewTreeID, &Ppt, sTreeRights) ;

	return true ;
}

string
NSTeamGraphManager::getTeamName(NSPatPathoArray *pPPT)
{
	string	sResult	= "" ;
	for (PatPathoIter pptIter = pPPT->begin() ; pptIter != pPPT->end() ; pptIter++)
	{
  	if ((*pptIter)->getLexique() == "LNOMA1")
    {
    	PatPathoIter	labelIter = pptIter ;
      labelIter++ ;
      if ((labelIter != pPPT->end()) && ((*labelIter)->getLexique() == "�CL000"))
      {
      	sResult = (*labelIter)->getTexteLibre() ;
        break ;
      }
    }
  }
  return sResult ;
}

NSMoralPerson *
NSTeamGraphManager::createTeam()
{
	NSPatPathoArray PPT(pContexte, graphObject) ;

  NSSmallBrother  BBoss(pContexte, &PPT) ;
  BBoss.pFenetreMere = pContexte->GetMainWindow() ;

  // Ici on lance une boite de dialogue modale
#ifdef __OB1__
	BB1BBInterfaceForKs InterfaceForKs(-1, pContexte->getSuperviseur()->getTeamMemberArchetypeId(), "", false) ;
	BBoss.lanceBbkArchetypeInDialog(pContexte->getSuperviseur()->getTeamMemberArchetypeId(), 0, 0, &InterfaceForKs, true) ;
#else
	BBoss.lanceBbkArchetypeInDialog(pContexte->getSuperviseur()->getTeamMemberArchetypeId(), 0, 0, true) ;
#endif

  // on teste le code de retour du dialogue, qui est stock� dans le
  // BBItem root cr�� par le pBigBoss.
  if (BBoss.pBBItem->iRetourDlg == 0)     // CmOK
  {
    // on enregistre la patpatho du pBigBoss, qui contient les nouvelles donn�es
    // si elle n'est pas vide.
    if (!(BBoss.getPatPatho()->empty()))
    {
      PPT = *(BBoss.getPatPatho()) ;
      NSMoralPerson *pMPTeam = new NSMoralPerson(&PPT) ;
      return pMPTeam ;
    }
  }

  return NULL ;
}

// -----------------------------------------------------------------------------
//
// Classe NSPersonGraphManager
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// default constructor
// -----------------------------------------------------------------------------
NSPersonGraphManager::NSPersonGraphManager(NSContexte* pCtx)
	:	NSRoot(pCtx)
{
try
{
	// NSSuper *pLocalSuper = pContexte->getSuperviseur() ;
  // NSArcManager *pAManager = pLocalSuper->getArcManager() ;

	bReadOnly 		= true ;
  bNeedUnlock 	= false ;

  pDataGraph  	= new NSDataGraph(pContexte, graphPerson) ;
  pLinkManager	= new NSLinkManager(pContexte, pDataGraph) ;
  pAttrArray 		= new NSBasicAttributeArray() ;

  lObjectCount++ ;
}
catch (...)
{
	erreur("Exception NSPersonGraphManager ctor", standardError, 0) ;
}
}


// -----------------------------------------------------------------------------
// copy constructor
// -----------------------------------------------------------------------------
NSPersonGraphManager::NSPersonGraphManager(const NSPersonGraphManager& rv)
	: NSRoot(rv.pContexte)
{
try
{
	bReadOnly 		= rv.bReadOnly ;
  bNeedUnlock 	= rv.bNeedUnlock ;

  pDataGraph    = new NSDataGraph(*(rv.pDataGraph)) ;
  pLinkManager	= new NSLinkManager(pContexte, pDataGraph) ;
  pAttrArray    = new NSBasicAttributeArray(*(rv.pAttrArray)) ;

  lObjectCount++ ;
}
catch (...)
{
	erreur("Exception NSPersonGraphManager copy ctor", standardError, 0) ;
}
}


// -----------------------------------------------------------------------------
// destructor
// -----------------------------------------------------------------------------
NSPersonGraphManager::~NSPersonGraphManager()
{
  if (pDataGraph)
  	delete pDataGraph ;

  if (pLinkManager)
  	delete pLinkManager ;

  if (pAttrArray)
  	delete pAttrArray ;

  lObjectCount-- ;
}


NSPersonGraphManager&
NSPersonGraphManager::operator=(const NSPersonGraphManager& src)
{
	if (this == &src)
  	return (*this) ;

	bReadOnly 		= src.bReadOnly ;
  bNeedUnlock 	= src.bNeedUnlock ;

  if (pDataGraph)
  	delete pDataGraph ;
  pDataGraph = new NSDataGraph(*(src.pDataGraph)) ;

  if (pLinkManager)
  	delete pLinkManager ;
  pLinkManager = new NSLinkManager(pContexte, pDataGraph) ;

  if (pAttrArray)
  	delete pAttrArray ;
  pAttrArray = new NSBasicAttributeArray(*(src.pAttrArray)) ;
/*
  *pDataGraph 	= *(src.pDataGraph) ;
  *pLinkManager = *(src.pLinkManager) ;
  *pAttrArray  	= *(src.pAttrArray) ;
*/
  return (*this) ;
}


void
NSPersonGraphManager::graphReset()
{
	// NSSuper *pLocalSuper = pContexte->getSuperviseur() ;
  pDataGraph->graphReset() ;
  pAttrArray->vider() ;
}


// -----------------------------------------------------------------------------
// Pr�paration et audit du graphe (tri des arbres par localisation et
// v�rification de son homog�n�it�)
// --
// Preparation and audit of the graph (sort the trees and check graph
// homogeneity)
// -----------------------------------------------------------------------------
bool
NSPersonGraphManager::graphPrepare()
{
	if (NULL == pDataGraph)
    return false ;

	if (pDataGraph->aTrees.empty())
    return true ;
	for (NSDataTreeIter i = pDataGraph->aTrees.begin() ; pDataGraph->aTrees.end() != i ; i++)
  	(*i)->sortPPTByLocalisation() ;

  return true ;
}


void
NSPersonGraphManager::setRootTree(string sTrID)
{
	pDataGraph->setGraphID(sTrID) ;
	pDataGraph->setLastTree() ;
}

string
NSPersonGraphManager::getRootTree()
{
	return (pDataGraph->getGraphID()) ;
}

string
NSPersonGraphManager::getPersonID()
{
	if (getRootTree() == "")
		return string("") ;

	return string(pDataGraph->getGraphID(), 0, PAT_NSS_LEN) ;
}

bool
NSPersonGraphManager::incrementeCode(string& sCompteur)
{
	return pDataGraph->incrementeCode(sCompteur) ;
}

bool
NSPersonGraphManager::getTree(string sObjectID, NSPatPathoArray* pPatPatho, string* psDocRosace)
{
	return pDataGraph->getTree(sObjectID, pPatPatho, psDocRosace) ;
}

string
NSPersonGraphManager::setTree(NSPatPathoArray* pPatPatho, string sDocRosace, string sCode)
{
	// NSSuper *pLocalSuper = pContexte->getSuperviseur() ;
  // NSArcManager *pArcManager = pLocalSuper->getArcManager() ;
  return pDataGraph->setTree(pPatPatho, sDocRosace, sCode) ;
}


bool
NSPersonGraphManager::updateTrees(NSVectPatPathoArray *	pVectTrees,
                                  string *							psNewDataTreeId,
                                  string *							psNewMetaTreeId,
                                  PIDSTYPE					    iTypePids,
                                  bool								  bInterface)
{
try
{
	if ((NULL == pVectTrees) || (pVectTrees->empty()))
		return false ;

	string ps2 = "NSPersonGraphManager::updateTrees : begin" ;
  pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

	NSDataGraph LocalGraph(pContexte, graphPerson) ;

	NSEnregTreeDocDlg* pEnregDlg = NULL ;

	bool bEnregIsCreated = false ;
	string sDocum = string(DOC_CODE_DOCUM_LEN, '0') ;
	sDocum[0] = '#' ;
	string sLocalRootTree = getPersonID() + sDocum ;
	LocalGraph.setLastTree(sLocalRootTree) ;
	NSDataTreeIter iterTree ;
	size_t lenTree = OBJECT_ID_LEN ;
	int nbTrees = pVectTrees->size() ;

	// on extrait ici les arbres (et leurs liens) du DataGraph et on les place dans le graphe local
	for (PatPathoIterVect i = pVectTrees->begin() ; pVectTrees->end() != i ; i++)
	{
		if ((*i) && (!((*i)->empty())))
		{
			string sTreeID = (*((*i)->begin()))->getDoc() ;
			string sCodeLex = (*((*i)->begin()))->getLexique() ;

			ps2 = string("NSPersonGraphManager::updateTrees : treeID = ") + sTreeID ;
			pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

			if (bInterface && (string("ZDOCU1") != sCodeLex) && (string("LCTRI1") != sCodeLex))
			{
        pEnregDlg = new NSEnregTreeDocDlg(pContexte->GetMainWindow(), pContexte) ;
				pEnregDlg->Create() ;
				pEnregDlg->Show(SW_SHOW) ;
				pEnregDlg->SetText(sCodeLex) ;
				bEnregIsCreated = true ;
			}

			string sTreeRosace = pDataGraph->aRights.find(sTreeID) ;

			// mise � jour des nodes textes libres dans la patpatho
			ps2 = string("NSPersonGraphManager::updateTrees : before updateNodesTL") ;
			pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

			pDataGraph->updateNodesTL(*i, sTreeID) ;

      ps2 = string("NSPersonGraphManager::updateTrees : before aRights.RemoveDocument") ;
			pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

			if ((string("") != sTreeID) && (pDataGraph->aTrees.ExisteTreeID(sTreeID, &iterTree)))
			{
				pDataGraph->aRights.RemoveDocument(sTreeID) ;
				delete (*iterTree) ;
				pDataGraph->aTrees.erase(iterTree) ;
			}

      ps2 = string("NSPersonGraphManager::updateTrees : before setTree") ;
			pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

			// Ne pas faire setTree(*i), qui r�attribue des treeID
			LocalGraph.setTree(*i, sTreeRosace, sTreeID) ;

      // on place ici les contributions
      if (string("LCTRI1") != sCodeLex)
        LocalGraph.signChanges(sTreeID) ;

      ps2 = string("NSPersonGraphManager::updateTrees : before links moving") ;
			pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

      if (false == pDataGraph->aLinks.empty())
      {
        for (NSPatLinkIter j = pDataGraph->aLinks.begin() ; pDataGraph->aLinks.end() != j ; )
        {
          if ((*j) &&
            	((string((*j)->getQualifie(), 0, lenTree) == sTreeID) ||
               (string((*j)->getQualifiant(), 0, lenTree) == sTreeID)))
          {
            LocalGraph.aLinks.push_back(new NSPatLinkInfo(*(*j))) ;
            delete (*j) ;
            pDataGraph->aLinks.erase(j) ;
          }
          else
            j++ ;
        }
      }

			ps2 = string("NSPersonGraphManager::updateTrees : before models moving") ;
			pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

      if (false == pDataGraph->aArchs.empty())
      {
        for (NSArcLinkIter k = pDataGraph->aArchs.begin() ; pDataGraph->aArchs.end() != k ; )
        {
          if ((*k) && (sTreeID == (*k)->object))
          {
            // on ne fait pas ici le push_back car il est fait par le setTree
            // pLocalGraph->aArchs.push_back(new NSArcLink(*(*k)));
            delete (*k) ;
            pDataGraph->aArchs.erase(k) ;
          }
          else
            k++ ;
        }
      }
    }
  }

	ps2 = "NSPersonGraphManager::updateTrees : before writeGraph" ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

  // on exp�die le graphe au pilote
  bool res = writeGraph(iTypePids, &LocalGraph) ;

  if (!res)
    erreur("erreur d'�criture du graphe � travers le pilote.", standardError, 0) ;

	ps2 = string("NSPersonGraphManager::updateTrees : before re-introducing trees") ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

  // on "plug" maintenant le graphe local (updat� par le pilote) sur le DataGraph
  // (m�me si le pilote ne l'a pas enregistr�, il faut le replacer dans le graphe)
  if (false == LocalGraph.aTrees.empty())
  {
    for (NSDataTreeIter i = LocalGraph.aTrees.begin() ; LocalGraph.aTrees.end() != i ; i++)
    {
      NSPatPathoArray Ppt(pContexte) ;
      string sTreeID = (*i)->getTreeID() ;
      string sTreeRosace ;
      LocalGraph.getTree(sTreeID, &Ppt, &sTreeRosace) ;
      pDataGraph->setTree(&Ppt, sTreeRosace, sTreeID) ;

      if (1 == nbTrees)
      {
        if (psNewDataTreeId)
        	*psNewDataTreeId = sTreeID ;
        else
        {
          erreur("L'identifiant de l'arbre � mettre � jour n'est pas d�clar� dans ::updateTrees().", standardError, 0) ;
          return false ;
        }
      }
    }
  }

	ps2 = string("NSPersonGraphManager::updateTrees : before re-introducing links") ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

  if (false == LocalGraph.aLinks.empty())
  {
    for (NSPatLinkIter j = LocalGraph.aLinks.begin() ; LocalGraph.aLinks.end() != j ; j++)
    {
      // s'il y a un arbre m�ta et un arbre data, on renvoie le code des datas.
      // (extr�mit� du lien NSRootLink::docData)
      if ((nbTrees > 1) && ((*j)->getLien() == pLinkManager->donneString(NSRootLink::docData)))
      {
        if ((psNewMetaTreeId) && (psNewDataTreeId))
        {
          *psNewMetaTreeId = (*j)->getQualifie() ;
          *psNewDataTreeId = (*j)->getQualifiant() ;
        }
        else
        {
          erreur("L'identifiant de l'arbre � mettre � jour n'est pas d�clar� dans ::updateTrees().", standardError, 0) ;
          return false ;
        }
      }

      (*j)->setDirty(false) ;
      pDataGraph->aLinks.push_back(new NSPatLinkInfo(*(*j))) ;
    }
  }

	ps2 = string("NSPersonGraphManager::updateTrees : before re-introducing models") ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

	if (false == LocalGraph.aArchs.empty())
		for (NSArcLinkIter k = LocalGraph.aArchs.begin() ; LocalGraph.aArchs.end() != k ; k++)
			pDataGraph->aArchs.push_back(new NSArcLink(*(*k))) ;

	if (bEnregIsCreated)
  {
		pEnregDlg->Destroy() ;
	  delete pEnregDlg ;
  }

	ps2 = string("NSPersonGraphManager::updateTrees : done") ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

  if (!res)
    return false ;

  return true ;
}
catch (...)
{
  erreur("Exception NSPersonGraphManager::updateTrees", standardError, 0) ;
  return false  ;
}
}

bool
NSPersonGraphManager::commitGraphTree(string& sTreeID, PIDSTYPE iTypePids)
{
try
{
	if (strlen(sTreeID.c_str()) != (PAT_NSS_LEN + DOC_CODE_DOCUM_LEN))
	{
  	erreur("TreeID de longueur non conforme.", standardError, 0) ;
    return false ;
	}

	string ps2 = "NSPersonGraphManager::commitGraphTree : begin" ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

	NSDataGraph LocalGraph(pContexte, graphPerson) ;
	NSEnregTreeDocDlg* pEnregDlg = 0 ;
	NSPatPathoArray PatPatho(pContexte) ;

	bool bEnregIsCreated = false ;
	string sDocum = string(DOC_CODE_DOCUM_LEN, '0') ;
	sDocum[0] = '#' ;
	string sLocalRootTree = getPersonID() + sDocum ;
	LocalGraph.setLastTree(sLocalRootTree) ;
	NSDataTreeIter iterTree ;
	size_t lenTree = OBJECT_ID_LEN ;

	// Ici on va sortir l'arbre � updater (sTreeID, qui en principe est en '#' au d�part) du
	// graphe de base (pDataGraph) pour l'introduire dans un graphe local avec ses liens et
	// ses arch�types. Ce graphe local sera ensuite envoy� au pilote.
	if (pDataGraph->aTrees.ExisteTreeID(sTreeID, &iterTree))
	{
  	(*iterTree)->getPatPatho(&PatPatho);

    string sCodeLex = (*(PatPatho.begin()))->getLexique() ;

    ps2 = string("NSPersonGraphManager::commitGraphTree : treeID = ") + sTreeID ;
    pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

    if ((sCodeLex != string("ZDOCU1")) && (sCodeLex != string("LCTRI1")))
    {
      pEnregDlg = new NSEnregTreeDocDlg(pContexte->GetMainWindow(), pContexte) ;
    	pEnregDlg->Create() ;
      pEnregDlg->Show(SW_SHOW) ;
      pEnregDlg->SetText(sCodeLex) ;
      bEnregIsCreated = true ;
    }

    pDataGraph->updateNodesTL(&PatPatho, sTreeID) ;

    string sTreeRosace = pDataGraph->aRights.find(sTreeID) ;

    ps2 = string("NSPersonGraphManager::commitGraphTree : before aRights.RemoveDocument") ;
    pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

    pDataGraph->aRights.RemoveDocument(sTreeID) ;
    delete (*iterTree) ;
    pDataGraph->aTrees.erase(iterTree) ;

    ps2 = string("NSPersonGraphManager::commitGraphTree : before setTree") ;
    pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

    // Ne pas faire setTree(pPatPatho), qui r�attribue des treeID
    LocalGraph.setTree(&PatPatho, sTreeRosace, sTreeID) ;

    // on place ici les contributions
    if (sCodeLex != string("LCTRI1"))
    	LocalGraph.signChanges(sTreeID) ;

    ps2 = string("NSPersonGraphManager::commitGraphTree : before links moving") ;
    pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

    if (!(pDataGraph->aLinks.empty()))
    {
    	for (NSPatLinkIter j = pDataGraph->aLinks.begin(); j != pDataGraph->aLinks.end(); )
      {
      	if ((*j) &&
            ((string((*j)->getQualifie(), 0, lenTree) == sTreeID) ||
             (string((*j)->getQualifiant(), 0, lenTree) == sTreeID)))
        {
        	LocalGraph.aLinks.push_back(new NSPatLinkInfo(*(*j))) ;
          delete (*j) ;
          pDataGraph->aLinks.erase(j) ;
        }
        else
        	j++ ;
      }
    }

    ps2 = string("NSPersonGraphManager::commitGraphTree : before models moving") ;
    pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

    if (!(pDataGraph->aArchs.empty()))
    {
    	for (NSArcLinkIter k = pDataGraph->aArchs.begin(); k != pDataGraph->aArchs.end(); )
      {
      	if ((*k) && (sTreeID == (*k)->object))
        {
        	// on ne fait pas ici le push_back car il est fait par le setTree
          // pLocalGraph->aArchs.push_back(new NSArcLink(*(*k)));
          delete (*k) ;
          pDataGraph->aArchs.erase(k) ;
        }
        else
        	k++ ;
      }
    }
  }
  else
  {
  	char msg[255] ;
    sprintf(msg, "L'arbre d'identifiant [%s] est inexistant dans le graphe.", sTreeID.c_str()) ;
    erreur(msg, standardError, 0) ;
  }

	ps2 = "NSPersonGraphManager::commitGraphTree : before writeGraph" ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

	// on exp�die le graphe au pilote
	bool res = writeGraph(iTypePids, &LocalGraph) ;

	if (!res)
		erreur("erreur d'�criture du graphe � travers le pilote.", standardError, 0) ;

	ps2 = string("NSPersonGraphManager::commitGraphTree : before re-introducing trees") ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

	// on "plug" maintenant le graphe local (updat� par le pilote) sur le DataGraph
	// (m�me si le pilote ne l'a pas enregistr�, il faut le replacer dans le graphe)
	if (!(LocalGraph.aTrees.empty()))
	{
  	// on fait ici cette boucle pour la forme, mais en principe pLocalGraph
    // ne contient qu'un seul arbre mis � jour par le writeGraph pr�c�dent
    for (NSDataTreeIter i = LocalGraph.aTrees.begin(); i != LocalGraph.aTrees.end(); i++)
    {
    	NSPatPathoArray Ppt(pContexte) ;
      sTreeID = (*i)->getTreeID() ;
      string sTreeRosace ;
      LocalGraph.getTree(sTreeID, &Ppt, &sTreeRosace) ;
      pDataGraph->setTree(&Ppt, sTreeRosace, sTreeID) ;
    }
  }

	ps2 = string("NSPersonGraphManager::commitGraphTree : before re-introducing links") ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

	if (!(LocalGraph.aLinks.empty()))
	{
  	for (NSPatLinkIter j = LocalGraph.aLinks.begin(); j != LocalGraph.aLinks.end(); j++)
    {
    	(*j)->setDirty(false) ;
      pDataGraph->aLinks.push_back(new NSPatLinkInfo(*(*j))) ;
    }
  }

	ps2 = string("NSPersonGraphManager::commitGraphTree : before re-introducing models") ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

	if (!(LocalGraph.aArchs.empty()))
		for (NSArcLinkIter k = LocalGraph.aArchs.begin(); k != LocalGraph.aArchs.end(); k++)
			pDataGraph->aArchs.push_back(new NSArcLink(*(*k))) ;

	if (bEnregIsCreated)
  {
		pEnregDlg->Destroy() ;
	  delete pEnregDlg ;
  }

	ps2 = string("NSPersonGraphManager::commitGraphTree : done") ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

	if (!res)
		return false ;

	return true ;
}
catch (...)
{
	erreur("Exception NSPersonGraphManager::commitGraphTree", standardError, 0) ;
	return false ;
}
}

bool
NSPersonGraphManager::signChanges(string sTreeID)
{
	return pDataGraph->signChanges(sTreeID) ;
}

bool
NSPersonGraphManager::getGraph()
{
	if ((getRootTree() == "") || (pDataGraph == 0))
  	return false ;

	// Prise de l'arbre de base
  // appel de readGraph
  //return pContexte->pPilot->readGraph(pDataGraph);
  return false ;
}

bool
NSPersonGraphManager::setGraph()
{
/* ******************* Obsolete ***************
#ifdef N_TIERS
    return pContexte->pPilot->writeGraph(pDataGraph);
#else
*/
	return true ;
}

bool
NSPersonGraphManager::writeGraph(PIDSTYPE iTypePids, NSDataGraph* pGraph)
{
	const char* serviceName ;
	bool bCreatePerson = false ;

	if (pGraph == 0)
		bCreatePerson = true ;

	if (iTypePids == pidsPatient)
	{
  	if (bCreatePerson)
    	serviceName = (NautilusPilot::SERV_CREATE_PATIENT).c_str() ;
    else
    	serviceName = (NautilusPilot::SERV_MODIFY_PERSON).c_str() ;
	}
	else if (iTypePids == pidsCorresp)
	{
		if (bCreatePerson)
    	serviceName = (NautilusPilot::SERV_CREATE_CORESPONDENT).c_str() ;
    else
    	serviceName = (NautilusPilot::SERV_MODIFY_PERSON).c_str() ;
	}
	else if (iTypePids == pidsUtilisat)
	{
		if (bCreatePerson)
    	serviceName = (NautilusPilot::SERV_CREATE_USER).c_str() ;
    else
    	serviceName = (NautilusPilot::SERV_MODIFY_USER).c_str() ;
	}
	else if (iTypePids == pidsPatientGroup)
	{
		if (bCreatePerson)
    	serviceName = (NautilusPilot::SERV_CREATE_GROUP_PATIENT).c_str() ;
    else
    	serviceName = (NautilusPilot::SERV_MODIFY_GROUP_PATIENT).c_str() ;
	}

	string sPids = pAttrArray->getAttributeValue(PERSON) ;
	string sUser = pAttrArray->getAttributeValue(OPERATOR) ;

	if (bCreatePerson)    // cas de la cr�ation (on passe alors le graphe global)
	{
  	// la liste de personnes en cas de doublons
    //
    NSPersonsAttributesArray doublonsList ;
    //la liste des attributes du pids est pAttrArray (variable de classe)

    bool res = pContexte->pPilot->createPersonOrObject(serviceName, pDataGraph, &doublonsList, pAttrArray, 0, false) ;

    size_t iListSize = 0 ;
    if (!(doublonsList.empty()))
    	iListSize = doublonsList.size() ;

		// For patients creation, we have to check if doublonsList really contains
    // patients (=doublons=creation failed) or just the new patient's status
    //
    if ((iTypePids == pidsPatient) && (iListSize > 0))
    {
    	NSPersonsAttributeIter i = doublonsList.begin() ;
      string sRole = (*i)->getAttributeValue(ROLE) ;
      if (sRole == string(""))
      	iListSize = 0 ;
    }

    if ((!res) && (iListSize > 0))		// pList not empty : cas des doublons
    {
    	string sErrorText = "echec service" ;
      if (iTypePids == pidsPatient)
      	sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "createPatientFailed") ;
      else if (iTypePids == pidsUtilisat)
      	sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "createUserFailed") ;
      erreur( sErrorText.c_str(), warningError, 0) ;
    }
    else if (iListSize > 0)
    {
    	string sRole ;
      if (iTypePids == pidsPatient)
      	sRole = PATIENT_ROLE ;
      else if (iTypePids == pidsUtilisat)
      	sRole = USER_ROLE ;
      else if (iTypePids == pidsCorresp)
      	sRole = CORRESP_ROLE ;

      NSTDoublonListDialog* pDoublonDlg = new NSTDoublonListDialog(pContexte->GetMainWindow(), pContexte,
                                                                            &doublonsList, sRole) ;
			if (pDoublonDlg->Execute() == IDOK)
      {
      	if (pDoublonDlg->bCreer)
        {
        	// Appel du service pour forcer la creation
          bool bForceRes = pContexte->pPilot->createPersonOrObject(serviceName, pDataGraph, &doublonsList, pAttrArray, 0, true) ;
          if (!bForceRes)
          {
          	delete pDoublonDlg ;
          	return false ;
          }
        }
        else
        {
        	mergeGraph(pDoublonDlg->sPersonSelect, sRole, pDoublonDlg->sRolePersonSelect) ;
        }
        delete pDoublonDlg ;
      }
			else
      {
      	delete pDoublonDlg ;
        return false ;
      }
    }
  }
  else
  {
		// modification des donn�es du pids
    // pour l'instant, on repasse tous les traits � chaque fois
		//        changeInfoPids();

    //la liste comprend ici la personne dont on modifie le graphe avec ses attributs de pids
    NSPersonsAttributesArray List ;
    //la liste des attributes du pids est pAttrArray (variable de classe)

    if (!pContexte->pPilot->modifyPersonOrObject(serviceName, pGraph, &List, pAttrArray))
    {
    	string sErrorText = "echec service" ;
      if (iTypePids == pidsPatient)
      	sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "modifyPatientFailed") ;
      else if (iTypePids == pidsUtilisat)
      	sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "modifyUserFailed") ;
			pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      erreur(sErrorText.c_str(), warningError, standardError, 0) ;
    }
	}
	return true ;
}

bool
NSPersonGraphManager::mergeGraph(string sPersonID, string sNewRole, string sOldRole)
{
	NSPatPathoArray OtherPPTAdmin(pContexte, graphPerson) ;
	NSPatPathoArray OtherPPTPDS(pContexte, graphPerson) ;
	NSPersonGraphManager OtherGraph(pContexte) ;
	if (!OtherGraph.getGraphAdmin(sPersonID, true))
  	return false ;

	OtherGraph.pAttrArray->push_back(new NSBasicAttribute(PERSON, sPersonID)) ;
	OtherGraph.pAttrArray->push_back(new NSBasicAttribute(OPERATOR, pContexte->getUtilisateurID())) ;

	NSPatPathoArray PPTAdmin(pContexte, graphPerson) ;
	NSPatPathoArray PPTPDS(pContexte, graphPerson) ;
	NSDataTreeIter iterTree ;

	if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
	{
  	(*iterTree)->getPatPatho(&PPTAdmin) ;

    if (OtherGraph.pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
    {
    	(*iterTree)->getPatPatho(&OtherPPTAdmin);

      if (!mergeTrees(&PPTAdmin, &OtherPPTAdmin))
      	return false ;
    }
    else
    	OtherPPTAdmin = PPTAdmin ;
  }
  else
  {
  	char msg[255] ;
    sprintf(msg, "Person=[%s] : Missing [ZADMI1] in graph.", getPersonID().c_str()) ;
    string sMsg = string(msg) ;
    pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trWarning) ;
    erreur(msg, standardError, 0) ;
    return false ;
  }

	if (pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
	{
  	(*iterTree)->getPatPatho(&PPTPDS) ;

    if (OtherGraph.pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
    {
    	(*iterTree)->getPatPatho(&OtherPPTPDS) ;

      if (!mergeTrees(&PPTPDS, &OtherPPTPDS))
      	return false ;
    }
    else
    	OtherPPTPDS = PPTPDS ;
  }

	if (OtherGraph.pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
	{
  	string sCodeDocAdmin = (*iterTree)->getTreeID() ;
    OtherGraph.setTree(&OtherPPTAdmin, "", sCodeDocAdmin) ;
  }
  else
  	OtherGraph.createPPTAdmin(&OtherPPTAdmin) ;

	if (OtherGraph.pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
  {
  	string sCodeDocPDS = (*iterTree)->getTreeID() ;
    OtherGraph.setTree(&OtherPPTPDS, "", sCodeDocPDS) ;
  }
  else
  	OtherGraph.createPPTPDS(&OtherPPTPDS) ;

	//la liste des attributes du pids est pAttrArray (variable de classe)
  pAttrArray->push_back(new NSBasicAttribute(ROLE, sNewRole)) ;
  pAttrArray->changeAttributeValue(PERSON, sPersonID) ;
  // on doit retirer la balise PIDS si elle existe avant de l'envoyer au serveur
  if (pAttrArray->getAttributeValue(PIDS) != "")
  	pAttrArray->changeAttributeValue(PIDS, pAttrArray->getAttributeValue(PIDS));

  // modification des attributs du PIDS
  if (!pContexte->pPilot->modifyPIDSData((NautilusPilot::SERV_MODIFY_PERSON_ROLE).c_str(), pAttrArray))
  {
  	string sErrorText = "echec service" ;
    sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "modifyPersonFailed") ;
    erreur(sErrorText.c_str(), warningError, standardError, 0) ;
    return false ;
	}

	// Rustine temporaire en attendant l'unification des pids
	PIDSTYPE iTypePids ;

	if (sOldRole.find(USER_ROLE) != NPOS)
  	iTypePids = pidsUtilisat ;
  else if (sOldRole.find(PATIENT_ROLE) != NPOS)
  	iTypePids = pidsPatient ;
  else if (sOldRole.find(CORRESP_ROLE) != NPOS)
  	iTypePids = pidsCorresp ;    // ATTENTION : non impl�ment� en modification pour l'instant dans setGraphAdmin

	// passer ici le type de pids dans setGraphAdmin en fonction de l'ancien role.
	OtherPPTAdmin.InserePatPatho(OtherPPTAdmin.end(), &OtherPPTPDS, 0) ;
	OtherGraph.setGraphAdmin(&OtherPPTAdmin, iTypePids) ;

	return true ;
}

bool
NSPersonGraphManager::mergeTrees(NSPatPathoArray* pSource, NSPatPathoArray* pDest)
{
	if (!pSource || pSource->empty() || !pDest)
		return false ;

	PatPathoIter iterSuiv ;
	string msg ;
	string sLang = "" ;

	if ((pContexte) && (pContexte->getUtilisateur()))  	sLang = pContexte->getUtilisateur()->donneLang() ;

	for (PatPathoIter i = pSource->begin(); i != pSource->end(); i++)
	{
  	iterSuiv = i ;
    iterSuiv++ ;

    if ((iterSuiv == pSource->end()) || ((*iterSuiv)->getColonne() <= (*i)->getColonne()))
    {
    	// on est s�r ici que iterElement est une feuille
      string sCheminLex = pSource->donneCheminItem(i) ;
      string sCheminFils = sCheminLex ;
      if ((*i)->getUnit() != "")
      	sCheminFils += string(1, cheminSeparationMARK) + (*i)->getUnit() ;
      sCheminFils += string(1, cheminSeparationMARK) + (*i)->getLexique() ;

      PatPathoIter iter ;
      string sElemLex = (*i)->getLexique() ;
      if (string(sElemLex, 0, 3) == "�CL")
      {
      	if (pDest->CheminDansPatpatho(sCheminFils, "/", &iter))
        {
        	string sTLSource = (*i)->getTexteLibre() ;
          string sTLDest = (*iter)->getTexteLibre() ;

          if (sTLSource != sTLDest)
          {
          	msg = string("Voulez-vous remplacer ") +  sTLDest + string(" par ") + sTLSource + string(" ?") ;
            int retVal = ::MessageBox(0, msg.c_str(), "Message Episodus", MB_YESNO) ;

            if (retVal == IDYES)
            	(*iter)->setTexteLibre(sTLSource) ;
          }
        }
        else
        {
        	Message Msg ;
          Msg.SetLexique((*i)->getLexique()) ;
          Msg.SetTexteLibre((*i)->getTexteLibre()) ;
          pDest->AjouterChemin(sCheminLex, &Msg) ;
        }
      }
      else // si ce n'est pas un texte libre
      {
      	if (pDest->CheminDansPatpatho(sCheminLex, "/", &iter))
        {
        	NSPatPathoArray ElemSource(pContexte, graphPerson) ;
          NSPatPathoArray ElemDest(pContexte, graphPerson) ;
          ElemSource.ajoutePatho(i, 0, 0) ;
          // on suppose que la feuille trouv�e dans pDest est unique
          iter++ ;
          ElemDest.ajoutePatho(iter, 0, 0) ;

          GlobalDkd Dcode(pContexte, sLang, sCheminLex, &ElemSource) ;
          Dcode.decodeNoeud() ;
          string sLibSource = *(Dcode.sDcodeur()) ;

          GlobalDkd Dcode2(pContexte, sLang, sCheminLex, &ElemDest) ;
          Dcode2.decodeNoeud() ;
          string sLibDest = *(Dcode2.sDcodeur()) ;

          if (sLibSource != sLibDest)
          {
          	string sLibChem ;
            pContexte->getSuperviseur()->getDico()->donneLibelleChemin(sLang, sCheminLex, &sLibChem, "/") ;

            msg = string("Dans ") + sLibChem + string(", voulez-vous remplacer ") +
                                sLibDest + string(" par ") + sLibSource + string(" ?");
            int retVal = ::MessageBox(0, msg.c_str(), "Message Episodus", MB_YESNO) ;

            if (retVal == IDYES)
            	*iter = *i ;
          }
        }
        else
        	pDest->AjouterChemin(sCheminLex, (*i)->getLexique()) ;
      }
    }
  }

	return true ;
}

bool
NSPersonGraphManager::getGraphAdmin(string sID, bool bVerbose, PIDSTYPE iTypePids, NSPatPathoArray* pPatPathoArray)
{
  // Note : En N_TIERS le param�tre sID contient le nss de la personne et non le TreeRoot
  // on appelle ici un service g�n�rique qui retrouve le sous-graphe administratif (ZADMI, DPROS)
  // pour une personne quelconque � partir de son nss.
  const char* serviceName ;

  if ((iTypePids == pidsPatient) || (iTypePids == pidsCorresp) || (iTypePids == pidsUtilisat))
  	serviceName = (NautilusPilot::SERV_READ_GRAPH_ADMIN).c_str() ;
  else
  {
  	erreur("Type pids incorrect dans getGraphAdmin().", standardError, 0) ;
    return false ;
  }

  if (strlen(sID.c_str()) != PAT_NSS_LEN)
  {
  	erreur("Identifiant de personne incorrect dans getGraphAdmin().", standardError, 0) ;
    return false ;
  }

  string ps = string("Calling Pilot for readGraphAdmin") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

  // On passe ici l'identifiant de la personne et les deux liens � remonter
  NSBasicAttributeArray AttrList ;
  AttrList.push_back(new NSBasicAttribute(PERSON, sID)) ;
  AttrList.push_back(new NSBasicAttribute(LINK, pLinkManager->donneString(NSRootLink::personAdminData))) ;
  AttrList.push_back(new NSBasicAttribute(LINK, pLinkManager->donneString(NSRootLink::personHealthProData))) ;

  bool res = pContexte->pPilot->readGraphAdmin(serviceName, pDataGraph, &AttrList) ;

  if (!res)
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "personNotFound") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
  }

  ps = string("Call for readGraphAdmin succeeded") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

  string sRoot = getRootTree() ;
  // on met � jour le compteur d'arbres � cr�er
  pDataGraph->setLastTree() ;

  // constitution de la patpatho contenant tous les arbres du graphe
  if (NULL != pPatPathoArray)
  {
  	NSDataTreeIter iterTree ;
    pPatPathoArray->vider() ;

    if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
    	(*iterTree)->getPatPatho(pPatPathoArray) ;
    else
    {
    	char msg[255] ;
      sprintf(msg, "Person=[%s] : Missing [ZADMI1] in graph.", sID.c_str()) ;
      string sMsg = string(msg) ;
      pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trWarning) ;
      if (bVerbose)
      	erreur(msg, standardError, 0) ;
      return false;
    }

    if (pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
    {
    	NSPatPathoArray PatPathoPDS(pContexte) ;
      (*iterTree)->getPatPatho(&PatPathoPDS) ;
      pPatPathoArray->InserePatPatho(pPatPathoArray->end(), &PatPathoPDS, 0, true) ;
    }
    else if (iTypePids != pidsPatient)
    {
    	char msg[255] ;
      sprintf(msg, "Person=[%s] : Missing [DPROS1] in graph.", sID.c_str()) ;
      string sMsg = string(msg) ;
      pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trWarning) ;
      // Ne pas signaler d'erreur car la personne ici peut �tre un patient
      // ou un utilisateur sans DPROS
      // if (bVerbose)
      //     erreur(msg, standardError, 0) ;
      // return false;
    }
	}

	return true ;
}

bool
NSPersonGraphManager::setGraphAdmin(NSPatPathoArray* pPatPathoArray, PIDSTYPE iTypePids)
{
	if (NULL == pPatPathoArray)
		return false ;

	NSPatPathoArray PatPathoAdmin(pContexte, graphPerson) ;
	NSPatPathoArray PatPathoPDS(pContexte, graphPerson) ;

  partDualPatho(pPatPathoArray, &PatPathoAdmin, &PatPathoPDS) ;

	// cr�ation/mise � jour du graphe
	// A revoir...
	string sNewPids = string(1, INMEMORY_CHAR) + string(PAT_NSS_LEN - 1, '0') ;
	if (getAttributeValue(PERSON) == sNewPids)
	{
  	if (!createGraphAdmin(&PatPathoAdmin, &PatPathoPDS, iTypePids))
      return false ;

    writeGraph(iTypePids, 0) ;
	}
	else                         //Modification
	{
  	if (!modifyGraphAdmin(&PatPathoAdmin, &PatPathoPDS, iTypePids))
      return false ;

    string sCodeDocAdmin, sCodeDocPDS ;
    NSDataTreeIter iterTree ;

    if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
    {
    	sCodeDocAdmin = (*iterTree)->getTreeID() ;
      commitGraphTree(sCodeDocAdmin, iTypePids) ;
    }

    if (pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
    {
    	sCodeDocPDS = (*iterTree)->getTreeID() ;
      commitGraphTree(sCodeDocPDS, iTypePids) ;
    }
  }

  // exportXML() ;

  return true ;
}

bool
NSPersonGraphManager::createPPTAdmin(NSPatPathoArray* pPPTAdmin)
{
	string sRootMeta = getRootTree();

  if (strlen(sRootMeta.c_str()) != OBJECT_ID_LEN)
  {
  	erreur("Impossible de cr�er la fiche administrative pour cette personne.", standardError, 0) ;
    return false ;
  }

  string sAdminMeta = pDataGraph->getNextTreeID() ;
  NSPatPathoArray PptMeta(pContexte) ;
  ChargePatPathoMeta(&PptMeta, "CQ030", "Fiche administrative", sAdminMeta, "ZADMI1", false) ;
  setTree(&PptMeta, "", sAdminMeta) ;

  string sAdminData = pDataGraph->getNextTreeID() ;
  setTree(pPPTAdmin, "", sAdminData) ;

  // lien personAdminData du meta root au meta admin
  if (!pLinkManager->etablirLien(sRootMeta, NSRootLink::personAdminData, sAdminMeta))
  {
  	erreur("Impossible de cr�er le lien [personAdminData] pour cette personne", standardError, 0) ;
    return false ;
  }

  // lien docData du meta admin au data admin
  if (!pLinkManager->etablirLien(sAdminMeta, NSRootLink::docData, sAdminData))
  {
  	erreur("Impossible de cr�er le lien des donn�es administratives pour cette personne", standardError, 0) ;
    return false ;
  }
  
  return true ;
}

bool
NSPersonGraphManager::createPPTPDS(NSPatPathoArray* pPPTPDS)
{
	string sRootMeta = getRootTree();

  if (strlen(sRootMeta.c_str()) != OBJECT_ID_LEN)
  {
  	erreur("Impossible de cr�er la fiche professionnel de sant� pour cette personne.", standardError, 0) ;
    return false ;
  }

  string sPDSMeta = pDataGraph->getNextTreeID() ;
  NSPatPathoArray PptMeta(pContexte) ;
  ChargePatPathoMeta(&PptMeta, "CS030", "Fiche professionnel de sant�", sPDSMeta, "DPROS1", false) ;
  setTree(&PptMeta, "", sPDSMeta) ;

  string sPDSData = pDataGraph->getNextTreeID() ;
  setTree(pPPTPDS, "", sPDSData) ;

  // lien personHealthProData du meta root au meta PDS
  if (!pLinkManager->etablirLien(sRootMeta, NSRootLink::personHealthProData, sPDSMeta))
  {
  	erreur("Impossible de cr�er le lien [personHealthProData] pour cette personne", standardError, 0) ;
    return false ;
  }

  // lien docData du meta PDS au data PDS
  if (!pLinkManager->etablirLien(sPDSMeta, NSRootLink::docData, sPDSData))
  {
  	erreur("Impossible de cr�er le lien des donn�es PDS pour cette personne", standardError, 0) ;
    return false ;
  }

  return true ;
}

bool
NSPersonGraphManager::createGraphAdmin(NSPatPathoArray* pPPTAdmin, NSPatPathoArray* pPPTPDS, PIDSTYPE iTypePids)
{
	pDataGraph->graphReset() ;

  if (!validAttributes(iTypePids))
  {
  	erreur("Personne non identifi�e : impossible de cr�er un graphe pour cette personne", standardError, 0) ;
    return false ;
  }

  string sPids = getAttributeValue(PERSON) ;

  string sRootMeta = sPids + INMEMORY_CHAR + string("00000") ;
  NSPatPathoArray PptMeta(pContexte) ;
  ChargePatPathoMeta(&PptMeta, "CS030", "Noeud racine patient", sRootMeta, "HHUMA3", false) ;
  setTree(&PptMeta, "", sRootMeta) ;

  setRootTree(sRootMeta);

  string sRootData = pDataGraph->getNextTreeID() ;
  NSPatPathoArray PptData(pContexte) ;
  PptData.ajoutePatho("HHUMA3", 0) ;
  setTree(&PptData, "", sRootData) ;

  // lien docData du meta root au data root
  if (!pLinkManager->etablirLien(sRootMeta, NSRootLink::docData, sRootData))
  {
  	erreur("Impossible de cr�er le RootGraph pour cette personne", standardError, 0) ;
    return false ;
  }

  if (pPPTAdmin)
  	createPPTAdmin(pPPTAdmin) ;

  if (pPPTPDS)
  	createPPTPDS(pPPTPDS) ;

  return true ;
}

bool
NSPersonGraphManager::modifyGraphAdmin(NSPatPathoArray* pPPTAdmin, NSPatPathoArray* pPPTPDS, PIDSTYPE /* iTypePids */)
{
	// Le graphe est suppos� ici avoir un graphID
  string sPids = getPersonID();
  if (sPids == "")
  {
  	erreur("Identifiant personne introuvable. Impossible de modifier le graphe.", standardError, 0);
    return false ;
  }

  NSDataTreeIter iterTree ;

  if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
  {
  	string sCodeDocAdmin = (*iterTree)->getTreeID() ;
    pDataGraph->updateNodesTL(pPPTAdmin, sCodeDocAdmin) ;
    setTree(pPPTAdmin, "", sCodeDocAdmin) ;
    // (*iterTree)->setPatPatho(pPatPathoAdmin);
  }
  else if (pPPTAdmin)
  {
  	char msg[255] ;
    strcpy(msg, "Impossible de mettre � jour l'arbre [ZADMI1] dans le graphe administratif.") ;
    erreur(msg, standardError, 0) ;
  }

  if (pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
  {
  	string sCodeDocPDS = (*iterTree)->getTreeID() ;
    pDataGraph->updateNodesTL(pPPTPDS, sCodeDocPDS) ;
    setTree(pPPTPDS, "", sCodeDocPDS) ;
    // (*iterTree)->setPatPatho(pPatPathoPDS);
  }
  else if ((NULL != pPPTPDS) && (false == pPPTPDS->empty()))
  	createPPTPDS(pPPTPDS) ;

	return true ;
}

bool
NSPersonGraphManager::GetTreesWithLink(string sCodeDocOrigine, NSRootLink::NODELINKTYPES typeLink, bool& bNoLink)
{
	NSPatLinkArray LinkArray ;
	NSPatLinkArray LinkDataArray ;

	NSLinkManager* pGraphe = pLinkManager ;

	NSPatLinkIter iterLink, iterLinkData ;
  string sCodeDocMeta ;
  string sCodeDocData ;
  bNoLink = false ;

	// chargement du document : on remonte le lien sp�cifi�
	LinkArray.vider() ;
	pGraphe->TousLesVrais(sCodeDocOrigine, typeLink, &LinkArray) ;

	// cas o� il n'existe pas de m�ta
	if (LinkArray.empty())
	{
  	bNoLink = true ;
    return true ;
	}

	for (iterLink = LinkArray.begin(); iterLink != LinkArray.end(); iterLink++)
	{
  	// on charge d'abord le document m�ta
    sCodeDocMeta = (*iterLink)->getQualifiant() ;
    NSDataTree DataTree(pContexte, sCodeDocMeta, graphPerson) ;
    if (!DataTree.readParadoxTree())
    {
    	char msg[255] ;
      sprintf(msg, "Impossible de charger l'arbre [%s] dans le graphe de la personne.", sCodeDocMeta.c_str()) ;
      erreur(msg, standardError, 0) ;
      return false ;
    }

    pDataGraph->aTrees.push_back(new NSDataTree(DataTree)) ;

    // chargement des datas du document
    LinkDataArray.vider() ;
    pGraphe->TousLesVrais(sCodeDocMeta, NSRootLink::docData, &LinkDataArray) ;

    // lien amorce des datas
    // si un data n'existe pas, on se contente de ne pas le charger
    if (LinkDataArray.empty())
    	continue ;

    for (iterLinkData = LinkDataArray.begin(); iterLinkData != LinkDataArray.end(); iterLinkData++)
    {
    	sCodeDocData = (*iterLinkData)->getQualifiant() ;
      NSDataTree DTree(pContexte, sCodeDocData, graphPerson) ;
      if (!DTree.readParadoxTree())
      {
      	char msg[255] ;
        sprintf(msg, "Impossible de charger l'arbre [%s] dans le graphe de la personne.", sCodeDocData.c_str()) ;
        erreur(msg, standardError, 0) ;
        return false ;
      }

      pDataGraph->aTrees.push_back(new NSDataTree(DTree)) ;
    }
	}

	return true ;
}

void
NSPersonGraphManager::setInfoPids(NSBasicAttributeArray *pAttr)
{
  pAttrArray->vider() ;

	if (pAttr)
		*pAttrArray = *pAttr ;
}

void
NSPersonGraphManager::changeInfoPids()
{
	NSBasicAttributeArray Attr ;

	Attr.push_back(new NSBasicAttribute(PERSON , getAttributeValue(PERSON))) ;
	Attr.push_back(new NSBasicAttribute(OPERATOR , getAttributeValue(OPERATOR))) ;
	Attr.push_back(new NSBasicAttribute(CONSOLE , getAttributeValue(CONSOLE))) ;
	Attr.push_back(new NSBasicAttribute(INSTANCE , getAttributeValue(INSTANCE))) ;

	pAttrArray->vider() ;

	*pAttrArray = Attr ;

	parseMainAttributes() ;
}

bool
NSPersonGraphManager::validAttributes(PIDSTYPE iTypePids)
{
	bool bValid = false;

	switch (iTypePids)
	{
  	case pidsUtilisat :

    	if ((getAttributeValue(LOGIN) != "") &&
          (getAttributeValue(PASSWORD) != "") &&
          (getAttributeValue(PERSON) != "") &&
          (getAttributeValue(OPERATOR) != "") &&
          (getAttributeValue(USERTYPE) != "") &&
          (getAttributeValue(PASSWDTYPE) != "") &&
          // (getAttributeValue(FIRST_NAME) != "") &&
          (getAttributeValue(LAST_NAME) != ""))
      	bValid = true ;

      break ;

    case pidsPatient:
    case pidsCorresp :

    	if ((getAttributeValue(OPERATOR) != "") &&
          (getAttributeValue(PERSON) != "") &&
          (getAttributeValue(LAST_NAME) != ""))
      	bValid = true ;

      break ;
  }

	return bValid ;
}

string
NSPersonGraphManager::getAttributeValue(string sBalise)
{
	return pAttrArray->getAttributeValue(sBalise) ;
}

void
NSPersonGraphManager::setAttributeValue(string sBalise, string sValue)
{
	pAttrArray->setAttributeValue(sBalise, sValue) ;
}

bool
NSPersonGraphManager::trouveNomCorresp(string& sInfo)
{
	NSPatPathoArray PatPathoCor(pContexte) ;

	NSDataTreeIter iterTree ;
	PatPathoCor.vider() ;

	if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
  	(*iterTree)->getPatPatho(&PatPathoCor) ;
  else
  {
  	char msg[255] ;
    strcpy(msg, "Impossible de charger l'arbre [ZADMI1] dans le graphe administratif.") ;
    erreur(msg, standardError, 0) ;
    return false ;
	}

	string sNom, sPrenom, sCode, sSexe, sNaissance, sCivilite ;

	ChargeDonneesAdmin(&PatPathoCor, sNom, sPrenom, sCode, sSexe, sNaissance, sCivilite) ;
	sInfo = sNom + string(" ") + sPrenom ;

	return true ;
}

bool
NSPersonGraphManager::trouveCivilite(string& sInfo, string sLang)
{
  NSPatPathoArray PatPathoArray(pContexte) ;
  NSDataTreeIter iterTree ;

  if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
    (*iterTree)->getPatPatho(&PatPathoArray) ;
  else
  {
    char msg[255] ;
    strcpy(msg, "Impossible de charger l'arbre [ZADMI1] dans le graphe administratif.") ;
    erreur(msg, standardError, 0)  ;
    return false ;
  }

  string sNom, sPrenom, sCode, sSexe, sNaissance, sCivilite ;
  string sNomLong ;

  if ((sLang == "") && (pContexte->getUtilisateur()))
    sLang = pContexte->getUtilisateur()->donneLang() ;

  int age ;
  bool bEnfant = false ;
  char szDateJour[10] ;

  ChargeDonneesAdmin(&PatPathoArray, sNom, sPrenom, sCode, sSexe, sNaissance, sCivilite) ;

  // Si la personne est un professionnel de sant�
  if (pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
  {
    PatPathoArray.vider() ;
    (*iterTree)->getPatPatho(&PatPathoArray) ;
    string sMetier, sSpec, sActiveJob, sOrient, sCivil, sTitre, sVille ;
    ChargeDonneesPDS(&PatPathoArray, sMetier, sSpec, sActiveJob, sOrient, sCivil, sTitre, sVille) ;

    if (sCivil != "")
        sCivilite = sCivil;

    if (sTitre != "")
    {
      // pContexte->getDico()->donneLibelle(sLang, &sCodeTitre, &sTitre) ;
      sTitre[0] = pseumaj(sTitre[0]) ;
      sInfo = sTitre + string(" ") + sPrenom + string(" ") + sNom ;
      return true ;
    }
  }

  if (sCivilite != "")
  {
    sCivilite[0] = pseumaj(sCivilite[0]) ;
    sInfo = sCivilite + string(" ") + sPrenom + string(" ") + sNom ;
    return true ;
  }

  // Calcul du nom long
  if ((sNaissance != "") && (sNaissance != string("00000000")))
  {
    char szNaissance[PAT_NAISSANCE_LEN + 1] ;
    strcpy(szNaissance, sNaissance.c_str()) ;
    donne_date_duJour(szDateJour) ;
    age = donne_age(szDateJour, szNaissance) ;

    if (age <= 14)
    	bEnfant = true ;
  }

  if ((sLang == "") && (pContexte->getUtilisateur()))
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  if (sLang == "fr")
  {
    if (bEnfant)
    	sNomLong = string("Enfant ") ;
    else
    {
      if (sSexe[0] == '2')
      {
        if (age < 18)
        	sNomLong = string("Mlle ") ;
        else
        	sNomLong = string("Mme ") ;
      }
      else
      	sNomLong = string("M. ") ;
    }
  }

  if (sLang == "en")
  {
    if (bEnfant)
    	sNomLong = string("Child ") ;
    else
    {
      if (sSexe[0] == '2')
      {
        if (age < 18)
        	sNomLong = string("Miss ") ;
        else
        	sNomLong = string("Mrs ") ;
      }
      else
      	sNomLong = string("M. ") ;
    }
  }

	sNomLong += sPrenom ;
	sNomLong += string(" ") ;
	sNomLong += sNom ;

  sInfo = sNomLong ;

  return true ;
}

bool
NSPersonGraphManager::trouveObjectAdrPrinc(PIDSTYPE iTypePids, string& sObject, string& sChez)
{
	NSPatPathoArray PatPathoArray(pContexte) ;
	NSDataTreeIter iterTree ;

	if (iTypePids == pidsPatient)
	{
		if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
    	(*iterTree)->getPatPatho(&PatPathoArray) ;
		else
		{
    	string sErrorText = pContexte->getSuperviseur()->getText("personErrors", "cannotFindAdminTreeInsideAdminGraph") ;
      sErrorText += string(" (person = ") + getPersonID() + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      erreur(sErrorText.c_str(), standardError, 0) ;
      return false ;
    }
  }
	else if (iTypePids == pidsCorresp)
	{
  	if (pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
    	(*iterTree)->getPatPatho(&PatPathoArray) ;
    else
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("personErrors", "cannotFindProTreeInsideAdminGraph") ;
      sErrorText += string(" (person = ") + getPersonID() + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    	erreur(sErrorText.c_str(), standardError, 0) ;
      return false ;
    }
  }
  else // cas utilisateur
		return false ;

	if (PatPathoArray.empty())
		return false ;

	PatPathoIter    iter ;
	string          sElemLex, sSens, sType;
	sObject = "" ;
	sChez   = "" ;

	// Chaque patpatho est une adresse de racine fille d'un �l�ment LADRE
	// Les chapitres recherch�s commencent en colonne 0
	iter = PatPathoArray.begin() ;
	int iColBase = (*iter)->getColonne() ;

	bool bPrincipale    = false ;
	bool bObject        = false ;
	bool bObjectDefault = false ;
	bool bChez          = true ;

	iter++ ;
	while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase))
	{
		sSens = (*iter)->getLexiqueSens(pContexte) ;

		// Chapitre "lieu" / place chapter
    if (((iTypePids == pidsPatient) && (sSens == string("LCOOR"))) ||
        ((iTypePids == pidsCorresp) && (sSens == string("ULIEX"))))
    {
    	iter++ ;
      while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un objet
        sSens = (*iter)->getLexiqueSens(pContexte) ;

        if (sSens == string("LCADR"))
        {
        	iter++ ;
          while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 2))
          {
          	// on cherche ici un objet
            sSens = (*iter)->getLexiqueSens(pContexte) ;

            if (sSens == string("LADRE"))
            {
            	int iColAdr = (*iter)->getColonne() ;

              iter++ ;
              while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColAdr))
              {
              	sSens = (*iter)->getLexiqueSens(pContexte) ;

                // Chapitre "type" / Type chapter
                if (sSens == string("LTYPA"))
                {
                	iter++ ;
                  while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColAdr + 1))
                  {
                  	// on cherche ici un code lexique
                    sType = (*iter)->getLexiqueSens(pContexte) ;

                    if (((iTypePids == pidsPatient) && (sType == string("URESI"))) ||
                        ((iTypePids == pidsCorresp) && (sType == string("LAZRE"))))
                    {
                    	bPrincipale = true ;
                      bChez = true ;
                    }

                    iter++ ;
                  }
                }
                else if (sSens == string("LQUIO"))
                {
                	iter++ ;
                  while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColAdr + 1))
                  {
                  	// on cherche ici un texte libre
                    sElemLex = (*iter)->getLexique() ;
                    if (string(sElemLex, 0, 3) == string("�CL"))
                    {
                    	if (bChez)
                      {
                      	sChez = (*iter)->getTexteLibre() ;
                        sChez = string("Chez ") + sChez ;
                      }
                    }
                    iter++ ;
                  }
                }
                // Chapitre "lieu" / place chapter
                else if (sSens == string("LLIEU"))
                {
                	iter++ ;
                  while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColAdr + 1))
                  {
                  	// on cherche ici un objet
                    sElemLex = (*iter)->getLexique() ;
                    if (sElemLex == string("�OBJE1"))
                    {
                    	if ((bPrincipale) || (!bObjectDefault))
                      {
                      	sObject = (*iter)->getComplement() ;
                        if (sObject != "")
                        {
                        	if (bPrincipale)
                          	bObject = true ;
                          bObjectDefault = true ;
                          bChez = false ;
                        }
                      }
                    }
                    iter++ ;
                  }
                }
                else
                	iter++ ;
              }

              if (bObject)
              	return true ;
            }
            else
            	iter++ ;
          }
        }
        else
        	iter++ ;
      }
    }
    else
    	iter++ ;
  }

	// En principe, on n'a pas trouv� ici d'objet "adresse principale"
	// On renvoie la premi�re trouv�e s'il en existe une.
	if (bObjectDefault)
		return true ;

	return false ;
}

string
NSPersonGraphManager::trouveLibLongForInGraphAdr(PIDSTYPE iTypePids)
{
	NSPatPathoArray PatPathoArray(pContexte) ;
	NSDataTreeIter iterTree ;

	if (iTypePids == pidsPatient)
	{
		if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
    	(*iterTree)->getPatPatho(&PatPathoArray) ;
		else
		{
    	string sErrorText = pContexte->getSuperviseur()->getText("personErrors", "cannotFindAdminTreeInsideAdminGraph") ;
      sErrorText += string(" (person = ") + getPersonID() + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      erreur(sErrorText.c_str(), standardError, 0) ;
      return string("") ;
    }
  }
	else if (iTypePids == pidsCorresp)
	{
  	if (pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
    	(*iterTree)->getPatPatho(&PatPathoArray) ;
    else
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("personErrors", "cannotFindProTreeInsideAdminGraph") ;
      sErrorText += string(" (person = ") + getPersonID() + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    	erreur(sErrorText.c_str(), standardError, 0) ;

      string sQuestionText = pContexte->getSuperviseur()->getText("personErrors", "doYouWantToUsePersonalInformation") ;
      int retVal = ::MessageBox(0, sQuestionText.c_str(), "", MB_YESNO) ;
			if (IDYES != retVal)
      	return string("") ;

      if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
    		(*iterTree)->getPatPatho(&PatPathoArray) ;
			else
			{
    		string sErrorText = pContexte->getSuperviseur()->getText("personErrors", "cannotFindAdminTreeInsideAdminGraph") ;
      	sErrorText += string(" (person = ") + getPersonID() + string(")") ;
      	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      	erreur(sErrorText.c_str(), standardError, 0) ;
      	return string("") ;
    	}
    }
  }
  else // cas utilisateur
		return string("") ;

	if (PatPathoArray.empty())
		return string("") ;

	PatPathoIter iter ;

	string sAdressPath = string("") ;
  if (iTypePids == pidsPatient)
  	sAdressPath = string("LCOOR1/LADRE1") ;
  else if (iTypePids == pidsCorresp)
  	sAdressPath = string("ULIEX1/LADRE1") ;

	bool bAdrFound = PatPathoArray.CheminDansPatpatho(sAdressPath, string(1, cheminSeparationMARK), &iter) ;
  if ((false == bAdrFound) || (NULL == iter) || (PatPathoArray.end() == iter))
		return string("") ;

	string          sElemLex, sSens, sType;

  string sLine1   = string("") ;
  string sLine2   = string("") ;
  string sLine3   = string("") ;
  string sZipCode = string("") ;
  string sCity    = string("") ;
  string sCountry = string("") ;

	// Chaque patpatho est une adresse de racine fille d'un �l�ment LADRE
	// Les chapitres recherch�s commencent en colonne 0
	int iColBase = (*iter)->getColonne() ;
  iter++ ;

  while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase))
	{
		sSens = (*iter)->getLexiqueSens(pContexte) ;

		// First line
    if (sSens == string("LADL1"))
    {
    	iter++ ;
      while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (string(sElemLex, 0, 3) == string("�CL"))
        	sLine1 = (*iter)->getTexteLibre() ;
        iter++ ;
      }
    }
    // Second line
    else if (sSens == string("LADL2"))
    {
    	iter++ ;
      while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (string(sElemLex, 0, 3) == string("�CL"))
        	sLine2 = (*iter)->getTexteLibre() ;
        iter++ ;
      }
    }
    // Second line
    else if (sSens == string("LADL3"))
    {
    	iter++ ;
      while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (string(sElemLex, 0, 3) == string("�CL"))
        	sLine3 = (*iter)->getTexteLibre() ;
        iter++ ;
      }
    }
    // City
    else if (sSens == string("LVILL"))
    {
    	iter++ ;
      while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 1))
      {
				sSens = (*iter)->getLexiqueSens(pContexte) ;

      	// Zip code
    		if (sSens == string("LZIP0"))
    		{
    			iter++ ;
      		while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 2))
      		{
      			// on cherche ici un texte libre
        		sElemLex = (*iter)->getLexique() ;
        		if (string(sElemLex, 0, 3) == string("�CL"))
        			sZipCode = (*iter)->getTexteLibre() ;
        		iter++ ;
      		}
    		}
        // City name
    		else if (sSens == string("LCOMU"))
    		{
    			iter++ ;
      		while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 2))
      		{
      			// on cherche ici un texte libre
        		sElemLex = (*iter)->getLexique() ;
        		if (string(sElemLex, 0, 3) == string("�CL"))
        			sCity = (*iter)->getTexteLibre() ;
        		iter++ ;
      		}
    		}
        // Country
    		else if (sSens == string("LPAYS"))
    		{
    			iter++ ;
      		while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 2))
      		{
      			// on cherche ici un texte libre
        		sElemLex = (*iter)->getLexique() ;
        		if (string(sElemLex, 0, 3) == string("�CL"))
        			sCountry = (*iter)->getTexteLibre() ;
        		iter++ ;
      		}
    		}
        else
        	iter++ ;
      }
    }
    else
    	iter++ ;
  }

  string sAdress = sLine1 ;
  if (sLine2 != string(""))
  	sAdress += string("\r\n") + sLine2 ;
  if (sLine3 != string(""))
  	sAdress += string("\r\n") + sLine3 ;
	if (sCity != string(""))
  {
  	sAdress += string("\r\n") ;
  	if (sZipCode != string(""))
    	sAdress += sZipCode + string(" ") ;
    sAdress += sCity ;
  }
  if (sCountry != string(""))
  	sAdress += string("\r\n") + sCountry ;

	return sAdress ;
}

bool
NSPersonGraphManager::trouveEMail(PIDSTYPE iTypePids, string& sInfo)
{
	NSPatPathoArray PatPathoArray(pContexte) ;
	NSDataTreeIter iterTree ;

	if (iTypePids == pidsPatient)
	{
  	if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
    	(*iterTree)->getPatPatho(&PatPathoArray) ;
    else
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("personErrors", "cannotFindAdminTreeInsideAdminGraph") ;
      sErrorText += string(" (person = ") + getPersonID() + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    	erreur(sErrorText.c_str(), standardError, 0) ;
      return false ;
    }
  }
  else
	{
  	if (pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
    	(*iterTree)->getPatPatho(&PatPathoArray);
    else
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("personErrors", "cannotFindProTreeInsideAdminGraph") ;
      sErrorText += string(" (person = ") + getPersonID() + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    	erreur(sErrorText.c_str(), standardError, 0) ;
      return false ;
    }
  }

	string sTelp, sEmail;

	ChargeContacts(&PatPathoArray, iTypePids, sTelp, sEmail) ;

	sInfo = sEmail ;

	return true ;
}

bool
NSPersonGraphManager::exportXML(string sFichier)
{
  ofstream    outFile ;
  string      sOut ;

  string sFichierOut = pContexte->PathName("EHTM") + sFichier ;
  outFile.open(sFichierOut.c_str()) ;
  if (!outFile)
  {
    erreur("Erreur d'ouverture en �criture du fichier graphtest.xml", standardError, 0) ;
    outFile.close() ;
  	return false ;
  }

  sOut = pDataGraph->genereXML() ;

  for (size_t i = 0; i < strlen(sOut.c_str()); i++)
  	outFile.put(sOut[i]) ;

  outFile.close() ;
  return true ;
}

bool
NSPersonGraphManager::createPerson(NSPatPathoArray* /* pPatPathoArray */, int /* iTypePerson */)
{
	return false ;
}

bool
NSPersonGraphManager::createKernelGraph(NSPatPathoArray* /* pPatPathoAdmin */)
{
	return false ;
}


// Ici on renvoie le code d'erreur suivant :
// 0 : OK, pas d'erreur
// 1 : arbre admin non trouv�
// 2 : arbre PDS non trouv�
// 3 : aucun des arbres trouv�
int
NSPersonGraphManager::parseMainAttributes()
{
  int iRes = 0 ;
  NSDataTreeIter iterTree ;

	string sLang = "" ;
  if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
  {
  	NSPatPathoArray PatPathoAdmin(pContexte) ;
    (*iterTree)->getPatPatho(&PatPathoAdmin) ;
    if (false == setAdminAttributes(&PatPathoAdmin, attribsInit))
    	iRes = 1 ;
  }
  else
    iRes = 1 ;

  if (pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
  {
    NSPatPathoArray PatPathoPDS(pContexte) ;
    (*iterTree)->getPatPatho(&PatPathoPDS) ;
    if (false == setPDSAttributes(&PatPathoPDS, attribsInit))
    	iRes += 2 ;
  }
  else
    iRes += 2 ;

  return iRes ;
}

bool
NSPersonGraphManager::setAdminAttributes(NSPatPathoArray* pPatPathoAdmin, ATTRIB_UPDATER iSettingType)
{
	if ((NULL == pPatPathoAdmin) || pPatPathoAdmin->empty())
		return false ;
	if ((*(pPatPathoAdmin->begin()))->getLexiqueSens(pContexte) != "ZADMI")
  	return false ;

	string sNom, sPrenom, sCode, sSexe, sNaissance, sCivilite ;
	ChargeDonneesAdmin(pPatPathoAdmin, sNom, sPrenom, sCode, sSexe, sNaissance, sCivilite) ;
	setAdminAttrArray(iSettingType, sNom, sPrenom, sSexe, sNaissance) ;

  return true ;
}

bool
NSPersonGraphManager::setPDSAttributes(NSPatPathoArray* pPatPathoPDS, ATTRIB_UPDATER iSettingType)
{
	if ((NULL == pPatPathoPDS) || pPatPathoPDS->empty())
		return false ;
	if ((*(pPatPathoPDS->begin()))->getLexiqueSens(pContexte) != "DPROS")
  	return false ;

	string sMetier, sSpecialite, sActiveJob, sOrientation, sCivil, sCodeTitre, sTitre, sVille ;
	ChargeDonneesPDS(pPatPathoPDS, sMetier, sSpecialite, sActiveJob, sOrientation, sCivil, sTitre, sVille) ;
	setPDSAttrArray(iSettingType, sMetier, sSpecialite, sActiveJob, sOrientation, sTitre, sVille) ;

	return true ;
}

bool
NSPersonGraphManager::setBothAttributes(NSPatPathoArray* pPatPathoDual, ATTRIB_UPDATER iSettingType)
{
	if ((NULL == pPatPathoDual) || pPatPathoDual->empty())
		return false ;

	NSPatPathoArray PatPathoAdmin(pContexte, graphPerson) ;
	NSPatPathoArray PatPathoPDS(pContexte, graphPerson) ;

	partDualPatho(pPatPathoDual, &PatPathoAdmin, &PatPathoPDS) ;

	bool bAdminParse = setAdminAttributes(&PatPathoAdmin, iSettingType) ;
  bool bPDSParse = setPDSAttributes(&PatPathoPDS, iSettingType) ;

  return (bAdminParse && bPDSParse) ;
}

void
NSPersonGraphManager::ChargePatPathoMeta(NSPatPathoArray* pPatPathoMeta, string typeDoc, string nomDoc,
                                            string /* codeDoc */, string sTypeContenu, bool bVisible)
{
	if (NULL == pPatPathoMeta)
		return ;

	NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

	// noeud racine
	Message Msg ;

  Msg.SetInteret("5") ;
	if (bVisible)
		Msg.SetVisible("1") ;
  else
  	Msg.SetVisible("0") ;
	pPatPathoMeta->ajoutePatho("ZDOCU1", &Msg, 0) ;

	// Intitul� : nom du document
	pPatPathoMeta->ajoutePatho("0INTI1", 1) ;
	Msg.Reset() ;
	Msg.SetTexteLibre(nomDoc.c_str()) ;
	pPatPathoMeta->ajoutePatho("�?????", &Msg, 2) ;

	// cr�ateur : op�rateur
	pPatPathoMeta->ajoutePatho("DOPER1", 1) ;
	Msg.Reset() ;
	Msg.SetComplement(pContexte->getUtilisateurID()) ;
	pPatPathoMeta->ajoutePatho("�SPID1", &Msg, 2) ;

	// Type : champ complement
  Msg.Reset() ;
	Msg.SetComplement(typeDoc.c_str()) ;
	pPatPathoMeta->ajoutePatho("0TYPE1", &Msg, 1) ;

	// Date de r�daction
	pPatPathoMeta->ajoutePatho("KREDA1", 1) ;
  Msg.Reset() ;
	Msg.SetUnit("2DA021") ;
	Msg.SetComplement(tpsNow.donneDateHeure()) ;
	pPatPathoMeta->ajoutePatho("�T0;19", &Msg, 2) ;

	if (sTypeContenu != "")
	{
		pPatPathoMeta->ajoutePatho("0TYPC1", 1) ;
		pPatPathoMeta->ajoutePatho(sTypeContenu, 2) ;
	}
}


void
NSPersonGraphManager::ChargeDonneesAdmin(NSPatPathoArray* pPatPathoArray, string& sNom, string& sPrenom,
                                            string& sCode, string& sSexe, string& sNaissance, string& sCivilite,
                                            string sLang)
{
  if ((NULL == pPatPathoArray) || (pPatPathoArray->empty()))
    return ;

  // On part du principe que les donn�es qui nous int�ressent sont dans un
  // sous chapitre LIDET (identit�)
  // On pourrait imaginer prendre les premi�res valeurs "nom", "pr�nom"...
  // rencontr�es
  //
  // We suppose that the values we need are in a sub-chapter LIDET (identity)
  // We could imagine we take the first encoutered "1st name", "2nd name"... values

  string       sElemLex, sSens, sType ;
  if ((sLang == "") && (pContexte->getUtilisateur()))
    sLang  = pContexte->getUtilisateur()->donneLang() ;

  sNom				= "" ;
  sPrenom			= "" ;
  sCode				= "" ;
  sSexe				= "" ;
  sNaissance	= "" ;
  sCivilite		= "" ;

  string sTemp	= ""  ;

  PatPathoIter iter = pPatPathoArray->begin() ;
  int iColBase = (*iter)->getColonne() ;
  iter++ ;

  while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase))
  {
    sSens = (*iter)->getLexiqueSens(pContexte) ;

    // Chapitre "identit�" / Identity chapter
    if (string("LIDET") == sSens)
    {
      int iColIdentity = (*iter)->getColonne() ;
      iter++ ;

      while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity))
      {
        sSens = (*iter)->getLexiqueSens(pContexte) ;

        // Nom du patient
        // Patient's name
        if ((string("LNOM0") == sSens) && (string("") == sNom))
        {
          iter++ ;
          while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColIdentity + 1))
          {
            // on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 3) == string("�CL"))
              sNom = (*iter)->getTexteLibre() ;

            iter++ ;
          }
      	}
        // Pr�nom du patient
        // Patient's second name
        else if ((string("LNOM2") == sSens) && (string("") == sPrenom))
        {
          iter++ ;
          while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity + 1))
          {
            // on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 3) == string("�CL"))
              sPrenom = (*iter)->getTexteLibre() ;

            iter++ ;
          }
        }
        // Code patient
        // Patient's code
        else if ((string("LCOD0") == sSens) && (string("") == sCode))
        {
          iter++ ;
          while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity + 1))
          {
            // on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 3) == string("�CL"))
              sCode = (*iter)->getTexteLibre() ;

            iter++ ;
          }
        }
        // Sexe du patient et civilit�
        // Patient's sex and civility
        else if (string("LSEXE") == sSens)
        {
          iter++ ;
          while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity + 1))
          {
            // on cherche ici un code lexique
            sTemp = (*iter)->getLexiqueSens(pContexte) ;

            if      (string("HMASC") == sTemp)
              sSexe = "1" ;
            else if (string("HFEMI") == sTemp)
              sSexe = "2" ;
            iter++ ;

            while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity + 2))
            {
              sSens = (*iter)->getLexiqueSens(pContexte) ;

              // Civilit�
              if (string("HCIVO") == sSens)
              {
                iter++ ;
                while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity + 3))
                {
                  // on cherche ici un code lexique pour un libelle
                  string sCodeLex = (*iter)->getLexique() ;
                  pContexte->getDico()->donneLibelle(sLang, &sCodeLex, &sCivilite) ;
                  iter++ ;
                }
              }
              else
              	iter++ ;
            }
          }
        }
        // Date de naissance
        // Birthdate
        else if (string("KNAIS") == sSens)
        {
          iter++ ;
          while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity + 1))
          {
            string sUnite  = (*iter)->getUnitSens(pContexte) ;
            string sFormat = (*iter)->getLexiqueSens(pContexte) ;
            string sValeur = (*iter)->getComplement() ;

            if ((string("2DA01") == sUnite) || (string("2DA02") == sUnite))
              sNaissance = sValeur ;

            iter++ ;
          }
        }
        else
          iter++ ;
      }
    }
    else
    	iter++ ;
  }
}

void
NSPersonGraphManager::setAdminAttrArray(ATTRIB_UPDATER iSettingType, string& sNom, string& sPrenom, string& sSexe, string& sNaissance)
{
	switch(iSettingType)
	{
		case attribsInit :
			pAttrArray->push_back(new NSBasicAttribute(LAST_NAME,  sNom)) ;
			pAttrArray->push_back(new NSBasicAttribute(FIRST_NAME, sPrenom)) ;
			pAttrArray->push_back(new NSBasicAttribute(SEX,        sSexe)) ;
			pAttrArray->push_back(new NSBasicAttribute(BIRTHDATE,  sNaissance)) ;
      break ;
    case attribsUpdate :
    	pAttrArray->setAttributeValue(LAST_NAME,  sNom) ;
			pAttrArray->setAttributeValue(FIRST_NAME, sPrenom) ;
			pAttrArray->setAttributeValue(SEX,        sSexe) ;
			pAttrArray->setAttributeValue(BIRTHDATE,  sNaissance) ;
      break ;
    case attribsChange :
    	pAttrArray->changeAttributeValue(LAST_NAME,  sNom) ;
			pAttrArray->changeAttributeValue(FIRST_NAME, sPrenom) ;
			pAttrArray->changeAttributeValue(SEX,        sSexe) ;
			pAttrArray->changeAttributeValue(BIRTHDATE,  sNaissance) ;
      break ;
	}
}

void
NSPersonGraphManager::ChargeDonneesPDS(NSPatPathoArray* pPatPathoArray, string& sMetier, string& sSpec, string& sActiveJob,
                                        string& sOrient, string& sCivilite, string& sTitre, string& sVille, string sLang)
{
	if ((NULL == pPatPathoArray) || (pPatPathoArray->empty()))
		return ;
	//
	// On part du principe que les donn�es qui nous int�ressent sont dans un
	// sous chapitre DPROS (professionnel de sant�)
	// On pourrait imaginer prendre les premi�res valeurs "m�tier", "sp�cialit�"...
	// rencontr�es
	//
	// We suppose that the values we need are in a sub-chapter DPROS (health professional)
	// We could imagine we take the first encoutered "job", "speciality"... values
	//
	PatPathoIter iter ;
	string       sElemLex, sSens, sType ;
	if ((sLang == "") && (pContexte->getUtilisateur()))
		sLang  = pContexte->getUtilisateur()->donneLang() ;

	sMetier    = string("") ;
	sSpec      = string("") ;
  sActiveJob = string("") ;
	sOrient    = string("") ;
	sCivilite  = string("") ;
	sTitre     = string("") ;
  sVille     = string("") ;

	string sCodeLex, sTemp = "" ;

	iter = pPatPathoArray->begin() ;
	int iColBase = (*iter)->getColonne() ;

	while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() >= iColBase))
	{
		sElemLex = (*iter)->getLexique() ;
		pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

		// Chapitre "professionnel de sant�" / Health professional chapter
		if (sSens == string("DPROS"))
		{
			int iColPros = (*iter)->getColonne() ;
			iter++ ;

			while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColPros))
			{
				sSens = (*iter)->getLexiqueSens(pContexte) ;

				if (sSens == string("LCOMP"))
				{
					int iColCompetences = (*iter)->getColonne() ;
					iter++ ;

					while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColCompetences))
					{
						sSens = (*iter)->getLexiqueSens(pContexte) ;

						// M�tier
						if ((sSens == string("LMETI")) && (sMetier == ""))
						{
							// on cherche ici un code lexique
							iter++;
							if (string((*iter)->getLexique(), 0, 2) == "�C")
							{
								iter++ ;
								while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColCompetences+2))
                {
                	sMetier = (*iter)->getLexique() ;
                  iter++ ;
                }
							}
							else
              {
              	sMetier = (*iter)->getLexique() ;
                iter++;
              }
						}
						// Sp�cialit�
						else if ((sSens == string("LSPEC")) && (sSpec == ""))
						{
							// on cherche ici un edit lexique (ayant comme fils un code lexique)
							iter++;
							if (string((*iter)->getLexique(), 0, 2) == "�C")
							{
								iter++ ;
								while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColCompetences+2))
                {
                	sSpec = (*iter)->getLexique() ;
                  iter++ ;
                }
							}
							else
              {
              	sSpec = (*iter)->getLexique() ;
                iter++ ;
              }
						}
            // Sp�cialit�
						else if ((sSens == string("LPROF")) && (sActiveJob == ""))
						{
							// on cherche ici un edit lexique (ayant comme fils un code lexique)
							iter++;
							if (string((*iter)->getLexique(), 0, 2) == "�C")
							{
								iter++ ;
								while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColCompetences+2))
                {
                	sActiveJob = (*iter)->getLexique() ;
                  iter++ ;
                }
							}
							else
              {
              	sActiveJob = (*iter)->getLexique() ;
                iter++ ;
              }
						}
						// Orientation
						else if ((sSens == string("LORIE")) && (sOrient == ""))
						{
							// on cherche ici un edit lexique (ayant comme fils un code lexique)
							iter++;
							if (string((*iter)->getLexique(), 0, 2) == "�C")
							{
								iter++ ;
								while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColCompetences+2))
                {
                	sOrient = (*iter)->getLexique() ;
                  iter++ ;
                }
							}
							else
              {
								sOrient = (*iter)->getLexique() ;
								iter++ ;
							}
						}
						else
							iter++ ;
					}
				}
                // Civilite
				else if (sSens == string("HCIVO"))
				{
					iter++;
					while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColPros+1))
					{
						// on cherche ici un code lexique pour un libelle
						sCodeLex = (*iter)->getLexique() ;
						pContexte->getDico()->donneLibelle(sLang, &sCodeLex, &sCivilite) ;

						iter++;
					}
				}
				// Titre
				else if (sSens == string("LTITR"))
				{
					iter++;
					while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColPros+1))
					{
						// on cherche ici un code lexique pour un libelle
						sCodeLex = (*iter)->getLexique() ;
						pContexte->getDico()->donneLibelle(sLang, &sCodeLex, &sTitre) ;

						iter++ ;
					}
				}
        else if (sSens == string("ULIEX"))
				{
					int iColLieux = (*iter)->getColonne() ;
					iter++ ;

					while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColLieux))
					{
						sSens = (*iter)->getLexiqueSens(pContexte) ;

						// Adresse
						if (sSens == string("LADRE"))
						{
            	int iColAdr = (*iter)->getColonne() ;
							iter++ ;
              while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColAdr))
							{
								sSens = (*iter)->getLexiqueSens(pContexte) ;

								// Adresse
								if (sSens == string("LVILL"))
								{
                	int iColVille = (*iter)->getColonne() ;
									iter++ ;
              		while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColVille))
									{
										sSens = (*iter)->getLexiqueSens(pContexte) ;

										// Adresse
										if (sSens == string("LCOMU"))
                    {
                    	iter++ ;
          						while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColVille + 1))
          						{
            						// on cherche ici un texte libre
            						sElemLex = (*iter)->getLexique() ;
            						if (string(sElemLex, 0, 3) == string("�CL"))
              						sVille = (*iter)->getTexteLibre() ;

            						iter++ ;
          						}
                    }
                    else
            					iter++ ;
                  }
                }
                else
            			iter++ ;
              }
            }
            else
            	iter++ ;
          }
        }
				else
					iter++ ;
			}
		}
		else
			iter++ ;
	}
}

void
NSPersonGraphManager::setPDSAttrArray(ATTRIB_UPDATER iSettingType, string& sMetier, string& sSpec, string& sActiveJob, string& sOrient, string& sTitre, string& sVille)
{
  string sCodeSens ;

	switch(iSettingType)
	{
		case attribsInit :
      pContexte->getDico()->donneCodeSens(&sMetier, &sCodeSens) ;
			pAttrArray->push_back(new NSBasicAttribute(PROFESSION,  sCodeSens)) ;
      pContexte->getDico()->donneCodeSens(&sSpec, &sCodeSens) ;
			pAttrArray->push_back(new NSBasicAttribute(SPECIALITY,  sCodeSens)) ;
      pContexte->getDico()->donneCodeSens(&sOrient, &sCodeSens) ;
			pAttrArray->push_back(new NSBasicAttribute(ORIENTATION, sCodeSens)) ;
			pAttrArray->push_back(new NSBasicAttribute(TITLE,       sTitre)) ;
      pAttrArray->push_back(new NSBasicAttribute(CITY_PRO,    sVille)) ;
      pContexte->getDico()->donneCodeSens(&sActiveJob, &sCodeSens) ;
      pAttrArray->push_back(new NSBasicAttribute(ACTIVE_JOB,  sCodeSens)) ;
      break ;

    case attribsUpdate :
      pContexte->getDico()->donneCodeSens(&sMetier, &sCodeSens) ;
    	pAttrArray->setAttributeValue(PROFESSION,  sCodeSens) ;
      pContexte->getDico()->donneCodeSens(&sSpec, &sCodeSens) ;
			pAttrArray->setAttributeValue(SPECIALITY,  sCodeSens) ;
      pContexte->getDico()->donneCodeSens(&sOrient, &sCodeSens) ;
			pAttrArray->setAttributeValue(ORIENTATION, sCodeSens) ;
			pAttrArray->setAttributeValue(TITLE,       sTitre) ;
      pAttrArray->setAttributeValue(CITY_PRO,    sVille) ;
      pContexte->getDico()->donneCodeSens(&sActiveJob, &sCodeSens) ;
      pAttrArray->setAttributeValue(ACTIVE_JOB,  sCodeSens) ;
      break ;

    case attribsChange :
      pContexte->getDico()->donneCodeSens(&sMetier, &sCodeSens) ;
    	pAttrArray->changeAttributeValue(PROFESSION,  sCodeSens) ;
      pContexte->getDico()->donneCodeSens(&sSpec, &sCodeSens) ;
			pAttrArray->changeAttributeValue(SPECIALITY,  sCodeSens) ;
      pContexte->getDico()->donneCodeSens(&sOrient, &sCodeSens) ;
			pAttrArray->changeAttributeValue(ORIENTATION, sCodeSens) ;
			pAttrArray->changeAttributeValue(TITLE,       sTitre) ;
      pAttrArray->changeAttributeValue(CITY_PRO,    sVille) ;
      pContexte->getDico()->donneCodeSens(&sActiveJob, &sCodeSens) ;
      pAttrArray->changeAttributeValue(ACTIVE_JOB,  sCodeSens) ;
      break ;
	}
}

void
NSPersonGraphManager::ChargeContacts(NSPatPathoArray* pPatPathoArray, PIDSTYPE iTypePids, string& sTelp, string& sEmail)
{
	if ((NULL == pPatPathoArray) || (pPatPathoArray->empty()))
		return ;
	//
  // On part du principe que les donn�es qui nous int�ressent sont dans un
  // sous chapitre LCOOR (coordonnees) ou ULIEX (lieu d'exercice) pour les corresp et les utilisateurs

  string          sElemLex, sSens, sType ;

  sTelp   = "" ;
  sEmail  = "" ;

  string          sTemp   = "" ;

	PatPathoIter iter = pPatPathoArray->begin() ;
	int iColBase = (*iter)->getColonne() ;
	iter++ ;

	while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColBase))
	{
  	sElemLex = (*iter)->getLexique() ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    // Chapitre "identit�" / Identity chapter
    if (((iTypePids == pidsPatient) && (sSens == string("LCOOR"))) ||
            (sSens == string("ULIEX")))
    {
    	int iColCoor = (*iter)->getColonne() ;
      iter++ ;

      while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColCoor))
      {
      	sElemLex = (*iter)->getLexique();
        pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

        // Nom du patient
        // Patient's name
        if ((sSens == string("LTELP")) && (sTelp == ""))
        {
        	iter++ ;
          while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColCoor+1))
          {
          	// on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 3) == string("�CL"))
            	sTelp = (*iter)->getTexteLibre() ;

            iter++ ;
          }
        }
        // Pr�nom du patient
      	// Patient's second name
        else if ((sSens == string("LMAIL")) && (sEmail == ""))
        {
        	iter++ ;
          while ((iter != pPatPathoArray->end()) && ((*iter)->getColonne() > iColCoor+1))
          {
          	// on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 3) == string("�CL"))
            	sEmail = (*iter)->getTexteLibre() ;

            iter++ ;
          }
        }
        else
        	iter++ ;
      }
    }
    else
    	iter++ ;
	}
}

void
NSPersonGraphManager::buildDualPatho(NSPatPathoArray* pDualPatho, NSPatPathoArray* pAdminPatho, NSPatPathoArray* pPDSPatho)
{
	if ((NULL == pDualPatho) || (NULL == pAdminPatho) || (NULL == pPDSPatho))
		return ;

	pDualPatho->vider() ;

  *pDualPatho = *pAdminPatho ;

  if (false == pPDSPatho->empty())
		pDualPatho->InserePatPatho(pDualPatho->end(), pPDSPatho, 0, true) ;
}

void
NSPersonGraphManager::partDualPatho(NSPatPathoArray* pDualPatho, NSPatPathoArray* pAdminPatho, NSPatPathoArray* pPDSPatho)
{
	if ((NULL == pDualPatho) || (NULL == pAdminPatho) || (NULL == pPDSPatho))
		return ;

	pAdminPatho->vider() ;
  pPDSPatho->vider() ;

  if (pDualPatho->empty())
		return ;

	NSVectPatPathoArray Vect ;
  PatPathoIter iterRoot = pDualPatho->begin() ;
  pDualPatho->ExtraireVecteurPatPathoFreres(iterRoot, &Vect) ;

	if (Vect.empty())
		return ;

	PatPathoIterVect iterVect = Vect.begin() ;
	string sTypeFrere ;
	while (Vect.end() != iterVect)
	{
  	if (false == (*iterVect)->empty())
    {
			// Le type de chaque frere est donn� par le code lexique de sa racine
    	iterRoot = (*iterVect)->begin() ;
    	sTypeFrere = (*iterRoot)->getLexiqueSens(pContexte) ;

    	if      (string("ZADMI") == sTypeFrere)
    		*pAdminPatho = *(*iterVect) ;
    	else if (string("DPROS") == sTypeFrere)
    		*pPDSPatho = *(*iterVect) ;
    }

    iterVect++ ;
  }
}

bool
NSPersonGraphManager::setTemplatePres(string sCodeDocPres, string sTemplate, string sEnTete)
{
	string sRightsPres ;
	NSPatPathoArray PatPathoArray(pContexte, graphPerson) ;

	if (!getTree(sCodeDocPres, &PatPathoArray, &sRightsPres))
		return false ;

	string sElemLex, sSens, sType ;
	string sTemp	= ""  ;

  if (PatPathoArray.empty())
		return true ;

	PatPathoIter iter = PatPathoArray.begin() ;
	int iColBase = (*iter)->getColonne() ;
	iter++ ;

	while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase))
	{
  	sElemLex = (*iter)->getLexique() ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    // Fichier Template
    if (sSens == string("0TPL0"))
    {
    	iter++ ;
      while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (sElemLex == string("�?????"))
        {
        	if ((*iter)->getTexteLibre() != sTemplate)
          {
          	(*iter)->setNodeID(string("")) ;
        		(*iter)->setTexteLibre(sTemplate) ;
          }
        }

        iter++ ;
      }
    }
    // Fichier En-tete
    else if (sSens == string("0ENTE"))
    {
    	iter++ ;
      while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (sElemLex == string("�?????"))
        {
        	if ((*iter)->getTexteLibre() != sEnTete)
          {
          	(*iter)->setNodeID(string("")) ;
        		(*iter)->setTexteLibre(sEnTete) ;
          }
        }

        iter++ ;
      }
    }
    else
    	iter++ ;
	} // boucle principale

	setTree(&PatPathoArray, "", sCodeDocPres) ;
	commitGraphTree(sCodeDocPres) ;

	return true ;
}

bool
NSPersonGraphManager::getTemplatePres(string sCodeDocPres, string& sTemplate, string& sEnTete)
{
	string sRightsPres ;
	NSPatPathoArray PatPathoArray(pContexte, graphPerson) ;

	if (!getTree(sCodeDocPres, &PatPathoArray, &sRightsPres))
		return false ;

	string sElemLex, sSens, sType ;
	string sTemp	= ""  ;

  sTemplate = string("") ;
  sEnTete   = string("") ;

  if (PatPathoArray.empty())
		return true ;

	PatPathoIter iter = PatPathoArray.begin() ;
	int iColBase = (*iter)->getColonne() ;
	iter++ ;

	while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase))
	{
  	sElemLex = (*iter)->getLexique() ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    // Fichier Template
    if (sSens == string("0TPL0"))
    {
    	iter++ ;
      while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (sElemLex == string("�?????"))
        	sTemplate = (*iter)->getTexteLibre() ;

        iter++ ;
      }
    }
    // Fichier En-tete
    else if (sSens == string("0ENTE"))
    {
    	iter++ ;
      while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (sElemLex == string("�?????"))
        	sEnTete = (*iter)->getTexteLibre() ;

        iter++ ;
      }
    }
    else
    	iter++ ;
	} // boucle principale

	return true ;
}

bool
NSPersonGraphManager::getLibIDsPpt(NSPatPathoArray* pPPTIdent)
{
	if (!pPPTIdent)
		return false ;

  NSDataTreeIter iterTree ;
  if (false == pDataGraph->aTrees.ExisteTree("0LIBI1", pContexte, &iterTree))
		return false ;

	if (NULL == iterTree)
		return false ;

	(*iterTree)->getPatPatho(pPPTIdent) ;

  return true ;
}

bool
NSPersonGraphManager::IPPEnCours(NSPatPathoArray* pPPTIdent, string sSite, string* psIpp,
                                    string* psOuvre, string* psFerme)
{
	if ((NULL == pPPTIdent) || (pPPTIdent->empty()))
		return false ;

	char szDateJour[15] ;
	donne_date_duJour(szDateJour) ;
	char szHeure[7] ;	donne_heure(szHeure) ;
	strcat(szDateJour, szHeure) ;

	bool bIPPEnCours = false ;

	PatPathoIter iter = pPPTIdent->begin() ;
	// int iColBase = (*iter)->getColonne() ;
	string sElemLex, sSens, sType ;
	string sSiteTrouve, sIppTrouve ;
	string sOuvre, sFerme ;
	string sTemp = "" ;

	iter++ ;

	while ((iter != pPPTIdent->end()) && (!bIPPEnCours))
	{
		iter = pPPTIdent->ChercherItem("LSITE", false, iter) ;

		if (iter != pPPTIdent->end())
		{
    	int iColSite = (*iter)->getColonne() ;
      iter++ ;

      sSens = (*iter)->getLexiqueSens(pContexte) ;

      if (string("�OB") == sSens)
      {
      	sSiteTrouve = (*iter)->getComplement() ;
        iter++ ;

        if (sSiteTrouve == sSite)
        {
        	while ((pPPTIdent->end() != iter) && ((*iter)->getColonne() > iColSite))
          {
          	sSens = (*iter)->getLexiqueSens(pContexte) ;

            if (string("LIPP0") == sSens)
            {
            	int iColIpp = (*iter)->getColonne() ;
              sIppTrouve = "" ;
              sOuvre = "" ;
              sFerme = "" ;
              iter++ ;

              while ((pPPTIdent->end() != iter) && ((*iter)->getColonne() > iColIpp))
              {
              	sSens = (*iter)->getLexiqueSens(pContexte) ;

                if (string("�CL") == sSens)
                {
                	sIppTrouve = (*iter)->getTexteLibre() ;
                  iter++ ;
                }

                else if (string("KOUVR") == sSens)
                {
                	iter++ ;
                  while ((pPPTIdent->end() != iter) && ((*iter)->getColonne() > iColIpp+1))
                  {
                    string sUnite  = (*iter)->getUnitSens(pContexte) ;
                    string sFormat = (*iter)->getLexiqueSens(pContexte) ;
                    string sValeur = (*iter)->getComplement() ;

                    if (("2DA01" == sUnite) || ("2DA02" == sUnite))
                    	sOuvre = sValeur ;

                    iter++ ;
                  }
                }
                else if (string("KFERM") == sSens)
                {
                	iter++ ;
                  while ((pPPTIdent->end() != iter) && ((*iter)->getColonne() > iColIpp+1))
                  {
                  	string sUnite  = (*iter)->getUnitSens(pContexte) ;
                    string sFormat = (*iter)->getLexiqueSens(pContexte) ;
                    string sValeur = (*iter)->getComplement() ;

                    if (("2DA01" == sUnite) || ("2DA02" == sUnite))
                    	sFerme = sValeur ;

                    iter++ ;
                  }
                }
                else
                	iter++ ;
              }
            }
            else
            	iter++ ;
          }

          if (sIppTrouve != "")
          {
          	if ((sOuvre != "") && (sOuvre <= string(szDateJour)))
            {
            	if ((sFerme == "") || (sFerme > string(szDateJour)))
              	bIPPEnCours = true ;
            }
        	}
        }
      }
      // Local IPP
      //
      else if (string("LIPP0") == sSens)
      {
        int iColIpp = (*iter)->getColonne() ;
        sIppTrouve = "" ;
        sOuvre = "" ;
        sFerme = "" ;
        iter++ ;

        while ((pPPTIdent->end() != iter) && ((*iter)->getColonne() > iColIpp))
        {
          sSens = (*iter)->getLexiqueSens(pContexte) ;

          if (string("�CL") == sSens)
          {
            sIppTrouve = (*iter)->getTexteLibre() ;
            iter++ ;
          }

          else if (string("KOUVR") == sSens)
          {
            iter++ ;
            while ((pPPTIdent->end() != iter) && ((*iter)->getColonne() > iColIpp+1))
            {
              string sUnite  = (*iter)->getUnitSens(pContexte) ;
              string sFormat = (*iter)->getLexiqueSens(pContexte) ;
              string sValeur = (*iter)->getComplement() ;

              if (("2DA01" == sUnite) || ("2DA02" == sUnite))
                sOuvre = sValeur ;

              iter++ ;
            }
          }
          else if (string("KFERM") == sSens)
          {
            iter++ ;
            while ((pPPTIdent->end() != iter) && ((*iter)->getColonne() > iColIpp+1))
            {
              string sUnite  = (*iter)->getUnitSens(pContexte) ;
              string sFormat = (*iter)->getLexiqueSens(pContexte) ;
              string sValeur = (*iter)->getComplement() ;

              if (("2DA01" == sUnite) || ("2DA02" == sUnite))
                sFerme = sValeur ;

              iter++ ;
            }
          }
          else
            iter++ ;
        }
        if ((string("") != sIppTrouve) && (string("") == sSite))
        {
          if ((string("") == sOuvre) && (string("") == sFerme))
            bIPPEnCours = true ;
          else if ((string("") != sOuvre) && (sOuvre <= string(szDateJour)))
          {
            if ((string("") == sFerme) || (sFerme > string(szDateJour)))
              bIPPEnCours = true ;
          }
        }
      }
      else
        while ((pPPTIdent->end() != iter) && ((*iter)->getColonne() > iColSite))
          iter++ ;
    }
  }

	if (bIPPEnCours)
	{
		if (psIpp)
    	*psIpp = sIppTrouve ;

    if (psOuvre)
    	*psOuvre = sOuvre ;

    if (psFerme)
    	*psFerme = sFerme ;
  }

	return bIPPEnCours ;
}

bool
NSPersonGraphManager::ClotureIPP(NSPatPathoArray* pPPTIdent, string sSite, string sIpp, NSPatPathoArray* pPPTIpp)
{
	if (!pPPTIdent)
		return false ;

	char szDateJour[15] ;
	donne_date_duJour(szDateJour) ;
	char szHeure[7] ;	donne_heure(szHeure) ;
	strcat(szDateJour, szHeure) ;

	bool bIPPTrouve = false;
	bool bDateTrouvee = false;
	bool bPremier = true;
	PatPathoIter iter = pPPTIdent->begin();
	PatPathoIter iterFirst, iterPrec;
	// int iColBase = (*iter)->getColonne() ;
	int iColIpp;
	string sElemLex, sSens, sType ;
	string sSiteTrouve, sIppTrouve;
	string sOuvre, sFerme;
	string sTemp = "" ;

	iter++ ;

	while ((iter != pPPTIdent->end()) && (!bIPPTrouve))
	{
  	iter = pPPTIdent->ChercherItem("LSITE", false, iter) ;

    if (iter != pPPTIdent->end())
    {
    	int iColSite = (*iter)->getColonne() ;
      iter++ ;

      sSens = (*iter)->getLexiqueSens(pContexte) ;

      if (string("�OB") == sSens)
      {
      	sSiteTrouve = (*iter)->getComplement() ;
        iter++ ;

        if (sSiteTrouve == sSite)
        {
        	while ((pPPTIdent->end() != iter) && ((*iter)->getColonne() > iColSite))
          {
          	sSens = (*iter)->getLexiqueSens(pContexte) ;

            if (string("LIPP0") == sSens)
            {
            	iColIpp = (*iter)->getColonne() ;

              if (bPremier)
              {
              	iterFirst = iter ;
                bPremier = false ;
              }

              sIppTrouve = "" ;
              sOuvre = "" ;
              sFerme = "" ;
              iter++ ;

              iterPrec = iter ;

              while ((iter != pPPTIdent->end()) && ((*iter)->getColonne() > iColIpp))
              {
              	sSens = (*iter)->getLexiqueSens(pContexte) ;

                if (string("�CL") == sSens)
                {
                	sIppTrouve = (*iter)->getTexteLibre() ;
                  iter++ ;
                }

                else if (string("KOUVR") == sSens)
                {
                	iter++ ;
                  while ((pPPTIdent->end() != iter) && ((*iter)->getColonne() > iColIpp+1))
                  {
                  	string sUnite  = (*iter)->getUnitSens(pContexte) ;
                    string sFormat = (*iter)->getLexiqueSens(pContexte) ;
                    string sValeur = (*iter)->getComplement() ;

                    if (("2DA01" == sUnite) || ("2DA02" == sUnite))
                    	sOuvre = sValeur ;

                    iter++ ;
                  }
                }
                else if (sSens == string("KFERM"))
                {
                	iter++ ;
                  while ((iter != pPPTIdent->end()) && ((*iter)->getColonne() > iColIpp+1))
                  {
                  	string sUnite  = (*iter)->getUnitSens(pContexte) ;
                    string sFormat = (*iter)->getLexiqueSens(pContexte) ;
                    string sValeur = (*iter)->getComplement() ;

                    if (("2DA01" == sUnite) || ("2DA02" == sUnite))
                    {
                    	sFerme = sValeur ;

                      if (sIppTrouve == sIpp)
                      {
                      	if (sFerme > string(szDateJour))
                        	(*iter)->setComplement(string(szDateJour)) ;

                        bDateTrouvee = true ;
                      }
                    }

                    iter++ ;
                  }
                }
                else
                	iter++ ;
              }
            }
            else
            	iter++ ;
          }
          if (sIppTrouve == sIpp)
          	bIPPTrouve = true ;
        }
      }
    }
  }

	if ((bIPPTrouve) && (!bDateTrouvee))
	{
  	NSPatPathoArray PPTFerme(pContexte, graphPerson) ;

    PPTFerme.ajoutePatho("KFERM1", 0) ;
    Message Msg ;
    Msg.SetComplement(szDateJour) ;
    Msg.SetUnit("2DA021") ;
    PPTFerme.ajoutePatho("�T0;19", &Msg, 1) ;

    // on cherche l'ipp suivant pour l'insertion
    iter = pPPTIdent->ChercherItem("LIPP0", false, iterPrec) ;

    pPPTIdent->InserePatPatho(iter, &PPTFerme, iColIpp + 1) ;
	}

	if (pPPTIpp != NULL)
		pPPTIdent->ExtrairePatPathoFreres(iterFirst, pPPTIpp) ;

	return bIPPTrouve ;
}

bool
NSPersonGraphManager::InsereIPPFusion(NSPatPathoArray* pPPTIdent, string sSite, NSPatPathoArray* pPPTIpp)
{
	if (NULL == pPPTIdent)
		return false ;

  PatPathoIter iter = pPPTIdent->begin() ;
  PatPathoIter iterNext ;
  int iColBase = (*iter)->getColonne() ;
  int iColSite = iColBase + 1 ;
  string sSiteTrouve = "" ;
  iter++ ;

	while ((iter != pPPTIdent->end()) && (sSiteTrouve != sSite))
	{
  	iter = pPPTIdent->ChercherItem("LSITE", false, iter) ;

    if (iter != pPPTIdent->end())
    {
    	iColSite = (*iter)->getColonne() ;
      iter++ ;

      string sSens = (*iter)->getLexiqueSens(pContexte) ;

      if (string("�OB") == sSens)
      {
      	sSiteTrouve = (*iter)->getComplement() ;
        iter++ ;

        if (sSiteTrouve == sSite)
        {
        	while ((pPPTIdent->end() != iter) && ((*iter)->getColonne() > iColSite))
          	iter++ ;

          iterNext = iter ;
        }
      }
    }
  }

	if (sSiteTrouve == sSite)
	{
		pPPTIdent->InserePatPatho(iterNext, pPPTIpp, iColSite + 1) ;
		return true ;
	}
  else
  {
  	NSPatPathoArray	pptIdLib(pContexte) ;

    pptIdLib.ajoutePatho("LSITE1", 0) ;

    Message Msg ;
    Msg.SetComplement(sSite) ;
    pptIdLib.ajoutePatho("�OBJE1", &Msg, 1) ;

    pPPTIdent->InserePatPatho(pPPTIdent->end(), &pptIdLib, iColSite) ;
    pPPTIdent->InserePatPatho(pPPTIdent->end(), pPPTIpp, iColSite + 1) ;
  }

	return false ;
}

bool
NSPersonGraphManager::LastOpenStay(string sDateTime, NSSejourInfo* pStayInfo)
{
	string sRootTree = getRootTree() ;

  VecteurString VectString ;
  VecteurString VecteurData  ;

  NSSejourArray SejourArray ;

  bool bOk ;

  // on cherche l'ensemble des s�jours li�s au noeud root du patient
  pLinkManager->TousLesVrais(sRootTree, NSRootLink::fonctionalUnitStay, &VectString) ;
  if (!VectString.empty())
  {
  	for (EquiItemIter i = VectString.begin(); i != VectString.end(); i++)
    {
    	NSDocumentInfo DocumInfo(*(*i), pContexte) ;

      NSPatPathoArray PatPathoArray(pContexte, graphPerson) ;

      VecteurData.vider() ;

      bOk = false ;

      // On remonte le lien data du m�ta-document
      pLinkManager->TousLesVrais(DocumInfo.sCodeDocMeta, NSRootLink::docData, &VecteurData) ;
      if (!VecteurData.empty())
      {
      	string sCodeDocData = *(*(VecteurData.begin())) ;
        string sCodePat = string(sCodeDocData, 0, PAT_NSS_LEN) ;
        string sCodeDoc = string(sCodeDocData, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;

        DocumInfo.setPatient(sCodePat) ;
        DocumInfo.setDocument(sCodeDoc) ;

        if ((DocumInfo.ParseMetaDonnees()) &&
                    (DocumInfo.DonnePatPatho(&PatPathoArray)))
        	bOk = true ;
      }

      if (!bOk || (PatPathoArray.empty()))
      	// s�jour sans lien data
        continue ;

      // Parsing de la patpatho et remplissage de la NSSejourInfo
      // que l'on stocke dans une array
      NSSejourInfo SejourInfo ;
      PatPathoIter iter;
      int iColBase;
      string sElemLex, sSens;
      string sNumero, sUnit, sDateDeb, sDateFin;

      string sTemp = "" ;

      iter = PatPathoArray.begin() ;
      iColBase = (*iter)->getColonne() ;
      SejourInfo.pDonnees->sTreeID = (*iter)->getDoc() ;
      iter++ ;

      while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase))
      {
      	sElemLex = (*iter)->getLexique() ;
        pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

        // num�ro de s�jour
        if (sSens == string("LNUSE"))
        {
        	iter++ ;
          sNumero = "" ;
          while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase+1))
          {
          	// on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 3) == string("�CL"))
            {
            	sNumero = (*iter)->getTexteLibre() ;
              SejourInfo.pDonnees->sNumero = sNumero ;
            }
            iter++ ;
          }
        }
        // unit� fonctionnelle
        else if (sSens == string("LUNIF"))
        {
        	iter++ ;
          sUnit = "" ;
          while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase+1))
          {
          	sElemLex = (*iter)->getLexique() ;
            if (sElemLex == string("�OBJE1"))
            {
            	sUnit = (*iter)->getComplement() ;
              SejourInfo.pDonnees->sUnit = sUnit ;
            }
            iter++ ;
          }
        }
        // date d'ouverture
        else if (sSens == string("KOUVR"))
        {
        	iter++ ;
          // int iLigneBase = (*iter)->getLigne() ;

          string sUnite  = (*iter)->getUnitSens(pContexte) ;
          string sFormat = (*iter)->getLexiqueSens(pContexte) ;
          string sValeur = (*iter)->getComplement() ;

          if (sUnite == "2DA02")
          	SejourInfo.pDonnees->sDateDeb = sValeur ;

          iter++ ;
        }
        // date de fermeture
        else if (sSens == string("KFERM"))
        {
        	iter++ ;
          // int iLigneBase = (*iter)->getLigne() ;

          string sUnite  = (*iter)->getUnitSens(pContexte) ;
          string sFormat = (*iter)->getLexiqueSens(pContexte) ;
          string sValeur = (*iter)->getComplement() ;

          if (sUnite == "2DA02")
          	SejourInfo.pDonnees->sDateFin = sValeur;

          iter++ ;
        }
        else
        	iter++ ;
      }

      SejourArray.push_back(new NSSejourInfo(SejourInfo)) ;
    }
  }

  if (SejourArray.empty())
    return false ;

  NSSejourIter lastOpenIter = NULL;

  // Deuxi�me passe : on regarde en fonction de la date le dernier
  // s�jour ouvert (dans lequel s'inscrit la date pass�e en param�tre)
  for (NSSejourIter k = SejourArray.begin(); k != SejourArray.end(); k++)
  {
  	// on regarde si la date d'ouverture est ant�rieure � la date du compte-rendu
    if ((*k)->pDonnees->sDateDeb <= sDateTime)
    {
    	if (lastOpenIter == NULL)
      	lastOpenIter = k ;
      else
      {
      	// Quand deux s�jours sont valides, on prend le plus r�cent
        if ((*k)->pDonnees->sDateDeb >= (*lastOpenIter)->pDonnees->sDateDeb)
        	lastOpenIter = k ;
      }
    }
  }

  if (lastOpenIter == NULL)
    return false ;

  *pStayInfo = *(*lastOpenIter) ;

  return true ;
}

void
NSPersonGraphManager::ConnectRootTreeToGoal(string sTree, string sGoalNode, NSRootLink::NODELINKTYPES iLink)
{
	// On cherche le m�ta - Looking for the meta data tree identifier
	//
	string sMetaTree = "" ;
	string sRootTree = string(sTree, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) ;

	VecteurString VectString ;
	pLinkManager->TousLesVrais(sRootTree, NSRootLink::docData, &VectString, "ENVERS") ;
	if (!VectString.empty())
		sMetaTree = *(*(VectString.begin())) ;

	if (sMetaTree == "")
		return ;

	// Getting the tree
	//
	NSPatPathoArray PPtMeta(pContexte) ;
	string sRosace = "" ;
	if ((getTree(sMetaTree, &PPtMeta, &sRosace)) && (!PPtMeta.empty()))
	{
  	PatPathoIter pptIter ;
    if (PPtMeta.CheminDansPatpatho("ZDOCU/0TYPC", string(1, cheminSeparationMARK), &pptIter))
    {
    	string sNode = (*pptIter)->getNode() ;
      pLinkManager->etablirLien(sNode, iLink, sGoalNode) ;
    }
	}

	// on enregistre le m�ta
	setTree(&PPtMeta, sRosace, sMetaTree) ;
	commitGraphTree(sMetaTree) ;

	return ;
}

void
NSPersonGraphManager::ConnectNodeToGoal(string sTreeNode, string sGoalNode, NSPatPathoArray* pData, NSRootLink::NODELINKTYPES iLink)
{
	// On cherche le m�ta - Looking for the meta data tree identifier
	//
	string sMetaTree = "" ;
	string sRootTree = string(sTreeNode, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) ;

	VecteurString VectString ;
	pLinkManager->TousLesVrais(sRootTree, NSRootLink::docData, &VectString, "ENVERS") ;
	if (!VectString.empty())
		sMetaTree = *(*(VectString.begin())) ;

	if (sMetaTree == "")
		return ;

	// Getting the tree
	//
	NSPatPathoArray PPtMeta(pContexte) ;
	string sRosace = "" ;
	if ((getTree(sMetaTree, &PPtMeta, &sRosace)) && (!PPtMeta.empty()))
	{
  	PatPathoIter pptIter ;
    string sNodePere = "" ;
    if (PPtMeta.CheminDansPatpatho("ZDOCU/9SUIV", string(1, cheminSeparationMARK), &pptIter))
    {
    	VecteurString VString ;
      pLinkManager->TousLesVrais(sTreeNode, NSRootLink::copyOf, &VString, "ENVERS") ;
      if (!VString.empty())
      	sNodePere = *(*(VString.begin())) ;

      if (sNodePere != "")
      {
      	// cas o� il faut remettre � jour les donn�es de suivi dans le m�ta
        // on remplace seulement les fils pour �viter de refaire les liens
        //
        NSPatPathoArray DataSuiv(pContexte) ;
        NSPatPathoArray MetaDataSuiv(pContexte) ;
        pData->ExtrairePatPatho(pData->begin(), &DataSuiv) ;
        pptIter = PPtMeta.ChercherNoeud(sNodePere) ;
        PPtMeta.ExtrairePatPatho(pptIter, &MetaDataSuiv) ;

        // on teste l'egalite du point de vue des donn�es
        if (!MetaDataSuiv.estEgal(&DataSuiv))
        {
        	PPtMeta.SupprimerFils(pptIter) ;
          PPtMeta.InserePatPathoFille(pptIter, &DataSuiv) ;
        }

        pLinkManager->etablirLien(sNodePere, (NSRootLink::NODELINKTYPES) iLink, sGoalNode) ;
      }
      else
      {
      	// Dans ce cas, on insere les pData � la fin des donn�es de suivi
        // apres avoir plac� les liens temporaires
        //
        PatPathoIter iterData = pData->begin() ;
        (*iterData)->addTemporaryLink(sTreeNode, NSRootLink::copyOf, dirFleche) ;
        (*iterData)->addTemporaryLink(sGoalNode, iLink, dirFleche) ;

        int iColSuiv = (*pptIter)->getColonne() ;

        //
        // On se positionne sur l'�l�ment qui suit le dernier fils
        //
        pptIter++ ;
        while ((pptIter != PPtMeta.end()) && ((*pptIter)->getColonne() > iColSuiv))
        	pptIter++ ;

        PPtMeta.InserePatPatho(pptIter, pData, iColSuiv + 1) ;
      }
    }
    else
    {
    	// on doit ici ajouter le chap�tre "donn�es de suivi"
      // avant d'ins�rer les pData
      //
      PPtMeta.ajoutePatho("9SUIV1", 1) ;

      PatPathoIter iterData = pData->begin();
      (*iterData)->addTemporaryLink(sTreeNode, NSRootLink::copyOf, dirFleche) ;
      (*iterData)->addTemporaryLink(sGoalNode, iLink, dirFleche) ;

      PPtMeta.InserePatPatho(PPtMeta.end(), pData, 2) ;
    }
	}

  // on enregistre le m�ta
  setTree(&PPtMeta, sRosace, sMetaTree) ;
  commitGraphTree(sMetaTree) ;
}

// fin de nsmanager.cpp
////////////////////////////////////////////////////


