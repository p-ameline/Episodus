//***************************************************************************//  NOM du FICHIER  : NSBBTRAN.CPP
//
//  Impl�mentation de toutes les classes qui font l'interface entre
//  BBItem et NSdlg
//
//  NSTransferInfo
//  NSTransferArray
//  Kaddachi Hafedh
// Date de cr�ation : PA Mai 96                mise � jour : PA 15/02/1995
//**************************************************************************
#include <owl\olemdifr.h>
#include <owl\applicat.h>

#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"

#include "nsbb\nsbbtran.h"

#include "nssavoir\nsguide.h"

#include "nsbb\nsbb_msg.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbb_dlg.h"

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
Message::Message(string noeud, string lexique, string complement, string type,
                 string Interet, string Certitude, string Pluriel,
                 string Visible, string TL, string sArc, string sUnite, string rig)
        :sNoeud(noeud), sLexique(lexique), sComplement(complement), sType(type),
         sInteret(Interet), sCertitude(Certitude), sPluriel(Pluriel),
         sVisible(Visible), sTexteLibre(TL), sArchetype(sArc), sUnit(sUnite), sRights(rig)
{
	pTemporaryLinks = 0 ;
}

//---------------------------------------------------------------------------
//  Constructeur par d�faut
//---------------------------------------------------------------------------
Message::Message()
{
	pTemporaryLinks = 0 ;

  Reset() ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
Message::Message(const Message& src)
{
	sTreeID     = src.sTreeID ;
	sNoeud      = src.sNoeud ;
	sLexique    = src.sLexique ;
	sComplement = src.sComplement ;
	sType       = src.sType ;
	sInteret    = src.sInteret ;
	sCertitude  = src.sCertitude ;
	sPluriel    = src.sPluriel ;
	sVisible    = src.sVisible ;
	sTexteLibre = src.sTexteLibre ;
	sArchetype  = src.sArchetype ;
	sUnit       = src.sUnit ;
	sRights     = src.sRights ;
  
	pTemporaryLinks = 0 ;
	if (src.pTemporaryLinks)
  	pTemporaryLinks = new NSLinkedNodeArray(*(src.pTemporaryLinks)) ;
}

//---------------------------------------------------------------------------
//  Surcharge de l'op�rateur d'affectation
//---------------------------------------------------------------------------
Message&
Message::operator=(Message src)
{
	if (this == &src)
		return *this ;

	sTreeID     = src.sTreeID ;
	sNoeud      = src.sNoeud ;
  sLexique    = src.sLexique ;
	sComplement = src.sComplement ;
  sType       = src.sType ;
  sInteret    = src.sInteret ;
	sCertitude  = src.sCertitude ;
  sPluriel    = src.sPluriel ;
  sVisible    = src.sVisible ;
  sTexteLibre = src.sTexteLibre ;
  sArchetype  = src.sArchetype ;
  sUnit       = src.sUnit ;
  sRights     = src.sRights ;
  SetTemporaryLinks(src.pTemporaryLinks) ;

	return *this ;
}

Message::~Message()
{
	if (pTemporaryLinks)
  	delete pTemporaryLinks ;
}

void
Message::Reset()
{
	sTreeID     = string("") ;
	sNoeud      = string("") ;
	sLexique    = string("") ;
	sComplement = string("") ;
	sType       = string("") ;
	sInteret    = string("A") ;
	sCertitude  = string("") ;
	sPluriel    = string("") ;
	sVisible    = string("1") ;
	sTexteLibre = string("") ;
	sArchetype  = string("") ;
	sUnit       = string("") ;
	sRights     = string("") ;

	if (pTemporaryLinks)
  	delete pTemporaryLinks ;

  pTemporaryLinks = 0 ;
}

void
Message::SetTemporaryLinks(NSLinkedNodeArray* pArray)
{
	if (pTemporaryLinks)
	{
  	delete pTemporaryLinks ;
    pTemporaryLinks = 0 ;
	}
	if (pArray && (false == pArray->empty()))
  	pTemporaryLinks = new NSLinkedNodeArray(*pArray) ;
}

//-----------------------------------------------------------------------
// exemple si sEtiquette : PFONC1.WCE751
//									---> patpatho : certitude : WCE751
//-----------------------------------------------------------------------
void
Message::MettreAJourCertitudePluriel(string sEtiquette)
{
  size_t posWPL 	= sEtiquette.find(string("WPL")) ;
  size_t posWCE  	= sEtiquette.find(string("WCE")) ;
  size_t posWCEA0 = sEtiquette.find(string("WCEA0")) ;
  size_t posCompl = sEtiquette.find(string("$")) ;

  // si pluriel
  if ((posWPL != NPOS))
    SetPluriel(string(sEtiquette, posWPL, BASE_PLURIEL_LEN)) ;

  // si certitude = pr�sence totale, ne rien mettre dans la case certitude de
  // la patpatho (c'est la valeur par d�faut)
  if (posWCEA0 != NPOS)
    SetCertitude(string("")) ;
  else
    if ((posWCE != NPOS))
      SetCertitude(string(sEtiquette, posWCE, BASE_CERTITUDE_LEN)) ;

  // on consid�re que le complement est toujours � la fin de sEtiquette
  if (posCompl != NPOS)
  {
    string sCompl = string(sEtiquette, posCompl+1, strlen(sEtiquette.c_str())-posCompl-1) ;
    if (strlen(sCompl.c_str()) > BASE_COMPLEMENT_LEN)
      sCompl = string(sCompl, 0, BASE_COMPLEMENT_LEN) ;
    SetComplement(sCompl) ;
  }
}

void
Message::InitFromEtiquette(string sEtiquette)
{
  char separator = intranodeSeparationMARK ;

  // L'�tiquette peut �tre du type Lexique/Certitude/Pluriel ou Lexique.Certitude.Pluriel
  //
  size_t posit = sEtiquette.find(string(1, separator)) ;
  if (NPOS == posit)
  {
    separator = cheminSeparationMARK ;
    posit = sEtiquette.find(string(1, separator)) ;
  }
  //
  // Si c'est le cas, la m�thode la plus propre consiste
  // � passer par un Message
  //
  if (posit == NPOS)
  {
    sLexique = sEtiquette ;
    return ;
  }

  int iTaille = strlen(sEtiquette.c_str()) ;
  sLexique   = string(sEtiquette, 0, posit) ;
  sEtiquette = string(sEtiquette, posit + 1, iTaille - posit - 1) ;

  if (sLexique[0] == '2')
  {
    sUnit      = sLexique ;

    posit = sEtiquette.find(string(1, separator)) ;
    if (posit == NPOS)
    {
      sLexique = sEtiquette ;
      return ;
    }

    sLexique   = string(sEtiquette, 0, posit) ;
    sEtiquette = string(sEtiquette, posit + 1, iTaille - posit - 1) ;
  }

  MettreAJourCertitudePluriel(sEtiquette) ;
}

//***************************************************************************
// Impl�mentation des m�thodes NSTransferInfo
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeurs
//---------------------------------------------------------------------------
NSTransferInfo::NSTransferInfo(BBFilsItem* pFilsItem, int actif,
                               string noeud, string complement, string type,
                               string interet, string certitude, string pluriel,
                               string visible, string sTL, string sArc, string sUnite)
               :pBBFilsItem(pFilsItem), iActif(actif)
{
try
{
	pControle 	= 0 ;
	pTransfertMessage    = new Message(noeud, complement, type, interet, certitude,
                                    pluriel, visible, sTL, sArc, sUnite) ;
	/* pTmpTransfertMessage    = new Message(noeud, complement, type, interet, certitude,
                                    pluriel, visible, sTL, sArc, sUnite); */
	pTmpTransfertMessage = pTransfertMessage ;

	pTransPatpatho       = new NSVectFatheredPatPathoArray() ;
	pTempoPatpatho       = new NSVectFatheredPatPathoArray() ;}catch (...)
{
	erreur("Exception (new NSTransferInfo 1).", standardError, 0) ;
}
}

NSTransferInfo::NSTransferInfo(BBFilsItem* pFilsItem, const NSTransferInfo& src)
               :pBBFilsItem(pFilsItem)
{
try
{
	iActif               = src.iActif ;
	pControle            = src.pControle ;

	pTransfertMessage    = new Message(*(src.pTransfertMessage)) ;
	// pTmpTransfertMessage    = new Message(*(src.pTmpTransfertMessage));
	pTmpTransfertMessage = pTransfertMessage  ;

	pTransPatpatho       = new NSVectFatheredPatPathoArray(*(src.pTransPatpatho)) ;
	pTempoPatpatho       = new NSVectFatheredPatPathoArray(*(src.pTempoPatpatho)) ;
}
catch (...)
{
	erreur("Exception (new NSTransferInfo 2).", standardError, 0);
}
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSTransferInfo::~NSTransferInfo()
{
	if (NULL != pControle)
		pControle->setTransfert(NULL) ;

	delete pTransfertMessage ;
	// delete pTmpTransfertMessage;
	delete pTransPatpatho ;
	delete pTempoPatpatho ;
}

//---------------------------------------------------------------------------//  Demande � un contr�le de se mettre dans l'�tat voulu
//---------------------------------------------------------------------------
void
NSTransferInfo::activeControle(int activation, Message* pMessage)
{
	if (NULL != pControle)
		pControle->activeControle(activation, pMessage) ;
}

//---------------------------------------------------------------------------
//  Transmet � BBItem l'avis d'activation d'un contr�le
//
//  etatInitial	 : �tat du contr�le avant activation
//  etatSouhait� : �tat souhait� apr�s activation
//  message		 : renseignements compl�mentaires : Donnees & Type
//---------------------------------------------------------------------------
void
NSTransferInfo::ctrlNotification(int etatInitial, int etatSouhaite, Message* pMessage, int indexFils)
{
	if ((NULL != pBBFilsItem) && (NULL != pBBFilsItem->getItemFather()))
		pBBFilsItem->getItemFather()->ctrlNotification(pBBFilsItem, &pControle->getIdentite(),
                                         etatInitial, etatSouhaite, pMessage, indexFils) ;
}

//---------------------------------------------------------------------------
//  Transf�re les donn�es du contr�le vers iActif et sDonnees
//						et vice-versa suivant la direction
//
//  direction : tdGetData ou tdSetData
//
//  Retourne  :	1 si le transfert a fonctionn�
//				0 sinon
//---------------------------------------------------------------------------
uint
NSTransferInfo::Transfer(TTransferDirection direction)
{
	if (NULL != pControle)
		return pControle->Transfer(direction) ;
	return 1 ;
}

uint
NSTransferInfo::TransferFinal(TTransferDirection direction)
{
	if (NULL != pControle)
		return pControle->TransferFinal(direction) ;
	return 1 ;}

uint
NSTransferInfo::TempTransfer()
{
	if (pControle)
		return pControle->TempTransfer() ;
	return 1 ;
}

void
NSTransferInfo::Desactive()
{
	iActif = 0 ;
}

void
NSTransferInfo::Active()
{
	iActif = 1;
}

//---------------------------------------------------------------------------
//  Enregistre le r�f�rencement,
//  lance �ventuellement la fonction d'initialisation
//
//  pCtrl : pointeur sur le contr�le Windows qui se d�clare
//---------------------------------------------------------------------------
void
NSTransferInfo::referenceControle(NSControle* pCtrl)
{
	pControle = pCtrl ;
}

//---------------------------------------------------------------------------
//  D�tache la partie Windows de la partie BigBrother
//---------------------------------------------------------------------------
void
NSTransferInfo::detacheControle()
{
	if (NULL != pControle)
	{
		pControle->setTransfert(0) ;
		pControle = 0 ;
	}
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSTransferInfo::NSTransferInfo(const NSTransferInfo& src)
{
try
{
	pBBFilsItem	= src.pBBFilsItem ;
	pControle   = src.pControle ;

	pTransfertMessage    = new Message(*(src.pTransfertMessage)) ;
	// pTmpTransfertMessage    = new Message(*(src.pTmpTransfertMessage)) ;
	pTmpTransfertMessage = pTransfertMessage ;
	pTransPatpatho       = new NSVectFatheredPatPathoArray(*(src.pTransPatpatho)) ;
	pTempoPatpatho       = new NSVectFatheredPatPathoArray(*(src.pTempoPatpatho)) ;

	iActif	   = src.iActif ;
}
catch (...)
{
	erreur("Exception (new NSTransferInfo copie).", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Surcharge de l'op�rateur d'affectation
//---------------------------------------------------------------------------
NSTransferInfo&
NSTransferInfo::operator=(NSTransferInfo src)
{
	if (this == &src)
		return *this ;

	pBBFilsItem	= src.pBBFilsItem ;
	pControle   = src.pControle ;

	*pTransfertMessage   = *(src.pTransfertMessage) ;
	// *pTmpTransfertMessage   = *(src.pTmpTransfertMessage) ;
	pTmpTransfertMessage = pTransfertMessage ;
	*pTransPatpatho      = *(src.pTransPatpatho) ;
	*pTempoPatpatho      = *(src.pTempoPatpatho) ;

	iActif	   = src.iActif ;

	return *this ;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSTransferInfo::operator==(const NSTransferInfo& x)
{
	return ((pControle == x.pControle) && (pBBFilsItem == x.pBBFilsItem)) ;
}

//***************************************************************************
// Impl�mentation des m�thodes NSTransferArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSTransferArray::NSTransferArray(NSTransferArray& rv)
                :TransferArray()
{
try
{
	if (false == rv.empty())
		for (iterTransferArray i = rv.begin(); i != rv.end(); i++)
			push_back(new NSTransferInfo(*(*i))) ;
}
catch (...)
{
	erreur("Exception (new NSTransferArray copie).", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSTransferArray::~NSTransferArray()
{
	if (empty())
		return ;
	for (iterTransferArray i = begin(); i != end(); )
	{
  	delete *i ;
    erase(i) ;
	}
}

