//**************************************************************************//  NOM du FICHIER  : nstrnode.CPP
//  Kaddachi Hafedh 20/03/1997
//**************************************************************************

#include "partage\nsdivfct.h"
#include "partage\ns_timer.h"
#include "nsbb\nsbbtran.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbb.h"
#include "nsbb\nsbbsmal.h"
#include "nssavoir\nspatho.h"
#include "nssavoir\nsconver.h"
#include "nssavoir\nsRightsManager.h"
#include "nsbb\nstrnode.rh"
#include "nsbb\nsbb.rh"
#include "nsbb\nStlibre.h"
#include "nsbb\nsbb_dlg.h"
#include "nsbb\nspardlg.h"
#include "nsbb\nstrewi.h"
#include "nsbb\nsednum.h"
#include "nsbb\nsdico.h"
#include "nsbb\nsedcon.h"
#include "nsbb\nsdlg.h"
//#include "nsbb\nsmanager.h"
#include "dcodeur\decoder.h"
#include "nautilus\nssoapview.h"
#include "nautilus\nsldvdoc.h"
#include "nsbb\ns_skins.h"
#include "nssavoir\nsgraphe.h"
#include "nssavoir\nsencycl.h"

#if !defined(OWL_LISTWIND_H)
# include <owl/listwind.h>
#endif

//-----------------------------------------------------------------------
// fonction globale de tri : selon la ligne
//-----------------------------------------------------------------------
bool
sortTreenodes(NSTreeNode* Node1, NSTreeNode* Node2)
{
	if (Node1->getLigne() < Node2->getLigne())
		return true ;
	return false ;
}

//----------------------------------------------------------------------
//----------------------------------------------------------------------
//									 Classe NSTreeWindow
//----------------------------------------------------------------------
//----------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSTreeWindow, TTreeWindow)
  EV_NOTIFY_AT_CHILD(TVN_SELCHANGED, SelChanged),
  EV_WM_RBUTTONDOWN,
  EV_WM_SETFOCUS,
  EV_WM_KILLFOCUS,
  EV_WM_LBUTTONDBLCLK,  //double click
  EV_WM_MOUSEMOVE,

  //param�tres
  EV_COMMAND(IDC_DELETE,              EvDelete),
  EV_COMMAND(IDC_INSERTFRERE,         InsereAvant),
  EV_COMMAND(IDC_INSERTELEMENTFICTIF, InsereApres),
  EV_COMMAND(IDC_MODIFIER,            Modifier),
  EV_COMMAND(IDC_ABSENT,              Absence),
  EV_COMMAND(IDC_PRESENCE,            Presence),
  EV_COMMAND(IDC_PARAMETRES,          Parametres),
  EV_COMMAND(IDC_FILGUIDE,            EditionFilGuide),
  EV_COMMAND(IDC_ENCYCLOP,            Encyclop),
  EV_COMMAND(IDC_CUT,                 CutNode),
  EV_COMMAND(IDC_COPY,                CopyNode),
  EV_COMMAND(IDC_PASTE,               PasteNode),
  EV_COMMAND(IDC_CLASSIF,             Classifier),
  EV_COMMAND(IDC_TREE_NEWPREOCCUP,    NewPreoccup),
  EV_COMMAND(IDC_CONNECTPREOCCUP,     ConnectToPreoccup),
  EV_COMMAND(IDC_EDITRIGHTS,     		  FixeDroits),
  EV_COMMAND(IDC_PASTE_TL,     		    InsertTlInEdit),
  EV_COMMAND(IDC_DICO_LOST_FOCUS,     DicoLostFocus),

  //Drag And Drop
  EV_WM_TIMER,
  EV_WM_LBUTTONDOWN,
  EV_WM_LBUTTONUP,
  NS_TVN_BEGINDRAG(EvTvnBeginDrag),

  //TreeView
  NS_TV_KEYDOWN(EvTvKeyDown),
  EV_WM_KEYDOWN,
  NS_TVN_BEGINLABELEDIT(TvnBeginLabelEdit),
  NS_TVN_ITEMEXPANDING(TvnItemExpanDing),
  NS_TVN_ITEMEXPANDED(TvnItemExpanded),
  EV_WM_VSCROLL,
  EV_WM_HSCROLL,
  EV_WM_PAINT,
  EV_WM_CTLCOLOR,

END_RESPONSE_TABLE;

#define NODES_COL_BASE 1
#define NODES_LIN_BASE 1

//----------------------------------------------------------------------
//----------------------------------------------------------------------
NSTreeWindow::NSTreeWindow(TWindow* parent,NSContexte* pCtx,
                            int id, int x, int y, int w, int h,
                            TStyle style, TModule* module)
             :TTreeWindow(parent, id, x, y, w, h, style, module), NSRoot(pCtx)
{
try
{
	bIniting                = true ;
  bLoosingFocus           = false ;
  Aparent                 = parent ;
  pEditDico               = 0 ;
  ReadOnly                = false ;
  pControle               = 0 ;
  pChampEdition           = 0 ;
  pPositionDragAndDrop    = 0 ;
  pChampDate              = 0 ;
  bDispatcherPatpatho     = true ;
  bDirty                  = false ;
  bLanceEdit              = false ;
  bPaint                  = false ;
  bEditionDico            = false ;
  bCurseurTexte           = false ;
  AfficheCopieCollee      = true ;
  skinName                = string("treeWindow") ;

  if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;
  else
  	sLang = "" ;

  pNSEncyclo = new NSEncyclo(pContexte) ;
  DBIResult Resultat ;
  Resultat = pNSEncyclo->open() ;
  if (Resultat != DBIERR_NONE)
  {
    string sErrMsg = pContexte->getSuperviseur()->getText("treeViewErrors", "cannotOpenEncyclopedia") ;
    pContexte->getSuperviseur()->trace(&sErrMsg, 1, NSSuper::trError) ;
  	erreur(sErrMsg.c_str(), standardError, Resultat) ;
    delete pNSEncyclo ;
    pNSEncyclo = 0 ;
  }
  pNSCV = new NSCV(pContexte);
  Resultat = pNSCV->open();
  if (Resultat != DBIERR_NONE)
  {
  	string sErrMsg = pContexte->getSuperviseur()->getText("treeViewErrors", "cannotOpenUnitConversionFile") ;
    pContexte->getSuperviseur()->trace(&sErrMsg, 1, NSSuper::trError) ;
  	erreur(sErrMsg.c_str(), standardError, Resultat) ;
    delete pNSCV ;
    pNSCV = 0 ;
  }

  pHitTestInfo = new TTwHitTestInfo ;
  // HINSTANCE Hinstance = pNSDLLModule->GetInstance();
  // HINSTANCE Hinstance1 = *GetApplication();
  pBBitemNSTreeWindow = 0 ;
  ModifierTexteLibre	= false ;
  Images = 0 ;
  pNodeArray = new NSTreeNodeArray() ;

    /*
    style = GetStyle();
    style = TTreeWindow::TStyle(style | TTreeWindow::twsHasLines | TTreeWindow::twsHasButtons | TTreeWindow::twsEditLabels);
    #if defined(BI_PLAT_WIN32)
        style = TTreeWindow::TStyle(style | TTreeWindow::twsLinesAtRoot);
	#endif
    SetStyle(style);
    */

	uint32 ui32Style = GetStyle() ;
  ui32Style |= TTreeWindow::twsHasLines | TTreeWindow::twsHasButtons | TTreeWindow::twsEditLabels ;
#if defined(BI_PLAT_WIN32)
	ui32Style |= TTreeWindow::twsLinesAtRoot ;
#endif
	SetStyle(ui32Style) ;
}
catch (...)
{
	erreur("Exception (NSTreeWindow ctor).", standardError, 0);
}
}

//----------------------------------------------------------------------//			Constructeur
//----------------------------------------------------------------------
NSTreeWindow::NSTreeWindow(TWindow* parent, NSContexte* pCtx, int resourceId,
                           TModule* module)
             :TTreeWindow(parent, resourceId, module), NSRoot(pCtx)
{
try
{
  bIniting            = true ;
  bLoosingFocus       = false ;
  Aparent             = parent ;
  ReadOnly            = false ;
  pControle           = 0 ;
  pEditDico           = 0 ;

  bDirty              = false ;
  AfficheCopieCollee  = true ;
  bLanceEdit          = false ;
  bPaint              = false ;
  bEditionDico        = false ;
  bCurseurTexte       = false ;
  skinName            = string("treeWindow") ;

  if (pContexte->getUtilisateur())
    sLang = pContexte->getUtilisateur()->donneLang() ;
  else
    sLang = "" ;

  pNSEncyclo = new NSEncyclo(pContexte) ;
  DBIResult Resultat = pNSEncyclo->open() ;
  if (Resultat != DBIERR_NONE)
  {
    string sErrMsg = pContexte->getSuperviseur()->getText("treeViewErrors", "cannotOpenEncyclopedia") ;
    pContexte->getSuperviseur()->trace(&sErrMsg, 1, NSSuper::trError) ;
  	erreur(sErrMsg.c_str(), standardError, Resultat) ;
    delete pNSEncyclo ;
    pNSEncyclo = 0 ;
  }

  pNSCV = new NSCV(pContexte) ;
  Resultat = pNSCV->open() ;
  if (Resultat != DBIERR_NONE)
  {
    string sErrMsg = pContexte->getSuperviseur()->getText("treeViewErrors", "cannotOpenUnitConversionFile") ;
    pContexte->getSuperviseur()->trace(&sErrMsg, 1, NSSuper::trError) ;
  	erreur(sErrMsg.c_str(), standardError, Resultat) ;
    delete pNSCV ;
    pNSCV = 0 ;
  }

  pHitTestInfo = new TTwHitTestInfo ;
  // HINSTANCE Hinstance = pNSDLLModule->GetInstance();
  // HINSTANCE Hinstance1 = *GetApplication();
  pBBitemNSTreeWindow = 0 ;
  Images = 0 ;
  pChampEdition = 0 ;
  pPositionDragAndDrop = 0 ;
  pChampDate = 0 ;
  bDispatcherPatpatho = true ;
  ModifierTexteLibre  = false ;
  pNodeArray = new NSTreeNodeArray() ;

  /*
  TStyle style = GetStyle();
  style = TTreeWindow::TStyle(style | TTreeWindow::twsHasLines | TTreeWindow::twsHasButtons | TTreeWindow::twsEditLabels);
  #if defined(BI_PLAT_WIN32)
    style = TTreeWindow::TStyle(style | TTreeWindow::twsLinesAtRoot);
#endif
  SetStyle(style);
  */

  uint32 ui32Style = GetStyle() ;
  ui32Style |= TTreeWindow::twsHasLines | TTreeWindow::twsHasButtons | TTreeWindow::twsEditLabels ;
  #if defined(BI_PLAT_WIN32)
      ui32Style |= TTreeWindow::twsLinesAtRoot ;
#endif
  SetStyle(ui32Style) ;
}
catch (...)
{
	erreur("Exception (NSTreeWindow ctor).", standardError, 0);
}
}

//----------------------------------------------------------------------
//			Destructeur
//----------------------------------------------------------------------
NSTreeWindow::~NSTreeWindow()
{
	if (pControle)
 	{
 		delete pControle ;
    pControle = 0 ;
 	}
 	if (pNodeArray)
 	{
 		delete pNodeArray ;
    pNodeArray = 0 ;
 	}
  if (pHitTestInfo)
  {
    delete pHitTestInfo ;
    pHitTestInfo = 0 ;
  }
  if (Images)
  {
    delete Images ;
    Images = 0 ;
  }
  if (pChampEdition)
  {
    delete pChampEdition ;
    pChampEdition = 0 ;
  }
  if (pChampDate)
  {
    delete pChampDate;
    pChampDate = 0;
  }
  if (pEditDico)
  {
    delete pEditDico ;
    pEditDico = 0 ;
  }
  if (NULL != pNSEncyclo)
    pNSEncyclo->close() ;
  if (NULL != pNSCV)
  {
    pNSCV->close() ;
    delete pNSCV ;
  }

  if (NULL != pPositionDragAndDrop)
    delete pPositionDragAndDrop ;
  if (NULL != pNSEncyclo)
    delete pNSEncyclo ;
}

//---------------------------------------------------------------------------
//  Description:	Constructeur copie
//---------------------------------------------------------------------------
NSTreeWindow::NSTreeWindow(NSTreeWindow& src)
             :TTreeWindow((TWindow *)src.GetParent(), src.GetId(), src.GetModule()),
              NSRoot(src.pContexte)
{
	bIniting             = true ;
  bLoosingFocus        = false ;

  if (NULL != src.pNodeArray)
    pNodeArray         = new NSTreeNodeArray(*(src.pNodeArray)) ;
  else
    pNodeArray         = 0 ;

  pControle            = src.pControle ;
  bDirty               = src.bDirty ;
  pEditDico            = src.pEditDico ;
  pNSTreeNodeEnCours   = src.pNSTreeNodeEnCours ;
  pBBitemNSTreeWindow  = src.pBBitemNSTreeWindow ;
  pChampEdition        = src.pChampEdition ;
  pChampDate           = src.pChampDate ;
  bDispatcherPatpatho  = src.bDispatcherPatpatho ;
  ModifierTexteLibre	 = src.ModifierTexteLibre ;
  pPositionDragAndDrop = src.pPositionDragAndDrop ;
  AfficheCopieCollee   = src.AfficheCopieCollee ;
  bLanceEdit           = src.bLanceEdit ;
  bPaint               = src.bPaint ;
  // to change
  pNSCV                = src.pNSCV ;
  sLang                = src.sLang ;
  skinName             = src.skinName ;
}

//---------------------------------------------------------------------------
//  Description:	Surcharge de l'op�rateur d'affectation
//---------------------------------------------------------------------------
NSTreeWindow&
NSTreeWindow::operator = (NSTreeWindow src)
{
	if (this == &src)
		return *this ;

	pNodeArray  		     = src.pNodeArray ;
  pContexte  			     = src.pContexte ;
  bDirty				       = src.bDirty ;
  pControle  			     = src.pControle ;
  pEditDico  			     = src.pEditDico ;
  pChampEdition		     = src.pChampEdition ;
  pChampDate			     = src.pChampDate ;
  pNSTreeNodeEnCours 	 = src.pNSTreeNodeEnCours ;
  pBBitemNSTreeWindow  = src.pBBitemNSTreeWindow ;
  bDispatcherPatpatho  = src.bDispatcherPatpatho ;
  ModifierTexteLibre	 = src.ModifierTexteLibre ;
  pPositionDragAndDrop = src.pPositionDragAndDrop ;
  AfficheCopieCollee   = src.AfficheCopieCollee ;
  bLanceEdit 			     = src.bLanceEdit ;
  bPaint				       = src.bPaint ;
  pNSCV				         = src.pNSCV ;
  sLang                = src.sLang ;
  skinName             = src.skinName ;

  return *this ;
}

//---------------------------------------------------------------------------
// SetupWindow
//---------------------------------------------------------------------------
void
NSTreeWindow::SetupWindow()
{
try
{
	bIniting = true ;

	TTreeWindow::SetupWindow() ;

	skinSwitchOn(skinName) ;

	Images = new TImageList(NS_CLASSLIB::TSize(16, 16), ILC_COLOR4, 15, 5);  Images->Add(OWL::TBitmap(*pNSDLLModule, IDB_0PLUS));
  Images->Add(OWL::TBitmap(*pNSDLLModule, IDB_1PLUS));
  Images->Add(OWL::TBitmap(*pNSDLLModule, IDB_2PLUS));
  Images->Add(OWL::TBitmap(*pNSDLLModule, IDB_3PLUS));
  Images->Add(OWL::TBitmap(*pNSDLLModule, IDB_4PLUS));
  Images->Add(OWL::TBitmap(*pNSDLLModule, IDB_TEXTELIBRE));
  Images->Add(OWL::TBitmap(*pNSDLLModule, IDB_PROP));
  SetImageList(TTreeWindow::Normal, *Images);
    //    // Pointeur vers le g�n�rateur - Langage generator's pointer
    //
    /* if (!(pContexte->getDico()->pGenerateur))
        TDialog::SetupWindow();
    NSGenerateur* pGene = pContexte->getDico()->pGenerateur;*/

	//
  //afficher les fils de GCONS1 (BBFilsItem lanceur de la consultation)
  //
  if ((NULL == pBBitemNSTreeWindow) || (pBBitemNSTreeWindow->aBBItemFils.empty()))
  {
  	bIniting = false ;
    return ;
  }

  BBFilsItem* GCONS1 = 0 ;
  if ((NULL != pControle) && (NULL != pControle->getTransfert()) &&
      (NULL != pControle->getTransfert()->pBBFilsItem))
		GCONS1 = pControle->getTransfert()->pBBFilsItem ;
	else
  	GCONS1 = *(pBBitemNSTreeWindow->aBBItemFils.begin()) ;

  if ((NULL == GCONS1->getPatPatho()) || (GCONS1->getPatPatho()->empty()))
  {
  	bIniting = false ;
    return ;
  }
  // NSPatPathoArray* ContenuPatpatho = *(GCONS1->getPatPatho()->begin());

  TTreeNode root = GetRoot() ;
  //
  // Prendre les fis de GCONS1  si la patpatho est vide
  //
  if ((NULL == pBBitemNSTreeWindow->pPPTEnCours) ||
      (false == pBBitemNSTreeWindow->pPPTEnCours->empty()))
  {
  	bIniting = false ;
		return ;
	}

	int compteur = NODES_LIN_BASE ;

  BBItem* pBBitem = *(GCONS1->VectorFils.begin()) ;
  BBiter  fils = pBBitem->aBBItemFils.begin() ;
  for (; fils != pBBitem->aBBItemFils.end(); fils++)
  {
    NSSuper* pSuper = pContexte->getSuperviseur() ;

    string sLibelleTrouve ;
    pSuper->getDico()->donneLibelle(sLang, &((*fils)->getItemLabel()), &sLibelleTrouve) ;

    TTreeNode* pAmorce = new TTreeNode(*this, TVI_FIRST);
    *pAmorce = root.AddChild(*pAmorce) ;
    NSTreeNode* pNewNSTreeNode = new NSTreeNode(*pAmorce, pContexte) ;
    // MAJ ligne et colonne
    pNewNSTreeNode->setLigne(compteur) ;
    pNewNSTreeNode->setColonne(NODES_COL_BASE) ;
    pNewNSTreeNode->pere = 0 ;
    pNewNSTreeNode->FrerePilote = 0 ;
    pNewNSTreeNode->SetLexique((*fils)->getItemLabel()) ;
    pNewNSTreeNode->SetNoeud((*fils)->getItemTransfertMsg()->GetNoeud()) ;
    pNewNSTreeNode->sLabel    = sLibelleTrouve ;
    pNewNSTreeNode->SetText(pNewNSTreeNode->sLabel.c_str(), true) ;
    pNewNSTreeNode->pControle = 0 ;
    pNewNSTreeNode->estPropose = true ;
    pNewNSTreeNode->SetImageIndex(6) ;
    pNewNSTreeNode->SetSelectedImageIndex(6, true) ;
    pNodeArray->push_back(pNewNSTreeNode) ;

    // Libell�
    string sChemin ;
    pNewNSTreeNode->formerChemin(&sChemin) ;
    NSCutPaste CutPaste(pContexte) ;
    pNewNSTreeNode->formerPatPatho(&CutPaste) ;
    GlobalDkd Dcode(pContexte, sLang, sChemin, CutPaste.pPatPatho) ;
    Dcode.decodeNoeud(sChemin) ;
    pNewNSTreeNode->sLabel = *(Dcode.sDcodeur()) ;

    // pAmorce->SelectItem(TVGN_CARET) ;
    // Valider() ;

    compteur++ ;
    Update() ;
    delete pAmorce ;
  }
//*******************************************************************
  //
  // Validation des noeuds de la colonne 0
  //
  TTreeNode firstNode = GetFirstVisible() ;
  if (firstNode != NULL)
  {
    // Puisque les �l�ments se d�s�lectionnent au fur et � mesure
    // qu'on descend, il faut d'abord valider les �l�ments racines
    // du haut en bas, puis ouvrir leurs fils du bas en haut
    //
    firstNode.SelectItem(TVGN_CARET) ;
    Valider() ;

    TTreeNode nextNode = firstNode.GetNextItem(TVGN_NEXT) ;
    while (nextNode != NULL)
    {
      nextNode.SelectItem(TVGN_CARET) ;
      Valider() ;

      nextNode = nextNode.GetNextItem(TVGN_NEXT) ;
    }

    nextNode = firstNode.GetNextItem(TVGN_NEXT) ;
    TTreeNode lastNode(nextNode) ;
    while (nextNode != NULL)
    {
      lastNode = nextNode ;
      nextNode = nextNode.GetNextItem(TVGN_NEXT) ;
    }

    nextNode = lastNode ;
    while (nextNode != NULL)
    {
      nextNode.SelectItem(TVGN_CARET) ;
      Valider(true) ;

      nextNode = nextNode.GetNextItem(TVGN_PREVIOUS) ;
    }
  }

  // Current algorithm push them in a sorted way already
  // It's cleaner to explicitly do it anyway
  //
  sort(pNodeArray->begin(), pNodeArray->end(), sortTreenodes) ;

//****************************************************************/
}
catch (...)
{
	erreur("Exception (NSTreeWindow::SetupWindow).", standardError, 0) ;
}
  bIniting = false ;
}


void
NSTreeWindow::skinSwitchOn(string sSkinName)
{
  // bool bSkinable = false ;

  nsSkin* pSkin = pContexte->getSkins()->donneSkin(sSkinName) ;
  if (pSkin)
  {
    ClassLib::TColor* pBackColor        = pSkin->getBackColor() ;
    // ClassLib::TColor* pBackTextColor    = pSkin->getFontBackColor() ;
    // ClassLib::TColor* pTextColor        = pSkin->getFontColor() ;

    if (pBackColor)
    {
      // bSkinable = true ;
      SetBkgndColor(*pBackColor) ;
    }
  }

    /******************************
    if (!bSkinable)
    {
        SetBkgndColor(0x00fff0f0) ; // 0x00bbggrr
    }
    *******************************/

  Invalidate() ;
}

void
NSTreeWindow::skinSwitchOff(string sSkinName)
{
  bool bSkinable = false ;

  nsSkin* pSkin = pContexte->getSkins()->donneSkin(sSkinName) ;
  if (pSkin)
  {
    ClassLib::TColor* pBackColor        = pSkin->getBackColor() ;
    // ClassLib::TColor* pBackTextColor    = pSkin->getFontBackColor() ;
    // ClassLib::TColor* pTextColor        = pSkin->getFontColor() ;

    if (pBackColor)
    {
      bSkinable = true ;
      SetBkgndColor(*pBackColor) ;
    }
  }

  if (!bSkinable)
    SetBkgndColor(0x00ffffff) ; // 0x00bbggrr

  Invalidate() ;
}

//-----------------------------------------------------------------
//lib�rer le BBItem lanceur de la consultation
//-----------------------------------------------------------------
void
NSTreeWindow::LibereBBitemLanceur()
{
  if (pBBitemNSTreeWindow)
  {
    delete pBBitemNSTreeWindow ;
    pBBitemNSTreeWindow = 0 ;
  }
}

//----------------------------------------------------------------
//former la patpatho globale
//----------------------------------------------------------------
void
NSTreeWindow::okFermerDialogue()
{
	//false pour ne pas tuer pTransfert li� � pBBitemNSTreeWindow
	pBBitemNSTreeWindow->okFermerDialogue(true, false) ;
}

//----------------------------------------------------------------
//vider l'array des tree nodes du controle TreeWindow
//----------------------------------------------------------------
void
NSTreeWindow::SupprimerTousNoeuds()
{
  iterNSTreeNode iter;

  if (false == pNodeArray->empty())
    for (iter = pNodeArray->begin() ; pNodeArray->end() != iter ; )
      SupprimerNoeud(*iter) ;
}

//-----------------------------------------------------------------
//
//extraire la patpatho de la consultation : c'est la patpatho
//BBIFilsItem lanceur de la consultation et la donner au pBigBoss
//
//-----------------------------------------------------------------
void
NSTreeWindow::EnregistrePatPatho(NSSmallBrother* pBigBoss)
{
  NSPatPathoArray* pPPT = pBigBoss->getPatPatho() ;
  BBFilsItem* pBBFilsLanceur = *(pBBitemNSTreeWindow->aBBItemFils.begin()) ;
  NSFatheredPatPathoArray* pFatheredElement = *(pBBFilsLanceur->getPatPatho()->begin()) ;
  *pPPT = *(pFatheredElement->getPatPatho()) ;
}

//----------------------------------------------------------------------------
// a partir d'une ligne et d'une colonne d'un NStreeNode , on lui trouve son p�re
//----------------------------------------------------------------------------
NSTreeNode*
NSTreeWindow::TrouverPere(int LigneFils, int ColonneFils)
{
  if (pNodeArray->empty())
    return 0 ;

  iterNSTreeNode iter = pNodeArray->begin() ;
 	iterNSTreeNode pere = pNodeArray->end() ;
 	iterNSTreeNode jter = pNodeArray->begin() ;

	// On cherche le premier NStreeNode dont la ligne est < � LigneFils
  // et la colonne est = � (ColonneFils - 1)
  //
  bool trouve = false ;

 	for (iter = pNodeArray->begin(); (pNodeArray->end() != iter) && (!trouve) ; iter++) 	{
    if (((*iter)->getLigne() < LigneFils) &&
        ((*iter)->getColonne() == (ColonneFils - 1)))
    {
      trouve = true ;
      pere = iter ;
    }
  }

  // Si trouv�
  if (pNodeArray->end() != pere)
  {
    // Chercher �ventuellement un autre p�re dont la ligne est < � celle
    // du premier p�re trouv�
    jter = pere ;
    jter++ ;
    while (jter != pNodeArray->end())
    {
      if (((*jter)->getLigne() < LigneFils) &&
                ((*jter)->getColonne() == (ColonneFils - 1)))
        pere = jter ;
      jter++ ;
    }
  }

  if (pNodeArray->end() == pere)
    return NULL ;

  if ((*pere)->FrerePilote)
    return((*pere)->FrerePilote) ;

  return(*pere) ;
}

//-----------------------------------------------------------------------
//cr�er un NSTReeNode en lui attribuant une ligne, une colonne et son p�re
// s'il existe sinon 0 , son identit� , son label, son code texte libre
//-----------------------------------------------------------------------
void
NSTreeWindow::CreerNSTreeNode(NSTreeNode* pNewNSTreeNode, int ligne, int colonne, string sIdentite,
				                     string sLabel, string sCodeTexteLibre)
{
  if (NULL == pNewNSTreeNode)
    return ;

  pNewNSTreeNode->pControle = 0 ;
  pNewNSTreeNode->setLigne(ligne) ;
  pNewNSTreeNode->setColonne(colonne) ;
  pNewNSTreeNode->SetLexique(sIdentite) ;
  pNewNSTreeNode->code = sCodeTexteLibre ;
  pNewNSTreeNode->sLabel = sLabel ;

  pNodeArray->push_back(pNewNSTreeNode) ;
  sort(pNodeArray->begin(), pNodeArray->end(), sortTreenodes) ;

  MiseAjourNSTreeNode(pNewNSTreeNode) ;
}

//-----------------------------------------------------------------------
//dispatcher  ContenuPatpatho qui contient le contenu total de la patpatho :
//Si pNSTreeNodeLanceur est nul, c'est le root qui affiche ContenuPatpatho
//		sinon si sHowToInsert == "AVANTFRERE"
//          	pNSTreeNodeLanceur cr�e le pathos de colonne 0 en tant que fr�res
//				si sHowToInsert == "AVANTFILS"
//          	pNSTreeNodeLanceur cr�e le pathos de colonne 0 en tant que fils directs
//sExpand 	si chaque p�re expand ses fils ou non, par d�faut = ""
//-----------------------------------------------------------------------
void
NSTreeWindow::DispatcherPatPatho(NSPatPathoArray* ContenuPatpatho,
                                 NSTreeNode* pNSTreeNodeLanceur,
                                 int* pDecalageLigneFils,
                                 string sHowToInsert, string sExpand,
                                 NSCutPastTLArray* pTLArray)
{
try
{
	if ((NULL == ContenuPatpatho) || (ContenuPatpatho->empty()))
	{
  	// Il ne faut pas tenter de dispatcher global par la suite, sinon on
    // obtient des duplication de noeuds lors du okFermerDialog
    //
    bDispatcherPatpatho = false ;
    return ;
	}

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	string sIdentitePere = "" ;  //code lexique  du NStreeNode p�re
  string sIdentiteFils = "" ;  //code lexique du NStreeNode fils
  string sNoeud        = "" ;  //code du noeud
  PatPathoIter iterTReeView = ContenuPatpatho->begin() ;

  int LigneFils = 0 ; //ligne pour les noeuds fils
  int lignePere = 1 ; //ligne pour les NStreeNodes p�re

  int ColonneFils = 0 ; //colonne pour les noeuds fils
  int colonnePere = 1 ; //colonne pour les NStreeNodes p�re

  //
  // D�calage en ligne et colonne des �l�ments de ContenuPatpatho lorsqu'ils
  // sont int�gr�s dans la treeWindow
  //
  int decalageLanceurColonne = 0 ;
  int decalageLanceurLigne   = 0 ;
  if (pNSTreeNodeLanceur)
  {
  	int ligneMax, colonneMax ;

    // On ins�re avant les fictifs, d'o� le true
    GetMaxCoordonnees(pNSTreeNodeLanceur, &ligneMax, &colonneMax, true) ;

    // d�calage des colonnes
    if 		(sHowToInsert == "AVANTFRERE")
    	decalageLanceurColonne = pNSTreeNodeLanceur->getColonne() ;
    else if (sHowToInsert == "AVANTFILS")
    	decalageLanceurColonne = pNSTreeNodeLanceur->getColonne() + 1 ;
    else
    	decalageLanceurColonne = pNSTreeNodeLanceur->getColonne() + 1 ;

    //d�calage des lignes
    if 		(sHowToInsert == "AVANTFRERE")
    	decalageLanceurLigne = ligneMax + 1 ;
    else if (sHowToInsert == "AVANTFILS")    	decalageLanceurLigne = pNSTreeNodeLanceur->getLigne() + 1 ;
    else
    	decalageLanceurLigne = ligneMax + 1 ;
	}

  string pLibelleTrouve = string("") ;
  string sLabel = string("") ;

  string sCodeTexteLibre = string(""), sTexteLibre = string("") ;
  int NbTexteLibre = 0 ;   //nb de fr�res fictifs qui vont supporter le texte libre
  bool texteRecupere ;
  //NSTlibre* pNSTlibre = new NSTlibre(pContexte);

  // When inserting several nodes, the reference node must be the previously
  // inserted node, or they will be inserted in reverse order
  //
  NSTreeNode* pNSTreeNodeReference = pNSTreeNodeLanceur ;

  //
  // On passe en revue toute la patpatho
  //
	while (iterTReeView != ContenuPatpatho->end())
	{
  	//
    // Si on est sur la colonne "0'
    //
    if ((*iterTReeView)->getColonne() == ORIGINE_PATH_PATHO)
    {
    	colonnePere = (*iterTReeView)->getColonne() + decalageLanceurColonne;
      lignePere   = (*iterTReeView)->getLigne()   + decalageLanceurLigne;
      // On tient compte du d�calage du aux textes libres multi-lignes      lignePere += NbTexteLibre;

      TTreeNode* pAmorce = NULL ;
      TTreeNode root   = GetRoot();

      if (((*iterTReeView)->getLexique() != "900001") &&
          ((*iterTReeView)->getLexique() != "900002"))
      	pAmorce = new TTreeNode(*this, TVI_FIRST) ;

      NSTreeNode* pNewNSTreeNode = 0 ;

      //
      // Si le dispatching se fait � partir d'un noeud, les �l�ments
      // de la colonne '0' sont cr��s comme fr�res de ce noeud si
      // sHowToInsert == "AVANTFRERE" ou comme fils de ce noeud si
      // sHowToInsert == "AVANTFILS"
      //
      if (pNSTreeNodeReference)
      {
      	if (sHowToInsert == "AVANTFRERE")// pNSTreeNodeReference cr�e son fr�re
      	{
        	NSTreeNode* pNSTreeFrereCreateur = 0 ;
          // pas de fr�res li�s : pNSTreeNodeLanceur cr�e son 1er fr�re
          if (pNSTreeNodeLanceur->VectFrereLie.empty())
          	pNSTreeFrereCreateur = pNSTreeNodeReference ;
          // sinon, le dernier �l�ment de VectFrereLie cr�e son fr�re
          else
          	// pNSTreeFrereCreateur = pNSTreeNodeReference->VectFrereLie.back() ;
            pNSTreeFrereCreateur = pNSTreeNodeLanceur->VectFrereLie.back() ;
          //
          // Cr�ation et insertion physique du noeud (TTreeNode)
          //
          if (pAmorce)
          {
          	*pAmorce = pNSTreeFrereCreateur->InsertItem(TTreeNode(*this, "")) ;
            //
            // Cr�ation du NSTreeNode � partir du TTreeNode
            //
            pNewNSTreeNode = new NSTreeNode(*pAmorce, pContexte) ;
          }
          else // constructeur d'un NSTreeNode "private"
          	pNewNSTreeNode = new NSTreeNode(*this, pContexte, "PRIVATE") ;
          //
          // R�f�rencement du p�re et de lui m�me dans l'array de fils
          // de son p�re
          //
          pNewNSTreeNode->pere = pNSTreeNodeReference->pere ;
          if (pNewNSTreeNode->pere)
          	(pNSTreeNodeReference->pere->VectFils).Referencer(pNewNSTreeNode) ;

          // The new node becomes the reference in order to create the next node
          //
          pNSTreeNodeReference = pNewNSTreeNode ;
        }
        else if (sHowToInsert == "AVANTFILS")//pNSTreeNodeLanceur cr�e son fils direct
        {
        	if (pAmorce)
          {
          	// Si le noeud lanceur n'a pas de fr�re li�s, il cr�e son fils
            if (pNSTreeNodeReference->VectFrereLie.empty()) //pas de fr�res li�s
            	*pAmorce = pNSTreeNodeReference->InsertChild(*pAmorce, TTreeNode::First) ;
            // sinon c'est le dernier fr�re li� qui le fait
            else
            {
            	NSTreeNode*	pNSTreeFrere = pNSTreeNodeReference->VectFrereLie.back() ; //d�rnier �l�ment de VectFrereLie cr�e son fr�re
              *pAmorce = pNSTreeFrere->InsertChild(*pAmorce, TTreeNode::First) ;
            }
            //
            // Cr�ation du NSTreeNode � partir du TTreeNode
            //
            pNewNSTreeNode = new NSTreeNode(*pAmorce, pContexte) ;
          }
          else
          	pNewNSTreeNode = new NSTreeNode(*this, pContexte, "PRIVATE") ;
          //
          // R�f�rencement du p�re et de lui m�me dans l'array de fils
          // de son p�re
          //
          pNewNSTreeNode->pere = pNSTreeNodeReference ;
          (pNSTreeNodeReference->VectFils).Referencer(pNewNSTreeNode) ;

          // The new node becomes the reference in order to create the next node
          // and the mode changes in order to create the next nodes as brothers
          // of the new node
          //
          pNSTreeNodeReference = pNewNSTreeNode ;
          sHowToInsert = "AVANTFRERE" ;
        }
        else //dernier fils de pNSTreeNodeLanceur
        {
        	NSTreeNode* pNSTreeNodeFrere = 0 ;

          //
          // On ins�re apr�s le dernier vrai fils
          //
          if (pNSTreeNodeLanceur->VectFils.empty())
          {
          	if (pAmorce)
            	*pAmorce = pNSTreeNodeLanceur->AddChild(*pAmorce) ;
          }
          else
          {
            iterNSTreeNode filsIt = pNSTreeNodeLanceur->VectFils.begin();
            iterNSTreeNode vraiFilsIt;
            for (; filsIt != pNSTreeNodeLanceur->VectFils.end(); filsIt++)
            {
            	if (((*filsIt)->estPropose) || ((*filsIt)->estFictif()))
              	break ;
              else
              	vraiFilsIt = filsIt ;
            }
            if      (filsIt == pNSTreeNodeLanceur->VectFils.end())
            {
            	if (pAmorce)
              	*pAmorce = pNSTreeNodeLanceur->AddChild(*pAmorce) ;
            }
            else if (filsIt == pNSTreeNodeLanceur->VectFils.begin())
            {
            	if (pAmorce)
              	*pAmorce = pNSTreeNodeLanceur->InsertChild(*pAmorce, TTreeNode::First) ;
              pNSTreeNodeFrere = *filsIt ;
            }
            else
            {
            	if (pAmorce)
              	*pAmorce = (*vraiFilsIt)->InsertItem(*pAmorce) ;
              pNSTreeNodeFrere = *vraiFilsIt ;
            }
          }

          if (pAmorce)
          	pNewNSTreeNode = new NSTreeNode(*pAmorce, pContexte) ;
          else
          	pNewNSTreeNode = new NSTreeNode(*this, pContexte, "PRIVATE") ;

          pNewNSTreeNode->pere = pNSTreeNodeLanceur ;
          (pNSTreeNodeLanceur->VectFils).Referencer(pNewNSTreeNode, pNSTreeNodeFrere) ;
        }
      }
      //
      // Dispatching � partir de la racine (root)
      //
      else
      {
      	if (pAmorce)
        {
        	if (sHowToInsert == "Debut")
          	*pAmorce = root.InsertChild(*pAmorce, TTreeNode::First) ;
          else
          	*pAmorce = root.AddChild(*pAmorce) ;
          pNewNSTreeNode = new NSTreeNode(*pAmorce, pContexte) ;
        }
        else
        	pNewNSTreeNode = new NSTreeNode(*this, pContexte, "PRIVATE") ;
        pNewNSTreeNode->pere = 0 ;
      }

      pNewNSTreeNode->FrerePilote = 0 ;

      //
      // Initialisation des champs du noeud � partir de l'�l�ment
      // cr�ateur de la patpatho
      //

      // Etiquette du BBFilsItem ou �????? pour texte libre
      sIdentitePere   = (*iterTReeView)->getLexique() ;
      sCodeTexteLibre = (*iterTReeView)->getComplement() ;      pNewNSTreeNode->SetNoeud((*iterTReeView)->getNodeID()) ;
      pNewNSTreeNode->SetUnit((*iterTReeView)->getUnit()) ;
      pNewNSTreeNode->SetInteret((*iterTReeView)->getInteret()) ;
      pNewNSTreeNode->SetPluriel((*iterTReeView)->getPluriel()) ;
      pNewNSTreeNode->SetCertitude((*iterTReeView)->getCertitude()) ;
      pNewNSTreeNode->SetVisible((*iterTReeView)->getVisible()) ;
      pNewNSTreeNode->SetRights((*iterTReeView)->getNodeRight()) ;

      pNewNSTreeNode->sTexteGlobal = (*iterTReeView)->getTexteLibre() ;

      // Gestion de la NSCutPastTLArray
      // En cas de copier coller avec texte libre
      //
      if ((sIdentitePere == string("�?????")) && pTLArray)
      {
      	if ((!(pTLArray->empty())) && (sCodeTexteLibre != string("")))
        {
        	CutPastTLIter i ;
          for (i = pTLArray->begin();
                                (i != pTLArray->end()) &&
                                    (sCodeTexteLibre != (*i)->sIndice); i++) ;
          if (i != pTLArray->end())
          {
          	sCodeTexteLibre = "" ;
            sTexteLibre     = (*i)->sTexte ;
          }
        }
      }
      else
      {
      	pNewNSTreeNode->sContenuTransfert = (*iterTReeView)->getComplement() ;
        sTexteLibre = pNewNSTreeNode->sTexteGlobal ;
      }

      // Instancier pNewNSTreeNode
      bool bTexte = pNewNSTreeNode->MettreAjourLabel(/*pNSTlibre*/ 0, &texteRecupere,
         						&NbTexteLibre, lignePere, colonnePere, sTexteLibre,
                                sCodeTexteLibre, sIdentitePere, this, sLang) ;
      if (!bTexte)
      {
        string sErrMsg = pContexte->getSuperviseur()->getText("treeViewErrors", "errorCreatingANewNode") ;
        pContexte->getSuperviseur()->trace(&sErrMsg, 1, NSSuper::trError) ;
        erreur(sErrMsg.c_str(), standardError, 0) ;
        return ;
      }
      // Pas de texte libre
      if (!(sIdentitePere == string("�?????")))
      {
      	string sChemin, sCheminLocal ;
        pNewNSTreeNode->formerChemin(&sChemin) ;
        pNewNSTreeNode->formerCheminLocal(&sCheminLocal) ;
        NSCutPaste CP(pContexte) ;
        pNewNSTreeNode->formerPatPatho(&CP) ;
        GlobalDkd Dcode(pContexte, sLang, sChemin, CP.pPatPatho) ;
        Dcode.decodeNoeud(sCheminLocal) ;
        pNewNSTreeNode->sLabel = *(Dcode.sDcodeur()) ;

        pNewNSTreeNode->SetText(pNewNSTreeNode->sLabel.c_str(), true) ;
        pNewNSTreeNode->InstancieUrl(pNSEncyclo) ;//Encyclop�die.db
      }

      if (pAmorce)
      	delete pAmorce ;
    }
    //****************************************************************
    // On n'est pas sur la colonne 0, on dispatche donc un fils
    //****************************************************************
    else
    //***************************  fils  *****************************
    {
    	ColonneFils = (*iterTReeView)->getColonne() + decalageLanceurColonne ;
      LigneFils   = (*iterTReeView)->getLigne()   + decalageLanceurLigne ;

      // On tient compte du d�calage du aux textes libres multi-lignes
      LigneFils += NbTexteLibre ;

      string sComplement = "" ;
      string sLabel = "" ;
      sIdentiteFils = (*iterTReeView)->getLexique() ;
      sNoeud        = (*iterTReeView)->getNodeID() ;

      string sSensFils = (*iterTReeView)->getLexiqueSens(pContexte) ;

      //
      // cas particulier : si sEtiquettePatpatho contient �C prendre
      // les donn�es dans l'�l�ment suivant de la patpatho qui, lui
      // (controle fictif) contient les vraies donn�es � afficher.
      // Exemple en Echo : Chimioth�rapie
      // Dans ce cas afficher l'�l�ment suivant
      PatPathoIter iterFictif  = ContenuPatpatho->begin() ;
      if ((sIdentiteFils.find(string("�C;")) != NPOS) ||
          (sIdentiteFils.find(string("/�C;")) != NPOS))
      {
        if (string("") == (*iterTReeView)->getTexteLibre())
        {
      	  iterFictif = iterTReeView ;
          iterFictif++ ;
          if ((ContenuPatpatho->end() != iterFictif) &&
              ((*iterFictif)->getColonne() == (*iterTReeView)->getColonne() + 1))
          {
        	  iterTReeView++ ;
            sIdentiteFils = (*iterTReeView)->getLexique() ;
          }
        }
      }

      //
      // Ajout du noeud comme fils de pNewNSTreeNodePere
      //
      TTreeNode* pAmorce = NULL ;
      NSTreeNode* pNewNSTreeNodePere ;
      NSTreeNode* pNewNSTreeNodeFils ;

      if ((sIdentiteFils != "900001") && (sIdentiteFils != "900002"))
      {
      	pAmorce = new TTreeNode(*this, "") ;
        // ATTENTION : l'�chelle pour les patpatho commence � 0 alors
        // que pour les NSTreeNodes elle commence � 1
        pNewNSTreeNodePere =  TrouverPere(LigneFils, ColonneFils ) ;
        if (NULL != pNewNSTreeNodePere)
        {
          // S'il n'existe pas de fr�res li�s, c'est le p�re qui cr�e son 1er fils
          if (pNewNSTreeNodePere->VectFrereLie.empty())
        	  *pAmorce = pNewNSTreeNodePere->AddChild(*pAmorce/*, TTreeNode::First*/) ;
          // Sinon, le dernier �l�ment de VectFrereLie cr�e son fr�re
          else
          {
        	  NSTreeNode*	pNSTreeFrere = pNewNSTreeNodePere->VectFrereLie.back() ;
            *pAmorce = pNSTreeFrere->InsertChild(*pAmorce, TTreeNode::First) ;
          }
        }
        //
        // Cr�ation du NSTreeNode � partir du TTreeNode
        //
        pNewNSTreeNodeFils = new NSTreeNode(*pAmorce, pContexte) ;
      }
      else
      {
      	pNewNSTreeNodePere = TrouverPere(LigneFils, ColonneFils ) ;
        pNewNSTreeNodeFils = new NSTreeNode(*this, pContexte, "PRIVATE") ;
      }
      //
      // R�f�rencement du p�re et de lui m�me dans l'array de fils
      // de son p�re
      //
      pNewNSTreeNodeFils->pere = pNewNSTreeNodePere ;
      if (NULL != pNewNSTreeNodePere)
        (pNewNSTreeNodePere->VectFils).Referencer(pNewNSTreeNodeFils) ;
      //
      // Prise en compte du compl�ment
      //
      // Texte libre
      //
      if ((string("�?????") == sIdentiteFils) ||
          (string("�C;") == sSensFils)) //texte libre
      {
      	sCodeTexteLibre = (*iterTReeView)->getComplement() ;
        pNewNSTreeNodeFils->sContenuTransfert = sCodeTexteLibre ;
        // Gestion de la NSCutPastTLArray
        if ((string("�?????") == sIdentiteFils) && (NULL != pTLArray))
        {
        	if ((!(pTLArray->empty())) && (sCodeTexteLibre != ""))
          {
          	CutPastTLIter i ;
            for (i = pTLArray->begin();
                                (pTLArray->end() != i) &&
                                    (sCodeTexteLibre != (*i)->sIndice); i++) ;
            if (pTLArray->end() != i)
            {
              sCodeTexteLibre = "" ;
              sTexteLibre     = (*i)->sTexte ;
            }
          }
        }
        else if (string("�C;") == sSensFils)
          sTexteLibre = (*iterTReeView)->getTexteLibre() ;
      }
      //
      // Pas de texte libre
      //
      else
      {
      	sCodeTexteLibre = "" ;
        pNewNSTreeNodeFils->sContenuTransfert = (*iterTReeView)->getComplement() ;
        pNewNSTreeNodeFils->InstancieUrl(pNSEncyclo) ;//Encyclop�die.db
        //
        // On regarde la cat�gorie du p�re
        //
        //date et heure, affiche la date sous forme JJ/MM/AAAA et
        //l'heure sous forme HH:MM
        //
        if (pSuper->getDico()->CodeCategorie(pNewNSTreeNodeFils->pere->getEtiquette()) == "K")
				{
        	string _sUnite = (*iterTReeView)->getUnit() ;
          if ((_sUnite == "2DA011") || (_sUnite == "2HE011"))
          	pNewNSTreeNodeFils->DateHeure = true ;
        }
        // valeur chiffr�e
        else if (pSuper->getDico()->CodeCategorie(pNewNSTreeNodeFils->pere->getEtiquette()) == "V")
        {
        	//si "CALCUL DYNAMIQUE" recalculer sComplement � partir de convert.db
          if ((sIdentiteFils.find("�ND")  != NPOS) ||
              (sIdentiteFils.find("/�ND") != NPOS))
          {
          	pNewNSTreeNodeFils->bRecalcul = true ;
            string sUniteConvert, sMethodeCalcul = "";
            if (pNSCV)
            	pNSCV->CalculValeur(pNewNSTreeNodeFils->pere->getEtiquette(), &sComplement,
			                         		&sUniteConvert, &sMethodeCalcul, ContenuPatpatho) ;
            if (sMethodeCalcul != "")
            	pNewNSTreeNodeFils->pere->SetComplement(sMethodeCalcul) ;
          }
          pNewNSTreeNodeFils->CreateurChampEdit = true ; //champ �dit : poids , taille,...
        }
      }
      //
      // Initialisation des autres variables
      //
      pNewNSTreeNodeFils->SetNoeud(sNoeud) ;
      pNewNSTreeNodeFils->SetUnit((*iterTReeView)->getUnit()) ;
      pNewNSTreeNodeFils->SetInteret((*iterTReeView)->getInteret()) ;
      pNewNSTreeNodeFils->SetPluriel((*iterTReeView)->getPluriel()) ;
      pNewNSTreeNodeFils->SetCertitude((*iterTReeView)->getCertitude()) ;
      pNewNSTreeNodeFils->SetVisible((*iterTReeView)->getVisible()) ;
      pNewNSTreeNodeFils->SetRights((*iterTReeView)->getNodeRight()) ;

      pNewNSTreeNodeFils->sTexteGlobal = (*iterTReeView)->getTexteLibre() ;

      //
      // Mise en place du noeud
      //
      sTexteLibre = pNewNSTreeNodeFils->sTexteGlobal ;
      bool bTexte = pNewNSTreeNodeFils->MettreAjourLabel(/*pNSTlibre*/ 0,
              &texteRecupere, &NbTexteLibre, LigneFils, ColonneFils,
                   sTexteLibre, sCodeTexteLibre, sIdentiteFils, this, sLang) ;
      if (!bTexte)
      {
        string sErrMsg = pContexte->getSuperviseur()->getText("treeViewErrors", "errorCreatingANewNode") ;
        pContexte->getSuperviseur()->trace(&sErrMsg, 1, NSSuper::trError) ;
        erreur(sErrMsg.c_str(), standardError, 0) ;
        return ;
      }

      if (sExpand == "EXPAND")
      	pNewNSTreeNodePere->ExpandTousNoeud() ;

      delete pAmorce ;
    }

    pLibelleTrouve  = string("") ;
    sLabel          = string("") ;
    sCodeTexteLibre = string("") ;
    sTexteLibre     = string("") ;
    sIdentitePere   = string("") ; //�tiquette du NStreeNode p�re
    sIdentiteFils   = string("") ; //�tiquette du NStreeNode fils

    if (pDecalageLigneFils)
      (*pDecalageLigneFils)++ ;
    // El�ment suivant
    if (iterTReeView != ContenuPatpatho->end())
      iterTReeView++ ;
  }
  bDispatcherPatpatho = false ; //on dispatche une seule fois la patpatho globale

  //
  // Pour chaque noeud , lui mettre � jour son affichage en tenant compte
  // de son champ visible
  //
  if (pNSTreeNodeLanceur)
  	pNSTreeNodeLanceur->InitialiseAffichage() ;
	else
  	AfficheLibelle() ;
}
catch (...)
{
	erreur("Exception (NSTreeWindow::DispatcherPatpatho).", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Function: 		NSTreeWindow::activeControle(int activation, Message* pMessage)
//
//  Reconstruction de la TreeView
//
//	 Arguments:		activation : BF_CHECKED , BF_UNCHECKED
//						message    : Contenu de la bo�te
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void
NSTreeWindow::activeControle(int /*activation*/, Message* /*pMessage*/)
{
	if (false == bDispatcherPatpatho)
  	return ;

  // patpatho du BBFilsItem qui a lanc� la treeview
  if ((pControle) && (pControle->getTransfert()) && (pControle->getTransfert()->pBBFilsItem))
  {
  	NSVectFatheredPatPathoArray* pPatpatho = pControle->getTransfert()->pBBFilsItem->getPatPatho() ;
    if (false == pPatpatho->empty())
    {
      NSFatheredPatPathoArray* pFatheredElement = *(pPatpatho->begin()) ;
    	NSPatPathoArray* ContenuPatpatho = pFatheredElement->getPatPatho() ;
      // Dispatcher la patpatho
      if (false == ContenuPatpatho->empty())
      	DispatcherPatPatho(ContenuPatpatho, 0, 0, "") ;
      else
      // Make certain that the patpatho will not be dispatched by another call to this function
        bDispatcherPatpatho = false ;
    }
  }

/*
  if (pNodeArray && pNodeArray->empty())
  {
  	SetFocus() ;
    Invalidate() ;
  }
*/
}

//----------------------------------------------------------------------
//----------------------------------------------------------------------
//	retourner un NSTReeNode ayant le m�me hitem que le TTreeNode s�lectionn�
//----------------------------------------------------------------------
//----------------------------------------------------------------------
NSTreeNode*
NSTreeWindow::GetNSTreeNode(TTreeNode* pTTreeNode)
{
  if ((NULL == pTTreeNode) || (pNodeArray->empty()))
    return NULL ;

  HTREEITEM TTitem, NSitem ;

  for (iterNSTreeNode i = pNodeArray->begin(); i != pNodeArray->end(); i++)
  {
    TTitem = pTTreeNode->operator HTREEITEM() ;
    NSitem = (*i)->operator HTREEITEM() ;
    if (TTitem == NSitem)
      return (*i) ;
  }
  return NULL ;
}

//----------------------------------------------------------------------//----------------------------------------------------------------------
//	retourner un NSTReeNode ayant le m�me hitem que le TTreeNode s�lectionn�
//----------------------------------------------------------------------
//----------------------------------------------------------------------
NSTreeNode*
NSTreeWindow::GetNSTreeNode(HTREEITEM TTitem)
{
  if (pNodeArray->empty())
    return NULL ;

  for (iterNSTreeNode i = pNodeArray->begin(); i != pNodeArray->end(); i++)
  {
    HTREEITEM NSitem = (*i)->operator HTREEITEM() ;
    if (TTitem == NSitem)
      return (*i) ;
  }
  return NULL ;
}

//------------------------------------------------------------------------//mise � jour d'un NSTreeNode
//------------------------------------------------------------------------
void
NSTreeWindow::MiseAjourNSTreeNode(NSTreeNode* pNSTreeNode)
{
  if ((NULL == pNSTreeNode) || (string("") == pNSTreeNode->getEtiquette()))
    return ;

try
{
  pNSTreeNode->pControle = new NSControle(pContexte, pBBitemNSTreeWindow , pNSTreeNode->getEtiquette(), "") ;
  pNSTreeNode->pControle->setControle(dynamic_cast<void*>(pNSTreeNode)) ;
  pNSTreeNode->pControle->setType(pNSTreeNode->donneType()) ;
  pNSTreeNode->pControle->setNSDialog(pBBitemNSTreeWindow->getDialog()) ;
  pNSTreeNode->pControle->setMUEView(pBBitemNSTreeWindow->getView()) ;
  pNSTreeNode->pContexte = pContexte ;

  // int colonne = pNSTreeNode->getColonne();
  int ligne = pNSTreeNode->getLigne() ;

  //retrouver pNSTreeNode dans pNodeArray
  iterNSTreeNode EnCours = pNodeArray->begin() ; // pNSTreeNode
  for (; (pNodeArray->end() != EnCours) && ((*EnCours) != pNSTreeNode); EnCours++) ;

  // Not found; leaving
  if (pNodeArray->end() == EnCours)
    return ;

  NSTreeNode* pNSTreePere = pNSTreeNode->pere ;
  if (pNSTreePere)
  {
    NSTreeNode* pNSTreePetitFrere = TrouverPetitFrere(pNSTreeNode, ligne) ;

    if (pNSTreePetitFrere)
      CreerBBItem(pNSTreeNode, pNSTreePetitFrere) ;
    else
      CreerBBItem(pNSTreeNode, 0) ;
  }
  else
  {
    //chercher le 1er NSTreeNode de colonne = 1 et apr�s pNSTreeNode
    NSTreeNode* pNSTreePetitFrere = TrouverPetitFrereFilsRoot(pNSTreeNode, ligne) ;
    if (pNSTreePetitFrere)
      CreerBBItem(pNSTreeNode, pNSTreePetitFrere) ;
    else
      CreerBBItem(pNSTreeNode, 0) ;
  }
  //
  // Il est important, apr�s connexion au BBitem, de mettre � jour
  // la structure de message qui lui est attach�e, sinon on risque
  // de perdre des donn�es lors d'un transfert Item -> Noeud
  //
  if ((pNSTreeNode->pControle->getTransfert()) &&
        	(pNSTreeNode->pControle->getTransfert()->pTransfertMessage))
  {
    int iActif ;
    pNSTreeNode->Transferer(tdGetData, &iActif,
                    pNSTreeNode->pControle->getTransfert()->pTransfertMessage) ;
  }
}
catch (...)
{
	erreur("Exception NSTreeWindow::MiseAjourNSTreeNode.", standardError, 0) ;
}
}

//------------------------------------------------------------------------
//remise � jour d'un NSTreeNode avec le nouveau code pStringCode
//------------------------------------------------------------------------
void
NSTreeWindow::ReMiseAjourNSTreeNode(NSTreeNode* pNSTreeNode, string sStringCode, string sComplement)
{
  if ((NULL == pNSTreeNode) || (NULL == pNSTreeNode->pControle))
    return ;
  //MAJ
  pNSTreeNode->pControle->setIdentite(sStringCode) ;
  pNSTreeNode->pControle->getTransfert()->pBBFilsItem->setItemLabel(sStringCode) ;
  pNSTreeNode->pControle->getTransfert()->pTransfertMessage->SetComplement(sComplement) ;
}

//---------------------------------------------------------------------------
//	cr�ation d'un BBItem rattach� au NSTreeNode
//---------------------------------------------------------------------------
void
NSTreeWindow::CreerBBItem(NSTreeNode* pNSTreeNode, NSTreeNode* pNSTreeNodePetitFrere)
{
	if (NULL == pNSTreeNode)
		return ;

	BBFilsItem* pFilsItemPere = 0 ; //le BBFilsItem rattach� au p�re de pNSTreeNode

	if (NULL == pNSTreeNode->pere)	{  	if ((NULL == pControle) || (NULL == pControle->getTransfert()))    	return ;		pFilsItemPere = pControle->getTransfert()->pBBFilsItem ;
    if (NULL == pFilsItemPere)
    	return ;

    // Colonne 0 :  Avant de cr�er un nouveau fils, il faut s'assurer qu'il
    //              n'existe pas un fils de m�me �tiquette
    // Column 0 :   Before the creation of a new son, let's check if it
    //              doesn't already have a son with the same label
    //
    if (!(pFilsItemPere->VectorFils.empty()))
    {
    	BBItem*     pPremItem = *(pFilsItemPere->VectorFils.begin()) ;
      BBFilsItem* pBonFils  = pPremItem->TrouverFilsAyantBonneEtiquette(pNSTreeNode->getEtiquette(), "") ;
      if ((NULL != pBonFils) && (0 == pBonFils->getItemTransfertData()->pControle))
      {
      	// Si on est ici, c'est que le m�canisme de cr�ation BBItem puis
        // BBFilsItem a d�j� �t� fait : il ne reste qu'� connecter
        // le contr�le au BBFilsItem
        // ne surtout pas faire pBonFils->CreerFilsManuel

        pBonFils->getItemTransfertData()->pControle = pNSTreeNode->pControle ;
        pNSTreeNode->pControle->setTransfert(pBonFils->getItemTransfertData()) ;

        return ;
      }
      else
      {
      	if (NULL != pNSTreeNodePetitFrere)
        {
        	pPremItem->CreerFilsManuel(pNSTreeNode->pControle, pNSTreeNodePetitFrere->pControle) ;
          return ;
        }
        else
        {
        	pPremItem->CreerFilsManuel(pNSTreeNode->pControle, 0) ;
          return ;
        }
      }
    }
  }
  else
  {
  	if ((NULL != pNSTreeNode->pere->pControle) && (NULL != pNSTreeNode->pere->pControle->getTransfert()))
    	pFilsItemPere = pNSTreeNode->pere->pControle->getTransfert()->pBBFilsItem ;
	}

  if (NULL == pFilsItemPere)
  {
    string sErr = string("Trying to create a son for a virtual node.") ;
    pContexte->getSuperviseur()->trace(&sErr, 1, NSSuper::trError) ;
    erreur(sErr.c_str(), standardError, 0) ;
    return ;
  }

	if (pNSTreeNodePetitFrere)
  	pFilsItemPere->CreerFilsManuel(pNSTreeNode->pControle, pNSTreeNodePetitFrere->pControle) ;
	else
		pFilsItemPere->CreerFilsManuel(pNSTreeNode->pControle, 0) ;
}

//-------------------------------------------------------------------------// 				Absence d'�l�ment lexique
//-------------------------------------------------------------------------
void
NSTreeWindow::Absence()
{
  TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNode)
    return ;
  SetDirty(true) ;
  pNSTreeNode->AbsenceLexique() ;
}

//-------------------------------------------------------------------------
// 				Pr�sence d'�l�ment lexique
//-------------------------------------------------------------------------
void
NSTreeWindow::Presence()
{
  TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNode)
    return ;
  SetDirty(true) ;
  pNSTreeNode->PresenceLexique() ;
}

//-------------------------------------------------------------------------// 		   Edition du noeud (p�res + fils) sous forme de fil guide
//-------------------------------------------------------------------------
void
NSTreeWindow::EditionFilGuide()
{
  TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNode)
    return ;
}

//-------------------------------------------------------------------------
// 				Pr�sence de l'�l�ment lexique dans Encyclop.db
//-------------------------------------------------------------------------
void
NSTreeWindow::Encyclop()
{
  TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNode)
    return ;
}

//-------------------------------------------------------------------------// 							Param�tres patpatho pour un noeud
//				les textes libres seront seulement concern�s par "inter�t"
//-------------------------------------------------------------------------
void
NSTreeWindow::Parametres()
{
	TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNode)
    return ;
  pNSTreeNode->RecupereParametre() ;
}

//-------------------------------------------------------------------------
// 					   Cr�ation d'une nouvelle pr�occupation
//-------------------------------------------------------------------------
void
NSTreeWindow::NewPreoccup()
{
	TTreeNode noeud = GetSelection() ;
	NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
	if (NULL == pNSTreeNode)
		return ;

	// Vraie pr�occupation ou traitement ?

	string sEtiquette = pNSTreeNode->getEtiquette() ;
	if (string("") == sEtiquette)
		return ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;
  NSToDoTask* pTask = new NSToDoTask ;

	if ((sEtiquette[0] == 'I') || (sEtiquette[0] == '_'))
	{
		pTask->sWhatToDo = "NewDrugFromNode" ;
		pTask->pPointer1 = (void*)this ;
		pTask->pPointer2 = (void*)pNSTreeNode ;
	}
	else
	{
		pTask->sWhatToDo = "NewPreoccupFromNode" ;
		pTask->pPointer1 = (void*)this ;
		pTask->pPointer2 = (void*)pNSTreeNode ;
	}

	pSuper->addToDo(pTask) ;
}

void
NSTreeWindow::ChangePreoccup(NSConcern* pConcern)
{
	TTreeNode noeud = GetSelection() ;
	NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
	if (NULL == pNSTreeNode)
		return ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;
	NSToDoTask* pTask = new NSToDoTask ;
	pTask->sWhatToDo = "ChangePreoccupFromNode" ;
	pTask->pPointer1 = (void*)this ;
	pTask->pPointer2 = (void*)pNSTreeNode ;
	pTask->sParam1   = pConcern->getNoeud() ;

	pSuper->addToDo(pTask) ;
}

/**
* 		   Cr�ation d'une nouvelle pr�occupation avec ses donn�es
*/
void
NSTreeWindow::NewPreoccupRC(NSPatPathoArray* pContenuPatpatho, string sArchetype)
{
	if ((!pContenuPatpatho) || (pContenuPatpatho->empty()))
		return ;

	string sRootLex = (*(pContenuPatpatho->begin()))->getLexique() ;

	NSCutPaste CutPaste(*(pContexte->getSuperviseur()->pBufCopie)) ;
	pContexte->getSuperviseur()->pBufCopie->vider() ;
	*(pContexte->getSuperviseur()->pBufCopie->pPatPatho) = *pContenuPatpatho ;

	//
	// Recherche du noeud "Assesment" pour y ajouter l'arbre
	//
	TTreeNode nextNode = GetFirstVisible() ;
	while (nextNode != NULL)
	{
		NSTreeNode* pNode = GetNSTreeNode(&nextNode) ;

		if (pNode && (pNode->getEtiquette() != ""))
		{
			string sEtiqu = pNode->getEtiquette() ;
			string sCodeSens ;
			pContexte->getDico()->donneCodeSens(&sEtiqu, &sCodeSens) ;
			if (sCodeSens == "0SOA4")
			{
				// Ajout de l'arbre comme fils du noeud assesment
				//
				CopyBranch(pNode, "COPIE") ;
				nextNode = nextNode.GetNextItem(TVGN_CHILD) ;
				while (nextNode != NULL)
				{
					NSTreeNode* pFilsNode = GetNSTreeNode(&nextNode) ;
					if (pFilsNode && (pFilsNode->getEtiquette() == sRootLex))
					{
						nextNode.SelectItem(TVGN_CARET) ;

						if (sArchetype != "")
						{
							string sArchetypeNode = pContexte->getSuperviseur()->getArcManager()->DonneNoeudArchetype(NSArcManager::archetype, sArchetype) ;
							if (sArchetypeNode != "")
								pFilsNode->addTemporaryLink(sArchetypeNode, NSRootLink::archetype, dirFleche) ;
						}

						NewPreoccup() ;
						break ;
					}
					nextNode = nextNode.GetNextItem(TVGN_NEXT) ;
				}
				break ;
			}
		}
		nextNode = nextNode.GetNextItem(TVGN_NEXT) ;
	}
	*(pContexte->getSuperviseur()->pBufCopie) = CutPaste ;
}

//
// Nouvelle description sans changement de nature
//
void
NSTreeWindow::EvolPreoccupRC(NSPatPathoArray* pContenuPatpatho, NSConcern* pConcern, string sArchetype)
{
	if ((!pContenuPatpatho) || (pContenuPatpatho->empty()) || (!pConcern))
		return ;

	string sRootLex = (*(pContenuPatpatho->begin()))->getLexique() ;

	NSCutPaste CutPaste(*(pContexte->getSuperviseur()->pBufCopie)) ;
  pContexte->getSuperviseur()->pBufCopie->vider() ;
  *(pContexte->getSuperviseur()->pBufCopie->pPatPatho) = *pContenuPatpatho ;

  TTreeNode nextNode = GetFirstVisible() ;
  while (nextNode != NULL)
  {
  	NSTreeNode* pNode = GetNSTreeNode(&nextNode) ;

    if (pNode && (pNode->getEtiquette() != ""))
    {
    	string sEtiqu = pNode->getEtiquette() ;
      string sCodeSens ;
      pContexte->getDico()->donneCodeSens(&sEtiqu, &sCodeSens) ;
      if (sCodeSens == "0SOA4")
      {
      	CopyBranch(pNode, "COPIE") ;
        nextNode = nextNode.GetNextItem(TVGN_CHILD) ;
        while (nextNode != NULL)
        {
        	NSTreeNode* pFilsNode = GetNSTreeNode(&nextNode) ;
          if (pFilsNode && (pFilsNode->getEtiquette() == sRootLex))
          {
          	nextNode.SelectItem(TVGN_CARET) ;
            pFilsNode->addTemporaryLink(pConcern->getNoeud(), NSRootLink::problemContactElement, dirFleche) ;
            break ;
          }
          nextNode = nextNode.GetNextItem(TVGN_NEXT) ;
        }
        break ;
      }
    }
    nextNode = nextNode.GetNextItem(TVGN_NEXT) ;
	}
	*(pContexte->getSuperviseur()->pBufCopie) = CutPaste ;
}

//
// Nouvelle description avec changement de nature
//
void
NSTreeWindow::ChangePreoccupRC(NSPatPathoArray* pContenuPatpatho, NSConcern* pConcern, string sArchetype)
{
    if ((!pContenuPatpatho) || (pContenuPatpatho->empty()) || (!pConcern))
        return ;
    string sRootLex = (*(pContenuPatpatho->begin()))->getLexique() ;

    NSCutPaste CutPaste(*(pContexte->getSuperviseur()->pBufCopie)) ;
    pContexte->getSuperviseur()->pBufCopie->vider() ;
    *(pContexte->getSuperviseur()->pBufCopie->pPatPatho) = *pContenuPatpatho ;

    TTreeNode nextNode = GetFirstVisible() ;
    while (nextNode != NULL)
    {
        NSTreeNode* pNode = GetNSTreeNode(&nextNode) ;

        if (pNode && (pNode->getEtiquette() != ""))
        {
            string sEtiqu = pNode->getEtiquette() ;
            string sCodeSens ;
            pContexte->getDico()->donneCodeSens(&sEtiqu, &sCodeSens) ;
            if (sCodeSens == "0SOA4")
            {
                CopyBranch(pNode, "COPIE") ;
                nextNode = nextNode.GetNextItem(TVGN_CHILD) ;
                while (nextNode != NULL)
                {
                    NSTreeNode* pFilsNode = GetNSTreeNode(&nextNode) ;
                    if (pFilsNode && (pFilsNode->getEtiquette() == sRootLex))
                    {
                        nextNode.SelectItem(TVGN_CARET) ;
                        ChangePreoccup(pConcern) ;
                        break ;
                    }
                    nextNode = nextNode.GetNextItem(TVGN_NEXT) ;
                }
                break ;
            }
        }
        nextNode = nextNode.GetNextItem(TVGN_NEXT) ;
    }
    *(pContexte->getSuperviseur()->pBufCopie) = CutPaste ;
}

//-------------------------------------------------------------------------
// 					 Connection � une pr�occupation existante
//-------------------------------------------------------------------------
void
NSTreeWindow::ConnectToPreoccup()
{
  TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNode)
    return ;
}

//-------------------------------------------------------------------------
// 							Classification
//-------------------------------------------------------------------------
void
NSTreeWindow::Classifier()
{
try
{
	TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNode)
    return ;

  BBFilsItem* pFilsItem ;

  if ((pNSTreeNode->pControle) &&
      (pNSTreeNode->pControle->getTransfert()) &&
      (pNSTreeNode->pControle->getTransfert()->pBBFilsItem))
  	pFilsItem = pNSTreeNode->pControle->getTransfert()->pBBFilsItem ;
  else
  	return ;

  NSEpisodus* pEpisodus = pContexte->getSuperviseur()->getEpisodus() ;

  //
  // Trouver automatiquement la classification � utiliser
  //
  ClassificationPrinciple* pPrincipe = NULL ;
  string                   sPostCase = "" ;

  string sChemin = string("") ;

  PrinciplesArray* pPrincipes = pEpisodus->pPrincipes ;
  if (!pPrincipes)
  	return ;

  pNSTreeNode->formerChemin(&sChemin) ;
  pPrincipe = pPrincipes->trouvePrincipe(sChemin, sPostCase) ;

  //
  // Ou demander
  //
  if (!pPrincipe)
  	return ;

  //
  // Puis trouver le code
  //
  string sClassif = pPrincipe->sClassification ;

  string sConcept ;
  pContexte->getDico()->donneCodeSens(&(pNSTreeNode->getEtiquette()), &sConcept) ;

  string sResO = string("") ;
  string sResP = string("") ;
  string sResI = string("") ;
  string sRes3 = string("") ;

  if (sConcept == string("�??"))
  {
  	string sLibelle  = pNSTreeNode->sTexteGlobal ;
    string sLocalize = pNSTreeNode->getPosition() ;

    ParseSOAP Parser(pContexte, &sClassif) ;
    Parser.computeParsing(&sLibelle, &sLocalize, &sResO, &sResP, &sResI, &sRes3) ;
  }
  else
  {
  	Classify ClassifTool(pContexte, &sClassif, &sConcept, &sPostCase) ;
  	ClassifTool.computeParsing(&sResO, &sResP, &sResI) ;
  }

  //
  // On trouve le code
  //
  classifExpert* pExpert = pEpisodus->pClassifExpert ;
  if (!pExpert)
      return ;

  NSEpiClassifInfoArray arrayClassif ;

  ElemSetArray* pElemDomain = 0 ;
  //
  // On instancie le domaine
  // Instanciating the domain
  //
  string sDomain  = sResP ;
  ParseCategory Parser(pExpert->donneCodeSize(sClassif), sClassif,
                                             pExpert->donnePattern(sClassif)) ;
  pElemDomain = Parser.DefDomain(sDomain) ;
  //
  // On trouve les codes qui correspondent au domaine
  // Finding the codes that belong to the domain
  //
  string sCaseSens ;
  pContexte->getDico()->donneCodeSens(&(pPrincipe->sCase), &sCaseSens) ;

  pExpert->fillList(sClassif, pElemDomain, &arrayClassif, sCaseSens) ;

  if (pElemDomain)
      delete pElemDomain ;

  string sGoodCode = "" ;
  //
  //
  //
  if (arrayClassif.size() != 1)
  {
  	SOAPObject SOAPObj(pNSTreeNode->sLabel, sResP, sClassif, 0, pFilsItem) ;
#ifndef _EXT_CAPTURE
		NSCapture Capture(pContexte) ;
#else
		NSCapture Capture ;
#endif

		Capture.sClassifResultO = sResO ;
    Capture.sClassifResultP = sResP ;
    Capture.sClassifResultI = sResI ;
    Capture.sClassifResult3 = sRes3 ;

    SOAPObj.pCaptElemnt = &Capture ;
    SOAPObj.sCase       = sCaseSens ;

    sGoodCode = pExpert->chooseCode(&SOAPObj) ;
  }
  else
  {
  	sGoodCode = (*(arrayClassif.begin()))->pDonnees->code ;

    string sCtrlData = "" ;
    NVLdVTemps tpsDebut ;
    tpsDebut.takeTime() ;
    pExpert->setControlString(&sCtrlData, sClassif, sCaseSens, pNSTreeNode->sLabel,
                                  classifExpert::niveauPreselection, 0,
                                  &tpsDebut, &tpsDebut, sGoodCode, sConcept) ;
    pExpert->storeControlData(sCtrlData) ;
  }

  if (sGoodCode == "")
  	return ;

  //
  // Ajouter � l'arbre
  //
  string sClassifPlein = sClassif + string(1, '1') ;

  pContexte->getSuperviseur()->pBufDragDrop->vider() ;
  NSPatPathoArray* pDragPatho = pContexte->getSuperviseur()->pBufDragDrop->pPatPatho ;

  NSPatPathoInfo pptInfo ;
  pptInfo.setLexique(sClassifPlein) ;
  pptInfo.setComplement(sGoodCode) ;

  pDragPatho->push_back(new NSPatPathoInfo(pptInfo)) ;

  DragFils(pNSTreeNode, "DRAG") ;
}
catch(...)
{
	erreur("Exception NSTreeWindow::Classifier.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------//	   Traitement de la commande clavier de changement d'"inter�t"
//-------------------------------------------------------------------------
void
NSTreeWindow::FixeInteret(char KbKey)
{
	TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNodeSelection = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNodeSelection)
    return ;

  if (false == isRealNode(pNSTreeNodeSelection))
    return ;

  if ((NULL == pNSTreeNodeSelection->pControle) ||
      (NULL == pNSTreeNodeSelection->pControle->getTransfert()))
    return ;

  Message* pMessage = pNSTreeNodeSelection->pControle->getTransfert()->pTransfertMessage ;
  if (!pMessage)
    return ;

  if      (('4' == KbKey) || (VK_NUMPAD4 == KbKey)) //max
    pMessage->SetInteret(string("E")) ;
  else if (('3' == KbKey) || (VK_NUMPAD3 == KbKey))
    pMessage->SetInteret(string("D")) ;
  else if (('2' == KbKey) || (VK_NUMPAD2 == KbKey))
    pMessage->SetInteret(string("C")) ;
  else if (('1' == KbKey) || (VK_NUMPAD1 == KbKey))
    pMessage->SetInteret(string("B")) ;
  else if (('0' == KbKey) || (VK_NUMPAD0 == KbKey))
    pMessage->SetInteret(string("A")) ;

  string sNewInteret = pMessage->GetInteret() ;
  pNSTreeNodeSelection->fixeInteret(sNewInteret) ;
}

//-------------------------------------------------------------------------
//	   			Traitement du changement de certitude
//-------------------------------------------------------------------------
void
NSTreeWindow::FixeCertitude(int iCert)
{
	TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNodeSelection = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNodeSelection)
    return ;

  if (false == isRealNode(pNSTreeNodeSelection))
    return ;

  if ((NULL == pNSTreeNodeSelection->pControle) ||
      (NULL == pNSTreeNodeSelection->pControle->getTransfert()))
    return ;

  Message* pMessage = pNSTreeNodeSelection->pControle->getTransfert()->pTransfertMessage ;
  if (NULL == pMessage)
    return ;

  if 		((iCert >= 0) && (iCert <= 12))
    pMessage->SetCertitude(string("WCE001")) ;
  else if ((iCert > 12) && (iCert <= 37))
    pMessage->SetCertitude(string("WCE251")) ;
  else if ((iCert > 37) && (iCert <= 62))
    pMessage->SetCertitude(string("WCE501")) ;
  else if ((iCert > 62) && (iCert <= 87))
    pMessage->SetCertitude(string("WCE751")) ;
  else
    pMessage->SetCertitude(string("")) ;

  string sNewCertitu = pMessage->GetCertitude() ;
  pNSTreeNodeSelection->fixeCertitude(sNewCertitu) ;
}

void
NSTreeWindow::FixeDroits()
{
  if (ReadOnly)
    return ;

  TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNodeSelection = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNodeSelection)
    return ;

  if (false == isRealNode(pNSTreeNodeSelection))
    return ;

try
{
	string sNodeRights = pNSTreeNodeSelection->getRights() ;

	RightsDialog* pRightsDlg = new RightsDialog(this, pContexte, &sNodeRights) ;
  int iReturn = pRightsDlg->Execute() ;

  if (IDOK == iReturn)
  {
    pNSTreeNodeSelection->SetRights(sNodeRights) ;

    // mise � jour du bbitem
    if ((pNSTreeNodeSelection->pControle->getTransfert()) &&
        	(pNSTreeNodeSelection->pControle->getTransfert()->pTransfertMessage))
    {
      int iActif ;
      pNSTreeNodeSelection->Transferer(tdGetData, &iActif,
                    pNSTreeNodeSelection->pControle->getTransfert()->pTransfertMessage) ;
    }

    SetDirty(true) ;
  }

  delete pRightsDlg ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSTreeWindow::FixeDroits : ") + e.why() ;
  pContexte->getSuperviseur()->trace(&sErr, 1, NSSuper::trError) ;
	erreur(sErr.c_str(), standardError, 0) ;
	return ;
}
catch (...){
	erreur("Exception NSTreeWindow::FixeDroits.", standardError, 0) ;
}
}

//------------------------------------------------------------------------
//trouver le plus proche petit fr�re d'un NSTreeNode
//------------------------------------------------------------------------
NSTreeNode*
NSTreeWindow::TrouverPetitFrere(NSTreeNode* pNSTreeNode, int ligne)
{
  if ((NULL == pNSTreeNode) || (NULL == pNSTreeNode->pere))
    return 0 ;

  if (true == pNSTreeNode->pere->VectFils.empty())
    return 0 ;

	int lignEnCours = 1000000 ;
  NSTreeNode* pNSTreePetitFrere = 0;
  //chercher le fr�re cadet le plus proche de pNSTreeNode
  iterNSTreeNode fils = pNSTreeNode->pere->VectFils.begin() ;
  for (; fils != pNSTreeNode->pere->VectFils.end(); fils++)
  {
    if ((false == (*fils)->estLie()) &&
        ((*fils)->getLigne() < lignEnCours) && ((*fils)->getLigne() > ligne))
    {
      lignEnCours = (*fils)->getLigne() ;
      pNSTreePetitFrere = *fils ;
    }
  }
  return (pNSTreePetitFrere) ;
}

//------------------------------------------------------------------------
//trouver le plus proche grand fr�re d'un NSTreeNode
//------------------------------------------------------------------------
NSTreeNode*
NSTreeWindow::TrouverGrandFrere(NSTreeNode* pNSTreeNode, int ligne)
{
  if ((NULL == pNSTreeNode) || (NULL == pNSTreeNode->pere))
    return 0 ;

  if (true == pNSTreeNode->pere->VectFils.empty())
    return 0 ;

	int lignEnCours = 0 ;
	NSTreeNode* pNSTreeGrandFrere = 0 ;
  //chercher le fr�re ain� le plus proche de pNSTreeNodeSelection
  iterNSTreeNode fils = pNSTreeNode->pere->VectFils.begin() ;
  for (; fils != pNSTreeNode->pere->VectFils.end(); fils++)
  {
    if ((false == (*fils)->estLie()) &&
        ((*fils)->getLigne() > lignEnCours) && ((*fils)->getLigne() < ligne))
    {
      lignEnCours = (*fils)->getLigne() ;
      pNSTreeGrandFrere = *fils ;    }
  }
  return (pNSTreeGrandFrere) ;
}

//------------------------------------------------------------------------// Touver le TTReenode dont le p�re est le root et qui soit le plus proche de
// l'�l�ment s�lectionn� (ain�)
//------------------------------------------------------------------------
NSTreeNode*
NSTreeWindow::TrouverGrandFrereFilsRoot(NSTreeNode* /*pNSTreeNode*/, int ligne)
{
  if (pNodeArray->empty())
  	return NULL ;

  // In order to know what is the "root column", we take 1st node's column
  //
  iterNSTreeNode iter = pNodeArray->begin() ;
  int iRefCol = (*iter)->getColonne() ;

  NSTreeNode* pNSTreeFrere = NULL ;

  int lignEnCours = 0 ;

  iterNSTreeNode fils = pNodeArray->begin() ;
  for (; fils != pNodeArray->end(); fils++)
  {
  	if ((*fils)->getColonne() == iRefCol)
    	if (((*fils)->getLigne() > lignEnCours) && ((*fils)->getLigne() < ligne))
      {
      	lignEnCours = (*fils)->getLigne() ;
        pNSTreeFrere = *fils ;
      }
  }
  return (pNSTreeFrere) ;
}

//------------------------------------------------------------------------//Touver le TTReenode dont le p�re est le root et qui soit le plus proche de
// l'�l�ment s�lectionn� (cadet)
//------------------------------------------------------------------------
NSTreeNode*
NSTreeWindow::TrouverPetitFrereFilsRoot(NSTreeNode* /*pNSTreeNode*/, int ligne)
{
	if (pNodeArray->empty())
		return NULL ;

  // In order to know what is the "root column", we take 1st node's column
  //
  iterNSTreeNode iter = pNodeArray->begin() ;
  int iRefCol = (*iter)->getColonne() ;

	int lignEnCours = 1000000 ;
  NSTreeNode* pNSTreePetitFrere = 0 ;
  //chercher le fr�re cadet le plus proche de pNSTreeNode

  for (; iter != pNodeArray->end(); iter++)
  {
  	if ((*iter)->getColonne() == iRefCol)
    {
    	if ((false == (*iter)->estLie()) &&
          ((*iter)->getLigne() < lignEnCours) && ((*iter)->getLigne() > ligne))
      {
      	lignEnCours = (*iter)->getLigne() ;
        pNSTreePetitFrere = *iter ;
      }
    }
  }
  return (pNSTreePetitFrere) ;
}

NSTreeNode*
NSTreeWindow::GetNodeForPath(string sPath, string separator)
{
  if ((string("") == sPath) || (pNodeArray->empty()))
    return 0 ;

  ClasseStringVector Vect ;
	DecomposeChaine(&sPath, &Vect, separator) ;

  if (Vect.empty())
		return 0 ;

  // The principle here is that the first element in sPath is the root concept
  // of the document; hence it doesn't appear as a node
  //
  int iVectorBase = 0 ;
  if ((NULL != pControle) && (NULL != pControle->getTransfert()) && (NULL != pControle->getTransfert()->pBBFilsItem))
  {
    BBFilsItem* pFilsItem = pControle->getTransfert()->pBBFilsItem ;
    string sFilsLabel = pFilsItem->getItemLabel() ;
    string sLabelSens = string("") ;
    pContexte->getSuperviseur()->getDico()->donneCodeSens(&sFilsLabel, &sLabelSens) ;

    if (sLabelSens != Vect[0]->sItem)
      return 0 ;

    iVectorBase = 1 ;
  }

  // This algorithm expects that pNodeArray is sorted; let's make sure it is
  //
  sort(pNodeArray->begin(), pNodeArray->end(), sortTreenodes) ;

  iterNSTreeNode iter = pNodeArray->begin() ;

  //
  size_t iColToSearch = NODES_COL_BASE ;
  string sToSearch    = Vect[iColToSearch - NODES_COL_BASE + iVectorBase]->sItem ;

  for ( ; pNodeArray->end() != iter ; iter++)
 	{
    // Right information in the right place
    //
    if ((*iter)->getColonne() == (int) iColToSearch)
    {
      if ((*iter)->getLabelSens() == sToSearch)
      {
        // Was it the last item in path: means search is successful
        //
        if (Vect.size() == iColToSearch - NODES_COL_BASE + iVectorBase + 1)
          return *iter ;
        else
        {
          iColToSearch++ ;
          sToSearch = Vect[iColToSearch - NODES_COL_BASE + iVectorBase]->sItem ;
        }
      }
    }
    else if ((*iter)->getColonne() < (int) iColToSearch)
    {
      if ((*iter)->getLabelSens() == sToSearch)
        iColToSearch = (*iter)->getColonne() + 1 ;
      else
        iColToSearch = (*iter)->getColonne() ;

      sToSearch = Vect[iColToSearch - NODES_COL_BASE + iVectorBase]->sItem ;
    }
  }
  return 0 ;
}

//----------------------------------------------------------------------
//								Il s'agit d'un code lexique
// 						on r�cup�re le code et le libell�
//						 on cr�e un BBFilsTtem rattach� au noeud
//			  on lance une bo�te d'�dition si le code est une valeur chiffr�e
//							on cr�e un fr�re et un fils fictifs
//----------------------------------------------------------------------
void
NSTreeWindow::DicoGetCodeLexique()
{
try
{
	if (NULL == pEditDico)
  	return ;

  char code[BASE_LEXI_LEN + 1] ;
	pEditDico->GetCodeLexiqueChoisi(code) ;
  string* pStringCode = new string(code) ;

	if (*pStringCode == "")
	{
  	delete pStringCode ;
    pEditDico->SetFocus() ;
    return ;
	}

	//MAJ du NSTreeNode � partir d'un TTreeNode
	TTreeNode noeud = GetSelection() ;

	string sChaineRecuperee = "" ;
	pEditDico->GetLabelChoisi(&sChaineRecuperee) ;

	noeud.SetText(sChaineRecuperee.c_str(), true) ;

	// La TreeWindow va reprendre le focus ==>
	// on sort du mode "Edition du pEditDico"
	// ATTENTION : Si SortieEditionDico() n'est pas appel� assez t�t, on risque
	//             de planter sur une interception de EvLButtonUp de la TreeWin
	//
	SortieEditionDico() ;

	bool CreerFilsChampEdit = false ; //cr�er un fils lanceur de la bo�te d'�dition
	bool bDateHeure = false ; //cr�er un fils lanceur de la bo�te d'�dition (date et heure)
	if (noeud.GetItem())
	{
		NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
    if (NULL == pNSTreeNode)
    {
    	delete pStringCode ;
      return ;
    }
    pNSTreeNode->SetImageIndex(0) ;
    pNSTreeNode->SetSelectedImageIndex(0) ;
    pNSTreeNode->SetInteret("A") ;
    if (pNSTreeNode)
    {
    	if (string("") != pNSTreeNode->sTexteGlobal)
      {
      	if (pEditDico)
        {
          char szThis[20] ;
          sprintf(szThis, "%p", HWindow) ;
          string sMsg = string("DicoGetCodeLexique for TreeWindow ") + string(szThis) + string(" : deleting EditDico.") ;
          pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

          KillDico() ;
        }
      }
      // Si l'ancien NSTreeNode contenait un texte libre avec
      // des fr�res li�s : il faut les tuer
      if (false == pNSTreeNode->VectFrereLie.empty())
      {
      	//d�caler les NSTreeNodes qui existent
        for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
        	if ((*iter)->getLigne() > pNSTreeNode->getLigne())
          	(*iter)->setLigne((*iter)->getLigne() -  pNSTreeNode->VectFrereLie.size()) ;

        iterNSTreeNode it = pNSTreeNode->VectFrereLie.begin() ;
        while (pNSTreeNode->VectFrereLie.end() != it)
        {        	NSTreeNode* pNSTemp = (*it) ;
          pNSTemp->Delete() ;
          pNodeArray->EnleverElement((*it)) ;
          if (pNSTreeNode->pere)
          	pNSTreeNode->pere->VectFils.EnleverElement((*it)) ;
          delete pNSTemp ;
          pNSTreeNode->VectFrereLie.erase(it) ;
        }
        pNSTreeNode->VectFrereLie.vider() ;
        ReconstruireFils(pNSTreeNode) ;
        pNSTreeNode->sTexteGlobal = string("") ;
      }

      pNSTreeNode->Type  = string("CC") ;

      pNSTreeNode->SetLexique(*pStringCode) ;
      pNSTreeNode->trouveLabel(sLang) ;

      pNSTreeNode->InstancieUrl(pNSEncyclo) ; //Encyclop�die.db
      strip(pNSTreeNode->sLabel, stripRight) ;

      // Position dans l'arbre
      string sCodeSens ;
      pContexte->getSuperviseur()->getDico()->donneCodeSens(&pNSTreeNode->getEtiquette(), &sCodeSens) ;

      // Si le NSTreeNode existe , ne pas le cr�er : changer seulement son code
      //if(pNSTreeNode->pControle == 0)
      if (pNSTreeNode->estFictif())
      	MiseAjourNSTreeNode(pNSTreeNode) ;
      else
      	ReMiseAjourNSTreeNode(pNSTreeNode, *pStringCode, "") ;

      BBItem* pBBItem = pNSTreeNode->pControle->getTransfert()->pBBFilsItem->getItemFather() ;

      // On montre l'arbre, avec son noeud nouveau ou modifi�, au Blackboard
//            pBBItem->pBigBoss->showBB();

			pNSTreeNode->SetPosition(pBBItem->sLocalisation +
         	                        string(1, cheminSeparationMARK) + sCodeSens) ;

      //
      // Si le code lexique de ce pNSTreeNode commence par V
      // (valeur chiffr�e), alors lui cr�er un fils qui lancera
      // la bo�te d'�dition et r�cup�rera la valeur donn�e et son unit�
      //
      if      (pContexte->getSuperviseur()->getDico()->CodeCategorie(pNSTreeNode->getEtiquette()) == string("V"))
      	CreerFilsChampEdit = true ;
      else if (pContexte->getSuperviseur()->getDico()->CodeCategorie(pNSTreeNode->getEtiquette()) == "K")
      	bDateHeure = true ;

      pNSTreeNode->SetImageIndex(0) ;
      pNSTreeNode->SetSelectedImageIndex(0) ;

      // Ajoute un fr�re et d'un fils
      AjouteElementFictif(pNSTreeNode, &noeud, CreerFilsChampEdit, bDateHeure) ;

      pNSTreeNode->DicoKillFocus(pStringCode, "CC") ;
      pNSTreeNode->ctrlNotification() ;
      //
      // Contracter pNSTreeNode si valeur chiffr�e
      //
      if ((!pNSTreeNode->VectFils.empty()) &&(CreerFilsChampEdit || bDateHeure) &&
          ((*(pNSTreeNode->VectFils.begin()))->sLabel != "" ))
      {
      	string sLabel ;
        //
        // Contracter le p�re
        //
        string sLabelFils = (*(pNSTreeNode->VectFils.begin()))->sLabel ;
        if ((sLabelFils.find("<") != NPOS) || (sLabelFils.find(">") != NPOS))
        	sLabel = pNSTreeNode->sLabel + " " + (*(pNSTreeNode->VectFils.begin()))->sLabel ;
        else
        	sLabel = pNSTreeNode->sLabel + " : " + (*(pNSTreeNode->VectFils.begin()))->sLabel ;
        pNSTreeNode->SetText(sLabel.c_str(), true) ;
        pNSTreeNode->CollapseTousNoeud() ;
        // Affiche pour pNSTreeNodeDblClk l'inter�t le plus �lev�
        // parmi ceux de ses descendants
        AfficheInteretMaximum(pNSTreeNode) ;
      }
		}
	}
	if (pEditDico)
		pEditDico->pDico->pDicoDialog->sAmmorce = "" ;
	SetFocus() ;
	delete pStringCode ;

	SetDirty(true) ;
}
catch (...)
{
	erreur("Exception (NSTreeWindow::DicoGetCodeLexique).", standardError, 0) ;
}
}

//*********************************************************************
//
//								TRAITEMENT DES TEXTES LIBRES//
//*********************************************************************
void
NSTreeWindow::DicoGetTexteLibre(string* pTexteLibre)
{
	if (NULL == pTexteLibre)
		return ;

try
{
	VecteurChaine VecteurTL ;

  // First step, cut text according to carriage returns
  //
  size_t posRN  = pTexteLibre->find("\r\n") ;
  size_t posR   = pTexteLibre->find("\r") ;
  size_t posN   = pTexteLibre->find("\n") ;
  size_t newpos = min(posR, posN) ;
  size_t pos    = 0 ;
  size_t len    = strlen(pTexteLibre->c_str()) ;
  while (NPOS != newpos)
	{
  	string sTxt = string(*pTexteLibre, pos, newpos - pos) ;
    VecteurTL.push_back(new string(sTxt)) ;

    pos = newpos + 1 ;
    if (posRN == newpos)
    	pos++ ;

    if (pos == len)
  		break ;

  	posRN  = pTexteLibre->find("\r\n", pos) ;
  	posR   = pTexteLibre->find("\r", pos) ;
  	posN   = pTexteLibre->find("\n", pos) ;
  	newpos = min(posR, posN) ;
	}
  if (pos < len)
  {
  	string sTxt = string(*pTexteLibre, pos, len - pos) ;
    VecteurTL.push_back(new string(sTxt)) ;
  }

  if (VecteurTL.empty())
		return ;

	TTreeNode noeud = GetSelection() ;
  int tailleVect = 0;
  if (noeud.GetItem())
  {
  	NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
    if (pNSTreeNode)
    {
    	IterString itStr = VecteurTL.begin() ;

    	VecteurChaine VecteurTexte ;   // d�composer pTexteLibre
      DecomposeChaineTL(*itStr, &VecteurTexte) ;
      //
      // Pas de fr�res li�s
      //
      if (pNSTreeNode->sTexteGlobal == string(""))
      {
      	//MAJ
        for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
        	if ((*iter)->getLigne() > pNSTreeNode->getLigne())
          	(*iter)->setLigne((*iter)->getLigne() + VecteurTexte.size() - 1) ;
      }
      //
      // Il y a des fr�res li�s
      //
      else
      {
      	if (VecteurTexte.size() > 1)
        {
        	bool OK = true ;
          //d�caler les NSTreeNodes qui existent
          for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
          {
          	if ((*iter)->FrerePilote)
            {
            	if ((*iter)->FrerePilote != pNSTreeNode)              	OK = true ;
              else
              	OK = false ;
            }
            else
            	OK = true ;

            if (OK &&
            		((*iter)->getLigne() > pNSTreeNode->getLigne()))
            {
            	//MAJ
              (*iter)->setLigne((*iter)->getLigne() - pNSTreeNode->VectFrereLie.size()) ;
              (*iter)->setLigne((*iter)->getLigne() + VecteurTexte.size() - 1) ;
            }
          }
        }
      }
      // RepartirTexteLibre(pNSTreeNode, &VecteurTexte, pTexteLibre, &tailleVect) ;
      RepartirTexteLibre(pNSTreeNode, &VecteurTexte, *itStr, &tailleVect) ;

      pNSTreeNode->sContenuTransfert = pNSTreeNode->code ;
      pNSTreeNode->DicoKillFocus(&pNSTreeNode->code, "CL") ;
      pNSTreeNode->Type = string("CL") ;
      pNSTreeNode->Interet() ;
    //pNSTreeNode->SetImageIndex(5);
    //pNSTreeNode->SetSelectedImageIndex(5);

    	if (pControle && pControle->getFonction())
  		{
  			if (pControle->getFonction()->containFonction("CLASSIF_FREE"))
    			Classifier() ;
    		else
    			/* int iNotifier = */ pControle->getFonction()->execute(NSDLGFCT_EXECUTE) ;
  		}

      if (VecteurTL.size() > 1)
      {
      	NSCutPaste CutPaste(pContexte) ;
        IterString itStr = VecteurTL.begin() ;
        itStr++ ;
        for ( ; VecteurTL.end() != itStr; itStr++)
        {
        	Message Msg ;
          Msg.SetLexique(string("�?????")) ;

          string sIndice = "00000";
					if (false == CutPaste.pTextesLibres->empty())
					{
    				NSCutPastTL* pCPTL = CutPaste.pTextesLibres->back() ;
						sIndice = pCPTL->sIndice ;

      			int i = strlen(sIndice.c_str()) ;
            bool tourner = true;
            while ((tourner) && (i > 0))
            {
              i-- ;
              if (((sIndice[i] >= '0') && (sIndice[i] < '9')) ||                  ((sIndice[i] >= 'A') && (sIndice[i] < 'Z')))
              {
                sIndice[i] = char(sIndice[i] + 1) ;
                tourner = false ;
              }
              else if (sIndice[i] == '9')
              {
                sIndice[i] = 'A' ;
                tourner = false ;
              }
              else
                sIndice[i] = '0' ;
            }
    			}

    			NSCutPastTL CPTexte ;
    			CPTexte.sIndice = sIndice ;
    			CPTexte.sTexte  = **itStr ;
    			CutPaste.pTextesLibres->push_back(new NSCutPastTL(CPTexte)) ;

    			Msg.SetComplement(sIndice) ;    			CutPaste.pPatPatho->ajoutePatho(string("�?????"), &Msg, 0) ;
        }

      	DragApres(pNSTreeNode, "COPIE", &CutPaste) ;
      }
      else if (false == bLoosingFocus)
      	AutoriserCreationFrere(pNSTreeNode) ;
      // donner le focus au NSEDitDico sur le fr�re qui vient d'�tre cr�e
      // (uniquement si on en a cr�� un nouveau)

      // No longer works because pNodeArray is now sorted on lines
      //
      // if (pNodeArray->back() != pNSTreeNode)
      //  pNodeArray->back()->SelectItem(TVGN_CARET) ;

      NSTreeNode* pPetitFrere = 0 ;

      NSTreeNode* pNSTreePere = pNSTreeNode->pere ;
      if (pNSTreePere)
        pPetitFrere = TrouverPetitFrere(pNSTreeNode, pNSTreeNode->getLigne()) ;
      else
        pPetitFrere = TrouverPetitFrereFilsRoot(pNSTreeNode, pNSTreeNode->getLigne()) ;
        
      if ((NULL != pPetitFrere) && (pPetitFrere->estFictif()))
        pPetitFrere->SelectItem(TVGN_CARET) ;
      else
        KillDico() ;
    }
  }

  if (pEditDico)
  {
    // We must be certain the editDico will not retain focus
    pEditDico->AcceptToLooseFocus() ;
  	pEditDico->pDico->pDicoDialog->sAmmorce = "" ;
  }
  SetFocus() ;

  // La TreeWindow vient de reprendre le focus ==>
  // on sort de l'edition du pEditDico pour
  // la cr�ation d'un texte libre
  SortieEditionDico() ;
	SetDirty(true) ;}
catch (...)
{
	erreur("Exception NSTreeWindow::DicoGetTexteLibre.", standardError, 0);
}
}

//-------------------------------------------------------------------------// 					  	 d�composer pTexteLibre
// 					en un ensemble de 40 caract�res
//-------------------------------------------------------------------------
void
NSTreeWindow::DecomposeChaineTL(string* pChaine, VecteurChaine* pVect)
{
try
{
	size_t LongueurTexte = 2 * TEXTE_LIBRE_LEN ;
	if (strlen(pChaine->c_str()) <= LongueurTexte)
	{
		pVect->push_back(new string (*pChaine) ) ;
    return ;
	}

	size_t taille = 0 ;
	size_t i = LongueurTexte ;
	while ((' ' != (*pChaine)[i]) && (i > 0))
		i-- ;

	if (0 == i)
  {
  	pVect->push_back(new string (*pChaine) ) ;
    return ;
  }

	taille = i + 1 ;
	pVect->push_back(new string((*pChaine), 0, i)) ;
	i = i + LongueurTexte ;

	while (i <= strlen(pChaine->c_str()))
	{
		while ((i > taille) && (' ' != (*pChaine)[i]))
    	i-- ;

		if (taille == i)
    {
    	while ((i <= strlen(pChaine->c_str())) && (' ' != (*pChaine)[i]))
    		i++ ;

      if (i > strlen(pChaine->c_str()))
      	break ;
    }


    pVect->push_back(new string((*pChaine), taille, i - taille)) ;

    taille = i + 1 ;
    i = i + LongueurTexte ;
	}

	pVect->push_back(new string((*pChaine), taille, strlen(pChaine->c_str())- taille)) ;
}
catch (...)
{
	erreur("Exception NSTreeWindow::DecomposeChaineTL.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------// R�partir un texte libre sur plusieurs NSTreeNode.
// pNSTreeNode est le NSTreeNode pilote.
//-------------------------------------------------------------------------
void
NSTreeWindow::RepartirTexteLibre(NSTreeNode* pNSTreeNode,
						         VecteurChaine* VecteurTexte,
                                 string* pTexteLibre, int* taille)
{
	if ((NULL == pNSTreeNode) || (NULL == VecteurTexte) || (VecteurTexte->empty()))
		return ;

	int ligne = pNSTreeNode->getLigne() ;
	int colonne = pNSTreeNode->getColonne() ;

	IterString iter = VecteurTexte->begin();

	pNSTreeNode->Type  = string("CL");
	pNSTreeNode->sLabel = *(*iter);

	pNSTreeNode->SetLexique(string("�?????")) ;
	pNSTreeNode->SetText((*iter)->c_str(), true) ;
	if (pNSTreeNode->estFictif())
		MiseAjourNSTreeNode(pNSTreeNode) ;
	else
  	ReMiseAjourNSTreeNode(pNSTreeNode, string("�?????"), pNSTreeNode->code) ;
	pNSTreeNode->sContenuTransfert = pNSTreeNode->code ;
	pNSTreeNode->DicoKillFocus(&pNSTreeNode->code, "CL") ;
	iter++ ;
	pNSTreeNode->sTexteGlobal = *pTexteLibre ;
	//
  // Si on ne change pas le nombre de fils li�s : on change seulement
  // leurs �tiquettes
  //
  if ((VecteurTexte->size() - 1) == pNSTreeNode->VectFrereLie.size())
  {
  	iterNSTreeNode jter = pNSTreeNode->VectFrereLie.begin() ;
    while ((iter != VecteurTexte->end()) &&
               (jter != pNSTreeNode->VectFrereLie.end()))
    {
    	ligne++ ;
      (*jter)->sLabel = *(*iter) ;
      (*jter)->SetText((*(*iter)).c_str()) ;
      iter++ ;
      jter++ ;
    }
	}
  else
  {
  	// Tuer les anciens fr�res li�s qui vont d�leter "interface"
    // les fils de pNSTreeNode
    if (false == pNSTreeNode->VectFrereLie.empty())
    {
    	iterNSTreeNode it = pNSTreeNode->VectFrereLie.begin() ;
      while (it != pNSTreeNode->VectFrereLie.end())
      {
      	NSTreeNode* pNSTemp = (*it) ;
        pNSTemp->Delete() ;
        pNodeArray->EnleverElement((*it)) ;
        if (pNSTreeNode->pere)
        	pNSTreeNode->pere->VectFils.EnleverElement((*it)) ;
        pNSTreeNode->VectFrereLie.EnleverElement((*it)) ;
        delete pNSTemp ;
      }
    }
    // Les fils de pNSTreeNode doivent �tre d�let�s "interface" puis
    // recr�s au niveau interface
    else
    {
      if (false == pNSTreeNode->VectFils.empty())
    	  for (iterNSTreeNode it = pNSTreeNode->VectFils.begin() ;
				      	it != pNSTreeNode->VectFils.end(); it++)
      	  (*it)->Delete() ;
    }

    pNSTreeNode->VectFrereLie.vider() ;
    while (iter != VecteurTexte->end())
    {
    	ligne++ ;
      AjouteFrereFictifTexteLibre(pNSTreeNode, ligne, colonne, *(*iter)) ;
      iter++ ;
    }
    // Si pNSTreeNode a des fils et des fr�res (au dessous de lui),
    // il faut les reconstruire au niveau interface au moyen du
    // dernier fr�re li�
    //
    ReconstruireFils(pNSTreeNode) ;
	}
  *taille += (VecteurTexte->size() - 1) ;
}

//----------------------------------------------------------------------// 							si pNSTreeNode a des fils ,
//						il faut les reconstruire au niveau interface au
// 							moyen du dernier fr�re li�
//----------------------------------------------------------------------
void
NSTreeWindow::ReconstruireFils(NSTreeNode* pNSTreeNode)
{
  if (NULL == pNSTreeNode)
    return ;

	int ligneFils   = pNSTreeNode->getLigne() ;
	int colonneFils = pNSTreeNode->getColonne() ;
	iterNSTreeNode it = pNSTreeNode->VectFils.begin() ;
	int compteur = 0 ; //nombre de fils

	string sIdentite ;
	string sCode ;
	NSControle* pControle = 0 ;

try
{
	for ( ; pNSTreeNode->VectFils.end() != it ; it++)
	{
  	TTreeNode* pAmorce = new TTreeNode(*this, (*it)->sLabel.c_str()) ;
    sIdentite = (*it)->getEtiquette() ;
    sCode     = (*it)->code ;
    pControle = (*it)->pControle ;
    if (pNSTreeNode->VectFrereLie.empty()) //pas de fr�res li�s
    {
    	*pAmorce    = pNSTreeNode->AddChild(*pAmorce) ;
      ligneFils   = ligneFils + compteur ;
      colonneFils	= colonneFils ;
    }
    else
    {
    	NSTreeNode*	pNSTreeFrere = pNSTreeNode->VectFrereLie.back() ; //d�rnier �l�ment de VectFrereLie cr�e son fr�re
			*pAmorce = pNSTreeFrere->AddChild(*pAmorce) ;
      //*(*it) = pNSTreeFrere->AddChild(*(*it));
      ligneFils   = pNSTreeFrere->getLigne() + 1 + compteur ;
      colonneFils = pNSTreeFrere->getColonne() + 1 ;
    }
    (*it)->SetLexique(sIdentite) ;
    (*it)->SetHTreeItem(pAmorce->operator HTREEITEM()) ;
    (*it)->setLigne(ligneFils) ;
    (*it)->setColonne(colonneFils) ;
    (*it)->pControle = pControle ;
    compteur++ ;

    ReconstruireFils((*it)) ;

    delete pAmorce ;
	}
}
catch (...)
{
	erreur("Exception NSTreeWindow::ReconstruireFils.", standardError, 0) ;
}
}

//----------------------------------------------------------------------
// 			si pNSTreeNode a des fr�res (au dessous de lui),
//						il faut les reconstruire au niveau interface au
// 							moyen du dernier fr�re li�
//----------------------------------------------------------------------
void
NSTreeWindow::ReconstruireFrere(NSTreeNode* pNSTreeNode)
{
  if ((NULL == pNSTreeNode) || (NULL == pNSTreeNode->pere) || pNSTreeNode->pere->VectFils.empty())
    return ;

try
{
	int ligneFils   = pNSTreeNode->getLigne() ;
	int colonneFils = pNSTreeNode->getColonne() ;

	iterNSTreeNode it = pNSTreeNode->pere->VectFils.begin() ;

	for ( ;(it != pNSTreeNode->pere->VectFils.end()) && ((*it) != pNSTreeNode); it++)
	{
  	TTreeNode* pAmorce = new TTreeNode(*this, (*it)->sLabel.c_str()) ;

    if (pNSTreeNode->VectFrereLie.empty()) //pas de fr�res li�s
    	*pAmorce = pNSTreeNode->AddChild(*pAmorce);
    else
    {
    	NSTreeNode*	pNSTreeFrere = pNSTreeNode->VectFrereLie.back() ; //d�rnier �l�ment de VectFrereLie cr�e son fr�re
			*pAmorce = pNSTreeFrere->AddChild(*pAmorce) ;
      ligneFils   = pNSTreeFrere->getLigne() + 1 ;
      colonneFils = pNSTreeFrere->getColonne() + 1 ;
    }
    (*it)->SetHTreeItem(pAmorce->operator HTREEITEM()) ;
    (*it)->setLigne(ligneFils) ;
    (*it)->setColonne(colonneFils) ;
    ReconstruireFils((*it)) ;
    delete pAmorce ;
	}
}
catch (...)
{
	erreur("Exception NSTreeWindow::ReconstruireFrere.", standardError, 0) ;
}
}

//*********************************************************************//
//								FIN TRAITEMENT DES TEXTES LIBRES
//
//*********************************************************************

// Fonction appel�e par TvnBeginLabelEdit
// Note : le curseur est g�r� par EvMouseMove
void
NSTreeWindow::EntreeEditionDico()
{
	bEditionDico = true ;
}

// Fonction appel�e dans quatre cas :
// - Insertion code lexique
// - Fin d'�dition d'un texte libre
// - Sortie par VK_DOWN ou VK_UP
void
NSTreeWindow::SortieEditionDico()
{
	bEditionDico = false ;

  // on r�tablit eventuellement le curseur
  if (bCurseurTexte)
  {
  	SetCursor(0, IDC_ARROW) ;
    bCurseurTexte = false ;
	}

  Invalidate() ;
}

//*********************************************************************
//
//								GESTION DE L'AJOUT DES FILS ET DES FRERES
//
//*********************************************************************

//----------------------------------------------------------------------
//				  Donne les coordonnees maximales pour les fils de pNSTreeNode
// 					si pNSTreeNode a des fr�res li�s : en tenir compte.//// Si bJustReal = true, on s'arr�te au premier fils fictif// (uniquement pour la colonne de gauche, bien entendu)////----------------------------------------------------------------------
void
NSTreeWindow::GetMaxCoordonnees(NSTreeNode* pNSTreeNode, int *ligne,
                                                int *colonne, bool bJustReal)
{
  if (NULL == pNSTreeNode)
    return ;

	// a minima : les coordonn�es du noeud lui m�me
	*ligne   = pNSTreeNode->getLigne() ;
	*colonne = pNSTreeNode->getColonne() ;

	// on prend en compte les fr�res li�s
	if (false == pNSTreeNode->VectFrereLie.empty())
	{
  	*ligne   = (pNSTreeNode->VectFrereLie.back())->getLigne() ;
    *colonne = (pNSTreeNode->VectFrereLie.back())->getColonne() ;
	}

	// on traite les descendants
  for (iterNSTreeNode iter = pNSTreeNode->VectFils.begin();
  								pNSTreeNode->VectFils.end() != iter ; iter++)
	{
		if ((bJustReal) && (((*iter)->estPropose) || ((*iter)->estFictif())))
    	return ;

    if (*ligne <= (*iter)->getLigne())
    	*ligne = (*iter)->getLigne() ;

    if (*colonne <= (*iter)->getColonne())
    	*colonne = (*iter)->getColonne() ;

    GetMaxCoordonnees((*iter), ligne, colonne) ; // ne pas tenir compte
                                                    // de bJustReal
	}
}


//--------------------------------------------------------------------------// ajout d'un fr�re fictif �  pNSTreeNode
// bLie montre si le fr�re qu 'on va cr�er est li� � pNSTreeNodePilote ou non
//--------------------------------------------------------------------------
void
NSTreeWindow::AjouteFrereFictifTexteLibre(NSTreeNode* pNSTreeNodePilote, int ligne,
									int colonne, string sTexteLibre, bool /*bLie*/)
{
  if (NULL == pNSTreeNodePilote)
    return ;

	NSTreeNode* pNSTreeFrere = 0 ;

try
{
	if (pNSTreeNodePilote->VectFrereLie.empty()) //pas de fr�res li�s: pNSTreeNodePilote cr�e son fr�re
		pNSTreeFrere = pNSTreeNodePilote ;
  else
  	pNSTreeFrere = pNSTreeNodePilote->VectFrereLie.back() ; //dernier �l�ment de VectFrereLie cr�e son fr�re

//	pTTreeNodeFrere = &(pNSTreeFrere->InsertItem(TTreeNode(*this, sTexteLibre.c_str())));

	NSTreeNode* pNewNSTreeNode =
    new NSTreeNode(pNSTreeFrere->InsertItem(TTreeNode(*this, sTexteLibre.c_str())), pContexte);

  pNewNSTreeNode->SetImageIndex(-1/*, bool sendNow = true*/) ;
  pNewNSTreeNode->SetSelectedImageIndex(-1) ;
  pNewNSTreeNode->pControle = 0 ;
  pNewNSTreeNode->pere = pNSTreeNodePilote->pere ;

  pNewNSTreeNode->FrerePilote = pNSTreeNodePilote ;
  pNewNSTreeNode->Type  = string("CL") ;
  pNewNSTreeNode->SetLexique(string("�?????")) ;
  pNSTreeNodePilote->VectFrereLie.push_back(pNewNSTreeNode) ;

	pNewNSTreeNode->sLabel = sTexteLibre ;
	//pNewNSTreeNode devient fils du p�re de  pNSTreeNode
	if (pNSTreeNodePilote->pere)
		(pNSTreeNodePilote->pere->VectFils).Referencer(pNewNSTreeNode) ;

	//MAJ ligne et colonne
	pNewNSTreeNode->setLigne(ligne) ;
	pNewNSTreeNode->setColonne(colonne) ;

	pNodeArray->push_back(pNewNSTreeNode) ;
  sort(pNodeArray->begin(), pNodeArray->end(), sortTreenodes) ;

	Update() ;
}
catch (...)
{
	erreur("Exception NSTreeWindow::AjouteFrereFictifTexteLibre.", standardError, 0) ;
}
}

//--------------------------------------------------------------------------// ajout d'un fils fictif �  pNSTreeNodePere
//--------------------------------------------------------------------------
void
NSTreeWindow::AjouteFilsFictif(NSTreeNode* pNSTreeNodePere, TTreeNode* pTTreeNode,
                               int ligne, int colonne, string sIdentite,
                               bool estPropose, bool CreerFilsChampEdit,
                               bool bDateHeure)
{
try
{
  if (NULL == pNSTreeNodePere)
    return ;

	int ligneFils   = ligne ;
	int colonneFils = colonne ;
	TTreeNode* pAmorce = new TTreeNode(*this, "") ;

	if (pNSTreeNodePere->VectFrereLie.empty()) //pas de fr�res li�s
		*pAmorce = pTTreeNode->InsertChild(*pAmorce, TTreeNode::First) ;
	else
	{
  	NSTreeNode*	pNSTreeFrere = pNSTreeNodePere->VectFrereLie.back() ; //d�rnier �l�ment de VectFrereLie cr�e son fr�re
		*pAmorce = pNSTreeFrere->InsertChild(*pAmorce, TTreeNode::First) ;
		ligneFils   = pNSTreeFrere->getLigne() + 1 ;
    colonneFils = pNSTreeFrere->getColonne() + 1 ;
	}
  NSTreeNode* pNewNSTreeNodeFils = new NSTreeNode(*pAmorce, pContexte) ;
  pNewNSTreeNodeFils->pControle = 0 ;
  pNewNSTreeNodeFils->FrerePilote = 0 ;
  //MAJ ligne et colonne
  pNewNSTreeNodeFils->setLigne(ligneFils) ;
  pNewNSTreeNodeFils->setColonne(colonneFils) ;
  pNewNSTreeNodeFils->SetInteret("A") ;
  //pNewNSTreeNodeFils devient fils de pNSTreeNodePere
  pNewNSTreeNodeFils->pere = pNSTreeNodePere ;
  (pNSTreeNodePere->VectFils).Referencer(pNewNSTreeNodeFils) ;

  pNodeArray->push_back(pNewNSTreeNodeFils) ;
  sort(pNodeArray->begin(), pNodeArray->end(), sortTreenodes) ;

	if (estPropose)//suite � la recherche dans le fil guide
	{
  	if (pEditDico)
    {
      char szThis[20] ;
      sprintf(szThis, "%p", HWindow) ;
      string sMsg = string("AjouteFilsFictif on Fils Guides for TreeWindow ") + string(szThis) + string(": deleting EditDico.") ;
      pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

      KillDico() ;
    }

    pNewNSTreeNodeFils->estPropose = true ;
    pNewNSTreeNodeFils->setLibelle(sIdentite, sLang) ;
    //
    //mettre ? devant les �tiquettes des fils
    //
    pNewNSTreeNodeFils->SetImageIndex(6) ;
    pNewNSTreeNodeFils->SetSelectedImageIndex(6,  true) ;

    pNewNSTreeNodeFils->SetLexique(sIdentite) ;
    pNewNSTreeNodeFils->SetText(pNewNSTreeNodeFils->sLabel.c_str(), true) ;
	}

	else if (CreerFilsChampEdit)//valeur chiffr�e
	{
  	if (pEditDico)
    {
      char szThis[20] ;
      sprintf(szThis, "%p", HWindow) ;
      char szDico[20] ;
      sprintf(szDico, "%p", pEditDico->HWindow) ;
      string sMsg = string("AjouteFilsFictif on num value : deleting EditDico ") + string(szDico) + string(" for TreeWindow ") + string(szThis) ;
      pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

      KillDico() ;
    }
    pNewNSTreeNodeFils->SetImageIndex(0) ;
    pNewNSTreeNodeFils->SetSelectedImageIndex(0, true) ;

    //
    //chercher dans Convert.db si cette valeur chiffr�e a une formule et si tous
    //les param�tres sont instanci�s faire le cacul et mettre � jour
    //pNewNSTreeNodeFils->sLabel
    //passer en param�tre la patpatho en cours
    //
    string sUniteConvert = "" ;//unit� dans convert.db
    string sMethodeCalcul = "" ;//nom de la m�thode de calcul � mettre dans
                                    //le compl�ment de pNewNSTreeNodeFils->pere

    NSPatPathoArray* pNSPatPathoEnCours = new NSPatPathoArray(pContexte) ;
    //false pour ne pas tuer pTransfert li� � pBBitemNSTreeWindow
		//pBBitemNSTreeWindow->okFermerDialogue(true, false);
    pBBitemNSTreeWindow->rapatrieTmpPpt(pBBitemNSTreeWindow->pBigBoss->pTmpPPtArray, 0) ;
    BBFilsItem* pBBFilsLanceur = *(pBBitemNSTreeWindow->aBBItemFils.begin()) ;
    //*pNSPatPathoEnCours = *(*(pBBFilsLanceur->getPatPatho()->begin()));
    NSFatheredPatPathoArray* pFatheredElement = *(pBBFilsLanceur->getTmpPatho()->begin()) ;
    *pNSPatPathoEnCours = *(pFatheredElement->getPatPatho()) ;
    if (pNSCV)
    	pNSCV->CalculValeur(pNSTreeNodePere->getEtiquette(), &(pNewNSTreeNodeFils->sLabel),
			                         &sUniteConvert, &sMethodeCalcul, pNSPatPathoEnCours) ;
    if (pNewNSTreeNodeFils->sLabel != "")
    	pNewNSTreeNodeFils->sContenuTransfert = pNewNSTreeNodeFils->sLabel ;
    if (sUniteConvert != "")
    {
    	pNewNSTreeNodeFils->SetLexique("�N0;03") ;
      pNewNSTreeNodeFils->SetUnit(sUniteConvert + string("1")) ;
    }

    delete pNSPatPathoEnCours ;
    bool bCalcul = false ;//calcul dans convert.db
    if (pNewNSTreeNodeFils->sContenuTransfert != "")
    	bCalcul = true ;
    RecupereValeurChiffree(pNewNSTreeNodeFils, bCalcul) ;

    if (pNewNSTreeNodeFils->estFictif())
    	MiseAjourNSTreeNode(pNewNSTreeNodeFils) ;
    if (pNewNSTreeNodeFils->getEtiquette() != "")
    {
    	pNewNSTreeNodeFils->DicoKillFocus(&pNewNSTreeNodeFils->sContenuTransfert, "CL") ;
      pNewNSTreeNodeFils->ctrlNotification() ;
    }

    if (sMethodeCalcul != "")    	pNewNSTreeNodeFils->pere->SetComplement(sMethodeCalcul) ;
	}
  else if (bDateHeure) //date ou heure
  {
  	if (pEditDico)
    {
      char szThis[20] ;
      sprintf(szThis, "%p", HWindow) ;
      char szDico[20] ;
      sprintf(szDico, "%p", pEditDico->HWindow) ;
      string sMsg = string("AjouteFilsFictif on date/hour : deleting EditDico ") + string(szDico) + string(" for TreeWindow ") + string(szThis) ;
      pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

      KillDico() ;
    }
    pNewNSTreeNodeFils->SetImageIndex(0) ;
    pNewNSTreeNodeFils->SetSelectedImageIndex(0, true) ;

    RecupereUniteDateHeure(pNewNSTreeNodeFils) ;

    if (pNewNSTreeNodeFils->estFictif())
    	MiseAjourNSTreeNode(pNewNSTreeNodeFils) ;
    if (pNewNSTreeNodeFils->getEtiquette() != "")
    {
    	pNewNSTreeNodeFils->DicoKillFocus(&pNewNSTreeNodeFils->sContenuTransfert, "CL") ;
      pNewNSTreeNodeFils->ctrlNotification() ;
    }
	}
  else
  	pNewNSTreeNodeFils->SelectItem(TVGN_CARET) ;

	delete pAmorce ;
}
catch (...)
{
	erreur("Exception NSTreeWindow::AjouteFilsFictif.", standardError, 0) ;
}
}

//--------------------------------------------------------------------------// ajout d'un fr�re fictif (au dessus ) � pNSTreeNode.
//TTreeNode est celui du p�re de pNSTreeNode
//--------------------------------------------------------------------------
void
NSTreeWindow::AjouteFrereFictifAvant(NSTreeNode* pNSTreeNode, TTreeNode* pTTreeNodePere, int ligne,
							int colonne , string sFaconAjout)
{
try
{
  if ((NULL == pTTreeNodePere) || (NULL == pNSTreeNode))
    return ;

  TTreeNode* pTTreeNode = new TTreeNode(*this, "") ;

  if (sFaconAjout == "Fin")
    *pTTreeNode = pTTreeNodePere->AddChild(*pTTreeNode);
  else if(sFaconAjout == "Debut")
    *pTTreeNode = pTTreeNodePere->InsertChild(*pTTreeNode, TTreeNode::First);

  NSTreeNode* pNewNSTreeNode = new NSTreeNode(*pTTreeNode, pContexte) ;
  pNewNSTreeNode->pControle = 0 ;
  pNewNSTreeNode->FrerePilote = 0 ;
  pNewNSTreeNode->pere = pNSTreeNode->pere ;
  pNewNSTreeNode->SetInteret("A") ;
  //pNewNSTreeNode devient fils du p�re de  pNSTreeNode
  if (pNSTreeNode->pere)
    (pNSTreeNode->pere->VectFils).Referencer(pNewNSTreeNode) ;

  //MAJ ligne et colonne
  pNewNSTreeNode->setLigne(ligne) ;
  pNewNSTreeNode->setColonne(colonne) ;

  pNodeArray->push_back(pNewNSTreeNode) ;
  sort(pNodeArray->begin(), pNodeArray->end(), sortTreenodes) ;

  Update() ;

//??   pTTreeNodePere->GetChild().ExpandItem(TTreeNode::Expand);
    //delete item;

  delete pTTreeNode ;
}
catch (...)
{
	erreur("Exception NSTreeWindow::AjouteFrereFictifAvant.", standardError, 0);
}
}

//----------------------------------------------------------------------
// 	cr�er  un fr�re  (en dessous) pour le noeud en question
//----------------------------------------------------------------------
void
NSTreeWindow::AjouteFrereFictifApres(NSTreeNode* pNSTreeFrere, int ligne, int colonne)
{
  if (NULL == pNSTreeFrere)
    return ;

  NSTreeNode* pNewNSTreeNode = 0 ;
  NSTreeNode* pNSTreeFrereCreateur = 0 ;

try
{
  if (pNSTreeFrere->VectFrereLie.empty()) //pas de fr�res li�s: pNSTreeNodePilote cr�e son fr�re
    pNSTreeFrereCreateur = pNSTreeFrere ;
  else
    pNSTreeFrereCreateur = pNSTreeFrere->VectFrereLie.back() ; //dernier �l�ment de VectFrereLie cr�e son fr�re

  pNewNSTreeNode =
      new NSTreeNode(pNSTreeFrereCreateur->InsertItem(TTreeNode(*this, "")), pContexte) ;

  pNewNSTreeNode->pControle = 0 ;
  pNewNSTreeNode->FrerePilote = 0 ;
  pNewNSTreeNode->SetInteret("A") ;

  // MAJ ligne et colonne
  pNewNSTreeNode->setLigne(ligne) ;
  pNewNSTreeNode->setColonne(colonne) ;

  // pNewNSTreeNode devient fils de pNSTreeNode
  pNewNSTreeNode->pere = pNSTreeFrere->pere ;
  if (pNSTreeFrere->pere)
    (pNSTreeFrere->pere->VectFils).Referencer(pNewNSTreeNode) ;

  pNodeArray->push_back(pNewNSTreeNode) ;
  sort(pNodeArray->begin(), pNodeArray->end(), sortTreenodes) ;
}
catch (...)
{
	erreur("Exception NSTreeWindow::AjouteFrereFictifApres.", standardError, 0);
}
}

//-----------------------------------------------------------------
//Autoriser la cr�ation d'un fils
//-----------------------------------------------------------------
void
NSTreeWindow::AutoriserCreationFils(NSTreeNode* pNSTreeNode, TTreeNode* Noeud)
{
  if (NULL == pNSTreeNode)
    return ;

  int ligne   = pNSTreeNode->getLigne() ;
  int colonne = pNSTreeNode->getColonne() ;

	//
  // Cr�ation classique de fils et de fr�re
  //

  int CreationFils = 1 ;
  iterNSTreeNode iter = pNSTreeNode->VectFils.begin();
  // Chercher un �l�ment non instanci� : fictif (non li�) et non propos�
  // et dont le code lexique ne commence pas par V (chiffr�e)
  for (; (iter != pNSTreeNode->VectFils.end()) && (CreationFils); iter++)
  {
    bool isRealNode(NSTreeNode* pNSTreeNode) ;

    if (((*iter)->estFictifPur()) && (!(*iter)->estPropose))
      CreationFils = 0 ;
  }

  if (CreationFils)
  {
    // MAJ des coordonn�es des fils et des petits fils de pNSTreeNode
    pNSTreeNode->MettreAJourLigne(1) ;

    // D�caler les NSTreeNodes qui existent et dont la ligne est sup�rieure
    // � ligneMaxInit
    for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
    {
      if (((*iter)->getLigne() > ligne) && (!(*iter)->Descendant(pNSTreeNode)) &&
                ((*iter)->FrerePilote != pNSTreeNode))
        (*iter)->setLigne((*iter)->getLigne() + 1) ;
                // DecalageLigneFrere  : �ventuellement un
                  //fr�re et  un fils de plus
    }
    AjouteFilsFictif(pNSTreeNode, Noeud, ligne + 1, colonne + 1, "",
                            false, false, false);
  }
}

//-----------------------------------------------------------------
// Autoriser la cr�ation d'un fr�re
//-----------------------------------------------------------------
void
NSTreeWindow::AutoriserCreationFrere(NSTreeNode* pNSTreeNode)
{
  if (NULL == pNSTreeNode)
    return ;

	int ligne   = pNSTreeNode->getLigne() ;
  int colonne = pNSTreeNode->getColonne() ;

  int ligneMaxInit = ligne ;
  int colonneMax = colonne ;
  GetMaxCoordonnees(pNSTreeNode, &ligneMaxInit, &colonneMax) ;
  int ligneMax = ligneMaxInit ;

  //savoir si on peut cr�er un fr�re ou non
  int CreationFrere      = 1 ;
  int DecalageLigneFrere = 1 ;

  // On peut d�cider d'interdire la cr�ation d'un fr�re, lors de la validation
  // d'un noeud, si ce noeud est suivi d'un fr�re fictif
  //
  bool bInterdireSiFrereFictif = false ;

  if ((bInterdireSiFrereFictif) && (false == pNodeArray->empty()))
  {
    iterNSTreeNode it = pNodeArray->begin() ;
    //chercher un fr�re (fictif non li� )� pNSTreeNode : m�me colonne et lignes diff�rentes
    for (; (it != pNodeArray->end()) && (CreationFrere); it++)
    {
      if (((*it)->getLigne()   == (pNSTreeNode->getLigne() + 1)) &&
            	((*it)->getColonne() == pNSTreeNode->getColonne()) &&
            	((*it)->pere == pNSTreeNode->pere                 ) &&
            	((*it)->estFictifPur()))
      {
        CreationFrere = 0 ;      //ne pas cr�er un fr�re
        DecalageLigneFrere = 0 ; //pas de d�calage
      }
    }
  }
  // D�caler les NSTreeNodes qui existent et dont la ligne est
  // sup�rieure � ligneMaxInit
  if ((DecalageLigneFrere != 0) && (false == pNodeArray->empty()))
  {
    for (iterNSTreeNode iter = pNodeArray->begin(); pNodeArray->end() != iter ; iter++)
    {
      if (((*iter)->getLigne() > ligneMaxInit) &&
            	(!(*iter)->Descendant(pNSTreeNode)) &&
            	((*iter)->FrerePilote != pNSTreeNode))
        (*iter)->setLigne((*iter)->getLigne() + DecalageLigneFrere) ;
        // DecalageLigneFrere  : �ventuellement un
            // fr�re et un fils de plus
    }
  }
  if (CreationFrere)
    AjouteFrereFictifApres(pNSTreeNode, ligneMax + 1, colonne) ;
}

//----------------------------------------------------------------------//	ajouter un un fr�re et un fils fictifs � un pNSTreeNode
// lors de l'ajout d'un fils on traite le cas o� le p�re (pNSTreeNode) est
// ouvreur de bo�te de dialogue, le cas o� ce p�re a des fils dans le fil
// guide et le cas classique
//----------------------------------------------------------------------
void
NSTreeWindow::AjouteElementFictif(NSTreeNode* pNSTreeNode, TTreeNode* Noeud, bool CreerFilsChampEdit, bool bDateHeure)
{
  if (NULL == pNSTreeNode)
    return ;

	int ligne   = pNSTreeNode->getLigne() ;
  int colonne = pNSTreeNode->getColonne() ;
  // NSTreeNode* pPere = pNSTreeNode->pere;
  int ligneMax, colonneMax ; // coordonn�es du fils de pNSTreeNode le plus �loign�
  int ligneMaxInit ;         // coordonn�es du fils de pNSTreeNode le plus �loign� avant insertion
  //************************************//
  //********    AJOUTER UN FILS ********//
  //************************************//

  ligneMaxInit = ligne ;
  colonneMax   = colonne ;

  ligneMax   = ligne ;
  colonneMax = colonne ;

  GetMaxCoordonnees(pNSTreeNode, &ligneMaxInit, &colonneMax) ;

  int CreationFils = 1 ;      //ajouter un fils si il n' y a pas de fils fictif
  int DecalageLigneFils = 0 ; //MAJ des lignes de tous les NSTReeNodes existants en cas de
   							      //cr�ation d'un nouveau fils pour pNSTreeNode

  if (false == pNSTreeNode->VectFils.empty())
  {
    iterNSTreeNode iter = pNSTreeNode->VectFils.begin() ;

   	//chercher un �l�ment non instanci� : fictif (non li�) et non propos�
   	for (; (iter != pNSTreeNode->VectFils.end()) && (CreationFils); iter++)
   	{
      if (((*iter)->estFictifPur()) && (false == (*iter)->estPropose))
      {
        CreationFils = 0 ;
        DecalageLigneFils = 0 ;
      }
    }
  }
  //cr�er un fils fictif pour pNSTreeNode  if (CreationFils)
    developper(pNSTreeNode, Noeud, &DecalageLigneFils, ligne, colonne, CreerFilsChampEdit, bDateHeure) ;

  GetMaxCoordonnees(pNSTreeNode, &ligneMax, &colonneMax) ;

    					//**************************************//
              //********    AJOUTER UN FRERE   *******//
              //**************************************//

	// Savoir si on peut cr�er un fr�re ou non
  int CreationFrere      = 1;
  int DecalageLigneFrere = 1;
  iterNSTreeNode it = pNodeArray->begin() ;
  //chercher un fr�re (fictif non li� )� pNSTreeNode : m�me colonne et lignes diff�rentes
  for (; (it != pNodeArray->end()) && (CreationFrere); it++)
  {
    if (((*it)->getLigne()  == (pNSTreeNode->getLigne() + 1)) &&
        ((*it)->getColonne() == pNSTreeNode->getColonne()) 	  &&
        ((*it)->pere == pNSTreeNode->pere) 					  &&
        ((*it)->estFictifPur()))
    {
      CreationFrere = 0 ;      //ne pas cr�er un fr�re
      DecalageLigneFrere = 0 ; //pas de d�calage
    }
	}
  //d�caler les NSTreeNodes qui existent et dont la ligne est sup�rieure � ligneMaxInit
  for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
  {
    if (((*iter)->getLigne() > ligneMaxInit) && (!(*iter)->Descendant(pNSTreeNode)) &&
           ((*iter)->FrerePilote != pNSTreeNode))
      (*iter)->setLigne((*iter)->getLigne() +  DecalageLigneFrere + DecalageLigneFils) ;
            // DecalageLigneFrere + DecalageLigneFils : �ventuellement un
            //fr�re et  un fils de plus
	}
  if (CreationFrere)
    AjouteFrereFictifApres(pNSTreeNode, ligneMax + 1, colonne) ;
}

//*********************************************************************
//
//			FIN DE LA GESTION DE L'AJOUT DES FILS ET DES FRERES
//
//*********************************************************************

//-----------------------------------------------------------------------------// faire une recherche filguide pour mettre � jour les donn�es du BBFilsItem
//qui pilote le noeud
//-----------------------------------------------------------------------------
bool
NSTreeWindow::RechercheFilGuide(NSTreeNode* pNSTreeNode, BBItemData* pDonnees, BBFilsItem* pBBfils)
{
	if ((NULL == pNSTreeNode) || (NULL == pDonnees) || (NULL == pBBfils))
  	return false ;

try
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

  //recherche s�mantique
  VecteurRechercheSelonCritere VecteurSelonCritere(GUIDE) ;
  string sCodeSens ;
  pSuper->getDico()->donneCodeSens(&pNSTreeNode->getEtiquette(), &sCodeSens) ;
  VecteurSelonCritere.AjouteEtiquette(sCodeSens) ;

  string sLocalisation;
  if (pNSTreeNode->pere)
  {
  	if (pNSTreeNode->pere->getPosition() == "")
    {
    	// Position dans l'arbre
      string sCodeSens ;
      pSuper->getDico()->donneCodeSens(&(pNSTreeNode->pere->getEtiquette()), &sCodeSens) ;
      pNSTreeNode->pere->SetPosition(pNSTreeNode->pere->pControle->getTransfert()->pBBFilsItem->getItemFather()->sLocalisation +
      								string(1,cheminSeparationMARK) + sCodeSens) ;
    }
    sLocalisation = pNSTreeNode->pere->getPosition() ;
  }
  else
  	sLocalisation = pNSTreeNode->pControle->getTransfert()->pBBFilsItem->getItemFather()->sLocalisation ;

  pSuper->getFilGuide()->chercheChemin(&sLocalisation ,
                             &VecteurSelonCritere, NSFilGuide :: compReseau) ;

  bool trouve;
  VecteurSelonCritere.SetData(sCodeSens, &trouve, pDonnees) ;
  string sEtiquette ;
  if (trouve)
  {
  	//on a trouv� la bonne fiche
    *(pBBfils->getItemData()) = *pDonnees ;

    //si feuille
    size_t pos = string(pBBfils->getItemData()->fils).find_first_not_of(string(" ")) ;
    if (pos)
    	pBBfils->FilsProlongeable = false ;
    else
    	pBBfils->FilsProlongeable = true ;
  }

  return trouve ;
}
catch (...)
{
	erreur("Exception NSTreeWindow::RechercheFilGuide", standardError, 0) ;
	return false ;
}
}

//------------------------------------------------------------------------------
//lors de l'ajout d'un fils � pNSTreeNode, on regardre :
//		  	+ si celui ci a une fiche fil guide :
//					-	s'il est lanceur d'une bo�te de dialogue, on d�veloppe cette
//						bo�te et on affiche le contenu
//       		- sinon on affiche simplement les fils
//			+ sinon on cr�e un fils classique et unique
//on met � jour le nombre de fils cr�es
//------------------------------------------------------------------------------
void
NSTreeWindow::developper(NSTreeNode* pNSTreeNode , TTreeNode* Noeud, int* DecalageLigneFils,
							int ligne, int colonne, bool CreerFilsChampEdit, bool bDateHeure,
                            bool bRechercheFilGuide, bool bInit)
{
try
{
	if (NULL == pNSTreeNode)
		return ;

  //
  // Si pNSTreeNode a dej� des fils propos�s ou c'est un texte libre,
  // il ne faut pas en cr�er d'autres mais un fils fictif non propos�
  //
  iterNSTreeNode iter;
  if (false == pNSTreeNode->VectFils.empty())
  {
    iter = pNSTreeNode->VectFils.begin() ;
    for ( ; (iter != pNSTreeNode->VectFils.end()) && (!(*iter)->estPropose); iter++) ;
  }
  //
  // Pas de fils propos�s, et pas texte libre
  //
  if (((pNSTreeNode->VectFils.empty()) || (iter == pNSTreeNode->VectFils.end()))
                            && (pNSTreeNode->getEtiquette() != "�?????"))
  {
    if ((NULL == pNSTreeNode->pControle) || (NULL == pNSTreeNode->pControle->getTransfert()))
      return ;

    BBFilsItem* pBBfils = pNSTreeNode->pControle->getTransfert()->pBBFilsItem ;
    if (NULL == pBBfils)
      return ;

    BBItemData* pDonnees = new BBItemData ;
    // bool bControleNotification = false; //le noeud a �t� notifi�
    //
		//Recherche s�mantique
    //
    bool elementFilGuide = false ; //�l�ment se trouvant dans fil guide
    bool trouve ;
    //
    // Tester si ce BBFilsItem a dej� des donn�es ou non
    //
    size_t pos = string(pBBfils->getItemData()->chemin).find_first_not_of(string(" ")) ;
    if (!pos)
    {
      trouve = true ;
      *pDonnees = *(pBBfils->getItemData()) ;
    }
    else
    {
      if (!bRechercheFilGuide)
        trouve = RechercheFilGuide(pNSTreeNode, pDonnees, pBBfils) ;
      else
        trouve = pBBfils->FilsProlongeable ;
    }
    if (trouve)
    {
      //existence de Bo�te de dialogue
      // test devenu inutile et g�n�rant un bug avec les archetypes
      // en principe si ouvreDialog() est vrai et que ce n'est pas un arch�type,
      // il doit exister un pDonnees->nomDialogue
      // size_t pos1 = string(pBBfils->pDonnees->nomDialogue).find_first_not_of(string(" "));      if (pBBfils->ouvreDialog())
      {
        pBBfils->FilsProlongeable = true ;

        // Si le premier �l�ment de VectFils de pBBfils (pBBfils
        // en tant que BBItem) contient un �l�ment dont les donn�es
        // sont vides alors enlever cet �l�ment de ce vecteur
        //
        if (false == pBBfils->VectorFils.empty())
        {
          BBiterFils iter = pBBfils->VectorFils.begin() ;
          while (iter != pBBfils->VectorFils.end())          {
            size_t pos = string((*iter)->pDonnees->chemin).find_first_not_of(string(" ")) ;
            if (pos)
            {
              delete (*iter) ;
              pBBfils->VectorFils.erase(iter) ;
            }
            else
              iter++ ;
          }
        }
        //
        // Ce BBFilsItem est cr�ateur de bo�te de dialogue,
        // si sa patpatho est vide il faudra la remplir (si elle a lieu)
        // depuis la patpatho globale, pour pouvoir la dispatcher �
        // l'ouverture de la bo�te de dialogue
        //
        if (pBBfils->PatPtahovide())
        {
          //
          // patpatho globale
          //
          NSVectFatheredPatPathoArray* pPatpatho = pControle->getTransfert()->pBBFilsItem->getPatPatho() ;
          if (false == pPatpatho->empty())
          {
            NSPatPathoArray* ContenuPatpatho = (*(pPatpatho->begin()))->getPatPatho() ;
            if ((NULL != ContenuPatpatho) && (false == ContenuPatpatho->empty()))
            {
              //
              // localiser la position de pNSTreeNode dans la patpatho globale
              //
              PatPathoIter iter = ContenuPatpatho->begin() ;
              bool continuer = true ;
              while ((iter != ContenuPatpatho->end()) && (continuer))
              {
                if (((*iter)->getLexique() == pNSTreeNode->getEtiquette())
                                    && (((*iter)->getLigne() + 1) == ligne))
                  continuer = false ;
                else
                  iter++ ;
              }

              if (iter != ContenuPatpatho->end())
              {
                NSVectFatheredPatPathoArray* pNSVectPatPathoArray = pBBfils->getPatPatho() ;
                pNSVectPatPathoArray->vider() ;
                pBBfils->getPatpathoActive(ContenuPatpatho, iter) ;
              }
            }
          }
        }

        //
        // Tuer le champ NSEditDico et fermer le lexique
        //
        if (pEditDico)
        {
          char szThis[20] ;
          sprintf(szThis, "%p", HWindow) ;
          char szDico[20] ;
          sprintf(szDico, "%p", pEditDico->HWindow) ;
          string sMsg = string("developper : deleting EditDico ") + string(szDico) + string(" for TreeWindow ") + string(szThis) ;
          pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

          KillDico() ;
        }

        pNSTreeNode->pControle->getTransfert()->ctrlNotification(BF_UNCHECKED, BF_CHECKED,
	            			pNSTreeNode->pControle->getTransfert()->pTransfertMessage) ;

        NSVectFatheredPatPathoArray* pPatpatho = pBBfils->getPatPatho() ;
        if (false == pPatpatho->empty())
        {
          //tuer les fils correspondant � l'ancienne patpatho

          int NbNoeudSupprime = 1 ;
          bool PatpthoNonVide = false ;
          SupprimerFils(pNSTreeNode, &NbNoeudSupprime, &PatpthoNonVide) ;
          if (PatpthoNonVide)
          {
            // MAJ lignes et colonnes
            iterNSTreeNode it = pNodeArray->begin() ;
            // Mettre � jour les coordonn�es des autres NSTreeNodes
            for (; it != pNodeArray->end(); it++)
              if ((*it)->getLigne() > ligne)
                (*it)->setLigne((*it)->getLigne() - NbNoeudSupprime) ;
          }

          NSPatPathoArray* ContenuPatpatho = (*(pPatpatho->begin()))->getPatPatho() ;
          //dispatcher la patpatho

          DispatcherPatPatho(ContenuPatpatho, pNSTreeNode, DecalageLigneFils, "") ;
					pNSTreeNode->SetImageIndex(0) ;
          pNSTreeNode->SetSelectedImageIndex(0, true) ;
          elementFilGuide = true ;

          SetDirty(true) ;        }      }
      //
      // Element non cr�ateur de boite de dialogue
      //
      else
      {
        //
        // Affichage de fils propos�s
        //
        if (pBBfils->FilsProlongeable)
        {                                      //
          (*DecalageLigneFils) = 0 ;
          bool bAutoriserFilsPropose = true ; //autoriser la cr�ation de
                                                     //fils propos�s ou non
                                                    //
          //
          // V�rifier qu'aucun anc�tre de pNSTreeNode ne fait partie
          // de ses fils, sinon cr�er un fils classique.
          // (Exemple: ant�c�dent chrirgicaux)
          //
          NSTreeNode* Pere = pNSTreeNode->pere ;
          bool continuer = true ;
          while (Pere && continuer)
          {
            if (string(pDonnees->fils).find(Pere->getEtiquette()) != NPOS)
            {
              bAutoriserFilsPropose = false ;
              continuer = false ;
            }
            else
              Pere = Pere->pere ;
          }
          if (bAutoriserFilsPropose)
          {
            //if (pBBfils->pDonnees->ouvreDialogue[0] == 'O')

            //extraire les �tiquette des fils
            VecteurChaine* pVect = new VecteurChaine ;
            DecomposeChaineTL(pVect, string(pDonnees->fils)) ;
            //inverser ce tableau!!!!!!!!
            reverse(pVect->begin(), pVect->end()) ;
            IterString fils = pVect->begin() ;
            int cardinal = 0 ;

            //
            // Nombre de fils fictifs qui vont �tre affich�s
            //
            for (; fils != pVect->end(); fils++)
              if (!pNSTreeNode->VectFils.Contient(*(*fils)))
                cardinal++ ;
            //
            // D�caler les NSTreeNodes qui existent et dont la
            // ligne est sup�rieure � ligne
            //
            iterNSTreeNode it = pNodeArray->begin();
            for (; it != pNodeArray->end(); it++)
              if ((*it)->getLigne() > ligne)
                (*it)->setLigne((*it)->getLigne() + cardinal) ;

            fils = pVect->begin() ;
            for (; fils != pVect->end(); fils++)
            {
              //
              // MAJ des coordonn�es des fils et des petits fils
              // de pNSTreeNode
              //pNSTreeNode->MettreAJourLigne(DecalageLigneFils);
              // Verifier si cet �l�ment est l'�tiquette d'un fils
              // existant de pNSTreeNode
              //
              if (!pNSTreeNode->VectFils.Contient(*(*fils)))
              {
                AjouteFilsFictif(pNSTreeNode, Noeud, ligne + cardinal, colonne + 1,
			            				*(*fils), true, CreerFilsChampEdit, bDateHeure) ;
                cardinal-- ;
                elementFilGuide = true ;
              }
            }
            // Attention : suite � l'astuce hafedhienne d'inverser
            // le tableau de fils du fil guide, il est n�cessaire
            // d'inverser le tableau de fils du NSTreeNode
            reverse(pNSTreeNode->VectFils.begin(), pNSTreeNode->VectFils.end()) ;

            delete pVect ;
          }
          else //cr�ation de fils et de fr�re fictifs
          {
            AutoriserCreationFils(pNSTreeNode, Noeud) ;
            AutoriserCreationFrere(pNSTreeNode) ;
          }
          pBBfils->FilsProlongeable = false ;
          SetDirty(true) ;
        }
      }
    }
    else
      pBBfils->FilsProlongeable = false ;

    delete pDonnees ;
    //
    //cr�ation de fils et de fr�res classiques
    //
    if (!elementFilGuide)
    {
      *DecalageLigneFils = 0 ;
      int CreationFils = 1 ;
      if ((pNSTreeNode) && (!(pNSTreeNode->VectFils.empty())))
      {
        iterNSTreeNode iter = pNSTreeNode->VectFils.begin() ;
        // chercher un �l�ment non instanci� : fictif (non li�) et non propos�
        // et dont le code lexique ne commence pas par V (chiffr�e)

        for (; (iter != pNSTreeNode->VectFils.end()) && (CreationFils); iter++)
        {
          if ((((*iter)->estFictifPur()) && (!(*iter)->estPropose)) ||
                        ((*iter)->CreateurChampEdit))
            CreationFils = 0;
        }
      }
      if (CreationFils && !bInit)
      {
        SetDirty(true) ;
        *DecalageLigneFils = 1 ;
        // MAJ des coordonn�es des fils et des petits fils de pNSTreeNode
        pNSTreeNode->MettreAJourLigne(*DecalageLigneFils) ;
        AjouteFilsFictif(pNSTreeNode, Noeud, ligne + 1,
            		  colonne + 1, "", false, CreerFilsChampEdit, bDateHeure) ;
      }
    }
  }
  //
  // Il existe un/des fil(s) propos�(s), ou c'est un texte libre
  //
  else
  {
    *DecalageLigneFils = 0 ;
    int CreationFils = 1 ;
    if ((pNSTreeNode) && (!(pNSTreeNode->VectFils.empty())))
    {
      iterNSTreeNode iter = pNSTreeNode->VectFils.begin() ;
      // Chercher un �l�ment non instanci� : fictif (non li�) et non propos�
      // et dont le code lexique ne commence pas par V (chiffr�e)
      for (; (iter != pNSTreeNode->VectFils.end()) && (CreationFils); iter++)
      {
        if ((((*iter)->estFictifPur()) && (!(*iter)->estPropose))
                    || ( (*iter)->CreateurChampEdit ))
          CreationFils = 0 ;
      }
    }
    if (CreationFils)
    {
      SetDirty(true) ;
      //
      // Cr�ation classique de fils et de fr�re
      //
      *DecalageLigneFils = 1 ;
      // MAJ des coordonn�es des fils et des petits fils de pNSTreeNode
      pNSTreeNode->MettreAJourLigne(*DecalageLigneFils) ;
      AjouteFilsFictif(pNSTreeNode, Noeud, ligne + 1,
                  colonne + 1, "", false, CreerFilsChampEdit, bDateHeure) ;
    }
  }
  pNSTreeNode->ExpandTousNoeud() ;
}
catch (...)
{
	erreur("Exception NSTreeWindow::developper", standardError, 0) ;
}
}

//--------------------------------------------------------------------// Supprimer au niveau interface et structure de donn�es les fils et petits
// fils de  pNSTreeNode
//--------------------------------------------------------------------
void
NSTreeWindow::SupprimerFils(NSTreeNode* pNSTreeNode, int* NbNoeudSupprime, bool* PatpthoNonVide)
{
    if ((!pNSTreeNode) || (pNSTreeNode->VectFils.empty()))
        return;

    iterNSTreeNode iterPath = pNSTreeNode->VectFils.begin();
    while (iterPath != pNSTreeNode->VectFils.end())
    {
        NSTreeNode* pNSTemp = (*iterPath);
   	    (*iterPath)->Delete();
        DetruitFils(NbNoeudSupprime, (*iterPath));

        // Enlever (*iter) de l'Array de son p�re
        pNSTreeNode->VectFils.EnleverElement(pNSTemp);

        *PatpthoNonVide = true;
        pNodeArray->EnleverElement(pNSTemp);
        delete pNSTemp;
    }
}

//----------------------------------------------------------------------// R�ponse � une touche du clavier
//----------------------------------------------------------------------
void
NSTreeWindow::EvTvKeyDown(TTwKeyDownNotify& nhmr){
  TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNodeSelection = GetNSTreeNode(&noeud) ;

	// Alt + Touche
  if (GetKeyState(VK_MENU) < 0)
  {
    // Alt M : Modifier le noeud
    //
    if ('M' == nhmr.wVKey)
      Modifier() ;
    else if (VK_RETURN == nhmr.wVKey)
      InsereApres() ;
  }
  //
  // Ctrl + Touche
  //
  else if (GetKeyState(VK_CONTROL) < 0)
  {
    if ((NULL == pNSTreeNodeSelection) || (false == isRealNode(pNSTreeNodeSelection)))
      return ;

    // Ctrl C : Copier
    //
    if      ('C' == nhmr.wVKey)
    {
      ModifierTexteLibre = true ;      CopierNode(pNSTreeNodeSelection) ;
    }
    // Ctrl V : Coller
    //
    else if ('V' == nhmr.wVKey)
    {
      ModifierTexteLibre = true ;      CollerNode(pNSTreeNodeSelection) ;
    }
    // Ctrl X : Couper
    //
    else if ('X' == nhmr.wVKey)
    {      ModifierTexteLibre = true ;
      CouperNode(pNSTreeNodeSelection) ;
    }
    // S�lection au clavier des items 0+,1+,2+,3+,4+
    //    else if ((nhmr.wVKey >= '0') && (nhmr.wVKey <= '4'))
      FixeInteret(nhmr.wVKey) ;
    else if ((nhmr.wVKey >= VK_NUMPAD0) && (nhmr.wVKey <= VK_NUMPAD4))
      FixeInteret(nhmr.wVKey) ;
    //
    // Ctrl N :
    // S�lection au clavier du switch positif/n�gatif pour la certitude (0/100)    //
    else if ('N' == nhmr.wVKey)
    {
      if (string("WCE001") == pNSTreeNodeSelection->getCertitude())
 				FixeCertitude(100) ;
      else
        FixeCertitude(0) ;
    }
    else if ('J' == nhmr.wVKey)
    {
      Classifier() ;    }
    else if ('P' == nhmr.wVKey)
    {
      NewPreoccup() ;    }
  }
  //
  // Touches ordianires (ni Alt, ni Ctrl)
  //
  else
  {
    //
		// touche Inser : cr�er �ventuellement un fr�re (au dessus)    //                pour le noeud en question
    if (VK_INSERT == nhmr.wVKey)
    {
      if (NULL == pNSTreeNodeSelection)
        return ;
      // Ne rien faire s'il s'agit d'un noued li�
      if (pNSTreeNodeSelection->estLie())
        return ;

      InsereAvant() ;
    }
    //
    // touche espace : valider un �l�ment
    //
    else if ((VK_SPACE == nhmr.wVKey) || (VK_RETURN == nhmr.wVKey))
    {
      if (NULL == pNSTreeNodeSelection)
        return ;
      // Ne rien faire s'il s'agit d'un noued li�
      if (pNSTreeNodeSelection->estLie())
        return ;
      Valider() ;
    }
    //
    // touche suppr  : supprimer un noeud et ses descendants
    //
    else if (VK_DELETE == nhmr.wVKey)
      EvDelete() ;
    //
    // tab key  : set focus to next control
    //
    else if (VK_TAB == nhmr.wVKey)
    {
      if (pControle && pControle->getNSDialog())
        pControle->getNSDialog()->ActiveControlSuivant(pControle) ;
      else if (pControle && pControle->getMUEView())
      {
        if (GetKeyState(VK_SHIFT) < 0)
          pControle->getMUEView()->SetFocusToPreviousControl((TControl*)this) ;
        else
          pControle->getMUEView()->SetFocusToNextControl((TControl*)this) ;
      }
    }
    else
    {
      // on bloque le clavier si on n'est pas en �dition texte libre
      // pour �viter la s�lection intempestive des items propos�s
      // (ce qui faisait disparaitre les autres items et plantait Nautilus)
      if (bEditionDico)
        DefaultProcessing() ;
    }
  }
}

//----------------------------------------------------------------------// 	cr�er �ventuellement un fr�re	(au dessus) pour le noeud en question
//----------------------------------------------------------------------
void
NSTreeWindow::InsereAvant()
{
	TTreeNode 	Noeud = GetSelection() ;  		  // TTreeNode s�lectionn�
  NSTreeNode* pNSTreeNodeSelection = GetNSTreeNode(&Noeud) ; // NSTreeNode correspondant
  if (NULL == pNSTreeNodeSelection)
    return ;

  NSTreeNode* pNSTreePere = pNSTreeNodeSelection->pere ; // p�re du NSTreeNode
  int ligne  	= pNSTreeNodeSelection->getLigne() ;       // correspondant
  int colonne = pNSTreeNodeSelection->getColonne() ;

    if (pNSTreePere) //si le p�re existe
    {
   	    iterNSTreeNode iter = pNSTreePere->VectFils.begin();
        int CreationGrandFrere = 1;
        // chercher si le p�re a un fils fictif qui se trouve
        // avant pNSTreeNodeSelection
        for (; (iter != pNSTreePere->VectFils.end()) && (CreationGrandFrere); iter++)
   		    if ( ( (*iter)->getLigne() < ligne ) && ((*iter)->estFictifPur()) )
      		    CreationGrandFrere = 0;      //ne pas cr�er un fr�re au dessus
        if (CreationGrandFrere)
        {
            NSTreeNode* pNSTreeFrere = TrouverGrandFrere(pNSTreeNodeSelection, ligne);
            // On a trouv� le fr�re ain� le plus proche de pNSTreeNodeSelection
            if (pNSTreeFrere)
            {
                // D�caler les NSTreeNodes qui existent et dont la ligne est
                // sup�rieure � ligneMax
         	    for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
         		    if ((*iter)->getLigne() > pNSTreeFrere->getLigne())
   					    (*iter)->setLigne((*iter)->getLigne() +  1 );
                AjouteFrereFictifApres(pNSTreeFrere, pNSTreeFrere->getLigne() + 1, pNSTreeFrere->getColonne());
            }
            else
            {
                // D�caler les NSTreeNodes qui existent
         	    for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
         		    if ((*iter)->getLigne() > pNSTreePere->getLigne())
   					    (*iter)->setLigne((*iter)->getLigne() +  1 );
         	    AjouteFilsFictif(pNSTreePere, pNSTreePere,
                pNSTreePere->getLigne() + 1 , pNSTreePere->getColonne() + 1, "", false, false, false);
            }
        }
    }
    else  // si le p�re n'existe pas
    {
        // Touver le TTReenode dont le p�re est le root et qui soit
        // le plus proche de l'�l�ment s�lectionn� (ain�)
        NSTreeNode* pNSTreeFrere  = TrouverGrandFrereFilsRoot(pNSTreeNodeSelection, ligne);

        // On a trouv� le fr�re ain� le plus proche de pNSTreeNodeSelection
        if (pNSTreeFrere)
        {
            // D�caler les NSTreeNodes qui existent et dont la ligne
            // est sup�rieure � ligneMax
            for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
                if ((*iter)->getLigne() >= ligne)
   					(*iter)->setLigne((*iter)->getLigne() +  1 );
            AjouteFrereFictifApres(pNSTreeFrere, ligne ,colonne);
        }
        else
        {
            for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
         	    if ((*iter)->getLigne() >= ligne)
            	    (*iter)->setLigne((*iter)->getLigne() +  1 );
            TTreeNode root = GetRoot();
      	    AjouteFrereFictifAvant(pNSTreeNodeSelection, &root, ligne, colonne, "Debut" );
        }
    }
}

//----------------------------------------------------------------------
//	ajouter un un fr�re et un fils fictifs � un NSTreeNode
//----------------------------------------------------------------------
void
NSTreeWindow::InsereApres()
{
  TTreeNode 	Noeud = GetSelection() ;  						   //TTreeNode s�lectionn�
  NSTreeNode* pNSTreeNodeSelection = GetNSTreeNode(&Noeud); //NSTreeNode correspondant
  if (NULL == pNSTreeNodeSelection)
    return ;
  //
  // supprimer tous les noeuds fictifs autres que ceux qui viennent d'�tre ajout�s
  // par pNSTreeNodeSelection
  //
  int NbNoeudSupprime = 0 ; //nombre de noeuds supprim�s
  int ligneSelectionnee = pNSTreeNodeSelection->getLigne() ; //ligne de l'�l�ment s�lectionn�
  int ligneMax = 0 ; //ligne du dernier �l�ment fictif supprim�

  if (false == pNodeArray->empty())
  {
    iterNSTreeNode iter = pNodeArray->begin() ;
    //tuer les noeuds fictifs purs se trouvant apr�s l'�l�ment selectionn�
    while (pNodeArray->end() != iter)
    {
      if (((*iter)->estFictifPur()) && ((*iter)->getLigne() > (ligneSelectionnee + 2 ))
                && (false == (*iter)->estPropose))
      {
        NSTreeNode* pTemp = *iter ;
        int ligne = (*iter)->getLigne() ;

        if (ligneMax <= ligne)
          ligneMax = ligne ;

        (*iter)->Delete() ;

        NbNoeudSupprime++ ;

        //enlever (*iter) de l'Array de son p�re
        if ((*iter)->pere)
          (*iter)->pere->VectFils.EnleverElement(pTemp) ;

        pNodeArray->EnleverElement(pTemp) ;        delete pTemp ;      }
      else
        iter++ ;
    }
  }

  if (false == pNodeArray->empty())
  {
    iterNSTreeNode it = pNodeArray->begin() ;
    //mettre � jour les coordonn�es des autres NSTreeNodes
    for (; it != pNodeArray->end(); it++)
      if ((*it)->getLigne() > ligneMax)
        (*it)->setLigne((*it)->getLigne() - NbNoeudSupprime) ;
  }

  AjouteElementFictif(pNSTreeNodeSelection, &Noeud, false, false) ;
}

void
NSTreeWindow::InsertTlInEdit()
{
  if ((false == bEditionDico) || (NULL == pEditDico))
    return ;

  pEditDico->CmEditPaste() ;
}

//------------------------------------------------------------------------
// D�truire les fils de pPere , cardinal contient le nombre de fils de pPere
//------------------------------------------------------------------------
void
NSTreeWindow::DetruitFils(int *cardinal, NSTreeNode* pPere)
{
	if ((NULL == pPere) || (NULL == cardinal) || pPere->VectFils.empty())
		return ;

  for (iterNSTreeNode iter = pPere->VectFils.begin();
  		                        iter != pPere->VectFils.end(); iter++)
  {
    (*cardinal)++ ;
    //tuer les fils
    DetruitFils(cardinal, (*iter)) ;
    //enlever  pNSTreeNodeSuppr de pNodeArray
    pNodeArray->EnleverElement(*iter) ;
  }
  pPere->VectFils.vider() ;
}

//----------------------------------------------------------------------
// D�truire un item .
// On d�truit tous les fils de cet item et on met � jour les coordonn�es des NStreeNodes restants
//----------------------------------------------------------------------
void
NSTreeWindow::EvDelete()
{
try
{
  TTreeNode NoeudSuppr = GetSelection() ;  				   //TTreeNode s�lectionn�
  NSTreeNode* pNSTreeNodeSuppr = GetNSTreeNode(&NoeudSuppr) ; //NSTreeNode correspondant

  if (NULL == pNSTreeNodeSuppr)
    return ;

  if (pNSTreeNodeSuppr->estLie())
    return ;

  NSTreeNode* pNSTreePere = pNSTreeNodeSuppr->pere ;     //p�re du NSTreeNode correspondant
  int         ligne       = pNSTreeNodeSuppr->getLigne() ;

  if (pNSTreeNodeSuppr->estPropose)
  {
    //
    // cr�er un pControle "Bidon" pour pouvoir supprimer le noeud fictif
    //
    pNSTreeNodeSuppr->pControle = new NSControle(pContexte, pBBitemNSTreeWindow, pNSTreeNodeSuppr->getEtiquette(), "") ;
    pNSTreeNodeSuppr->pControle->setControle(dynamic_cast<void*>(pNSTreeNodeSuppr)) ;
    pNSTreeNodeSuppr->pControle->setType(pNSTreeNodeSuppr->donneType()) ;
    pNSTreeNodeSuppr->pControle->setNSDialog(pBBitemNSTreeWindow->getDialog()) ;
    pNSTreeNodeSuppr->pControle->setMUEView(pBBitemNSTreeWindow->getView()) ;
    pNSTreeNodeSuppr->Delete() ;
  }
  else
  {
    if (!pNSTreeNodeSuppr->estFictif())
    {
      if (pNSTreeNodeSuppr->pControle->getTransfert())
      {
        //supprimer les fils fictifs avant de supprimer pNSTreeNodeSuppr
        TuerFilsFictif(pNSTreeNodeSuppr) ;
        Message Msg ;
        pNSTreeNodeSuppr->pControle->getTransfert()->ctrlNotification( BF_CHECKED, BF_DELETE, &Msg) ;
      }
      else
        pNSTreeNodeSuppr->Delete() ;
    }
  }

  int cardinal = 1 ; //nb fils et petits fils
  DetruitFils(&cardinal, pNSTreeNodeSuppr) ;
  //enlever  pNSTreeNodeSuppr (et ses fr�res li�s ) de pNodeArray
  pNodeArray->EnleverElement(pNSTreeNodeSuppr) ;

  //enlever  pNSTreeNodeSuppr de l'Array de son p�re
  if (pNSTreePere)
    pNSTreePere->VectFils.EnleverElement(pNSTreeNodeSuppr) ;

  //fr�res li�s
  iterNSTreeNode iter = pNSTreeNodeSuppr->VectFrereLie.begin() ;
  while (iter != pNSTreeNodeSuppr->VectFrereLie.end())
  {
    NSTreeNode* pNSTemp = (*iter) ;
    (*iter)->Delete() ;
    pNodeArray->EnleverElement((*iter)) ;
    if (pNSTreePere)
      pNSTreePere->VectFils.EnleverElement((*iter)) ;
    pNSTreeNodeSuppr->VectFrereLie.EnleverElement((*iter)) ;
    delete pNSTemp ;
  }
  //base de donn��s : MiseAJour !!!!!!!!!!!!!!!!!!!!!!
  if (!pNSTreeNodeSuppr->VectFrereLie.empty())
    cardinal += pNSTreeNodeSuppr->VectFrereLie.size() ;

  delete pNSTreeNodeSuppr ;

  //mettre � jour les coordonn�es des autres NSTreeNodes
  if (false == pNodeArray->empty())
    for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
      if ((*iter)->getLigne() > ligne)
        (*iter)->setLigne((*iter)->getLigne() - cardinal) ;

  if (pNodeArray->empty())
    EvSetFocus(0) ;

  SetDirty(true) ;
}
catch (...){
	erreur("Exception NSTreeWindow::EvDelete.", standardError, 0) ;
}
}

//---------------------------------------------------------------------//tuer r�cursivement les fils fictifs d'un NSTreeNode et mettre � jour les lignes des
//�l�ments qui suivent
//---------------------------------------------------------------------
void
NSTreeWindow::TuerFilsFictif(NSTreeNode* pNSTreeNodePere)
{
	if ((NULL == pNSTreeNodePere) || pNSTreeNodePere->VectFils.empty())
		return ;

  int ligneMax = 0 ; //ligne du dernier �l�ment fictif supprim�
  iterNSTreeNode fils = pNSTreeNodePere->VectFils.begin() ;
  int NbNoeudSupprime = 0 ;
  while (fils != pNSTreeNodePere->VectFils.end())
  {
    if ((*fils)->estFictifPur())
    {
      NSTreeNode* pTemp = *fils ;
      int ligne = (*fils)->getLigne() ;

      if (ligneMax <= ligne)
        ligneMax = ligne ;
      (*fils)->Delete() ;

      NbNoeudSupprime++ ;      //enlever (*iter) de l'Array de son p�re
      pNSTreeNodePere->VectFils.EnleverElement(pTemp) ;

      pNodeArray->EnleverElement(pTemp) ;
      delete pTemp ;
    }
    else
    {
      TuerFilsFictif(*fils) ;
      fils++ ;
    }
  }
  if (NbNoeudSupprime && pNodeArray && (false == pNodeArray->empty()))
  {
    iterNSTreeNode it = pNodeArray->begin() ;
    //mettre � jour les coordonn�es des autres NSTreeNodes
    for (; it != pNodeArray->end(); it++)
      if( (*it)->getLigne() > ligneMax )
        (*it)->setLigne((*it)->getLigne() - NbNoeudSupprime) ;
  }
}

//----------------------------------------------------------------------//----------------------------------------------------------------------
void
NSTreeWindow::EvSetFocus(HWND hWndLostFocus)
{
  bLoosingFocus = false ;

  TWindow::EvSetFocus(hWndLostFocus);
  if (ReadOnly)
    return ;

  //si pas de NSTreeNode
  if (pNodeArray->empty())
    CreeNoeudFictif() ;

  // donner le focus au pEditDico
  if (pEditDico)
  {
    bLanceEdit = true ;

    // pEditDico->pDico->pDicoDialog->setEdit(pEditDico, pEditDico->sTypeLexique) ;
    // pEditDico->SetPositionLexique() ;

    pEditDico->SetFocus() ;
    pEditDico->Invalidate() ;
  }
}

//----------------------------------------------------------------------
//cr�e premier noeud fictif
//----------------------------------------------------------------------
void
NSTreeWindow::Initialise(HWND hWndLostFocus)
{
  TWindow::EvSetFocus(hWndLostFocus) ;
  CreeNoeudFictif() ;
  if (pEditDico)
  {
    bLanceEdit = true ;

    // pEditDico->pDico->pDicoDialog->setEdit(pEditDico, pEditDico->sTypeLexique) ;
    // pEditDico->SetPositionLexique() ;

    pEditDico->SetFocus() ;
    pEditDico->Invalidate() ;
  }
}

//----------------------------------------------------------------------
//cr�e premier noeud fictif
//----------------------------------------------------------------------
void
NSTreeWindow::CreeNoeudFictif()
{
  if (ReadOnly)
    return ;
try{
  NSSuper* pSuper = pContexte->getSuperviseur() ;

  //SetFocus();
  NSTreeNode* pNewNSTreeNode ;

  // Si pas de NSTreeNode
  if (pNodeArray->empty())
  {
    int rep ;
    //si donn�es dans pSuper->pPatPathoCopie proposer de les afficher
    if (AfficheCopieCollee && (false == pSuper->pBufCopie->empty()))
    {
      AfficheCopieCollee = false ;
      rep = MessageBox("Voulez-vous coller les informations du Presse papier dans la nouvelle fiche?", "Message", MB_YESNO) ;
      AfficheCopieCollee = true ;
      if (IDYES == rep)
      {
        DispatcherPatPatho(pSuper->pBufCopie->pPatPatho, 0, 0, "", "EXPAND") ;
        pSuper->pBufCopie->vider() ;
        SetDirty(true) ;
        return ;
      }
    }

    if (AfficheCopieCollee)
    {
      TTreeNode root = GetRoot() ;
      TTreeNode* pAmorce = new TTreeNode(*this, TVI_FIRST) ;
      *pAmorce = root.AddChild(*pAmorce) ;

      pNewNSTreeNode = new NSTreeNode(*pAmorce, pContexte) ;
      pNewNSTreeNode->pControle = 0 ;

      //MAJ ligne et colonne
      pNewNSTreeNode->setLigne(NODES_LIN_BASE) ;
      pNewNSTreeNode->setColonne(NODES_COL_BASE) ;
      pNewNSTreeNode->pere = 0 ;
      pNewNSTreeNode->FrerePilote = 0 ;

      pNodeArray->push_back(pNewNSTreeNode) ;
      sort(pNodeArray->begin(), pNodeArray->end(), sortTreenodes) ;

      pNewNSTreeNode->SelectItem(TVGN_CARET) ;
      pNewNSTreeNode->EditLabel() ;
      delete pAmorce ;
    }
  }
}
catch (...)
{
	erreur("Exception NSTreeWindow::CreeNoeudFictif.", standardError, 0) ;
}
}

//----------------------------------------------------------------------// un noeud a �t� s�lectionn� : quand on applique la fonction
// SelectItem(TVGN_CARET) sur un noeud
//----------------------------------------------------------------------
void
NSTreeWindow::SelChanged()
{
  TWindow::Invalidate() ;
	if (ReadOnly)
    return ;

  if (pEditDico)
  {
    char szThis[20] ;
    sprintf(szThis, "%p", HWindow) ;
    char szDico[20] ;
    sprintf(szDico, "%p", pEditDico->HWindow) ;
    string sMsg = string("SelChanged : deleting EditDico ") + string(szDico) + string(" for TreeWindow ") + string(szThis) ;
    pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

    KillDico() ;
  }

  //SetFocus();
  TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNode)
    return ;

  //if((pNSTreeNode->sTexteGlobal != "") || (pNSTreeNode->FrerePilote))
  //	return;

  int NbNoeudSupprime = 0 ;                          //nombre de noeuds supprim�s
  int ligneSelectionnee  = pNSTreeNode->getLigne() ; //ligne de l'�l�ment s�lectionn�
  int ligneMax = 0 ;                                 //ligne du dernier �l�ment fictif supprim�

  if (pNodeArray->empty())
    return ;

  iterNSTreeNode iter = pNodeArray->begin() ;  //tuer les noeuds fictifs purs se trouvant avant l'�l�ment selectionn�  while (pNodeArray->end() != iter)
  {
    if (((*iter)->estFictifPur()) && ((*iter)->getLigne() < ligneSelectionnee))
    {
      NSTreeNode* pTemp = *iter ;
      int ligne = (*iter)->getLigne() ;

      if (ligneMax <= ligne)
        ligneMax = ligne ;

      (*iter)->Delete() ;

      NbNoeudSupprime++ ;

      //enlever (*iter) de l'Array de son p�re
      if ((*iter)->pere)
        (*iter)->pere->VectFils.EnleverElement(pTemp) ;

      pNodeArray->EnleverElement(pTemp) ;
      delete pTemp ;
    }
    else
      iter++ ;
  }

  if (pNodeArray->empty())
    return ;

  // mettre � jour les coordonn�es des autres NSTreeNodes
  if (NbNoeudSupprime > 0)
    for (iterNSTreeNode it = pNodeArray->begin() ; pNodeArray->end() != it ; it++)
      if ((*it)->getLigne() > ligneMax)
        (*it)->setLigne((*it)->getLigne() - NbNoeudSupprime) ;

  if ((pNSTreeNode->estFictifPur()) && (!pNSTreeNode->estPropose) && !bIniting)
    pNSTreeNode->EditLabel() ;
}

//----------------------------------------------------------------------// �dition
//----------------------------------------------------------------------
bool
NSTreeWindow::TvnBeginLabelEdit(TTwDispInfoNotify& /*nmHdr*/)
{
  if (ReadOnly)
    return true ;
try
{
  char szThis[20] ;
  sprintf(szThis, "%p", HWindow) ;
  string sMsgHeader = string("TvnBeginLabelEdit for TreeWindow ") + string(szThis) + string(" : ") ;
  string sMsg = sMsgHeader + string("Entering.") ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  NS_CLASSLIB::TRect rectEdit, rectangle ;
  //
  // tuer le champ NSEditDico et fermer le lexique
  //
  if (pEditDico)
  {
    char szDico[20] ;
    sprintf(szDico, "%p", pEditDico->HWindow) ;
    sMsg = sMsgHeader + string("deleting EditDico ") + string(szDico)  ;
    pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

    KillDico() ;
  }
  // char texte[1000];

  // GetSelection donne uniquement le HTTREEITEM
  TTreeNode noeud = GetSelection() ;
  pNSTreeNodeEnCours = GetNSTreeNode(&noeud) ;

  if (NULL == pNSTreeNodeEnCours)
  {
    bForceEdit = false ;
    return true ;
  }
  if (pNSTreeNodeEnCours->estPropose)
    return true ;
  if ((pNSTreeNodeEnCours->getEtiquette() != "") &&
      (pNSTreeNodeEnCours->getEtiquette() != "�?????") && (false == bForceEdit))
    return true ;

  if (pNSTreeNodeEnCours->estLie())  {
    pNSTreeNodeEnCours->FrerePilote->SelectItem(TVGN_CARET) ;
    pNSTreeNodeEnCours->FrerePilote->EditLabel() ;
    return true ;
  }

  NS_CLASSLIB::TRect rectBoiteMere = Parent->GetWindowRect();
  //
  // On r�cup�re le rectangle dans lequel elle s'inscrit
  // ATTENTION : le rep�re est fix� sur le TreeView
  //
  pNSTreeNodeEnCours->GetItemRect(rectEdit, true) ;
  //
  // Recalcul du rectangle en prenant le rep�re de la fen�tre
  // dans la zone client de la fenetre m�re.
  // Dans un dialogue, le controle est � X > 0 et Y > 0
  // Dans une fenetre (consultation) le controle est � X = 0 et Y = 0
  // rectEdit.left += Attr.X ;
  // rectEdit.top  += Attr.Y ;
  //
  // s'il s'agit d'un texte libre, donner au champ �dit les dimensions
  // d'un edit multiligne
  //
  if (pNSTreeNodeEnCours->sTexteGlobal != "") //texte libre
  {
    rectEdit.right  = 0 ; //rectBoiteMere.right    - 100;
    rectEdit.bottom = 0 ; //rectBoiteMere.bottom   - 100;
  }
  else
  {
    // rectEdit.right  += Attr.X + 200 ;     //87 42 191 58
    rectEdit.right += 200 ;
    // rectEdit.bottom += Attr.Y ;
  }
  // on garde en m�moire la zone occup�e par le NSEditDico
  rectEditDico = rectEdit ;

  //
  // Activation du NSEditDico
  //
  // uint 		 length = 1000;
  string sChaine ;

  if (!(pNSTreeNodeEnCours->VectFrereLie.empty()))
    sChaine = pNSTreeNodeEnCours->sTexteGlobal ;
  else
    sChaine = pNSTreeNodeEnCours->sLabel ;

  strip(sChaine, stripRight) ;

  if (NULL == pEditDico)
  {
    sMsg = sMsgHeader + string("Creating EditDico.") ;
    pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

    // pEditDico = new NSEditDico(pContexte, Parent, TreeEditId++, pContexte->getSuperviseur()->getDico(), "","", rectEdit.left, rectEdit.top,
    //                            rectEdit.Width(),rectEdit.Height(), 0, true) ;
    pEditDico = new NSEditDico(pContexte, this, TreeEditIdAsConst, pContexte->getSuperviseur()->getDico(), "","", rectEdit.left, rectEdit.top,
                               rectEdit.Width(),rectEdit.Height(), 0, true) ;
    pEditDico->rect = rectEdit ;
    pEditDico->Create() ;

    char szDico[20] ;
    sprintf(szDico, "%p", pEditDico->HWindow) ;
    sMsg = sMsgHeader + string("EditDico ") + string(szDico) + string(" created.") ;
    pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;
  }

  sMsg = sMsgHeader + string("Initiating EditDico.") ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  pEditDico->SetpTreeAEditer(this) ;
  pEditDico->EveilleToi(&sChaine, &rectEdit) ;

  sMsg = sMsgHeader + string("Starting edit process.") ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  // message
  bLanceEdit = true ;
  EntreeEditionDico() ;
  pEditDico->bGardeFocus = true ;
  pEditDico->SetFocus() ;
  // pEditDico->Invalidate() ;

  sMsg = sMsgHeader + string("Leaving.") ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  bForceEdit = false ;
  return TRUE ;
}
catch (...)
{	erreur("Exception NSTreeWindow::TvnBeginLabelEdit.", standardError, 0) ;
  return TRUE ;
}
}

//----------------------------------------------------------------------
//d�velopper ou non un TReeNode ( + ou -)
//pour chaque noeud , lui mettre � jour son affichage en tenant compte des
//�tiquettes de ses fils et de son champ sVisible
//----------------------------------------------------------------------
void
NSTreeWindow::AfficheLibelle()
{
  if (true == pNodeArray->empty())
    return ;

  iterNSTreeNode iterNode = pNodeArray->begin() ;

  //on cache les noeuds non visibles
  for (; iterNode != pNodeArray->end(); iterNode++)
  {
    string sLabel = (*iterNode)->sLabel ;
    if (((*iterNode)->getVisible() == "0") && (!(*iterNode)->VectFils.empty()))
    {
      iterNSTreeNode fils = (*iterNode)->VectFils.begin();
      //
      // si le fils est lui m�me p�re, mettre "..." devant son �tiquette
      //
      string sSuite = string("") ;
      if (!(*fils)->VectFils.empty())
        sSuite = "..." ;
      else
        sSuite = "";
      //
      // Il s'agit d'une valeur chiffr�e
      //
      if ((*fils)->CreateurChampEdit)
      {
        if (((*fils)->sLabel.find("<") != NPOS) ||
                  ((*fils)->sLabel.find(">") != NPOS))
          sLabel += " " + (*fils)->sLabel ;
        else
          sLabel += " : " + (*fils)->sLabel ;
        (*iterNode)->SetText(sLabel.c_str(), true) ;
      }
      //
      // Il s'agit d'une date ou d'une heure
      //
      else if ((*fils)->DateHeure)
      {
        sLabel += " : " + (*fils)->sLabel ;
        (*iterNode)->SetText(sLabel.c_str(), true) ;
      }
      else
      {
        sLabel += " (" ;
        while (fils != (*iterNode)->VectFils.end())
        {
          if ((!(*fils)->estLie()) &&((*fils)->sLabel != ""))
          {
            if (!(*fils)->estLie())
            {
              string sLabelAffiche = "";
              if ((*fils)->sTexteGlobal != "") //si texte libre
              {
                //premier " "
                size_t pos  = (*fils)->sLabel.find(" ") ;
                sLabelAffiche = (*fils)->sLabel ;
                if (pos != NPOS)
                {
                  sLabelAffiche = string(((*fils)->sLabel), 0, pos) ;
                  sLabelAffiche = sLabelAffiche.c_str() + string("...") ;
                }
              }
              else
                sLabelAffiche = (*fils)->sLabel ;
              //
              // si le fils est lui m�me p�re, mettre "..."
              // devant son �tiquette
              // sauf s'il s'agit de texte libre
              //              string sSuite = "" ;
              if ((!(*fils)->VectFils.empty()) &&
                              (sLabelAffiche.find("...") == NPOS))
              {
                //si au moins un fils de (*fils) a un sLabel non vide
                bool continuer = true ;
                iterNSTreeNode petitFils = (*fils)->VectFils.begin() ;
                while ((petitFils != (*fils)->VectFils.end()) && continuer)
                {
                  if ((*petitFils)->sLabel != "")
                  {
                    sSuite = "..." ;
                    continuer = false ;
                  }
                  else
                    petitFils++ ;
                }
              }
              else
                sSuite = "" ;

              if ((*fils)->sLabel != "")
              {
                if (*fils == (*iterNode)->VectFils.back()) //le dernier
                  sLabel += sLabelAffiche.c_str() + sSuite + string(")") ;
                else
                  sLabel += sLabelAffiche.c_str() + sSuite + string(", ") ;
              }
            }
          }
          fils++ ;
        }
      }
      (*iterNode)->CollapseTousNoeud() ;
      AfficheInteretMaximum((*iterNode)) ; //affiche pour pNSTreeNodeDblClk l'inter�t le plus �lev�
                          //parmi ceux de ses descendants
      if ((sLabel != " (") &&(sLabel != ((*iterNode)->sLabel + " ()")))
        (*iterNode)->SetText(sLabel.c_str(), true) ;
    }
    else
      (*iterNode)->ExpandTousNoeud() ;
  }
}

//----------------------------------------------------------------------
//d�velopper ou non un TReeNode ( + ou -)
//----------------------------------------------------------------------
bool
NSTreeWindow::TvnItemExpanDing(TTwNotify& nmHdr)
{
try
{
	NSTreeNode* pNSTreeNodeSelection = GetNSTreeNode(nmHdr.itemNew.hItem) ; //NSTreeNode correspondant
	if (NULL == pNSTreeNodeSelection)
		return false ;

	NS_CLASSLIB::TRect rectEdit ;
	//
	// Cacher NSEditDico
	//
	if (NULL != pEditDico)
		pEditDico->Show(SW_HIDE) ;

	string sLabel = "" ;
	string sLabelAnnexe = "" ;

  /*
		TVE_COLLAPSE      Collapses the list.
    TVE_COLLAPSERESET Collapses the list and removes the child items.
                      Note that TVE_COLLAPSE must also be specified.
		TVE_EXPAND	      Expands the list.
		TVE_TOGGLE	      Collapses the list if it is currently expanded
                      or expands it if it is currently collapsed.
	*/
	//
	if (nmHdr.action == TVE_COLLAPSE) // on clique sur - : prendre les �tiquettes
                                      // des fils et les coller
                                      // � celle de leur p�re
	{
    sLabel = pNSTreeNodeSelection->sLabel.c_str() ;
    if (false == pNSTreeNodeSelection->VectFils.empty())
    {
      pNSTreeNodeSelection->SetVisible("0") ;
      iterNSTreeNode fils = pNSTreeNodeSelection->VectFils.begin() ;
      (*fils)->SetVisible("0") ;

      string sChemin ;
      pNSTreeNodeSelection->formerChemin(&sChemin) ;
      NSCutPaste CP(pContexte) ;
      pNSTreeNodeSelection->formerPatPatho(&CP) ;
      GlobalDkd Dcode(pContexte, sLang, sChemin, CP.pPatPatho) ;
      Dcode.decode(pContexte->getSuperviseur()->getDico()->dcTiret) ;
      sLabel = *(Dcode.sDcodeur()) ;

      //
      //Il s'agit d'une valeur chiffr�e
      //
      /*if ((*fils)->CreateurChampEdit)
      {
          if (((*fils)->sLabel.find("<") != NPOS) || ((*fils)->sLabel.find(">") != NPOS))
            sLabel += " " + (*fils)->sLabel;
          else
            sLabel += " : " + (*fils)->sLabel;
        pNSTreeNodeSelection->SetText(sLabel.c_str(), true);
          //affiche pour pNSTreeNodeDblClk l'inter�t le plus �lev�
          //parmi ceux de ses descendants
          AfficheInteretMaximum(pNSTreeNodeSelection);
      }
      //
      //Il s'agit d'une date ou d'une heure
      //
      else if((*fils)->DateHeure)
      {
        sLabel += " : " + (*fils)->sLabel;
        pNSTreeNodeSelection->SetText(sLabel.c_str(), true);
          //affiche pour pNSTreeNodeDblClk l'inter�t le plus �lev�
          //parmi ceux de ses descendants
          AfficheInteretMaximum(pNSTreeNodeSelection);
      }
      else
      {
          sLabel += " (";        //
          sLabelAnnexe = sLabel; // Utile pour savoir si les fils ont
                                 // des �tiquettes ou non
        while (fils != pNSTreeNodeSelection->VectFils.end())
          {
              if ((!(*fils)->estLie()) && ((*fils)->sLabel != ""))
              {
                  string sLabelAffiche = "";
                  if ((*fils)->sTexteGlobal != "") //si texte libre
                  {
                      //premier " "
                      sLabelAffiche = (*fils)->sLabel;
                      size_t pos  = (*fils)->sLabel.find(" ");
                      if (pos != NPOS)
                      {
                          sLabelAffiche = string(((*fils)->sLabel), 0, pos);
                        sLabelAffiche = sLabelAffiche.c_str() + string("...");
                      }
                  }
                  else
                      sLabelAffiche = (*fils)->sLabel;
                  //
                  // si le fils est lui m�me p�re, mettre "..."
                  // devant son �tiquette
                  string sSuite = "";
                  if ((!(*fils)->VectFils.empty()) && (sLabelAffiche.find("...") == NPOS))
                  {
                      // Si au moins un fils de (*fils) a un sLabel non vide
                      bool continuer = true;
                      iterNSTreeNode petitFils = (*fils)->VectFils.begin();
                      while (( petitFils != (*fils)->VectFils.end()) && continuer)
                      {
                          if ((*petitFils)->sLabel != "")
                          {
                        sSuite = "...";
                              continuer = false;
                          }
                          else
                            petitFils++;
                      }
                  }
                  else
                      sSuite = "";
                if ((*fils)->sLabel != "")
                  {
                if (*fils == pNSTreeNodeSelection->VectFils.back()) //le dernier
                      sLabel += sLabelAffiche.c_str() + sSuite + string(")");
                    else
                        sLabel += sLabelAffiche.c_str() + sSuite + string(", ");
                  }
              }
              fils++;
          }
          //
          // V�rifier si on a une parenth�se fermante
          //
          if (sLabel.find(")") == NPOS)
          {
            // Si "," est le dernier caract�re
              if(sLabel[strlen(sLabel.c_str()) - 1] == ' ')
                  sLabel = string(sLabel, 0, strlen(sLabel.c_str()) - 2) + ")";              else
                  sLabel += ")";
          }
          if ((!(sLabelAnnexe == sLabel)) && (sLabel != (pNSTreeNodeSelection->sLabel + " ()")))
            pNSTreeNodeSelection->SetText(sLabel.c_str(), true);
          AfficheInteretMaximum(pNSTreeNodeSelection); //affiche pour pNSTreeNodeDblClk l'inter�t le plus �lev�
                      //parmi ceux de ses descendants
      } */
      if ((!(sLabelAnnexe == sLabel)) && (sLabel != (pNSTreeNodeSelection->sLabel + " ()")))
                pNSTreeNodeSelection->SetText(sLabel.c_str(), true) ;
        AfficheInteretMaximum(pNSTreeNodeSelection) ; //affiche pour pNSTreeNodeDblClk l'inter�t le plus �lev�
                          //parmi ceux de ses descendants
    }
  }
	else if (nmHdr.action == TVE_EXPAND) //	on clique sur + : afficher le label brut
	{
  	AfficheInteretReel(pNSTreeNodeSelection) ;
    pNSTreeNodeSelection->SetText(pNSTreeNodeSelection->sLabel.c_str(), true) ;
    pNSTreeNodeSelection->SetVisible("1") ;
	}
	//
  // Nouvelles coordonn�es de pNSTreeNodeEnCours
  //
  return false ;
}
catch (...)
{
	erreur("Exception NSTreeWindow::TvnItemExpanDing.", standardError, 0);
	return false ;
}
}

//-------------------------------------------------------------------//avertir la treeview que le noeud a �t� contract� ou d�velopp�
//redimensionnement du champ �dit
//-------------------------------------------------------------------
bool
NSTreeWindow::TvnItemExpanded(TTwNotify& /*nmHdr*/)
{
  if (pEditDico)
  {
    int W, H ;
    NS_CLASSLIB::TRect rectNoeud ;
    NS_CLASSLIB::TRect rectEdit ;
    pEditDico->Show(SW_SHOWNORMAL) ;
    pNSTreeNodeEnCours->GetItemRect(rectNoeud, true) ;
    rectEdit = pEditDico->GetWindowRect() ;
    W = rectEdit.Width() ;
    H = rectEdit.Height() ;
    rectEdit.left   = rectNoeud.left ;
    rectEdit.top    = rectNoeud.top ;
    rectEdit.right  = rectEdit.left + W ;
    rectEdit.bottom = rectEdit.top + H ;
    pEditDico->MoveWindow(rectEdit, true) ;
  }
  return false ;
}

//------------------------------------------------------------------//redimensionnement du champ �dit
//------------------------------------------------------------------
void
NSTreeWindow::EvVScroll(uint scrollCode, uint thumbPos, HWND hWndCtl)
{
  TWindow::EvVScroll(scrollCode, thumbPos, hWndCtl);
  if (ReadOnly)
    return ;

  if (pEditDico)
  {
    pEditDico->Show(SW_HIDE) ;
   	//TWindow::EvVScroll(scrollCode, thumbPos, hWndCtl);
    int W,H;
    NS_CLASSLIB::TRect rectNoeud;
    NS_CLASSLIB::TRect rectEdit;
    pEditDico->Show(SW_SHOWNORMAL);
    pNSTreeNodeEnCours->GetItemRect(rectNoeud, true);
    rectEdit = pEditDico->GetWindowRect();
    W = rectEdit.Width() ;
    H = rectEdit.Height();
    rectEdit.left   = rectNoeud.left;
    rectEdit.top    = rectNoeud.top;
    rectEdit.right  = rectEdit.left + W;
    rectEdit.bottom = rectEdit.top + H;
    pEditDico->MoveWindow(rectEdit, true);
    bLanceEdit = true;
    pEditDico->SetFocus();
  }
}

//------------------------------------------------------------------//redimensionnement du champ �dit
//------------------------------------------------------------------
void
NSTreeWindow::EvHScroll(uint scrollCode, uint thumbPos, HWND hWndCtl)
{
  TWindow::EvHScroll(scrollCode, thumbPos, hWndCtl) ;
	if (ReadOnly)
    return ;

  if (pEditDico)
  {
    pEditDico->Show(SW_HIDE) ;
    //TWindow::EvHScroll(scrollCode, thumbPos, hWndCtl);
    int W, H ;
    NS_CLASSLIB::TRect rectNoeud ;
    NS_CLASSLIB::TRect rectEdit ;
    pEditDico->Show(SW_SHOWNORMAL) ;
    pNSTreeNodeEnCours->GetItemRect(rectNoeud, true) ;
    rectEdit = pEditDico->GetWindowRect() ;
    W = rectEdit.Width() ;
    H = rectEdit.Height() ;
    rectEdit.left   = rectNoeud.left ;
    rectEdit.top    = rectNoeud.top ;
    rectEdit.right  = rectEdit.left + W ;
    rectEdit.bottom = rectEdit.top + H ;
    pEditDico->MoveWindow(rectEdit, true) ;
    bLanceEdit = true ;
    pEditDico->SetFocus() ;
  }
}

//------------------------------------------------------------------// redimensionnement du champ �dit
//------------------------------------------------------------------
void
NSTreeWindow::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& rect)
{
  TWindow::Paint(dc, erase, rect) ;
  bPaint = true ;
}

//------------------------------------------------------------------
//redimensionnement du champ �dit
//------------------------------------------------------------------
void
NSTreeWindow::EvPaint()
{
  //TWindow::EvPaint();
  DefaultProcessing() ;
  bPaint = true ;
}

//--------------------------------------------------------//changer la couleur du label du noeud en fonction de son inter�t//--------------------------------------------------------
HBRUSH
NSTreeWindow::EvCtlColor(HDC hdc,HWND hwndchild,UINT ctltype)
{
	TTreeNode node = GetSelection() ;
	NSTreeNode* pNSTreeNodeSelection = GetNSTreeNode(&node) ;
	if (NULL != pNSTreeNodeSelection)
	{
		string interet = pNSTreeNodeSelection->getInteret() ;
    SetBkColor(hdc,RGB(0,255,255)) ;
    if (interet == string("A"))
    	SetTextColor(hdc,RGB(255,0,255)) ;
    else if (interet == string("B"))
    	SetTextColor(hdc,RGB(255,0,255)) ;
    else if (interet == string("C"))
    	SetTextColor(hdc,RGB(255,0,255)) ;
    else if (interet == string("D"))
    	SetTextColor(hdc,RGB(0,255,255)) ;
    else
    	SetTextColor(hdc,RGB(0,0,255)) ;
	}
	return TWindow::EvCtlColor(hdc, hwndchild, ctltype) ;
}

//---------------------------------------------------------------------// savoir si on a � enregistrer ce document ou non
//---------------------------------------------------------------------
void
NSTreeWindow::SetDirty(bool bEtat)
{
  // Par convention, dirty n'est pas mis � true pendant l'initialisation
  if (bIniting)
    return ;

  bDirty = bEtat ;
}

bool
NSTreeWindow::GetDirty()
{
  return bDirty ;
}

//----------------------------------------------------------------------
// s�lectionner le noeud suivant
//----------------------------------------------------------------------
void
NSTreeWindow::NStreeNodeSuivant()
{
  if (pEditDico)
  {
    char szThis[20] ;
    sprintf(szThis, "%p", HWindow) ;
    char szDico[20] ;
    sprintf(szDico, "%p", pEditDico->HWindow) ;
    string sMsg = string("NStreeNodeSuivant : deleting EditDico ") + string(szDico) + string(" for TreeWindow ") + string(szThis) ;
    pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

    KillDico() ;
  }

  SetFocus() ;

  //TTreeNode suivant valide
  TTreeNode node = GetSelection() ;
  NSTreeNode* pNSTreeNodeSelection = GetNSTreeNode(&node) ;

  if (NULL != pNSTreeNodeSelection)
  {
    TTreeNode noeud = pNSTreeNodeSelection->GetNextVisible() ;
    if (noeud)
    {
      NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
      if (NULL != pNSTreeNode)
        pNSTreeNode->SelectItem(TVGN_CARET) ;
    }
  }
}

//----------------------------------------------------------------------
// s�lectionner le noeud pr�c�dent
//----------------------------------------------------------------------
void
NSTreeWindow::NStreeNodePrcedent()
{
  if (pEditDico)
  {
    char szThis[20] ;
    sprintf(szThis, "%p", HWindow) ;
    char szDico[20] ;
    sprintf(szDico, "%p", pEditDico->HWindow) ;
    string sMsg = string("NStreeNodePrcedent : deleting EditDico ") + string(szDico) + string(" for TreeWindow ") + string(szThis) ;
    pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

    KillDico() ;
  }

  SetFocus() ;

  //TTreeNode suivant valide
  TTreeNode node = GetSelection() ;
  NSTreeNode* pNSTreeNodeSelection = GetNSTreeNode(&node) ;
  if (NULL != pNSTreeNodeSelection)
  {
    TTreeNode noeud = pNSTreeNodeSelection->GetPrevVisible() ;
    if (noeud)
    {
      NSTreeNode* pNSTreeNode = GetNSTreeNode(&noeud) ;
      if (NULL != pNSTreeNode)
        pNSTreeNode->SelectItem(TVGN_CARET) ;
    }
  }
}

//----------------------------------------------------------------------//modifier un NSTreeNode
//----------------------------------------------------------------------
void
NSTreeWindow::Modifier()
{
  bForceEdit = true ;
  TTreeNode noeud = GetSelection() ;
  NSTreeNode* pNSTreeNodeSelection = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNodeSelection)
    return ;

  ModifierTexteLibre = true ;
  if (pNSTreeNodeSelection->estLie())
  {
    pNSTreeNodeSelection->FrerePilote->SelectItem(TVGN_CARET) ;
    pNSTreeNodeSelection->FrerePilote->EditLabel() ;
  }
  else
    pNSTreeNodeSelection->EditLabel() ;
}

//----------------------------------------------------------------------//----------------------------------------------------------------------
void
NSTreeWindow::EvKillFocus(HWND hWndGetFocus)
{
  TWindow::EvKillFocus(hWndGetFocus) ;

  //
	//	Quand un contr�le est activ� il re�oit :
	//								WM_SETFOCUS
	//								WM_KILLFOCUS
	//                      WM_PAINT
	//								WM_SETFOCUS
  // il faut ignorer les killFocus tant que ce contr�le n'a pas re�u WM_PAINT
  //

  if (!bPaint)
    return ;
  bPaint = false ;

  if (bLanceEdit)
  {
    bLanceEdit = false ;
    return ;
  }

  if (pEditDico)
  {
    // Means that the dicoDialog is being created
    //
    if (NULL == pEditDico->pDico->pDicoDialog)
      return ;

    if ((hWndGetFocus == pEditDico->HWindow) || IsChild(hWndGetFocus))
      return ;

    if ((pEditDico->pDico->pDicoDialog) &&
        (pEditDico == pEditDico->pDico->pDicoDialog->pEdit))
    {
      if ((hWndGetFocus == pEditDico->pDico->pDicoDialog->HWindow) ||
                (pEditDico->pDico->pDicoDialog->IsChild(hWndGetFocus)))
        return ;
    }

    pEditDico->TextLibre() ;

    if (pEditDico)
    {
      char szThis[20] ;
      sprintf(szThis, "%p", HWindow) ;
      char szDico[20] ;
      sprintf(szDico, "%p", pEditDico->HWindow) ;
      string sMsg = string("EvKillFocus : deleting EditDico ") + string(szDico) + string(" for TreeWindow ") + string(szThis) ;
      pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

      KillDico() ;
    }
  }

  //tuer le noeud fictif s'il est le seul dans la treeview
    /*if(pNodeArray->size() == 1)
    {
   	    NSTreeNode* pNStreeNode = *(pNodeArray->begin());
        if(pNStreeNode->estFictifPur())
        {
            pNStreeNode->Delete();
            pNodeArray->EnleverElement(pNStreeNode);
            delete pNStreeNode;
            if(pEditDico)
   		    {
   			    delete pEditDico;
      		    pEditDico = 0;
   		    }
        }
    }*/
}

void
NSTreeWindow::DicoLostFocus()
{
  char szThis[20] ;
  sprintf(szThis, "%p", HWindow) ;
  string sMsgHeader = string("DicoLostFocus for TreeWindow ") + string(szThis) + string(" : ") ;
  string sMsg = sMsgHeader + string("Entering.") ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  bLoosingFocus = true ;

  if (NULL == pEditDico)
    return ;

  SortieEditionDico() ;

  pEditDico->TextLibre() ;

  if (NULL == pEditDico)
    return ;

  char szDico[20] ;
  sprintf(szDico, "%p", pEditDico->HWindow) ;
  sMsg = sMsgHeader + string("Deleting EditDico ") + string(szDico) ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  KillDico() ;

  sMsg = sMsgHeader + string("Leaving.") ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;
}

void
NSTreeWindow::KillDico()
{
  char szThis[20] ;
  sprintf(szThis, "%p", HWindow) ;
  char szDico[20] ;
  sprintf(szDico, "%p", pEditDico->HWindow) ;
  string sMsg = string("KillDico for TreeWindow ") + string(szThis) + string(" : deleting EditDico ") + string(szDico) ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  // Destroy() will issue a killfocus; we have to prevent the EditDico
  // to call a DicoLostFocus... in order to do that, we switch off the
  // "editing" flag
  //
  SortieEditionDico() ;

  pEditDico->Destroy() ;

  delete pEditDico ;
  pEditDico = 0 ;
}

//----------------------------------------------------------------------
// On utilise EvMouseMove pour pouvoir passer le curseur en mode texte
// lorsqu'il passe sur le champ edit en cours (pEditDico)
// Note : on est oblig�s de le faire au niveau de la TreeWindow car
// la classe NSEditDico n'intercepte pas MouseMove et ne peut changer
// le curseur (on se demande bien pourquoi)
//----------------------------------------------------------------------
void
NSTreeWindow::EvMouseMove(uint modKeys, NS_CLASSLIB::TPoint& point)
{
  // On prend en compte le d�calage de la TreeWindow par rapport � sa m�re
  // X et Y sont > 0 dans le cas d'une boite de dialogue m�re
  // rectEditDico est exprim� en coordonn�es client de la fenetre m�re
  NS_CLASSLIB::TSize origin(Attr.X, Attr.Y) ;
  point += origin ;

  // si on est en �dition dans le pEditDico en cours
  if (bEditionDico)
  {
    // si le pointeur est dans la zone Edit
    if (rectEditDico.Contains(point))
    {
      if (!bCurseurTexte)
      {
        // On passe le curseur en mode texte
        SetCursor(0, IDC_IBEAM) ;
        bCurseurTexte = true ;
      }
    }
    else
    {
      if (bCurseurTexte)
      {
        // On passe le curseur en mode normal
        SetCursor(0, IDC_ARROW) ;
        bCurseurTexte = false ;
      }
    }
  }

  TTreeWindow::EvMouseMove(modKeys, point) ;
}

//----------------------------------------------------------------------
//on tue un noeud fictif pur s'il est unique et le pEDitDico perd le focus
//----------------------------------------------------------------------
void
NSTreeWindow::TuerNoeudFictif()
{
  //tuer le noeud fictif s'il est le seul dans la treeview
  if (pNodeArray->size() == 1)
  {
    NSTreeNode* pNStreeNode = *(pNodeArray->begin());
    if (pNStreeNode->estFictifPur())
    {
      pNStreeNode->Delete() ;
      pNodeArray->EnleverElement(pNStreeNode) ;
      delete pNStreeNode ;
    }
  }
}

//-----------------------------------------------------------------------
// click droit de la souris sur un noeud
//-----------------------------------------------------------------------
void
NSTreeWindow::EvRButtonDown(uint /*modkeys*/, NS_CLASSLIB::TPoint& point)
{
try
{
	//
	// Si on est en cours d'�dition, et que le texte n'est pas vide, on ne
	// fait rien
	//
	if ((bEditionDico) && (pEditDico))
	{    NS_CLASSLIB::TRect rectEdit = pEditDico->GetWindowRect() ;    NS_CLASSLIB::TRect rectThis = GetWindowRect();    int iGlobalX = point.X() + rectThis.Left() ;    int iGlobalY = point.Y() + rectThis.Top() ;    // Point inside the Edit    //    if ((iGlobalX > rectEdit.Left()) && (iGlobalX < rectEdit.Right()) &&        (iGlobalY > rectEdit.Top())  && (iGlobalY < rectEdit.Bottom()))    {      NS_CLASSLIB::TPoint lp = point ;
      NSSuper* pSuper = pContexte->getSuperviseur() ;
      string sPaste = pSuper->getText("treeViewManagement", "paste") ;

      OWL::TPopupMenu *menu = new OWL::TPopupMenu() ;
      menu->AppendMenu(MF_STRING, IDC_PASTE_TL, sPaste.c_str()) ;
      ClientToScreen(lp) ;
      menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow) ;
      delete menu ;            return ;    }  	// on teste dans ce cas si le texte est vide
    // (cas o� on ne doit pas empecher le click)
    int len = pEditDico->GetTextLen() ;
    char far* texte = new char[len + 1] ;
    pEditDico->GetText(texte, len + 1) ;
    string sTexte = string(texte) ;
    delete[] texte ;

    if (sTexte != "")
    	return ;

    SortieEditionDico() ;
	}

	NSSuper* pSuper = pContexte->getSuperviseur() ;
	NS_CLASSLIB::TPoint lp = point ;
	pHitTestInfo->pt = lp ;

	NSTreeNode* pNSTreeNodeSelection = 0;
	pNSTreeNodeSelection = GetNSTreeNode(HitTest(pHitTestInfo));
	if (NULL == pNSTreeNodeSelection)
		return ;

	TPopupMenu *menu = new TPopupMenu() ;

	pNSTreeNodeSelection->SelectItem(TVGN_CARET) ;

	string sRights = pSuper->getText("treeViewManagement", "rightsManagement") ;
	string sInserB = pSuper->getText("treeViewManagement", "insertBefore") ;
	string sInserA = pSuper->getText("treeViewManagement", "insertAfter") ;
	string sModif  = pSuper->getText("treeViewManagement", "modifyNode") ;
	string sAbsent = pSuper->getText("treeViewManagement", "absenceOf") ;
	string sPresen = pSuper->getText("treeViewManagement", "presenceOf") ;
  string sParams = pSuper->getText("treeViewManagement", "parameters") ;
	string sGuides = pSuper->getText("treeViewManagement", "filGuide") ;
	string sEncycl = pSuper->getText("treeViewManagement", "encyclopedia") ;
	string sDel    = pSuper->getText("treeViewManagement", "delete") ;
	string sCut    = pSuper->getText("treeViewManagement", "cut") ;
	string sCopy   = pSuper->getText("treeViewManagement", "copy") ;
  string sPaste  = pSuper->getText("treeViewManagement", "paste") ;
  string sCreHC  = pSuper->getText("treeViewManagement", "createHealtConcern") ;
  string sClassi = pSuper->getText("treeViewManagement", "classify") ;

	if (!ReadOnly)
	{
  	menu->AppendMenu(MF_STRING, IDC_EDITRIGHTS, sRights.c_str()) ;
    menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
	}
	else
	{
  	menu->AppendMenu(MF_GRAYED, 0, sRights.c_str()) ;
    menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
	}

	if (pNSTreeNodeSelection->estLie()) //NSTreeNode repr�sentant la suite d'un texte libre
	{
  	menu->AppendMenu(MF_GRAYED, 0, sInserB.c_str()) ;
    menu->AppendMenu(MF_GRAYED, 0, sInserA.c_str()) ;
    if (pNSTreeNodeSelection->getEtiquette() == "")
    	menu->AppendMenu(MF_GRAYED, 0, sModif.c_str()) ;
    else
    	menu->AppendMenu(MF_STRING, IDC_MODIFIER, sModif.c_str()) ;

    menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
    menu->AppendMenu(MF_GRAYED, 0, sAbsent.c_str()) ;
    menu->AppendMenu(MF_GRAYED, 0, sParams.c_str()) ;
    menu->AppendMenu(MF_GRAYED, 0, sGuides.c_str()) ;
    menu->AppendMenu(MF_GRAYED, 0, sEncycl.c_str()) ;

    menu->AppendMenu(MF_SEPARATOR, 0, 0);
    menu->AppendMenu(MF_GRAYED, 0, sDel.c_str()) ;
	}
	else
	{
  	// El�ment fictif ou texte libre non propos�
    //
    if (pNSTreeNodeSelection->estFictif() &&
            (!pNSTreeNodeSelection->estPropose))
    {
    	menu->AppendMenu(MF_GRAYED, 0, sInserB.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sInserA.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sModif.c_str()) ;

      menu->AppendMenu(MF_SEPARATOR, 0, 0);
      menu->AppendMenu(MF_GRAYED, 0, sAbsent.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sParams.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sGuides.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sEncycl.c_str()) ;

      menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
      menu->AppendMenu(MF_GRAYED, 0, sDel.c_str()) ;
    }
    else if (pNSTreeNodeSelection->estPropose)
    {
    	menu->AppendMenu(MF_GRAYED, 0, sInserB.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sInserA.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sModif.c_str()) ;

      menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
      menu->AppendMenu(MF_GRAYED, 0, sAbsent.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sParams.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sGuides.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sEncycl.c_str()) ;

      menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
      menu->AppendMenu(MF_STRING, IDC_DELETE, sDel.c_str()) ;
    }
    else if (!(pNSTreeNodeSelection->sTexteGlobal == string(""))) //fr�re pilote
    {
    	menu->AppendMenu(MF_STRING, IDC_INSERTFRERE,         sInserB.c_str()) ;
      menu->AppendMenu(MF_STRING, IDC_INSERTELEMENTFICTIF, sInserA.c_str()) ;
      menu->AppendMenu(MF_STRING, IDC_MODIFIER,            sModif.c_str()) ;

      menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
      menu->AppendMenu(MF_GRAYED, 0, sAbsent.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sParams.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sGuides.c_str()) ;
      menu->AppendMenu(MF_GRAYED, 0, sEncycl.c_str()) ;

      menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
      menu->AppendMenu(MF_STRING, IDC_DELETE, sDel.c_str()) ;
      menu->AppendMenu(MF_STRING, IDC_CUT,    sCut.c_str()) ;
      menu->AppendMenu(MF_STRING, IDC_COPY,   sCopy.c_str()) ;

      if (pSuper->pBufCopie->empty())
      	menu->AppendMenu(MF_GRAYED, 0, sPaste.c_str()) ;
      else
      	menu->AppendMenu(MF_STRING, IDC_PASTE, sPaste.c_str()) ;
    }
    else
    {
    	menu->AppendMenu(MF_STRING, IDC_INSERTFRERE,         sInserB.c_str()) ;
      menu->AppendMenu(MF_STRING, IDC_INSERTELEMENTFICTIF, sInserA.c_str()) ;
      menu->AppendMenu(MF_STRING, IDC_MODIFIER,            sModif.c_str()) ;
      menu->AppendMenu(MF_SEPARATOR, 0, 0) ;

      string sCertitude = pNSTreeNodeSelection->Certitude() ;
      if ((sCertitude == "ABSENCE") || (sCertitude == "PRESENCE"))
      {
      	if (pNSTreeNodeSelection->Absence)
        	menu->AppendMenu(MF_STRING, IDC_PRESENCE, sPresen.c_str()) ;
        else
        	menu->AppendMenu(MF_STRING, IDC_ABSENT,   sAbsent.c_str()) ;
      }
      else
      	menu->AppendMenu(MF_STRING, IDC_ABSENT, sAbsent.c_str()) ;

      menu->AppendMenu(MF_STRING, IDC_PARAMETRES, sParams.c_str()) ;
      menu->AppendMenu(MF_STRING, IDC_FILGUIDE,   sGuides.c_str()) ;

      if (pNSTreeNodeSelection->bEncyclop)
      	menu->AppendMenu(MF_STRING, IDC_ENCYCLOP, sEncycl.c_str()) ;
      else
      	menu->AppendMenu(MF_GRAYED, 0, sEncycl.c_str()) ;

      menu->AppendMenu(MF_SEPARATOR, 0, 0) ;      menu->AppendMenu(MF_STRING, IDC_DELETE, sDel.c_str()) ;      menu->AppendMenu(MF_STRING, IDC_CUT,    sCut.c_str()) ;
      menu->AppendMenu(MF_STRING, IDC_COPY,   sCopy.c_str()) ;
      if (pSuper->pBufCopie->empty())
      	menu->AppendMenu(MF_GRAYED, 0, sPaste.c_str()) ;
      else
      	menu->AppendMenu(MF_STRING, IDC_PASTE, sPaste.c_str()) ;

      menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
      menu->AppendMenu(MF_STRING, IDC_TREE_NEWPREOCCUP, sCreHC.c_str()) ;
      menu->AppendMenu(MF_STRING, IDC_CLASSIF,          sClassi.c_str()) ;
    }
  }
  ClientToScreen(lp) ;
  menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow) ;
  delete menu ;
}
catch (...)
{
	erreur("Exception NSTreeWindow::EvRButtonDown.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------
// 					  		D�composer pChaine et mettre ses
//							  		items dans le vecteur pVect
//-------------------------------------------------------------------------
void
NSTreeWindow::DecomposeChaineTL(VecteurChaine* pVect, string sChaine  )
{
try
{
	if (NULL == pVect)
		return ;

	size_t debut = 0 ;
	size_t posit = sChaine.find(string("|")) ;
	if (NPOS == posit)		pVect->push_back(new string(sChaine)) ;
	else
	{
		while ((NPOS != posit) && (posit < strlen(sChaine.c_str())))
		{
    	pVect->push_back(new string(sChaine, debut, posit - debut)) ;
      debut = posit + 1 ;
      posit = sChaine.find(string("|"), debut+1) ;
    }
    pVect->push_back(new string(sChaine, debut, strlen(sChaine.c_str()) - debut)) ;
	}
}
catch (...){
	erreur("Exception NSTreeWindow::DecomposeChaineTL.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------
// double click sur un noeud qui supporte :
//						- 	un texte libre : �diter ce texte
//						-  un NSTreeNode propos� : valider le NSTreeNode et le d�velopper
//						-	un NSTreeNode classique : lui cr�er un fr�re et un fils
//						-  un NSTreeNode prolongeable : le d�velopper, il peut lancer une
//							bo�te de dialogue ou des fils propos�s
//------------------------------------------------------------------------
void
NSTreeWindow::EvLButtonDblClk(uint /*a*/, NS_CLASSLIB::TPoint& p)
{
	// ATTENTION : V�rifier que le double click n'est pas effectu� dans
  //             le NSEditDico en cours (pour l'instant on applique le m�me
  //             traitement)
  if (pEditDico && bEditionDico)
  {
  	ClassLib::TRect rectangleEdit ;
    pEditDico->GetClientRect(rectangleEdit) ;
    if (rectangleEdit.Contains(p))
    	return ;
    else
    	return ;
  }

	Valider() ;
}

// -----------------------------------------------------------------------
//  Activer le noeud en cours
//
//  Si bInit = false c'est une initialisation automatique au d�marrage
// -----------------------------------------------------------------------
voidNSTreeWindow::Valider(bool bInit)
{
try
{
	TTreeNode node = GetSelection() ;	NSTreeNode* pNSTreeNodeDblClk = GetNSTreeNode(&node) ;
	if (NULL == pNSTreeNodeDblClk)
		return ;

	//TTreeWindow::EvLButtonDblClk(a, p);  //appel TvnItemExpanDing
	int ligne ;
	int colonne ;
	int decalage = 0 ;
	// int ligneMax = 0, colonneMax = 0;

	//
	// Analyse du noeud sur lequel est effectu� le double click
	//

	// Si le noeud est fictif (pControle == 0), on l'�dite normalement
	// sauf si c'est un noeud propos� ou un fr�re li� de texte libre
	//
	if (pNSTreeNodeDblClk->estFictif())
  	if ((!pNSTreeNodeDblClk->estPropose) &&
        (pNSTreeNodeDblClk->sTexteGlobal == "") &&
        (!pNSTreeNodeDblClk->FrerePilote))
			return ;

	ligne = pNSTreeNodeDblClk->getLigne() ;
	colonne = pNSTreeNodeDblClk->getColonne() ;
	//
	// Valeur chiffr�e
	//
	if (pNSTreeNodeDblClk->CreateurChampEdit && !bInit)
	{
		bool bCalcul = false ; //calcul dans convert.db
    //
    // Si "CALCUL DYNAMIQUE" recalculer sComplement � partir de convert.db
    //
    if (pNSTreeNodeDblClk->bRecalcul)
    {
    	string sUniteConvert, sMethodeCalcul ;
      NSPatPathoArray* pNSPatPathoEnCours = new NSPatPathoArray(pContexte) ;
      //false pour ne pas tuer pTransfert li� � pBBitemNSTreeWindow
      pBBitemNSTreeWindow->okFermerDialogue(true, false) ;
      BBFilsItem* pBBFilsLanceur  = *(pBBitemNSTreeWindow->aBBItemFils.begin()) ;
      NSFatheredPatPathoArray* pFatheredElement = *(pBBFilsLanceur->getPatPatho()->begin()) ;
      *pNSPatPathoEnCours = *(pFatheredElement->getPatPatho()) ;

      if (pNSCV)
      	pNSCV->CalculValeur(pNSTreeNodeDblClk->pere->getEtiquette(), &(pNSTreeNodeDblClk->sLabel),
			                         		&sUniteConvert, &sMethodeCalcul, pNSPatPathoEnCours) ;
      if (pNSTreeNodeDblClk->sLabel != "")
      	pNSTreeNodeDblClk->sContenuTransfert = pNSTreeNodeDblClk->sLabel ;
      if (sUniteConvert != "")
      	pNSTreeNodeDblClk->SetUnit(sUniteConvert + string("1")) ;
      if (sMethodeCalcul != "")
      	pNSTreeNodeDblClk->pere->SetComplement(sMethodeCalcul) ;
      bCalcul = true ;
      delete pNSPatPathoEnCours ;
    }
    RecupereValeurChiffree(pNSTreeNodeDblClk, bCalcul) ;
	}
  //
  // Date et heure
  //
  else if (pNSTreeNodeDblClk->DateHeure && !bInit)
		RecupereUniteDateHeure(pNSTreeNodeDblClk) ;
  //
  // Texte libre : �dition
  //
  else if (((pNSTreeNodeDblClk->sTexteGlobal != "") ||
        		 (pNSTreeNodeDblClk->FrerePilote)) && !bInit)
	{
  	ModifierTexteLibre = true ;
    if (pNSTreeNodeDblClk->estLie()) //si le NSTreeNode est li� : modifier son fr�re pilote
    {
    	pNSTreeNodeDblClk->FrerePilote->SelectItem(TVGN_CARET) ;
      pNSTreeNodeDblClk->FrerePilote->EditLabel() ;
    }
    else
    	pNSTreeNodeDblClk->EditLabel() ;
	}
  //
  // Prolongement avec des fils fil guide
  //
  else if (NULL != pNSTreeNodeDblClk->pControle /* && !bInit */)
	{
  	if (NULL != pNSTreeNodeDblClk->pControle->getTransfert())
    {
    	//BBFilsItem* rattach� � ce noeud
      BBFilsItem* pBBfils = pNSTreeNodeDblClk->pControle->getTransfert()->pBBFilsItem ;
      if ((NULL != pBBfils) && (pBBfils->FilsProlongeable == false))
      {
      	BBItemData* pDonnees = new BBItemData ;
        //Recherche s�mantique
        bool trouve = RechercheFilGuide(pNSTreeNodeDblClk, pDonnees, pBBfils) ;
        if (!trouve)
        	pBBfils->FilsProlongeable = false ;
        delete pDonnees ;
      }
    }
    //
    // exemple lancement de bo�te de dialogue
    //
    if ((NULL != pNSTreeNodeDblClk->pControle->getTransfert()) &&
        (NULL != pNSTreeNodeDblClk->pControle->getTransfert()->pBBFilsItem) &&
        (true == pNSTreeNodeDblClk->pControle->getTransfert()->pBBFilsItem->FilsProlongeable))
    {
    	decalage = 0 ;
      developper(pNSTreeNodeDblClk ,&node, &decalage, ligne, colonne, false, false, true, bInit) ;
      if (decalage)
      {
      	//d�caler les NSTreeNodes qui existent et dont la ligne est sup�rieure � ligneMaxInit
        for (iterNSTreeNode iter = pNodeArray->begin();
                    						iter != pNodeArray->end(); iter++)
        {
        	if (((*iter)->getLigne() > ligne) &&
                        (!(*iter)->Descendant(pNSTreeNodeDblClk)))
          	(*iter)->setLigne((*iter)->getLigne() + decalage) ;
        }
      }
    }
    //
    // un noeud classique : cr�ation de fr�re et fils
    //
    else
    {
    	pNSTreeNodeDblClk->SetImageIndex(0) ;
      pNSTreeNodeDblClk->SetSelectedImageIndex(0, true) ;
      InsereApres() ;
    }
  }
  //
  // �l�ment propos� : valider pNSTreeNodeDblClk et lui cre�r un fils et
  //							un fr�re ou des fils propos�s
  //
	else if (pNSTreeNodeDblClk->estPropose)
	{
  	string sLibelleTrouve ;
    MiseAjourNSTreeNode(pNSTreeNodeDblClk) ;
    pNSTreeNodeDblClk->estPropose = false ;
    pNSTreeNodeDblClk->SetInteret("A") ;
    //localisation
    string sCodeSens ;
    pContexte->getSuperviseur()->getDico()->donneCodeSens(&(pNSTreeNodeDblClk->getEtiquette()), &sCodeSens) ;

    if ((NULL == pNSTreeNodeDblClk->pControle) ||
        (NULL == pNSTreeNodeDblClk->pControle->getTransfert()) ||
        (NULL == pNSTreeNodeDblClk->pControle->getTransfert()->pBBFilsItem))
			return ;

    BBItem* pBBItem = pNSTreeNodeDblClk->pControle->getTransfert()->pBBFilsItem->getItemFather() ;
		if (NULL == pBBItem)
			return ;

    // On montre l'arbre, avec son noeud nouveau ou modifi�, au Blackboard
    // pBBItem->pBigBoss->showBB();

    pNSTreeNodeDblClk->SetPosition(pBBItem->sLocalisation +         				string(1,cheminSeparationMARK) + sCodeSens) ;

    bool CreerFilsChampEdit = false ;
    bool bDateHeure = false ;
    //
    // Si ce le code lexique de ce pNSTreeNode commence par V (valeur chiffr�e)
    // alors lui cr�er  un fils qui lancera la bo�te d'�dition et
    // r�cup�rera la valeur donn�e et son unit�
    //
    if      (pContexte->getSuperviseur()->getDico()->CodeCategorie(pNSTreeNodeDblClk->getEtiquette()) == string("V"))
    	CreerFilsChampEdit = true ;
    else if (pContexte->getSuperviseur()->getDico()->CodeCategorie(pNSTreeNodeDblClk->getEtiquette()) == "K" )
    	bDateHeure = true ;

    decalage = 0 ;
    developper(pNSTreeNodeDblClk ,&node, &decalage, ligne, colonne, CreerFilsChampEdit, bDateHeure, false, bInit) ;
    pNSTreeNodeDblClk->SetImageIndex(0) ;
    pNSTreeNodeDblClk->SetSelectedImageIndex(0, true) ;
    pNSTreeNodeDblClk->DicoKillFocus(&pNSTreeNodeDblClk->getEtiquette(), "CC") ;
    pNSTreeNodeDblClk->ctrlNotification() ;

    //
    // contracter pNSTreeNode si valeur chiffr�e non suivi de fils guides
    //
    if (CreerFilsChampEdit || bDateHeure)
    {
    	NSTreeNode* pPremFils = *(pNSTreeNodeDblClk->VectFils.begin()) ;
      if ((pPremFils->sLabel != "") && (!(pPremFils->estPropose)))
      {
      	string sLabel ;
        //
        //Contracter le p�re
        //
        sLabel = pNSTreeNodeDblClk->sLabel + " : " + (*(pNSTreeNodeDblClk->VectFils.begin()))->sLabel ;
        pNSTreeNodeDblClk->SetText(sLabel.c_str(), true) ;
        pNSTreeNodeDblClk->CollapseTousNoeud() ;
        AfficheInteretMaximum(pNSTreeNodeDblClk) ; //affiche pour pNSTreeNodeDblClk l'inter�t le plus �lev�
                                        //parmi ceux de ses descendants
      }
    }
    if (decalage)
    {
    	//d�caler les NSTreeNodes qui existent et dont la ligne est sup�rieure � ligneMaxInit
      for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
      	if( ((*iter)->getLigne() > ligne) && (!(*iter)->Descendant(pNSTreeNodeDblClk)))
        	(*iter)->setLigne((*iter)->getLigne() + decalage) ;
    }
	}
}
catch (...)
{
	erreur("Exception NSTreeWindow::Valider.", standardError, 0) ;
}
}

// Virtual node validated by a process (and not the user), don't
// open sub-windows or sub-nodes
//
void
NSTreeWindow::NodeRemoteValidation(NSTreeNode* pNSTreeNode)
{
  if (NULL == pNSTreeNode)
    return ;

  // Creation of BBItem etc
  //
  MiseAjourNSTreeNode(pNSTreeNode) ;

  // If something wrong happened, better leave
  //
  if ((NULL == pNSTreeNode->pControle) ||
      (NULL == pNSTreeNode->pControle->getTransfert()) ||
      (NULL == pNSTreeNode->pControle->getTransfert()->pBBFilsItem))
    return ;

  string sLibelleTrouve ;

  pNSTreeNode->estPropose = false ;
  pNSTreeNode->SetInteret("A") ;

  BBItem* pBBItem = pNSTreeNode->pControle->getTransfert()->pBBFilsItem->getItemFather() ;
  if (NULL == pBBItem)
    return ;

  //localisation
  string sCodeSens ;
  pContexte->getSuperviseur()->getDico()->donneCodeSens(&(pNSTreeNode->getEtiquette()), &sCodeSens) ;

  // On montre l'arbre, avec son noeud nouveau ou modifi�, au Blackboard
  // pBBItem->pBigBoss->showBB();
  pNSTreeNode->SetPosition(pBBItem->sLocalisation +
         				string(1, cheminSeparationMARK) + sCodeSens) ;


  // decalage = 0 ;
  // developper(pNSTreeNodeDblClk ,&node, &decalage, ligne, colonne, CreerFilsChampEdit, bDateHeure, false, bInit) ;

  pNSTreeNode->SetImageIndex(0) ;
  pNSTreeNode->SetSelectedImageIndex(0, true) ;
  // pNSTreeNode->DicoKillFocus(&pNSTreeNodeDblClk->getEtiquette(), "CC") ;
  pNSTreeNode->ctrlNotification() ;
}

//----------------------------------------------------------------------
// affiche pour pNSTreeNode l'inter�t le plus �lev� parmi ceux de ses descendants
//----------------------------------------------------------------------
void
NSTreeWindow::AfficheInteretMaximum(NSTreeNode* pNSTreeNode)
{
  if (NULL == pNSTreeNode)
    return ;

  string sInteret = pNSTreeNode->getInteret() ; //sauvegarde
  string sInteretMax = "" ;
  pNSTreeNode->donneIneretMax(&sInteretMax) ;
  pNSTreeNode->SetInteret(sInteretMax) ;
  pNSTreeNode->Interet() ;
  pNSTreeNode->SetInteret(sInteret) ;
}

//----------------------------------------------------------------------
// affiche l'int�r�t r�el du pNSTreeNode
//----------------------------------------------------------------------
void
NSTreeWindow::AfficheInteretReel(NSTreeNode* pNSTreeNode)
{
	if (NULL == pNSTreeNode)
		return ;

	pNSTreeNode->Interet() ; //afficher l'inter�t r�el de ce noeud
}

//----------------------------------------------------------------------
// r�cuperer une valeur chiffr�e avec son unit�
// bCalcul : calcul dynamique ?
//----------------------------------------------------------------------
void
NSTreeWindow::RecupereValeurChiffree(NSTreeNode* pNSTreeNode, bool bCalcul)
{
try
{
	if (NULL == pNSTreeNode)
		return ;

	string sQualifiant = "" ;
  NS_CLASSLIB::TRect rectEdit ;
  string sLabelUnite ; //label de l'unit� (venant du lexique)
  pNSTreeNode->pere->GetItemRect(rectEdit, true) ;

  if (!pChampEdition)
    pChampEdition = new ChampEdition(this, "VALEUR_CHIFFREE", 255, pContexte, rectEdit, pNSDLLModule);

  pChampEdition->bCalcul = bCalcul;
  if ((pNSTreeNode->getEtiquette().find("�ND") != NPOS) ||
        (pNSTreeNode->getEtiquette().find("/�ND") != NPOS))
   	    pChampEdition->sTypeCalcul = "DYNAMIQUE";
  //
  // Donner les valeurs par d�faut (unit� et valeurs) � pChampEdition
  // ces valeurs proviennent de pNSTreeNode ou de nssavoir.db
  //
  if (pNSTreeNode->sLabel != "")
  {
    size_t posIntervalle = pNSTreeNode->sContenuTransfert.find("<<");
    if (posIntervalle == NPOS) //valeur exacte
    {
      pChampEdition->sValeurExacte = pNSTreeNode->sContenuTransfert;
      //
      // Transformer le point en une virgule
      //
      size_t pos = pChampEdition->sValeurExacte.find(".") ;
      if (pos != NPOS)
        pChampEdition->sValeurExacte.replace(pos, 1, ",") ;
      pChampEdition->sValeurInf = "" ;
      pChampEdition->sValeurSup = "" ;
    }
    else
    {
      pChampEdition->sValeurExacte = "" ;
      pChampEdition->sValeurInf = string(pNSTreeNode->sContenuTransfert, 0, posIntervalle) ;
      pChampEdition->sValeurSup = string(pNSTreeNode->sContenuTransfert, posIntervalle + 2, strlen(pNSTreeNode->sLabel.c_str())) ;
      size_t pos = pChampEdition->sValeurInf.find(".") ;
      if (NPOS != pos)
        pChampEdition->sValeurInf.replace(pos, 1, ",") ;
      pos = pChampEdition->sValeurSup.find(".") ;
      if (NPOS != pos)
        pChampEdition->sValeurSup.replace(pos, 1, ",") ;
    }
  }

  // Unit� ?
  if (pNSTreeNode->getUnit() == "200001")
  {
    sQualifiant = "" ;
    pChampEdition->pUnite->sCode = "200001" ;
  }
  else if (pNSTreeNode->getUnit() != "")
    sQualifiant = pNSTreeNode->getUnit() ;
  else
    // Le p�re la fournit : exemple poids -> kg
    ////unit� dans nssavoir.db
    sQualifiant = TrouverUnite(pNSTreeNode->pere->getEtiquette()) ;

  if (sQualifiant != "")
  {
/*
   	    if (strlen(sQualifiant.c_str()) == (BASE_LEXI_LEN - 1))
      	    sQualifiant += "1";
        pContexte->getSuperviseur()->pDico->donneLibelle(sLang, &sQualifiant, &sLabelUnite);
        pChampEdition->pUnite->sCode = sQualifiant;
        pChampEdition->sUnite = sLabelUnite ;
*/
    pChampEdition->setUnit(sQualifiant) ;
  }
  else //unit� si elle existe fournie par le lexique ou pas d'unit�
  {
    size_t pos  = pNSTreeNode->getEtiquette().find("/") ;
    if (pos != NPOS)
    {
      string sCode = string(pNSTreeNode->getEtiquette(), 0, pos) ;
/*
            if (sCode == "200001")//ne pas afficher "~nombre sans unit�"
         	    sLabelUnite = "";
            else
      		    pContexte->getSuperviseur()->pDico->donneLibelle(sLang, &sCode, &sLabelUnite);
	        	pChampEdition->sUnite = sLabelUnite ;
            pChampEdition->pUnite->sCode = sCode;
*/
      pChampEdition->setUnit(sCode) ;
    }
  }
  pChampEdition->SetCaption(pNSTreeNode->pere->sLabel.c_str()); //titre , exemple "Poids du patient"
  pChampEdition->sEtiquette = pNSTreeNode->pere->getEtiquette() ;
  int execute = pChampEdition->Execute() ;
  if (execute == IDOK)
  {
    //
    // Ne pas accepter les textes libres
    //
    if (string("�?????") == pChampEdition->sUnite)
    {
      string sErrMsg = pContexte->getSuperviseur()->getText("lexiqueManagement", "freeTextNotAllowed") ;
      pContexte->getSuperviseur()->trace(&sErrMsg, 1, NSSuper::trWarning) ;
      erreur(sErrMsg.c_str(), warningError, 0) ;
      pChampEdition->pUnite->SetFocus() ;
      return ;
    }
    string sLivre = "�N0;03" ;
    // Calcul dynamique ou stockage statique
    if ((pChampEdition->sTypeCalcul == "STOCK") ||
            (pChampEdition->sTypeCalcul == ""))
      pNSTreeNode->bRecalcul = false ;

    if (pChampEdition->sTypeCalcul == "DYNAMIQUE")
    {
      pNSTreeNode->bRecalcul = true;
      sLivre = "�ND;03" ;
    }
    pNSTreeNode->CreateurChampEdit = true ;
    pNSTreeNode->Type = string("CL") ;

      /*string sUnit = "";

      if(pChampEdition->sUnite != "")
      	sUnit = string(" ") + pChampEdition->sUnite;

      if(pChampEdition->sValeurExacte != "")
      	pNSTreeNode->sLabel = pChampEdition->sValeurExacte + sUnit;
      else
      	pNSTreeNode->sLabel = "entre " + pChampEdition->sValeurInf + (" et ") +
 				                       pChampEdition->sValeurSup + sUnit;*/

    if (string("") == pChampEdition->pUnite->sCode)
      pChampEdition->pUnite->sCode = "200001" ;

    pNSTreeNode->SetLexique(sLivre) ;
    pNSTreeNode->SetUnit(pChampEdition->pUnite->sCode) ;

    string sComplement ;
    if (pChampEdition->sValeurExacte != "")
    {
      //
      // Transformer la virgule si elle existe en un point
      //
      sComplement = pChampEdition->sValeurExacte ;
      size_t pos = sComplement.find(",") ;
      if (pos != NPOS)
        sComplement.replace(pos, 1, ".") ;
    }
    else
    {
      //
      // Transformer la virgule si elle existe en un point
      //
      string sInf = pChampEdition->sValeurInf ;
      size_t pos = sInf.find(",") ;
      if (pos != NPOS)
        sInf.replace(pos, 1, ".") ;

      string sSup = pChampEdition->sValeurSup ;
      pos = sSup.find(",") ;
      if (pos != NPOS)
        sSup.replace(pos, 1, ".") ;

      sComplement = sInf + ("<<") + sSup;
    }
    pNSTreeNode->SetComplement(sComplement) ;

    string sChemin, sCheminLocal ;
    pNSTreeNode->formerChemin(&sChemin) ;
    pNSTreeNode->formerCheminLocal(&sCheminLocal) ;
    NSCutPaste CP(pContexte) ;
    pNSTreeNode->formerPatPatho(&CP) ;
    GlobalDkd Dcode(pContexte, sLang, sChemin, CP.pPatPatho) ;
    Dcode.decodeNoeud(sCheminLocal) ;
    pNSTreeNode->sLabel = *(Dcode.sDcodeur()) ;

    pNSTreeNode->SetText(pNSTreeNode->sLabel.c_str(), true) ;

    if (!pNSTreeNode->estFictif())
      ReMiseAjourNSTreeNode(pNSTreeNode, pNSTreeNode->getEtiquette(), sComplement) ;
  }

  pChampEdition->sValeurExacte 	= "" ;
  pChampEdition->sValeurSup    	= "" ;
  pChampEdition->sValeurInf    	= "" ;
  pChampEdition->sUnite        	= "" ;
  pChampEdition->sTypeCalcul		= "" ;
  pChampEdition->pUnite->sCode	= "" ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSTreeWindow::RecupereValeurChiffree : ") + e.why() ;
  pContexte->getSuperviseur()->trace(&sErr, 1, NSSuper::trError) ;
  erreur(sErr.c_str(), standardError, 0) ;
  return ;
}
catch (...){
	erreur("Exception NSTreeWindow::RecupereValeurChiffree.", standardError, 0);
}
}

//----------------------------------------------------------------------
// r�cuperer l'unit� d'une valeur chiffr�e type date_heure
//----------------------------------------------------------------------

voidNSTreeWindow::RecupereUniteDateHeure(NSTreeNode* pNSTreeNode)
{
try
{
	if (NULL == pNSTreeNode)
		return ;

	string sUnite = "";
	NS_CLASSLIB::TRect rectEdit;
	string sLabelUnite ; //label de l'unit� (venant du lexique)
	pNSTreeNode->pere->GetItemRect(rectEdit, true);
	string sIdentitePere = pNSTreeNode->pere->getEtiquette() ;

	//
	// Chercher dans nssavoir.db le code lexique qui est li� � celui du p�re
	// de pNewNSTreeNode par le lien "ME" et qui contient l'unit� de la valeur
	// chiffr�e
	//
	sUnite = TrouverUnite(pNSTreeNode->pere->getEtiquette()) ;
	if (sUnite == "")
		return;

	if (!pChampDate)
	{
  	if (sUnite == "2DA01")
    	pChampDate = new NSDate(this, "Date", pContexte, "DATE", rectEdit, pNSDLLModule);
		else if(sUnite == "2HE01")
    	pChampDate = new NSDate(this, "Date", pContexte, "HEURE", rectEdit, pNSDLLModule);
    else
    	return;
	}
	else
		pChampDate->Initialise(sUnite);

  //
  // Donner les valeurs par d�faut (unit� et valeurs) � pChampEdition
  // ces valeurs proviennent de pNSTreeNode ou de nssavoir.db
  //
  if (pNSTreeNode->sLabel != "")
    pChampDate->sValeur = pNSTreeNode->sLabel;


  pChampDate->SetCaption(pNSTreeNode->pere->sLabel.c_str()); //titre
  int execute = pChampDate->Execute();
  if (execute == IDOK)
  {
    if (sUnite != "") //unit� dans nssavoir.db
    {
      pNSTreeNode->sLabel = pChampDate->sValeur;
      pNSTreeNode->AfficheLabel(sUnite);
      if (strlen(sUnite.c_str()) == BASE_SENS_LEN)
      	pContexte->getDico()->donneCodeComplet(sUnite) ;

			pNSTreeNode->SetLexique("�D0;10") ;
			pNSTreeNode->SetUnit(sUnite) ;
			pNSTreeNode->SetText(pNSTreeNode->sLabel.c_str(), true);
      //
      // transformer la virgule, si elle existe, en un point
      //
      string sComplement = pChampDate->sValeur ;
      size_t pos = sComplement.find(",") ;
      if (pos != NPOS)
        sComplement.replace(pos, 1, ".") ;
      pNSTreeNode->sContenuTransfert = sComplement ;      pNSTreeNode->DateHeure =	true ;
      pNSTreeNode->Type  = string("CL") ;
    }
    else
      pNSTreeNode->SetLexique(string("")) ;
	}
  pChampDate->Nettoyer() ;
}
catch (...){
	erreur("Exception NSTreeWindow::RecupereUniteDateHeure.", standardError, 0) ;
}}

//---------------------------------------------------------------------------//Trouver les items �quivalents � sQualifie au sens r�seau s�mantique
//et s'arr�ter au premier ayant un lien de type "ME".
//Renvoyer dans string le qualifiant trouv� sinon "".
//---------------------------------------------------------------------------
string
NSTreeWindow::TrouverUnite(string sQualifie)
{
  if (string("") == sQualifie)
    return string("") ;

  string sQualifiant = chercheClefComposite(sQualifie, "ME") ;
  if (string("") != sQualifiant)
    return sQualifiant ;

  //  // recherche s�mantique sur les qualifiants li�s � sQualifie par le lien
  // sLien et appel recursif sur les sQualifiants
  //
  sQualifiant = chercheClefComposite(sQualifie, "ES") ;
  if (sQualifiant == "")
    return "" ;

  return (TrouverUnite(sQualifiant)) ;
}

//--------------------------------------------------------------------------//recherche composite selon le lien sLien et le qualifi� sQualifie, retourner
//le qualifiant
//---------------------------------------------------------------------------
string
NSTreeWindow::chercheClefComposite(string sQualifie, string sLien)
{
try
{
	if ((sQualifie == "") || (sLien == ""))
		return string("") ;

  string sCodeSens ;
  pContexte->getDico()->donneCodeSens(&sQualifie, &sCodeSens) ;

  if ((strlen(sLien.c_str()) > SAVOIR_LIEN_LEN) || (strlen(sCodeSens.c_str()) > SAVOIR_QUALIFIE_LEN))
    return string("") ;

	NSSuper*  pSuper  = pContexte->getSuperviseur() ;
  NSSavoir* pSavoir = pSuper->getFilGuide()->pSavoir ;
  if (NULL == pSavoir)
    return string("") ;

  CURProps curProps ;
	DBIResult lastError = DbiGetCursorProps(pSavoir->PrendCurseur(), curProps) ;
	if (lastError != DBIERR_NONE)
	{
		erreur("Impossible d'acceder aux propri�t�s de nssavoir.db.", standardError, lastError) ;
		return string("") ;
	}

	Byte* pIndex = new Byte[curProps.iRecBufSize] ;
	memset(pIndex, 0, curProps.iRecBufSize) ;
	DbiPutField(pSavoir->PrendCurseur(), SAVOIR_LIEN_FIELD,     pIndex, (Byte*)(sLien.c_str())) ;
	DbiPutField(pSavoir->PrendCurseur(), SAVOIR_QUALIFIE_FIELD, pIndex, (Byte*)(sCodeSens.c_str())) ;
	pSavoir->lastError = pSavoir->chercheClefComposite("FLECHE",
                                                     NODEFAULTINDEX,
                                                     keySEARCHEQ,
                                                     dbiWRITELOCK,
                                                     pIndex) ;
  delete[] pIndex ;

  if (pSavoir->lastError != DBIERR_NONE)
		return string("") ;

	pSavoir->lastError = pSavoir->getRecord() ;
	if (pSavoir->lastError != DBIERR_NONE)
	{
		erreur("Le fichier nssavoir.db inutilisable.", standardError, pSavoir->lastError) ;
		return string("") ;
	}
	string sQualifiant = string(pSavoir->pDonnees->qualifiant) ;
	return sQualifiant ;
}
catch (...){
	erreur("Exception NSTreeWindow::chercheClefComposite.", standardError, 0) ;
	return string("") ;
}
}

//��������������������������������������������������������������������������//
//		  				fonctions sp�cifiques au Drag and Drop,
//							au copie coll�e, coup�e coll�e
//
//��������������������������������������������������������������������������

//---------------------------------------------------------------//On est sur le noeud � "Dragger"
//---------------------------------------------------------------

bool
NSTreeWindow::EvTvnBeginDrag(TTwNotify& nmHdr)
{
	if (ReadOnly)
		return false ;

try
{
	NSTreeNode* pNSTreeNodeDrag = GetNSTreeNode(nmHdr.itemNew.hItem) ; //NSTreeNode correspondant
	if (NULL == pNSTreeNodeDrag)
		return false ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	if ((pNSTreeNodeDrag->estFictif()) || (pNSTreeNodeDrag->estPropose))
	{
  	pSuper->bDragAndDrop = false ;
    return false ;
	}

	// s'il s'agit d'un fr�re li� , prendre son fr�re pilote
	if (pNSTreeNodeDrag->estLie())
  	pNSTreeNodeDrag = pNSTreeNodeDrag->FrerePilote ;

    pNSTreeNodeDrag->CopyPatPatho("DRAG");

    NS_CLASSLIB::TRect itemRect;

    pSuper->offNode = true;
    pSuper->bDragAndDrop = true;


    pNSTreeNodeDrag->GetItemRect( itemRect );    // Transforme le curseur en curseur de drag    //
  	NS_CLASSLIB::TRect curRect( 0, 0, nmHdr.ptDrag.x, nmHdr.ptDrag.y );
  	curRect &= itemRect; // Get the intersection of the two rectangles.
                       // ( Width()+GetIndent(), Height() ) is the cursor's hotspot
                       // inside the item rect.

    //
  	// Start the drag operation
  	//
    pSuper->DragDrop = new TImageList( pNSTreeNodeDrag->CreateDragImage() );
    pSuper->DragDrop->BeginDrag( 0, curRect.Width()+GetIndent(), curRect.Height() );
    pSuper->DragDrop->DragEnter( *this, nmHdr.ptDrag.x, nmHdr.ptDrag.y );
    SetCapture();

    // We want a fast update.  We'll use a timer instead of EvMouseMove
  	// since we want to be able to scroll when the last (or first) visible
  	// node is targeted (immitating Explorer).  This way resting the drag
  	// image over the last (or first) node will continuously scroll the list
  	//
  	SetTimer( ID_TREETIMER, 60 );

    return true;
}
catch (...){
	erreur("Exception NSTreeWindow::EvTvnBeginDrag.", standardError, 0);
    return false;
}
}

//---------------------------------------------------------------
// On empeche la TreeWindow d'�craser le texte libre lorsqu'on
// a cliqu� hors de la zone d'�dition (d�finie par rectEditDico)
//---------------------------------------------------------------
void
NSTreeWindow::EvLButtonDown( uint modKeys, NS_CLASSLIB::TPoint& pt )
{
try
{
  /********* bug lorsqu'on clicke sur du texte situ� au dessus d'un node
  if (bEditionDico)
  {
    // si le pointeur est dans la zone Edit
    if (rectEditDico.Contains(pt))
      TTreeWindow::EvLButtonDown(modKeys, pt) ;
  }
  ***************************/

  if ((false == bEditionDico) || (NULL == pEditDico))
    TTreeWindow::EvLButtonDown(modKeys, pt) ;
  else
  {
    // on teste dans ce cas si le texte est vide
    // (cas o� on ne doit pas empecher le click)

    int len = pEditDico->GetTextLen() ;
    char far* texte = new char[len + 1] ;
    pEditDico->GetText(texte, len + 1) ;
    string sTexte = string(texte) ;
    delete[] texte ;

    if (string("") == sTexte)   // on sort de l'�dition du pEditDico
    {
      TTreeWindow::EvLButtonDown(modKeys, pt) ;
      SortieEditionDico() ;
    }
  }
}
catch (...){
	erreur("Exception NSTreeWindow::EvLButtonDown.", standardError, 0);
}
}

//---------------------------------------------------------------
//On a atteint le noeud sur lequel on va faire le "dropp"
//---------------------------------------------------------------
void
NSTreeWindow::EvLButtonUp( uint /*modKeys*/, NS_CLASSLIB::TPoint& pt )
{
	if (ReadOnly)
		return ;
try
{
	NSSuper* pSuper = pContexte->getSuperviseur();

	if (bEditionDico && pEditDico)
	{
    // On prend en compte le d�calage de la TreeWindow par rapport � sa m�re
    // X et Y sont > 0 dans le cas d'une boite de dialogue m�re
    // rectEditDico est exprim� en coordonn�es client de la fenetre m�re
    NS_CLASSLIB::TSize origin(Attr.X, Attr.Y);
    pt += origin;

    // on r�cup�re le texte
    int len = pEditDico->GetTextLen();
    char far* texte = new char[len + 1];
    pEditDico->GetText(texte, len + 1);
    string sTexte = string(texte);
    delete[] texte;

    if (string("") != sTexte)
    {
    	// on r�cup�re le IC
      TIC* pIc = new TIC("DISPLAY", 0, 0) ;
      // on suppose constante la hauteur des caract�res
      NS_CLASSLIB::TSize size = pIc->GetTextExtent(texte, 1) ;
      int hauteur = size.Y() ;
      int largeur = 0 ;
      int line  ;
      if (hauteur >= 1)
      	line = (pt.Y() - rectEditDico.top) / hauteur ;
      else
      	line = 0 ;
      int nblines = pEditDico->GetNumLines() ;
      int nbCars ;
      int lineLen ;

      if (line > (nblines - 1))
      {
      	line = nblines - 1 ;
        nbCars = pEditDico->GetLineIndex(line) + pEditDico->GetLineLength(line) ;
      }
      else
      {
      	nbCars = pEditDico->GetLineIndex(line) ;
        lineLen = pEditDico->GetLineLength(line) ;
        string sLigne = string(sTexte, nbCars, lineLen) ;
        int numCar = 0 ;

        while ((numCar <= lineLen) && ((pt.X() - rectEditDico.left) > largeur))
        {
        	numCar++ ;
          size = pIc->GetTextExtent(sLigne.c_str(), numCar) ;
          largeur = size.X() ;
        }

        nbCars += numCar ;
      }
      delete pIc ;
      pEditDico->SetSelection(nbCars, nbCars) ;
    }
    else
    	DefaultProcessing() ;
  }
  else if (pSuper->bDragAndDrop)
  {
  	NS_CLASSLIB::TPoint pt ;
    GetCursorPos(pt) ;

    NS_CLASSLIB::TRect wndRect = GetWindowRect() ;
    if (wndRect.Contains(pt))
    {
      // Clean up...
      //
      pSuper->DragDrop->DragLeave( *this ) ;
      pSuper->DragDrop->EndDrag() ;
      delete pContexte->getSuperviseur()->DragDrop ;
      pSuper->DragDrop = 0 ;
      ReleaseCapture() ;
      pSuper->bDragAndDrop = false ;

      // Get the node that we dropped on
      TTreeNode NodeDrop = GetDropHilite() ;
      NSTreeNode* pNodeDrop = GetNSTreeNode(&NodeDrop) ;
      if (NULL == pNodeDrop)
        return ;
      //
      // Un-drophilite the node we dropped on.  If we don't, very strange
      // TreeView node repainting will occur.
      //
      TTreeNode node( *this, (HTREEITEM)NULL ) ;
      node.SelectItem( TTreeNode::DropHilite ) ;

      if (!pPositionDragAndDrop)
      	pPositionDragAndDrop = new PositionDragAndDrop(this, "DRAG_DROP_COPIE",
                        pContexte, pNSDLLModule) ;

      int execute = pPositionDragAndDrop->Execute() ;
      if (IDOK == execute)
      {
      	if      (pPositionDragAndDrop->sPosition == "AVANT")
        	DragAvant(pNodeDrop, "DRAG") ;
        else if (pPositionDragAndDrop->sPosition == "APRES")
        	DragApres(pNodeDrop, "DRAG") ;
        else
        	DragFils(pNodeDrop, "DRAG") ;
      }
      pPositionDragAndDrop->sPosition = "" ;
      KillTimer(ID_TREETIMER) ;
      Update() ;
    }
    else
    {
    	/* HWND AppWindow = */ WindowFromPoint(pt) ;
    }
  }
  else
  	DefaultProcessing() ;
}catch (...)
{
	erreur("Exception NSTreeWindow::EvLButtonUp.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------
// We'll use a timer message to update our drag image instead of MouseMove
// messages.
//-------------------------------------------------------------------------
void
NSTreeWindow::EvTimer( uint id )
{
  if (ReadOnly)
    return ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;

  if (pContexte->getSuperviseur()->bDragAndDrop && (id == ID_TREETIMER))
  {
    NS_CLASSLIB::TPoint pt ;
    GetCursorPos(pt) ;

    NS_CLASSLIB::TRect wndRect = GetWindowRect() ;
    if (wndRect.Contains(pt))
    {
      ScreenToClient(pt) ;

      // Draw the image at the cursor's position
      //
      TTwHitTestInfo hitTestInfo ;
      hitTestInfo.pt = pt ;

      // Are we on a node?
      if (HitTest(&hitTestInfo))
      {
        TTreeNode dropHilite( *this, hitTestInfo.hItem ) ;
        TTreeItem item ;
        dropHilite.GetItem() ;
        item.mask |= TVIF_STATE ;
        dropHilite.GetItem(&item) ;

        if ( !(item.state & TVIS_DROPHILITED) || pSuper->offNode ) //no superfluous repaints
        {
          pSuper->offNode = false ;

          // If it's on an item, DropHilite the item.
          // In order for things to paint correctly, we have to turn off the
          // drag image, repaint the node, and turn the drag image back on.
          //
          pSuper->DragDrop->DragLeave( *this ) ;

          dropHilite.SelectItem( TTreeNode::DropHilite ) ;

          // This code makes the tree scroll if needed
          //
          TTreeNode next = dropHilite.GetNextVisible() ;
          if ( next )
            next.EnsureVisible() ;
          TTreeNode prev = dropHilite.GetPrevVisible() ;
          if ( prev )
            prev.EnsureVisible() ;

          // Turn the list back on
          pSuper->DragDrop->DragEnter( *this, pt.x, pt.y ) ;
        }
      }
      else if (!pSuper->offNode)//We're not on a node
      {
        pSuper->offNode = true; //We won't repaint again unless we need to...
        pSuper->DragDrop->DragLeave( *this );
        ::SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_NO)) );
        pSuper->DragDrop->DragEnter( *this, pt.x, pt.y );
      }
      // Move the drag image over here...
      //
      pSuper->DragDrop->DragMove( pt.x, pt.y );
    }
    else
      ::SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_HAND)) ) ;
  }
  else
    DefaultProcessing() ;
}

//------------------------------------------------------------------------
//sCopie vaut "DRAG" si pSuper->pPatPathoDragDrop "COPIE" si pSuper->pPatPathoCopie
//copie la patpatho sous pNodeDrop
//------------------------------------------------------------------------
void
NSTreeWindow::CopyBranch(NSTreeNode* pNodeDrop, string sCopie, NSCutPaste* pCP)
{
	if (NULL == pNodeDrop)
		return ;

  int ligneDrop   = pNodeDrop->getLigne() ;
  int colonneDrop = pNodeDrop->getColonne() ;
  int DecalageLigneFils = 1 ;

  NSCutPaste* pCutPaste = pCP ;
	if (NULL == pCutPaste)
	{
  	if      (sCopie == "DRAG")
    	pCutPaste = pContexte->getSuperviseur()->pBufDragDrop ;
		else if (sCopie == "COPIE")
    	pCutPaste = pContexte->getSuperviseur()->pBufCopie ;
	}

  NSCutPastTLArray* pTLArray = pCutPaste->pTextesLibres ;
  NSPatPathoArray   Patho(pContexte) ;
  Patho = *(pCutPaste->pPatPatho) ;

  DecalageLigneFils = Patho.Taille() ;

  int ligneMax   = ligneDrop ;
  int colonneMax = colonneDrop ;

  // On ins�re avant les fictifs
  GetMaxCoordonnees(pNodeDrop, &ligneMax, &colonneMax, true /*bJustReal*/) ;
  if (!(pNodeArray->empty()))  {  	iterNSTreeNode iter = pNodeArray->begin() ;
    //mettre � jour les coordonn�es des autres NSTreeNodes
    for (; iter != pNodeArray->end(); iter++)
    	if ((*iter)->getLigne() > ligneMax )
      	(*iter)->setLigne((*iter)->getLigne() + DecalageLigneFils) ;
  }
  DispatcherPatPatho(&Patho, pNodeDrop, 0, "", "EXPAND", pTLArray) ;
  SetDirty(true) ;

  Invalidate() ;
}

//-------------------------------------------------------------------
//supprimer un noeud et ses fils et mettre � jour les lignes et les colonnes
//-------------------------------------------------------------------
void
NSTreeWindow::SupprimerNoeud(NSTreeNode* pNSTreeNodeSuppr)
{
	if (NULL == pNSTreeNodeSuppr)
		return ;

try
{
	int ligneDrag = pNSTreeNodeSuppr->getLigne();

	TuerFilsFictif(pNSTreeNodeSuppr);

	if (pNSTreeNodeSuppr->pControle)
	{
		Message Msg ;
    pNSTreeNodeSuppr->pControle->getTransfert()->ctrlNotification(BF_CHECKED, BF_DELETE, &Msg) ;
	}

	int cardinal = 1 ; //nb fils et petits fils
	DetruitFils(&cardinal, pNSTreeNodeSuppr) ;
	//enlever  pNSTreeNodeSuppr (et ses fr�res li�s ) de pNodeArray
	pNodeArray->EnleverElement(pNSTreeNodeSuppr) ;

	//enlever  pNSTreeNodeSuppr de l'Array de son p�re
	if (pNSTreeNodeSuppr->pere)
		pNSTreeNodeSuppr->pere->VectFils.EnleverElement(pNSTreeNodeSuppr) ;

	//fr�res li�s
	iterNSTreeNode iter = pNSTreeNodeSuppr->VectFrereLie.begin() ;
	while (iter != pNSTreeNodeSuppr->VectFrereLie.end())
	{
  	NSTreeNode* pNSTemp = (*iter) ;
    (*iter)->Delete() ;
    pNodeArray->EnleverElement((*iter));
    if (pNSTreeNodeSuppr->pere)
    	pNSTreeNodeSuppr->pere->VectFils.EnleverElement((*iter));
    pNSTreeNodeSuppr->VectFrereLie.EnleverElement((*iter));
    delete pNSTemp ;
	}
	//base de donn��s : MiseAJour !!!!!!!!!!!!!!!!!!!!!!
	if (false == pNSTreeNodeSuppr->VectFrereLie.empty())
		cardinal += pNSTreeNodeSuppr->VectFrereLie.size() ;

	delete pNSTreeNodeSuppr ;

	//mettre � jour les coordonn�es des autres NSTreeNodes
	if (false == pNodeArray->empty())
		for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
    	if ((*iter)->getLigne() > ligneDrag)
      	(*iter)->setLigne((*iter)->getLigne() - cardinal) ;
}
catch (...)
{
	erreur("Exception NSTreeWindow::SupprimerNoeud.", standardError, 0);
}
}

//-----------------------------------------------------------------------
//copier le noeud pNSTreeNodeDrag (et ses fils )
//----------------------------------------------------------------------
void
NSTreeWindow::CopierNode(NSTreeNode*  pNSTreeNodeDrag)
{
	pNSTreeNodeDrag->CopyPatPatho("COPIE");
}

//-----------------------------------------------------------------------//coller le noeud pNSTreeNodeDrag (et ses fils )
//----------------------------------------------------------------------
void
NSTreeWindow::CollerNode(NSTreeNode* pNodeDrop)
{
try
{
	if (NULL == pNodeDrop)
		return ;

	if (!pPositionDragAndDrop)
		pPositionDragAndDrop = new PositionDragAndDrop(this, "DRAG_DROP_COPIE",
               		pContexte, pNSDLLModule) ;

	int execute = pPositionDragAndDrop->Execute() ;
	if (execute == IDOK)
	{
		if 		(pPositionDragAndDrop->sPosition == "AVANT")
			DragAvant(pNodeDrop, "COPIE") ;
    else if (pPositionDragAndDrop->sPosition == "APRES")
    	DragApres(pNodeDrop, "COPIE") ;
    else
    	DragFils(pNodeDrop, "COPIE") ;
	}
	pPositionDragAndDrop->sPosition = "" ;
}
catch (...)
{
	erreur("Exception NSTreeWindow::CollerNode.", standardError, 0) ;
}
}

//-----------------------------------------------------------------------
//couper le noeud pNSTreeNodeDrag (et ses fils )
//----------------------------------------------------------------------
void
NSTreeWindow::CouperNode(NSTreeNode* pNSTreeNodeDrag)
{
	if (NULL == pNSTreeNodeDrag)
		return ;

	pNSTreeNodeDrag->CopyPatPatho("COPIE") ;
	SupprimerNoeud(pNSTreeNodeDrag) ;
}

//-----------------------------------------------------------------------//copier le noeud pNSTreeNodeDrag (et ses fils )
//----------------------------------------------------------------------
void
NSTreeWindow::CopyNode()
{
	TTreeNode node = GetSelection() ;
	NSTreeNode* pNSTreeNodeDrag = GetNSTreeNode(&node) ;
	if (NULL == pNSTreeNodeDrag)
		return ;
	CopierNode(pNSTreeNodeDrag) ;
}

//-----------------------------------------------------------------------//coller le noeud pNSTreeNodeDrag (et ses fils )
//----------------------------------------------------------------------
void
NSTreeWindow::PasteNode()
{
	TTreeNode node = GetSelection() ;
	NSTreeNode* pNodeDrop = GetNSTreeNode(&node) ;
  if (NULL == pNodeDrop)
  	return ;
	CollerNode(pNodeDrop) ;
  pContexte->getSuperviseur()->pBufCopie->vider() ;
}

//-----------------------------------------------------------------------
//couper le noeud pNSTreeNodeDrag (et ses fils )
//----------------------------------------------------------------------
void
NSTreeWindow::CutNode()
{
	TTreeNode node = GetSelection() ;
	NSTreeNode* pNSTreeNodeDrag = GetNSTreeNode(&node) ;
  if (NULL == pNSTreeNodeDrag)
  	return ;
  CouperNode(pNSTreeNodeDrag) ;
}

//-----------------------------------------------------------------------//drag and drop ou copie avant le noeud destination
//sCopie vaut "DRAG" ou dans pSuper->pPatPathoDragDrop si sCopie
//vaut "COPIE"
//----------------------------------------------------------------------
void
NSTreeWindow::DragAvant(NSTreeNode* pNodeDrop, string sCopie, NSCutPaste* pCP)
{
	if (NULL == pNodeDrop)
		return ;

	NSCutPaste* pCutPaste = pCP ;
	if (NULL == pCutPaste)
	{
  	if      (sCopie == "DRAG")
    	pCutPaste = pContexte->getSuperviseur()->pBufDragDrop ;
		else if (sCopie == "COPIE")
    	pCutPaste = pContexte->getSuperviseur()->pBufCopie ;
	}

	NSTreeNode* pNSTreePere = pNodeDrop->pere ;     //p�re du NSTreeNode correspondant
	int ligne = pNodeDrop->getLigne() ;
    // int colonne    			= pNodeDrop->getColonne() ;

	int ligneMax ;	int colonneMax = 1 ;

	NSCutPastTLArray* pTLArray = pCutPaste->pTextesLibres ;
	NSPatPathoArray   Patho(pContexte) ;
  Patho = *(pCutPaste->pPatPatho) ;

/*
	if      (sCopie == "DRAG")
	{
		Patho    = *(pContexte->getSuperviseur()->pBufDragDrop->pPatPatho) ;
		pTLArray = pContexte->getSuperviseur()->pBufDragDrop->pTextesLibres ;
	}
	else if (sCopie == "COPIE")
	{
		Patho    = *(pContexte->getSuperviseur()->pBufCopie->pPatPatho) ;
		pTLArray = pContexte->getSuperviseur()->pBufCopie->pTextesLibres ;
	}
*/

	int Taille = Patho.Taille() ;

	if (pNSTreePere) //si le p�re existe
	{
		// iterNSTreeNode iter = pNSTreePere->VectFils.begin() ;
		NSTreeNode* pNSTreeFrere = TrouverGrandFrere(pNodeDrop, ligne) ;
		//on a trouv� le fr�re ain� le plus proche de pNodeDrop
		if (pNSTreeFrere)
		{
    	ligneMax = pNSTreeFrere->getLigne() ;
      GetMaxCoordonnees(pNSTreeFrere, &ligneMax, &colonneMax, true) ;
      //d�caler les NSTreeNodes qui existent et dont la ligne est sup�rieure � ligneMax
      if (!(pNodeArray->empty()))
      {
      	for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
        	if( (*iter)->getLigne() > ligneMax )
          	(*iter)->setLigne((*iter)->getLigne() +  Taille) ;
      }
      DispatcherPatPatho(&Patho, pNSTreeFrere, 0, "AVANTFRERE", "EXPAND", pTLArray);
    }
    else
    {
    	ligneMax = pNSTreePere->getLigne() ;
      //d�caler les NSTreeNodes qui existent et dont la ligne est sup�rieure � ligneMax
      if (!(pNodeArray->empty()))
      {
      	for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
        	if ( (*iter)->getLigne() > ligneMax )
          	(*iter)->setLigne((*iter)->getLigne() + Taille) ;
      }
      DispatcherPatPatho(&Patho, pNSTreePere, 0, "AVANTFILS", "EXPAND", pTLArray) ;
    }
  }
  else
  {
  	//
    //Touver le TTReenode dont le p�re est le root et qui soit le plus proche de
    // l'�l�ment s�lectionn� (ain�)
    //
		NSTreeNode* pNSTreeFrere  = TrouverGrandFrereFilsRoot(pNodeDrop, ligne) ;
    //on a trouv� le fr�re ain� le plus proche de pNodeDrop
    if (pNSTreeFrere)
    {
    	ligneMax   = pNSTreeFrere->getLigne() ;
      GetMaxCoordonnees(pNSTreeFrere, &ligneMax, &colonneMax, true) ;
      //d�caler les NSTreeNodes qui existent et dont la ligne est sup�rieure � ligneMax
      if (!(pNodeArray->empty()))
      {
      	for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
        	if ((*iter)->getLigne() > ligneMax)
          	(*iter)->setLigne((*iter)->getLigne() + Taille) ;
      }
      DispatcherPatPatho(&Patho, pNSTreeFrere, 0, "AVANTFRERE", "EXPAND", pTLArray) ;
    }
    else
    {
    	TTreeNode root = GetRoot() ;
      //d�caler les NSTreeNodes qui existent et dont la ligne est sup�rieure � ligneMax
      if (!(pNodeArray->empty()))
      {
      	for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
        	(*iter)->setLigne((*iter)->getLigne() +  Taille) ;
      }
      DispatcherPatPatho(&Patho, 0, 0, "Debut", "EXPAND", pTLArray) ;
    }
  }
  SetDirty(true) ;
}

//-----------------------------------------------------------------------
//sCopie vaut "DRAG" ou dans pSuper->pPatPathoDragDrop si sCopie
//vaut "COPIE"
//----------------------------------------------------------------------
void
NSTreeWindow::DragApres(NSTreeNode* pNodeDrop, string sCopie, NSCutPaste* pCP)
{
	int ligneMax ;
	int colonneMax = 1 ;

  NSCutPaste* pCutPaste = pCP ;
	if (NULL == pCutPaste)
	{
  	if      (sCopie == "DRAG")
    	pCutPaste = pContexte->getSuperviseur()->pBufDragDrop ;
		else if (sCopie == "COPIE")
    	pCutPaste = pContexte->getSuperviseur()->pBufCopie ;
	}

	NSCutPastTLArray* pTLArray = pCutPaste->pTextesLibres ;
	NSPatPathoArray   Patho(pContexte) ;
  Patho = *(pCutPaste->pPatPatho) ;

  if (NULL != pNodeDrop)
	{
		int Taille = Patho.Taille() ;		ligneMax   = pNodeDrop->getLigne() ;
		GetMaxCoordonnees(pNodeDrop, &ligneMax, &colonneMax, true) ;
		//d�caler les NSTreeNodes qui existent et dont la ligne est sup�rieure � ligneMax
		for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
			if ((*iter)->getLigne() > ligneMax)
				(*iter)->setLigne((*iter)->getLigne() +  Taille) ;
	}

	DispatcherPatPatho(&Patho, pNodeDrop, 0, "AVANTFRERE", "EXPAND", pTLArray) ;	SetDirty(true) ;
}

//-----------------------------------------------------------------------//drag and drop ou copie en dessous du noeud destination
//sCopie vaut "DRAG" ou dans pSuper->pPatPathoDragDrop si sCopie
//vaut "COPIE"
//----------------------------------------------------------------------
void
NSTreeWindow::DragFils(NSTreeNode* pNodeDrop, string sCopie, NSCutPaste* pCP)
{
	CopyBranch(pNodeDrop, sCopie, pCP) ;
	SetDirty(true) ;
}

int
NSTreeWindow::donneIndexInteret(char cInteret)
{
	if      (cInteret == 'A')
		return 0 ;
	else if (cInteret == 'B')
		return 1 ;
	else if (cInteret == 'C')
		return 2 ;
	else if (cInteret == 'D')
		return 3 ;
	else if (cInteret == 'E')
		return 4 ;

	return 0 ;
}

bool
NSTreeWindow::canWeClose()
{
	return true ;
}

bool
NSTreeWindow::isRealNode(NSTreeNode* pNSTreeNode)
{
  if (NULL == pNSTreeNode)
    return false ;

  if ((pNSTreeNode->estFictifPur()) || (pNSTreeNode->estPropose))
    return false ;

  return true ;
}

// fin de nstrewi.cpp
///////////////////////////////////////////////////

