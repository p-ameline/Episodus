//#include <checks.h>
#include <owl\control.h>
#include <owl\dc.h>
#include <owl\edit.h>

#include "nsbb\nsbbtran.h"
#include "nsbb\nsbb.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbbsmal.h"
#include "nsbb\nsedilex.h"
#include "nsbb\nStlibre.h"
#include "partage\nsdivfct.h"
#include "nautilus\nsepicap.h"
#include "nsbb\nscombo.h"
#include "nsbb\nsdlg.h"

//
// General Controls diagnostic group
//
DIAG_DEFINE_GROUP_INIT(OWL_INI, OwlControl, 1, 0);

DEFINE_RESPONSE_TABLE1(NSEditLexique, NSEditDicoGlobal)
  EV_WM_CHAR,
  EV_WM_KEYDOWN,
  EV_WM_KEYUP,
  EV_WM_GETDLGCODE,
	EV_WM_KILLFOCUS,
  EV_WM_RBUTTONDOWN,
  EV_COMMAND(CM_EDITPASTE, CmEditPaste),
   //EV_NOTIFY_AT_CHILD(WM_KEYDOWN, EvKeyDown),
END_RESPONSE_TABLE;

//
// Constructeur
//
NSEditLexique::NSEditLexique(TWindow* parent, NSContexte* pCtx, int resId,
                             NSDico* pDictio, uint textLen, string sTypeLexique,
                             TModule* module)
              :NSEditDicoGlobal(pCtx, parent, resId, pDictio, sTypeLexique, textLen, module)
{
  pControle       = 0 ;
  sContenuPere    = "" ;
  pContexte       = pCtx ;
  pNSEdit         = 0 ;
  sComplement     = "" ;
  bWinStd         = false ;
}

NSEditLexique::NSEditLexique(TWindow* parent, NSContexte* pCtx, int resourceId,                             NSDico* pDictio, const char far* text,
                             int x, int y, int w, int h, uint textLimit,
                             bool multiline, string sTypeLexiq, TModule* module)
              :NSEditDicoGlobal(pCtx, parent,resourceId, pDictio, text, x, y, w, h,
                                textLimit, multiline, sTypeLexiq, module)
{
  pControle       = 0 ;
  pContexte       = pCtx ;
  sContenuPere    = "" ;
  pNSEdit         = 0 ;
  sComplement     = "" ;
  bWinStd         = false ;
}

NSEditLexique::~NSEditLexique(){
  if (pNSEdit)
    delete pNSEdit ;
}

//----------------------------------------------------------------------------//----------------------------------------------------------------------------
void
NSEditLexique::SetupWindow()
{
  NSEditDicoGlobal::SetupWindow() ;
}

//----------------------------------------------------------------------------// positionner le lexique selon les coordonn�es de l'�cran et celles de la bo�te
// m�re
//----------------------------------------------------------------------------
void
NSEditLexique::SetPositionLexique()
{
try
{
	//
  // coordonn�es de l'�cran en pixels
  //
  TIC* pTic = new TIC("DISPLAY", 0, 0) ;
  int XScreen = pTic->GetDeviceCaps(HORZRES) ;
  int YScreen = pTic->GetDeviceCaps(VERTRES) ;
  delete pTic ;

	//position du lexique
  NS_CLASSLIB::TRect rectBoiteMere = Parent->GetWindowRect() ; //bo�te m�re
  NS_CLASSLIB::TRect rectEdition   = GetWindowRect() ; //rectangle d'�dition (this)

  //  // Attr : this
  //
  int x = Attr.X + Attr.W + rectBoiteMere.left  + 5 ;
  int y = rectEdition.top ;

  NS_CLASSLIB::TRect rectLex = pDico->pDicoDialog->GetWindowRect();  //lexique
  if ((x + rectLex.Width()) >= XScreen)
    x = rectEdition.left  - rectLex.Width() - 5 ;

  if ((y + rectLex.Height()) >= YScreen)
    y = YScreen - rectLex.bottom + rectLex.top ;

  pDico->pDicoDialog->SetWindowPos(0,x,y,rectLex.Width(),rectLex.Height(),SWP_NOZORDER) ;

  //
  // coordonn�es de l'�cran
  //
   /*   // Device metrics for screen
		HDC hDCScreen = GetDC(NULL);
		//ASSERT(hDCScreen != NULL);
		rectEdition.right = GetDeviceCaps(hDCScreen, HORZRES);
		rectEdition.bottom = GetDeviceCaps(hDCScreen, VERTRES);
		ReleaseDC(NULL, hDCScreen);
   */
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSEditLexique::SetPositionLexique : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
}
catch (...)
{
	erreur("Exception NSEditLexique::SetPositionLexique.", standardError, 0) ;
}
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSEditLexique::UpdateDico()
{
  //
  // R�cup�ration du contenu du contr�le
  //
  int oldBuffLen = GetTextLen() ;
  char far* oldBuff = new char[oldBuffLen+1] ;

  GetText(oldBuff, oldBuffLen+1) ;  string sContenu = string(oldBuff) ;
  delete[] oldBuff ;

  strip(sContenu) ;  //
  // Transmission du contenu � la boite de dialogue
  //
	int OouF = pDico->pDicoDialog->DonneAmmorce(&sContenu) ;
  if (OouF == 1)
  {
    bGardeFocus = true ;
    //
    // fixer la position du lexique
    //
    SetPositionLexique() ;
		pDico->pDicoDialog->montrerDialogue() ;
    SetFocus() ;
  }
  else if (OouF == 2)
    pDico->pDicoDialog->cacherDialogue() ;
}

//-------------------------------------------------------------------------//-------------------------------------------------------------------------
void
NSEditLexique::EvChar(uint key, uint repeatCount, uint flags)
{
    if ((key == VK_RETURN) || (key == VK_TAB))
  		//pour enlever le Beep ne pas appliquer TEdit::EvChar(key, repeatCount, flags)
  		return ;
    TEdit::EvChar(key, repeatCount, flags) ;
    UpdateDico() ;
}

//---------------------------------------------------------------------------//---------------------------------------------------------------------------
void
NSEditLexique::EvKeyDown(uint key, uint repeatCount, uint flags)
{
  TEdit::EvKeyDown(key, repeatCount, flags) ;
  Parent->SendNotification(Attr.Id, 200, HWindow) ;
  //
  // Transmission du contenu � la boite de dialogue
  //

  // fl�che basse
  //
  if (VK_DOWN == key)
  {
    if (string("") == pDico->pDicoDialog->sAmmorce)
      return ;
    else
      pDico->pDicoDialog->ElementSuivant() ;
  }
  //
  // fl�che haute
  //
  else if (VK_UP == key)
  {
    //si ammorce vide alors passer au NStrreNode suivant
    if (string("") == pDico->pDicoDialog->sAmmorce)
      return ;
    else
      pDico->pDicoDialog->ElementPrecedent() ;
  }
  else if ((key == VK_INSERT) || (key == VK_RETURN))
    pDico->pDicoDialog->InsererElementLexique() ;
  else if (key == VK_TAB)
  {
    if (bWinStd)
    {
      THandle hNextTab ;
      if (GetKeyState(VK_SHIFT) < 0)
        hNextTab = Parent->GetNextDlgTabItem(((TWindow*)this)->GetHandle(), /*bool previous=*/ true) ;
      else
        hNextTab = Parent->GetNextDlgTabItem(((TWindow*)this)->GetHandle(), /*bool previous=*/ false) ;
      bGardeFocus = false ;
      ::SetFocus(hNextTab) ;
    }
  }
  else
    UpdateDico() ;
}

//fonction permettant � la touche ENTREE d'avoir le m�me effet que TAB
void
NSEditLexique::EvKeyUp(uint key, uint repeatcount, uint flags)
{
  // Gestion windows standard
  // Windows standard behaviour
  if (pControle && pControle->getNSDialog())
  {
    NSSuper* pSuper = pControle->getNSDialog()->pBBItem->pBigBoss->pContexte->getSuperviseur() ;
    if ((pSuper && pSuper->getDPIO()) && (pSuper->getDPIO()->bReturnCloses))
    {
      TEdit::EvKeyUp(key, repeatcount, flags) ;
      return ;
    }
  }

  switch (key)
  {
    //return
    case VK_RETURN :
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // suivant pControle sinon le premier
      //
            /*if (pControle && pControle->getNSDialog())
                pControle->getNSDialog()->ActiveControlSuivant(pControle);
            else
            {
                if (parentEdit->Parent->ChildWithId(1))
                    parentEdit->Parent->ChildWithId(1)->SetFocus();
                else
                    parentEdit->CloseWindow(IDOK);
            } */
      break ;

    //tabulation
    case VK_TAB	:
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // suivant pControle sinon le premier
      //
      if (pControle && pControle->getNSDialog() && (!bWinStd))
      {
        pControle->getNSDialog()->ActiveControlSuivant(pControle) ;
        break ;
      }

    default		:
      TEdit::EvKeyUp(key, repeatcount, flags) ;
  }
}

//fonction permettant de voir passer toutes les touchesuint
NSEditLexique::EvGetDlgCode(MSG far* msg)
{
  uint retVal = (uint)DefaultProcessing() ;

  if (msg && (msg->wParam == VK_RETURN))
  {
    if (pDico && pDico->pDicoDialog && pDico->pDicoDialog->IsWindow())
      pDico->pDicoDialog->InsererElementLexique() ;
    // retVal |= DLGC_WANTCHARS ;
    retVal |= DLGC_WANTALLKEYS ;
  }
  return retVal ;
}

void
NSEditLexique::CmEditPaste()
{
	TEdit::CmEditPaste() ;
}

//-------------------------------------------------------------------------
// 					l'utilisateur a choisi un �l�ment dans le lexique
//-------------------------------------------------------------------------
void
NSEditLexique::ElementSelectionne()
{
try
{
	char code[PATHO_CODE_LEN + 1] ;
	GetCodeLexiqueChoisi(code) ;
	string sContenu ;
	GetLabelChoisi(&sContenu) ;
	SetText(sContenu.c_str()) ;
	pDico->pDicoDialog->cacherDialogue() ;

  if ((NULL == pControle) || (NULL == pControle->getTransfert()) || (NULL == pControle->getTransfert()->pBBFilsItem))
	{
		erreur("Non connected control.", standardError, 0) ;
		return ;
	}
	sContenuPere = sContenu ;

/*
  BBItem* pBBItemPere = pControle->getTransfert()->pBBFilsItem->pPere ;
	//
	// Vider la liste des fils du BBItem sur cet edit
	//
	pControle->getTransfert()->pBBFilsItem->VectorFils.vider();
	if (pNSEdit)
	{
		delete pNSEdit ;
		pNSEdit = 0 ;
	}
	if (!pNSEdit)
	{
		pNSEdit 	         = new NSEditLexiqueDerive(pContexte, this) ;
		pNSEdit->pControle = new NSControle(pBBItemPere, string(code), "") ;
		pNSEdit->pControle->setControle(dynamic_cast<void*>(pNSEdit)) ;
		pNSEdit->pControle->setType(pNSEdit->donneType()) ;
		pNSEdit->pContexte = pContexte ;
		pNSEdit->pControle->setNSDialog(pBBItemPere->pNSDialog) ;
	}
	sComplement = "" ;
	pNSEdit->sContenuTransfert = sContenu ;
	pNSEdit->pControle->setIdentite(string(code)) ;
	CreerBBItem() ;
*/

  CreerEditDerive(string(code), sContenu) ;

  // Set local transfert so that old value doesn't prevent the new one to be activated 
  //
  NSTransferInfo *pTransfert = pControle->getTransfert() ;
  Message        *pTrMessage = pTransfert->pTransfertMessage ;
  pTrMessage->SetLexique(string(code)) ;

	if (pNSEdit->pControle->getTransfert())
	{
		Message MessageNewFils ;
		pNSEdit->pControle->getTransfert()->ctrlNotification(BF_UNCHECKED, BF_CHECKED, &MessageNewFils) ;
	}
}
catch (...)
{
	erreur("Exception NSEditLexique::ElementSelectionne.", standardError, 0) ;
}
}

//------------------------------------------------------------------------// le champ edit perd son focus
//------------------------------------------------------------------------
void
NSEditLexique::EvKillFocus(THandle hWndGetFocus)
{
try
{
  if (hWndGetFocus == HWindow)
    return ;
  //
  // R�cup�re le texte
  //
  string sContenu = "" ;
  int nMaxInput = GetTextLen() ;
  if (nMaxInput > 0)
  {
    char far* str = new char[nMaxInput + 1] ;
    GetText(str, nMaxInput + 1) ;
    sContenu = string(str) ;
    delete[] str ;
  }

  if ((NULL != pControle) && (NULL != pControle->getTransfert()) &&
      (NULL != pControle->getTransfert()->pBBFilsItem) &&
      (false == pControle->getTransfert()->pBBFilsItem->VectorFils.empty()))
  {
    BBFilsItem* pFilsEditLexique = *((*(pControle->getTransfert()->pBBFilsItem->VectorFils.begin()))->aBBItemFils.begin()) ;
    if (pFilsEditLexique && pFilsEditLexique->getItemLabel() == "") //d�sactiver ce fils
      pFilsEditLexique->Desactive() ;
  }
  if (!bGardeFocus)
  {
    if (hWndGetFocus != THandle(this))
    {
      if ((pDico->pDicoDialog) &&
                (hWndGetFocus != pDico->pDicoDialog->HWindow) &&
                (!(pDico->pDicoDialog->IsChild(hWndGetFocus))))
      {
        pDico->pDicoDialog->cacherDialogue() ;
        NSEditDicoGlobal::EvKillFocus(hWndGetFocus) ;
      }
      else
        TEdit::EvKillFocus(hWndGetFocus) ;
    }
  }
  else
    bGardeFocus = false ;
}
catch (...)
{
	erreur("Exception NSEditLexique::EvKillFocus.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Function: 		NSEdit::activeControle(int activation, string message)
//
//  Description:	Initialise le contr�le avant affichage de la bo�te de
//						dialogue
//
//  Arguments:		activation : BF_CHECKED ou BF_UNCHECKED
//						message    : Contenu de la bo�te
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void
NSEditLexique::activeControle(int activation, Message* pMessage)
{
  // Gestion windows standard
  // Windows standard behaviour
  if (pControle && pControle->getNSDialog())
  {
    NSSuper* pSuper = pControle->getNSDialog()->pBBItem->pBigBoss->pContexte->getSuperviseur() ;
    if ((pSuper && pSuper->getDPIO()) && (pSuper->getDPIO()->bReturnCloses))
      bWinStd = true ;
  }

  string sContenu = "" ;
	switch (activation)
	{
    //
    // recup�rer la strinf � afficher cher le fils fictif
    //
    case BF_CHECKED	:

      if ((!(pMessage->GetLexique() == string("�?????"))) && (pMessage->GetLexique() != "")) //pas de texte libre
      {
        string sLang = "" ;
        if (pContexte->getUtilisateur())
          sLang = pContexte->getUtilisateur()->donneLang() ;

        pContexte->getDico()->donneLibelle(sLang, &pMessage->GetLexique(), &sContenu) ;

        CreerEditDerive(pMessage->GetLexique(), sContenu) ;
        SetText(sContenu.c_str()) ;
      }
      else // texte libre
        sContenu = pMessage->GetTexteLibre() ;

      sContenuPere = sContenu ;

      // Note : dans le cas o� on vient d'�tre activ� par le pNSEdit (NSEditLexiqueDerive)
      // on ne doit pas faire de SetText car le message transmis est vide.
      if (NULL == pNSEdit)
        SetText(sContenu.c_str()) ;
      break ;
		case BF_UNCHECKED :
      sContenu = "" ;
      sContenuPere = "" ;
      SetText(sContenu.c_str()) ;
      //
      // Le BBFilsItem (qui controle ce champ edit) dont l'�tiquette
      // contient �C0;020 doit d�sactiver son fils contenu dans l'EditLexique
      //
      if (!pControle->getTransfert()->pBBFilsItem->VectorFils.empty())
      {
        BBFilsItem* pFilsEditLexique = *((*(pControle->getTransfert()->pBBFilsItem->VectorFils.begin()))->aBBItemFils.begin()) ;
        pFilsEditLexique->Desactive() ;
        (*(pControle->getTransfert()->pBBFilsItem->VectorFils.begin()))->aBBItemFils.vider() ;
        pControle->getTransfert()->pBBFilsItem->VectorFils.vider() ;
      }
      break ;
  }
  sComplement = pMessage->GetComplement() ;

  if (pDico->pDicoDialog)
    pDico->pDicoDialog->cacherDialogue() ;
}

//---------------------------------------------------------------------------
//  Function: 		NSEdit::Transfer(TTransferDirection direction,
//															 int* pActif, string* pMessage)
//
//  Description:	Si direction = tdSetData
//							Initialise le contr�le
//						Si direction = tdGetData
//							Initialise pActif et pMessage
//
//  Arguments:		direction : tdGetData ou tdSetData
//
//  Returns:		1 si le transfert a fonctionn�
//						0 sinon
//---------------------------------------------------------------------------
uint
NSEditLexique::Transferer(TTransferDirection direction, int* pActif, Message* pMessage)
{
try
{
  string sContenu = "";
  int nMaxInput = GetTextLen() ;
  if (nMaxInput > 0)
  {
    char far* str = new char[nMaxInput + 1] ;
    GetText(str, nMaxInput + 1) ;
    sContenu = string(str) ;
    delete[] str ;
  }

  string sCodeLexique = "" ;  if (pNSEdit)
    sCodeLexique = pNSEdit->pControle->getIdentite() ;

  if (((sCodeLexique == "") || (sCodeLexique == string("�?????"))) &&
         (sContenu != "") && (!(sContenu == sContenuPere)) ) //texte libre
  {
/*
    pControle->getTransfert()->pBBFilsItem->VectorFils.vider() ;
    if (pNSEdit)
    {
      	    delete pNSEdit;
      	    pNSEdit = 0;
   	    }
        if (!pNSEdit)
        {
      	    BBItem* pBBItemPere = pControle->getTransfert()->pBBFilsItem->pPere;
            pNSEdit = new NSEditLexiqueDerive(pContexte, this);
            pNSEdit->pControle  = new NSControle(pBBItemPere, string("�?????"), "");
            pNSEdit->pControle->setControle(dynamic_cast<void*>(pNSEdit));
            pNSEdit->pControle->setType(pNSEdit->donneType());
            pNSEdit->pContexte            = pContexte;
            pNSEdit->pControle->setNSDialog(pBBItemPere->pNSDialog);
        }
        pNSEdit->sContenuTransfert = sContenu;
        pNSEdit->sIdentite = string("�?????");
        pNSEdit->pControle->setIdentite(string("�?????"));
        CreerBBItem();
*/

    CreerEditDerive(string("�?????"), sContenu) ;
  }

  if (direction == tdSetData)
  {
    switch (*pActif)
		{
      case 0 :

        sContenu = string("") ;
        sContenuPere = "" ;
        break ;

			case 1 :

        if ((!(pMessage->GetLexique() == string("�?????"))) && (pMessage->GetLexique() != "")) //pas de texte libre
        {
          string sLang = "" ;
          if (pContexte->getUtilisateur())
            sLang = pContexte->getUtilisateur()->donneLang() ;

          pContexte->getDico()->donneLibelle(sLang, &pMessage->GetLexique(), &sContenu) ;
        }
        else // texte libre
          sContenu = pMessage->GetTexteLibre();

        SetText(sContenu.c_str()) ;
        sContenuPere = sContenu ;
        break ;
    }
  }
	else if (direction == tdGetData)
	{
    if (sContenu == "")
      *pActif = 0 ;
    else
      *pActif = 1 ;
    //
		//transferer les donn�es
    //    if (pMessage)    {      string sEtiquette = string("") ;
      if (pControle->getTransfert())
        sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

      pMessage->MettreAJourCertitudePluriel(sEtiquette) ;
    }
  }
  if (pDico->pDicoDialog)
    pDico->pDicoDialog->cacherDialogue() ;

  return 1 ;
}
catch (...)
{
  erreur("Exception NSEditLexique::Transferer.", standardError, 0) ;
  return 0 ;
}
}

uintNSEditLexique::TempTransferer(int* pActif, Message* pMessage)
{
  string sContenu = "";
  int nMaxInput = GetTextLen();
  if (nMaxInput > 0)
  {
    char far* str = new char[nMaxInput + 1] ;
    GetText(str, nMaxInput + 1) ;
    sContenu = string(str) ;
    delete[] str ;
  }

  string sCodeLexique = "" ;  if (NULL != pNSEdit)
    sCodeLexique = pNSEdit->pControle->getIdentite() ;

  if (string("") == sContenu)
    *pActif = 0 ;
  else
    *pActif = 1 ;

  //
  //transferer les donn�es
  //  if (NULL != pMessage)  {    string sEtiquette = string("");
    if ((NULL != pControle->getTransfert()) && (NULL != pControle->getTransfert()->pBBFilsItem))
      sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

    pMessage->MettreAJourCertitudePluriel(sEtiquette);
  }
  return 1 ;
}
voidNSEditLexique::CreerEditDerive(string sCode, string sContenu){  //	// Vider la liste des fils du BBItem sur cet edit
	//
  BBFilsItem* pFilsItemPere = 0 ;
  BBItem*     pBBItemPere   = 0 ;
  if ((NULL != pControle) && (NULL != pControle->getTransfert()))
  {
    pFilsItemPere = pControle->getTransfert()->pBBFilsItem ; //le BBFilsItem rattach� au p�re
    pBBItemPere = pFilsItemPere->getItemFather() ;
  }
  if (NULL != pFilsItemPere)
    pFilsItemPere->VectorFils.vider() ;

	if (NULL != pNSEdit)
	{
		delete pNSEdit ;
		pNSEdit = 0 ;
	}
	if (NULL == pNSEdit)
	{
		pNSEdit 	         = new NSEditLexiqueDerive(pContexte, this) ;
		pNSEdit->pControle = new NSControle(pContexte, pBBItemPere, sCode, "") ;
		pNSEdit->pControle->setControle(dynamic_cast<void*>(pNSEdit)) ;
		pNSEdit->pControle->setType(pNSEdit->donneType()) ;
		pNSEdit->pContexte = pContexte ;
		pNSEdit->pControle->setNSDialog(pBBItemPere->getDialog()) ;
    pNSEdit->pControle->setMUEView(pBBItemPere->getView()) ;
	}
	sComplement = "" ;
	pNSEdit->sContenuTransfert = sContenu ;
  pNSEdit->sIdentite         = sCode ;
	pNSEdit->pControle->setIdentite(sCode) ;
	CreerBBItem() ;}void
NSEditLexique::CreerBBItem()
{
  if ((NULL == pControle) || (NULL == pControle->getTransfert()))
    return ;

  //
  //cr�er un BBfilsItem rattach� � ce nouveau controle
  //
  BBFilsItem* pFilsItemPere = pControle->getTransfert()->pBBFilsItem ; //le BBFilsItem rattach� au p�re
  if (NULL == pFilsItemPere)
    return ;

  pFilsItemPere->CreerFilsManuel(pNSEdit->pControle, 0) ;

  // on ajoute maintenant manuellement le nom du dialogue du BBItem p�re
  // l'array des fils contient en principe le fils cr�� ci-dessus.
  if (pFilsItemPere->VectorFils.empty())
    return ;

  BBiterFils iter ;
  for (iter = pFilsItemPere->VectorFils.begin(); iter != pFilsItemPere->VectorFils.end(); iter++)
  {
    (*iter)->setDialogName(pFilsItemPere->getItemFather()->getDialogName()) ;
    (*iter)->sIdArchetype = pFilsItemPere->getItemFather()->sIdArchetype ;
  }
}

void
NSEditLexique::EvRButtonDown(uint /* modKeys */, NS_CLASSLIB::TPoint& point)
{
try
{
  NS_CLASSLIB::TPoint lp = point ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;
  string sPaste = pSuper->getText("treeViewManagement", "paste") ;

  OWL::TPopupMenu *menu = new OWL::TPopupMenu() ;

  menu->AppendMenu(MF_STRING, CM_EDITPASTE, sPaste.c_str()) ;

  ClientToScreen(lp) ;
  menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow) ;
  delete menu ;
}
catch (...)
{
  erreur("Exception NSEditLexique::EvRButtonDown.", standardError, 0) ;
}
}

//*************************************************************************
// 								classe NSEditLexiqueDerive
//*************************************************************************

NSEditLexiqueDerive::NSEditLexiqueDerive(NSContexte* pCtx, NSEditLexique* pEdit)
                    :NSRoot(pCtx)
{
  pEditPere         = pEdit ;
  pComboPere        = 0 ;
	sContenuTransfert = "" ;
  pControle         = 0 ;
  sIdentite         = "" ;
  pContexte         = pCtx ;
  sComplement       = "" ;
}

NSEditLexiqueDerive::NSEditLexiqueDerive(NSContexte* pCtx, NSComboSemantique* pCombo)
                    :NSRoot(pCtx)
{
  pEditPere         = 0 ;
  pComboPere        = pCombo ;
	sContenuTransfert = "" ;
  pControle         = 0 ;
  sIdentite         = "" ;
  pContexte         = pCtx ;
  sComplement       = "" ;
}

NSEditLexiqueDerive::~NSEditLexiqueDerive()
{
  if (NULL != pControle)
    delete pControle ;
}

//---------------------------------------------------------------------------//  Function: 		NSEdit::activeControle(int activation, string message)
//
//  Description:	Initialise le contr�le avant affichage de la bo�te de
//						dialogue
//
//  Arguments:		activation : BF_CHECKED ou BF_UNCHECKED
//						message    : Contenu de la bo�te
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void
NSEditLexiqueDerive::activeControle(int activation, Message* pMessage)
{
  switch (activation)
	{
    //
    // recup�rer la string � afficher chez le fils fictif
    //
		case BF_CHECKED	:
      if ((!(pMessage->GetLexique() == string("�?????"))) && (pMessage->GetLexique() != ""))
      {
        string sLang = "" ;
        if (pContexte->getUtilisateur())
          sLang = pContexte->getUtilisateur()->donneLang() ;

        pContexte->getDico()->donneLibelle(sLang, &pMessage->GetLexique(), &sContenuTransfert);
      }
      else
      {
        /*
        if (pMessage->GetComplement() != "")
                {
                    bool texteRecupere = pNSTlibre->RecupereTexte(pMessage->GetComplement(), &sContenuTransfert);
                    if (texteRecupere == false)
                    {
                        erreur("Erreur R�cup�ration texte libre.", 0, 0);
                        delete pNSTlibre;
                        return ;
                    }
                }
        */
        if (pMessage->GetTexteLibre() != "")
          sContenuTransfert = pMessage->GetTexteLibre() ;
      }
      //pEditPere->SetText(sContenuTransfert.c_str());
      break ;

    case BF_UNCHECKED :

      sContenuTransfert = "" ;
      break ;
  }
}

//---------------------------------------------------------------------------
//  Function: 		NSEdit::Transfer(TTransferDirection direction,
//															 int* pActif, string* pMessage)
//
//  Description:	Si direction = tdSetData
//							Initialise le contr�le
//						Si direction = tdGetData
//							Initialise pActif et pMessage
//
//  Arguments:		direction : tdGetData ou tdSetData
//
//  Returns:		1 si le transfert a fonctionn�
//						0 sinon
//---------------------------------------------------------------------------
uint
NSEditLexiqueDerive::Transferer(TTransferDirection direction, int* pActif, Message* pMessage)
{  // NSTlibre* pNSTlibre = new NSTlibre(pContexte);
	if (direction == tdSetData)
	{
    switch (*pActif)
		{
      case 0 :

        sContenuTransfert = string("") ;
        break ;

			case 1 :

        /*
        sComplement = pMessage->GetComplement();
                if (sComplement != "")
                {
                    bool texteRecupere = pNSTlibre->RecupereTexte(sComplement, &sContenuTransfert);
                   	if (texteRecupere == false)
                   	{
                        erreur("Erreur R�cup�ration texte libre.", 0, 0);
                        return 0;
                   	}
        }
        */
        sContenuTransfert = pMessage->GetTexteLibre() ;
        //pEditPere->Insert(sContenuTransfert.c_str());
        break ;
    }
  }
	else if (direction == tdGetData)
	{
    if (sContenuTransfert == "")
      *pActif = 0 ;
    else
      *pActif = 1 ;

    if (pMessage)
    {
      pMessage->SetTexteLibre(sContenuTransfert) ;
      //
      // transferer les donn�es
      //
      if (sContenuTransfert != "")
      {
        //
        // texte libre : mettre dans le complement de
        // la patpatho relative � ce fils le code
        // du texte libre
        //
        if (sIdentite == string("�?????"))
          pMessage->SetComplement(sComplement) ;
      }

      string sEtiquette = string("") ;
      if (pControle->getTransfert())
        sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

      pMessage->MettreAJourCertitudePluriel(sEtiquette) ;
    }
  }
  return 1 ;
}

uintNSEditLexiqueDerive::TempTransferer(int* pActif, Message* pMessage)
{  if (sContenuTransfert == "")
    *pActif = 0 ;
  else
    *pActif = 1 ;

  if (pMessage)
  {
    pMessage->SetTexteLibre(sContenuTransfert) ;
    //
    // transferer les donn�es
    //
    if (sContenuTransfert != "")
    {
      //
      // texte libre : mettre dans le complement de
      // la patpatho relative � ce fils le code
      // du texte libre
      //
      if (sIdentite == string("�?????"))
        pMessage->SetComplement(sComplement) ;
    }

    string sEtiquette = string("") ;
    if (pControle->getTransfert())
      sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

    pMessage->MettreAJourCertitudePluriel(sEtiquette) ;
  }
  return 1 ;
}
boolNSEditLexiqueDerive::canWeClose(){  return true ;}