//Kaddachi Hafedh
#include <owl\olemdifr.h>#include <owl\applicat.h>
#include <stdexcept>
#include <iostream>

#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbbsmal.h"
#include "nsbb\nsbbtran.h"
#include "nsbb\nsbb.h"
#include "nsbb\nstrewi.h"
#include "nsbb\nsbb_msg.h"
#include "nsbb\nsdlg.h"

#include "ns_ob1\nautilus-bbk.h"

#include "nsbb\nsarc.h"
#include "nssavoir\nsgraphe.h"
#include "nsbb\nspanesplitter.h"

/*** Constructeur - Constructor
*/

NSSmallBrother::NSSmallBrother(NSContexte* pCtx, NSPatPathoArray* pArray,
                               NSMagicView* pMagVue)
               :NSRoot(pCtx)
{
try
{
	pBBFiche = 0 ;
	pNSSmallVue = pMagVue ;
	pPatPathoArray = pArray ;
	pPatPathoArray->pContexte = pContexte ;
	pTmpPPtArray = new NSPatPathoArray(pContexte) ;
	pBBItem = 0;
	pFenetreMere = 0;
	pResModuleArray = new NSResModuleArray();
	contexteModule = '0';
	lexiqueModule[0] = '\0';
	noeudModule[0] = '\0';
	Correction = false; 		//Savoir si on corrige une phrase ou non
	sCheminCorrection = "";     //Chemin de la correction
	sPositionConclusion = "";   //Position de conclusion manuelle par rapport
                                //� la conclusion automatique
	VectorCalcul = new ClasseCalculVector;
	pCmdMsgArray = new BBCmdMsgVector;

	sFichierSauveRoot = "";	iSeuilSauve  = 10000;
	iNumSauve 	 = 0;
	iNumMaxSauve = 0;
}
catch (...)
{
	erreur("Exception NSSmallBrother ctor.", standardError, 0) ;
}
}

/***  Constructeur copie - Copy constructor
*/
NSSmallBrother::NSSmallBrother(NSSmallBrother& src)
               :NSRoot(src.pContexte)
{
try
{
	pBBFiche 						= src.pBBFiche ;

	pPatPathoArray 			= src.pPatPathoArray ;
  pTmpPPtArray        = new NSPatPathoArray(pContexte) ;
	pBBItem 						= src.pBBItem ;
	Correction 					= src.Correction ;
	VectorCalcul 				= src.VectorCalcul ;
	sPositionConclusion	= src.sPositionConclusion ;

	VectorCalcul        = new ClasseCalculVector(*(src.VectorCalcul));
	pCmdMsgArray        = new BBCmdMsgVector(*(src.pCmdMsgArray));
	pResModuleArray     = new NSResModuleArray(*(src.pResModuleArray));

	sFichierSauveRoot   = src.sFichierSauveRoot;
	iSeuilSauve         = src.iSeuilSauve;
	iNumSauve 	        = src.iNumSauve;
	iNumMaxSauve        = src.iNumMaxSauve;
}
catch (...)
{
	erreur("Exception NSSmallBrother copy ctor.", standardError, 0);
}
}

//---------------------------------------------------------------------------
// Destructeur
//---------------------------------------------------------------------------
NSSmallBrother::~NSSmallBrother()
{
	if (pResModuleArray)
		delete pResModuleArray ;
	if (VectorCalcul)
		delete VectorCalcul ;
	if (pCmdMsgArray)
		delete pCmdMsgArray ;
	if (pTmpPPtArray)
		delete pTmpPPtArray ;

	DeleteFile("arbre.tmp") ;
}

bool
NSSmallBrother::lanceModule()
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;
	if (!pSuper->getFilGuide()->Prend())
		return false ;

	pBBFiche = static_cast<BBFiche*>(pSuper->getFilGuide()->pBBFiche) ;

	iSeuilSauve = 10 ;

	return lanceScript() ;
}

//---------------------------------------------------------------------------// Lancement de l'�laboration d'un compte rendu
//---------------------------------------------------------------------------
bool
NSSmallBrother::lanceScript()
{
try
{
	if (false == ouvreScript())
		return false ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	//
	// On commence par vider la pile de messages (pour ne pas �tre pollu� par
	// des messages non trait�s)
	//
	pCmdMsgArray->vider() ;

	EnleverTitre() ;
	//
	// Cr�ation du BBItem ammorce
	//
	pBBItem = new BBItem(pContexte, this) ;

	BBFiche* pBBCommeFiche = static_cast<BBFiche*>(pBBFiche) ;
	BBItemData* pDo = static_cast<BBItemData*>(pBBCommeFiche->pDonnees) ;

	*(pBBItem->pDonnees) = *pDo ;
	pBBItem->setDialogName(string(pBBItem->pDonnees->nomDialogue)) ;

	string sCodeSens ;
	pSuper->getDico()->donneCodeSens(&(string(lexiqueModule)), &sCodeSens) ;
	pBBItem->sLocalisation = sCodeSens ;

	//
	// Si le module ne contient pas la conclusion (pas de 0CONC1 dans le guide)
	// il faut conserver dans une variable temporaire la conclusion, sinon elle
	// sera �cras�e
	//
	NSPatPathoArray* pPPT = pPatPathoArray ;
	NSPatPathoArray PatTempo(pContexte) ;

	PatPathoIter iterConclusion ;

	if (false == pPPT->empty())
	{
		iterConclusion  = pPPT->begin() ;
    iterConclusion  = ChercherItem(pPPT, "0CONC1") ;
    if (iterConclusion != pPPT->end())
    pPPT->ExtrairePatPatho(iterConclusion, &PatTempo) ;
  }

  string sTrace = "BB : Lancement du module...\n" ;
  pContexte->getSuperviseur()->trace(&sTrace, 1) ;
  //
  // Lancement du module
  //
	pBBItem->creer() ;

	/* int resAct = */ pBBItem->activer() ;
  sTrace = "BB : ...Fin du module\n" ;  pContexte->getSuperviseur()->trace(&sTrace, 1) ;
  //
  // Remise en place de la conclusion
  //
  sTrace = "BB : Remise en place de la conclusion...\n" ;
  pContexte->getSuperviseur()->trace(&sTrace, 1) ;

  if (false == pPPT->empty())
  {
    iterConclusion = pPPT->begin() ;
    iterConclusion = ChercherItem(pPPT, "0CONC1") ;

    sPositionConclusion = pBBItem->pDonnees->fils ;
    if ((pPPT->end() == iterConclusion) && (false == PatTempo.empty()))
    {
      //
      // Mettre � jour les localisations des �l�ments de la cl
      //
      PatPathoIter jter = PatTempo.begin() ;
      for (; jter != PatTempo.end(); jter++)
      {
        (*jter)->pDonnees->setLigne((*jter)->pDonnees->getLigne() + 1) ;
        (*jter)->pDonnees->setColonne((*jter)->pDonnees->getColonne() + 1) ;
      }
      jter = PatTempo.begin() ;
      PatTempo.ajoutePatho(jter, "0CONC1", 0, -1) ;
      //
      // Concat�ner les 2 patpathos
      //
      ConcatenerPatpatho("0CONC1", &PatTempo, pPPT) ;
    }
  }
  sTrace = "BB : ...Fin de remise en place de la conclusion\n" ;
  pContexte->getSuperviseur()->trace(&sTrace, 1) ;

  if (false == getPatPatho()->empty())
  {
    // On remet en place le titre � la racine de la patpatho
    //
    sTrace = "BB : Remise en place du titre...\n" ;
    pContexte->getSuperviseur()->trace(&sTrace, 1) ;

    MetTitre() ;

    sTrace = "BB : Titre remis en place...\n" ;
    pContexte->getSuperviseur()->trace(&sTrace, 1) ;
    //
    sTrace = "BB : Prise du pointeur sur le module...\n" ;
    pContexte->getSuperviseur()->trace(&sTrace, 1) ;

    TModule* pModule = TrouverModule(pBBItem->pDonnees->fichierDialogue) ;

    sTrace = "BB : ...Pointeur sur le module pris\n" ;
    pContexte->getSuperviseur()->trace(&sTrace, 1) ;

    bool (FAR *pAdresseFct) (NSSmallBrother far*, int) ; //on d�clare un pointeur
                                                            //sur une fonction
    bool retour = true ;
    if (pModule)
    {
      // On cherche le nom de fichier de la dll
      //
      string sModule = string(pModule->GetName()) ;

      sTrace = "BB : Module : " + sModule + "\n" ;
      pContexte->getSuperviseur()->trace(&sTrace, 1) ;
      if (sModule == "")
      {
        delete pBBItem ;
        return true ;
      }
      string sNom = "" ;
      int i = strlen(sModule.c_str()) - 1 ;
      while ((i >= 0) && (sModule[i] != '\\') && (sModule[i] != ':'))
      {
        sNom = string(1, pseumaj(sModule[i])) + sNom ;
        i-- ;
      }
      if ((sNom == "NSBB.DLL") || (sNom == "NSMBB.DLL"))
      {
        delete pBBItem ;
        return true ;
      }
      //
      // instancier le pointeur (recherche dans bb_res.def)
      //
      sTrace = "BB : Prise du pointeur sur la conclusion...\n" ;
      pContexte->getSuperviseur()->trace(&sTrace, 1) ;
      (FARPROC) pAdresseFct = pModule->GetProcAddress(MAKEINTRESOURCE(2)) ;
      sTrace = "BB : ...Pointeur sur la conclusion r�cup�r�\n" ;
      pContexte->getSuperviseur()->trace(&sTrace, 1) ;
      if (pAdresseFct)
      {
        sTrace = "BB : Lancement de la conclusion automatique...\n" ;
        pContexte->getSuperviseur()->trace(&sTrace, 1) ;
        retour = (*pAdresseFct)(this, 0) ;
        sTrace = "BB : ...Conclusion automatique termin�e\n" ;
        pContexte->getSuperviseur()->trace(&sTrace, 1) ;
      }
    }
    delete pBBItem ;
    pBBItem = 0 ;
    return retour ;
  }
  delete pBBItem ;
  pBBItem = 0 ;
	return false ;
}
catch (...)
{
	erreur("Exception au lancement du script.", standardError, 0) ;
	return false ;
}
}
boolNSSmallBrother::EstFormulaire(){  return pBBItem->ouvreArchetype() ;}NSDialog*NSSmallBrother::lanceBbkArchetypeInDialog(string sArchetype, nsarcParseur* pParseur, BBFilsItem* pFilsPere, BB1BBInterfaceForKs* pKsInter, bool bModal){try{	NSSuper* pSuper = pContexte->getSuperviseur() ;	if (false == pSuper->getFilGuide()->Prend())		return 0 ;
	if (false == pSuper->getDico()->Prend())
		return 0 ;	// Cr�ation du BBItem ammorce (le p�re)	//
	pBBItem = new BBItem(pContexte, this) ;

	// on donne artificellement le fils pere au BBItem
	// pour le cas des archetypes multi-niveaux
	pBBItem->pBBFilsPere = pFilsPere ;

	BBItemData Data ;

	// indispensable dans activer :
	strcpy(Data.ouvreDialogue, "A") ;
	strcpy(Data.fils, sArchetype.c_str()) ;
	strcpy(Data.decalageNiveau, "+00+00") ;

	*(pBBItem->pDonnees) = Data ;

	if (pKsInter)
  	pBBItem->KsInterface = *pKsInter ;
  else
		// Make certain it can be inited by BBK
  	pBBItem->KsInterface.setInitFromBbk(true) ;

	if (pParseur)
	{
		pBBItem->pParseur = pParseur ;		pBBItem->bCreateParseur = false ;	}  else	{		pBBItem->pParseur = new nsarcParseur(pContexte) ;		pBBItem->bCreateParseur = true ;
		string sArchetypeFile = pSuper->getArcManager()->DonneFichierArchetypeParNom(NSArcManager::archetype, sArchetype) ;
		if (string("") == sArchetypeFile)
		{
      string sErrorMsg = pSuper->getText("archetypesManagement", "cannotFindThisArchetypeFile") ;
      sErrorMsg += string(" ") + sArchetype ;
			erreur(sErrorMsg.c_str(), standardError, 0) ;
			delete pBBItem ;
			return 0 ;
		}

		if (false == pBBItem->pParseur->open(sArchetypeFile))
		{
      string sErrorMsg = pSuper->getText("archetypesManagement", "archetypeParsingError") ;
      sErrorMsg += string(" ") + sArchetypeFile ;
			erreur(sErrorMsg.c_str(), standardError, 0) ;
    	delete pBBItem ;
    	return 0 ;
  	}	}
	Carchetype* pArchetype = pBBItem->pParseur->pArchetype ;
	if (NULL == pArchetype)
	{
    string sErrorMsg = pSuper->getText("archetypesManagement", "archetypeExecutionError") ;
    erreur(sErrorMsg.c_str(), standardError, 0) ;
		delete pBBItem ;
    return 0 ;
  }

  // on renseigne les champs d�finissant le dialogue
  // (ces champs seront utilis�s par BBItem::activer dans creerDialogue()
  //  qui ne sera appel�e que pour le BBItem Root)
  if (NULL != pArchetype->getDialog())
  {
  	string sNomDialog = pArchetype->getDialog()->getStringAttribute(ATTRIBUT_DIALOGUE_NOM) ;
    pBBItem->setDialogName(sNomDialog) ;
    string sNomDll = pArchetype->getDialog()->getStringAttribute(ATTRIBUT_DIALOGUE_DLL) ;
    strcpy(pBBItem->pDonnees->fichierDialogue, sNomDll.c_str()) ;
    pBBItem->sIdArchetype = pArchetype->getName() ;
  }
  else
  {
    if (string("") != pBBItem->getDialogName())
  	  pBBItem->setDialogName(string("")) ;
    strcpy(pBBItem->pDonnees->fichierDialogue, "") ;
    pBBItem->sIdArchetype = pArchetype->getName() ;
  }

	string sMsg = "lanceBbkArchetype() : Calling creerArchetype" ;
	pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  // on d�veloppe tout l'archetype � partir du BBItem root
  pBBItem->bModalDialog   = bModal ;
  pBBItem->creerArchetype(pArchetype->getRootItem(), false) ;

	pBBItem->activer() ;
	if (pBBItem->getDialog())  {		if (pArchetype)    {    	Creferences* pRef = pArchetype->getReference() ;      if (pRef)      {      	Chead* pHead = pRef->getHead() ;        if (pHead)        {        	string sTitle   = pHead->getTitle() ;          if (sTitle != "")          	pBBItem->getDialog()->SetCaption(sTitle.c_str()) ;          string sUrl     = pHead->getHelpUrl();          if (sUrl != "")          	pBBItem->getDialog()->sHelpBodyUrl = sUrl ;        }      }    }  }	return pBBItem->getDialog() ;}catch (...)
{
	erreur("Exception NSSmallBrother::lanceBbkArchetypeInDialog.", standardError, 0) ;
	return 0 ;
}}boolNSSmallBrother::lanceBbkArchetypeInView(string sArchetype, nsarcParseur* pParseur, BBFilsItem* pFilsPere, NSBBMUEView* pView, BB1BBInterfaceForKs* pKsInter){try{	NSSuper* pSuper = pContexte->getSuperviseur() ;	if (false == pSuper->getFilGuide()->Prend())		return false ;
	if (false == pSuper->getDico()->Prend())
		return false ;	// Cr�ation du BBItem ammorce (le p�re)	//
	pBBItem = new BBItem(pContexte, this) ;

	// on donne artificellement le fils pere au BBItem
	// pour le cas des archetypes multi-niveaux
  //
	pBBItem->pBBFilsPere = pFilsPere ;
	pBBItem->setView(pView)  ;

	BBItemData Data ;

	// indispensable dans activer :
	strcpy(Data.ouvreDialogue, "A") ;
	strcpy(Data.fils, sArchetype.c_str()) ;
	strcpy(Data.decalageNiveau, "+00+00") ;

	*(pBBItem->pDonnees) = Data ;

	if (pKsInter)
  	pBBItem->KsInterface = *pKsInter ;
  else
		// Make certain it can be inited by BBK
  	pBBItem->KsInterface.setInitFromBbk(true) ;

	if (pParseur)
	{
		pBBItem->pParseur = pParseur ;		pBBItem->bCreateParseur = false ;	}  else	{		pBBItem->pParseur = new nsarcParseur(pContexte) ;		pBBItem->bCreateParseur = true ;
		string sArchetypeFile = pContexte->getSuperviseur()->getArcManager()->DonneFichierArchetypeParNom(NSArcManager::archetype, sArchetype) ;
		if (string("") == sArchetypeFile)
		{
			string sErrorMsg = pSuper->getText("archetypesManagement", "cannotFindThisArchetypeFile") ;
      sErrorMsg += string(" ") + sArchetype ;
			erreur(sErrorMsg.c_str(), standardError, 0) ;
			delete pBBItem ;
			return false ;
		}

		if (false == pBBItem->pParseur->open(sArchetypeFile))
		{
			string sErrorMsg = pSuper->getText("archetypesManagement", "archetypeParsingError") ;
      sErrorMsg += string(" ") + sArchetypeFile ;
			erreur(sErrorMsg.c_str(), standardError, 0) ;
    	delete pBBItem;
    	return false ;
  	}	}
	Carchetype* pArchetype  = pBBItem->pParseur->pArchetype ;
	if (!pArchetype)
	{
		string sErrorMsg = pSuper->getText("archetypesManagement", "archetypeExecutionError") ;
    erreur(sErrorMsg.c_str(), standardError, 0) ;
		delete pBBItem ;
    return false ;
  }

  // on renseigne les champs d�finissant le dialogue
  // (ces champs seront utilis�s par BBItem::activer dans creerDialogue()
  //  qui ne sera appel�e que pour le BBItem Root)
  if (NULL != pArchetype->getDialog())
  {
  	string sNomDialog = pArchetype->getDialog()->getStringAttribute(ATTRIBUT_DIALOGUE_NOM) ;
    pBBItem->setDialogName(sNomDialog) ;
    string sNomDll = pArchetype->getDialog()->getStringAttribute(ATTRIBUT_DIALOGUE_DLL) ;
    strcpy(pBBItem->pDonnees->fichierDialogue, sNomDll.c_str()) ;
    pBBItem->sIdArchetype = pArchetype->getName() ;
  }
  else
  {
    if (string("") != pBBItem->getDialogName())
  	  pBBItem->setDialogName(string("")) ;
    strcpy(pBBItem->pDonnees->fichierDialogue, "") ;
    pBBItem->sIdArchetype = pArchetype->getName() ;
  }

	string sMsg = "lanceBbkArchetype(): Calling creerArchetype" ;
	pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  // on d�veloppe tout l'archetype � partir du BBItem root
  pBBItem->bModalDialog = false ;
  pBBItem->creerArchetype(pArchetype->getRootItem(), false) ;

	return true ;
}catch (...)
{
	erreur("Exception NSSmallBrother::lanceBbkArchetypeInView.", standardError, 0) ;
	return 0 ;
}}boolNSSmallBrother::fermeBbkArchetype(int /* iReturn */, TWindow* view){	NSSuper* pSuper = pContexte->getSuperviseur() ;	NSToDoTask* pTask = new NSToDoTask ;
	pTask->sWhatToDo = "FermeArchetype" ;
	pTask->pPointer1 = (void*)this ;
	pTask->pPointer2 = (void*)view ;

	pSuper->addToDo(pTask) ;

	return true ;}voidNSSmallBrother::canCloseArchetype(bool bCanClose, bool bCanCloseDPIO){	if (NULL == pBBItem)		return ;	NSBBMUEView* pMView = pBBItem->getView() ;  if ((NULL == pMView) || (false == pMView->IsWindow()))		return ;  // pBBItem->getDialog()->ForceCanClose();  pMView->getPaneSplitter()->youCanCloseNow() ;/*	if (pMView)	{		pBBItem->getDialog()->ForceCanClose();		pMView->getPaneSplitter()->youCanCloseNow() ;	}	else	{		if (bCanClose)			pBBItem->getDialog()->CloseWindow(IDOK) ;	}*/	if (bCanCloseDPIO)	{
		NSSuper* pSuper = pContexte->getSuperviseur() ;
		NSToDoTask* pTask = new NSToDoTask ;
		pTask->sWhatToDo = "FermeDPIO" ;
		pTask->pPointer1 = (void*) pMView ;

		pSuper->addToDo(pTask) ;
	}
}//----------------------------------------------------------------------------//lancement de la conclusion automatique
//----------------------------------------------------------------------------
bool
NSSmallBrother::ConclusionAutomatique()
{
    return true;
}

//---------------------------------------------------------------------------//---------------------------------------------------------------------------
bool
NSSmallBrother::lanceScript(NSTreeWindow* pTreeWind)
{
try
{
	NSSuper* pSuper = pContexte->getSuperviseur();
	//
	// Cr�er le pemier BBItem (GCONS le p�re)
	//
	pBBItem = new BBItem(pContexte, this) ;
	BBFiche* pBBCommeFiche = static_cast<BBFiche*>(pBBFiche) ;
	BBItemData* pDo = static_cast<BBItemData*>(pBBCommeFiche->pDonnees) ;
	*(pBBItem->pDonnees) = *(pDo) ;

	pBBItem->setDialogName(string(pBBItem->pDonnees->nomDialogue)) ;
	string sCodeSens ;
	pSuper->getDico()->donneCodeSens(&(string(lexiqueModule)), &sCodeSens) ;
	pBBItem->sLocalisation = sCodeSens ;
	pTreeWind->pBBitemNSTreeWindow = pBBItem ;
	pBBItem->creer() ;

	//
	// Cr�er le deuxi�me BBItem (GCONS le fils)
	//
	BBFilsItem* pFilsItem = *(pBBItem->aBBItemFils.begin()) ;
	int creer = pBBItem->developperConsultation(pFilsItem) ;
	if (creer != 0)
		return false ;

	return true ;
}
catch (...)
{
	erreur("Exception au lancement du script.", standardError, 0) ;
	return false ;
}
}

//----------------------------------------------------------------------------//	enlever le titre au compte rendu :  exemple : GECHY
//----------------------------------------------------------------------------
void
NSSmallBrother::EnleverTitre()
{
    //
    // enlever titre
    //
    NSPatPathoArray* pPPT = getPatPatho();
    if (pPPT->empty())
        return;
    PatPathoIter gechy = pPPT->begin();
    PatPathoIter j = pPPT->begin();
    if (gechy == pPPT->end())
   	    return ;

    strcpy(noeudModule, (*gechy)->pDonnees->noeud);

    delete *gechy;
    pPPT->erase(gechy);

    j = pPPT->begin();
    while( j != pPPT->end())
    {
   	    (*j)->pDonnees->setColonne((*j)->pDonnees->getColonne() - 1 );
        (*j)->pDonnees->setLigne((*j)->pDonnees->getLigne() - 1 );
        j++;
    }
}

//----------------------------------------------------------------------------
//	Remet le titre � la racine de la patpatho
//----------------------------------------------------------------------------
void
NSSmallBrother::MetTitre()
{
  // Take care not to shift all lines and columns for nothing
  //
  if (string("") == string(lexiqueModule))
    return ;

  NSPatPathoArray* pPPTEnCoursTitre = getPatPatho() ;
  if (NULL == pPPTEnCoursTitre)
    return ;

  pPPTEnCoursTitre->ajouteTitre(string(lexiqueModule), string(noeudModule)) ;

  if (pPPTEnCoursTitre->empty())
    return ;

  // on d�cale tout d'un cran (sauf le titre) apr�s insertion du titre
  PatPathoIter j = pPPTEnCoursTitre->begin() ;
  if (j != pPPTEnCoursTitre->end())
    j++ ;
  else
    return ;

  while (j != pPPTEnCoursTitre->end())
  {
    (*j)->pDonnees->setColonne((*j)->pDonnees->getColonne() + 1) ;
    (*j)->pDonnees->setLigne((*j)->pDonnees->getLigne() + 1) ;
    j++ ;
  }
}

//----------------------------------------------------------------------------
//pLocalisation		: localisation du BBItem correspondant � la phrase � corriger
//----------------------------------------------------------------------------
bool
NSSmallBrother::corrigeModule(string* pLocalisation)
{
try
{
	Correction = true ;
	string sCodeSens ;
	NSPatPathoArray* pPPT = getPatPatho() ;
	if (pPPT->empty())
		return false ;
	PatPathoIter j = pPPT->begin() ;

	//
	// Trouver le noeud ayant pLocalisation comme localisation
	//
	bool trouve = false ;
	while (j != pPPT->end())
	{
		if (strcmp((*j)->pDonnees->codeLocalisation, pLocalisation->c_str()) == 0)
		{
			(*j)->ID = 1 ;
			trouve = true ;
		}
		else
			(*j)->ID = 0 ;
		j++ ;
	}

	if (!trouve)
		return false ;

	//
	// Cr�ation du BBItem ammorce
	//
	ouvreScript() ;
	pBBItem = new BBItem(pContexte, this) ;
	BBFiche* pBBCommeFiche = static_cast<BBFiche*>(pBBFiche) ;
	BBItemData* pDo = static_cast<BBItemData*>(pBBCommeFiche->pDonnees) ;

	*(pBBItem->pDonnees) = *pDo ;
	pBBItem->setDialogName(string(pBBItem->pDonnees->nomDialogue)) ;

	EnleverTitre() ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	pSuper->getDico()->donneCodeSens(&(string(lexiqueModule)), &sCodeSens) ;
	pBBItem->sLocalisation = sCodeSens ;

	//
  //si le module ne contient pas la conclusion (pas de 0CONC1 dans le guide)
  //il faut conserver dans une variable temporaire la conclusion, sinon elle
  //sera �cras�e
  //
	NSPatPathoArray PatTempo(pContexte) ;

  PatPathoIter iterConclusion = pPPT->begin() ;
  iterConclusion = ChercherItem(pPPT, "0CONC1") ;
  if (iterConclusion != pPPT->end())
  	pPPT->ExtrairePatPatho(iterConclusion, &PatTempo) ;

	pBBItem->creer() ;
	/* int resAct = */ pBBItem->activer() ;

	iterConclusion = pPPT->begin() ;
  iterConclusion = ChercherItem(pPPT, "0CONC1") ;
  sPositionConclusion = pBBItem->pDonnees->fils ;

  if ((iterConclusion == pPPT->end()) && (!PatTempo.empty()))
  {
  	//
    // Mettre � jour les localisations des �l�ments de la cl
    //
    PatPathoIter jter = PatTempo.begin() ;
    for(; jter != PatTempo.end(); jter++)
    {
    	(*jter)->pDonnees->setLigne((*jter)->pDonnees->getLigne() + 1) ;
      (*jter)->pDonnees->setColonne((*jter)->pDonnees->getColonne() + 1) ;
    }
    jter = PatTempo.begin() ;
    PatTempo.ajoutePatho(jter, "0CONC1", 0, -1) ;
    //
    //concat�ner les 2 patpathos
    //
    ConcatenerPatpatho("0CONC1", &PatTempo, pPPT) ;
	}

	if (!getPatPatho()->empty())
	{
  	// ajoute le titre au compte rendu :  GECHY
    MetTitre() ;
    //
    TModule* pModule = TrouverModule(pBBItem->pDonnees->fichierDialogue) ;
    bool (FAR *pAdresseFct) (NSSmallBrother far*, int) ;    //on d�clare un pointeur
                                                                //sur une fonction
    bool retour = true ;
    if (NULL != pModule)
    {
    	//
      //instancier le pointeur (recherche dans bb_res.def)
      //
      (FARPROC) pAdresseFct = pModule->GetProcAddress(MAKEINTRESOURCE(2)) ;
      if (pAdresseFct)
      	retour = (*pAdresseFct)(this, 0) ;
    }
    delete pBBItem ;
    pBBItem = 0 ;
    return retour ;
	}
	delete pBBItem ;
	pBBItem = 0 ;
	return false ;
}
catch (...)
{
	erreur("Exception NSSmallBrother::corrigeModule.", standardError, 0) ;
	return false ;
}
}

//----------------------------------------------------------------------------
//pLocalisation		: localisation du BBItem correspondant � la phrase � corriger
//----------------------------------------------------------------------------
bool
NSSmallBrother::SupprimerLigneCR(string* pLocalisation)
{
try
{
	NSSuper* pSuper = pContexte->getSuperviseur();

	string sCodeSens;
	NSPatPathoArray* pPPT = getPatPatho();
	if (pPPT->empty())
		return false;
	PatPathoIter Supprimer = pPPT->begin();
	//
	// Trouver le noeud ayant pLocalisation comme localisation
	//
	bool trouve = false;
	bool bContinuer = true;
	while ((Supprimer != pPPT->end()) && (bContinuer))
	{
		if (strcmp((*Supprimer)->pDonnees->codeLocalisation, pLocalisation->c_str()) == 0)
		{
			(*Supprimer)->ID = 1;
			trouve = true;
			bContinuer = false;
		}
		else
		{
			(*Supprimer)->ID = 0;
			Supprimer++;
		}
	}

	if (!trouve)
		return false;
	int ligneSupprimer    = (*Supprimer)->pDonnees->getLigne();
	int colonneSupprimer  = (*Supprimer)->pDonnees->getColonne();

	//
	// Enlever l'�l�ment Supprimer et tous ses descendants
	//
	pPPT->SupprimerItem(Supprimer);
	//
	// Supprimer �ventuellement le p�re de Supprimer
	//
	pPPT->SupprimerPere(ligneSupprimer, colonneSupprimer);
	if (getPatPatho()->empty())
		return true ;

	if (!pSuper->getFilGuide()->Prend())
		return false;

	pBBFiche = static_cast<BBFiche*>(pSuper->getFilGuide()->pBBFiche);
	PatPathoIter iJ = getPatPatho()->begin();
	// On prend l'�l�ment
	string sCodeLex = (*iJ)->pDonnees->lexique;
	// Puis son code utile
	// string sCodeUtile = "";
	// pSuper->pDico->donneCodeSens(&sCodeLex, &sCodeUtile);

  strcpy(lexiqueModule, sCodeLex.c_str());
  if (!(ouvreScript()))
  	return false ;

  BBItemData* pBBitemData = static_cast<BBItemData*>(pBBFiche->pDonnees) ;
  if (!pBBitemData)
  	return false ;

	TModule* pModule = TrouverModule(pBBitemData->fichierDialogue);
	if (!pModule)
  	return false ;

	string sModule = string(pModule->GetName()) ;
	if (sModule == "")
		return true ;

  string sNom = string("") ;
	int i = strlen(sModule.c_str()) - 1 ;
	while ((i >= 0) && (sModule[i] != '\\') && (sModule[i] != ':'))
	{
		sNom = string(1, pseumaj(sModule[i])) + sNom ;
		i-- ;
	}
	if ((sNom == "NSBB.DLL") || (sNom == "NSMBB.DLL"))
		return true ;

/*
	if ((sCodeUtile == "GECHY") || (sCodeUtile == "GECHZ"))
	{
		pModule = new TModule("BB_KE.DLL", TRUE);
		if (!pModule)
		{
			erreur("La BB_KE.DLL est introuvable.", 0, -1);
			return false;
		}
	}
	else if (sCodeUtile == "GDUOB")
	{
		pModule = new TModule("BB_GG.DLL", TRUE);
		if (!pModule)
		{
			erreur("La BB_GG.DLL est introuvable.", 0, -1);
			return false;
		}
	}
	else if (sCodeUtile == "GCOLL")
	{
		pModule = new TModule("BB_GC.DLL", TRUE);
		if (!pModule)
		{
			erreur("La BB_GC.DLL est introuvable.", 0, -1);
			return false;
		}
	}
*/

	bool (FAR *pAdresseFct) (NSSmallBrother far*, int) ; //on d�clare un pointeur
                                                            //sur une fonction
	bool retour = true ;
	//
	//instancier le pointeur (recherche dans bb_res.def)
	//
	(FARPROC) pAdresseFct = pModule->GetProcAddress(MAKEINTRESOURCE(2)) ;

	if (pAdresseFct)
		retour = (*pAdresseFct)(this, 0) ;
	
	return retour ;
}
catch (...)
{
	erreur("Exception NSSmallBrother::SupprimerLigneCR.", standardError, 0) ;
	return false;
}
}

//-----------------------------------------------------------------------//***********************************************************************
//							outils pour traiter les conclusions
//***********************************************************************
//-----------------------------------------------------------------------

//-----------------------------------------------------------------------
//trouver un item dont le code lexique est sItem
//-----------------------------------------------------------------------
PatPathoIter
NSSmallBrother::ChercherItem(NSPatPathoArray* pPPT, string sItem)
{
  return pPPT->ChercherItem(sItem) ;
}

//------------------------------------------------------------------------//ajoute �l�ment � la patptho
//------------------------------------------------------------------------
/*
void
NSSmallBrother::ajoutePatho(NSPatPathoArray* pPPT, string sItem, int ligne, int colonne)
{
  pPPT->ajoutePatho(sItem, ligne, colonne);
}
*/

//--------------------------------------------------------------------------//donner au fils de pBBItem le bout de patpatho (s'il existe) qui le concerne
//pour qu 'il puisse l'afficher dans la fen�tre des textes libres
//--------------------------------------------------------------------------
void
NSSmallBrother::ActiverPatpathoBBfils(NSPatPathoArray* pPatpathoActuelle, BBItem* pBBItem, PatPathoIter iterPere)
{
  if ((NULL == pPatpathoActuelle) || (pPatpathoActuelle->end() == iterPere))
    return ;

  if ((NULL == pBBItem) || (NULL == pBBItem->pBBFilsPere))
    return ;

  // patpatho � afficher dans la fen�tre des textes libres ou
  // de la conclusion automatique
  NSVectFatheredPatPathoArray* pNSVectPatPathoArray = pBBItem->pBBFilsPere->getPatPatho() ;
  pNSVectPatPathoArray->vider() ;
  NSPatPathoArray* pPathRes =
        	pBBItem->pBBFilsPere->getPatpathoActive(pPatpathoActuelle, iterPere) ;
          
  if (pPathRes)
    delete pPathRes ;
}

//--------------------------------------------------------------------------
//recherche s�mantique de l'�l�ment de code lexique sItem et dont le p�re
//a pour localisation sLocalisation
//--------------------------------------------------------------------------
bool
NSSmallBrother::RechercheSemantique(string sItem, string sLocalisation)
{
try
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	VecteurRechercheSelonCritere VecteurSelonCritere(GUIDE) ;
  VecteurSelonCritere.AjouteEtiquette(sItem) ;
  pSuper->getFilGuide()->chercheChemin(&sLocalisation ,
                             &VecteurSelonCritere, NSFilGuide :: compReseau) ;
  pBBFiche = static_cast<BBFiche*>(pSuper->getFilGuide()->pBBFiche) ;
  bool trouve ;
  BBItemData Donnees ;
  VecteurSelonCritere.SetData(sItem, &trouve, &Donnees) ;
  if (trouve)
  	return true ;
  return false ;
}
catch (...)
{
	erreur("Exception NSSmallBrother::RechercheSemantique.", standardError, 0) ;
  return false ;
}
}

//-------------------------------------------------------------------------------//d�caler les lignes et les colonnes des �l�ments de pPathDestination par rapport
//au dernier �l�ment de pPathSource
//-------------------------------------------------------------------------------
void
NSSmallBrother::MettreAjourPatpatho(NSPatPathoArray* pPathDestination,
											   NSPatPathoArray* pPathSource)
{
    if (pPathDestination->empty())
        return;
    PatPathoIter j = pPathDestination->begin();
    for (; j != pPathDestination->end(); j++)
    {
        (*j)->pDonnees->setLigne((*j)->pDonnees->getLigne() +
                            (pPathSource->back())->pDonnees->getLigne() + 1);
        (*j)->pDonnees->setColonne((*j)->pDonnees->getColonne() +      	                    (pPathSource->back())->pDonnees->getColonne() + 1);
    }
}

//----------------------------------------------------------------------
//----------------------------------------------------------------------
void
NSSmallBrother::ConcatenerPatpatho(NSPatPathoArray* pPatpathoSource,
                                   NSPatPathoArray* pPatpathoDestination,
                                   bool bDecalage)
{
	if ((!pPatpathoDestination) || (!pPatpathoSource))
    	return;
    if (pPatpathoSource->empty())
    	return;

    int decaligne;
	if (pPatpathoDestination->empty())
    	decaligne = 0;
    else
    {
    	if ((pPatpathoDestination->back())->pDonnees)
    		decaligne = (pPatpathoDestination->back())->pDonnees->getLigne() + 1;
        else
        {
        	erreur("ConcatenerPatpatho : patpatho invalide", standardError, 0) ;
            return;
        }
    }
    //
    //concat�ner les 2 patpathos
    //
try
{
    PatPathoIter j = pPatpathoSource->begin();
    for (; j != pPatpathoSource->end(); j++)
    {
   	    (*j)->pDonnees->setLigne((*j)->pDonnees->getLigne() + decaligne);
        if (bDecalage)
            (*j)->pDonnees->setColonne((*j)->pDonnees->getColonne() + 1);

   	    pPatpathoDestination->push_back(new NSPatPathoInfo(*(*j)));
    }
}
catch (const exception& e)
{
    string sExept = "Exception NSSmallBrother::ConcatenerPatpatho " + string(e.what());
    erreur(sExept.c_str(), standardError, 0) ;
}
catch (...)
{
	erreur("Exception NSSmallBrother::ConcatenerPatpatho.", standardError, 0) ;
}
}

//----------------------------------------------------------------------//concat�ner les deux patpatho selon la position  de sItem dans sPositionConclusion
//----------------------------------------------------------------------
void
NSSmallBrother::ConcatenerPatpatho(string sItem, NSPatPathoArray* pPatpathoSource,
                                   NSPatPathoArray* pPatpathoDestination)

{
	if ((!pPatpathoDestination) || (!pPatpathoSource))
		return ;
  if (pPatpathoSource->empty())
  	return ;
  if (sPositionConclusion == "")
  	return ;

try
{
	// ajouter sItem selon sa position dans les fils de GECHY/GDUOB...
  // (donn�es par) sPositionConclusion
  ClasseStringVector Vect ;
  DecomposeChaine(&sPositionConclusion, &Vect, "|");
  if (Vect.empty())
  {
  	ConcatenerPatpatho(pPatpathoSource, pPatpathoDestination) ;
    return ;
  }

  iterString iterpVect = Vect.begin() ;
  iterString iterSuivant = Vect.begin() ;
  bool continuer = true ;
  while ((iterpVect != Vect.end()) && continuer)
  {
  	if ((*iterpVect)->sItem == sItem)
    	continuer = false ;
    else
    	iterpVect++ ;
  }
  //si sItem est le dernier fils de GECHY/GDUOB..., on ajoute pPatpathoSource
  //� la fin de pPatpathoDestination
  //sinon on l'ajoute selon la position de sItem dans sPositionConclusion
  if ((iterpVect == Vect.end()) || (*iterpVect == Vect.back()))
  	ConcatenerPatpatho(pPatpathoSource, pPatpathoDestination) ;
  else
  {
  	iterSuivant = iterpVect ;
    iterSuivant++ ;
    if (iterSuivant == Vect.end())
    	ConcatenerPatpatho(pPatpathoSource, pPatpathoDestination) ;
    else
    {
    	PatPathoIter iterAvant = pPatpathoDestination->ChercherItem((*iterSuivant)->sItem);
      if (iterAvant == pPatpathoDestination->end())
      	ConcatenerPatpatho(pPatpathoSource, pPatpathoDestination);
      else
      	//Ins�rer pPatpathoSource dans pPatpathoDestination juste avant iterAvant
        pPatpathoDestination->InserePatPatho(iterAvant, pPatpathoSource);
    }
  }
}
catch (...)
{
	erreur("Exception NSSmallBrother::ConcatenerPatpatho.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------// Ouverture de la DLL qui contient les ressources de ce type d'examen
//---------------------------------------------------------------------------
bool
NSSmallBrother::ouvreResModule()
{
	return true;
}

//-------------------------------------------------------------------//sert pour �tablir la conclusion dans un CR (suite � un click droit)
//-------------------------------------------------------------------
void
NSSmallBrother::Conclusion()
{
try
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	// Il faut d�sactiver la sauvegarde automatique en conclusion, sinon
	// on �crase toutes les donn�es sauvegard�es
	int iAncienSeuilSauve = iSeuilSauve ;
	iSeuilSauve = -1 ;

	NSPatPathoArray TmpPPT(pContexte) ;

	NSPatPathoArray* pPPT = getPatPatho() ;
	NSPatPathoArray pPPTgag(pContexte) ;
    							  //pBBitem : lanceur du module (GECHY par exemple)
	BBItem* pBBItemPere     = 0;  //BBitem p�re (conclusion automatique : 0CONC1 le p�re)
	BBItem* pBBItemLanceur  = 0;  //BBitem lanceur de la conclusion automatique
    							  //on a l'arborescence suivante
    							  //	pBBItem
                                  //       		pBBItemPere
                                  //                   pBBItemLanceur

    //
    //savoir si on peut avoir une conclusion automatique : pr�sence dans le guide
    //de 0CONC ->faire une recherche s�mantique.
    //Si ce n'est pas le cas, une conclusion manuelle est propos�e et elle �crase
    //l'ancien texte libre.
    //Si c'est le cas, la bo�te de dialogue de conclusion est activ�e.
    //
	string sCodeSens;
	string sSens;
	PatPathoIter iterModule = pPPT->begin() ;
	string sLanceurModule = string((*iterModule)->pDonnees->lexique) ; //GECHY par exemple
	pSuper->getDico()->donneCodeSens(&sLanceurModule, &sSens) ;

	bool bTexteLibre = false;
	// bool bConclusionAutomatique = false;

	//
	// M�moriser la patpatho actuelle
	//
	NSPatPathoArray PatpathoActuelle = *pPPT;
	NSPatPathoArray* pPatpathoActuelle = &PatpathoActuelle;
	pPPT->vider();
	PatPathoIter iterConclusion = pPatpathoActuelle->ChercherItem("0CONC1");

	NSPatPathoArray* pPPTEnCours;

	if (!RechercheSemantique("0CONC", sSens)) //bo�te de texte libre
	{
		strcpy(lexiqueModule, "#####1");
		contexteModule = ' ';
		bTexteLibre = true;
		//on a l'arborescence suivante
		//			pBBItem = "#####1"
		//       		pBBItemPere = "#####1"
		//                   pBBItemLanceur = "#TLI#1"

		if (!ouvreScript())
		{
			iSeuilSauve = iAncienSeuilSauve ;
			return ;
		}
		//
		// Cr�ation du BBItem ammorce (le p�re) pBBItemPere =  "#####1" le p�re non lanceur de Bo�te de dialogue
		//														est dont le seul fils est "#####1"
		//
		pBBItem = new BBItem(pContexte, this) ;
		BBFiche* pBBCommeFiche = static_cast<BBFiche*>(pBBFiche) ;
		BBItemData* pDo = static_cast<BBItemData*>(pBBCommeFiche->pDonnees) ;
		*(pBBItem->pDonnees) = *pDo ;
		pBBItem->setDialogName(string(pDo->nomDialogue)) ;
		pSuper->getDico()->donneCodeSens(&(string(lexiqueModule)), &sCodeSens);
		pBBItem->sLocalisation = sCodeSens;
		pBBItem->creer(true);

    //
    // pBBItemLanceur = "#####1"  p�re de "#TLI#1"
    //
    BBFilsItem* pFilsBBItem = *(pBBItem->aBBItemFils.begin());
    //
    //si le premier �l�ment de de la patpatho de pFilsBBItem est vide, il faut le virer
    //
    NSPatPathoArray* pPPTEnCours = 0; //patpatho de pBBItemLanceur
    if (iterConclusion != pPatpathoActuelle->end())
    {
    	//
      //
      //	pPPTEnCours est la patpatho de pBBItemLanceur , elle est du type
      // 		0CONC1
      //				#TLI#1
      //				  	[ce bout de paptho sera affich� dans le texte libre]
      //
      //
      NSVectFatheredPatPathoArray* pNSVectPatPathoArray = pFilsBBItem->getPatPatho() ;
      pNSVectPatPathoArray->vider();
      pPPTEnCours = pFilsBBItem->getPatpathoActive(pPatpathoActuelle,
 								      				                      iterConclusion) ;
      pBBItemLanceur = new BBItem(pContexte, pFilsBBItem, this, pPPTEnCours, &TmpPPT) ;
    }
    else
    	pBBItemLanceur = new BBItem(pContexte, pFilsBBItem, this, pPPT, &TmpPPT) ;

    *(pBBItemLanceur->pDonnees) = *(pFilsBBItem->getItemData()) ;
		pBBItemLanceur->setDialogName(string(pBBItemLanceur->pDonnees->nomDialogue)) ;
    string sFilsLabel = pFilsBBItem->getItemLabel() ;
    pSuper->getDico()->donneCodeSens(&sFilsLabel, &sCodeSens) ;
    pBBItemLanceur->sLocalisation = pBBItem->sLocalisation ;
    pBBItemLanceur->creer(false) ;
    //
    // le param�tre true emp�che l'appel � DispatcherPatPatho
    // dans creer() (nsbbitem.cpp) car on appelle la m�me
    // fonction dans nstrnode.cpp
    //
  }
  else //conclusion automatique
  {
		//
		// Cr�ation du BBItem ammorce (exemple GECHY en �cho)
		//
    strcpy(lexiqueModule, sLanceurModule.c_str()) ;
    contexteModule = ' ' ;
    if (!ouvreScript())
    {
    	iSeuilSauve = iAncienSeuilSauve ;
			return ;
    }

		pBBItem = new BBItem(pContexte, this) ;
    BBFiche* pBBCommeFiche = static_cast<BBFiche*>(pBBFiche) ;
    BBItemData* pDo = static_cast<BBItemData*>(pBBCommeFiche->pDonnees) ;
		*(pBBItem->pDonnees) = *pDo ;
		pBBItem->setDialogName(string(pBBItem->pDonnees->nomDialogue)) ;
    pBBItem->sLocalisation = sSens ;
		pBBItem->creer(true) ;
    sPositionConclusion = pBBItem->pDonnees->fils ;
    //0CONC le p�re
		pBBItemPere = pBBItem->CreerBBitem(this, "0CONC1", pPPT, sSens, pBBItemPere) ;
    if (!pBBItemPere)
    {
    	delete pBBItem ;
      pBBItem = 0 ;
      iSeuilSauve = iAncienSeuilSauve ;
      return ;
    }
    //0CONC le fils
    BBFilsItem* pFilsBBItem = *(pBBItemPere->aBBItemFils.begin()) ;
    pPPTEnCours = 0; //patpatho de pBBItemLanceur
    bool bNePasDispatcher;
    if (iterConclusion != pPatpathoActuelle->end())
    {
    	NSVectFatheredPatPathoArray* pNSVectPatPathoArray = pFilsBBItem->getPatPatho();
      pNSVectPatPathoArray->vider();
      //
      // Attention, si OCONC1 n'a pas de fils, pPPTEnCours = 0
      //
      pPPTEnCours = pFilsBBItem->getPatpathoActive(pPatpathoActuelle,
 								      				                      iterConclusion);

      if (pPPTEnCours)
      {
      	bNePasDispatcher = false;
        pBBItemLanceur = new BBItem(pContexte, pFilsBBItem, this, pPPTEnCours, &TmpPPT);
      }
      else
      {
      	bNePasDispatcher = true;
        pBBItemLanceur = new BBItem(pContexte, pFilsBBItem, this, pPPT, &TmpPPT);
      }
    }
    else
    {
    	bNePasDispatcher = true;
      pBBItemLanceur = new BBItem(pContexte, pFilsBBItem, this, pPPT, &TmpPPT);
    }

    //
    // pPPTEnCours sera dispatch�e dans les bo�tes de dialogue
    // de pBBItemLanceur et de ses fils
    //

    pBBItemLanceur->sLocalisation = pBBItemPere->sLocalisation ;
    *(pBBItemLanceur->pDonnees) = *(pFilsBBItem->getItemData()) ;
    pBBItemLanceur->setDialogName(string(pBBItemLanceur->pDonnees->nomDialogue)) ;
    pBBItemLanceur->creer(bNePasDispatcher) ;
    // bConclusionAutomatique = true;
  }

  pBBItemLanceur->activer() ;   	//lancer la bo�te de texte libre ou
                             		//la bo�te de la conclusion automatique
  //texte libre
  if ((pBBItemLanceur->bConclusion) && (bTexteLibre))
  {
  	//
    //effacer l'ancien texte libre
    //
    PatPathoIter iterConclusion = pPatpathoActuelle->ChercherItem("0CONC1") ;
    if (iterConclusion != pPatpathoActuelle->end())
    	pPatpathoActuelle->SupprimerItem(iterConclusion) ;

    //
    //mettre � jour les localisations des �l�ments du texte libre
    //mettre "0CONC1" au d�but de pBBItemLanceur->pPPTEnCours
    //
    if (!pBBItemLanceur->pPPTEnCours->empty())
    {
    	PatPathoIter iterPremier = pBBItemLanceur->pPPTEnCours->begin();
      PatPathoIter jter        = pBBItemLanceur->pPPTEnCours->begin();
      jter = iterPremier;
      for ( ; jter != pBBItemLanceur->pPPTEnCours->end(); jter++)
      {      	(*jter)->pDonnees->setLigne((*jter)->pDonnees->getLigne() + 1);
        (*jter)->pDonnees->setColonne((*jter)->pDonnees->getColonne() + 1);
      }
      pBBItemLanceur->pPPTEnCours->ajoutePatho(iterPremier, "0CONC1", 0 , -1);
      //
      //concat�ner les 2 patpathos
      //
      ConcatenerPatpatho("0CONC1", pBBItemLanceur->pPPTEnCours, pPatpathoActuelle);
    }
  }
  else //conclusion automatique
  {
  	PatPathoIter iterConclusion = pPatpathoActuelle->ChercherItem("0CONC1");
    if (iterConclusion == pPatpathoActuelle->end())
    {
    	//une conclusion automatique vient d'�tre faite
      if (!pBBItemLanceur->pPPTEnCours->empty())
      {
      	//
        // mettre � jour les localisations des �l�ments du texte libre
        // mettre "0CONC1" au d�but de pBBItemLanceur->pPPTEnCours
        //
        PatPathoIter iterPremier = pBBItemLanceur->pPPTEnCours->begin();
        PatPathoIter jter = pBBItemLanceur->pPPTEnCours->begin();
        jter = iterPremier;
        for ( ; jter != pBBItemLanceur->pPPTEnCours->end(); jter++)
        {
        	(*jter)->pDonnees->setLigne((*jter)->pDonnees->getLigne() + 1);
          (*jter)->pDonnees->setColonne((*jter)->pDonnees->getColonne() + 1);
        }
        pBBItemLanceur->pPPTEnCours->ajoutePatho(iterPremier, "0CONC1", 0 , -1);

        //
        // Concat�ner les 2 patpathos
        //
        ConcatenerPatpatho("0CONC1", pBBItemLanceur->pPPTEnCours, pPatpathoActuelle);
      }
    }
    else
    {
    	//
      // si on a d�sactiv� tout ce qui est cl automatique, enlever 0CONC1 de
      //la patpatho globale : pas de cl automatqiue
      //
      if (pBBItemLanceur->pPPTEnCours->empty())
      {
      	if (iterConclusion != pPatpathoActuelle->end())
        	pPatpathoActuelle->SupprimerItem(iterConclusion);
      }
      else
      {
      		    //
      		    //effacer l'ancienne conclusion automatqiue
      		    //
      		    if (iterConclusion != pPatpathoActuelle->end())
      			    pPatpathoActuelle->SupprimerItem(iterConclusion);

                PatPathoIter iterPremier = pBBItemLanceur->pPPTEnCours->begin();
                PatPathoIter jter = pBBItemLanceur->pPPTEnCours->begin();
                jter = iterPremier;
                for ( ; jter != pBBItemLanceur->pPPTEnCours->end(); jter++)
                {
            	    (*jter)->pDonnees->setLigne((*jter)->pDonnees->getLigne() + 1);
                    (*jter)->pDonnees->setColonne((*jter)->pDonnees->getColonne() + 1);
                }
                pBBItemLanceur->pPPTEnCours->ajoutePatho(iterPremier, "0CONC1", 0 , -1);
      		    //
      		    //concat�ner les 2 patpathos
      		    //
      		    ConcatenerPatpatho("0CONC1", pBBItemLanceur->pPPTEnCours, pPatpathoActuelle);
      	    }
        }
    }

    *pPPT = *pPatpathoActuelle;
    iSeuilSauve = iAncienSeuilSauve;
    /*if (iSeuilSauve > 0)
    {
    	pBBItem->pPPTEnCours = pPPT;
    	sauvegarde();
    } */

    if (pBBItem)
    {
        delete pBBItem;
     	pBBItem = 0;
    }
    // -------------------- pBBItemPere est ins�r� dans le VectorFils
    // -------------------- de son BBItemFils par la m�thode CreerBBitem
    // -------------------- il est donc d�truit automatiquement
    // -------------------- ce serait peut-�tre bien de faire de m�me avec
    // -------------------- pBBItemLanceur
    // if (pBBItemPere)
    //	delete pBBItemPere;
    if (pBBItemLanceur)
    	delete pBBItemLanceur;

    PatPathoIter iterPremier = pPPT->begin();
    string sLexiqueModule = string((*iterPremier)->pDonnees->lexique);
    strcpy(lexiqueModule, sLexiqueModule.c_str());
}
catch (...)
{
	erreur("Exception NSSmallBrother::Conclusion.", standardError, 0) ;
}
}

//-------------------------------------------------------------------
// sert pour lancer un texte libre en �dition
//-------------------------------------------------------------------
void
NSSmallBrother::EditionTexteLibre()
{
try
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	// Il faut d�sactiver la sauvegarde automatique en conclusion, sinon
	// on �crase toutes les donn�es sauvegard�es
	int iAncienSeuilSauve = iSeuilSauve ;
	iSeuilSauve = -1 ;

	NSPatPathoArray TmpPPT(pContexte) ;
	NSPatPathoArray* pPPT = getPatPatho() ;

	string sCodeSens;
	string sSens;

	strcpy(lexiqueModule, "#####1");
	contexteModule = ' ';
	// bool bTexteLibre = true;
	//on a l'arborescence suivante
	//			pBBItem = "#####1"
	//       		pBBItemPere = "#####1"
	//                   pBBItemLanceur = "#TLI#1"

	if (!pSuper->getFilGuide()->Prend())
		return ;

	if (!pSuper->getDico()->Prend())
		return ;

	pBBFiche = static_cast<BBFiche*>(pSuper->getFilGuide()->pBBFiche) ;

	// Positionnement sur la fiche d'ammorce
	if (!ouvreScript())
	{
		iSeuilSauve = iAncienSeuilSauve ;
		return ;
	}
  //
  // Cr�ation du BBItem ammorce (le p�re) pBBItemPere =  "#####1" le p�re non lanceur de Bo�te de dialogue
  //														est dont le seul fils est "#####1"
  //
  pBBItem = new BBItem(pContexte, this) ;
  BBFiche* pBBCommeFiche = static_cast<BBFiche*>(pBBFiche) ;
  BBItemData* pDo = static_cast<BBItemData*>(pBBCommeFiche->pDonnees) ;
  *(pBBItem->pDonnees) = *pDo ;
  pBBItem->setDialogName(string(pDo->nomDialogue)) ;
  pSuper->getDico()->donneCodeSens(&(string(lexiqueModule)), &sCodeSens) ;
  pBBItem->sLocalisation = sCodeSens ;
  pBBItem->creer(true) ;

	if (pBBItem->aBBItemFils.empty())
  {
  	delete pBBItem ;
    pBBItem = 0 ;
    return ;
  }
  //
  // pBBItemLanceur = "#####1"  p�re de "#TLI#1"
  //
  BBFilsItem* pFilsBBItem = *(pBBItem->aBBItemFils.begin());

  BBItem BBItemLanceur(pContexte, pFilsBBItem, this, pPPT, &TmpPPT) ;

  *(BBItemLanceur.pDonnees) = *(pFilsBBItem->getItemData()) ;
  BBItemLanceur.setDialogName(string(BBItemLanceur.pDonnees->nomDialogue)) ;
  string sFilsLabel = pFilsBBItem->getItemLabel() ;
  pSuper->getDico()->donneCodeSens(&sFilsLabel, &sCodeSens) ;
  BBItemLanceur.sLocalisation = pBBItem->sLocalisation ;
  BBItemLanceur.creer(false) ;
  //
  // le param�tre true emp�che l'appel � DispatcherPatPatho
  // dans creer() (nsbbitem.cpp) car on appelle la m�me
  // fonction dans nstrnode.cpp
  //

  BBItemLanceur.activer();   	//lancer la bo�te de texte libre

  *pPPT = *(BBItemLanceur.pPPTEnCours) ;
  iSeuilSauve = iAncienSeuilSauve ;
  /*if (iSeuilSauve > 0)
  {
    	pBBItem->pPPTEnCours = pPPT;
    	sauvegarde();
    } */

  if (pBBItem)
  {
  	delete pBBItem ;
    pBBItem = 0 ;
  }
}
catch (...)
{
	erreur("Exception NSSmallBrother::EditionTexteLibre.", standardError, 0) ;
}
}

/*** Choix du code (ex CCAM) dans un CR - Choice of exam classification code
*/
void
NSSmallBrother::Codage()
{
try
{
	NSSuper* pSuper = pContexte->getSuperviseur();

	// Il faut d�sactiver la sauvegarde automatique en conclusion, sinon
	// on �crase toutes les donn�es sauvegard�es
	int iAncienSeuilSauve = iSeuilSauve;
	iSeuilSauve = -1;

	NSPatPathoArray* pPPT = getPatPatho() ;
	NSPatPathoArray  pPPTgag(pContexte) ;

	NSPatPathoArray  TmpPPT(pContexte) ;

	//pBBitem : lanceur du module (GECHY par exemple)
	BBItem* pBBItemPere    = 0 ;    //BBitem p�re (conclusion automatique : 0CONC1 le p�re)
	BBItem* pBBItemLanceur = 0 ;    //BBitem lanceur de la conclusion automatique
    							    //on a l'arborescence suivante
    							    //	pBBItem
                      //       		pBBItemPere
                      //                   pBBItemLanceur

	//
	//savoir si on peut avoir une conclusion automatique : pr�sence dans le guide
	//de 0CONC ->faire une recherche s�mantique.
	//Si ce n'est pas le cas, une conclusion manuelle est propos�e et elle �crase
	//l'ancien texte libre.
	//Si c'est le cas, la bo�te de dialogue de conclusion est activ�e.
	//
	string sCodeSens ;
	string sSens ;
	PatPathoIter iterModule = pPPT->begin();
  //
	// Exam's root concept
	//
	string sLanceurModule = string((*iterModule)->pDonnees->lexique); //GECHY par exemple
	pSuper->getDico()->donneCodeSens(&sLanceurModule, &sSens);

	// bool bTexteLibre = false;

	//
	// M�moriser la patpatho actuelle
	//
	NSPatPathoArray PatpathoActuelle = *pPPT;
	NSPatPathoArray* pPatpathoActuelle = &PatpathoActuelle;
	pPPT->vider();
	PatPathoIter iterConclusion = pPatpathoActuelle->ChercherItem("0CODE1");

	NSPatPathoArray* pPPTEnCours = NULL ;

/*
	if (!RechercheSemantique("0CODE", sSens)) //bo�te de texte libre
	{
		strcpy(lexiqueModule, "#####1") ;
		contexteModule = ' ' ;
		bTexteLibre = true ;
		//on a l'arborescence suivante
		//			pBBItem = "#####1"
		//       		pBBItemPere = "#####1"
		//                   pBBItemLanceur = "#TLI#1"

		if (!ouvreScript())
		{
			iSeuilSauve = iAncienSeuilSauve ;
			delete pTmpPPT ;
			return ;
		}
		//
		// Cr�ation du BBItem ammorce (le p�re) pBBItemPere =  "#####1" le p�re non lanceur de Bo�te de dialogue
		//														est dont le seul fils est "#####1"
		//
		pBBItem = new BBItem(this) ;
		BBFiche* pBBCommeFiche = static_cast<BBFiche*>(pBBFiche) ;
		BBItemData* pDo = static_cast<BBItemData*>(pBBCommeFiche->pDonnees) ;
		*(pBBItem->pDonnees) = *pDo ;
		strcpy(pBBItem->szNomDlg, pDo->nomDialogue) ;
		pSuper->pDico->donneCodeSens(&(string(lexiqueModule)), &sCodeSens) ;
		pBBItem->sLocalisation = sCodeSens ;
		pBBItem->creer(true) ;

		//
		// pBBItemLanceur = "#####1"  p�re de "#TLI#1"
		//
		BBFilsItem* pFilsBBItem = *(pBBItem->aBBItemFils.begin()) ;
		//
		// si le premier �l�ment de de la patpatho de pFilsBBItem est vide, il faut le virer
		//
		NSPatPathoArray* pPPTEnCours = 0 ; //patpatho de pBBItemLanceur
		if (iterConclusion != pPatpathoActuelle->end())
		{
			//
			//
			//	pPPTEnCours est la patpatho de pBBItemLanceur , elle est du type
			// 		0CONC1
			//				#TLI#1
			//				  	[ce bout de paptho sera affich� dans le texte libre]
			//
			//
			NSVectPatPathoArray* pNSVectPatPathoArray = pFilsBBItem->getPatPatho() ;
			pNSVectPatPathoArray->vider() ;
			pPPTEnCours = pFilsBBItem->getPatpathoActive(pPatpathoActuelle,
 								      				                      iterConclusion) ;
			pBBItemLanceur = new BBItem(pFilsBBItem, this, pPPTEnCours, pTmpPPT) ;
		}
		else
			pBBItemLanceur = new BBItem(pFilsBBItem, this, pPPT, pTmpPPT) ;

		*(pBBItemLanceur->pDonnees) = *(pFilsBBItem->pDonnees);
		strcpy(pBBItemLanceur->szNomDlg, pBBItemLanceur->pDonnees->nomDialogue);
		pSuper->pDico->donneCodeSens(&pFilsBBItem->sEtiquette, &sCodeSens);
		pBBItemLanceur->sLocalisation = pBBItem->sLocalisation;
		pBBItemLanceur->creer(false);
		//
		// le param�tre true emp�che l'appel � DispatcherPatPatho
		// dans creer() (nsbbitem.cpp) car on appelle la m�me
		// fonction dans nstrnode.cpp
		//
	}
	else //conclusion automatique
	{ */
		//
		// Cr�ation du BBItem ammorce (exemple GECHY en �cho)
		//
		strcpy(lexiqueModule, sLanceurModule.c_str()) ;
		contexteModule = ' ' ;
		if (!ouvreScript())
		{
			iSeuilSauve = iAncienSeuilSauve ;
			return ;
		}

		pBBItem = new BBItem(pContexte, this) ;
		BBFiche* pBBCommeFiche = static_cast<BBFiche*>(pBBFiche) ;
		BBItemData* pDo = static_cast<BBItemData*>(pBBCommeFiche->pDonnees) ;
		*(pBBItem->pDonnees) = *pDo ;
		pBBItem->setDialogName(string(pBBItem->pDonnees->nomDialogue)) ;
		pBBItem->sLocalisation = sSens ;
		pBBItem->creer(true) ;		sPositionConclusion = pBBItem->pDonnees->fils ;
		//0CODE le p�re

		// ***************** New code **************

		if ((iterConclusion != pPatpathoActuelle->end()) && (iterConclusion != NULL))
		{
    	pPPTEnCours = new NSPatPathoArray(pContexte) ;
    	pPatpathoActuelle->ExtrairePatPatho(iterConclusion, pPPTEnCours) ;
		}
    pBBItemPere = pBBItem->CreerBBitem(this, "0CODE1", pPPTEnCours, sSens, pBBItemPere) ;

    if (pPPTEnCours != NULL)
		{
    	delete pPPTEnCours ;
      pPPTEnCours = NULL ;
		}

		if (!pBBItemPere)
		{
			delete pBBItem ;
			pBBItem = 0 ;
			iSeuilSauve = iAncienSeuilSauve ;

      *pPPT = *pPatpathoActuelle ;

			return ;
		}
    pBBItemPere->activer() ;

		PatPathoIter iterConc = pPatpathoActuelle->ChercherItem("0CODE1");
		//
		// No code was chosen
		//
		if (iterConc == pPatpathoActuelle->end())
		{
			//une conclusion automatique vient d'�tre faite
			if (!pBBItemPere->pPPTEnCours->empty())
			{
				//
				// mettre � jour les localisations des �l�ments du texte libre
				// mettre "0CODE1" au d�but de pBBItemLanceur->pPPTEnCours
				//
				PatPathoIter iterPremier = pBBItemPere->pPPTEnCours->begin();
				PatPathoIter jter = pBBItemPere->pPPTEnCours->begin();
				jter = iterPremier;
				for ( ; jter != pBBItemPere->pPPTEnCours->end(); jter++)
				{
					(*jter)->pDonnees->setLigne((*jter)->pDonnees->getLigne() + 1);
					(*jter)->pDonnees->setColonne((*jter)->pDonnees->getColonne() + 1);
				}
				pBBItemPere->pPPTEnCours->ajoutePatho(iterPremier, "0CODE1", 0 , -1);

				//
				// Concat�ner les 2 patpathos
				//
				ConcatenerPatpatho("0CODE1", pBBItemPere->pPPTEnCours, pPatpathoActuelle);
			}
		}
		else
		{
			//
			// si on a d�sactiv� tout ce qui est cl automatique, enlever 0CONC1 de
			// la patpatho globale : pas de cl automatqiue
			//
			if (pBBItemPere->pPPTEnCours->empty())
			{
				if (iterConc != pPatpathoActuelle->end())
					pPatpathoActuelle->SupprimerItem(iterConc);
			}
			else
			{
				//
				// effacer l'ancienne conclusion automatqiue
				//
				if (iterConc != pPatpathoActuelle->end())
					pPatpathoActuelle->SupprimerItem(iterConc) ;

				PatPathoIter iterPremier = pBBItemPere->pPPTEnCours->begin();
				PatPathoIter jter = pBBItemPere->pPPTEnCours->begin();
				jter = iterPremier;
				for ( ; jter != pBBItemPere->pPPTEnCours->end(); jter++)
				{
					(*jter)->pDonnees->setLigne((*jter)->pDonnees->getLigne() + 1);
					(*jter)->pDonnees->setColonne((*jter)->pDonnees->getColonne() + 1);
				}
				pBBItemPere->pPPTEnCours->ajoutePatho(iterPremier, "0CODE1", 0 , -1);
				//
				// concat�ner les 2 patpathos
				//
				ConcatenerPatpatho("0CODE1", pBBItemPere->pPPTEnCours, pPatpathoActuelle);
			}
		}

		*pPPT = *pPatpathoActuelle;
    iSeuilSauve = iAncienSeuilSauve;

    if (pBBItem)
    {
			delete pBBItem;
     	pBBItem = 0;
    }
    // -------------------- pBBItemPere est ins�r� dans le VectorFils
    // -------------------- de son BBItemFils par la m�thode CreerBBitem
    // -------------------- il est donc d�truit automatiquement
    // -------------------- ce serait peut-�tre bien de faire de m�me avec
    // -------------------- pBBItemLanceur
    // if (pBBItemPere)
    //	delete pBBItemPere;


    PatPathoIter iterPremier = pPPT->begin();
    string sLexiqueModule = string((*iterPremier)->pDonnees->lexique);
    strcpy(lexiqueModule, sLexiqueModule.c_str());

/*
		pBBItemPere = pBBItem->CreerBBitem(this, "0CODE1", pPPT, sSens, pBBItemPere);
		if (!pBBItemPere)
		{
			delete pBBItem ;
			pBBItem = 0 ;
			iSeuilSauve = iAncienSeuilSauve ;
			return ;
		}
		//0CONC le fils
		BBFilsItem* pFilsBBItem = *(pBBItemPere->aBBItemFils.begin());
		pPPTEnCours = 0; //patpatho de pBBItemLanceur
		bool bNePasDispatcher;
		if ((iterConclusion != pPatpathoActuelle->end()) && (iterConclusion != NULL))
		{
			NSVectPatPathoArray* pNSVectPatPathoArray = pFilsBBItem->getPatPatho();
			pNSVectPatPathoArray->vider();
			//
			// Attention, si OCODE1 n'a pas de fils, pPPTEnCours = 0
			//
			pPPTEnCours = pFilsBBItem->getPatpathoActive(pPatpathoActuelle,
 								      				                      iterConclusion);

			if (pPPTEnCours)
			{
				bNePasDispatcher = false;
				pBBItemLanceur = new BBItem(pFilsBBItem, this, pPPTEnCours, pTmpPPT);
			}
			else
			{
				bNePasDispatcher = true;
				pBBItemLanceur = new BBItem(pFilsBBItem, this, pPPT, pTmpPPT);
			}
		}
		else
		{
			bNePasDispatcher = true;
			pBBItemLanceur = new BBItem(pFilsBBItem, this, pPPT, pTmpPPT);
		}

		//
		// pPPTEnCours sera dispatch�e dans les bo�tes de dialogue
		// de pBBItemLanceur et de ses fils
		//
		pBBItemLanceur->sLocalisation = pBBItemPere->sLocalisation;
		*(pBBItemLanceur->pDonnees) = *(pFilsBBItem->pDonnees);
		strcpy(pBBItemLanceur->szNomDlg, pBBItemLanceur->pDonnees->nomDialogue);
		pBBItemLanceur->creer(bNePasDispatcher);
        // bConclusionAutomatique = true;
//    }

    pBBItemLanceur->activer();   	//lancer la bo�te de texte libre ou
                             		//la bo�te de la conclusion automatique

    //texte libre
    if ((pBBItemLanceur->bConclusion) && (bTexteLibre))
    {
        //
        //effacer l'ancien texte libre
        //
  		PatPathoIter iterConclusion = pPatpathoActuelle->ChercherItem("0CODE1");
        if (iterConclusion != pPatpathoActuelle->end())
            pPatpathoActuelle->SupprimerItem(iterConclusion);

        //
        //mettre � jour les localisations des �l�ments du texte libre
        //mettre "0CONC1" au d�but de pBBItemLanceur->pPPTEnCours
        //
        if (!pBBItemLanceur->pPPTEnCours->empty())
        {
      	    PatPathoIter iterPremier = pBBItemLanceur->pPPTEnCours->begin();
            PatPathoIter jter        = pBBItemLanceur->pPPTEnCours->begin();
            jter = iterPremier;
            for ( ; jter != pBBItemLanceur->pPPTEnCours->end(); jter++)
            {
         	    (*jter)->pDonnees->setLigne((*jter)->pDonnees->getLigne() + 1);
                (*jter)->pDonnees->setColonne((*jter)->pDonnees->getColonne() + 1);
            }
            pBBItemLanceur->pPPTEnCours->ajoutePatho(iterPremier, "0CODE1", 0 , -1);
            //
      	    //concat�ner les 2 patpathos
      	    //
      	    ConcatenerPatpatho("0CONC1", pBBItemLanceur->pPPTEnCours, pPatpathoActuelle);
        }
    }
    else //conclusion automatique
    {
   	    PatPathoIter iterConclusion = pPatpathoActuelle->ChercherItem("0CODE1");
        if (iterConclusion == pPatpathoActuelle->end())
        {
            //une conclusion automatique vient d'�tre faite
            if (!pBBItemLanceur->pPPTEnCours->empty())
            {
         	    //
      		    // mettre � jour les localisations des �l�ments du texte libre
      		    // mettre "0CONC1" au d�but de pBBItemLanceur->pPPTEnCours
      		    //
	      	    PatPathoIter iterPremier = pBBItemLanceur->pPPTEnCours->begin();
   	            PatPathoIter jter = pBBItemLanceur->pPPTEnCours->begin();
      	        jter = iterPremier;
         	    for ( ; jter != pBBItemLanceur->pPPTEnCours->end(); jter++)
                {
            	    (*jter)->pDonnees->setLigne((*jter)->pDonnees->getLigne() + 1);
                    (*jter)->pDonnees->setColonne((*jter)->pDonnees->getColonne() + 1);
                }
         	    pBBItemLanceur->pPPTEnCours->ajoutePatho(iterPremier, "0CODE1", 0 , -1);

      		    //
      		    // Concat�ner les 2 patpathos
      		    //
      		    ConcatenerPatpatho("0CODE1", pBBItemLanceur->pPPTEnCours, pPatpathoActuelle);
            }
        }
        else
        {
      	    //
      	    // si on a d�sactiv� tout ce qui est cl automatique, enlever 0CONC1 de
      	    //la patpatho globale : pas de cl automatqiue
      	    //
      	    if (pBBItemLanceur->pPPTEnCours->empty())
      	    {
      		    if (iterConclusion != pPatpathoActuelle->end())
      			    pPatpathoActuelle->SupprimerItem(iterConclusion);
      	    }
      	    else
      	    {
      		    //
      		    //effacer l'ancienne conclusion automatqiue
      		    //
      		    if (iterConclusion != pPatpathoActuelle->end())
      			    pPatpathoActuelle->SupprimerItem(iterConclusion);

                PatPathoIter iterPremier = pBBItemLanceur->pPPTEnCours->begin();
                PatPathoIter jter = pBBItemLanceur->pPPTEnCours->begin();
                jter = iterPremier;
                for ( ; jter != pBBItemLanceur->pPPTEnCours->end(); jter++)
                {
            	    (*jter)->pDonnees->setLigne((*jter)->pDonnees->getLigne() + 1);
                    (*jter)->pDonnees->setColonne((*jter)->pDonnees->getColonne() + 1);
                }
                pBBItemLanceur->pPPTEnCours->ajoutePatho(iterPremier, "0CODE1", 0 , -1);
      		    //
      		    //concat�ner les 2 patpathos
      		    //
      		    ConcatenerPatpatho("0CODE1", pBBItemLanceur->pPPTEnCours, pPatpathoActuelle);
      	    }
        }
    }

    *pPPT = *pPatpathoActuelle;
    iSeuilSauve = iAncienSeuilSauve;

    if (pBBItem)
    {
        delete pBBItem;
     	pBBItem = 0;
    }
    // -------------------- pBBItemPere est ins�r� dans le VectorFils
    // -------------------- de son BBItemFils par la m�thode CreerBBitem
    // -------------------- il est donc d�truit automatiquement
    // -------------------- ce serait peut-�tre bien de faire de m�me avec
    // -------------------- pBBItemLanceur
    // if (pBBItemPere)
    //	delete pBBItemPere;
    if (pBBItemLanceur)
    	delete pBBItemLanceur;

    delete pTmpPPT;

    PatPathoIter iterPremier = pPPT->begin();
    string sLexiqueModule = string((*iterPremier)->pDonnees->lexique);
    strcpy(lexiqueModule, sLexiqueModule.c_str());
*/
    return;
}
catch (...)
{
    erreur("Exception NSSmallBrother::Codage.", standardError, 0) ;
}
}


//------------------------------------------------------------------------// sTypeDocument : type de document : exemple consultation, ant�c�dent,...
// lancement de document type consultation
//	pNSTreeWindow : pointeur sur la TreeView qui supportera la vue
//------------------------------------------------------------------------
void
NSSmallBrother::lanceConsult(string sTypeDocument, NSTreeWindow* pNSTreeWindow)
{
try
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	NSPatPathoArray* pPPT = getPatPatho() ;

	contexteModule = ' ';
	string sLexique ;
	string sCodeSens ;
	if (!ouvreResModule())
		return ;
	if (!pSuper->getFilGuide()->Prend())
		return ;
	if (!pSuper->getDico()->Prend())
		return ;
	//
	// Instancie la fiche guide
	//
	pBBFiche = static_cast<BBFiche*>(pSuper->getFilGuide()->pBBFiche) ;

	//
  // Cr�ation d'un nouveau document
  //
  if (sTypeDocument != "") //ok sur le choix du type
  {
  	pPPT->vider() ;
    sLexique = sTypeDocument ;
    strcpy(lexiqueModule, sLexique.c_str()) ; //choix de l'utilisateur

    // Reprise d'un �ventuel fichier temporaire
    if (pPatPathoArray->empty())
    	reprise() ;
  }
  //
  // Reprise d'un document existant
  //
  else
  {
  	//
    // Si la patpatho n'est pas vide, on initialise noeud et lexique
    // � partir de sa racine
    //
    if (!(pPPT->empty()))
    {
    	// strcpy(noeudModule, (*(pPPT->begin()))->pDonnees->noeud);

      sLexique = string((*(pPPT->begin()))->pDonnees->lexique) ;
      EnleverTitre() ;
      strcpy(lexiqueModule, sLexique.c_str()) ; //1er �l�ment de la patpatho
    }
    else
    	return ;
	}

  pSuper->getDico()->donneCodeSens(&sLexique, &sCodeSens) ;
  pBBFiche = static_cast<BBFiche*>(pSuper->getFilGuide()->pBBFiche) ;
  ouvreScript() ;  //recherche dans GUIDES.DB

  BBFiche* pBBCommeFiche = static_cast<BBFiche*>(pBBFiche) ;
  BBItemData* pDo = static_cast<BBItemData*>(pBBCommeFiche->pDonnees) ;

  string sFils = string(pDo->fils) ;
  //
  // Tester si la fiche r�cuper�e dans le guide correspond au lanceur
  // de la consultation
  //
  if ((!(sCodeSens == string(pBBFiche->pDonnees->chemin))) /*pas de fiche dans le guide*/
                    ||
      (sFils.find(sLexique) == NPOS) /* l'�l�ment lanceur ne figure pas en tant que son
                                         propre fils dans le guide, exemple GECHY */)
  {
    //mauvaise fiche par la recherche exacte : faire une recherche s�mantique
    VecteurRechercheSelonCritere VecteurSelonCritere(GUIDE) ;
    string sLocalisation;

    sLocalisation = sCodeSens;
    bool trouve;
    VecteurSelonCritere.AjouteEtiquette(sCodeSens);
    pSuper->getFilGuide()->chercheChemin(&sLocalisation ,
                         &VecteurSelonCritere, NSFilGuide :: compReseau);

    VecteurSelonCritere.SetData(sCodeSens, &trouve, pBBFiche->pDonnees) ;
    if ((!trouve) || (sFils.find(sLexique) == NPOS)) /* l'�l�ment lanceur ne figure pas en tant que son
                                       propre fils dans le guide, exemple GECHY */
    // La recherche s�mantique � �chou�
    {
      //
      // Instancier "� la main" les donn�es
      // Exemple si on choisit ant�c�dents (ANTEC1) et qu'on ne trouve pas
      // dans le guide les donn�es correspondants � ce code, on cr�e
      // la fiche suivante :  chemin  	    : ANTEC
      //						fils	  		: ANTEC1
      //                      nomDialogue 	: TEXTELIB
      //                      ouvreDialogue   : O
      //                      decalageNiveau	: +00+00
      //                      fichierDialogue : NSBB
      //
      pBBFiche->pDonnees->metAZero() ;
      strcpy(pDo->chemin, sCodeSens.c_str()) ;
      strcpy(pDo->fils, sLexique.c_str()) ;
      strcpy(pDo->nomDialogue, "TEXTELIB") ;
      strcpy(pDo->ouvreDialogue, "O") ;
      strcpy(pDo->decalageNiveau, "+00+00") ;
      strcpy(pDo->fichierDialogue, "NSBB") ;
    }
  }
  //
	// Cr�ation du BBItem ammorce (le p�re)
	//
	pBBItem = new BBItem(pContexte, this) ;

	*(pBBItem->pDonnees) = *pDo ;
	pBBItem->setDialogName(string(pBBItem->pDonnees->nomDialogue)) ;

  pBBItem->sLocalisation = sCodeSens ;
	pBBItem->creer(true) ;   // Le param�tre true emp�che l'appel �
                            // DispatcherPatPatho dans creer() (nsbbitem.cpp)
                            // car on appelle la m�me fonction dans nstrnode.cpp
  //
  // Ajout sp�cifique
  //
  pNSTreeWindow->pBBitemNSTreeWindow  = pBBItem ;
  pNSTreeWindow->pControle    		= new NSControle(pContexte, pBBItem, sLexique.c_str(), "") ; //1er �l�ment de la patpatho
  pNSTreeWindow->pControle->setControle(static_cast<void*>(pNSTreeWindow)) ;
  pNSTreeWindow->pControle->setType(pNSTreeWindow->donneType()) ;
  pNSTreeWindow->pControle->setNSDialog(0) ;

  //
  // Cr�er le deuxi�me BBItem (GCONS le fils en cas de consultation par exemple)
  //
  BBFilsItem* pFilsItem = *(pBBItem->aBBItemFils.begin()) ;
  int creer = pBBItem->developperConsultation(pFilsItem) ;
  if (creer != 0)
  	return ;

  BBFilsItem* fils = *(pNSTreeWindow->pBBitemNSTreeWindow->aBBItemFils.begin()) ;
    //   NSCSDocument* CSDoc = dynamic_cast<NSCSDocument*>(pDoc);
    //   *(*(fils->getPatPatho()->begin())) = *(CSDoc->pPatPathoArray);
  NSPatPathoArray* pPatPatho = (*(fils->getPatPatho()->begin()))->getPatPatho() ;
	*pPatPatho = *pPPT ;
}
catch (...)
{
	erreur("Exception NSSmallBrother::lanceConsult.", standardError, 0) ;
}
}

void
NSSmallBrother::lance12(string sNoeud1, string sNoeud2)
{
try
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;
	//
	// Cr�ation du BBItem ammorce (le p�re)
	//
	pBBItem = new BBItem(pContexte, this) ;

	BBItemData* pDo = new BBItemData() ;
	strcpy(pDo->ouvreDialogue, "N") ;
	strcpy(pDo->fils, sNoeud2.c_str()) ;
	strcpy(pDo->decalageNiveau, "+01+01") ;
	strcpy(pDo->fichierDialogue, "NSBB") ;

	*(pBBItem->pDonnees) = *pDo ;
	pBBItem->setDialogName(string("")) ;

	string sCodeSens ;
	pSuper->getDico()->donneCodeSens(&sNoeud1, &sCodeSens) ;
	pBBItem->sLocalisation = sCodeSens ;
	pBBItem->creer(false) ;

	//
	// Cr�er le deuxi�me BBItem
	//
	BBFilsItem* pFilsItem = *(pBBItem->aBBItemFils.begin()) ;
	int creer = pBBItem->developperConsultation(pFilsItem) ;
	// Si result dialogue OK : 0, si CANCEL : -1
	if (creer != 0)
	{
		delete pBBItem ;
		pBBItem = 0 ;
		return ;
	}

	pBBItem->okFermerDialogue(true) ;
	*pPatPathoArray = *(pBBItem->pPPTEnCours) ;

	delete pBBItem ;
	pBBItem = 0 ;
}
catch (...)
{
	erreur("Exception NSSmallBrother::lanceConsult.", standardError, 0) ;
}
}



/**
* Ouverture du fichier des fils guides et positionnement sur la fiche d'ammorce
* Open Fils guides repository and set the cursor at this module's root 
*/
bool
NSSmallBrother::ouvreScript()
{
try
{
	NSSuper* pSuper = pContexte->getSuperviseur();
	//
	// Recherche de l'ammorce
	//
	string sCodeSens;
	pSuper->getDico()->donneCodeSens(&(string(lexiqueModule)), &sCodeSens);

  if (sCodeSens == "")
  	return false ;

  if (!pBBFiche)
  	pBBFiche = static_cast<BBFiche*>(pSuper->getFilGuide()->pBBFiche) ;

	pBBFiche->lastError = pBBFiche->chercheClef(&sCodeSens,
                                                "CHEMIN",
                                                keySEARCHGEQ,
                                                dbiWRITELOCK);
	if (pBBFiche->lastError != DBIERR_NONE)
	{
		erreur("Le fichier de script n'est pas ammor�able.", standardError, pBBFiche->lastError);
		return false;
	}
	//
	// On r�cup�re l'enregistrement
	//
	pBBFiche->lastError = pBBFiche->getRecord() ;
	if (pBBFiche->lastError != DBIERR_NONE)
	{
		erreur("Le fichier de script est inutilisable.", standardError, pBBFiche->lastError) ;
		return false ;
	}
	return true ;
}
catch (...)
{
	erreur("Exception NSSmallBrother::ouvreScript.", standardError, 0) ;
	return false ;
}
}

//---------------------------------------------------------------------------//		M�thode qui retourne un pointeur sur le module(pTModule)
//		de l'�l�ment si libelle existe
//---------------------------------------------------------------------------
TModule*
NSSmallBrother::TrouverModule(const char * lib)
{
    if (!lib || (lib[0] == '\0') || (pResModuleArray->empty()))
        return 0 ;

    // Parcourir le vecteur pResModuleArraypour savoir si lib existe,
    // si c'est le cas alors retourner le module correspondant
	for (iterNSTModuleArray i = pResModuleArray->begin();
                                            i != pResModuleArray->end(); i++)
        if (strcmp((*i)->libelle, lib) == 0)
      	    return (*i)->pTModule;

    // lib n'existe pas , on ne retourne rien
    return 0;
}

//---------------------------------------------------------------------------//  	M�thode de param = libell� , si libelle existe ne fait rien, sinon cr�ee
// 	un nouveau TModule et une nouvelle fiche NSModuleDialogue qu'il ajoute au vecteur.
//---------------------------------------------------------------------------
bool
NSSmallBrother::CreerNouveauModule(char * lib)
{
	if (!lib || (lib[0] == '\0'))
		return false ;

try
{
	TModule*		  pNewTModule;
  NSModuleDialogue* pNewNSModuleDialogue;

	// Voir si lib existe, si c'est le cas alors ne rien faire
  if (!(pResModuleArray->empty()))
  	for (iterNSTModuleArray i = pResModuleArray->begin(); i != pResModuleArray->end(); i++)
    	if (strcmp((*i)->libelle, lib) == 0)
      	return true ;

  // lib n'existe pas : on cr�ee alors un nouveau module et un nouveau
  // NSModuleDialogue que l'on rajoute au vecteur pResModuleArray.
  pseumaj(lib) ;

  if ((string(lib) == "NSBB") || (string(lib) == "NSMBB"))
  	pNewTModule = pNSDLLModule ;
  else
  {
  	string sNomDLL = string(lib) + ".DLL" ;
		pNewTModule = new TModule(sNomDLL.c_str(), true) ;
		if (!pNewTModule)
		{
    	string sErreur = string("La DLL sp�cifique (") + sNomDLL + string(") est introuvable.") ;
			erreur(sErreur.c_str(), standardError, -1) ;
			return false ;
		}
  }

  pNewNSModuleDialogue = new NSModuleDialogue() ;
  pNewNSModuleDialogue->pTModule = pNewTModule ;
  strcpy(pNewNSModuleDialogue->libelle, lib) ;
  pResModuleArray->push_back(pNewNSModuleDialogue) ;

  return true ;
}
catch (...)
{
	erreur("Exception NSSmallBrother::CreerNouveauModule.", standardError, 0) ;
	return false ;
}
}

//---------------------------------------------------------------------
// MAJ de VectorCalcul
//---------------------------------------------------------------------
void
NSSmallBrother::AjouteVecteur(string sLocalisation , string sContenu)
{
try
{
	VectorCalcul->push_back(new classCalcul(sLocalisation , sContenu));
}
catch (...)
{
    erreur("Exception NSSmallBrother::AjouteVecteur.", standardError, 0) ;
}
}

voidNSSmallBrother:: RemplirVecteur(string sLocalisation, string sContenu)
{
    if (!(VectorCalcul->empty()))
    {
        iterStringCalcul iter = VectorCalcul->begin() ;
        for (; iter != VectorCalcul->end(); iter++)
        {
   	        if ((*iter)->sLocalisation == sLocalisation)
            {
      	        (*iter)->sContenu = sContenu ;
                return ;
            }
        }
    }

    AjouteVecteur(sLocalisation , sContenu) ;
}

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
string
NSSmallBrother::TrouverElement(string sLocalisation)
{
    if (!(VectorCalcul->empty()))
    {
        iterStringCalcul iter = VectorCalcul->begin() ;
        for (; iter != VectorCalcul->end(); iter++)
        {
   	        if ((*iter)->sLocalisation == sLocalisation)
      	        return (*iter)->sContenu ;
        }
    }
	return (string("")) ;
}

//--------------------------------------------------------------------------------
// Prend le message en bas de pile (et l'efface)
//
// Il est possible de passer un pointeur pour r�cup�rer le BBCmdMessage
// ou de ne rien passer pour traiter uniquement le code de commande (iCmd)
//--------------------------------------------------------------------------------
int
NSSmallBrother::depile(BBCmdMessage* pCmdMsg)
{
    if (pCmdMsgArray->empty())
   	    return NSDLG_AUCUN ;

    iterBBCmdMsg i = pCmdMsgArray->begin() ;

    int iCommande = (*i)->iCmd ;
    if (pCmdMsg)
   	    *pCmdMsg = *(*i) ;

    delete *i ;
    pCmdMsgArray->erase(i) ;

    return iCommande;
}

//--------------------------------------------------------------------------------
// Ajoute un message en haut de la pile
//--------------------------------------------------------------------------------
void
NSSmallBrother::empile(BBCmdMessage* pCmdMsg, bool tuer)
{
try
{
    pCmdMsgArray->push_back(new BBCmdMessage(*pCmdMsg)) ;

    if (tuer)
    {
        delete pCmdMsg ;
        pCmdMsg = 0 ;
    }
}
catch (...)
{
    erreur("Exception NSSmallBrother::empile.", standardError, 0) ;
}
}

//--------------------------------------------------------------------------------
// Ajoute un message en haut de la pile
//--------------------------------------------------------------------------------
void
NSSmallBrother::reEmpile(BBCmdMessage* pCmdMsg, bool tuer)
{
try
{
    pCmdMsgArray->push_front(new BBCmdMessage(*pCmdMsg)) ;

    if (tuer)
    {
   	    delete pCmdMsg ;
        pCmdMsg = 0 ;
    }
}
catch (...)
{
    erreur("Exception NSSmallBrother::reEmpile.", standardError, 0) ;
}
}

void
NSSmallBrother::repriseSauvegarde()
{}

void
NSSmallBrother::effacerSauvegarde()
{}

void
NSSmallBrother::sauvegarde()
{
try
{
	// Attention : lors de la modification d'un conclusion, pPPTEnCours est nul
	//
	// if ((!pBBItem) || (!(pBBItem->pPPTEnCours)))
	if (NULL == pBBItem)
		return ;
/*
    NSPatPathoArray* pPATP = pBBItem->pPPTEnCours;
    if (pPATP->pContexte != pContexte)
    	return;
    if (!pContexte->getPatient())
        return;

    //    // Il faut construire l'arbre
    //

    // On sauvegarde la patpatho initiale
    NSPatPathoArray* pPPTSauve = new NSPatPathoArray(pContexte);
    if (!(pPPTSauve->empty()))
        *pPPTSauve = *pPATP;

    // On met � jour la patpatho
    pBBItem->MiseAjourPatpatho();
*/

  // Modifs PA 16/05/09
  //
	// pBBItem->rapatrieTmpPpt() ;
	// NSPatPathoArray* pPATP = pBBItem->pTempPPT ;

  pTmpPPtArray->vider() ;

  pBBItem->rapatrieTmpPpt(pTmpPPtArray, 0) ;
	NSPatPathoArray* pPATP = pTmpPPtArray ;
	if ((NULL == pPATP) || pPATP->empty())
		return ;

	// On ajoute le titre
	pPATP->ajouteTitre(string(lexiqueModule), string(noeudModule)) ;
	// on d�cale tout d'un cran (sauf le titre) apr�s insertion du titre
	PatPathoIter j = pPATP->begin() ;
	if (j != pPATP->end())
		j++ ;
	else
	{
		// delete pPPTSauve;
    return ;
	}

	while (j != pPATP->end())
	{
		(*j)->pDonnees->setColonne((*j)->pDonnees->getColonne() + 1) ;
		(*j)->pDonnees->setLigne((*j)->pDonnees->getLigne() + 1) ;
    j++ ;
	}

	//
	// Puis le transformer en chaine
	//
	string sChaine;
	pPATP->genereChaine(&sChaine) ;
	string sEntete = string("{PatPatho CN040|") ;
	if (pContexte->getPatient())
		sEntete += pContexte->getPatient()->getNom() + string("|")
                     + pContexte->getPatient()->getPrenom() + string("|")
                     + pContexte->getPatient()->getNaissance() + string("|")
                     + pContexte->getPatient()->getSexe() + string("}") ;
	else
		sEntete += string(" | |00000000| }") ;

	sChaine = sEntete + sChaine + string("{/PatPatho}") ;
	// On remet la patpatho
	// *pPATP = *pPPTSauve;
	// delete pPPTSauve;

	// On enregistre la cha�ne
	ofstream outFile ;
	outFile.open("arbre.tmp", ios::out) ; // �crase le contenu
	if (!outFile)
		return ;

	outFile << sChaine ;	outFile.close() ;
}
catch(ios_base::failure var)
{
	string sExept = "Exception (" + string(var.what()) + ") lors de la sauvegarde automatique" ;
  erreur(sExept.c_str(), standardError, 0) ;
}
catch (...)
{
	erreur("Probl�me inconnu lors de la sauvegarde automatique.", standardError, 0) ;
}
}

voidNSSmallBrother::rapatriePatpatho(BBItem* pItem)
{
	if ((NULL == pItem) || (pItem->aBBItemFils.empty()))
		return ;

try
{
  // Modifs PA 16/05/09
	// pItem->pTempPPT->vider() ;

  pTmpPPtArray->vider() ;

	if (pItem->aBBItemFils.empty())
		return ;

	// pour tous les fils
	//
	for (BBiter i = pItem->aBBItemFils.begin(); pItem->aBBItemFils.end() != i; i++)
	{
		//
		// Demande � l'�l�ment de transfert de se mettre � jour, uniquement si
		// l'�l�ment n'est pas prolongeable
		//
		if (false == (*i)->FilsProlongeable)
			if (NULL == (*i)->getItemTransfertData()->TempTransfer())
				return ;
    //
		// Lance la fonction r�cursivement sur l'�ventuel BBItem fils
		//
    for (BBiterFils j = (*i)->VectorFils.begin(); (*i)->VectorFils.end() != j; j++)
    	if (*j)
      	rapatriePatpatho((*j)) ;

		if ((*i)->Actif())
    {
    	//
      //cas particulier : si sEtiquettePatpatho contient �C prendre les donn�es
      //vider le compl�ment
      //
      if (((*i)->getItemLabel().find(string("�C;")) != NPOS) ||
            	((*i)->getItemLabel().find(string("/�C;")) != NPOS))
      	(*i)->getItemTransfertMsg()->SetComplement(string("")) ;

      NSVectFatheredPatPathoArray* pPatpathoItem = (*i)->getTmpPatho() ;

      //si le vecteur est vide on ajoute seulement  l'�tiquette
      //if (pPatpathoItem->empty())
      if ((*i)->TmpPptvide())
      	pItem->AjouteTmpEtiquette(pTmpPPtArray, (*i)) ;

      // sinon, pour chaque �l�ment du vecteur , on ajoute
      // l'�tiquette et cet �l�ment
      else
      {
      	if (string((*i)->getItemData()->decalageNiveau) == string("+00+00"))
        	for (FatheredPatPathoIterVect j = pPatpathoItem->begin(); pPatpathoItem->end() != j; j++)
          	// pItem->pTempPPT->ajouteVecteur((*j)->getPatPatho(), ORIGINE_PATH_PATHO + 0) ;
            pTmpPPtArray->ajouteVecteur((*j)->getPatPatho(), ORIGINE_PATH_PATHO + 0) ;
        else
        {
        	for (FatheredPatPathoIterVect j = pPatpathoItem->begin(); pPatpathoItem->end() != j; j++)
          {
          	pItem->AjouteTmpEtiquette(pTmpPPtArray, (*i)) ;
            // pItem->pTempPPT->ajouteVecteur((*j)->getPatPatho(), ORIGINE_PATH_PATHO + 1) ;
            pTmpPPtArray->ajouteVecteur((*j)->getPatPatho(), ORIGINE_PATH_PATHO + 1) ;
          }
        }
      }
    }
  }
}
catch (...)
{
	erreur("Exception NSSmallBrother::rapatriePatpatho.", standardError, 0) ;
}
}

/*
void
NSSmallBrother::rapatriePatpatho(BBItem* pItem)
{
    if (pItem->aBBItemFils.empty())
        return;

try
{
    pItem->pPPTEnCours->vider();

    NSVectPatPathoArray* pPatpathoItem;

    // pour tous les fils
    //
    for (BBiter i = pItem->aBBItemFils.begin(); i != pItem->aBBItemFils.end(); i++)
    {
    	//
		// Demande � l'�l�ment de transfert de se mettre � jour, uniquement si
		// l'�l�ment n'est pas prolongeable
		//
    	if ((*i)->FilsProlongeable == false)
		{
        	if (!((*i)->pTransfert->Transfer(tdGetData)))
            	return;

        	// Utilis� pour le transfert de document type consultation
        	// pour la mise � jour de la base des textes libres
        	//
        	if (!((*i)->pTransfert->TransferFinal(tdGetData)))
            	return;
		}
    	//
		// Lance la fonction r�cursivement sur l'�ventuel BBItem fils
		//
    	for (BBiterFils j = (*i)->VectorFils.begin(); j != (*i)->VectorFils.end(); j++)
        	if (*j)
   	    		rapatriePatpatho((*j));

        if ((*i)->Actif())
        {
        	//
            //cas particulier : si sEtiquettePatpatho contient �C prendre les donn�es
            //vider le compl�ment
            //
            if (((*i)->sEtiquette.find(string("�C;")) != NPOS) ||
            	((*i)->sEtiquette.find(string("/�C;")) != NPOS))
            	(*i)->pTransfert->pTransfertMessage->SetComplement(string(""));

            pPatpathoItem = (*i)->getPatPatho();

            //si le vecteur est vide on ajoute seulement  l'�tiquette
            //if (pPatpathoItem->empty())
            if ((*i)->PatPtahovide())
            	pItem->AjouteEtiquette((*i));

            // sinon, pour chaque �l�ment du vecteur , on ajoute
            // l'�tiquette et cet �l�ment
            else
            {
            	if (string((*i)->pDonnees->decalageNiveau) == string("+00+00"))
                {
                	for (PatPathoIterVect j = pPatpathoItem->begin(); j != pPatpathoItem->end(); j++)
                    	pItem->pPPTEnCours->ajouteVecteur(*j, ORIGINE_PATH_PATHO + 0);
                }
                else
                {
                	for (PatPathoIterVect j = pPatpathoItem->begin(); j != pPatpathoItem->end(); j++)
                    {
                    	pItem->AjouteEtiquette((*i));
                        pItem->pPPTEnCours->ajouteVecteur(*j, ORIGINE_PATH_PATHO + 1);
                    }
                }
            }
        }
    }
}
catch (const exception& e)
{
    string sExept = "Exception (" + string(e.what()) + ") au rapatriement des donn�es";
    erreur(sExept.c_str(), standardError, 0) ;
}
}
*/

voidNSSmallBrother::showBB(){	rapatriePatpatho(pBBItem) ;	addDatasFromNautilusOnBlackboard(pContexte, pBBItem->pPPTEnCours) ;}void
NSSmallBrother::reprise()
{
try
{
	string sChaine = "" ;

	// On r�cup�re la cha�ne  ifstream inFile ;
  inFile.open("arbre.tmp", ios::in) ;
	if (!inFile)
		return ;

	string line ;

  while (!inFile.eof())  {
  	getline(inFile, line) ;
    if (line != "")
    	sChaine += line ;
  }

  // inFile >> sChaine;  inFile.close() ;

  if (sChaine == "")  	return ;

  string sCivilite = "" ;
  if (("{PatPatho CN030" == string(sChaine, 0, 15)) ||      ("{PatPatho CN040" == string(sChaine, 0, 15)))  {     
  	size_t n = 16 ;
    string sNom = "" ;
    for (; (n < strlen(sChaine.c_str())) && (sChaine[n] != '|'); n++)
    	sNom += sChaine[n] ;
    if (n < strlen(sChaine.c_str()))
    	n++ ;
    string sPrenom = "" ;
    for (; (n < strlen(sChaine.c_str())) && (sChaine[n] != '|'); n++)
    	sPrenom += sChaine[n] ;

    if (n < strlen(sChaine.c_str()))    	n++ ;
    string sNaissance = "" ;
    for (; (n < strlen(sChaine.c_str())) && (sChaine[n] != '|'); n++)
    	sNaissance += sChaine[n] ;
    sCivilite = sPrenom + string(" ") + sNom ;
  }

	NSPatPathoArray PPTReprise(pContexte) ;  PPTReprise.initialiseDepuisChaine(&sChaine) ;

  if (PPTReprise.empty())  	return ;

  PatPathoIter j = PPTReprise.begin() ;  if (strcmp((*j)->pDonnees->lexique, lexiqueModule) != 0)
  	return ;

  string sMessage;
  if (sCivilite == "")  	sMessage = string("Il existe un compte rendu de ce type en m�moire temporaire.\n Souhaitez vous le r�cup�rer ?") ;
  else
		sMessage = string("Un compte rendu de ce type, r�alis� pour ") +
        		   sCivilite +
                   string(" est rest� en m�moire temporaire.\n Souhaitez vous le r�cup�rer ?") ;

	int idRet = MessageBox(0, sMessage.c_str(), "Reprise de fichier temporaire", MB_YESNO) ;  if (idRet != IDYES)
  	return ;

  *pPatPathoArray = PPTReprise ;
	return ;}
catch(ios_base::failure var)
{
	string sExept = "Exception (" + string(var.what()) + ") � la reprise des donn�es" ;
  erreur(sExept.c_str(), standardError, 0) ;
}
catch (...)
{
	erreur("Exception NSSmallBrother::reprise.", standardError, 0) ;
}
}

voidNSSmallBrother::defaire()
{}

voidNSSmallBrother::refaire()
{}

// -------------------------------------------------------------------------
// -------------------- METHODES DE NSModuleArray ---------------------------
// -------------------------------------------------------------------------

NSModuleDialogue::NSModuleDialogue(){
	libelle[0] = '\0' ;
  pTModule = 0 ;
}

NSModuleDialogue::~NSModuleDialogue(){
	if ((pTModule) && (pTModule != pNSDLLModule))
  {
  	delete pTModule ;
    pTModule = 0 ;
  }
}

//---------------------------------------------------------------------------//  Description :	Constructeur copie
//  Retour :		Rien
//---------------------------------------------------------------------------
NSResModuleArray::NSResModuleArray(NSResModuleArray& rv)
                 :NSTModuleArray()
{
try
{
    if (!(rv.empty()))
        for (iterNSTModuleArray i = rv.begin(); i != rv.end(); i++)   	        push_back(new NSModuleDialogue());
}
catch (...)
{
    erreur("Exception NSResModuleArray copy ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Fonction:		~NSModuleArray()
//  Description:	Destructeur
//---------------------------------------------------------------------------
void
NSResModuleArray::vider()
{
    if (empty())
        return;

    for (iterNSTModuleArray i = begin(); i != end(); )    {
        if ((*i)->pTModule)
        {
            const char* nomModule = (*i)->pTModule->GetName();
            //
            // ne pas deleter le module "nsbb.dll" , il sera delet� �
            // DllEntryPoint(nsbb.cpp)
            //
            if ((string(nomModule).find(string("nsbb")) == NPOS) &&
                (string(nomModule).find(string("NSBB")) == NPOS) &&
                (string(nomModule).find(string("nsmbb")) == NPOS) &&
                (string(nomModule).find(string("NSMBB")) == NPOS) )
            {
      		    delete (*i)->pTModule;
         	    (*i)->pTModule = 0;
            }
        }
   	    delete *i;
        erase(i);
    }
}

NSResModuleArray::~NSResModuleArray(){
	vider();
}

//---------------------------------------------------------------------------//  Fonction	 : NSResModuleArray::operator=(NSResModuleArray src)
//
//  Description : Op�rateur d'affectation
//---------------------------------------------------------------------------
NSResModuleArray&
NSResModuleArray::operator=(NSResModuleArray src)
{
	if (this == &src)
		return *this ;

try
{
	vider() ;

	if (!(src.empty()))
		for (iterNSTModuleArray i = src.begin(); i != src.end(); i++)			push_back(new NSModuleDialogue()) ;

	return *this ;}
catch (...)
{
	erreur("Exception NSResModuleArray (op =).", standardError, 0) ;
	return *this ;
}
}

//***************************************************************************// 							Impl�mentation des m�thodes ClasseCalculVector
//***************************************************************************
ClasseCalculVector::~ClasseCalculVector()
{
	vider();
}

ClasseCalculVector::ClasseCalculVector()                   :vectclassCalcul()
{}

voidClasseCalculVector::vider()
{
	if (empty())
		return ;

	iterStringCalcul i = begin() ;	while (i != end())
	{
		delete *i ;
		erase(i) ;
	}
}

ClasseCalculVector&ClasseCalculVector::operator=(ClasseCalculVector src)
{
	if (this == &src)
		return *this ;

try
{
	vider() ;

	if (false == src.empty())
		for (iterStringCalcul i = src.begin(); i != src.end(); i++)			push_back(new classCalcul(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception ClasseCalculVector (op =).", standardError, 0) ;
	return *this ;
}
}

ClasseCalculVector::ClasseCalculVector(ClasseCalculVector& src){
try
{
	if (false == src.empty())
		for (iterStringCalcul i = src.begin(); i != src.end(); i++)
			push_back(new classCalcul(*(*i))) ;
}
catch (...)
{
	erreur("Exception ClasseCalculVector copy ctor.", standardError, 0) ;
}
}

//************************************************************************
// classe classCalcul
//************************************************************************
classCalcul::classCalcul(classCalcul& src)
{
    sLocalisation = src.sLocalisation;
    sContenu      = src.sContenu;
}


//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
classCalcul&
classCalcul::operator= (classCalcul src)
{	if (this == &src)		return *this ;    sLocalisation = src.sLocalisation;
    sContenu      = src.sContenu;

    return *this;
}

classCalcul::classCalcul( string sLoca, string sCont){
    sLocalisation = sLoca;
    sContenu      = sCont;
}

//***************************************************************************// 							Impl�mentation des m�thodes BBCmdMsgVector
//***************************************************************************
BBCmdMsgVector::BBCmdMsgVector()
               :vectbbcmdmsg()
{
}

BBCmdMsgVector::BBCmdMsgVector(BBCmdMsgVector& src){
try
{
    if (!(src.empty()))
        for (iterBBCmdMsg i = src.begin(); i != src.end(); i++)
   	        push_back(new BBCmdMessage(*(*i)));
}
catch (...)
{
    erreur("Exception BBCmdMsgVector copy ctor.", standardError, 0) ;
}
}

BBCmdMsgVector::~BBCmdMsgVector()
{
    vider();
}

void
BBCmdMsgVector::vider()
{
    if (empty())
        return;

    iterBBCmdMsg i = begin();
    while (i != end())    {
   	    delete *i;
        erase(i);
        i = begin();
    }
}

BBCmdMsgVector&BBCmdMsgVector::operator=(BBCmdMsgVector src)
{
try
{
    vider();

    if (!(src.empty()))
        for (iterBBCmdMsg i = src.begin(); i != src.end(); i++)   	        push_back(new BBCmdMessage(*(*i)));

  	return *this;}
catch (...)
{
    erreur("Exception BBCmdMsgVector (op =).", standardError, 0) ;
    return *this;
}
}

//************************************************************************
// classe BBCmdMessage
//************************************************************************
BBCmdMessage::BBCmdMessage(int cmd, string message)
{
	iCmd 	 = cmd;
  	sMessage = message;
}

BBCmdMessage::BBCmdMessage(BBCmdMessage& src){
	iCmd 	 = src.iCmd;
    sMessage = src.sMessage;
}

//---------------------------------------------------------------------------//  Op�rateur d'affectation
//---------------------------------------------------------------------------
BBCmdMessage&
BBCmdMessage::operator=(BBCmdMessage src)
{
	iCmd 	 = src.iCmd;
    sMessage = src.sMessage;

    return *this;
}
