// -----------------------------------------------------------------------------// Nsbbitem.cpp
// -----------------------------------------------------------------------------
// Impl�mentation de toutes les classes n�cessaires au fonctionnement de BIG-BROTHER
// -----------------------------------------------------------------------------
// $Revision: 1.85 $
// $Author: philippe $
// $Date: 2005/06/17 10:19:53 $
// -----------------------------------------------------------------------------
// PK  - 04/1993
// PA  - 02/1995
// HK  - 03/1997
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Copyright Nautilus, 2004
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � g�rer et traiter les
// informations de sant� d'une personne.
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to manage and process
// a person's health data.
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------

#include <owl\olemdifr.h>
#include <owl\applicat.h>
#include <owl\checkbox.h>

#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"

#include "nsbb\nsbb_msg.h"

#include "partage\ns_vector.h"
#include "nsbb\nsbb.h"
#include "nsbb\nsbbsmal.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbbtran.h"
#include "nsbb\nsbouton.h"
#include "nsbb\nsarc.h"#include "nsbb\nstabwindow.h"#include "nsbb\ns_multi.h"#include "nsbb\nsrcdlg.h"#include "nssavoir\nsgraphe.h"#include "nssavoir\nsguide.h"#include "parseur\balise.h"#include <owl\window.h>
#include "nsbb\nsattval.h"

// -----------------------------------------------------------------------------
// Impl�mentation de VectorBBItem
// -----------------------------------------------------------------------------
VectorBBItem::VectorBBItem(VectorBBItem& rv)
             :BBFilsVecteur()
{
try
{
  if (!(rv.empty()))
    for (BBiterFils i = rv.begin() ; i != rv.end() ; i++)
      push_back(new BBItem(*(*i))) ;
}
catch (...)
{
  erreur("Exception VectorBBItem copy ctor.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------// Vidange de l'array// -----------------------------------------------------------------------------
void
VectorBBItem::vider()
{
  if (empty())
    return ;

  for (BBiterFils i = begin() ; i != end() ; )
  {
    delete (*i) ;
    erase(i) ;
  }
}

VectorBBItem::~VectorBBItem()
{
	vider() ;
}

// -----------------------------------------------------------------------------
// Impl�mentation de BBFilsExclu
// -----------------------------------------------------------------------------
BBFilsExclu::BBFilsExclu()
{
}

BBFilsExclu::BBFilsExclu(const BBFilsExclu& src)
{
	aExclusion = src.aExclusion ;
}

BBFilsExclu&
BBFilsExclu::operator=(const BBFilsExclu src)
{
	if (this == &src)
  	return *this ;
    
	aExclusion = src.aExclusion ;
	return (*this) ;
}

int
BBFilsExclu::operator==(BBFilsExclu& o)
{
	if (aExclusion == o.aExclusion)
		return 1 ;
	else
		return 0 ;
}

// -----------------------------------------------------------------------------
// Impl�mentation de BBExcluArray
// -----------------------------------------------------------------------------
BBExcluArray::BBExcluArray(BBExcluArray& rv)
             :BBFilsExcluArray()
{
try
{
  if (!(rv.empty()))
    for (BBExIter i = rv.begin() ; i != rv.end() ; i++)
      push_back(new BBFilsExclu(*(*i))) ;
}
catch (...)
{
  erreur("Exception BBExcluArray copy ctor.", standardError, 0) ;
}
}


// -----------------------------------------------------------------------------
// Vidange de l'array
// -----------------------------------------------------------------------------
void
BBExcluArray::vider()
{
  if (empty())
    return;
  for (BBExIter i = begin() ; i != end() ; )
  {
    delete (*i) ;
    erase(i) ;
  }
}


BBExcluArray::~BBExcluArray()
{
	vider() ;
}


// -----------------------------------------------------------------------------
//
// Impl�mentation de BBFilsItem
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Function     : inline BBFilsItem::BBFilsItem(string loc, string Avant, string Apres)
// Arguments    : loc  		      -> Localisation de l'Item au sein de l'arbre
//                Avant, Apres  -> Pr�fixe/Suffixe � ajouter au codon de l'Item
// Description  : Constructeur par d�faut
// -----------------------------------------------------------------------------
inline
BBFilsItem::BBFilsItem(NSContexte *pCtx, BBItem* pPereItem, NSSmallBrother* pBig, string Avant, string Apres)
           :NSRoot(pCtx), pBigBoss(pBig), _pPere(pPereItem)
{
try
{
  _sNom             = string("") ;
  _sEtiquette       = string("") ;
  estActif          = false ;
  DialogueMultiple  = false ;
  FilsProlongeable  = false ;
  bCorriger         = false ;
  _pDonnees 	  	  = new BBItemData ;
  pNsMultiDialog    = 0 ;
  pCitem            = 0 ;  _pTransfert       = new NSTransferInfo(this) ;
}
catch (...)
{
  erreur("Exception constructeur BBFilsItem.", standardError, 0) ;
}
}

BBFilsItem::~BBFilsItem(){
  VectorFils.vider() ;

	delete _pDonnees ;

  if (NULL != _pTransfert)
    delete _pTransfert ;

  // Note : on ne delete pas le pCitem  // car est d�truit par BBItem dans le delete du parseur  if (!Exclusion.aExclusion.empty())
  {
    vector<string *>::iterator i ;
    for (i = Exclusion.aExclusion.begin() ; i != Exclusion.aExclusion.end() ; )
    {
      delete (*i) ;
      Exclusion.aExclusion.erase(i) ;
    }
  }
}

// -----------------------------------------------------------------------------// Constructeur copie// -----------------------------------------------------------------------------
BBFilsItem::BBFilsItem(BBFilsItem& src)
           :NSRoot(src.pContexte)
{
try
{
  pBigBoss          = src.pBigBoss ;
  _pPere            = src._pPere ;
  FilsProlongeable  = src.FilsProlongeable ;
  pNsMultiDialog    = src.pNsMultiDialog ;
  pCitem            = src.pCitem ;  _pDonnees         = new BBItemData(*(src._pDonnees)) ;
  DialogueMultiple  = src.DialogueMultiple ;
  estActif          = src.estActif ;
  VectorFils        = src.VectorFils ;
  bCorriger         = src.bCorriger ;

	if (src._pTransfert)
		_pTransfert 		= new NSTransferInfo(this, *(src._pTransfert)) ;
	else
		_pTransfert 		= 0 ;

	_sEtiquette 			= src._sEtiquette ;
	_sNom             = src._sNom ;
}
catch (...)
{
  erreur("Exception constructeur copie BBFilsItem.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
inline
BBFilsItem& BBFilsItem::operator=(BBFilsItem src)
{
	if (this == &src)
  	return *this ;

try
{
  pBigBoss          = src.pBigBoss ;
  _pPere		        = src._pPere ;
  estActif          = src.estActif ;
  DialogueMultiple  = src.DialogueMultiple ;
  bCorriger		      = src.bCorriger ;
  // R�allocation de pFils et pTransfert
  pNsMultiDialog    = src.pNsMultiDialog ;
  pCitem            = src.pCitem ;

 	if (_pTransfert)
		delete _pTransfert ;
	if (src._pTransfert)
		_pTransfert = new NSTransferInfo(this, *(src._pTransfert)) ;
  else
  	_pTransfert = 0 ;

  _pDonnees   = new BBItemData(*(src._pDonnees)) ;
	_sNom       = src._sNom ;
	_sEtiquette = src._sEtiquette ;

	return (*this) ;
}
catch (...)
{
  erreur("Exception BBFilsItem::operator=.", standardError, 0) ;
  return (*this) ;
}
}

// -----------------------------------------------------------------------------// Op�rateur de comparaison// -----------------------------------------------------------------------------
int
BBFilsItem::operator==(BBFilsItem& o)
{
	if ((_sNom                  == o._sNom) 			      &&
      (_sEtiquette 	          == o._sEtiquette) 		  &&
      (VectorFils 	          == o.VectorFils)		    &&
      (_pPere 			          == o._pPere) 			      &&
      (_pDonnees		          == o._pDonnees)  	 	    &&
      (DialogueMultiple       == o.DialogueMultiple)  &&
      (pNsMultiDialog	        == o.pNsMultiDialog)    &&
      (pCitem                 == o.pCitem)            &&      (estActif   	          == o.estActif)          &&
      (bCorriger		          == o.bCorriger)		      &&
      (_pTransfert 	          == o._pTransfert))
		return 1 ;
	else
		return 0 ;
}


// -----------------------------------------------------------------------------
// Function     : void BBFilsItem::creerFils()
// Description  : Pour chaque fils "actif" (qui correspond � une �tiquette),
//					      on cherche la fiche Paradox correspondante et, si elle
//					      int�resse la m�me fen�tre, on cr�e une BBItem
// -----------------------------------------------------------------------------
void
BBFilsItem::creerFils(int indexFils)
{
try
{
  NSVectFatheredPatPathoArray* pVect    = getPatPatho() ;
  NSVectFatheredPatPathoArray* pVectTmp = getTmpPatho() ;

  if (pVect->empty())
    pVect->push_back(new NSFatheredPatPathoArray(pContexte, 0, new NSPatPathoArray(pContexte))) ; // mettre une patpatho vide
  if (pVectTmp->empty())
    pVectTmp->push_back(new NSFatheredPatPathoArray(pContexte, 0, new NSPatPathoArray(pContexte))) ; // mettre une patpatho vide

  // ici deux cas :
  // soit indexFils == -1 et on cr�e un fils pour chaque entr�e de pVect
  // soit indexFils >= 0 et on ne cr�e que le fils correspondant � l'entr�e n�indexFils de pVect
  // Important : on passe au nouveau BBItem un pointeur sur une patpatho du pTransfert, donc :
  // - chaque fils sera ult�rieurement cr�� et activ� par la fonction BBItem::developper, et :
  // - pour chaque fils, le OkFermerDialogue remettra directement � jour ce pointeur dans le pTransfert initial
  //   (en fait, on indique au d�part la patpatho � mettre � jour par le dialogue associ� au BBItem)

  int index = 0 ;
  FatheredPatPathoIterVect iJ    = pVect->begin() ;
  FatheredPatPathoIterVect iJTmp = pVectTmp->begin() ;
  for ( ; iJ != pVect->end() ; iJ++, iJTmp++, index++)
  {
    if ((indexFils < 0) || (index == indexFils))
    {
      if (iJTmp == pVectTmp->end())
      {
        pVectTmp->push_back(new NSFatheredPatPathoArray(pContexte, 0, new NSPatPathoArray(pContexte))) ; // mettre une patpatho vide
        iJTmp = pVectTmp->end() ;
        iJTmp-- ;
      }
      VectorFils.push_back(new BBItem(pContexte, this, pBigBoss, (*iJ)->getPatPatho(), (*iJTmp)->getPatPatho())) ; // cr�er un nouveau BBItem
    }
  }

  if (false == VectorFils.empty())
    for (BBiterFils i = VectorFils.begin() ; i != VectorFils.end() ; i++)
      *((*i)->pDonnees) = *(_pDonnees) ;
}
catch (...)
{
  erreur("Exception BBFilsItem::creerFils.", standardError, 0) ;
}
}

boolBBFilsItem::actifVide()
{
  return _pDonnees->actifVide() ;
}

void
BBFilsItem::Desactive()
{
  _pTransfert->Desactive() ;
  DesactiveFils() ;

  if (NULL != _pPere)
    _pPere->DesactivePereFictif(this) ;

  // si this est champ edit non actif, et s'il est fils unique de son p�re,
  // alors d�sactiver ce p�re s'il est non actif vide
  /*
  if ((!Actif()) && (pPere->aBBItemFils.size() == 1) && (!pPere->actifVide()))
    pPere->pBBFilsPere->pTransfert->Desactive() ;
  */
}

void
BBFilsItem::Active()
{
  _pTransfert->Active() ;
  if (NULL != _pPere)
    _pPere->ActivePere(this) ;
}

// -----------------------------------------------------------------------------// Function: void BBFilsItem::CreerFilsManuel(...)// le BBfilsItem se cr�e en tant que BBitem
// -----------------------------------------------------------------------------
void
BBFilsItem::CreerFilsManuel(NSControle* pControle, NSControle* pControlePetitFrere/*, BBItemData* pDonnees*/)
{
try
{
  BBItem* pBBItem ;
  //il n' a pas de BBItem fils
	if (VectorFils.empty())
  {
    NSVectFatheredPatPathoArray* pVect    = getPatPatho() ;
    NSVectFatheredPatPathoArray* pVectTmp = getTmpPatho() ;
    if (pVect->empty())
      pVect->push_back(new NSFatheredPatPathoArray(pContexte, 0, new NSPatPathoArray(pContexte))) ; // mettre une patpatho vide
    if (pVectTmp->empty())
      pVectTmp->push_back(new NSFatheredPatPathoArray(pContexte, 0, new NSPatPathoArray(pContexte))) ; // mettre une patpatho vide

    pBBItem = new BBItem(pContexte, this, pBigBoss, (*(pVect->begin()))->getPatPatho(), (*(pVectTmp->begin()))->getPatPatho()) ;
    pBBItem->sLocalisation = getLocalisation() ;
    pBBItem->iProfondeur = _pPere->iProfondeur + 1 ;
    VectorFils.push_back(pBBItem) ; // cr�er un nouveau BBItem
  }
  else
    pBBItem = *(VectorFils.begin()) ;

  pBBItem->CreerFilsManuel(pControle, pControlePetitFrere) ;
}
catch (...)
{
  erreur("Exception BBFilsItem::CreerFilsManuel.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
void
BBFilsItem::DestructionManuelle(Message* pMessage)
{
  if (!(VectorFils.empty()))
    for (BBiterFils i = VectorFils.begin() ; i != VectorFils.end() ; i++)
      (*i)->DestructionManuelle(pMessage) ;

  tuerFils() ;
  _pTransfert->activeControle(BF_DELETE, pMessage) ;
}

// -----------------------------------------------------------------------------// vider VectorFils// -----------------------------------------------------------------------------
void
BBFilsItem::tuerFils()
{
  VectorFils.vider() ;
}

// -----------------------------------------------------------------------------
// lancer les bo�tes de dialogue multiples
// -----------------------------------------------------------------------------
void
BBFilsItem::lancerMultiDialogue()
{
try
{
  if (pNsMultiDialog)
    return ;
	pNsMultiDialog = 0 ;  if (_pTransfert && _pTransfert->pControle && (_pTransfert->pControle->getGestionMultiple()))    return ;  if (VectorFils.empty())  	return ;	BBItem* PremierBBitem = *(VectorFils.begin());
  if (!(PremierBBitem->uniciteLesion()))
  {
  	pNsMultiDialog = new NsMultiDialog(PremierBBitem->donneFenetre(), "MULTI", this, pNSDLLModule) ;
    DialogueMultiple = true ;
  }
}
catch (...)
{
  erreur("Exception BBFilsItem::lancerMultiDialogue.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Retourne vrai si le BBFilsItem ouvre un dialogue (ou arch�type)
// -----------------------------------------------------------------------------
bool
BBFilsItem::ouvreDialog(){  return ((_pDonnees->ouvreDlg()) || (_pDonnees->ouvreArchetype())) ;}intBBFilsItem::Actif(){  return _pTransfert->iActif ;}NSVectFatheredPatPathoArray*BBFilsItem::getPatPatho(){  return _pTransfert->getPatPatho() ;}NSVectFatheredPatPathoArray*BBFilsItem::getTmpPatho(){  return _pTransfert->getTmpPatho() ;}Message*BBFilsItem::getItemTransfertMsg(){  return _pTransfert->pTransfertMessage ;}
// -----------------------------------------------------------------------------// -----------------------------------------------------------------------------voidBBFilsItem::creerNouveauFils()
{
try
{
  NSPatPathoArray* pPath = new NSPatPathoArray(pContexte) ; //cr�er une patpatho vide
  getPatPatho()->push_back(new NSFatheredPatPathoArray(pContexte, 0, pPath)) ;
  NSPatPathoArray* pPathTmp = new NSPatPathoArray(pContexte) ; //cr�er une patpatho vide
  getTmpPatho()->push_back(new NSFatheredPatPathoArray(pContexte, 0, pPathTmp)) ;

  BBItem* pNewFils = new BBItem(pContexte, this, pBigBoss, pPath, pPathTmp) ; //cr�er un nouveau BBItem
  pNewFils->iProfondeur = _pPere->iProfondeur + 1 ;
  VectorFils.push_back(pNewFils) ;

  *(pNewFils->pDonnees) = *(_pDonnees) ;

  _pPere->donneGenetique(pNewFils, _sEtiquette) ;

  // On demande au BBItem de se cr�er (et de cr�er ses fils qui correspondent � la m�me bo�te de dialogue)
  int i = pNewFils->creer() ;
  if (i != 0)
    return ;

  // On demande au BBItem de s'activer
  /* int iRetActiv = */ pNewFils->activer() ;

  if (pNewFils->iProfondeur < pBigBoss->iSeuilSauve)
    pBigBoss->sauvegarde() ;
}
catch (...)
{
  erreur("Exception BBFilsItem::creerNouveauFils.", standardError, 0) ;
}
}

bool
BBFilsItem::estPlusZero()
{
  if (NULL == _pDonnees)
    return false ;

  return (_pDonnees->getLevelShift() == string("+00+00")) ;
}
// -----------------------------------------------------------------------------// Fonction appel�e par le BBItem p�re qui pr�vient que la boite de dialogue// demande l'autorisation de se fermer.
// Demande � la structure de transfert de se mettre � jour.
// Retransmet la demande aux �ventuels BBItem de la branche qui concernent
// la m�me boite de dialogue.
// -----------------------------------------------------------------------------
// Arguments  : bDetacheControle : autorise � d�tacher le controle
// Returns    : true si la boite de dialogue a l'autorisation de se fermer, false sinon
// -----------------------------------------------------------------------------
bool
BBFilsItem::okFermerDialogue(bool rapatrier, bool bDetacheControle)
{
try
{
	// Demande � l'�l�ment de transfert de se mettre � jour, uniquement si
	// l'�l�ment n'est pas prolongeable
  if (FilsProlongeable == false)
	{
    if (!_pTransfert->Transfer(tdGetData))
      return false ;

    // Utilis� pour le transfert de document type consultation pour la mise � jour de la base des textes libres
    if (!_pTransfert->TransferFinal(tdGetData))
      return false ;
	}

	// Lance la fonction r�cursivement sur l'�ventuel BBItem fils
  if (false == VectorFils.empty())
  {
    for (BBiterFils i = VectorFils.begin() ; i != VectorFils.end() ; i++)
    {
      if (*i)
      {
        bool bFerme = (*i)->okFermerDialogue(rapatrier, bDetacheControle) ;
        if (!(PatPtahovide()))
          Active() ;
        if (!bFerme)
        {
          if (bDetacheControle)
            _pTransfert->detacheControle() ;
          return bFerme ;
        }
      }
    }
    // Ajout 23/04/2004 PA
    if (PatPtahovide() && !(actifVide()))
      Desactive() ;
  }

	// D�tache l'�l�ment de transfert du contr�le Windows associ�
  // Il ne faut pas le faire avant l'appel � okFermerDialogue des fils,
  // sinon l'�l�ment est consid�r� comme un pere fictif (et il risque
  // d'�tre d�sactiv� s'il est dans le m�me dialogue que ses fils et
  // que ses fils sont vides - m�me s'il est lui m�me actif vide)
  // --
  // We disconnect the transfert element from the GUI control
  // We must do it after that okFermerDialogue has been called on its sons
  // elsewhere this element will be considered as a fake father (pere fictif)
  // and there is a risk it can be switched off if it is in the same dialog
  // box as its sons and the sons are off - even if this element is "on even
  // if empty" (actif vide)
  if (bDetacheControle)
    _pTransfert->detacheControle() ;

	return true ;
}
catch (...)
{
  erreur("Exception BBFilsItem::okFermerDialogue.", standardError, 0) ;
  return false ;
}
}

void
BBFilsItem::detacheControle()
{
  // Lance la fonction r�cursivement sur l'�ventuel BBItem fils
  if (false == VectorFils.empty())
    for (BBiterFils i = VectorFils.begin() ; i != VectorFils.end() ; i++)
      if (*i)
        (*i)->detacheControle() ;

  _pTransfert->detacheControle() ;
}

void
BBFilsItem::rapatrieTmpPpt(NSPatPathoArray *pTempPatPatho, size_t iLevel)
{
try
{
	// Demande � l'�l�ment de transfert de se mettre � jour, uniquement si
	// l'�l�ment n'est pas prolongeable
  if (false == FilsProlongeable)
	{
    if ((NULL == _pTransfert) || (NULL == _pTransfert->TempTransfer()))
      return ;
	}

	// Lance la fonction r�cursivement sur l'�ventuel BBItem fils
  if (false == VectorFils.empty())
    for (BBiterFils i = VectorFils.begin() ; i != VectorFils.end() ; i++)
      if (NULL != *i)
        (*i)->rapatrieTmpPpt(pTempPatPatho, iLevel) ;

	return ;
}
catch (...)
{
  erreur("Exception BBFilsItem::rapatrieTmpPpt.", standardError, 0) ;
  return ;
}
}

// -----------------------------------------------------------------------------// Function     : int BBFilsItem::Initialiser(string sCodon, int iActif)// Description  : Initialise les donn�es du niveau, initialise l'�ventuel BBItem qui y est rattach�.
// Arguments    : sCodon  -> Codon � ce niveau
//        			  iActif  -> Mode Actif/Non actif � ce niveau
// Returns      : 0 si tout a bien fonctionn�, 1 si on a eu un probl�me
// -----------------------------------------------------------------------------
int
BBFilsItem::Initialiser(string sCodon, int iActif)
{
try
{
	// Initialisation des variables locales
	_pTransfert->iActif = iActif ;

	// Initialisation de l'�ventuel BBItem rattach�
  if (VectorFils.empty())
		return 0 ;

	for (BBiterFils i = VectorFils.begin() ; i != VectorFils.end() ; i++)
	{
  	if (*i)
    	return (*i)->Initialiser() ;
    else
    	return 0 ;
  }

  return 0 ;
}
catch (...)
{
  erreur("Exception BBFilsItem::Initialiser.", standardError, 0) ;
  return 0 ;
}
}

// -----------------------------------------------------------------------------// Transf�rer la valeur sVal et activer le contr�le pilot� par this// -----------------------------------------------------------------------------
void
BBFilsItem::ActiveControle(string sVal)
{
	if ((NULL == _pTransfert) || (NULL == getItemTransfertMsg()))
		return ;

  if (string("�CL") == string(_sEtiquette, 0, 3))
  	getItemTransfertMsg()->SetTexteLibre(sVal) ;
  else
  	getItemTransfertMsg()->SetComplement(sVal) ;

  // pTransfert->pTmpTransfertMessage->SetComplement(sVal) ;
  _pTransfert->activeControle(BF_CHECKED, getItemTransfertMsg()) ;
  _pTransfert->Transfer(tdGetData) ;
  _pTransfert->pBBFilsItem->Active() ;
}

// -----------------------------------------------------------------------------
//activer le bouton pilot� par this
// -----------------------------------------------------------------------------
void
BBFilsItem::ActiveBouton(string sEtiquette)
{
  NSButton* pNSButton = static_cast<NSButton *>(_pTransfert->pControle->getControle()) ;
  if (NULL != pNSButton)
    pNSButton->BNClicked() ;
}

// -----------------------------------------------------------------------------
// Transf�rer la valeur sVal et activer le contr�le pilot� par this
// -----------------------------------------------------------------------------
void
BBFilsItem::DesactiveControle()
{
  if (NULL == _pTransfert)
    return ;

  if (NULL != getItemTransfertMsg())
  {
    getItemTransfertMsg()->SetComplement("") ;
    // if (pTransfert->pTmpTransfertMessage)
    //    pTransfert->pTmpTransfertMessage->SetComplement("") ;
    _pTransfert->activeControle(BF_UNCHECKED, getItemTransfertMsg()) ;
  }
  _pTransfert->Transfer(tdGetData) ;
  _pTransfert->pBBFilsItem->Desactive() ;
}

// -----------------------------------------------------------------------------// voir si le vecteur des patpatho est vide ou non dans les cas des dialogues uniques// et les dialogues multiples
// -----------------------------------------------------------------------------
bool
BBFilsItem::PatPtahovide()
{
  if (DialogueMultiple)
    return (getPatPatho()->MultiEstVide()) ;
  return getPatPatho()->estVide() ;
}

// -----------------------------------------------------------------------------
// voir si le vecteur des patpatho est vide ou non dans les cas des dialogues uniques
// et les dialogues multiples
// -----------------------------------------------------------------------------
bool
BBFilsItem::TmpPptvide()
{
  if (DialogueMultiple)
    return (getTmpPatho()->MultiEstVide()) ;
  return getTmpPatho()->estVide() ;
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
void
BBFilsItem::DesactiveFils()
{
  if (VectorFils.empty())
    return ;

  // Premier cas : il ne s'agit pas d'un Archetype
  if (NULL == pCitem)
  {
    // Modif RS 03/11/03 : on regarde � quelle fenetre est li�
    // le BBItem p�re et on v�rifie si les BBItem fils appartiennent
    // � la m�me fen�tre.
    TWindow* pWindowPere = (TWindow *) _pPere->getDialog() ;
    if (NULL == pWindowPere)
      pWindowPere = _pPere->donneFenetre() ;

    if ((NULL == pWindowPere) || (!pWindowPere->IsWindow()))
      return ;

    BBiterFils iter ;

    /*
    // ancienne m�thode
    for (iter = VectorFils.begin() ; iter != VectorFils.end() ; iter++)
      if ( strcmp(pPere->szNomDlg, (*iter)->szNomDlg) == 0 )
        (*iter)->DesactiveFils() ;
    */

    for (iter = VectorFils.begin() ; iter != VectorFils.end() ; iter++)
    {
      // Si le BBItem est ouvreur de boite de dialogue,
      // on ne d�sactive pas ses fils.
      // Sinon, on v�rifie � chaque niveau si les fils sont dans
      // la m�me fen�tre que leur pBBFIlsItem p�re.
      if ((*iter)->lienDialogue())
      {
        TWindow* pWindowFils = (TWindow *) (*iter)->getDialog() ;
        if (!pWindowFils)
          pWindowFils = (*iter)->donneFenetre() ;

        if ((pWindowFils) && (pWindowFils == pWindowPere))
          (*iter)->DesactiveFils() ;
      }
    }
  }
  else
  {
    // Dans un Arch�type
    BBiterFils iter ;
    for (iter = VectorFils.begin() ; iter != VectorFils.end() ; iter++)
    {
      // Pour les Archetypes, lienDialogue signifie une ouverture de fen�tre
      // if (!((*iter)->lienDialogue()))
      if (_pPere->dansMemeDialogue(*iter))
        (*iter)->DesactiveFils() ;
    }
  }
}

// -----------------------------------------------------------------------------// Efface toutes les donn�es pour permettre un redispatche// -----------------------------------------------------------------------------
void
BBFilsItem::RemetAZero()
{
  if (VectorFils.empty())
    return ;

  BBiterFils iter ;
  for (iter = VectorFils.begin() ; iter != VectorFils.end() ; iter++)
    if (_pPere->dansMemeDialogue(*iter))
      (*iter)->RemetAZero() ;
}

void
BBFilsItem::Redeveloppe()
{
  if (pNsMultiDialog)
    pNsMultiDialog->CmCancel() ;
  else
  {
    if ((false == VectorFils.empty()) && ((*(VectorFils.begin()))->getDialog()))
      (*(VectorFils.begin()))->getDialog()->Destroy() ;
  }

  _pPere->developper(this) ;
}

void
BBFilsItem::Redispatche()
{
  BBiterFils iter ;

  for (iter = VectorFils.begin() ; iter != VectorFils.end() ; iter++)
    if (_pPere->dansMemeDialogue(*iter))
      (*iter)->Redispatche() ;
}

// -----------------------------------------------------------------------------
// mettre � jour la patptho en cours
// pere : it�rateur sur l �l�ment patpatho (dans PatpathoActuelle)
// correspondant au BBItem pere de ce BBFilsItem
// -----------------------------------------------------------------------------
void
BBFilsItem::RemplirPatpatho(NSPatPathoArray* /*pPatpathoActuelle*/, PatPathoIter /*pere*/)
{
}

// -----------------------------------------------------------------------------
// In order that miscellanous Fils Guides don't get stuck to dialog controls
// that should be leaves, we have to destroy all BBItems that don't open a
// dialog or have sons connected to controls.
// If the control is a TreeView, it can do what it wants.
// -----------------------------------------------------------------------------
void
BBFilsItem::cutBadDialogBranches(NSDialog* pDlg)
{
	if (NULL == pDlg)
		return ;

	// Only leaves must cut bad branches. If we are not on an Item that is
  // connected to a control, we just iterate
  //
	if ((NULL == _pTransfert) || (NULL == _pTransfert->pControle))
  {
  	if (false == VectorFils.empty())
  		for (BBiterFils it = VectorFils.begin() ; it != VectorFils.end() ; it++)
    		(*it)->cutBadDialogBranches(pDlg) ;

    return ;
  }
  //
  //
  NSDialog* pCrlDlg = _pTransfert->pControle->getNSDialog() ;
  if (pCrlDlg != pDlg)
		return ;

  // If we are there, we are supposed to be connected to a control
  //
  // TreeWindows can do what they want
  //
	WNDTYPE iCtrlType = _pTransfert->pControle->getType() ;
  if (isTreeWindow == iCtrlType)
		return ;

	// If it is a leaf and it is "expandable", check that the Fil Guide is a
  // "Windows opening" one
  //
  if (true == VectorFils.empty())
  {
  	if (true == FilsProlongeable)
    {
    	// Sometimes, the Fil Guide that is connected to the control doesn't
      // open a dialog because its sons do it. In order not to cut this
      // good branch, we have no other way than to test if its Dialog Name is
      // __IDEM ; meaning that is has been built to get connected to a dialog
      //
    	if ((NULL == _pDonnees) ||
               ((false == _pDonnees->ouvreDlg()) &&
                (string("__CROS") != _pDonnees->getDialogName())))
      {
      	FilsProlongeable = false ;
        if ((NULL != _pDonnees))
        	_pDonnees->metAZero() ;
      }
    }
    return ;
  }

  // Other controls must kill their sons if they have not themselves a parent
  // connected to the same dialog
  //
  for (BBiterFils it = VectorFils.begin() ; it != VectorFils.end() ; )
  {
  	if (false == (*it)->isBadDialogBranch(pDlg))
    {
    	(*it)->cutBadDialogBranches(pDlg) ;
      it++ ;
    }
    else
    {
    	Message Msg ;
    	(*it)->DestructionManuelle(&Msg) ;
      delete *it ;
      VectorFils.erase(it) ;
    }
  }
}

bool
BBFilsItem::isBadDialogBranch(NSDialog* pDlg)
{
	if (NULL == pDlg)
		return false ;

	// No sons : means it is either connected to the dialog, or a bad branch
	//
	if (true == VectorFils.empty())
	{
  	if ((NULL == _pTransfert) || (NULL == _pTransfert->pControle))
			return true ;
    else
    	return false ;
  }

  // If there are sons, just check that a least one is not a bad branch
  //
  for (BBiterFils it = VectorFils.begin() ; it != VectorFils.end() ; it++)
  	if (false == (*it)->isBadDialogBranch(pDlg))
    	return false ;

	return true ;
}

// -----------------------------------------------------------------------------
// instancier la patpatho active d'un BBFilsItem qui correspondant au pPPTEnCours
// du BBitem (�gal � ce BBFilsItem)
// pere : it�rateur sur l �l�ment patpatho (dans PatpathoActuelle)
// correspondant au BBItem pere de ce BBFilsItem
// -----------------------------------------------------------------------------
NSPatPathoArray*
BBFilsItem::getPatpathoActive(NSPatPathoArray* pPatpathoActuelle, PatPathoIter pere)
{
try
{
	if ((NULL == pPatpathoActuelle) || (pPatpathoActuelle->empty()) || (NULL == pere))
    return NULL ;

  int LignePere 	= (*pere)->getLigne() ;
  int ColonnePere = (*pere)->getColonne() ;

  PatPathoIter fils = pPatpathoActuelle->begin() ;
  fils = pere ;

  if (pPatpathoActuelle->end() == fils)
    return NULL ;
  fils++ ;

  bool PatPathoNonVide = false ; // savoir s'il y a des donn�es � mettre dans la la patpatho du fils ou non
  bool bContinuer = true ;
  Message message("") ;
  NSPatPathoArray* pPatpathoFils = new NSPatPathoArray(pContexte) ;

  while ((bContinuer) && (fils != pPatpathoActuelle->end()))
	{
    int LigneFils 	= (*fils)->getLigne() ;
    int ColonneFils = (*fils)->getColonne() ;

		if ((ColonneFils > ColonnePere) && (LigneFils > LignePere))
    {
      message.SetNoeud(     (*fils)->getNodeID()) ;
      message.SetLexique(   (*fils)->getLexique()) ;
      message.SetUnit(      (*fils)->getUnit()) ;
      message.SetCertitude( (*fils)->getCertitude()) ;
      message.SetInteret(   (*fils)->getInteret()) ;
      message.SetComplement((*fils)->getComplement()) ;
      message.SetPluriel(   (*fils)->getPluriel()) ;
      message.SetVisible(   (*fils)->getVisible()) ;
      message.SetType(      (*fils)->getType()) ;
      message.SetTexteLibre((*fils)->getTexteLibre()) ;
      message.SetNodeRight( (*fils)->getNodeRight()) ;

      NSPatPathoInfo* pPatPatho = new NSPatPathoInfo() ;
      pPatPatho->setNodeID(    message.GetNoeud()) ;
      pPatPatho->setLexique(   message.GetLexique()) ;
      pPatPatho->setUnit(      message.GetUnit()) ;
      pPatPatho->setComplement(message.GetComplement()) ;
      pPatPatho->setCertitude( message.GetCertitude()) ;
      pPatPatho->setInteret(   message.GetInteret()) ;
      pPatPatho->setPluriel(   message.GetPluriel()) ;
      pPatPatho->setVisible(   message.GetVisible()) ;
      pPatPatho->setNodeRight( message.GetNodeRight()) ;
      pPatPatho->setTexteLibre(message.GetTexteLibre()) ;
      pPatPatho->setColonne(ColonneFils - (ColonnePere + 1)) ;
      pPatPatho->setLigne(LigneFils - (LignePere + 1)) ;

      pPatpathoFils->push_back(pPatPatho) ;
      PatPathoNonVide = true ;
    }
    else
      bContinuer = false ;
    fils++ ;
  }

  if (PatPathoNonVide)
  {
    (getPatPatho())->push_back(new NSFatheredPatPathoArray(pContexte, 0, new NSPatPathoArray(*pPatpathoFils))) ;
    return pPatpathoFils ;
  }

  delete pPatpathoFils ;
  return NULL ;
}
catch (...)
{
  erreur("Exception BBFilsItem::getPatpathoActive.", standardError, 0) ;
  return NULL ;
}
}

string
BBFilsItem::getLocalisation()
{
	string sEtiq ;
	NSSuper* pSuper = pContexte->getSuperviseur() ;
  pSuper->getDico()->donneCodeSens(&_sEtiquette, &sEtiq) ;

  return _pPere->sLocalisation + string(1, cheminSeparationMARK) + sEtiq ;
}

// -----------------------------------------------------------------------------
//
// Impl�mentation de BBFilsArray
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
BBFilsArray::BBFilsArray(BBFilsArray& rv)
            :BBFilsItemArray()
{
try
{
  gestionVecteur = rv.gestionVecteur ;
  if (!(rv.empty()))
    for (BBiter i = rv.begin() ; i != rv.end() ; i++)
      push_back(new BBFilsItem(*(*i))) ;
}
catch (...)
{
  erreur("Exception BBFilsArray ctor.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------// Destructeur// -----------------------------------------------------------------------------
BBFilsArray::~BBFilsArray()
{
	vider() ;
}

// -----------------------------------------------------------------------------// Renvoie un pointeur sur le indice i�me �l�ment de l'array// Renvoie 0 si l'�l�ment n'existe pas
// -----------------------------------------------------------------------------
BBFilsItem*
BBFilsArray::donneNieme(int indice)
{
  if (indice < 0)
    return NULL ;

  if (gestionVecteur)
  {
    if (size_t(indice) < size())
      return (*this)[indice] ;
  }
  else
  {
    if (empty())
      return NULL ;
    BBiter iter ;
    int    i ;
    for (iter = begin(), i = 0 ; (iter != end()) && (i < indice) ; iter++, i++)      ;    if (iter != end())
      return (*iter) ;
  }
  return NULL ;
}

// -----------------------------------------------------------------------------
// Renvoie un pointeur sur l'�l�ment de l'array dont l'�tiquette correspond
// Renvoie 0 si l'�l�ment n'existe pas
// -----------------------------------------------------------------------------
BBFilsItem *
BBFilsArray::donneEtiqu(string* psEtiquette)
{
  if ((empty()) || (!psEtiquette))
    return 0 ;

  BBiter Iter ;
  for (Iter = begin() ; (Iter != end()) && ((*Iter)->getItemLabel() != *psEtiquette) ; Iter++)
    ;

  if (Iter != end())
    return (*Iter) ;

  return 0 ;
}

// -----------------------------------------------------------------------------
// Vidange de l'array
// -----------------------------------------------------------------------------
void
BBFilsArray::vider()
{
  if (empty())
    return ;

	for (BBiter i = begin() ; i != end() ; )
  {
    delete (*i) ;
    erase(i) ;
  }
}

// -----------------------------------------------------------------------------
//
// Impl�mentation de BBItem
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Constructeur � partir d'un BBItem p�re
// -----------------------------------------------------------------------------
BBItem::BBItem(NSContexte *pCtx, BBFilsItem* pere, NSSmallBrother* pBig, NSPatPathoArray* pPPTEnCoursActif, NSPatPathoArray* pPPTEnCoursTMP)
       :NSRoot(pCtx), pBBFilsPere(pere), pBigBoss(pBig), KsInterface(-1)
{
try
{
  pPatPatho	  	        = 0 ;
  sLocalisation 	      = "" ;
  pDonnees 	  	        = new BBItemData ;
  pNSFonction	  	      = 0 ;
  _pNSDialog 	          = 0 ;
  bModalDialog          = true ;    // boite modale par d�faut
  pParseur              = 0 ;  bCreateParseur        = true ;  _pView                = 0 ;  bCacher			          = false ;   // cacher la NSDialog
  _sNomDlg              = string("") ;
  sIdArchetype          = "" ;
  bActif		            = false ;
  ID				            = 0 ;
  iFilsActif	          = 0 ;
  pPPTEnCours 	        = pPPTEnCoursActif ;
  // pTempPPT              = pPPTEnCoursTMP ;
  pPPTMerge             = 0 ;
  bConclusion           = false ;
  sPositionConclusion   = "" ;
  ConclusionAutomatique = false ;
  iProfondeur           = 0 ;
  iStatusDlg            = NSDLGSTATUS_NORMAL ;

#ifdef __OB1__
	// The ability to be initialised by BBK is inherited from father at construction
  //
	if (pere && pere->getItemFather())
		KsInterface.setInitFromBbk(pere->getItemFather()->KsInterface.getInitFromBbk()) ;
#endif
}
catch (...)
{
  erreur("Exception BBItem ctor 1.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Constructeur par d�faut
// -----------------------------------------------------------------------------
BBItem::BBItem(NSContexte *pCtx, NSSmallBrother* pBig, bool Actif, int Id)
       :NSRoot(pCtx), pBigBoss(pBig), bActif(Actif), ID(Id), KsInterface(-1)
{
try
{
  pPatPatho	            = 0 ;
  sLocalisation         = "" ;
  pDonnees		          = new BBItemData ;
  pBBFilsPere	          = 0 ;
  bCacher			          = false ;                     // cacher la NSDialog
  _pNSDialog	          = 0 ;
  bModalDialog          = true ;                      // boite modale par d�faut
  pParseur              = 0 ;  bCreateParseur        = true ;  _pView                = 0 ;  _sNomDlg              = string("") ;
  sIdArchetype          = "" ;
  pNSFonction	          = 0 ;
  iFilsActif	          = 0 ;
  pPPTEnCours           = pBigBoss->getPatPatho() ;   //  NSPatPathoArray*
  // pTempPPT              = pBigBoss->getTmpPatho() ;
  pPPTMerge             = 0 ;
  bConclusion           = false ;
  sPositionConclusion   = "" ;
  ConclusionAutomatique = false ;
  iProfondeur           = 0 ;
  iStatusDlg            = NSDLGSTATUS_NORMAL ;
}
catch (...)
{
  erreur("Exception BBItem ctor 2.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
BBItem::BBItem(BBItem& src)
       :NSRoot(src.pContexte), bActif(src.bActif), ID(src.ID), KsInterface(src.KsInterface)
{
try
{
	pBigBoss 		          = src.pBigBoss ;

  pPatPatho	  	        = src.pPatPatho ;
  sLocalisation 	      = src.sLocalisation ;
  bCacher			          = src.bCacher ; //cacher la NSDialog
  pDonnees		          = new BBItemData(*(src.pDonnees)) ;
  pBBFilsPere		        = src.pBBFilsPere ;
  aBBItemFils 	        = src.aBBItemFils ;
  if (src.pParseur)
    pParseur            = new nsarcParseur(*(src.pParseur)) ;
  else
    pParseur            = 0 ;
  bCreateParseur        = src.bCreateParseur ;
  _pView                = src._pView ;
  _pNSDialog		        = src._pNSDialog ;
  bModalDialog          = src.bModalDialog ;
  _sNomDlg              = src._sNomDlg ;
  sIdArchetype          = src.sIdArchetype ;

  pNSFonction		        = src.pNSFonction ;
  iFilsActif		        = src.iFilsActif ;

  pPPTEnCours	  	      = src.pPPTEnCours ;
  // pTempPPT		          = src.pTempPPT ;
  pPPTMerge             = src.pPPTMerge ;
  bConclusion           = src.bConclusion ;
  sPositionConclusion   = src.sPositionConclusion ;
  ConclusionAutomatique = src.ConclusionAutomatique ;
  iProfondeur           = src.iProfondeur ;
  iStatusDlg            = src.iStatusDlg ;
}
catch (...)
{
  erreur("Exception BBItem copy ctor.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------// Destructeur// -----------------------------------------------------------------------------
BBItem::~BBItem()
{
  aBBItemFils.vider() ;

  if(pDonnees)
		delete pDonnees ;

	if (pNSFonction)
    delete pNSFonction ;

  if ((bCreateParseur) && (pParseur))
    delete pParseur ;
  // aBBItemFils.vider() ;
}

// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
inline BBItem&
BBItem::operator=(BBItem src)
{
	if (this == &src)
  	return *this ;

try
{
	pBigBoss 		          = src.pBigBoss ;

  pPatPatho	  	        = src.pPatPatho ;
  sLocalisation 	      = src.sLocalisation ;

  if (pDonnees)
  	delete pDonnees ;
  pDonnees		          = new BBItemData(*(src.pDonnees)) ;

  pBBFilsPere		        = src.pBBFilsPere ;
  aBBItemFils 	        = src.aBBItemFils ;
  bCacher			          = src.bCacher ;

  if (pParseur)
  	delete pParseur ;
  if (src.pParseur)
    pParseur            = new nsarcParseur(*(src.pParseur)) ;
  else
    pParseur            = 0 ;

  bCreateParseur        = src.bCreateParseur ;
  _pView                = src._pView ;
  _pNSDialog		        = src._pNSDialog ;
  bModalDialog          = src.bModalDialog ;
  _sNomDlg              = src._sNomDlg ;
  sIdArchetype          = src.sIdArchetype ;
  pNSFonction		        = src.pNSFonction ;

  bActif			          = src.bActif ;
  ID			              = src.ID ;

  iFilsActif		        = src.iFilsActif;

  pPPTEnCours		        = src.pPPTEnCours;
  // pTempPPT		          = src.pTempPPT;
  pPPTMerge             = src.pPPTMerge;
  bConclusion           = src.bConclusion;
  sPositionConclusion   = src.sPositionConclusion;
  ConclusionAutomatique = src.ConclusionAutomatique;
  iProfondeur           = src.iProfondeur;
  iStatusDlg            = src.iStatusDlg;

#ifdef __OB1__
  KsInterface           = src.KsInterface ;
#endif

  return *this;
}
catch (...)
{
  erreur("Exception BBItem::operator=.", standardError, 0) ;
  return (*this) ;
}
}

// -----------------------------------------------------------------------------
// ce BBItem cr�e son fils (qui correspond au NStreeNode qui vient d'�tre
// cr�e) et l'ajoute � la liste de ses fils
// -----------------------------------------------------------------------------
void
BBItem::CreerFilsManuel(NSControle* pControle, NSControle* pControlePetitFrere)
{
try
{
  if (NULL == pControle)
    return ;

  // Cr�ation d'un BBFilsItem (qui correspond au NStreeNode qui vient d'�tre cr�e)
  BBFilsItem* pFilsItem = new BBFilsItem(pContexte, this, pBigBoss) ;
  pFilsItem->getItemTransfertData()->pControle = pControle ;
  pControle->setTransfert(pFilsItem->getItemTransfertData()) ;
  pFilsItem->setItemLabel(pControle->getIdentite()) ;

  // Ajout de l'�l�ment � l'Array de Fils
  if (NULL == pControlePetitFrere)
    aBBItemFils.push_back(pFilsItem) ;
  else
  {
  	NSTransferInfo* pTrInfo = pControlePetitFrere->getTransfert() ;
    if (NULL != pTrInfo)
    {
    	BBFilsItem* pFilsItemPetitFrere = pTrInfo->pBBFilsItem ;
    	BBiter iter = find(aBBItemFils.begin(), aBBItemFils.end(), pFilsItemPetitFrere) ;
    	//inserer pFilsItem avant pFilsItemPetitFrere
    	aBBItemFils.insert(iter, pFilsItem) ;
    }
    else
    	aBBItemFils.push_back(pFilsItem) ;
  }
}
catch (...)
{
  erreur("Exception BBItem::CreerFilsManuel.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// cr�er un BBitem de code lexique sItem, fils de this
// -----------------------------------------------------------------------------
BBItem*
BBItem::CreerBBitem(NSSmallBrother* pBigBoss, string sItem, NSPatPathoArray* pPPT, string sSens, BBItem* pBBItemCree)
{
try
{
  // On cherche le FilsItem � prolonger
  BBFilsItem* pBBFils = TrouverFilsAyantBonneEtiquette(sItem, "") ;
  if (!pBBFils)
    return 0 ;

  // On cr�e la patpatho
  NSPatPathoArray* pPath = new NSPatPathoArray(pContexte) ;
  pBBFils->getPatPatho()->push_back(new NSFatheredPatPathoArray(pContexte, 0, pPath)) ;
  if (pPPT)
    *pPath = *pPPT ;
  NSPatPathoArray* pPathTmp = new NSPatPathoArray(pContexte) ;
  pBBFils->getTmpPatho()->push_back(new NSFatheredPatPathoArray(pContexte, 0, pPathTmp)) ;

  // On cr�e le BBItem
  pBBItemCree = new BBItem(pContexte, pBBFils, pBigBoss, pPath, pPathTmp) ;
  pBBFils->VectorFils.push_back(pBBItemCree) ; // R�f�rence le BBItem chez son fils

  *(pBBItemCree->pDonnees) = *(pBBFils->getItemData()) ;
  pBBItemCree->_sNomDlg = string(pBBItemCree->pDonnees->nomDialogue) ;
  string sCodeSens ;
  NSSuper* pSup = pContexte->getSuperviseur() ;
  pSup->getDico()->donneCodeSens(&sItem, &sCodeSens) ;
  pBBItemCree->sLocalisation  =  sSens + "/"+ sCodeSens ;
  pBBItemCree->iProfondeur = this->iProfondeur + 1 ;
  if (string("") != pBBItemCree->pDonnees->getDialogFile())
    if (!pBigBoss->CreerNouveauModule(pBBItemCree->pDonnees->fichierDialogue))
      return 0 ;
  pBBItemCree->creer(false) ;
  return pBBItemCree ;
}
catch (...)
{
  erreur("Exception BBItem::CreerBBitem.", standardError, 0) ;
  return 0 ;
}
}

// -----------------------------------------------------------------------------
// Function     : int BBItem::creer(string code)
// Arguments    : Consultation -> Si Consultation = true, on ne dispatche pas la
//                patpatho car les NSTreeWindow le font elles m�me
// Description  : Demande � l'objet de se mettre en place : il cr�e des objets
//				        BBFilsItem pour chaque �tiquette, qu'il stocke dans aBBItemFils.
//					      A la fin, lance creerFils
// -----------------------------------------------------------------------------
int
BBItem::creer(bool Consultation)
{
try
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	int         i ;
	BBFilsItem* pFilsItem ;
  string      sFutureLocalisation, sCodeSens ;

	// Si l'�l�ment est li� � une fonction, on la cr�e
	if (lienFonction())
		pNSFonction = new NSBBFonction(pContexte, pDonnees->getFctName(), this) ;

  // Cas d'un bbitem li� � un arch�type
  if (ouvreArchetype())
  {
    string sArchetype = pDonnees->getSonsList() ;

    string sArchetypeFile = pSuper->getArcManager()->DonneFichierArchetypeParNom(NSArcManager::archetype, sArchetype) ;
    if (string("") == sArchetypeFile)
    {
      string sErrorMsg = pSuper->getText("archetypesManagement", "cannotFindThisArchetypeFile") ;
      sErrorMsg += string(" ") + sArchetype ;
      erreur(sErrorMsg.c_str(), standardError, 0) ;
      return 1 ;
    }

    if (NULL != pParseur)
    	delete pParseur ;

    pParseur = new nsarcParseur(pContexte) ;
    if (pParseur->open(sArchetypeFile))
    {
      // on renseigne les champs d�finissant le dialogue
      // (ces champs seront utilis�s par BBItem::activer dans creerDialogue()
      //  qui ne sera appel�e que pour le BBItem Root)
      if (NULL != pParseur->pArchetype->getDialog())
      {
        string sNomDialog = pParseur->pArchetype->getDialog()->getStringAttribute(ATTRIBUT_DIALOGUE_NOM) ;
        _sNomDlg = sNomDialog ;
        string sNomDll = pParseur->pArchetype->getDialog()->getStringAttribute(ATTRIBUT_DIALOGUE_DLL) ;
        pDonnees->setDialogFile(sNomDll) ;
        sIdArchetype = pParseur->pArchetype->getName() ;
      }
      else
      {
        if (string("") != _sNomDlg)
          _sNomDlg = string("") ;
        pDonnees->setDialogFile(string("")) ;
        sIdArchetype = pParseur->pArchetype->getName() ;
      }

      // on d�veloppe tout l'archetype � partir du BBItem root
      creerArchetype(pParseur->pArchetype->getRootItem(), Consultation) ;

      return 0 ;
    }
    return 1 ;
  }

	// Si cet �l�ment n'a pas de fils, on sort
	if ((string("") == pDonnees->getSonsList()) || (strspn(pDonnees->fils, " ") == strlen(pDonnees->fils)))
		return 0 ;

	// On passe en revue le champ Fils, en cr�ant un BBFilsItem pour chaque �tiquette  VecteurRechercheSelonCritere VecteurSelonCritere(GUIDE) ;
  for (i = 0 ; (pDonnees->fils[i] != '\0') && (pDonnees->fils[i] != ' ') ; i++)
  {
    // Cr�ation d'un BBFilsItem
    pFilsItem = new BBFilsItem(pContexte, this, pBigBoss) ;

    // Prise de l'�tiquette
    string sNewLabel = string("") ;
    for ( ; ('\0' != pDonnees->fils[i]) && (nodeSeparationMARK != pDonnees->fils[i]) ; i++)
      sNewLabel += pDonnees->fils[i] ;
    pFilsItem->setItemLabel(sNewLabel) ;

    // On fabrique le chemin indiqu� par le futur �l�ment

    // traiter le cas des textes libres � part
    if ((pFilsItem->getItemLabel() != string("#####1")) && (pFilsItem->getItemLabel() != string("#####2")))
    {
      string sFilsLabel = pFilsItem->getItemLabel() ;
      pSuper->getDico()->donneCodeSens(&sFilsLabel, &sCodeSens) ;
      VecteurSelonCritere.AjouteEtiquette(sCodeSens) ;
    }

    // Ajout de l'�l�ment � l'Array de Fils
    aBBItemFils.push_back(pFilsItem) ;

    if (('\0' == pDonnees->fils[i]) || (' ' == pDonnees->fils[i]))
      break ;
  }

  pSuper->afficheStatusMessage("Recherche des fils guides") ;  pSuper->getFilGuide()->chercheChemin(&sLocalisation, &VecteurSelonCritere, NSFilGuide::compReseau) ;

  bool trouve ;
  if (!(aBBItemFils.empty()))
	{
  	BBiter it = aBBItemFils.begin() ;
  	for ( ; it != aBBItemFils.end() ; it++)
  	{
    	// traiter le cas des textes libres � part
    	if (((*it)->getItemLabel() == string("#####1")) || ((*it)->getItemLabel() == string("#####2")))
    	{
        BBItemData* pItemData = (*it)->getItemData() ;
        if (NULL != pItemData)
        {
      	  pItemData->metAZero() ;
      	  pItemData->setSemanticPath("~****/#####") ;
      	  pItemData->setSonsList("#TLI#1") ;
      	  pItemData->setDialogName("TEXTLIB") ;
      	  pItemData->setOpenDialog(true) ;
      	  pItemData->setLevelShift("+00+00") ;
      	  pItemData->setDialogFile("NSBB") ;
      	  pItemData->setEmptyActivation(false) ;
        }
        (*it)->FilsProlongeable = true ;
    	}
    	else
    	{
        string sFilsLabel = (*it)->getItemLabel() ;
      	pSuper->getDico()->donneCodeSens(&sFilsLabel, &sCodeSens) ;
      	VecteurSelonCritere.SetData(sCodeSens, &trouve, (*it)->getItemData()) ;
      	if (trouve)
      	{
        	// si feuille

        	// cas particulier : �tiquette = #C���1 : pas de fils mais
        	// le consid�rer comme prolongeable
        	size_t pos = (*it)->getItemData()->getSonsList().find_first_not_of(string(" ")) ;
        	if (pos)
          	(*it)->FilsProlongeable = false ;
        	else
          	(*it)->FilsProlongeable = true ;
      	}
      	else
        	(*it)->FilsProlongeable = false ;
    	}
    }
  }

  // Don't do that before DispatcherPatPatho() because it can lead to
  // potential active item excluding the good ones
  // creerExclus() ;

  //M.A.J des patpatho
  if (!Consultation)
    if (pPPTEnCours)
      DispatcherPatPatho() ;

  creerExclus() ;
  creerFils() ;
  return 0 ;
}
catch (...)
{
  erreur("Exception BBItem::creer.", standardError, 0) ;
  return 1 ;
}
}
// -----------------------------------------------------------------------------// Function     : int BBItem::creerArchetype(Citem* pItem, bool Consultation)// Arguments    : pItem -> objet item � d�velopper//                Consultation -> Si Consultation = true, on ne dispatche
//                pas la patpatho car les NSTreeWindow le font elles m�me
// Description  : Demande � l'objet de se mettre en place : il cr�e des objets
//				        BBFilsItem pour chaque �tiquette, qu'il stocke dans aBBItemFils.
//                (idem creer mais avec des Citem au lieu des fils guide)
//				        A la fin, lance creerFils
// -----------------------------------------------------------------------------
// ATTENTION    : a priori on ne devrait jamais avoir Consultation = true (car
//                les Archetypes ne sont probablement jamais li�s � des
//                NSTreeWindow (?))
// -----------------------------------------------------------------------------
int
BBItem::creerArchetype(Citem* pItem, bool Consultation){try{	if (!pItem)		return 0 ;	BBFilsItem* pFilsItem ;	ValIter     ival ;	string      sCodeSens ;	bool        bChercherChemin = false ;	bool        trouve ;	//NSSuper* pSuper = pBigBoss->pContexte->getSuperviseur() ;	NSSuper* pSuper = pContexte->getSuperviseur() ;	string sMsg = "creerArchetype() : Entr�e" ;	pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;	// Si l'�l�ment Citem n'a pas de fils, on sort	if ((!(pItem->getArrayFils())) || (pItem->getArrayFils()->empty()))		return 0 ;	// Vecteur de recherche pour les fils guides suivant l'archetype	// (� partir des Citem feuilles de l'archetype)	VecteurRechercheSelonCritere VecteurSelonCritere(GUIDE) ;	// On r�cup�re les fils de premier niveau	for (ival = pItem->getArrayFils()->begin() ; ival != pItem->getArrayFils()->end() ; ival++)	{		// Item		if ((*ival)->sLabel == LABEL_ITEM)		{			// cr�ation d'un BBFilsItem du BBItem			pFilsItem = new BBFilsItem(pContexte, this, pBigBoss) ;			// Stockage du Citem dans le BBFilsItem			pFilsItem->pCitem = dynamic_cast<Citem *>((*ival)->pObject) ;			// R�cup�ration de l'�tiquette attach�e au Citem			pFilsItem->setItemLabel(pFilsItem->pCitem->getStringAttribute(ATTRIBUT_ITEM_CODE)) ;			sMsg = "creerArchetype() : Nouveau fils " + pFilsItem->getItemLabel() ;			pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;/*			string sComplement = pFilsItem->pCitem->getStringAttribute(ATTRIBUT_ITEM_COMPLEMENT) ;			if (sComplement != )*/			string sDecal = pFilsItem->pCitem->getStringAttribute(ATTRIBUT_ITEM_DECAL) ;			if (sDecal == "") // si le decalage n'est pas pr�cis�...				sDecal = string("+01+01") ;  // ... on prend la valeur par d�faut			// on donne au nouveau fils son d�calage			pFilsItem->getItemData()->setLevelShift(sDecal) ;			// Si c'est une feuille			if (pFilsItem->pCitem->getArrayFils()->empty())			{				// sauf dans le cas des textes libres				if ((pFilsItem->getItemLabel() != string("#####1")) && (pFilsItem->getItemLabel() != string("#####2")))				{
					if (pFilsItem->pCitem->getArchetype() == string(""))
          {
						// on ajoute au vecteur de recherche
            string sFilsLabel = pFilsItem->getItemLabel() ;
						pSuper->getDico()->donneCodeSens(&sFilsLabel, &sCodeSens) ;
						VecteurSelonCritere.AjouteEtiquette(sCodeSens) ;
						bChercherChemin = true ;
					}
				}
			}			// Ajout du BBFilsItem � l'array des fils			aBBItemFils.push_back(pFilsItem) ;		}
		// Contrainte
		else if ((*ival)->sLabel == LABEL_CONTRAINTE)
		{			string sExclus ;			Ccontrainte* pContrainte = dynamic_cast<Ccontrainte *>((*ival)->pObject) ;			if (pContrainte->getStringAttribute(ATTRIBUT_CONTR_TYPE) == string(VAL_ATTR_CONTR_TYPE_EXCLUS))			{				sExclus = pContrainte->getStringAttribute(ATTRIBUT_CONTR_LISTE) ;				pDonnees->setSonsRules(sExclus) ;			}		}	}	if (bChercherChemin)	{		sMsg = "creerArchetype() : Recherche des fils guides suivant archetype" ;		pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;		pSuper->afficheStatusMessage("Recherche des fils guides suivant archetype") ;		pSuper->getFilGuide()->chercheChemin(&sLocalisation, &VecteurSelonCritere, NSFilGuide::compReseau) ;
	}

	if (!(aBBItemFils.empty()))
	{
		// parcours de l'array des fils cr��s et d�tection des fils prolongeables
		// normalement chaque BBFilsItem de l'array est associ� � un Citem
		BBiter it = aBBItemFils.begin() ;

		for ( ; it != aBBItemFils.end() ; it++)		{
			// cas des feuilles
			if ((*it)->pCitem->getArrayFils()->empty())
			{
				// traiter le cas des textes libres � part
				if (((*it)->getItemLabel() == string("#####1")) || ((*it)->getItemLabel() == string("#####2")))
				{
          BBItemData* pFilsData = (*it)->getItemData() ;
          if (NULL != pFilsData)
          {
					  pFilsData->metAZero() ;
					  pFilsData->setSemanticPath("~****/#####") ;
					  pFilsData->setSonsList("#TLI#1") ;
					  pFilsData->setDialogName("TEXTLIB") ;
					  pFilsData->setOpenDialog(true) ;
					  pFilsData->setLevelShift("+00+00") ;
					  pFilsData->setDialogFile("NSBB") ;
					  pFilsData->setEmptyActivation(false) ;
          }

					(*it)->FilsProlongeable = true ;
				}
      	// cas des feuilles non texte-libre
				else
				{
					string sArchetype = (*it)->pCitem->getArchetype() ;

        	// s'il existe un Archetype, on le met en place
        	if (sArchetype != string(""))
        	{
            BBItemData* pFilsData = (*it)->getItemData() ;
            if (NULL != pFilsData)
            {
						  pFilsData->metAZero() ;
						  pFilsData->setSemanticPath((*it)->getItemLabel()) ;
						  pFilsData->setSonsList(sArchetype) ;
						  pFilsData->setOpenArchetype(true) ;

          	  string sDecal = (*it)->pCitem->getStringAttribute(ATTRIBUT_ITEM_DECAL);
						  if (sDecal == "") // si le decalage n'est pas pr�cis�...							  sDecal = string("+01+01");  // ... on prend la valeur par d�faut

						  pFilsData->setLevelShift(sDecal) ;
						  pFilsData->setEmptyActivation(false) ;
            }

						(*it)->FilsProlongeable = true ;
        	}
        	// on regarde s'il existe un fil guide
        	else
        	{
            string sItemLabel = (*it)->getItemLabel() ;
						pSuper->getDico()->donneCodeSens(&sItemLabel, &sCodeSens) ;
						VecteurSelonCritere.SetData(sCodeSens, &trouve, (*it)->getItemData()) ;

						if (trouve)						{
							// si feuille

							// cas particulier : �tiquette = #C���1 : pas de fils mais
							// le consid�rer comme prolongeable
							size_t pos = (*it)->getItemData()->getSonsList().find_first_not_of(string(" ")) ;

							// Pour les Arch�types, on n'accepte comme prolongement							// que des fils guides qui ouvrent une boite de dialogue
							// (ou un Arch�type)
							// --
							// Archetypes can only be extended by fils guides that
							// open a dialog or another Archetype
							if ((0 == pos) && (((*it)->getItemData()->ouvreDlg() || (*it)->getItemData()->ouvreArchetype())))
								(*it)->FilsProlongeable = true ;
							else
								(*it)->FilsProlongeable = false ;
						}
						else
							(*it)->FilsProlongeable = false ;
					}
				}
			}
			else // cas des non-feuilles => fils prolongeable
				(*it)->FilsProlongeable = true ;
		} // fin du for (; it != aBBItemFils.end(); it++)
	}

	sMsg = "creerArchetype() : MAJ des patpatho" ;
	pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

	// M.A.J des patpatho (sauf mode Consultation)
	if (!Consultation)
		if (pPPTEnCours)
			DispatcherPatPatho() ;

	sMsg = "creerArchetype() : Appel de creerFilsArchetype" ;
	pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

	creerExclus() ;
	creerFilsArchetype() ;

	return 0 ;
}catch (...){  erreur("Exception BBItem::creerArchetype.", standardError, 0) ;  return 1 ;}}boolBBItem::verifConstraintItem(string* psMessage){  if ((!pParseur) || (!(pParseur->pArchetype)))    return true ;  Carchetype* pArc = pParseur->pArchetype ;  if (pArc->vect_val.empty())    return true ;  NSPatPathoArray TempPPT(pContexte) ;  rapatrieTmpPpt(&TempPPT, 0) ;  // on recherche dans l'archetype la balise items (qui se situe � la racine)  for (ValIter i = pArc->vect_val.begin() ; pArc->vect_val.end() != i ; i++)  {    Citem *pItemRoot = dynamic_cast<Citem *>((*i)->pObject) ;    if ((NULL != pItemRoot) && (true == pItemRoot->bItemRoot))    {      // � priori on est dans la balise "items"      Valeur_array *pItemSons = pItemRoot->getArrayFils() ;      if ((NULL == pItemSons) || pItemSons->empty())        return false ;      for (ValIter itemIter = pItemSons->begin() ; itemIter != pItemSons->end() ; itemIter++)
      {
        Citem *pItem = dynamic_cast<Citem *>((*itemIter)->pObject) ;
        if (pItem && (false == pItem->verifConstraintsWithPPatho(&TempPPT, psMessage)))
          return false ;
      }
      return true ;
    }
  }  return false ;/*  // si on a pas trouv� la balise "items" on ne peut pas continuer, on sort  if (itemsVal == NULL)  {    // erreur    return ;  }  for (PatPathoIter pptIter = pTempPPT->begin() ; pptIter != pTempPPT->end() ; pptIter++)  {    if ((*pptIter)->pDonnees->getColonne() == 0)    {      // on est � la racine de la patpatho      Cbalise *pBalise = itemsVal->pObject ;      for (Val_iter v = pBalise->vect_val.begin() ; v != pBalise->vect_val.end() ; v++)      {        Attr_iter a = NULL ;        for (a = pBalise->vect_attr.begin() ; a != pBalise->vect_attr.end() ; a++)          if ((*a)->sLabel == "code")            break ;        if ((*a)->sLabel == "code")        {          // ce qui est contenu dans (*a)->sValue doit �tre le chemin          // on construit le noeud � partir du code lexique et du complement          char  pcPath[128] ;          sprintf(pcPath, "%s/$%s", (*pptIter)->pDonnees->lexique, (*pptIter)->pDonnees->complement) ;          if (strcmp(pcPath, (*a)->sValue.c_str()))          {            // le noeud correspond � l'item dans l'archetype            // il faut maintenant v�rifier ces fils            //if (!comparePPathoWithArc()          }        }        // il faut v�rifier que le code correspond � la patpatho        // code archetype correspond � un iter de (*i)->pObject->vect_attr (sLabel="code") et sValue=$chemin        // $chemin doit correspondre � (*pptIter)->pDonnees->lexique + "/$" + (*pptIter)->pDonnees->complement        // si il correspond, on v�rifie la contrainte et on lance la v�rification        // sur ses fils        NSSuper *pSuper = pBigBoss->pContexte->getSuperviseur() ;      }    }  }*/}// -----------------------------------------------------------------------------// -----------------------------------------------------------------------------voidBBItem::MiseAjourPatPatho(NSPatPathoArray*	pPatpathoFils, NSPatPathoInfo* pPatPatho, int ligneNonNulle)
{
try
{
  if ((!pPatPatho) || (!pPatpathoFils))
    return ;

  pPatPatho->setColonne(pPatPatho->getColonne() - 1) ;
  pPatPatho->setLigne(pPatPatho->getLigne() - ligneNonNulle + ORIGINE_PATH_PATHO) ;

  // un �l�ment de plus
  pPatpathoFils->push_back(new NSPatPathoInfo((*pPatPatho))) ;
}
catch (...)
{
  erreur("Exception BBItem::MiseAjourPatPatho.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------// -----------------------------------------------------------------------------voidBBItem::MiseAjourPatPathoZero(NSPatPathoArray *pPatpathoFils, NSPatPathoInfo *pPatPatho, int ligneNonNulle)
{
try
{
  if ((NULL == pPatPatho) || (NULL == pPatpathoFils))
    return ;

  pPatPatho->setColonne(pPatPatho->getColonne()) ;
  pPatPatho->setLigne(pPatPatho->getLigne() - ligneNonNulle + ORIGINE_PATH_PATHO ) ;

  // un �l�ment de plus
  pPatpathoFils->push_back(new NSPatPathoInfo((*pPatPatho))) ;
}
catch (...)
{
  erreur("Exception BBItem::MiseAjourPatPathoZero.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// A partir du compl�ment sComplement reconstruire la string $0..sComplement
// exemple  sComplement = 1.5 on aura $001.5
// exemple  sComplement = 1 on aura $00001
// -----------------------------------------------------------------------------
string
BBItem::AjusteEtiquetteAvecDollar(string sComplement)
{
  string sDollar = string("$") ;

  if (BASE_LEXIQUE_LEN < strlen(sComplement.c_str()))
    return "" ;
  for (size_t i = 1 ; i < BASE_LEXIQUE_LEN - strlen(sComplement.c_str()) ; i++)
    sDollar = sDollar + string("0") ;
  return (sDollar + sComplement) ;
}

// -----------------------------------------------------------------------------
// retourner le BBFilsItem ayant sEtiquette comme �tiquette.
// traiter le cas o� l'�tiquette du fils contient WCEA00.
// traiter le cas o� l'�tiquette du fils est du type 200001/�N0;01/$00001 : dans ce cas
// sComplement est forc�ment 1 : $00001
// si multidialogue alors ne pas tenir compte de Actif
// -----------------------------------------------------------------------------
BBFilsItem *
BBItem::TrouverFilsAyantBonneEtiquette(string sEtiquette, string sComplement)
{
  if (sEtiquette == "")
    return NULL ;

  BBiter  Iter ;
  size_t  posWCEA0 ;

  if (aBBItemFils.empty())
    return NULL ;

  string sEtiq, sEtiqIter;
  NSSuper* pSuper = pContexte->getSuperviseur() ;

  pSuper->getDico()->donneCodeSens(&sEtiquette, &sEtiq) ;

  for (Iter = aBBItemFils.begin() ; Iter != aBBItemFils.end() ; Iter++)
  {
    string sFilsLabel = (*Iter)->getItemLabel() ;
    pSuper->getDico()->donneCodeSens(&sFilsLabel, &sEtiqIter) ;

    // �galit� stricte
    if (sEtiqIter == sEtiq)
    {
      if (!(*Iter)->getItemData()->uniciteLesion())
        return (*Iter) ;
      else
      {
        if (!(*Iter)->Actif())
          return (*Iter) ;
      }
    }
    if ((sEtiqIter.find(sEtiq) != string::npos) && (((!(*Iter)->getItemData()->uniciteLesion()) || (!(*Iter)->Actif()))))
    {
      // Cas particulier : l'�tiquette du fils contient WCEA00
      posWCEA0 = sEtiqIter.find(string("WCEA0")) ;
      if ((posWCEA0 != string::npos) && (posWCEA0 < strlen(sEtiqIter.c_str())))
        return (*Iter) ;

      if (sComplement != "")
      {
        // On teste avec le compl�ment "brut"
        if (sEtiqIter == (sEtiq + string(1, cheminSeparationMARK) + string(1, '$') + sComplement))
          return (*Iter) ;

        // Cas (*Iter)->sEtiquette = 200001/�N0;01/$00001
        // sEtiquette = 200001/�N0;01
        // AjusteEtiquetteAvecDollar(sComplement) = $00001
        if (sEtiqIter == (sEtiq + string(1, cheminSeparationMARK) + AjusteEtiquetteAvecDollar(sComplement)))
          return (*Iter) ;
      }
      else
      {
        if (!(*Iter)->Actif())
        {
          // Cas particulier : l'�tiquette du fils contient WCEA00
          posWCEA0 = sEtiqIter.find(string("WCEA0")) ;
          if ((posWCEA0 != string::npos) && (posWCEA0 < strlen(sEtiqIter.c_str())))
            return (*Iter) ;

          // Cas (*Iter)->sEtiquette = 200001/�N0;01/$00001
          // sEtiquette = 200001/�N0;01
          // AjusteEtiquetteAvecDollar(sComplement) = $00001

          if (sEtiqIter == (sEtiq + string(1, cheminSeparationMARK) + AjusteEtiquetteAvecDollar(sComplement)))
            return (*Iter) ;
        }
      }
    }
  }
  return NULL ;
}

// -----------------------------------------------------------------------------
// M.A.J du patptho de tous les BBFilsItem � partir de celui de leur p�re
// -----------------------------------------------------------------------------
void
BBItem::DispatcherPatPatho()
{
	if ((!pPPTEnCours) || (pPPTEnCours->empty()))
    return ;

  string sEtiquettePatpatho ;
  BBiter Iter ;

  int ligneNulle, ColonneNulle ;  bool patPathoFilsNonvide = false ;  // d�tecter si la patpatho est vide ou non
  int colonneNonNulle ;
  int ligneNonNulle ;
  string motcompose = "" ;	//mot compos�

try
{
  NSSuper* pSuper = pContexte->getSuperviseur() ;

  PatPathoIter iterColonneNulle = pPPTEnCours->begin() ; // items dont la colonne est nulle
  PatPathoIter k 				        = pPPTEnCours->begin() ; // iterateur temporaire
  PatPathoIter iterTemp 		    = pPPTEnCours->begin() ; // iterateur temporaire

  string sComplement ; //donnees num�riques
  string sUnit ;
  string sInteret ;
  string sPluriel ;
  string sVisible ;
  string sCertitude ;
  string sLexique ;
  string sNoeud ;
  string sTree ;
  string sTexteLibre ;
  string sRights ;

  int pFilSuivant ;
  int decalageNonNul ;

  // PatPathoIter i = pPPTEnCours->begin() ;

  // On passe en revue toute la patpatho
  while (iterColonneNulle != pPPTEnCours->end())
  {
    sComplement = string("") ;
    sUnit       = string("") ;
    sInteret    = string("") ;
    sPluriel    = string("") ;
    sVisible    = string("") ;
    sCertitude  = string("") ;
    sLexique    = string("") ;
    sNoeud      = string("") ;
    sTree       = string("") ;
    sTexteLibre = string("") ;
    sRights     = string("") ;
    decalageNonNul = 1 ;

    // items dont la colonne est non nulle
    PatPathoIter iterColonneNonNulle = pPPTEnCours->begin() ;
    sEtiquettePatpatho = "" ;
    if ((*iterColonneNulle)->getColonne() == ORIGINE_PATH_PATHO)
    {
      // R�cup�rer les donn�es dans la patpatho
      sEtiquettePatpatho = (*iterColonneNulle)->getLexique() ; // mot unique
      sNoeud             = (*iterColonneNulle)->getNodeID() ;
      sTree              = (*iterColonneNulle)->getDoc() ;

      // Cas particulier : si sEtiquettePatpatho contient �C prendre les donn�es
      // dans l'�l�ment suivant de la patpatho qui, lui (controle fictif)
      // contient les vraies donn�es � afficher.
      // Exemple en Echo : Chimioth�rapie
      if ((sEtiquettePatpatho.find(string("�C;")) != string::npos) || (sEtiquettePatpatho.find(string("/�C;")) != string::npos))
      {
        k = iterColonneNulle ;
        k++ ;
        if (k != pPPTEnCours->end())
        {
          sLexique    = (*k)->getLexique() ;
          sUnit       = (*k)->getUnit() ;
          sComplement = (*k)->getComplement() ;
          sInteret    = (*k)->getInteret() ;
          sPluriel    = (*k)->getPluriel() ;
          sVisible    = (*k)->getVisible() ;
          sCertitude  = (*k)->getCertitude() ;
          sTexteLibre = (*k)->getTexteLibre() ;
          sRights     = (*k)->getNodeRight() ;
          sNoeud      += string(1,cheminSeparationMARK) + (*k)->getNodeID() ;
        }
      }
      else
      {
        sComplement = (*iterColonneNulle)->getComplement() ;
        sUnit       = (*iterColonneNulle)->getUnit() ;
        sInteret    = (*iterColonneNulle)->getInteret() ;
        sPluriel    = (*iterColonneNulle)->getPluriel() ;
        sVisible    = (*iterColonneNulle)->getVisible() ;        sCertitude  = (*iterColonneNulle)->getCertitude() ;
        sTexteLibre = (*iterColonneNulle)->getTexteLibre() ;
        sRights		  = (*iterColonneNulle)->getNodeRight() ;
      }
      ligneNulle   = (*iterColonneNulle)->getLigne() ;
      ColonneNulle = (*iterColonneNulle)->getColonne() ;
      iterColonneNonNulle = iterColonneNulle ;
      iterColonneNonNulle++ ;
      if ((pPPTEnCours->end() != iterColonneNonNulle) &&
          ((*iterColonneNonNulle)->getColonne() == ORIGINE_PATH_PATHO))
        iterColonneNonNulle = iterColonneNulle ;

      if (pPPTEnCours->end() != iterColonneNonNulle)
      {
        colonneNonNulle = (*iterColonneNonNulle)->getColonne() ;
        ligneNonNulle   = (*iterColonneNonNulle)->getLigne() ;
      }

      // L'unit� est inscrite en premier
      if (sUnit != "")
        sEtiquettePatpatho = sUnit + string(1,cheminSeparationMARK) + sEtiquettePatpatho ;
      // L'�tiquette pourrait �tre du type : sEtiquettePatpatho + sPluriel + sCertitude ;
      string sPlurielProvisoir ;
      if (sPluriel == string(""))
        sPlurielProvisoir = string("") ;
      else
        sPlurielProvisoir = string(1, cheminSeparationMARK) + sPluriel ;

      string sCertitudeProvisoir  ;
      if (sCertitude == string(""))
        sCertitudeProvisoir = string("") ;
      else
          sCertitudeProvisoir = string(1, cheminSeparationMARK) + sCertitude ;

      string sEtiquetteBrute = sEtiquettePatpatho ; // sans certitude et pluriel

      // Traiter le cas o� il y a : certitude et/ou pluriel
      sEtiquettePatpatho = sEtiquettePatpatho + sPlurielProvisoir + sCertitudeProvisoir ;
      motcompose = sEtiquettePatpatho ;

      // size_t posWCEA0;
      // Trouver le fils ayant la bonne �tiquette
      BBFilsItem* filsTrouve = TrouverFilsAyantBonneEtiquette(sEtiquettePatpatho, sComplement) ;

      // Si on trouve un fils , on l'active et on lui donnee ses donn�es (vides ou non )
      if (filsTrouve)
      {
        Message* pFilsMessage = filsTrouve->getItemTransfertMsg() ;
        pFilsMessage->SetTreeID(sTree) ;
        pFilsMessage->SetNoeud(sNoeud) ;
        pFilsMessage->SetLexique(sLexique) ;
        pFilsMessage->SetComplement(sComplement) ;
        pFilsMessage->SetUnit(sUnit) ;
        pFilsMessage->SetPluriel(sPluriel) ;
        pFilsMessage->SetVisible(sVisible) ;
        pFilsMessage->SetCertitude(sCertitude) ;
        pFilsMessage->SetInteret(sInteret) ;
        pFilsMessage->SetTexteLibre(sTexteLibre) ;
        pFilsMessage->SetNodeRight(sRights) ;

        filsTrouve->Active() ; // rendre ce fils actif
        if ((*iterColonneNulle)->ID == 1)          filsTrouve->bCorriger = true ;

        if (filsTrouve->estPlusZero())
        {
          if (filsTrouve->getItemData()->getSonsList().find(sEtiquettePatpatho) != string::npos)
          {
            decalageNonNul = 0 ;
            pFilSuivant = 1 ;
            NSPatPathoArray PatpathoFils(pContexte) ;
            patPathoFilsNonvide = false ;
            iterColonneNonNulle = iterColonneNulle ;
            ligneNonNulle = ligneNulle ;
            while ((pPPTEnCours->end() != iterColonneNonNulle) && (pFilSuivant))
            {
              NSPatPathoInfo PatPatho(*(*iterColonneNonNulle)) ;

              // Placer l'�l�ment dont la colonne est nulle
              MiseAjourPatPathoZero(&PatpathoFils, &PatPatho, ligneNonNulle) ;
              patPathoFilsNonvide = true ;

              sUnit       = (*iterColonneNonNulle)->getUnit() ;
              if (sUnit != "")
                motcompose += string(1, cheminSeparationMARK) + sUnit ;

              // Former �ventuellement le mot compos�
              motcompose += string(1, cheminSeparationMARK) + (*iterColonneNonNulle)->getLexique() ;

              //if(motcompose.find(string("�")) != NPOS)
              sComplement = (*iterColonneNonNulle)->getComplement() ;
              sInteret    = (*iterColonneNonNulle)->getInteret() ;
              sPluriel    = (*iterColonneNonNulle)->getPluriel() ;
              sVisible    = (*iterColonneNonNulle)->getVisible() ;
              sCertitude  = (*iterColonneNonNulle)->getCertitude() ;
              sTexteLibre = (*iterColonneNonNulle)->getTexteLibre() ;
              sRights		  = (*iterColonneNonNulle)->getNodeRight() ;

              k = iterColonneNonNulle ;
              k++ ;

              //test pour l'�l�ment suivant
              if ((pPPTEnCours->end() != k) && ((*k)->getColonne() > ORIGINE_PATH_PATHO))
                iterColonneNonNulle++ ;
              else
                pFilSuivant = 0 ;
            } //while

            if ((filsTrouve) && (patPathoFilsNonvide))
            {
              NSPatPathoArray* pNewPpt = new NSPatPathoArray(PatpathoFils) ;
              (filsTrouve->getPatPatho())->push_back(new NSFatheredPatPathoArray(pContexte, new NSPatPathoInfo(**iterColonneNulle), pNewPpt)) ;
            }
          }
        }
      }
      // Si on n'a pas trouv� de fils, c'est certainement un +00+00
      // Attention, les textes libres am�nent artificiellement un +00+00
      // suppl�mentaire, � cause du fil guide */##### -+00+00-> #TLI#1
      else
      {
        for (Iter = aBBItemFils.begin(); Iter != aBBItemFils.end(); Iter++)
        {
          if ((*Iter)->estPlusZero())
          {
            if ((*Iter)->getItemData()->getSonsList().find(sEtiquetteBrute) != NPOS)
            {
              decalageNonNul = 0 ;

              (*Iter)->Active() ; //rendre ce fils actif

              Message* pFilsMessage = (*Iter)->getItemTransfertMsg() ;
              if (NULL != pFilsMessage)
              {
                pFilsMessage->SetComplement(sComplement) ;
                pFilsMessage->SetUnit(sUnit) ;
                pFilsMessage->SetPluriel(sPluriel) ;
                pFilsMessage->SetVisible(sVisible) ;
                pFilsMessage->SetCertitude(sCertitude) ;
                pFilsMessage->SetInteret(sInteret) ;
                pFilsMessage->SetTexteLibre(sTexteLibre) ;
                pFilsMessage->SetNodeRight(sRights) ;
              }

              pFilSuivant = 1 ;
              NSPatPathoArray PatpathoFils(pContexte) ;
              patPathoFilsNonvide = false ;
              iterColonneNonNulle = iterColonneNulle ;
              ligneNonNulle = ligneNulle ;
              while ((iterColonneNonNulle != pPPTEnCours->end()) && (pFilSuivant))
              {
                NSPatPathoInfo PatPatho(*(*iterColonneNonNulle)) ;
                //placer l'�l�ment dont la colonne est nulle
                MiseAjourPatPathoZero(&PatpathoFils, &PatPatho, ligneNonNulle) ;
                patPathoFilsNonvide = true ;

                sUnit       = (*iterColonneNonNulle)->getUnit() ;
                if (sUnit != "")
                  motcompose += string(1, cheminSeparationMARK) + sUnit ;

                // former �ventuellement le mot compos�
                motcompose += string(1,cheminSeparationMARK) + (*iterColonneNonNulle)->getLexique() ;

                //if(motcompose.find(string("�")) != string::npos)
                sComplement = (*iterColonneNonNulle)->getComplement() ;
                sInteret    = (*iterColonneNonNulle)->getInteret() ;
                sPluriel    = (*iterColonneNonNulle)->getPluriel() ;
                sVisible    = (*iterColonneNonNulle)->getVisible() ;
                sCertitude  = (*iterColonneNonNulle)->getCertitude() ;
                sTexteLibre = (*iterColonneNonNulle)->getTexteLibre() ;
                sRights     = (*iterColonneNonNulle)->getNodeRight() ;

                k = iterColonneNonNulle ;
                k++ ;

                /*
                //passer � l'�l�ment suivant s'il a la m�me colonne que l'�l�ment
                //en cours

                if ((k != pPPTEnCours->end()) && ((*k)->pDonnees->getColonne() == (*iterColonneNonNulle)->pDonnees->getColonne()))
                  iterColonneNonNulle++ ;
                else
                {
                */
                  // Test pour l'�l�ment suivant
                  if ((pPPTEnCours->end() != k) && ((*k)->getColonne() > ORIGINE_PATH_PATHO))
                    iterColonneNonNulle++ ;
                  else
                    pFilSuivant = 0 ;
                //}
              } // while

              if ((Iter != aBBItemFils.end()) && (patPathoFilsNonvide))
              {
                NSVectFatheredPatPathoArray* pPatpatho = (*Iter)->getPatPatho() ;
                if (!pPatpatho->empty())
                {
                  NSPatPathoArray* ContenuPatpatho = (*(pPatpatho->begin()))->getPatPatho() ;

                  // Si ContenuPatpatho existe, mettre pPatpathoFils � la suite
                  if (!ContenuPatpatho->empty())
                    pBigBoss->ConcatenerPatpatho(&PatpathoFils, ContenuPatpatho, false) ;
                  // Sinon, mettre pPatpathoFils � la place
                  else
                    pPatpatho->push_back(new NSFatheredPatPathoArray(pContexte, new NSPatPathoInfo(**iterColonneNulle), new NSPatPathoArray(PatpathoFils))) ;
                }
                else
                  pPatpatho->push_back(new NSFatheredPatPathoArray(pContexte, new NSPatPathoInfo(**iterColonneNulle), new NSPatPathoArray(PatpathoFils))) ;
              }
              filsTrouve = (*Iter) ;
            }
          }
        }

        // Si on n'a toujours pas trouv� de fils, c'est que c'est une s�rie de +00+00
        if (!filsTrouve)
        {
          // bool bTrouveSuite = false ;
          for (Iter = aBBItemFils.begin() ; Iter != aBBItemFils.end() ; Iter++)
          {
          	bool bTrouveSuite = false ;

            if ((*Iter)->estPlusZero())
            {
              string sFilsLabel = (*Iter)->getItemLabel() ;
              string sSens      = string("") ;
              pSuper->getDico()->donneCodeSens(&sFilsLabel, &sSens) ;
              string sLocalChem = sLocalisation + string(1, cheminSeparationMARK) + sSens ;

              VecteurRechercheSelonCritere VecteurSelonCritere(GUIDE) ;
              for (int i = 0 ; ('\0' != (*Iter)->getItemData()->fils[i]) && (' ' != (*Iter)->getItemData()->fils[i]) ; i++)
              {
                string sEtiquet  = "" ;
                string sCodeSens = "" ;

                // Prise de l'�tiquette
                for ( ; ('\0' != (*Iter)->getItemData()->fils[i]) && (nodeSeparationMARK != (*Iter)->getItemData()->fils[i]) ; i++)
                  sEtiquet += (*Iter)->getItemData()->fils[i] ;

                // traiter le cas des textes libres � part

                //if ((!(sEtiquet == string("#####1"))) && (!(sEtiquet == string("#####2"))))
                //{
                  pSuper->getDico()->donneCodeSens(&sEtiquet, &sCodeSens) ;
                  VecteurSelonCritere.AjouteEtiquette(sCodeSens) ;
                //}
                // Attention � la double boucle qui fait sauter par dessus le '\0'
                if ('\0' == (*Iter)->getItemData()->fils[i])
                  break ;
              }
              if (false == VecteurSelonCritere.empty())
              {
                pSuper->afficheStatusMessage("Recherche des fils guides +00+00") ;
                pSuper->getFilGuide()->chercheChemin(&sLocalChem, &VecteurSelonCritere, NSFilGuide::compReseau) ;

                for (IterCritere iCrit = VecteurSelonCritere.begin() ; (VecteurSelonCritere.end() != iCrit) && !bTrouveSuite ; iCrit++)
                {
                  RechercheSelonCritereData* pRechItem = (RechercheSelonCritereData *)(*iCrit) ;
                  if (((*iCrit)->trouve) &&
                      (string("+00+00") == pRechItem->pDonnees->getLevelShift()) &&
                      (string::npos != string(pRechItem->pDonnees->fils).find(sEtiquetteBrute)))
                    bTrouveSuite = true ;
                }
              }
            }
            if (bTrouveSuite)
            {
              decalageNonNul = 0 ;
              (*Iter)->Active() ; //rendre ce fils actif
              Message* pFilsMessage = (*Iter)->getItemTransfertMsg() ;
              if (NULL != pFilsMessage)
              {
                pFilsMessage->SetComplement(sComplement) ;
                pFilsMessage->SetUnit(sUnit) ;
                pFilsMessage->SetPluriel(sPluriel) ;
                pFilsMessage->SetVisible(sVisible) ;
                pFilsMessage->SetCertitude(sCertitude) ;
                pFilsMessage->SetInteret(sInteret) ;
                pFilsMessage->SetTexteLibre(sTexteLibre) ;
                pFilsMessage->SetNodeRight(sRights) ;
              }

              pFilSuivant = 1 ;
              NSPatPathoArray PatpathoFils(pContexte) ;
              patPathoFilsNonvide = false ;
              iterColonneNonNulle = iterColonneNulle ;
              ligneNonNulle = ligneNulle ;
              while ((iterColonneNonNulle != pPPTEnCours->end()) && (pFilSuivant))
              {
                NSPatPathoInfo PatPatho(*(*iterColonneNonNulle)) ;
                //placer l'�l�ment dont la colonne est nulle
                MiseAjourPatPathoZero(&PatpathoFils, &PatPatho, ligneNonNulle) ;
                patPathoFilsNonvide = true ;

                sUnit       = (*iterColonneNonNulle)->getUnit() ;
                if (sUnit != "")
                  motcompose += string(1, cheminSeparationMARK) + sUnit ;

                // former �ventuellement le mot compos�
                motcompose += string(1,cheminSeparationMARK) + (*iterColonneNonNulle)->getLexique() ;

                //if(motcompose.find(string("�")) != NPOS)
                sComplement = (*iterColonneNonNulle)->getComplement() ;
                sInteret    = (*iterColonneNonNulle)->getInteret() ;
                sPluriel    = (*iterColonneNonNulle)->getPluriel() ;
                sVisible    = (*iterColonneNonNulle)->getVisible() ;
                sCertitude  = (*iterColonneNonNulle)->getCertitude() ;
                sTexteLibre = (*iterColonneNonNulle)->getTexteLibre();
                sRights		  = (*iterColonneNonNulle)->getNodeRight() ;

                k = iterColonneNonNulle ;
                k++ ;

                /*
                // passer � l'�l�ment suivant s'il a la m�me colonne que l'�l�ment en cours

                if ((k != pPPTEnCours->end()) && ((*k)->pDonnees->getColonne() == (*iterColonneNonNulle)->pDonnees->getColonne()))
                  iterColonneNonNulle++ ;
                else
                {
                */
                  // Test pour l'�l�ment suivant
                  if ((pPPTEnCours->end() != k) &&
                      ((*k)->getColonne() > ORIGINE_PATH_PATHO))
                    iterColonneNonNulle++ ;
                  else
                    pFilSuivant = 0 ;                //}
              } // while
              if ((Iter != aBBItemFils.end()) && (patPathoFilsNonvide))              {
                NSVectFatheredPatPathoArray* pPatpatho = (*Iter)->getPatPatho() ;
                if (false == pPatpatho->empty())
                {
                  NSPatPathoArray* ContenuPatpatho = (*(pPatpatho->begin()))->getPatPatho() ;

                  // Si ContenuPatpatho existe, mettre pPatpathoFils � la suite
                  if (!ContenuPatpatho->empty())
                    pBigBoss->ConcatenerPatpatho(&PatpathoFils, ContenuPatpatho, false) ;
                  // Sinon, mettre pPatpathoFils � la place
                  else
                    pPatpatho->push_back(new NSFatheredPatPathoArray(pContexte, new NSPatPathoInfo(**iterColonneNulle), new NSPatPathoArray(PatpathoFils))) ;
                }
                else
                  pPatpatho->push_back(new NSFatheredPatPathoArray(pContexte, new NSPatPathoInfo(**iterColonneNulle), new NSPatPathoArray(PatpathoFils))) ;
              }
              filsTrouve = (*Iter) ;
            }
          }
        }
      }
      pFilSuivant = 1 ; // on passe au pfils suivant ou non
      patPathoFilsNonvide = false ;
      if ((iterColonneNonNulle != pPPTEnCours->end()) && (decalageNonNul))
      {
        NSPatPathoArray PatpathoFils(pContexte) ;

        iterTemp = iterColonneNonNulle ;
        // Si mot compos�
        if ((ligneNonNulle == ligneNulle) && (colonneNonNulle != ColonneNulle))
          iterTemp++ ;

        // Si la colonne du fils suivant est non nulle et  ce fils existe
        if ((pPPTEnCours->end() != iterTemp) &&
            ((*iterTemp)->getColonne() > ORIGINE_PATH_PATHO))
        {
          // On passe � l'item suivant
          iterColonneNonNulle = iterTemp ;

          // M.A.J du patpatho du fils
          while ((pPPTEnCours->end() != iterColonneNonNulle) && (pFilSuivant))
          {
            NSPatPathoInfo PatPatho(*(*iterColonneNonNulle)) ;
            MiseAjourPatPatho(&PatpathoFils, &PatPatho, ligneNonNulle) ;

            patPathoFilsNonvide = true ;

            sUnit       = (*iterColonneNonNulle)->getUnit() ;
            if (sUnit != "")
              motcompose += string(1, cheminSeparationMARK) + sUnit ;
            // Former �ventuellement le mot compos�
            motcompose += string(1,cheminSeparationMARK) + (*iterColonneNonNulle)->getLexique() ;
            sComplement = (*iterColonneNonNulle)->getComplement() ;
            sInteret    = (*iterColonneNonNulle)->getInteret() ;
            sPluriel    = (*iterColonneNonNulle)->getPluriel() ;
            sVisible    = (*iterColonneNonNulle)->getVisible() ;
            sCertitude  = (*iterColonneNonNulle)->getCertitude() ;
            sTexteLibre = (*iterColonneNonNulle)->getTexteLibre() ;
            sRights		  = (*iterColonneNonNulle)->getNodeRight() ;

            k = iterColonneNonNulle ;
            k++ ;

            // Test pour l'�l�ment suivant
            if ((pPPTEnCours->end() != k) &&
                ((*k)->getColonne() > ORIGINE_PATH_PATHO))
              iterColonneNonNulle++ ;
            else
              pFilSuivant = 0 ;
          } //while
        }
        // Mise � jour du patPatho du fils
        if ((filsTrouve) && (patPathoFilsNonvide))
          (filsTrouve->getPatPatho())->push_back(new NSFatheredPatPathoArray(pContexte, new NSPatPathoInfo(**iterColonneNulle), new NSPatPathoArray(PatpathoFils)));
      }
    }
    // Cas de mot compos� : exemple : MAMPL/2M001/�N0;01
    for (Iter = aBBItemFils.begin() ; (Iter != aBBItemFils.end()) && ((*Iter)->getItemLabel() != motcompose) ; Iter++)
      ;
    if (Iter != aBBItemFils.end())
    {
      (*Iter)->Active() ; // rendre ce fils actif et lui attribuer ses donn�es
      Message* pFilsMessage = (*Iter)->getItemTransfertMsg() ;
      if (NULL != pFilsMessage)
      {
        pFilsMessage->SetTreeID(sTree) ;
        pFilsMessage->SetNoeud(sNoeud) ;
        pFilsMessage->SetComplement(sComplement) ;
        pFilsMessage->SetUnit(sUnit) ;
        pFilsMessage->SetPluriel(sPluriel) ;
        pFilsMessage->SetVisible(sVisible) ;
        pFilsMessage->SetCertitude(sCertitude) ;
        pFilsMessage->SetInteret(sInteret) ;
        pFilsMessage->SetTexteLibre(sTexteLibre) ;
        pFilsMessage->SetNodeRight(sRights) ;
      }
    }
    if (iterColonneNonNulle != pPPTEnCours->end())
      iterColonneNulle = iterColonneNonNulle ;

		// El�ment suivant
		if (iterColonneNulle != pPPTEnCours->end())
      iterColonneNulle++ ;
	}

  // Now we have to check that self excluding sons are not selected
  //
  creerExclus() ;
  DispatcherPatPathoArbitrateExcluded() ;
}
catch (...)
{
  erreur("Exception BBItem::DispatcherPatPatho.", standardError, 0) ;
}
}

void
BBItem::DispatcherPatPathoArbitrateExcluded()
{
  if (aBBItemFils.empty())
    return ;

  for (BBiter Iter = aBBItemFils.begin() ; aBBItemFils.end() != Iter ; Iter++)
  {
    BBiter IterBro = Iter ;
    IterBro++ ;
    while (((*Iter)->Actif()) && (aBBItemFils.end() != IterBro))
    {
      if (((*IterBro)->Actif()) && (isExcluded(*Iter, *IterBro)))
        arbitrateExcluded(*Iter, *IterBro) ;
      IterBro++ ;
    }
  }
}

void
BBItem::arbitrateExcluded(BBFilsItem *pFilsIt1, BBFilsItem *pFilsIt2)
{
  if ((NULL == pFilsIt1) || (NULL == pFilsIt2))
    return ;

  // So far, the arbitration is made on:
  // - the size of the patpatho
  // - if equal, the order (first remains)
  //
  NSVectFatheredPatPathoArray* pFatheredPptArray1 = pFilsIt1->getPatPatho() ;
  NSVectFatheredPatPathoArray* pFatheredPptArray2 = pFilsIt2->getPatPatho() ;

  // Is one of both arrays empty?
  //
  if ((NULL == pFatheredPptArray2) || (pFatheredPptArray2->estVide()))
  {
    pFilsIt2->Desactive() ;
    return ;
  }
  if ((NULL == pFatheredPptArray1) || (pFatheredPptArray1->estVide()))
  {
    pFilsIt1->Desactive() ;
    return ;
  }

  // Evaluate the size of collected information
  //
  FatheredPatPathoIterVect iter ;

  size_t iSize1 = 0 ;
	for (iter = pFatheredPptArray1->begin(); pFatheredPptArray1->end() != iter ; iter++)
    if ((NULL != (*iter)->getPatPatho()) && (false == (*iter)->getPatPatho()->empty()))
      iSize1 += (*iter)->getPatPatho()->size() ;

  size_t iSize2 = 0 ;
	for (iter = pFatheredPptArray2->begin(); pFatheredPptArray2->end() != iter ; iter++)
    if ((NULL != (*iter)->getPatPatho()) && (false == (*iter)->getPatPatho()->empty()))
      iSize2 += (*iter)->getPatPatho()->size() ;

  if (iSize1 > iSize2)
  {
    pFilsIt2->Desactive() ;
    return ;
  }
  if (iSize2 > iSize1)
  {
    pFilsIt1->Desactive() ;
    return ;
  }

  // No valid criterion remains... first one wins
  //
  pFilsIt2->Desactive() ;

  return ;
}

// -----------------------------------------------------------------------------
// Description  : Pour chaque fils "actif" (qui correspond � une �tiquette), on
//                cherche la fiche Paradox correspondante et, si elle int�resse
//                la m�me fen�tre, on cr�e une BBItem
// Returns      : 0 si OK et 1 si le champ exclu est non traitable
// -----------------------------------------------------------------------------
int
BBItem::creerExclus()
{
try
{
	// Si la liste d'exclusion ou la liste des fils sont vides, on sort
	if ((pDonnees->exclusion[0] == '\0') || (strspn(pDonnees->exclusion, " ") == strlen(pDonnees->exclusion)))
		return 0 ;
	if (aBBItemFils.empty())
		return 0 ;

	int	 i ;
	string totalDesCodes ;
  BBiter Iter, Jter, excluIter ;
  string exclueur, exclus ;

	// Assemblage de la liste compl�te des �tiquettes
	totalDesCodes = "" ;

	// Cas particulier : exclusion compl�te
  if ((pDonnees->exclusion[0] == '(') && (pDonnees->exclusion[1] == ')'))
	{
    // Pour chacun des fils
    for (Iter = aBBItemFils.begin() ; Iter != aBBItemFils.end() ; Iter++)
    {
      // On ajoute � sa liste d'exclusion toutes les autres �tiquettes
      for (Jter = aBBItemFils.begin() ; Jter != aBBItemFils.end() ; Jter++)
        if ((*Jter)->getItemLabel() != (*Iter)->getItemLabel())
          (*Iter)->Exclusion.aExclusion.push_back(new string((*Jter)->getItemLabel())) ;
    }
		return 0 ;
  }

	// Analyse du champ exclusion
	for (i = 0 ; pDonnees->exclusion[i] != '\0' ; i++)
	{
		// on cherche une parenth�se ouvrante
		for ( ; (pDonnees->exclusion[i] != '\0') && (pDonnees->exclusion[i] != '(') ; i++)
      ;
		if (pDonnees->exclusion[i] != '(')
			return 0 ;
		i++ ;

		// Les caract�res apr�s la parenth�se donnent l'�tiquette de l'exclueur
    exclueur = "" ;
    for ( ; (pDonnees->exclusion[i] != '\0') && (pDonnees->exclusion[i] != ')') && (pDonnees->exclusion[i] != '-') ; i++)
      exclueur += pDonnees->exclusion[i] ;

		// Recherche de son indice
    for (excluIter = aBBItemFils.begin() ; (excluIter != aBBItemFils.end()) && ((*excluIter)->getItemLabel() != exclueur) ; excluIter++)
      ;

		if (excluIter == aBBItemFils.end())
			return 1 ;

		// L'exclueur est forc�ment suivi d'un tiret
		if (pDonnees->exclusion[i] != '-')
			return 1 ;
		i++ ;

		// apr�s le tiret, une parenth�se fermante signifie que l'exclueur exclue tous les autres
		if (pDonnees->exclusion[i] == ')')
		{
			// On ajoute l'exclueur � la liste des autres
			// et chacun des autres � la liste de l'exclueur
      for (Iter = aBBItemFils.begin(); Iter != aBBItemFils.end(); Iter++)
      {
        if ((*Iter)->getItemLabel() == (*excluIter)->getItemLabel())
        {
          for (Jter = aBBItemFils.begin(); Jter != aBBItemFils.end(); Jter++)
            if ((*Jter)->getItemLabel() != (*Iter)->getItemLabel())
              (*Iter)->Exclusion.aExclusion.push_back(new string((*Jter)->getItemLabel())) ;
        }
        else
          (*Iter)->Exclusion.aExclusion.push_back(new string((*excluIter)->getItemLabel())) ;
      }
    }
		else
		{
			// chaque exclus est s�par� par une virgule jusqu'� la parenth�se fermante
			for ( ; (pDonnees->exclusion[i] != '\0') && (pDonnees->exclusion[i] != ')') ; )
			{
        exclus = "" ;
        for ( ; ('\0' != pDonnees->exclusion[i]) && (')' != pDonnees->exclusion[i]) && (nodeSeparationMARK != pDonnees->exclusion[i]) ; i++)
          exclus += pDonnees->exclusion[i] ;

				// Recherche de son indice
				for (Iter = aBBItemFils.begin() ; (aBBItemFils.end() != Iter) && ((*Iter)->getItemLabel() != exclus) ; Iter++)
          ;

				if (Iter == aBBItemFils.end())					return 1 ;

				// Ajout de l'exclu � la liste de l'exclueur et vice versa
        (*Iter)->Exclusion.aExclusion.push_back(new string((*excluIter)->getItemLabel())) ;
        (*excluIter)->Exclusion.aExclusion.push_back(new string((*Iter)->getItemLabel())) ;

                // On avance d'un cran
				if (nodeSeparationMARK == pDonnees->exclusion[i])
					i++ ;
			}
		}
    if ('\0' == pDonnees->exclusion[i])
      break ;
	}
  return 0 ;
}
catch (...)
{
  erreur("Exception BBItem::creerExclus.", standardError, 0) ;
  return 0 ;
}
}

// -----------------------------------------------------------------------------
// Function     : int BBItem::creerFils()
// Arguments    :	code -> codon d'initialisation
// Description  : Pour chaque fils "actif" (qui correspond � une �tiquette), on
//                cherche la fiche Paradox correspondante et, si elle int�resse
//                la m�me fen�tre, on cr�e une BBItem
// -----------------------------------------------------------------------------
int
BBItem::creerFils()
{
try
{
  string  sFutureLocalisation = "" ;
  string  sCodeSens ;

	// Si le fil guide n'est pas li� � une boite de dialogue, on sort.
  if ((!lienDialogue ()) || (aBBItemFils.empty()))
    return 0 ;

	// On passe en revue tous les Fils d�clar�s de la BBItem,
	for (BBiter i = aBBItemFils.begin() ; i != aBBItemFils.end() ; i++)
	{
    if ((*i)->FilsProlongeable)
		{
      // On ne cr�e un BBItem � partir de la fiche Paradox que si l'�l�ment
      // concerne la m�me boite de dialogue et que l'�l�ment n'est pas une feuille.
      if ((strncmp((*i)->getItemData()->nomDialogue, "__IDEM", 6) == 0) ||
          ((strcmp(pDonnees->nomDialogue, (*i)->getItemData()->nomDialogue) == 0) &&
           (strncmp((*i)->getItemData()->nomDialogue, "__AUTO", 6) != 0)
          )
         )
      {
        // Cr�ation d'un BBItem
        (*i)->creerFils() ;

        // Initialisation du BBItem
        // attribuer la patpthoarray correspondante � ce pFilsItem
        // si pFilsItem->sEtiquette trouv�e
        string sEtiquette = (*i)->getItemLabel() ;
        if (!((*i)->VectorFils.empty()))
        {
          for (BBiterFils iter = (*i)->VectorFils.begin() ; iter != (*i)->VectorFils.end() ; iter++)
          {
            donneGenetique((*iter), sEtiquette) ;

            // On demande au BBItem de se cr�er
            (*iter)->creer() ;
          }
        }
      }
    }
  }
	return 0 ;
}
catch (...)
{
  erreur("Exception BBItem::creerFils.", standardError, 0) ;
  return 0 ;
}
}

// -----------------------------------------------------------------------------
// Function     : int BBItem::creerFils()
// Description  : Pour chaque fils, on cherche le Citem correspondant dans
//                l'archetype et, si il ne s'agit pas d'une feuille, on cr�e un
//                BBItem
// -----------------------------------------------------------------------------
int
BBItem::creerFilsArchetype(){try{  NSSuper* pSuper = pContexte->getSuperviseur() ;  string sMsg = "creerFilsArchetype() : Entr�e" ;  pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;  if (aBBItemFils.empty())    return 0 ;  // On passe en revue tous les Fils d�clar�s de la BBItem,  for (BBiter i = aBBItemFils.begin() ; i != aBBItemFils.end() ; i++)
  {
    // si le Citem correspondant n'est pas une feuille
    if (((*i)->pCitem) && ((*i)->pCitem->getArrayFils()) && (!(*i)->pCitem->getArrayFils()->empty()))
    {
      sMsg = "creerFilsArchetype() : Appel de creerFils" ;
      pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

      // Cr�ation d'un BBItem
      (*i)->creerFils() ;

      // Initialisation du BBItem
      //attribuer la patpathoarray correspondante � ce pFilsItem (donneGenetique)      //si pFilsItem->sEtiquette trouv�e
      string sEtiquette = (*i)->getItemLabel() ;

      sMsg = "creerFilsArchetype() : Etiquette " + sEtiquette ;
      pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

      // Chaque BBFilsItem a un vecteur de BBItem mais en g�n�ral, ce vecteur
      // contient un seul BBItem.
      if (!((*i)->VectorFils.empty()))
      {
        for (BBiterFils iter = (*i)->VectorFils.begin() ; iter != (*i)->VectorFils.end() ; iter++)        {
          sMsg = "creerFilsArchetype() : Avant donneGenetique()" ;
          pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

          donneGenetique((*iter), sEtiquette) ;

          sMsg = "creerFilsArchetype() : Apr�s donneGenetique() " + (*iter)->sLocalisation ;
          pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

          // On demande au BBItem de se cr�er par l'archetype en repartant du Citem du fils          (*iter)->creerArchetype((*i)->pCitem) ;
        }
      }
    }
  }

  sMsg = "creerFilsArchetype() : Sortie" ;
  pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  return 1 ;
}catch (...){
  erreur("Exception BBItem::creerFilsArchetype.", standardError, 0) ;
  return 0 ;
}
}
// -----------------------------------------------------------------------------// mise � jour du patpatho dans les cas ://    - Si le BBItem est rattach� purement � une fonction
//		- Si le BBItem n'est pas rattach� � une boite de dialogue, il active sa
// 			premi�re branche si il est en mode "automatique", il propose ses fils si
// 			il est en mode "manuel"
// -----------------------------------------------------------------------------
void
BBItem::MiseAjourPatpatho()
{
try
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	if (NULL == pPPTEnCours)
		return ;

/*
	NSPatPathoArray PPTMissingConcepts(pBigBoss->pContexte) ;
	if ((NULL != pParseur) && (false == pPPTEnCours->empty()))
  	PPTMissingConcepts = *pPPTEnCours ;
*/

	pPPTEnCours->vider() ;

	if (aBBItemFils.empty())
		return ;

	int colonne = 0 ;
	string sCodeSens ;
	VecteurRechercheSelonCritere VecteurSelonCritere(GUIDE) ;
	bool rechercher = false ;

	for (BBiter it = aBBItemFils.begin() ; it != aBBItemFils.end() ; it++)
	{
		// On fabrique le chemin indiqu� par le futur �l�ment
		if ((NULL == (*it)->getItemData()) || ('\0' == (*it)->getItemData()->chemin[0]))
		{
      string sFilsLabel = (*it)->getItemLabel() ;
			pSuper->getDico()->donneCodeSens(&sFilsLabel, &sCodeSens) ;
			VecteurSelonCritere.AjouteEtiquette(sCodeSens) ;
			rechercher = true ;
		}
	}
	if (rechercher)
		pSuper->getFilGuide()->chercheChemin(&sLocalisation, &VecteurSelonCritere, NSFilGuide::compReseau) ;

	bool trouve ;
	for (BBiter Iter = aBBItemFils.begin() ; Iter != aBBItemFils.end() ; Iter++)
	{
    string sFilsLabel = (*Iter)->getItemLabel() ;
		pSuper->getDico()->donneCodeSens(&sFilsLabel, &sCodeSens) ;

		if ((rechercher) && ((NULL == (*Iter)->getItemData()) || ('\0' == (*Iter)->getItemData()->chemin[0])))
			VecteurSelonCritere.SetData(sCodeSens, &trouve, (*Iter)->getItemData()) ;
		else
			trouve = true ;

		if (trouve)
		{
			if ((*Iter)->Actif())
			{
				colonne = 0 ;
				NSVectFatheredPatPathoArray* pPatpathoItem = (*Iter)->getPatPatho() ;

				if ((*Iter)->getItemData()->uniciteLesion()) //non multidialogue
				{
					if (!((*Iter)->estPlusZero()))
					{
						colonne = 1 ;
						AjouteEtiquette((*Iter)) ;
					}
					if (pPatpathoItem && (!(pPatpathoItem->empty())))
					{
						for (FatheredPatPathoIterVect j = pPatpathoItem->begin() ; j != pPatpathoItem->end() ; j++)
						{
							pPPTEnCours->ajouteVecteur((*j)->getPatPatho(), ORIGINE_PATH_PATHO + colonne) ;
							colonne = 1 ;
						}
					}
				}
				else
				{
          // si Iter est multidialogue, il faut dupliquer Iter autant de fois
          // qu'il a �t� cr�e en tant que multidialogue.
          // Exemple : this est PPAT
          //  Iter = PINQ9 (multidialogue)
          //    avec le patpatho suivantes : 	1) PIVG(0,0)
          //														      2) PIVD(0,0)
          //	on aura alors pour PPATT
          //     PINQ9(0,0)
          //        PIVG(1,1)
          //     PINQ9(2,0)
          //        PIVD(3,1)
					if (false == (*Iter)->estPlusZero())
					{
          	if (pPatpathoItem && (false == pPatpathoItem->empty()))
						{
							for (FatheredPatPathoIterVect j = pPatpathoItem->begin() ; j != pPatpathoItem->end() ; j++)
							{
								AjouteEtiquette((*Iter), string(""), (*j)->getFatherNode(), true) ;
								pPPTEnCours->ajouteVecteur((*j)->getPatPatho(), ORIGINE_PATH_PATHO + 1) ;
							}
            }
					}
					else
					{
						colonne = 0 ;
						if (pPatpathoItem && (!(pPatpathoItem->empty())))
						{
							for (FatheredPatPathoIterVect j = pPatpathoItem->begin() ; j != pPatpathoItem->end() ; j++)
							{
								pPPTEnCours->ajouteVecteur((*j)->getPatPatho(), ORIGINE_PATH_PATHO + colonne) ;
								colonne = 1 ;
							}
						}
					}
				}
			}
		}
	}

/*
	if (false == PPTMissingConcepts.empty())
	{
    // Killing all leaves that still exist in the new patpatho
    //
    // We suppose that this job has already been done by other archetypes
    // related BBItems, so that leaves that are controled by sub-levels have
    // already been managed
    //
    PatPathoIter it = PPTMissingConcepts.begin() ;
    for (; PPTMissingConcepts.end() != it; )
    {
    	// Is it a leaf?
      //
      PatPathoIter itFils = PPTMissingConcepts.ChercherPremierFils(it) ;
      if ((NULL == itFils) || (PPTMissingConcepts.end() == itFils))
      {
      	string sItemPath = PPTMissingConcepts.donneCheminItem(it) ;
        if (true == pPPTEnCours->CheminDansPatpatho(sItemPath))
        {
        	delete *it ;
          PPTMissingConcepts.erase(it) ;
        }
        else
        	it++ ;
      }
      else
      	it++ ;
    }
    //
    // Now that we have all the missing elements, we have to distinguish between
    // those nodes that were deleted (because they were available in the
    // archetype OR are "excluded" by other nodes available in the archetype)
    // and those nodes that are not handled by the archetype (we have to add
    // them back)
    //

  }
*/
}
catch (...)
{
	erreur("Exception BBItem::MiseAjourPatpatho.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// lors de la correction d'un CR le BBitem d�veloppe la bo�te qui contient la phrase � corriger
// -----------------------------------------------------------------------------
void
BBItem::Corriger()
{
  if (aBBItemFils.empty())
    return ;

  // Trouver le fils ayant dans sa patpatho l'�l�ment d'ID  = 1
  for (BBiter Iter = aBBItemFils.begin() ; Iter != aBBItemFils.end() ; Iter++)
  {
    if (!((*Iter)->PatPtahovide()))
    {
      NSVectFatheredPatPathoArray* pPatpathoItem = (*Iter)->getPatPatho() ;
      FatheredPatPathoIterVect     iterPath      = pPatpathoItem->begin() ;
      for ( ; iterPath != pPatpathoItem->end() ; iterPath++)
      {
        NSPatPathoArray* pPatPatho = (*iterPath)->getPatPatho() ;
        for (PatPathoIter it = pPatPatho->begin() ; pPatPatho->end() != it ; it++)
        {
          if ((*it)->ID == 1)
          {
            int k = developper(*Iter) ;
            if (k == 3)
            {
              BBItem* bbitem = *((*Iter)->VectorFils.begin()) ;
              //Iter en tant que BBItem
              bbitem->activer() ;
            }
            MiseAjourPatpatho() ;
          }
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------// Function     : int BBItem::activer()// Description  : Demande � la BBItem de se lancer : cr�er la boite de dialogue
//                ou lancer un processus
//						    Il serait tentant de g�rer � ce niveau la g�n�ration/mise �
//						    jour/destruction des l�sions lorsque le BBItem est cr�ateur.
//						    La diversit� de traitement des l�sions (unique/multiples...)
//						    nous oblige � les traiter plus bas (bonne id�e ?).
// Returns      : 1 si aucune branche ne poss�de cette �tiquette valeur de
//                retour de BBItem::developper(int numFils) sinon
// -----------------------------------------------------------------------------
int
BBItem::activer()
{
try
{
	bool bTourner ;
	int i ;
  BBCmdMessage BBMsg ;

  //en mode correction //on est pas au bout du chemin
  if (pBigBoss->Correction)
  {
    NSPatPathoArray PPT(pContexte) ;

		// trouver le fils ayant dans sa patpatho l'�l�ment d'ID  = 1
    for (BBiter Iter = aBBItemFils.begin() ; Iter != aBBItemFils.end() ; Iter++)
    {
      if (!((*Iter)->PatPtahovide()))
      {
        NSVectFatheredPatPathoArray* pPatpathoItem = (*Iter)->getPatPatho() ;
        FatheredPatPathoIterVect iterPath = pPatpathoItem->begin() ;
        for ( ; iterPath != pPatpathoItem->end() ; iterPath++)
        {
          NSPatPathoArray* pPatPatho = (*iterPath)->getPatPatho() ;
          for (PatPathoIter it = pPatPatho->begin() ; pPatPatho->end() != it ; it++)
          {
            if ((*it)->ID == 1)
            {
              // si d�calge nul alors ne pas d�velopper Iter, mais attribuer true � son bCorriger
              int k = developper(*Iter) ;
              if (k == 3)
              {
                if ((*Iter)->FilsProlongeable)
                {
                  if (!(*Iter)->VectorFils.empty())
                  {
                    BBItem* bbitem = *((*Iter)->VectorFils.begin()) ;
                    // Iter en tant que BBItem
                    bbitem->activer() ;
                  }
                }
              }
              MiseAjourPatpatho() ;
              return 0 ;
            }
          }
        }
      }
    }

    for (BBiter Iter = aBBItemFils.begin() ; Iter != aBBItemFils.end() ; Iter++)
    {
      if ((*Iter)->bCorriger)
      {
        pBigBoss->Correction = false ;
        PPT.vider() ;
        if ((false == (*Iter)->getItemData()->uniciteLesion()) && pPPTEnCours)
        {
          PatPathoIter it = pPPTEnCours->begin() ;

          for ( ; (it != pPPTEnCours->end()) && ((*it)->ID != 1) ; it++)
            ;
          if (it != pPPTEnCours->end())
            pPPTEnCours->ExtrairePatPatho(it, &PPT) ;
        }

        int m = developper(*Iter, &PPT) ;
        if (m != 0)
        {
          bool cherchePereOD = true ;
          BBItem* pere = (*Iter)->getItemFather() ;
          while (cherchePereOD)
          {
            if (!pere)
              cherchePereOD = false ;
            else
            {
              if (pere->ouvreDialog())
                cherchePereOD = false ;
              else
              {
                if (pere->pBBFilsPere)
                  pere = (pere->pBBFilsPere)->getItemFather() ;
                else
                  pere = 0 ;
              }
            }
          }
          if (pere)
            pere->activer() ;
        }
        MiseAjourPatpatho() ;
        return 0 ;
      }
    }
	}

	// Si le BBItem est rattach� � une boite de dialogue, on la cr�e
	if (lienDialogue())
  {
    if (pBBFilsPere)
      pBBFilsPere->lancerMultiDialogue() ;

    return creerDialogue() ;
	}

  BBiter ItFils ;
  string sLocalis, sEtiquet, sGag ;
  size_t pos ;
  bool	 bCheminTrouve ;

	// Si le BBItem est rattach� purement � une fonction, on l'ex�cute
	if (lienFonction())
  {
		// La fonction peut se comporter soit comme une boite de dialogue (et elle
    // retourne 0), soit comme un aiguillage, et elle choisi le premier fils actif
    if (pBigBoss->pileVide())
      bTourner = pNSFonction->execute(NSFCT_ACTIVE, &iFilsActif) ;
    else
      bTourner = true ;

    i = 0 ;
		while (bTourner)
		{
      if (pBigBoss->pileVide())
      {
        i = developper(aBBItemFils.donneNieme(iFilsActif - 1)) ;
				bTourner = pNSFonction->execute(NSFCT_AIGUILLE, &i) ;

        MiseAjourPatpatho() ;
      }
      else
        i = pBigBoss->depile(&BBMsg) ;

      if (bTourner)
      {
				switch (i)
				{
					case NSDLG_SUITE        : // passage � la suite
                                    iFilsActif++;
                                    // S'il n'y a pas de suivant : on sort par le bas
                                    if (aBBItemFils.donneNieme(iFilsActif - 1) == 0)
                                    {
                                      if (pBBFilsPere)
                                      {
                                        if (pBBFilsPere->PatPtahovide())
                                        {
                                          if (actifVide())
                                            pBBFilsPere->Active() ;
                                          else
                                            pBBFilsPere->Desactive() ;
                                        }
                                        else
                                          pBBFilsPere->Active() ;
                                      }
                                      return 0 ;
                                    }
                                    break ;

					case NSDLG_RETOUR       : // retour en arri�re
                                    iFilsActif-- ;
                                    // Si on est au d�but : on sort par le haut
                                    if (iFilsActif == 0)
                                      return -1 ;
                                    break ;

          case NSDLG_SORTIE_BAS   : // sortie par le bas
                                    if (pBBFilsPere)
                                    {
                                      if (pBBFilsPere->PatPtahovide())
                                      {
                                        if (actifVide())
                                          pBBFilsPere->Active() ;
                                        else
                                          pBBFilsPere->Desactive() ;
                                      }                                      else
                                        pBBFilsPere->Active() ;
                                    }
                                    return 0 ;

          case NSDLG_SORTIE_HAUT  : // sortie par le haut
               			                return -1 ;

          case NSDLG_ALLER_A      : // Traitement du message pour extraire la localisation et l'�tiquette � atteindre
                                    pos = BBMsg.sMessage.find(string(1, nodeSeparationMARK)) ;
                                    if ((pos != string::npos) && (pos < strlen(BBMsg.sMessage.c_str())))
                                    {
                                      sLocalis = string(BBMsg.sMessage, 0, pos) ;
                                      sEtiquet = string(BBMsg.sMessage, pos + 1, strlen(BBMsg.sMessage.c_str()) - pos - 1) ;

                                      ItFils = aBBItemFils.begin() ;

                                      bCheminTrouve = false ;

                                      // 3 cas :
                                      // 1) sLocalisation == sLocalis on lance l'�tiquette
                                      // 2) sLocalisation est au d�but de sLocalis et on lance l'�tiquette qui va dans la bonne direction
                                      // 3) sinon, on descend d'un cran
                                      if (sLocalisation == sLocalis)
                                      {
                                        int iBonFils = 1 ;

                                        for ( ; (ItFils != aBBItemFils.end()) && ((*ItFils)->getItemLabel() != sEtiquet) ; ItFils++)
                                          iBonFils++ ;
                                        if (ItFils != aBBItemFils.end())
                                        {
                                          iFilsActif = iBonFils ;
                                          bCheminTrouve = true ;
                                        }
                                      }
                                      else if ((strlen(sLocalisation.c_str()) < strlen(sLocalis.c_str())) && (string(sLocalis, 0, strlen(sLocalisation.c_str())) == sLocalisation))
                                      {
                                        int iBonFils = 1 ;

                                        // On cherche l'�tiquette qui va dans la bonne direction
                                        for ( ; (ItFils != aBBItemFils.end()) && (!bCheminTrouve) ; ItFils++)
                                        {
                                          iBonFils++ ;
                                          sGag = sLocalisation + (*ItFils)->getItemLabel() ;
                                          if ((strlen(sGag.c_str()) <= strlen(sLocalis.c_str())) && (string(sLocalis, 0, strlen(sGag.c_str())) == sGag))
                                            bCheminTrouve = true ;
                                        }
                                        if (ItFils != aBBItemFils.end())
                                        {
                                          iFilsActif = iBonFils ;
                                          bCheminTrouve = true ;
                                          pBigBoss->reEmpile(&BBMsg, false) ;
                                        }
                                      }
                                      // On rempile et on sort par le bas
                                      if (!bCheminTrouve)
                                      {
                                        pBigBoss->reEmpile(&BBMsg, false) ;
                                        if (pBBFilsPere)
                                        {
                                          if (pBBFilsPere->PatPtahovide())
                                          {
                                            if (actifVide())
                                              pBBFilsPere->Active() ;
                                            else
                                              pBBFilsPere->Desactive() ;
                                          }
                                          else
                                            pBBFilsPere->Active() ;
                                        }
                                        return 0 ;
                                      }
                                    }
                                    break ;

          default                 : if ((i >= NSDLGRETOUR_DIRECT) && (i < NSDLGRETOUR_FIN))
                  		              {
                                      // iFilsActif = i - NSDLGRETOUR_DIRECT + 1 ;
                                      bTourner = false ;
                  		              }
                  		              else if ((i > 0) && (aBBItemFils.donneNieme(i-1) != 0))
                  			              iFilsActif = i;
        }
      }
      else
      {
        if (pBBFilsPere)
        {
          if (pBBFilsPere->PatPtahovide())
          {
            if (actifVide())
              pBBFilsPere->Active() ;
            else
              pBBFilsPere->Desactive() ;
          }
          else
            pBBFilsPere->Active() ;
        }
      }
    }
    return i ;
	}

	// Si le BBItem n'est pas rattach� � une boite de dialogue, il active sa
  // premi�re branche si il est en mode "automatique", il propose ses fils si il
  // est en mode "manuel"
  if (aBBItemFils.empty())
    return 0 ;

  // Il est prudent de v�rifier qu'au moins un fils est "d�veloppable", sinon on
  // entre dans une boucle sans fin
  ItFils = aBBItemFils.begin() ;
  for ( ; ItFils != aBBItemFils.end() ; ItFils++)
    if ((*ItFils)->FilsProlongeable)
      break ;
  if (ItFils == aBBItemFils.end())
  {
    // On simule une sortie "par le bas"
    if (pBBFilsPere)
    {
      if (pBBFilsPere->PatPtahovide())
      {
        if (actifVide())
          pBBFilsPere->Active() ;
        else
          pBBFilsPere->Desactive() ;
      }
      else
          pBBFilsPere->Active();
    }
    return 0 ;
  }

	iFilsActif  = 1 ;
	bTourner    = 1 ;

	while (bTourner)
	{
    if (pBigBoss->pileVide())
    {
      i = developper(aBBItemFils.donneNieme(iFilsActif-1)) ;
      MiseAjourPatpatho() ;
    }
    else
      i = pBigBoss->depile(&BBMsg) ;

		switch (i)
		{
			case NSDLG_SUITE      : // passage � la suite
                              iFilsActif++ ;
                              // S'il n'y a pas de suivant : on sort par le bas
                              if (aBBItemFils.donneNieme(iFilsActif-1) == 0)
                              {
                                if (pBBFilsPere)
                                {
                                  if (pBBFilsPere->PatPtahovide())
                                  {
                                    if (actifVide())
                                      pBBFilsPere->Active() ;
                                    else
                                      pBBFilsPere->Desactive() ;
                                  }
                                  else                                    pBBFilsPere->Active() ;
                                }
                                return 0 ;
                              }
                              break ;

			case NSDLG_RETOUR     : // Retour en arri�re
                              iFilsActif-- ;
                              // Si on est au d�but : on sort par le haut
                              if (iFilsActif == 0)
                                return -1 ;
                              break ;

			case NSDLG_SORTIE_BAS : // Sortie par le bas
                              if (pBBFilsPere)
                              {
                                if (pBBFilsPere->PatPtahovide())
                                {
                                  if (actifVide())
                                    pBBFilsPere->Active() ;
                                  else
                                    pBBFilsPere->Desactive() ;
                                }
                                else
                                  pBBFilsPere->Active() ;
                              }
                              return 0 ;

			case NSDLG_SORTIE_HAUT  : // Sortie par le haut
         		                    return -1 ;

      case NSDLG_ALLER_A      : // Traitement du message pour extraire la localisation et l'�tiquette � atteindre
                                pos = BBMsg.sMessage.find(string(1, nodeSeparationMARK)) ;
                                if ((pos != string::npos) && (pos < strlen(BBMsg.sMessage.c_str())))
                                {
                                  sLocalis = string(BBMsg.sMessage, 0, pos) ;
                                  sEtiquet = string(BBMsg.sMessage, pos+1, strlen(BBMsg.sMessage.c_str())-pos-1) ;

                                  ItFils = aBBItemFils.begin() ;

                                  bCheminTrouve = false ;

                                  // 3 cas :
                                  // 1) sLocalisation == sLocalis on lance l'�tiquette
                                  // 2) sLocalisation est au d�but de sLocalis et on lance l'�tiquette qui va dans la bonne direction
                                  // 3) sinon, on descend d'un cran
                                  if (sLocalisation == sLocalis)
                                  {
                                    int iBonFils = 1 ;
                                    for ( ; (ItFils != aBBItemFils.end()) && ((*ItFils)->getItemLabel() != sEtiquet) ; ItFils++)
                                      iBonFils++ ;
                                    if (ItFils != aBBItemFils.end())
                                    {
                                      iFilsActif = iBonFils ;
                                      bCheminTrouve = true ;
                                    }
                                  }
               		                else if ((strlen(sLocalisation.c_str()) < strlen(sLocalis.c_str())) && (string(sLocalis, 0, strlen(sLocalisation.c_str())) == sLocalisation))
               		                {
               			                int iBonFils = 1 ;

                                    // On cherche l'�tiquette qui va dans la bonne direction
                                    for ( ; (ItFils != aBBItemFils.end()) && (!bCheminTrouve) ; ItFils++)
                                    {
                                      iBonFils++ ;
                                      sGag = sLocalisation + (*ItFils)->getItemLabel() ;
                                      if ((strlen(sGag.c_str()) <= strlen(sLocalis.c_str())) && (string(sLocalis, 0, strlen(sGag.c_str())) == sGag))
                                        bCheminTrouve = true ;
                                    }
                                    if (ItFils != aBBItemFils.end())
                                    {
                                      iFilsActif = iBonFils ;
                                      bCheminTrouve = true ;
                                      pBigBoss->reEmpile(&BBMsg, false) ;
                                    }
                                  }
                                  // On rempile et on sort par le bas
                                  if (!bCheminTrouve)
                                  {
                                    pBigBoss->reEmpile(&BBMsg, false) ;
                                    if (pBBFilsPere)
                                    {
                                      if (pBBFilsPere->PatPtahovide())                                      {                                        if (actifVide())
                                          pBBFilsPere->Active() ;                                        else
                                          pBBFilsPere->Desactive() ;
                                      }
                                      else
                                        pBBFilsPere->Active() ;
                                    }
                                    return 0 ;
                                  }
                                }
                                break ;

      default                 : if ((i >= NSDLGRETOUR_DIRECT) && (i < NSDLGRETOUR_FIN))
                	                iFilsActif = i - NSDLGRETOUR_DIRECT + 1 ;
                                /*
                                else if (i == NSDLGRETOUR_FIN)
                                {
                                  if(pBBFilsPere)
                                  {
                                    if(pBBFilsPere->PatPtahovide())
                                    {
                                      if (actifVide())
                                        pBBFilsPere->Active() ;
                                      else
                                        pBBFilsPere->Desactive() ;
                                    }
                                    else
                                      pBBFilsPere->Active() ;
                                  }
                                  return 0 ;
                                }
                                */
                                else if ((i > 0) && (aBBItemFils.donneNieme(i-1) != 0))
                	                iFilsActif = i ;
    }
  }
  return 1 ;
}
catch (...)
{
  erreur("Exception BBItem::activer.", standardError, 0) ;
  return 1 ;
}
}

// -----------------------------------------------------------------------------// Function     : int BBItem::developper(string sEtiquette)// Arguments    : sEtiquette -> �tiquette de la branche � d�velopper
// Description  : Demande � l'arborescence de se prolonger (usuellement pour
//                ouvrir une nouvelle boite de dialogue)
// Returns      : 1 si aucune branche ne poss�de cette �tiquette valeur de
//                retour de BBItem::developper(int numFils) sinon
// -----------------------------------------------------------------------------
int
BBItem::developper(string sEtiquette)
{
try
{
  if (aBBItemFils.empty())
    return 1 ;

  BBiter i ;

	// Recherche du BBFilsItem qui pilote cette branche
  for (i = aBBItemFils.begin() ; (i != aBBItemFils.end()) && ((*i)->getItemLabel() != sEtiquette) ; i++)
    ;

	// Si on a trouv� la branche, on lui demande de se d�velopper
	if (i != aBBItemFils.end())
		return developper(*i) ;
	return 1 ;
}
catch (...)
{
  erreur("Exception BBItem::developper 1.", standardError, 0) ;
  return 1 ;
}
}

// -----------------------------------------------------------------------------
// Function     : int BBItem::developper(BBFilsItem* pFilsIt)
// Arguments    : BBFilsItem* pFils -> pointeur sur le fils � d�velopper
// Description  : Demande � l'arborescence de se prolonger (usuellement pour
//                ouvrir une nouvelle boite de dialogue).
//                Il faut alors : - cr�er un BBItem � partir du fils choisi
//                                - lancer BBItem.creer()
//                                - lancer BBItem.activer()
// Returns      : 0 si tout a bien fonctionn�
//						    1 si on a eu un probl�me
//						    2 si la branche n'a pas de prolongation
//						    3 si la branche a d�j� �t� prolong�e
// -----------------------------------------------------------------------------
int
BBItem::developper(BBFilsItem* pFilsIt, NSPatPathoArray* pPPT, int indexFils)
{
try
{
	int i ;

  if ((!pFilsIt) || (!(pFilsIt->VectorFils.empty())))
    return 3 ;

  //for (BBiterFils iter = pFilsIt->VectorFils.begin() ; iter != pFilsIt->VectorFils.end() ; iter++)
  //	if ((*iter))
  //    return 3 ;


	// La branche est-elle prolongeable ?

	//if (!(pFilsIt->estProlongeable()))  //PENSER A RETOURNER 1 EN CAS DE PB FICHIER DANS ESTPRO...
  if (!(pFilsIt->FilsProlongeable))
    return 2 ;

	//si pFilsIt actif et vide, on le d�sactive
  if (pFilsIt->Actif() && (pFilsIt->getItemTransfertData()->pTransPatpatho->empty()))
	{
    // Sauf si on est en mode correction
    if (!(pFilsIt->bCorriger))
    {
      pFilsIt->Desactive() ;
      return 0 ; // iRetourDlg =0
    }
  }

  string sEtiquette = pFilsIt->getItemLabel() ;

	//*(pFilsIt->pDonnees) = *(pBigBoss->pBBFiche->pDonnees) ;
  pFilsIt->creerFils(indexFils) ;

  int iRetActiv = 0 ;
  // int ok = 0 ;
  // multidialogue
  if ((false == pFilsIt->getItemData()->uniciteLesion()) && (pFilsIt->bCorriger) && pPPT)
  {
    // chercher parmi les multiples BBitem celui dont le pPPTEnCours est pPPT
    // sa bo�te de dialogue sera affich�e , alors que celles de ses fr�res sera cach�es
    bool continuer = true ;
    BBiterFils iter = pFilsIt->VectorFils.begin() ;
    while((iter != pFilsIt->VectorFils.end()) && (continuer))
    {      (*iter)->iRetourDlg = 0 ;
      PatPathoIter it= (*iter)->pPPTEnCours->begin() ;
      PatPathoIter jt = pPPT->begin() ;
      bool bEgalite = true ;
      bool bContinue = true ;
      while((it != (*iter)->pPPTEnCours->end()) && (jt != pPPT->end()) && bContinue)
      {
        if (!(*((*it)->pDonnees) == *((*jt)->pDonnees)))
        {
          bEgalite  = false ;
          bContinue = false ;
        }
        else
        {
          it++ ;
          jt++ ;
        }
      }

      if (!bEgalite)
        (*iter)->bCacher = true ; // cr�er la NSDialog et la cacher
      iter++ ;
    }
	}

  for (BBiterFils iter = pFilsIt->VectorFils.begin() ; iter != pFilsIt->VectorFils.end() ; iter++)
  {
    // Simplifie les �critures
    BBItem* pNewFils = (*iter) ;

    // Donne sa filiation au nouvel �l�ment
    donneGenetique(pNewFils, sEtiquette) ;

    // On demande au BBItem de se cr�er (et de cr�er ses fils qui correspondent � la m�me bo�te de dialogue)
    i = pNewFils->creer() ;
    if (i == 0)
    {
      iRetActiv = pNewFils->activer() ;
      if ((pNewFils->iProfondeur < pBigBoss->iSeuilSauve) && (pNewFils->pPPTEnCours))
        pBigBoss->sauvegarde() ;
    }
	}

  //cr�e la boite multidialogue
  if ((pFilsIt->pNsMultiDialog))
  {
    int exexute = pFilsIt->pNsMultiDialog->Execute() ;
    if (exexute != IDCANCEL)
    {
      if ((pFilsIt->PatPtahovide()))
      {
        if (pFilsIt->actifVide())
          pFilsIt->Active() ;
        else
          pFilsIt->Desactive() ;
      }
      else
        pFilsIt->Active() ;
    }
	}

  if (!(pFilsIt->pNsMultiDialog))
    pFilsIt->tuerFils() ;

  // Demande � l'�ventuelle boite de dialogue de r�percuter les modifs
  if (_pNSDialog)
    _pNSDialog->rafraichitControles() ;

	return iRetActiv ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception BBItem::developper 2 : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
  return 1 ;
}
catch (...)
{
  erreur("Exception BBItem::developper 2.", standardError, 0) ;
  return 1 ;
}
}

// -----------------------------------------------------------------------------
// Function     : int BBItem::developper(BBFilsItem* pFilsIt)
//	              cas de la consultation
// Arguments    : BBFilsItem* pFils -> pointeur sur le fils � d�velopper
// Description  : Demande � l'arborescence de se prolonger (usuellement pour
//                ouvrir une nouvelle boite de dialogue).
//                Il faut alors : - cr�er un BBItem � partir du fils choisi
//                                - lancer BBItem.creer()
//                                - lancer BBItem.activer()
// Returns      : 0 si tout a bien fonctionn�
//						    1 si on a eu un probl�me
//						    2 si la branche n'a pas de prolongation
//						    3 si la branche a d�j� �t� prolong�e
// -----------------------------------------------------------------------------
int
BBItem::developperConsultation(BBFilsItem* pFilsIt)
{
try
{
  if (!pFilsIt)
    return 1 ;

  if (!((pFilsIt->VectorFils.empty())))
    for (BBiterFils iter = pFilsIt->VectorFils.begin() ; iter != pFilsIt->VectorFils.end() ; iter++)
      if ((*iter))
        return 3 ;

	// La branche est-elle prolongeable ?
//  if (!(pFilsIt->FilsProlongeable))
//	  return 2 ;

  //si pFilsIt actif et vide, on le d�sactive
  if (pFilsIt->Actif() && (pFilsIt->getItemTransfertData()->pTransPatpatho->empty()))
  {
    pFilsIt->Desactive() ;
    return 0 ;  // iRetourDlg =0
  }

  int iRes = 0 ;
  pFilsIt->creerFils() ;
  string sEtiquette = pFilsIt->getItemLabel() ;

  if (pFilsIt->VectorFils.empty())
    return 0 ;

  for (BBiterFils iter = pFilsIt->VectorFils.begin() ; iter != pFilsIt->VectorFils.end() ; iter++)
  {
    // Simplifie les �critures
    BBItem* pNewFils = (*iter) ;

    // Donne sa filiation au nouvel �l�ment
    donneGenetique(pNewFils, sEtiquette) ;

    // On demande au BBItem de se cr�er (et de cr�er ses fils qui correspondent � la m�me bo�te de dialogue)
    int iResult = pNewFils->creer() ;
    if (iResult == 1)
      return 1 ;

    // rustine 28/11/02 RS
    //if (sEtiquette == string("ZRIKC1"))    if (pNewFils->ouvreArchetype())      iRes = pNewFils->activer() ;  }

  return iRes ;}
catch (...)
{
  erreur("Exception BBItem::developperConsultation.", standardError, 0) ;
  return 3 ;
}
}

// -----------------------------------------------------------------------------
// Initialise le BBItem
// -----------------------------------------------------------------------------
void
BBItem::donneGenetique(BBItem* pNewFils, string sEtiquette)
{
  NSSuper* pSuper = pContexte->getSuperviseur() ;
  string sMsg = string("donneGenetique() : Entr�e -> Etiquette = ") + sEtiquette ;
  pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  // Initialisation con�ue pour les Fils guides
  if (strncmp(pNewFils->pDonnees->nomDialogue, "__IDEM", 6) == 0)
    pNewFils->_sNomDlg = _sNomDlg ;
  else
    pNewFils->_sNomDlg = string(pNewFils->pDonnees->nomDialogue) ;

  // Dans le cas d'un Arch�type, et faute de Fil guide, on reste dans la m�me fen�tre
  if ((string("") == pNewFils->_sNomDlg) && (sIdArchetype != ""))
    pNewFils->_sNomDlg = _sNomDlg ;

  // on place ici l'h�ritage de l'id d'archetype des BBItem pour le cas des
  // archetypes (les dialogues se passent la chaine vide) car donneGenetique est
  // appel�e pour chaque nouveau BBItem fils dans la m�thode BBItem::creerFilsArchetype()
  pNewFils->sIdArchetype = sIdArchetype ;

  // Calcul de la nouvelle localisation
  string sCodeSens, sEtiquettePere = string("") ;
  pSuper->getDico()->donneCodeSens(&sEtiquette, &sCodeSens) ;

  sMsg = "donneGenetique() : Avant r�cup de sEtiquettePere" ;
  pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  if (pBBFilsPere)
  {
    string sFilsLabel = pBBFilsPere->getItemLabel() ;
    pSuper->getDico()->donneCodeSens(&sFilsLabel, &sEtiquettePere) ;
  }

  sMsg = string("donneGenetique() : sEtiquettePere = ") + sEtiquettePere ;
  pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;
  sMsg = string("donneGenetique() : sLocalisation = ") + sLocalisation ;
  pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

  if (estPlusZero())
  {
    if (strlen(sLocalisation.c_str()) > strlen(sEtiquettePere.c_str()))
      pNewFils->sLocalisation = string(sLocalisation, 0, strlen(sLocalisation.c_str()) - strlen(sEtiquettePere.c_str())) ;
    else
      pNewFils->sLocalisation = "" ;

    if ((pNewFils->sLocalisation != "") && (sEtiquettePere == ""))
      pNewFils->sLocalisation += string(1,cheminSeparationMARK) ;

    pNewFils->sLocalisation += sCodeSens ;
  }
  else
    pNewFils->sLocalisation = sLocalisation + string(1,cheminSeparationMARK) + sCodeSens ;

  sMsg = "donneGenetique() : Sortie" ;
  if (estPlusZero())
    sMsg += "+00+00" ;
  pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;
}

// -----------------------------------------------------------------------------
// Function     : int BBItem::creerDialogue()
// Description  : Cr�ation de l'�l�ment d'interface (boite de dialogue...) qui
//                correspond � ce BBItem. Si l'�l�ment est g�n�rateur de l�sion
//                unique, la gestion de la l�sion se fait � ce niveau.
// Returns      : 0 si tout a bien fonctionn�
//						    1 si on a eu un probl�me
//						    2 si ce BBItem n'est pas ouvreur de bo�te de dialogue
//						    3 si une boite de dialogue est d�j� ouverte
//						    4 si La DLL sp�cifique est introuvable
// -----------------------------------------------------------------------------
// En cas de lancement d'un NSDialog::Execute(), retourne 0 pour OK et -1 pour
// CANCEL (cf NSDialog)
// -----------------------------------------------------------------------------
int
BBItem::creerDialogue()
{
try
{
  NSSuper* pSuper = pContexte->getSuperviseur() ;

  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	string sMsg = "creerDialogue() : Entr�e" ;
	pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

	// On teste si le BBItem est ouvreur et s'il poss�de un nom de dialogue
  string Nom ;
  bool   bTabControl = false ;

	if (!ouvreDialog())
		return 2 ;

	if ((string("") == _sNomDlg) || (string::npos == _sNomDlg.find_first_not_of(string(" "))))
  {
    if ((pParseur) && (pParseur->pArchetype) && (pParseur->pArchetype->getDialogBox(sLang) == NULL))
      return 2 ;
  }

	// On v�rifie qu'un dialogue n'est pas d�j� cr��
	if (_pNSDialog)
		return 3 ;

	// On cr�e un objet NSDialog
  if (pDonnees->fichierDialogue[0] != '\0')
    if (!pBigBoss->CreerNouveauModule(pDonnees->fichierDialogue))
      return 4 ;

  NsMultiDialog* pMulti = 0 ;

  if (pBBFilsPere)
    pMulti = pBBFilsPere->pNsMultiDialog ;

  TModule* pModule ;

  if (strcmp(pDonnees->fichierDialogue, "") != 0)
  {
    pModule = pBigBoss->TrouverModule(pDonnees->fichierDialogue) ;
    if (!pModule)
      return 1 ;
  }
  else
    pModule = NULL ;

  pSuper->afficheStatusMessage("Cr�ation du dialogue") ;

  if ((false == ouvreArchetype()) || (string("__AUTO") != _sNomDlg))
  {
    if (string("__AUTO") == _sNomDlg)#ifdef __OB1__      _pNSDialog = new NSDialog(pContexte, donneFenetre(), this, pModule, pMulti) ;
#else
			_pNSDialog = new NSDialog(pContexte, donneFenetre(), this, pModule, pMulti, pBigBoss->IsInitFromBbk()) ;
#endif
    else if (string("") == _sNomDlg)
    {
      // on sait d�j� ici qu'on poss�de un dialogbox dans l'archetype
      if (pParseur->pArchetype->getDialogBox(sLang)->getTabControl() == NULL)
      {
        if (pParseur->pArchetype->getFunction() == "Controled")
#ifdef __OB1__
          _pNSDialog = new NSRCDialog(pContexte, donneFenetre(), this, pModule, pMulti) ;
#else
					_pNSDialog = new NSRCDialog(pContexte, donneFenetre(), this, pModule, pMulti, pBigBoss->IsInitFromBbk()) ;
#endif
        else
#ifdef __OB1__
          _pNSDialog = new NSDialog(pContexte, donneFenetre(), this, pModule, pMulti) ;
#else
					_pNSDialog = new NSDialog(pContexte, donneFenetre(), this, pModule, pMulti, pBigBoss->IsInitFromBbk()) ;
#endif
      }
      else
        bTabControl = true ;
    }
    else#ifdef __OB1__      _pNSDialog = new NSDialog(pContexte, donneFenetre(), _sNomDlg.c_str(), 0, this, pModule, pMulti) ;
#else
			_pNSDialog = new NSDialog(pContexte, donneFenetre(), _sNomDlg.c_str(), 0, this, pModule, pMulti, pBigBoss->IsInitFromBbk()) ;
#endif
  }
  // Boite de dialogue non modale : pour le dialogue de l�sion multiples ou les  // Archetypes lorsqu'ils sont en BBItem lanceur (les Arch�types de sous-niveau  // sont modaux)  // if ((pMulti) || (ouvreArchetype() && (this == pBigBoss->pBBItem)))  if ((pMulti) || (!bModalDialog))
  {
    if (ouvreArchetype() && (string("__AUTO") == _sNomDlg))    {      nsarcDialog* pDlg = new nsarcDialog(donneFenetre(), pContexte, pParseur) ;      pDlg->Create() ;    }    else if (bTabControl)
    {
#ifdef __OB1__
      NSTabWindow* pDlg = new NSTabWindow(pContexte, donneFenetre(), this, pModule, pMulti) ;
#else
			NSTabWindow* pDlg = new NSTabWindow(pContexte, donneFenetre(), this, pModule, pMulti, pBigBoss->IsInitFromBbk()) ;
#endif
      pDlg->Create() ;
      // on r�f�rence pNSDialog pour servir + tard � la NSCQVue
      _pNSDialog = pDlg ;
    }
    else
      _pNSDialog->Create() ;
    //if (bCacher)    //	pNSDialog->ShowWindow(SW_HIDE) ;
  }
  else
  {
    //if (bCacher)
    //  pNSDialog->ShowWindow(SW_HIDE);

    pSuper->afficheStatusMessage("Ouverture du dialogue") ;

    if (bTabControl)
    {
#ifdef __OB1__
      NSTabWindow* pDlg = new NSTabWindow(pContexte, donneFenetre(), this, pModule, pMulti) ;
#else
			NSTabWindow* pDlg = new NSTabWindow(pContexte, donneFenetre(), this, pModule, pMulti, pBigBoss->IsInitFromBbk()) ;
#endif
      _pNSDialog = pDlg ;
      pDlg->Execute() ;
    }
    else
      _pNSDialog->Execute() ;

    if (bCacher)
      _pNSDialog->ShowWindow(SW_HIDE) ;

    if (_pNSDialog)
    {
      if (pBBFilsPere)
      {
        if (pBBFilsPere->PatPtahovide())
        {
          if ((actifVide()) && (iRetourDlg == 0))  // OK
            pBBFilsPere->Active() ;
          else
            pBBFilsPere->Desactive() ;
        }
        else
          pBBFilsPere->Active() ;
      }

      // On fait le delete � la fin, de fa�on � ce que le BBItem sache encore
      // � quel dialogue il est attach� pendant les Active() ou Desactive()
      delete _pNSDialog ;
      _pNSDialog = 0 ;
    }
  }

	sMsg = "creerDialogue() : Sortie" ;
	pSuper->trace(&sMsg, 1, NSSuper::trSubDetails) ;

	return iRetourDlg ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception BBItem::creerDialogue : ") ;
  if (string("") != _sNomDlg)
  	sErr += _sNomDlg + string(" ") ;
  sErr += e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
  return 0 ;
}
catch (...)
{
  erreur("Exception BBItem::creerDialogue.", standardError, 0) ;
  return 0 ;
}
}

// -----------------------------------------------------------------------------// Function     : int BBItem::gereRien()// Description  : Gestion de l'�l�ment __RIEN
//						    Cet �l�ment permet de cr�er/d�truire des l�sions pour
//                lorsqu'il n'y a pas de boite de dialogue associ�e.
// Returns      : 0 si tout a bien fonctionn�
//						    1 si on a eu un probl�me
// -----------------------------------------------------------------------------
int
BBItem::gereRien()
{
	return 0 ;
}

// -----------------------------------------------------------------------------
// enleve les 0 de la string : 00023 devient 23 -- 00.23 devient 0.23
// -----------------------------------------------------------------------------
string
BBItem::EnleveZeo(string* pDollar)
{
  if (NULL == pDollar)
  {
    *pDollar = string("") ;
    return (*pDollar) ;
  }

  if (string("0") == *pDollar)
    return (*pDollar) ;

  bool bIsNegative = false ;

  // There is a minus sign
  //
  size_t iPos = pDollar->find("-") ;
  if (NPOS != iPos)
  {
    // If it isn't the first char, that's bad
    //
    if (iPos > 0)
    {
      *pDollar = string("") ;
      return (*pDollar) ;
    }

    // If the entry is limited to this minus char, that's bad too
    //
    if (strlen(pDollar->c_str()) == 1)
    {
      *pDollar = string("") ;
      return (*pDollar) ;
    }

    // If there are multiple minus char, that's also bad
    //
    size_t iPos = pDollar->find("-", 1) ;
    if (NPOS != iPos)
    {
      *pDollar = string("") ;
      return (*pDollar) ;
    }

    bIsNegative = true ;
    *pDollar = string(*pDollar, 1, strlen(pDollar->c_str()) - 1) ;
  }

  char cZero = (*pDollar)[0] ;
  size_t longueur =  strlen(pDollar->c_str()) ;
  while ((cZero == '0') &&  ((*pDollar)[1] != '.'))
  {
    (*pDollar) = string((*pDollar), 1, longueur) ;
    cZero = (*pDollar)[0] ;
  }

  if (bIsNegative)
    *pDollar = string("-") + *pDollar ;

  if (string("-0") == *pDollar)
    *pDollar = string("0") ;

  return (*pDollar) ;
}

// -----------------------------------------------------------------------------
// le vecteur est vide on ajoute seulement l'�tiquette
// ranger le patpatho de pFils dans pPPTEnCours
// traite les cas suivants :  1)	pFils : VDIAM1/MSYST1/2KG001/�N0;01
//											          mettre dans pPPTEnCours : VDIAM1 	MSYST1
//																							            2KG001 	�N0;01
//                            2)  pFils : 2KG001/�N0;01
//											          mettre dans pPPTEnCours : 2KG001 	�N0;01
//
//									          3)  pFils : VDIAM1
//                                mettre dans pPPTEnCours : VDIAM1
// -----------------------------------------------------------------------------
// Refabrication de la patpathoinfo du noeud fils � partir de ses donn�es de transfert <br>
// Ajout de la patpathoInfo au pPPTEnCours <br>
// Rebuilding the patpathoInfo of the child node from it's transfert data <br>
// Adding the pathpatoInfo to pPPTEnCours
// -----------------------------------------------------------------------------
void
BBItem::AjouteEtiquette(BBFilsItem* pFils, string sArc, NSPatPathoInfo* pPreviousNode, bool bForceEmptyId)
{
try
{
	if ((NULL == pFils) || (NULL == pFils->getItemTransfertData()) || (NULL == pFils->getItemTransfertMsg()))
		return ;

  Message* pTranfertMsg = pFils->getItemTransfertMsg() ;
	Message Msg(*pTranfertMsg) ;

  if (NULL != pPreviousNode)
  {
    Msg.SetTreeID(pPreviousNode->getDoc()) ;
    Msg.SetNoeud(pPreviousNode->getNodeID()) ;
  }
  else if (bForceEmptyId)
  {
    Msg.SetTreeID(string("")) ;
    Msg.SetNoeud(string("")) ;
  }

	size_t posit ;
	string sLabel = "" ;
	string sNoeud = "" ;
	string sChampEdit = "" ;
	string sUnite = "" ;
	// On met de c�t� les constituants du message
	sChampEdit 		   	  = Msg.GetComplement() ;
	string sCertitude  	= Msg.GetCertitude() ;
	string sPluriel    	= Msg.GetPluriel() ;
	string sVisible    	= Msg.GetVisible() ;
	string sStockNoeud 	= Msg.GetNoeud() ;
	string sTexteLibre  = Msg.GetTexteLibre() ;
	string sRights		  = Msg.GetNodeRight() ;

	// pTransfertMessage a un int�ret vide alors initialser cet int�ret avec "A"
	if (Msg.GetInteret() == "")
  {
		Msg.SetInteret(string("A")) ;
    pTranfertMsg->SetInteret(string("A")) ;
  }

	// Initialisation de l'archetype
	if ((string("") != sArc) && (Msg.GetArchetype() != sArc))
  {
		Msg.SetArchetype(sArc) ;
    pTranfertMsg->SetArchetype(sArc) ;
  }

	sLabel = pFils->getItemLabel() ;

	// texte libre �?????
	if (sLabel == string("�?????"))
	{
		if (pPPTEnCours)
			pPPTEnCours->ajoutePatho(sLabel, &Msg, ORIGINE_PATH_PATHO + 0) ;
		return ;
	}

	// Est-ce une �tiquette multiple ?
	posit = sLabel.find(string(1, cheminSeparationMARK)) ;

	// Un / positionn� � la fin : on l'enl�ve
	if (posit == strlen(sLabel.c_str()) - 1)
	{
		pFils->setItemLabel(string(sLabel, 0, strlen(sLabel.c_str()) - 1)) ;
		posit = string::npos ;
	}

	// Pas une �tiquette multiple, traitement simple
	if (posit == string::npos)
	{
		sLabel = pFils->getItemLabel() ;
		if (pPPTEnCours)
			pPPTEnCours->ajoutePatho(sLabel, &Msg, ORIGINE_PATH_PATHO + 0) ;
		return ;
	}

	// Une �tiquette multiple peut juste signifier un compl�ment forc� ($...)
	if ((pFils->getItemLabel())[posit+1] == '$')
	{
		sLabel = string(pFils->getItemLabel(), 0, posit) ;
		size_t posit_debut = posit + 2 ;
		if ((posit_debut < strlen(pFils->getItemLabel().c_str())) && (pPPTEnCours))
		{
			string sComplValue = string(pFils->getItemLabel(), posit_debut, strlen(pFils->getItemLabel().c_str()) - posit_debut) ;

      // Numerical value
      if (sLabel.find("�N") != string::npos)
      {
      	strip(sComplValue, stripLeft, '0') ;
        if (sComplValue == "")
        	sComplValue = "0" ;
      }

      pTranfertMsg->SetComplement(sComplValue) ;
			Msg.SetComplement(sComplValue) ;
			pPPTEnCours->ajoutePatho(sLabel, &Msg, ORIGINE_PATH_PATHO + 0) ;
		}
		return ;
	}

  string sEtiqRoot        = "" ;
  string sEtiqFormat      = "" ;
  string sEtiqUnite       = "" ;
  string sEtiqComplement  = "" ;
  string sEtiqCertitude   = "" ;
  string sEtiqPluriel     = "" ;

  string sEtiqLabel       = pFils->getItemLabel() ;
  posit = sEtiqLabel.find(string(1, cheminSeparationMARK)) ;

  while (posit != string::npos)
  {
    string sElement = string(sEtiqLabel, 0, posit) ;
    sEtiqLabel      = string(sEtiqLabel, posit + 1, strlen(sEtiqLabel.c_str()) - posit - 1) ;

    if      (sElement[0] == '2')
      sEtiqUnite  = sElement ;
    else if (sElement[0] == '�')
      sEtiqFormat = sElement ;
    else if (sElement[0] == '$')
      sEtiqComplement = string(sElement, 1, strlen(sElement.c_str()) - 1) ;
    else if (sElement[0] == 'W')
    {
      if      (string(sElement, 0, 3) == "WCE")
        sEtiqCertitude  = sElement ;
      else if (string(sElement, 0, 3) == "WPL")
        sEtiqPluriel    = sElement ;
    }
    else
      sEtiqRoot = sElement ;

    posit = sEtiqLabel.find(string(1, cheminSeparationMARK)) ;
  }
  if      (sEtiqLabel[0] == '2')
    sEtiqUnite  = sEtiqLabel ;
  else if (sEtiqLabel[0] == '�')
    sEtiqFormat = sEtiqLabel ;
  else if (sEtiqLabel[0] == '$')
    sEtiqComplement = string(sEtiqLabel, 1, strlen(sEtiqLabel.c_str())-1) ;
  else if (sEtiqLabel[0] == 'W')
  {
    if      (string(sEtiqLabel, 0, 3) == "WCE")
      sEtiqCertitude  = sEtiqLabel ;
    else if (string(sEtiqLabel, 0, 3) == "WPL")
      sEtiqPluriel    = sEtiqLabel ;
  }
  else
    sEtiqRoot = sEtiqLabel ;

  if (sChampEdit == "")
  {
    pTranfertMsg->SetComplement(sEtiqComplement) ;
    Msg.SetComplement(sEtiqComplement) ;
  }

  pTranfertMsg->SetUnit(sEtiqUnite) ;
  Msg.SetUnit(sEtiqUnite) ;

  if (sEtiqCertitude.find(string("WCEA0")) == string::npos) //ne pas mettre dans certitude WCEA0 : pr�sent 100%
  {
    pTranfertMsg->SetCertitude(sEtiqCertitude) ;
    Msg.SetCertitude(sEtiqCertitude) ;
  }

  pTranfertMsg->SetPluriel(sEtiqPluriel) ;
  Msg.SetPluriel(sEtiqPluriel) ;

  if (string("") != sEtiqRoot)
    sEtiqFormat = sEtiqRoot ;

	// Verify that there is not useless '0' on left
	if (string(sEtiqFormat, 0, 2) == string("�N"))
	{
		sChampEdit = Msg.GetComplement() ;
    EnleveZeo(&sChampEdit) ;
    pTranfertMsg->SetComplement(sChampEdit) ;
    Msg.SetComplement(sChampEdit) ;
	}

	pPPTEnCours->ajoutePatho(sEtiqFormat, &Msg, ORIGINE_PATH_PATHO + 0) ;
}
catch (...)
{
	erreur("Exception BBItem::AjouteEtiquette.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Refabrication de la patpathoinfo du noeud fils � partir de ses donn�es de transfert
// Rebuilding the patpathoinfo of the child node from it's transfert data
// -----------------------------------------------------------------------------
void
BBItem::AjouteTmpEtiquette(NSPatPathoArray *pTempPatPatho, BBFilsItem* pFils, NSPatPathoInfo* pPreviousNode)
{
try
{
  if (NULL == pTempPatPatho)
    return ;

  if ((NULL == pFils) || (NULL == pFils->getItemTransfertData()))
    return ;

  Message* pTmpMsg = pFils->getItemTransfertData()->pTmpTransfertMessage ;
  if (NULL == pTmpMsg)
    return ;

  Message Msg(*pTmpMsg) ;
  if (NULL != pPreviousNode)
  {
    Msg.SetTreeID(pPreviousNode->getDoc()) ;
    Msg.SetNoeud(pPreviousNode->getNodeID()) ;
  }

  string sNoeud = "" ;
  string sUnite = "" ;

  // On met de c�t� les constituants du message
  string sChampEdit 	= Msg.GetComplement() ;
  string sCertitude   = Msg.GetCertitude() ;
  string sPluriel     = Msg.GetPluriel() ;
  string sVisible     = Msg.GetVisible() ;
  string sStockNoeud  = Msg.GetNoeud() ;
  string sTexteLibre  = Msg.GetTexteLibre() ;
  //
  // pTransfertMessage a un int�ret vide alors initialser cet int�ret avec "A"
  //
  if (pTmpMsg->GetInteret() == "")
  {
    pTmpMsg->SetInteret(string("A")) ;
    Msg.SetInteret(string("A")) ;
  }

  string sLabel = pFils->getItemLabel() ;

  //texte libre �?????
  if (sLabel == string("�?????"))
  {
    pTempPatPatho->ajoutePatho(sLabel, &Msg, ORIGINE_PATH_PATHO + 0) ;
    return ;
  }

  // Est-ce une �tiquette multiple ?
  size_t posit = sLabel.find(string(1, cheminSeparationMARK)) ;
  // Un / positionn� � la fin : on l'enl�ve
  if (posit == strlen(sLabel.c_str()) - 1)
  {
    pFils->setItemLabel(string(sLabel, 0, strlen(sLabel.c_str()) - 1)) ;
    posit = string::npos ;
  }

  // Pas une �tiquette multiple, traitement simple
  if (posit == string::npos)
  {
    sLabel = pFils->getItemLabel() ;
    pTempPatPatho->ajoutePatho(sLabel, &Msg, ORIGINE_PATH_PATHO + 0) ;
    return ;
  }

  // Une �tiquette multiple peut juste signifier un compl�ment forc� ($...)
  if ('$' == (pFils->getItemLabel())[posit + 1])
  {
    size_t posit_debut = posit + 2 ;
    if (posit_debut < strlen(pFils->getItemLabel().c_str()))
    {
      string sComplValue = string(pFils->getItemLabel(), posit_debut, strlen(pFils->getItemLabel().c_str()) - posit_debut) ;
      pTmpMsg->SetComplement(sComplValue) ;
      Msg.SetComplement(sComplValue) ;
      pTempPatPatho->ajoutePatho(sLabel, &Msg, ORIGINE_PATH_PATHO + 0) ;
    }
    return ;
  }

  string sEtiqRoot        = "" ;
  string sEtiqFormat      = "" ;
  string sEtiqUnite       = "" ;
  string sEtiqComplement  = "" ;
  string sEtiqCertitude   = "" ;
  string sEtiqPluriel     = "" ;

  string sEtiqLabel       = pFils->getItemLabel() ;
  posit = sEtiqLabel.find(string(1, cheminSeparationMARK)) ;

  while (posit != string::npos)
  {
    string sElement = string(sEtiqLabel, 0, posit) ;
    sEtiqLabel      = string(sEtiqLabel, posit + 1, strlen(sEtiqLabel.c_str()) - posit - 1) ;

    if      (sElement[0] == '2')
      sEtiqUnite  = sElement ;
    else if (sElement[0] == '�')
      sEtiqFormat = sElement ;
    else if (sElement[0] == '$')
      sEtiqComplement = string(sElement, 1, strlen(sElement.c_str()) - 1) ;
    else if (sElement[0] == 'W')
    {
      if      (string(sElement, 0, 3) == "WCE")
        sEtiqCertitude  = sElement ;
      else if (string(sElement, 0, 3) == "WPL")
        sEtiqPluriel    = sElement ;
    }
    else
      sEtiqRoot = sElement ;

    posit = sEtiqLabel.find(string(1, cheminSeparationMARK)) ;
  }
  if      (sEtiqLabel[0] == '2')
    sEtiqUnite  = sEtiqLabel ;
  else if (sEtiqLabel[0] == '�')
    sEtiqFormat = sEtiqLabel ;
  else if (sEtiqLabel[0] == '$')
    sEtiqComplement = string(sEtiqLabel, 1, strlen(sEtiqLabel.c_str()) - 1) ;
  else if (sEtiqLabel[0] == 'W')
  {
    if      (string(sEtiqLabel, 0, 3) == "WCE")
      sEtiqCertitude  = sEtiqLabel ;
    else if (string(sEtiqLabel, 0, 3) == "WPL")
      sEtiqPluriel    = sEtiqLabel ;
  }
  else
    sEtiqRoot = sEtiqLabel ;

  if (sChampEdit == "")
  {
    pTmpMsg->SetComplement(sEtiqComplement) ;
    Msg.SetComplement(sEtiqComplement) ;
  }

  pTmpMsg->SetUnit(sEtiqUnite) ;
  Msg.SetUnit(sEtiqUnite) ;

  if (sEtiqCertitude.find(string("WCEA0")) == string::npos) //ne pas mettre dans certitude WCEA0 : pr�sent 100%
  {
    pTmpMsg->SetCertitude(sEtiqCertitude) ;
    Msg.SetCertitude(sEtiqCertitude) ;
  }

  pTmpMsg->SetPluriel(sEtiqPluriel) ;
  Msg.SetPluriel(sEtiqPluriel) ;

  if (sEtiqRoot != "")
    sEtiqFormat = sEtiqRoot ;

  pTempPatPatho->ajoutePatho(sEtiqFormat, &Msg, ORIGINE_PATH_PATHO + 0) ;
}
catch (...)
{
  erreur("Exception BBItem::AjouteEtiquette.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------// Function     : bool BBItem::okFermerDialogue()// Description  : Fonction appel�e par la boite de dialogue qui souhaite se
//                fermer et demande l'autorisation de le faire. Demande aux
//                BBFilsItem de se pr�parer � la fermeture.
// Returns      : true si la boite de dialogue � l'autorisation de se fermer
//						    false sinon
// -----------------------------------------------------------------------------
bool
BBItem::okFermerDialogue(bool rapatrier, bool bDetacheControle)
{
try
{
	bool retour = true ;
	NSVectFatheredPatPathoArray* pPatpathoItem ;
  string sNomXml ;

  // Si le BBItem est ouvreur d'archetype, il transmet le nom du fichier
  // � ses fils (racines de l'archetype) par AjouteEtiquette
  if (ouvreArchetype())
    sNomXml = string(pDonnees->fils) ;
  else
    sNomXml = "" ;

	// Si on demande un rapatriement : mise � z�ro du codon
  if (rapatrier)
		bMiseAJour = true ;
	else
		bMiseAJour = false ;

  if (rapatrier == true)
  {
    if (pPPTEnCours)
      pPPTEnCours->vider() ;

    if (!(aBBItemFils.empty()))
    {
      //pour tous les fils
			for (BBiter i = aBBItemFils.begin() ; i != aBBItemFils.end() ; i++)
      {
        if ((*i)->okFermerDialogue(rapatrier, bDetacheControle))
        {
          if ( (*i)->Actif())
          {
            // cas particulier : si sEtiquettePatpatho contient �C --> prendre les donn�es vider le compl�ment
            if (((*i)->getItemLabel().find(string("�C;")) != string::npos) || ((*i)->getItemLabel().find(string("/�C;")) != string::npos))
              (*i)->getItemTransfertMsg()->SetComplement(string("")) ;

            pPatpathoItem = (*i)->getPatPatho() ;

            // si le vecteur est vide on ajoute seulement  l'�tiquette
            // if (pPatpathoItem->empty())
            if ((*i)->PatPtahovide())
              AjouteEtiquette((*i), sNomXml) ;

            // sinon, pour chaque �l�ment du vecteur , on ajoute l'�tiquette et cet �l�ment
            else if (pPPTEnCours)
            {
              if ((*i)->estPlusZero())
              {
                if (!(pPatpathoItem->empty()))
                  for (FatheredPatPathoIterVect j = pPatpathoItem->begin() ; j != pPatpathoItem->end() ; j++)
                    pPPTEnCours->ajouteVecteur((*j)->getPatPatho(), ORIGINE_PATH_PATHO + 0) ;
              }
              else if (!(pPatpathoItem->empty()))
              {
                for (FatheredPatPathoIterVect j = pPatpathoItem->begin() ; j != pPatpathoItem->end() ; j++)
                {
                  AjouteEtiquette((*i), sNomXml, (*j)->getFatherNode(), true) ;
                  pPPTEnCours->ajouteVecteur((*j)->getPatPatho(), ORIGINE_PATH_PATHO + 1) ;
                }
              }
            }
          }
        }
      }
    }
  }

  // PA 16/05/09
  // if (NULL != pTempPPT)
  //  *pTempPPT = *pPPTEnCours ;

  mergePPTEnCours(bDetacheControle) ;
  return retour ;
}
catch (...)
{
  erreur("Exception BBItem::okFermerDialogue.", standardError, 0) ;
  return true ;
}
}

void
BBItem::detacheControle()
{
  if (aBBItemFils.empty())
    return ;

  for (BBiter i = aBBItemFils.begin() ; i != aBBItemFils.end() ; i++)
    (*i)->detacheControle() ;
}

void
BBItem::mergePPTEnCours(bool bKillMerge)
{
try
{
  if (NULL == pPPTMerge)
    return ;

  if (pPPTMerge->empty())
  {
    delete pPPTMerge ;
    pPPTMerge = 0 ;
    return ;
  }

  if (pPPTEnCours->empty())
  {
    *pPPTEnCours = *pPPTMerge ;
    delete pPPTMerge ;
    pPPTMerge = 0 ;
    return ;
  }

  NSVectPatPathoArray Vect ;
  PatPathoIter iterRoot = pPPTMerge->begin() ;
  pPPTMerge->ExtraireVecteurPatPathoFreres(iterRoot, &Vect) ;

  string sElemLex, sSens ;
  PatPathoIter iterCourant, iterLast ;
  int iColBase = (*iterRoot)->getColonne() ;

  PatPathoIterVect iterVect = Vect.begin() ;
  while (Vect.end() != iterVect)
  {
    // Le type de chaque frere est donn� par le code lexique de sa racine
    iterRoot = (*iterVect)->begin() ;
    sElemLex = (*iterRoot)->getLexique() ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    // on supprime tous les fils de code sSens dans pPPTEnCours
    iterCourant = pPPTEnCours->ChercherItem(sSens) ;
    iterLast = NULL ;

    while ((iterCourant != NULL) && (pPPTEnCours->end() != iterCourant))
    {
      if ((*iterCourant)->getColonne() == iColBase)
      {
        pPPTEnCours->SupprimerFils(iterCourant) ;
        pPPTEnCours->SupprimerItem(iterCourant) ;

        iterLast = iterCourant ;

        if ((NULL == iterCourant) || (pPPTEnCours->end() == iterCourant))
          break ;

        if ((*iterCourant)->getLexique() != sElemLex)
          iterCourant = pPPTEnCours->ChercherItem(sSens, true, iterCourant) ;
      }
      else // cas item trouv� ailleurs qu'en colonne 0
        iterCourant = pPPTEnCours->ChercherItem(sSens, true, iterCourant) ;
    }

    // on ins�re le nouveau fils de la patpatho de merge
    if ((NULL != iterLast) && (pPPTEnCours->end() != iterLast))
      // s'il existait un fils : on le r��crit � son ancienne position
      // NB : les fils doivent en principe �tre uniques
      pPPTEnCours->InserePatPatho(iterLast, *iterVect, 0, true) ;
    else
      // insertion en queue
      pPPTEnCours->InserePatPatho(pPPTEnCours->end(), *iterVect, 0, true) ;

    iterVect++ ;
  }

  // RAZ de pPPTMerge
  if (bKillMerge)
  {
    delete pPPTMerge ;
    pPPTMerge = 0 ;
  }
}
catch (...)
{
  erreur("Exception BBItem::mergePPTEnCours.", standardError, 0) ;
}
}

void
BBItem::rapatrieTmpPpt(NSPatPathoArray *pTempPatPatho, size_t iLevel)
{
try
{
  if (NULL == pTempPatPatho)
    return ;

  // PA 16/05/09
  // pTempPatPatho->vider() ;

  if (aBBItemFils.empty())
    return  ;

  // bool retour = true;
  NSVectFatheredPatPathoArray* pPatpathoItem ;

  //pour tous les fils
  for (BBiter i = aBBItemFils.begin() ; i != aBBItemFils.end() ; i++)
  {
    NSPatPathoArray SonTempPatPatho(pContexte) ;

    // PA 18/05/09 (*i)->rapatrieTmpPpt(pTempPatPatho) ;
    if ((*i)->Actif())
    {
      // cas particulier : si sEtiquettePatpatho contient �C --> prendre les donn�es vider le compl�ment
      if (((*i)->getItemLabel().find(string("�C;")) != string::npos) ||
          ((*i)->getItemLabel().find(string("/�C;")) != string::npos))
      {
        if (((*i)->getItemTransfertData()) && ((*i)->getItemTransfertData()->pTmpTransfertMessage))
          (*i)->getItemTransfertData()->pTmpTransfertMessage->SetComplement(string("")) ;
      }

      // This son is not "expanded"; just take stored information
      //
      if ((*i)->VectorFils.empty())
      {
        // pPatpathoItem = (*i)->getTmpPatho() ;
        pPatpathoItem = (*i)->getPatPatho() ;

        //si le vecteur est vide on ajoute seulement  l'�tiquette
        //if (pPatpathoItem->empty())
        // if ((*i)->TmpPptvide())
        if ((*i)->PatPtahovide())
          AjouteTmpEtiquette(&SonTempPatPatho, (*i)) ;

        // sinon, pour chaque �l�ment du vecteur , on ajoute
        // l'�tiquette et cet �l�ment
        else
        {
          if ((*i)->estPlusZero())
          {
            if (false == pPatpathoItem->empty())
              for (FatheredPatPathoIterVect j = pPatpathoItem->begin() ; j != pPatpathoItem->end() ; j++)
                SonTempPatPatho.ajouteVecteur((*j)->getPatPatho(), ORIGINE_PATH_PATHO + 0) ;
          }
          else if (false == pPatpathoItem->empty())
          {
            for (FatheredPatPathoIterVect j = pPatpathoItem->begin() ; j != pPatpathoItem->end() ; j++)
            {
              AjouteTmpEtiquette(&SonTempPatPatho, (*i)) ;
              SonTempPatPatho.ajouteVecteur((*j)->getPatPatho(), ORIGINE_PATH_PATHO + 1) ;
            }
          }
        }
      }
      // This son is "expanded"; get fresh information
      //
      else
      {
        size_t iSubLevel = 0 ;
        if (false == (*i)->estPlusZero())
        {
          AjouteTmpEtiquette(&SonTempPatPatho, (*i)) ;
          iSubLevel++ ;
        }
        (*i)->rapatrieTmpPpt(&SonTempPatPatho, iSubLevel) ;
      }
    }
    // Not "activated" but in duty; get current state
    else if (false == (*i)->VectorFils.empty())
    {
      // First step: is there some data there?
      NSPatPathoArray LocalTempPatPatho(pContexte) ;
      (*i)->rapatrieTmpPpt(&LocalTempPatPatho, 0) ;

      if (false == LocalTempPatPatho.empty())
      {
        if (false == (*i)->estPlusZero())
          AjouteTmpEtiquette(&SonTempPatPatho, (*i)) ;

        if (false == SonTempPatPatho.empty())
          SonTempPatPatho.InserePatPathoFille(&(SonTempPatPatho.back()), &LocalTempPatPatho) ;
        else
          SonTempPatPatho = LocalTempPatPatho ;
      }                                   
    }

    if (false == SonTempPatPatho.empty())
      pTempPatPatho->InserePatPatho(pTempPatPatho->end(), &SonTempPatPatho, iLevel) ;
  }
  return ;
}
catch (...)
{
  erreur("Exception BBItem::rapatrieTmpPpt.", standardError, 0) ;
  return ;
}
}

// -----------------------------------------------------------------------------// fermeture d'une bo�te de dialogue// -----------------------------------------------------------------------------
void
BBItem::CmOkFermer(NSDialog* pDialog)
{
  if (NULL == pDialog)
    return ;

  donneRetourDlg(0) ;
  pDialog->CmOk() ;
  delete pDialog ;
  pDialog = 0 ;
  
  if (pBBFilsPere)
  {
    if (pBBFilsPere->PatPtahovide())
    {
      if (actifVide())
        pBBFilsPere->Active() ;
      else
        pBBFilsPere->Desactive() ;
    }
    else
      pBBFilsPere->Active() ;
  }
}

// -----------------------------------------------------------------------------// fermeture d'une bo�te de dialogue// -----------------------------------------------------------------------------
void
BBItem::CmCancelFermer(NSDialog* pDialog)
{
  if (!pDialog)
    return ;

	donneRetourDlg(-1) ;
	okFermerDialogue(false) ;
	pDialog->Destroy(IDCANCEL) ;
	pDialog = 0 ;
}

// -----------------------------------------------------------------------------// Function     : void BBItem::ctrlNotification(BBFilsItem* pFilsItem, string* pIdentite, int etatInitial, int etatSouhaite, Message* pMessage, int indexFils)// Description  : R�ponse � la notification d'activation d'un contr�le
// Arguments    : sIdentite 		-> coordonn�es du contr�le
//						    etatInitial		-> �tat du contr�le avant activation
//						    etatSouhaite  -> �tat final d�sir�
//						    message				-> informations compl�mentaires
//                indexFils     -> index du fils de pFilsItem � d�velopper
// Returns      : Rien
// -----------------------------------------------------------------------------
void
BBItem::ctrlNotification(BBFilsItem* pFilsItem, string* /*pIdentite*/, int /*etatInitial*/, int etatSouhaite, Message* pMessage, int indexFils)
{
	int k ;

  if (pFilsItem == 0)    return ;

  // TRAITEMENT DES TREEVIEW

  if (etatSouhaite == BF_DELETE) //  TreeView 	{
    //pour chacun des BBItem fils
    pFilsItem->DestructionManuelle(pMessage) ;
    //enlever pFilsItem de le liste des fils de son p�re
    if (!(aBBItemFils.empty()))
    {
      BBiter it = aBBItemFils.begin() ;
      for (it = aBBItemFils.begin() ; (it != aBBItemFils.end()) && ((*it) != pFilsItem) ; it++)
        ;
      if (it != aBBItemFils.end())
      {
        delete (*it) ;
        aBBItemFils.erase(it) ;
      }
    }
    //si le p�re(this) n'a plus de fils il faut le d�sactiver
    if (aBBItemFils.empty())
      if (!actifVide())
        pBBFilsPere->Desactive() ;
    return ;
  }

	// Si le fils est terminal, on laisse le contr�le faire � sa guise
  if (!(pFilsItem->FilsProlongeable))
	{
    if (pFilsItem->getItemTransfertData())
    {
      // Le contr�le se met lui m�me � jour
      pFilsItem->getItemTransfertData()->activeControle(etatSouhaite, pMessage) ;

      // Puis met � jour sa structure de transfert
      pFilsItem->getItemTransfertData()->Transfer(tdGetData) ;
    }

		// Si le contr�le d�sirait se s�lectionner, on d�sactive ses fr�res incompatibles
		if (pFilsItem->Actif())
			pFilsItem->Active() ;
    else
      pFilsItem->Desactive() ;

		// Cas particulier de l'�l�ment cr�ateur de l�sion non ouvreur de dialogue
		// (par exemple champ Edit) - s'il �tait ouvreur de dialogue, la l�sion
		// serait trait�e par la fonction creerDialogue()
		return ;
	}

	// Si le fils n'est pas terminal, on analyse
	// Premier cas : le contr�le d�sire se s�lectionner
  if (etatSouhaite == BF_CHECKED)
	{
		// On d�veloppe la branche ou �ventuellement la sous-branche indiqu�e par indexFils (si indexFils >= 0)
		k = developper(pFilsItem, 0, indexFils) ;

    // Si le contr�le est p�re d'un autre contr�le situ� dans la m�me boite
    // de dialogue, developper retourne une erreur 3, il faut g�rer ce
    // contr�le comme un contr�le terminal, puisque c'est � l'utilisateur
    // d'instancier (ou non) le fils.
    if ((k == 3) && (pFilsItem->getItemTransfertData()))
    {
      pFilsItem->getItemTransfertData()->activeControle(etatSouhaite, pMessage) ;
      pFilsItem->getItemTransfertData()->Transfer(tdGetData) ;
    }

		// Si le contr�le a r�ussi � se s�lectionner, on d�truit les incompatibles
		if (pFilsItem->Actif())
			pFilsItem->Active() ;
    else
      pFilsItem->Desactive() ;
    }

	// Deuxi�me cas : le contr�le d�sire se d�selectionner
  // Si c'est un controle "ON/OFF" (radiobouton, checkbox), cel� veut
  // simplement dire qu'il �tait d�j� coch� et que l'utilisateur a cliqu�
  // dessus. On a alors deux cas dans pPatPatho :
  //				1) L'�l�ment n'a pas de fils et on le laisse se d�selectionner
  //				2) L'�l�ment a des fils et il doit se d�velopper
	if (etatSouhaite == BF_UNCHECKED)
	{
    if (pFilsItem->PatPtahovide())
    {
      pFilsItem->Desactive() ;
      if (pFilsItem->getItemTransfertData())
        pFilsItem->getItemTransfertData()->activeControle(etatSouhaite, pMessage) ;
    }
    else
    {
			// On d�veloppe la branche
			k = developper(pFilsItem) ;

      // Si le contr�le est p�re d'un autre contr�le situ� dans la m�me boite
      // de dialogue, developper retourne une erreur 3, il faut g�rer ce
      // contr�le comme un contr�le terminal, puisque c'est � l'utilisateur
      // d'instancier (ou non) le fils.
      if ((k == 3) && (pFilsItem->getItemTransfertData()))
      {
        pFilsItem->getItemTransfertData()->activeControle(etatSouhaite, pMessage) ;
        pFilsItem->getItemTransfertData()->Transfer(tdGetData) ;
      }

			// Si le contr�le a r�ussi � se s�lectionner, on d�truit les incompatibles
      if (pFilsItem->Actif())
				pFilsItem->Active() ;
      else
        pFilsItem->Desactive() ;
    }
	}

	// Transmission de son �tat au contr�le
  if (pFilsItem->getItemTransfertData())
  {
    if (pFilsItem->Actif())
      pFilsItem->getItemTransfertData()->activeControle(BF_CHECKED, pMessage) ;
    else
      pFilsItem->getItemTransfertData()->activeControle(BF_UNCHECKED, pMessage) ;
  }
}

// -----------------------------------------------------------------------------// le BBItem d�truit tous ses fils// -----------------------------------------------------------------------------
void
BBItem::DestructionManuelle(Message* pMessage)
{
  if (aBBItemFils.empty())
    return ;

  for (BBiter i = aBBItemFils.begin() ; i != aBBItemFils.end() ; i++)
    (*i)->DestructionManuelle(pMessage) ;
}

// -----------------------------------------------------------------------------
// Function     : int BBItem::DetruireExclus(int iRef)
// Description  : Destruction des contr�les incompatibles avec le contr�le qui vient d'etre s�lectionn�
// Arguments    : pointeur sur BBFilsItem
// Returns      : Rien
// Comment      : pFilsIt->Exclusion = aBBItemExclu[iRef]
// -----------------------------------------------------------------------------
void
BBItem::DetruireExclus(BBFilsItem* pFilsIt)
{
  if (!pFilsIt)
    return ;

	vector<string *>::iterator i ;
  BBiter iter ;

  // traitement sp�cial des BBFilsItem contr�lant un EditLexique
  // ils doivent demander � leur p�re (de type �C0;020) cr�ateur de desactiver ses fr�res
  if (pFilsIt->getItemFather() && pFilsIt->getItemFather()->pBBFilsPere)
	{
    string sIdentite = pFilsIt->getItemFather()->pBBFilsPere->getItemLabel() ;
    if ((sIdentite.find(string("�C;")) != string::npos) || (sIdentite.find(string("/�C;")) != string::npos))
      pFilsIt->getItemFather()->pBBFilsPere->getItemFather()->DetruireExclus(pFilsIt->getItemFather()->pBBFilsPere) ;
	}

  if (pFilsIt->Exclusion.aExclusion.empty())
    return ;

	for (i = pFilsIt->Exclusion.aExclusion.begin() ; i != pFilsIt->Exclusion.aExclusion.end() ; i++)
	{
    if (**i != pFilsIt->getItemLabel())
    {
      for (iter = aBBItemFils.begin() ; (iter != aBBItemFils.end()) && ((*iter)->getItemLabel() != **i) ; iter++)
        ;

      if (iter != aBBItemFils.end())
      {
        if (string("") != (*iter)->getItemLabel())
        {
          (*iter)->DesactiveFils() ;
          (*iter)->Desactive() ;

          if ((*iter)->getItemTransfertData()->pControle)
            (*iter)->getItemTransfertData()->activeControle(BF_UNCHECKED, (*iter)->getItemTransfertMsg()) ;
        }
      }
    }
	}
}

bool
BBItem::isExcluded(BBFilsItem *pFilsIt1, BBFilsItem *pFilsIt2)
{
  if ((NULL == pFilsIt1) || (NULL == pFilsIt2))
    return false ;

  if (pFilsIt1->Exclusion.aExclusion.empty())
    return false ;

  vector<string *>::iterator i ;
	for (i = pFilsIt1->Exclusion.aExclusion.begin() ; i != pFilsIt1->Exclusion.aExclusion.end() ; i++)
    if (**i == pFilsIt2->getItemLabel())
      return true ;

  return false ;
}
// -----------------------------------------------------------------------------// D�sactive tous les fils, mais conserve les patpathos en l'�tat// -----------------------------------------------------------------------------
void
BBItem::DesactiveFils()
{
  if (aBBItemFils.empty())
    return ;

  for (BBiter iter = aBBItemFils.begin() ; iter != aBBItemFils.end() ; iter++)
  {
    (*iter)->DesactiveFils() ;
    (*iter)->Desactive() ;

    if (((*iter)->getItemTransfertData()) && ((*iter)->getItemTransfertData()->pControle))
      (*iter)->getItemTransfertData()->activeControle(BF_UNCHECKED, (*iter)->getItemTransfertMsg()) ;
  }
}

// -----------------------------------------------------------------------------
// D�sactive tous les fils et vide les patpathos
// -----------------------------------------------------------------------------
void
BBItem::RemetAZero()
{
  if (aBBItemFils.empty())
    return ;

  // if (pPPTEnCours)
  //	pPPTEnCours->vider();

  for (BBiter iter = aBBItemFils.begin() ; iter != aBBItemFils.end() ; iter++)
  {
    (*iter)->DesactiveFils() ;
    if ((*iter)->getPatPatho())
      (*iter)->getPatPatho()->vider() ;
    (*iter)->RemetAZero() ;
  }
}

// -----------------------------------------------------------------------------// D�sactive tous les fils et vide les patpathos// -----------------------------------------------------------------------------
void
BBItem::Redeveloppe()
{
	if (_pNSDialog)
    _pNSDialog->Destroy() ;

  okFermerDialogue(false) ;

  activer() ;}

void
BBItem::Redispatche()
{
  DispatcherPatPatho() ;  for (BBiter iter = aBBItemFils.begin() ; iter != aBBItemFils.end() ; iter++)
    (*iter)->Redispatche() ;
}


void
BBItem::ActivePere(BBFilsItem* pFilsIt)
{
  if (!pFilsIt)
    return ;

	DetruireExclus(pFilsIt);
  if (pBBFilsPere)
	{
    // Attention : si on ne teste que dansMemeDialogue, il y a un bug
    // (retour vers pr�ambule dans �cho-coeur efface les donn�es descriptives)
    if ((_sNomDlg == pBBFilsPere->getItemFather()->_sNomDlg) || dansMemeDialogue(pBBFilsPere->getItemFather()))
    {
      if (pBBFilsPere->getItemTransfertData())
        pBBFilsPere->getItemTransfertData()->Active() ;
      if (pBBFilsPere->getItemFather())
        pBBFilsPere->getItemFather()->ActivePere(pBBFilsPere) ;

      if ((pBBFilsPere->getItemTransfertData()) && (pBBFilsPere->getItemTransfertData()->pControle))
        pBBFilsPere->getItemTransfertData()->activeControle(BF_CHECKED, pBBFilsPere->getItemTransfertMsg()) ;
    }
	}
}


voidBBItem::DesactivePereFictif(BBFilsItem* pFilsIt)
{
  if (!pFilsIt)
    return ;

  // bool tourner = true ;
  if (pFilsIt->getItemTransfertData())
    pFilsIt->getItemTransfertData()->Desactive() ;

  if ((pBBFilsPere) && (pBBFilsPere->getItemFather()))
  {
    // Si on n'est pas en mode correction, on d�sactive r�cursivement
    // les p�res qui ne sont pas li�s � des �l�ments de dialogue

    // En mode correction, les boites de dialogue interm�diaires ne sont
    // pas ouvertes ; il faut limiter la r�action en chaine en v�rifiant
    // qu'on est bien dans le cadre d'une
    //if ((!(pBigBoss->Correction)) || (dansDialogue()))
    if (dansDialogue())
    {
      if ((dansMemeDialogue(pBBFilsPere->getItemFather())) &&
          (NULL == pBBFilsPere->getItemTransfertData()->pControle))
        pBBFilsPere->getItemFather()->DesactivePereFictif(pBBFilsPere) ;
    }
  }
}


// -----------------------------------------------------------------------------// Function     : int BBItem::Initialiser()// Description  : R�partition du codon entre les BBFilsItem de fa�on r�cursive
// Returns      : 0 si tout a bien fonctionn�, 1 si on a eu un probl�me
// -----------------------------------------------------------------------------
int
BBItem::Initialiser()
{
	// Si le tableau de fils est vide, on sort imm�diatement
	if (aBBItemFils.empty())
		return 1 ;

  for (BBiter iter = aBBItemFils.begin() ; iter != aBBItemFils.end() ; iter++)
    (*iter)->Initialiser() ;

  return 0 ;
}


// -----------------------------------------------------------------------------// Function     : int BBItem::InitialiserSeparateur()// Description  : R�partition du codon entre les BBFilsItem quand il y a des s�parateurs
// Returns      : 0 si tout a bien fonctionn�, 1 si on a eu un probl�me
// -----------------------------------------------------------------------------
int
BBItem::InitialiserSeparateur()
{
	return 0 ;
}


// -----------------------------------------------------------------------------// Function     : int BBItem::InitialiserNumerique()// Description  : R�partition du codon entre les BBFilsItem quand il y n'y a pas de s�parateur
// Returns      : 0 si tout a bien fonctionn�, 1 si on a eu un probl�me
// -----------------------------------------------------------------------------
int
BBItem::InitialiserNumerique()
{
  return 0 ;
}


// -----------------------------------------------------------------------------
// Function     : BBFilsItem* BBItem::ChercheFils(string sIdentite, string sCheminParcouru)
// Description  : Recherche le BBFilsItem qui, pour la fen�tre en cours, correspond � un groupe et une �tiquette donn�e
// Retours      : un pointeur sur le BBFilsItem si on l'a trouv�, 0 sinon
// -----------------------------------------------------------------------------
BBFilsItem*
BBItem::ChercheFils(string sIdentite, string sCheminParcouru)
{
  if (true == aBBItemFils.empty())
    return NULL ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;

  string sCheminPossible ;

  string pCodeSenssIdentite ;
  string pCodeSenssCheminParcouru ;

  string sIter ;

	// Si aucun fils ne correspond directement, on cherche r�cursivement dans les BBItems qui leurs sont attach�s
	BBFilsItem* pBBFilsIt ;
	BBItem*		pBBIt ;

	for (BBiter iter = aBBItemFils.begin() ; iter != aBBItemFils.end() ; iter++)
	{
		pSuper->getDico()->donneCodeSens(&sCheminParcouru, &pCodeSenssCheminParcouru) ;
		pSuper->getDico()->donneCodeSens(&sIdentite, &pCodeSenssIdentite) ;
    string sFilsLabel = (*iter)->getItemLabel() ;
		pSuper->getDico()->donneCodeSens(&sFilsLabel, &sIter) ;

		if (pCodeSenssCheminParcouru == "")
			sCheminPossible = sIter ;
		else
			sCheminPossible = pCodeSenssCheminParcouru + string(1,cheminSeparationMARK) + sIter ;

		if ((sCheminPossible == pCodeSenssIdentite) && (NULL == (*iter)->getItemTransfertData()->pControle))
			return(*iter) ;
    if (sCheminPossible == string(pCodeSenssIdentite, 0, strlen(sCheminPossible.c_str())))
    {
      if (!((*iter)->VectorFils.empty()))
      {
        for (BBiterFils iterfils = (*iter)->VectorFils.begin() ; iterfils != (*iter)->VectorFils.end() ; iterfils++)
        {
          pBBIt = (*iterfils) ;
          if (pBBIt)
          {
            //pBBFilsIt = pBBIt->ChercheFils(pCodeSenssIdentite, sCheminPossible);
            pBBFilsIt = pBBIt->ChercheFils(sIdentite, sCheminPossible) ;
            if (pBBFilsIt)
              return pBBFilsIt ;
          }
        }
      }
    }
  }

	// Si on est encore l�, c'est qu'on n'a rien trouv�
	return NULL ;
}


// -----------------------------------------------------------------------------// Function     : TWindow * BBItem::donneFenetre()// Description  : Recherche le pointeur sur la fen�tre m�re de la bo�te de
//                dialogue � ouvrir (premi�re fen�tre rencontr�e chez les anc�tres)
// Returns      : le pointeur
// -----------------------------------------------------------------------------
TWindow *
BBItem::donneFenetre()
{
	// Si on est � l'origine, on d�pend directement de la fen�tre principale
	// (Attention dansDialogue() d�pend de cette valeur)

  // if (sLocalisation.find(cheminSeparationMARK) == string::npos)
  if (NULL == pBBFilsPere)
	{
		if (_pView && _pView->IsWindow())
    	return (TWindow*) _pView ;
    else
    	return pContexte->GetMainWindow() ;
	}

	// Si le p�re d�pend d'une boite de dialogue, on renvoie son pointeur	if (pBBFilsPere->getItemFather()->getDialog())
		return (TWindow*)pBBFilsPere->getItemFather()->getDialog() ;

	// Sinon on recherche r�cursivement	return (pBBFilsPere->getItemFather()->donneFenetre()) ;
}


bool
BBItem::dansDialogue()
{
	if (donneFenetre() == pContexte->GetMainWindow())
    return false ;
  else
    return true ;
}


// -----------------------------------------------------------------------------
// Ce BBItem et *pAutre sont-ils dans le m�me dialogue ?
// Rappel : si un BBItem est dans un Arch�type, sIdArchetype est l'ID de l'Arch.
//          si l'Archetype est li� � un RC dans une dll, szNomDlg est non vide
//          si l'Arch�type contient ses contr�les, szNomDlg est vide)
//          si le BBItem provient d'un Fil guide non lanceur d'Arch�type,
//          alors sIdArchetype est vide, mais pas szNomDlg
// -----------------------------------------------------------------------------
// Are this BBItem and *pAutre in the same dialog
// -----------------------------------------------------------------------------
bool
BBItem::dansMemeDialogue(BBItem *pAutre)
{
  if (!pAutre)
    return false ;

  // 1. Cas des archetypes
  if (((sIdArchetype != "") || (pAutre->sIdArchetype != "")) && (sIdArchetype == pAutre->sIdArchetype))
    return true ;

  // 2. Cas des dialogues
  if (((string("") != _sNomDlg) || (string("") != pAutre->_sNomDlg)) && (pAutre->_sNomDlg == _sNomDlg))
    return true ;

  return false ;
}


bool
BBItem::estPlusZero()
{
  if (!pDonnees)
    return false ;

  return (pDonnees->getLevelShift() == string("+00+00")) ;
}


// -----------------------------------------------------------------------------
// Function     : int BBItem::actifVide()
// Description  : Annonce si le BBItem est (ou non) activ� m�me si son codon
//						    est vide (sous niveaux non obligatoires)
// Returns      : 1 si le BBItem est activ�, 0 sinon
// -----------------------------------------------------------------------------
bool
BBItem::actifVide()
{
	return (pDonnees->actifVide()) ;
}

// -----------------------------------------------------------------------------// Function     : int BBItem::uniciteLesion()// Description  : Annonce si la l�sion est (ou non) unique
// Returns      : true si la l�sion est unique, false sinon
// -----------------------------------------------------------------------------
bool
BBItem::uniciteLesion()
{
	return (pDonnees->uniciteLesion()) ;
}

// -----------------------------------------------------------------------------
// Function     : int BBItem::lienDialogue()
// Description  : Annonce si le BBItem est (ou non) rattach� � une boite de dialogue
// Retours      : 1 si le BBItem est rattach�, 0 sinon
// -----------------------------------------------------------------------------
bool
BBItem::lienDialogue()
{
	if (string("__CROS") == _sNomDlg)
		return false ;

	if ((string("") != _sNomDlg) && (string::npos != _sNomDlg.find_first_not_of(string(" "))))
		return true ;

  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  if ((pParseur) && (pParseur->pArchetype) && (pParseur->pArchetype->getDialogBox(sLang) != NULL))    return true ;	return false ;}

// -----------------------------------------------------------------------------// Function     : int BBItem::lienFonction()// Description  : Annonce si le BBItem est (ou non) rattach� � une fonction
// Returns      : 1 si le BBItem est rattach�, 0 sinon
// -----------------------------------------------------------------------------
bool
BBItem::lienFonction()
{
	if ((pDonnees->nomFonction[0] != '\0') && (strspn(pDonnees->nomFonction, " ") != strlen(pDonnees->nomFonction)))
		return true ;

	return false ;}

// -----------------------------------------------------------------------------
// Function     : int BBItem::ouvreDialog()
// Description  : Annonce si le BBItem ouvre (ou non) un dialogue (dialogue �ventuellement rattach� � un arch�type)
// Retours      : 1 si le BBItem est rattach�, 0 sinon
// -----------------------------------------------------------------------------
bool
BBItem::ouvreDialog()
{
	return (pDonnees->ouvreDlg() || pDonnees->ouvreArchetype()) ;
}

// -----------------------------------------------------------------------------
// Function     : int BBItem::ouvreArchetype()
// Description  : Annonce si le BBItem ouvre (ou non) un arch�type
// Returns      : 1 si le BBItem est ouvreur d'archetype, 0 sinon
// -----------------------------------------------------------------------------
bool
BBItem::ouvreArchetype()
{
	return pDonnees->ouvreArchetype() ;
}
stringBBItem::donneVraiChemin(){  if (!pBBFilsPere)    return "" ;  string sChemin = "" ;  bool bPlusZero = pBBFilsPere->estPlusZero() ;  if (false == bPlusZero)    sChemin = pBBFilsPere->getItemLabel() ;  BBItem* pBBcurrent = pBBFilsPere->getItemFather() ;  while (pBBcurrent && pBBcurrent->pBBFilsPere)  {    bPlusZero = pBBcurrent->pBBFilsPere->estPlusZero() ;    if (false == bPlusZero)    {      if (string("") != sChemin)        sChemin = string(1, cheminSeparationMARK) + sChemin ;      sChemin = pBBcurrent->pBBFilsPere->getItemLabel() + sChemin ;    }    pBBcurrent  = pBBcurrent->pBBFilsPere->getItemFather() ;  }  if (pBBcurrent && pBBcurrent->pBigBoss)  {    if (string("") != sChemin)      sChemin = string(1, cheminSeparationMARK) + sChemin ;    sChemin = string(pBBcurrent->pBigBoss->lexiqueModule) + sChemin ;  }  return sChemin ;}voidBBItem::cutBadDialogBranches(NSDialog* pDlg){	if ((NULL == pDlg) || (true == aBBItemFils.empty()))		return ;	for (BBiter iter = aBBItemFils.begin() ; iter != aBBItemFils.end() ; iter++)  	(*iter)->cutBadDialogBranches(pDlg) ;}boolBBItem::isBadDialogBranch(NSDialog* pDlg){	if (NULL == pDlg)		return false ;	if (true == aBBItemFils.empty())		return true ;	for (BBiter iter = aBBItemFils.begin() ; iter != aBBItemFils.end() ; iter++)  	if (false == (*iter)->isBadDialogBranch(pDlg))    	return false ;	return true ;}