#include <windows.h>#include <bwcc.h>
#include "nautilus\nssuper.h"#include "nsbb\nsradiob.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbb_dlg.h"
#include "nsbb\nsbbtran.h"
#include "nsbb\nsdlg.h"

DEFINE_RESPONSE_TABLE1(NSRadioButton, TRadioButton)
	EV_NOTIFY_AT_CHILD(BN_CLICKED, BNClicked),
  EV_WM_KEYUP,
END_RESPONSE_TABLE;


//
// Constructeurs
//
NSRadioButton::NSRadioButton(NSContexte *pCtx, TWindow* parent, int resId, TGroupBox* group)
              :TRadioButton(parent, resId, group), NSRoot(pCtx)
{
  pControle = 0 ;
  ActiveToi = true ;
	DisableTransfer() ;
}

NSRadioButton::NSRadioButton(NSContexte *pCtx, TWindow* parent, int resId, const char far* title,
                             int x, int y, int w, int h, TGroupBox *group,
                             TModule* module)
              :TRadioButton(parent, resId, title, x, y, w, h, group, module), NSRoot(pCtx)
{
  pControle = 0 ;
  ActiveToi = true ;
	DisableTransfer() ;
  //
  // Attention, le constructeur de TRadioButton employ� ici attribue le style
  // BS_AUTORADIOBUTTON, que nous rempla�ons par BS_RADIOBUTTON
  //
  Attr.Style = (Attr.Style ^ BS_AUTORADIOBUTTON) | BS_RADIOBUTTON ;
  Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;
}

char far*
NSRadioButton::GetClassName()
{
  return RADIO_CLASS ;
}

void
NSRadioButton::GetWindowClass(WNDCLASS far& wc)
{
  TWindow::GetWindowClass(wc) ;
  // static TBrush yellow(TColor::LtYellow);
  // wc.hbrBackground = yellow;
  // wc.lpszClassName = RADIO_CLASS;
  // wc.style |= BS_RADIOBUTTON;
}

void
NSRadioButton::SetupWindow()
{
  TRadioButton::SetupWindow() ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;
  SetWindowFont(*(pSuper->getDialogFont()), false) ;
}

bool
NSRadioButton::canWeClose()
{
  return true ;
}

//
// Destructeur
//
NSRadioButton::~NSRadioButton()
{
  if ((pControle) && (pControle->getControle()))
    pControle->setControle(0) ;
}

//
// Fonction d�clench� lorsque la boite � cocher est activ�e.
//
void
NSRadioButton::BNClicked()
{
	if (false == ActiveToi)
	{
  	ActiveToi = true ;
    return ;
	}

	Message Msg ;

	int iNotifier = 1 ;	if (GetCheck() == BF_CHECKED)
	{
  	if ((NULL != pControle) && (NULL != pControle->getTransfert()))
    	pControle->getTransfert()->ctrlNotification(BF_CHECKED, BF_UNCHECKED, &Msg) ;
  }
  else
  {
  	if ((NULL != pControle) && (NULL != pControle->getFonction()) && iNotifier)
    	iNotifier = pControle->getFonction()->execute(NSDLGFCT_EXECUTE) ;

    if ((NULL != pControle) && (NULL != pControle->getTransfert()))
    {
    	pControle->getTransfert()->ctrlNotification(BF_UNCHECKED, BF_CHECKED, &Msg) ;
      iNotifier = 0 ;
    }
	}

	/*//
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle->pNSDlgFct && iNotifier)
		iNotifier = pControle->pNSDlgFct->execute(NSDLGFCT_EXECUTE);  */

	TRadioButton::BNClicked() ;
}

//---------------------------------------------------------------------------
//  Function: 		NSRadioButton::Transfer(TTransferDirection direction,
//																int* pActif, string* pMessage)
//
//  Description:	Si direction = tdSetData
//							Initialise le contr�le
//						Si direction = tdGetData
//							Initialise pActif et pMessage
//
//  Arguments:		direction : tdGetData ou tdSetData
//
//  Returns:		1 si le transfert a fonctionn�
//						0 sinon
//---------------------------------------------------------------------------
uint
NSRadioButton::Transferer(TTransferDirection direction,
                                            int* pActif, Message* pMessage)
{
	if (direction == tdSetData)
	{
  	switch (*pActif)
    {
    	case 0  : SetCheck(BF_UNCHECKED) ; break ;
      case 1  : SetCheck(BF_CHECKED) ;   break ;
      default : SetCheck(BF_GRAYED) ;    break ;
		}
	}
	else if (direction == tdGetData)
	{
  	switch (GetCheck())
    {
    	case BF_UNCHECKED : *pActif =  0 ; break ;
      case BF_CHECKED 	: *pActif =  1 ; break ;
      case BF_GRAYED 	  : *pActif = -1 ; break ;
    }

    if (NULL != pMessage)
    {
    	string sEtiquette = string("") ;

      if ((NULL != pControle) && (NULL != pControle->getTransfert()))
      	sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

      if (NULL != pMessage)
      	pMessage->MettreAJourCertitudePluriel(sEtiquette) ;
    }
	}
	return 1 ;
}

uint
NSRadioButton::TempTransferer(int* pActif, Message* pMessage)
{
	switch (GetCheck())
	{
  	case BF_UNCHECKED : *pActif =  0 ; break ;
    case BF_CHECKED   : *pActif =  1 ; break ;
    case BF_GRAYED    : *pActif = -1 ; break ;
	}

	if (NULL != pMessage)
	{
		string sEtiquette = string("") ;

    if ((NULL != pControle) && (NULL != pControle->getTransfert()) && (NULL != pControle->getTransfert()->pBBFilsItem))
    	sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

    pMessage->MettreAJourCertitudePluriel(sEtiquette) ;
	}
	return 1 ;
}

void
NSRadioButton::EvKeyUp(uint key, uint repeatcount, uint flags)
{
  // Gestion windows standard
  // Windows standard behaviour
  if (pControle->getNSDialog())
  {
    // return TEdit::EvKeyUp(key, repeatcount, flags) ;
    TRadioButton::EvKeyUp(key, repeatcount, flags) ;
    return ;
  }

  // THandle NextControl = 0;
  switch (key)
  {
    //return
    case VK_DOWN   :
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // suivant pControle sinon le premier
      //
      if (pControle && pControle->getNSDialog())
        pControle->getNSDialog()->ActiveControlSuivant(pControle) ;
      else if (pControle && pControle->getMUEView())
        pControle->getMUEView()->SetFocusToNextControl((TControl*)this) ;
      break ;

    case VK_UP    :
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // pr�c�dent pControle sinon le dernier
      //
      if (pControle && pControle->getNSDialog())
        pControle->getNSDialog()->ActiveControlPrecedent(pControle) ;
      else if (pControle && pControle->getMUEView())
        pControle->getMUEView()->SetFocusToPreviousControl((TControl*)this) ;
      break ;

    //tabulation
    case VK_TAB	:
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // suivant pControle sinon le premier
      //
      if (pControle && pControle->getNSDialog())
        pControle->getNSDialog()->ActiveControlSuivant(pControle) ;
      else if (pControle && pControle->getMUEView())
      {
        if (GetKeyState(VK_SHIFT) < 0)
          pControle->getMUEView()->SetFocusToPreviousControl((TControl*)this) ;
        else
          pControle->getMUEView()->SetFocusToNextControl((TControl*)this) ;
      }
      break ;

    default		:
      //return TEdit::EvKeyUp(key, repeatcount, flags);
      TRadioButton::EvKeyUp(key, repeatcount, flags) ;
      return ;
  }
}
