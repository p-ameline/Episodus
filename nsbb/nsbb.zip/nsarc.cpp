// -----------------------------------------------------------------------------
// nsarc.cpp
// -----------------------------------------------------------------------------
// Parseur d'arch�types XML
// -----------------------------------------------------------------------------
// $Revision: 1.44 $
// $Author: philippe $
// $Date: 2005/05/18 07:38:08 $
// -----------------------------------------------------------------------------
// FLP - april 2005
// RS  - november 2002
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Copyright Nautilus, 2004
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � g�rer et traiter les
// informations de sant� d'une personne.
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to manage and process
// a person's health data.
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------


#include "nsbb\nsarc.h"#include "partage\nsdivfct.h"
#include "pre_parseur.h"
#include "nsbb\nsarcParseError.h"
#include "nsbb\nsbb.h"
#include "nsbb\nsbbsmal.h"

#include "ns_ob1\Interface.h"
#include "ns_ob1\OB1.rh"

#define CM_HAUTEUR  701

string
TexteXmlVersNormal(string texte)
{
  string  copie = texte ;
  bool    boucle = true ;
  size_t  car_start, car_end ;
  size_t  pos = 0 ;

  while ((boucle == true) && (pos < strlen(copie.c_str())))
  {
    car_start = copie.find("&", pos) ;
    if (car_start == string::npos)
      boucle = false ;
    else
    {
      car_end = copie.find(";", car_start) ;
      if (car_end == string::npos)
        // texte mal format� : on s'arr�te
        boucle = false ;
      else
      {
        string caract = string(copie, car_start, car_end - car_start + 1) ;

        if (caract == string("&acirc;"))
          copie.replace(car_start, caract.length(), "�") ;
        else if (caract == string("&agrave;"))
          copie.replace(car_start, caract.length(), "�") ;
        else if (caract == string("&ccedil;"))
          copie.replace(car_start, caract.length(), "�") ;
        else if (caract == string("&eacute;"))
          copie.replace(car_start, caract.length(), "�") ;
        else if (caract == string("&ecirc;"))
          copie.replace(car_start, caract.length(), "�") ;
        else if (caract == string("&egrave;"))
          copie.replace(car_start, caract.length(), "�") ;
        else if (caract == string("&euml;"))
          copie.replace(car_start, caract.length(), "�") ;
        else if (caract == string("&icirc;"))
          copie.replace(car_start, caract.length(), "�") ;
        else if (caract == string("&iuml;"))
          copie.replace(car_start, caract.length(), "�") ;
        else if (caract == string("&ocirc;"))
          copie.replace(car_start, caract.length(), "�") ;
        else if (caract == string("&ouml;"))
          copie.replace(car_start, caract.length(), "�") ;
        else if (caract == string("&lt;"))
          copie.replace(car_start, caract.length(), "<") ;
        else if (caract == string("&gt;"))
          copie.replace(car_start, caract.length(), ">") ;
        else if (caract == string("&ramp;"))
          copie.replace(car_start, caract.length(), "&") ;
        else if (caract == string("&quot;"))
          copie.replace(car_start, caract.length(), "\"") ;
        else if (caract == string("&#124;"))
          copie.replace(car_start, caract.length(), "|") ;
        else if (caract == string("&#163;"))
          copie.replace(car_start, caract.length(), "�") ;
        else if (caract == string("&#36;"))
          copie.replace(car_start, caract.length(), "$") ;

        // on repart apr�s le dernier caract�re remplac�
        pos = car_start + 1 ;
      }
    }
  }

  return copie ;
}


// -----------------------------------------------------------------------------
//
// classe nsarcParseur
//
// -----------------------------------------------------------------------------


nsarcParseur::nsarcParseur(NSContexte* pCtx, bool bVerb)
{
  pArchetype  = 0 ;
  pContexte   = pCtx ;
  bParsingOk  = false ;
  bVerbose    = bVerb ;
}


nsarcParseur::~nsarcParseur()
{
  if (pArchetype)
    delete pArchetype ;
}


nsarcParseur::nsarcParseur(const nsarcParseur& rv)
{
  if (rv.pArchetype)
    pArchetype = new Carchetype(*(rv.pArchetype)) ;
  else
    pArchetype = 0 ;

  pContexte   = rv.pContexte ;
  bParsingOk  = rv.bParsingOk ;
  bVerbose    = rv.bVerbose ;
}


nsarcParseur&
nsarcParseur::operator=(const nsarcParseur& src)
{
	if (this == &src)
		return *this ;

	if (pArchetype)
		delete pArchetype ;

  if (src.pArchetype)
    pArchetype = new Carchetype(*(src.pArchetype)) ;
  else
    pArchetype = 0 ;

  pContexte   = src.pContexte ;
  bParsingOk  = src.bParsingOk ;
  bVerbose    = src.bVerbose ;

  return (*this) ;
}


bool
nsarcParseur::open(string sXmlFileName)
{
  ifstream  xml_file ;
	string    tmp_xml_string ;
	string    xml_string ;
	bool      reponse ;

	xml_file.open(sXmlFileName.c_str()) ;
  if (!xml_file)
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    sErrorText += string(" ") + sXmlFileName ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
  }

	while (getline(xml_file, tmp_xml_string))
		xml_string += tmp_xml_string + '\n' ;
	xml_file.close() ;

  // xml_string = TexteXmlVersNormal(xml_string) ;

	reponse = pre_parseur(&xml_string) ;
	if (false == reponse)
  {
    string sErrorText = pContexte->getSuperviseur()->getText("archetypesManagement", "archetypePreParsingError") ;
    sErrorText += string(" (") + sXmlFileName + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;

		return false ;
  }

  int iParsingError ;
	if (parse_archetype(xml_string, string("archetype"), &iParsingError) == false)
  {
    if (bVerbose)
    {
    	string sErrParse = parseErrorMessage(iParsingError) ;

    	string sErrorText = pContexte->getSuperviseur()->getText("archetypesManagement", "archetypeParsingError") ;
    	sErrorText += string(" ") + sErrParse ;
    	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    	erreur(sErrorText.c_str(), standardError, 0) ;
    }
    return false ;
  }

  bParsingOk = true ;
  return true ;
}

bool
nsarcParseur::parse_archetype(string arc, string tag, int* iParsingError)
{
try
{
  size_t arc_start, arc_end, header_end, attrib_start ;
  string attributes, values ;

  arc_start = arc.find ("<" + tag) ;
  if (arc_start != string::npos)
  {
    arc_end = arc.find ("</" + tag + ">") ;
    if (arc_end == string::npos)
    {
      // erreur (pas de balise de fin)
      *iParsingError = EARCHETYPE_BALISE_FIN ;
      return false ;
    }

    header_end = arc.find (">", arc_start) ;
    if (arc_end < header_end)
    {
      // erreur (pas de fin de balise de debut)
      *iParsingError = EARCHETYPE_BALISE_DEBUT_FERMANTE ;
      return false ;
    }

    // attrib_start indique soit header_end('>') soit le premier attribut
    attrib_start = arc.find_first_not_of(' ', arc_start + tag.length() + 1) ;

    attributes = string (arc, attrib_start, header_end - attrib_start) ;
    values = string (arc, header_end + 1, arc_end - header_end - 1) ;
  }
  else
  {
    // erreur (pas de balise de debut)
    *iParsingError = EARCHETYPE_BALISE_DEBUT ;
    return false ;
  }

  pArchetype = new Carchetype(attributes, values, NULL, pContexte) ;
  if (!pArchetype->parser())
  {
    *iParsingError = pArchetype->iParsingError ;
    return false ;
  }
  return true ;
}
catch (...)
{
  erreur("Exception nsarcParseur::parse_archetype.", standardError, 0) ;
  return false ;
}
}


// -----------------------------------------------------------------------------
//
// classe nsrefParseur
//
// -----------------------------------------------------------------------------

nsrefParseur::nsrefParseur(NSContexte* pCtx, bool bVerb)
{
  pReferentiel  = 0 ;
  pContexte     = pCtx ;
  bParsingOk    = false ;
  bVerbose      = bVerb ;
}


nsrefParseur::~nsrefParseur()
{
  if (pReferentiel)
    delete pReferentiel ;
}


bool
nsrefParseur::open(string sXmlFileName)
{
  ifstream  xml_file ;
  string    tmp_xml_string ;
  string    xml_string ;
  bool      reponse ;

  xml_file.open(sXmlFileName.c_str()) ;
  if (!xml_file)
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    sErrorText += string(" ") + sXmlFileName ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
  }

  while (getline(xml_file, tmp_xml_string))
    xml_string += tmp_xml_string + '\n' ;
  xml_file.close() ;

  // xml_string = TexteXmlVersNormal(xml_string) ;

  reponse = pre_parseur(&xml_string) ;
  if (reponse == false)
    return false ;

  int iParsingError ;
	if (parse_referentiel(xml_string, string("referential"), &iParsingError) == false)
  {
    if (bVerbose)
    {
      string sErrParse = parseErrorMessage(iParsingError) ;

      string sErrorText = pContexte->getSuperviseur()->getText("referentialErrors", "referentialParsingError") ;
    	sErrorText += string(" ") + sErrParse ;
    	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    	erreur(sErrorText.c_str(), standardError, 0) ;
    }
    return false ;
  }
  bParsingOk = true ;
  return true ;
}

bool
nsrefParseur::parse_referentiel(string ref, string tag, int* iParsingError)
{
try
{
  size_t ref_start, ref_end, header_end, attrib_start ;
  string attributes, values ;

  ref_start = ref.find("<" + tag) ;
  if (ref_start != string::npos)
  {
    ref_end = ref.find("</" + tag + ">") ;
    if (ref_end == string::npos)
    {
      // erreur (pas de balise de fin)
      *iParsingError = EREFERENTIEL_BALISE_FIN ;
      return false ;
    }

    header_end = ref.find(">", ref_start) ;
    if (ref_end < header_end)
    {
      // erreur (pas de fin de balise de debut)
      *iParsingError = EREFERENTIEL_BALISE_DEBUT_FERMANTE ;
      return false ;
    }

    // attrib_start indique soit header_end('>') soit le premier attribut
    attrib_start = ref.find_first_not_of(' ', ref_start + tag.length() + 1) ;
    attributes = string(ref, attrib_start, header_end - attrib_start) ;
    values = string(ref, header_end + 1, ref_end - header_end - 1) ;
  }
  else
  {
    // erreur (pas de balise de debut)
    *iParsingError = EREFERENTIEL_BALISE_DEBUT ;
    return false ;
  }

  pReferentiel = new Creferentiel(attributes, values, NULL, pContexte) ;
  if (!pReferentiel->parser())
  {
    *iParsingError = pReferentiel->iParsingError ;
    return false ;
  }
  return true ;
}
catch (...)
{
  erreur("Exception nsrefParseur::parse_referentiel.", standardError, 0) ;
  return false ;
}
}


// -----------------------------------------------------------------------------
//
// Classe nsrefButton
//
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(nsrefButton, TRadioButton)
	EV_NOTIFY_AT_CHILD(BN_CLICKED, BNClicked),
END_RESPONSE_TABLE ;

nsrefButton::nsrefButton(TWindow* parent, NSContexte* pCtx, int resId, const char far* title,                             int x, int y, int w, int h, TGroupBox *group,
                             TModule* module)
  : TRadioButton(parent, resId, title, x, y, w, h, group, module),
    NSRoot(pCtx)
{
  // Attention, le constructeur de TRadioButton employ� ici attribue le style
  // BS_AUTORADIOBUTTON, que nous rempla�ons par BS_RADIOBUTTON
  Attr.Style    = (Attr.Style ^ BS_AUTORADIOBUTTON) | BS_RADIOBUTTON ;
  Attr.ExStyle  |= WS_EX_NOPARENTNOTIFY ;

  pProposition = 0 ;
}

nsrefButton::~nsrefButton()
{
}

void
nsrefButton::BNClicked()
{
try
{
	if (GetCheck() == BF_CHECKED)
  {
  	bool bCanUncheck = true ;
    if ((pProposition) && (pProposition->bInitialStateOn) &&
        (string("") != pProposition->propos->getUncheckArchetype()) &&
        (true == pProposition->propos->getIsAutocheck()))
    {
    	if (!(pProposition->pReadyTree))
      	pProposition->pReadyTree = new NSPatPathoArray(pContexte) ;

      TWindow* pParent = Parent ;
#ifdef __OB1__
      NSSmallBrother BigBoss(pContexte, pProposition->pReadyTree, 0) ;
#else
			NSSmallBrother BigBoss(pContexte, pProposition->pReadyTree, 0, true) ;
#endif

      BigBoss.pFenetreMere = pParent ;
			// string sArchetype = string("admin.goal.refuse.1.0") ;
      string sArchetype = pProposition->propos->getUncheckArchetype() ;
# ifdef __OB1__
    	BB1BBInterfaceForKs InterfaceForKs(-1, sArchetype, "", true) ;
			/* NSDialog *pClientWin = */ BigBoss.lanceBbkArchetypeInDialog(sArchetype, 0, 0, &InterfaceForKs, true /*modal*/) ;
# else
			/* NSDialog *pClientWin = */ BigBoss.lanceBbkArchetypeInDialog(sArchetype, 0, 0, true /*modal*/) ;
# endif

      pParent->SetFocus() ;

      if (pProposition->pReadyTree->empty())
      	bCanUncheck = false ;
    }
    if (bCanUncheck)
    	Uncheck() ;
  }
  else
  	Check() ;

  // TRadioButton::BNClicked() ;
}
catch (...)
{
	erreur("Exception nsrefButton::BNClicked.", standardError, 0) ;
}
}


// -----------------------------------------------------------------------------
//
// Classe nsrefGroup
//
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(nsrefGroup, TGroupBox)
//  EV_WM_PAINT,
  EV_COMMAND(CM_HAUTEUR, CmHauteur),
END_RESPONSE_TABLE ;


nsrefGroup::nsrefGroup(nsrefDialog* pere, int Id, const char far *text, int x, int y, int w, int h, TModule* module)  : TGroupBox((TWindow*) pere, Id, text, x, y, w, h, module)
{
  pDlg = pere ;
  Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;
  hauteur = h ;
}


nsrefGroup::~nsrefGroup()
{
}


void
nsrefGroup::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& rect)
{
  NS_CLASSLIB::TRect winRect ;
  GetWindowRect(winRect) ;
  NS_CLASSLIB::TRect clientRect ;
  GetClientRect(clientRect) ;

  TGroupBox::Paint(dc, erase, rect) ;
}


void
nsrefGroup::CmHauteur()
{
  pDlg->iVGroupHeight = hauteur ;
}


// -----------------------------------------------------------------------------
//
// Classe NSProposition
//
// -----------------------------------------------------------------------------

NSProposition::NSProposition(Cproposition* prop, nsrefButton* butt)
{
  propos          = prop ;
  button          = butt ;

  bInitialStateOn = false ;
  pReadyTree      = 0 ;
}


NSProposition::~NSProposition()
{
  // on ne delete pas la proposition car
  // elle est rattach�e au parseur
  if (button)
    delete button ;
  if (pReadyTree)
    delete pReadyTree ;
}


NSProposition::NSProposition(const NSProposition& rv)
{
try
{
  propos          = rv.propos ;
  button          = rv.button ;
  bInitialStateOn = rv.bInitialStateOn ;

  if (rv.pReadyTree)
    pReadyTree = new NSPatPathoArray(*(rv.pReadyTree)) ;
  else
    pReadyTree = 0 ;
}
catch (...)
{
  erreur("Exception NSProposition copy ctor.", standardError, 0) ;
}
}


NSProposition&
NSProposition::operator=(const NSProposition& src)
{
try
{
	if (this == &src)
		return *this ;

  propos          = src.propos;
  button          = src.button;
  bInitialStateOn = src.bInitialStateOn ;

  if (pReadyTree)
    delete pReadyTree ;
  if (src.pReadyTree)
    pReadyTree = new NSPatPathoArray(*(src.pReadyTree)) ;
  else
    pReadyTree = 0 ;

  return (*this) ;
}
catch (...)
{
  erreur("Exception NSProposition = operator.", standardError, 0) ;
  return (*this) ;
}
}


// -----------------------------------------------------------------------------
//
// Classe NSProposArray
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Constructeur copie// ---------------------------------------------------------------------------NSProposArray::NSProposArray(const NSProposArray& rv)
  : NSProposVector()
{try{  if (!rv.empty())    for (NSProposCIter i = rv.begin() ; i != rv.end() ; i++)      push_back(new NSProposition(*(*i))) ;}catch (...)
{
  erreur("Exception NSProposArray copy ctor.", standardError, 0) ;
}}
NSProposArray&
NSProposArray::operator=(const NSProposArray& src)
{try{	if (this == &src)		return *this ;  vider() ;  if (!src.empty())    for (NSProposCIter i = src.begin() ; i != src.end() ; i++)      push_back(new NSProposition(*(*i))) ;  return (*this) ;}catch (...)
{
  erreur("Exception NSProposArray = operator.", standardError, 0) ;
  return (*this) ;
}}


voidNSProposArray::vider(){  if (!empty())    for (NSProposIter i = begin() ; i != end() ; )    {      delete (*i) ;      erase(i) ;    }}
NSProposArray::~NSProposArray(){	vider() ;}


// -----------------------------------------------------------------------------
//
// Classe nsrefDialog
//
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(nsrefDialog, TDialog)
  EV_COMMAND(IDCANCEL,    CmCancel),
	EV_COMMAND(IDOK,        CmOk),
	EV_COMMAND(IDC_OTHER,   CmOther),
  EV_COMMAND(IDHELP,      CmHelp),
  EV_WM_VSCROLL,
  EV_MESSAGE(WM_MOUSEWHEEL, EvMouseWheel),
  EV_COMMAND(IDM_BBK_EVENT, CmBbkEvent),
END_RESPONSE_TABLE ;

nsrefDialog::nsrefDialog(TWindow* Parent, NSContexte* pCtx, nsrefParseur* parseur, bool bSimple)
            :TDialog(Parent, "DLG_BASE", pNSDLLModule), NSRoot(pCtx)
{
try
{
  pParseur        = parseur ;
  pProposArray    = new NSProposArray ;
  bSimplifie      = bSimple ;
  pScrollBar      = 0 ;
  sTitle          = "" ;
  sHelp           = "" ;
}
catch (...)
{
  erreur("Exception nsrefDialog ctor.", standardError, 0) ;
}
}

nsrefDialog::~nsrefDialog()
{
  delete pProposArray ;
  if (pScrollBar)
    delete pScrollBar ;
}

void
nsrefDialog::SetupWindow()
{
try
{
	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	NS_CLASSLIB::TRect cvtRect ;
	ValIter ival ;

	int iBoxHeight = 10 ;    // hauteur du bouton
	int iBoxWidth  = 300 ;   // largeur du bouton
	int iBoxInterv = 3 ;     // intervalle entre deux boutons
	int iBoxTop    = 4 ;     // haut du 1er bouton � partir du haut du groupbox
	int iBoxTitleTop = 12 ;
	int iBoxLeft   = 5 ;     // gauche des boutons � partir de la gauche du groupbox

	int iGroupTop  = 3 ;     // haut du groupbox
	int iFirstGroupTop = iGroupTop ;
	int iGroupLeft = 2 ;     // gauche du groupbox

	// int iSeparLeft = 3 ;     // gauche du s�parateur  int iSepar_Btn = 4 ;     // intervalle entre le s�parateur et le bouton	int iGB_Separ  = 3 ;     // intervalle entre le bas du groupbox et le s�parateur

	int iBtnHeight = 25 ;    // hauteur d'un bouton Borland
	int iBtnWidth  = 43 ;    // largeur d'un bouton Borland
	int iBtnLeft   = 5 ;     // gauche du premier bouton
	int iBtn_bas   = 7 ;     // intervalle entre le bas du bouton et le bas de la boite

	int  iNbBoxes ;/*	// initialisation de la largeur de la fenetre d'un referentiel	TDC					*pDC = new TDC(GetDC(HWindow)) ;
	TEXTMETRIC	TextMetric ;
	pDC->GetTextMetrics(TextMetric) ;
	float				iUnit = TextMetric.tmAveCharWidth / 4.0 ;

//	TIC pDC = new TIC("DISPLAY", NULL, NULL) ;
//	pDC->SetMapMode(MM_TEXT) ;
	for (ival = pParseur->pReferentiel->getValArray()->begin(); ival != pParseur->pReferentiel->getValArray()->end() ; ival++)
	{
		if ((*ival)->sLabel == LABEL_PROPOSITION)
		{
			Cproposition	*pCProp = dynamic_cast<Cproposition *>((*ival)->pObject) ;
			string sTitre = pCProp->getStringAttribute(ATTRIBUT_PROP_NOM) ;
			if (sTitre != "")
			{
				int	iTailleTitre = (pDC->GetTextExtent(sTitre.c_str(), strlen(sTitre.c_str()))).cx * iUnit ;
				if (iTailleTitre > iBoxWidth)
					iBoxWidth = iTailleTitre ;
			}
		}
	}
	delete pDC ;
*/

  if ((NULL == pParseur) || (NULL == pParseur->pReferentiel))
    return ;

  Valeur_array* pValArray = pParseur->pReferentiel->getValArray() ;
  if ((NULL == pValArray) || (pValArray->empty()))
    return ;

  for (ival = pValArray->begin() ; ival != pValArray->end() ; ival++)
  {    if (LABEL_PROPOSITION == (*ival)->sLabel)    {      Cproposition* pCprop = dynamic_cast<Cproposition *>((*ival)->pObject) ;      if (NULL != pCprop)        pCprop->setTraite(false) ;    }  }
	int iGroupWidth = (2 * iBoxLeft) + iBoxWidth ;	int iTotalWidth = (2 * iGroupLeft) + iGroupWidth ;
	int iGroupHeight = 0 ;
	int iTotalGroupHeight = 0 ;
	int iTopOfBox ;
	int iID = CBUTTONID ;

	// Initialisation des variables globales
  //
  Cglobalvars *pGVars = pParseur->pReferentiel->getGVars() ;
  if (pGVars != NULL)
    pGVars->process(true, HWindow) ;

	VecteurString aExcluded ;
	VecteurString aNeeded ;

	//
	// Premi�re passe : recherche du groupe vide
  //
  string sGroup = "" ;

	iNbBoxes = pParseur->pReferentiel->getNbPropGroup("", false, sLang) ;

	if (iNbBoxes > 0)	{		iGroupHeight = (2 * iBoxTop) + (iNbBoxes * iBoxHeight) + ((iNbBoxes - 1) * iBoxInterv) ;
		iTotalGroupHeight += iGroupHeight ;

		// On cr�e le groupe		cvtRect = NS_CLASSLIB::TRect(iGroupLeft, iGroupTop, iGroupLeft + iGroupWidth, iGroupTop + iGroupHeight) ;
		MapDialogRect(cvtRect) ;

		/* nsrefGroup *pGroup = */ new nsrefGroup(this, -1, "", cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), /* TModule* */ 0) ;
		iTopOfBox = iGroupTop + iBoxTop ;
		for (ival = pValArray->begin() ; ival != pValArray->end() ; ival++)		{			if ((*ival)->sLabel == LABEL_PROPOSITION)			{				Cproposition* pCprop = dynamic_cast<Cproposition *>((*ival)->pObject) ;				if ((NULL != pCprop) && (string("") == pCprop->getGroup(sLang)))				{					pCprop->setTraite(true) ;					// Rectangle du bouton					cvtRect = NS_CLASSLIB::TRect(iGroupLeft + iBoxLeft, iTopOfBox, iGroupLeft + iBoxLeft + iBoxWidth, iTopOfBox + iBoxHeight) ;					MapDialogRect(cvtRect) ;
					// Titre					string sTitre = pCprop->getTitle(sLang) ;					// bouton					nsrefButton *pButton = new nsrefButton(this, pContexte, iID, sTitre.c_str(), cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), 0, 0) ;          NSProposition* pPropos = new NSProposition(pCprop, pButton) ;
          pButton->pProposition = pPropos ;

					pProposArray->push_back(pPropos) ;

					iTopOfBox += iBoxHeight + iBoxInterv ;
					iID++ ;

          pCprop->addExcludedToVector(&aExcluded) ;
          pCprop->addNeededToVector(&aNeeded) ;
				}
			}		}	}	// Deuxi�me passe : Recherche des autres groupes	while (pParseur->pReferentiel->getNextGroup(sGroup, sLang))	{		if (false == bSimplifie)		{
      // on est surs d'avoir au moins une proposition dans le groupe
      iNbBoxes = pParseur->pReferentiel->getNbPropGroup(sGroup, false, sLang) ;

			iGroupTop += iGroupHeight + iGB_Separ ;			iGroupHeight = (iBoxTitleTop + iBoxTop) + (iNbBoxes * iBoxHeight) + ((iNbBoxes-1) * iBoxInterv) ;
			iTotalGroupHeight += iGB_Separ + iGroupHeight ;			// On cr�e le groupe			cvtRect = NS_CLASSLIB::TRect(iGroupLeft, iGroupTop, iGroupLeft + iGroupWidth, iGroupTop + iGroupHeight) ;
			MapDialogRect(cvtRect) ;

			/* nsrefGroup *pGroup = */ new nsrefGroup(this, -1, sGroup.c_str(), cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), /* TModule* */ 0) ;			iTopOfBox = iGroupTop + iBoxTitleTop ;
		}
    else      iNbBoxes = pParseur->pReferentiel->getNbPropGroup(sGroup, true, sLang) ;		bool	bFirstInGroup = true ;		for (ival = pValArray->begin() ; ival != pValArray->end() ; ival++)		{			if ((*ival)->sLabel == LABEL_PROPOSITION)			{				Cproposition* pCprop = dynamic_cast<Cproposition *>((*ival)->pObject) ;				if ((NULL != pCprop) && (false == pCprop->getTraite()) && (pCprop->getGroup(sLang) == sGroup))				{					pCprop->setTraite(true) ;					if (bSimplifie)					{            bool bValid = true ;            // Does this proposition belong to the excluded list          	//
        		string sPropID = pCprop->getStringAttribute(ATTRIBUT_PROP_ID) ;
						if ((sPropID != "") && (aExcluded.ItemDansUnVecteur(sPropID)))
          		bValid = false ;            // Else, if this proposition doesn't belong to the needed list,            // we have to check its validity            //            else if ((sPropID == "") || (!(aNeeded.ItemDansUnVecteur(sPropID))))              for (ValIter i = pCprop->getValArray()->begin() ; bValid && (i != pCprop->getValArray()->end()) ; i++)              {                if ((*i)->sLabel == LABEL_VALIDITE)                {                  Ccontrainte		*pCvalidite = dynamic_cast<Ccontrainte *>((*i)->pObject) ;                  NSValidateur	valid(pCvalidite, pParseur->pContexte) ;                  if (!(valid.Validation()))                  {                    bValid = false ;                    break ;                  }                }              }            if (bValid)            {              if (bFirstInGroup)              {                iGroupTop += iGroupHeight + iGB_Separ ;                iGroupHeight = (iBoxTitleTop + iBoxTop) + (iNbBoxes * iBoxHeight) + ((iNbBoxes-1) * iBoxInterv) ;
                iTotalGroupHeight += iGB_Separ + iGroupHeight ;                // On cr�e le groupe                cvtRect = NS_CLASSLIB::TRect(iGroupLeft, iGroupTop, iGroupLeft + iGroupWidth, iGroupTop + iGroupHeight) ;
                MapDialogRect(cvtRect) ;

                nsrefGroup *pGroup = new nsrefGroup(this, -1, sGroup.c_str(), cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), /* TModule* */ 0) ;                pGroup->Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;
                iTopOfBox = iGroupTop + iBoxTitleTop ;

                bFirstInGroup = false ;
              }              // Rectangle du bouton              cvtRect = NS_CLASSLIB::TRect(iGroupLeft + iBoxLeft, iTopOfBox, iGroupLeft + iBoxLeft + iBoxWidth, iTopOfBox + iBoxHeight) ;              MapDialogRect(cvtRect) ;
              // Titre              string sTitre = pCprop->getTitle(sLang) ;              // bouton              nsrefButton* pButton = new nsrefButton(this, pContexte, iID, sTitre.c_str(), cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), 0, 0) ;              NSProposition* pPropos = new NSProposition(pCprop, pButton) ;
              pButton->pProposition = pPropos ;

              pProposArray->push_back(pPropos) ;

              iTopOfBox += iBoxHeight + iBoxInterv ;

              // Aide en ligne
              if (sHelp == "")
                sHelp = pCprop->getHelpUrl(sLang) ;

              pCprop->addExcludedToVector(&aExcluded) ;
              pCprop->addNeededToVector(&aNeeded) ;
            }
					}					else					{						// Rectangle du bouton						cvtRect = NS_CLASSLIB::TRect(iGroupLeft + iBoxLeft, iTopOfBox, iGroupLeft + iBoxLeft + iBoxWidth, iTopOfBox + iBoxHeight) ;						MapDialogRect(cvtRect) ;
						string sTitre = pCprop->getTitle(sLang) ;						nsrefButton* pButton = new nsrefButton(this, pContexte, iID, sTitre.c_str(), cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), 0, 0) ;            NSProposition* pPropos = new NSProposition(pCprop, pButton) ;            pButton->pProposition = pPropos ;						pProposArray->push_back(pPropos) ;

						iTopOfBox += iBoxHeight + iBoxInterv ;

            // Aide en ligne
            if (sHelp == "")
              sHelp = pCprop->getHelpUrl(sLang) ;
					}

					iID++ ;
				}
			}		}	}  // On fixe la taille de la boite de dialogue	int iTotalHeight = iFirstGroupTop + iTotalGroupHeight + iGB_Separ + iSepar_Btn + iBtnHeight + iBtn_bas ;  int iTotalBtnHeight = iSepar_Btn + iBtnHeight + iBtn_bas ;
	NS_CLASSLIB::TRect dlgSizeRect(0, 0, iTotalWidth, iTotalHeight) ;	MapDialogRect(dlgSizeRect) ;  // on convertit ici un rectangle fictif en pixels pour obtenir la hauteur des boutons + separateur  NS_CLASSLIB::TRect BtnRect(0, 0, iTotalWidth, iTotalBtnHeight) ;  MapDialogRect(BtnRect) ;  iVSizeNoScroll = BtnRect.Height() ;  NS_CLASSLIB::TRect BtnBasRect(0, 0, iTotalWidth, iBtnHeight + iBtn_bas) ;  MapDialogRect(BtnBasRect) ;  iVSizeBtnBas = BtnBasRect.Height() ;  // on fait de meme pour r�cup�rer la hauteur des boutons en pixels  NS_CLASSLIB::TRect BoxHeightRect(0, 0, iTotalWidth, iBoxHeight) ;  MapDialogRect(BoxHeightRect) ;  iVBoxHeight = BoxHeightRect.Height() ;	// On cr�e le s�parateur	int iSepareTop = iGroupHeight + iGroupTop + iGB_Separ ;

	// cvtRect = NS_CLASSLIB::TRect(iGroupLeft, iSepareTop, iGroupLeft + iGroupWidth, iSepareTop + iBtnHeight + (2*iSepar_Btn)) ;	// MapDialogRect(cvtRect) ;
	// TGroupBox* pDip = new TGroupBox(this, IDC_SEPAR, "", cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), /*TModule**/ 0) ;
  // pDip->Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;
	// pDip->Attr.Style |= BSS_HDIP ;

	// On cr�e les boutons
	int iNbBtn ;
	if (bSimplifie)
		iNbBtn = 4 ;
	else
		iNbBtn = 3 ;

	int iBtnInterv = (iTotalWidth - (2 * iBtnLeft) - (iNbBtn * iBtnWidth)) / (iNbBtn - 1) ;
	int iBtnTopPos  = iSepareTop + iSepar_Btn ;
  int iBtnLeftPos = iBtnLeft ;

	// Bouton OK
	cvtRect = NS_CLASSLIB::TRect(iBtnLeftPos, iBtnTopPos, iBtnLeftPos + iBtnWidth, iBtnTopPos + iBtnHeight) ;	MapDialogRect(cvtRect) ;
	/* TButton* pBtOK = */ new TButton(this, IDOK, "", cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), /*isDefault*/ true, 0) ;
	iBtnLeftPos += iBtnWidth + iBtnInterv ;

	// Bouton CANCEL	cvtRect = NS_CLASSLIB::TRect(iBtnLeftPos, iBtnTopPos, iBtnLeftPos + iBtnWidth, iBtnTopPos + iBtnHeight) ;	MapDialogRect(cvtRect) ;
	/* TButton* pBtCn = */ new TButton(this, IDCANCEL, "", cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), /*isDefault*/ false, 0) ;
	iBtnLeftPos += iBtnWidth + iBtnInterv ;
	// Bouton HELP	cvtRect = NS_CLASSLIB::TRect(iBtnLeftPos, iBtnTopPos, iBtnLeftPos + iBtnWidth, iBtnTopPos + iBtnHeight) ;	MapDialogRect(cvtRect) ;
	/* TButton* pBtHl = */ new TButton(this, IDHELP, "", cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), /*isDefault*/ false, 0) ;
	iBtnLeftPos += iBtnWidth + iBtnInterv ;
	if (bSimplifie)	{		// Bouton AUTRE		cvtRect = NS_CLASSLIB::TRect(iBtnLeftPos, iBtnTopPos, iBtnLeftPos + iBtnWidth, iBtnTopPos + iBtnHeight) ;		MapDialogRect(cvtRect) ;
		/* TButton* pBtAutre = */ new TButton(this, IDC_OTHER, "Autre", cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), /*isDefault*/ false, 0) ;
		iBtnLeftPos += iBtnWidth + iBtnInterv ;
	}
  // Titre de la boite de dialogue  string sTitle = pParseur->pReferentiel->getTitle(sLang) ;  if (sTitle != "")
    SetCaption(sTitle.c_str()) ;  else    SetCaption("R�f�rentiel") ;  // Ascenseur  pScrollBar = new TScrollBar(this, VSCROLLID, 0, 0, SCROLL_WIDTH, 100, false) ;	// Appel du SetupWindow() de TDialog	TDialog::SetupWindow() ;

	// Pr�-cochage : Appel au blackboard
  PreCochePropositions() ;

	// Redimentionnement
	GetWindowRect(dlgRect) ;
	NS_CLASSLIB::TRect clientRect ;
	GetClientRect(clientRect) ;

	// On compare le clientRect r�el avec les dimensions souhait�es, et on modifie le WindowRect en cons�quence	int nouvWindowWidth  = dlgRect.Width()  + (dlgSizeRect.Width()  - clientRect.Width()) ;
	int nouvWindowHeight = dlgRect.Height() + (dlgSizeRect.Height() - clientRect.Height()) ;

	MoveWindow(dlgRect.left, dlgRect.top, nouvWindowWidth, nouvWindowHeight) ;

  // Evaluation du rectangle utilisable � l'�cran
  // NS_CLASSLIB::TRect mainRect = Parent->GetWindowRect() ;

  // Taille de l'�cran - Screen size
  TScreenDC screenDC ;
  int iHorzRes = screenDC.GetDeviceCaps(HORZRES) ;
  int iVertRes = screenDC.GetDeviceCaps(VERTRES) ;

  usableRect = NS_CLASSLIB::TRect(dlgRect.TopLeft(), NS_CLASSLIB::TPoint(iHorzRes, iVertRes)) ;

  // TaskBar de Windows
  // RECT        rect ;
  APPBARDATA  AppBarData ;

  AppBarData.hWnd = ::FindWindow("Shell_TrayWnd", NULL) ;
  if (AppBarData.hWnd != 0)
  {
    AppBarData.cbSize = sizeof(AppBarData) ;
    int iResult = ::SHAppBarMessage(ABM_GETTASKBARPOS, &AppBarData) ;
    if (iResult)
    {
      switch (AppBarData.uEdge)
      {
        case ABE_BOTTOM : usableRect.bottom = AppBarData.rc.top ; break ;
        case ABE_LEFT   : if (usableRect.Left() < AppBarData.rc.right) usableRect.left = AppBarData.rc.right ; break ;
        case ABE_RIGHT  : if (usableRect.Right() > AppBarData.rc.left) usableRect.right = AppBarData.rc.left ; break ;
        case ABE_TOP    : break ;
      }
    }
  }

  // Initialisation de l'ascenseur
  iVSize = nouvWindowHeight ;
  iHSize = nouvWindowWidth ;
  // Par d�faut l'ascenseur est visible : il faut donc le cacher s'il est inutile
  bVisibleScroll = true ;
  SetSize() ;
}
catch (...)
{
  erreur("Exception nsrefDialog::SetupWindow.", standardError, 0) ;
}
}

void
nsrefDialog::SetSize()
{
  bool bShowScroll = false ;
  bool bHideScroll = false ;

  iDecalageY = 0 ;
  iOldDecalY = 0 ;

  if (iVSize > usableRect.Height())
  {
    iVRealSize = usableRect.Height() ;
    iHRealSize = iHSize + SCROLL_WIDTH ;
    if (dlgRect.left + iHRealSize > usableRect.Right())
      iHRealSize = usableRect.Right() - dlgRect.left ;
    dlgRect.right = dlgRect.left + iHRealSize ;
    if (!bVisibleScroll)
    {
      bShowScroll = true ;
      bVisibleScroll = true ;
    }
    SCROLLINFO scInfo ;
    scInfo.cbSize = (UINT) sizeof(scInfo) ;
    scInfo.fMask = SIF_ALL ;
    scInfo.nMin = 1 ;
    scInfo.nMax = iVSize ;
    scInfo.nPage = (UINT) iVRealSize ;
    scInfo.nPos = 1 ;
    pScrollBar->SetScrollInfo(&scInfo, TRUE) ;
  }
  else
  {
    iVRealSize = iVSize ;
    iHRealSize = iHSize ;
    dlgRect.right = dlgRect.left + iHRealSize ;
    if (bVisibleScroll)
    {
      bHideScroll = true ;
      bVisibleScroll = false ;
    }
  }

  dlgRect.bottom = dlgRect.top + iVRealSize ;

  // SetWindowPos(Parent->HWindow, Attr.X, Attr.Y, Attr.W, Attr.H, SWP_NOZORDER) ;
  MoveWindow(dlgRect.left, dlgRect.top, dlgRect.Width(), dlgRect.Height()) ;

  if (bVisibleScroll)
  {
    pScrollBar->Attr.H = GetClientRect().Height() - iVSizeNoScroll ;
    pScrollBar->Attr.X = GetClientRect().Width() - SCROLL_WIDTH ;
    pScrollBar->SetWindowPos(HWindow, pScrollBar->Attr.X, pScrollBar->Attr.Y, pScrollBar->Attr.W, pScrollBar->Attr.H, SWP_NOZORDER) ;
    pScrollBar->SetRange(0, iVSize - iVRealSize, false) ;

    WNDENUMPROC lpEnumDlgFunc1, lpEnumDlgFunc2 ;

    // Pr�paration de la fonction d'�num�ration
    lpEnumDlgFunc1 = (WNDENUMPROC) MakeProcInstance((FARPROC) nsrefDialog::DlgScrollCtrl, hInstance) ;
    EnumChildWindows(HWindow, lpEnumDlgFunc1, LPARAM((TWindow *)this)) ;

    NS_CLASSLIB::TRect dlgRect ;
    NS_CLASSLIB::TRect cliRect ;

    GetClientRect(dlgRect) ;
    cliRect = NS_CLASSLIB::TRect(0, dlgRect.Height() - iVSizeNoScroll, dlgRect.Width(), dlgRect.Height()) ;
    // InvalidateRect(cliRect) ;

    // On recale ensuite les boutons en bas du dialogue
    lpEnumDlgFunc2 = (WNDENUMPROC) MakeProcInstance((FARPROC) nsrefDialog::DlgScrollBtns, hInstance) ;
    EnumChildWindows(HWindow, lpEnumDlgFunc2, LPARAM((TWindow *)this)) ;
  }

  if (bShowScroll)
    pScrollBar->Show(SW_SHOW) ;

  if (bHideScroll)
    pScrollBar->Show(SW_HIDE) ;
}

void
nsrefDialog::EvVScroll(UINT scrollCode, UINT /* thumbPos */, HWND /* hWndCtl */)
{
  if (((scrollCode == SB_LINEUP) || (scrollCode == SB_PAGEUP)) && (iDecalageY == 0))
    return ;

  int iMaxDecal = iVSize - iVRealSize ;

  if (((scrollCode == SB_LINEDOWN) || (scrollCode == SB_PAGEDOWN)) && (iDecalageY >= iMaxDecal))
    return ;

  if      (scrollCode == SB_LINEDOWN)
  {
    if (iMaxDecal > iDecalageY + 10)
      iDecalageY += 10 ;
    else
      iDecalageY = iMaxDecal ;
  }
  else if (scrollCode == SB_PAGEDOWN)
  {
    if (iMaxDecal > iDecalageY + iVRealSize)
      iDecalageY += iVRealSize ;
    else
      iDecalageY = iMaxDecal ;
  }
  else if (scrollCode == SB_LINEUP)
  {
    if (iDecalageY > 10)
      iDecalageY -= 10 ;
    else
      iDecalageY = 0 ;
  }
  else if (scrollCode == SB_PAGEUP)
  {
    if (iDecalageY > iVRealSize)
      iDecalageY -= iVRealSize ;
    else
      iDecalageY = 0 ;
  }

  pScrollBar->SetPosition(iDecalageY) ;

  WNDENUMPROC lpEnumDlgFunc1, lpEnumDlgFunc2 ;

  // Pr�paration de la fonction d'�num�ration
  lpEnumDlgFunc1 = (WNDENUMPROC) MakeProcInstance((FARPROC) nsrefDialog::DlgScrollCtrl, hInstance) ;

  // On passe comme param�tre de EnumChildWindows LPARAM(this), l'adresse de
  // this puisque dans les fonctions static on ne peut pas r�cup�rer
  // le pointeur this.
  EnumChildWindows(HWindow, lpEnumDlgFunc1, LPARAM((TWindow *)this)) ;

  NS_CLASSLIB::TRect dlgRect ;
  NS_CLASSLIB::TRect cliRect ;

  GetClientRect(dlgRect) ;
  cliRect = NS_CLASSLIB::TRect(0, dlgRect.Height() - iVSizeNoScroll, dlgRect.Width(), dlgRect.Height()) ;
  InvalidateRect(cliRect) ;

  // On recale ensuite les boutons en bas du dialogue
  lpEnumDlgFunc2 = (WNDENUMPROC) MakeProcInstance((FARPROC) nsrefDialog::DlgScrollBtns, hInstance) ;

  // On passe comme param�tre de EnumChildWindows LPARAM(this), l'adresse de
  // this puisque dans les fonctions static on ne peut pas r�cup�rer
  // le pointeur this.
  EnumChildWindows(HWindow, lpEnumDlgFunc2, LPARAM((TWindow *)this)) ;

  iOldDecalY = iDecalageY ;
}

LRESULT
nsrefDialog::EvMouseWheel(WPARAM /* wParam */, LPARAM /* lParam */)
{
  return 0 ;
}

bool FAR PASCAL _export
nsrefDialog::DlgScrollCtrl(HWND hWnd, LPARAM lParam)
{
try
{
	// Adresse de l'objet bo�te de dialogue courante
	TWindow* pWnd = reinterpret_cast<TWindow *>(lParam) ;
	nsrefDialog* pDlg = dynamic_cast<nsrefDialog *>(pWnd) ;

  int ctrlID  = ::GetDlgCtrlID(hWnd) ;
  NS_CLASSLIB::TRect ctrlRect ;
  NS_CLASSLIB::TRect dlgRect ;
  int X, Y ;
  int hScroll, hGroup ;

  if ((ctrlID != VSCROLLID) && (ctrlID != IDOK) && (ctrlID != IDCANCEL) &&
      (ctrlID != IDHELP) && (ctrlID != IDC_OTHER))
  {
    ::GetWindowRect(hWnd, &ctrlRect) ;
    pDlg->GetClientRect(dlgRect) ;
    hScroll = dlgRect.Height() - pDlg->iVSizeNoScroll ;
    NS_CLASSLIB::TPoint point(dlgRect.X(), dlgRect.Y()) ;
    pDlg->ClientToScreen(point) ;
    ctrlRect.top += (pDlg->iOldDecalY - pDlg->iDecalageY) ;
    ctrlRect.bottom += (pDlg->iOldDecalY - pDlg->iDecalageY) ;
    X = ctrlRect.left - point.X() ;
    Y = ctrlRect.top - point.Y() ;
    TWindow* ctrlWin = new TWindow(hWnd) ;
    ::SetWindowPos(hWnd, HWND_TOPMOST, X, Y, ctrlRect.Width(), ctrlRect.Height(), SWP_SHOWWINDOW) ;

    if (ctrlID != -1)
    {
      if (Y + ctrlRect.Height() > hScroll)
        ctrlWin->Show(SW_HIDE) ;
      else
        ctrlWin->Show(SW_SHOW) ;

      ::MoveWindow(hWnd, X, Y, ctrlRect.Width(), ctrlRect.Height(), true) ;
    }
    else
    {
      ::SendMessage(hWnd, WM_COMMAND, CM_HAUTEUR, 0) ;
      int hauteur = pDlg->iVGroupHeight ;

      if (Y + hauteur > hScroll)
      {
        if (Y < hScroll)
        {
          // le groupe est en partie cach� : on recalcule la hauteur
          hGroup = hScroll - Y ;
          ctrlWin->Show(SW_SHOW) ;
        }
        else
        {
          hGroup = ctrlRect.Height() ;
          ctrlWin->Show(SW_HIDE) ;
        }
      }
      else
      {
        hGroup = hauteur ;
        ctrlWin->Show(SW_SHOW) ;
      }

      ::MoveWindow(hWnd, X, Y, ctrlRect.Width(), hGroup, true) ;
    }

    delete ctrlWin ;

    pDlg->Invalidate() ;
  }

  return true ;
}
catch (...)
{
  erreur("Exception nsrefDialog::DlgScrollCtrl.", standardError, 0) ;
  return false ;
}
}


bool FAR PASCAL _export
nsrefDialog::DlgScrollBtns(HWND hWnd, LPARAM lParam)
{
	// Adresse de l'objet bo�te de dialogue courante
	TWindow* pWnd = reinterpret_cast<TWindow *>(lParam) ;
	nsrefDialog* pDlg = dynamic_cast<nsrefDialog *>(pWnd) ;

  int ctrlID  = ::GetDlgCtrlID(hWnd) ;
  NS_CLASSLIB::TRect ctrlRect ;
  NS_CLASSLIB::TRect dlgRect ;
  int X, Y ;
  HWND hInsert ;

  if ((ctrlID != VSCROLLID) &&
      ((ctrlID == IDOK) || (ctrlID == IDCANCEL) || (ctrlID == IDHELP) || (ctrlID == IDC_OTHER)))
  {
    ::GetWindowRect(hWnd, &ctrlRect) ;
    pDlg->GetClientRect(dlgRect) ;
    NS_CLASSLIB::TPoint point(dlgRect.X(), dlgRect.Y()) ;
    pDlg->ClientToScreen(point) ;
    X = ctrlRect.left - point.X() ;
    Y = dlgRect.Height() - pDlg->iVSizeBtnBas ;
    hInsert = HWND_BOTTOM ;
    ::MoveWindow(hWnd, X, Y, ctrlRect.Width(), ctrlRect.Height(), true) ;
    ::SetWindowPos(hWnd, hInsert, X, Y, ctrlRect.Width(), ctrlRect.Height(), SWP_SHOWWINDOW) ;
    pDlg->Invalidate() ;
  }
  return true ;
}


void
nsrefDialog::PreCochePropositions()
{
	if (pProposArray->empty())
		return ;

	VecteurString aNeeded ;

  NSSuper* pSuper = pParseur->pContexte->getSuperviseur() ;
  pSuper->afficheStatusMessage("Pr�cochage : Interrogation du blackboard...") ;

  for (NSProposIter i = pProposArray->begin() ; i != pProposArray->end() ; i++)
  {
    bool bValid = true ;

    // Does this proposition belong to the needed list
    //
    string sPropID = (*i)->propos->getStringAttribute(ATTRIBUT_PROP_ID) ;
    if ((sPropID == "") || (!(aNeeded.ItemDansUnVecteur(sPropID))))
      for (ValIter ival = (*i)->propos->getValArray()->begin() ; ival != (*i)->propos->getValArray()->end() ; ival++)
      {
        // s'il y a une clause de validit�
        if ((*ival)->sLabel == LABEL_VALIDITE)
        {
          // on v�rifie l'etat des variable � l'aide du NSValidateur
          Ccontrainte* pCvalidite = dynamic_cast<Ccontrainte *>((*ival)->pObject) ;
          NSValidateur valid(pCvalidite, pParseur->pContexte) ;
          // si OK, on coche la proposition
          if (!(valid.Validation()))
          {
            bValid = false ;
            break ;
          }
        }
      }

    if (bValid)
		{
      if ((*i)->propos->getIsAutocheck())
			  (*i)->button->SetCheck(BF_CHECKED) ;
			(*i)->bInitialStateOn = true ;

      (*i)->propos->addNeededToVector(&aNeeded) ;
    }
  }

  pSuper->afficheStatusMessage("Pr�cochage : termin�.") ;
}


void
nsrefDialog::CmOk()
{
  if (!pProposArray->empty())
    for (NSProposIter i = pProposArray->begin() ; i != pProposArray->end() ; i++)
    {
      if ((*i)->button->GetCheck() == BF_CHECKED)
        (*i)->propos->setCheck(true) ;
      else if ((*i)->bInitialStateOn)
      {
        (*i)->propos->bInitialyChecked = true ;
        (*i)->propos->setCheck(false) ;
      }

      if ((*i)->pReadyTree && (!((*i)->pReadyTree->empty())))
      {
        if (!((*i)->propos->pReasonTree))
          (*i)->propos->pReasonTree = new NSPatPathoArray(pContexte) ;
        *((*i)->propos->pReasonTree) = *((*i)->pReadyTree) ;
      }
    }

  TDialog::CmOk();
}


void
nsrefDialog::CmCancel()
{
  TDialog::CmCancel() ;
}


void
nsrefDialog::CmOther()
{
/*
  for (ValIter ival = pParseur->pReferentiel->getValArray()->begin() ; ival != pParseur->pReferentiel->getValArray()->end() ; ival++)
  {    if ((*ival)->sLabel == LABEL_PROPOSITION)    {      Cproposition* pCprop = dynamic_cast<Cproposition *>((*ival)->pObject) ;      pCprop->setTraite(false) ;    }  }*/
/*
  if (!pProposArray->empty())
    for (NSProposIter i = pProposArray->begin() ; i != pProposArray->end() ; i++)
    {
      if ((*i)->button->GetCheck() == BF_CHECKED)
        (*i)->propos->setCheck(true) ;
    }
*/
  TDialog::CloseWindow(IDC_OTHER) ;
}

void
nsrefDialog::CmBbkEvent()
{
  TDialog::CloseWindow(IDC_BBK_EVENT) ;
}

void
nsrefDialog::CmHelp()
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;
	if (pSuper)
	{
		if (sHelp != "")
		{
			pSuper->setAideIndex("") ;
			pSuper->setAideCorps(sHelp) ;
		}
		else
		{
			pSuper->setAideIndex("") ;
			pSuper->setAideCorps("zz_generique.htm") ;
		}
	}
	pContexte->NavigationAideEnLigne() ;
}


// -----------------------------------------------------------------------------
//
// Classe NSValidateur
//
// -----------------------------------------------------------------------------


NSValidateur::NSValidateur(Ccontrainte* pValid, NSContexte* pCtx)
{
  pValidity = pValid ;
  pContexte = pCtx ;
}


NSValidateur::~NSValidateur()
{
  // on ne detruit rien car la contrainte de validit� appartient au parseur
}


bool
NSValidateur::getValeurVariable(string sName, string& sAlias, NSPatPathoArray** ppPatPathoArray)
{
	sAlias = "" ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;

  // At first, we process local variables (those that are defined inside the validator
  //
  // The point here is that if they have been defined specifically, it
  // means that they deserve to be processed specifically too
  //
  if (false == pValidity->getValArray()->empty())
  {
    for (ValIter ival = pValidity->getValArray()->begin() ; pValidity->getValArray()->end() != ival ; ival++)
    {      if (LABEL_VARIABLE == (*ival)->sLabel)      {        Cvariable* pCvar = dynamic_cast<Cvariable *>((*ival)->pObject) ;
        if ((NULL != pCvar) && (pCvar->getName() == sName) && (false == pCvar->isEmpty()))
        {
          for (ValIter ival = pCvar->vect_val.begin() ; pCvar->vect_val.end() != ival ; ival++)
          {
            // on r�cup�re le p�re des items de l'archetype
            if (LABEL_ALIAS == (*ival)->sLabel) // items
            {
              Calias *pAlias = dynamic_cast<Calias *>((*ival)->pObject) ;
              if (NULL == pAlias)
                break ;

              string sVarAlias = pAlias->getValue() ;

              // pour l'instant le blackboard ne r�pond qu'� une question oui/non
              // L'alias doit etre un chemin de codes sens (s�parateur : '/')
              string sQuestion = sVarAlias ;
              NSPatPathoArray* pPatPathoLocale = NULL ;

              bool bWaitForBlackBoard = true ;
              // on pose la question au blackboard
              string sAnswerDate ;

              pSuper->donneMainWindow()->SetCursor(pNSDLLModule, IDC_THINKING_CURSOR) ;
              while (bWaitForBlackBoard)
              {
                AnswerStatus::ANSWERSTATUS res = pSuper->getBBinterface()->getAnswer2Question(sQuestion, "", &pPatPathoLocale, sAnswerDate, false) ;
                if (res == AnswerStatus::astatusProcessed)
                {
                  bWaitForBlackBoard = false ;

                  // on teste d'abord l'existence de la variable
                  // (la patpatho r�sultat est non vide ==> la variable existe)
                  if ((pPatPathoLocale) && (!((pPatPathoLocale)->empty())))
                  {
                    sAlias = sQuestion ;
                    *ppPatPathoArray = pPatPathoLocale ;
                    pSuper->donneMainWindow()->SetCursor(0, IDC_ARROW) ;
                    return true ;
                  }
                }
              }
              pSuper->donneMainWindow()->SetCursor(0, IDC_ARROW) ;

              if (pPatPathoLocale)
                delete pPatPathoLocale ;
            }
          } // fin du for sur les alias

          // on sort du for global car on a trouv� le nom de la variable
          return false ;
        } // fin du if (pCvar->getStringAttribute(ATTRIBUT_VAR_NOM) == sName)
      }
    } // fin du for global (sur les variables)
  }

  // parsing des variables globales
  Cglobalvars *gVars = getGlobalVars() ;
  if ((NULL != gVars) && (gVars->isVarP(sName, GlobalVar::variable)))
  {
    NSPatPathoArray * pPPT = gVars->getPPT(sName, GlobalVar::variable) ;
    if (pPPT != NULL)
    {
      *ppPatPathoArray = new NSPatPathoArray(*pPPT) ;
      return true ;
    }
  }

  return false ;
}

bool
NSValidateur::getValeurContrainte(string sName)
{
try
{
	bool result = false ;

/*
  if ((!pValidity) || (pValidity->getValArray()->empty()))
		return false ;
*/
  if (!pValidity)
    return false ;

  // At first, we process local variables (those that are defined inside the validator
  //
  // The point here is that if they have been defined specifically, it
  // means that they deserve to be processed specifically too
  //
  if (false == pValidity->getValArray()->empty())
  {
    for (ValIter ival = pValidity->getValArray()->begin() ; ival != pValidity->getValArray()->end() ; ival++)
    {
      if ((*ival)->sLabel == LABEL_CONTRAINTE)
      {        Ccontrainte* pCcont = dynamic_cast<Ccontrainte *>((*ival)->pObject) ;
        if ((string("") == sName) || (pCcont->getStringAttribute(ATTRIBUT_CONTR_NOM) == sName))
        {
          if (pCcont->getStringAttribute(ATTRIBUT_CONTR_TYPE) == string(VAL_ATTR_CONTR_TYPE_EXP))
            result = AnalyseExpression(pCcont->getStringAttribute(ATTRIBUT_CONTR_EXP)) ;
          else if (pCcont->getStringAttribute(ATTRIBUT_CONTR_TYPE) == string(VAL_ATTR_CONTR_TYPE_EXIST))
          {
            NSPatPathoArray* pPatPathoArray = NULL ;
            string sAlias ;
            string sVarName = pCcont->getStringAttribute(ATTRIBUT_CONTR_VAR) ;
            result = getValeurVariable(sVarName, sAlias, &pPatPathoArray) ;
            if (pPatPathoArray)
              delete pPatPathoArray ;
          }
          else if (pCcont->getStringAttribute(ATTRIBUT_CONTR_TYPE) == string(VAL_ATTR_CONTR_TYPE_COND))
          {
            string sContrExp = pCcont->getStringAttribute(ATTRIBUT_CONTR_EXP) ;
            size_t iBookMark = 0 ;
            result = Interprete(sContrExp, iBookMark) ;
          }

          if (sName != "")
            break ;

          if (result == false)
            break ;
        }
      }
    }
  }

  // parsing des contraintes globales
  Cglobalvars *gVars = getGlobalVars() ;
  if ((NULL != gVars) && (gVars->isVarP(sName, GlobalVar::constraint)))
  {
    switch (gVars->getState(sName, GlobalVar::constraint))
    {
      case GlobalVar::stateNotDef :
      	if      (pValidity->getStringAttribute(ATTRIBUT_CONTR_TYPE) == string(VAL_ATTR_CONTR_TYPE_EXP))
        	result = AnalyseExpression(pValidity->getStringAttribute(ATTRIBUT_CONTR_EXP)) ;
				else if (pValidity->getStringAttribute(ATTRIBUT_CONTR_TYPE) == string(VAL_ATTR_CONTR_TYPE_EXIST))
				{
					NSPatPathoArray * pPPT = NULL ;
					string sAlias ;
					string sVarName = pValidity->getStringAttribute(ATTRIBUT_CONTR_VAR) ;
					result = getValeurVariable(sVarName, sAlias, &pPPT) ;
					if (pPPT)
						delete pPPT ;
				}
				else if (pValidity->getStringAttribute(ATTRIBUT_CONTR_TYPE) == string(VAL_ATTR_CONTR_TYPE_COND))
        {
          string sContrExp = pValidity->getStringAttribute(ATTRIBUT_CONTR_EXP) ;
          size_t iBookMark = 0 ;
					result = Interprete(sContrExp, iBookMark) ;
        }
				break ;
      case GlobalVar::found       : return true ;
      case GlobalVar::notFound    :
      default                     : return false ;
    }
  }
	return result ;
}
catch (...)
{
  erreur("Exception NSValidateur::getValeurContrainte.", standardError, 0) ;
  return false ;
}
}

bool
NSValidateur::AnalyseExpression(string sExp)
{
try
{
  strip(sExp, stripBoth) ;

	// recherche des �l�ments de l'expression
	size_t pos1 = sExp.find(" ") ;
	if (pos1 == string::npos)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("referentialErrors", "validationStringSyntaxError") ;
    sErrorText += string(" ") + sExp ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	// nom de la variable
	string sVarName = string(sExp, 0, pos1) ;

	// operateur
	pos1 = sExp.find_first_not_of(' ', pos1 + 1) ;
	size_t pos2 = sExp.find(" ", pos1) ;
	if (pos2 == string::npos)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("referentialErrors", "validationStringSyntaxError") ;
    sErrorText += string(" ") + sExp ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}
	string sOper = string(sExp, pos1, pos2 - pos1) ;

	// chemin
	pos2 = sExp.find_first_not_of(' ', pos2 + 1) ;
	string sChemin = string(sExp, pos2, strlen(sExp.c_str()) - pos2) ;

  string  sVarAlias ;
	string  sValeur1, sUnite1, sValeur2, sUnite2 ;
	string  sTemp, sFormat ;
	double  dValue1, dValue2 ;
	bool    bValeur = false ;


	// Si le chemin est compos� de Valeur[Unite]
	pos1 = sChemin.find("[") ;
	if (pos1 != string::npos)
	{
		sValeur2 = string(sChemin, 0, pos1) ;
		pos2 = sChemin.find("]", pos1 + 1) ;
		if (pos2 == string::npos)
		{
    	string sErrorText = pContexte->getSuperviseur()->getText("referentialErrors", "validationStringSyntaxError") ;
    	sErrorText += string(" ") + sExp ;
    	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    	erreur(sErrorText.c_str(), standardError, 0) ;
			return false ;
		}
		sUnite2 = string(sChemin, pos1 + 1, pos2 - pos1 - 1) ;
		bValeur = true ;
	}

	NSPatPathoArray* pAnswer = NULL ;
	bool result = false ;

	if (getValeurVariable(sVarName, sVarAlias, &pAnswer))
	{
		if (bValeur)
		{
			PatPathoIter iter = pAnswer->begin() ;
			int iLigneBase = (*iter)->getLigne() ;
			sTemp = "" ;
			sFormat = "" ;

			while ((iter != pAnswer->end()) && ((*iter)->getLigne() == iLigneBase))
			{
				if (((*iter)->pDonnees->lexique)[0] == '�')
				{
					sTemp       = (*iter)->getLexique() ;
					pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
					sValeur1    = (*iter)->getComplement() ;
					sTemp       = (*iter)->getUnit() ;
					pContexte->getDico()->donneCodeSens(&sTemp, &sUnite1) ;
					break ;
			  }
			  iter++ ;
		  }

      if (sUnite1 == sUnite2)
      {
        if (sFormat == "")
          return false ;
        else if (sFormat[1] == 'N')
        {
          dValue1 = atof(sValeur1.c_str()) ;
          dValue2 = atof(sValeur2.c_str()) ;
        }
      }
      else
      {
        if (pAnswer)
          delete pAnswer ;
        return false ;
      }
	  }

	  // cas de la recherche parmis tous les freres
    if (sOper[0] == '*')
    {
      sOper = string(sOper, 1, strlen(sOper.c_str()) - 1) ;
      if (sOper == string("|="))
        result = pAnswer->CheminDansPatpatho(sChemin) ;
      else if (sOper == string("<"))
      {
        if ((bValeur) && (sFormat[1] == 'N'))
          result = (dValue1 < dValue2) ;
      }
      else if (sOper == string("<="))
      {
        if ((bValeur) && (sFormat[1] == 'N'))
          result = (dValue1 <= dValue2) ;
      }
      else if (sOper == string("=="))
      {
        if ((bValeur) && (sFormat[1] == 'N'))
          result = (dValue1 == dValue2) ;
      }
      else if (sOper == string(">"))
      {
        if ((bValeur) && (sFormat[1] == 'N'))
          result = (dValue1 > dValue2) ;
      }
      else if (sOper == string(">="))
      {
        if ((bValeur) && (sFormat[1] == 'N'))
          result = (dValue1 >= dValue2) ;
      }
      else
      {
      	string sErrorText = pContexte->getSuperviseur()->getText("referentialErrors", "invalidOperatorForExpressions") ;
    		sErrorText += string(" -> ") + sOper + string(" in ") + sExp ;
    		pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    		erreur(sErrorText.c_str(), standardError, 0) ;
        if (pAnswer)
          delete pAnswer ;
        return false ;
      }
    }
    else
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("referentialErrors", "invalidOperatorForExpressions") ;
      sErrorText += string(" -> ") + sOper + string(" in ") + sExp ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      erreur(sErrorText.c_str(), standardError, 0) ;
      if (pAnswer)
        delete pAnswer ;
      return false ;
    }
	}

	if (pAnswer)
		delete pAnswer ;

	return result ;
}
catch (...)
{
  erreur("Exception NSValidateur::AnalyseExpression.", standardError, 0) ;
  return false ;
}
}


bool
NSValidateur::carAutorise(char c, bool debut)
{
  if      ((!debut) && (c >= '0') && (c <= '9'))
    return true ;
  else if ((c >= 'A') && (c <= 'Z'))
    return true ;
  else if ((c >= 'a') && (c <= 'z'))
    return true ;
  else if ((!debut) && ((c == '_') || (c == '-') || (c == '+')))
    return true ;

  return false ;
}


// -----------------------------------------------------------------------------
// Fonction d'�valuation du validateur de contraintes
// renvoie 0 ou 1 dans le cas normal, -1 si erreur
// La chaine vide est consid�r�e comme vraie (1) par convention
// -----------------------------------------------------------------------------
int
NSValidateur::Interprete(string sReq, size_t& cc)
{
  int  result = 1 ;
  int  result1 ;
  char oper = ' ' ;
  bool bNegation ;

  while (cc < strlen(sReq.c_str()))  {
    result1 = 1 ;
    bNegation = false ;

    while ((cc < strlen(sReq.c_str())) && (' ' == sReq[cc]))      cc++ ;

    // on �value l'op�rande en cours    if (cc < strlen(sReq.c_str()))
    {
      // on �value d'abord la n�gation
      if ('!' == sReq[cc])
      {
        cc++ ;
        bNegation = true ;
      }

      if (cc == strlen(sReq.c_str()))
      {
        string sErrorText = pContexte->getSuperviseur()->getText("referentialErrors", "validationStringSyntaxError") ;
				sErrorText += string(" ") + sReq ;
    		pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
				erreur(sErrorText.c_str(), standardError, 0) ;
        return -1 ;
      }

      // on doit avoir ici une '(' ou un nom de contrainte
      if (carAutorise(sReq[cc], true))
      {
        string sNomContrainte = "" ;
        while ((cc < strlen(sReq.c_str())) && carAutorise(sReq[cc]))
        {
          sNomContrainte += string(1, sReq[cc]) ;
          cc++ ;
        }
        if (string("") != sNomContrainte)
          result1 = getValeurContrainte(sNomContrainte) ;
      }
      else if ('(' == sReq[cc])
      {
        cc++ ;
        result1 = Interprete(sReq, cc) ;
      }
      else
      {
        string sErrorText = pContexte->getSuperviseur()->getText("referentialErrors", "validationStringSyntaxError") ;
				sErrorText += string(" ") + sReq ;
    		pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
				erreur(sErrorText.c_str(), standardError, 0) ;
        return -1 ;
      }
    }

    // cas erreur � l'�valuation de l'op�rande    if (-1 == result1)
      return -1 ;
    if (bNegation)
      result1 = !result1 ;

    // on calcule le r�sultat selon l'op�rateur en cours    if      (' ' == oper)
      result = result1 ;
    else if ('|' == oper)
      result = result || result1 ;
    else if ('&' == oper)
      result = result && result1 ;

    // on avance � nouveau    while ((cc < strlen(sReq.c_str())) && (' ' == sReq[cc]))
      cc++ ;

    // on �value l'op�rateur    if (cc < strlen(sReq.c_str()))
    {
      // on doit avoir ici une ')' ou un op�rateur
      if (('|' == sReq[cc]) || ('&' == sReq[cc]))
      {
        oper = sReq[cc] ;
        cc++ ;
      }
      else if (')' == sReq[cc])
      {
        cc++ ;
        return result ;
      }
      else
      {
        string sErrorText = pContexte->getSuperviseur()->getText("referentialErrors", "validationStringSyntaxError") ;
				sErrorText += string(" ") + sReq ;
    		pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
				erreur(sErrorText.c_str(), standardError, 0) ;
        return -1 ;
      }
    }
  }
  return result ;
}


string
NSValidateur::getValidator()
{
  string sResult = "" ;
  for (ValIter ival = pValidity->getValArray()->begin() ; ival != pValidity->getValArray()->end() ; ival++)
  {
    if ((*ival)->sLabel == LABEL_VALIDATEUR)
    {      Cvalidateur* pCvalidator = dynamic_cast<Cvalidateur *>((*ival)->pObject) ;
      sResult = pCvalidator->getStringAttribute(ATTRIBUT_VALIDATEUR_COND) ;
      break ;
    }
  }
  return sResult ;
}


bool
NSValidateur::Validation()
{
  string sValidator = getValidator() ;
  bool result ;

  if (sValidator == "")
    result = getValeurContrainte() ;
  else
  {
    size_t iBookMark = 0 ;
    result = Interprete(sValidator, iBookMark) ;
  }
  return result ;
}


Cglobalvars *
NSValidateur::getGlobalVars()
{
  // we get the root balise e.g. the proposition balise
  Cbalise *fatherBalise = pValidity->parent ;
  Cbalise *rootBalise = pValidity ;
  while (fatherBalise != NULL)
  {
    rootBalise = fatherBalise ;
    fatherBalise = rootBalise->parent ;
  }

  Creferentiel *refBalise = dynamic_cast<Creferentiel *>(rootBalise) ;
  if (refBalise != NULL)
  {
    Cglobalvars *gVars = refBalise->getGVars() ;
    if (gVars != NULL)
      return gVars ;
  }

  return NULL ;
}



// -----------------------------------------------------------------------------
//
// Classe NSControlTextArray
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------NSControlTextArray::NSControlTextArray(const NSControlTextArray& rv)  : NSControlTextVector(){try{  if (!rv.empty())    for (NSControlTextCIter i = rv.begin() ; i != rv.end() ; i++)      push_back(new NSControlText(*(*i))) ;}catch (...)
{
  erreur("Exception NSControlTextArray copy ctor.", standardError, 0) ;
}}

NSControlTextArray&
NSControlTextArray::operator=(const NSControlTextArray& src)
{try{	if (this == &src)		return *this ;  vider() ;  if (!src.empty())    for (NSControlTextCIter i = src.begin() ; i != src.end() ; i++)      push_back(new NSControlText(*(*i))) ;  return (*this) ;}catch (...)
{
  erreur("Exception NSControlTextArray = operator.", standardError, 0) ;
  return (*this) ;
}}

voidNSControlTextArray::vider(){  if (!empty())	  for (NSControlTextIter i = begin() ; i != end() ; )    {      delete (*i) ;      erase(i) ;    }}
NSControlTextArray::~NSControlTextArray(){	vider() ;}



// -----------------------------------------------------------------------------
//
// Classe NSControlText
//
// -----------------------------------------------------------------------------


NSControlText::NSControlText(Citem* pCitem)
{
  item    = pCitem ;
  button  = 0 ;
  texte   = 0 ;
  edit    = 0 ;
}


NSControlText::~NSControlText()
{
  // on ne delete pas les items car
  // ils sont rattach�s au parseur
  if (button)
    delete button ;
  if (texte)
    delete texte ;
  if (edit)
    delete edit ;
}


NSControlText::NSControlText(const NSControlText& rv)
{
  item    = rv.item ;
  button  = rv.button ;
  texte   = rv.texte ;
  edit    = rv.edit ;
  fils    = rv.fils ;
}

NSControlText&
NSControlText::operator=(const NSControlText& src)
{
	if (this == &src)
		return *this ;

  item    = src.item ;
  button  = src.button ;
  texte   = src.texte ;
  edit    = src.edit ;
  fils    = src.fils ;

  return (*this) ;
}

// -----------------------------------------------------------------------------
//
// Classe nsarcDialog
//
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(nsarcDialog, TDialog)
  EV_COMMAND(IDCANCEL,     CmCancel),
	EV_COMMAND(IDOK,         CmOk),
END_RESPONSE_TABLE ;


nsarcDialog::nsarcDialog(TWindow* Parent, NSContexte* pCtx, nsarcParseur* parseur)
  : TDialog(Parent, "DLG_BASE", pNSDLLModule),
    NSRoot(pCtx)
{
try
{
  pParseur = parseur ;
  pControl = new NSControlText(parseur->pArchetype->getRootItem()) ;
  InitControles(pControl->item, pControl) ;
}
catch (...)
{
  erreur("Exception nsarcDialog ctor.", standardError, 0) ;
}
}


nsarcDialog::~nsarcDialog()
{
  delete pControl ;
}


void
nsarcDialog::SetupWindow()
{
try
{
  NS_CLASSLIB::TRect cvtRect ;

  iBoxHeight = 10 ;    // hauteur du bouton
  iBoxWidth  = 150 ;   // largeur du bouton
  iBoxInterv = 3 ;     // intervalle entre deux boutons
  iBoxTop    = 4 ;     // haut du 1er bouton
  iBoxLeft   = 15 ;    // d�calage gauche des boutons

  iSeparLeft = 3 ;     // gauche du s�parateur
  iGB_Separ  = 3 ;     // intervalle entre le bas du groupbox et le s�parateur
  iSepar_Btn = 8 ;     // intervalle entre le s�parateur et le bouton

  iBtnHeight = 25 ;    // hauteur d'un bouton Borland  iBtnWidth  = 43 ;    // largeur d'un bouton Borland
  iBtnLeft   = 3 ;     // gauche du premier bouton
  iBtn_bas   = 3 ;     // intervalle entre le bas du bouton et le bas de la boite

  iTotalWidth = 0 ;  iTopOfBox = iBoxTop ;
  iID = 200 ;

  SetupControles(pControl, 0, iTopOfBox) ;

  // On fixe la taille de la boite de dialogue
  iTotalHeight = iTopOfBox + iGB_Separ + iSepar_Btn + iBtnHeight + iBtn_bas ;  iTotalWidth += iBoxLeft ;
  NS_CLASSLIB::TRect dlgSizeRect(0, 0, iTotalWidth, iTotalHeight) ;  MapDialogRect(dlgSizeRect) ;  // On cr�e le s�parateur  int iSepareTop = iTopOfBox + iGB_Separ ;

  cvtRect = NS_CLASSLIB::TRect(iSeparLeft, iSepareTop, iSeparLeft + iTotalWidth - (2 * iSeparLeft), iSepareTop + 3) ;  MapDialogRect(cvtRect) ;

  TGroupBox* pDip = new TGroupBox(this, -1, "", cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), /*TModule**/ 0) ;  pDip->Attr.Style |= BSS_HDIP ;

  // On cr�e les boutons  int iNbBtn = 3 ;
  int iBtnInterv = (iTotalWidth - (2 * iBtnLeft) - (iNbBtn * iBtnWidth)) / (iNbBtn - 1) ;
  int iBtnTopPos  = iSepareTop + iSepar_Btn ;
  int iBtnLeftPos = iBtnLeft ;

  // Bouton OK
  cvtRect = NS_CLASSLIB::TRect(iBtnLeftPos, iBtnTopPos, iBtnLeftPos + iBtnWidth, iBtnTopPos + iBtnHeight) ;  MapDialogRect(cvtRect) ;
  /* TButton* pBtOK = */ new TButton(this, IDOK, "", cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), /*isDefault*/ false, 0) ;

  iBtnLeftPos += iBtnWidth + iBtnInterv ;
  // Bouton CANCEL  cvtRect = NS_CLASSLIB::TRect(iBtnLeftPos, iBtnTopPos, iBtnLeftPos + iBtnWidth, iBtnTopPos + iBtnHeight) ;  MapDialogRect(cvtRect) ;
  /* TButton* pBtCn = */ new TButton(this, IDCANCEL, "", cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), /*isDefault*/ false, 0) ;
  iBtnLeftPos += iBtnWidth + iBtnInterv ;
  // Bouton HELP  cvtRect = NS_CLASSLIB::TRect(iBtnLeftPos, iBtnTopPos, iBtnLeftPos + iBtnWidth, iBtnTopPos + iBtnHeight) ;  MapDialogRect(cvtRect) ;
  /* TButton* pBtHl = */ new TButton(this, IDHELP, "", cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), /*isDefault*/ false, 0) ;
  iBtnLeftPos += iBtnWidth + iBtnInterv ;
  // Titre de la boite de dialogue  SetCaption("Arch�type") ;  // Appel du SetupWindow() de TDialog  TDialog::SetupWindow() ;

  // Redimentionnemen t
  NS_CLASSLIB::TRect dlgRect ;
  GetWindowRect(dlgRect) ;
  NS_CLASSLIB::TRect clientRect ;
  GetClientRect(clientRect) ;

  // On compare le clientRect r�el avec les dimensions souhait�es,  // et on modifie le WindowRect en cons�quence
  int nouvWindowWidth  = dlgRect.Width()  + (dlgSizeRect.Width()  - clientRect.Width()) ;
  int nouvWindowHeight = dlgRect.Height() + (dlgSizeRect.Height() - clientRect.Height()) ;

  MoveWindow(dlgRect.left, dlgRect.top, nouvWindowWidth, nouvWindowHeight) ;
}
catch (...)
{
  erreur("Exception nsarcDialog SetupWindow.", standardError, 0) ;
}
}


void
nsarcDialog::InitControles(Citem* item, NSControlText* control)
{
try
{
  if (item->vect_val.empty())
    return ;

  for (ValIter ival = item->vect_val.begin() ; ival != item->vect_val.end() ; ival++)
  {
    if ((*ival)->sLabel == LABEL_ITEM)
    {      // on doit ins�rer la valeur avant le petit fr�re      Citem* pCitem = dynamic_cast<Citem*>((*ival)->pObject) ;

      if (pCitem->getControl() == string(VAL_ATTR_ITEM_CTRL_ACTIF))
      {
        NSControlText* pCont = new NSControlText(pCitem) ;
        control->fils.push_back(pCont) ;
        InitControles(pCitem, pCont) ;
      }
      else
        InitControles(pCitem, control) ;
    }
  }
}
catch (...)
{
  erreur("Exception nsarcDialog InitControles.", standardError, 0) ;
}
}


void
nsarcDialog::SetupControles(NSControlText* control, int left, int& top)
{
try
{
  NS_CLASSLIB::TRect cvtRect ;

  if (control->item->getControl() == string(VAL_ATTR_ITEM_CTRL_ACTIF))
  {
    string sCode = control->item->getCode() ;
    if (sCode.find("�") != string::npos)
    {
      // Rectangle du texte de l'edit
      cvtRect = NS_CLASSLIB::TRect(left, top, left + iBoxWidth, top + iBoxHeight) ;      MapDialogRect(cvtRect) ;
      // Titre      string sTitre = control->item->getText() ;      // static      control->texte = new TStatic(this, -1, sTitre.c_str(), cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), 0, 0) ;
      // Rectangle du champ edit
      cvtRect = NS_CLASSLIB::TRect(left, top + iBoxHeight, left + iBoxWidth, top + (2*iBoxHeight)) ;      MapDialogRect(cvtRect) ;
      // champ edit      control->edit = new TEdit(this, iID, "", cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height()) ;      top += (2*iBoxHeight) + iBoxInterv ;
      iID++ ;
    }
    else // (bouton)
    {
      // Rectangle du bouton
      cvtRect = NS_CLASSLIB::TRect(left, top, left + iBoxWidth, top + iBoxHeight) ;      MapDialogRect(cvtRect) ;
      // Titre      string sTitre = control->item->getText() ;      // bouton      control->button = new nsrefButton(this, pContexte, iID, sTitre.c_str(), cvtRect.Left(), cvtRect.Top(), cvtRect.Width(), cvtRect.Height(), 0, 0) ;
      top += iBoxHeight + iBoxInterv ;
      iID++ ;
    }
  }

  if (!control->fils.empty())
  {
    if ((left + iBoxLeft + iBoxWidth) > iTotalWidth)
      iTotalWidth = left + iBoxLeft + iBoxWidth ;

    for (NSControlTextIter i = control->fils.begin() ; i != control->fils.end() ; i++)
      SetupControles(*i, left + iBoxLeft, top) ;
  }
}
catch (...)
{
  erreur("Exception nsarcDialog SetupControles.", standardError, 0) ;
}
}

void
nsarcDialog::CmOk()
{
  TDialog::CmOk() ;
}

void
nsarcDialog::CmCancel()
{
  TDialog::CmCancel() ;
}

// -----------------------------------------------------------------------------
//
// Classe NSDrufRefFileManager
//
// -----------------------------------------------------------------------------

NSDrufRefFileManager::NSDrufRefFileManager(NSContexte* pCtx) : NSRoot(pCtx)
{
	pRefParseur       = 0 ;
  sFullPathFileName = string("") ;
}

NSDrufRefFileManager::~NSDrufRefFileManager()
{
	if (NULL != pRefParseur)
		delete pRefParseur ;
}

bool
NSDrufRefFileManager::writeFile()
{
	if ((NULL == pRefParseur) || (string("") == sFullPathFileName))
		return false ;

	Creferentiel* pReferential = pRefParseur->pReferentiel ;
  if (NULL == pReferential)
		return false ;

  return true ;
}

