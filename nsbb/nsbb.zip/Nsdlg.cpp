//**************************************************************************//  NOM du FICHIER : NSDLG.CPP
//
//  Impl�mentation des m�thodes de :
//     NSDialog
//     NSDialogModal
//     NSDialogModeless
//
//  Auteur : KRZISCH Ph.
// Date de cr�ation : juin 93             mise � jour : mai 94
//**************************************************************************
#include <iostream.h>
#include <typeinfo.h>
#include <string.h>

#include <owl/owlpch.h>

//#include <regexp.h>
#include <cstring.h>
#include <bwcc.h>

#include <owl/module.h>
#include <owl/edit.h>
#include <owl/static.h>
#include <owl/radiobut.h>
#include <owl/checkbox.h>
#include <owl/groupbox.h>
#include <owl/listbox.h>
#include <owl/combobox.h>
#include <owl/scrollba.h>
#include <owl/validate.h>

#include "partage\nsglobal.h"

//#include "nsutil.h"
#include "partage\nsapp.h"
#include "nsutil\nscache.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbbsmal.h"
#include "nsutil\nsutil.h"
#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"
#include "nautilus\nsdochis.h"
#include "nautilus\nshistdo.h"
#include "nsbb\nstrewi.h"
#include "nsbb\nsedilex.h"
#include "nsbb\nsedit.h"
#include "nsbb\nsdico.h"
#include "nsbb\nsbouton.h"
#include "nsbb\nschkbox.h"
#include "nsbb\nsradiob.h"
#include "nsbb\nsgroupe.h"
#include "nsbb\nsonglet.h"
#include "nsbb\nscombo.h"
#include "nsbb\nslistwind.h"

#include "nsbb\nsbb.h"
#include "nsbb\nsbb_msg.h"
#include "nsbb\nsbb.rh"
#include "nsbb\nsarc.h"
#include "partage\ns_vector.h"
#include "partage\ns_timer.h"
#include "nsbb\ns_multi.h"
#include "dcodeur\nsgenlan.h"
#include "dcodeur\decoder.h"
#include "nautilus\nsepicap.h"
#include "nautilus\nscqvue.h"
#include "nssavoir\nsconver.h"
#include "nsbb\nsPaneSplitter.h"
#include "nsbb\nsdefArch.h"

#include "ns_ob1\Interface.h"
#include "ns_ob1\InterfaceForKs.h"
#include "ns_ob1\BB1Task.h"

#include "ns_ob1\OB1.rh"
#include "nautilus\nautilus.rh"

const char  codeMARK    = 'O';

const string     NULLSTRING        = string("") ;
int				    	 NULLINT           = 0 ;
Voidptr			     NULLPTR           = NULL ;
PatPathoIter     *NULLPATPATHOITER = (PatPathoIter *) NULL;
NSPatPathoArray	 *NULLPATHO        = (NSPatPathoArray *) NULL ;
PathsList		     *NULLPATHS        = (PathsList *) NULL ;
BB1Object				 *NULLOBJECT       = (BB1Object *) NULL ;
NautilusQuestion *NULLLNAUTQUEST   = (NautilusQuestion *) NULL ;
NautilusEvent		 *NULLNAUTILUSEVENT	= (NautilusEvent *) NULL ;

//#include "nsbb\nsconclu.h"

//#include "kebis.h"

//void strAnalyse(const char* input, const char* separateurs,
//					 CacheArray& elts, int nb=1);
//void    strAnalyse(Pchar input, Pchar separateurs, CacheArray& elts, int nb = 1);
//void    strAnalyse(Pchar input, Pchar separateurs, Pchar elts[], int nb = 1);//bool    ptrInit(char** strPtr, int length, char car = ' ');
//bool    ptrInit(char** strPtr, const char* strInit);

// D�finition des expressions r�guli�res
//const TRegexp MWord("[A-Z][a-z]+");   // Mot commen�ant par une majuscule
//const TRegexp mWord("[a-z]+");        // Mot en minuscule
//const TRegexp Naturel("[0-9]+");      // Nombre naturel
//const TRegexp Entier("(+|-)[0-9]+");  // Nombre entier

//---------------------------------------------------------------------------
//  Configuration des bo�tes de dialogue
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
const char szSepare[]= "/;";  // Cha�ne des s�parateurs utilis�s pour
										// la configuration des bo�tes de Dialogue
typedef void* Pvoid;
HINSTANCE hInstance;

//***************************************************************************
// Impl�mentation des m�thodes NSDialog
//***************************************************************************
//$$ ID du contr�le NSBitmap
#define DIALOG_1  1

// Table de r�ponses aux messages
DEFINE_RESPONSE_TABLE1(NSDialog, TDialog)
	EV_COMMAND(IDCANCEL,      CmCancel),
	EV_COMMAND(IDOK,          CmOk),
	EV_COMMAND(IDRETOUR,      CmRetour),
	EV_COMMAND(IDSUITE,       CmSuite),
	EV_COMMAND(IDHELPWWW,     CmHelp),
	EV_COMMAND(IDHELP,        CmHelp),
	EV_COMMAND(IDTREEPASTE,   CmTreePaste),
	EV_COMMAND(IDCONCLUSION,  CmConclusion),
	EV_COMMAND(IDBBKCALCUL,   CmBbkCalcul),  EV_COMMAND(IDM_BBK_EVENT, CmBbkEvent),	// EV_WM_MOVE,	// EV_WM_WINDOWPOSCHANGED,
	EV_WM_ACTIVATE,
	EV_WM_NCACTIVATE,
	EV_WM_SETFOCUS,
	EV_WM_WINDOWPOSCHANGING,
	EV_WM_LBUTTONDOWN,
  EV_WM_TIMER,
END_RESPONSE_TABLE ;

//---------------------------------------------------------------------------
//  Function: NSDialog::NSDialog(TWindow* AParent, TResId ResourceID,
//                               TResId ConfigResID, BBItem* pItem)
//
//  Arguments:
//            AParent       -> Pointeur sur l'objet Parent
//            ResourceID    -> ID de la ressource
//            Config5ResID  -> ID de la ressource de configuration
//			  pItem			-> Pointeur sur le BBItem cr�ateur
//  Description:
//            Constructeur de NSDialog qui appelle le constructeur de
//            TDialog.
//  Returns:
//            RIEN
//---------------------------------------------------------------------------
NSDialog::NSDialog( NSContexte    *pCtx,
                    TWindow       *AParent,
                    TResId        ResourceID,
                    TResId        ConfResID,
                    BBItem        *pItem,
                    TModule       *pResModule,                    NsMultiDialog *pControlMulti)         :TDialog(AParent, ResourceID, pResModule), NSRoot(pCtx){
	ResID            = ResourceID ;
	ConfigResID      = ConfResID ;
	bPOMRDialog      = false ;	init(pItem, pControlMulti) ;
	bMereMUEView     = false ;
	bActivateMUEView = true ;
  bOkActivated     = false ;
  bBlackboardStillAtWork = false ;
}

NSDialog::NSDialog( NSContexte    *pCtx,
                    TWindow       *AParent,
                    BBItem        *pItem,
                    TModule       * /*pResModule */,
                    NsMultiDialog *pControlMulti)
         :TDialog(AParent, "DLG_BASE", pNSDLLModule), NSRoot(pCtx){
	ResID            = 0 ;
	ConfigResID      = 0 ;
	bPOMRDialog      = false ;
	init(pItem, pControlMulti) ;
	bMereMUEView     = false ;
	bActivateMUEView = true ;
  bOkActivated     = false ;
  bBlackboardStillAtWork = false ;
}

void
NSDialog::init(BBItem* pItem, NsMultiDialog* pControlMulti)
{
try
{
	pNSCtrl     = new NSControleVector() ;
	pConfigCtrl = new NSDialogVector() ;
	pBBItem 	  = pItem ;

	// Si le dialogue est dynamique, on ne se pr�occupe pas de DLL
	if (ResID != 0)
		pNSResModule = pItem->pBigBoss->TrouverModule(pItem->pDonnees->fichierDialogue) ;
	else
		pNSResModule = 0 ;

	pControleur	  = 0 ;
	pConfigEdit	  = 0 ;
	pConfigOnglet = 0 ;
	pConfigHelp   = 0 ;
	pResInfo	  = 0 ;	canCloseOk = false ;	// pDefRegions	  = 0;
	pControleurMulti = pControlMulti ;
	for (int i = 0; i < 20; i++)
		pConfigCache[i] = 0 ;
	pConfigCacheTab = 0 ;
	pGroupCurr		= 0 ;
	iNbrCtrl = 0 ;
	//$$ Temporaire
	hInstance = GetModule()->GetInstance() ;

	sHelpBodyUrl    = "" ;
	sHelpIndexUrl   = "" ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;
	if (pSuper)
	{
		pSuper->setAideIndex("") ;
		pSuper->setAideCorps("zz_generique.htm") ;
	}

	if (ResID != 0)
		initialiseRessources(ResID, ConfigResID) ;
	// else if ((pBBItem == pBBItem->pBigBoss->pBBItem) && (pBBItem->ouvreArchetype()))
	else if (pBBItem->ouvreArchetype())
		initialiseRessourcesArchetype() ;

	if (pControlMulti)
		pControlMulti->referenceDialogue(this) ;

	pView       = 0 ;
	bCanMove    = true ;
}
catch (...)
{
	erreur("Exception NSDialog::init.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSDialog::~NSDialog()
{
	Desactive() ;
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void NSDialog::Desactive()
{
	if (!bActif)
		return ;

	int i;	for (i = 0; i < 20; i++)
	{
		if (pConfigCache[i])
		{
			delete pConfigCache[i] ;
			pConfigCache[i] = 0 ;
		}
	}
	if (pConfigCacheTab)
	{
		delete pConfigCacheTab ;
    pConfigCacheTab = 0 ;
	}

	if (pControleur)
	{
		delete pControleur;
		pControleur = 0;
	}
	if (pConfigEdit)
	{
		delete pConfigEdit;
		pConfigEdit = 0;
	}
  if (pConfigHelp)
	{
		delete pConfigHelp;
		pConfigHelp = 0;
	}
  if (pConfigOnglet)
	{
		delete pConfigOnglet;
		pConfigOnglet = 0;
	}
	if (pResInfo)
	{
		delete pResInfo;
		pResInfo = 0;
	}
    /*
	if (pDefRegions)	{
		delete pDefRegions;
		pDefRegions = 0;
	}
    */    /*	if (isOnglet)	{
	}
    */
	if (pNSCtrl)
  {
  	delete pNSCtrl ;
    pNSCtrl = 0 ;
  }
  if (pConfigCtrl)
  {
  	delete pConfigCtrl ;
    pConfigCtrl = 0 ;
  }
	if (!(aGroups.empty()))
  {
  	vector<OWL::TGroupBox*>::iterator BBGrpIter = aGroups.begin() ;
    for ( ; BBGrpIter != aGroups.end() ; )
    {
    	delete *BBGrpIter ;
      aGroups.erase(BBGrpIter) ;
    }
  }

	bActif = false ;
}

//---------------------------------------------------------------------------//  Function: NSDialog::SetupWindow()
//
//  Arguments:
//	    AUCUN
//  Description:
//	    Sert � configurer tous les contr�les si n�cessaire.
//          Initialise �galement la PvoidArray qui va servir
//          � m�moriser l'adresse de tous les emplacements de m�moire
//          servant au transfert de donn�es des diff�rents contr�les de
//          la bo�te de dialogue. Ce vecteur est la propri�t� de BigBrother
//          puisque celui-ci est le seul � conna�tre le moment opportun de
//          destruction de l'objet de transfert.
//          (Cela pose un probl�me d'encapsulation C++)
//  Returns:
//	    RIEN
//---------------------------------------------------------------------------
void
NSDialog::SetupWindow()
{
  NSSuper *pSuper = pContexte->getSuperviseur() ;

  string ps = string("Entr�e dans SetupWindow de NSDialog") ;
  pSuper->trace(&ps, 1) ;

  // En cas de perte du focus, on cache l'�ventuelle fen�tre de pilotage
  // de description multiple pour �viter sa s�lection � partir d'une fen�tre
  // fille de cette boite de dialogue
  TWindow   *pMere = Parent ;
  NSDialog  *pDialog = TYPESAFE_DOWNCAST(pMere, NSDialog) ;
  if (pDialog)
  {
    if (pDialog->pControleurMulti)
      pDialog->pControleurMulti->Show(SW_HIDE) ;
  }

  if (pControleurMulti)
  {
    pControleurMulti->setPosition(this) ;
    // donner un titre aux (pBBItem->pBBFilsPere->VectorFils.size())
    // bo�tes pBBItem->pBBFilsPere->VectorFils.size() = nombre de
    // bo�tes multidialogue
    pControleurMulti->setTitre(this, pBBItem->pBBFilsPere->VectorFils.size()) ;
  }

  // Si le dialogue est statique, on �num�re ses contr�les pour cr�er les
  // bons objets
  if (ResID != 0)
  {
    WNDENUMPROC lpEnumDlgFunc ;

    // Enum�ration et configuration des contr�les

    // Initialisation des variables incr�ment�es dans l'�num�ration
    iIndexCtrl = 0 ;
    iIndexEdit = 0 ;

    pSuper->afficheStatusMessage("Connexion des contr�les") ;

    // Pr�paration de la fonction d'�num�ration
    lpEnumDlgFunc = (WNDENUMPROC) MakeProcInstance((FARPROC) NSDialog::DlgConfigCtrl, hInstance) ;

    // On passe comme param�tre de EnumChildWindows LPARAM(this), l'adresse de
    // this puisque dans les fonctions static on ne peut pas r�cup�rer le
    // pointeur this.
    EnumChildWindows(HWindow, lpEnumDlgFunc, LPARAM((TWindow *)this)) ;

    TDialog::SetupWindow() ;
   
  }
  // else if ((pBBItem == pBBItem->pBigBoss->pBBItem) && (pBBItem->ouvreArchetype()))
  else if (pBBItem->ouvreArchetype())
    CreerControlesArchetype() ;

  // Si le dialogue est dynamique, on cr�e � la main ses contr�les
  else
    CreerControles() ;


	// Appel obligatoire au SetupWindow() de l'anc�tre


	// Il est inutile de lancer ForEach avant TDialog::SetupWindow, car ChildList
  // n'est pas encore instanci�

	// Marche ForEach((TActionFunc)(&(NSDialog::DlgConfigCtrl2)), (void *)((TWindow *)this)) ;

	// Lance les �ventuelles fonctions d'initialisation des contr�les
	initialiseControles();

  // Lorsqu'on initialise � partir du blackboard en mod "SetupWindow" par default
	if (pBBItem->KsInterface.getInitFromBbk())
    initControlesFromBbk() ;

  // v�rification qu'il y a quelquechose dans les variables de la capture
  if (!pSuper->getEpisodus()->CaptureArray.empty())
  {
    initControlesFromCapture() ;
    // pSuper->pEpisodus->CaptureArray.vider() ;
  }

	// Initialise les contr�les NAUTILUS en fonction du contexte Big Brother
	rafraichitControles() ;

  // It's time for the BBItem to cut bad branches: Ordinary "Fils Guides" that
  // got connected to leaves but don't open a dialog. They tend to cause system
  // hanging
  //
	if (false == pBBItem->ouvreArchetype())
		pBBItem->cutBadDialogBranches(this) ;

	//$$ Temporaire
	// ConfigShow() ;
  pSuper->afficheStatusMessage("") ;

  if (pView)
  {
    if (pSuper->getDPIO())
    {
      ps = string("SetupWindow de NSDialog, partie sp�cifique � DPIO") ;
      pSuper->trace(&ps, 1) ;

      NS_CLASSLIB::TRect dlgRect ;
      GetWindowRect(dlgRect) ;

      int iWidth  = dlgRect.Width() ;
      int iHeigth = dlgRect.Height() ;

      int iX = pSuper->getDPIO()->iCurrentX ;
      int iY = pSuper->getDPIO()->iCurrentY ;

      SetWindowPos(0, iX, iY, iWidth, iHeigth, SWP_NOZORDER);

      pSuper->getDPIO()->iCurrentX += pSuper->getDPIO()->iDeltaPosX ;
      pSuper->getDPIO()->iCurrentY += pSuper->getDPIO()->iDeltaPosY ;
    }
  }
  ps = string("Sortie de SetupWindow de NSDialog") ;
  pSuper->trace(&ps, 1) ;
}


//---------------------------------------------------------------------------
//  Function: 		NSDialog::initialiseRessources()
//
//  Arguments:		AUCUN
//
//  Description:	Initialise les descripteurs de ressources situ�s dans
//						le fichier '_INIT'
//
//  Returns:		true si OK, false en cas d'erreur
//---------------------------------------------------------------------------
bool
NSDialog::initialiseRessources(TResId ResourceID, TResId ConfigResID)
{
    //
	// Une NSDialog poss�de TOUJOURS une ressource de configuration
	//
	if (ConfigResID == 0)
	{
		char nomConfigRes[BB_NOM_DIALOGUE_LEN + 5];
		strcpy(nomConfigRes, ResourceID);
		strcat(nomConfigRes, "_INIT");
		ConfigResID = nomConfigRes;
	}
	if (LoadConfigResource(ConfigResID))
	{		//
		// Analyse de la ressource de configuration
		//
		AnalyseRes();
		//
		// Cr�ation de la matrice de configuration pour le contr�leur
		//
		if (pControleur)
		{
			AnalyseCtrl(pControleur->c_str(), "|:");
			delete pControleur;
			pControleur = 0;
		}
		//
		// Cr�ation de la matrice de configuration pour les contr�les EDIT
		//
		if (pConfigEdit)
		{
			AnalyseEdit(pConfigEdit->c_str(), szSepare);
			delete pConfigEdit;
			pConfigEdit = 0;
		}
        //
		// Cr�ation de la matrice de configuration pour les onglets
		//
		if (pConfigOnglet)
		{
			AnalyseOnglet(pConfigOnglet->c_str(), szSepare);
			delete pConfigOnglet;
			pConfigOnglet = 0;
		}
        //
		// Initialisation de l'aide en ligne
		//
		if (pConfigHelp)
		{
            //MessageBox("Entr�e dans AnalyseHelp", "", MB_ICONEXCLAMATION);
			AnalyseHelp(pConfigHelp->c_str(), szSepare);
			delete pConfigHelp;
			pConfigHelp = 0;
		}
        else
            AnalyseHelp("", szSepare);

		// Cr�ation de la matrice de configuration des r�gions d'un bitmap
		// pBitmapRegion = new DefRegion[ ]

		// Cr�ation de la matrice de transfert
		// pTransferBuf = new NSTransferArray;
		// SetTransferBuffer(dynamic_cast<void*>(pTransferBuf));
		delete pResInfo;
		pResInfo = 0;
	}
	else
    {
		// Message d'erreur
        return false ;
	}
    bActif = true;
    return true ;
}

//---------------------------------------------------------------------------
//  Function: 		NSDialog::initialiseRessourcesArchetype()
//
//  Arguments:		AUCUN
//
//  Description:	Initialise les descripteurs de ressources situ�s dans
//						le fichier '_INIT'
//
//  Returns:		true si OK, false en cas d'erreur
//---------------------------------------------------------------------------
bool
NSDialog::initialiseRessourcesArchetype()
{
	if (!pBBItem || !(pBBItem->pParseur) || !(pBBItem->pParseur->pArchetype))
		return false ;
    
	//
	// Une NSDialog poss�de TOUJOURS une ressource de configuration
	//
  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	Cdialogbox* pDialogBox = pBBItem->pParseur->pArchetype->getDialogBox(sLang);
	if (!pDialogBox)
		return false ;

	// Crcdata* pRCData = pDialogBox->getRCData();

	pResInfo = new string(pDialogBox->getValueRCData());

	//	// Analyse de la ressource de configuration
	//
	AnalyseRes() ;

	//	// Cr�ation de la matrice de configuration pour le contr�leur
	//
	if (pControleur)
	{
		AnalyseCtrl(pControleur->c_str(), "|:") ;
		delete pControleur ;
		pControleur = 0 ;
	}

    //    // Cr�ation de la matrice de configuration pour les contr�les EDIT
    //
    if (pConfigEdit)
    {
        AnalyseEdit(pConfigEdit->c_str(), szSepare);
        delete pConfigEdit;
        pConfigEdit = 0;
    }

    //    // Cr�ation de la matrice de configuration pour les onglets
    //
    if (pConfigOnglet)
    {
        AnalyseOnglet(pConfigOnglet->c_str(), szSepare);
        delete pConfigOnglet;
        pConfigOnglet = 0;
    }

    //    // Initialisation de l'aide en ligne
    //
    if (pConfigHelp)
    {
        //MessageBox("Entr�e dans AnalyseHelp", "", MB_ICONEXCLAMATION);
        AnalyseHelp(pConfigHelp->c_str(), szSepare);
        delete pConfigHelp;
        pConfigHelp = 0;
    }
    else
        AnalyseHelp("", szSepare);

    // Cr�ation de la matrice de configuration des r�gions d'un bitmap    // pBitmapRegion = new DefRegion[ ]

    // Cr�ation de la matrice de transfert    // pTransferBuf = new NSTransferArray;
    // SetTransferBuffer(dynamic_cast<void*>(pTransferBuf));

    delete pResInfo;    pResInfo = 0;

    bActif = true;    return true ;}
void
NSDialog::AnalyseCtrl(const char *input, const char *separateurs)
{
try
{
	if (!input || !separateurs)
		return ;

  size_t posit, pos ;
  char  separe[2] ;
  string vide = " " ;
  string sCopie = string(input) ;
  string sIdentite ;

  separe[0] = separateurs[0] ;
  separe[1] = '\0' ;
  size_t posApres = sCopie.find(separe[0]) ;
  size_t posAvant = 0 ;
	while ((posApres != string::npos) && (posApres < strlen(sCopie.c_str())))
	{
		NSDialogCtrl* pConfigCt = new NSDialogCtrl() ;
		pConfigCt->sIdentite = string(sCopie, posAvant, posApres - posAvant) ;
    posit     = (pConfigCt->sIdentite).find(separateurs[1]) ;
    sIdentite = pConfigCt->sIdentite ;

    if ((posit != string::npos) && (posit < strlen(sIdentite.c_str())))
    {
      pConfigCt->sIdentite    = string(sIdentite, 0, posit) ;
      pConfigCt->sDlgFonction = string(sIdentite, posit + 1, strlen(sIdentite.c_str())) ;
    }

    pos = (pConfigCt->sIdentite).find(vide) ;
    if (pos != string::npos)
      pConfigCt->sIdentite = string("") ;

    pConfigCtrl->push_back(pConfigCt) ;
    posAvant = posApres + 1 ;
		posApres = sCopie.find(separe[0], posApres + 1) ;
  }
}
catch (...)
{
  erreur("Exception NSDialog::AnalyseCtrl.", standardError, 0) ;
}
}

void
NSDialog::AnalyseEdit(const char *input, const char *separateurs)
{
try
{
	if (!input || !separateurs)
		return ;

  int 	i = 0 ;
	char  *szCur ;
	char  *copie ;

  copie = new char[strlen(input) + 1] ;
	strcpy(copie, input) ;

	szCur = strtok(copie, separateurs) ;

  while (szCur != NULL)
	{
		pConfigCache[i] = new NSDialogEdit ;
		strcpy(pConfigCache[i]->szType, szCur) ;

		szCur = strtok(NULL, separateurs) ;
		if (szCur != NULL)
		{
			pConfigCache[i]->nMaxInput = atoi(szCur) ;
			szCur = strtok(NULL, separateurs) ;
		}
		i++ ;
	}
  delete[] copie ;
}catch (...)
{
  erreur("Exception NSDialog::AnalyseEdit.", standardError, 0) ;
}
}

void
NSDialog::AnalyseOnglet(const char *input, const char *separateurs)
{
try
{
	if (!input || !separateurs)
		return ;

  char  *szCur ;
	char  *copie ;

  copie = new char[strlen(input) + 1] ;
	strcpy(copie, input) ;

  // La cha�ne de configuration est de la forme :
  // "Mitrale/Mitrale;Aortique;Aorte;Pulmonaire;Tricuspide;Cavit�s/"
  // cad
  // "OngletActif/Onglet1;Onglet2;Onglet3/"

	// strtok place un \0 � la fin de l'�l�ment si il est trouv�
	szCur = strtok(copie, separateurs) ;
  if (szCur != NULL)
  {
    pConfigCacheTab = new NSDialogOnglet ;
    pConfigCacheTab->sOngletActif = string(szCur) ;
    szCur = strtok(NULL, separateurs) ;
    pConfigCacheTab->nNbOnglets = 0 ;
  }
	while ((pConfigCacheTab) && (szCur != NULL))
	{
    if (*szCur != '\0')
    {
      pConfigCacheTab->pTexteOnglets[pConfigCacheTab->nNbOnglets] = new string(szCur) ;
      pConfigCacheTab->nNbOnglets++ ;
    }
    szCur = strtok(NULL, separateurs) ;
  }
	delete[] copie ;
}
catch (...)
{
  erreur("Exception NSDialog::AnalyseOnglet.", standardError, 0) ;
}
}

void
NSDialog::AnalyseHelp(const char *input, const char *separateurs)
{
	//
	//
	if (pBBItem->pParseur && pBBItem->pParseur->pArchetype)
	{
		Creferences* pRef = pBBItem->pParseur->pArchetype->getReference() ;
		if (pRef)		{			Chead* pHead = pRef->getHead() ;			if (pHead)			{				string sUrl = pHead->getHelpUrl();				if (sUrl != "")				{					sHelpBodyUrl = sUrl ;
					return ;
				}
			}
		}
	}

	if ((!input) || (input[0] == '\0'))
		return ;

  // La cha�ne de configuration est de la forme :
  // "Index/Corps/"

  char   separe[2] ;
  string vide = " " ;
  string sCopie = string(input) ;
  string sIdentite ;

  separe[0] = separateurs[0] ;
  separe[1] = '\0' ;

  size_t posApres = sCopie.find(separe[0]) ;  size_t posAvant = 0 ;

  if (posApres == NPOS)    return ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;

  if (posApres == posAvant)
    sHelpIndexUrl = "" ;
  else
    sHelpIndexUrl = string(sCopie, posAvant, posApres - posAvant) ;

  pSuper->setAideIndex(sHelpIndexUrl) ;

  posAvant = posApres + 1 ;
  posApres = sCopie.find(separe[0], posApres + 1) ;

  if (posApres == posAvant)
      sHelpBodyUrl = "" ;
  else if (posApres == NPOS)
      sHelpBodyUrl = string(sCopie, posAvant, strlen(sCopie.c_str()) - posAvant) ;
  else
      sHelpBodyUrl = string(sCopie, posAvant, posApres - posAvant) ;

  pSuper->setAideCorps(sHelpBodyUrl) ;
}

//---------------------------------------------------------------------------//  Function:   bool NSDialog::LoadConfigResource()
//
//  Arguments:
//
//  Description:
//    Charge la ressource de configuration associ�e � la bo�te de dialogue.
//    La ressource associ�e � une bo�te de dialogue se pr�sente de la mani�re
//    suivante dans le fichier RES :
// MYRESSOURCE_1 MYRESSOURCE
// {
//  "EDITTEXT"                               // Configuration des contr�les EDIT
//  "C/34;D/12;C/4;C/7;C/3;C/10"
//  "NSBITMAP"                               // Configuration des r�gions d'un
//  300                                      // NSBitmap
// "T�te:103,10/58,76/102,109/115,98"
// "Cou:103,10/58,76/84,136/0,107/0,68"
// "Epaule:0,107/58,76/98,155/0,164"
// "Sternum:0,164/98,155/0,205/84,214"
// }
//     Mais dans la m�moire :
//"EDITTEXT/C/34;D/12;C/4;C/7;C/3;C/10/NSBITMAP/300/T�te:103,10/58,76/102,109/
// 115,98/Cou:103,10/58,76/84,136/0,107/0,68/Epaule:0,107/58,76/98,155/0,164/
// Sternum:0,164/98,155/0,205/84,214"
//
//  Returns:
//      true   si aucun incident n'est survenu
//      false  sinon
//  REMARQUE :
//   Ce type de ressource est partageable par toutes les instances de
//   l'application.
//---------------------------------------------------------------------------
string* NSDialog::LoadConfigResource(TResId resId, const char far* resType)
{
try
{
    HRSRC    resHdl;
	HGLOBAL  glbHdl;
	//
	// Chargement en m�moire de la ressource
	//
	if ((resHdl = pNSResModule->FindResource(resId, resType)) != 0)
    {
        if ((glbHdl = pNSResModule->LoadResource(resHdl)) != 0)
        {
            pResInfo = new string((char*)LockResource(glbHdl));
#if !defined __WIN32__
			//
			// D�bloquage de la ressource et lib�ration
			//
			GlobalUnlock(glbHdl);
#endif
        }
#if !defined __WIN32__
		FreeResource(glbHdl);
#endif
    }
	return pResInfo;
}
catch (...)
{
    erreur("Exception NSDialog::LoadConfigResource.", standardError, 0) ;
    return NULL ;
}
}


// -----------------------------------------------------------------------------// Function     : bool NSDialog::AnalyseRes()// Arguments    : AUCUN
// Description  : Analyse la string de configuration.
//                D�termine la cha�ne de configuration pour les contr�les EDIT
//                et cr�e des DefRegionArray pour chacun des "NSBitmap" d�clar�s
//                dans pesInfo.
// Returns      : RIEN
// -----------------------------------------------------------------------------
bool
NSDialog::AnalyseRes()
{
try
{
  string sConfigBitmap, sConfigEdit, sConfigControle;
	int	 nbPos = 5;
	size_t pos[5], nouvPos,     // Positions
			 len ;    		    // Longueur de l'information
	int	 i;
	//
	// Si la chaine de configuration est vide, on sort imm�diatement
	//
	if ((*pResInfo) == "")
		return true;
    //
    // Si la chaine contient une fin explicite, on tronque pResInfo
    //
    size_t posFin = pResInfo->find(string("FINRCDAT"));
    if (posFin != NPOS)
   	    *pResInfo = string(*pResInfo, 0, posFin);
    //
	// Prise de la position des divers �l�ments
	//
  len    = strlen(pResInfo->c_str());
	pos[0] = pResInfo->find(string("NSBITMAP"));
	pos[1] = pResInfo->find(string("EDITTEXT"));
	pos[2] = pResInfo->find(string("NSCONTRO"));
	pos[3] = pResInfo->find(string("NSONGLET"));
  pos[4] = pResInfo->find(string("NSAIDELI"));
	//
	// Configuration des NSBITMAP
	//
	/*if (pos[0] != NPOS)
	{
        size_t ext;

		for (nouvPos = len, i = 0; i < nbPos; i++)
			if ((pos[i] > pos[0]) && (pos[i] < nouvPos))
				nouvPos = pos[i];
		sConfigBitmap = (*pResInfo)(pos[0]+8, nouvPos-pos[0]-8);
		//
		// Analyse de sConfigBitmap
		//
		if (!sConfigBitmap.is_null())
		{
			//
			// ID du bitmap
			//
			nouvPos = sConfigBitmap.find(Naturel, &ext, 0);
			BitmapID = atoi(string(sConfigBitmap(nouvPos, ext)).c_str());
			//
			// $$ Compte le nombre de r�gions
			//
			nouvPos = 0;
         int nbReg;
			for (nbReg = 0;
					(nouvPos = sConfigBitmap.find(MWord, &ext, nouvPos)) != NPOS;
					nbReg++, nouvPos += ext);
			//
			// Construction de la matrice d'initialisation des r�gions
			//
			nouvPos = 0;
			pDefRegions = new DefRegionArray;

			for (i = 0; i < nbReg ; i++)
			{
				nouvPos = sConfigBitmap.find(MWord, &ext, nouvPos);
				if ((len = sConfigBitmap.find(MWord, &ext, nouvPos+ext)) != NPOS)
					pDefRegions->push_back(new DefRegion(string(sConfigBitmap(nouvPos, len-nouvPos))));
				else
				{
					len = sConfigBitmap.length();
					pDefRegions->push_back(new DefRegion(string(sConfigBitmap(nouvPos, len))));
				}
				nouvPos = len;
			}
		}
	} */
	//
	// Configuration pour les contr�les Edit
	//
    if (pos[1] != NPOS)
	{
        for (nouvPos = len, i = 0; i < nbPos; i++)
            if ((pos[i] > pos[1]) && (pos[i] < nouvPos))
                nouvPos = pos[i];
        pConfigEdit = new string(*pResInfo, pos[1]+8, nouvPos-pos[1]-8);
    }
	//
	// Configuration pour le contr�leur
	//
	if (pos[2] != NPOS)
	{
		for (nouvPos = len, i = 0; i < nbPos; i++)
			if ((pos[i] > pos[2]) && (pos[i] < nouvPos))
				nouvPos = pos[i];
		pControleur = new string(*pResInfo, pos[2]+8, nouvPos-pos[2]-8);
	}
	//
	// Configuration pour les onglets
	//
	if (pos[3] != NPOS)
	{
		for (nouvPos = len, i = 0; i < nbPos; i++)
			if ((pos[i] > pos[3]) && (pos[i] < nouvPos))
				nouvPos = pos[i];
        pConfigOnglet = new string(*pResInfo, pos[3]+8, nouvPos-pos[3]-8);
	}
    //
	// Configuration pour l'aide en ligne
	//
	if (pos[4] != NPOS)
	{
		for (nouvPos = len, i = 0; i < nbPos; i++)
			if ((pos[i] > pos[4]) && (pos[i] < nouvPos))
				nouvPos = pos[i];
        pConfigHelp = new string(*pResInfo, pos[4]+8, nouvPos-pos[4]-8);
        // MessageBox(pConfigHelp->c_str(), "Chaine d'aide", MB_ICONEXCLAMATION);
	}
	return true;
}
catch (...)
{
    erreur("Exception NSDialog::AnalyseRes().", standardError, 0) ;
    return true;
}
}
//---------------------------------------------------------------------------//  Function:  NSDialog::DlgConfigCtrl(HWND hWnd, LPARAM lParam)
//
//  Arguments:
//	     hWnd    -> handle du contr�le enfant
//	     lParam  -> lParam de la structure MESSAGE
//  Description:
//	    - Sert � cr�er tous les objets OWL correspondants aux objets
//      d'interface (contr�les) d�finis dans la ressource bo�te de dialogue.
//     - Cr�e les buffers de transfert pour chaque objet OWL dans une
//      NSTranferArray.
//     - Utilise les info. stock�es dans pConfigCache sous la forme
//      une lettre pour le type de saisie et un nombre pour le nombre
//      de caract�res � saisir pour cr�er des validateurs et des limiteurs
//      de saisie pour les contr�les EDIT.
//      Incr�mentation de nIndexCurr.
//      (ex :   )
//  REMARQUE :
//     Comme dans les fonction static il n'est pas possible d'acc�der � this,
//     on r�cup�re celui-ci dans lParam
//  Returns:
//	     true  pour que l'�num�ration puisse continuer.
//---------------------------------------------------------------------------
bool FAR PASCAL _export NSDialog::DlgConfigCtrl(HWND hWnd, LPARAM lParam)
{
try
{
	int  nIndex ;                    // Position dans *pConfigCache
	char szType[25] ;                // Type de contr�le EDIT
	char szEditDateType[2] ;         //type de date du controle EDIT
	char szClassName[30],           // Nom de la classe du contr�le
		  szBuffer[80] ;            // Utilis�e pour les fonctions WINDOWS
	memset(szType,	    0, 25) ;
	memset(szClassName, 0, 30) ;
	memset(szBuffer,    0, 80) ;

	string  typeCtrl        = "" ;       // Type de contr�le
	string  sIdentite       = "" ;
	string  sDlgFonction    = "" ;
	HWND    hDlg            = NULL ;    // Handle de la bo�te de dialogue Parent.
	UINT    nMaxInput       = 255 ;     // Nombre maximal de caract�res � saisir
	//
	// Adresse de l'objet bo�te de dialogue courante
	//
	TWindow* pWnd = reinterpret_cast<TWindow*>(lParam) ;
	NSDialog* pDlgCurrent = dynamic_cast<NSDialog*>(pWnd) ;

	if ((NULL == pDlgCurrent) || (NULL == pDlgCurrent->pBBItem) || (NULL == pDlgCurrent->pBBItem->pBigBoss))
		return true ;

	// NSContexte* pContexte = pDlgCurrent->pBBItem->pBigBoss->pContexte ;
  NSContexte* pContexte = pDlgCurrent->pContexte ;
  if (NULL == pContexte)
	  return true ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	//
	// Obtention de l'ID du contr�le et de son type WINDOWS
	//
	int ctrlID  = ::GetDlgCtrlID(hWnd);
	::GetClassName(hWnd, (LPSTR) szClassName, 30);
	//
	// Obtention du handle de la bo�te de Dialogue
	//
	hDlg = ::GetParent(hWnd);

	//
  // Initialisation de Groupe et Identite
  //
  nIndex = pDlgCurrent->iIndexCtrl ;

  if ((NULL == pDlgCurrent->pConfigCtrl) || (pDlgCurrent->pConfigCtrl->size() <= nIndex))
  	return true ;

	NSDialogCtrl* pCfgCtrl = (*(pDlgCurrent->pConfigCtrl))[nIndex] ;
  if (NULL == pCfgCtrl)
  	return true ;

	sIdentite 	 = pCfgCtrl->sIdentite ;
	sDlgFonction = pCfgCtrl->sDlgFonction ;

	// -------------------------------------------------------------------
	//                              TreeView
	// -------------------------------------------------------------------
	if (!strcmp(szClassName,"SysTreeView32"))
	{
    NSTreeWindow* pNSTreeWindow = new NSTreeWindow(pDlgCurrent, pContexte, ctrlID) ;

    // pNSTreeWindow->pBBitemNSTreeWindow  = pDlgCurrent->pBBItem;
    pNSTreeWindow->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem, sIdentite, sDlgFonction) ;
    pNSTreeWindow->pControle->setControle(dynamic_cast<void*>(pNSTreeWindow)) ;
    pNSTreeWindow->pControle->setType(pNSTreeWindow->donneType()) ;
    pNSTreeWindow->pControle->setNSDialog(pDlgCurrent) ;
    pDlgCurrent->referenceControle(pNSTreeWindow->pControle) ;

    if ((pNSTreeWindow->pControle->getTransfert()) &&
                (pNSTreeWindow->pControle->getTransfert()->pBBFilsItem))
    {
      BBFilsItem* pSonItem = pNSTreeWindow->pControle->getTransfert()->pBBFilsItem ;
      BBItem*     pFatherItem = pSonItem->getItemFather() ;
      pNSTreeWindow->pBBitemNSTreeWindow = pFatherItem ;

      // BBFilsItem*	pCtrlBBFilsItem = pNSTreeWindow->pControle->getTransfert()->pBBFilsItem ;
      // if (!(pCtrlBBFilsItem->VectorFils.empty()))
      //    pNSTreeWindow->pBBitemNSTreeWindow = *(pCtrlBBFilsItem->VectorFils.begin()) ;

      //
      // Cr�er le deuxi�me BBItem (GCONS le fils en cas de consultation par exemple)
      //
      /* int creer = */ pFatherItem->developperConsultation(pSonItem) ;
    }

    pDlgCurrent->iIndexCtrl++ ;
    return true ;
  }

  // -------------------------------------------------------------------
  //                                 Edit
  // -------------------------------------------------------------------
  if (!strcmp(szClassName, "Edit"))
  {
    string sIden = "" ;
    //
    // Contr�le reli� � un BBFisItem / This control is linked to a BBFilsItem
    //
    if (sIdentite != "")
    {
      //NSEdit qui bosse avec le lexique
      if ((sIdentite.find(string("�C;")) != NPOS) || (sIdentite.find(string("/�C;")) != NPOS))
      {
        NSEditLexique* pNSEdit = new NSEditLexique(pDlgCurrent,
                                                   pContexte,
                                                   ctrlID,
                                                   pContexte->getSuperviseur()->getDico(),
                                                   nMaxInput+1) ;
        pNSEdit->pControle            = new NSControle(pContexte, pDlgCurrent->pBBItem, sIdentite, sDlgFonction) ;
        pNSEdit->pControle->setControle(dynamic_cast<void*>(pNSEdit)) ;
        pNSEdit->pControle->setType(pNSEdit->donneType()) ;
        pNSEdit->pControle->setNSDialog(pDlgCurrent) ;
        pDlgCurrent->referenceControle(pNSEdit->pControle) ;
      }
      //
      // Champ edit qui n'ouvre pas le lexique et aliment Complement
      //
      else if (sIdentite.find(string("�CC")) != NPOS)      {        NSEditNoLex* pEdit ;        strcpy(szType, "C") ;        string sLen = string(sIdentite, 3, 3) ;        int iLen = atoi(sLen.c_str()) ;        pEdit = new NSEditNoLex(pContexte, pDlgCurrent, ctrlID, szType, sLang, iLen) ;        pEdit->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem/*, cGroupe*/,																		sIdentite, sDlgFonction) ;

        pEdit->pControle->setControle(dynamic_cast<void*>(pEdit)) ;        pEdit->pControle->setType(pEdit->donneType()) ;
        pEdit->pControle->setNSDialog(pDlgCurrent) ;
        pDlgCurrent->referenceControle(pEdit->pControle) ;

        //        // Incr�mentation de iIndexEdit de 1 pour passer � l'Edit suivant.
        //

        pDlgCurrent->iIndexEdit++ ;      }      //      // Champ edit qui n'ouvre pas le lexique et alimente Texte libre      //      else if (sIdentite.find(string("�CL")) != NPOS)      {        NSEditNoLex* pEdit ;        strcpy(szType, "L") ;        string sLen = string(sIdentite, 3, 3) ;        int iLen = atoi(sLen.c_str()) ;        pEdit = new NSEditNoLex(pContexte, pDlgCurrent, ctrlID, szType, sLang, iLen) ;        pEdit->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem/*, cGroupe*/,																		sIdentite, sDlgFonction) ;

        pEdit->pControle->setControle(dynamic_cast<void*>(pEdit)) ;        pEdit->pControle->setType(pEdit->donneType()) ;
        pEdit->pControle->setNSDialog(pDlgCurrent) ;
        pDlgCurrent->referenceControle(pEdit->pControle) ;

        //        // Incr�mentation de iIndexEdit de 1 pour passer � l'Edit suivant.
        //

        pDlgCurrent->iIndexEdit++;      }      else
      {
        //
        // Index du contr�le
        //
        nIndex = pDlgCurrent->iIndexEdit ;
        //
        // Type de saisie dans le contr�le
        //

        string sTypeDate = string("") ;
        //
        //trouver l
        //
        size_t pos = sIdentite.find(string("�")) ;
        if (NPOS != pos)
        {
          string sLivre = string(sIdentite, pos + 1, 1) ;
          strcpy(szType, sLivre.c_str()) ;

          sTypeDate = string(sIdentite, pos + 2, 1) ;
          strcpy(szEditDateType, sTypeDate.c_str()) ;
        }

        //
        // Cr�ation de l'objet OWL correspondant � l'objet d'interface
        //
        NSEdit* pEdit = NULL ;
        WNDTYPE	iEditType = isEdit ;
        switch (szType[0])
        {
          case codeMARK :
            pEdit = new NSEdit(pContexte, pDlgCurrent, ctrlID, szType, sLang) ;
            break ;
          case nbMARK :
            pEdit = new NSEdit(pContexte, pDlgCurrent, ctrlID, szType, sLang) ;
            break ;
          case charMARK :
            pEdit = new NSEdit(pContexte, pDlgCurrent, ctrlID, szType, sLang) ;
            break ;
          case dateMARK :
            //NSEditDate*
            pEdit = new NSEditDate(pContexte, pDlgCurrent, ctrlID, szType, sLang, sTypeDate[0]) ;
            iEditType = isEditDate ;
            break ;
          case dateHeureMARK :
            pEdit = new NSEditDateHeure(pContexte, pDlgCurrent, ctrlID, szType, sLang, sTypeDate[0]) ;
            iEditType = isEditDateHeure ;
            break ;
          case heureMARK :
            pEdit = new NSEditHeure(pContexte, pDlgCurrent, ctrlID, szType, sLang) ;
            break ;
          default :
            string sErrMess = string("Unknown Edit type : ") + string(1, szType[0]) ;
            erreur(sErrMess.c_str(), standardError, 0) ;
        }
        if (NULL != pEdit)
        {
          pEdit->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem/*, cGroupe*/,
                                                    sIdentite, sDlgFonction) ;
          pEdit->pControle->setControle(dynamic_cast<void*>(pEdit)) ;
          // pEdit->pControle->setType(pEdit->donneType());  // doesn't work, always return a isEdit type
          pEdit->pControle->setType(iEditType) ;
          pEdit->pControle->setNSDialog(pDlgCurrent) ;
          pDlgCurrent->referenceControle(pEdit->pControle) ;
          //
          // Incr�mentation de iIndexEdit de 1 pour passer � l'Edit suivant.
          //
          pDlgCurrent->iIndexEdit++ ;
        }
      }
    }
    // Contr�le non reli� � un BBFisItem
    else
    {
      // On ne le cr�e que s'il est attach� � une fonction
      if (string("") != sDlgFonction)
      {
        NSEdit* pEdit = new NSEdit(pContexte, pDlgCurrent, ctrlID, "", sLang) ;
        pEdit->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem/*, cGroupe*/,
                                                    sIdentite, sDlgFonction) ;
        pEdit->pControle->setControle(dynamic_cast<void*>(pEdit)) ;
        pEdit->pControle->setType(pEdit->donneType()) ;
        pEdit->pControle->setNSDialog(pDlgCurrent) ;
        pDlgCurrent->referenceControle(pEdit->pControle) ;
        //
        // Incr�mentation de iIndexEdit de 1 pour passer � l'Edit suivant.
        //
        pDlgCurrent->iIndexEdit++ ;
      }
    }

    pDlgCurrent->iIndexCtrl++ ;
    return true ;
  }
  //
  // NSBitmap (Bitmap interactif)
  //----------------------------
  // $$ Pour l'instant ne participe pas au transfert
/*
  if (!strcmp(szClassName, "NSBitmap"))  {        NSBitmap* pNSBitmap = new NSBitmap(static_cast<TWindow*>(pDlgCurrent), ctrlID,
															pDlgCurrent->BitmapID,	pDlgCurrent->defRegions());
        pNSBitmap->pControle    = new NSControle(pDlgCurrent->pBBItem, sIdentite, sDlgFonction);
        pNSBitmap->pControle->setControle(dynamic_cast<void*>(pNSBitmap));
        pNSBitmap->pControle->setType(pNSBitmap->donneType());
        pNSBitmap->pControle->setNSDialog(pDlgCurrent);
        pDlgCurrent->referenceControle(pNSBitmap->pControle);
  }
*/

  // -------------------------------------------------------------------  //                                  Static
  // -------------------------------------------------------------------
  if (!strcmp(szClassName, "Static"))
  {
    if ((-1 != ctrlID) && (0xFFFF != ctrlID))
    {
      // R�cup�ration de la longueur du texte du contr�le
      nMaxInput = ::GetDlgItemText(hDlg, ctrlID, szBuffer, nMaxInput) ;
      // Cr�ation de l'objet OWL correspondant � l'objet d'interface
      //new TStatic(pDlgCurrent, ctrlID, nMaxInput+1);
      NSStatic* pNSStatic  = new NSStatic(pContexte, static_cast<TWindow*>(pDlgCurrent), ctrlID) ;
      pNSStatic->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem, sIdentite, sDlgFonction) ;
      pNSStatic->pControle->setControle(dynamic_cast<void*>(pNSStatic)) ;
      pNSStatic->pControle->setType(pNSStatic->donneType()) ;
      pNSStatic->pControle->setNSDialog(pDlgCurrent) ;
      pDlgCurrent->referenceControle(pNSStatic->pControle) ;
    }

    pDlgCurrent->iIndexCtrl++ ;
    return true ;
  }

  // -------------------------------------------------------------------
  //                       Button  (autre que OK et Cancel)
  // -------------------------------------------------------------------
  if (!strcmp(szClassName, "Button") &&
       (IDOK != ctrlID) && (IDCANCEL != ctrlID))
  {
    // D�termination du style
    int nIndex = ::GetWindowLong(hWnd, GWL_STYLE) ;

    //    // Contr�le RadioButton
    //
    if (((nIndex& BS_AUTORADIOBUTTON) == BS_AUTORADIOBUTTON)||
					            ((nIndex& BS_RADIOBUTTON) == BS_RADIOBUTTON))
    {      NSRadioButton* pRaBut = new NSRadioButton(pContexte, pDlgCurrent, ctrlID, pDlgCurrent->pGroupCurr) ;
      pRaBut->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem, sIdentite, sDlgFonction) ;
      pRaBut->pControle->setControle(dynamic_cast<void*>(pRaBut)) ;
      pRaBut->pControle->setType(pRaBut->donneType()) ;
      pRaBut->pControle->setNSDialog(pDlgCurrent) ;
      pDlgCurrent->referenceControle(pRaBut->pControle) ;
    }
    //
    // Contr�le CheckBox
    //
    else if (((nIndex& BS_CHECKBOX) == BS_CHECKBOX)||
						        ((nIndex& BS_AUTOCHECKBOX)==BS_AUTOCHECKBOX))
    {
      //TCheckBox* pChkBox = new TCheckBox(pDlgCurrent, ctrlID, pDlgCurrent->pGroupCurr);
      //pControle->pCtrl = dynamic_cast<void*>(pChkBox);
      //pControle->sTypeCtrl = "CheckBox";
    }
    //
    // Contr�le Button
    //
    else
    {
      NSButton* pButt = new NSButton(pContexte, pDlgCurrent, ctrlID);
      pButt->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem, /*cGroupe,*/
																		sIdentite, sDlgFonction) ;
      pButt->pControle->setControle(dynamic_cast<void*>(pButt)) ;
      pButt->pControle->setType(pButt->donneType()) ;
      pButt->pControle->setNSDialog(pDlgCurrent) ;
      pDlgCurrent->referenceControle(pButt->pControle) ;
    }

    pDlgCurrent->iIndexCtrl++ ;
    return true ;
  }

  // -------------------------------------------------------------------
  //                          Bo�te de liste
  // -------------------------------------------------------------------
  if (!strcmp(szClassName, "Listbox"))
  {
    //TListBox* pListB = new TListBox(pDlgCurrent, ctrlID);
    //pControle->pCtrl 		= dynamic_cast<void*>(pListB);
    //pControle->sTypeCtrl = szClassName;

    pDlgCurrent->iIndexCtrl++ ;
    return true ;
  }

  // -------------------------------------------------------------------
  //                              Combobox
  // -------------------------------------------------------------------
  if (!strcmp(szClassName, "Combobox"))
  {
    // is it a classification or not ?
    bool bClassif = false ;
    VectString aVecteurString ;
    NSSuper* pSuper = pContexte->getSuperviseur() ;
    pSuper->getFilGuide()->TousLesVrais("0CODE", "ES", &aVecteurString, "ENVERS") ;    if (!(aVecteurString.empty()))    {      string sIdentSens ;      pSuper->getDico()->donneCodeSens(&sIdentite, &sIdentSens) ;      if (aVecteurString.contains(sIdentSens))        bClassif = true ;    }

    if (bClassif)
    {
      NSComboClassif* pComboB = new NSComboClassif(pContexte, pDlgCurrent, ctrlID) ;

      pComboB->pControle->setControle(dynamic_cast<void*>(pComboB)) ;
      pComboB->pControle->setType(pComboB->donneType()) ;
      pComboB->pControle->setNSDialog(pDlgCurrent) ;
      pDlgCurrent->referenceControle(pComboB->pControle) ;

      //pControle->pCtrl 		= dynamic_cast<void*>(pComboB);
      //pControle->sTypeCtrl = szClassName;

      pDlgCurrent->iIndexCtrl++ ;
      return true ;
    }
    else
    {
      NSComboSemantique* pComboB = new NSComboSemantique(pContexte, pDlgCurrent, ctrlID) ;

      pComboB->pControle->setControle(dynamic_cast<void*>(pComboB)) ;
      pComboB->pControle->setType(pComboB->donneType()) ;
      pComboB->pControle->setNSDialog(pDlgCurrent) ;
      pDlgCurrent->referenceControle(pComboB->pControle) ;

      //pControle->pCtrl 		= dynamic_cast<void*>(pComboB);
      //pControle->sTypeCtrl = szClassName;

      pDlgCurrent->iIndexCtrl++ ;
      return true ;
    }
  }

  // -------------------------------------------------------------------
  //                                  Group
  // -------------------------------------------------------------------
  if (!strcmp(szClassName, "Group"))
  {
    // pDlgCurrent->iIndexGroupe++;
    //pDlgCurrent->pGroupCurr = new TGroupBox(pDlgCurrent, ctrlID);

    pDlgCurrent->iIndexCtrl++ ;
    return true ;
  }

  // -------------------------------------------------------------------
  //                              ScrollBar
  // -------------------------------------------------------------------
  if (!strcmp(szClassName, "ScrollBar"))
  {
    // Cr�ation de l'objet OWL correspondant � l'objet d'interface
    new TScrollBar(pDlgCurrent, ctrlID) ;
    typeCtrl = "ScrollBar" ;

    pDlgCurrent->iIndexCtrl++ ;
    return true ;
  }

  // -------------------------------------------------------------------
  //                      Bouton BORLAND
  // -------------------------------------------------------------------
  if (!strcmp(szClassName, "BorBtn")
                && (ctrlID != IDOK)
                && (ctrlID != IDCANCEL)
                && (ctrlID != IDRETOUR)
                && (ctrlID != IDSUITE)
                && (ctrlID != IDHELP)
                && (ctrlID != IDHELPWWW)
                && (ctrlID != IDHELPNEW)
                && (ctrlID != IDTREEPASTE)
                && (ctrlID != IDCONCLUSION)
                && (ctrlID != IDBBKCALCUL)               )
  {
    // D�termination du style
    int nIndex = ::GetWindowLong(hWnd, GWL_STYLE) ;

    if ( !((nIndex& BBS_BITMAP) == BBS_BITMAP) )
    {
      NSButton* pButt = new NSButton(pContexte, pDlgCurrent, ctrlID) ;
      pButt->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem, sIdentite, sDlgFonction) ;
      pButt->pControle->setControle(dynamic_cast<void*>(pButt)) ;
      pButt->pControle->setType(pButt->donneType()) ;
      pButt->pControle->setNSDialog(pDlgCurrent) ;
      pDlgCurrent->referenceControle(pButt->pControle) ;
    }

    pDlgCurrent->iIndexCtrl++ ;
    return true ;
  }

  // -------------------------------------------------------------------
  //                          CheckBox BORLAND
  // -------------------------------------------------------------------
  if (!strcmp(szClassName, "BorCheck"))
  {
    NSCheckBox* pChkBox = new NSCheckBox(pContexte, pDlgCurrent, ctrlID, pDlgCurrent->pGroupCurr) ;
    pChkBox->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem, sIdentite, sDlgFonction) ;
    pChkBox->pControle->setControle(dynamic_cast<void*>(pChkBox)) ;
    pChkBox->pControle->setType(pChkBox->donneType()) ;
    pChkBox->pControle->setNSDialog(pDlgCurrent) ;
    pDlgCurrent->referenceControle(pChkBox->pControle) ;

    pDlgCurrent->iIndexCtrl++ ;
    return true ;
  }

  // -------------------------------------------------------------------
  //                          RadioBouton BORLAND
  // -------------------------------------------------------------------
  if (!strcmp(szClassName, "BorRadio"))
  {
    NSRadioButton* pRaBut = new NSRadioButton(pContexte, pDlgCurrent, ctrlID, pDlgCurrent->pGroupCurr) ;
    pRaBut->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem, sIdentite, sDlgFonction) ;
    pRaBut->pControle->setControle(dynamic_cast<void*>(pRaBut)) ;
    pRaBut->pControle->setType(pRaBut->donneType()) ;
    pRaBut->pControle->setNSDialog(pDlgCurrent) ;
    pDlgCurrent->referenceControle(pRaBut->pControle) ;

    pDlgCurrent->iIndexCtrl++ ;
    return true ;
  }

  // -------------------------------------------------------------------
  //                                  Onglets
  // -------------------------------------------------------------------
  if (!strcmp(szClassName, "SysTabControl32"))
  {
    NSOnglet* pOnglet = new NSOnglet(pContexte, pDlgCurrent, ctrlID);
    pOnglet->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem, sIdentite, sDlgFonction);
    pOnglet->pControle->setControle(dynamic_cast<void*>(pOnglet)) ;
    pOnglet->pControle->setType(pOnglet->donneType()) ;
    pOnglet->pControle->setNSDialog(pDlgCurrent) ;
    pDlgCurrent->referenceControle(pOnglet->pControle) ;

    pDlgCurrent->iIndexCtrl++ ;
    return true ;
  }

  // -------------------------------------------------------------------
  //                          BorShade BORLAND
  // -------------------------------------------------------------------
  if (!strcmp(szClassName, "BorShade"))
  {
    // D�termination du style
    int nIndex = ::GetWindowLong(hWnd, GWL_STYLE) ;
    //
    // Contr�le Group
    //
    if (((nIndex& BSS_RGROUP) == BSS_RGROUP) ||
                            ((nIndex& WS_GROUP) == WS_GROUP))
    {
      if (sIdentite != "")
      {
        NSGroupBox* pGrpBox = new NSGroupBox(pContexte, pDlgCurrent, ctrlID) ;
        pGrpBox->pControle = new NSControle(pContexte, pDlgCurrent->pBBItem, sIdentite, sDlgFonction) ;
        pGrpBox->pControle->setControle(dynamic_cast<void*>(pGrpBox)) ;
        pGrpBox->pControle->setType(pGrpBox->donneType()) ;
        pDlgCurrent->referenceControle(pGrpBox->pControle) ;
        pDlgCurrent->pGroupCurr = (OWL::TGroupBox*)pGrpBox ;
      }
      else
      {
        OWL::TGroupBox* pGroupBox = new OWL::TGroupBox(pDlgCurrent, ctrlID) ;
        pDlgCurrent->aGroups.push_back(pGroupBox) ;
        pDlgCurrent->pGroupCurr = pGroupBox ;
      }
    }

    pDlgCurrent->iIndexCtrl++ ;
    return true ;
  }
  //
  // Incr�mentation du compteur
  //
  pDlgCurrent->iIndexCtrl++ ;

  return true ;
}
catch (...)
{
  erreur("Exception NSDialog::DlgConfigCtrl.", standardError, 0) ;
  return false ;
}
}

void
NSDialog::activateParent()
{
	if (pView == NULL)
	{
		TWindow::BringWindowToTop() ;
		return ;
	}
	NSMUEView* pMueView = TYPESAFE_DOWNCAST(pView, NSMUEView) ;
	if (pMueView == NULL)
	{
		TWindow::BringWindowToTop() ;
		return;
	}
	pMueView->activateParent() ;
}

void
NSDialog::DlgConfigCtrl2(TWindow* /* pWnd */, void* /* lParam */)
//void DlgConfigCtrl2(TWindow* pWnd, void* lParam)
{
/*
	int  nIndex;                   // Position dans *pConfigCache
	char szType[25];             	 // Type de contr�le EDIT
	char szClassName[15],          // Nom de la classe du contr�le
  szBuffer[80],             // Utilis�e pour les fonctions WINDOWS
	szLen[5],						 // Taille � saisir pour un Edit
	cGroupe;
	string typeCtrl = "";          // Type de contr�le
	string sIdentite, sDlgFonction;
	HWND hDlg;                     // Handle de la bo�te de dialogue Parent.
	UINT  nMaxInput = 255;         // Nombre maximal de caract�res � saisir
	void* pTransferBufCtrl = NULL; // adresse du buffer de transfert

	// Adresse de l'objet bo�te de dialogue courante
	//NSDialog* pDlgCurrent = this;
	TWindow* pWind = reinterpret_cast<TWindow*>(lParam);
	NSDialog* pDlgCurrent = dynamic_cast<NSDialog*>(pWind);

	// Obtention de l'ID du contr�le et de son type WINDOWS
	int ctrlID  = pWnd->GetDlgCtrlID();
	::GetClassName(pWnd->HWindow, (LPSTR) szClassName, 15);
	pDlgCurrent->MessageBox(szClassName, "DIALOG CONFIG", MB_ICONEXCLAMATION);
	//szClassName = ((TDialog*)pWnd)->GetClassName();

	// Obtention du handle de la bo�te de Dialogue
	//hDlg   = ::GetParent(hWnd);

	// Initialisation de Groupe et Identite
	nIndex = pDlgCurrent->iIndexCtrl;
	// string sCtrl = (*(pDlgCurrent->pConfigCtrl))[nIndex].getItem(0);
	// cGroupe = sCtrl[0];
	// sIdentite = (*(pDlgCurrent->pConfigCtrl))[nIndex].getItem(1);
	cGroupe = pDlgCurrent->pConfigCtrl[nIndex]->cGroupe;
	sIdentite = pDlgCurrent->pConfigCtrl[nIndex]->sIdentite;
	sDlgFonction = pDlgCurrent->pConfigCtrl[nIndex]->sDlgFonction;

	// Traitement suivant le type de contr�le rencontr�
	// BVSP : Contr�le Onglets

	if (!strcmp(szClassName, "SaxTabs"))
	{
		delete pWnd;
		NSOnglet* pOnglet = new NSOnglet(pDlgCurrent, ctrlID);
		pOnglet->pControle = new NSControle(pDlgCurrent->pBBItem, cGroupe,
																		sIdentite, sDlgFonction);
		pOnglet->pControle->pNSCtrl   = dynamic_cast<void*>(pOnglet);
		pOnglet->pControle->iType     = pOnglet->donneType();
		pOnglet->pControle->pNSDialog = pDlgCurrent;
		pDlgCurrent->referenceControle(pOnglet->pControle);
	}

	// Incr�mentation du compteur
	pDlgCurrent->iIndexCtrl++;

	return;
  */
}

// -----------------------------------------------------------------------------
// Function     : NSDialog::DisplayBlank(void)
// Arguments    : AUCUN
// Description  : Permet d'afficher des champs blancs
// Returns      : RIEN
// -----------------------------------------------------------------------------
void NSDialog::BlankDisplay(int id)
{
  SetDlgItemText(id, "") ;
}

// -----------------------------------------------------------------------------
// demander � la bo�te de dialogue m�re d'activer le controle
// suivant pControle sinon le premier
// -----------------------------------------------------------------------------
void
NSDialog::ActiveControlSuivant(NSControle* pControle)
{
	if (!(pNSCtrl->empty()))
	{
  	// Find current control
    //
		iterNSControle i ;
		for (i = pNSCtrl->begin() ;
                            (i != pNSCtrl->end()) && (*i != pControle); i++) ;
		if (i != pNSCtrl->end())
			i++ ;  //suivant

		// Find first enabled control
    //
		while (pNSCtrl->end() != i)
    {
    	if (NULL != (*i)->getControle())
      {
      	TControl* pCtrl = (TControl*) (*i)->getControle() ;
      	if (true == pCtrl->IsWindowEnabled())
        	break ;
      }
    	i++ ;
    }

		if (pNSCtrl->end() != i)
		{

			(*i)->SetFocus();
			return ;
		}
	}
	//
	// Donner le focus au bouton Ok s'il existe sinon fermer la bo�te
	//
	if (Parent->ChildWithId(IDOK))
		Parent->ChildWithId(IDOK)->SetFocus() ;
	else
		CmOk() ;

    //	(*(pNSCtrl->begin()))->SetFocus();
}

//---------------------------------------------------------------------------// demander � la bo�te de dialogue m�re d'activer le controle
// pr�c�dent pControle sinon le dernier
//---------------------------------------------------------------------------
void
NSDialog::ActiveControlPrecedent(NSControle* pControle)
{
	if (pNSCtrl->empty())
		return ;

	iterNSControle i ;
	for (i = pNSCtrl->begin() ; (i != pNSCtrl->end()) && (*i != pControle); i++) ;
	if (i != pNSCtrl->end())
	{
		if (i == pNSCtrl->begin())
			(pNSCtrl->back())->SetFocus() ;
		else
		{
			i-- ;  //pr�c�edent
			(*i)->SetFocus() ;
		}
	}
}

//---------------------------------------------------------------------------
//  Function:		NSDialog::referenceControle(void* pNSControle)
//
//  Arguments:		pNSControle : pointeur (au type void) sur le controle
//
//  Description:	Sert � ajouter ce pointeur � la liste des objets de
//						contr�le (NSButton, NSCheckBox...) cr��s par NSDialog.
//						Cette liste sert, entre autres, � pouvoir les d�truires
//						� la fermeture de la boite de dialogue.
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void
NSDialog::referenceControle(NSControle* pNSControle)
{
	pNSCtrl->push_back(pNSControle) ;
}

void
NSDialog::CreerControles()
{
try
{
  if (NULL == pContexte->getDico()->pGenerateur)
  {
    TDialog::SetupWindow() ;
    return ;
  }

  NSPathologData Data ;
  int            iGenre ;
  string         sLibel ;

  string sLang = "" ;
  if ((pContexte) && (pContexte->getUtilisateur()))
    sLang = pContexte->getUtilisateur()->donneLang() ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;
  NSGenerateur* pGene = pContexte->getDico()->pGenerateur ;

  int iBoxHeight = 10 ;    // hauteur du bouton
  int iBoxWidth  = 175 ;   // largeur du bouton
  int iBoxInterv = 3 ;     // intervalle entre deux boutons
  int iBoxTop    = 4 ;     // haut du 1er bouton � partir du haut du groupbox
  int iBoxLeft   = 5 ;     // gauche des boutons � partir de la gauche du groupbox

  int iGroupTop  = 3 ;     // haut du groupbox
  int iGroupLeft = 2 ;     // gauche du groupbox

  int iSeparLeft = 3 ;     // gauche du s�parateur
  int iGB_Separ  = 3 ;     // intervalle entre le bas du groupbox et le s�parateur
  int iSepar_Btn = 8 ;     // intervalle entre le s�parateur et le bouton

  int iBtnHeight = 25 ;    // hauteur d'un bouton
  int iBtnWidth  = 43 ;    // hauteur d'un bouton
  int iBtnLeft   = 3 ;     // gauche du premier bouton

  int iBtn_bas   = 3 ;     // intervalle entre le bas du bouton et le bas de la boite

  int  iNbBoxes = 0 ;
  bool bTexteLibre = false ;

  // Combien de boites � cocher faut-il cr�er ?
  // Existe-t-il un texte libre ?
  //
  if (false == pBBItem->aBBItemFils.empty())
  {
    for (BBiter i = pBBItem->aBBItemFils.begin();
                                        i != pBBItem->aBBItemFils.end(); i++)
    {
      if ((*i)->getItemLabel() == "#####1")
        bTexteLibre = true ;
      else
        iNbBoxes++ ;
    }
  }

  int iGroupWidth = (2 * iBoxLeft) + iBoxWidth ;
  int iTotalWidth = (2 * iGroupLeft) + iGroupWidth ;

  int iGroupHeight ;
  if (iNbBoxes > 0)
    iGroupHeight = (2 * iBoxTop) + (iNbBoxes * iBoxHeight) +
                        ((iNbBoxes-1) * iBoxInterv) ;
  else
    iGroupHeight = (2 * iBoxTop) ;

  int iTotalHeight = iGroupTop + iGroupHeight + iGB_Separ + iSepar_Btn +
                        iBtnHeight + iBtn_bas ;

  // On fixe la taille de la boite de dialogue
  //
  NS_CLASSLIB::TRect dlgSizeRect(0, 0, iTotalWidth, iTotalHeight) ;
  MapDialogRect(dlgSizeRect) ;

  // On cr�e le groupe
  //
  NS_CLASSLIB::TRect cvtRect = NS_CLASSLIB::TRect(iGroupLeft, iGroupTop,
                                 iGroupLeft + iGroupWidth,
                                 iGroupTop + iGroupHeight) ;
  MapDialogRect(cvtRect) ;

  TGroupBox* pGroup = new TGroupBox(this, -1, "",
                                      cvtRect.Left(), cvtRect.Top(),
                                      cvtRect.Width(), cvtRect.Height(),
                                      /* TModule* */ 0) ;
  pGroup->Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;

  // On cr�e les cases � cocher
  //
  if (false == pBBItem->aBBItemFils.empty())
  {
    int iTopOfBox = iGroupTop + iBoxTop ;

    GlobalDkd dCode(pContexte, sLang) ;

    int iID = 200 ;
    for (BBiter i = pBBItem->aBBItemFils.begin(); i != pBBItem->aBBItemFils.end(); i++)
    {
      if ((*i)->getItemLabel() != "#####1")
      {
        // D�termination du libell� du bouton

        Message Msg("");
        Msg.InitFromEtiquette((*i)->getItemLabel());
        string sMixte = Msg.GetLexique() ;
        if (string("") != Msg.GetComplement())
          sMixte += string(1, intranodeSeparationMARK) + Msg.GetComplement() ;
        if (string("") != Msg.GetPluriel())
          sMixte += string(1, intranodeSeparationMARK) + Msg.GetPluriel() ;
        if (string("") != Msg.GetCertitude())
          sMixte += string(1, intranodeSeparationMARK) + Msg.GetCertitude() ;

        int iGenreObj, iCertObj ;
        sLibel = dCode.decodeMot(&sMixte, 1, &iGenreObj, &iCertObj) ;

        /*
        Message* pMsg = new Message("");
        pMsg->InitFromEtiquette((*i)->sEtiquette);
        pContexte->getDico()->trouvePathologData(sLang, &(pMsg->GetLexique()), &Data);
        Data.donneGenre(&iGenre);
        if (pMsg->GetPluriel() != "")
            Data.donneGenrePluriel(&iGenre);
        pGene->donneLibelleAffiche(&sLibel, &Data, iGenre);
        delete pMsg;
        */
        sLibel[0] = pseumaj(sLibel[0]) ;

        cvtRect = NS_CLASSLIB::TRect(iGroupLeft + iBoxLeft,
                                     iTopOfBox,
                                     iGroupLeft + iBoxLeft + iBoxWidth,
                                     iTopOfBox + iBoxHeight) ;
        MapDialogRect(cvtRect) ;

        if ((*i)->FilsProlongeable)
        {
          // Checkbox or Edit?
          //
          string sEditFormat = string("") ;
          string sEditUnit   = string("") ;
          string sEditLabel  = string("") ;
          if (false == (*i)->VectorFils.empty())
          {
            BBItem* pSonItem = *((*i)->VectorFils.begin()) ;
            if (pSonItem->aBBItemFils.size() == 1)
            {
              BBFilsItem* pSonFilsItem = *(pSonItem->aBBItemFils.begin()) ;
              sEditLabel = pSonFilsItem->getItemLabel() ;
              Message Msg ;
              Msg.InitFromEtiquette(sEditLabel) ;
              sEditUnit = Msg.GetUnit() ;
              if (string("") != sEditUnit)
                sEditFormat = Msg.GetLexique() ;
            }
          }

          if ((string("") == sEditUnit) || (string("") == sEditFormat))
          {
            NSCheckBox* pChkBx = new NSCheckBox(pContexte, this, iID,
                                              sLibel.c_str(),
                                              cvtRect.Left(), cvtRect.Top(),
                                              cvtRect.Width(), cvtRect.Height(),
                                              /*pGroup*/ 0, 0) ;
            pChkBx->pControle = new NSControle(pContexte, pBBItem, (*i)->getItemLabel(), "") ;
            pChkBx->pControle->setControle(dynamic_cast<void*>(pChkBx)) ;
            pChkBx->pControle->setType(pChkBx->donneType()) ;
            pChkBx->pControle->setNSDialog(this) ;
            referenceControle(pChkBx->pControle) ;
          }
          else
          {
            NSStatic* pNSStatic  = new NSStatic(pContexte, this, iID, sLibel.c_str(),
                                                cvtRect.Left(), cvtRect.Top(),
                                              cvtRect.Width(), cvtRect.Height()) ;
            pNSStatic->pControle = new NSControle(pContexte, pBBItem, (*i)->getItemLabel(), "") ;
            pNSStatic->pControle->setControle(dynamic_cast<void*>(pNSStatic)) ;
            pNSStatic->pControle->setType(pNSStatic->donneType()) ;
            pNSStatic->pControle->setNSDialog(this) ;
            referenceControle(pNSStatic->pControle) ;

            iID++ ;

            string sDisplayedUnit = string("") ;

            NSEdit* pEdit = NULL ;
            WNDTYPE	iEditType = isEdit ;

            string sLivre = string(sEditFormat, 1, 1) ;
            char szType[2] ;
            strcpy(szType, sLivre.c_str()) ;

            int iEditMargin = 90 ;
            int iEditXPos   = cvtRect.Left() + cvtRect.Width() - iEditMargin ;
            int iEditWidth  = 30 ;

            switch (sEditFormat[1])
            {
              case codeMARK :
                pEdit = new NSEdit(pContexte, this, iID, szType, "",
                                     iEditXPos, cvtRect.Top(), iEditWidth,
                                     cvtRect.Height(), sLang) ;
                break ;
              case nbMARK :
                {
                  pEdit = new NSEdit(pContexte, this, iID, szType, "",
                                     iEditXPos, cvtRect.Top(), iEditWidth,
                                     cvtRect.Height(), sLang) ;
                  string sUnitSens = string("") ;
                  pSuper->getDico()->donneCodeSens(&sEditUnit, &sUnitSens) ;
                  if (string("20000") != sUnitSens)
                    sDisplayedUnit = sEditUnit ;
                }
                break ;
              case charMARK :
                pEdit = new NSEdit(pContexte, this, iID, szType, "",
                                     iEditXPos, cvtRect.Top(), iEditWidth,
                                     cvtRect.Height(), sLang) ;
                break ;
              case dateMARK :
                //NSEditDate*
                pEdit = new NSEditDate(pContexte, this, iID, szType, "",
                                     iEditXPos, cvtRect.Top(), iEditWidth,
                                     cvtRect.Height(), sLang, sEditFormat[2]) ;
                iEditType = isEditDate ;
                break ;
              case dateHeureMARK :
                pEdit = new NSEditDateHeure(pContexte, this, iID, szType, "",
                                     iEditXPos, cvtRect.Top(), iEditWidth,
                                     cvtRect.Height(), sLang, sEditFormat[2]) ;
                iEditType = isEditDateHeure ;
                break ;
              case heureMARK :
                pEdit = new NSEditHeure(pContexte, this, iID, szType, "",
                                     iEditXPos, cvtRect.Top(), iEditWidth,
                                     cvtRect.Height(), sLang) ;
                break ;
              default :
                string sErrMess = string("Unknown Edit type : ") + sEditFormat ;
                erreur(sErrMess.c_str(), standardError, 0) ;
            }
            if (NULL != pEdit)
            {
              string sItemLabel = (*i)->getItemLabel() + string(1, cheminSeparationMARK) + sEditLabel ;

              pEdit->pControle = new NSControle(pContexte, *((*i)->VectorFils.begin()),
                                                    sEditLabel, "") ;
              pEdit->pControle->setControle(dynamic_cast<void*>(pEdit)) ;
              // pEdit->pControle->setType(pEdit->donneType());  // doesn't work, always return a isEdit type
              pEdit->pControle->setType(iEditType) ;
              pEdit->pControle->setNSDialog(this) ;
              referenceControle(pEdit->pControle) ;
              //
              // Incr�mentation de iIndexEdit de 1 pour passer � l'Edit suivant.
              //
              iIndexEdit++ ;

              if (string("") != sDisplayedUnit)
              {
                iID++ ;

                string sUnitLib = string("") ;
                int iUnitWidth = iEditMargin - iEditWidth - 2 ;
                pContexte->getDico()->donneLibelle(sLang, &sDisplayedUnit, &sUnitLib) ;
                /* NSStatic* pStatic = */ new NSStatic(pContexte, this, iID,
                                            sUnitLib.c_str(),
                                            iEditXPos + iEditWidth + 2,
                                            cvtRect.Top(), iUnitWidth, cvtRect.Height()) ;
              }
            }
          }
        }
        else
        {
          NSRadioButton* pRaBut = new NSRadioButton(pContexte, this, iID,
                                            sLibel.c_str(),
                                            cvtRect.Left(), cvtRect.Top(),
                                            cvtRect.Width(), cvtRect.Height(),
                                            /*pGroup*/ 0, 0) ;
          pRaBut->pControle = new NSControle(pContexte, pBBItem, (*i)->getItemLabel(), "") ;
          pRaBut->pControle->setControle(dynamic_cast<void*>(pRaBut)) ;
          pRaBut->pControle->setType(pRaBut->donneType()) ;
          pRaBut->pControle->setNSDialog(this) ;
          referenceControle(pRaBut->pControle) ;
        }

        iTopOfBox += iBoxHeight + iBoxInterv ;
        iID++ ;
      }
    }
  }

  // On cr�e le s�parateur
  //
  int iSepareTop = iGroupHeight + iGroupTop + iGB_Separ ;
  cvtRect = NS_CLASSLIB::TRect(iSeparLeft, iSepareTop,
                                 iSeparLeft + iTotalWidth - (2 * iSeparLeft),
                                 iSepareTop + 3) ;
  MapDialogRect(cvtRect) ;
  TGroupBox* pDip = new TGroupBox(this, -1, "",
                                    cvtRect.Left(), cvtRect.Top(),
                                    cvtRect.Width(), cvtRect.Height(),
                                    /*TModule**/ 0) ;
  pDip->Attr.Style |= BSS_HDIP ;

  // On cr�e les boutons
  //
  int iNbBtn ;
  if (bTexteLibre)
    iNbBtn = 4 ;
  else
    iNbBtn = 3 ;

  int iBtnInterv = (iTotalWidth - (2 * iBtnLeft) - (iNbBtn * iBtnWidth)) / (iNbBtn - 1) ;

  int iBtnTopPos  = iSepareTop + iSepar_Btn ;
  int iBtnLeftPos = iBtnLeft ;

  cvtRect = NS_CLASSLIB::TRect(iBtnLeftPos, iBtnTopPos,
                                 iBtnLeftPos + iBtnWidth,
                                 iBtnTopPos + iBtnHeight) ;
  MapDialogRect(cvtRect) ;
  /*TButton* pBtOK =*/ new TButton(this, IDOK, "", cvtRect.Left(), cvtRect.Top(),
                                 cvtRect.Width(), cvtRect.Height(),
                                 /*isDefault*/ false, 0) ;
  iBtnLeftPos += iBtnWidth + iBtnInterv ;

  cvtRect = NS_CLASSLIB::TRect(iBtnLeftPos, iBtnTopPos,
                                 iBtnLeftPos + iBtnWidth,
                                 iBtnTopPos + iBtnHeight) ;
  MapDialogRect(cvtRect) ;
  /*TButton* pBtCn =*/ new TButton(this, IDCANCEL, "", cvtRect.Left(), cvtRect.Top(),
                                 cvtRect.Width(), cvtRect.Height(), /*isDefault*/ false, 0) ;
  iBtnLeftPos += iBtnWidth + iBtnInterv ;

  if (bTexteLibre)
  {
    cvtRect = NS_CLASSLIB::TRect(iBtnLeftPos, iBtnTopPos,
                                 iBtnLeftPos + iBtnWidth,
                                 iBtnTopPos + iBtnHeight) ;
    MapDialogRect(cvtRect) ;

    if (false == pBBItem->aBBItemFils.empty())
    {
      for (BBiter i = pBBItem->aBBItemFils.begin(); i != pBBItem->aBBItemFils.end(); i++)
      {
        if ((*i)->getItemLabel() == "#####1")
        {
          NSButton* pBtTl = new NSButton(pContexte, this, IDTL, "", cvtRect.Left(), cvtRect.Top(),
                                 cvtRect.Width(), cvtRect.Height(), /*isDefault*/ false, 0) ;
          pBtTl->pControle = new NSControle(pContexte, pBBItem, (*i)->getItemLabel(), "") ;
          pBtTl->pControle->setControle(dynamic_cast<void*>(pBtTl)) ;
          pBtTl->pControle->setType(pBtTl->donneType()) ;
          pBtTl->pControle->setNSDialog(this) ;
          referenceControle(pBtTl->pControle) ;
        }
      }
    }

    iBtnLeftPos += iBtnWidth + iBtnInterv ;
  }

  cvtRect = NS_CLASSLIB::TRect(iBtnLeftPos, iBtnTopPos,
                                 iBtnLeftPos + iBtnWidth,
                                 iBtnTopPos + iBtnHeight) ;
  MapDialogRect(cvtRect) ;
  /*TButton* pBtHl =*/ new TButton(this, IDHELP, "", cvtRect.Left(), cvtRect.Top(),
                                 cvtRect.Width(), cvtRect.Height(), /*isDefault*/ false, 0) ;
  iBtnLeftPos += iBtnWidth + iBtnInterv ;

  //
  // Titre de la boite de dialogue
  //
  if (pBBItem->pBBFilsPere)
  {
    Message Msg ;
    Msg.InitFromEtiquette(pBBItem->pBBFilsPere->getItemLabel()) ;
    pContexte->getDico()->trouvePathologData(sLang, &(Msg.GetLexique()), &Data) ;
    Data.donneGenre(&iGenre) ;
    if (Msg.GetPluriel() != "")
      Data.donneGenrePluriel(&iGenre) ;
    pGene->donneLibelleAffiche(&sLibel, &Data, iGenre) ;
    // Passage en majuscules
    for (size_t i = 0; i < strlen(sLibel.c_str()); i++)
      sLibel[i] = pseumaj(sLibel[i]) ;
    SetCaption(sLibel.c_str()) ;
  }

  //
  // Appel du SetupWindow() de TDialog
  //
  TDialog::SetupWindow() ;

  //
  // Redimentionnement
  //
  NS_CLASSLIB::TRect dlgRect ;
  GetWindowRect(dlgRect) ;
  NS_CLASSLIB::TRect clientRect ;
  GetClientRect(clientRect) ;
  //
  // On compare le clientRect r�el avec les dimensions souhait�es,
  // et on modifie le WindowRect en cons�quence
  //
  int nouvWindowWidth  = dlgRect.Width()  + (dlgSizeRect.Width()  - clientRect.Width()) ;
  int nouvWindowHeight = dlgRect.Height() + (dlgSizeRect.Height() - clientRect.Height()) ;
  MoveWindow(dlgRect.left, dlgRect.top, nouvWindowWidth, nouvWindowHeight) ;
}
catch (...)
{
	erreur("Exception lors de la cr�ation dynamique de dialogue.", standardError, 0) ;
}
}

void
NSDialog::CreerControlesArchetype()
{
try
{
  if ((!pBBItem) || (!pBBItem->pParseur) || (!pBBItem->pParseur->pArchetype))
    return ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  Cdialogbox *pDialogBox = pBBItem->pParseur->pArchetype->getDialogBox(sLang) ;
  if (NULL == pDialogBox)
    return ;

  Ccontrol * pControl = pDialogBox->getFirstControl() ;
  if (NULL == pControl)
    return ;

  // Crcdata* pRCData        = pDialogBox->getRCData();
  int coords[4] ;
  UINT  nMaxInput = 255 ;         // Nombre maximal de caract�res � saisir
  string sType, sCoords, sCaption, sFilling ;

  // string sRCData = pRCData->getNSContro();
  string sRCData = pDialogBox->getStringRCData() ;

  string sIdentite ;
  string sDlgFonction = "" ;   // temporairement
  NS_CLASSLIB::TRect cvtRect ;
  int prec = 0, suiv ;
  int ctrlID ;
	char szType[25] ;       // Type de contr�le EDIT
  char szEditDateType[2] ;         //type de date dans le controle EDIT (NSEditDate)
  char szTypeControl[255] ;
  size_t posLex ;

  suiv = sRCData.find("|") ;

  while (pControl != NULL)
  {
    sType    = pControl->getType() ;
    sCoords  = pControl->getCoords() ;
    sCaption = pControl->getCaption() ;
    sFilling = pControl->getFilling() ;
    ctrlID   = pControl->getRefId() ;

    // conversion du type en majuscules
    pseumaj(&sType) ;

    coords[0] = pControl->getX() ;
    coords[1] = pControl->getY() ;
    coords[2] = pControl->getW() ;
    coords[3] = pControl->getH() ;

    // Rectangle de conversion des coordonn�es en unit�s de boite de dialogue
    cvtRect = NS_CLASSLIB::TRect(coords[0], coords[1], coords[0] + coords[2], coords[1] + coords[3]) ;

    MapDialogRect(cvtRect) ;

    coords[0] = cvtRect.Left() ;
    coords[1] = cvtRect.Top() ;
    coords[2] = cvtRect.Width() ;
    coords[3] = cvtRect.Height() ;

    sDlgFonction    = "" ;
    sIdentite       = string(sRCData, prec, suiv - prec) ;

    if (sIdentite != "")
    {
      size_t fct_posit = sIdentite.find(':') ;
      if (fct_posit != string::npos)
      {
        if (fct_posit < strlen(sIdentite.c_str()))
          sDlgFonction = string(sIdentite, fct_posit + 1, strlen(sIdentite.c_str())) ;
        sIdentite = string(sIdentite, 0, fct_posit) ;
      }
    }

    // -------------------------------------------------------------------------
    // Traitement suivant le type de contr�le rencontr�

    if (sType == string("SYSTREEVIEW32"))
    {
      // TreeView
      NSTreeWindow * pNSTreeWindow = new NSTreeWindow(this, pContexte, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
      pNSTreeWindow->Attr.Style = pControl->getIStyle() ;
      pNSTreeWindow->pBBitemNSTreeWindow  = pBBItem ;
      pNSTreeWindow->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      pNSTreeWindow->pControle->setControle(dynamic_cast<void *>(pNSTreeWindow)) ;
      pNSTreeWindow->pControle->setType(pNSTreeWindow->donneType()) ;
      pNSTreeWindow->pControle->setNSDialog(this) ;
      pNSTreeWindow->pControle->setFilling(sFilling) ;
      referenceControle(pNSTreeWindow->pControle) ;

      if ((pNSTreeWindow->pControle->getTransfert()) &&
                (pNSTreeWindow->pControle->getTransfert()->pBBFilsItem))
      {
      	BBFilsItem* pSonItem = pNSTreeWindow->pControle->getTransfert()->pBBFilsItem ;
      	BBItem*     pFatherItem = pSonItem->getItemFather() ;
      	pNSTreeWindow->pBBitemNSTreeWindow = pFatherItem ;

        // BBFilsItem*	pCtrlBBFilsItem = pNSTreeWindow->pControle->getTransfert()->pBBFilsItem ;
        // if (!(pCtrlBBFilsItem->VectorFils.empty()))
        //    pNSTreeWindow->pBBitemNSTreeWindow = *(pCtrlBBFilsItem->VectorFils.begin()) ;

        //
    		// Cr�er le deuxi�me BBItem (GCONS le fils en cas de consultation par exemple)
    		//
        if (NULL != pFatherItem)
    		  /* int creer = */ pFatherItem->developperConsultation(pSonItem) ;
        /*
        if (!(pSonItem->PatPtahovide()))
        {
        	NSPatPathoArray* pPatPatho = *(pSonItem->getPatPatho()->begin()) ;
        	pNSTreeWindow->DispatcherPatPatho(pPatPatho, 0, 0, "") ;
        }
        */
      }
    }

    if (sType == string("SYSLISTVIEW32"))
    {
      // ListView
      if (sIdentite.find(string("LCADR")) != NPOS)
      {
        // Liste d'adresses
        NSAdrListWindow * pNSAdrListWindow = new NSAdrListWindow(this, pContexte, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
        pNSAdrListWindow->Attr.Style = pControl->getIStyle() ;
        pNSAdrListWindow->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pNSAdrListWindow->pControle->setControle(dynamic_cast<void *>(pNSAdrListWindow)) ;
        pNSAdrListWindow->pControle->setType(pNSAdrListWindow->donneType()) ;
        pNSAdrListWindow->pControle->setFilling(sFilling) ;
        pNSAdrListWindow->pControle->setNSDialog(this) ;

        // on ajoute ici un indicateur pour pr�ciser que ce controle g�re
        // lui-m�me la gestion multiple sans lancer de multi-dialogue
        pNSAdrListWindow->pControle->setGestionMultiple(true) ;
        referenceControle(pNSAdrListWindow->pControle) ;
      }
      else if (sIdentite.find(string("LCORR")) != NPOS)
      {
        NSCorListWindow * pNSCorListWindow = new NSCorListWindow(this, pContexte, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
        pNSCorListWindow->Attr.Style = pControl->getIStyle() ;
        pNSCorListWindow->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pNSCorListWindow->pControle->setControle(dynamic_cast<void *>(pNSCorListWindow)) ;
        pNSCorListWindow->pControle->setType(pNSCorListWindow->donneType()) ;
        pNSCorListWindow->pControle->setFilling(sFilling) ;
        pNSCorListWindow->pControle->setNSDialog(this) ;
        // on ajoute ici un indicateur pour pr�ciser que ce controle g�re
        // lui-m�me la gestion multiple sans lancer de multi-dialogue
        pNSCorListWindow->pControle->setGestionMultiple(true) ;
        referenceControle(pNSCorListWindow->pControle) ;
      }
      else
      {
        string sItem ;
        size_t pos = sIdentite.find_last_of('/') ;
        if (pos != NPOS)
          sItem = string(sIdentite, pos + 1, strlen(sIdentite.c_str()) - pos - 1) ;
        else
          sItem = sIdentite ;

        if (sItem[0] == 'V')
        {
          NSHistorizedValListWindow * pNSHistoListWindow = new NSHistorizedValListWindow(this, pContexte, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
          pNSHistoListWindow->Attr.Style = pControl->getIStyle() ;
          pNSHistoListWindow->setItemValue(sItem) ;
          pNSHistoListWindow->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
          pNSHistoListWindow->pControle->setControle(dynamic_cast<void *>(pNSHistoListWindow)) ;
          pNSHistoListWindow->pControle->setType(pNSHistoListWindow->donneType()) ;
          pNSHistoListWindow->pControle->setFilling(sFilling) ;
          pNSHistoListWindow->pControle->setNSDialog(this) ;

          // on ajoute ici un indicateur pour pr�ciser que ce controle g�re
          // lui-m�me la gestion multiple sans lancer de multi-dialogue
          pNSHistoListWindow->pControle->setGestionMultiple(true) ;
          referenceControle(pNSHistoListWindow->pControle) ;
        }
        else
        {
          NSHistorizedListWindow * pNSHistoListWindow = new NSHistorizedListWindow(this, pContexte, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
          pNSHistoListWindow->Attr.Style = pControl->getIStyle() ;
          pNSHistoListWindow->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
          pNSHistoListWindow->pControle->setControle(dynamic_cast<void *>(pNSHistoListWindow)) ;
          pNSHistoListWindow->pControle->setType(pNSHistoListWindow->donneType()) ;
          pNSHistoListWindow->pControle->setFilling(sFilling) ;
          pNSHistoListWindow->pControle->setNSDialog(this) ;

          // on ajoute ici un indicateur pour pr�ciser que ce controle g�re
          // lui-m�me la gestion multiple sans lancer de multi-dialogue
          pNSHistoListWindow->pControle->setGestionMultiple(true) ;
          referenceControle(pNSHistoListWindow->pControle) ;
        }
      }
    }

    if (sType == string("VALLISTVIEW32"))
    {
      // contr�le vallistview - from FLP
      NSHistorizedValListWindow * pNSHistoValWindow = new NSHistorizedValListWindow(this, pContexte, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
      pNSHistoValWindow->Attr.Style = pControl->getIStyle() ;
      pNSHistoValWindow->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      pNSHistoValWindow->pControle->setControle(dynamic_cast<void*>(pNSHistoValWindow)) ;
      pNSHistoValWindow->pControle->setType(pNSHistoValWindow->donneType()) ;
      pNSHistoValWindow->pControle->setFilling(sFilling);
      pNSHistoValWindow->pControle->setNSDialog(this) ;
      // on ajoute ici un indicateur pour pr�ciser que ce controle g�re lui-m�me
      // la gestion multiple sans lancer de multi-dialogue
      pNSHistoValWindow->pControle->setGestionMultiple(true) ;
      referenceControle(pNSHistoValWindow->pControle) ;
    }

    if (sType == string("EDIT"))
    {
      // Contr�le Edit
      string sIden = "" ;
      if ((sIdentite.find(string("�C;")) != NPOS) || (sIdentite.find(string("/�C;")) != NPOS))
      {
        // NSEdit qui bosse avec le lexique
        NSEditLexique * pNSEdit = new NSEditLexique(this, pContexte, ctrlID, pContexte->getSuperviseur()->getDico(), "", coords[0], coords[1], coords[2], coords[3], nMaxInput + 1) ;
        pNSEdit->Attr.Style = pControl->getIStyle() ;
        pNSEdit->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pNSEdit->pControle->setControle(dynamic_cast<void *>(pNSEdit)) ;
        pNSEdit->pControle->setType(pNSEdit->donneType()) ;
        pNSEdit->pControle->setFilling(sFilling) ;
        pNSEdit->pControle->setNSDialog(this) ;
        referenceControle(pNSEdit->pControle) ;
      }
      else if (sIdentite.find(string("�CC")) != NPOS)
      {        // Champ edit qui n'ouvre pas le lexique et aliment Complement        NSEditNoLex * pEdit ;        strcpy(szType, "C0") ;        posLex = sIdentite.find(string("�CC")) ;        string sElemLex = string(sIdentite, posLex, BASE_LEXIQUE_LEN) ;        string sLen = string(sElemLex, 4, 2) ;        int iLen = atoi(sLen.c_str()) ;        pEdit = new NSEditNoLex(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang, iLen) ;        pEdit->Attr.Style = pControl->getIStyle() ;        pEdit->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;        pEdit->pControle->setControle(dynamic_cast<void *>(pEdit)) ;
        pEdit->pControle->setType(pEdit->donneType()) ;
        pEdit->pControle->setFilling(sFilling) ;
        pEdit->pControle->setNSDialog(this) ;
        referenceControle(pEdit->pControle) ;

        // Incr�mentation de iIndexEdit de 1 pour passer � l'Edit suivant.        iIndexEdit++ ;
      }      else if (sIdentite.find(string("�CL")) != NPOS)      {        // Champ edit qui n'ouvre pas le lexique et alimente Texte libre        NSEditNoLex* pEdit ;        posLex = sIdentite.find(string("�CL")) ;        string sElemLex = string(sIdentite, posLex, BASE_LEXIQUE_LEN) ;        strcpy(szType, string(sElemLex, 2, 2).c_str()) ;        string sLen = string(sElemLex, 4, 2) ;        int iLen = atoi(sLen.c_str()) ;        pEdit = new NSEditNoLex(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang, iLen) ;        pEdit->Attr.Style = pControl->getIStyle() ;        pEdit->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;        pEdit->pControle->setControle(dynamic_cast<void *>(pEdit)) ;
        pEdit->pControle->setType(pEdit->donneType()) ;
        pEdit->pControle->setFilling(sFilling) ;
        pEdit->pControle->setNSDialog(this) ;
        referenceControle(pEdit->pControle) ;

        // Incr�mentation de iIndexEdit de 1 pour passer � l'Edit suivant.        iIndexEdit++ ;
      }      else
      {
        // Type de saisie dans le contr�le
        string sLivre ;
        string sTypeDate ;
        size_t pos = sIdentite.find(string("�")) ;
        if (pos != NPOS)
        {
          sLivre = string(sIdentite, pos + 1, 1) ;
          strcpy(szType, sLivre.c_str()) ;

          sTypeDate = string(sIdentite, pos + 2, 1) ;
          strcpy(szEditDateType, sTypeDate.c_str()) ;
        }

        // Cr�ation de l'objet OWL correspondant � l'objet d'interface
        NSEdit* pEdit = NULL ;
        WNDTYPE	iEditType = isEdit ;
        switch (szType[0])
        {
          case codeMARK       : pEdit = new NSEdit(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang) ;
                                break ;
          case nbMARK         : pEdit = new NSEdit(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang) ;
                                break ;
          case charMARK       : pEdit = new NSEdit(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang) ;
                                break ;
          case dateMARK       : // NSEditDate*
                                pEdit = new NSEditDate(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang, szEditDateType[0]) ;
                                iEditType = isEditDate ;
                                break ;
          case dateHeureMARK  : pEdit = new NSEditDateHeure(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang, szEditDateType[0]) ;
                                iEditType = isEditDateHeure ;
                                break ;
          case heureMARK      : pEdit = new NSEditHeure(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang) ;
                                break ;
          default             : string sErrMess = string("Unknown Edit type : ") + string(1, szType[0]) ;
                                erreur(sErrMess.c_str(), standardError, 0) ;
        }

        if (pEdit)
        {
        	pEdit->Attr.Style = pControl->getIStyle() ;

          pEdit->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
          pEdit->pControle->setControle(dynamic_cast<void *>(pEdit)) ;
          // pEdit->pControle->setType(pEdit->donneType()) ; // doesn't work, always set a isEdit type
          pEdit->pControle->setType(iEditType) ;
          pEdit->pControle->setFilling(sFilling) ;
          pEdit->pControle->setNSDialog(this) ;
          referenceControle(pEdit->pControle) ;

          // Incr�mentation de iIndexEdit de 1 pour passer � l'Edit suivant.
          iIndexEdit++ ;
        }
      }
    }

    // Static
    if ((sType == string("STATIC")) || (sType == string("BORSTATIC")))
    {
      // Cr�ation de l'objet OWL correspondant � l'objet d'interface
      NSStatic* pNSStatic = new NSStatic(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
      pNSStatic->Attr.Style = pControl->getIStyle() ;
      pNSStatic->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      pNSStatic->pControle->setControle(dynamic_cast<void *>(pNSStatic)) ;
      pNSStatic->pControle->setType(pNSStatic->donneType()) ;
      pNSStatic->pControle->setFilling(sFilling) ;
      pNSStatic->pControle->setNSDialog(this) ;
      referenceControle(pNSStatic->pControle) ;
    }

    if ((sType == string("BUTTON")) &&
          (ctrlID != IDOK) && (ctrlID != IDCANCEL) &&
          (ctrlID != IDB_OK) && (ctrlID != IDB_CANCEL))
    {
      // Contr�le Button (� voir pour OK et Cancel)

      // -----------------------------------------------------------------------
      // ATTENTION : Il faut penser � tester du plus grand au plus petit sinon
      // un groupbox r�pond oui � radiobouton (par exemple)
      // #define BS_PUSHBUTTON       0x00000000L
      // #define BS_DEFPUSHBUTTON    0x00000001L
      // #define BS_CHECKBOX         0x00000002L
      // #define BS_AUTOCHECKBOX     0x00000003L
      // #define BS_RADIOBUTTON      0x00000004L
      // #define BS_3STATE           0x00000005L
      // #define BS_AUTO3STATE       0x00000006L
      // #define BS_GROUPBOX         0x00000007L
      // #define BS_USERBUTTON       0x00000008L
      // #define BS_AUTORADIOBUTTON  0x00000009L

      // D�termination du style
      // int nIndex = ::GetWindowLong(hWnd, GWL_STYLE);
      int nIndex = pControl->getIStyle();

      if ((nIndex & BS_AUTORADIOBUTTON) == BS_AUTORADIOBUTTON)      {
        // Contr�le AutoRadioButton

        // Cr�ation de l'objet OWL correspondant � l'objet d'interface
        NSRadioButton * pRaBut = new NSRadioButton(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3], pGroupCurr) ;
        pRaBut->Attr.Style = pControl->getIStyle() ;
        pRaBut->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pRaBut->pControle->setControle(dynamic_cast<void *>(pRaBut)) ;
        pRaBut->pControle->setType(pRaBut->donneType()) ;
        pRaBut->pControle->setFilling(sFilling) ;
        pRaBut->pControle->setNSDialog(this) ;
        referenceControle(pRaBut->pControle) ;
      }
      else if ((nIndex & BS_GROUPBOX) == BS_GROUPBOX)
      {
        // Contr�le Groupbox
        if (sIdentite != "")
        {
          NSGroupBox * pGrpBox = new NSGroupBox(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
          pGrpBox->Attr.Style = pControl->getIStyle() ;
          pGrpBox->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
          pGrpBox->pControle->setControle(dynamic_cast<void *>(pGrpBox)) ;
          pGrpBox->pControle->setType(pGrpBox->donneType()) ;
          pGrpBox->pControle->setFilling(sFilling) ;
          pGrpBox->pControle->setNSDialog(this) ;
          referenceControle(pGrpBox->pControle) ;
          pGroupCurr = (OWL::TGroupBox *)pGrpBox ;
        }
        else
        {
          OWL::TGroupBox* pGroupBox = new OWL::TGroupBox(this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
          pGroupBox->Attr.Style = pControl->getIStyle() ;
          aGroups.push_back(pGroupBox) ;
          pGroupCurr = pGroupBox ;
        }
      }
      else if ((nIndex & BS_RADIOBUTTON) == BS_RADIOBUTTON)
      {        // Contr�le RadioButton

        // Cr�ation de l'objet OWL correspondant � l'objet d'interface
        NSRadioButton * pRaBut = new NSRadioButton(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3], pGroupCurr) ;
        pRaBut->Attr.Style = pControl->getIStyle() ;
        pRaBut->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pRaBut->pControle->setControle(dynamic_cast<void *>(pRaBut)) ;
        pRaBut->pControle->setType(pRaBut->donneType()) ;
        pRaBut->pControle->setFilling(sFilling) ;
        pRaBut->pControle->setNSDialog(this) ;
        referenceControle(pRaBut->pControle) ;
      }
      else if (((nIndex& BS_CHECKBOX) == BS_CHECKBOX) || ((nIndex& BS_AUTOCHECKBOX) == BS_AUTOCHECKBOX))
      {
        // Contr�le CheckBox
        NSCheckBox * pChkBox = new NSCheckBox(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3], pGroupCurr) ;
        pChkBox->Attr.Style = pControl->getIStyle() ;
        pChkBox->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pChkBox->pControle->setControle(dynamic_cast<void *>(pChkBox)) ;
        pChkBox->pControle->setType(pChkBox->donneType()) ;
        pChkBox->pControle->setFilling(sFilling) ;
        pChkBox->pControle->setNSDialog(this) ;
        referenceControle(pChkBox->pControle) ;
      }
      else
      {
        // Contr�le Button (par d�faut ne participe au transfert )
        NSButton * pButt = new NSButton(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
        pButt->Attr.Style = pControl->getIStyle() ;
        pButt->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pButt->pControle->setControle(dynamic_cast<void *>(pButt)) ;
        pButt->pControle->setType(pButt->donneType()) ;
        pButt->pControle->setFilling(sFilling) ;
        pButt->pControle->setNSDialog(this) ;
        referenceControle(pButt->pControle) ;
      }
    }
    else if (sType == string("BUTTON"))
    {
      TButton* pButt = new TButton(this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
      pButt->Attr.Style = pControl->getIStyle() ;
    }

    if (sType == string("SCROLLBAR"))
    {
      // Contr�le ScrollBar
      int nIndex = pControl->getIStyle() ;
      if ((nIndex& WS_HSCROLL) == WS_HSCROLL)
      {        // Cr�ation de l'objet OWL correspondant � l'objet d'interface
        TScrollBar* pScroll = new TScrollBar(this, ctrlID, coords[0], coords[1], coords[2], coords[3], true) ;
        pScroll->Attr.Style = pControl->getIStyle() ;
      }
      else
      {
        // Cr�ation de l'objet OWL correspondant � l'objet d'interface
        TScrollBar* pScroll = new TScrollBar(this, ctrlID, coords[0], coords[1], coords[2], coords[3], false) ;
        pScroll->Attr.Style = pControl->getIStyle() ;
      }
      // typeCtrl = "ScrollBar" ;
    }

    // BORLAND : Contr�le Bouton
    if ((sType == string("BORBTN")) &&  (ctrlID != IDOK)          && (ctrlID != IDCANCEL)     &&
                                        (ctrlID != IDB_OK)        && (ctrlID != IDB_CANCEL)   &&
                                        (ctrlID != IDRETOUR)      && (ctrlID != IDSUITE)      &&
                                        (ctrlID != IDHELP)        && (ctrlID != IDHELPWWW)    &&
                                        (ctrlID != IDHELPNEW)     && (ctrlID != IDTREEPASTE)  &&
                                        (ctrlID != IDCONCLUSION)  && (ctrlID != IDBBKCALCUL))
    {
      // D�termination du style
      // int nIndex = ::GetWindowLong(hWnd, GWL_STYLE);
      int nIndex = pControl->getIStyle() ;

      if (!((nIndex & BBS_BITMAP) == BBS_BITMAP))
      {
        // Contr�le RadioButton
        NSButton * pButt = new NSButton(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
        pButt->Attr.Style = pControl->getIStyle() ;
        pButt->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pButt->pControle->setControle(dynamic_cast<void *>(pButt)) ;
        pButt->pControle->setType(pButt->donneType()) ;
        pButt->pControle->setFilling(sFilling) ;
        pButt->pControle->setNSDialog(this) ;
        referenceControle(pButt->pControle) ;
      }
    }
    else if (sType == string("BORBTN"))
    {
      // For dialogs, buttons IDB_OK and IDB_CANCEL (that are not created for
      // windows) are visible and given the IDOK and IDCANCEL IDs
      //
      if      (IDB_OK == ctrlID)
        ctrlID = IDOK ;
      else if (IDB_CANCEL == ctrlID)
        ctrlID = IDCANCEL ;

      TButton* pButt = new TButton(this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
      pButt->Attr.Style = pControl->getIStyle() ;
    }

    // BORLAND : Contr�le CheckBox
    if (sType == string("BORCHECK"))
    {
      NSCheckBox * pChkBox = new NSCheckBox(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3], pGroupCurr) ;
      pChkBox->Attr.Style = pControl->getIStyle() ;
      pChkBox->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      pChkBox->pControle->setControle(dynamic_cast<void *>(pChkBox)) ;
      pChkBox->pControle->setType(pChkBox->donneType()) ;
      pChkBox->pControle->setFilling(sFilling) ;
      pChkBox->pControle->setNSDialog(this) ;
      referenceControle(pChkBox->pControle) ;
    }

    if (sType == string("BORRADIO"))
    {
      // BORLAND : Contr�le RadioBouton
      NSRadioButton * pRaBut = new NSRadioButton(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3], pGroupCurr) ;
      pRaBut->Attr.Style = pControl->getIStyle() ;
      pRaBut->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      pRaBut->pControle->setControle(dynamic_cast<void *>(pRaBut)) ;
      pRaBut->pControle->setType(pRaBut->donneType()) ;
      pRaBut->pControle->setFilling(sFilling) ;
      pRaBut->pControle->setNSDialog(this) ;
      referenceControle(pRaBut->pControle) ;
    }

    if (sType == string("SYSTABCONTROL32"))
    {
      // BORLAND : Contr�le Onglets
      NSOnglet * pOnglet = new NSOnglet(pContexte, this, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
      pOnglet->Attr.Style = pControl->getIStyle() ;
      pOnglet->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      pOnglet->pControle->setControle(dynamic_cast<void *>(pOnglet)) ;
      pOnglet->pControle->setType(pOnglet->donneType()) ;
      pOnglet->pControle->setFilling(sFilling) ;
      pOnglet->pControle->setNSDialog(this) ;
      referenceControle(pOnglet->pControle) ;
    }

    if (sType == string("COMBOBOX"))
    {
    	// is it a classification or not ?
      bool bClassif = false ;
      VectString aVecteurString ;
			NSSuper* pSuper = pContexte->getSuperviseur() ;
			pSuper->getFilGuide()->TousLesVrais("0CODE", "ES", &aVecteurString, "ENVERS") ;			if (!(aVecteurString.empty()))			{				string sIdentSens ;				pSuper->getDico()->donneCodeSens(&sIdentite, &sIdentSens) ;        if (aVecteurString.contains(sIdentSens))        	bClassif = true ;			}
      if (bClassif)
			{
      	// BORLAND : Contr�le Combobox
      	NSComboClassif * pComboB = new NSComboClassif(pContexte, this, ctrlID, coords[0], coords[1], coords[2], coords[3], pControl->getIStyle(), 0) ;
        pComboB->Attr.Style = pControl->getIStyle() ;
      	// NSComboClassif * pComboB = new NSComboClassif(this, ctrlID) ;
      	pComboB->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      	pComboB->pControle->setControle(dynamic_cast<void *>(pComboB)) ;
      	pComboB->pControle->setType(pComboB->donneType()) ;
      	pComboB->pControle->setFilling(sFilling) ;
      	pComboB->pControle->setNSDialog(this) ;
      	referenceControle(pComboB->pControle) ;
      }
      else
      {
      	NSComboSemantique * pComboB = new NSComboSemantique(pContexte, this, ctrlID, coords[0], coords[1], coords[2], coords[3], pControl->getIStyle(), 0) ;
        pComboB->Attr.Style = pControl->getIStyle() ;
      	// NSComboClassif * pComboB = new NSComboClassif(this, ctrlID) ;
      	pComboB->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      	pComboB->pControle->setControle(dynamic_cast<void *>(pComboB)) ;
      	pComboB->pControle->setType(pComboB->donneType()) ;
      	pComboB->pControle->setFilling(sFilling) ;
      	pComboB->pControle->setNSDialog(this) ;
      	referenceControle(pComboB->pControle) ;
      }
    }

    // BORLAND : Contr�le BorShade
    if (sType == string("BORSHADE"))
    {
      // D�termination du style
      // int nIndex = ::GetWindowLong(hWnd, GWL_STYLE) ;
      int nIndex = pControl->getIStyle() ;

      if (((nIndex & BSS_RGROUP) == BSS_RGROUP) || ((nIndex & WS_GROUP) == WS_GROUP))
      {
        // Contr�le Group
        if (sIdentite != "")
        {
          NSGroupBox * pGrpBox = new NSGroupBox(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
          pGrpBox->Attr.Style = pControl->getIStyle() ;
          pGrpBox->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
          pGrpBox->pControle->setControle(dynamic_cast<void *>(pGrpBox)) ;
          pGrpBox->pControle->setType(pGrpBox->donneType()) ;
          pGrpBox->pControle->setFilling(sFilling) ;
          pGrpBox->pControle->setNSDialog(this) ;
          referenceControle(pGrpBox->pControle) ;
          pGroupCurr = (OWL::TGroupBox *)pGrpBox ;
        }
        else
        {
          OWL::TGroupBox* pGroupBox = new OWL::TGroupBox(this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
          pGroupBox->Attr.Style = pControl->getIStyle() ;
          // aGroups.push_back(pGroupBox) ;
          pGroupCurr = pGroupBox ;
        }
      }
    }

/*
    if (ctrlID == IDBBKCALCUL)
    {
      // cas o� le contr�le n'est pas un des contr�les pr�c�dents, mais que
      // c'est le contr�le qui lance le calcul par le Blackboard
      NSControle * pCtr = new NSControle(pBBItem, sIdentite, sDlgFonction) ;
      referenceControle(pCtr) ;
    }
*/

    // Incr�mentation du compteur
    iIndexCtrl++ ;
    prec = suiv + 1 ;
    suiv = sRCData.find("|", prec) ;
    pControl = pDialogBox->getNextControl(pControl) ;
  }

  // On fixe la taille de la boite de dialogue
  NS_CLASSLIB::TRect dlgSizeRect(0, 0, pDialogBox->getW(), pDialogBox->getH()) ;
  MapDialogRect(dlgSizeRect) ;

  // Appel du SetupWindow() de TDialog
  TDialog::SetupWindow() ;

  // On fixe la caption du dialogue
  string sDlgCaption = pDialogBox->getCaption() ;
  if (sDlgCaption[0] == '$')
  {
    if (sDlgCaption == string("$NAME"))
    {
      if (NULL != pContexte->getPatient())
        sDlgCaption = pContexte->getPatient()->getNomLong() ;
      else
        sDlgCaption = "" ;
    }
    else
      sDlgCaption = "" ;
  }
  SetCaption(sDlgCaption.c_str()) ;

  // Redimentionnement
  NS_CLASSLIB::TRect dlgRect ;
  GetWindowRect(dlgRect) ;
  NS_CLASSLIB::TRect clientRect ;
  GetClientRect(clientRect) ;

  // On compare le clientRect r�el avec les dimensions souhait�es, et on modifie
  // le WindowRect en cons�quence
  int nouvWindowWidth  = dlgRect.Width()  + (dlgSizeRect.Width()  - clientRect.Width()) ;
  int nouvWindowHeight = dlgRect.Height() + (dlgSizeRect.Height() - clientRect.Height()) ;
  MoveWindow(dlgRect.left, dlgRect.top, nouvWindowWidth, nouvWindowHeight) ;

  // Evaluation du rectangle utilisable � l'�cran
  NS_CLASSLIB::TRect usableRect ;

  // Taille de l'�cran - Screen size
  TScreenDC screenDC ;
  int iHorzRes = screenDC.GetDeviceCaps(HORZRES) ;
  int iVertRes = screenDC.GetDeviceCaps(VERTRES) ;

  usableRect = NS_CLASSLIB::TRect(dlgRect.TopLeft(), NS_CLASSLIB::TPoint(iHorzRes, iVertRes)) ;

  // TaskBar de Windows
  // RECT        rect ;
  APPBARDATA  AppBarData ;

  AppBarData.hWnd = ::FindWindow("Shell_TrayWnd", NULL) ;
  if (AppBarData.hWnd != 0)
  {
    AppBarData.cbSize = sizeof(AppBarData) ;
    int iResult = ::SHAppBarMessage(ABM_GETTASKBARPOS, &AppBarData) ;
    if (iResult)
    {
      switch (AppBarData.uEdge)
      {
        case ABE_BOTTOM : usableRect.bottom = AppBarData.rc.top ;
                          break ;
        case ABE_LEFT   : if (usableRect.Left() < AppBarData.rc.right)
                            usableRect.left = AppBarData.rc.right ;
                          break ;
        case ABE_RIGHT  : if (usableRect.Right() > AppBarData.rc.left)
                            usableRect.right = AppBarData.rc.left ;
                          break ;
        case ABE_TOP    : break ;
      }
    }
  }

  int newTop;
  if (nouvWindowHeight > usableRect.Height())
  {
    newTop = dlgRect.top - (nouvWindowHeight - usableRect.Height()) ;
  }

  if (newTop < 0)
    newTop = 0 ;

  if (newTop < dlgRect.top)
    MoveWindow(dlgRect.left, newTop, nouvWindowWidth, nouvWindowHeight) ;
}
catch (...)
{
  erreur("Exception NSDialog::CreerControlesArchetype.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------// Function     :	NSDialog::detruitControles()
// Arguments    :	Rien
// Description  :	Sert � d�truire les objets de contr�le (NSButton, NSCheckBox)
//						    cr��s par NSDialog.
// Returns      :	Rien
// -----------------------------------------------------------------------------
voidNSDialog::detruitControles()
{
    pNSCtrl->vider() ;
}


// -----------------------------------------------------------------------------
// Function     :	NSDialog::initControlesFromBbk()
// Description  :	Initialise les contr�les � partir du blackboard.
// Returns      :	Rien
// -----------------------------------------------------------------------------
void
NSDialog::initControlesFromBbk(string sAction)
{
	// No use to init from bbk if patient is not opened
	//
	if (NULL == pContexte->getPatient())
		return ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;
  if (NULL == pSuper->getBBinterface())
		return ;

	pSuper->getBBinterface()->connectTokenToWindow(pBBItem->KsInterface.getTokenId(), HWindow) ;

	if (pNSCtrl->empty())
  	return ;

  // L'archetype est par convention dans le champ fils du BBItem lanceur
  string sArchetype = string(pBBItem->pDonnees->fils) ;

  pSuper->afficheStatusMessage("Interrogation du Blackboard...") ;

  bool bAsynchronousQuestionsAsked = false ;

  for (iterNSControle i = pNSCtrl->begin(); (i != pNSCtrl->end()); i++)  {  	if ((*i)->getTransfert() && ((*i)->isToFilling(sAction)))    {      string sCheminBBFilsItem = string("") ;    	(*i)->getPathForBlackboard(&sCheminBBFilsItem) ;      string end_date = "", date_fils ;

      (*i)->getEndValidityDate(&end_date) ;

      // on a ici un chemin non vide = une question � poser au blackboard
      NSPatPathoArray* pPatPathoArray = NULL ;

      // on pose la question au blackboard
			int res = pSuper->getBBinterface()->precoche(sCheminBBFilsItem, sArchetype, &pPatPathoArray, &date_fils, "", end_date) ;
			if ((res == 1) && (NULL != pPatPathoArray) && (!(pPatPathoArray->empty())))
        // il y a une r�ponse du blackboard ==>
        // on transmet la patpatho au BBFilsItem via le pTransfert
        // On met � jour le contr�le
        //
				initControlFromBbkAnswer(*i, pPatPathoArray, &date_fils) ;

      else if ((*i)->initOnTimer())
      {
      	bAsynchronousQuestionsAsked = true ;
        // TypedVal typ(sCheminBBFilsItem) ;
      	// AskDeterministicQuestion *DPIOMessage = new AskDeterministicQuestion("From dialog", &typ, 10) ;
  			// pSuper->bbkToDo(pBBItem->pBigBoss->pContexte, 0, "AskDeterministicQuestion", "", "", DPIOMessage, true, NULL, false) ;
      }
      if (pPatPathoArray)
        delete pPatPathoArray ;
		}
  }  if (bAsynchronousQuestionsAsked)  	SetTimer(ID_OB1_TIMER, 1000) ;}void
NSDialog::initControlFromBbkAnswer(NSControle* pControl, NSPatPathoArray* pPatPathoArray, string* psDate)
{
	if (NULL == pControl)
  	return ;
  if ((NULL == pPatPathoArray) || pPatPathoArray->empty())
  	return ;

  pControl->initFromArray(pPatPathoArray) ;

  if (NULL == psDate)
		return ;

  //
  // Recherche d'un contr�le qui contiendrait la date de cette information
  // We look for another control whose subject would be this control's date
  //
  if (pNSCtrl->empty())
    return ;

  iterNSControle k ;
  for (k = pNSCtrl->begin(); (k != pNSCtrl->end()) && (*k != pControl); k++) ;
  if (k == pNSCtrl->end())
  	return ;

  string sIdentite = pControl->getIdentite() ;
  bool trouve = false ;

  k++ ;

  while (k != pNSCtrl->end())
  {
    if (((*k)->getFilling() == "D") && ((*k)->getPathControl() == sIdentite))
    {
      trouve = true ;
      break ;
    }

    k++ ;
  }

  if (!trouve)
		return ;

  // on regarde si on a une date ou une date et heure
  string sDateIdent = (*k)->getIdentite() ;
  string typeDate = "" ;
  size_t pos = sDateIdent.find_last_of("/�") ;
  if (pos != string::npos)
  	typeDate = string(sDateIdent, pos, 2) ;

  string date_fils = *psDate ;

  if ((typeDate == "�T") || (typeDate == "�D"))
  {
  	NVLdVTemps tpsObj ;
    tpsObj.initFromDate(date_fils) ;

    if (typeDate == "�T")
    	date_fils = tpsObj.donneDateHeure() ;
    else
    	date_fils = tpsObj.donneDate() ;
  }

  (*k)->getTransfert()->pTransfertMessage->SetComplement(date_fils) ;
  (*k)->getTransfert()->pBBFilsItem->Active() ; //rendre ce fils actif
  (*k)->prepareControle() ;
}

// -----------------------------------------------------------------------------
// Function     :	NSDialog::rafraichitControles()
// Description  :	Initialise les contr�les en fonction de l'�tat du BBItem.
// Returns      :	Rien
// -----------------------------------------------------------------------------
void
NSDialog::rafraichitControles()
{
	if (pNSCtrl->empty())
  	return ;

  for (iterNSControle i = pNSCtrl->begin(); (i != pNSCtrl->end()); i++)
  	(*i)->prepareControle() ;
}

// -----------------------------------------------------------------------------
//  Function    : NSDialog::initialiseControles()
//  Description :	Initialisation des contr�les apr�s TDialog::SetupWindow()
//						    - Lance l'�ventuelle fonction d'initialisation des contr�les.
//						    - Initialise l'onglet
//  Returns     : Rien
// -----------------------------------------------------------------------------
void
NSDialog::initialiseControles()
{
	if (pNSCtrl->empty())
		return ;

	iterNSControle i ;
	for (i = pNSCtrl->begin() ; (i != pNSCtrl->end()); i++)
	{
  	//
    // Si le contr�le est un onglet, on l'initialise
    //
    if ((*i)->getType() == isOnglet)
    	(static_cast<NSOnglet*>((*i)->getControle()))->InitialiseTabs(pConfigCacheTab) ;

    //
    // On lance l'�ventuelle fonction d'initialisation
    //
		if ((*i)->getFonction())
    	(*i)->getFonction()->execute(NSDLGFCT_CREATION) ;
	}
}

void
NSDialog::initControlesFromCapture()
{
  NSSuper *pSuper = pContexte->getSuperviseur() ;
  if (pSuper->getEpisodus() == NULL)
    return ;

  NSCaptureArray* pCapt = &(pSuper->getEpisodus()->CaptureArray) ;
  if (pCapt->empty())
    return ;

  // ici on en est
  for (iterNSControle i = pNSCtrl->begin() ; i != pNSCtrl->end() ; i++)
  {
    if ((*i)->getTransfert())
    {
      // on r�cup�re le chemin du BBItem p�re du BBFilesItem associ� au
      // NSControle via son transfert
      //
      BBFilsItem* pFilsItem = (*i)->getTransfert()->pBBFilsItem ;

      string sCheminBBFilsItem = string("");
      string sEtiq = string("") ;

      if (pFilsItem)
      {
      	// on r�cup�re le chemin du BBItem p�re
      	sCheminBBFilsItem = (*i)->getTransfert()->pBBFilsItem->getItemFather()->sLocalisation ;
      	// on r�cup�re l'�tiquette du fils
      	string  sEtiquette = (*i)->getTransfert()->pBBFilsItem->getItemLabel() ;
      	pSuper->getDico()->donneCodeSens(&sEtiquette, &sEtiq) ;
      }

      for (CaptureIter captIter = pCapt->begin() ; captIter != pCapt->end() ; captIter++)
      {
      	if ((*captIter)->sChemin != string(""))
        {
          //
          // On regarde si le chemin de l'�l�ment se termine par le chemin
          // de capture
          //
          string sCheminCapture ;
          pSuper->getDico()->donneCodeSens(&((*captIter)->sChemin), &sCheminCapture) ;

          // Attention, la d�tection automatique ajoute GCONS1, il faut le
          // supprimer
          if ((strlen(sCheminCapture.c_str()) > 6) && (string(sCheminCapture, 0, 6) == "GCONS/"))
            sCheminCapture = string(sCheminCapture, 6, strlen(sCheminCapture.c_str())-6) ;

          string sCheminCompare = "" ;

          size_t iCaptLen = strlen(sCheminCapture.c_str()) ;
          size_t iBBLen   = strlen(sCheminBBFilsItem.c_str()) ;

          if (iBBLen >= iCaptLen)
              sCheminCompare = string(sCheminBBFilsItem, iBBLen - iCaptLen, iCaptLen) ;

          //if (sCheminCapture == sCheminBBFilsItem)
          if (sCheminCompare == sCheminCapture)
          {
            if      (sEtiq[0] == '�')
            {
              (*i)->getTransfert()->pTransfertMessage->SetTexteLibre((*captIter)->sLibelle) ;
              (*i)->getTransfert()->pBBFilsItem->Active() ;
            }
            else if (sEtiq[0] == '2')
            {
              size_t iChemMark = sEtiq.find(cheminSeparationMARK) ;
              if (string::npos != iChemMark)
              {
                string  sUnit   = string(sEtiq, 0, iChemMark) ;
                string  sLexiq  = string(sEtiq, iChemMark + 1, strlen(sEtiq.c_str()) - iChemMark - 1) ;

                string sValeur = (*captIter)->sLibelle ;

                // Conversion d'unit�s
                if (((*captIter)->sUnit != "") && (sUnit != (*captIter)->sUnit))
                {
                  NSCV NsCv(pContexte) ;
                  DBIResult Resultat = NsCv.open() ;
                  if (Resultat != DBIERR_NONE)
                  {
                    erreur("Erreur � l'ouverture de la base convert.", standardError, Resultat) ;
                    sValeur = "" ;
                  }
                  else
                  {
                    double dVal = StringToDouble(sValeur) ;
                    if (NsCv.ConvertirUnite(&dVal, sUnit, (*captIter)->sUnit))
                      sValeur = DoubleToString(&dVal, 0, 2) ;
                    else
                      sValeur = "" ;

                    NsCv.close();
                  }
                }

                if (sValeur != "")
                {
                  (*i)->getTransfert()->pTransfertMessage->SetLexique(sLexiq) ;
                  (*i)->getTransfert()->pTransfertMessage->SetUnit(sUnit) ;
                  (*i)->getTransfert()->pTransfertMessage->SetComplement(sValeur) ;
                  (*i)->getTransfert()->pBBFilsItem->Active() ;
                }
              }
            }
            else
            {
              string  sLabel ;
              pSuper->getDico()->donneCodeSens(&((*captIter)->sLibelle), &sLabel) ;
              if (sEtiq == sLabel)
                (*i)->getTransfert()->pBBFilsItem->Active() ;
            }
            (*i)->executeKillFocusBehaviour() ;
            (*i)->prepareControle() ;
            break ;
          }
        }
      }
    }
  }
}


void NSDialog::TestClick(WPARAM)
{
	::MessageBox(0, "Click sur un bouton", "Configuration", MB_OK);
}

void
NSDialog::ForceCanClose()
{
	canCloseOk = false ;
}

// -----------------------------------------------------------------------------// Function     : NSDialog::Canclose()// Arguments    : AUCUN
// Description  : Finit le sousclassement des contr�les EDIT pour laisser la
//                place propre
// Returns      : true
// -----------------------------------------------------------------------------
bool
NSDialog::CanClose()
{
    //
    // En cas de perte du focus, on cache l'�ventuelle fen�tre de pilotage
    // de description multiple pour �viter sa s�lection � partir d'une fen�tre
    // fille de cette boite de dialogue
    //
    if (canCloseOk)
    {
        canCloseOk = false;
        return false;
    }
    TWindow* pMere = Parent;
    NSDialog* pDialog = TYPESAFE_DOWNCAST(pMere, NSDialog);
    if (pDialog)
    {
        if (pDialog->pControleurMulti)
        {
            pDialog->pControleurMulti->Show(SW_SHOWNORMAL);
            pDialog->SetFocus();
        }
    }

    //
    // Si on "remplace" une CQVue, il faut fermer la vue
    //
    //if (pView)
    //    ::SendMessage(pView->GetHandle(), WM_CLOSE, 0, 0) ;

    return true;
}

//--------------------------------------------------------------------------// quand on selectionne une boite de dialogue
//	utilis�e surtout pour les bo�tes multidialogue
//--------------------------------------------------------------------------
void
NSDialog::EvActivate(uint active, bool minimized, HWND hwnd)
{
	string ps = string("Entr�e dans EvActivate de NSDialog") ;	pContexte->getSuperviseur()->trace(&ps, 1) ;

	TWindow::EvActivate(active, minimized, hwnd) ;

	if (((active == WA_ACTIVE) || (active == WA_CLICKACTIVE)) && (!minimized))
	{
		if (pControleurMulti)
			pControleurMulti->setActive(this) ;

		if ((sHelpBodyUrl != "") || (sHelpIndexUrl != ""))
		{
			NSSuper* pSuper = pContexte->getSuperviseur() ;
			if (pSuper)
			{
				pSuper->setAideIndex(sHelpIndexUrl) ;
				pSuper->setAideCorps(sHelpBodyUrl) ;
			}
			else
			{
				pSuper->setAideIndex("") ;
				pSuper->setAideCorps("zz_generique.htm") ;
			}
		}
	}

	if (pView == NULL)
	{
  	ps = string("Sortie de EvActivate de NSDialog (view is Null)") ;
		pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
		return ;	}	NSMUEView* pMueView = TYPESAFE_DOWNCAST(pView, NSMUEView) ;
	if (pMueView == NULL)
  {
  	ps = string("Sortie de EvActivate de NSDialog (MueView is Null)") ;
		pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
		return ;	}

	NSPaneSplitter* pPaneSplit = pMueView->getPaneSplitter() ;
	if ((pPaneSplit == NULL) || (pPaneSplit->pMDIChild == NULL))
  {
  	ps = string("Sortie de EvActivate de NSDialog (Invalid PaneSplitter is Null)") ;
		pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
		return ;	}

	if (((active == WA_ACTIVE) || (active == WA_CLICKACTIVE)) && (!minimized))
	{
  	/****************************
		HWND hForeGround = ::GetForegroundWindow() ;
  	    if ((hForeGround == GetHandle()) || (hForeGround == pPaneSplit->pMDIChild->GetHandle()))
			return ;
    ******************************/

		if (bActivateMUEView)
    {
      NSSuper* pSuper = pContexte->getSuperviseur() ;
      NSToDoTask* pTask = new NSToDoTask ;
      pTask->sWhatToDo = "ActivateMUEView" ;
      pTask->pPointer1 = (void*)pMueView ;
      pTask->pPointer2 = (void*)this ;

      pSuper->addToDo(pTask) ;
    }
    else
    	bActivateMUEView = true ;

		// pPaneSplit->pMDIChild->PostMessage(WM_ACTIVATE, MAKEWPARAM(active, minimized), LPARAM(hwnd)) ;
	}
    /**********************************
	else
	{
  	    SetWindowPos(pPaneSplit->pMDIChild->GetHandle() ,0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE	) ;
	}
    *************************************/

	ps = string("Sortie de EvActivate de NSDialog") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
}boolNSDialog::EvNCActivate(bool active){	TDialog::EvNCActivate(active) ;  if (active)		activateParent() ;  return true ;}voidNSDialog::EvLButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point){	TDialog::EvLButtonDown(modKeys, point) ;	if (pView == NULL)		return ;	NSMUEView* pMueView = TYPESAFE_DOWNCAST(pView, NSMUEView) ;
	if (pMueView == NULL)
		return ;

	NSPaneSplitter* pPaneSplit = pMueView->getPaneSplitter() ;
	if ((pPaneSplit == NULL) || (pPaneSplit->pMDIChild == NULL))
		return ;

	// Send WM_PARENTNOTIFY to parent's MDIchild
  LPARAM wparam = MAKEWPARAM(WM_LBUTTONDOWN, 0) ;
  LPARAM lparam = MAKELPARAM(point.X(), point.Y()) ;
  pPaneSplit->pMDIChild->PostMessage(WM_PARENTNOTIFY, wparam, lparam) ;
	// pPaneSplit->pMDIChild->PostMessage(WM_PARENTNOTIFY, MAKEWPARAM(WM_LBUTTONDOWN, 0), MAKELPARAM(point.X(), point.Y())) ;
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------
void
NSDialog::CmHelp()
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;
	if (pSuper)
	{
		if ((sHelpBodyUrl != "") || (sHelpIndexUrl != ""))
		{
			pSuper->setAideIndex(sHelpIndexUrl) ;
			pSuper->setAideCorps(sHelpBodyUrl) ;
		}
		else
		{
			pSuper->setAideIndex("") ;
			pSuper->setAideCorps("zz_generique.htm") ;
		}
	}

	pContexte->NavigationAideEnLigne() ;
}


voidNSDialog::CmTreePaste()
{
try
{
	string      sLocalis  = pBBItem->sLocalisation ;

	NSPatPathoArray *pPathoSynthese = 0 ;

	bool continuer = true ;

	if (pContexte->getPatient())
	{
		NSDocHistoArray *pDocArray = &(pContexte->getPatient()->pDocHis->VectDocument) ;

		if (!(pDocArray->empty()))
		{
			DocumentIter iterDoc = pDocArray->begin() ;
			while ((iterDoc != pDocArray->end()) && continuer)
			{
				PatPathoIter iter = (*iterDoc)->pPatPathoArray->begin() ;
				if ((*iter)->getLexique() == string("ZSYNT1"))
        {
        	pPathoSynthese = (*iterDoc)->pPatPathoArray ;
          continuer = false ;
        }
        else
        	iterDoc++ ;
      }
    }
  }

	if (!pPathoSynthese || pPathoSynthese->empty())
		return ;

	string sousChaine, sLocaCherche ;
	PatPathoIter IterPpt = pPathoSynthese->begin() ;

/*
  bool bChercher = true;
  while (bChercher && (sLocalis != ""))
  {
    sLocaCherche = sLocalis ;
    IterPpt = pPathoSynthese->ChaineDansPatpatho(sLocaCherche, &sousChaine, string("|")) ;
        if (IterPpt == pPathoSynthese->end())
        {
        	size_t posSepare = sLocalis.find('/');
            if (posSepare == NPOS)
                sLocalis = "";
            else
                sLocalis = string(sLocalis, posSepare+1, strlen(sLocalis.c_str())-posSepare-1);
        }
        else
        	bChercher = false;
    } */
	sLocaCherche = sLocalis;	size_t posSepare = sLocaCherche.find('/');
	while (posSepare != NPOS)
	{
		sLocaCherche = string(sLocaCherche, posSepare+1, strlen(sLocaCherche.c_str())-posSepare-1);
		posSepare = sLocaCherche.find('/');
	}
	IterPpt = pPathoSynthese->ChaineDansPatpatho(sLocaCherche, &sousChaine, string("|"));

	if ((NULL == IterPpt) || (pPathoSynthese->end() == IterPpt))
	{
		// delete pPathoSynthese;
		return ;
	}
	if (!(pBBItem->pPPTEnCours))
		return ;

	// On est sur l'�l�ment, ce sont ses fils qui nous int�ressent
	int iColRef = (*IterPpt)->getColonne() + 1;
	int iLigRef = (*IterPpt)->getLigne() + 1;

	// On v�rifie qu'il existe bien des donn�es � r�cup�rer avant de
	// remettre � z�ro le BBItem
	IterPpt++ ;
	if ((pPathoSynthese->end() == IterPpt) || ((*IterPpt)->getColonne() < iColRef))
		return ;

	BBFilsItem*	pFilsPere =	pBBItem->pBBFilsPere ;
	if (NULL == pFilsPere)
		return ;

	NSVectFatheredPatPathoArray* pVect = pFilsPere->getPatPatho() ;
	if (pVect->empty())
		pVect->push_back(new NSFatheredPatPathoArray(pContexte, 0, new NSPatPathoArray(pContexte))) ;
	else
		(*(pVect->begin()))->getPatPatho()->vider() ;
	FatheredPatPathoIterVect iJ = pVect->begin() ;

	// pBBItem->RemetAZero();

	while ((IterPpt != pPathoSynthese->end()) &&
           ((*IterPpt)->getColonne() >= iColRef))
	{
		NSPatPathoInfo* pPpt = new NSPatPathoInfo(*(*IterPpt)) ;
		pPpt->setColonne(pPpt->getColonne() - iColRef) ;
		pPpt->setLigne(pPpt->getLigne() - iLigRef) ;
		(*iJ)->getPatPatho()->push_back(pPpt) ;

		IterPpt++ ;
	}

	pFilsPere->Redeveloppe();
	//rafraichitControles();
	//Invalidate();
}
catch (...)
{
	erreur("Exception NSDialog::CmTreePaste.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------
//  Function: 		void NSDialog::CmOk()
//
//  Arguments:		AUCUN
//  Description:	R�pond � OK.
//  Returns:		RIEN
//---------------------------------------------------------------------------
void
NSDialog::CmOk()
{
	// If Ok already activated, do nothing
  //
	if (bOkActivated)
		return ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;

	bOkActivated = true ;

	if (bMereMUEView)
		canCloseOk = true ;

	//
  // Les conditions de fermeture sont-elles remplies ?
  //
  if (false == pNSCtrl->empty())
  	for (iterNSControle i = pNSCtrl->begin(); i != pNSCtrl->end(); i++)
    	if (!((*i)->canWeClose()))
      {
      	bOkActivated = false ;
      	return ;
      }

	string sMessage ;
	// v�rification des contraintes (SFMG RC)
	if (!pBBItem->verifConstraintItem(&sMessage))
	{
    string sWarningMsg = pSuper->getText("archetypesMessages", "someMandatoryInformationIsMissing") ;
  	erreur(sWarningMsg.c_str(), warningError, 0) ;
    bOkActivated = false ;
    return ;
  }

	bool bRootArchetype = false ;
  if ((pBBItem == pBBItem->pBigBoss->pBBItem) && (pBBItem->ouvreArchetype()))
  	bRootArchetype = true ;

  //
  // D�clenchement du calcul
  //
  if (bRootArchetype)
  	CmBbkCalcul() ;

	pBBItem->donneRetourDlg(0) ;

	//
  // S'il s'agit de NSTreeWindow et d'un texte libre, alors enregistrer
  // ce texte
  //
  if (!(pNSCtrl->empty()))
  {
  	for (iterNSControle i = pNSCtrl->begin(); i != pNSCtrl->end(); i++)
    {
    	if ((*i)->getType() == isTreeWindow)
      {
      	NSTreeWindow* pNSTreeWindow = static_cast<NSTreeWindow*>((*i)->getControle());
        if (pNSTreeWindow->pEditDico)
        	pNSTreeWindow->pEditDico->TextLibre() ;
      }
    }
  }

  // Attention : pour la fiche administrative, qui ne se ferme pas sur le OK
  // il ne faut pas d�tacher les contr�les
  bool bDetacheCtrls = true ;
  if (bRootArchetype)
  {
  	if ((pBBItem->pParseur) && (pBBItem->pParseur->pArchetype))
    {
    	NSSuper* pSuper = pContexte->getSuperviseur() ;

    	string sArcName = pBBItem->pParseur->pArchetype->getName() ;
      if (pSuper->getDemographicArchetypeId() == sArcName)
      	bDetacheCtrls = false ;
    }
  }

  executePreClosingFunctions() ;

  // Le BBItem donne-t-il l'autorisation de fermer ?
  // Does the BBItem allow this dialog to close ?
  //
	if (!(pBBItem->okFermerDialogue(true, bDetacheCtrls)))
  {
  	bOkActivated = false ;
  	return ;
  }

  //
  // S'il s'agit de NSTreeWindow tuer pEDitDico
  //
  closeEditDico() ;

  //
  // Eventuel lancement de fonction
  //
  executeClosingFunctions() ;

  //
  // Si la boite de dialogue est un formulaire
  //
  if ((bRootArchetype) && (!(pBBItem->bModalDialog)))
  {
  	// On signale la volont� de fermer ; c'est pBigBoss qui
    // fermera le questionnaire apr�s �ventuel enregistrement
    //
    /*bool bRet =*/ pBBItem->pBigBoss->fermeBbkArchetype(IDOK, pView) ;

    return;
  }

  if (pControleurMulti)
  {
  	bOkActivated = false ;
  	pControleurMulti->idOk(this) ;
  }
  else
  {
  	if (CanClose())
    	CloseWindow(IDOK) ;
  }
}

void NSDialog::CmSuite(){
	CmOk() ;
}

//-------------------------------------------------------------------------//  Function: 		void NSDialog::CmRetour()
//
//  Arguments:		AUCUN
//  Description:	R�pond au bouton de retour en arri�re
//  Returns:		RIEN
//---------------------------------------------------------------------------
void NSDialog::CmRetour()
{
	executePreClosingFunctions() ;

	pBBItem->donneRetourDlg(-1);
	if (!pBBItem->okFermerDialogue(true))
		return ;

  //
  // S'il s'agit de NSTreeWindow tuer pEDitDico
  //
  closeEditDico() ;

  //
  // Eventuel lancement de fonction
  //
  executeClosingFunctions() ;

  if (CanClose())
    CloseWindow(IDOK) ;
}

//-------------------------------------------------------------------------//  Function: 		void NSDialog::CmConclusion()
//
//  Arguments:		AUCUN
//  Description:	R�pond au bouton de sortie par le bas
//  Returns:		RIEN
//---------------------------------------------------------------------------
void NSDialog::CmConclusion()
{
try
{
	pBBItem->donneRetourDlg(NSDLG_SORTIE_BAS) ;

	BBCmdMessage* pCmdMsg = new BBCmdMessage(NSDLG_SORTIE_BAS) ;
	for (int i = 0; i < 10; i++)
		pBBItem->pBigBoss->empile(pCmdMsg, false) ;
	delete pCmdMsg ;

  executePreClosingFunctions() ;

	if (!pBBItem->okFermerDialogue(true))
		return ;

  //
  // S'il s'agit de NSTreeWindow tuer pEDitDico
  //
  closeEditDico() ;

  //
  // Eventuel lancement de fonction
  //
  executeClosingFunctions() ;

  if (CanClose())
    CloseWindow(IDOK) ;
}
catch (...)
{
	erreur("Exception NSDialog::CmConclusion().", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Function    : void NSDialog::CmBbkCalcul()
// Arguments   : AUCUN
// Description : R�pond au bouton de calcul via le blackboard
// Returns     : RIEN
// -----------------------------------------------------------------------------
void
NSDialog::CmBbkCalcul()
{
try
{
	if (pNSCtrl->empty())
		return ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	bool trouve = false ;

  iterNSControle i = pNSCtrl->begin() ;
	for ( ; (i != pNSCtrl->end()) ; i++)
	{		TControl * pCtrl = static_cast<TControl *>((*i)->getControle()) ;		int idCtrl = pCtrl->GetDlgCtrlID() ;		if (idCtrl == IDBBKCALCUL)		{			trouve = true ;			break ;
		}
	}

	if (!trouve)
		return ;

	SetCursor(pNSDLLModule, IDC_THINKING_CURSOR) ;

	// on enregistre les modifs de tous les fils du BBItem root
	pBBItem->okFermerDialogue(true, false) ;

	NSPatPathoArray PatPathoArray(pContexte) ;

	// L'archetype est par convention dans le champ fils du BBItem lanceur
	string sArchetype = string(pBBItem->pDonnees->fils) ;
	pSuper->afficheStatusMessage("Renseignement du Blackboard...") ;
	string sDejaRepondu = "" ;

  string sCheminBBFilsItem ;
	// Enum�ration de tous les contr�les situ�s avant le contr�le IDBBKCALCUL
	for (i = pNSCtrl->begin() ; (i != pNSCtrl->end()) ; i++)
	{    TControl * pCtrl = static_cast<TControl *>((*i)->getControle()) ;    int idCtrl = pCtrl->GetDlgCtrlID() ;    if (idCtrl == IDBBKCALCUL)      break ;    if (NULL != (*i)->getTransfert())    {      // on r�cup�re le chemin du BBItem pere du BBFilsItem associ�      // au NSControle via son pTransfert      sCheminBBFilsItem = (*i)->getPath() ;      sCheminBBFilsItem = (*i)->cutPath(&sCheminBBFilsItem, string("/0QUES/"), false) ;/*      sCheminBBFilsItem = (*i)->getTransfert()->pBBFilsItem->getItemFather()->sLocalisation ;      // on rajoute l'�tiquette du fils      string sEtiq ;      string sEtiquette = (*i)->getTransfert()->pBBFilsItem->getItemLabel() ;      pSuper->getDico()->donneCodeSens(&sEtiquette, &sEtiq) ;
      sCheminBBFilsItem += string(1, cheminSeparationMARK) + sEtiq ;

      // on enleve le chemin jusqu'� "0QUES1"
      size_t pos = sCheminBBFilsItem.find("/0QUES/") ;      if (pos == string::npos)        continue ;

      sCheminBBFilsItem = string(sCheminBBFilsItem, pos + 7, strlen(sCheminBBFilsItem.c_str()) - pos - 7) ;
*/
      if (sCheminBBFilsItem == "")
        continue ;

      // Cas d'une valeur chiffr�e sur un bouton : enlever ce qui suit /$
      size_t pos = sCheminBBFilsItem.find("/$") ;
      if (pos == 0)
        continue ;
      if (pos != string::npos)
        sCheminBBFilsItem = string(sCheminBBFilsItem, 0, pos) ;

      sCheminBBFilsItem = getRegularPath(sCheminBBFilsItem, cheminSeparationMARK, intranodeSeparationMARK) ;

      // on a ici un chemin non vide = une r�ponse � donner au blackboard
      PatPathoArray.vider() ;

      if ((*i)->getType() == isHistoryValListWindow)
      {
        // cas des listes d'elts multiples : on prend le pTransfert du p�re et
        // on r�cup�re la premiere patpatho de ce transfert
        BBItem* pBBItemPere = (*i)->getTransfert()->pBBFilsItem->getItemFather() ;
        if ((NULL != pBBItemPere) && (NULL != pBBItemPere->pBBFilsPere) && (NULL != pBBItemPere->pBBFilsPere->getItemTransfertData()))
        {
          NSTransferInfo *pTransfert = pBBItemPere->pBBFilsPere->getItemTransfertData() ;
          NSVectFatheredPatPathoArray* pFatheredArray = pTransfert->getPatPatho() ;
          if ((NULL != pFatheredArray) && (false == pFatheredArray->empty()))
          {
            NSFatheredPatPathoArray* pFatheredElement = *(pFatheredArray->begin()) ;
            if ((NULL != pFatheredElement) && (false == pFatheredElement->getPatPatho()->empty()))
              PatPathoArray = *(pFatheredElement->getPatPatho()) ;
          }
        }
      }
      else
      {
        NSVectFatheredPatPathoArray* pFatheredArray = (*i)->getTransfert()->getPatPatho() ;
        if ((NULL != pFatheredArray) && (false == pFatheredArray->empty()) && (false == (*(pFatheredArray->begin()))->getPatPatho()->empty()))
        {
          NSFatheredPatPathoArray* pFatheredElement = *(pFatheredArray->begin()) ;
          PatPathoArray = *(pFatheredElement->getPatPatho()) ;
        }

        else if ((*i)->getTransfert()->pBBFilsItem->Actif())
        {
          BBFilsItem * pFils = (*i)->getTransfert()->pBBFilsItem ;
          BBItem * pPere = pFils->getItemFather() ;
          if (pPere)
          {
            pFils->getItemTransfertData()->pTmpTransfertMessage = pFils->getItemTransfertData()->pTransfertMessage ;
            pFils->getItemTransfertData()->iTmpActif = pFils->getItemTransfertData()->iActif ;

            // Modif PA 16/05/09
            // pPere->pTempPPT->vider() ;
            // pPere->AjouteTmpEtiquette(pFils) ;
            // PatPathoArray = *(pPere->pTempPPT) ;
            NSPatPathoArray TempPPT(pContexte) ;
            pPere->AjouteTmpEtiquette(&TempPPT, pFils) ;
            PatPathoArray = TempPPT ;
          }
        }
      }

      // on donne les r�ponses au blackboard
      if (sCheminBBFilsItem != sDejaRepondu)
      {
				if (((*i)->getTransfert()->pBBFilsItem->VectorFils.empty()) && (PatPathoArray.size() > 1))
        {
        	// Insert the array as an answer to this control's path
          //
        	pSuper->getBBinterface()->insertAnswerOnBlackboard(sCheminBBFilsItem, &PatPathoArray, Undefined) ;
          //
          // Insert leaves as elements with their own path
          //
        	insertLeavesOnBlackBoard(sCheminBBFilsItem, &PatPathoArray) ;
        }
        else
        	pSuper->getBBinterface()->insertAnswerOnBlackboard(sCheminBBFilsItem, &PatPathoArray, Undefined) ;
      }
      // Evite qu'un bouton non click� remette � z�ro ce que vient de mettre un bouton click�
      // To prevent a non clicked button to reset the value just set up by an activated button
      if (!(PatPathoArray.empty()))
        sDejaRepondu = sCheminBBFilsItem ;
    }
	}

  iterNSControle iPostCalcul = i ;

/*
	// On lib�re le KS afin qu'il puisse effectuer les calculs
  string sKsName = pBBItem->KsInterface.getKsName() ;
  if (sKsName != "")
  	pSuper->getBBinterface()->driveKSfromDialog(sKsName, BB1BBInterface::ksFree) ;
*/

	string sErrMsg = pSuper->getText("bbkKsManagement", "blackboardInDuty") ;
	pSuper->afficheStatusMessage((char*)sErrMsg.c_str()) ;

	// This is the case when the KS is already running and waits for the user
  // to press Ok
  //
	if (pBBItem->KsInterface.getTokenId() > 0)
  {
		// On lib�re le token afin qu'il puisse lancer le KS afin d'effectuer les calculs
		pSuper->getBBinterface()->driveKSfromDialog(pBBItem->KsInterface.getTokenId(), BB1BBInterface::ksFree) ;

  	bBlackboardStillAtWork = true ;

    waitForKS() ;
	}
  // This is the case when the KS will only start when results are asked
  // We ask the first question, then wait for the KS end of work signal
  //
  else
  {
  	bool bFirstCompute = true ;
		for (i = iPostCalcul ; (i != pNSCtrl->end()) ; i++)
		{			if ((*i)->getTransfert())			{				// on r�cup�re le chemin du BBItem pere du BBFilsItem associ�				// au NSControle via son pTransfert      	//				sCheminBBFilsItem = getPathForBbkQuestion(i) ;				if (sCheminBBFilsItem != string(""))        {					// on a ici un chemin non vide = une question � poser au blackboard
					NSPatPathoArray * pPatPathoLocal = NULL ;

      		string sAnswerDate ;
					AnswerStatus::ANSWERSTATUS res = pSuper->getBBinterface()->getAnswer2Question(sCheminBBFilsItem, sArchetype, &pPatPathoLocal, sAnswerDate, bFirstCompute, true /* bUserIsWaiting */, HWindow) ;
					bFirstCompute = false ;
          if ((res == AnswerStatus::astatusProcessed) && (pPatPathoLocal != NULL) && (!(pPatPathoLocal->empty())))
					{
						// il y a une r�ponse du blackboard ==> on transmet la patpatho au
        		// BBFilsItem via le pTransfert et on met � jour le contr�le
            //
        		initControlFromBbkAnswer(*i, pPatPathoLocal, &sAnswerDate) ;
          }
          else if (res == AnswerStatus::astatusProcessing)
      			bBlackboardStillAtWork = true ;
          if (pPatPathoLocal)
      			delete pPatPathoLocal ;
        }
      }
    }

    if (bBlackboardStillAtWork)
    	waitForKS() ;
  }

  sErrMsg = pSuper->getText("bbkKsManagement", "displayingResults") ;
	pSuper->afficheStatusMessage((char*) sErrMsg.c_str()) ;

	// bool bFirstCompute = true ;

	for (i = iPostCalcul ; (i != pNSCtrl->end()) ; i++)
	{		if ((*i)->getTransfert())		{			// on r�cup�re le chemin du BBItem pere du BBFilsItem associ�			// au NSControle via son pTransfert      //			sCheminBBFilsItem = getPathForBbkQuestion(i) ;			if (sCheminBBFilsItem == "")				continue ;

			// on a ici un chemin non vide = une question � poser au blackboard
			NSPatPathoArray * pPatPathoLocal = NULL ;

      string sAnswerDate ;
			AnswerStatus::ANSWERSTATUS res = pSuper->getBBinterface()->getAnswer2Question(sCheminBBFilsItem, sArchetype, &pPatPathoLocal, sAnswerDate, false /* bFirstCompute */, true /* bUserIsWaiting */, HWindow) ;
			// bFirstCompute = false ;
			if ((res == AnswerStatus::astatusProcessed) && (pPatPathoLocal != NULL) && (!(pPatPathoLocal->empty())))
			{
				// il y a une r�ponse du blackboard ==> on transmet la patpatho au
        // BBFilsItem via le pTransfert et on met � jour le contr�le

        initControlFromBbkAnswer(*i, pPatPathoLocal, &sAnswerDate) ;
      }
      else if (res == AnswerStatus::astatusProcessing)
      	bBlackboardStillAtWork = true ;

      if (pPatPathoLocal)
      	delete pPatPathoLocal ;
		}
	}

/*
  while (bBlackboardStillAtWork)
	{
  	i = iPostCalcul ;
    bBlackboardStillAtWork = false ;

    for ( ; (i != pNSCtrl->end()) ; i++)
    {      if ((*i)->getTransfert())      {        // on r�cup�re le chemin du BBItem pere du BBFilsItem associ�        // au NSControle via son pTransfert        sCheminBBFilsItem = (*i)->getTransfert()->pBBFilsItem->pPere->sLocalisation ;        // on rajoute l'�tiquette du fils        string sEtiq ;        string sEtiquette = (*i)->getTransfert()->pBBFilsItem->sEtiquette ;        pSuper->getDico()->donneCodeSens(&sEtiquette, &sEtiq) ;
        sCheminBBFilsItem += string(1, cheminSeparationMARK) + sEtiq ;

        // on enleve le chemin jusqu'� "0CALC1"
        size_t pos = sCheminBBFilsItem.find("/0CALC/") ;        if (pos == string::npos)          continue ;

        sCheminBBFilsItem = string(sCheminBBFilsItem, pos + 7, strlen(sCheminBBFilsItem.c_str()) - pos - 7) ;
        if (sCheminBBFilsItem == "")
          continue ;

        // on a ici un chemin non vide = une question � poser au blackboard
        NSPatPathoArray * pPatPathoLocal = NULL ;

        string sAnswerDate ;
        AnswerStatus::ANSWERSTATUS res = pSuper->getBBinterface()->getAnswer2Question(sCheminBBFilsItem, sArchetype, &pPatPathoLocal, sAnswerDate, false, true  bUserIsWaiting , HWindow) ;

        if ((res == AnswerStatus::astatusProcessed) && (pPatPathoLocal != NULL) && (!(pPatPathoLocal->empty())))
          initControlFromBbkAnswer(*i, pPatPathoLocal, &sAnswerDate) ;
        else if (res == AnswerStatus::astatusProcessing)
          bBlackboardStillAtWork = true ;

        if (pPatPathoLocal)
          delete pPatPathoLocal ;
      }
      pSuper->getApplication()->PumpWaitingMessages() ;
    }
	}
*/

  SetCursor(0, IDC_ARROW) ;

  sErrMsg = pSuper->getText("bbkKsManagement", "resultsDisplayed") ;
	pSuper->afficheStatusMessage((char*) sErrMsg.c_str()) ;

/*
	// On stoppe le KS apr�s qu'il a effectu� les calculs
  if (sKsName != "")
  	pSuper->getBBinterface()->driveKSfromDialog(sKsName, BB1BBInterface::ksHold) ;
*/

	// on lance ici le r�f�rentiel
	// le parseur appartient toujours au BBItem lanceur (cf NSBBSmall::lanceBbkArchetype)
	// string sNomRef = pBBItem->pParseur->pArchetype->getDialog()->getStringAttribute(ATTRIBUT_DIALOGUE_REF);
	// if (sNomRef != "")
	//     pSuper->BbkShowReferential(sNomRef, pContexte);
}
catch (...)
{
	erreur("Exception NSDialog::CmBbkCalcul().", standardError, 0) ;
}
}

string
NSDialog::getPathForBbkQuestion(iterNSControle iterCtrl)
{
	if ((NULL == iterCtrl) || (NULL == *iterCtrl) || (NULL == (*iterCtrl)->getTransfert()))
		return string("") ;

	// NSSuper* pSuper = pContexte->getSuperviseur() ;

	// on r�cup�re le chemin du BBItem pere du BBFilsItem associ�
	// au NSControle via son pTransfert  //  BBFilsItem* pFilsItem = (*iterCtrl)->getTransfert()->pBBFilsItem ;  if ((NULL == pFilsItem) || (NULL == pFilsItem->getItemFather()))  	return string("") ;/*	string sCheminBBFilsItem = pFilsItem-><getItemFather()->sLocalisation ;	// on rajoute l'�tiquette du fils  string sEtiq ;  string sEtiquette = pFilsItem->getItemLabel() ;	pSuper->getDico()->donneCodeSens(&sEtiquette, &sEtiq) ;
	sCheminBBFilsItem += string(1, cheminSeparationMARK) + sEtiq ;
*/

  string sCheminBBFilsItem = pFilsItem->getLocalisation() ;

	// on enleve le chemin jusqu'� "0CALC1"
	size_t pos = sCheminBBFilsItem.find("/0CALC/") ;	if (pos == string::npos)  	return sCheminBBFilsItem ;

	sCheminBBFilsItem = string(sCheminBBFilsItem, pos + 7, strlen(sCheminBBFilsItem.c_str()) - pos - 7) ;

  return sCheminBBFilsItem ;
}

void
NSDialog::waitForKS()
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	NVLdVTemps tpsBBKStart ;
	tpsBBKStart.takeTime() ;

	int iMaxTimeBeforeStop = 90 ;

	while (bBlackboardStillAtWork)
	{
		pSuper->getApplication()->PumpWaitingMessages() ;

		NVLdVTemps tpsNow ;
    tpsNow.takeTime() ;
    NVLdVTemps tpsCompare(tpsBBKStart) ;
    tpsCompare.ajouteSecondes(iMaxTimeBeforeStop) ;
    if (tpsCompare < tpsNow)
    {
    	string sWarningMessage = pSuper->getText("bbkKsManagement", "thisKsSeemsHanged") ;
      string sMsg = pSuper->getText("bbkKsManagement", "doYouWantToResetIt") ;
      sWarningMessage += string(1, '\n') + sMsg ;
      int rep = MessageBox(sWarningMessage.c_str(), "", MB_YESNO) ;
      if (rep == IDYES)
      	bBlackboardStillAtWork = false ;
      else
      	tpsBBKStart.takeTime() ;
    }
  }
}

void
NSDialog::CmBbkEvent()
{
	bBlackboardStillAtWork = false ;
}

void
NSDialog::insertLeavesOnBlackBoard(string sCheminPere, NSPatPathoArray* pPatPathoArray)
{
	if (!pPatPathoArray || pPatPathoArray->empty())
		return ;

  pContexte->getSuperviseur()->getBBinterface()->insertLeavesOnBlackBoard(sCheminPere, pPatPathoArray) ;

/*
	NSSuper *pSuper = pContexte->getSuperviseur() ;

  PatPathoIter iterSuiv ;

	for (PatPathoIter i = pPatPathoArray->begin(); i != pPatPathoArray->end(); i++)
  {
  	iterSuiv = i ;
    iterSuiv++ ;

    if ((iterSuiv == pPatPathoArray->end()) || ((*iterSuiv)->getColonne() <= (*i)->getColonne()))
    {
    	// on est s�r ici que iterElement est une feuille
      NSPatPathoArray* pPatPatho = new NSPatPathoArray(pContexte, graphPerson) ;
      pPatPatho->ajoutePatho(i, 0, 0) ;
      string sCheminLex = pPatPathoArray->donneCheminItem(i) ;
      if ((*i)->getUnit() != "")
      	sCheminLex += string(1, cheminSeparationMARK) + (*i)->getUnit() ;
      sCheminLex += string(1, cheminSeparationMARK) + (*i)->getLexique() ;
      string sCheminFils = "" ;
      string sElemLex, sCodeSens ;
      // on enl�ve d'abord la racine
      size_t pos = sCheminLex.find(string(1, cheminSeparationMARK)) ;
      if (pos != string::npos)
      	sCheminLex = string(sCheminLex, pos+1, strlen(sCheminLex.c_str())-pos-1) ;
      else
      	sCheminLex = "" ;

      while (sCheminLex != "")
      {
      	pos = sCheminLex.find(string(1, cheminSeparationMARK)) ;
        if (pos != string::npos)
        {
        	sElemLex = string(sCheminLex, 0, pos) ;
          pSuper->getDico()->donneCodeSens(&sElemLex, &sCodeSens) ;
          sCheminFils += string(1, cheminSeparationMARK) + sCodeSens ;
          sCheminLex = string(sCheminLex, pos+1, strlen(sCheminLex.c_str())-pos-1) ;
        }
        else
        {
        	sElemLex = sCheminLex ;
          pSuper->getDico()->donneCodeSens(&sElemLex, &sCodeSens) ;
          sCheminFils += string(1, cheminSeparationMARK) + sCodeSens ;
          sCheminLex = "" ;
        }
      }

      if (sCheminFils != "")
      	sCheminFils = sCheminPere + sCheminFils ;
      else
      	sCheminFils = sCheminPere ;

      sCheminFils = getRegularPath(sCheminFils, cheminSeparationMARK, intranodeSeparationMARK) ;

			pSuper->getBBinterface()->insertAnswerOnBlackboard(sCheminFils, pPatPatho, Undefined) ;
		}
	}
*/
}
//-------------------------------------------------------------------------
//  Function: 		void NSDialog::CmOkMessage(int iMessage)
//
//  Arguments:		AUCUN
//  Description:	Equivalent � OK, mais avec orientation de sortie.
//  Returns:		RIEN
//---------------------------------------------------------------------------
void NSDialog::CmOkMessage(int iMessage)
{
	executePreClosingFunctions() ;

	pBBItem->donneRetourDlg(iMessage) ;
	if (!pBBItem->okFermerDialogue(true))
		return ;

	//
	// S'il s'agit de NSTreeWindow tuer pEDitDico
	//
  closeEditDico() ;

  //
  // Eventuel lancement de fonction
  //
  executeClosingFunctions() ;

	if (CanClose())
  {
    /*
    if (pView)
    {
        NSSuper* pSuper = pBBItem->pBigBoss->pContexte->getSuperviseur();
        NSToDoTask* pTask = new NSToDoTask ;
        pTask->sWhatToDo = "FermeDPIO" ;
        pTask->pPointer1 = (void*)pView ;

        pSuper->aToDo.push_back(pTask) ;

        pSuper->pNSApplication->GetMainWindow()->PostMessage(WM_COMMAND, IDM_TODO) ;
    }
    */
		CloseWindow(IDOK) ;	}
}
void
NSDialog::CloseWindow(int retVal)
{
/*
	if (NULL != pBBItem)
	{
  	NSSuper* pSuper = pBBItem->pBigBoss->pContexte->getSuperviseur() ;

		// On lib�re le KS afin qu'il puisse effectuer les calculs
  	string sKsName = pBBItem->KsInterface.getKsName() ;
  	if (sKsName != "")
  		pSuper->getBBinterface()->driveKSfromDialog(sKsName, true) ;
	}
*/
	TDialog::CloseWindow(retVal) ;
}

void
NSDialog::closeEditDico()
{
	//
	// S'il s'agit de NSTreeWindow tuer pEDitDico
	//
	if (!pNSCtrl || pNSCtrl->empty())
		return ;

	for (iterNSControle i = pNSCtrl->begin(); i != pNSCtrl->end(); i++)
	{
		if ((*i)->getType() == isTreeWindow)
		{
    	NSTreeWindow* pNSTreeWindow = static_cast<NSTreeWindow*>((*i)->getControle()) ;
      if (pNSTreeWindow->pEditDico)
      {
      	delete pNSTreeWindow->pEditDico ;
        pNSTreeWindow->pEditDico = 0 ;
      }
    }
  }
}

void
NSDialog::executeClosingFunctions()
{
	if ((NULL == pNSCtrl) || (true == pNSCtrl->empty()))
		return ;

	for (iterNSControle i = pNSCtrl->begin() ; pNSCtrl->end() != i ; i++)
		if ((*i)->getFonction())
    	(*i)->getFonction()->execute(NSDLGFCT_FERMETURE) ;
}

void
NSDialog::executePreClosingFunctions()
{
	if ((NULL == pNSCtrl) || (true == pNSCtrl->empty()))
		return ;

	for (iterNSControle i = pNSCtrl->begin() ; pNSCtrl->end() != i ; i++)
		if ((*i)->getFonction())
    	(*i)->getFonction()->execute(NSDLGFCT_PREFERME) ;
}

//------------------------------------------------------------------------// Cette fen�tre doit fermer ses fen�tres filles et petites filles
// si elles sont ouvertes avant de se refermer elle m�me
//------------------------------------------------------------------------
void
NSDialog::CmOkFermer()
{
	if (false == pBBItem->aBBItemFils.empty())
  {
  	for (BBiter i = pBBItem->aBBItemFils.begin() ;
                               i != pBBItem->aBBItemFils.end() ; i++)
    {    	if (false == (*i)->VectorFils.empty())
      {
      	for (BBiterFils j = (*i)->VectorFils.begin() ; j != (*i)->VectorFils.end() ; j++)
        	if ((*j)->getDialog())
          	(*j)->getDialog()->CmOkFermer() ;
      }
    }
  }
  CmOk() ;
}

//------------------------------------------------------------------------//cette fen�tre doit fermer ses fen�tres filles et petites filles
//si elles sont ouvertes avant de se refermer elle m�me
//------------------------------------------------------------------------
void
NSDialog::CmCancelFermer()
{
	if (false == pBBItem->aBBItemFils.empty())
  {
  	for (BBiter i = pBBItem->aBBItemFils.begin() ;
                               i != pBBItem->aBBItemFils.end() ; i++)
    {
    	if (false == (*i)->VectorFils.empty())
      {
      	for (BBiterFils j = (*i)->VectorFils.begin() ; j != (*i)->VectorFils.end() ; j++)
        	if ((*j)->getDialog())
          	(*j)->CmCancelFermer((*j)->getDialog()) ;
      }
    }
  }
  pBBItem->CmCancelFermer(this) ;
}

//-------------------------------------------------------------------------//  Function: void NSDialog::CmCancel()
//
//  Description: R�pond � IDCancel.
//               Consulte BigBrother.
//---------------------------------------------------------------------------
void
NSDialog::CmCancel()
{
	if (bBlackboardStillAtWork)
		bBlackboardStillAtWork = false ;

	pBBItem->donneRetourDlg(-1) ;
	pBBItem->okFermerDialogue(false) ;
  pBBItem->detacheControle() ;

	//
	// S'il s'agit de NSTreeWindow tuer pEDitDico
	//
  closeEditDico() ;

	//si dialogue non multiple, on ferme cette boite de dialogue, sinon c'est NsMultiDialog
	// qui s'en charge
	if ((!(pBBItem->pBBFilsPere)) || (!(pBBItem->pBBFilsPere->pNsMultiDialog)))
	{
		if (CanClose())
			Destroy(IDCANCEL) ;
	}
	if (pView)
	{
		NSSuper* pSuper = pContexte->getSuperviseur() ;
		NSToDoTask* pTask = new NSToDoTask ;
		pTask->sWhatToDo = "FermeDPIO" ;
		pTask->pPointer1 = (void*)pView ;

		pSuper->addToDo(pTask) ;
	}
}
voidNSDialog::EvSetFocus(THandle hWndLostFocus)
{
	//
  // On remet la fenetre de saisie dans le Lexique au premier plan
  // We bring back the Lexique window on top
  //
  if (pBBItem && pBBItem->pBigBoss)
  {
  	NSSuper* pSuper = pContexte->getSuperviseur() ;
    NSDico*  pDico  = pSuper->getDico() ;
    if (pDico)
    {
    	ChoixPathoDialog* pDicoDlg = pDico->pDicoDialog ;      //      // ATTENTION :  si elle �tait cach�e, le BringWindowToTop entraine      //              un comportement erratique      // WARNING :    if the window was hidden, BringWindowToTop can      //              make the system unstable      //      if (pDicoDlg && (pDicoDlg->EstOuvert()))
      	pDicoDlg->BringWindowToTop() ;
    }
  }
/*    if (pView)    {        NSMUEView* pMueView = TYPESAFE_DOWNCAST(pView, NSMUEView);        if (pMueView)
            pMueView->SetFocus() ;
        else
            pView->SetFocus() ;    }*/   /*   if (bInitFromBbk)        initControlesFromBbk("SetFocus") ;  */	activateParent() ;	TDialog::EvSetFocus(hWndLostFocus) ;}
void
NSDialog::EvWindowPosChanging(WINDOWPOS far& windowPos)
{
	if (!pView)
		return ;

  if (bCanMove)
  	return ;

	if ((windowPos.x != 0) || (windowPos.y != 0) || (windowPos.cx != 0) || (windowPos.cy != 0))
  {
  	NS_CLASSLIB::TRect rectCli = Parent->GetClientRect() ;
    if ((windowPos.x < 0) || (windowPos.y < 0) ||
        (windowPos.x + windowPos.cx > rectCli.Width()) ||
        (windowPos.y + windowPos.cy > rectCli.Height()))
    	windowPos.flags = SWP_NOMOVE ;
  }
}

void
NSDialog::EvTimer(uint id)
{
	if      (id == ID_OB1_TIMER)
		checkPrecocheOnTimer() ;

	else if (id == ID_OB1_TIMER2)
		checkResultOnTimer() ;

	return ;
}

void
NSDialog::checkPrecocheOnTimer()
{
	if (pNSCtrl->empty())
		return ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;

  // L'archetype est par convention dans le champ fils du BBItem lanceur
  string sArchetype = string(pBBItem->pDonnees->fils) ;

  pSuper->afficheStatusMessage("Interrogation du Blackboard...") ;

  bool bSomeAnswerStillMissing = false ;

  for (iterNSControle i = pNSCtrl->begin(); (i != pNSCtrl->end()); i++)  {  	if ((*i)->getTransfert() && ((*i)->isEmpty()) && ((*i)->initOnTimer()))
    {
    	string sCheminBBFilsItem ;
    	(*i)->getPathForBlackboard(&sCheminBBFilsItem) ;

      // on a ici un chemin non vide = une question � poser au blackboard
      NSPatPathoArray* pPatPathoArray = NULL ;

      string date_fils = string("") ;
      string end_date  = string("") ;
      (*i)->getEndValidityDate(&end_date) ;

      // on pose la question au blackboard
			int res = pSuper->getBBinterface()->precoche(sCheminBBFilsItem, sArchetype, &pPatPathoArray, &date_fils, "", end_date) ;
			if ((res == 1) && (NULL != pPatPathoArray) && (!(pPatPathoArray->empty())))
        // il y a une r�ponse du blackboard ==>
        // on transmet la patpatho au BBFilsItem via le pTransfert
        // On met � jour le contr�le
        //
      	initControlFromBbkAnswer(*i, pPatPathoArray, &date_fils) ;
      else
      	bSomeAnswerStillMissing = true ;
    }
  }
  if (!bSomeAnswerStillMissing)
  	KillTimer(ID_OB1_TIMER) ;
}

void
NSDialog::checkResultOnTimer()
{
	
}

//-------------------------------------------------------------------------//  Function: LRESULT NSDialog::EvCorrect(WPARAM wParam, LPARAM lParam)
//
//  Arguments:
//	      wParam ->
//       lParam ->
//  Description:
//	      Le message WM_CORRECT est �mis par les contr�les Edit
//            donc on veut v�rifier la validit� des saisies.
//            La responsabilit� de la d�cision est laiss�e � la fen�tre
//            m�re.
//  Returns:
//
//---------------------------------------------------------------------------
LRESULT NSDialog::EvCorrect(WPARAM /* wParam */, LPARAM /* lParam */)
{
  ::MessageBox(0, "Message WM_CORRECT", "Test", MB_OK);
  return NULL;
}

//-------------------------------------------------------------------------//  Function: void NSDialog::WM_Continue(WPARAM wParam, LPARAM lParam)
//
//  Arguments:
//        wParam ->
//        lParam ->
//  Description:
//	      Le message WM_CONTINUE est �mis par les contr�les ou la
//            bo�te de dialogue elle m�me.
//            Il doit g�n�rer une consultation de BigBrother qui donne la
//            marche � suivre.
//            Analyse le message dans lequel on doit trouver l'identit� de
//            la fen�tre �mettrice, et des informations compl�mentaires
//            si n�cessaire.
//            Consulte BigBrother.
//            Cr�e la fen�tre suivante.
//  Returns:
//
//---------------------------------------------------------------------------
LRESULT NSDialog::EvContinue(WPARAM /* wParam */, LPARAM /* lParam */)
{
	//::MessageBox(0, "Message WM_CONTINUE", "Configuration", MB_OK);
	return NULL;
}

/*voidNSDialog::EvMove(ClassLib::TPoint& clientOrigin)
{
}

voidNSDialog::EvWindowPosChanged(WINDOWPOS far& windowPos)
{

} */
static void count(TWindow* child, void* i)
{
  int* n = (int*)i;
  if (child) (*n)++;
}

int NSDialog::CountChild(){
	int i = 0;
	ForEach((TActionFunc)count, (void*)&i );
	return i;
}

void NSDialog::ConfigShow(){
	char p[255];
  int j;

// Affichage de la matrice d'initialisation// Analyse de la cha�ne propos�e
/*  strcpy(p, "");
  int j = pConfigCache->GetItemsInContainer();
  for(int i = 0; i < pConfigCache->GetItemsInContainer(); i++) {
	 CacheElement elt = (*pConfigCache)[i];
	 ChaineArray * list = elt.listItems;
	 strcat(p, (*list)[0].c_str());
	 strcat(p, "|");
	 strcat(p, (*list)[1].c_str());
	 strcat(p, "\n");
  }
  ::MessageBox(0, p, "Cha�ne de configuration", MB_YESNO); */

// Matrice de transfert
/*  j =  pTransferBuf->GetItemsInContainer();
  itoa(j, p, 10);
  strcat(p, "buffers dans la matrice de transfert");
  ::MessageBox(0, p,"Buffer de transfert", MB_YESNO); */

  // Nombre d'objets OWL
  j = CountChild();
  itoa(j, p, 10);
  strcat(p,"enfants dans la ChildList");
  ::MessageBox(0, p, "Nombre d'enfants dans la ChildList", MB_YESNO);
}

void
NSDialog::GetWindowClass(WNDCLASS& wndClass)
{
    TResId dlgClass;

#ifndef _INCLUS
    #if defined(BI_COMP_BORLANDC)
    if (GetApplication()->BWCCEnabled()) {
        GetApplication()->GetBWCCModule()->Register(*GetModule());
        dlgClass = BORDLGCLASS;
    }
    else
    #endif
        dlgClass = WC_DIALOG;
#else
    #if defined(BI_COMP_BORLANDC)
    if (pContexte->getSuperviseur()->BWCCOn)
    {
    pContexte->getSuperviseur()->GetBWCCModule()->Register(*GetModule());
        dlgClass = BORDLGCLASS;
    }
    else
    #endif
        dlgClass = WC_DIALOG;
#endif

    if (!TUser::GetClassInfo(0, dlgClass, &wndClass))
        GetModule()->GetClassInfo(dlgClass, &wndClass);

    wndClass.lpszClassName = GetClassName();    wndClass.hInstance = *GetModule();   //!CQ Win32 only? (B50.26561)
}

//------------------------------------------------------------------------------//------------------------------------------------------------------------------bool
NSDialog::Create()
{
  if (this->IsWindow())
    return false;
  OWL::TDialog::Create();
  return true;
}
/******************************************************************************/
//
//  Wrappers pour TDialog
//
/******************************************************************************/

#ifdef _INCLUS
//// Registers the TWindow's MS-Windows, if not already registered
//
bool
NSDialog::Register()
{
  // Only check for globally registered classes if not under NT or WoW box,
  // since NT treats a 0 hInstance completely differently than Windows.
  //
#if defined(BI_PLAT_WIN32)
  static bool checkGlobal = !TSystem::IsNT();
#else
  static bool checkGlobal = !TSystem::IsWoW();
#endif

  WNDCLASS  windowClass;
  bool gc;
  if (checkGlobal)
    gc = TUser::GetClassInfo(0, GetClassName(), &windowClass) != 0;
  else
    gc = false;

  // If the wndclass is not yet registered, call GetWindowClass() to let our
  // derived class fill in the appropriate info. If the class is still then not
  // registered, then make it so.
  //
  if (!gc && !GetModule()->GetClassInfo(GetClassName(), &windowClass)) {
    GetWindowClass(windowClass);
    WNDCLASS dummy;
    if (!GetModule()->GetClassInfo(GetClassName(), &dummy))
      return ::RegisterClass(&windowClass);
  }

  return true;
}

char far*NSDialog::GetClassName()
{
#if defined(BI_COMP_BORLANDC)
  if (pContexte->getSuperviseur()->BWCCOn)
    return BORDLGCLASS;
  else
#endif
    return (char far*)WC_DIALOG;
}

static bool
NSDialogRegisterFails(TWindow* win, void*)
{
  return !win->Register();
}

void
NSDialog::RegisterChildObjects()
{
  if (FirstThat(NSDialogRegisterFails))
    TXWindow::Raise(this, IDS_CHILDREGISTERFAIL);
}

extern TDialog* _OWLDATA DlgCreationWindow;

int
NSDialog::Execute()
{
  PRECONDITION(GetHandle() == 0);

  IsModal = true;

  if (!Register())
    TXWindow::Raise(this, IDS_CLASSREGISTERFAIL);

  DlgCreationWindow = this;

  // Register all the dialog's child objects (for custom control support)
  //
  RegisterChildObjects();

  int retValue = DoExecute();
//  GetApplication()->ResumeThrow();

  // DoEcecute returns -1 if it could not create the dialog box
  //
  if (retValue == -1)
    TXWindow::Raise(this, IDS_WINDOWEXECUTEFAIL);

  return retValue;
}
#endif // _INCLUS

/*void NSMainWindow::WMContinue(RTMessage Msg)
{
  pNSSuperviseur->QueFaire();

  switch(pNSSuperviseur->Action()) {

	  case NSW_RIEN_FAIRE  : break;
	  case NSW_MODALE      : //
				 //************************************************
				 GetModule()->ExecDialog(pNSSuperviseur->pDlgEnCours());
				 PostMessage(this->HWindow, WM_CONTINUE, 0L, 0L);
				 break;
	  case NSW_NON_MODALE  : //
				 //************************************************
				 GetModule()->MakeWindow(pNSSuperviseur->pDlgEnCours());
				 PostMessage(this->HWindow, WM_CONTINUE, 0L, 0L);
				 break;
	  case NSW_FERMER      : ShutDownWindow();
						 break;
	  case NSW_TOUT_FERMER : break;
  }
}
*/

//---------------------------------------------------------------------------//  Function: NSBBFonction::NSBBFonction(string	sNomFonct, BBItem* pBBItemPere)
//
//  Arguments:		sNomFonct  	 -> Nom de la fonction
//                pBBItemPere  -> BBItem cr�ateur de la fonction
//
//  Description:	Constructeur initi� par un BBItem
//---------------------------------------------------------------------------
NSBBFonction::NSBBFonction(NSContexte* pCtx, string sNomFonct, BBItem* pBBItemPere)
             :NSRoot(pCtx)
{
	sNomFonction  = sNomFonct ;
	pBBItem 	    = pBBItemPere ;
	pBBPhraseItem = 0 ;

	iNbrCtrl = 0;
	for (int i = 0; i < 100; i++)
		pNSCtrl[i] = 0;
	//
	// Prise de l'adresse de la fonction NSBBFct dans la DLL de ressources
	// Cette fonction doit se trouver en 2�me position de la liste d'Export
	//

  if (!pBBItem)
  	return ;

	pNSResModule = pBBItem->pBigBoss->TrouverModule(pBBItem->pDonnees->fichierDialogue);
	if (pNSResModule)
		(FARPROC) pAdresseFct = pNSResModule->GetProcAddress(MAKEINTRESOURCE(1));
}

//---------------------------------------------------------------------------//  Function: NSBBFonction::NSBBFonction(string	sNomFonct, BBPhraseItem* pBBItemPere)
//
//  Arguments:		sNomFonct  	 -> Nom de la fonction
//                pBBItemPere  -> BBItem cr�ateur de la fonction
//
//  Description:	Constructeur initi� par un BBPhraseItem
//---------------------------------------------------------------------------
NSBBFonction::NSBBFonction(NSContexte* pCtx, string sNomFonct, BBPhraseItem* pBBItemPere)
             :NSRoot(pCtx)
{
	sNomFonction  = sNomFonct ;

	pBBItem 		  = 0 ;
	pBBPhraseItem = pBBItemPere ;

	iNbrCtrl = 0 ;
	for (int i = 0; i < 100; i++)
		pNSCtrl[i] = 0 ;

	//
	// Prise de l'adresse de la fonction NSBBFct dans la DLL de ressources
	// Cette fonction doit se trouver en 2�me position de la liste d'Export
	//
	(FARPROC) pAdresseFct = pNSResModule->GetProcAddress(MAKEINTRESOURCE(1));
}

//---------------------------------------------------------------------------
//  Function:    NSBBFonction::~NSBBFonction()
//
//  Description: Destructeur
//---------------------------------------------------------------------------
NSBBFonction::~NSBBFonction()
{
	for (int i = 0; i < iNbrCtrl; i++)
  	if (pNSCtrl[i])
			delete pNSCtrl[i] ;
}

//---------------------------------------------------------------------------
//  Function: NSBBFonction::referenceTransfert()
//
//  Arguments:		Aucun
//
//  Description:
//---------------------------------------------------------------------------
int
NSBBFonction::referenceTransfert()
{
	return 0 ;
}

//---------------------------------------------------------------------------
//  Function: NSBBFonction::execute(int iParam)
//
//  Arguments:	iParam 	  : param�tre qui pr�cise l'action � effectuer
//									 (r�f�rencement, ex�cution de la fct...)
//					sEtiquette : position BB de l'appelant
//					pNSCtrl	  : pointeur sur un �ventuel contr�le Windows
//
//  Description: 	Ex�cute la fonction
//---------------------------------------------------------------------------
bool
NSBBFonction::execute(int iParam, int* piValeur, string /* sEtiquette */, NSControle* /* pNSCtrl */)
{
	NSSmallBrother* pBigBrother ;

	if (pBBItem)
		pBigBrother = pBBItem->pBigBoss ;
	else
		return false ;

	if (pAdresseFct)
		return ((*pAdresseFct)(this, pBigBrother, iParam, piValeur)) ;

	return false ;
}

//---------------------------------------------------------------------------//  Function: NSBBFonction::nouveauCtrl(char cGroupe, string sIdentite, string sDlgFct)
//
//  Description: 	Cr�e un objet NSControle
//---------------------------------------------------------------------------
int
NSBBFonction::nouveauCtrl(string sIdentite, string sDlgFct)
{
try
{
	if (pBBItem == 0)
		return 1 ;

	pNSCtrl[iNbrCtrl] = new NSControle(pContexte, pBBItem, sIdentite, sDlgFct) ;
	pNSCtrl[iNbrCtrl]->setType(isFunct) ;
	iNbrCtrl++ ;
	return 0 ;
}
catch (...)
{
	erreur("Exception NSBBFonction::nouveauCtrl.", standardError, 0) ;
	return 0 ;
}
}

int farajouteBBFonctionCtrl(NSBBFonction* pBBFct, char sIdentite, string sDlgFct)
{
	return pBBFct->nouveauCtrl(string(1,sIdentite), sDlgFct) ;
}

// --------------------------------------------------------------------------
// ---------------------- M�thodes de NSDialogCtrl --------------------------
// --------------------------------------------------------------------------

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSDialogCtrl::NSDialogCtrl()
{
 //	cGroupe 	 	 = ' ';
	sIdentite 	 = "";
	sControle 	 = "";
	sDlgFonction = "";
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSDialogCtrl::NSDialogCtrl(NSDialogCtrl& rv)
{
	//cGroupe 	 	 = rv.cGroupe;
	sIdentite 	 = rv.sIdentite;
	sControle 	 = rv.sControle;
	sDlgFonction = rv.sDlgFonction;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSDialogCtrl::~NSDialogCtrl()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSDialogCtrl&
NSDialogCtrl::operator=(NSDialogCtrl src)
{
	if (this == &src)
		return *this ;

	//cGroupe 	 	 = src.cGroupe;
	sIdentite 	 = src.sIdentite ;
	sControle 	 = src.sControle ;
	sDlgFonction = src.sDlgFonction ;
  
	return *this ;
}

//---------------------------------------------------------------------------
//  Op�rateur ==
//---------------------------------------------------------------------------
int
NSDialogCtrl::operator == (const NSDialogCtrl& o)
{
	if (/*(cGroupe   == o.cGroupe) &&*/
		 (sIdentite == o.sIdentite))
		return 1;
	 return 0;
}

// --------------------------------------------------------------------------
// ---------------------- M�thodes de NSDialogVector --------------------------
// --------------------------------------------------------------------------

//---------------------------------------------------------------------------
//  Description :	Constructeur copie
//  Retour :		Rien
//---------------------------------------------------------------------------
NSDialogVector::NSDialogVector(NSDialogVector& rv)
               :NSDialogCtrlVector()
{
try
{
	if (!(rv.empty()))
		for (iterNSDialogCtrlVector i = rv.begin(); i != rv.end(); i++)
			push_back(new NSDialogCtrl(**i)) ;
}
catch (...)
{
	erreur("Exception NSDialogVector copy ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Description:	Destructeur
//---------------------------------------------------------------------------
void
NSDialogVector::vider()
{
	if (empty())
		return ;

	for (iterNSDialogCtrlVector i = begin(); i != end(); )
	{
		delete *i ;
    erase(i) ;
	}
}

NSDialogVector::~NSDialogVector()
{
	vider() ;
}

//---------------------------------------------------------------------------
//
//  Description : Op�rateur d'affectation
//---------------------------------------------------------------------------
NSDialogVector&
NSDialogVector::operator=(NSDialogVector src)
{
	if (this == &src)
		return *this ;

try
{
	vider() ;

	if (!(src.empty()))
		for (iterNSDialogCtrlVector i = src.begin(); i != src.end(); i++)
			push_back(new NSDialogCtrl(**i)) ;

	return *this ;
}
catch (...)
{
	erreur("Exception NSDialogVector (=).", standardError, 0) ;
	return *this ;
}
}

// --------------------------------------------------------------------------// ---------------------- M�thodes de NSDialogEdit --------------------------
// --------------------------------------------------------------------------

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSDialogEdit::NSDialogEdit()
{
	szType[0] = '\0' ;
	nMaxInput = 0 ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSDialogEdit::NSDialogEdit(NSDialogEdit& rv)
{
	strcpy(szType, rv.szType) ;
	nMaxInput = rv.nMaxInput ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSDialogEdit::~NSDialogEdit()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSDialogEdit&
NSDialogEdit::operator=(NSDialogEdit src)
{
	if (this == &src)
		return *this ;

	strcpy(szType, src.szType) ;
	nMaxInput = src.nMaxInput ;
  
	return *this ;
}

//---------------------------------------------------------------------------
//  Op�rateur ==
//---------------------------------------------------------------------------
int
NSDialogEdit::operator == (const NSDialogEdit& o)
{
	if ((strcmp(szType, o.szType) == 0) && (nMaxInput == o.nMaxInput))
		return 1 ;

	return 0 ;}

// --------------------------------------------------------------------------
// --------------------- M�thodes de NSDialogOnglet -------------------------
// --------------------------------------------------------------------------

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSDialogOnglet::NSDialogOnglet()
{
	nNbOnglets 	 = 0;
	sOngletActif = "";
	for (int i = 0; i < 20; i++)
		pTexteOnglets[i] = 0 ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSDialogOnglet::NSDialogOnglet(NSDialogOnglet& rv)
{
try
{
	nNbOnglets 	 = rv.nNbOnglets ;
	sOngletActif = rv.sOngletActif ;
 	for (int i = 0; i < nNbOnglets; i++)
  	pTexteOnglets[i] = new string(*(rv.pTexteOnglets[i])) ;
}
catch (...)
{
	erreur("Exception NSDialogOnglet copy ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSDialogOnglet::~NSDialogOnglet()
{
	for (int i = 0; i < nNbOnglets; i++)
  	if (NULL != pTexteOnglets[i])
			delete pTexteOnglets[i] ;
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSDialogOnglet&
NSDialogOnglet::operator=(NSDialogOnglet src)
{
	if (this == &src)
		return *this ;

try
{
	for (int i = 0; i < nNbOnglets; i++)
  {
  	delete pTexteOnglets[i] ;
    pTexteOnglets[i] = NULL ;
  }

	nNbOnglets 	 = src.nNbOnglets ;
	sOngletActif = src.sOngletActif ;

 	for (int i = 0; i < nNbOnglets; i++)
  	pTexteOnglets[i] = new string(*(src.pTexteOnglets[i])) ;

	return *this ;
}
catch (...)
{
	erreur("Exception NSDialogOnglet (=).", standardError, 0) ;
	return *this ;
}
}

//---------------------------------------------------------------------------//  Op�rateur ==
//---------------------------------------------------------------------------
int
NSDialogOnglet::operator == (const NSDialogOnglet& o)
{
	if ((nNbOnglets != o.nNbOnglets) || strcmp(sOngletActif.c_str(),o.sOngletActif.c_str())   )
  	return 0 ;

	for (int i = 0; i < nNbOnglets; i++)
  	if (strcmp((pTexteOnglets[i]->c_str()), (o.pTexteOnglets[i]->c_str())))
    	return 0 ;

	return 1 ;
}

