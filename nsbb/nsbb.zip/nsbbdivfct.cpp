// -----------------------------------------------------------------------------// nsbbdivfct.cpp
// -----------------------------------------------------------------------------
// Fen�tre de liste des Equipes
// -----------------------------------------------------------------------------
// $Revision: 1.46 $
// $Author: remi $
// $Date: 2005/06/13 17:04:33 $
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Copyright Nautilus, 2004
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � g�rer et traiter les
// informations de sant� d'une personne.
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to manage and process
// a person's health data.
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------
#include <stdio.h>
#include "partage\nsglobal.h"

#include "nsbb\nsbbitem.h"#include "nsbb\nsbbsmal.h"#include "nsbb\nsbbtran.h"#include "nsbb\nsdlg.h"#include "nsbb\nsradiob.h"
#include "nsbb\nstrewi.h"
#include "nsbb\nsbouton.h"
#include "nsbb\nstrnode.h"
#include "nsbb\nsedit.h"
#include "nsbb\nschkbox.h"
#include "partage\nsdivfct.h"
#include "nsbb\nsbbdivfct.h"
#include "nsbb\nsbb_msg.h" //NSDLGRETOUR_DIRECT ..
#include "partage\nsmatfic.h"
#include "nsepisod\nsldvuti.h"
#include "nsbb\nsattval.h"
#include "nsbb\nsarc.h"
#include "nsbb\nsmanager.h"
#include "nautilus\nsepicap.h"
#include "nsbb\nsmpidsobj.h"
#include "nssavoir\nsconver.h"
#include "nsbb\nsdefArch.h"
#include "nautilus\nssoapview.h"
#include "nautilus\nsdochis.h"
#include "nautilus\nscsvue.h"
#include "nautilus\nshistdo.h"

# include "nsbb\nslistwind.h"
# include "pilot\NautilusPilot.hpp"
# include "nsbb\tagNames.h"

# include "ns_ob1\BB1types.h"

#define DECALAGE_INDEX_ID 200  // D�calage entre un contr�le et son static d'index

struct ltstring
{
  bool operator()(const string s1, const string s2) const
  {
    return s1 < s2 ;
  }
};


//***************************************************************************
//                      Fonctions utilitaires
//***************************************************************************

void
ActiveChampEdit(BBFilsItem* fils, string sVal)
{
    fils->ActiveControle(sVal);
}

BBFilsItem*
RetournerValeurEdit(BBItem* pItem, string sEtiquette, string* pValeurEdit)
{
	if (pItem->aBBItemFils.empty())
	{
		*pValeurEdit = string("") ;
		return(0) ;
	}

  bool bTexteLibre = false ;
  if (sEtiquette.find(string("�CL")) != NPOS)
  	bTexteLibre = true ;

	string resultat ;
	BBiter  iterFils1 = pItem->aBBItemFils.begin() ;
	BBFilsItem* fils ;
	while (iterFils1 != pItem->aBBItemFils.end())
	{
		if ((*iterFils1)->getItemTransfertData()->pControle)
		{
			if ((*iterFils1)->getItemTransfertData()->pControle->getIdentite().find(sEtiquette) != NPOS)
			{
				fils = (*iterFils1) ;
        if (bTexteLibre)
        	*pValeurEdit = (*iterFils1)->getItemTransfertMsg()->GetTexteLibre() ;
        else
					*pValeurEdit = (*iterFils1)->getItemTransfertMsg()->GetComplement() ;
				return(*iterFils1) ;
			}
		}
		if (!((*iterFils1)->VectorFils.empty()))
		{			BBiterFils petitFils1  = (*iterFils1)->VectorFils.begin();
			for (; petitFils1  != (*iterFils1)->VectorFils.end(); petitFils1++)
			{
				BBiter  iterChampEdit1 = (*petitFils1)->aBBItemFils.begin();

				while (iterChampEdit1 != (*petitFils1)->aBBItemFils.end())				{					if ((*iterChampEdit1)->getItemTransfertData()->pControle)
					{
						if ((*iterChampEdit1)->getItemTransfertData()->pControle->getIdentite().find(sEtiquette) != NPOS)
						{
							fils = (*iterChampEdit1) ;
              if (bTexteLibre)
        				*pValeurEdit = (*iterChampEdit1)->getItemTransfertMsg()->GetTexteLibre() ;
              else
								*pValeurEdit = (*iterChampEdit1)->getItemTransfertMsg()->GetComplement() ;
							return (*iterChampEdit1) ;
						}
					}
					if (!((*iterChampEdit1)->VectorFils.empty()))
					{
						BBiterFils iter = (*iterChampEdit1)->VectorFils.begin() ;
						fils = RetournerValeurEdit(*iter, sEtiquette, pValeurEdit) ;
						if (fils)
							return (fils) ;
					}

					iterChampEdit1++ ;
				}
			}
		}
		iterFils1++ ;
	}
	*pValeurEdit = string("") ;
	return(0) ;
}

BBFilsItem*
RetournerValeurEdit(BBItem* pItem, string sEtiquette, string* pValeurEdit, bool bFromRoot)
{
  if (NULL == pItem)
    return 0 ;

	// Si on doit repartir de la racine
	//
	if (bFromRoot)
	{
		BBFilsItem* pVRFilsItem;
		BBItem*     pVRItem = pItem;
		bool        tourner = true;
		while (tourner)
		{
			pVRFilsItem = pVRItem->pBBFilsPere;
			if (NULL == pVRFilsItem)
				tourner = false;
			else
				pVRItem = pVRFilsItem->getItemFather() ;
		}
		return
			RetournerValeurEdit(pVRItem, sEtiquette, pValeurEdit, false);
	}

	if (pItem->aBBItemFils.empty())	{
		*pValeurEdit = string("");
		return(0) ;
	}
	// Recherche effective
	//
	string resultat;
	BBiter  iterFils1 = pItem->aBBItemFils.begin();
	//
	// On passe en revue les fils
	//
	BBFilsItem* fils;
	while (iterFils1 != pItem->aBBItemFils.end())
	{
		// On regarde si le fils est bien celui qu'on cherche
		//
		if ((*iterFils1)->getItemTransfertData()->pControle)
		{
			if ((*iterFils1)->getItemTransfertData()->pControle->getIdentite().find(sEtiquette) != NPOS)
			{
				fils = (*iterFils1);
				*pValeurEdit = (*iterFils1)->getItemTransfertMsg()->GetComplement() ;
				return(*iterFils1) ;
			}
		}
		// Sinon, on lance it�rativement sur les BBItem d�riv�s
		//
		if (!((*iterFils1)->VectorFils.empty()))
		{
			BBiterFils petitFils1  = (*iterFils1)->VectorFils.begin() ;
			for (; petitFils1  != (*iterFils1)->VectorFils.end(); petitFils1++)
			{
				BBiter  iterChampEdit1 = (*petitFils1)->aBBItemFils.begin() ;

				while (iterChampEdit1 != (*petitFils1)->aBBItemFils.end())
				{
					if ((*iterChampEdit1)->getItemTransfertData()->pControle)
					{
						if ((*iterChampEdit1)->getItemTransfertData()->pControle->getIdentite().find(sEtiquette) != NPOS)
						{
							fils = (*iterChampEdit1) ;
							*pValeurEdit = (*iterChampEdit1)->getItemTransfertMsg()->GetComplement() ;
							return (*iterChampEdit1) ;
						}
					}
					if (!((*iterChampEdit1)->VectorFils.empty()))
					{
						BBiterFils iter  = (*iterChampEdit1)->VectorFils.begin() ;
						fils =  RetournerValeurEdit(*iter, sEtiquette, pValeurEdit, false) ;
						if (fils)
							return (fils) ;
					}

					iterChampEdit1++;
				}
			}
		}
		iterFils1++;
	}
	*pValeurEdit = string("");
	return(0) ;
}

void
RetournerDateMax(BBItem* pItem, string* pDateMax)
{
  if ((NULL == pItem) || (NULL == pDateMax))
    return ;

  string sValDate = "";
  string sRefValeur = "" ;
  string sValSens = "" ;

  if (pItem->aBBItemFils.empty())
	{
		*pDateMax = string("");
		return ;
	}

  NSSuper* pSuper = pItem->pBigBoss->pContexte->getSuperviseur() ;

  for (BBiter iterFils = pItem->aBBItemFils.begin(); iterFils != pItem->aBBItemFils.end(); iterFils++)
  {
    sRefValeur = (*iterFils)->getItemLabel() ;
    pSuper->getDico()->donneCodeSens(&sRefValeur, &sValSens) ;

    if (sValSens == "KDARE")
    {
      if (!((*iterFils)->VectorFils.empty()))
      {
        BBiterFils BBFils  = (*iterFils)->VectorFils.begin() ;
        if (!(*BBFils)->aBBItemFils.empty())
        {
          BBiter iterPetitFils = (*BBFils)->aBBItemFils.begin() ;
          if (((*iterPetitFils)->getItemLabel()).find("�T") != NPOS)
          {
            sValDate = (*iterPetitFils)->getItemTransfertMsg()->GetComplement() ;
            if (sValDate > (*pDateMax))
              *pDateMax = sValDate ;
          }
        }
      }
    }
    else
    {
      for (BBiterFils BBFils = (*iterFils)->VectorFils.begin(); BBFils != (*iterFils)->VectorFils.end(); BBFils++)
        RetournerDateMax(*BBFils, pDateMax) ;
    }
  }
}

//
// Recherche dans pDialog d'un contr�le situ� apr�s pNSFct, mais avant tout
// autre contr�le ayant une fonction identique � pNSFct, et de fonction sFctName
//
// Looking in pDialog for a control located after pNSFct's control, but before
// any other control with the same function as pNSFct, whose function is sFctName
//
NSControle*
RechercheFctApres(NSControleVector* pNSCtrl, NSDlgFonction *pNSFct, string sFctName)
{
  if ((NULL == pNSFct) || (NULL == pNSCtrl) || (pNSCtrl->empty()))
    return 0 ;

  string      sThisFct   = pNSFct->sNomFonction ;
  NSControle* pThisCtrl  = pNSFct->pControle ;

  bool        bFoundThis = false ;

  iterNSControle itCtrl ;
  for (itCtrl = pNSCtrl->begin() ; pNSCtrl->end() != itCtrl ; itCtrl++)
  {
    if (NULL != (*itCtrl)->getFonction())
    {
      // Au del� du contr�le actuel / Beyond current control
      if (bFoundThis)
      {
        if ((*itCtrl)->getFonction()->containFonction(sFctName))
          break ;
        if ((*itCtrl)->getFonction()->sNomFonction == sThisFct)
          return NULL ;
      }
      else
      {
        if (*itCtrl == pThisCtrl)
          bFoundThis = true ;
      }
    }
  }
  if (itCtrl == pNSCtrl->end())
    return 0 ;

  return *itCtrl ;
}

//
// Recherche dans pDialog d'un contr�le situ� avant pNSFct, mais apr�s tout
// autre contr�le ayant une fonction identique � pNSFct, et de fonction sFctName
//
// Looking in pDialog for a control located before pNSFct's control, but after
// any other control with the same function as pNSFct, whose function is sFctName
//
NSControle*
RechercheFctAvant(NSControleVector* pNSCtrl, NSDlgFonction *pNSFct, string sFctName)
{
  if ((NULL == pNSFct) || (NULL == pNSCtrl) || (pNSCtrl->empty()))
    return 0 ;

  string      sThisFct   = pNSFct->sNomFonction ;
  NSControle* pThisCtrl  = pNSFct->pControle ;
  NSControle* pCandidate = 0 ;

  iterNSControle itCtrl ;
  for (itCtrl = pNSCtrl->begin() ; pNSCtrl->end() != itCtrl ; itCtrl++)
  {
    if ((*itCtrl)->getFonction())
    {
      if (*itCtrl == pThisCtrl)
        return pCandidate ;

      if ((*itCtrl)->getFonction()->containFonction(sFctName))
        pCandidate = *itCtrl ;
      if ((*itCtrl)->getFonction()->sNomFonction == sThisFct)
        pCandidate  = 0 ;
    }
  }
  return 0 ;
}

//----------------------------------------------------------------------------
// retourner le BBFilsItem ayant sEtiquette comme �tiquette.
//----------------------------------------------------------------------------
BBFilsItem*
TrouverFilsAyantBonneEtiquette(BBItem* pere, string sEtiquette)
{
	if ((NULL == pere) || (pere->aBBItemFils.empty()))
  	return 0 ;

  string sEtiq ;
  NSSuper* pSuper = pere->pContexte->getSuperviseur() ;

  pSuper->getDico()->donneCodeSens(&sEtiquette, &sEtiq) ;

	BBiter Iter ;
	for (Iter = pere->aBBItemFils.begin(); Iter != pere->aBBItemFils.end() ; Iter++)
  {
    string sEtiqIter ;
    string sFilsLabel = (*Iter)->getItemLabel() ;
    pSuper->getDico()->donneCodeSens(&sFilsLabel, &sEtiqIter) ;

		//�galit� stricte
		if (sEtiqIter == sEtiq)
			return (*Iter) ;
  }

	return 0 ;
}

string
FindValueInPathFromRootChapter(BBItem* pRootItem, string sPath, string sValueString)
{
	if ((NULL == pRootItem) || (string("") == sPath) || (string("") == sValueString))
		return string("") ;

  ClasseStringVector PathVect ;
	DecomposeChaine(&sPath, &PathVect, string(1, cheminSeparationMARK)) ;
  if (PathVect.empty())
  	return string("") ;

  BBFilsItem* pFilsItem    = 0 ;
  BBItem*     pCurrentItem = pRootItem ;

  size_t     iLevel    = 1 ;
  iterString iterpVect = PathVect.begin() ;
  for ( ; PathVect.end() != iterpVect ; iterpVect++, iLevel++)
  {
	  // Find the FilsItem that commands the level
    //
	  pFilsItem = TrouverFilsAyantBonneEtiquette(pCurrentItem, (*iterpVect)->sItem) ;
    if (NULL == pFilsItem)
		  return string("") ;

    // If this element is not the last one
    //
    if (PathVect.size() > iLevel)
    {
      // Let's suppose this Item has a single son
      //
      if (pFilsItem->VectorFils.size() == 1)
        pCurrentItem = *(pFilsItem->VectorFils.begin()) ;
      else
        return string("") ;
    }
  }

  // Get its information storage structure
  //
	if ((NULL == pFilsItem->getItemTransfertData()) || (NULL == pFilsItem->getItemTransfertData()->pTransPatpatho))
		return string("") ;  NSVectFatheredPatPathoArray *pFatheredPptArray = pFilsItem->getItemTransfertData()->pTransPatpatho ;	if (pFatheredPptArray->empty())
		return string("") ;

  // Get needed value inside the storage structure
  //
	string sValue ;
	NSPatPathoArray* pPPT = (*(pFatheredPptArray->begin()))->getPatPatho() ;
	if (false == pPPT->CheminDansPatpatho(pRootItem->pBigBoss, sValueString, &sValue))
		return string("") ;

	return sValue ;
}

string
FindValueInRootChapter(BBItem* pRootItem, string sChapter, string sValueString)
{
	if ((NULL == pRootItem) || (string("") == sValueString))
		return string("") ;

	// Find the FilsItem that commands the chapter
  //
	BBFilsItem* pVRFilsItem = pRootItem->TrouverFilsAyantBonneEtiquette(sChapter, string("")) ;
	if (NULL == pVRFilsItem)
		return string("") ;

  // Get its information storage structure
  //
	if ((NULL == pVRFilsItem->getItemTransfertData()) || (NULL == pVRFilsItem->getItemTransfertData()->pTransPatpatho))
		return string("") ;  NSVectFatheredPatPathoArray *pFatheredPptArray = pVRFilsItem->getItemTransfertData()->pTransPatpatho ;	if (pFatheredPptArray->empty())
		return string("") ;

  // Get needed value inside the storage structure
  //
	string sValue ;
	NSPatPathoArray* pPPT = (*(pFatheredPptArray->begin()))->getPatPatho() ;
	if (false == pPPT->CheminDansPatpatho(pRootItem->pBigBoss, sValueString, &sValue))
		return string("") ;

	return sValue ;
}

/***************************************************************/      						// Donn�es administratives
/***************************************************************/

//-------------------------------------------------------------------
// Afficher la date du jour
//-------------------------------------------------------------------
void
FixerDateDuJour(NSDlgFonction *pNSFct)
{
	if (!pNSFct || !pNSFct->pControle)
		return ;

	int iCtrlType = pNSFct->pControle->getType() ;
  if ((iCtrlType != isEditDate) && (iCtrlType != isEditDateHeure))
		return ;

	if (!pNSFct->pControle->getTransfert() || !pNSFct->pControle->getTransfert()->pTransfertMessage)
		return ;

	string sDate = pNSFct->pControle->getTransfert()->pTransfertMessage->GetComplement() ;
	if (sDate == "")
	{
  	NVLdVTemps tpsNow ;
    tpsNow.takeTime() ;
    if      (iCtrlType == isEditDate)
    	sDate = tpsNow.donneDate() ;
    else if (iCtrlType == isEditDateHeure)
			sDate = tpsNow.donneDateHeure() ;
	}
	ActiveChampEdit(pNSFct->pControle->getTransfert()->pBBFilsItem, sDate) ;
}

//-------------------------------------------------------------------
// Synchronisation d'unit�s entre deux edits fr�res
// Values synchronization for 2 brother edits with different units
//-------------------------------------------------------------------
void
SynchroNumValues(NSDlgFonction *pNSFct)
{
try
{
	if (!pNSFct || !(pNSFct->pControle) || !(pNSFct->pControle->getTransfert()))
		return ;

	NSTransferInfo*	pTrans = pNSFct->pControle->getTransfert() ;
	if (!pTrans->pBBFilsItem)
  	return ;

  BBFilsItem* pFilsCurrent = pTrans->pBBFilsItem ;

	//
	// Est-ce une �tiquette multiple ?
	//
	size_t posit = (pFilsCurrent->getItemLabel()).find(string(1, cheminSeparationMARK));
  if (posit == NPOS)
  	return ;
	string sUnit = string(pFilsCurrent->getItemLabel(), 0, posit) ;
	size_t posit_debut = posit + 1 ;
	string sLexique = string(pFilsCurrent->getItemLabel(), posit_debut, strlen(pFilsCurrent->getItemLabel().c_str()) - posit_debut) ;

  string sValue   = pTrans->pTransfertMessage->GetComplement() ;

	BBItem*	pItemPere = pFilsCurrent->getItemFather() ;
  if (!pItemPere)
		return ;

  string sRefValeur = string("") ;
  if (pItemPere->pBBFilsPere)
  	sRefValeur = pItemPere->pBBFilsPere->getItemLabel() ;

	if (pItemPere->aBBItemFils.empty())
		return ;

	NSCV* pNSCV = NULL ;

  BBiter  iter = pItemPere->aBBItemFils.begin() ;
  for ( ; iter != pItemPere->aBBItemFils.end() ; iter++)
	{
		if (*iter != pFilsCurrent)
		{
    	posit = ((*iter)->getItemLabel()).find(string(1, cheminSeparationMARK));

			NSTransferInfo*	pIterTrans = (*iter)->getItemTransfertData() ;
			if (pIterTrans && pIterTrans->pTransfertMessage && (posit != NPOS))
			{
				string sIterUnit = string((*iter)->getItemLabel(), 0, posit) ;
				posit_debut = posit + 1 ;
				string sIterLexique = string((*iter)->getItemLabel(), posit_debut, strlen((*iter)->getItemLabel().c_str()) - posit_debut) ;

        //
        // We only synchronize homogeneous data
        //
        if ((sIterLexique == sLexique) && (sIterUnit != ""))
        {
        	if (!pNSCV)
          {
        		pNSCV = new NSCV(pNSFct->pBBItem->pBigBoss->pContexte) ;
          	DBIResult Resultat = pNSCV->open() ;
            if (Resultat != DBIERR_NONE)
            {
            	erreur("Erreur � l'ouverture de la base convert.", standardError, Resultat) ;
            	delete pNSCV ;
              return ;
            }
        	}
          string sValeur ;
          double dVal = StringToDouble(sValue) ;
          if (pNSCV->ConvertirUnite(&dVal, sIterUnit, sUnit, sRefValeur))
          	sValeur = DoubleToString(&dVal, 0, 2) ;
          else
          	sValeur = "" ;

          if ((pFilsCurrent->getItemTransfertMsg()->GetComplement() != "") && (sValeur != ""))
          	ActiveChampEdit(*iter, sValeur) ;
        }
      }
		}
	}
	if (pNSCV)
  {
  	pNSCV->close() ;
		delete pNSCV ;
  }
}
catch (...)
{
	erreur("Exception SynchroNumValues.", standardError, 0) ;
	return ;
}
}

void
RemplirDateMax(NSDlgFonction *pNSFct)
{
	if (!pNSFct || !(pNSFct->pControle) || !(pNSFct->pControle->getTransfert()))
		return ;

	string sDateMax = "" ;
	BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;

	NSTransferInfo*	pTrans = pNSFct->pControle->getTransfert() ;
	if (!pTrans->pBBFilsItem)
		return ;

	BBFilsItem* pFilsCurrent = pTrans->pBBFilsItem ;

	// on remonte au BBFilsItem pere pour trouver l'�tiquette
	BBItem*	pItemPere = pFilsCurrent->getItemFather() ;
	if (!pItemPere)
		return ;

	BBFilsItem* pFilsValue = pItemPere->pBBFilsPere ;
	string sRefValeur = string("") ;
	if (!pFilsValue)
		return ;

	sRefValeur = pFilsValue->getItemLabel() ;
	// on rajoute le chemin de la date
	sRefValeur += string("/KDARE1/2DA021/�T0;10");

	if (pFilsCurrent->getItemTransfertMsg()->GetComplement() != "")
	{
  	// on r�cup�re la date max
    RetournerDateMax(pItem, &sDateMax) ;

    BBFilsItem* fils ;

    string sCurrentDate ;
    fils = RetournerValeurEdit(pItem, sRefValeur, &sCurrentDate) ;

    if (sDateMax == "")
    {
    	NVLdVTemps tDateJour ;
      tDateJour.takeTime() ;
      sDateMax = tDateJour.donneDateHeure() ;
    }

    ActiveChampEdit(fils, sDateMax) ;
  }
}

//-------------------------------------------------------------------
// Renseigner la dur�e de la p�riode de temps
//-------------------------------------------------------------------
void
AdaptLastingTime(NSDlgFonction *pNSFct)
{
  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
    return ;
  NSControleVector* pNSCtrl = pNSFct->pControle->getInterfaceControls() ;
  if ((NULL == pNSCtrl) || (pNSCtrl->empty()))
    return ;

  //
  // On recherche un contr�le, situ� apr�s l'actuel et de fonction LASTING_TIME
  // Looking for a control located after this one and whose function is LASTING_TIME
  //
  NSControle* pLastingCtrl = RechercheFctApres(pNSCtrl, pNSFct, "LASTING_TIME") ;
  if (NULL == pLastingCtrl)
    pLastingCtrl = RechercheFctApres(pNSCtrl, pNSFct, "LASTING_TIME_FORCE") ;

  NSControle* pNoEndingCtrl = RechercheFctApres(pNSCtrl, pNSFct, "NOENDING") ;
  if ((NULL == pLastingCtrl) && (NULL == pNoEndingCtrl))
    return ;

  if ((NULL == pNSFct->pControle->getTransfert()) || (NULL == pNSFct->pControle->getTransfert()->pTransfertMessage))
    return ;
  string sDate = pNSFct->pControle->getTransfert()->pTransfertMessage->GetComplement() ;

  // Si on est vide, mettre � z�ro pLastingCtrl
  // If we are empty, reset pLastingCtrl
  //
  if (string("") == sDate)
  {
    if (pLastingCtrl && (pLastingCtrl->getType() == isEdit))
      (static_cast<NSEdit*>(pLastingCtrl->getControle()))->SetText("") ;
  }

  // Est-on un d�but ou une fin ? chercher la fonction inverse
  // Are we a time beginning or a time ending ? looking for the opposite function

  if ((pNSFct->containFonction("BEGINNOW")) || (pNSFct->containFonction("BEGIN")))
  {
    if ((NULL == pLastingCtrl) || (string("") == sDate))
      return ;
    NSControle* pEndingCtrl = RechercheFctApres(pNSCtrl, pNSFct, "ENDING") ;
    if ((NULL == pEndingCtrl) || (NULL == pEndingCtrl->getTransfert()) || (NULL == pEndingCtrl->getTransfert()->pTransfertMessage))
      return ;
    string sEndingDate = pEndingCtrl->getTransfert()->pTransfertMessage->GetComplement() ;
    if (string("") == sEndingDate)
      return ;

    NVLdVTemps tpsBegin, tpsEnding ;
    tpsBegin.initFromDate(sDate) ;
    tpsEnding.initFromDate(sEndingDate) ;

    unsigned long lDeltaDays = tpsEnding.daysBetween(tpsBegin) + 1 ;

    if (pLastingCtrl->getType() == isEdit)
    {
      char szDelta[35] ;
      (static_cast<NSEdit*>(pLastingCtrl->getControle()))->SetText(ltoa((long)lDeltaDays, szDelta, 10)) ;
    }
    return ;
  }

  if (pNSFct->containFonction("ENDING"))
  {
    if (pNoEndingCtrl)
    {
      if (string("") == sDate)
      {
        if      (pNoEndingCtrl->getType() == isCaseACocher)
          (static_cast<NSCheckBox*>(pLastingCtrl->getControle()))->SetCheck(BF_CHECKED) ;
        else if (pNoEndingCtrl->getType() == isRadioBtn)
          (static_cast<NSRadioButton*>(pLastingCtrl->getControle()))->SetCheck(BF_CHECKED) ;
      }
      else
      {
        if      (pNoEndingCtrl->getType() == isCaseACocher)
          (static_cast<NSCheckBox*>(pLastingCtrl->getControle()))->SetCheck(BF_UNCHECKED) ;
        else if (pNoEndingCtrl->getType() == isRadioBtn)
          (static_cast<NSRadioButton*>(pLastingCtrl->getControle()))->SetCheck(BF_UNCHECKED) ;
      }
    }

    if ((NULL == pLastingCtrl) || (string("") == sDate))
      return ;

    NSControle* pBeginCtrl = RechercheFctAvant(pNSCtrl, pNSFct, "BEGINNOW") ;
    if (NULL == pBeginCtrl)
      pBeginCtrl = RechercheFctAvant(pNSCtrl, pNSFct, "BEGIN") ;
    if ((NULL == pBeginCtrl) || (NULL == pBeginCtrl->getTransfert()) || (NULL == pBeginCtrl->getTransfert()->pTransfertMessage))
      return ;
    string sBeginDate = pBeginCtrl->getTransfert()->pTransfertMessage->GetComplement() ;
    if (string("") == sBeginDate)
      return ;

    NVLdVTemps tpsBegin, tpsEnding ;
    tpsBegin.initFromDate(sBeginDate) ;
    tpsEnding.initFromDate(sDate) ;

    unsigned long lDeltaDays = tpsEnding.daysBetween(tpsBegin) + 1 ;

    if (pLastingCtrl->getType() == isEdit)
    {
      char szDelta[35] ;
      (static_cast<NSEdit*>(pLastingCtrl->getControle()))->SetText(ltoa((long)lDeltaDays, szDelta, 10)) ;
    }
    return ;
  }
}

void
AdaptEnding(NSDlgFonction *pNSFct, bool bForceEnding)
{
	if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

	NSControleVector* pNSCtrl = pNSFct->pControle->getInterfaceControls() ;
  if ((NULL == pNSCtrl) || (pNSCtrl->empty()))
    return ;

	string sNbDays ;
	if (pNSFct->pControle->getTransfert())
		sNbDays = pNSFct->pControle->getTransfert()->pTransfertMessage->GetComplement() ;
	else
	{
		if (pNSFct->pControle->getType() == isEdit)
		{
    	char szDelta[35] ;
      (static_cast<NSEdit*>(pNSFct->pControle->getControle()))->GetText(szDelta, 34) ;
      sNbDays = string(szDelta) ;
    }
  }
	if (sNbDays == "")
		return ;

	int iNbDays = atoi(sNbDays.c_str()) ;
	if (iNbDays <= 0)
		return ;

	NSControle* pBeginCtrl = RechercheFctAvant(pNSCtrl, pNSFct, "BEGINNOW") ;
	if (!pBeginCtrl)
		pBeginCtrl = RechercheFctAvant(pNSCtrl, pNSFct, "BEGIN") ;
	if (!pBeginCtrl)
		return ;
	int iBeginCtrlType = pBeginCtrl->getType() ;
  if ((iBeginCtrlType != isEditDate) && (iBeginCtrlType != isEditDateHeure))
		return ;

	NSControle* pEndingCtrl = RechercheFctAvant(pNSCtrl, pNSFct, "ENDING") ;
	if (!pEndingCtrl)
		return ;
	int iEndingCtrlType = pEndingCtrl->getType() ;
  if ((iEndingCtrlType != isEditDate) && (iEndingCtrlType != isEditDateHeure))
		return ;

	string sEndingDate = pEndingCtrl->getTransfert()->pTransfertMessage->GetComplement() ;
	string sBeginDate  = pBeginCtrl->getTransfert()->pTransfertMessage->GetComplement() ;
	if ((sEndingDate == "") && (sBeginDate == ""))
		return ;

	if ((sEndingDate == "") ||
      ((true == bForceEnding) && (string("") != sBeginDate)))
	{
		NVLdVTemps tpsEnding ;
		tpsEnding.initFromDate(sBeginDate) ;
		tpsEnding.ajouteJours(iNbDays - 1) ;
    if      (iEndingCtrlType == isEditDate)
    	sEndingDate = tpsEnding.donneDate() ;
    else if (iEndingCtrlType == isEditDateHeure)
    	sEndingDate = tpsEnding.donneDateHeure() ;
		ActiveChampEdit(pEndingCtrl->getTransfert()->pBBFilsItem, sEndingDate) ;
		return ;
	}
  if (sBeginDate == "")
  {
  	NVLdVTemps tpsBegin ;
    tpsBegin.initFromDate(sEndingDate) ;
    tpsBegin.ajouteJours(1 - iNbDays) ;
    if      (iBeginCtrlType == isEditDate)
    	sBeginDate = tpsBegin.donneDate() ;
    else if (iBeginCtrlType == isEditDateHeure)
    	sBeginDate = tpsBegin.donneDateHeure() ;
    ActiveChampEdit(pBeginCtrl->getTransfert()->pBBFilsItem, sBeginDate) ;
    return ;
  }
}

void
FixLastingTime(NSDlgFonction* /*pNSFct*/)
{
}

void
FixNoEnding(NSDlgFonction* /*pNSFct*/)
{
}

void
CancelEnding(NSDlgFonction* /*pNSFct*/)
{
}

void FixCaption(NSDlgFonction *pNSFct)
{
  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
    return ;

  BBItem* pBBItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (NULL == pBBItem)
    return ;

  string sEtiq = "" ;

  if (pBBItem->pBBFilsPere)
    sEtiq = pBBItem->pBBFilsPere->getItemLabel() ;
  else
  {
    if (pBBItem->pParseur)
    {
      Citem* pRootItem = pBBItem->pParseur->pArchetype->getRootItem() ;
      if (pRootItem->getArrayFils()->empty())
        return ;
      ValIter ival ;
      bool bTourner = true ;

      // On r�cup�re le premier fils de premier niveau
      for (ival = pRootItem->getArrayFils()->begin(); bTourner && (ival != pRootItem->getArrayFils()->end()); ival++)      {        if ((*ival)->sLabel == LABEL_ITEM)        {          Citem* pFirstItem = dynamic_cast<Citem*>((*ival)->pObject) ;          if (pFirstItem)          {            sEtiq = pFirstItem->getStringAttribute(ATTRIBUT_ITEM_CODE) ;            bTourner = false ;          }        }      }      if (bTourner)        return ;    }
    else
      return ;
  }

  string sTitre = "" ;
  string sLang  = "" ;

  if (pBBItem->pBigBoss->pContexte->getUtilisateur())
    sLang = pBBItem->pBigBoss->pContexte->getUtilisateur()->donneLang() ;

  if (sEtiq != string("�?????"))
  {
    pBBItem->pBigBoss->pContexte->getDico()->donneLibelle(sLang, &sEtiq, &sTitre) ;
    sTitre[0] = pseumaj(sTitre[0]) ;
  }

  TWindow* pInterface = pNSFct->pControle->getInterfacePointer() ;
  pInterface->SetCaption(sTitre.c_str()) ;
}


void
CreatePreoccup(NSDlgFonction *pNSFct)
{
	if (!pNSFct || !(pNSFct->pControle) || !(pNSFct->pControle->getTransfert()))
		return ;

	NSTransferInfo*	pTrans = pNSFct->pControle->getTransfert() ;
	if (!pTrans->pBBFilsItem)
  	return ;

  BBFilsItem* pFilsCurrent = pTrans->pBBFilsItem ;

  string sDate = "" ;
  string sPreoccup = "" ;

  NSSuper* pSuper = pFilsCurrent->getItemFather()->pBigBoss->pContexte->getSuperviseur() ;
	//
	// Est-ce une �tiquette multiple (date) ?
	//
	size_t posit = (pFilsCurrent->getItemLabel()).find(string(1, cheminSeparationMARK));
  if (posit != NPOS)
	{
		string sUnit = string(pFilsCurrent->getItemLabel(), 0, posit) ;
		size_t posit_debut = posit + 1 ;
		string sLexique = string(pFilsCurrent->getItemLabel(), posit_debut, strlen(pFilsCurrent->getItemLabel().c_str()) - posit_debut) ;

  	string sValue   = pTrans->pTransfertMessage->GetComplement() ;

		BBItem*	pItemPere = pFilsCurrent->getItemFather() ;
  	if (!pItemPere)
			return ;

		BBFilsItem* pFilsValue = pItemPere->pBBFilsPere ;
  	string sRefValeur = string("") ;
  	if (!pFilsValue)
			return ;
		sRefValeur      = pFilsValue->getItemLabel() ;
    string sValSens = "" ;

    pSuper->getDico()->donneCodeSens(&sRefValeur, &sValSens) ;

    if (sValSens != "KOUVR")
    	return ;

		sDate = sValue ;
    if (sDate == "")
    	return ;

    BBItem*	pItemPreoccup = pFilsValue->getItemFather() ;
  	if (!pItemPreoccup)
			return ;

  	if (!pItemPreoccup->pBBFilsPere)
			return ;
		sPreoccup = pItemPreoccup->pBBFilsPere->getItemLabel() ;
	}
	else
		sPreoccup = pFilsCurrent->getItemLabel() ;

	// NSDialog* pDialog = pNSFct->pControle->getNSDialog() ;
  TWindow* pInterface = pNSFct->pControle->getInterfacePointer() ;

	NSToDoTask* pTask = new NSToDoTask ;

  pTask->sWhatToDo = "NewPreoccup" ;
  // pTask->pPointer1 = (void*)pDialog ;
  pTask->pPointer1 = (void*)pInterface ;
	pTask->sParam1 = sPreoccup ;
	pTask->sParam2 = sDate ;

	pSuper->addToDo(pTask) ;
}

void
EditAddress(NSDlgFonction *pNSFct)
{
try
{
	if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
  	return ;
  BBItem* pBBItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (NULL == pBBItem)
  	return ;

  // on r�cup�re le contexte du pBigBoss du BBItem root du dialogue
  // d'origine (cr�� � partir de l'archetype d'�dition d'adresse)
  NSContexte* pContexte = pBBItem->pBigBoss->pContexte ;
  string sObjectID ;
  BBFilsItem* pBBFilsItem ;

  // La fonction, rattach�e � l'item �OBJE1, a un pointeur
  // sur le pTransfert associ�, ce qui permet de r�cup�rer
  // l'identifiant de l'objet � �diter.
  NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if (pTransfert && pTransfert->pTransfertMessage)
  {
    sObjectID = pTransfert->pTransfertMessage->GetComplement() ;
    pBBFilsItem = pTransfert->pBBFilsItem ;
  }
  else
  {
    erreur("Transfert non initialis� dans la fonction d'�dition d'adresse.", standardError, 0) ;
    return ;
  }

  NSAddressGraphManager* pAddressManager = new NSAddressGraphManager(pContexte);
  NSPatPathoArray* pPatPathoAdr = new NSPatPathoArray(pContexte, graphObject);

  // Si on avait d�j� un objet adresse, on reload son graphe
  if (sObjectID != "")
  {
    if (!pAddressManager->getGraphAdr(sObjectID, pPatPathoAdr))
    {
      erreur("Impossible de r�cup�rer le graphe dans la fonction d'�dition d'adresse.", standardError, 0) ;
      delete pPatPathoAdr ;
      delete pAddressManager ;
      return ;
    }

    // Pr�paration de la fonction d'�num�ration
    WNDENUMPROC lpEnumFunc = (WNDENUMPROC) MakeProcInstance((FARPROC) SetStaticCaption, hInstance) ;
    string sTitre, sAdresse ;

    sAdresse = pAddressManager->trouveLibCourtAdr() ;
    sTitre = string("Domicili�|") + sAdresse ;
    // On passe comme param�tre de EnumChildWindows le titre et l'adresse
    TWindow* pInterface = pNSFct->pControle->getInterfacePointer() ;
    EnumChildWindows(pInterface->HWindow, lpEnumFunc, LPARAM(&sTitre)) ;
    pInterface->Invalidate() ;

    // on active le bouton "modifier", qui contient l'objet
    // pour qu'il soit pris en compte au retour de la fonction de modification
    pTransfert->pBBFilsItem->Active() ;

    // dans cette fonction, on ne lance pas l'archetype en modification
    // (cela est r�alis� par la fonction ModifyAddress())
    // delete pPatPathoAdr ;
    // delete pGraphManager ;
    // return ;
  }

  // on initialise un pBigBoss pour pouvoir lancer l'archetype de gestion d'adresse
  NSSmallBrother* pBigBoss = new NSSmallBrother(pContexte, pPatPathoAdr) ;
  pBigBoss->pFenetreMere = pNSFct->pControle->getInterfacePointer() ;
  // Ici on lance une boite de dialogue modale
	BB1BBInterfaceForKs InterfaceForKs(-1, pContexte->getSuperviseur()->getAddressArchetypeId(), "", false) ;
  pBigBoss->lanceBbkArchetypeInDialog(pContexte->getSuperviseur()->getAddressArchetypeId(), 0, pBBFilsItem, &InterfaceForKs, true) ;

  // on teste le code de retour du dialogue, qui est stock� dans le
  // BBItem root cr�� par le pBigBoss.
  if (pBigBoss->pBBItem->iRetourDlg == 0)     // CmOK
  {
    // on enregistre la patpatho du pBigBoss, qui contient les nouvelles donn�es
    // si elle n'est pas vide.
    if (!(pBigBoss->getPatPatho()->empty()))
    {
      *pPatPathoAdr = *(pBigBoss->getPatPatho());

      /*
      if (pGraphManager->setGraphAdr(pPatPathoAdr))
      {
        // Pr�paration de la fonction d'�num�ration
        WNDENUMPROC lpEnumFunc = (WNDENUMPROC) MakeProcInstance((FARPROC) SetStaticCaption, hInstance) ;
        string sTitre, sAdresse ;

        sAdresse = pGraphManager->trouveLibCourtAdr() ;
        sTitre = string("Domicili�|") + sAdresse ;
        // On passe comme param�tre de EnumChildWindows le titre et l'adresse
        EnumChildWindows(pDialog->HWindow, lpEnumFunc, LPARAM(&sTitre)) ;
        pDialog->Invalidate() ;

        // on r�cup�re l'objectID root du graphe pour
        // le stocker dans le compl�ment de l'item �OBJE1
        sObjectID = pGraphManager->getRootObject() ;
        pTransfert->pTransfertMessage->SetComplement(sObjectID) ;
        pTransfert->pBBFilsItem->Active() ;
#ifdef N_TIERS
				pDialog->CmOk() ;
#endif
      }
      */
    }
  }

  delete pPatPathoAdr ;
  delete pBigBoss ;
  delete pAddressManager ;
}
catch (...)
{
	erreur("Exception EditAddress.", standardError, 0) ;
	return ;
}
}

void
ModifyAddress(NSDlgFonction *pNSFct)
{
try
{
  if (!pNSFct || !(pNSFct->pControle))
  	return ;
  BBItem* pBBItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (NULL == pBBItem)
  	return ;

  // on r�cup�re le contexte du pBigBoss du BBItem root du dialogue
  // d'origine (cr�� � partir de l'archetype d'�dition d'adresse)
  NSContexte* pContexte = pBBItem->pBigBoss->pContexte ;
  string sObjectID ;
  BBFilsItem* pBBFilsItem ;
  bool bExistObject = false;

  // La fonction, rattach�e � l'item �OBJE1, a un pointeur
  // sur le pTransfert associ�, ce qui permet de r�cup�rer
  // l'identifiant de l'objet � �diter.
  NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if (pTransfert && pTransfert->pTransfertMessage)
  {
    sObjectID = pTransfert->pTransfertMessage->GetComplement() ;
    pBBFilsItem = pTransfert->pBBFilsItem ;
  }
  else
  {
    erreur("Transfert non initialis� dans la fonction d'�dition d'adresse.", standardError, 0) ;
    return ;
  }

  NSAddressGraphManager* pAddressManager = new NSAddressGraphManager(pContexte) ;
  NSPatPathoArray* pPatPathoAdr = new NSPatPathoArray(pContexte, graphObject) ;

  // Si on avait d�j� un objet adresse, on reload son graphe
  if (sObjectID != "")
  {
    if (!pAddressManager->getGraphAdr(sObjectID, pPatPathoAdr))
    {
      erreur("Impossible de r�cup�rer le graphe dans la fonction d'�dition d'adresse.", standardError, 0) ;
      delete pPatPathoAdr ;
      delete pAddressManager ;
      return ;
    }

    bExistObject = true;

    // Pr�paration de la fonction d'�num�ration
    WNDENUMPROC lpEnumFunc = (WNDENUMPROC) MakeProcInstance((FARPROC) SetStaticCaption, hInstance) ;
    string sTitre, sAdresse ;

    sAdresse = pAddressManager->trouveLibCourtAdr() ;
    sTitre = string("Domicili�|") + sAdresse ;
    // On passe comme param�tre de EnumChildWindows le titre et l'adresse
    TWindow* pInterface = pNSFct->pControle->getInterfacePointer() ;
    EnumChildWindows(pInterface->HWindow, lpEnumFunc, LPARAM(&sTitre)) ;
    pInterface->Invalidate() ;

    // on active le bouton "modifier", qui contient l'objet
    // pour qu'il soit pris en compte au retour de la fonction de modification
    pTransfert->pBBFilsItem->Active() ;

    /*
    // dans cette fonction, on ne lance pas l'archetype en modification
    // quand il existe un objet, on revient sur l'archetype interm�diaire
    // � partir duquel on peut corriger ou changer d'adresse.
    delete pPatPathoAdr ;
    delete pAddressManager ;
    return ;
    */
  }

  TWindow* pInterface = pNSFct->pControle->getInterfacePointer() ;

  // on initialise un pBigBoss pour pouvoir lancer l'archetype de gestion d'adresse
  NSSmallBrother* pBigBoss = new NSSmallBrother(pContexte, pPatPathoAdr) ;
  pBigBoss->pFenetreMere = pInterface ;
  // Ici on lance une boite de dialogue modale
	BB1BBInterfaceForKs InterfaceForKs(-1, pContexte->getSuperviseur()->getAddressArchetypeId(), "", false) ;
  do
  {
    pBigBoss->lanceBbkArchetypeInDialog(pContexte->getSuperviseur()->getAddressArchetypeId(), 0, pBBFilsItem, &InterfaceForKs, true) ;
  }
  while (pBigBoss->pBBItem->iStatusDlg == NSDLGSTATUS_REINIT);

  // on teste le code de retour du dialogue, qui est stock� dans le
  // BBItem root cr�� par le pBigBoss.
  if (pBigBoss->pBBItem->iRetourDlg == 0)     // CmOK
  {
    // on enregistre la patpatho du pBigBoss, qui contient les nouvelles donn�es
    // si elle n'est pas vide.
    if (!(pBigBoss->getPatPatho()->empty()))
    {
      *pPatPathoAdr = *(pBigBoss->getPatPatho()) ;
      // on remet le graphe � z�ro pour �viter la formation de doublons issus d'un merge
      pAddressManager->graphReset() ;
      if (pAddressManager->setGraphAdr(pPatPathoAdr))
      {
        // Pr�paration de la fonction d'�num�ration
        WNDENUMPROC lpEnumFunc = (WNDENUMPROC) MakeProcInstance((FARPROC) SetStaticCaption, hInstance) ;
        string sTitre, sAdresse ;

        sAdresse = pAddressManager->trouveLibCourtAdr() ;
        sTitre = string("Domicili�|") + sAdresse ;
        // On passe comme param�tre de EnumChildWindows le titre et l'adresse
        TWindow* pInterface = pNSFct->pControle->getInterfacePointer() ;
        EnumChildWindows(pInterface->HWindow, lpEnumFunc, LPARAM(&sTitre)) ;
        pInterface->Invalidate() ;

        // on r�cup�re l'objectID root du graphe pour
        // le stocker dans le compl�ment de l'item �OBJE1
        sObjectID = pAddressManager->getRootObject() ;
      }
    }
  }

  if (sObjectID != "")
  {
    pTransfert->pTransfertMessage->SetComplement(sObjectID) ;
    pTransfert->pBBFilsItem->Active() ;
    if (!bExistObject)
    {
      TDialog* pDlg = TYPESAFE_DOWNCAST(pInterface, TDialog) ;
      if (pDlg)
        pDlg->CmOk() ;
    }
  }
  else
  {
    TDialog* pDlg = TYPESAFE_DOWNCAST(pInterface, TDialog) ;
    if (pDlg)
  	  pDlg->CmCancel() ;
  }

  delete pPatPathoAdr ;
  delete pBigBoss ;
  delete pAddressManager ;
}
catch (...)
{
	erreur("Exception ModifyAddress.", standardError, 0) ;
	return ;
}
}


void
EditAddressButton(NSDlgFonction *pNSFct)
{
try
{
  if (!pNSFct || !(pNSFct->pControle))
  	return ;
  NSDialog* pDialog = pNSFct->pControle->getNSDialog() ;
  if (!pDialog)
  	return ;
  if (!pDialog->pBBItem)
  	return ;

  // on r�cup�re le contexte du pBigBoss du BBItem root du dialogue
  // d'origine (cr�� � partir de l'archetype d'�dition d'adresse)
  NSContexte* pContexte = pDialog->pBBItem->pBigBoss->pContexte ;
  string sObjectID ;
  BBFilsItem* pBBFilsItem ;

  // La fonction, rattach�e � l'item �OBJE1, a un pointeur
  // sur le pTransfert associ�, ce qui permet de r�cup�rer
  // l'identifiant de l'objet � �diter.
  NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if (pTransfert && pTransfert->pTransfertMessage)
  {
    sObjectID = pTransfert->pTransfertMessage->GetComplement() ;
    pBBFilsItem = pTransfert->pBBFilsItem ;
  }
  else
  {
    erreur("Transfert non initialis� dans la fonction d'�dition d'adresse.", standardError, 0) ;
    return ;
  }

  NSAddressGraphManager* pAddressManager = new NSAddressGraphManager(pContexte) ;
  NSPatPathoArray* pPatPathoAdr = new NSPatPathoArray(pContexte, graphObject) ;

  // Si on avait d�j� un objet adresse, on reload son graphe
  if (sObjectID != "")
  {
    if (!pAddressManager->getGraphAdr(sObjectID, pPatPathoAdr))
    {
      erreur("Impossible de r�cup�rer le graphe dans la fonction d'�dition d'adresse.", standardError, 0) ;
      delete pPatPathoAdr ;
      delete pAddressManager ;
      return ;
    }

    /*
    // Pr�paration de la fonction d'�num�ration
    WNDENUMPROC lpEnumFunc = (WNDENUMPROC) MakeProcInstance((FARPROC) SetStaticCaption, hInstance) ;
    string sTitre, sAdresse ;

    sAdresse = pGraphManager->trouveLibCourtAdr();
    sTitre = string("Domicili�|") + sAdresse ;
    // On passe comme param�tre de EnumChildWindows le titre et l'adresse
    EnumChildWindows(pDialog->HWindow, lpEnumFunc, LPARAM(&sTitre)) ;
    pDialog->Invalidate() ;
    */

    // on active le bouton "modifier", qui contient l'objet
    // pour qu'il soit pris en compte au retour de la fonction de modification
    // (m�me si on sort par CmCancel() de l'archetype)
    // pTransfert->pBBFilsItem->Active() ;
  }

  // on initialise un pBigBoss pour pouvoir lancer l'archetype de gestion d'adresse
  NSSmallBrother* pBigBoss = new NSSmallBrother(pContexte, pPatPathoAdr) ;
  pBigBoss->pFenetreMere = (TWindow*) pDialog ;
  // Ici on lance une boite de dialogue modale
	BB1BBInterfaceForKs InterfaceForKs(-1, pContexte->getSuperviseur()->getAddressArchetypeId(), "", false) ;
  pBigBoss->lanceBbkArchetypeInDialog(pContexte->getSuperviseur()->getAddressArchetypeId(), 0, pBBFilsItem, &InterfaceForKs, true) ;

  // on teste le code de retour du dialogue, qui est stock� dans le
  // BBItem root cr�� par le pBigBoss.
  if (pBigBoss->pBBItem->iRetourDlg == 0)     // CmOK
  {
    // on enregistre la patpatho du pBigBoss, qui contient les nouvelles donn�es
    // si elle n'est pas vide.
    if (!(pBigBoss->getPatPatho()->empty()))
    {
      *pPatPathoAdr = *(pBigBoss->getPatPatho()) ;
      // on remet le graphe � z�ro pour �viter la formation de doublons issus d'un merge
      pAddressManager->graphReset() ;
      if (pAddressManager->setGraphAdr(pPatPathoAdr))
      {
        // Pr�paration de la fonction d'�num�ration
        WNDENUMPROC lpEnumFunc = (WNDENUMPROC) MakeProcInstance((FARPROC) SetStaticCaption, hInstance) ;
        string sTitre, sAdresse ;

        sAdresse = pAddressManager->trouveLibCourtAdr() ;
        sTitre = string("Adresse|") + sAdresse ;
        // On passe comme param�tre de EnumChildWindows le titre et l'adresse
        EnumChildWindows(pDialog->HWindow, lpEnumFunc, LPARAM(&sTitre)) ;
        pDialog->Invalidate() ;

        // on r�cup�re l'objectID root du graphe pour
        // le stocker dans le compl�ment de l'item �OBJE1
        sObjectID = pAddressManager->getRootObject() ;
        pTransfert->pTransfertMessage->SetComplement(sObjectID) ;
      }
    }
  }

  delete pPatPathoAdr ;
  delete pBigBoss ;
  delete pAddressManager ;
}
catch (...)
{
	erreur("Exception EditAddressButton.", standardError, 0) ;
	return ;
}
}


void ChooseAddress(NSDlgFonction* /* pNSFct */)
{
try
{
}
catch (...)
{
	erreur("Exception ChooseAddress.", standardError, 0) ;
	return ;
}
}

void ChoosePatAddress(NSDlgFonction* /* pNSFct */)
{
try
{
}
catch (...)
{
	erreur("Exception ChoosePatAddress.", standardError, 0) ;
	return ;
}
}

void ChooseCorAddress(NSDlgFonction* /* pNSFct */)
{
try
{
}
catch (...)
{
	erreur("Exception ChooseCorAddress.", standardError, 0) ;
	return ;
}
}

void ShowCorresp(NSDlgFonction* /* pNSFct */)
{
try
{
}
catch (...)
{
	erreur("Exception ShowCorresp.", standardError, 0) ;
	return ;
}
}

void EditCorresp(NSDlgFonction* /* pNSFct */)
{
try
{
}
catch (...)
{
	erreur("Exception EditCorresp.", standardError, 0) ;
	return ;
}
}

void ShowRefCorresp(NSDlgFonction* /* pNSFct */)
{
try
{
}
catch (...)
{
	erreur("Exception ShowRefCorresp.", standardError, 0) ;
	return ;
}
}

void EditRefCorresp(NSDlgFonction* /* pNSFct */)
{
try
{
}
catch (...)
{
	erreur("Exception EditRefCorresp.", standardError, 0) ;
	return ;
}
}


void
PidsAdrSite(NSDlgFonction *pNSFct)
{
try
{
	if (!pNSFct || !(pNSFct->pControle))
  	return ;
  NSDialog* pDialog = pNSFct->pControle->getNSDialog() ;
  if (!pDialog)
  	return ;
  if (!pDialog->pBBItem)
  	return;

  // on r�cup�re le contexte du pBigBoss du BBItem root du dialogue
  // d'origine (cr�� � partir de l'archetype d'�dition d'adresse)
  NSContexte* pContexte = pDialog->pBBItem->pBigBoss->pContexte ;
  string sSearch ;
  BBFilsItem* pBBFilsItem ;

  // La fonction, rattach�e � l'item Nom du SITE, a un pointeur
  // sur le pTransfert associ�, ce qui permet de r�cup�rer
  // la valeur du champ Edit pour la recherche.
  NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if (pTransfert && pTransfert->pTransfertMessage)
  {
    sSearch = pTransfert->pTransfertMessage->GetTexteLibre() ;
    pBBFilsItem = pTransfert->pBBFilsItem ;
  }
  else
  {
    erreur("Transfert non initialis� dans la fonction d'�dition d'adresse.", standardError, 0) ;
    return ;
  }

  if (sSearch == "")
  	return ;

  NSAddressGraphManager* pAddressManager = new NSAddressGraphManager(pContexte) ;
  NSPatPathoArray* pPatPathoAdr = new NSPatPathoArray(pContexte, graphObject) ;
  NSVectPatPathoArray* pVectAdr = new NSVectPatPathoArray() ;
  VecteurString* pFoundObjects = new VecteurString() ;
  VecteurString* pLibelles = new VecteurString() ;
  string sLibelle ;

  NSDataGraph* pGraph = new NSDataGraph(pContexte, graphObject) ;
  NSPersonsAttributesArray* pObjList = new NSPersonsAttributesArray() ;
  NSBasicAttributeArray *pAttrList = new NSBasicAttributeArray() ;
  pAttrList->push_back(new NSBasicAttribute("_LSITE_LSITE", strpids(sSearch))) ;
  pAttrList->push_back(new NSBasicAttribute(RESEARCH, CONTAIN_RESEARCH)) ;

  bool res = pContexte->pPilot->objectList(NautilusPilot::SERV_OBJECT_LIST.c_str(), pObjList, pAttrList) ;
  if (!res)
  {
    string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "objectNotFound") ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
    delete pGraph ;
		delete pObjList ;
    delete pAttrList ;
    delete pAddressManager ;
  	delete pPatPathoAdr ;
  	delete pVectAdr ;
  	delete pFoundObjects ;
  	delete pLibelles ;
    return ;
  }

	if (!(pObjList->empty()))
  	for (NSPersonsAttributeIter k = pObjList->begin() ; k != pObjList->end() ; k++)
  	{
    	string sOIDS = (*k)->getAttributeValue(OIDS) ;
    	pFoundObjects->push_back(new string(sOIDS)) ;
  	}

  delete pAttrList ;
  delete pObjList ;
  delete pGraph ;

  // Si aucun objet trouv� : on sort
  if (pFoundObjects->empty())
	{
  	delete pAddressManager ;
  	delete pPatPathoAdr ;
  	delete pVectAdr ;
  	delete pFoundObjects ;
  	delete pLibelles ;
  	return ;
	}

  for (EquiItemIter i = pFoundObjects->begin(); i != pFoundObjects->end(); i++)
  {
    // on r�cup�re le graphe de l'objet point�
    // et on conserve son libell�.
    pAddressManager->graphReset() ;
    pPatPathoAdr->vider() ;
    pAddressManager->getGraphAdr((*(*i)), pPatPathoAdr) ;
    sLibelle = pAddressManager->trouveLibCourtAdr() ;
    pLibelles->push_back(new string(sLibelle)) ;
    pVectAdr->push_back(new NSPatPathoArray(*pPatPathoAdr)) ;
  }

  ChoixDansListeDialog* pListeDialog = new ChoixDansListeDialog(pDialog, pContexte, pLibelles, sSearch) ;
  if ((pListeDialog->Execute() == IDCANCEL) || (pListeDialog->itemChoisi == -1))
  {
  	delete pAddressManager ;
  	delete pPatPathoAdr ;
  	delete pVectAdr ;
  	delete pFoundObjects ;
  	delete pLibelles ;
  	return ;
	}

  // on instancie la pPPTMerge qui fusionne avec pPPTEnCours de BBItem sur okFermerDialogue()
  BBItem* pBBItemRoot = pDialog->pBBItem ;
  int index = pListeDialog->itemChoisi ;
  pBBItemRoot->pPPTMerge = new NSPatPathoArray(*((*pVectAdr)[index])) ;
  // on lance la r�ouverture du dialogue
  pBBItemRoot->donneStatusDlg(NSDLGSTATUS_REINIT);
  pDialog->CmOk() ;

  /*
  // on reconstitue un graphe � partir de la patpatho r�sultat (dans pBBItemRoot)
  pAddressManager->graphReset() ;
  pAddressManager->setGraphAdr(pBBItemRoot->pPPTEnCours) ;

  // Pr�paration de la fonction d'�num�ration
  WNDENUMPROC lpEnumFunc = (WNDENUMPROC) MakeProcInstance((FARPROC) SetStaticCaption, hInstance) ;
  string sTitre, sAdresse, sObjectID ;

  sAdresse = pGraphManager->trouveLibCourtAdr() ;
  sTitre = string("Domicili�|") + sAdresse ;
  sObjectID = pAddressManager->getRootObject() ;
  // On passe comme param�tre de EnumChildWindows le titre et l'adresse
  EnumChildWindows(pDialogSource->HWindow, lpEnumFunc, LPARAM(&sTitre)) ;
  pDialogSource->Invalidate() ;

  // on remet l'objectID � sa place � l'aide du pTransfert de la boite pr�c�dente
  // et on r�active l'archetype.
  pBBItemRoot->pBBFilsPere->pTransfert->pTransfertMessage->SetComplement(sObjectID) ;
  pBBItemRoot->pBBFilsPere->pTransfert->pBBFilsItem->Active() ;
  */

  delete pAddressManager ;
  delete pPatPathoAdr ;
  delete pVectAdr ;
  delete pFoundObjects ;
  delete pLibelles ;
}
catch (...)
{
	erreur("Exception PidsAdrSite.", standardError, 0) ;
	return ;
}
}


void
PidsAdrVoie(NSDlgFonction *pNSFct)
{
try
{
	if (!pNSFct || !(pNSFct->pControle))
  	return ;
  NSDialog* pDialog = pNSFct->pControle->getNSDialog() ;
  if (!pDialog)
  	return ;
  if (!pDialog->pBBItem)
  	return ;

  // on r�cup�re le contexte du pBigBoss du BBItem root du dialogue
  // d'origine (cr�� � partir de l'archetype d'�dition d'adresse)
  NSContexte* pContexte = pDialog->pBBItem->pBigBoss->pContexte ;
  string sSearch ;
  BBFilsItem* pBBFilsItem ;

  // La fonction, rattach�e � l'item Nom du SITE, a un pointeur
  // sur le pTransfert associ�, ce qui permet de r�cup�rer
  // la valeur du champ Edit pour la recherche.
  NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if (pTransfert && pTransfert->pTransfertMessage)
  {
    sSearch = pTransfert->pTransfertMessage->GetTexteLibre() ;
    pBBFilsItem = pTransfert->pBBFilsItem ;
  }
  else
  {
    erreur("Transfert non initialis� dans la fonction d'�dition d'adresse.", standardError, 0) ;
    return ;
  }

  if (sSearch == "")
  	return ;

  NSAddressGraphManager* pAddressManager = new NSAddressGraphManager(pContexte) ;
  NSPatPathoArray* pPatPathoAdr = new NSPatPathoArray(pContexte, graphObject) ;
  NSVectPatPathoArray* pVectAdr = new NSVectPatPathoArray() ;
  VecteurString* pFoundObjects = new VecteurString() ;
  VecteurString* pLibelles = new VecteurString() ;
  string sLibelle ;

  NSDataGraph* pGraph = new NSDataGraph(pContexte, graphObject) ;
  NSPersonsAttributesArray* pObjList = new NSPersonsAttributesArray() ;
  NSBasicAttributeArray *pAttrList = new NSBasicAttributeArray() ;
  pAttrList->push_back(new NSBasicAttribute("_LVOIE_LVOIE", strpids(sSearch))) ;
  pAttrList->push_back(new NSBasicAttribute(RESEARCH, CONTAIN_RESEARCH)) ;

  bool res = pContexte->pPilot->objectList(NautilusPilot::SERV_OBJECT_LIST.c_str(), pObjList, pAttrList) ;
  if (!res)
  {
    string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "objectNotFound") ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
    delete pAttrList ;
  	delete pObjList ;
  	delete pGraph ;
    delete pAddressManager ;
  	delete pPatPathoAdr ;
  	delete pVectAdr ;
  	delete pFoundObjects ;
  	delete pLibelles ;
    return ;
  }

	if (!(pObjList->empty()))
  	for (NSPersonsAttributeIter k = pObjList->begin() ; k != pObjList->end() ; k++)
  	{
    	string sOIDS = (*k)->getAttributeValue(OIDS) ;
    	pFoundObjects->push_back(new string(sOIDS)) ;
  	}

  delete pAttrList ;
  delete pObjList ;
  delete pGraph ;

  // Si aucun objet trouv� : on sort
  if (pFoundObjects->empty())
	{
  	delete pAddressManager ;
  	delete pPatPathoAdr ;
  	delete pVectAdr ;
  	delete pFoundObjects ;
  	delete pLibelles ;
  	return ;
	}

  for (EquiItemIter i = pFoundObjects->begin(); i != pFoundObjects->end(); i++)
  {
    // on r�cup�re le graphe de l'objet point�
    // et on conserve son libell�.
    pAddressManager->graphReset() ;
    pPatPathoAdr->vider() ;
    pAddressManager->getGraphAdr((*(*i)), pPatPathoAdr) ;
    pAddressManager->trouveInfoVoieAdr(sLibelle) ;
    string sVille, sPays, sZip, sCedex ;
    pAddressManager->trouveInfoVilleAdr(sVille, sPays, sZip, sCedex) ;
    sLibelle += string(" ") + sZip + string(" ") + sVille ;
    pLibelles->push_back(new string(sLibelle)) ;
    pVectAdr->push_back(new NSPatPathoArray(*pPatPathoAdr)) ;
  }

  ChoixDansListeDialog* pListeDialog = new ChoixDansListeDialog(pDialog, pContexte, pLibelles, sSearch) ;
  if ((pListeDialog->Execute() == IDCANCEL) || (pListeDialog->itemChoisi == -1))
  	return ;

  // on instancie la pPPTMerge qui fusionne avec pPPTEnCours de BBItem sur okFermerDialogue()
  BBItem* pBBItemRoot = pDialog->pBBItem ;
  int index = pListeDialog->itemChoisi ;
  pBBItemRoot->pPPTMerge = new NSPatPathoArray(*((*pVectAdr)[index])) ;
  // on lance la r�ouverture du dialogue
  pBBItemRoot->donneStatusDlg(NSDLGSTATUS_REINIT);
  pDialog->CmOk() ;

  delete pAddressManager ;
  delete pPatPathoAdr ;
  delete pVectAdr ;
  delete pFoundObjects ;
  delete pLibelles ;
}
catch (...)
{
	erreur("Exception PidsAdrVoie.", standardError, 0) ;
	return ;
}
}

bool
getCityFromZip(string sZipCode, NSPatPathoArray* pCityPpt, NSDialog* pMotherDialog, NSContexte* pContexte)
{
	if ((string("") == sZipCode) || (NULL == pCityPpt) || (NULL == pMotherDialog) || (NULL == pContexte))
		return false ;

  NSPersonsAttributesArray ObjList ;
  NSBasicAttributeArray    AttrList ;
  AttrList.push_back(new NSBasicAttribute("_LVILL_LVILL", strpids(sZipCode))) ;
  AttrList.push_back(new NSBasicAttribute(RESEARCH, CONTAIN_RESEARCH)) ;

  bool res = pContexte->pPilot->objectList(NautilusPilot::SERV_OBJECT_LIST.c_str(), &ObjList, &AttrList) ;
  if (!res)
  {
    string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "objectNotFound") ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
    return false ;
  }

  VecteurString FoundObjects ;

  if (!(ObjList.empty()))
  	for (NSPersonsAttributeIter k = ObjList.begin() ; k != ObjList.end() ; k++)
  	{
    	string sOIDS = (*k)->getAttributeValue(OIDS) ;
    	FoundObjects.push_back(new string(sOIDS)) ;
  	}

  // Si aucun objet trouv� : on sort
  if (FoundObjects.empty())
		return false ;

	NSAddressGraphManager    AddressManager(pContexte) ;
  NSPatPathoArray          PatPathoAdr(pContexte, graphObject) ;
  NSVectPatPathoArray      VectAdr ;

  VecteurString            Libelles ;

  for (EquiItemIter i = FoundObjects.begin(); i != FoundObjects.end(); i++)
  {
    // on r�cup�re le graphe de l'objet point�
    // et on conserve son libell�.
    AddressManager.graphReset() ;
    PatPathoAdr.vider() ;
    AddressManager.getGraphAdr((*(*i)), &PatPathoAdr) ;
    string sVille, sPays, sZip, sCedex ;
    AddressManager.trouveInfoVilleAdr(sVille, sPays, sZip, sCedex) ;
    string sLibelle = sZip + string(" ") + sVille + string(" ") + sPays ;
    Libelles.push_back(new string(sLibelle)) ;
    VectAdr.push_back(new NSPatPathoArray(PatPathoAdr)) ;
  }

  ChoixDansListeDialog* pListeDialog = new ChoixDansListeDialog(pMotherDialog, pContexte, &Libelles, sZipCode) ;
  if ((pListeDialog->Execute() == IDCANCEL) || (pListeDialog->itemChoisi == -1))
  	return false ;

	int index = pListeDialog->itemChoisi ;

  if ((index >= 0) && (index < int(VectAdr.size())))
  {
  	*pCityPpt = *(VectAdr[index]) ;
    return true ;
	}

  return false ;
}

bool
getCityFromZipTxt(string sZipCode, string &sCityName, TWindow* pMotherDialog, NSContexte* pContexte)
{
  //
  // Load the file
  //
  string sFileName = pContexte->PathName("FPER") + string("zipCodes.txt") ;

  ifstream inFile ;
  inFile.open(sFileName.c_str()) ;
  if (!inFile)
    return false ;

  int iCounter = 0 ;
  int iLoopThreshold = 100 ;

  VecteurString Libelles ;

  string sLine ;
  while (false == inFile.eof())
  {
		getline(inFile, sLine) ;

    size_t iPos = sLine.find(";") ;
    if (NPOS != iPos)
    {
      string sCityName = string(sLine, 0, iPos) ;
      string sCityZip  = string(sLine, iPos+1, strlen(sLine.c_str()) - iPos) ;

      strip(sCityName, stripBoth) ;
      strip(sCityZip, stripBoth) ;

      if (strlen(sCityZip.c_str()) < 5)
        sCityZip = string(5 - strlen(sCityZip.c_str()), '0') + sCityZip ;

      vraiemaj(&sCityName) ;

      if (sZipCode == sCityZip)
        Libelles.push_back(new string(sCityName)) ;
    }

    iCounter++ ;
    if (iCounter > iLoopThreshold)
    {
      iCounter = 0 ;
      pContexte->getSuperviseur()->getApplication()->PumpWaitingMessages() ;
    }
  }

  inFile.close() ;

  if (Libelles.empty())
    return false ;

  if (Libelles.size() == 1)
  {
    sCityName = *(Libelles[0]) ;
    return true ;
  }

  ChoixDansListeDialog* pListeDialog = new ChoixDansListeDialog(pMotherDialog, pContexte, &Libelles, sZipCode) ;
  if ((pListeDialog->Execute() == IDCANCEL) || (-1 == pListeDialog->itemChoisi))
  	return false ;

	int index = pListeDialog->itemChoisi ;
  sCityName = *(Libelles[index]) ;

  return true ;
}

void
PidsAdrZip(NSDlgFonction *pNSFct)
{
/*
try
{
  if (NULL == pNSFct || (NULL == pNSFct->pControle))
  	return ;

  BBItem* pBBItemRoot = pNSFct->pControle->getInterfaceElementItem() ;
  if (NULL == pBBItemRoot)

  // on r�cup�re le contexte du pBigBoss du BBItem root du dialogue
  // d'origine (cr�� � partir de l'archetype d'�dition d'adresse)
  NSContexte* pContexte = pNSFct->pControle->getInterfaceContext() ;
  string sSearch = string("") ;
  BBFilsItem* pBBFilsItem ;

  // La fonction, rattach�e � l'item Nom du SITE, a un pointeur
  // sur le pTransfert associ�, ce qui permet de r�cup�rer
  // la valeur du champ Edit pour la recherche.
  NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if (pTransfert && pTransfert->pTransfertMessage)
  {
    sSearch = pTransfert->pTransfertMessage->GetTexteLibre() ;
    pBBFilsItem = pTransfert->pBBFilsItem ;
  }
  else
  {
    erreur("Transfert non initialis� dans la fonction d'�dition d'adresse.", standardError, 0) ;
    return ;
  }

  if (sSearch == "")
  	return ;

  NSPatPathoArray PatPathoAdr(pContexte, graphObject) ;
	bool bGotCity = getCityFromZip(sSearch, &PatPathoAdr, pDialog, pContexte) ;

  if (false == bGotCity)
		return ;

  // on instancie la pPPTMerge qui fusionne avec pPPTEnCours de BBItem sur okFermerDialogue()
  //
  pBBItemRoot->pPPTMerge = new NSPatPathoArray(PatPathoAdr) ;

  // on lance la r�ouverture du dialogue
  //
  // pBBItemRoot->donneStatusDlg(NSDLGSTATUS_REINIT) ;
  // pDialog->CmOk() ;
}
catch (...)
{
	erreur("Exception PidsAdrZip.", standardError, 0) ;
	return ;
}
*/
}

void
PidsZipFillCity(NSDlgFonction *pNSFct)
{
try
{
  if (NULL == pNSFct || (NULL == pNSFct->pControle))
  	return ;

	// First, get zip code from current interface control
	//
	string sSearch = string("") ;

	NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if ((NULL != pTransfert) && (NULL != pTransfert->pTransfertMessage))
    sSearch = pTransfert->pTransfertMessage->GetTexteLibre() ;

  if (sSearch == "")
  	return ;

	// Then, find if a "city" interface control is available around
  //

	BBFilsItem* pZipFilsItem = pTransfert->pBBFilsItem ;
  if ((NULL == pZipFilsItem->getItemFather()) || (NULL == pZipFilsItem->getItemFather()->pBBFilsPere) || (NULL == pZipFilsItem->getItemFather()->pBBFilsPere->getItemFather()))
  	return ;

	string sZipPathway = pNSFct->pControle->getIdentite() ;
  string sZipLabel   = pZipFilsItem->getItemLabel() ;
  size_t iPos        = sZipPathway.rfind("LZIP01/�CL000") ;
  if (iPos == string::npos)
  	return ;

  string sCityPathway = string(sZipPathway, 0, iPos) + string("LCOMU1/�CL000") ;

	BBItem* pDialogItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (NULL == pDialogItem)
		return ;

	string retour ;
	BBFilsItem* pCityFils = RetournerValeurEdit(pDialogItem, sCityPathway, &retour, true) ;
	if (NULL == pCityFils)
		return ;

	// on r�cup�re le contexte du pBigBoss du BBItem root du dialogue
  // d'origine (cr�� � partir de l'archetype d'�dition d'adresse)
  //
  NSContexte* pContexte = pDialogItem->pBigBoss->pContexte ;

  string sCityName = string("") ;
  bool bGotCity = getCityFromZipTxt(sSearch, sCityName, pNSFct->pControle->getInterfacePointer(), pContexte) ;
  if ((false == bGotCity) || (string("") == sCityName))
		return ;

  ActiveChampEdit(pCityFils, sCityName) ;
}
catch (...)
{
	erreur("Exception PidsZipFillCity.", standardError, 0) ;
	return ;
}
}

void
SurfOnTheMap(NSDlgFonction *pNSFct)
{
try
{
  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
  	return ;
  BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (NULL == pItem)
  	return ;

  NSContexte* pContexte = pItem->pBigBoss->pContexte ;

  BBFilsItem* fils ;

	string sLigne1 ;
	fils = RetournerValeurEdit(pItem, string("LADL11/�CL000"), &sLigne1) ;
	string sLigne2 ;
	fils = RetournerValeurEdit(pItem, string("LADL21/�CL000"), &sLigne2) ;
	string sCP ;
	fils = RetournerValeurEdit(pItem, string("LVILL1/LZIP01/�CL000"), &sCP) ;
	string sVille ;
	fils = RetournerValeurEdit(pItem, string("LVILL1/LCOMU1/�CL000"), &sVille) ;
  string sCountry ;
	fils = RetournerValeurEdit(pItem, string("LVILL1/LPAYS1/�CL000"), &sCountry) ;

  string sWebLink = string("http://www.viamichelin.com/viamichelin/fra/dyn/controller/mapPerformPage?") ;

  string sAdress ;
  if (sLigne2 == string(""))
  	sAdress = sLigne1 ;
  else
  	sAdress = sLigne2 ;
  sWebLink += string("strAddress=") + texteWebLink(sAdress) ;
  sWebLink += string("&strLocation=") + texteWebLink(sVille) ;
  sWebLink += string("&strCP=") + texteWebLink(sCP) ;
  sWebLink += string("&strCountry=") + texteWebLink(sCountry) ;

  string sWebLink2 = string("http://maps.google.com/maps?q=") ;

  sWebLink2 += texteWebLink(sAdress) ;
  sWebLink2 += texteWebLink(string("  ") + sVille) ;
  sWebLink2 += texteWebLink(string("  ") + sCP) ;
  sWebLink2 += texteWebLink(string("  ") + sCountry) ;

  string sWebLinkToMap = sWebLink ;

  int iRandomNumber = rand() ;
  int iRandomDividedByTwo = iRandomNumber / 2 ;
  if (iRandomDividedByTwo * 2 == iRandomNumber)
  	sWebLinkToMap = sWebLink2 ;

  // http://maps.google.com/maps?q=15%2C%20Rue%20Hoche%20%20VERSAILLES%20%2078000%20
	// http://www.viamichelin.com/viamichelin/fra/dyn/controller/mapPerformPage?strAddress=143%2C%20rue%20de%20Saussure&strLocation=PARIS&strCP=75017&strCountry=

  ::ShellExecute(pContexte->GetMainWindow()->HWindow,
                  "open",
                  sWebLinkToMap.c_str(),
                  "",
                  "",
                  SW_SHOWNORMAL);
}
catch (...)
{
	erreur("Exception SurfOnTheMap.", standardError, 0) ;
	return ;
}
}

//
// Calcul de la surface corporelle
//
void CalcSC(NSDlgFonction *pNSFct)
{
  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
    return ;

  double dSC ;
  string sSC = "" ;
  BBFilsItem* fils ;
  BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;

	string sPoids ;
  fils = RetournerValeurEdit(pItem, string("VPOID1/2KG001/�N0;03"), &sPoids) ;
  string sTaille ;
  fils  = RetournerValeurEdit(pItem, string("VTAIL1/2CM001/�N0;03"), &sTaille) ;

  if ((sPoids != "") && (sTaille != ""))
  {
    dSC = 0.0001 * 71.84 * pow(StringToDouble(sPoids), 0.425) *
        								pow(StringToDouble(sTaille), 0.725) ;

    sSC = DoubleToString(&dSC, -1, 2) ;

    //activer le BBFilsItem qui pilote le champ QR
    string retour ;
    fils = RetournerValeurEdit(pItem, string("VSUCO1/2MCAR1/�N0;03"), &retour) ;
    if (fils)
      ActiveChampEdit(fils, sSC) ;
  }
}

//
// Prise de l'IPP actif
//
void GetIPP(NSDlgFonction *pNSFct)
{
	if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

	NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if (NULL == pTransfert)
		return ;

	BBFilsItem* fils = pTransfert->pBBFilsItem ;
  if (NULL == fils)
  	return ;

	if ((NULL == pNSFct->pBBItem) || (NULL == pNSFct->pBBItem->pBigBoss))
		return ;
	NSContexte* pContexte = pNSFct->pBBItem->pBigBoss->pContexte ;

	// At creation time, there is no patient
  if (NULL == pContexte->getPatient())
		return ;

  string sSite = pContexte->getSuperviseur()->getIppSite() ;
  if (string("") == sSite)
		return ;

	NSPatPathoArray pptIdent(pContexte) ;
	if (false == pContexte->getPatient()->pGraphPerson->getLibIDsPpt(&pptIdent))
		return ;

  string sCurrentIpp ;
  if (false == pContexte->getPatient()->pGraphPerson->IPPEnCours(&pptIdent, sSite, &sCurrentIpp))
  	return ;

	ActiveChampEdit(fils, sCurrentIpp) ;
}

//
// Prise de l'IPP local
//
void GetLocalIPP(NSDlgFonction *pNSFct, bool bManual)
{
	if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

	NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if (NULL == pTransfert)
		return ;

	BBFilsItem* fils = pTransfert->pBBFilsItem ;
  if (NULL == fils)
  	return ;

	if ((NULL == pNSFct->pBBItem) || (NULL == pNSFct->pBBItem->pBigBoss))
		return ;
	NSContexte* pContexte = pNSFct->pBBItem->pBigBoss->pContexte ;

	// At creation time, there is no patient
  if (NULL == pContexte->getPatient())
  {
    if (false == bManual)
    {
      // Automatic proposal of the next Id to attribute
      //
      string sNewIPP = GetNewIPP(pContexte) ;
      if (string("") == sNewIPP)
        return ;

      ActiveChampEdit(fils, sNewIPP) ;
    }
		return ;
  }

	NSPatPathoArray pptIdent(pContexte) ;
	if (false == pContexte->getPatient()->pGraphPerson->getLibIDsPpt(&pptIdent))
		return ;

  string sCurrentIpp ;
  if (false == pContexte->getPatient()->pGraphPerson->IPPEnCours(&pptIdent, string(""), &sCurrentIpp))
  	return ;

	ActiveChampEdit(fils, sCurrentIpp) ;
}

string GetNewIPP(NSContexte* pContexte)
{
  ifstream inFile ;

  // ATTENTION : ce fichier est obligatoirement avec la base des patients
  string sFichierCompteurs = pContexte->PathName("BGLO") + string("nauti.lus") ;

  inFile.open(sFichierCompteurs.c_str());  if (!inFile)
  {
    string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
    return string("") ;
  }

  string sNewValue = string("") ;
  string sRegulExp = string("") ;

  string sLine ;
  while (!inFile.eof())  {
    getline(inFile, sLine) ;
    if (string("") != sLine)
    {
      string sLabel = string("") ;
      string sValue = string("") ;

      size_t i = 0 ;
      while ((i < strlen(sLine.c_str())) && (sLine[i] != ' ') && (sLine[i] != '\t'))
        sLabel += sLine[i++] ;

      while ((i < strlen(sLine.c_str())) && ((sLine[i] == ' ') || (sLine[i] == '\t')))        i++ ;

      while (i < strlen(sLine.c_str()))        sValue += sLine[i++] ;

      sLabel = pseumaj(sLabel) ;
      if      (string("IPP") == sLabel)
        sNewValue = sValue ;
      else if (string("REGEX") == sLabel)
        sRegulExp = sValue ;
    }
  }
  inFile.close() ;

  string sNextVal = string("") ;

  // Elaborate the new value
  //
  if (string("d+") == sRegulExp)
  {
    int iVal = atoi(sNewValue.c_str()) ;
    iVal++ ;
    char szNextVal[34] ;
    itoa(iVal, szNextVal, 10) ;
    sNextVal = string(szNextVal) ;
  }

  ofstream outFile ;
  // On r��crit le nouveau fichier
  outFile.open(sFichierCompteurs.c_str()) ;
  if (!outFile)
  {
    string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningOutputFile") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
    return sNewValue ;
  }

  outFile << ( string("IPP   ") + sNextVal  + string("\n") ) ;
  outFile << ( string("REGEX ") + sRegulExp + string("\n") ) ;

  outFile.close() ;  return sNewValue ;}

//
// Calcul de l'Index de Masse Corporelle
//
void CalcIMC(NSDlgFonction *pNSFct)
{
	if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

	BBFilsItem* fils ;
	BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (!pItem)
		return ;

	string sPoids ;
	fils = RetournerValeurEdit(pItem, string("VPOID1/2KG001/�N0;03"), &sPoids) ;
  if (sPoids == "")
		return ;
	string sTaille ;
	fils  = RetournerValeurEdit(pItem, string("VTAIL1/2CM001/�N0;03"), &sTaille) ;
	if (sTaille == "")
		return ;

	string retour ;
	fils = RetournerValeurEdit(pItem, string("VIMC02/2KGM21/�N0;03"), &retour) ;
	if (!fils)
		return ;

	double dTaille = StringToDouble(sTaille) ;

	if (dTaille < 0.02)
		return ;

	double dIMC = StringToDouble(sPoids) / pow(StringToDouble(sTaille) / 100, 2) ;
	string sIMC = DoubleToString(&dIMC, -1, 2) ;

	ActiveChampEdit(fils, sIMC) ;
}

//
// Calcul du gain de poids de grossesse
//
void CalcWeigthGain(NSDlgFonction *pNSFct)
{
	if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

	BBFilsItem* fils ;
	BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (!pItem)
		return ;

	string sPoids ;
	fils = RetournerValeurEdit(pItem, string("VPOID1/2KG001/�N0;03"), &sPoids) ;
  if (string("") == sPoids)
		return ;
	string sPoidsDebutGrossesse ;
	fils  = RetournerValeurEdit(pItem, string("VPOIG1/2KG001/�N0;03"), &sPoidsDebutGrossesse) ;
	if (string("") == sPoidsDebutGrossesse)
		return ;

	string retour ;
	fils = RetournerValeurEdit(pItem, string("VGPOI1/2KG001/�N0;03"), &retour) ;
	if (!fils)
		return ;

	double dGP = StringToDouble(sPoids) - StringToDouble(sPoidsDebutGrossesse) ;
	string sGP = DoubleToString(&dGP, -1, 2) ;

	ActiveChampEdit(fils, sGP) ;
}

//
// Calcul de la consommation hebdomadaire d'alcool
//
void CalcVCHAL(NSDlgFonction *pNSFct)
{
	if (!pNSFct || !(pNSFct->pControle))
		return ;

	BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (!pItem)
		return ;

	string sConsoQuot ;
	BBFilsItem* fils = RetournerValeurEdit(pItem, string("VCOAL1/2VVIN1/�N0;03"), &sConsoQuot) ;
	if (sConsoQuot == "")
		return ;
	string sFrequency ;
	fils  = RetournerValeurEdit(pItem, string("VFREQ1/2JPSE1/�N0;03"), &sFrequency) ;
	if (sFrequency == "")
		return ;

  string retour ;
	fils = RetournerValeurEdit(pItem, string("VCHAL1/2VVAS1/�N0;03"), &retour) ;
	if (!fils)
		return ;

	double dConsoHebdo = StringToDouble(sConsoQuot) * StringToDouble(sFrequency) ;
	string sConsoHebdo = DoubleToString(&dConsoHebdo, -1, 0) ;

	//activer le BBFilsItem qui pilote le champ
	ActiveChampEdit(fils, sConsoHebdo) ;
}

//
// Calcul de la dur�e d'arr�t du tabac � partir de la date d'arr�t
//
void CalcVDATA(NSDlgFonction *pNSFct)
{
	if (!pNSFct || !(pNSFct->pControle))
		return ;

	BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (!pItem)
		return ;

	string sDateArret ;
	BBFilsItem* fils = RetournerValeurEdit(pItem, string("KARRE1/2DA011/�D0;10"), &sDateArret) ;
	if (sDateArret == "")
		return ;

  string retour ;
	fils = RetournerValeurEdit(pItem, string("VDATA1/2DAT31/�N0;03"), &retour) ;
	if (!fils)
		return ;

	NVLdVTemps tEndDate ;
	if (!(tEndDate.initFromDate(sDateArret)))
		return ;

	NVLdVTemps tNow ;
	tNow.takeTime() ;

  unsigned long lStopDays = tNow.daysBetween(tEndDate) ;
	double dNbYearsSinceEnd = double(lStopDays) / double(365.25) ;

	string sDureeArret = DoubleToString(&dNbYearsSinceEnd, -1, 2) ;

	//activer le BBFilsItem qui pilote le champ
	ActiveChampEdit(fils, sDureeArret) ;
}

//
// Calcul le LDL � partir de Friedwald, en grammes par litre
//
void CalcFriedwaldGpl(NSDlgFonction *pNSFct)
{
	if (!pNSFct || !(pNSFct->pControle))
		return ;

	BBFilsItem* fils ;
	BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (!pItem)
		return ;

	string sTrigly ;
	fils = RetournerValeurEdit(pItem, string("VTRIG2/2GPAL1/�N0;03"), &sTrigly) ;
  if (sTrigly == "")
		return ;

	// V�rifier Trigglyc�rides < 4 g/l
  //
  double dTrigly = StringToDouble(sTrigly) ;
  if (dTrigly >= 4)
		return ;

	string sCholTotal ;
	fils  = RetournerValeurEdit(pItem, string("VCHOL1/2GPAL1/�N0;03"), &sCholTotal) ;
	if (sCholTotal == "")
		return ;

	string sHDLChol ;
	fils  = RetournerValeurEdit(pItem, string("VCHO02/2GPAL1/�N0;03"), &sHDLChol) ;
	if (sHDLChol == "")
		return ;

	string retour ;
	fils = RetournerValeurEdit(pItem, string("VCHO12/2GPAL1/�N0;03"), &retour) ;
	if (!fils)
		return ;

	double dLDL = StringToDouble(sCholTotal) - StringToDouble(sHDLChol) - (dTrigly / 5) ;
	string sLDL = DoubleToString(&dLDL, -1, 2) ;

	ActiveChampEdit(fils, sLDL) ;

	// Remettre � z�ro l'�ventuelle valeur exprim�e en mmol/l
	fils = RetournerValeurEdit(pItem, string("VCHO12/2MMOL1/�N0;03"), &retour) ;
	if (!fils)
		return ;
	ActiveChampEdit(fils, "") ;
}

//
// Calcul la micro-albuminurie par 24 heures
//
void CalcMicroAlb24(NSDlgFonction *pNSFct)
{
	if (!pNSFct || !(pNSFct->pControle))
		return ;

	BBFilsItem* fils ;
	BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (!pItem)
		return ;

	string sMicroAlb ;
	fils = RetournerValeurEdit(pItem, string("VM8AL1/2MGPL1/�N0;03"), &sMicroAlb) ;
  if (sMicroAlb == "")
		return ;

	string sVolUrine24 ;
	fils  = RetournerValeurEdit(pItem, string("VUR241/2ML001/�N0;03"), &sVolUrine24) ;
	if (sVolUrine24 == "")
		return ;

	string retour ;
	fils = RetournerValeurEdit(pItem, string("VM8AL1/2MG241/�N0;03"), &retour) ;
	if (!fils)
		return ;

	double dMA24 = StringToDouble(sMicroAlb) * (StringToDouble(sVolUrine24) / 1000) ;
	string sMicroAlb24 = DoubleToString(&dMA24, -1, 2) ;

	ActiveChampEdit(fils, sMicroAlb24) ;
}

//
// Calcul de la consommation de sel
//
void CalcConsoSel(NSDlgFonction *pNSFct)
{
	if (!pNSFct || !(pNSFct->pControle))
		return ;

	BBFilsItem* fils ;
	BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (!pItem)
		return ;

	string sNatriurie24 ;
	fils = RetournerValeurEdit(pItem, string("VNATQ3/2ME241/�N0;03"), &sNatriurie24) ;
  if (sNatriurie24 == "")
		return ;

	string retour ;
	fils = RetournerValeurEdit(pItem, string("VCSEL1/2GR241/�N0;03"), &retour) ;
	if (!fils)
		return ;

	double dConso = StringToDouble(sNatriurie24) / 17 ;
	string sConsoSel24 = DoubleToString(&dConso, -1, 2) ;

	ActiveChampEdit(fils, sConsoSel24) ;
}

//
// Calcul de la formule de Cockroft � partir d'une natriurie en mg/l
//
void CalcCockroftMGPL(NSDlgFonction *pNSFct)
{
	if (!pNSFct || !(pNSFct->pControle))
		return ;

	BBFilsItem* fils ;
	BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (!pItem)
		return ;

	string sCreatininemie ;
	fils = RetournerValeurEdit(pItem, string("VCREA1/2MGPL1/�N0;03"), &sCreatininemie) ;
  if (sCreatininemie == "")
		return ;

	// On cherche le poids en repartant de la racine
	string sPoids ;
	fils = RetournerValeurEdit(pItem, string("VPOID1/2KG001/�N0;03"), &sPoids, true) ;
  if (sPoids == "")
		return ;

  // On cherche l'�ge
  NSContexte* pContexte = pItem->pBigBoss->pContexte ;
  NSPatientChoisi* pPat = pContexte->getPatient() ;
  if (!pPat)
		return ;

	char szBirthDate[9] ;
	if (!(pPat->donneNaissance(szBirthDate)))
		return ;
  char szCurrentDate[9] ;
	donne_date_duJour(szCurrentDate) ;
	int	iAge = donne_age(szCurrentDate, szBirthDate) ;

	string retour ;
	fils = RetournerValeurEdit(pItem, string("VCLAM1/2MLPM1/�N0;03"), &retour) ;
	if (!fils)
		return ;

	// ANAES
	//
	// chez l�homme :
	// DFG (ml/min) = [(140-�ge)] x poids / 7,2 x cr�atinin�mie en mg/l]
	// chez la femme :
	// DFG (ml/min) = [(140-�ge)] x poids / 7,2 x cr�atinin�mie en mg/l] x 0,85

	double dCorrectingFactor = 1 ;
	if (pPat->estMasculin())
		dCorrectingFactor = 1 ;
	else if (pPat->estFeminin())
		dCorrectingFactor = 0.85 ;

	double dClairance = (140 - double(iAge)) * StringToDouble(sPoids) / (StringToDouble(sCreatininemie) * 7.2) ;
  dClairance = dCorrectingFactor * dClairance ;
	string sClairance = DoubleToString(&dClairance, -1, 2) ;

	ActiveChampEdit(fils, sClairance) ;
}

//
// Classification automatique � partir du contenu d'un champ Edit
//
void Classify(NSDlgFonction *pNSFct, bool bOneTopic)
{
	if ((NULL == pNSFct) || (NULL == pNSFct->pControle) || (NULL == pNSFct->pControle->getTransfert()))
		return ;

  BBFilsItem* pFilsItem = pNSFct->pControle->getTransfert()->pBBFilsItem ;
  if (!pFilsItem)
  	return ;

  //
  // Getting the text from edit control
  //
  NSEdit* pEdit = (static_cast<NSEdit *>(pNSFct->pControle->getControle())) ;
  if (!pEdit)
  	return ;

  int iTxtBuffLen = pEdit->GetTextLen() ;

  if (iTxtBuffLen == 0)
  	return ;

  char far* szTxtBuff = new char[iTxtBuffLen+1] ;
  pEdit->GetText(szTxtBuff, iTxtBuffLen + 1) ;

  string sCapturedText = string(szTxtBuff) ;
  delete[] szTxtBuff ;

  //
  // Finding the proper classification
  //
  string sChemin = pFilsItem->getItemFather()->sLocalisation ;

  NSContexte* pContexte = pNSFct->pBBItem->pBigBoss->pContexte ;
  NSEpisodus* pEpisodus = pContexte->getSuperviseur()->getEpisodus() ;

  PrinciplesArray* pPrincipes = pEpisodus->pPrincipes ;
  if (!pPrincipes)
  	return ;

  string sPostCase = string("") ;
  ClassificationPrinciple* pPrincipe = pPrincipes->trouvePrincipe(sChemin, sPostCase) ;

  //
  // Ou demander
  //
  if (!pPrincipe)
  	return ;

  //
  // Puis trouver le code
  //
  string sClassif = pPrincipe->sClassification ;

  string sResO = "" ;
  string sResP = "" ;
  string sResI = "" ;
  string sRes3 = "" ;

	ParseSOAP SOAPParser(pContexte, &sClassif) ;
  SOAPParser.computeParsing(&sCapturedText, &sChemin, &sResO, &sResP, &sResI, &sRes3) ;

  //
  // On trouve le code
  //
  classifExpert* pExpert = pEpisodus->pClassifExpert ;
  if (!pExpert)
      return ;

  NSEpiClassifInfoArray arrayClassif ;

  ElemSetArray* pElemDomain = 0 ;
  //
  // On instancie le domaine
  // Instanciating the domain
  //
  string sDomain  = sResP ;
  ParseCategory Parser(pExpert->donneCodeSize(sClassif), sClassif,
                                             pExpert->donnePattern(sClassif)) ;
  pElemDomain = Parser.DefDomain(sDomain) ;
  //
  // On trouve les codes qui correspondent au domaine
  // Finding the codes that belong to the domain
  //
  string sCaseSens ;
  pContexte->getDico()->donneCodeSens(&(pPrincipe->sCase), &sCaseSens) ;

  pExpert->fillList(sClassif, pElemDomain, &arrayClassif, sCaseSens) ;

  if (pElemDomain)
      delete pElemDomain ;

	SOAPObject* pSOAPObj = new SOAPObject(pFilsItem->getItemLabel(), sResP, sClassif, 0, pFilsItem) ;
#ifndef _EXT_CAPTURE
	NSCapture* pCapture = new NSCapture(pContexte) ;
#else
	NSCapture* pCapture = new NSCapture() ;
#endif

	pCapture->sClassifResultO = sResO ;
  pCapture->sClassifResultP = sResP ;
  pCapture->sClassifResultI = sResI ;

  pSOAPObj->pCaptElemnt = pCapture ;
  pSOAPObj->sCase       = sCaseSens ;

  //
  // Sending to the SOAP tank
  //
  NSToDoTask* pTask = new NSToDoTask ;

	pTask->sWhatToDo = "AddToSOAP" ;
	pTask->pPointer1 = (void*)pSOAPObj ;

  pContexte->getSuperviseur()->addToDo(pTask) ;

/*
  if (!bOneTopic)
  {
    // Traitement des retours chariot
    size_t iCR = sCapturedText.find('\n') ;
    while (iCR != string::npos)
    {
      string sSubText = string(sCapturedText, 0, iCR) ;
      strip(sSubText, stripBoth, '\r') ;
      strip(sSubText, stripBoth) ;
      sCapturedText = string(sCapturedText, iCR+1, strlen(sCapturedText.c_str())-iCR-1) ;
      strip(sCapturedText, stripBoth, '\r') ;
      strip(sCapturedText, stripBoth) ;

      if (sSubText != "")
      {
        NSCapture * pCapt = new NSCapture(pContexte, pModel->sCorrespondence, sSubText, pModel->sClassifier, pModel->sUnit) ;
        pCaptArray->ajouter(pCapt) ;

        // Attention : la fonction "ajouter" peut supprimer pCapt s'il doublonne un �l�ment existant
        if (pCapt && (pCapt->sClassifier != ""))
          addToSOAP(pCapt) ;
      }
      iCR = sCapturedText.find('\n') ;
    }
  }

	if (sCapturedText != "")
	{
		NSCapture * pCapt = new NSCapture(pContexte, pModel->sCorrespondence, sText, pModel->sClassifier, pModel->sUnit) ;
		pCaptArray->ajouter(pCapt) ;

		// Attention : la fonction "ajouter" peut supprimer pCapt s'il doublonne un �l�ment existant
		if (pCapt && (pCapt->sClassifier != ""))
			addToSOAP(pCapt) ;
	}


  SOAPObject* pSOAPObj = new SOAPObject(sLibellePere, szTxtBuff, sLexique, 100, (*pptIt)->pDonnees->getNode()) ;
  pSOAPObj->sCase = sCase ;  pSuper->getEpisodus()->addToSOAP(pSOAPObj) ;

*/
}

void initFromCurrentHealthProblems(NSDlgFonction *pNSFct)
{
	if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

  // Only treeWindows are accepted
  //
  if (isTreeWindow != pNSFct->pControle->getType())
		return ;
	NSTreeWindow* pTreeWin = static_cast<NSTreeWindow*>(pNSFct->pControle->getControle()) ;
  if (NULL == pTreeWin)
		return ;

	// Make certain we can get the context
  //
	if ((NULL == pNSFct->pBBItem) || (NULL == pNSFct->pBBItem->pBigBoss))
		return ;

	if (false == pNSFct->pBBItem->pBigBoss->getPatPatho()->empty())
  	return ;

	NSContexte* pContexte = pNSFct->pBBItem->pBigBoss->pContexte ;

  // Getting the Health concerns tree from patient's graph
  //
	string sPath = string("ZPOMR/0PRO1") ;

  PathsList que ;
  string sAnswerDate ;
  que.push_back(new string(sPath)) ;  // PathsList's destructor makes delete

  BB1BBInterface* interfa = pContexte->getSuperviseur()->getBBinterface() ;

  NSPatPathoArray* respat = interfa->SearchInPatientFolder(&que, &sAnswerDate);

  // Nothing found in patient's record - we leave
  //
  if (NULL == respat)
  	return ;

	if (true == respat->empty())
	{
  	delete respat ;
    return ;
	}

  PatPathoIter iter = respat->begin() ;
  string sRootSens = (*iter)->getLexiqueSens(pContexte) ;
  if (string("0PRO1") != sRootSens)
		return ;

  NSPatPathoArray PPT(pContexte) ;

  string sHealthConcernCode = string("") ;

  NVLdVTemps tDateOuverture ;
	NVLdVTemps tDateFermeture ;
  NVLdVTemps tNow ;
	tNow.takeTime() ;

  for ( ; respat->end() != iter; iter++)
  {
  	int iCol = (*iter)->getColonne() ;
    if (1 == iCol)
    {
    	if (string("") != sHealthConcernCode)
    		if ((tDateOuverture <= tNow) && ((tDateFermeture.estNoLimit()) || (tDateFermeture >= tNow)))
					PPT.ajoutePatho(sHealthConcernCode, 0) ;

    	sHealthConcernCode = (*iter)->getLexique() ;
      tDateOuverture.init() ;
			tDateFermeture.setNoLimit() ;
    }
    else if (2 == iCol)
    {
      string sSens = (*iter)->getLexiqueSens(pContexte) ;

    	// Dates
      if ((string("KOUVR") == sSens) || (string("KFERM") == sSens))
      {
      	iter++ ;
        if (respat->end() == iter)
        	break ;

        string sUnite  = "";
        string sFormat = "";
        string sValeur = "";
        string sTemp   = "";
        string sValueLex = (*iter)->getLexique() ;
        if ('�' == sValueLex[0])
        {
        	sFormat = (*iter)->getLexiqueSens(pContexte) ;
          sValeur = (*iter)->getComplement() ;
          sUnite  = (*iter)->getUnitSens(pContexte) ;

          // sFormat est du type �D0;03
          if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) &&
                          (sValeur != ""))
          {
          	if ((sUnite == "2DA01") || (sUnite == "2DA02"))
            {
            	if (sSens == "KOUVR")
              	tDateOuverture.initFromDate(sValeur) ;
              else
              	if (sSens == "KFERM")
                	tDateFermeture.initFromDate(sValeur) ;
            }
          }
        }
      }
    }
  }

  if (string("") != sHealthConcernCode)
		if ((tDateOuverture <= tNow) && ((tDateFermeture.estNoLimit()) || (tDateFermeture >= tNow)))
    	PPT.ajoutePatho(sHealthConcernCode, 0) ;

	delete respat ;

  if (true == PPT.empty())
		return ;

	NSCutPaste saveCP(pContexte) ;
  NSCutPaste* pActiveCP = pContexte->getSuperviseur()->pBufCopie ;
  saveCP = *pActiveCP ;

  pActiveCP->vider() ;
	*(pActiveCP->pPatPatho) = PPT ;

	pTreeWin->DragApres(NULL, string("COPIE")) ;

	*pActiveCP = saveCP ;
}

void GetPrescriptionCrossover(NSDlgFonction *pNSFct)
{
  NSSuper *pSuper = pNSFct->pContexte->getSuperviseur() ;

  string sTraceText = string("Entering GetPrescriptionCrossover") ;
  pSuper->trace(&sTraceText, 1, NSSuper::trDetails) ;

  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

	BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (NULL == pItem)
		return ;

	string sStartingDate ;
	BBFilsItem* fils = RetournerValeurEdit(pItem, string("N00001/KPHAT1/KOUVR1/2DA011/�D0;10"), &sStartingDate) ;
	if ((NULL == fils) || (string("") == sStartingDate))
		return ;

  sTraceText = string("GetPrescriptionCrossover : treatment starting date = ") + sStartingDate ;
  pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;

  string sRetour ;
	BBFilsItem* pTargetFils = RetournerValeurEdit(pItem, string("N00001/KPHAT1/VDUCH1/2DAT01/�N0;03"), &sRetour) ;
	if (NULL == pTargetFils)
		return ;

  NVLdVTemps tStartingDate ;
	if (false == tStartingDate.initFromDate(sStartingDate))
		return ;

  NSSmallBrother* pBigBoss = pItem->pBigBoss ;
  if (NULL == pBigBoss)
    return ;

  NSHistoryValManagementArray histoManager(pBigBoss->pContexte, NSHistoryValManagementArray::histTypeDate) ;

  // Getting the accurate path to look for this drug's prescription ending
  //
  // Of course, we could find the KFERM1 element and get its path, but since
  // it is not used otherwise in this function (and could even not exist), we
  // get the KOUVR1 path and adapt it
  //
  string sAccurateClosingPath = fils->getLocalisation() ;
  size_t iDrugPhaseCursor = sAccurateClosingPath.find("N0000/KPHAT/KOUVR") ;
  if (string::npos == iDrugPhaseCursor)
    return ;

  string sItemValue = string(sAccurateClosingPath, 0, iDrugPhaseCursor) + string("N0000/KPHAT/KFERM") ;

  sTraceText = string("GetPrescriptionCrossover : get history for path ") + sItemValue ;
  pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;

  histoManager.ChargeHistoryValueItem(sItemValue) ;
  if (histoManager.empty())
  	return ;

	sort(histoManager.begin(), histoManager.end(), sortByDateSup) ;

  NSHistoryValManagementIter histoIt = histoManager.begin() ;
  string sPreviousEndingDate = (*histoIt)->getValue() ;

  NVLdVTemps tPreviousEndingDate ;
	if (false == tPreviousEndingDate.initFromDate(sPreviousEndingDate))
		return ;

  sTraceText = string("GetPrescriptionCrossover : previous closing date = ") + sPreviousEndingDate ;
  pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;

  int iDeltaDays = 0 ;

  //
  // Let's be accurate here :
  //    - tPreviousEndingDate : last day WITH the drug
  //    - tStartingDate       : first day WITH the drug
  // So, if tPreviousEndingDate == tStartingDate, there is a 1 day crossover
  //
  if (tStartingDate > tPreviousEndingDate)
  {
    iDeltaDays = (int) tStartingDate.daysBetween(tPreviousEndingDate) ;
    iDeltaDays = - iDeltaDays + 1 ;
  }
  else
    iDeltaDays = (int) tPreviousEndingDate.daysBetween(tStartingDate) + 1 ;

  char szCOvalue[33] ;
  itoa(iDeltaDays, szCOvalue, 10) ;

  sTraceText = string("GetPrescriptionCrossover : number of days between those dates = ") + string(szCOvalue) ;
  pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;

	ActiveChampEdit(pTargetFils, string(szCOvalue)) ;

  sTraceText = string("Leaving GetPrescriptionCrossover") ;
  pSuper->trace(&sTraceText, 1, NSSuper::trDetails) ;
}

void SetPrescriptionCrossover(NSDlgFonction *pNSFct)
{
  NSSuper *pSuper = pNSFct->pContexte->getSuperviseur() ;

  string sTraceText = string("Entering SetPrescriptionCrossover") ;
  pSuper->trace(&sTraceText, 1, NSSuper::trDetails) ;

  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

	BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (NULL == pItem)
		return ;

	string sStartingDate ;
	BBFilsItem* fils = RetournerValeurEdit(pItem, string("N00001/KPHAT1/KOUVR1/2DA011/�D0;10"), &sStartingDate) ;
	if ((NULL == fils) || (string("") == sStartingDate))
		return ;

  string sCrossover ;
	BBFilsItem* pTargetFils = RetournerValeurEdit(pItem, string("N00001/KPHAT1/VDUCH1/2DAT01/�N0;03"), &sCrossover) ;
	if (NULL == pTargetFils)
		return ;

  sTraceText = string("SetPrescriptionCrossover : crossover is set to ") + sCrossover ;
  pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;

  NVLdVTemps tStartingDate ;
	if (false == tStartingDate.initFromDate(sStartingDate))
		return ;

  NSSmallBrother* pBigBoss = pItem->pBigBoss ;
  if (NULL == pBigBoss)
    return ;

  NSHistoryValManagementArray histoManager(pBigBoss->pContexte, NSHistoryValManagementArray::histTypeDate) ;

  // Getting the accurate path to look for this drug's prescription ending
  //
  // Of course, we could find the KFERM1 element and get its path, but since
  // it is not used otherwise in this function (and could even not exist), we
  // get the KOUVR1 path and adapt it
  //
  string sAccurateClosingPath = fils->getLocalisation() ;
  size_t iDrugPhaseCursor = sAccurateClosingPath.find("N0000/KPHAT/KOUVR") ;
  if (string::npos == iDrugPhaseCursor)
    return ;

  string sItemValue = string(sAccurateClosingPath, 0, iDrugPhaseCursor) + string("N0000/KPHAT/KFERM") ;

  sTraceText = string("SetPrescriptionCrossover : get history for path ") + sItemValue ;
  pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;

  histoManager.ChargeHistoryValueItem(sItemValue) ;
  if (histoManager.empty())
  	return ;

	sort(histoManager.begin(), histoManager.end(), sortByDateSup) ;

  NSHistoryValManagementIter histoIt = histoManager.begin() ;
  string sPreviousEndingDate = (*histoIt)->getValue() ;

  sTraceText = string("SetPrescriptionCrossover : previous closing date = ") + sPreviousEndingDate ;
  pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;

  NVLdVTemps tPreviousEndingDate ;
	if (false == tPreviousEndingDate.initFromDate(sPreviousEndingDate))
		return ;

  int iCrossover = atoi(sCrossover.c_str()) ;
  if ((0 == iCrossover) && (string("0") != sCrossover))
    return ;

  // Remember that if tPreviousEndingDate == tStartingDate, there is a 1 day crossover
  //
  int iDeltaDays = 1 - iCrossover ;

  tPreviousEndingDate.ajouteJours(iDeltaDays) ;
  string sNewStartingDate = tPreviousEndingDate.donneDate() ;

  sTraceText = string("SetPrescriptionCrossover : calculated prescription date = ") + sNewStartingDate ;
  pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;

	ActiveChampEdit(fils, sNewStartingDate) ;

  sTraceText = string("Leaving SetPrescriptionCrossover") ;
  pSuper->trace(&sTraceText, 1, NSSuper::trDetails) ;
}

// From DDR, set DDR calculated Conception date
//
void SetGestationDDR(NSDlgFonction *pNSFct)
{
  NSSuper *pSuper = pNSFct->pContexte->getSuperviseur() ;

  string sTraceText = string("Entering SetGestationDDR") ;
  pSuper->trace(&sTraceText, 1, NSSuper::trDetails) ;

  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

  BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (NULL == pItem)
		return ;

  NVLdVTemps tConception ;
  tConception.init() ;

  // First, we check that there is some information available
  //
  string sDDR ;
	BBFilsItem* filsDDR = RetournerValeurEdit(pItem, string("0CAGE1/KDERE1/2DA011/�D0;10"), &sDDR) ;
  if ((NULL == filsDDR) || (string("") == sDDR))
  {
    string sTraceText = string("SetGestationDDR : No DDR found... leaving") ;
    pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;
    return ;
  }

  // Then, we check that there is an edit field to host the calculated date
  //
  string sConceptionDate ;
	BBFilsItem* filsConceptionDate = RetournerValeurEdit(pItem, string("0CAGE1/KDATC1/3CDDR1/2DA011/�D0;10"), &sConceptionDate) ;
  if (NULL == filsConceptionDate)
  {
    string sTraceText = string("SetGestationDDR : No control found for DRDR conception date... leaving") ;
    pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;
    return ;
  }

  NVLdVTemps tDDR ;
  tDDR.initFromDate(sDDR) ;

  tConception = tDDR ;
  tConception.ajouteJours(14) ;

  sConceptionDate = tConception.donneDate() ;
  ActiveChampEdit(filsConceptionDate, sConceptionDate) ;

  sTraceText = string("SetGestationDDR : DRDR conception date set (") + sConceptionDate + string("). Job done. Leaving") ;
  pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;
}

// From DDR calculated Conception date, set the Conception date (if no echo)
//
void SetGestationDatesDDR(NSDlgFonction *pNSFct)
{
  NSSuper *pSuper = pNSFct->pContexte->getSuperviseur() ;

  string sTraceText = string("Entering SetGestationDatesDDR") ;
  pSuper->trace(&sTraceText, 1, NSSuper::trDetails) ;

  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

  BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (NULL == pItem)
		return ;

  // First, we check that there is a DDR conception date available
  //
  string sDDRConceptionDate ;
	BBFilsItem* filsDDRDate = RetournerValeurEdit(pItem, string("0CAGE1/KDATC1/3CDDR1/2DA011/�D0;10"), &sDDRConceptionDate) ;
  if ((NULL == filsDDRDate) || (string("") == sDDRConceptionDate))
  {
    string sTraceText = string("SetGestationDatesDDR : DDR conception date not found... leaving") ;
    pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;
    return ;
  }

  // First, we check that no echographic information is available
  //
  string sEchoDate ;
	BBFilsItem* filsEchoDate = RetournerValeurEdit(pItem, string("0CAGE1/KDATC1/3EEDC1/2DA011/�D0;10"), &sEchoDate) ;
  if ((NULL != filsEchoDate) && (string("") != sEchoDate))
  {
    string sTraceText = string("SetGestationDatesDDR : Echo date found... leaving") ;
    pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;
    return ;
  }

  // Then, we check that there is an edit field to host the calculated date
  //
  string sConceptionDate ;
	BBFilsItem* filsConceptionDate = RetournerValeurEdit(pItem, string("0CAGE1/KDATC1/2DA011/�D0;10"), &sConceptionDate) ;
  if (NULL == filsConceptionDate)
  {
    string sTraceText = string("SetGestationDatesDDR : No control found for conception date... leaving") ;
    pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;
    return ;
  }

  ActiveChampEdit(filsConceptionDate, sDDRConceptionDate) ;

  sTraceText = string("SetGestationDatesDDR : Conception date set (") + sDDRConceptionDate + string("). Job done. Leaving") ;
  pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;
}

// From Echographic Conception date, set the Conception date
//
void SetGestationDatesEcho(NSDlgFonction *pNSFct)
{
  NSSuper *pSuper = pNSFct->pContexte->getSuperviseur() ;

  string sTraceText = string("Entering SetGestationDatesDDR") ;
  pSuper->trace(&sTraceText, 1, NSSuper::trDetails) ;

  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

  BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (NULL == pItem)
		return ;

  // First, we check that echographic information is available
  //
  string sEchoDate ;
	BBFilsItem* filsEchoDate = RetournerValeurEdit(pItem, string("0CAGE1/KDATC1/3EEDC1/2DA011/�D0;10"), &sEchoDate) ;
  if ((NULL == filsEchoDate) || (string("") == sEchoDate))
  {
    string sTraceText = string("SetGestationDatesEcho : No echo date found... leaving") ;
    pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;
    return ;
  }

  // Then, we check that there is an edit field to host the calculated date
  //
  string sConceptionDate ;
	BBFilsItem* filsConceptionDate = RetournerValeurEdit(pItem, string("0CAGE1/KDATC1/2DA011/�D0;10"), &sConceptionDate) ;
  if (NULL == filsConceptionDate)
  {
    string sTraceText = string("SetGestationDatesEcho : No control found for conception date... leaving") ;
    pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;
    return ;
  }

  ActiveChampEdit(filsConceptionDate, sEchoDate) ;

  sTraceText = string("SetGestationDatesEcho : Conception date set (") + sEchoDate + string("). Job done. Leaving") ;
  pSuper->trace(&sTraceText, 1, NSSuper::trSubDetails) ;
}

void SetGestationDates(NSDlgFonction *pNSFct)
{
  NSSuper *pSuper = pNSFct->pContexte->getSuperviseur() ;

  string sTraceText = string("Entering SetAgeGestSA") ;
  pSuper->trace(&sTraceText, 1, NSSuper::trDetails) ;

  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

  BBItem* pItem = pNSFct->pControle->getInterfaceElementItem() ;
  if (NULL == pItem)
		return ;

  NVLdVTemps tConception ;
  tConception.init() ;

  string sDateConception ;
	BBFilsItem* filsConception = RetournerValeurEdit(pItem, string("0CAGE1/KDATC1/2DA011/�D0;10"), &sDateConception) ;

  if ((NULL != filsConception) && (string("") != sDateConception))
    tConception.initFromDate(sDateConception) ;
  else
  {
	  string sDDR ;
	  BBFilsItem* filsDDR = RetournerValeurEdit(pItem, string("0CAGE1/KDERE1/2DA011/�D0;10"), &sDDR) ;

    if ((NULL == filsDDR) || (string("") == sDDR))
		  return ;

    NVLdVTemps tDDR ;
    tDDR.initFromDate(sDDR) ;

    tConception = tDDR ;
    tConception.ajouteJours(14) ;
  }

  int iAgeSA    = 0 ;
  int iAgeJours = 0 ;

  NVLdVTemps tNow ;
  tNow.takeTime() ;

  unsigned long lDeltaDays = tNow.daysBetween(tConception) ;

  iAgeJours = int(lDeltaDays) ;

  double dAgeSem = double(iAgeJours) / 7 ;
  int iAgeSem = int(floor(dAgeSem)) ;

  iAgeSA = iAgeSem + 2 ;

  NVLdVTemps tAccouchement = tConception ;
  // tAccouchement.ajouteMois(9) ;
  tAccouchement.ajouteJours(266) ;

  string sBirthDate ;
	BBFilsItem* filsBirth = RetournerValeurEdit(pItem, string("0CAGE1/KACCO1/2DA011/�D0;10"), &sBirthDate) ;
	if (NULL != filsBirth)
  {
    sBirthDate = tAccouchement.donneDate() ;
    ActiveChampEdit(filsBirth, sBirthDate) ;
  }

  char szAgeInDays[33] ;
  itoa(iAgeJours, szAgeInDays, 10) ;

  string sAgeInDay ;
	BBFilsItem* filsAgeDays = RetournerValeurEdit(pItem, string("0CAGE1/KAGFO3/2DAA01/�N0;03"), &sAgeInDay) ;
	if (NULL != filsAgeDays)
    ActiveChampEdit(filsAgeDays, string(szAgeInDays)) ;

  char szAgeInSA[33] ;
  itoa(iAgeSA, szAgeInSA, 10) ;

  string sAgeInSA ;
	BBFilsItem* filsAgeSA = RetournerValeurEdit(pItem, string("0CAGE1/KAGFO3/2DAA12/�N0;03"), &sAgeInSA) ;
	if (NULL != filsAgeSA)
    ActiveChampEdit(filsAgeSA, string(szAgeInSA)) ;
}

void CheckSurgicalHistory(NSDlgFonction *pNSFct, string sCutConcept)
{
  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

  // Is the control already "activated"?
  //
  NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if ((NULL == pTransfert) || (true == pTransfert->iActif))
		return ;

  // Get element's path beyond "surgical history" (QANTC)
  //
  BBFilsItem*	pBBFils = pTransfert->pBBFilsItem ;
  if (NULL == pBBFils)
		return ;

  string sElementPath = pBBFils->getLocalisation() ;

  // Find such an element in a previous report
  //
  NSSearchStruct searchStruct(NSSearchStruct::modeAsIs,
		                            NSSearchStruct::typeAsIs ,                                NSSearchStruct::positLastInTime,                                1, "", "", NULL) ;

  bool bOk = pNSFct->pContexte->getPatient()->ChercheChemin(sElementPath, &searchStruct) ;
  if ((bOk) && (false == searchStruct.aFoundNodes.empty()))
  {
    pTransfert->Active() ;
    return ;
  }

  // Find such an element in the synthesis
  //
  size_t iQuantcPos = sElementPath.find(sCutConcept) ;
  if (NPOS == iQuantcPos)
    return ;

  size_t iElmtPathLen = strlen(sElementPath.c_str()) ;
  string sDetails = string("") ;
  iQuantcPos = sElementPath.find(cheminSeparationMARK, iQuantcPos + 1) ;
  if ((NPOS != iQuantcPos) && (iQuantcPos < iElmtPathLen - 1))
    sDetails = string(sElementPath, iQuantcPos + 1, iElmtPathLen - iQuantcPos - 1) ;

  string sSynthesisPath = string("ZSYNT/QANTP/QANTC/") + sDetails ;

  NSSearchStruct searchStruct2(NSSearchStruct::modeAsIs,
		                            NSSearchStruct::typeAsIs ,                                NSSearchStruct::positLastInTime,                                1, "", "", NULL) ;

  bOk = pNSFct->pContexte->getPatient()->ChercheChemin(sSynthesisPath, &searchStruct2) ;
  if ((bOk) && (false == searchStruct2.aFoundNodes.empty()))
    pTransfert->Active() ;
}

void CheckSurgicalHistoryChapter(NSDlgFonction *pNSFct, string sCutConcept)
{
try
{
  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

  // Is the control already "activated"?
  //
  NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if ((NULL == pTransfert) || (true == pTransfert->iActif))
		return ;

  // Get element's path beyond "surgical history" (QANTC)
  //
  BBFilsItem*	pBBFils = pTransfert->pBBFilsItem ;
  if (NULL == pBBFils)
		return ;

  string sElementPath = pBBFils->getLocalisation() ;

  // Find such an element in a previous report
  //
  NSSearchStruct searchStruct(NSSearchStruct::modeAsIs,
		                            NSSearchStruct::typeAsIs ,                                NSSearchStruct::positLastInTime,                                1, "", "", NULL) ;

  bool bOk = pNSFct->pContexte->getPatient()->ChercheChemin(sElementPath, &searchStruct) ;

  if ((false == bOk) || (searchStruct.aFoundNodes.empty()))
  {
    // Find such an element in the synthesis
    //
    string sSynthesisPath = string("ZSYNT/QANTP/QANTC/") + pBBFils->getItemLabel() ;

    bOk = pNSFct->pContexte->getPatient()->ChercheChemin(sSynthesisPath, &searchStruct) ;
  }

  if ((false == bOk) || (searchStruct.aFoundNodes.empty()))
    return ;

  std::string date = "" ;
  std::string sNoeud = "" ;

  MappingNSSearchResult::MMapIt it = searchStruct.aFoundNodes.begin() ;
  searchStruct.aFoundNodes.fullRData(it, date, sNoeud) ;
  NSPatPathoArray *pAnswer = new NSPatPathoArray(pNSFct->pContexte) ;
  pNSFct->pContexte->getPatient()->DonneArray(sNoeud, pAnswer) ;
  if (false == pAnswer->empty())
  {
    pAnswer->clearAllIDs() ;
    PatPathoIter iter = pAnswer->begin() ;

    // pAnswer may contain multiple instances of the same information
    //
    NSVectPatPathoArray Vect  ;
    PatPathoIter iterRoot = pAnswer->begin() ;
    pAnswer->ExtraireVecteurPatPathoFreres(iterRoot, &Vect) ;

    if (false == Vect.empty())
    {
      PatPathoIterVect iterVect = Vect.begin() ;
      while (iterVect != Vect.end())
      {
        // Get the sub-patpatho to remove root node
        //
        NSPatPathoArray *pSubPpt = new NSPatPathoArray(pNSFct->pContexte) ;
        PatPathoIter iter = (*iterVect)->begin() ;
        iter++ ;
        while ((*iterVect)->end() != iter)
        {
          int iColonne = (*iter)->getColonne() ;
          int iLigne   = (*iter)->getLigne() ;

          NSPatPathoInfo* pPatPatho = new NSPatPathoInfo() ;
          *(pPatPatho->pDonnees) = *((*iter)->pDonnees) ;

          pPatPatho->setColonne(iColonne - 1) ;
          pPatPatho->setLigne(iLigne - 1) ;

          pSubPpt->push_back(pPatPatho) ;

          iter++ ;
        }
        pTransfert->pTransPatpatho->push_back(new NSFatheredPatPathoArray(pNSFct->pContexte, 0, pSubPpt)) ;

        iterVect++ ;
      }
    }
  }
  delete pAnswer ;

  pTransfert->Active() ;

  return ;
}
catch (...)
{
	erreur("Exception CheckSurgicalHistoryChapter.", standardError, 0) ;
	return ;
}
}

void CheckFamilyHistory(NSDlgFonction *pNSFct, string sCutConcept)
{
  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

  // Is the control already "activated"?
  //
  NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if ((NULL == pTransfert) || (true == pTransfert->iActif))
		return ;

  // Get element's path beyond "personal history" (QANTF)
  //
  BBFilsItem*	pBBFils = pTransfert->pBBFilsItem ;
  if (NULL == pBBFils)
		return ;

  string sElementPath = pBBFils->getLocalisation() ;

  // Find such an element in a previous report
  //
  NSSearchStruct searchStruct(NSSearchStruct::modeAsIs,
		                            NSSearchStruct::typeAsIs ,                                NSSearchStruct::positLastInTime,                                1, "", "", NULL) ;

  bool bOk = pNSFct->pContexte->getPatient()->ChercheChemin(sElementPath, &searchStruct) ;
  if ((bOk) && (false == searchStruct.aFoundNodes.empty()))
  {
    pTransfert->Active() ;
    return ;
  }

  // Find such an element in the synthesis
  //
  size_t iQuantcPos = sElementPath.find(sCutConcept) ;
  if (NPOS == iQuantcPos)
    return ;

  size_t iElmtPathLen = strlen(sElementPath.c_str()) ;
  string sDetails = string("") ;
  iQuantcPos = sElementPath.find(cheminSeparationMARK, iQuantcPos + 1) ;
  if ((NPOS != iQuantcPos) && (iQuantcPos < iElmtPathLen - 1))
    sDetails = string(sElementPath, iQuantcPos + 1, iElmtPathLen - iQuantcPos - 1) ;

  string sSynthesisPath = string("ZSYNT/QANTF/") + sDetails ;

  NSSearchStruct searchStruct2(NSSearchStruct::modeAsIs,
		                            NSSearchStruct::typeAsIs ,                                NSSearchStruct::positLastInTime,                                1, "", "", NULL) ;

  bOk = pNSFct->pContexte->getPatient()->ChercheChemin(sSynthesisPath, &searchStruct2) ;
  if ((bOk) && (false == searchStruct2.aFoundNodes.empty()))
    pTransfert->Active() ;
}

void RecordInSynthesis(NSDlgFonction *pNSFct, string sContextPath, string sCutConcept)
{
  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

  // Is the control "activated"?
  //
  NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if ((NULL == pTransfert) || (false == pTransfert->iActif))
		return ;

  NSVectFatheredPatPathoArray* pTransPatpatho = pTransfert->pTransPatpatho ;
  if ((NULL == pTransPatpatho) || pTransPatpatho->estVide())
    return ;

  // Get synthesis document
  //
  NSDocumentHisto* pSynthDoc = pNSFct->pContexte->getPatient()->GetSynthesisDocument() ;
  if (NULL == pSynthDoc)
    return ;

  BBFilsItem*	pBBFilsItem = pTransfert->pBBFilsItem ;
  if (NULL == pBBFilsItem)
    return ;

  string sItemLabel = pBBFilsItem->getItemLabel() ;

  // NSNoyauDocument* pDocNoy = pSynthDoc->pDocNoy ;

  // If document is opened (pDocNoy not NULL)
  //
  NSHISTODocument* pHistor = pNSFct->pContexte->getPatient()->pDocHis ;
  if (NULL == pHistor)
    return ;

  NSNoyauDocument* pDocNoy = 0 ;

  if (false == pHistor->VectDocumentOuvert.empty())
  {
    string codeDocHisto = pSynthDoc->getID() ;

    for (DocumentIter iterDoc = pHistor->VectDocumentOuvert.begin(); pHistor->VectDocumentOuvert.end() != iterDoc ; iterDoc++)
    {
		  if ((*iterDoc)->getID() == codeDocHisto)
			  pDocNoy = (*iterDoc)->pDocNoy ;
    }
  }

  if (NULL != pDocNoy)
  {
    // iterating into this document's views
    //
    TView* pView = pDocNoy->GetViewList() ;
    for ( ; (NULL != pView) && (string("NSCsVue") != string(pView->GetViewName())) ; pView = pView->GetNextView())
      ;
    if (NULL != pView)
    {
      // NSCsVue* pCsView = dynamic_cast<NSCsVue*>(pView) ;
      // NSTreeWindow* pTreeWin = (NSTreeWindow*)(pCsView) ;
      NSTreeWindow* pTreeWin = dynamic_cast<NSTreeWindow*>(pView) ;
      if (NULL != pTreeWin)      {
        NSTreeNode* pNode = pTreeWin->GetNodeForPath(sContextPath, string(1, cheminSeparationMARK)) ;
        if (NULL != pNode)
        {
          if (pNode->estFictif())
            pTreeWin->NodeRemoteValidation(pNode) ;

          if (pNode->estFictif())
            return ;

          NSPatPathoArray newPpt(pNSFct->pContexte) ;

          Message Msg ;
          newPpt.parseBlock(sItemLabel, &Msg) ;
          newPpt.ajoutePatho(Msg.GetLexique(), &Msg, 0) ;
          for (FatheredPatPathoIterVect vectIt = pTransPatpatho->begin() ; pTransPatpatho->end() != vectIt ; vectIt++)
            newPpt.InserePatPathoFille(newPpt.begin(), (*vectIt)->getPatPatho()) ;

          NSCutPaste CutPaste(pNSFct->pContexte) ;
          *(CutPaste.pPatPatho) = newPpt ;
          pTreeWin->DragFils(pNode, string("DRAG"), &CutPaste) ;

/*
          for (FatheredPatPathoIterVect vectIt = pTransPatpatho->begin() ; pTransPatpatho->end() != vectIt ; vectIt++)
          {
            *(CutPaste.pPatPatho) = *((*vectIt)->getPatPatho()) ;
            pTreeWin->DragFils(pNode, string("DRAG"), &CutPaste) ;
          }
*/

          // Save changes
          if ((NULL != pTreeWin->pControle) &&
              (NULL != pTreeWin->pControle->getTransfert()) &&
              (NULL != pTreeWin->pControle->getTransfert()->pBBFilsItem))
          {
            BBFilsItem* pFilsItem = pTreeWin->pControle->getTransfert()->pBBFilsItem ;
            NSSmallBrother*	pBigBoss = pFilsItem->pBigBoss ;

            pTreeWin->okFermerDialogue() ;
            pTreeWin->EnregistrePatPatho(pBigBoss) ;

            NSNoyauDocument noyauDoc(0, pSynthDoc, 0, pNSFct->pContexte, false) ;
            *(noyauDoc.pPatPathoArray) = *(pBigBoss->getPatPatho()) ;
            noyauDoc.enregistrePatPatho() ;

            *(pSynthDoc->pPatPathoArray) = *(noyauDoc.pPatPathoArray) ;

            pTreeWin->SetDirty(false) ;
          }

          return ;
        }
      }
    }
  }

  NSPatPathoArray synthesisPpt(pNSFct->pContexte) ;
  pNSFct->pContexte->getPatient()->DonnePathoSynthese(&synthesisPpt) ;
  if (synthesisPpt.empty())
    return ;

  string sElementPathInSynthesis = sContextPath + string(1, cheminSeparationMARK) + sItemLabel ;

  PatPathoIter synthesisIter ;
  bool bFound = synthesisPpt.CheminDansPatpatho(sElementPathInSynthesis, string(1, cheminSeparationMARK), &synthesisIter) ;

  if (false == bFound)
  {
    synthesisPpt.AjouterChemin(sContextPath, sItemLabel, true, string(1, cheminSeparationMARK)) ;

    if (false == synthesisPpt.CheminDansPatpatho(sElementPathInSynthesis, string(1, cheminSeparationMARK), &synthesisIter))
      return ;

    for (FatheredPatPathoIterVect vectIt = pTransPatpatho->begin() ; pTransPatpatho->end() != vectIt ; vectIt++)
      synthesisPpt.InserePatPathoFille(synthesisIter, (*vectIt)->getPatPatho()) ;
  }

  NSNoyauDocument noyauDoc(0, pSynthDoc, 0, pNSFct->pContexte, false) ;
  *(noyauDoc.pPatPathoArray) = synthesisPpt ;
  noyauDoc.enregistrePatPatho() ;

  *(pSynthDoc->pPatPathoArray) = *(noyauDoc.pPatPathoArray) ;
}

void InitTitleOfMaterial(NSDlgFonction *pNSFct)
{
/*
  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

  NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
	if ((NULL == pTransfert) || (NULL == pTransfert->pBBFilsItem))
		return ;

  BBFilsItem* pFilsItem = pTransfert->pBBFilsItem ;
  if (NULL == pFilsItem)
  	return ;

  NSButton* pNSButton = static_cast<NSButton*>(pTransfert->pControle->getControle()) ;
  if (NULL == pNSButton)
		return ;

	string sCode = pFilsItem->sEtiquette ;
  if (string("") == sCode)
    return ;

  NSSmallBrother* pBigBoss = pNSFct->pBBItem->pBigBoss ;

	NSPatPathoArray* pPPT = pBigBoss->getPatPatho() ;
  if (NULL == pPPT)
		return ;

	PatPathoIter iter = pPPT->ChercherItem(sCode) ;
	if (pPPT->end() == iter)
		return ;

	string sObjectId = (*iter)->getComplement() ;
  if (string("") == sObjectId)
		return ;

	NSMaterielInfo Materiel ;
  Materiel.initialiseDepuisObjet(pBigBoss->pContexte, sObjectId) ;

	string sNom = Materiel.pDonnees->libelle_complet ;
	if (sNom != "")
	{
  	string sNumSerie = string(Materiel.pDonnees->num_serie) ;
    if (sNumSerie != "")
    	sNom += " n�" + sNumSerie ;
	}

	if (sNom != "")
		pNSButton->SetCaption(sNom.c_str()) ;
	else
		pNSButton->SetCaption("Pr�ciser l'endoscope") ;
*/
}

void SelectMaterial(NSDlgFonction *pNSFct)
{
  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;
}

void InitTitleOfPerson(NSDlgFonction *pNSFct)
{
  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

  NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if ((NULL == pTransfert) || (NULL == pTransfert->pBBFilsItem) || (NULL == pTransfert->pControle->getControle()))
		return ;

	NSButton* pNSButton = static_cast<NSButton*>(pTransfert->pControle->getControle()) ;
  if (NULL == pNSButton)
		return ;

  NSSmallBrother* pBigBoss = pNSFct->pBBItem->pBigBoss ;
  if (NULL == pBigBoss)
    return ;

	string sCode = pTransfert->pBBFilsItem->getItemLabel() ;
  if (string("") == sCode)
    return ;

  string sCorrespId = string("") ;

  if ((NULL != pTransfert->pTransfertMessage) && (string("") != pTransfert->pTransfertMessage->GetComplement()))
    sCorrespId = pTransfert->pTransfertMessage->GetComplement() ;
  else
  {
	  NSPatPathoArray* pPPT = pBigBoss->getPatPatho() ;
	  if (NULL == pPPT)
  	  return ;

	  //
	  // chercher dans pPPT sCode
	  //
	  PatPathoIter iter = pPPT->ChercherItem(sCode) ;
	  if ((NULL == iter) || (pPPT->end() == iter))
		  return ;

	  sCorrespId = (*iter)->getComplement() ;
    if (string("") == sCorrespId)
		  return ;
  }

	NSPersonInfo* pPersonInfo = pBigBoss->pContexte->getPersonArray()->getPerson(sCorrespId, pidsCorresp) ;
  if (NULL == pPersonInfo)
  	return ;

	string sIdentite = pPersonInfo->sNom + " " + pPersonInfo->sPrenom ;

	if (sIdentite != "")
		pNSButton->SetCaption(sIdentite.c_str()) ;
	else
		pNSButton->SetCaption("Pr�ciser l'anesth�siste") ;
}

void SelectPerson(NSDlgFonction *pNSFct)
{
  if ((NULL == pNSFct) || (NULL == pNSFct->pControle))
		return ;

	NSTransferInfo* pTransfert = pNSFct->pControle->getTransfert() ;
  if (NULL == pTransfert)
  	return ;

  if ((NULL == pNSFct->pBBItem) || (NULL == pNSFct->pBBItem->pBigBoss))
		return ;
  NSContexte* pContexte = pNSFct->pBBItem->pBigBoss->pContexte ;

	string sSpecialite = "DANES1" ; //code lexique de l'anesth�siste

	NSTPersonListDialog Liste(pNSFct->pControle->getInterfacePointer(),
                                        pidsCorresp, false, pContexte) ;

	if (IDOK != Liste.Execute())
		return ;

	if (string("") == Liste.pPersonSelect->sPersonID)
		return ;

	pTransfert->pTransfertMessage->SetComplement(Liste.pPersonSelect->sPersonID) ;
	pTransfert->pBBFilsItem->Active() ;
	string sIdentite = Liste.pPersonSelect->sNom + " " +
                                Liste.pPersonSelect->sPrenom ;

	NSButton* pNSButton = static_cast<NSButton*>(pTransfert->pControle->getControle()) ;
  if (NULL == pNSButton)
		return ;

	if (sIdentite != "")
		pNSButton->SetCaption(sIdentite.c_str()) ;
	else
		pNSButton->SetCaption("Pr�ciser l'anesth�siste") ;
}

// Fonction d'�num�ration pour la mise � jour des champs Static
bool FAR PASCAL SetStaticCaption(HWND hWnd, LPARAM lParam)
{
try
{
	char szClassName[30];           // Nom de la classe du contr�le
	char szBuffer[255] ;             // Utilis�e pour les fonctions WINDOWS

	memset(szClassName, 0, 30) ;
	memset(szBuffer,    0, 255) ;

	HWND    hDlg            = NULL ;    // Handle de la bo�te de dialogue Parent.
	UINT    nMaxInput       = 255;      // Nombre maximal de caract�res � saisir
	//
	// Adresse de l'objet bo�te de dialogue courante
	//
	string* pParam = reinterpret_cast<string*>(lParam) ;
  if (NULL == pParam)
		return true ;
	string sParam = *pParam ;

	size_t pos = sParam.find("|") ;
	if (NPOS == pos)
		return true ;

	string sTitle = string(sParam, 0, pos) ;
	string sName = string(sParam, pos+1, strlen(sParam.c_str())-pos-1) ;
	string sCaption ;

	//
	// Obtention de l'ID du contr�le et de son type WINDOWS
	//
	int ctrlID  = ::GetDlgCtrlID(hWnd) ;
	::GetClassName(hWnd, (LPSTR) szClassName, 30) ;
	pseumaj(szClassName) ;
	//
	// Obtention du handle de la bo�te de Dialogue
	//
	hDlg = ::GetParent(hWnd) ;

	// -------------------------------------------------------------------
  //                                  Static
  // -------------------------------------------------------------------
  if ((!strcmp(szClassName, "STATIC")) || (!strcmp(szClassName, "BORSTATIC")) ||
      (!strcmp(szClassName, "BORSHADE")) || (!strcmp(szClassName, "BUTTON")))
	{
  	if ((ctrlID != -1) && (ctrlID != 0xFFFF))
    {
    	// R�cup�ration de la longueur du texte du contr�le
      nMaxInput = ::GetDlgItemText(hDlg, ctrlID, szBuffer, nMaxInput) ;
      string sTitleCaption = string(szBuffer) ;
      pos = sTitleCaption.find(" : ") ;
      if (pos != NPOS)
      	sTitleCaption = string(sTitleCaption, 0, pos) ;

      if (sTitleCaption == sTitle)
      {
      	sCaption = sTitle + string(" : ") + sName ;
        ::SetDlgItemText(hDlg, ctrlID, sCaption.c_str()) ;
      }
    }
  }

	return true ;
}
catch (...)
{
	erreur("Exception NSDialog::SetStaticCaption.", standardError, 0) ;
	return false;
}
}

