// -----------------------------------------------------------------------------
// nsmpids.cpp// -----------------------------------------------------------------------------
// Base contenant l'identifiant patient dans le modele MUE
// -----------------------------------------------------------------------------
// $Revision: 1.25 $
// $Author: remi $
// $Date: 2005/06/24 14:00:21 $
// -----------------------------------------------------------------------------
// FLP - octobre 2004
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Copyright Nautilus, 2004
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � g�rer et traiter les
// informations de sant� d'une personne.
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to manage and process
// a person's health data.
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------

#include "nsbb\nsmpids.h"
#include "partage\nsdivfct.h"
#include "nsbb\nsmanager.h"
#include "nautilus\nssuper.h"
#include "nsbb\nsarc.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbbsmal.h"
#include "nsbb\nsdefArch.h"
#include "nsbb\nspardlg.h"

#include "pilot\NautilusPilot.hpp"
#include "nsbb\tagNames.h"

//***************************************************************************
// Impl�mentation des m�thodes NSPids
//***************************************************************************

//---------------------------------------------------------------------------
//  Function:    NSPidsData::NSPidsData()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSPidsData::NSPidsData()
{
	metAZero();
}

//---------------------------------------------------------------------------
//  Fonction:		NSPidsData::NSPidsData(NSPidsData& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSPidsData::NSPidsData(NSPidsData& rv)
{
	strcpy(nss,								rv.nss);
    strcpy(rootdoc,                         rv.rootdoc);
	strcpy(nom,								rv.nom);
	strcpy(prenom,							rv.prenom);
	strcpy(code,							rv.code);
	strcpy(sexe,							rv.sexe);
	strcpy(naissance,						rv.naissance);
    strcpy(login,                           rv.login);
    strcpy(passwd,                          rv.passwd);
    strcpy(nb_exemp,                        rv.nb_exemp);
    strcpy(messagerie,                      rv.messagerie);
}

//---------------------------------------------------------------------------
//  Fonction:		NSPidsData::operator=(NSPidsData src)
//  Description:	Op�rateur =
//  Retour:			R�f�rence sur l'objet cible
//---------------------------------------------------------------------------
NSPidsData&
NSPidsData::operator=(NSPidsData src)
{
	if (this == &src)
		return *this ;

	strcpy(nss, 	  					src.nss);
    strcpy(rootdoc,                     src.rootdoc);
	strcpy(nom, 	  					src.nom);
	strcpy(prenom, 	  					src.prenom);
	strcpy(code,   	  					src.code);
	strcpy(sexe,      					src.sexe);
	strcpy(naissance, 					src.naissance);
    strcpy(login,                       src.login);
    strcpy(passwd,                      src.passwd);
    strcpy(nb_exemp,                    src.nb_exemp);
    strcpy(messagerie,                  src.messagerie);

	return *this;
}

//---------------------------------------------------------------------------
//  Fonction:		NSPidsData::operator==(NSPidsData src)
//  Description:	Op�rateur de comparaison
//  Retour:			0 ou 1
//---------------------------------------------------------------------------
int
NSPidsData::operator == ( NSPidsData& o )
{
	if ((strcmp(nss, 		  							o.nss) 							== 0) &&
            (strcmp(rootdoc,                            o.rootdoc)                      == 0) &&
			(strcmp(nom, 		  						o.nom) 							== 0) &&
			(strcmp(prenom, 	  						o.prenom) 						== 0) &&
			(strcmp(code,   	  						o.code) 						== 0) &&
			(strcmp(sexe,      							o.sexe) 						== 0) &&
			(strcmp(naissance, 							o.naissance) 					== 0)
			)
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Function:    NSPidsData::metAZero()
//
//  Description: Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSPidsData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(nss,       					0,	PIDS_NSS_LEN + 1);
    memset(rootdoc,                     0,  PIDS_ROOTDOC_LEN + 1);
	memset(nom,       					0, 	PIDS_NOM_LEN + 1);
	memset(prenom,    					0, 	PIDS_PRENOM_LEN + 1);
	memset(code,      					0, 	PIDS_CODE_LEN + 1);
	memset(sexe,      					0, 	PIDS_SEXE_LEN + 1);
	memset(naissance, 					0, 	PIDS_NAISSANCE_LEN + 1);
    memset(login,                       0,  PIDS_LOGIN_LEN + 1);
    memset(passwd,                      0,  PIDS_PASSWD_LEN + 1);
    memset(nb_exemp,                    0,  PIDS_NB_EXEMP_LEN + 1);
    memset(messagerie,                  0,  PIDS_MESSAGERIE_LEN + 1);
}

//---------------------------------------------------------------------------
//  Function:    NSPidsData::metABlanc()
//
//  Description: Met � blanc les variables de la fiche
//---------------------------------------------------------------------------
void
NSPidsData::metABlanc()
{
	//
	// Met les champs de donn�es � blanc
	//
	memset(nss,       					' ', 	PIDS_NSS_LEN);
    memset(rootdoc,                     ' ',    PIDS_ROOTDOC_LEN);
	memset(nom,       					' ', 	PIDS_NOM_LEN);
	memset(prenom,    					' ', 	PIDS_PRENOM_LEN);
	memset(code,      					' ', 	PIDS_CODE_LEN);
	memset(sexe,      					' ', 	PIDS_SEXE_LEN);
	memset(naissance, 					' ', 	PIDS_NAISSANCE_LEN);
    memset(login,                       ' ',    PIDS_LOGIN_LEN);
    memset(passwd,                      ' ',    PIDS_PASSWD_LEN);
    memset(nb_exemp,                    ' ',    PIDS_NB_EXEMP_LEN + 1);
    memset(messagerie,                  ' ',    PIDS_MESSAGERIE_LEN + 1);
}

/*****************************************************************************/
// 							METHODES DE NSPids
/*****************************************************************************/

//---------------------------------------------------------------------------
//  Function:    NSPids::NSPids(NSSuper* pSuper)
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSPids::NSPids(NSContexte* pCtx, PIDSTYPE iType)
       :NSPidsInfo(pCtx), NSFiche(pCtx)
{
	iTypePids = iType ;
}

//---------------------------------------------------------------------------
//  Function:  NSPids::~NSPids()
//
//  Arguments:
//
//  Description:
//             Destructeur.
//             Ferme proprement une classe de ce type.
//  Returns:
//             Aucun
//---------------------------------------------------------------------------
NSPids::~NSPids()
{
}

//---------------------------------------------------------------------------
//  Function:  NSPids::alimenteFiche()
//
//  Arguments:
//
//  Description:
//             Transf�re le contenu de pRecBuff dans les variables de
//             la fiche
//  Returns:
//             Rien
//---------------------------------------------------------------------------
void NSPids::alimenteFiche()
{
	alimenteChamp(pDonnees->nss, 			PIDS_NSS_FIELD,		 		PIDS_NSS_LEN);
    alimenteChamp(pDonnees->rootdoc,        PIDS_ROOTDOC_FIELD,         PIDS_ROOTDOC_LEN);
	alimenteChamp(pDonnees->nom, 			PIDS_NOM_FIELD,		 		PIDS_NOM_LEN);
	alimenteChamp(pDonnees->prenom, 		PIDS_PRENOM_FIELD,	 		PIDS_PRENOM_LEN);
	alimenteChamp(pDonnees->code, 			PIDS_CODE_FIELD,		 	PIDS_CODE_LEN);
	alimenteChamp(pDonnees->sexe, 			PIDS_SEXE_FIELD,		 	PIDS_SEXE_LEN);
	alimenteChamp(pDonnees->naissance,	    PIDS_NAISSANCE_FIELD,	    PIDS_NAISSANCE_LEN);
    if (iTypePids == pidsUtilisat)
    {
        alimenteChamp(pDonnees->login, 			PIDS_LOGIN_FIELD,		 	PIDS_LOGIN_LEN);
	    alimenteChamp(pDonnees->passwd,	        PIDS_PASSWD_FIELD,	        PIDS_PASSWD_LEN);
    }
}

//---------------------------------------------------------------------------
//  Function:  NSPids::videFiche()
//
//  Description: Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void NSPids::videFiche()
{
	videChamp(pDonnees->nss, 			PIDS_NSS_FIELD,		 		PIDS_NSS_LEN);
    videChamp(pDonnees->rootdoc,        PIDS_ROOTDOC_FIELD,         PIDS_ROOTDOC_LEN);
	videChamp(pDonnees->nom, 			PIDS_NOM_FIELD,		 		PIDS_NOM_LEN);
	videChamp(pDonnees->prenom, 		PIDS_PRENOM_FIELD,	 		PIDS_PRENOM_LEN);
	videChamp(pDonnees->code, 			PIDS_CODE_FIELD,		 	PIDS_CODE_LEN);
	videChamp(pDonnees->sexe, 			PIDS_SEXE_FIELD,		 	PIDS_SEXE_LEN);
	videChamp(pDonnees->naissance,	    PIDS_NAISSANCE_FIELD,	    PIDS_NAISSANCE_LEN);
    if (iTypePids == pidsUtilisat)
    {
        videChamp(pDonnees->login, 			PIDS_LOGIN_FIELD,		 	PIDS_LOGIN_LEN);
	    videChamp(pDonnees->passwd,	        PIDS_PASSWD_FIELD,	        PIDS_PASSWD_LEN);
    }
}

//---------------------------------------------------------------------------
//  Function:  NSPids::open()
//
//  Arguments:
//
//  Description:
//             Ouvre la table primaire et les index secondaires
//  Returns:
//             PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult NSPids::open()
{
    char tableName[255];
    if (iTypePids == pidsPatient)        strcpy(tableName, "NSPIDS.DB");    else if (iTypePids == pidsCorresp)        strcpy(tableName, "NSPIDSCOR.DB");
    else
        strcpy(tableName, "NSPIDSUTI.DB");

	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL);
    return (lastError);
}

//---------------------------------------------------------------------------
//  Function:  NSPids::close()
//
//  Arguments:
//
//  Description:
//             Ferme la table primaire et l'index secondaire
//  Returns:
//             PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult NSPids::close()
{
	//
	// Appelle la fonction close() de la classe de base pour fermer
	// l'index primaire
	//
	lastError = NSFiche::close();

    return (lastError);
}



// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes NSPidsInfo
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Fonction    : NSPidsInfo::NSPidsInfo(NSSuper* pSuper)
// Description : Constructeur avec superviseur (pour les acc�s aux bases)
// Retour      : Rien
// -----------------------------------------------------------------------------
NSPidsInfo::NSPidsInfo(NSContexte* pCtx)
	:	NSRoot(pCtx)
{
	// Cr�e l'objet de donn�es
	pDonnees 	  		= new NSPidsData() ;
  pGraphPerson    = new NSPersonGraphManager(pContexte) ;
  pGraphAdr       = new NSAddressGraphManager(pContexte) ;
  sFonction       = "" ;
  sChez           = "" ;
}


// -----------------------------------------------------------------------------
// Fonction    : NSPidsInfo::NSPidsInfo(NSPids *)
// Description : Constructeur � partir d'un NSPids
// Retour      : Rien
// -----------------------------------------------------------------------------
NSPidsInfo::NSPidsInfo(NSPids *pPids)
	:	NSRoot(pPids->NSPidsInfo::pContexte)
{
	// Cr�e l'objet de donn�es
	pDonnees 	   		= new NSPidsData() ;
  pGraphPerson    = new NSPersonGraphManager(pContexte) ;
  pGraphAdr       = new NSAddressGraphManager(pContexte) ;
  sFonction       = "" ;
  sChez           = "" ;

	// Copie les donn�es du NSPids
	*pDonnees 	   	= *(pPids->pDonnees) ;
}


// -----------------------------------------------------------------------------
// Fonction    : NSPidsInfo::NSPidsInfo(NSBasicAttributeArray *pAttribute)
// Description : Constructeur avec NSBasicAttributeArray (pour les acc�s aux bases a l'aide du pilot)
// Retour      : Rien
// -----------------------------------------------------------------------------
NSPidsInfo::NSPidsInfo(NSBasicAttributeArray *pAttribute, NSContexte *pCtx)
	: NSRoot(pCtx)
{
	// Cr�e l'objet de donn�es
	pDonnees 	  	= new NSPidsData() ;
  pGraphPerson  = new NSPersonGraphManager(pContexte) ;
  pGraphAdr     = new NSAddressGraphManager(pContexte) ;
  sFonction     = "" ;
  sChez         = "" ;

  NSBasicAttributeIter iter = pAttribute->begin() ;
  for(iter ; iter != pAttribute->end() ; iter++)
  {
    if ((*iter)->getBalise() == FIRST_NAME)
      strcpy(pDonnees->prenom, ((*iter)->getText()).c_str()) ;
    else if ((*iter)->getBalise() == LAST_NAME)
      strcpy(pDonnees->nom, ((*iter)->getText()).c_str()) ;
    else if ((*iter)->getBalise() == BIRTHDATE)
      strcpy(pDonnees->naissance, ((*iter)->getText()).c_str()) ;
    else if ((*iter)->getBalise() == SEX)
      strcpy(pDonnees->sexe, ((*iter)->getText()).c_str()) ;
    else if ((*iter)->getBalise() == PIDS)
      strcpy(pDonnees->nss, ((*iter)->getText()).c_str()) ;
    else if ((*iter)->getBalise() ==  LOGIN)
      strcpy(pDonnees->login, ((*iter)->getText()).c_str()) ;
  }
}

// -----------------------------------------------------------------------------
// Fonction    : NSPidsInfo::~NSPidsInfo()
// Description : Destructeur
// Retour      : Rien
// -----------------------------------------------------------------------------
NSPidsInfo::~NSPidsInfo()
{
	delete pDonnees ;
  delete pGraphPerson ;
  delete pGraphAdr ;
  // pas de delete du pSuper
}


// -----------------------------------------------------------------------------
// Fonction    : NSPidsInfo::NSPidsInfo(NSPidsInfo& rv)
// Description : Constructeur copie
// Retour      : Rien
// -----------------------------------------------------------------------------
NSPidsInfo::NSPidsInfo(NSPidsInfo& rv)
	:	NSRoot(rv.pContexte)
{
	// Cr�e l'objet de donn�es
	pDonnees 	   	= new NSPidsData(*(rv.pDonnees)) ;
  pGraphPerson  = new NSPersonGraphManager(*(rv.pGraphPerson)) ;
  pGraphAdr     = new NSAddressGraphManager(*(rv.pGraphAdr)) ;
  sFonction     = rv.sFonction ;
  sChez         = rv.sChez ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSPidsInfo::operator=(NSPidsInfo src)
//  Description:	Op�rateur d'affectation
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
NSPidsInfo& NSPidsInfo::operator=(NSPidsInfo src)
{
	if (this == &src)
		return *this ;

	*pDonnees 	   = *(src.pDonnees) ;
	*pGraphPerson  = *(src.pGraphPerson) ;
	*pGraphAdr     = *(src.pGraphAdr) ;
	sFonction      = src.sFonction ;
	sChez          = src.sChez ;

	return *this;
}

//---------------------------------------------------------------------------
//  Fonction:		NSPidsInfo::operator==(NSPidsInfo src)
//  Description:	Op�rateur de comparaison
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
int NSPidsInfo::operator == ( NSPidsInfo& o )
{
	int egal = 1;

	if (!(*pDonnees 			== *(o.pDonnees)))
		egal = 0;

    return egal;
}

// --------------------------------------------------------------------------
// ------------------------ METHODES DE NSPidsArray ----------------------
// --------------------------------------------------------------------------

NSPidsArray::NSPidsArray(NSPidsArray& rv)
               :NSPidsVector()
{
try
{
    if (!(rv.empty()))
    {
        for (NSPidsIter i = rv.begin(); i != rv.end(); i++)
            push_back(new NSPidsInfo(*(*i)));
    }
}
catch (const exception& e)
{
    string sExept = "Exception NSPidsArray copy ctor " + string(e.what());
    erreur(sExept.c_str(), standardError, 0);
}
catch (...)
{
    erreur("Exception NSPidsArray copy ctor.", standardError, 0);
}
}

voidNSPidsArray::vider()
{
    if (empty())
        return;

    for (NSPidsIter i = begin(); i != end(); )
    {
   	    delete *i;
        erase(i);
    }
}

NSPidsArray::~NSPidsArray()
{
	vider();
}

NSPidsArray&
NSPidsArray::operator=(NSPidsArray src)
{
	if (this == &src)
		return *this ;

try
{
	vider() ;

	if (!(src.empty()))		for (NSPidsIter i = src.begin(); i != src.end(); i++)			push_back(new NSPidsInfo(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception NSPidsArray (= operator).", standardError, 0) ;
	return *this;
}
}

int
NSPidsArray::operator==(NSPidsArray& o)
{
try
{
    NSPidsIter i,j;
    int egal = 1;    if (empty())    {        if (o.empty())            return 1;        else            return 0;    }    i = begin();    j = o.begin();    while ((i != end()) && (j != o.end()))    {        if (!((*(*i)) == (*(*j))))        {            egal = 0;            break;        }        i++;        j++;    }    if (egal)    {        if ((i != end()) || (j != o.end()))            egal = 0;    }    return egal;
}
catch (const exception& e)
{
    string sExept = "Exception NSPidsArray (== operator) " + string(e.what());
    erreur(sExept.c_str(), standardError, 0);
    return 0;
}
catch (...)
{
    erreur("Exception NSPidsArray (== operator).", standardError, 0);
    return 0;
}
}

//***************************************************************************
// Impl�mentation des m�thodes du NSPersonManager
//***************************************************************************

NSPersonInfo::NSPersonInfo(NSContexte* pCtx, NSBasicAttributeArray* pAttribute)
             :NSRoot(pCtx)
{
	initValues() ;

	pVectData = new NSVectPatPathoArray() ;

	if ((!pAttribute) || (pAttribute->empty()))
		return ;

	NSBasicAttributeIter iter = pAttribute->begin() ;
	for(iter ; iter != pAttribute->end() ; iter++)
	{
    if      ((*iter)->getBalise() == FIRST_NAME)
    	sPrenom = (*iter)->getText() ;
    else if ((*iter)->getBalise() == LAST_NAME)
    	sNom = (*iter)->getText() ;
    else if ((*iter)->getBalise() == BIRTHDATE)
    	sNaissance = (*iter)->getText() ;
    else if ((*iter)->getBalise() == SEX)
    	_sSexe = (*iter)->getText() ;
    else if ((*iter)->getBalise() == PIDS)
    	sPersonID = (*iter)->getText() ;
    else if ((*iter)->getBalise() == LOGIN)
    	sLogin = (*iter)->getText() ;
    else if ((*iter)->getBalise() == ROLE)
    	sRoles = (*iter)->getText() ;
    else if ((*iter)->getBalise() == CITY_PRO)
    	sVille = (*iter)->getText() ;
    else if ((*iter)->getBalise() == APPOINTMENT_DATE)
    	sReconvocDate = (*iter)->getText() ;
    else if ((*iter)->getBalise() == LOCKED)
    	sBlocked = (*iter)->getText() ;
	}
}

NSPersonInfo::NSPersonInfo(NSContexte* pCtx, string sNss, PIDSTYPE iTypePids)
             :NSRoot(pCtx)
{
	initValues() ;

	sPersonID = sNss ;
	pVectData = new NSVectPatPathoArray() ;

	NSPatPathoArray PatPathoData(pContexte) ;

	typePids = iTypePids ;

	bool bVerbose = false ;
	if (iTypePids == pidsPatient)
		bVerbose = true ;

	// on lance un PersonGraphManager pour r�cup�rer les donn�es
	NSPersonGraphManager GraphManager(pContexte) ;
	if (GraphManager.getGraphAdmin(sPersonID, bVerbose, iTypePids, &PatPathoData))
	{
  	NSPatPathoArray PatPathoAdmin(pContexte, graphPerson) ;
		NSPatPathoArray PatPathoPDS(pContexte, graphPerson) ;

    string sCode ;
    string sCivil ;
    string sSex ;
    string sActiveJob ;

    GraphManager.partDualPatho(&PatPathoData, &PatPathoAdmin, &PatPathoPDS) ;
    GraphManager.ChargeDonneesAdmin(&PatPathoAdmin, sNom, sPrenom, sCode, sSex, sNaissance, sCivilite) ;
    GraphManager.ChargeDonneesPDS(&PatPathoPDS, sMetier, sSpecialite, sActiveJob, sOrientation, sCivil, sTitre, sVille) ;

    if (string("") != sCivil)
      sCivilite = sCivil ;

    if      (string("1") == sSex)
      metMasculin() ;
    else if (string("2") == sSex)
      metFeminin() ;

    updateCalculatedValues(&GraphManager, iTypePids) ;
  }
}

// Ici on fournit une patpatho et on cr�e le graphe � l'aide du pilote
NSPersonInfo::NSPersonInfo(NSContexte* pCtx, NSPatPathoArray* pPatPathoData, PIDSTYPE iTypePids) : NSRoot(pCtx)
{
	pVectData = new NSVectPatPathoArray() ;
  string sCode ;
  string sCivil ;
  string sActiveJob ;

  typePids = iTypePids ;

  // on lance un PersonGraphManager pour r�cup�rer les donn�es
  //
  NSPersonGraphManager GraphManager(pContexte) ;

  if ((NULL != pPatPathoData) && (false == pPatPathoData->empty()))
  {
  	NSPatPathoArray PatPathoAdmin(pContexte, graphPerson) ;
		NSPatPathoArray PatPathoPDS(pContexte, graphPerson) ;

    string sSex ;

    GraphManager.partDualPatho(pPatPathoData, &PatPathoAdmin, &PatPathoPDS) ;
    GraphManager.ChargeDonneesAdmin(&PatPathoAdmin, sNom, sPrenom, sCode, sSex, sNaissance, sCivilite) ;
    GraphManager.ChargeDonneesPDS(&PatPathoPDS, sMetier, sSpecialite, sActiveJob, sOrientation, sCivil, sTitre, sVille) ;

    if      (string("1") == sSex)
      metMasculin() ;
    else if (string("2") == sSex)
      metFeminin() ;
	}

	if (sCivil != "")
  	sCivilite = sCivil ;

	// S�lection des traits � envoyer au pilote
	string sNewPids = string(1, INMEMORY_CHAR) + string(PAT_NSS_LEN - 1, '0') ;
  NSBasicAttributeArray AttrList ;

  switch (iTypePids)
  {
  	case pidsPatient :
    	break ;
    case pidsCorresp :
    	AttrList.push_back(new NSBasicAttribute(OPERATOR, pContexte->getUtilisateurID())) ;
      AttrList.push_back(new NSBasicAttribute(FIRST_NAME, sPrenom)) ;
      AttrList.push_back(new NSBasicAttribute(LAST_NAME, sNom)) ;
      AttrList.push_back(new NSBasicAttribute(CITY_PRO, sVille)) ;
      AttrList.push_back(new NSBasicAttribute(PIDS, sNewPids)) ;
      AttrList.push_back(new NSBasicAttribute(PERSON, sNewPids)) ;
      GraphManager.setInfoPids(&AttrList) ;
      break ;
    case pidsUtilisat :
    	break ;
  }

	if (GraphManager.setGraphAdmin(pPatPathoData, iTypePids))
  	// on r�cup�re le personID issu du graphe
    sPersonID = GraphManager.getPersonID() ;
  else
  	erreur("La cr�ation de la personne a �chou�.", standardError, 0) ;

  updateCalculatedValues(&GraphManager, iTypePids) ;
}

NSPersonInfo::~NSPersonInfo()
{
	delete pVectData ;
}

NSPersonInfo::NSPersonInfo(NSPersonInfo& rv) : NSRoot(rv.pContexte)
{
	sPersonID     = rv.sPersonID ;
  sNom          = rv.sNom ;
  sPrenom       = rv.sPrenom ;
  sLang         = rv.sLang ;
  _sSexe        = rv._sSexe ;
  sNaissance    = rv.sNaissance ;
  sMetier       = rv.sMetier ;
  sSpecialite   = rv.sSpecialite ;
  sOrientation  = rv.sOrientation ;
  sTitre        = rv.sTitre ;
  sCivilite     = rv.sCivilite ;
  sRoles        = rv.sRoles ;
	sVille        = rv.sVille ;
	sReconvocDate = rv.sReconvocDate ;
	sBlocked      = rv.sBlocked ;

  typePids      = rv.typePids ;

  sChez         = rv.sChez ;
  sObjectAdr    = rv.sObjectAdr ;
  sMainAdr      = rv.sMainAdr ;

  pVectData = new NSVectPatPathoArray(*(rv.pVectData)) ;
}

NSPersonInfo&
NSPersonInfo::operator=(NSPersonInfo src)
{
	if (this == &src)
		return *this ;

	sPersonID     = src.sPersonID ;
  sNom          = src.sNom ;
  sPrenom       = src.sPrenom ;
  sLang         = src.sLang ;
  _sSexe        = src._sSexe ;
  sNaissance    = src.sNaissance ;
  sMetier       = src.sMetier ;
  sSpecialite   = src.sSpecialite ;
  sOrientation  = src.sOrientation ;
  sTitre        = src.sTitre ;
  sCivilite     = src.sCivilite ;
  sRoles        = src.sRoles ;
	sVille        = src.sVille ;
	sReconvocDate = src.sReconvocDate ;
	sBlocked      = src.sBlocked ;

  typePids      = src.typePids ;

  sChez         = src.sChez ;
  sObjectAdr    = src.sObjectAdr ;
  sMainAdr      = src.sMainAdr ;

  *pVectData = *(src.pVectData) ;

  return *this ;
}

int
NSPersonInfo::operator==(NSPersonInfo& o)
{
	if (sPersonID == o.sPersonID)
		return 1 ;

	return 0 ;
}


NSPersonGraphManager *
NSPersonInfo::getPersonGraph()
{
	NSPersonGraphManager *pGraphManager = new NSPersonGraphManager(pContexte) ;
  if (pGraphManager->getGraphAdmin(sPersonID, typePids))
  	return pGraphManager ;
  return NULL ;
}

string
NSPersonInfo::getMainAdr(PIDSTYPE iTypePids)
{
	if (sMainAdr != "")
  	return sMainAdr ;

  NSPersonGraphManager PersonManager(pContexte) ;
  if (sObjectAdr == "")
  {
  	if (!PersonManager.getGraphAdmin(sPersonID, iTypePids))
      return "" ;

    if (!PersonManager.trouveObjectAdrPrinc(iTypePids, sObjectAdr, sChez))
    {
    	sMainAdr = sCivilite + string("\r\n") + PersonManager.trouveLibLongForInGraphAdr(iTypePids) ;
      return sMainAdr ;
    }
  }

  if (sObjectAdr != "")
  {
  	NSAddressGraphManager AddressManager(pContexte) ;
    if (AddressManager.getGraphAdr(sObjectAdr))
    {
    	sMainAdr = sCivilite + string("\r\n") ;
      if (sChez != "")
      	sMainAdr += sChez + string("\r\n") ;
      sMainAdr += AddressManager.trouveLibLongAdr() ;
    }
    else
    	sMainAdr = "" ;
  }
  else
  	sMainAdr = sCivilite + string("\r\n") + PersonManager.trouveLibLongForInGraphAdr(iTypePids) ;

  return sMainAdr ;
}

void
NSPersonInfo::updateCalculatedValues(NSPersonGraphManager* pPersonGraphManager, PIDSTYPE iTypePids)
{
  // Calcul de la civilit�
  if (string("") != sCivilite)
  {
    sCivilite[0] = pseumaj(sCivilite[0]) ;
    sCivilite = sCivilite + string(" ") + sPrenom + string(" ") + sNom ;
  }
  else
    sCivilite = sPrenom + string(" ") + sNom ;

  if (sTitre != "")
  {
    sTitre[0] = pseumaj(sTitre[0]) ;
    sCivilite = sTitre + string(" ") + sPrenom + string(" ") + sNom ;
  }

  if (NULL == pPersonGraphManager)
    return ;

  sMainAdr = sCivilite + string("\r\n") + pPersonGraphManager->trouveLibLongForInGraphAdr(iTypePids) ;
}

void
NSPersonInfo::initValues()
{
	sPersonID     = string("") ;
	sNom          = string("") ;
	sPrenom       = string("") ;
	sLang         = string("") ;
	_sSexe        = string("") ;
	sNaissance    = string("") ;
	sLogin        = string("") ;

	sMetier       = string("") ;
	sSpecialite   = string("") ;
	sOrientation  = string("") ;
	sActivite     = string("") ;
	sTitre        = string("") ;
	sCivilite     = string("") ;
	sRoles        = string("") ;
	sVille        = string("") ;
	sReconvocDate = string("") ;
	sBlocked      = string("") ;

	sChez         = string("") ;
	sObjectAdr    = string("") ;
	sMainAdr      = string("") ;

	typePids      = pidsPatient ;

	pVectData     = 0 ;
}

string
NSPersonInfo::getNomLong()
{
	string sNomLong = string("") ;
  
	sNomLong += sNom ;
  if (string("") != sPrenom)
		sNomLong += string(" ") + sPrenom ;

	return sNomLong ;
}

// --------------------------------------------------------------------------
// ------------------------ METHODES DE NSPersonArray ----------------------
// --------------------------------------------------------------------------

NSPersonArray::NSPersonArray(NSPersonArray& rv)
              :NSPersonVector(), NSRoot(rv.pContexte)
{
try
{
	if (!(rv.empty()))
  	for (NSPersonIter i = rv.begin(); i != rv.end(); i++)
    	push_back(new NSPersonInfo(*(*i))) ;
}
catch (...)
{
	erreur("Exception NSPersonArray copy ctor.", standardError, 0) ;
}
}

voidNSPersonArray::vider()
{
	if (empty())
  	return ;

  for (NSPersonIter i = begin(); i != end(); )
  {
  	delete *i ;
    erase(i) ;
  }
}

NSPersonArray::~NSPersonArray()
{
	vider() ;
}

NSPersonArray&
NSPersonArray::operator=(NSPersonArray src)
{
	if (this == &src)
		return *this ;

try
{
	vider() ;

  if (!(src.empty()))  	for (NSPersonIter i = src.begin(); i != src.end(); i++)    	push_back(new NSPersonInfo(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception NSPersonArray (= operator).", standardError, 0) ;
  return *this ;
}
}

int
NSPersonArray::operator==(NSPersonArray& o)
{
try
{
    NSPersonIter i,j;
    int egal = 1;    if (empty())    {        if (o.empty())            return 1;        else            return 0;    }    i = begin();    j = o.begin();    while ((i != end()) && (j != o.end()))    {        if (!((*(*i)) == (*(*j))))        {            egal = 0;            break;        }        i++;        j++;    }    if (egal)    {        if ((i != end()) || (j != o.end()))            egal = 0;    }	return egal ;
}
catch (...)
{
	erreur("Exception NSPersonArray (== operator).", standardError, 0) ;
  return 0 ;
}
}

NSPersonInfo*
NSPersonArray::lookForPersonInArray(string sID)
{
  if ((sID == "") || (true == empty()))
  	return NULL ;

  for (NSPersonIter i = begin() ; end() != i ; i++)
    if ((*i)->sPersonID == sID)
      return (*i) ;

  return NULL ;
}

NSPersonInfo *
NSPersonArray::getPerson(string sID, PIDSTYPE iTypePids)
{
	if (sID == "")
  	return NULL ;

  NSPersonInfo* pPerson = lookForPersonInArray(sID) ;

  if (NULL != pPerson)
    return pPerson ;

  NSPersonInfo* pNewPerson = new NSPersonInfo(pContexte, sID, iTypePids) ;
  push_back(pNewPerson) ;
  return back() ;
}

NSPersonInfo *
NSPersonArray::createPerson(PIDSTYPE iTypePids)
{
  NSPatPathoArray PatPathoData(pContexte, graphPerson) ;

  NSSmallBrother  BigBoss(pContexte, &PatPathoData) ;
  BigBoss.pFenetreMere = pContexte->GetMainWindow() ;

#ifdef __OB1__
	BB1BBInterfaceForKs InterfaceForKs(-1, pContexte->getSuperviseur()->getReferalProfessionnalArchetypeId(), "", false) ;
#endif
  // Ici on lance une boite de dialogue modale
  switch (iTypePids)
  {
    case pidsPatient	:	break ;
    case pidsCorresp	:
#ifdef __OB1__
    	BigBoss.lanceBbkArchetypeInDialog(pContexte->getSuperviseur()->getReferalProfessionnalArchetypeId(), 0, 0, &InterfaceForKs, true) ;
#else
    	BigBoss.lanceBbkArchetypeInDialog(pContexte->getSuperviseur()->getReferalProfessionnalArchetypeId(), 0, 0, true) ;
#endif
      break ;
    case pidsUtilisat	:	break ;
  }

  // on teste le code de retour du dialogue, qui est stock� dans le
  // BBItem root cr�� par le pBigBoss.
  if (BigBoss.pBBItem->iRetourDlg == 0)     // CmOK
  {
    // on enregistre la patpatho du pBigBoss, qui contient les nouvelles donn�es
    // si elle n'est pas vide.
    if (!(BigBoss.getPatPatho()->empty()))
    {
      PatPathoData = *(BigBoss.getPatPatho()) ;

      NSPersonInfo *pNewPerson = new NSPersonInfo(pContexte, &PatPathoData, iTypePids) ;
      push_back(pNewPerson) ;
      return back() ;
    }
  }
  return NULL ;
}

bool
NSPersonArray::modifyPerson(string sID, string sRoles, PIDSTYPE iTypePids)
{
	// Modify "as a correspondant"
  //
	if (pidsCorresp == iTypePids)
  {
  	// Is she also a Patient?
    //
  	size_t iPatientPos  = sRoles.find(PATIENT_ROLE) ;
    //
    // If not also a Patient, do as usual
    //
    if (NPOS == iPatientPos)
    {
    	NSPatPathoArray PatPathoData(pContexte, graphPerson) ;
  		NSPersonGraphManager GraphManager(pContexte) ;
  		bool bVerbose = false ;
      if (GraphManager.getGraphAdmin(sID, bVerbose, iTypePids, &PatPathoData))
      {
      	GraphManager.setAttributeValue(PIDS, sID) ;
        GraphManager.setAttributeValue(PERSON, GraphManager.getPersonID()) ;
				GraphManager.setAttributeValue(OPERATOR, pContexte->getUtilisateurID()) ;
				GraphManager.setAttributeValue(CONSOLE,  string(pContexte->getSuperviseur()->getConsole())) ;
				// GraphManager.setAttributeValue(INSTANCE, string(szInstance)) ;

      	NSSmallBrother BigBoss(pContexte, &PatPathoData) ;
    		BigBoss.pFenetreMere = pContexte->GetMainWindow() ;
#ifdef __OB1__
				BB1BBInterfaceForKs InterfaceForKs(-1, pContexte->getSuperviseur()->getReferalProfessionnalArchetypeId(), "", false) ;
				BigBoss.lanceBbkArchetypeInDialog(pContexte->getSuperviseur()->getReferalProfessionnalArchetypeId(), 0, 0, &InterfaceForKs, true) ;
#else
				BigBoss.lanceBbkArchetypeInDialog(pContexte->getSuperviseur()->getReferalProfessionnalArchetypeId(), 0, 0, true) ;
#endif
      	// on teste le code de retour du dialogue, qui est stock� dans le BBItem
    		// root cr�� par le pBigBoss.
    		if (BigBoss.pBBItem->iRetourDlg == 0)     // CmOK
    		{
      		// on enregistre la patpatho du pBigBoss, qui contient les nouvelles donn�es
      		// si elle n'est pas vide.
      		if (!(BigBoss.getPatPatho()->empty()))
      		{
        		PatPathoData = *(BigBoss.getPatPatho()) ;
            if (false == GraphManager.setBothAttributes(&PatPathoData, NSPersonGraphManager::attribsUpdate))
            	return false ;
            // pUtilInfo->pGraphPerson->setInfoPids(&AttrList) ;
        		if (false == GraphManager.setGraphAdmin(&PatPathoData, pidsCorresp))
        			return false ;
        		return true ;
      		}
    		}
			}
    }
    //
    // If also a Patient, ask what part to edit
    //
    else
    {
    	whatToEditDialog sayWhot(pContexte->GetMainWindow(), sRoles, pContexte) ;
      int idRet = sayWhot.Execute() ;
      if (idRet != IDOK)
      	return true ;

      NSPatPathoArray PatPathoData(pContexte, graphPerson) ;
  		NSPersonGraphManager GraphManager(pContexte) ;
  		bool bVerbose = false ;
      if (false == GraphManager.getGraphAdmin(sID, bVerbose, iTypePids, &PatPathoData))
      	return false ;

      NSPatPathoArray PatPathoPerso(pContexte, graphPerson) ;
      NSPatPathoArray PatPathoPro(pContexte, graphPerson) ;

      if (false == PatPathoData.empty())
      	GraphManager.partDualPatho(&PatPathoData, &PatPathoPerso, &PatPathoPro) ;

      if (sayWhot.isPersonalDataActive())
      {
      	NSSmallBrother BigBoss(pContexte, &PatPathoPerso) ;
    		BigBoss.pFenetreMere = pContexte->GetMainWindow() ;
        string sArchetypeId = pContexte->getSuperviseur()->getDemographicArchetypeId() ;
#ifdef __OB1__
				BB1BBInterfaceForKs InterfaceForKs(-1, sArchetypeId, "", false) ;
				BigBoss.lanceBbkArchetypeInDialog(sArchetypeId, 0, 0, &InterfaceForKs, true) ;
#else
				BigBoss.lanceBbkArchetypeInDialog(sArchetypeId, 0, 0, true) ;
#endif

				if ((0 == BigBoss.pBBItem->iRetourDlg) &&
            (*(BigBoss.getPatPatho()) != PatPathoPerso))
        	PatPathoPerso = *(BigBoss.getPatPatho()) ;
      }
      if (sayWhot.isProfessionalDataActive())
      {
      	NSSmallBrother BigBoss(pContexte, &PatPathoPro) ;
    		BigBoss.pFenetreMere = pContexte->GetMainWindow() ;
        string sArchetypeId = pContexte->getSuperviseur()->getReferalProfessionnalEditArchetypeId() ;
#ifdef __OB1__
				BB1BBInterfaceForKs InterfaceForKs(-1, sArchetypeId, "", false) ;
				BigBoss.lanceBbkArchetypeInDialog(sArchetypeId, 0, 0, &InterfaceForKs, true) ;
#else
				BigBoss.lanceBbkArchetypeInDialog(sArchetypeId, 0, 0, true) ;
#endif

				if ((0 == BigBoss.pBBItem->iRetourDlg) &&
            (*(BigBoss.getPatPatho()) != PatPathoPro))
        	PatPathoPro = *(BigBoss.getPatPatho()) ;
      }

      // Concatenating both patPatho
      //
      NSPatPathoArray newPatPathoData(pContexte, graphPerson) ;
      GraphManager.buildDualPatho(&newPatPathoData, &PatPathoPerso, &PatPathoPro) ;

      if (newPatPathoData != PatPathoData)
      {
      	// pUtilInfo->pGraphPerson->setInfoPids(&AttrList) ;
        bool bRet = GraphManager.setGraphAdmin(&newPatPathoData, pidsCorresp) ;
        if (false == bRet)
        	return false ;
      }
    }
  }

	return false ;
}

// fin du fichier nsmpids.cpp

