// --------------------------------------------------------------------------// NSSOAPVIEW.CPP		Document/Vues SOAP
// --------------------------------------------------------------------------
// Fabrice LE PERRU - Novembre/D�cembre 2001
// source : Fabrice LE PERRU -- nsepisodview.cpp - Aout 2001
//          -- source : R�mi SPAAK - Mai 1997
// --------------------------------------------------------------------------

#include <owl/uihelper.h>
#include <owl\owlpch.h>
#include <owl\validate.h>
#include <owl\inputdia.h>
#include <owl\splitter.h>
//#include <nautilus\nsSOAPview.h>
#include <fstream.h>
#include <stdlib.h>

#include <bwcc.h>
#include <owl/button.h>

#include "nautilus\nssuper.h"
#include "nsbb\nsmview.h"
#include "nsbb\nspanesplitter.h"
#include "nautilus\nscqvue.h"
#include "nsbb\nsdlg.h"
#include "nsbb\nsattvaltools.h"
#include "nsbb\nsarc.h"

#include "nsbb\nsbb.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbbsmal.h"
#include "nsbb\nstrewi.h"
#include "nsbb\nsedilex.h"
#include "nsbb\nsedit.h"
#include "nsbb\nsdico.h"
#include "nsbb\nsbouton.h"
#include "nsbb\nschkbox.h"
#include "nsbb\nsradiob.h"
#include "nsbb\nsgroupe.h"
#include "nsbb\nsonglet.h"
#include "nsbb\nscombo.h"
#include "nsbb\nslistwind.h"
#include "nsbb\nstabwindow.h"

#include "nssavoir\nsconver.h"

#include "nautilus\nsepicap.h"
#include "nautilus\nsldvdoc.h"

#include "partage\ns_timer.h"
#include "ns_ob1\OB1.rh"
#include "nautilus\nautilus.rh"
#include "nsbb\nsbb.rh"

const char codeMARK = 'O' ;

// --------------------------------------------------------------------------
//
//		   METHODES DES VUES GENERALES DU MODELE Document / Vue de MUE
//
// --------------------------------------------------------------------------


// --------------------------------------------------------------------------
//
// Class NSMUEView
//
// --------------------------------------------------------------------------

// Table de r�ponses
DEFINE_RESPONSE_TABLE1(NSMUEView, TWindowView)
    EV_VN_ISWINDOW,
    EV_WM_SIZE,
    EV_WM_MOVE,
    EV_WM_PAINT,
    EV_WM_WINDOWPOSCHANGED,
    EV_WM_DESTROY,
    EV_WM_KEYDOWN,
    EV_WM_SETFOCUS,
END_RESPONSE_TABLE ;

// ConstructeurNSMUEView::NSMUEView(NSContexte* pCtx, TDocument* doc, TWindow *parent, string sFunction, string sDoc, string sPreoccu)
          :TWindowView(*doc, parent), NSRoot(pCtx)
//            :TView(*doc), TWindow(parent), NSRoot(pCtx)
{
try
{
	pDoc        = doc ;
  sFonction   = sFunction ;
  sPreoccup   = sPreoccu ;
  sDocType    = sDoc ;

  bFirstSetup = true ;
  //
  // On r�f�rence cette fen�tre au niveau du Superviseur
  //

  bSetupToolBar = true ;

  pCreateWindow = NULL ;
  pSplittedWindow = NULL ;
  pDialog = NULL ;
  splitDir = psNone ;
  percent = 0.0 ;
  uButtonsStyle = MYWS_NONE ;

  pMUEViewMenu  = 0 ;
}
catch (...)
{
	erreur("Exception NSMUEView ctor.", standardError, 0) ;
}
}

// DestructeurNSMUEView::~NSMUEView()
{
	if (pMUEViewMenu)
  	delete pMUEViewMenu ;
}

void
NSMUEView::concernChanged(string sConcern)
{
}

// GetWindow renvoie this (� red�finir car virtual dans TView)TWindow*
NSMUEView::GetWindow()
{
	return (TWindow*) this;
}

// Appel de la fonction de remplissage de la vue
void
NSMUEView::SetupWindow()
{
try
{
	SetWindowPosit() ;

	//TWindowView::SetupWindow();
  TWindow::SetupWindow() ;
  bFirstSetup = false ;
}
catch (...)
{
	erreur("Exception NSMUEView::SetupWindow.", standardError, 0) ;
}
}

// Fonction CanClose : Appel de CanClose du documentbool
NSMUEView::CanClose()
{
	TMyApp *pMyApp = pContexte->getSuperviseur()->getApplication() ;
  pMyApp->FlushControlBar() ;
  bSetupToolBar = false ;
  return true ;
}

//
// Does a given HWND belong to this view? Yes if it is us, or a child of us
//
boolNSMUEView::VnIsWindow(HWND hWnd)
{
	return hWnd == GetHandle() || IsChild(hWnd) ;
}

bool
NSMUEView::PreProcessMsg(MSG &msg)
{
  PRECONDITION(GetHandle()) ;
  return hAccelerator ? ::TranslateAccelerator(GetHandle(), hAccelerator, &msg) : false ;
}

void
NSMUEView::addConcernTitle()
{
	if (sPreoccup == "")
		return ;

	NSLdvDocument *pLdvDoc = pContexte->getPatient()->pDocLdv ;
	ArrayConcern  *pConcernArray = pLdvDoc->getConcerns() ;
	if (!pConcernArray)
		return ;

	NSConcern* pConcern = pConcernArray->getConcern(sPreoccup) ;
	if (pConcern)
		sViewName += string(" - ") + pConcern->sTitre ;
}

voidNSMUEView::EvDestroy()
{
   // RecordWindowPosit();
}

void
NSMUEView::EvKeyDown(uint key, uint repeatCount, uint flags)
{
	if      (key == VK_TAB)
  {
  	if (GetKeyState(VK_SHIFT) < 0)
    	pPaneSplitter->setFocusToPrevView(this, HWindow) ;
    else
    	pPaneSplitter->setFocusToNextView(this, HWindow) ;
  }
  else
  	TWindowView::EvKeyDown(key, repeatCount, flags) ;
}

void
NSMUEView::EvSetFocus(HWND hWndLostFocus)
{
	pPaneSplitter->pCurrentFocusedView = this ;

	TWindowView::EvSetFocus(hWndLostFocus) ;

  activateMUEViewMenu() ;
}

void
NSMUEView::setFocusToNextSplitterView()
{
	pPaneSplitter->setFocusToNextView(this, HWindow) ;
}


void
NSMUEView::setFocusToPrevSplitterView()
{
	pPaneSplitter->setFocusToPrevView(this, HWindow) ;
}

void
NSMUEView::SetWindowPosit()
{
	Parent->Show(SW_HIDE) ;
  NS_CLASSLIB::TRect rectDlg = Parent->GetWindowRect() ;//coordonn�es par % � l'�cran
  int     X,Y,W,H ;
  string  sTaille ;
  NS_CLASSLIB::TPoint point(rectDlg.X(), rectDlg.Y()) ;
  Parent->Parent->ScreenToClient(point) ;
  X = rectDlg.X() ;
  Y = rectDlg.Y() ;
  W = rectDlg.Width() ;
  H = rectDlg.Height() ;

  NSWindowProperty* pWinProp = pContexte->getUtilisateur()->aWinProp.getProperty(sFonction) ;
  if (pWinProp)
  {
  	X = pWinProp->X() ;
    Y = pWinProp->Y() ;
    W = pWinProp->W() ;
    H = pWinProp->H() ;
  }

  //
  // fixer la nouvelle position
  // (on ne tient pas compte de la taille, vu le probleme pour restaurer
  //  une fenetre TView,TWindow mise en icone)
  //
	Parent->SetWindowPos(0, X, Y, W, H, SWP_NOZORDER) ;
  Parent->Show(SW_SHOWNORMAL) ;
}

/*void
NSMUEView::RecordWindowPosit()
{
    NS_CLASSLIB::TRect rectDlg = Parent->GetWindowRect();//coordonn�es par % � l'�cran
    int X,Y,W,H;
    NS_CLASSLIB::TPoint point(rectDlg.X(), rectDlg.Y());
    Parent->Parent->ScreenToClient(point);
    X = point.X();
  	Y = point.Y();
    W = rectDlg.Width();
    H = rectDlg.Height();

    if (Parent->IsIconic())
        return ;

    string sUserId = string(pContexte->getUtilisateur()->pDonnees->indice) ;
    NS_CLASSLIB::TRect  rect(X, Y, X + W, Y + H) ;
    pContexte->getUtilisateur()->aWinProp.setProperty(sUserId, sFonction, rect, pContexte->PathName("FGLO")) ;
} */

// fonction permettant de prendre toute la taille de TWindow par la TListWindow
void
NSMUEView::EvSize(uint sizeType, ClassLib::TSize& size)
{
	TWindow::EvSize(sizeType, size) ;
}


voidNSMUEView::EvMove(ClassLib::TPoint& clientOrigin)
{
  TWindow::EvMove(clientOrigin);
}


voidNSMUEView::EvWindowPosChanged(WINDOWPOS far& windowPos)
{
  TWindow::EvWindowPosChanged(windowPos);
}


voidNSMUEView::gotMoved()
{
}

voidNSMUEView::EvPaint(){
	TWindow::EvPaint() ;
}

//   bDependence = true  -> fenetre maitre
//   bDependence = false -> fenetre esclave
//  par defeult la fenetre est maitre

/*void
NSMUEView::setDependance(bool bDep)
{
      bDependence = bDep;
}

bool
NSMUEView:: getDependance()
{
      return  bDependence;
} */


TWindow*
NSMUEView:: getCreateWindow()
{
	return pCreateWindow ;
}

TWindow*
NSMUEView:: getSplittedWindow()
{
	return pSplittedWindow ;
}

void
NSMUEView::newWindow(string sWndChild)
{
	if (sWndChild == "")
		return ;

	NSSuper* pSuper = pContexte->getSuperviseur();
	NSToDoTask* pTask = new NSToDoTask;
	pTask->sWhatToDo = "OpenNewWindow";
	pTask->pPointer1 = (void*)this;
	//pTask->pPointer2 = (void*)pDoc;
	pTask->sParam1   = sWndChild;

	pSuper->addToDo(pTask) ;
}

void
NSMUEView::focusView()
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;
	NSToDoTask* pTask = new NSToDoTask ;
	pTask->sWhatToDo = "FocusWindow" ;
	pTask->pPointer1 = (void*)this ;

	pSuper->addToDo(pTask) ;
}

void
NSMUEView::activate()
{
	if ((NULL == pPaneSplitter) || (NULL == pPaneSplitter->pMDIChild))
		return ;

	if (false == pPaneSplitter->pMDIChild->IsWindow())
  	return ;

	::SetFocus(pPaneSplitter->pMDIChild->GetHandle()) ;
}

bool
NSMUEView::Create()
{
	if (this->IsWindow())
		return false ;
	OWL::TWindow::Create() ;
	return true ;
}

void
NSMUEView::activateParent()
{
	activateMUEViewMenu() ;
	//pPaneSplitter->pMDIChild->GetHandle()) ;
	pPaneSplitter->activateParent() ;
  pPaneSplitter->SetFrameTitle(getFunction(), sViewName) ;
}

void
NSMUEView::initMUEViewMenu(string sMenuName)
{
	if (pMUEViewMenu)
  	delete pMUEViewMenu ;

	nsMenuIniter menuIter(pContexte) ;
	pMUEViewMenu = new OWL::TMenuDescr ;
  menuIter.initMenuDescr(pMUEViewMenu, sMenuName) ;

	return ;
}

void
NSMUEView::activateMUEViewMenu()
{
	if (!pMUEViewMenu)
		return ;

	TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;
  pMyApp->GetMainWindow()->SetMenuDescr(*pMUEViewMenu) ;

	return ;
}

//-----------------------------------------------------------------------//
//				   	             Classe NSLDVView                              //
//                                                                       //
//                    NSMUEView li�e � NSLdvDocument                     //
//-----------------------------------------------------------------------//

NSLDVView::NSLDVView(NSContexte* pCtx, TDocument* pDoc, TWindow *parent, string sFunction, string sDoc, string sPreoccu)
          :NSMUEView(pCtx, pDoc, parent, sFunction, sDoc, sPreoccu)
{
}

NSLDVView::~NSLDVView()
{
}

//-----------------------------------------------------------------------//
//				   	           Classe NSBBMUEView                              //
//                                                                       //
//                    NSMUEView li�e aux BBItems                         //
//-----------------------------------------------------------------------//

#define ID_TABCTRL 100

DEFINE_RESPONSE_TABLE1(NSBBMUEView, NSMUEView)
  EV_WM_SIZE,
  EV_COMMAND(IDM_BBK_EVENT,      CmBbkEvent),
  EV_TCN_SELCHANGE(ID_TABCTRL,	 TabSelChange),
	EV_TCN_SELCHANGING(ID_TABCTRL, TabSelChanging),
	EV_TCN_KEYDOWN(ID_TABCTRL,		 TabKeyDown),
END_RESPONSE_TABLE ;

NSBBMUEView::NSBBMUEView(NSContexte* pCtx, TDocument* pDoc, TWindow *parent, string sFunction, string sDoc, string sPreoccu)
            :NSMUEView(pCtx, pDoc, parent, sFunction, sDoc, sPreoccu)
{
  pBBItem        = 0 ;
  pNSCtrl        = 0 ;
  m_tabCtrl      = 0 ;
  _tabbedWindows = 0 ;
  _bControlInit  = false ;

  _bWaitingForKsAnswer     = false ;
  _bWaitingForSystemAction = false ;
}

NSBBMUEView::~NSBBMUEView()
{
  if (NULL != pNSCtrl)
    delete pNSCtrl ;

  _tabbedWindows->vider() ;
  delete _tabbedWindows ;
}

void
NSBBMUEView::SetupWindow()
{
  NSMUEView::SetupWindow() ;

  InitMetrics() ;

  CreerControlesArchetype() ;

  // Hide all windows but the first
	if (_tabbedWindows && (false == _tabbedWindows->empty()))
		for (NSWindowsIter i = _tabbedWindows->begin() ; _tabbedWindows->end() != i ; i++)
    {
      if ((NULL != (*i)->controls) && (false == (*i)->controls->empty()))
        for (NSControlsIter j = (*i)->controls->begin(); (*i)->controls->end() != j ; j++)
        {
          SetupWindowForControl(*j) ;
          (*j)->Create() ;

          bool bChildIsVisible = true ; // (((*j)->GetStyle() & WS_VISIBLE) == WS_VISIBLE) ;
          NSControle* pCtrl = getNSControl(*j) ;
          if (pCtrl)
            bChildIsVisible = pCtrl->isVisible() ;

          if ((_tabbedWindows->begin() == i) && bChildIsVisible)
            (*j)->Show(SW_SHOW) ;
          else
            (*j)->Show(SW_HIDE) ;
        }

    	if (_tabbedWindows->begin() != i)
    	{
      	(*i)->Show(SW_HIDE) ;
        // Don't do this because it switchs the control to "NOT WS_VISIBLE"
        // and it becomes undistinguishable from true hidden controls
        // (*i)->EnableWindow(false) ;
      }
    }

  // Make sure controls have been created before following initializations
  //
  initialiseControles() ;
  initControlesFromBbk() ;
  initControlesFromCapture() ;

  rafraichitControles() ;

	// Set to the first tab
  if ((NULL != m_tabCtrl) && (_tabbedWindows->size() > 1))
  {
    SetSelectedTab(0) ;
	  m_tabCtrl->Show(SW_SHOW) ;
    // Don't do this because it switchs the control to "WS_VISIBLE"
    // even for hidden controls
	  // m_tabCtrl->EnableWindow(true) ;
  }

  // Set focus to first control
  SetFocusToNextControl(0) ;
}

void
NSBBMUEView::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectangleAPeindre)
{
  if (false == _tabbedWindows->empty())
		for (NSWindowsIter i = _tabbedWindows->begin() ; _tabbedWindows->end() != i ; i++)
      if ((NULL != (*i)->controls) && (false == (*i)->controls->empty()))
        for (NSControlsIter j = (*i)->controls->begin(); (*i)->controls->end() != j ; j++)
          (*j)->Paint(dc, erase, RectangleAPeindre) ;
}

void
NSBBMUEView::EvSize(uint sizeType, ClassLib::TSize& size)
{
	NSMUEView::EvSize(sizeType, size) ;

  // Adjust tab control to new window size
  if (m_tabCtrl && m_tabCtrl->GetHandle() && (_tabbedWindows->size() > 1))
  {
		m_tabCtrl->SetWindowPos(0, 0, 0, size.cx, size.cy, SWP_NOZORDER | SWP_NOMOVE) ;

    NSOneTabWindow *pSelectedTab = Retrieve(m_tabCtrl->GetSel()) ;
    if ((NULL == pSelectedTab) || (NULL == pSelectedTab->GetHandle()))
      return ;

    ClassLib::TRect rect ;
		m_tabCtrl->GetWindowRect(rect) ;

    // NOTE: GetWindowRect returns screen coordinates... we'll need
		//       to have the coordinates relative to the frame window,
		//       the parent of both the tab and client window
		::MapWindowPoints(HWND_DESKTOP, *this, (LPPOINT)&rect, 2);

    m_tabCtrl->AdjustRect(false, rect) ;

    pSelectedTab->SetWindowPos(0, rect, SWP_NOZORDER) ;
  }
}

// -----------------------------------------------------------------------------
// Description:	Init controls with BBItems information
// -----------------------------------------------------------------------------
void
NSBBMUEView::rafraichitControles()
{
	if (pNSCtrl->empty())
  	return ;

  for (iterNSControle i = pNSCtrl->begin(); (i != pNSCtrl->end()); i++)
  	(*i)->prepareControle() ;
}

void
NSBBMUEView::referenceControle(NSControle* pNSControle)
{
	pNSCtrl->push_back(pNSControle) ;
}

//
// See http://support.microsoft.com/default.aspx?scid=kb;EN-US;145994
//
void
NSBBMUEView::InitMetrics()
{
  // Doesn't work properly because it is based on a claimed "system font"
  // that is seldom used actually 
  //
  // cxSysChar = LOWORD(GetDialogBaseUnits()) ;
  // cySysChar = HIWORD(GetDialogBaseUnits()) ;

  if ((NULL == pBBItem) || (NULL == pBBItem->pParseur) || (NULL == pBBItem->pParseur->pArchetype))
    return ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  Cdialogbox * pDialogBox = pBBItem->pParseur->pArchetype->getDialogBox(sLang) ;
  if (NULL == pDialogBox)
    return ;

  LOGFONT logFont ;
  logFont.lfHeight         = 8 ;
	logFont.lfWidth          = 0 ;
	logFont.lfEscapement     = 0 ;
	logFont.lfOrientation    = 0 ;
	logFont.lfWeight         = FW_NORMAL ;
	logFont.lfItalic         = 0 ;
	logFont.lfUnderline      = 0 ;
	logFont.lfStrikeOut      = 0 ;
	logFont.lfCharSet        = ANSI_CHARSET ;
	logFont.lfOutPrecision   = OUT_TT_PRECIS ;
	logFont.lfClipPrecision  = CLIP_DEFAULT_PRECIS ;
	logFont.lfQuality        = PROOF_QUALITY ;
	logFont.lfPitchAndFamily = VARIABLE_PITCH | FF_ROMAN ;
	strcpy(logFont.lfFaceName, "MS Sans Serif") ;

  string sFontType = pDialogBox->getFontType() ;
  if (string("") != sFontType)
    strcpy(logFont.lfFaceName, sFontType.c_str()) ;

  string sFontSize = pDialogBox->getFontSize() ;
  if (string("") != sFontSize)
    logFont.lfHeight = (LONG) atoi(sFontSize.c_str()) ;

  TScreenDC screenDC ;
  screenDC.SelectObject(TFont(&logFont)) ;

  TEXTMETRIC tm ;
  screenDC.GetTextMetrics(tm) ;

  cySysChar = tm.tmHeight ;

  ClassLib::TSize size = screenDC.GetTextExtent(
           "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", 52) ;
  cxSysChar = (size.X() / 26 + 1) / 2 ;

  char cxValue[35] ;
  itoa(cxSysChar, cxValue, 10) ;
  char cyValue[35] ;
  itoa(cySysChar, cyValue, 10) ;

  string ps = string("NSBBMUEView::InitMetrics") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
  ps = string(" --> cxSysChar = ") + string(cxValue) + string(" ; cySysChar = ") + string(cyValue) ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

  itoa(int(tm.tmAveCharWidth), cxValue, 10) ;
  itoa(int(tm.tmMaxCharWidth), cyValue, 10) ;
  ps = string(" --> tmAveCharWidth = ") + string(cxValue) + string(" ; tmMaxCharWidth = ") + string(cyValue) ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
}

void
NSBBMUEView::CreerControlesArchetype()
{
try
{
  if ((NULL == pBBItem) || (NULL == pBBItem->pParseur) || (NULL == pBBItem->pParseur->pArchetype))
    return ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  Cdialogbox * pDialogBox = pBBItem->pParseur->pArchetype->getDialogBox(sLang) ;
  if (NULL == pDialogBox)
    return ;

  Ccontrol * pControl = pDialogBox->getFirstControl() ;
  if (NULL == pControl)
    return ;

  int hSysButton = 0 ;

  // Tabs management
  //
  _tabbedWindows = new NSWindowsArray() ;

  Ctabcontrol* pTabControl = pDialogBox->getTabControl() ;
  if (NULL != pTabControl)
  {
    // int iWidth  = max(GetClientRect().Width(), 0) ;
    // int iHeight = max(GetClientRect().Height(), 0) ;
    int iWidth  = 0 ;
    int iHeight = 0 ;
    m_tabCtrl = new TTabControl(this, /*NSTabWindow::*/ID_TABCTRL, 0, 0, iWidth, iHeight) ;

    Ctab* pTab = pTabControl->getFirstTab() ;

    // We create the array of tabbedWindows; controls will be added later
	  //
    while (NULL != pTab)
    {
		  string sTitle = pTab->getTitle() ;
		  string sOrder = pTab->getOrder() ;
		  // int    iOrder = atoi(sOrder.c_str()) ;

		  NSOneTabWindow *pWinToAdd = new NSOneTabWindow(this, sTitle.c_str()) ;
		  _tabbedWindows->push_back(pWinToAdd) ;

		  pTab = pTabControl->getNextTab(pTab) ;
	  }
  }
  // If there is no tabs, we create a virtual one
  //
  else
  {
    _tabbedWindows->push_back(new NSOneTabWindow(this, "virtual tab")) ;
    // NSWindowsIter i = _tabbedWindows->begin() ;
    // (*i)->Show(SW_HIDE) ;
  }

  // Crcdata* pRCData        = pDialogBox->getRCData();

  UINT  nMaxInput = 255 ;         // Nombre maximal de caract�res � saisir

  // string sRCData = pRCData->getNSContro();
  string sRCData = pDialogBox->getStringRCData() ;

  int prec = 0, suiv ;
	char szType[25] ;       // Type de contr�le EDIT
  char szEditDateType[2] ;         //type de date dans le controle EDIT (NSEditDate)
  // char szTypeControl[255] ;
  size_t posLex ;

  OWL::TGroupBox *pGroupCurr = 0 ;

  pNSCtrl = new NSControleVector() ;

  suiv = sRCData.find("|") ;

  while (NULL != pControl)
  {
    string sType    = pControl->getType() ;
    string sCoords  = pControl->getCoords() ;
    string sCaption = pControl->getCaption() ;
    string sFilling = pControl->getFilling() ;
    int    ctrlID   = pControl->getRefId() ;

    int    indexTab = 1 ;
    string sTabNb   = pControl->getTab() ;
    if (string("") != sTabNb)
      indexTab = atoi(sTabNb.c_str()) ;

    // conversion du type en majuscules
    pseumaj(&sType) ;

    int coords[4] ;
    coords[0] = getWindowXFromDialogX(pControl->getX()) ;
    coords[1] = getWindowYFromDialogY(pControl->getY()) ;
    coords[2] = getWindowXFromDialogX(pControl->getW()) ;
    coords[3] = getWindowYFromDialogY(pControl->getH()) ;

    string sDlgFonction = "" ;
    string sIdentite    = string(sRCData, prec, suiv - prec) ;

    if (string("") != sIdentite)
    {
      size_t fct_posit = sIdentite.find(':') ;
      if (fct_posit != string::npos)
      {
        if (fct_posit < strlen(sIdentite.c_str()))
          sDlgFonction = string(sIdentite, fct_posit + 1, strlen(sIdentite.c_str())) ;
        sIdentite = string(sIdentite, 0, fct_posit) ;
      }
    }

    // -------------------------------------------------------------------------
    // Traitement suivant le type de contr�le rencontr�

    if (string("SYSTREEVIEW32") == sType)
    {
      // TreeView
      NSTreeWindow * pNSTreeWindow = new NSTreeWindow(this, pContexte, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
      pNSTreeWindow->Attr.Style = pControl->getIStyle() ;

      ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pNSTreeWindow) ;

      pNSTreeWindow->pBBitemNSTreeWindow  = pBBItem ;
      pNSTreeWindow->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      pNSTreeWindow->pControle->setControle(dynamic_cast<void *>(pNSTreeWindow)) ;
      pNSTreeWindow->pControle->setType(pNSTreeWindow->donneType()) ;
      pNSTreeWindow->pControle->setMUEView(this) ;
      pNSTreeWindow->pControle->setFilling(sFilling) ;
      pNSTreeWindow->pControle->setVisible(isControlProperty(pNSTreeWindow, WS_VISIBLE)) ;
      referenceControle(pNSTreeWindow->pControle) ;

      if ((pNSTreeWindow->pControle->getTransfert()) &&
                (pNSTreeWindow->pControle->getTransfert()->pBBFilsItem))
      {
      	BBFilsItem* pSonItem = pNSTreeWindow->pControle->getTransfert()->pBBFilsItem ;
      	BBItem*     pFatherItem = pSonItem->getItemFather() ;
      	pNSTreeWindow->pBBitemNSTreeWindow = pFatherItem ;
        //
    		// Cr�er le deuxi�me BBItem (GCONS le fils en cas de consultation par exemple)
    		//
        if (NULL != pFatherItem)
    		  pFatherItem->developperConsultation(pSonItem) ;
      }
    }

    if (string("SYSLISTVIEW32") == sType)
    {
/*
      // ListView
      if (sIdentite.find(string("LCADR")) != NPOS)
      {
        // Liste d'adresses
        NSAdrListWindow * pNSAdrListWindow = new NSAdrListWindow(this, pContexte, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
        pNSAdrListWindow->Attr.Style = pControl->getIStyle() ;
        pNSAdrListWindow->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pNSAdrListWindow->pControle->setControle(dynamic_cast<void *>(pNSAdrListWindow)) ;
        pNSAdrListWindow->pControle->setType(pNSAdrListWindow->donneType()) ;
        pNSAdrListWindow->pControle->setFilling(sFilling) ;
        pNSAdrListWindow->pControle->setMUEView(this) ;

        // on ajoute ici un indicateur pour pr�ciser que ce controle g�re
        // lui-m�me la gestion multiple sans lancer de multi-dialogue
        pNSAdrListWindow->pControle->setGestionMultiple(true) ;
        referenceControle(pNSAdrListWindow->pControle) ;
      }
      else if (sIdentite.find(string("LCORR")) != NPOS)
      {
        NSCorListWindow * pNSCorListWindow = new NSCorListWindow(this, pContexte, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
        pNSCorListWindow->Attr.Style = pControl->getIStyle() ;
        pNSCorListWindow->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pNSCorListWindow->pControle->setControle(dynamic_cast<void *>(pNSCorListWindow)) ;
        pNSCorListWindow->pControle->setType(pNSCorListWindow->donneType()) ;
        pNSCorListWindow->pControle->setFilling(sFilling) ;
        pNSCorListWindow->pControle->setMUEView(this) ;
        // on ajoute ici un indicateur pour pr�ciser que ce controle g�re
        // lui-m�me la gestion multiple sans lancer de multi-dialogue
        pNSCorListWindow->pControle->setGestionMultiple(true) ;
        referenceControle(pNSCorListWindow->pControle) ;
      }
      else
      {
*/
        string sItem ;
        size_t pos = sIdentite.find_last_of('/') ;
        if (pos != NPOS)
          sItem = string(sIdentite, pos + 1, strlen(sIdentite.c_str()) - pos - 1) ;
        else
          sItem = sIdentite ;

        if (sItem[0] == 'V')
        {
          NSHistorizedValListWindow * pNSHistoListWindow = new NSHistorizedValListWindow(this, pContexte, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
          pNSHistoListWindow->Attr.Style = pControl->getIStyle() ;
          pNSHistoListWindow->setItemValue(sItem) ;

          ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pNSHistoListWindow) ;

          pNSHistoListWindow->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
          pNSHistoListWindow->pControle->setControle(dynamic_cast<void *>(pNSHistoListWindow)) ;
          pNSHistoListWindow->pControle->setType(pNSHistoListWindow->donneType()) ;
          pNSHistoListWindow->pControle->setFilling(sFilling) ;
          pNSHistoListWindow->pControle->setVisible(isControlProperty(pNSHistoListWindow, WS_VISIBLE)) ;
          pNSHistoListWindow->pControle->setMUEView(this) ;

          // on ajoute ici un indicateur pour pr�ciser que ce controle g�re
          // lui-m�me la gestion multiple sans lancer de multi-dialogue
          pNSHistoListWindow->pControle->setGestionMultiple(true) ;
          referenceControle(pNSHistoListWindow->pControle) ;
        }
        else
        {
          NSHistorizedListWindow * pNSHistoListWindow = new NSHistorizedListWindow(this, pContexte, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
          pNSHistoListWindow->Attr.Style = pControl->getIStyle() ;

          ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pNSHistoListWindow) ;

          pNSHistoListWindow->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
          pNSHistoListWindow->pControle->setControle(dynamic_cast<void *>(pNSHistoListWindow)) ;
          pNSHistoListWindow->pControle->setType(pNSHistoListWindow->donneType()) ;
          pNSHistoListWindow->pControle->setFilling(sFilling) ;
          pNSHistoListWindow->pControle->setVisible(isControlProperty(pNSHistoListWindow, WS_VISIBLE)) ;
          pNSHistoListWindow->pControle->setMUEView(this) ;

          // on ajoute ici un indicateur pour pr�ciser que ce controle g�re
          // lui-m�me la gestion multiple sans lancer de multi-dialogue
          pNSHistoListWindow->pControle->setGestionMultiple(true) ;
          referenceControle(pNSHistoListWindow->pControle) ;
        }
      // }
    }

    if (string("VALLISTVIEW32") == sType)
    {
      // contr�le vallistview - from FLP
      NSHistorizedValListWindow * pNSHistoValWindow = new NSHistorizedValListWindow(this, pContexte, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
      pNSHistoValWindow->Attr.Style = pControl->getIStyle() ;

      ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pNSHistoValWindow) ;

      pNSHistoValWindow->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      pNSHistoValWindow->pControle->setControle(dynamic_cast<void*>(pNSHistoValWindow)) ;
      pNSHistoValWindow->pControle->setType(pNSHistoValWindow->donneType()) ;
      pNSHistoValWindow->pControle->setFilling(sFilling);
      pNSHistoValWindow->pControle->setVisible(isControlProperty(pNSHistoValWindow, WS_VISIBLE)) ;
      pNSHistoValWindow->pControle->setMUEView(this) ;
      // on ajoute ici un indicateur pour pr�ciser que ce controle g�re lui-m�me
      // la gestion multiple sans lancer de multi-dialogue
      pNSHistoValWindow->pControle->setGestionMultiple(true) ;
      referenceControle(pNSHistoValWindow->pControle) ;
    }

    if (string("EDIT") == sType)
    {
      // Contr�le Edit
      string sIden = "" ;
      if ((sIdentite.find(string("�C;")) != NPOS) || (sIdentite.find(string("/�C;")) != NPOS))
      {
        // NSEdit qui bosse avec le lexique
        NSEditLexique * pNSEdit = new NSEditLexique(this, pContexte, ctrlID,
                                                    pContexte->getSuperviseur()->getDico(),
                                                    "",
                                                    coords[0], coords[1],
                                                    coords[2], coords[3],
                                                    nMaxInput + 1) ;
        pNSEdit->Attr.Style = pControl->getIStyle() ;

        ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pNSEdit) ;

        pNSEdit->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pNSEdit->pControle->setControle(dynamic_cast<void *>(pNSEdit)) ;
        pNSEdit->pControle->setType(pNSEdit->donneType()) ;
        pNSEdit->pControle->setFilling(sFilling) ;
        pNSEdit->pControle->setVisible(isControlProperty(pNSEdit, WS_VISIBLE)) ;
        pNSEdit->pControle->setMUEView(this) ;
        referenceControle(pNSEdit->pControle) ;
      }
      else if (sIdentite.find(string("�CC")) != NPOS)
      {        // Champ edit qui n'ouvre pas le lexique et aliment Complement        NSEditNoLex * pEdit ;        strcpy(szType, "C0") ;        posLex = sIdentite.find(string("�CC")) ;        string sElemLex = string(sIdentite, posLex, BASE_LEXIQUE_LEN) ;        string sLen = string(sElemLex, 4, 2) ;        int iLen = atoi(sLen.c_str()) ;        pEdit = new NSEditNoLex(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang, iLen) ;        pEdit->Attr.Style = pControl->getIStyle() ;        ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pEdit) ;        pEdit->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;        pEdit->pControle->setControle(dynamic_cast<void *>(pEdit)) ;
        pEdit->pControle->setType(pEdit->donneType()) ;
        pEdit->pControle->setFilling(sFilling) ;
        pEdit->pControle->setVisible(isControlProperty(pEdit, WS_VISIBLE)) ;
        pEdit->pControle->setMUEView(this) ;
        referenceControle(pEdit->pControle) ;
      }
      else if (sIdentite.find(string("�CL")) != NPOS)      {        // Champ edit qui n'ouvre pas le lexique et alimente Texte libre        NSEditNoLex* pEdit ;        posLex = sIdentite.find(string("�CL")) ;        string sElemLex = string(sIdentite, posLex, BASE_LEXIQUE_LEN) ;        strcpy(szType, string(sElemLex, 2, 2).c_str()) ;        string sLen = string(sElemLex, 4, 2) ;        int iLen = atoi(sLen.c_str()) ;        pEdit = new NSEditNoLex(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang, iLen) ;        pEdit->Attr.Style = pControl->getIStyle() ;        ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pEdit) ;        pEdit->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;        pEdit->pControle->setControle(dynamic_cast<void *>(pEdit)) ;
        pEdit->pControle->setType(pEdit->donneType()) ;
        pEdit->pControle->setFilling(sFilling) ;
        pEdit->pControle->setVisible(isControlProperty(pEdit, WS_VISIBLE)) ;
        pEdit->pControle->setMUEView(this) ;
        referenceControle(pEdit->pControle) ;
      }
      else
      {
        // Type de saisie dans le contr�le
        string sLivre ;
        string sTypeDate ;
        size_t pos = sIdentite.find(string("�")) ;
        if (pos != NPOS)
        {
          sLivre = string(sIdentite, pos + 1, 1) ;
          strcpy(szType, sLivre.c_str()) ;

          sTypeDate = string(sIdentite, pos + 2, 1) ;
          strcpy(szEditDateType, sTypeDate.c_str()) ;
        }

        // Cr�ation de l'objet OWL correspondant � l'objet d'interface
        NSEdit* pEdit = NULL ;
        WNDTYPE	iEditType = isEdit ;
        switch (szType[0])
        {
          case codeMARK       : pEdit = new NSEdit(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang) ;
                                break ;
          case nbMARK         : pEdit = new NSEdit(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang) ;
                                break ;
          case charMARK       : pEdit = new NSEdit(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang) ;
                                break ;
          case dateMARK       : // NSEditDate*
                                pEdit = new NSEditDate(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang, szEditDateType[0]) ;
                                iEditType = isEditDate ;
                                break ;
          case dateHeureMARK  : pEdit = new NSEditDateHeure(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang, szEditDateType[0]) ;
                                iEditType = isEditDateHeure ;
                                break ;
          case heureMARK      : pEdit = new NSEditHeure(pContexte, this, ctrlID, szType, "", coords[0], coords[1], coords[2], coords[3], sLang) ;
                                break ;
          default             : string sErrMess = string("Unknown Edit type : ") + string(1, szType[0]) ;
                                erreur(sErrMess.c_str(), standardError, 0) ;
        }

        if (pEdit)
        {
        	pEdit->Attr.Style = pControl->getIStyle() ;

          ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pEdit) ;

          pEdit->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
          pEdit->pControle->setControle(dynamic_cast<void *>(pEdit)) ;
          // pEdit->pControle->setType(pEdit->donneType()) ; // doesn't work, always set a isEdit type
          pEdit->pControle->setType(iEditType) ;
          pEdit->pControle->setFilling(sFilling) ;
          pEdit->pControle->setVisible(isControlProperty(pEdit, WS_VISIBLE)) ;
          pEdit->pControle->setMUEView(this) ;
          referenceControle(pEdit->pControle) ;
        }
      }
    }

    // Static
    if ((string("STATIC") == sType) || (string("BORSTATIC") == sType))
    {
      // Cr�ation de l'objet OWL correspondant � l'objet d'interface
      NSStatic* pNSStatic = new NSStatic(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
      pNSStatic->Attr.Style = pControl->getIStyle() ;

      ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pNSStatic) ;

      pNSStatic->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      pNSStatic->pControle->setControle(dynamic_cast<void *>(pNSStatic)) ;
      pNSStatic->pControle->setType(pNSStatic->donneType()) ;
      pNSStatic->pControle->setFilling(sFilling) ;
      pNSStatic->pControle->setVisible(isControlProperty(pNSStatic, WS_VISIBLE)) ;
      pNSStatic->pControle->setMUEView(this) ;
      referenceControle(pNSStatic->pControle) ;
    }

    if ((string("BUTTON") == sType) &&
             (IDOK   != ctrlID) && (IDCANCEL   != ctrlID) &&
             (IDB_OK != ctrlID) && (IDB_CANCEL != ctrlID))
    {
      // Contr�le Button (� voir pour OK et Cancel)

      // -----------------------------------------------------------------------
      // ATTENTION : Il faut penser � tester du plus grand au plus petit sinon
      // un groupbox r�pond oui � radiobouton (par exemple)
      // #define BS_PUSHBUTTON       0x00000000L
      // #define BS_DEFPUSHBUTTON    0x00000001L
      // #define BS_CHECKBOX         0x00000002L
      // #define BS_AUTOCHECKBOX     0x00000003L
      // #define BS_RADIOBUTTON      0x00000004L
      // #define BS_3STATE           0x00000005L
      // #define BS_AUTO3STATE       0x00000006L
      // #define BS_GROUPBOX         0x00000007L
      // #define BS_USERBUTTON       0x00000008L
      // #define BS_AUTORADIOBUTTON  0x00000009L

      // D�termination du style
      // int nIndex = ::GetWindowLong(hWnd, GWL_STYLE);
      int nIndex = pControl->getIStyle();

      if ((nIndex & BS_AUTORADIOBUTTON) == BS_AUTORADIOBUTTON)      {
        // Contr�le AutoRadioButton

        // Cr�ation de l'objet OWL correspondant � l'objet d'interface
        NSRadioButton * pRaBut = new NSRadioButton(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3], pGroupCurr) ;
        pRaBut->Attr.Style = pControl->getIStyle() ;

        ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pRaBut) ;

        pRaBut->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pRaBut->pControle->setControle(dynamic_cast<void *>(pRaBut)) ;
        pRaBut->pControle->setType(pRaBut->donneType()) ;
        pRaBut->pControle->setFilling(sFilling) ;
        pRaBut->pControle->setVisible(isControlProperty(pRaBut, WS_VISIBLE)) ;
        pRaBut->pControle->setMUEView(this) ;
        referenceControle(pRaBut->pControle) ;
      }
      else if ((nIndex & BS_GROUPBOX) == BS_GROUPBOX)
      {
        // Contr�le Groupbox
        if (sIdentite != "")
        {
          NSGroupBox * pGrpBox = new NSGroupBox(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
          pGrpBox->Attr.Style = pControl->getIStyle() ;

          ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pGrpBox) ;

          pGrpBox->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
          pGrpBox->pControle->setControle(dynamic_cast<void *>(pGrpBox)) ;
          pGrpBox->pControle->setType(pGrpBox->donneType()) ;
          pGrpBox->pControle->setFilling(sFilling) ;
          pGrpBox->pControle->setVisible(isControlProperty(pGrpBox, WS_VISIBLE)) ;
          pGrpBox->pControle->setMUEView(this) ;
          referenceControle(pGrpBox->pControle) ;
          pGroupCurr = (OWL::TGroupBox *)pGrpBox ;
        }
        else
        {
          OWL::TGroupBox* pGroupBox = new OWL::TGroupBox(this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
          pGroupBox->Attr.Style = pControl->getIStyle() ;

          ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pGroupBox) ;

          // aGroups.push_back(pGroupBox) ;
          pGroupCurr = pGroupBox ;
        }
      }
      else if ((nIndex & BS_RADIOBUTTON) == BS_RADIOBUTTON)
      {        // Contr�le RadioButton

        // Cr�ation de l'objet OWL correspondant � l'objet d'interface
        NSRadioButton * pRaBut = new NSRadioButton(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3], pGroupCurr) ;
        pRaBut->Attr.Style = pControl->getIStyle() ;

        ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pRaBut) ;

        pRaBut->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pRaBut->pControle->setControle(dynamic_cast<void *>(pRaBut)) ;
        pRaBut->pControle->setType(pRaBut->donneType()) ;
        pRaBut->pControle->setFilling(sFilling) ;
        pRaBut->pControle->setVisible(isControlProperty(pRaBut, WS_VISIBLE)) ;
        pRaBut->pControle->setMUEView(this) ;
        referenceControle(pRaBut->pControle) ;
      }
      else if (((nIndex& BS_CHECKBOX) == BS_CHECKBOX) || ((nIndex& BS_AUTOCHECKBOX) == BS_AUTOCHECKBOX))
      {
        // Contr�le CheckBox
        NSCheckBox * pChkBox = new NSCheckBox(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3], pGroupCurr) ;
        pChkBox->Attr.Style = pControl->getIStyle() ;

        ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pChkBox) ;

        pChkBox->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pChkBox->pControle->setControle(dynamic_cast<void *>(pChkBox)) ;
        pChkBox->pControle->setType(pChkBox->donneType()) ;
        pChkBox->pControle->setFilling(sFilling) ;
        pChkBox->pControle->setVisible(isControlProperty(pChkBox, WS_VISIBLE)) ;
        pChkBox->pControle->setMUEView(this) ;
        referenceControle(pChkBox->pControle) ;
      }
      else
      {
        // Contr�le Button (par d�faut ne participe au transfert )
        NSButton * pButt = new NSButton(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
        pButt->Attr.Style = pControl->getIStyle() ;

        ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pButt) ;

        pButt->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pButt->pControle->setControle(dynamic_cast<void *>(pButt)) ;
        pButt->pControle->setType(pButt->donneType()) ;
        pButt->pControle->setFilling(sFilling) ;
        pButt->pControle->setVisible(isControlProperty(pButt, WS_VISIBLE)) ;
        pButt->pControle->setMUEView(this) ;
        referenceControle(pButt->pControle) ;
      }
    }
    else if (string("BUTTON") == sType)
    {
      TButton* pButt = new TButton(this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
      pButt->Attr.Style = pControl->getIStyle() ;

      // Les boutons OK et CANCEL ne sont pas cr��s dans la vue
      // OK and CANCEL buttons are not created inside the view
      //
      if ((IDOK == ctrlID) || (IDCANCEL == ctrlID))
      {
        if      (IDOK == ctrlID)
          uButtonsStyle |= MYWS_OK ;
        else if (IDCANCEL == ctrlID)
          uButtonsStyle |= MYWS_CANCEL ;
      }
      // IDB_OK and IDB_CANCEL are not created in windows (they are in dialogs)
      //
      else if ((IDB_OK != ctrlID) && (IDB_CANCEL != ctrlID))
      {
      	// Bouton systeme : ne pas referencer dans les controles de tabbedWindows
        TButton* pButt = new TButton(this, ctrlID, sCaption.c_str(),
                                            coords[0], coords[1], coords[2], coords[3]);
        pButt->Attr.Style = pControl->getIStyle() ;

        if ((coords[1] + coords[3]) > hSysButton)
        	hSysButton = coords[1] + coords[3] ;
      }
    }

    if (string("SCROLLBAR") == sType)
    {
      // Contr�le ScrollBar
      int nIndex = pControl->getIStyle() ;
      if ((nIndex& WS_HSCROLL) == WS_HSCROLL)
      {        // Cr�ation de l'objet OWL correspondant � l'objet d'interface
        TScrollBar* pScroll = new TScrollBar(this, ctrlID, coords[0], coords[1], coords[2], coords[3], true) ;
        pScroll->Attr.Style = pControl->getIStyle() ;
        ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pScroll) ;
      }
      else
      {
        // Cr�ation de l'objet OWL correspondant � l'objet d'interface
        TScrollBar* pScroll = new TScrollBar(this, ctrlID, coords[0], coords[1], coords[2], coords[3], false) ;
        pScroll->Attr.Style = pControl->getIStyle() ;
        ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pScroll) ;
      }
      // typeCtrl = "ScrollBar" ;
    }
    // BORLAND : Contr�le Bouton
    if ((string("BORBTN") == sType) &&  (ctrlID != IDOK)          && (ctrlID != IDCANCEL)     &&
                                        (ctrlID != IDB_OK)        && (ctrlID != IDB_CANCEL)   &&
                                        (ctrlID != IDRETOUR)      && (ctrlID != IDSUITE)      &&
                                        (ctrlID != IDHELP)        && (ctrlID != IDHELPWWW)    &&
                                        (ctrlID != IDHELPNEW)     && (ctrlID != IDTREEPASTE)  &&
                                        (ctrlID != IDCONCLUSION)  && (ctrlID != IDBBKCALCUL))
    {
      // D�termination du style
      // int nIndex = ::GetWindowLong(hWnd, GWL_STYLE);
      int nIndex = pControl->getIStyle() ;

      if (!((nIndex & BBS_BITMAP) == BBS_BITMAP))
      {
        // Contr�le RadioButton
        NSButton * pButt = new NSButton(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
        pButt->Attr.Style = pControl->getIStyle() ;

        ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pButt) ;

        pButt->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
        pButt->pControle->setControle(dynamic_cast<void *>(pButt)) ;
        pButt->pControle->setType(pButt->donneType()) ;
        pButt->pControle->setFilling(sFilling) ;
        pButt->pControle->setVisible(isControlProperty(pButt, WS_VISIBLE)) ;
        pButt->pControle->setMUEView(this) ;
        referenceControle(pButt->pControle) ;
      }
    }
    else if (string("BORBTN") == sType)
    {
      if ((ctrlID == IDOK) || (ctrlID == IDCANCEL))
      {
        if      (IDOK == ctrlID)
          uButtonsStyle |= MYWS_OK ;
        else if (IDCANCEL == ctrlID)
          uButtonsStyle |= MYWS_CANCEL ;
      }
      // IDB_OK and IDB_CANCEL are not created in windows (they are in dialogs)
      //
      else if ((IDB_OK != ctrlID) && (IDB_CANCEL != ctrlID))
      {
      	// bouton systeme : ne pas referencer dans les controles de tabbedWindows
        TButton* pButt = new TButton(this, ctrlID, sCaption.c_str(),
                                            coords[0], coords[1], coords[2], coords[3]);
        pButt->Attr.Style = pControl->getIStyle() ;

        if ((coords[1] + coords[3]) > hSysButton)
        	hSysButton = coords[1] + coords[3];
      }
    }

    // BORLAND : Contr�le CheckBox
    if (string("BORCHECK") == sType)
    {
      NSCheckBox * pChkBox = new NSCheckBox(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3], pGroupCurr) ;
      pChkBox->Attr.Style = pControl->getIStyle() ;

      ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pChkBox) ;

      pChkBox->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      pChkBox->pControle->setControle(dynamic_cast<void *>(pChkBox)) ;
      pChkBox->pControle->setType(pChkBox->donneType()) ;
      pChkBox->pControle->setFilling(sFilling) ;
      pChkBox->pControle->setVisible(isControlProperty(pChkBox, WS_VISIBLE)) ;
      pChkBox->pControle->setMUEView(this) ;
      referenceControle(pChkBox->pControle) ;
    }

    if (string("BORRADIO") == sType)
    {
      // BORLAND : Contr�le RadioBouton
      NSRadioButton * pRaBut = new NSRadioButton(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3], pGroupCurr) ;
      pRaBut->Attr.Style = pControl->getIStyle() ;

      ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pRaBut) ;

      pRaBut->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      pRaBut->pControle->setControle(dynamic_cast<void *>(pRaBut)) ;
      pRaBut->pControle->setType(pRaBut->donneType()) ;
      pRaBut->pControle->setFilling(sFilling) ;
      pRaBut->pControle->setVisible(isControlProperty(pRaBut, WS_VISIBLE)) ;
      pRaBut->pControle->setMUEView(this) ;
      referenceControle(pRaBut->pControle) ;
    }

    if (string("SYSTABCONTROL32") == sType)
    {
      // BORLAND : Contr�le Onglets
      NSOnglet * pOnglet = new NSOnglet(pContexte, this, ctrlID, coords[0], coords[1], coords[2], coords[3]) ;
      pOnglet->Attr.Style = pControl->getIStyle() ;

      ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pOnglet) ;

      pOnglet->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      pOnglet->pControle->setControle(dynamic_cast<void *>(pOnglet)) ;
      pOnglet->pControle->setType(pOnglet->donneType()) ;
      pOnglet->pControle->setFilling(sFilling) ;
      pOnglet->pControle->setVisible(isControlProperty(pOnglet, WS_VISIBLE)) ;
      pOnglet->pControle->setMUEView(this) ;
      referenceControle(pOnglet->pControle) ;
    }

    if (string("COMBOBOX") == sType)
    {
    	// is it a classification or not ?
      bool bClassif = false ;
      VectString aVecteurString ;
      NSContexte *pContexte = pBBItem->pBigBoss->pContexte ;
			NSSuper* pSuper = pContexte->getSuperviseur() ;			pSuper->getFilGuide()->TousLesVrais("0CODE", "ES", &aVecteurString, "ENVERS") ;			if (false == aVecteurString.empty())			{				string sIdentSens ;				pSuper->getDico()->donneCodeSens(&sIdentite, &sIdentSens) ;        if (aVecteurString.contains(sIdentSens))        	bClassif = true ;			}
      if (bClassif)
			{
      	// BORLAND : Contr�le Combobox
      	NSComboClassif * pComboB = new NSComboClassif(pContexte, this, ctrlID, coords[0], coords[1], coords[2], coords[3], pControl->getIStyle(), 0) ;
        pComboB->Attr.Style = pControl->getIStyle() ;

        ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pComboB) ;

      	// NSComboClassif * pComboB = new NSComboClassif(this, ctrlID) ;
      	pComboB->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      	pComboB->pControle->setControle(dynamic_cast<void *>(pComboB)) ;
      	pComboB->pControle->setType(pComboB->donneType()) ;
      	pComboB->pControle->setFilling(sFilling) ;
        pComboB->pControle->setVisible(isControlProperty(pComboB, WS_VISIBLE)) ;
      	pComboB->pControle->setMUEView(this) ;
      	referenceControle(pComboB->pControle) ;
      }
      else
      {
      	NSComboSemantique * pComboB = new NSComboSemantique(pContexte, this, ctrlID, coords[0], coords[1], coords[2], coords[3], pControl->getIStyle(), 0) ;
        pComboB->Attr.Style = pControl->getIStyle() ;

        ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pComboB) ;

      	// NSComboClassif * pComboB = new NSComboClassif(this, ctrlID) ;
      	pComboB->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
      	pComboB->pControle->setControle(dynamic_cast<void *>(pComboB)) ;
      	pComboB->pControle->setType(pComboB->donneType()) ;
      	pComboB->pControle->setFilling(sFilling) ;
        pComboB->pControle->setVisible(isControlProperty(pComboB, WS_VISIBLE)) ;
      	pComboB->pControle->setMUEView(this) ;
      	referenceControle(pComboB->pControle) ;
      }
    }

    // BORLAND : Contr�le BorShade
    if (string("BORSHADE") == sType)
    {
      // D�termination du style
      // int nIndex = ::GetWindowLong(hWnd, GWL_STYLE) ;
      int nIndex = pControl->getIStyle() ;

      if (((nIndex & BSS_RGROUP) == BSS_RGROUP) || ((nIndex & WS_GROUP) == WS_GROUP))
      {
        // Contr�le Group
        if (sIdentite != "")
        {
          NSGroupBox * pGrpBox = new NSGroupBox(pContexte, this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
          pGrpBox->Attr.Style = pControl->getIStyle() ;

          ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pGrpBox) ;

          pGrpBox->pControle = new NSControle(pContexte, pBBItem, sIdentite, sDlgFonction) ;
          pGrpBox->pControle->setControle(dynamic_cast<void *>(pGrpBox)) ;
          pGrpBox->pControle->setType(pGrpBox->donneType()) ;
          pGrpBox->pControle->setFilling(sFilling) ;
          pGrpBox->pControle->setVisible(isControlProperty(pGrpBox, WS_VISIBLE)) ;
          pGrpBox->pControle->setMUEView(this) ;
          referenceControle(pGrpBox->pControle) ;
          pGroupCurr = (OWL::TGroupBox *)pGrpBox ;
        }
        else
        {
          OWL::TGroupBox* pGroupBox = new OWL::TGroupBox(this, ctrlID, sCaption.c_str(), coords[0], coords[1], coords[2], coords[3]) ;
          pGroupBox->Attr.Style = pControl->getIStyle() ;

          ((*_tabbedWindows)[indexTab-1])->controls->push_back((TWindow *) pGroupBox) ;

          // aGroups.push_back(pGroupBox) ;
          pGroupCurr = pGroupBox ;
        }
      }
    }

/*
    if (ctrlID == IDBBKCALCUL)
    {
      // cas o� le contr�le n'est pas un des contr�les pr�c�dents, mais que
      // c'est le contr�le qui lance le calcul par le Blackboard
      NSControle * pCtr = new NSControle(pBBItem, sIdentite, sDlgFonction) ;
      referenceControle(pCtr) ;
    }
*/

    // Incr�mentation du compteur
    prec = suiv + 1 ;
    suiv = sRCData.find("|", prec) ;

    string ps = string(" --> Get Next Control ") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

    pControl = pDialogBox->getNextControl(pControl) ;
  }

  // ------------------------------------------------------------

  // On fixe la caption du dialogue
  string sDlgCaption = pDialogBox->getCaption() ;
  if ('$' == sDlgCaption[0])
  {
    if (string("$NAME") == sDlgCaption)
    {
      if (NULL != pBBItem->pBigBoss->pContexte->getPatient())
        sDlgCaption = pBBItem->pBigBoss->pContexte->getPatient()->getNomLong() ;
      else
        sDlgCaption = "" ;
    }
    else
      sDlgCaption = "" ;
  }
  SetCaption(sDlgCaption.c_str()) ;

  int hTab = 0 ;

  if (m_tabCtrl && (_tabbedWindows->size() > 1))
  {
    m_tabCtrl->Create() ;

    // on construit maintenant les tabs
	  // Add the tabs & pages already in tabbedWindowArray
	  NSOneTabWindow *ptr ;
	  int hTemp = 0 ;
    for (NSWindowsIter i = _tabbedWindows->begin() ; _tabbedWindows->end() != i ; i++)
    {
      ptr = *i ;

      // Reparent and create
      ptr->SetParent(this) ;
      if (!ptr->GetHandle())
        ptr->Create() ;
      // Retrieve window's text, use that for tab text
      TAPointer<_TCHAR> txt = new _TCHAR[ptr->GetWindowTextLength() + 1] ;
      ptr->GetWindowText(txt, ptr->GetWindowTextLength()+1) ;
      m_tabCtrl->Add(TTabItem(txt)) ;
      // Select new tab as current
      m_tabCtrl->SetSel(m_tabCtrl->GetCount() - 1) ;
      // Center and display associated TWindow*
      hTemp = AdjustTabClient() ;

      // on note la hauteur de la barre des tabs
      if (hTemp > hTab)
        hTab = hTemp ;
    }
  }

  // ------------------------------------------------------------
}
catch (...)
{
  erreur("Exception NSBBMUEView::CreerControlesArchetype.", standardError, 0) ;
}
}

void
NSBBMUEView::CmBbkCalcul()
{
try
{
  if ((NULL == pNSCtrl) || (pNSCtrl->empty()))
		return ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	bool trouve = false ;

  // Is there a KS involved?
  //
  iterNSControle i = pNSCtrl->begin() ;
	for ( ; (i != pNSCtrl->end()) ; i++)
	{		TControl * pCtrl = static_cast<TControl *>((*i)->getControle()) ;		int idCtrl = pCtrl->GetDlgCtrlID() ;		if (idCtrl == IDBBKCALCUL)		{			trouve = true ;			break ;
		}
	}

	if (false == trouve)
		return ;

	SetCursor(pNSDLLModule, IDC_THINKING_CURSOR) ;

	// on enregistre les modifs de tous les fils du BBItem root
	pBBItem->okFermerDialogue(true, false) ;

	NSPatPathoArray PatPathoArray(pContexte) ;

	// L'archetype est par convention dans le champ fils du BBItem lanceur
	string sArchetype = string(pBBItem->pDonnees->fils) ;
	pSuper->afficheStatusMessage("Renseignement du Blackboard...") ;
	string sDejaRepondu = "" ;

	// Enum�ration de tous les contr�les situ�s avant le contr�le IDBBKCALCUL
	for (i = pNSCtrl->begin() ; (i != pNSCtrl->end()) ; i++)
	{    TControl * pCtrl = static_cast<TControl *>((*i)->getControle()) ;    int idCtrl = pCtrl->GetDlgCtrlID() ;    if (idCtrl == IDBBKCALCUL)      break ;    if (NULL != (*i)->getTransfert())    {      string sCheminBBFilsItem = (*i)->getPath() ;      sCheminBBFilsItem = (*i)->cutPath(&sCheminBBFilsItem, string("/0QUES/"), false) ;/*      // on r�cup�re le chemin du BBItem pere du BBFilsItem associ�      // au NSControle via son pTransfert      string sCheminBBFilsItem = (*i)->getTransfert()->pBBFilsItem->getItemFather()->sLocalisation ;      // on rajoute l'�tiquette du fils      string sEtiq ;      string sEtiquette = (*i)->getTransfert()->pBBFilsItem->getItemLabel() ;      pSuper->getDico()->donneCodeSens(&sEtiquette, &sEtiq) ;
      sCheminBBFilsItem += string(1, cheminSeparationMARK) + sEtiq ;

      // on enleve le chemin jusqu'� "0QUES1"
      size_t pos = sCheminBBFilsItem.find("/0QUES/") ;      if (pos == string::npos)        continue ;

      sCheminBBFilsItem = string(sCheminBBFilsItem, pos + 7, strlen(sCheminBBFilsItem.c_str()) - pos - 7) ;
*/
      if (sCheminBBFilsItem == "")
        continue ;

      // Cas d'une valeur chiffr�e sur un bouton : enlever ce qui suit /$
      size_t pos = sCheminBBFilsItem.find("/$") ;
      if (pos == 0)
        continue ;
      if (pos != string::npos)
        sCheminBBFilsItem = string(sCheminBBFilsItem, 0, pos) ;

      sCheminBBFilsItem = getRegularPath(sCheminBBFilsItem, cheminSeparationMARK, intranodeSeparationMARK) ;

      // on a ici un chemin non vide = une r�ponse � donner au blackboard
      PatPathoArray.vider() ;

      if ((*i)->getType() == isHistoryValListWindow)
      {
        // cas des listes d'elts multiples : on prend le pTransfert du p�re et
        // on r�cup�re la premiere patpatho de ce transfert
        BBItem* pBBItemPere = (*i)->getTransfert()->pBBFilsItem->getItemFather() ;
        if ((NULL != pBBItemPere) && (NULL != pBBItemPere->pBBFilsPere) && (NULL != pBBItemPere->pBBFilsPere->getItemTransfertData()))
        {
          NSTransferInfo *pTransfert = pBBItemPere->pBBFilsPere->getItemTransfertData() ;
          NSVectFatheredPatPathoArray* pFatheredArray = pTransfert->getPatPatho() ;
          if ((NULL != pFatheredArray) && (false == pFatheredArray->empty()))
          {
            NSFatheredPatPathoArray* pFatheredElement = *(pFatheredArray->begin()) ;
            if ((NULL != pFatheredElement) && (false == pFatheredElement->getPatPatho()->empty()))
              PatPathoArray = *(pFatheredElement->getPatPatho()) ;
          }
        }
      }
      else
      {
        NSVectFatheredPatPathoArray* pFatheredArray = (*i)->getTransfert()->getPatPatho() ;
        if ((NULL != pFatheredArray) && (false == pFatheredArray->empty()) && (false == (*(pFatheredArray->begin()))->getPatPatho()->empty()))
        {
          NSFatheredPatPathoArray* pFatheredElement = *(pFatheredArray->begin()) ;
          PatPathoArray = *(pFatheredElement->getPatPatho()) ;
        }

        else if ((*i)->getTransfert()->pBBFilsItem->Actif())
        {
          BBFilsItem * pFils = (*i)->getTransfert()->pBBFilsItem ;
          BBItem * pPere = pFils->getItemFather() ;
          if (pPere)
          {
            pFils->getItemTransfertData()->pTmpTransfertMessage = pFils->getItemTransfertData()->pTransfertMessage ;
            pFils->getItemTransfertData()->iTmpActif = pFils->getItemTransfertData()->iActif ;
            // Modif 16/05/09 PA
            // pPere->pTempPPT->vider() ;
            // pPere->AjouteTmpEtiquette(pFils) ;
            // PatPathoArray = *(pPere->pTempPPT) ;
            NSPatPathoArray TempPPT(pContexte) ;
            pPere->AjouteTmpEtiquette(&TempPPT, pFils) ;
            PatPathoArray = TempPPT ;
          }
        }
      }

      // on donne les r�ponses au blackboard
      if (sCheminBBFilsItem != sDejaRepondu)
      {
				if (((*i)->getTransfert()->pBBFilsItem->VectorFils.empty()) && (PatPathoArray.size() > 1))
        {
        	// Insert the array as an answer to this control's path
          //
        	pSuper->getBBinterface()->insertAnswerOnBlackboard(sCheminBBFilsItem, &PatPathoArray, Undefined) ;
          //
          // Insert leaves as elements with their own path
          //
        	pSuper->getBBinterface()->insertLeavesOnBlackBoard(sCheminBBFilsItem, &PatPathoArray) ;
        }
        else
        	pSuper->getBBinterface()->insertAnswerOnBlackboard(sCheminBBFilsItem, &PatPathoArray, Undefined) ;
      }
      // Evite qu'un bouton non click� remette � z�ro ce que vient de mettre un bouton click�
      // To prevent a non clicked button to reset the value just set up by an activated button
      if (!(PatPathoArray.empty()))
        sDejaRepondu = sCheminBBFilsItem ;
    }
	}

  iterNSControle iPostCalcul = i ;

/*
	// On lib�re le KS afin qu'il puisse effectuer les calculs
  string sKsName = pBBItem->KsInterface.getKsName() ;
  if (sKsName != "")
  	pSuper->getBBinterface()->driveKSfromDialog(sKsName, BB1BBInterface::ksFree) ;
*/

	string sErrMsg = pSuper->getText("bbkKsManagement", "blackboardInDuty") ;
	pSuper->afficheStatusMessage((char*)sErrMsg.c_str()) ;

	// This is the case when the KS is already running and waits for the user
  // to press Ok
  //
	if (pBBItem->KsInterface.getTokenId() > 0)
  {
		// On lib�re le token afin qu'il puisse lancer le KS afin d'effectuer les calculs
		pSuper->getBBinterface()->driveKSfromDialog(pBBItem->KsInterface.getTokenId(), BB1BBInterface::ksFree) ;

  	_bWaitingForKsAnswer = true ;

    waitForKS() ;
	}
  // This is the case when the KS will only start when results are asked
  // We ask the first question, then wait for the KS end of work signal
  //
  else
  {
  	bool bFirstCompute = true ;
		for (i = iPostCalcul ; (i != pNSCtrl->end()) ; i++)
		{			if ((*i)->getTransfert())			{				// on r�cup�re le chemin du BBItem pere du BBFilsItem associ�				// au NSControle via son pTransfert      	//        string sCheminBBFilsItem = (*i)->getPath() ;        sCheminBBFilsItem = (*i)->cutPath(&sCheminBBFilsItem, string("/0CALC/"), false) ;				if (sCheminBBFilsItem != string(""))        {					// on a ici un chemin non vide = une question � poser au blackboard
					NSPatPathoArray * pPatPathoLocal = NULL ;

      		string sAnswerDate ;
					AnswerStatus::ANSWERSTATUS res = pSuper->getBBinterface()->getAnswer2Question(sCheminBBFilsItem, sArchetype, &pPatPathoLocal, sAnswerDate, bFirstCompute, true /* bUserIsWaiting */, HWindow) ;
					bFirstCompute = false ;
          if ((res == AnswerStatus::astatusProcessed) && (pPatPathoLocal != NULL) && (!(pPatPathoLocal->empty())))
					{
						// il y a une r�ponse du blackboard ==> on transmet la patpatho au
        		// BBFilsItem via le pTransfert et on met � jour le contr�le
            //
        		initControlFromBbkAnswer(*i, pPatPathoLocal, &sAnswerDate) ;
          }
          else if (res == AnswerStatus::astatusProcessing)
      			_bWaitingForKsAnswer = true ;
          if (pPatPathoLocal)
      			delete pPatPathoLocal ;
        }
      }
    }

    if (_bWaitingForKsAnswer)
    	waitForKS() ;
  }
}
catch (...)
{
	erreur("Exception NSBBMUEView::CmBbkCalcul().", standardError, 0) ;
}
}

void
NSBBMUEView::CmBbkCalculFinalStep()
{
  _bWaitingForKsAnswer = false ;

  SetCursor(0, IDC_ARROW) ;

  if ((NULL == pNSCtrl) || (pNSCtrl->empty()))
		return ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;

  string sErrMsg = pSuper->getText("bbkKsManagement", "displayingResults") ;
	pSuper->afficheStatusMessage((char*) sErrMsg.c_str()) ;

  iterNSControle i = pNSCtrl->begin() ;
	for ( ; (pNSCtrl->end() != i) ; i++)
	{		TControl *pCtrl = static_cast<TControl *>((*i)->getControle()) ;    if (pCtrl && (IDBBKCALCUL == pCtrl->GetDlgCtrlID()))      break ;  }  if (i == pNSCtrl->end())    return ;  i++ ;  if (i == pNSCtrl->end())    return ;  // L'archetype est par convention dans le champ fils du BBItem lanceur	string sArchetype = string(pBBItem->pDonnees->fils) ;	for ( ; (i != pNSCtrl->end()) ; i++)
	{		if ((*i)->getTransfert())		{			// on r�cup�re le chemin du BBItem pere du BBFilsItem associ�			// au NSControle via son pTransfert      //			// sCheminBBFilsItem = getPathForBbkQuestion(i) ;      string sCheminBBFilsItem = (*i)->getPath() ;      sCheminBBFilsItem = (*i)->cutPath(&sCheminBBFilsItem, string("/0CALC/"), false) ;			if (string("") == sCheminBBFilsItem)				continue ;

			// on a ici un chemin non vide = une question � poser au blackboard
			NSPatPathoArray * pPatPathoLocal = NULL ;

      string sAnswerDate ;
			AnswerStatus::ANSWERSTATUS res = pSuper->getBBinterface()->getAnswer2Question(sCheminBBFilsItem, sArchetype, &pPatPathoLocal, sAnswerDate, false /* bFirstCompute */, true /* bUserIsWaiting */, HWindow) ;
			// bFirstCompute = false ;
			if ((res == AnswerStatus::astatusProcessed) && (NULL != pPatPathoLocal) && (false == pPatPathoLocal->empty()))
			{
				// il y a une r�ponse du blackboard ==> on transmet la patpatho au
        // BBFilsItem via le pTransfert et on met � jour le contr�le

        initControlFromBbkAnswer(*i, pPatPathoLocal, &sAnswerDate) ;
      }
      else if (res == AnswerStatus::astatusProcessing)
      	_bWaitingForKsAnswer = true ;

      if (pPatPathoLocal)
      	delete pPatPathoLocal ;
		}
	}

  sErrMsg = pSuper->getText("bbkKsManagement", "resultsDisplayed") ;
	pSuper->afficheStatusMessage((char*) sErrMsg.c_str()) ;

  CmOkFinalStep() ;
}

void
NSBBMUEView::waitForKS()
{
	_tpsBBKStart.takeTime() ;
  
  SetTimer(ID_KSWAIT_TIMER, 1000) ;
}

void
NSBBMUEView::CmBbkEvent()
{
	_bWaitingForKsAnswer = false ;
  KillTimer(ID_KSWAIT_TIMER) ;

  CmBbkCalculFinalStep() ;
}

NSControle*
NSBBMUEView::getNSControl(TWindow *pCtrl)
{
  // For efficiency reasons, try to order tests according to frequency
  //

  // Static
  //
  NSStatic* pStatic = TYPESAFE_DOWNCAST(pCtrl, NSStatic) ;
  if (pStatic)
    return pStatic->pControle ;

  // Groups
  //
  NSGroupBox* pGroup = TYPESAFE_DOWNCAST(pCtrl, NSGroupBox) ;
  if (pGroup)
    return pGroup->pControle ;

  // Edit
  //
  NSEdit* pEdit = TYPESAFE_DOWNCAST(pCtrl, NSEdit) ;
  if (pEdit)
    return pEdit->pControle ;
  NSEditDate* pEditDate = TYPESAFE_DOWNCAST(pCtrl, NSEditDate) ;
  if (pEditDate)
    return pEditDate->pControle ;
  NSEditDateHeure* pEditDateHeure = TYPESAFE_DOWNCAST(pCtrl, NSEditDateHeure) ;
  if (pEditDateHeure)
    return pEditDateHeure->pControle ;
  NSEditHeure* pEditHeure = TYPESAFE_DOWNCAST(pCtrl, NSEditHeure) ;
  if (pEditHeure)
    return pEditHeure->pControle ;
  NSEditLexique* pEditLex = TYPESAFE_DOWNCAST(pCtrl, NSEditLexique) ;
  if (pEditLex)
    return pEditLex->pControle ;
  NSEditNoLex* pEditNoLex = TYPESAFE_DOWNCAST(pCtrl, NSEditNoLex) ;
  if (pEditNoLex)
    return pEditNoLex->pControle ;

  // Buttons (radio, check...)
  //
  NSRadioButton* pRadio = TYPESAFE_DOWNCAST(pCtrl, NSRadioButton) ;
  if (pRadio)
    return pRadio->pControle ;
  NSCheckBox* pCheck = TYPESAFE_DOWNCAST(pCtrl, NSCheckBox) ;
  if (pCheck)
    return pCheck->pControle ;
  NSButton* pButton = TYPESAFE_DOWNCAST(pCtrl, NSButton) ;
  if (pButton)
    return pButton->pControle ;

  // Trees
  //
  NSTreeWindow* pTree = TYPESAFE_DOWNCAST(pCtrl, NSTreeWindow) ;
  if (pTree)
    return pTree->pControle ;

  // Combos
  //
  NSComboSemantique* pSemantic = TYPESAFE_DOWNCAST(pCtrl, NSComboSemantique) ;
  if (pSemantic)
    return pSemantic->pControle ;
  NSComboClassif* pClassif = TYPESAFE_DOWNCAST(pCtrl, NSComboClassif) ;
  if (pClassif)
    return pClassif->pControle ;

  // Tabs
  //
  NSOnglet* pTab = TYPESAFE_DOWNCAST(pCtrl, NSOnglet) ;
  if (pTab)
    return pTab->pControle ;

  // Lists
  //
  NSHistorizedValListWindow* pHVList = TYPESAFE_DOWNCAST(pCtrl, NSHistorizedValListWindow) ;
  if (pHVList)
    return pHVList->pControle ;
  NSHistorizedListWindow* pHList = TYPESAFE_DOWNCAST(pCtrl, NSHistorizedListWindow) ;
  if (pHList)
    return pHList->pControle ;
  NSAdrListWindow* pAdrList = TYPESAFE_DOWNCAST(pCtrl, NSAdrListWindow) ;
  if (pAdrList)
    return pAdrList->pControle ;
  NSCorListWindow* pCorList = TYPESAFE_DOWNCAST(pCtrl, NSCorListWindow) ;
  if (pCorList)
    return pCorList->pControle ;

  return 0 ;
}

void
NSBBMUEView::SetupWindowForControl(TWindow *pCtrl)
{
  // For efficiency reasons, try to order tests according to frequency
  //

  // Static
  //
  NSStatic* pStatic = TYPESAFE_DOWNCAST(pCtrl, NSStatic) ;
  if (pStatic)
  {
    pStatic->SetupWindow() ;
    return ;
  }

  // Groups
  //
  NSGroupBox* pGroup = TYPESAFE_DOWNCAST(pCtrl, NSGroupBox) ;
  if (pGroup)
  {
    pGroup->SetupWindow() ;
    return ;
  }
/*
  OWL::TGroupBox* pGrpBox = TYPESAFE_DOWNCAST(pCtrl, OWL::TGroupBox) ;
  if (pGrpBox)
  {
    pGrpBox->SetupWindow() ;
    return ;
  }
*/

  // Edit
  //
  NSEdit* pEdit = TYPESAFE_DOWNCAST(pCtrl, NSEdit) ;
  if (pEdit)
  {
    pEdit->SetupWindow() ;
    return ;
  }
  NSEditDate* pEditDate = TYPESAFE_DOWNCAST(pCtrl, NSEditDate) ;
  if (pEditDate)
  {
    pEditDate->SetupWindow() ;
    return ;
  }
  NSEditDateHeure* pEditDateHeure = TYPESAFE_DOWNCAST(pCtrl, NSEditDateHeure) ;
  if (pEditDateHeure)
  {
    pEditDateHeure->SetupWindow() ;
    return ;
  }
  NSEditHeure* pEditHeure = TYPESAFE_DOWNCAST(pCtrl, NSEditHeure) ;
  if (pEditHeure)
  {
    pEditHeure->SetupWindow() ;
    return ;
  }
  NSEditLexique* pEditLex = TYPESAFE_DOWNCAST(pCtrl, NSEditLexique) ;
  if (pEditLex)
  {
    pEditLex->SetupWindow() ;
    return ;
  }
  NSEditNoLex* pEditNoLex = TYPESAFE_DOWNCAST(pCtrl, NSEditNoLex) ;
  if (pEditNoLex)
  {
    pEditNoLex->SetupWindow() ;
    return ;
  }

  // Buttons (radio, check...)
  //
  NSRadioButton* pRadio = TYPESAFE_DOWNCAST(pCtrl, NSRadioButton) ;
  if (pRadio)
  {
    pRadio->SetupWindow() ;
    return ;
  }
  NSCheckBox* pCheck = TYPESAFE_DOWNCAST(pCtrl, NSCheckBox) ;
  if (pCheck)
  {
    pCheck->SetupWindow() ;
    return ;
  }
  NSButton* pButton = TYPESAFE_DOWNCAST(pCtrl, NSButton) ;
  if (pButton)
  {
    pButton->SetupWindow() ;
    return ;
  }

  // Trees
  //
  NSTreeWindow* pTree = TYPESAFE_DOWNCAST(pCtrl, NSTreeWindow) ;
  if (pTree)
  {
    pTree->SetupWindow() ;
    return ;
  }

  // Combos
  //
  NSComboSemantique* pSemantic = TYPESAFE_DOWNCAST(pCtrl, NSComboSemantique) ;
  if (pSemantic)
  {
    pSemantic->SetupWindow() ;
    return ;
  }
  NSComboClassif* pClassif = TYPESAFE_DOWNCAST(pCtrl, NSComboClassif) ;
  if (pClassif)
  {
    pClassif->SetupWindow() ;
    return ;
  }

  // Tabs
  //
  NSOnglet* pTab = TYPESAFE_DOWNCAST(pCtrl, NSOnglet) ;
  if (pTab)
  {
    pTab->SetupWindow() ;
    return ;
  }

  // Lists
  //
  NSHistorizedValListWindow* pHVList = TYPESAFE_DOWNCAST(pCtrl, NSHistorizedValListWindow) ;
  if (pHVList)
  {
    pHVList->SetupWindow() ;
    return ;
  }
  NSHistorizedListWindow* pHList = TYPESAFE_DOWNCAST(pCtrl, NSHistorizedListWindow) ;
  if (pHList)
  {
    pHList->SetupWindow() ;
    return ;
  }
  NSAdrListWindow* pAdrList = TYPESAFE_DOWNCAST(pCtrl, NSAdrListWindow) ;
  if (pAdrList)
  {
    pAdrList->SetupWindow() ;
    return ;
  }
  NSCorListWindow* pCorList = TYPESAFE_DOWNCAST(pCtrl, NSCorListWindow) ;
  if (pCorList)
  {
    pCorList->SetupWindow() ;
    return ;
  }

  // Scroll bars
  //
/*
  TScrollBar* pScroll = TYPESAFE_DOWNCAST(pCtrl, TScrollBar) ;
  if (pScroll)
  {
    pScroll->SetupWindow() ;
    return ;
  }
*/
}

void
NSBBMUEView::executeClosingFunctions()
{
  if ((NULL == pNSCtrl) || (true == pNSCtrl->empty()))
		return ;

	for (iterNSControle i = pNSCtrl->begin() ; pNSCtrl->end() != i ; i++)
		if ((*i)->getFonction())
    	(*i)->getFonction()->execute(NSDLGFCT_FERMETURE) ;
}

void
NSBBMUEView::executePreClosingFunctions()
{
  if ((NULL == pNSCtrl) || (true == pNSCtrl->empty()))
		return ;

	for (iterNSControle i = pNSCtrl->begin() ; pNSCtrl->end() != i ; i++)
		if ((*i)->getFonction())
    	(*i)->getFonction()->execute(NSDLGFCT_PREFERME) ;
}

bool
NSBBMUEView::isControlProperty(TWindow *pCtrl, uint32 StyleInfo)
{
  if (NULL == pCtrl)
    return false ;

  return ((pCtrl->GetStyle() & StyleInfo) == StyleInfo) ;
}

void
NSBBMUEView::SetFocusToNextControl(OWL::TControl* pTControle)
{
  NSControlsArray* pControlsArray = getActiveControls() ;
  if ((NULL == pControlsArray) || pControlsArray->empty())
    return ;

  NSControlsIter itCtrl = pControlsArray->begin() ;

  if (NULL == pTControle)
  {
    bool bSearch = true ;
    while (bSearch)
    {
      if (isControlProperty(*itCtrl, WS_TABSTOP) &&
          isControlProperty(*itCtrl, WS_VISIBLE))
        bSearch = false ;
      else if (pControlsArray->end() == itCtrl)
        return ;
      else
        itCtrl++ ;
    }
  }
  else
  {
    HWND hControlWnd = pTControle->HWindow ;

    for ( ; (pControlsArray->end() != itCtrl) && (hControlWnd != (*itCtrl)->HWindow) ; itCtrl++) ;

    bool bSearch = true ;
    while (bSearch)
    {
      if (pControlsArray->end() == itCtrl)
        itCtrl = pControlsArray->begin() ;
      else
      {
        itCtrl++ ;
        if (pControlsArray->end() == itCtrl)
          itCtrl = pControlsArray->begin() ;
      }

      if (hControlWnd == (*itCtrl)->HWindow)
        return ;

      if (isControlProperty(*itCtrl, WS_TABSTOP) &&
          isControlProperty(*itCtrl, WS_VISIBLE))
        bSearch = false ;
    }
  }

  (*itCtrl)->SetFocus() ;

  // We want Edit controls to be in "full selection" state
  //
  TEdit* pEdit = TYPESAFE_DOWNCAST(*itCtrl, TEdit) ;
	if (pEdit)
	{
    int iTextSize = pEdit->GetTextLen() ;
    if (iTextSize < 1)
      return ;

    pEdit->SetSelection(0, iTextSize) ;
  }
}

void
NSBBMUEView::SetFocusToPreviousControl(OWL::TControl* pTControle)
{
  NSControlsArray* pControlsArray = getActiveControls() ;
  if ((NULL == pControlsArray) || pControlsArray->empty())
    return ;

  NSControlsIter itCtrl = pControlsArray->begin() ;

  if (NULL == pTControle)
  {
    itCtrl = pControlsArray->end() ;
    itCtrl-- ;

    bool bSearch = true ;
    while (bSearch)
    {
      if (isControlProperty(*itCtrl, WS_TABSTOP) &&
          isControlProperty(*itCtrl, WS_VISIBLE))
        bSearch = false ;
      else if (pControlsArray->begin() == itCtrl)
        return ;
      else
        itCtrl-- ;
    }
    (*itCtrl)->SetFocus() ;
    return ;
  }
  else
  {
    HWND hControlWnd = pTControle->HWindow ;

    for ( ; (pControlsArray->end() != itCtrl) && (hControlWnd != (*itCtrl)->HWindow) ; itCtrl++) ;

    bool bSearch = true ;
    while (bSearch)
    {
      if (pControlsArray->begin() == itCtrl)
        itCtrl = pControlsArray->end() ;
      itCtrl-- ;

      if (hControlWnd == (*itCtrl)->HWindow)
        return ;

      if (isControlProperty(*itCtrl, WS_TABSTOP) &&
          isControlProperty(*itCtrl, WS_VISIBLE))
        bSearch = false ;
    }
  }

  (*itCtrl)->SetFocus() ;

  // We want Edit controls to be in "full selection" state
  //
  TEdit* pEdit = TYPESAFE_DOWNCAST(*itCtrl, TEdit) ;
	if (pEdit)
	{
    int iTextSize = pEdit->GetTextLen() ;
    if (iTextSize < 1)
      return ;

    pEdit->SetSelection(0, iTextSize) ;
  }
}

void
NSBBMUEView::initialiseControles()
{
  if (pNSCtrl->empty())
		return ;

	for (iterNSControle it = pNSCtrl->begin() ; pNSCtrl->end() != it ; it++)
    //
    // On lance l'�ventuelle fonction d'initialisation
    //
		if ((*it)->getFonction())
    	(*it)->getFonction()->execute(NSDLGFCT_CREATION) ;
}

void
NSBBMUEView::initControlesFromBbk(string sAction)
{
  // No use to init from bbk if patient is not opened
	//
	if (NULL == pContexte->getPatient())
		return ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;
  if (NULL == pSuper->getBBinterface())
		return ;

	pSuper->getBBinterface()->connectTokenToWindow(pBBItem->KsInterface.getTokenId(), HWindow) ;

	if (pNSCtrl->empty())
  	return ;

  // L'archetype est par convention dans le champ fils du BBItem lanceur
  string sArchetype = string(pBBItem->pDonnees->fils) ;

  pSuper->afficheStatusMessage("Interrogation du Blackboard...") ;

  bool bAsynchronousQuestionsAsked = false ;

  for (iterNSControle i = pNSCtrl->begin(); (i != pNSCtrl->end()); i++)  {  	if ((*i)->getTransfert() && ((*i)->isToFilling(sAction)))    {      string sCheminBBFilsItem = string("") ;    	(*i)->getPathForBlackboard(&sCheminBBFilsItem) ;      string end_date = "", date_fils ;

      (*i)->getEndValidityDate(&end_date) ;

      // on a ici un chemin non vide = une question � poser au blackboard
      NSPatPathoArray* pPatPathoArray = NULL ;

      // on pose la question au blackboard
			int res = pSuper->getBBinterface()->precoche(sCheminBBFilsItem, sArchetype, &pPatPathoArray, &date_fils, "", end_date) ;
			if ((res == 1) && (NULL != pPatPathoArray) && (!(pPatPathoArray->empty())))
        // il y a une r�ponse du blackboard ==>
        // on transmet la patpatho au BBFilsItem via le pTransfert
        // On met � jour le contr�le
        //
				initControlFromBbkAnswer(*i, pPatPathoArray, &date_fils) ;

      else if ((*i)->initOnTimer())
      {
      	bAsynchronousQuestionsAsked = true ;
        // TypedVal typ(sCheminBBFilsItem) ;
      	// AskDeterministicQuestion *DPIOMessage = new AskDeterministicQuestion("From dialog", &typ, 10) ;
  			// pSuper->bbkToDo(pBBItem->pBigBoss->pContexte, 0, "AskDeterministicQuestion", "", "", DPIOMessage, true, NULL, false) ;
      }
      if (pPatPathoArray)
        delete pPatPathoArray ;
		}
  }  if (bAsynchronousQuestionsAsked)  	SetTimer(ID_OB1_TIMER, 1000) ;}

void
NSBBMUEView::initControlFromBbkAnswer(NSControle* pControl, NSPatPathoArray* pPatPathoArray, string* psDate)
{
  if (NULL == pControl)
  	return ;
  if ((NULL == pPatPathoArray) || pPatPathoArray->empty())
  	return ;

  pControl->initFromArray(pPatPathoArray) ;

  if (NULL == psDate)
		return ;

  //
  // Recherche d'un contr�le qui contiendrait la date de cette information
  // We look for another control whose subject would be this control's date
  //
  if (pNSCtrl->empty())
    return ;

  iterNSControle k ;
  for (k = pNSCtrl->begin(); (k != pNSCtrl->end()) && (*k != pControl); k++) ;
  if (k == pNSCtrl->end())
  	return ;

  string sIdentite = pControl->getIdentite() ;
  bool trouve = false ;

  k++ ;

  while (k != pNSCtrl->end())
  {
    if (((*k)->getFilling() == "D") && ((*k)->getPathControl() == sIdentite))
    {
      trouve = true ;
      break ;
    }

    k++ ;
  }

  if (!trouve)
		return ;

  // on regarde si on a une date ou une date et heure
  string sDateIdent = (*k)->getIdentite() ;
  string typeDate = "" ;
  size_t pos = sDateIdent.find_last_of("/�") ;
  if (pos != string::npos)
  	typeDate = string(sDateIdent, pos, 2) ;

  string date_fils = *psDate ;

  if ((typeDate == "�T") || (typeDate == "�D"))
  {
  	NVLdVTemps tpsObj ;
    tpsObj.initFromDate(date_fils) ;

    if (typeDate == "�T")
    	date_fils = tpsObj.donneDateHeure() ;
    else
    	date_fils = tpsObj.donneDate() ;
  }

  (*k)->getTransfert()->pTransfertMessage->SetComplement(date_fils) ;
  (*k)->getTransfert()->pBBFilsItem->Active() ; //rendre ce fils actif
  (*k)->prepareControle() ;
}

void
NSBBMUEView::EvTimer(uint id)
{
	if      (id == ID_OB1_TIMER)
		checkPrecocheOnTimer() ;

	else if (id == ID_OB1_TIMER2)
		checkResultOnTimer() ;

  else if (id == ID_KSWAIT_TIMER)
		stillWaitingForKsTimer() ;

	return ;
}

void
NSBBMUEView::checkPrecocheOnTimer()
{
	if (pNSCtrl->empty())
		return ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;

  // L'archetype est par convention dans le champ fils du BBItem lanceur
  string sArchetype = string(pBBItem->pDonnees->fils) ;

  pSuper->afficheStatusMessage("Interrogation du Blackboard...") ;

  bool bSomeAnswerStillMissing = false ;

  for (iterNSControle i = pNSCtrl->begin(); (i != pNSCtrl->end()); i++)  {  	if ((*i)->getTransfert() && ((*i)->isEmpty()) && ((*i)->initOnTimer()))
    {
    	string sCheminBBFilsItem ;
    	(*i)->getPathForBlackboard(&sCheminBBFilsItem) ;

      // on a ici un chemin non vide = une question � poser au blackboard
      NSPatPathoArray* pPatPathoArray = NULL ;

      string date_fils = string("") ;
      string end_date  = string("") ;
      (*i)->getEndValidityDate(&end_date) ;

      // on pose la question au blackboard
			int res = pSuper->getBBinterface()->precoche(sCheminBBFilsItem, sArchetype, &pPatPathoArray, &date_fils, "", end_date) ;
			if ((res == 1) && (NULL != pPatPathoArray) && (!(pPatPathoArray->empty())))
        // il y a une r�ponse du blackboard ==>
        // on transmet la patpatho au BBFilsItem via le pTransfert
        // On met � jour le contr�le
        //
      	initControlFromBbkAnswer(*i, pPatPathoArray, &date_fils) ;
      else
      	bSomeAnswerStillMissing = true ;
    }
  }
  if (!bSomeAnswerStillMissing)
  	KillTimer(ID_OB1_TIMER) ;
}

void
NSBBMUEView::checkResultOnTimer()
{
}

void
NSBBMUEView::stillWaitingForKsTimer()
{
  int iMaxTimeBeforeStop = 90 ;

  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;
  NVLdVTemps tpsCompare(_tpsBBKStart) ;
  tpsCompare.ajouteSecondes(iMaxTimeBeforeStop) ;
  if (tpsCompare > tpsNow)
    return ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;

  string sWarningMessage = pSuper->getText("bbkKsManagement", "thisKsSeemsHanged") ;
  string sMsg = pSuper->getText("bbkKsManagement", "doYouWantToResetIt") ;
  sWarningMessage += string(1, '\n') + sMsg ;
  int rep = MessageBox(sWarningMessage.c_str(), "", MB_YESNO) ;
  if (rep == IDYES)
  {
    _bWaitingForKsAnswer = false ;
    KillTimer(ID_KSWAIT_TIMER) ;
  }
  else
    _tpsBBKStart.takeTime() ;
}

void
NSBBMUEView::initControlesFromCapture()
{
  NSSuper *pSuper = pContexte->getSuperviseur() ;
  if (pSuper->getEpisodus() == NULL)
    return ;

  NSCaptureArray* pCapt = &(pSuper->getEpisodus()->CaptureArray) ;
  if (pCapt->empty())
    return ;

  // ici on en est
  for (iterNSControle i = pNSCtrl->begin() ; i != pNSCtrl->end() ; i++)
  {
    if ((*i)->getTransfert())
    {
      // on r�cup�re le chemin du BBItem p�re du BBFilesItem associ� au
      // NSControle via son transfert
      //
      BBFilsItem* pFilsItem = (*i)->getTransfert()->pBBFilsItem ;

      string sCheminBBFilsItem = string("");
      string sEtiq = string("") ;

      if (pFilsItem)
      {
      	// on r�cup�re le chemin du BBItem p�re
      	sCheminBBFilsItem = (*i)->getTransfert()->pBBFilsItem->getItemFather()->sLocalisation ;
      	// on r�cup�re l'�tiquette du fils
      	string  sEtiquette = (*i)->getTransfert()->pBBFilsItem->getItemLabel() ;
      	pSuper->getDico()->donneCodeSens(&sEtiquette, &sEtiq) ;
      }

      for (CaptureIter captIter = pCapt->begin() ; captIter != pCapt->end() ; captIter++)
      {
      	if ((*captIter)->sChemin != string(""))
        {
          //
          // On regarde si le chemin de l'�l�ment se termine par le chemin
          // de capture
          //
          string sCheminCapture ;
          pSuper->getDico()->donneCodeSens(&((*captIter)->sChemin), &sCheminCapture) ;

          // Attention, la d�tection automatique ajoute GCONS1, il faut le
          // supprimer
          if ((strlen(sCheminCapture.c_str()) > 6) && (string(sCheminCapture, 0, 6) == "GCONS/"))
            sCheminCapture = string(sCheminCapture, 6, strlen(sCheminCapture.c_str())-6) ;

          string sCheminCompare = "" ;

          size_t iCaptLen = strlen(sCheminCapture.c_str()) ;
          size_t iBBLen   = strlen(sCheminBBFilsItem.c_str()) ;

          if (iBBLen >= iCaptLen)
              sCheminCompare = string(sCheminBBFilsItem, iBBLen - iCaptLen, iCaptLen) ;

          //if (sCheminCapture == sCheminBBFilsItem)
          if (sCheminCompare == sCheminCapture)
          {
            if      (sEtiq[0] == '�')
            {
              (*i)->getTransfert()->pTransfertMessage->SetTexteLibre((*captIter)->sLibelle) ;
              (*i)->getTransfert()->pBBFilsItem->Active() ;
            }
            else if (sEtiq[0] == '2')
            {
              size_t iChemMark = sEtiq.find(cheminSeparationMARK) ;
              if (string::npos != iChemMark)
              {
                string  sUnit   = string(sEtiq, 0, iChemMark) ;
                string  sLexiq  = string(sEtiq, iChemMark + 1, strlen(sEtiq.c_str()) - iChemMark - 1) ;

                string sValeur = (*captIter)->sLibelle ;

                // Conversion d'unit�s
                if (((*captIter)->sUnit != "") && (sUnit != (*captIter)->sUnit))
                {
                  NSCV NsCv(pContexte) ;
                  DBIResult Resultat = NsCv.open() ;
                  if (Resultat != DBIERR_NONE)
                  {
                    erreur("Erreur � l'ouverture de la base convert.", standardError, Resultat) ;
                    sValeur = "" ;
                  }
                  else
                  {
                    double dVal = StringToDouble(sValeur) ;
                    if (NsCv.ConvertirUnite(&dVal, sUnit, (*captIter)->sUnit))
                      sValeur = DoubleToString(&dVal, 0, 2) ;
                    else
                      sValeur = "" ;

                    NsCv.close();
                  }
                }

                if (sValeur != "")
                {
                  (*i)->getTransfert()->pTransfertMessage->SetLexique(sLexiq) ;
                  (*i)->getTransfert()->pTransfertMessage->SetUnit(sUnit) ;
                  (*i)->getTransfert()->pTransfertMessage->SetComplement(sValeur) ;
                  (*i)->getTransfert()->pBBFilsItem->Active() ;
                }
              }
            }
            else
            {
              string  sLabel ;
              pSuper->getDico()->donneCodeSens(&((*captIter)->sLibelle), &sLabel) ;
              if (sEtiq == sLabel)
                (*i)->getTransfert()->pBBFilsItem->Active() ;
            }
            (*i)->executeKillFocusBehaviour() ;
            (*i)->prepareControle() ;
            break ;
          }
        }
      }
    }
  }
}

int
NSBBMUEView::getWindowXFromDialogX(int iX)
{
  return MulDiv(iX, cxSysChar, 4) ;
}

int
NSBBMUEView::getWindowYFromDialogY(int iY)
{
  return MulDiv(iY, cySysChar, 8) ;
}

ClassLib::TRect
NSBBMUEView::getWindowRectFromDialogRect(int iX, int iY, int iW, int iH)
{
  int newX = getWindowXFromDialogX(iX) ;
  int newY = getWindowYFromDialogY(iY) ;
  int newW = getWindowXFromDialogX(iW) ;
  int newH = getWindowYFromDialogY(iH) ;

  return ClassLib::TRect(newX, newY, newX + newW, newY + newH) ;
}

bool
NSBBMUEView::CanSave()
{
  if (NULL == pBBItem)
    return true ;

  NSSuper *pSuper = pContexte->getSuperviseur() ;

  pSuper->getApplication()->PumpWaitingMessages() ;

  //
  // Are controls happy with their contents
  //
  if ((NULL != pNSCtrl) && (false == pNSCtrl->empty()))
  {
    THandle hWndFocused = GetFocus() ;
    
  	for (iterNSControle i = pNSCtrl->begin(); i != pNSCtrl->end(); i++)
    {
      // TreeWindow: get free text that would be in "editing" state
      //
      if ((*i)->getType() == isTreeWindow)
      {
      	NSTreeWindow* pNSTreeWindow = static_cast<NSTreeWindow*>((*i)->getControle()) ;
        if (pNSTreeWindow && pNSTreeWindow->pEditDico)
        	pNSTreeWindow->pEditDico->TextLibre() ;
      }
      else if ((*i)->getType() == isEditDate)
      {
      	NSEditDate* pEditDate = static_cast<NSEditDate*>((*i)->getControle()) ;
        if (pEditDate && (pEditDate->HWindow == hWndFocused))
        {
          bool bCanLetItBe = true ;
          pEditDate->actionForKillFocus(bCanLetItBe) ;
        	if (false == bCanLetItBe)
      	    return false ;
        }
      }
      else if ((*i)->getType() == isEditDateHeure)
      {
      	NSEditDateHeure* pEditDate = static_cast<NSEditDateHeure*>((*i)->getControle()) ;
        if (pEditDate && (pEditDate->HWindow == hWndFocused))
        {
          bool bCanLetItBe = true ;
          pEditDate->actionForKillFocus(bCanLetItBe) ;
        	if (false == bCanLetItBe)
      	    return false ;
        }
      }
      else if ((*i)->getType() == isEditNoLexique)
      {
      	NSEditNoLex* pEditNoLex = static_cast<NSEditNoLex*>((*i)->getControle()) ;
        if (pEditNoLex && (pEditNoLex->HWindow == hWndFocused))
        {
          bool bCanLetItBeAndExecPostExec = true ;
          pEditNoLex->actionForKillFocus(bCanLetItBeAndExecPostExec) ;
        	if (false == bCanLetItBeAndExecPostExec)
      	    return false ;
        }
      }

    	if (false == (*i)->canWeClose())
      	return false ;
    }
  }

  // Checking constraints
  //
  string sMessage ;
	if (false == pBBItem->verifConstraintItem(&sMessage))
	{
    string sWarningMsg = pSuper->getText("archetypesMessages", "someMandatoryInformationIsMissing") ;
    if (string("") != sMessage)
      sWarningMsg += string(" ") + sMessage ;
  	erreur(sWarningMsg.c_str(), warningError, 0) ;
    return false ;
  }

  return true ;
}

void
NSBBMUEView::Attach(NSWindowsArray *pWindowArray)
{
  if ((NULL == pWindowArray) || (false == pWindowArray->empty()))
    return ;

  for (NSWindowsIter i = pWindowArray->begin() ; pWindowArray->end() != i ; i++)
    Attach(*i) ;
}

void
NSBBMUEView::Attach(NSOneTabWindow *newChildWindow, LPCTSTR /* title */)
{
try
{
	// Add to collection of TWindow*'s
	_tabbedWindows->push_back(newChildWindow) ;
    /************************
	if (GetHandle())
	{
		// Reparent the given widget
		newChildWindow->SetParent(this) ;

		if (!newChildWindow->GetHandle())
			newChildWindow->Create() ;
	}
    *****************************/

	if (m_tabCtrl)
	{
  	// Retrieve window's text, use that for tab text
    TAPointer<_TCHAR> txt = new _TCHAR[newChildWindow->GetWindowTextLength() + 1] ;
    newChildWindow->GetWindowText(txt, newChildWindow->GetWindowTextLength() + 1) ;
    m_tabCtrl->Add(TTabItem(txt)) ;
    // Select new tab as current
    SetSelectedTab(m_tabCtrl->GetCount() - 1) ;
    newChildWindow->Show(SW_SHOW) ;
    // newChildWindow->EnableWindow(true) ;
  }
}
catch (...)
{
	erreur("Exception NSTabWindow::Attach.", standardError, 0) ;
}
}

NSOneTabWindow*
NSBBMUEView::Detach(int index)
{
	NSOneTabWindow *retval = (*_tabbedWindows)[index] ;

	// Remove window element from list
    //	tabbedWindows->Detach(index) ;

	return retval ;
}

int
NSBBMUEView::Retrieve(NSOneTabWindow *ptr)
{
	int index = 0 ;
  if (false == _tabbedWindows->empty())
    for (NSWindowsIter iter = _tabbedWindows->begin() ; _tabbedWindows->end() != iter ; iter++, index++)
      if (*iter == ptr)
        return index ;

	// throw an exception instead?
	return -1 ;
}

NSOneTabWindow*
NSBBMUEView::Detach(NSOneTabWindow *ptr)
{
  return Detach(Retrieve(ptr)) ;
}

NSOneTabWindow*
NSBBMUEView::Retrieve(int index)
{
  return ((*_tabbedWindows)[index]) ;
}

NSOneTabWindow*
NSBBMUEView::operator[](int index)
{
  return ((*_tabbedWindows)[index]) ;
}

int
NSBBMUEView::operator[](NSOneTabWindow *win)
{
  return Retrieve(win) ;
}

NSControlsArray*
NSBBMUEView::getActiveControls()
{
  NSOneTabWindow* pTab ;
  if (_tabbedWindows->size() == 1)
    pTab = *(_tabbedWindows->begin()) ;
  else
    pTab = (*_tabbedWindows)[m_tabCtrl->GetSel()] ;
    
  if (NULL == pTab)
    return 0 ;

  return pTab->controls ;
}

void
NSBBMUEView::SetSelectedTab(int index)
{
  m_tabCtrl->SetSel(index) ;

  // TTabControl does not send the TCN_ messages, so we need to "fake" it
  TNotify     dummy ;
  TabSelChanging(dummy) ;
  TabSelChange(dummy) ;
}

void
NSBBMUEView::TabSelChange(TNotify far&)
{
	AdjustTabClient() ;
	// Here, GetSel() returns the after-the-click-current tab selected
	(*_tabbedWindows)[m_tabCtrl->GetSel()]->Show(SW_SHOW) ;
  // (*_tabbedWindows)[m_tabCtrl->GetSel()]->EnableWindow(true) ;
	(*_tabbedWindows)[m_tabCtrl->GetSel()]->SetWindowPos(HWND_TOP, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW) ;
}


bool
NSBBMUEView::TabSelChanging(TNotify far&)
{
	// Here, GetSel() returns the before-the-click-current tab selected
	if ((*_tabbedWindows)[m_tabCtrl->GetSel()])
	{
		(*_tabbedWindows)[m_tabCtrl->GetSel()]->Show(SW_HIDE) ;
		// (*_tabbedWindows)[m_tabCtrl->GetSel()]->EnableWindow(false) ;
	}
	return false ;
}

void
NSBBMUEView::TabKeyDown(TTabKeyDown far&)
{
}

int
NSBBMUEView::AdjustTabClient()
{
  int height = 0 ;
  int width  = 0 ;

	// Retrieve pointer to tab control, the client window
	if (m_tabCtrl && m_tabCtrl->GetHandle())
	{
		// Retrieve the window rectangle of the tab control
		ClassLib::TRect rect;
		m_tabCtrl->GetWindowRect(rect);

		// NOTE: GetWindowRect returns screen coordinates... we'll need
		//       to have the coordinates relative to the frame window,
		//       the parent of both the tab and client window
		::MapWindowPoints(HWND_DESKTOP, *this, (LPPOINT)&rect, 2);

		// Ask the tab for it's 'client-area' based in it window location
		m_tabCtrl->AdjustRect(false, rect);
        height = rect.top;
        width = rect.left;

		// Move the Client window
		// TWindow *Client = (*tabbedWindows)[m_tabCtrl->GetSel()];
		// if (Client && Client->GetHandle())
		//  	Client->SetWindowPos(HWND_TOP, rect, SWP_SHOWWINDOW);

    int k = 0;
    if (false == _tabbedWindows->empty())
    {
      for (NSWindowsIter i = _tabbedWindows->begin(); i != _tabbedWindows->end(); i++, k++)
      {
        if ((!_bControlInit) && ((*i)->controls) && (!((*i)->controls->empty())))
          for (NSControlsIter j = (*i)->controls->begin(); j != (*i)->controls->end(); j++)
            (*j)->MoveWindow((*j)->Attr.X + width, (*j)->Attr.Y + height, (*j)->Attr.W, (*j)->Attr.H) ;

        if (k == m_tabCtrl->GetSel())
        {
          // Move the Client window
          // NSOneTabWindow *Client = *i;
          // if (Client && Client->GetHandle())
          //   Client->SetWindowPos(HWND_TOP, rect, SWP_SHOWWINDOW);

          if (((*i)->controls) && (!((*i)->controls->empty())))
          {
            for (NSControlsIter j = (*i)->controls->begin(); j != (*i)->controls->end(); j++)
            {
              bool bChildIsVisible = true ; // (((*j)->GetStyle() & WS_VISIBLE) == WS_VISIBLE) ;

              NSControle* pCtrl = getNSControl(*j) ;
              if (pCtrl)
                bChildIsVisible = pCtrl->isVisible() ;

              if (bChildIsVisible)
                (*j)->Show(SW_SHOW) ;

              // Don't do this because it switchs the control to "WS_VISIBLE"
              // even for hidden controls
              // (*j)->EnableWindow(true) ;
              (*j)->SetWindowPos(HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW) ;
            }
          }
        }
        else
        {
          if (((*i)->controls) && (!((*i)->controls->empty())))
            for (NSControlsIter j = (*i)->controls->begin(); j != (*i)->controls->end(); j++)
            {
              (*j)->Show(SW_HIDE) ;
              // Don't do this because it switchs the control to "NOT WS_VISIBLE"
              // and it becomes undistinguishable from true hidden controls
              // (*j)->EnableWindow(false) ;
            }
        }
      }
    }

    if (!_bControlInit)
      _bControlInit = true ;
	}

  return height ;
}


//-----------------------------------------------------------------------//
//				   	    Classe NSWindowProperty                          //
//-----------------------------------------------------------------------//

// Default ctor
NSWindowProperty::NSWindowProperty()
{
	_sFunction  = "" ;
  _iX         = 0 ;  _iY         = 0 ;  _iW         = 0 ;  _iH         = 0 ;
  _paramSplit = new ArraySplitWindow() ;
  _iActivity  = available ;
  _cHotKey    = '\0' ;
  _sModifiers = string("") ;
}

// Copy ctor
NSWindowProperty::NSWindowProperty(NSWindowProperty& rv)
{
	_sFunction  = rv._sFunction ;
  _iX         = rv._iX ;  _iY         = rv._iY ;  _iW         = rv._iW ;  _iH         = rv._iH ;
  _paramSplit = new ArraySplitWindow(*rv._paramSplit) ;
  _iActivity  = rv._iActivity ;
  _cHotKey    = rv._cHotKey ;
  _sModifiers = rv._sModifiers ;
}

// Destructor
NSWindowProperty::~NSWindowProperty(){	if (_paramSplit != NULL)		delete _paramSplit ;}voidNSWindowProperty::initFromRect(NS_CLASSLIB::TRect rect){	setX(rect.X()) ;
	setY(rect.Y()) ;
	setW(rect.Width()) ;
	setH(rect.Height()) ;
}NSWindowProperty&
NSWindowProperty::operator=(NSWindowProperty src)
{
	if (this == &src)
		return *this ;

	_sFunction   = src._sFunction ;
  _iX          = src._iX ;  _iY          = src._iY ;  _iW          = src._iW ;  _iH          = src._iH ;
  _iActivity   = src._iActivity ;
  _cHotKey     = src._cHotKey ;
  _sModifiers  = src._sModifiers ;

try
{
	if (src._paramSplit)
		*_paramSplit = *(src._paramSplit) ;
  else
  	resetSplitList() ;

	return *this ;
}
catch (...)
{
	erreur("Exception NSWindowProperty =operator.", standardError, 0) ;
	return *this ;
}
}

void
NSWindowProperty::resetSplitList()
{
  if (!(_paramSplit->empty()))
  	_paramSplit->vider() ;
}

void
NSWindowProperty::addSplit(string sTargetFct, string sSplitFct, TSplitDirection dir, float percent)
{
  if (sSplitFct == string(""))
		return ;

	if (sTargetFct == string(""))
  	sTargetFct = _sFunction ;

	ArraySWIter iter;
	if (!_paramSplit->empty())
  	for (iter = _paramSplit->begin(); (iter != _paramSplit->end()) && (((*iter)->getMotherWindow() != sTargetFct)
                                    || ((*iter)->getChildWindow() != sSplitFct)); iter++ ) ;

	if ((_paramSplit->empty()) || (iter == _paramSplit->end()))
	{
  	NSSplittingWindowProperty* pWinSplit = new NSSplittingWindowProperty() ;
    pWinSplit->setMotherWindow(sTargetFct);
    pWinSplit->setChildWindow(sSplitFct);
    pWinSplit->setSplitDirection(dir);
    pWinSplit->setPercent(percent);

    _paramSplit->push_back(pWinSplit);
  }
  else
  {
  	(*iter)->setSplitDirection(dir);
    (*iter)->setPercent(percent);
  }
}

UINT
NSWindowProperty::getModifiersAsInt()
{
	UINT Mods = 0 ;

  if (true == isInModifier(MOD_ALT))
  	Mods = Mods | MOD_ALT ;
	if (true == isInModifier(MOD_CONTROL))
  	Mods = Mods | MOD_CONTROL ;
  if (true == isInModifier(MOD_SHIFT))
  	Mods = Mods | MOD_SHIFT ;
  if (true == isInModifier(MOD_WIN))
  	Mods = Mods | MOD_WIN ;

	return Mods ;
}

boolNSWindowProperty::isInModifier(UINT iModConst){	switch (iModConst)  {  	case MOD_ALT     : return ((NPOS != _sModifiers.find("A")) || (NPOS != _sModifiers.find("a"))) ;    case MOD_CONTROL : return ((NPOS != _sModifiers.find("C")) || (NPOS != _sModifiers.find("c"))) ;    case MOD_SHIFT   : return ((NPOS != _sModifiers.find("S")) || (NPOS != _sModifiers.find("s"))) ;    case MOD_WIN     : return ((NPOS != _sModifiers.find("W")) || (NPOS != _sModifiers.find("w"))) ;  }  return false ;}voidNSWindowProperty::addToModifiers(UINT iModConst){	if (true == isInModifier(iModConst))		return ;	switch (iModConst)  {  	case MOD_ALT     : _sModifiers += string("A") ; break ;    case MOD_CONTROL : _sModifiers += string("C") ; break ;    case MOD_SHIFT   : _sModifiers += string("S") ; break ;    case MOD_WIN     : _sModifiers += string("W") ; break ;  }}
//-----------------------------------------------------------------------//
//				   		 Classe ArrayWinProp                            //
//-----------------------------------------------------------------------//

ArrayWinProp::ArrayWinProp(ArrayWinProp& rv)
             :ArrayWP(), NSRoot(rv.pContexte)
{
try
{
	if (!(rv.empty()))
		for (ArrayWPIter i = rv.begin(); i != rv.end(); i++)
			push_back(new NSWindowProperty(*(*i)));
}
catch (...)
{
	erreur("Exception ArrayWinProp copy ctor.", standardError, 0) ;
}
}

void
ArrayWinProp::vider()
{
	if (empty())
		return;

	for (ArrayWPIter i = begin(); i != end(); )
	{
		delete *i;
		erase(i);
	}
}

ArrayWinProp::~ArrayWinProp()
{
	vider();
}

ArrayWinProp&
ArrayWinProp::operator=(ArrayWinProp src)
{
	if (this == &src)
		return *this ;

try
{
	if (!empty())
		vider() ;

	if (!(src.empty()))
    for (ArrayWPIter It = src.begin(); It != src.end() ; It++)
    	push_back(new NSWindowProperty(*(*It))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception ArrayWinProp =operator.", standardError, 0) ;
	return *this ;
}
}

/*void
ArrayWinProp::initialiser(string sUserId, string sPersoDirectory)
{
	// une erreur bizzare pousse � d�finir deux ifstreams
	ifstream    inFile1, inFile2 ;

	string      line ;
	string      sData = "" ;
	string      sNomAttrib ;
	string      sValAttrib ;
	size_t      i = 0 ;	string      sFichier ;

	if (sUserId != "")
	{
        sFichier = sPersoDirectory + string("winpos_") + sUserId + string(".dat") ;
		inFile1.open(sFichier.c_str()) ;
	}
	else
	{
		inFile1.open("perso\\winpos.dat") ;
		if (!inFile1)
			return ;
	}

	if (!inFile1)
	{
		sFichier = sPersoDirectory + string("winpos.dat") ;
		inFile2.open(sFichier.c_str()) ;
		if (!inFile2)
		{
			erreur("Impossible d'ouvrir le fichier winpos.dat.", 0, 0) ;
			return ;
		}

		while (!inFile2.eof())
		{
			getline(inFile2,line) ;
			if (line != "")
				sData += line + "\n" ;
		}

		inFile2.close() ;
	}
	else
	{
		while (!inFile1.eof())
		{
			getline(inFile1,line) ;
			if (line != "")
				sData += line + "\n" ;
		}

		inFile1.close() ;
	}

	// boucle de chargement des attributs
	i = 0 ;
	while (i < strlen(sData.c_str()))
	{
		sNomAttrib = "" ;
		sValAttrib = "";

		while ((i < strlen(sData.c_str())) && (sData[i] != ' ') && (sData[i] != '\t'))
			sNomAttrib += sData[i++] ;
		while ((strlen(sData.c_str())) && ((sData[i] == ' ') || (sData[i] == '\t')))
			i++ ;

		while ((strlen(sData.c_str())) && (sData[i] != '\n'))
			sValAttrib += sData[i++] ;

		i++ ;

        if ((sNomAttrib != "") && (sValAttrib != ""))
        {
            NSWindowProperty* pWinProp = new NSWindowProperty() ;
            pWinProp->sFunction = sNomAttrib ;

            int     j = 0, iVal ;
            size_t  pos = sValAttrib.find(',') ;
            while (pos != string::npos)
            {
                string sData = string(sValAttrib, 0, pos) ;
                sValAttrib = string(sValAttrib, pos+1, strlen(sValAttrib.c_str())-pos-1) ;
                pos = sValAttrib.find(',') ;
                iVal = atoi(sData.c_str()) ;
                j++ ;
                switch (j)
                {
                    case 1 : pWinProp->iX = iVal ; break ;
                    case 2 : pWinProp->iY = iVal ; break ;
                    case 3 : pWinProp->iW = iVal ; break ;
                    case 4 : pWinProp->iH = iVal ; break ;
                }
            }
            iVal = atoi(sValAttrib.c_str()) ;
            j++ ;
            switch (j)
            {
                case 1 : pWinProp->iX = iVal ; break ;
                case 2 : pWinProp->iY = iVal ; break ;
                case 3 : pWinProp->iW = iVal ; break ;
                case 4 : pWinProp->iH = iVal ; break ;
            }

            push_back(pWinProp) ;
        }
	}
	return ;
}   */

NS_CLASSLIB::TRect
ArrayWinProp::getPropertyRect(string sFunction)
{
	NSWindowProperty* pProp = getProperty(sFunction) ;
  if (!pProp)
  	return NS_CLASSLIB::TRect(0, 0, 0, 0) ;

	return NS_CLASSLIB::TRect(pProp->X(), pProp->Y(), pProp->X() + pProp->W(), pProp->Y() + pProp->H()) ;
}

void
ArrayWinProp::setProperty(string sUserId, string sFunction, NS_CLASSLIB::TRect rect, string sPersoDirectory)
{
	ArrayWPIter iter ;
  if (!empty())
  	for (iter = begin(); (iter != end()) && ((*iter)->getFunction() != sFunction); iter++) ;

  // Pas trouv� : on ajoute
  // Not found : we add it
  if ((empty()) || (iter == end()))
	{
		NSWindowProperty* pWinProp = new NSWindowProperty() ;
    pWinProp->setFunction(sFunction) ;
    pWinProp->initFromRect(rect) ;
    push_back(pWinProp) ;
	}
  else
  	(*iter)->initFromRect(rect) ;

  // Mise � jour du fichier
  string sFichier = sPersoDirectory + string("winpos_") + sUserId + string(".dat") ;

  ofstream outFile ;
  outFile.open(sFichier.c_str(), ios::out) ;
  if (!outFile)
  {
        string sErreur = "Erreur d'ouverture du fichier " + sFichier ;
        erreur(sErreur.c_str(), standardError, 0) ;
        return ;
    }

    string sLine;    for (iter = begin(); iter != end(); iter++)    {        sLine = (*iter)->getFunction() + string(" ") ;        char cValue[35] ;        itoa((*iter)->X(), cValue, 10) ;        sLine += string(cValue) ;        itoa((*iter)->Y(), cValue, 10) ;        sLine += string(",") + string(cValue) ;        itoa((*iter)->W(), cValue, 10) ;        sLine += string(",") + string(cValue) ;        itoa((*iter)->H(), cValue, 10) ;        sLine += string(",") + string(cValue) ;        sLine += string("\n") ;        outFile << sLine ;    }    outFile.close() ;
}

void
ArrayWinProp::saveWindowProperty(string sUserId, string sPersoDirectory, NSWindowProperty *wndProp, bool bWriteFile)
{
	ArrayWPIter iter ;
	if (!bWriteFile)
	{
		if (NULL == wndProp)
			return ;
		string sFunction = wndProp->getFunction() ;
    if (sFunction == "")
			return ;
		if (!empty())
			for (iter = begin(); (iter != end()) && ((*iter)->getFunction() != sFunction); iter++) ;

    // Pas trouv� : on ajoute
    // Not found : we add it
		if ((empty()) || (iter == end()))
		{
			push_back(new NSWindowProperty(*wndProp)) ;
		}
		else
		{
    	if (-1 != wndProp->X())
				(*iter)->setX(wndProp->X()) ;
      if (-1 != wndProp->Y())
				(*iter)->setY(wndProp->Y()) ;
      if (-1 != wndProp->W())
				(*iter)->setW(wndProp->W()) ;
      if (-1 != wndProp->H())
				(*iter)->setH(wndProp->H()) ;

      if (NSWindowProperty::undefined != wndProp->getActivity())
      {
      	(*iter)->setActivity(wndProp->getActivity()) ;
      	(*iter)->setHotKey(wndProp->getHotKey()) ;
        (*iter)->setModifiers(wndProp->getModifiers()) ;
      }
			(*iter)->getSplit()->vider() ;
		}
	}
	else
	{
		// Mise � jour du fichier
		string sFichier = sPersoDirectory + string("winpos_") + sUserId + string(".dat") ;

		ofstream outFile ;
		outFile.open(sFichier.c_str(), ios::out) ;
		if (!outFile)
		{
			string sErreur = "Erreur d'ouverture du fichier " + sFichier ;
			erreur(sErreur.c_str(), standardError, 0) ;
			return ;
		}

		string sLine;		for (iter = begin(); iter != end(); iter++)		{			sLine = (*iter)->getFunction() + string(" ") ;			char cValue[35] ;			itoa((*iter)->X(), cValue, 10) ;			sLine += string(cValue) ;			itoa((*iter)->Y(), cValue, 10) ;			sLine += string(",") + string(cValue) ;			itoa((*iter)->W(), cValue, 10) ;			sLine += string(",") + string(cValue) ;			itoa((*iter)->H(), cValue, 10) ;			sLine += string(",") + string(cValue) ;			if (!(*iter)->getSplit()->empty())			{				ArraySWIter iterSplit ;				for (iterSplit = (*iter)->getSplit()->begin(); iterSplit != (*iter)->getSplit()->end(); iterSplit++)				{					string sDir ;					switch ((*iterSplit)->getSplitDirection())					{						case psHorizontal :							sDir = "H" ;
							break ;
						case psVertical   :
							sDir = "V" ;							break ;					}					int dec, sign, ndig = 3 ;					char *str ;					str = fcvt((*iterSplit)->getPercent(), ndig, &dec, &sign) ;

					// ltoa((*iterSplit)->getPercent(), cValue,10);					sLine += string(" [") + (*iterSplit)->getMotherWindow() + string(",") +                        (*iterSplit)->getChildWindow() + string(",") +  sDir +                        string(",") +  string(str) + string ("]");				}			}      sLine += string(" (") ;      switch ((*iter)->getActivity())      {      	case NSWindowProperty::blackboardedWithPatient :        	sLine += string("B") ;          break ;        case NSWindowProperty::openedWithPatient :        	sLine += string("A") ;          break ;        case NSWindowProperty::available :        	sLine += string("1") ;          break ;        case NSWindowProperty::notAvailable :        	sLine += string("0") ;          break ;        //        // Default is considered as Available        //        default :        	sLine += string("1") ;      }      sLine += string(",") ;      if ((*iter)->getHotKey() != '\0')      {      	sLine += string(1, (*iter)->getHotKey()) ;        sLine += string(",") ;        sLine += (*iter)->getModifiers() ;      }      sLine += string(")") ;			sLine += string("\n") ;			outFile << sLine ;		}		outFile.close() ;
	}
}

//----------------------------------------------------------------
void
ArrayWinProp::initWindsChild(string sUserId, string sPersoDirectory)
{
	string sFileName ;

	if (sUserId != "")
	{
  	sFileName = sPersoDirectory + string("winpos_") + sUserId + string(".dat") ;
    if (initFromFile(sFileName))
    	return ;
  }

  sFileName = sPersoDirectory + string("winpos.dat") ;
  if (initFromFile(sFileName))
    	return ;

	string sErreur = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") + string(" winpos.dat") ;
  erreur(sErreur.c_str(), standardError, 0) ;
}

bool
ArrayWinProp::initFromFile(string sFileName)
{
	if (sFileName == string(""))
		return false ;

	string sData = string("") ;

  if (!getStringFromFile(sFileName, &sData))
		return false ;

  if (sData == string(""))
		return false ;

	return initFromString(sFileName, &sData) ;
}

bool
ArrayWinProp::getStringFromFile(string sFileName, string* pData)
{
	if (!pData || (sFileName == string("")))
		return false ;

	*pData = string("") ;

try
{
	ifstream inFile ;
  inFile.open(sFileName.c_str()) ;
  if (!inFile)
  	return false ;

  string sLine ;

  while (!inFile.eof())
  {
  	getline(inFile, sLine) ;
    if (sLine != "")
    	*pData += sLine + string("\n") ;
  }

  inFile.close() ;

  return true ;
}
catch (...)
{
	string sErreur = string("Exception ArrayWinProp::initFromFile : ") + pContexte->getSuperviseur()->getText("fileErrors", "errorReadingFile") + string(" ") + sFileName ;
	erreur(sErreur.c_str(), standardError, 0) ;
  return false ;
}
}

bool
ArrayWinProp::initFromString(string sFileName, string* pData)
{
	if (!pData)
		return false ;

	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "corruptedFile") + string(" ") + sFileName ;

	string sNomAttrib ;
	string sValAttrib ;
  string sValSplit ;
  string sValDetails ;
	string sFichier ;
	// boucle de chargement des attributs
	size_t i = 0 ;
  size_t iStrLen = strlen(pData->c_str()) ;
	while (i < iStrLen)
	{
		sNomAttrib  = "" ;
		sValAttrib  = "" ;
    sValSplit   = "" ;
    sValDetails = "" ;

    string sBloc1 = "" ;
    string sBloc2 = "" ;

    bool bContinue = gotoNextBlock(pData, &i) ;
    if (bContinue)
    	bContinue = readBlockInString(pData, &i, &sNomAttrib) ;

    if (bContinue)
    	bContinue = gotoNextBlock(pData, &i) ;
    if (bContinue)
    	bContinue = readBlockInString(pData, &i, &sValAttrib) ;

    if ((sNomAttrib == "") || (sValAttrib == ""))
    {
    	erreur(sErrorText.c_str(), standardError, 0) ;
  		return false ;
    }

    if (bContinue)
    	bContinue = gotoNextBlock(pData, &i) ;
    if (bContinue)
    	bContinue = readBlockInString(pData, &i, &sBloc1) ;

    if (bContinue)
    	bContinue = gotoNextBlock(pData, &i) ;
    if (bContinue)
    	bContinue = readBlockInString(pData, &i, &sBloc2) ;

    if (sBloc1 != string(""))
    {
    	if      (sBloc1[0] == '[')
    		sValSplit = sBloc1 ;
      else if (sBloc1[0] == '(')
    		sValDetails = sBloc1 ;
    }

    if (sBloc2 != string(""))
    {
    	if      (sBloc2[0] == '[')
    		sValSplit = sBloc2 ;
      else if (sBloc2[0] == '(')
    		sValDetails = sBloc2 ;
    }

		if ((i < iStrLen) && ((*pData)[i] == '\n'))
			i++ ;
    NSWindowProperty* pWinProp = new NSWindowProperty() ;
    pWinProp->setFunction(sNomAttrib) ;
    if (!initSizeFromString(&sValAttrib, pWinProp))
    {
    	delete pWinProp ;
      return false ;
    }
    if ((sValSplit != "") && (!initSplitFromString(&sValSplit, pWinProp)))
    {
    	erreur(sErrorText.c_str(), standardError, 0) ;
      return false ;
    }
    if ((sValDetails != "") && (!initDetailsFromString(&sValDetails, pWinProp)))
    {
    	erreur(sErrorText.c_str(), standardError, 0) ;
      return false ;
    }

    push_back(pWinProp) ;
	}

	return true ;
}

// return : true = can continue ; false = must stop
//
bool
ArrayWinProp::readBlockInString(string* psSource, size_t* piCursor, string* psResult)
{
	if (!psResult)
		return false ;
	*psResult = string("") ;

  if (!psSource || !piCursor)
		return false ;

  size_t iSourceLen = strlen(psSource->c_str()) ;
  if (*piCursor >= iSourceLen)
  	return false ;

	while ((*piCursor < iSourceLen) &&
         ((*psSource)[*piCursor] != ' ') &&
         ((*psSource)[*piCursor] != '\t') &&
         ((*psSource)[*piCursor] != '\n'))
  	*psResult += (*psSource)[(*piCursor)++] ;

	if ((*piCursor >= iSourceLen) || ((*psSource)[*piCursor] == '\n'))
  	return false ;
  return true ;
}

// return : true = can continue ; false = must stop
//
bool
ArrayWinProp::gotoNextBlock(string* psSource, size_t* piCursor)
{
	if (!psSource || !piCursor)
		return false ;

  size_t iSourceLen = strlen(psSource->c_str()) ;
  if (*piCursor >= iSourceLen)
  	return false ;

  while ((*piCursor < iSourceLen) &&
         (((*psSource)[*piCursor] == ' ') ||
          ((*psSource)[*piCursor] == '\t')))
  	(*piCursor)++ ;

	if ((*piCursor >= iSourceLen) || ((*psSource)[*piCursor] == '\n'))
  	return false ;
  return true ;
}

// return : true = good string ; false = string with wrong format
//
// Format : 148,268,437,282
//          no space allowed
//
bool
ArrayWinProp::initSizeFromString(string* psSource, NSWindowProperty* pWinProp)
{
	if (!psSource || !pWinProp)
		return false ;

  if (*psSource == string(""))
  	return false ;
  string sValAttrib = *psSource ;

  char cSeparator = ',' ;

  int     j = 0, iVal ;
  size_t  pos = sValAttrib.find(cSeparator) ;
  while (pos != string::npos)
  {
  	string sData = string(sValAttrib, 0, pos) ;

    int iVal = atoi(sData.c_str()) ;
    j++ ;
    switch (j)
    {
    	case 1  : pWinProp->setX(iVal) ; break ;
      case 2  : pWinProp->setY(iVal) ; break ;
      case 3  : pWinProp->setW(iVal) ; break ;
      case 4  : pWinProp->setH(iVal) ; break ;
      default : return false ;
    }

    sValAttrib = string(sValAttrib, pos+1, strlen(sValAttrib.c_str())-pos-1) ;
    pos = sValAttrib.find(cSeparator) ;
  }

  if (j != 3)
  	return false ;

  iVal = atoi(sValAttrib.c_str()) ;
  pWinProp->setH(iVal) ;

  return true ;
}

// return : true = good string ; false = string with wrong format
//
// Format : [EpiRCManagement,RcItemHistory,H,462][EpiRCManagement,ProcessManagement,H,462]
//          no space allowed
//
bool
ArrayWinProp::initSplitFromString(string* psSource, NSWindowProperty* pWinProp)
{
	if (!psSource || !pWinProp)
		return false ;

  if (*psSource == string(""))
  	return true ;

  char cStart     = '[' ;
  char cSeparator = ',' ;
  char cEnd       = ']' ;

	string sWndMother, sWndChild, sPercent, sSplit ;
  size_t count = 0 ;
  size_t iSize = strlen(psSource->c_str()) ;
  while (count < iSize)
  {
  	sWndMother = "" ;
    sWndChild  = "" ;
    sSplit     = "" ;
    sPercent   = "" ;

    if ((*psSource)[count] != cStart)
    	return false ;
    count++ ;

    while ((count < iSize) && ((*psSource)[count] != cSeparator))
    	sWndMother += (*psSource)[count++] ;

    if (count >= iSize)
    	return false ;
    count++ ;

    while ((count < iSize) && ((*psSource)[count] != cSeparator))
    	sWndChild += (*psSource)[count++] ;

    if (count >= iSize)
    	return false ;
    count++ ;

    while ((count < iSize) && ((*psSource)[count] != cSeparator))
    	sSplit += (*psSource)[count++] ;

    if (count >= iSize)
    	return false ;
    count++ ;

    while ((count < iSize) && ((*psSource)[count] != cEnd))
    	sPercent += (*psSource)[count++] ;

    if (count >= iSize)
    	return false ;
    count++ ;

    int iVal = atoi(sPercent.c_str()) ;

    switch (sSplit[0])
    {
    	case 'H' :
      	pWinProp->addSplit(sWndMother, sWndChild, psHorizontal, (float(iVal))/(float(1000))) ;
        break ;
      case 'V' :
      	pWinProp->addSplit(sWndMother,sWndChild, psVertical, (float(iVal))/(float(1000))) ;
        break ;
      default :
      	return false ;
    }
  }
  return true ;
}

// return : true = good string ; false = string with wrong format
//
// Format : (1,B) or (1,)
//          no space allowed
//
bool
ArrayWinProp::initDetailsFromString(string* psSource, NSWindowProperty* pWinProp)
{
	if (!psSource || !pWinProp)
		return false ;

  if (*psSource == string(""))
  	return true ;

  char cStart     = '(' ;
  char cSeparator = ',' ;
  char cEnd       = ')' ;

  if ((*psSource)[0] != cStart)
  	return false ;
  size_t count = 1 ;

	string sAutoOpen = string("") ;
  string sHotKey   = string("") ;
  string sModifier = string("") ;

  size_t iSize = strlen(psSource->c_str()) ;

  while ((count < iSize) && ((*psSource)[count] != cSeparator))
  	sAutoOpen += (*psSource)[count++] ;

  if (count >= iSize)
  	return false ;
  count++ ;

  while ((count < iSize) && ((*psSource)[count] != cSeparator) && ((*psSource)[count] != cEnd))
  	sHotKey += (*psSource)[count++] ;

  if (count >= iSize)
  	return false ;
	if (count < iSize - 1)
		count++ ;

  while ((count < iSize) && ((*psSource)[count] != cSeparator) && ((*psSource)[count] != cEnd))
  	sModifier += (*psSource)[count++] ;

	if (count >= iSize)
  	return false ;

  if      (sAutoOpen == string(1, 'B'))
  	pWinProp->setActivity(NSWindowProperty::blackboardedWithPatient) ;
  else if (sAutoOpen == string(1, 'A'))
  	pWinProp->setActivity(NSWindowProperty::openedWithPatient) ;
  else if (sAutoOpen == string(1, '1'))
  	pWinProp->setActivity(NSWindowProperty::available) ;
  else if (sAutoOpen == string(1, '0'))
  	pWinProp->setActivity(NSWindowProperty::notAvailable) ;
  else
  	return false ;

  if (string("") != sHotKey)
	{
   	if (1 == strlen(sHotKey.c_str()))
  		pWinProp->setHotKey(sHotKey[0]) ;
    else
    {
    	size_t i = 0 ;
    	for ( ; (i < strlen(sHotKey.c_str())) && (isdigit(sHotKey[i])) ; i++) ;
    	if (i == strlen(sHotKey.c_str()))
      {
      	int iValue = atoi(sHotKey.c_str()) ;
        pWinProp->setHotKey(char(iValue)) ;
      }
    }
	}

	if (string("") != sModifier)
  	pWinProp->setModifiers(sModifier) ;

  return true ;
}

//trouve les proprietes d'une fenetre qui a cr�� un MDIChild
NSWindowProperty*
ArrayWinProp::getProperty(string sFunction)
{
	if (empty())
		return NULL ;

	ArrayWPIter iter ;
	for (iter = begin(); (iter != end()) && ((*iter)->getFunction() != sFunction); iter++) ;

	if (iter == end())
		return NULL ;
	else
  	return *iter ;
}

//--------------------------------------------------------

/*//trouve les proprietes d'une fenetre a partir de son nom
NSWindowProperty*
ArrayWinProp::searchProperty(string sFunction)
{
    ArrayWPIter iter ;
    for (iter = begin(); (iter != end()) && ((*iter)->sFunction != sFunction); iter++) ;
    if (iter != end())
        return *iter ;

    NSWindowProperty *pWinProp = new NSWindowProperty();
    for (iter = begin(); ((iter != end())&& !((*iter)->paramSplit->empty())); iter++)
    {

        ArraySWIter iterSplit ;        for (iterSplit = (*iter)->paramSplit->begin(); iterSplit != (*iter)->paramSplit->end(); iterSplit++)
        {
            if ((*iterSplit)->getChildWindow() == sFunction)
            {
                pWinProp->addSplit((*iterSplit)->getMotherWindow(),sFunction,(*iterSplit)->getSplitDirection(),(*iterSplit)->getSplitDirection());
                return pWinProp;
            }
            if ((*iterSplit)->getMotherWindow() == sFunction)
            {
                pWinProp->addSplit(sFunction,(*iterSplit)->getChildWindow() ,(*iterSplit)->getSplitDirection(),(*iterSplit)->getSplitDirection());
                return pWinProp;
             }

        }
    }

}  */


//recherche des propriet� pour chaque paneSplitter

NSSplittingWindowProperty*
ArrayWinProp::searchProperty(string sMother, string sChild)
{
	if (empty())
		return NULL ;

	ArrayWPIter iter ;
  for (iter = begin(); (iter != end()); iter++)
  {
  	if (!((*iter)->getSplit()->empty()))
    {    	ArraySWIter iterSplit ;      for (iterSplit = (*iter)->getSplit()->begin(); iterSplit != (*iter)->getSplit()->end(); iterSplit++)      	if (((*iterSplit)->getChildWindow() == sChild) && ((*iterSplit)->getMotherWindow() == sMother))
        {
        	NSSplittingWindowProperty *pSplitProp = new NSSplittingWindowProperty(**iterSplit) ;
          return pSplitProp ;
        }
    }
  }
  return NULL ;
}


//---------------------------------------------------



//-----------------------------------------------------------------------------
//              classe NSSplittingWindowProperty
//-----------------------------------------------------------------------------
NSSplittingWindowProperty::NSSplittingWindowProperty()
{
	sMotherWind  = "" ;
  sChildWind   = "" ;  percent      = 1 ;  dirSplitting = psNone ;}

NSSplittingWindowProperty::NSSplittingWindowProperty(NSSplittingWindowProperty& rv)
{
	sMotherWind  = rv.sMotherWind  ;
  sChildWind   = rv.sChildWind ;  percent      = rv.percent ;  dirSplitting = rv.dirSplitting ;
}

// Destructor
NSSplittingWindowProperty::~NSSplittingWindowProperty(){}

NSSplittingWindowProperty&
NSSplittingWindowProperty::operator=(NSSplittingWindowProperty src)
{
	sMotherWind  = src.sMotherWind  ;
  sChildWind   = src.sChildWind ;  percent      = src.percent ;  dirSplitting = src.dirSplitting ;

  return *this ;
}

//------------------------------------------------------------------------------
ArraySplitWindow::ArraySplitWindow(ArraySplitWindow& rv)
{
try
{
	if (!(rv.empty()))
		for (ArraySWIter i = rv.begin(); i != rv.end(); i++)
			push_back(new NSSplittingWindowProperty(*(*i))) ;
}
catch (...)
{
	erreur("Exception ArraySplitWindow copy ctor.", standardError, 0) ;
}
}

void
ArraySplitWindow::vider()
{
	if (empty())
		return ;

	for (ArraySWIter i = begin(); i != end(); )
	{
  	if (*i)
    	delete *i ;
		erase(i) ;
	}
}

ArraySplitWindow::~ArraySplitWindow()
{
	vider();
}

ArraySplitWindow&
ArraySplitWindow::operator=(ArraySplitWindow src)
{
	vider() ;

	if (!(src.empty()))
		for (ArraySWIter i = src.begin(); i != src.end(); i++)
			push_back(new NSSplittingWindowProperty(*(*i))) ;

	return *this ;
}

//------------------------------------------------------------------------------

void
ArrayMUEView::vider()
{
	if (empty())
		return;

	for (ArrayMUEViewIter i = begin(); i != end(); )
		erase(i);
}

ArrayMUEView::~ArrayMUEView()
{
	vider();
}

