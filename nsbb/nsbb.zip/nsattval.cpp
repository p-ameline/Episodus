// -----------------------------------------------------------------------------
// nsattval.cpp
// -----------------------------------------------------------------------------
// Attributs/Valeurs d'arch�types XML
// -----------------------------------------------------------------------------
// $Revision: 1.66 $
// $Author: pameline $
// $Date: 2005/06/29 12:24:29 $
// -----------------------------------------------------------------------------
// FLP - april 2005
// FLP - july/august 2003
// RS  - july 2003
// FLP - june 2003
// RS  - november 2002// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Copyright Nautilus, 2004
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � g�rer et traiter les
// informations de sant� d'une personne.
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to manage and process
// a person's health data.
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------


#include <bwcc.h>

#include "nsbb\nsattval.h"#include "nsbb\nsarcParseError.h"#include "nsbb\nsarc.h"#include "nsbb\nsbb.rh"#include "nautilus\nsepicap.h"#include "nsbb\nsbbtran.h"#ifdef __OB1__# include "ns_ob1\nautilus-bbk.h"#else# include "ns_bbk\bb1bb.h"#endifCarchetype::Carchetype(string attributs, string values, Cbalise *father, NSContexte *pCtx)  : Cbalise(attributs, values, father)
{
  pContexte = pCtx ;
}


Carchetype::~Carchetype()
{
}


Carchetype::Carchetype(const Carchetype& rv)
  : Cbalise(rv)
{
  pContexte = rv.pContexte ;
}


Carchetype&
Carchetype::operator=(const Carchetype& src)
{
	Cbalise* pbdata1 = this;
	Cbalise* pbdata2 = (Carchetype*)&src;

  // Appel de l'operateur = de Cbalise (recopie des arguments de la classe Cbalise)
	*pbdata1 = *pbdata2;

	pContexte = src.pContexte ;

  return (*this) ;
}


bool
Carchetype::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (getStringAttribute(ATTRIBUT_ARCHETYPE_NAME) == "")
  {
    // erreur (pas de nom)
    iParsingError = EARCHETYPE_NONAME ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	if (vect_val.empty())
  {
    // erreur (pas de valeur)
    iParsingError = EARCHETYPE_VAL_EMPTY ;
    return false ;
  }

  int nb_dialogue     = 0 ;
  int nb_dialogbox    = 0 ;
  int nb_items        = 0 ;
  int nb_contraintes  = 0 ;
  int nb_present      = 0 ;

	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
		if      (LABEL_DIALOGUE == (*ival)->sLabel) // dialogue
		{
      (*ival)->pObject = new Cdialogue((*ival)->sAttribute, (*ival)->sValue, this) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing dialogue
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
			nb_dialogue++ ;
		}
    else if (LABEL_DIALOGBOX == (*ival)->sLabel) // dialogue
		{
      (*ival)->pObject = new Cdialogbox((*ival)->sAttribute, (*ival)->sValue, this) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing dialogue
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
			nb_dialogbox++ ;
		}
    else if (LABEL_PRESENTATION == (*ival)->sLabel) // mod�le html de pr�sentation
		{
      (*ival)->pObject = new Cpresentation((*ival)->sAttribute, (*ival)->sValue, this);
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
			nb_present++ ;
		}
    else if (LABEL_REFERENCES == (*ival)->sLabel) // references
    {
      (*ival)->pObject = new Creferences((*ival)->sAttribute, (*ival)->sValue, this) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing items
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
    }
    else if (LABEL_ITEMS == (*ival)->sLabel) // items
    {
      (*ival)->pObject = new Citem((*ival)->sAttribute, (*ival)->sValue, this, pContexte, true) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing items
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
			nb_items++ ;
    }
    else if (LABEL_CONTRAINTES == (*ival)->sLabel) // contraintes
    {
      (*ival)->pObject = new Ccontrainte((*ival)->sAttribute, (*ival)->sValue, this, true) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing contraintes
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
			nb_contraintes++ ;
    }
		else
    {
      // erreur (valeur incorrecte)
      iParsingError = EARCHETYPE_VAL ;
      return false ;
    }
  }

	if ((nb_dialogue > 1) /* || (nb_dialogbox > 1)*/ || (nb_items != 1) || (nb_contraintes > 1) || (nb_present > 1))
  {
    // erreur (nb valeurs incorrect)
    iParsingError = EARCHETYPE_NBVAL ;
    return false ;
  }
	return true ;
}boolCarchetype::verif(){
  return true ;
}


bool
Carchetype::compresser()
{
  return true ;
}


bool
Carchetype::traiter()
{
  return true ;
}


string
Carchetype::getName()
{
  return getStringAttribute(ATTRIBUT_ARCHETYPE_NAME) ;
}


string
Carchetype::getFunction()
{
  return getStringAttribute(ATTRIBUT_ARCHETYPE_FUNCT) ;
}


Citem *
Carchetype::getRootItem()
{
  Citem     *pRootItem = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re le p�re des items de l'archetype
      if (LABEL_ITEMS == (*ival)->sLabel) // items
      {
        pRootItem = dynamic_cast<Citem *>((*ival)->pObject) ;
        break ;
      }
    }
  }
  return pRootItem ;
}


Cdialogue *
Carchetype::getDialog()
{
  Cdialogue *pDialog = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if (LABEL_DIALOGUE == (*ival)->sLabel)
      {
        pDialog = dynamic_cast<Cdialogue *>((*ival)->pObject) ;
        break ;
      }
    }
  }
  return pDialog ;
}


Creferences *
Carchetype::getReference()
{
  Creferences *pRef = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if (LABEL_REFERENCES == (*ival)->sLabel)
      {
        pRef = dynamic_cast<Creferences *>((*ival)->pObject) ;
        break ;
      }
    }
  }
  return pRef ;
}


Cdialogbox *
Carchetype::getDialogBox(string sLang)
{
  Cdialogbox  *pDefDialogBox = NULL ;
  Cdialogbox  *pDialogBox    = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin (); ival != vect_val.end (); ival++)
    {
      // on r�cup�re l'objet dialogue
      if (LABEL_DIALOGBOX == (*ival)->sLabel)
      {
        pDialogBox = dynamic_cast<Cdialogbox *>((*ival)->pObject) ;
        if (pDialogBox)
        {
        	if (pDialogBox->getLang() == sLang)
        		break ;
          if (pDialogBox->getLang() == "")
          	pDefDialogBox = pDialogBox ;
        }
      }
    }
  }
  if (pDialogBox && (pDialogBox->getLang() == sLang))
  	return pDialogBox ;
  else
  	return pDefDialogBox ;
}


Cpresentation *
Carchetype::getPresentation()
{
  Cpresentation *pPres = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet presentation
      if (LABEL_PRESENTATION == (*ival)->sLabel)
      {
        pPres = dynamic_cast<Cpresentation *>((*ival)->pObject) ;
        break ;
      }
    }
  }
  return pPres ;
}


// -----------------------------------------------------------------------------
//
// Classe Cdialogue
//
// -----------------------------------------------------------------------------

Cdialogue::Cdialogue(string attributs, string values, Cbalise *father)
  : Cbalise(attributs, values, father)
{
}

Cdialogue::~Cdialogue()
{
}

bool
Cdialogue::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (vect_attr.empty())
  {
    // erreur (pas d'attribut)
    iParsingError = EDIALOGUE_ATTR_EMPTY ;
    return false ;
  }

	int nb_dll = 0 ;
  int nb_nom = 0 ;
  int nb_ref = 0 ;

	for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
  {
    if      (ATTRIBUT_DIALOGUE_NOM == (*iattribut)->getLabel()) // nom du dialogue
			nb_nom++ ;
    else if (ATTRIBUT_DIALOGUE_DLL == (*iattribut)->getLabel()) // dll
			nb_dll++ ;
    else if (ATTRIBUT_DIALOGUE_REF == (*iattribut)->getLabel()) // referentiel
			nb_ref++ ;
		else
    {
      // erreur (attribut incorrect)
      iParsingError = EDIALOGUE_ATTR ;
      return false ;
    }
  }

	if ((nb_nom > 1) || (nb_dll > 1) || (nb_ref > 1))
  {
    // erreur (nb attributs incorrect)
    iParsingError = EDIALOGUE_NBATTR ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	if (!vect_val.empty())
  {
    // erreur (cas normal : pas de valeur)
    iParsingError = EDIALOGUE_VAL_NOT_EMPTY ;
    return false ;
  }
	return true ;
}

boolCdialogue::verif(){
  return true ;
}

bool
Cdialogue::compresser()
{
  return true ;
}

bool
Cdialogue::traiter()
{
  return true ;
}

// -----------------------------------------------------------------------------
//
// Classe Creferences
//
// -----------------------------------------------------------------------------

Creferences::Creferences(string attributs, string values, Cbalise *father)
  : Cbalise(attributs, values, father)
{
}

Creferences::~Creferences()
{
}

bool
Creferences::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	if (vect_val.empty())
  {
    // erreur (pas de valeur)
    iParsingError = EARCHETYPE_VAL_EMPTY ;
    return false ;
  }

	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
		if      (LABEL_CONCERN == (*ival)->sLabel) // dialogue
		{
      (*ival)->pObject = new Cconcern((*ival)->sAttribute, (*ival)->sValue, this);
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing dialogue
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
		}
    else if (LABEL_HEAD == (*ival)->sLabel) // header
		{
      (*ival)->pObject = new Chead((*ival)->sAttribute, (*ival)->sValue, this);
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing dialogue
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
		}
		else
    {
      // erreur (valeur incorrecte)
      iParsingError = EARCHETYPE_VAL ;
      return false ;
    }
  }
	return true ;
}boolCreferences::verif(){
  return true ;
}

bool
Creferences::compresser()
{
  return true ;
}

bool
Creferences::traiter()
{
  return true ;
}

Cconcern *
Creferences::getFirstCconcern()
{
  Cconcern  *pRef = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if (LABEL_CONCERN == (*ival)->sLabel)
      {
        pRef = dynamic_cast<Cconcern *>((*ival)->pObject) ;
        break ;
      }
    }
  }
  return pRef ;
}

Cconcern *
Creferences::getNextCconcern(Cconcern *pPrevious)
{
  Cconcern  *pRef = NULL ;
  if (!vect_val.empty())
  	return pRef ;

  Cconcern  *pBuf ;
  bool      bReturnNext = false ;
  if (!pPrevious)
  	bReturnNext = true ;

  for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
  	// on r�cup�re l'objet dialogue
    if (LABEL_CONCERN == (*ival)->sLabel)
    {
    	pBuf = dynamic_cast<Cconcern *>((*ival)->pObject) ;
      if (pBuf && bReturnNext)
      {
      	pRef = pBuf ;
        break ;
      }
      if (pBuf == pPrevious)
      	bReturnNext = true ;
    }
  }

  return pRef ;
}

Chead *
Creferences::getHead(string sLang)
{
  Chead *pDefRef = NULL ;
  Chead *pRef    = NULL ;

  if (vect_val.empty())
  	return pRef ;

  for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
  	// on r�cup�re l'objet dialogue
    if (LABEL_HEAD == (*ival)->sLabel)
    {
    	pRef = dynamic_cast<Chead *>((*ival)->pObject) ;
      if (pRef)
      {
      	if (pRef->getLang() == sLang)
        	break ;
        if (pRef->getLang() == "")
        	pDefRef = pRef ;
      }
    }
  }
  if (pRef && (pRef->getLang() == sLang))
  	return pRef ;
  else
  	return pDefRef ;
}

// -----------------------------------------------------------------------------
//
// Classe Cconcern
//
// -----------------------------------------------------------------------------

Cconcern::Cconcern(string attributs, string values, Cbalise *father)
  : Cbalise(attributs, values, father)
{
}

Cconcern::~Cconcern()
{
}

bool
Cconcern::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

  /*
	if (vect_val.empty())
  {
    // erreur (pas de valeur)
    iParsingError = EARCHETYPE_VAL_EMPTY ;
    return false ;
  }

  nb_dialogue     = 0 ;
  nb_items        = 0 ;
  nb_contraintes  = 0 ;

	for (ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
		if ((*ival)->sLabel == LABEL_CONCERN) // dialogue
		{
      (*ival)->pObject = new Cconcern((*ival)->sAttribute, (*ival)->sValue) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing dialogue
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
			nb_dialogue++ ;
		}
		else
    {
      // erreur (valeur incorrecte)
      iParsingError = EARCHETYPE_VAL ;
      return false ;
    }
  }
  */

	/*
  if ((nb_dialogue > 1) || (nb_items != 1) || (nb_contraintes > 1))
  {
    // erreur (nb valeurs incorrect)
    iParsingError = EARCHETYPE_NBVAL ;
    return false ;
  }
  */

	return true ;
}boolCconcern::verif(){
  return true ;
}

bool
Cconcern::compresser()
{
  return true ;
}

bool
Cconcern::traiter()
{
  return true ;
}

string
Cconcern::getCode()
{
  return getStringAttribute(ATTRIBUT_CONCERN_CODE) ;
}

string
Cconcern::getCategory()
{
  return getStringAttribute(ATTRIBUT_CONCERN_CATEGORY) ;
}

bool
Cconcern::getAutoCreate()
{
  bool bDefault = false ;
  return getBooleanAttribute(ATTRIBUT_CONCERN_AUTO, &bDefault) ;
}

int
Cconcern::getSeverity()
{
  return getIntAttribute(ATTRIBUT_CONCERN_SEVE) ;
}

// -----------------------------------------------------------------------------
//
// Classe Chead
//
// -----------------------------------------------------------------------------

Chead::Chead(string attributs, string values, Cbalise *father)
  : Cbalise(attributs, values, father)
{
}

Chead::~Chead()
{
}

bool
Chead::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	return true ;
}boolChead::verif(){
  return true ;
}

bool
Chead::compresser()
{
  return true ;
}

bool
Chead::traiter()
{
  return true ;
}

string
Chead::getTitle()
{
  return getStringAttribute(ATTRIBUT_HEAD_TITLE) ;
}

string
Chead::getHelpUrl()
{
  return getStringAttribute(ATTRIBUT_HEAD_HELP) ;
}

string
Chead::getLang()
{
  return getStringAttribute(ATTRIBUT_HEAD_LANG) ;
}

string
Chead::getGroup()
{
  return getStringAttribute(ATTRIBUT_PROP_GROUPE) ;
}

// -----------------------------------------------------------------------------
//
// Classe Citem
//
// -----------------------------------------------------------------------------

Citem::Citem(string attributs, string values, Cbalise *father, NSContexte *pCtx, bool bRoot)
  : Cbalise (attributs, values, father)
{
  bItemRoot = bRoot ;
  pContexte = pCtx ;
}


Citem::~Citem()
{
}


bool
Citem::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (!bItemRoot)
  {
    if (vect_attr.empty())
    {
      // erreur (pas d'attribut)
      iParsingError = EITEM_ATTR_EMPTY ;
      return false ;
    }

    int nb_code       = 0 ;
    int nb_decal      = 0 ;
    int nb_control    = 0 ;
    int nb_text       = 0 ;
    int nb_complement = 0 ;
    int nb_archetype  = 0 ;

    for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
    {
      if      ((*iattribut)->getLabel() == ATTRIBUT_ITEM_CODE) // chemin
        nb_code++ ;
      else if ((*iattribut)->getLabel() == ATTRIBUT_ITEM_DECAL)   // d�calageNiveau
        nb_decal++ ;
      else if ((*iattribut)->getLabel() == ATTRIBUT_ITEM_CONTROL)   // Elt de dialogue
        nb_control++ ;
      else if ((*iattribut)->getLabel() == ATTRIBUT_ITEM_TEXT)   // texte de l'elt de dialogue
        nb_text++ ;
      else if ((*iattribut)->getLabel() == ATTRIBUT_ITEM_COMPLEMENT)  // complement
        nb_complement++ ;
      else if ((*iattribut)->getLabel() == ATTRIBUT_ITEM_ARCHETYPE) // archetype
				nb_archetype++ ;
      else
      {
        // erreur (attribut incorrect)
        iParsingError = EITEM_ATTR ;
        return false ;
      }
    }

    if (nb_code != 1)
    {
      // erreur (nb attributs incorrect)
      iParsingError = EITEM_NBATTR ;
      return false ;
    }

    if ((nb_decal > 1) || (nb_control > 1) || (nb_text > 1))
    {
      // erreur (nb attributs incorrect)
      iParsingError = EITEM_NBATTR ;
      return false ;
    }
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

  if (bItemRoot)
  {
    if (vect_val.empty())
    {
      // erreur (pas de valeur)
      iParsingError = EITEM_VAL_EMPTY ;
      return false ;
    }
  }

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      if ((*ival)->sLabel == LABEL_ITEM) // item
      {
        (*ival)->pObject = new Citem((*ival)->sAttribute, (*ival)->sValue, this, pContexte) ;
        if (!(*ival)->pObject->parser())
        {
          // erreur parsing item
          iParsingError = (*ival)->pObject->iParsingError ;
          return false ;
        }
      }
      else if ((*ival)->sLabel == LABEL_CONTRAINTE) // contrainte de saisie
      {
        (*ival)->pObject = new Ccontrainte((*ival)->sAttribute, (*ival)->sValue, this) ;
        if (!(*ival)->pObject->parser())
        {
          iParsingError = (*ival)->pObject->iParsingError ;
          return false ;
        }
      }
      else
      {
        // erreur (valeur incorrecte)
        iParsingError = EITEM_VAL ;
        return false ;
      }
    }
  }
	return true ;
}

bool
Citem::verif()
{
  return true ;
}

bool
Citem::compresser()
{
  return true ;
}

bool
Citem::traiter()
{
  return true ;
}

string
Citem::getCode()
{
  return getStringAttribute(ATTRIBUT_ITEM_CODE) ;
}

void
Citem::setCode(string sCode)
{
  setStringAttribute(ATTRIBUT_ITEM_CODE, sCode) ;
}

string
Citem::getDecalage()
{
  return getStringAttribute(ATTRIBUT_ITEM_DECAL) ;
}

string
Citem::getControl()
{
  return getStringAttribute(ATTRIBUT_ITEM_CONTROL) ;
}

void
Citem::setControl(string sControl)
{
  setStringAttribute(ATTRIBUT_ITEM_CONTROL, sControl, true) ;
}

string
Citem::getText()
{
  return getStringAttribute(ATTRIBUT_ITEM_TEXT) ;
}

void
Citem::setText(string sText)
{
  setStringAttribute(ATTRIBUT_ITEM_TEXT, sText, true) ;
}

string
Citem::getArchetype()
{
  return getStringAttribute(ATTRIBUT_ITEM_ARCHETYPE) ;
}

void
Citem::setArchetype(string sArchetype)
{
  setStringAttribute(ATTRIBUT_ITEM_ARCHETYPE, sArchetype, true) ;
}

Valeur_array *
Citem::getArrayFils()
{
  return (&vect_val) ;
}

// -----------------------------------------------------------------------------
// added by fab -- aout 2003
// -----------------------------------------------------------------------------
bool
Citem::verifConstraintsWithPPatho(NSPatPathoArray *pPPT, string* psMessage)
{
	bool  bNeeded     = false ;
  bool  bSonExist   = false ;
  int   iNbMinExist = -1 ;
  int   iNbMaxExist = -1 ;

  // recherche des contraintes sur l'item
  Valeur_array  *pItemSons = this->getArrayFils() ;
  for (ValIter i = pItemSons->begin() ; i != pItemSons->end() ; i++)
  {
    Ccontrainte   *pConstraint = dynamic_cast<Ccontrainte *> ((*i)->pObject) ;
    if      (pConstraint && (pConstraint->getStringAttribute(ATTRIBUT_CONTR_TYPE) == VAL_ATTR_CONTR_TYPE_NEEDED))
      bNeeded = true ;
    else if (pConstraint && (pConstraint->getStringAttribute(ATTRIBUT_CONTR_TYPE) == VAL_ATTR_CONTR_TYPE_SONSEX))
    {
      bSonExist = true ;
      // on r�cup�re le nombre min
      int iNb = pConstraint->getIntAttribute(ATTRIBUT_CONTR_MIN) ;
      if (iNb > 0)
        iNbMinExist = iNb ;

      // on r�cup�re le nombre max
      iNb = pConstraint->getIntAttribute(ATTRIBUT_CONTR_MAX) ;
      if (iNb > 0)
        iNbMaxExist = iNb ;
    }
  }  // v�rification que si une contrainte SonsExist existe qu'il y ai un nb min ou un nb max  if (bSonExist && (iNbMinExist <= 0) && (iNbMaxExist <= 0))	{
		// erreur min et/ou max doivent �tre pr�sent dans une contrainte de type "sonsexist"
		return false ;
	}

	if (!bSonExist && !bNeeded)
		return true ;

	if (searchInPPathoItemPath(pPPT))
	{
		// l'item est pr�sent dans la PPatho --> on va maintenant v�rifier ses fils
		if      (bSonExist)
		{
			// dans ce cas on compte les fils qui existe (ou qui ont leurs contraintes v�rifi�es)
			int     iNb = 0 ;
			Valeur_array  *pItemSons = getArrayFils() ;
			for (ValIter itemIter = pItemSons->begin() ; itemIter != pItemSons->end() ; itemIter++)
			{
				Citem   *pItem = dynamic_cast<Citem *> ((*itemIter)->pObject) ;
				if (pItem)
				{
					if (pItem->verifConstraintsWithPPatho(pPPT, psMessage))
						iNb++ ;
				}
			}
			if      ((iNbMinExist != -1) && (iNb < iNbMinExist))
				return false ;
			else if ((iNbMaxExist != -1) && (iNb > iNbMaxExist))
				return false ;
			/*
			else    // ((iNbMinExist == -1) && (iNb >= iNbMinExist)) || ((iNbMaxExist == -1) && (iNb >= iNbMaxExist))
				return true ;
			*/
    	}
		else if (bNeeded)
		{
			// dans ce cas, on v�rifie que tous les fils ont leur contraintes v�rifi�s
			Valeur_array  *pItemSons = getArrayFils() ;
			for (ValIter itemIter = pItemSons->begin() ; itemIter != pItemSons->end() ; itemIter++)
			{
				Citem   *pItem = dynamic_cast<Citem *> ((*itemIter)->pObject) ;
				if (pItem)
				{
					if (!(pItem->verifConstraintsWithPPatho(pPPT, psMessage)))
						return false ;
				}
			}
		}
		return true ;
	}
	else
		return false ;
}


bool
Citem::searchInPPathoItemPath(NSPatPathoArray *pPPT)
{
	if (!pPPT || (pPPT->empty()))
    	return false ;

	for (PatPathoIter pptIter = pPPT->begin() ; pptIter != pPPT->end() ; pptIter++)
	{		if ((*pptIter)->pDonnees != 0)		{			char  pcPath[128] ;			if (strlen((*pptIter)->pDonnees->complement) > 0)				sprintf(pcPath, "%s/$%s", (*pptIter)->pDonnees->lexique, (*pptIter)->pDonnees->complement) ;			else				sprintf(pcPath, "%s", (*pptIter)->pDonnees->lexique) ;			if (strcmp(pcPath, getCode().c_str()) == 0)			// le path du Citem est pr�sent dans la PPatho				return true ;		}	}	return false ;}


// -----------------------------------------------------------------------------
//
// Classe Ccontrainte
//
// -----------------------------------------------------------------------------

Ccontrainte::Ccontrainte(string attributs, string values, Cbalise *father, bool bRoot)
  : Cbalise(attributs, values, father)
{
  bContrainteRoot = bRoot ;
}


Ccontrainte::~Ccontrainte()
{
}


bool
Ccontrainte::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (!bContrainteRoot)
  {
    if (vect_attr.empty())
    {
      // erreur (pas d'attribut)
      iParsingError = ECONTR_ATTR_EMPTY ;
      return false ;
    }

    int nb_type   = 0 ;
    int nb_liste  = 0 ;
    int nb_nom    = 0 ;
    int nb_label  = 0 ;
    int nb_exp    = 0 ;
    int nb_min    = 0 ;
    int nb_max    = 0 ;
    int nb_var    = 0 ;
    for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
    {
      if      ((*iattribut)->getLabel() == ATTRIBUT_CONTR_TYPE) // type de contrainte
        nb_type++ ;
      else if ((*iattribut)->getLabel() == ATTRIBUT_CONTR_LISTE)
        nb_liste++ ;
      else if ((*iattribut)->getLabel() == ATTRIBUT_CONTR_NOM)
        nb_nom++ ;
      else if ((*iattribut)->getLabel() == ATTRIBUT_CONTR_LABEL)
        nb_label++ ;
      else if ((*iattribut)->getLabel() == ATTRIBUT_CONTR_EXP)
        nb_exp++ ;
      else if ((*iattribut)->getLabel() == ATTRIBUT_CONTR_VAR)
        nb_var++ ;
      else if ((*iattribut)->getLabel() == ATTRIBUT_CONTR_MIN)
        nb_min++ ;
      else if ((*iattribut)->getLabel() == ATTRIBUT_CONTR_MAX)
        nb_max++ ;
      else if (((*iattribut)->getLabel() != ATTRIBUT_CONTR_PUBLISH) &&
               ((*iattribut)->getLabel() != ATTRIBUT_CONTR_CLASSIFY))
      {
        // erreur (attribut incorrect)
        iParsingError = ECONTR_ATTR ;
        return false ;
      }
    }

    if      (nb_type != 1)
    {
      // erreur (nb attributs incorrect)
      iParsingError = ECONTR_NBATTR ;
      return false ;
    }
    else if ((nb_nom > 1) || (nb_label > 1) || (nb_liste > 1) || (nb_exp > 1) || (nb_min > 1) || (nb_max > 1) || (nb_var > 1))
    {
      // erreur (nb attributs incorrect)
      iParsingError = ECONTR_NBATTR ;
      return false ;
    }
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

  if (bContrainteRoot)
  {
    if (vect_val.empty())
    {
      // erreur (pas de valeur)
      iParsingError = ECONTR_VAL_EMPTY ;
      return false ;
    }
  }
  else
  {
    if (!vect_val.empty())
    {
      iParsingError = ECONTR_VAL ;
      return false ;
    }
  }

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      if      ((*ival)->sLabel == LABEL_CONTRAINTE) // contrainte
      {
        (*ival)->pObject = new Ccontrainte((*ival)->sAttribute, (*ival)->sValue, this) ;
        if (!(*ival)->pObject->parser())
        {
          // erreur parsing contrainte
          iParsingError = (*ival)->pObject->iParsingError ;
          return false ;
        }
      }
      else if ((*ival)->sLabel == LABEL_VARIABLE)
      {
        (*ival)->pObject = new Cvariable((*ival)->sAttribute, (*ival)->sValue, this) ;
        if (!(*ival)->pObject->parser())
        {
          // erreur parsing variable
          iParsingError = (*ival)->pObject->iParsingError ;
          return false ;
        }
      }
      else if ((*ival)->sLabel == LABEL_VALIDATEUR)
      {
        (*ival)->pObject = new Cvalidateur((*ival)->sAttribute, (*ival)->sValue, this) ;
        if (!(*ival)->pObject->parser())
        {
          // erreur parsing validateur
          iParsingError = (*ival)->pObject->iParsingError ;
          return false ;
        }
      }
      else
      {
        // erreur (valeur incorrecte)
        iParsingError = ECONTR_VAL ;
        return false ;
      }
    }
  }
	return true ;
}

bool
Ccontrainte::verif()
{
  return true ;
}

bool
Ccontrainte::compresser()
{
  return true ;
}

bool
Ccontrainte::traiter()
{
  return true ;
}

Valeur_array *
Ccontrainte::getValArray()
{
  return (&vect_val) ;
}

bool
Ccontrainte::mustPublish()
{
	string sPubli = getStringAttribute(ATTRIBUT_CONTR_PUBLISH) ;
	if (sPubli == "1")
		return true ;

	return false ;
}

// -----------------------------------------------------------------------------
//
// Classe variable
//
// -----------------------------------------------------------------------------

Cvariable::Cvariable(string attributs, string values, Cbalise *father)
          :Cbalise(attributs, values, father)
{
}

Cvariable::~Cvariable()
{
}

bool
Cvariable::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (vect_attr.empty())
  {
    // erreur (pas d'attribut)
    iParsingError = EVARIABLE_ATTR_EMPTY ;
    return false ;
  }

  int nb_nom    = 0 ;
  int nb_label  = 0 ;
  int nb_unit   = 0 ;
  int nb_expres = 0 ;
	for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
  {
		if      ((*iattribut)->getLabel() == ATTRIBUT_VAR_NOM) // nom de la variable
			nb_nom++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_VAR_LABEL)
			nb_label++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_VAR_UNIT)
      nb_unit++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_VAR_EXPRESSION)
      nb_expres++ ;
		else
    {
      // erreur (attribut incorrect)
      iParsingError = EVARIABLE_ATTR ;
      return false ;
    }
  }

	if ((nb_nom != 1) || (nb_label > 1) || (nb_unit > 1))
  {
    // erreur (nb attributs incorrect)
    iParsingError = EVARIABLE_NBATTR ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	if ((0 == nb_expres) && vect_val.empty())
  {
    // erreur (pas de valeur)
    iParsingError = EVARIABLE_VAL_EMPTY ;
    return false ;
  }

  int nb_alias = 0 ;
  if (false == vect_val.empty())
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      if ((*ival)->sLabel == LABEL_ALIAS) // chemin associ�
      {
        (*ival)->pObject = new Calias((*ival)->sAttribute, (*ival)->sValue, this) ;
        if (!(*ival)->pObject->parser())
        {
          // erreur parsing contrainte
          iParsingError = (*ival)->pObject->iParsingError ;
          return false ;
        }
        nb_alias++ ;
      }
      else
      {
        // erreur (valeur incorrecte)
        iParsingError = EVARIABLE_VAL ;
        return false ;
      }
    }

	if ((0 == nb_expres) && (nb_alias < 1))
  {
    // erreur (nb valeurs incorrect)
    iParsingError = EVARIABLE_NBVAL ;
    return false ;
  }
	return true ;
}

boolCvariable::verif(){
  return true ;
}

bool
Cvariable::compresser()
{
  return true ;
}

bool
Cvariable::traiter()
{
  return true ;
}

string
Cvariable::getName()
{
  return getStringAttribute(ATTRIBUT_VAR_NOM) ;
}

string
Cvariable::getLabel()
{
  return getStringAttribute(ATTRIBUT_VAR_LABEL) ;
}

string
Cvariable::getExpression()
{
  return getStringAttribute(ATTRIBUT_VAR_EXPRESSION) ;
}

string
Cvariable::getUnit()
{
  return getStringAttribute(ATTRIBUT_VAR_UNIT) ;
}

bool
Cvariable::isEmpty()
{
  return vect_val.empty() ;
}

// -----------------------------------------------------------------------------
//
// Classe alias
//
// -----------------------------------------------------------------------------

Calias::Calias(string attributs, string values, Cbalise *father)
       :Cbalise(attributs, values, father)
{
}

Calias::~Calias()
{
}

bool
Calias::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	return true ;
}

boolCalias::verif(){
  return true ;
}

bool
Calias::compresser()
{
  return true ;
}

bool
Calias::traiter()
{
  return true ;
}

string
Calias::getValue()
{
  return getValeurs() ;
}

// -----------------------------------------------------------------------------
//
// Classe validateur
//
// -----------------------------------------------------------------------------

Cvalidateur::Cvalidateur(string attributs, string values, Cbalise *father)
  : Cbalise(attributs, values, father)
{
}

Cvalidateur::~Cvalidateur()
{
}

bool
Cvalidateur::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (vect_attr.empty())
  {
    // erreur (pas d'attribut)
    iParsingError = EVALIDATEUR_ATTR_EMPTY ;
    return false ;
  }

  int nb_cond = 0 ;

	for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
  {
		if ((*iattribut)->getLabel() == ATTRIBUT_VALIDATEUR_COND) // condition du validateur
			nb_cond++ ;
		else
    {
      // erreur (attribut incorrect)
      iParsingError = EVALIDATEUR_ATTR ;
      return false ;
    }
  }

	if (nb_cond != 1)
  {
    // erreur (nb attributs incorrect)
    iParsingError = EVALIDATEUR_NBATTR ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	if (!vect_val.empty())
  {
    // erreur (cas normal : pas de valeur)
    iParsingError = EVALIDATEUR_VAL_NOT_EMPTY ;
    return false ;
  }

	return true ;
}

boolCvalidateur::verif(){
  return true ;
}

bool
Cvalidateur::compresser()
{
  return true ;
}

bool
Cvalidateur::traiter()
{
    return true ;
}

// -----------------------------------------------------------------------------
//
// Creferentiel
//
// -----------------------------------------------------------------------------

Creferentiel::Creferentiel(string attributs, string values, Cbalise *father, NSContexte *pCtx)
  : Cbalise(attributs, values, father)
{
  pContexte   = pCtx ;
  pGlobalVars = NULL ;
}

Creferentiel::~Creferentiel()
{
  // change 7 july 2008: the object is now pointed by a pObject with
  // pGlobalVars as an alias... so better don't use delete on it!
  //
  // if (pGlobalVars != NULL)
  //  delete pGlobalVars ;
}

bool
Creferentiel::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (getStringAttribute(ATTRIBUT_REFER_NAME) == "")
  {
    // erreur (pas de nom)
    iParsingError = EREFERENTIEL_NONAME ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	if (vect_val.empty())
  {
    // erreur (pas de valeur)
    iParsingError = EREFERENTIEL_VAL_EMPTY ;
    return false ;
  }

  int nb_dialogue = 0 ;
  int nb_prop     = 0 ;

	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
		if      ((*ival)->sLabel == LABEL_DIALOGUE) // dialogue
		{
      (*ival)->pObject = new Cdialogue((*ival)->sAttribute, (*ival)->sValue, this) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing dialogue
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
			nb_dialogue++ ;
		}
    else if ((*ival)->sLabel == LABEL_REFERENCES) // references
    {
      (*ival)->pObject = new Creferences((*ival)->sAttribute, (*ival)->sValue, this) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing items
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
    }
    else if ((*ival)->sLabel == LABEL_PROPOSITION) // proposition
    {
      (*ival)->pObject = new Cproposition((*ival)->sAttribute, (*ival)->sValue, this, pContexte) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing props
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
			nb_prop++ ;
    }
    else if ((*ival)->sLabel == LABEL_GLOBALVARS) // variables globales
    {
      (*ival)->pObject = new Cglobalvars((*ival)->sAttribute, (*ival)->sValue, this, pContexte) ;

      pGlobalVars = (Cglobalvars*) (*ival)->pObject ;
      if (false == pGlobalVars->parser())
      {
        // erreur parsing globalvars
        iParsingError = pGlobalVars->iParsingError ;
        return false ;
      }
    }
		else
    {
      // erreur (valeur incorrecte)
      iParsingError = EREFERENTIEL_VAL ;
      return false ;
    }
  }

	if ((nb_dialogue > 1) || (nb_prop < 1))
  {
    // erreur (nb valeurs incorrect)
    iParsingError = EREFERENTIEL_NBVAL ;
    return false ;
  }

	return true ;
}boolCreferentiel::verif(){
  return true ;
}

bool
Creferentiel::compresser()
{
  return true ;
}

bool
Creferentiel::traiter()
{
  return true ;
}

Valeur_array *
Creferentiel::getValArray()
{
  return (&vect_val) ;
}

Cglobalvars *
Creferentiel::getGVars()
{
  return (pGlobalVars) ;
}

int
Creferentiel::getNbPropGroup(string sGroup, bool bWithValidation, string sLang)
{
  if (vect_val.empty())
    return 0 ;

	VecteurString aExcluded ;
	VecteurString aNeeded ;

  int       nb_prop = 0 ;
  for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
    if ((*ival)->sLabel == LABEL_PROPOSITION) // proposition
    {
      Cproposition *pCprop = dynamic_cast<Cproposition *>((*ival)->pObject) ;
      if (pCprop->getGroup(sLang) == sGroup)
      {
        if (bWithValidation)
        {
        	bool bValid = true ;

        	// Does this proposition belong to the excluded list
          //
        	string sPropID = pCprop->getStringAttribute(ATTRIBUT_PROP_ID) ;
					if ((sPropID != "") && (aExcluded.ItemDansUnVecteur(sPropID)))
          	bValid = false ;

          // Else, if this proposition doesn't belong to the needed list,
          // we have to check its validity          //          else if ((sPropID == "") || (!(aNeeded.ItemDansUnVecteur(sPropID))))
          	for (ValIter i = pCprop->getValArray()->begin() ; bValid && (i != pCprop->getValArray()->end()) ; i++)
          	{            	if ((*i)->sLabel == LABEL_VALIDITE)              {              	Ccontrainte		*pCvalidite = dynamic_cast<Ccontrainte *>((*i)->pObject) ;              	NSValidateur	valid(pCvalidite, pContexte) ;              	if (!(valid.Validation()))                {                	bValid = false ;                  break ;                }              }            }          if (bValid)          {          	nb_prop++ ;            // Take into account the excluded            //            pCprop->addExcludedToVector(&aExcluded) ;            pCprop->addNeededToVector(&aNeeded) ;          }
        }
        else
          nb_prop++ ;
      }
    }
  }
  return nb_prop ;
}

bool
Creferentiel::getNextGroup(string& sGroup, string sLang)
{
  bool    trouve = false ;
  sGroup = "" ;

  if (!vect_val.empty())
	  for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      if ((*ival)->sLabel == LABEL_PROPOSITION) // proposition
      {
        Cproposition *pCprop = dynamic_cast<Cproposition *>((*ival)->pObject) ;
        if (!pCprop->getTraite())
        {
          sGroup = pCprop->getGroup(sLang) ;
          trouve = true ;
          break ;
        }
      }
    }

  return trouve ;
}

Creferences *
Creferentiel::getReference()
{
  Creferences *pRef = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if ((*ival)->sLabel == LABEL_REFERENCES)
      {
        pRef = dynamic_cast<Creferences *>((*ival)->pObject) ;
        break ;
      }
    }
  }
  return pRef ;
}

string
Creferentiel::getTitle(string sLang)
{
	// First : look into the references
  //
  Creferences* pRef = getReference() ;
  if (pRef)
  {
  	Chead* pHead = pRef->getHead(sLang) ;
    if (pHead)
    	return pHead->getTitle() ;
  }
	// Obsolete
  //
  return getStringAttribute(ATTRIBUT_REFER_TITLE) ;
}

string
Creferentiel::getHelpUrl(string sLang)
{
	// First : look into the references
  //
  Creferences* pRef = getReference() ;
  if (pRef)
  {
  	Chead* pHead = pRef->getHead(sLang) ;
    if (pHead)
    	return pHead->getHelpUrl() ;
  }
  return string("") ;
}

string
Creferentiel::getName()
{
  return getStringAttribute(ATTRIBUT_REFER_NAME) ;
}

string
Creferentiel::getEvolutionOf()
{
  return getStringAttribute(ATTRIBUT_REFER_EVOLUTIONOF) ;
}

// -----------------------------------------------------------------------------
//
// Classe Cproposition
//
// -----------------------------------------------------------------------------

Cproposition::Cproposition(string attributs, string values, Cbalise *father, NSContexte *pCtx)
  : Cbalise(attributs, values, father)
{
  pContexte         = pCtx ;
  traite            = false ;
  check             = false ;
  bInitialyChecked  = false ;
  pReasonTree       = 0 ;
}


Cproposition::~Cproposition()
{
  if (pReasonTree)
    delete pReasonTree ;
}


bool
Cproposition::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (vect_attr.empty())
  {
    // erreur (pas d'attribut)
    iParsingError = EPROP_ATTR_EMPTY ;
    return false ;
  }

  int nb_nom      = 0 ;
  int nb_group    = 0 ;
  int nb_help     = 0 ;
  int nb_id       = 0 ;
  int nb_evidence = 0 ;
  int nb_autochk  = 0 ;
  int nb_replace  = 0 ;
  int nb_sameas   = 0 ;
  int nb_unck_Arc = 0 ;
	for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
  {
		if      ((*iattribut)->getLabel() == ATTRIBUT_PROP_NOM) // nom du dialogue
			nb_nom++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_PROP_GROUPE)
      nb_group++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_PROP_HELP)
      nb_help++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_PROP_ID)
      nb_id++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_PROP_EVIDENCE_LVL)
      nb_evidence++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_PROP_AUTOCHECK)
      nb_autochk++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_PROP_REPLACE)
      nb_replace++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_PROP_SAMEAS)
      nb_sameas++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_PROP_UNCHECK_ARCH)
      nb_unck_Arc++ ;
		else
    {
      // erreur (attribut incorrect)
      iParsingError = EPROP_ATTR ;
      return false ;
    }
  }

	if (/*(nb_nom != 1) || (nb_group > 1) ||*/ (nb_id > 1))
  {
    // erreur (nb attributs incorrect)
    iParsingError = EPROP_NBATTR ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	if (vect_val.empty())
  {
    // iParsingError = EPROP_VAL_EMPTY;
    // return false; // erreur (pas de valeur)
    return true ;
  }

  int nb_valid  = 0 ;
  int nb_tree   = 0 ;
	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
    if ((*ival)->sLabel == LABEL_REFERENCES) // validite
		{
    	(*ival)->pObject = new Creferences((*ival)->sAttribute, (*ival)->sValue, this) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing items
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
		}
		else if ((*ival)->sLabel == LABEL_VALIDITE) // validite
		{
      (*ival)->pObject = new Ccontrainte((*ival)->sAttribute, (*ival)->sValue, this, true) ;
      if (!(*ival)->pObject->parser())
      {
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
			nb_valid++ ;
		}
		else if ((*ival)->sLabel == LABEL_FRIENDSGROUP) // friends
		{
      (*ival)->pObject = new CFriendsGroup((*ival)->sAttribute, (*ival)->sValue, this, pContexte) ;
      if (!(*ival)->pObject->parser())
      {
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
		}
    else if ((*ival)->sLabel == LABEL_TREE) // items
    {
      (*ival)->pObject = new Ctree((*ival)->sAttribute, (*ival)->sValue, this, pContexte);
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing items
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
      Ctree *pCtree = dynamic_cast<Ctree *>((*ival)->pObject) ;
      pCtree->traiteCodeLoc() ;
      pCtree->chargePatPatho() ;
			nb_tree++ ;
    }
		else
    {
      // erreur (valeur incorrecte)
      iParsingError = EPROP_VAL ;
      return false ;
    }
  }

	if (nb_valid > 1)
  {
    // erreur (nb valeurs incorrect)
    iParsingError = EPROP_NBVAL ;
    return false ;
  }
	return true ;
}boolCproposition::verif(){
  return true ;
}


bool
Cproposition::compresser()
{
  return true ;
}

bool
Cproposition::traiter()
{
  return true ;
}


Valeur_array *
Cproposition::getValArray()
{
  return (&vect_val) ;
}


Ccontrainte *
Cproposition::getValidity()
{
  Ccontrainte *pValidity = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      if ((*ival)->sLabel == LABEL_VALIDITE) // validite
      {
        pValidity = dynamic_cast<Ccontrainte *>((*ival)->pObject) ;
        break ;
      }
    }
  }
  return pValidity ;
}

Creferences *
Cproposition::getReference()
{
  Creferences *pReference = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      if ((*ival)->sLabel == LABEL_REFERENCES) // references
      {
        pReference = dynamic_cast<Creferences *>((*ival)->pObject) ;
        break ;
      }
    }
  }
  return pReference ;
}

bool
Cproposition::getTraite()
{
  return traite ;
}

void
Cproposition::setTraite(bool bTraite)
{
  traite = bTraite ;
}

bool
Cproposition::getCheck()
{
  return check ;
}

void
Cproposition::setCheck(bool bCheck)
{
  check = bCheck ;
}

string
Cproposition::getPropID()
{
	string sLocalID = getStringAttribute(ATTRIBUT_PROP_ID) ;
	if (sLocalID == "")
		return "" ;

	Creferentiel* pRef = dynamic_cast<Creferentiel *>(parent) ;
	if (!pRef)
		return "" ;

	string sRefName = pRef->getName() ;

	if (sRefName == "")
		return "" ;

	return sRefName + string(1, '#') + sLocalID ;
}

string
Cproposition::getReplacedPropID()
{
	return getStringAttribute(ATTRIBUT_PROP_REPLACE) ;
}

string
Cproposition::getSameAsPropID()
{
	return getStringAttribute(ATTRIBUT_PROP_SAMEAS) ;
}

string
Cproposition::getUncheckArchetype()
{
	return getStringAttribute(ATTRIBUT_PROP_UNCHECK_ARCH) ;
}

Cproposition::EVIDENCE_LEVEL
Cproposition::getEvidenceLevel()
{
  string sAttributeValue = getStringAttribute(ATTRIBUT_PROP_EVIDENCE_LVL) ;
  pseumaj(&sAttributeValue) ;

  if (string("A") == sAttributeValue)
    return levelA ;
  if (string("B") == sAttributeValue)
    return levelB ;
  if (string("C") == sAttributeValue)
    return levelC ;
  if ((string("PRO") == sAttributeValue) || (string("P") == sAttributeValue))
    return levelPro ;

  return levelUnknown ;
}

bool
Cproposition::getIsAutocheck()
{
  // Autocheck is true by default
  //
  bool bDefault = true ;
  return getBooleanAttribute(ATTRIBUT_PROP_AUTOCHECK, &bDefault) ;
}

string
Cproposition::getTitle(string sLang)
{
	// First : look into the references
  //
  Creferences* pRef = getReference() ;
  if (pRef)
  {
  	Chead* pHead = pRef->getHead(sLang) ;
    if (pHead)
    	return pHead->getTitle() ;
  }
	// Deprecated
  //
  return getStringAttribute(ATTRIBUT_PROP_NOM) ;
}

string
Cproposition::getGroup(string sLang)
{
	// First : look into the references
  //
  Creferences* pRef = getReference() ;
  if (pRef)
  {
  	Chead* pHead = pRef->getHead(sLang) ;
    if (pHead)
    	return pHead->getGroup() ;
  }
	// Deprecated
  //
  return getStringAttribute(ATTRIBUT_PROP_GROUPE) ;
}

string
Cproposition::getHelpUrl(string sLang)
{
	// First : look into the references
  //
  Creferences* pRef = getReference() ;
  if (pRef)
  {
  	Chead* pHead = pRef->getHead(sLang) ;
    if (pHead)
    	return pHead->getHelpUrl() ;
  }
	// Deprecated
  //
  return getStringAttribute(ATTRIBUT_PROP_HELP) ;
}

string
Cproposition::getRefIDFromPropID()
{
	string sPropId = getPropID() ;
  if (sPropId == "")
		return string("") ;

	size_t separ = sPropId.find("#") ;
  if (separ == string::npos)
    return string("") ;

	return string(sPropId, 0, separ) ;
}

string
Cproposition::getLocalPropIDFromPropID()
{
	string sPropId = getPropID() ;
  if (sPropId == "")
		return string("") ;

	size_t separ = sPropId.find("#") ;
  if ((separ == string::npos) || (separ == strlen(sPropId.c_str()) - 1))
    return string("") ;

	return string(sPropId, separ + 1, strlen(sPropId.c_str()) - separ - 1) ;
}

void
Cproposition::addExcludedToVector(VecteurString* pVector)
{
	if (!pVector || (vect_val.empty()))
		return ;

	CFriendsGroup* pFriends = NULL ;
	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
	{
		if ((*ival)->sLabel == LABEL_FRIENDSGROUP) // validite
		{
			pFriends = dynamic_cast<CFriendsGroup*>((*ival)->pObject) ;
			break ;
		}
	}
	if (!pFriends)
		return ;

	CExcludedFriends* pExclFriends = pFriends->getExcludedFriends() ;
	if (!pExclFriends)
		return ;

	Cfriend* pFriend = pExclFriends->getNextExcludedFriend(NULL) ;
	while (pFriend)
	{
		string sID = pFriend->getId() ;
		if ((sID != "") && (!(pVector->ItemDansUnVecteur(sID))))
			pVector->push_back(new string(sID)) ;

		pFriend = pExclFriends->getNextExcludedFriend(pFriend) ;
	}
}

void
Cproposition::addNeededToVector(VecteurString* pVector)
{
	if (!pVector || (vect_val.empty()))
		return ;

	CFriendsGroup* pFriends = NULL ;
	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
	{
		if ((*ival)->sLabel == LABEL_FRIENDSGROUP) // validite
		{
			pFriends = dynamic_cast<CFriendsGroup*>((*ival)->pObject) ;
			break ;
		}
	}
	if (!pFriends)
		return ;

	CNeededFriends* pNeededFriends = pFriends->getNeededFriends() ;
	if (!pNeededFriends)
		return ;

	Cfriend* pFriend = pNeededFriends->getNextNeededFriend(NULL) ;
	while (pFriend)
	{
		string sID = pFriend->getId() ;
		if ((sID != "") && (!(pVector->ItemDansUnVecteur(sID))))
			pVector->push_back(new string(sID)) ;

		pFriend = pNeededFriends->getNextNeededFriend(pFriend) ;
	}
}


// -----------------------------------------------------------------------------
//
// Classe Ctree
//
// -----------------------------------------------------------------------------

Ctree::Ctree(string attributs, string values, Cbalise *father, NSContexte *pCtx)
  : Cbalise(attributs, values, father)
{
  pContexte       = pCtx ;
  pPatPathoArray  = new NSPatPathoArray(pCtx) ;
}

Ctree::~Ctree()
{
  delete pPatPathoArray ;
}

bool
Ctree::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (vect_attr.empty())
  {
    // erreur (pas d'attribut)
    iParsingError = ETREE_ATTR_EMPTY ;
    return false ;
  }

  int nb_loc = 0 ;
	for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
  {
		if ((*iattribut)->getLabel() == ATTRIBUT_TREE_LOC) // localisation
			nb_loc++ ;
		else
    {
      // erreur (attribut incorrect)
      iParsingError = ETREE_ATTR ;
      return false ;
    }
  }

	if (nb_loc != 1)
  {
    // erreur (nb attributs incorrect)
    iParsingError = ETREE_NBATTR ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	if (vect_val.empty())
  {
    // erreur (pas de valeur)
    iParsingError = ETREE_VAL_EMPTY ;
    return false ;
  }

  int nb_node = 0 ;
	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
		if ((*ival)->sLabel == LABEL_NODE) // noeud
		{
      (*ival)->pObject = new Cnode((*ival)->sAttribute, (*ival)->sValue, this) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing items
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
			nb_node++ ;
		}
		else
    {
      // erreur (valeur incorrecte)
      iParsingError = ETREE_VAL ;
      return false ;
    }
  }

	if (nb_node < 1)
  {
    // erreur (nb valeurs incorrect)
    iParsingError = ETREE_NBVAL ;
    return false ;
  }
	return true ;
}

boolCtree::verif(){
  return true ;
}

bool
Ctree::chargePatPatho()
{
	if (vect_val.empty())
    return false ;

	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
		if ((*ival)->sLabel == LABEL_NODE) // noeud
		{
      Cnode *pCnode = dynamic_cast<Cnode *>((*ival)->pObject) ;
      if (pCnode)
      	pCnode->chargePatPatho(pPatPathoArray) ;
		}
  }
  return true ;
}

bool
Ctree::initFromPatPatho()
{
	if (NULL == pPatPathoArray)
  	return false ;

	vect_val.vider() ;

	if (true == pPatPathoArray->empty())
  	return true ;

	PatPathoIter it = pPatPathoArray->begin() ;
  while ((NULL != it) && (pPatPathoArray->end() != it))
	{
  	// Create CValeur and Cnode
    //
  	CValeur* pValeur = new CValeur(LABEL_NODE, string(""), string(""), this) ;
		vect_val.push_back(pValeur) ;
    pValeur->pObject = new Cnode(string(""), string(""), this) ;

    // Init Cnode
    //
    Cnode *pCnode = dynamic_cast<Cnode*>(pValeur->pObject) ;
    *(pCnode->pPatPathoInfo) = **it ;

    // if (string("") != pCnode->pPatPathoInfo->getLocalisation())
    //	pCnode->addAttribute(ATTRIBUT_NODE_LOC,        pCnode->pPatPathoInfo->getLocalisation()) ;
    if (string("") != pCnode->pPatPathoInfo->getType())
    	pCnode->addAttribute(ATTRIBUT_NODE_TYPE,       pCnode->pPatPathoInfo->getType()) ;
    if (string("") != pCnode->pPatPathoInfo->getLexique())
    	pCnode->addAttribute(ATTRIBUT_NODE_LEXIQUE,    pCnode->pPatPathoInfo->getLexique()) ;
    if (string("") != pCnode->pPatPathoInfo->getUnit())
    	pCnode->addAttribute(ATTRIBUT_NODE_UNIT,       pCnode->pPatPathoInfo->getUnit()) ;
    if (string("") != pCnode->pPatPathoInfo->getComplement())
    	pCnode->addAttribute(ATTRIBUT_NODE_COMPLEMENT, pCnode->pPatPathoInfo->getComplement()) ;
    if (string("") != pCnode->pPatPathoInfo->getTexteLibre())
    	pCnode->addAttribute(ATTRIBUT_NODE_FREETEXT,   pCnode->pPatPathoInfo->getTexteLibre()) ;
    if (string("") != pCnode->pPatPathoInfo->getCertitude())
    	pCnode->addAttribute(ATTRIBUT_NODE_CERTITUDE,  pCnode->pPatPathoInfo->getCertitude()) ;
    if (string("") != pCnode->pPatPathoInfo->getInteret())
    	pCnode->addAttribute(ATTRIBUT_NODE_INTERET,    pCnode->pPatPathoInfo->getInteret()) ;
    if (string("") != pCnode->pPatPathoInfo->getPluriel())
    	pCnode->addAttribute(ATTRIBUT_NODE_PLURIEL,    pCnode->pPatPathoInfo->getPluriel()) ;

    NSPatPathoArray subPpt(pPatPathoArray->pContexte) ;
    pPatPathoArray->ExtrairePatPatho(it, &subPpt) ;
    pCnode->initFromPatPatho(&subPpt) ;

    // Next root node ?
    //
    it = pPatPathoArray->ChercherFrere(it) ;
	}

	return true ;
}

bool
Ctree::compresser()
{
  return true ;
}

bool
Ctree::traiter()
{
  return true ;
}

bool
Ctree::traiteCodeLoc()
{
  int iLigne    = 0 ;
  int iColonne  = 0 ;

  for (ValIter iterVal = vect_val.begin() ; iterVal != vect_val.end() ; iterVal++)
  {
    iColonne = 0 ;
    Cnode *pCnode = dynamic_cast<Cnode *>((*iterVal)->pObject) ;
    pCnode->traiteCodeLoc(&iLigne, iColonne) ;
  }
  return true ;
}

string
Ctree::getLocalisation()
{
	return getStringAttribute(ATTRIBUT_TREE_LOC) ;
}

// -----------------------------------------------------------------------------
//
// Classe Cnode
//
// -----------------------------------------------------------------------------

Cnode::Cnode(string attributs, string values, Cbalise *father)
      :Cbalise(attributs, values, father)
{
  pPatPathoInfo = new NSPatPathoInfo ;
}

Cnode::~Cnode()
{
  delete pPatPathoInfo ;
}

bool
Cnode::parser()
{
  //string    sTexteLibre ;

  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (vect_attr.empty())
  {
    // erreur (pas d'attribut)
    iParsingError = ENODE_ATTR_EMPTY ;
    return false ;
  }

  int nb_loc      = 0 ;
  int nb_type     = 0 ;
  int nb_lex      = 0 ;
  int nb_compl    = 0 ;
  int nb_cert     = 0 ;
  int nb_interet  = 0 ;
  int nb_pluriel  = 0 ;
  int nb_freetext = 0 ;

	for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
  {
		if      ((*iattribut)->getLabel() == ATTRIBUT_NODE_LOC)
		{
      pPatPathoInfo->setLocalisation((*iattribut)->getValue()) ;
			nb_loc++ ;
		}
    else if ((*iattribut)->getLabel() == ATTRIBUT_NODE_TYPE)
		{
      pPatPathoInfo->setType((*iattribut)->getValue()) ;
			nb_type++ ;
		}
    else if ((*iattribut)->getLabel() == ATTRIBUT_NODE_LEXIQUE)
    {
      pPatPathoInfo->setLexique((*iattribut)->getValue()) ;
      nb_lex++ ;
    }
    else if ((*iattribut)->getLabel() == ATTRIBUT_NODE_UNIT)
      pPatPathoInfo->setUnit((*iattribut)->getValue()) ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_NODE_COMPLEMENT)
    {
      // Attention l'attribut lexique doit etre d�fini avant complement
      if (nb_lex)
      {
/*
        // fabDOIT
        // maintenant on a une balise freetext pour les textes libres
        // cette rustine n'a plus lieu d'exister
        if (pPatPathoInfo->getLexique() == "�?????")
        {
          sTexteLibre = (*iattribut)->sValue ;

          if (sTexteLibre == "")            sTexteLibre = "[texte non r�cup�r�]" ;
          else
            pPatPathoInfo->pDonnees->setTexteLibre(sTexteLibre) ;
        }
        else
*/
        pPatPathoInfo->setComplement((*iattribut)->getValue()) ;

        nb_compl++ ;
      }
    }
    else if ((*iattribut)->getLabel() == ATTRIBUT_NODE_FREETEXT)
    {
      pPatPathoInfo->setTexteLibre((*iattribut)->getValue()) ;
      nb_freetext++ ;
    }
    else if ((*iattribut)->getLabel() == ATTRIBUT_NODE_CERTITUDE)
    {
      pPatPathoInfo->setCertitude((*iattribut)->getValue()) ;
      nb_cert++ ;
    }
    else if ((*iattribut)->getLabel() == ATTRIBUT_NODE_INTERET)
    {
      pPatPathoInfo->setInteret((*iattribut)->getValue()) ;
      nb_interet++ ;
    }
    else if ((*iattribut)->getLabel() == ATTRIBUT_NODE_PLURIEL)
    {
      pPatPathoInfo->setPluriel((*iattribut)->getValue()) ;
      nb_pluriel++ ;
    }
		else
    {
      // erreur (attribut incorrect)
      iParsingError = ENODE_ATTR ;
      return false ;
    }
  }

	if ((nb_loc > 1) || (nb_type > 1) || (nb_lex != 1) || (nb_compl > 1) || (nb_cert > 1) || (nb_interet > 1) || (nb_pluriel > 1) || (nb_freetext > 1))
  {
    // erreur (nb attributs incorrect)
    iParsingError = ENODE_NBATTR ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      if ((*ival)->sLabel == LABEL_NODE) // fils
      {
        (*ival)->pObject = new Cnode((*ival)->sAttribute, (*ival)->sValue, this) ;
        if (!(*ival)->pObject->parser())
        {
          // erreur parsing node
          iParsingError = (*ival)->pObject->iParsingError ;
          return false ;
        }
      }
      else
      {
        // erreur (valeur incorrecte)
        iParsingError = ENODE_VAL ;
        return false ;
      }
    }
  }
	return true ;
}

boolCnode::verif(){
  return true ;
}

bool
Cnode::compresser()
{
  return true ;
}

bool
Cnode::traiter()
{
  return true ;
}

bool
Cnode::chargePatPatho(NSPatPathoArray *pPPTArray)
{
  if (!pPPTArray)
    return false ;

  // on charge la patpathoInfo du node en cours
  pPPTArray->push_back(new NSPatPathoInfo(*pPatPathoInfo)) ;

  // on relance sur les node fils
  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // apres parsing on est surs qu'il n'y a que des node
      Cnode *pCnode = dynamic_cast<Cnode *>((*ival)->pObject) ;
      pCnode->chargePatPatho(pPPTArray) ;
    }
  }
  return false ;
}

bool
Cnode::initFromPatPatho(NSPatPathoArray *pPPTArray)
{
	if (NULL == pPPTArray)
  	return false ;

	vect_val.vider() ;

	if (true == pPPTArray->empty())
  	return true ;

	PatPathoIter it = pPPTArray->begin() ;
  while ((NULL != it) && (pPPTArray->end() != it))
	{
  	// Create CValeur and Cnode
    //
  	CValeur* pValeur = new CValeur(LABEL_NODE, string(""), string(""), this) ;
		vect_val.push_back(pValeur) ;
    pValeur->pObject = new Cnode(string(""), string(""), this) ;

    // Init Cnode
    //
    Cnode *pCnode = dynamic_cast<Cnode*>(pValeur->pObject) ;
    *(pCnode->pPatPathoInfo) = **it ;

    // if (string("") != pCnode->pPatPathoInfo->getLocalisation())
    //	pCnode->addAttribute(ATTRIBUT_NODE_LOC,        pCnode->pPatPathoInfo->getLocalisation()) ;
    if (string("") != pCnode->pPatPathoInfo->getType())
    	pCnode->addAttribute(ATTRIBUT_NODE_TYPE,       pCnode->pPatPathoInfo->getType()) ;
    if (string("") != pCnode->pPatPathoInfo->getLexique())
    	pCnode->addAttribute(ATTRIBUT_NODE_LEXIQUE,    pCnode->pPatPathoInfo->getLexique()) ;
    if (string("") != pCnode->pPatPathoInfo->getUnit())
    	pCnode->addAttribute(ATTRIBUT_NODE_UNIT,       pCnode->pPatPathoInfo->getUnit()) ;
    if (string("") != pCnode->pPatPathoInfo->getComplement())
    	pCnode->addAttribute(ATTRIBUT_NODE_COMPLEMENT, pCnode->pPatPathoInfo->getComplement()) ;
    if (string("") != pCnode->pPatPathoInfo->getTexteLibre())
    	pCnode->addAttribute(ATTRIBUT_NODE_FREETEXT,   pCnode->pPatPathoInfo->getTexteLibre()) ;
    if (string("") != pCnode->pPatPathoInfo->getCertitude())
    	pCnode->addAttribute(ATTRIBUT_NODE_CERTITUDE,  pCnode->pPatPathoInfo->getCertitude()) ;
    if (string("") != pCnode->pPatPathoInfo->getInteret())
    	pCnode->addAttribute(ATTRIBUT_NODE_INTERET,    pCnode->pPatPathoInfo->getInteret()) ;
    if (string("") != pCnode->pPatPathoInfo->getPluriel())
    	pCnode->addAttribute(ATTRIBUT_NODE_PLURIEL,    pCnode->pPatPathoInfo->getPluriel()) ;

    NSPatPathoArray subPpt(pPPTArray->pContexte) ;
    pPPTArray->ExtrairePatPatho(it, &subPpt) ;
    pCnode->initFromPatPatho(&subPpt) ;

    // Next root node ?
    //
    it = pPPTArray->ChercherFrere(it) ;
	}

	return true ;
}

bool
Cnode::traiteCodeLoc(int *iLigne, int iColonne)
{
  pPatPathoInfo->setLigne((*iLigne)++) ;
  pPatPathoInfo->setColonne(iColonne) ;

  for (ValIter iterVal = vect_val.begin() ; iterVal != vect_val.end() ; iterVal++)
  {
    Cnode *pCnode = dynamic_cast<Cnode *>((*iterVal)->pObject) ;
    pCnode->traiteCodeLoc(iLigne, iColonne + 1) ;
  }
  return true ;
}


// -----------------------------------------------------------------------------
//
// Classe CFriendsGroup
//
// -----------------------------------------------------------------------------

CFriendsGroup::CFriendsGroup(string attributs, string values, Cbalise *father, NSContexte *pCtx)
  : Cbalise(attributs, values, father)
{
  pContexte       = pCtx ;
}


CFriendsGroup::~CFriendsGroup()
{
}


bool
CFriendsGroup::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	//
	// Pas grave si vide ; Can be empty
	//
	if (vect_val.empty())
  	return true ;

	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
		if ((*ival)->sLabel == LABEL_EXCLUDE) // noeud
		{
      (*ival)->pObject = new CExcludedFriends((*ival)->sAttribute, (*ival)->sValue, this, pContexte) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing items
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
		}
		else if ((*ival)->sLabel == LABEL_NEED) // noeud
		{
      (*ival)->pObject = new CNeededFriends((*ival)->sAttribute, (*ival)->sValue, this, pContexte) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing items
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
		}
		else
    {
      // erreur (valeur incorrecte)
      iParsingError = ETREE_VAL ;
      return false ;
    }
  }

	return true ;
}

boolCFriendsGroup::verif(){
  return true ;
}

bool
CFriendsGroup::compresser()
{
  return true ;
}

bool
CFriendsGroup::traiter()
{
  return true ;
}

CExcludedFriends*
CFriendsGroup::getExcludedFriends()
{
  for (ValIter iterVal = vect_val.begin() ; iterVal != vect_val.end() ; iterVal++)
  {
		if ((*iterVal)->sLabel == LABEL_EXCLUDE) // noeud
		{
      CExcludedFriends *pExcluded = dynamic_cast<CExcludedFriends *>((*iterVal)->pObject) ;
      if (pExcluded)
      	return pExcluded ;
		}
  }
  return NULL ;
}

CNeededFriends*
CFriendsGroup::getNeededFriends()
{
  for (ValIter iterVal = vect_val.begin() ; iterVal != vect_val.end() ; iterVal++)
  {
		if ((*iterVal)->sLabel == LABEL_NEED) // noeud
		{
      CNeededFriends *pNeeded = dynamic_cast<CNeededFriends *>((*iterVal)->pObject) ;
      if (pNeeded)
      	return pNeeded ;
		}
  }
  return NULL ;
}

// -----------------------------------------------------------------------------
//
// Classe CExcludedFriends
//
// -----------------------------------------------------------------------------

CExcludedFriends::CExcludedFriends(string attributs, string values, Cbalise *father, NSContexte *pCtx)
  : Cbalise(attributs, values, father)
{
  pContexte       = pCtx ;
}


CExcludedFriends::~CExcludedFriends()
{
}


bool
CExcludedFriends::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	//
	// Pas grave si vide ; Can be empty
	//
	if (vect_val.empty())
  	return true ;

	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
		if ((*ival)->sLabel == LABEL_FRIEND) // noeud
		{
      (*ival)->pObject = new Cfriend((*ival)->sAttribute, (*ival)->sValue, this, pContexte) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing items
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
		}
		else
    {
      // erreur (valeur incorrecte)
      iParsingError = ETREE_VAL ;
      return false ;
    }
  }

	return true ;
}

boolCExcludedFriends::verif(){
  return true ;
}

bool
CExcludedFriends::compresser()
{
  return true ;
}

bool
CExcludedFriends::traiter()
{
  return true ;
}

Cfriend*
CExcludedFriends::getNextExcludedFriend(Cfriend *pPrevious)
{
  Cfriend  *pRef = NULL ;
  Cfriend  *pBuf ;
  bool     bReturnNext = false ;
  if (!pPrevious)
  	bReturnNext = true ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if ((*ival)->sLabel == LABEL_FRIEND)
      {
        pBuf = dynamic_cast<Cfriend *>((*ival)->pObject) ;
        if (pBuf)
				{
        	if (bReturnNext)
        	{
          	pRef = pBuf ;
          	break ;
        	}
        	if (pBuf == pPrevious)
          	bReturnNext = true ;
				}
      }
    }
  }
  return pRef ;
}


// -----------------------------------------------------------------------------
//
// Classe CNeededFriends
//
// -----------------------------------------------------------------------------

CNeededFriends::CNeededFriends(string attributs, string values, Cbalise *father, NSContexte *pCtx)
  : Cbalise(attributs, values, father)
{
  pContexte       = pCtx ;
}


CNeededFriends::~CNeededFriends()
{
}


bool
CNeededFriends::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	//
	// Pas grave si vide ; Can be empty
	//
	if (vect_val.empty())
  	return true ;

	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
		if ((*ival)->sLabel == LABEL_FRIEND) // noeud
		{
      (*ival)->pObject = new Cfriend((*ival)->sAttribute, (*ival)->sValue, this, pContexte) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing items
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
		}
		else
    {
      // erreur (valeur incorrecte)
      iParsingError = ETREE_VAL ;
      return false ;
    }
  }

	return true ;
}

boolCNeededFriends::verif(){
  return true ;
}

bool
CNeededFriends::compresser()
{
  return true ;
}

bool
CNeededFriends::traiter()
{
  return true ;
}

Cfriend*
CNeededFriends::getNextNeededFriend(Cfriend *pPrevious)
{
  Cfriend  *pRef = NULL ;
  Cfriend  *pBuf ;
  bool     bReturnNext = false ;
  if (!pPrevious)
  	bReturnNext = true ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if ((*ival)->sLabel == LABEL_FRIEND)
      {
        pBuf = dynamic_cast<Cfriend *>((*ival)->pObject) ;
        if (pBuf)
				{
        	if (bReturnNext)
        	{
          	pRef = pBuf ;
          	break ;
        	}
        	if (pBuf == pPrevious)
          	bReturnNext = true ;
				}
      }
    }
  }
  return pRef ;
}


// -----------------------------------------------------------------------------
//
// Classe Cfriend
//
// -----------------------------------------------------------------------------

Cfriend::Cfriend(string attributs, string values, Cbalise *father, NSContexte *pCtx)
  : Cbalise(attributs, values, father)
{
  pContexte       = pCtx ;
}


Cfriend::~Cfriend()
{
}


bool
Cfriend::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (vect_attr.empty())
  {
    // erreur (pas d'attribut)
    iParsingError = ETREE_ATTR_EMPTY ;
    return false ;
  }

  int nb_id = 0 ;
	for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
  {
		if ((*iattribut)->getLabel() == ATTRIBUT_FRIEND_ID) // localisation
			nb_id++ ;
		else
    {
      // erreur (attribut incorrect)
      iParsingError = ETREE_ATTR ;
      return false ;
    }
  }

	if (nb_id != 1)
  {
    // erreur (nb attributs incorrect)
    iParsingError = ETREE_NBATTR ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	return true ;
}

boolCfriend::verif(){
  return true ;
}

bool
Cfriend::compresser()
{
  return true ;
}

bool
Cfriend::traiter()
{
  return true ;
}

string
Cfriend::getId()
{
  return getStringAttribute(ATTRIBUT_FRIEND_ID) ;
}

// -----------------------------------------------------------------------------
// ajout FLP - juin 2003
// -----------------------------------------------------------------------------
// balises "dialogbox" et "rcdata" dans archetypes
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// balise dialogbox
// -----------------------------------------------------------------------------

Cdialogbox::Cdialogbox(string attributes, string values, Cbalise *father)
  : Cbalise(attributes, values, father)
{
}


Cdialogbox::~Cdialogbox()
{
}


bool
Cdialogbox::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (vect_attr.empty())
  {
    iParsingError = EDIALOGBOX_ATTR_EMPTY ;
    return false ; // erreur (pas d'attribut)
  }

  int   nbLang      = 0 ;
  int   nbType      = 0 ;
  int   nbCoords    = 0 ;
  int   nbStyle     = 0 ;
  int   nbClass     = 0 ;
  int   nbCaption   = 0 ;
  int   nbFontSize  = 0 ;
  int   nbFontType  = 0 ;
  int   nbNSTitre   = 0 ;

	for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
  {
		if      ((*iattribut)->getLabel() == ATTRIBUT_DIALOGBOX_LANG)     // langue de la dialogbox
			nbLang++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_DIALOGBOX_TYPE)     // type de la dialogbox
			nbType++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_DIALOGBOX_COORDS)   // coordonn�es de la dialogbox
			nbCoords++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_DIALOGBOX_STYLE)    // style de la dialogbox
			nbStyle++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_DIALOGBOX_CLASS)    // class de la dialogbox
      nbClass++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_DIALOGBOX_CAPTION)  // caption de la dialogbox
      nbCaption++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_DIALOGBOX_FONTSIZE) // fontsize de la dialogbox
      nbFontSize++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_DIALOGBOX_FONTTYPE) // fonttype de la dialogbox
      nbFontType++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_DIALOGBOX_NSTITRE) // titre du rcdata de la dialogbox
      nbNSTitre++ ;
		else
    {
      // erreur (attribut incorrect)
      iParsingError = EDIALOGBOX_ATTR ;
      return false ;
    }
  }

	if ((nbType     !=  1)  ||
      (nbCoords   !=  1)  ||
      (nbStyle    !=  1)  ||
      (nbClass    !=  1)  ||
      (nbCaption  !=  1)  ||
      (nbFontSize !=  1)  ||
      (nbFontType !=  1)  ||
      (nbNSTitre  >   1))
  {
    // erreur (nb attributs incorrect)
    iParsingError = EDIALOGBOX_NBATTR ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
  parseValue() ;

	if (!parser_valeurs())
		return false ;

	if (vect_val.empty())
  {
    // erreur (pas de valeur)
    iParsingError = EDIALOGBOX_VAL_EMPTY ;
    return false ;
  }

  int nbControl     = 0 ;
  int nbRCData      = 0 ;
  int nbTabControl  = 0 ;
	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
		if ((*ival)->sLabel == LABEL_DIALOGBOX_CONTROL)     // control appartenant � la dialogbox
		{
      (*ival)->pObject = new Ccontrol((*ival)->sAttribute, (*ival)->sValue, this) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing dialogue
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
/*
      if (!(*ival)->pObject->parseValue())
      {
        iParsingError = ECONTROL_ATTR_PARSING;
        return false;
      }
*/
			nbControl++ ;
		}
    else if ((*ival)->sLabel == LABEL_DIALOGBOX_RCDATA) // rcdata de la dialogbox
    {
      (*ival)->pObject = new Crcdata((*ival)->sAttribute, (*ival)->sValue, this) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing items
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
      nbRCData++ ;
    }
    else if ((*ival)->sLabel == LABEL_DIALOGBOX_ONGLETS) // onglets de la dialogbox
    {
      (*ival)->pObject = new Ctabcontrol((*ival)->sAttribute, (*ival)->sValue, this) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing items
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
      nbTabControl++ ;
    }
		else
    {
      // erreur (valeur incorrecte)
      iParsingError = EDIALOGBOX_VAL ;
      return false ;
    }
  }

	if ((nbControl < 1) || (nbRCData > 1) || (nbTabControl > 1))
  {
    // erreur (nb valeurs incorrect)
    iParsingError = EDIALOGBOX_NBVAL ;
    return false ;
  }

	return true ;
}


bool
Cdialogbox::verif()
{
  return true ;
}


bool
Cdialogbox::compresser()
{
  return true ;
}


bool
Cdialogbox::traiter()
{
  return true ;
}


int
Cdialogbox::getIStyle()
{
  return value.iStyle ;
}


void
Cdialogbox::setIStyle(string style)
{
  string    attr ;
  size_t    i = 0 ;
  int       iStyle = 0 ;

  // on avance sur les blancs initiaux
  while ((i < strlen(style.c_str())) && ((style[i] == ' ') || (style[i] == '|')))
    i++;

  while (i < strlen(style.c_str()))
  {
    attr = "" ;

    while ((i < strlen(style.c_str())) && (style[i] != ' ') && (style[i] != '|'))
      attr += style[i++] ;

    while ((i < strlen(style.c_str())) && ((style[i] == ' ') || (style[i] == '|')))
      i++ ;

    if      (attr == "WS_BORDER")
      iStyle |= WS_BORDER ;
    else if (attr == "WS_CAPTION")
      iStyle |= WS_CAPTION ;
    else if (attr == "WS_CHILD")
      iStyle |= WS_CHILD ;
    else if (attr == "WS_CHILDWINDOW")
      iStyle |= WS_CHILDWINDOW ;
    else if (attr == "WS_CLIPCHILDREN")
      iStyle |= WS_CLIPCHILDREN ;
    else if (attr == "WS_CLIPSIBLINGS")
      iStyle |= WS_CLIPSIBLINGS ;
    else if (attr == "WS_DISABLED")
      iStyle |= WS_DISABLED ;
    else if (attr == "WS_DLGFRAME")
      iStyle |= WS_DLGFRAME ;
    else if (attr == "WS_GROUP")
      iStyle |= WS_GROUP ;
    else if (attr == "WS_HSCROLL")
      iStyle |= WS_HSCROLL ;
    else if (attr == "WS_ICONIC")
      iStyle |= WS_ICONIC ;
    else if (attr == "WS_MAXIMIZE")
      iStyle |= WS_MAXIMIZE ;
    else if (attr == "WS_MAXIMIZEBOX")
      iStyle |= WS_MAXIMIZEBOX ;
    else if (attr == "WS_MINIMIZE")
      iStyle |= WS_MINIMIZE ;
    else if (attr == "WS_MINIMIZEBOX")
      iStyle |= WS_MINIMIZEBOX ;
    else if (attr == "WS_OVERLAPPED")
      iStyle |= WS_OVERLAPPED ;
    else if (attr == "WS_OVERLAPPEDWINDOW")
      iStyle |= WS_OVERLAPPEDWINDOW ;
    else if (attr == "WS_POPUP")
      iStyle |= WS_POPUP ;
    else if (attr == "WS_POPUPWINDOW")
      iStyle |= WS_POPUPWINDOW ;
    else if (attr == "WS_SIZEBOX")
      iStyle |= WS_SIZEBOX ;
    else if (attr == "WS_SYSMENU")
      iStyle |= WS_SYSMENU ;
    else if (attr == "WS_TABSTOP")
      iStyle |= WS_TABSTOP ;
    else if (attr == "WS_THICKFRAME")
      iStyle |= WS_THICKFRAME ;
    else if (attr == "WS_TILED")
      iStyle |= WS_TILED ;
    else if (attr == "WS_TILEDWINDOW")
      iStyle |= WS_TILEDWINDOW ;
    else if (attr == "WS_VISIBLE")
      iStyle |= WS_VISIBLE ;
    else if (attr == "WS_VSCROLL")
      iStyle |= WS_VSCROLL ;

    else if (attr == "DS_3DLOOK")
      iStyle |= DS_3DLOOK ;
    else if (attr == "DS_ABSALIGN")
      iStyle |= DS_ABSALIGN ;
    else if (attr == "DS_CENTER	")
      iStyle |= DS_CENTER	 ;
    else if (attr == "DS_CENTERMOUSE	")
      iStyle |= DS_CENTERMOUSE	 ;
    else if (attr == "DS_CONTEXTHELP")
      iStyle |= DS_CONTEXTHELP ;
    else if (attr == "DS_CONTROL	")
      iStyle |= DS_CONTROL	 ;
    else if (attr == "DS_FIXEDSYS")
      iStyle |= DS_FIXEDSYS ;
    else if (attr == "DS_LOCALEDIT")
      iStyle |= DS_LOCALEDIT ;
    else if (attr == "DS_MODALFRAME")
      iStyle |= DS_MODALFRAME ;
    else if (attr == "DS_NOFAILCREATE")
      iStyle |= DS_NOFAILCREATE ;
    else if (attr == "DS_NOIDLEMSG")
      iStyle |= DS_NOIDLEMSG ;
//  seems to not be defined
//    else if (attr == "DS_RECURSE")
//      iStyle |= DS_RECURSE ;
    else if (attr == "DS_SETFONT")
      iStyle |= DS_SETFONT ;
    else if (attr == "DS_SETFOREGROUND")
      iStyle |= DS_SETFOREGROUND ;
    else if (attr == "DS_SYSMODAL")
      iStyle |= DS_SYSMODAL ;
    //
    // TreeView styles
    //
    else if (attr == "TVS_HASBUTTONS")
      iStyle |= TVS_HASBUTTONS ;
    else if (attr == "TVS_HASLINES")
      iStyle |= TVS_HASLINES ;
    else if (attr == "TVS_LINESATROOT")
      iStyle |= TVS_LINESATROOT ;
    else if (attr == "TVS_EDITLABELS")
      iStyle |= TVS_EDITLABELS ;
    else if (attr == "TVS_SHOWSELALWAYS")
      iStyle |= TVS_SHOWSELALWAYS ;
    else if (attr == "TVS_NOTOOLTIPS")
      iStyle |= TVS_NOTOOLTIPS ;
    else if (attr == "TVS_CHECKBOXES")
      iStyle |= TVS_CHECKBOXES ;
    else if (attr == "TVS_TRACKSELECT")
      iStyle |= TVS_TRACKSELECT ;
    else if (attr == "TVS_SINGLEEXPAND")
      iStyle |= TVS_SINGLEEXPAND ;
    else if (attr == "TVS_INFOTIP")
      iStyle |= TVS_INFOTIP ;
    else if (attr == "TVS_FULLROWSELECT")
      iStyle |= TVS_FULLROWSELECT ;
    else if (attr == "TVS_NOSCROLL")
      iStyle |= TVS_NOSCROLL ;
    else if (attr == "TVS_NONEVENHEIGHT")
      iStyle |= TVS_NONEVENHEIGHT ;
    else
    {
      char msg[255] ;
      sprintf(msg, "Le style [%s] n'est pas encore d�fini dans le parseur.", attr.c_str()) ;
      erreur(msg, standardError, 0) ;
    }
  }

  value.iStyle = iStyle ;
}


bool
Cdialogbox::parseValue()
{
  string    sCoords = getCoords() ;
  size_t    deb     = 0 ;
  size_t    fin ;

  // Parsing du style
  value.style = getStyle() ;
  setIStyle(value.style) ;

  // Parsing des coordonn�es
  value.coords = getCoords() ;

  fin = sCoords.find(" ") ;
  if (fin == string::npos)
    return false ;
  string sX = string(sCoords, deb, fin - deb) ;
  value.x   = atoi(sX.c_str()) ;

  deb = fin ;
  fin = sCoords.find(" ", deb + 1) ;
  if (fin == string::npos)
    return false ;
  string sY = string(sCoords, deb + 1, fin - (deb + 1)) ;
  value.y   = atoi(sY.c_str()) ;

  deb = fin ;
  fin = sCoords.find(" ", deb + 1) ;
  if (fin == string::npos)
    return false ;
  string sW = string(sCoords, deb + 1, fin - (deb + 1)) ;
  value.w   = atoi(sW.c_str()) ;

  deb = fin ;
  fin = strlen(sCoords.c_str()) ;
  string sH = string(sCoords, deb + 1, fin - (deb + 1)) ;
  value.h   = atoi(sH.c_str()) ;

  return true ;
}


int
Cdialogbox::getX()
{
  return (value.x) ;
}


int
Cdialogbox::getY()
{
  return (value.y) ;
}


int
Cdialogbox::getW()
{
  return (value.w) ;
}


int
Cdialogbox::getH()
{
  return (value.h) ;
}

string
Cdialogbox::getLang()
{
	return getStringAttribute(ATTRIBUT_DIALOGBOX_LANG) ;
}

string
Cdialogbox::getType()
{
  return getStringAttribute(ATTRIBUT_DIALOGBOX_TYPE) ;
}


string
Cdialogbox::getCoords()
{
  return getStringAttribute(ATTRIBUT_DIALOGBOX_COORDS) ;
}


string
Cdialogbox::getStyle()
{
  return getStringAttribute(ATTRIBUT_DIALOGBOX_STYLE) ;
}


string
Cdialogbox::getClass()
{
  return getStringAttribute(ATTRIBUT_DIALOGBOX_CLASS) ;
}


string
Cdialogbox::getCaption()
{
  return getStringAttribute(ATTRIBUT_DIALOGBOX_CAPTION) ;
}


string
Cdialogbox::getFontSize()
{
  return getStringAttribute(ATTRIBUT_DIALOGBOX_FONTSIZE) ;
}


string
Cdialogbox::getFontType()
{
  return getStringAttribute(ATTRIBUT_DIALOGBOX_FONTTYPE) ;
}

string
Cdialogbox::getNSTitre()
{
  return getStringAttribute(ATTRIBUT_DIALOGBOX_NSTITRE) ;
}


Ccontrol *
Cdialogbox::getFirstControl()
{
  Ccontrol  *pControl = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if ((*ival)->sLabel == LABEL_DIALOGBOX_CONTROL)
      {
        pControl = dynamic_cast<Ccontrol *>((*ival)->pObject) ;
        break ;
      }
    }
  }
  return pControl ;
}


Ccontrol *
Cdialogbox::getNextControl(Ccontrol *pLastControl)
{
  Ccontrol  *pControl   = NULL ;
  Ccontrol  *pBuf ;
  bool      bReturnNext = false ;
  if (!pLastControl)
  	bReturnNext = true ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if ((*ival)->sLabel == LABEL_DIALOGBOX_CONTROL)
      {
        pBuf = dynamic_cast<Ccontrol *>((*ival)->pObject);
        if (bReturnNext && pBuf)
        {
          pControl = pBuf;
          break;
        }
        if (pBuf == pLastControl)
          bReturnNext = true;
      }
    }
  }
  return pControl ;
}


int
Cdialogbox::getNbControl()
{
  Ccontrol  *pControl   = NULL ;
  int       nbControl   = 0 ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if ((*ival)->sLabel == LABEL_DIALOGBOX_CONTROL)
      {
        pControl = dynamic_cast<Ccontrol *>((*ival)->pObject);
        if (pControl != NULL)
          nbControl++ ;
      }
    }
  }
  return nbControl ;
}


Crcdata *
Cdialogbox::getRCData()
{
  Crcdata   *pRCData = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if ((*ival)->sLabel == LABEL_DIALOGBOX_RCDATA)
      {
        pRCData = dynamic_cast<Crcdata *>((*ival)->pObject) ;
        break ;
      }
    }
  }
  return pRCData ;
}


Ctabcontrol *
Cdialogbox::getTabControl()
{
  Ctabcontrol   *pTabControl = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if ((*ival)->sLabel == LABEL_DIALOGBOX_ONGLETS)
      {
        pTabControl = dynamic_cast<Ctabcontrol *>((*ival)->pObject) ;
        break ;
      }
    }
  }
  return pTabControl ;
}


string
Cdialogbox::getStringRCData()
{
  string    sRCData = "" ;
  Ccontrol  *pControl = getFirstControl() ;

  while (pControl != NULL)
  {
    string sData = pControl->getData() ;

    if (sData == "")
      sRCData += string(" |") ;
    else
      sRCData += (sData + string("|")) ;

    pControl = getNextControl(pControl) ;
  }

  return sRCData ;
}


string
Cdialogbox::getValueRCData()
{
  string sNSTitre = getNSTitre() ;
  string sRCData  = getStringRCData() ;

  string sReturn = string("\"NSTITRE\"\n\"") + sNSTitre + string("\"\n\"NSCONTRO\"\n\"") + sRCData + string("\"\n\"FINRCDAT\"\n") ;
  return sReturn ;
}


Ccontrol::Ccontrol(string attributes, string values, Cbalise *father)
  : Cbalise(attributes, values, father)
{
}


Ccontrol::~Ccontrol()
{
}


bool
Ccontrol::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (vect_attr.empty())
  {
    iParsingError = ECONTROL_ATTR_EMPTY ;
    return false ; // erreur (pas d'attribut)
  }

  int       nbValue = 0 ;
  int       nbTab = 0 ;
  int       nbData = 0 ;
  int       nbFill = 0;
/*
// for the future
  int       nbCaption = 0 ;
  int       nbRefId   = 0 ;
  int       nbType    = 0 ;
  int       nbStyle   = 0 ;
  int       nbCoords  = 0 ;
*/

	for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
  {
		if      ((*iattribut)->getLabel() == ATTRIBUT_CONTROL_VALUE)      // valeur du control
			nbValue++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_CONTROL_ONGLET) // onglet associ�
			nbTab++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_CONTROL_DATA)  // chemin du RCData associ�
			nbData++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_CONTROL_FILLING)  // chemin du coche associ�
			nbFill++ ;
/*
    else if ((*iattribut)->sLabel == ATTRIBUT_CONTROL_CAPTION) // dll
			nbCaption++ ;
    else if ((*iattribut)->sLabel == ATTRIBUT_CONTROL_REFID) // referentiel
			nbRefId++ ;
    else if ((*iattribut)->sLabel == ATTRIBUT_CONTROL_TYPE) // referentiel
			nbType++ ;
    else if ((*iattribut)->sLabel == ATTRIBUT_CONTROL_STYLE) // referentiel
			nbStyle++ ;
    else if ((*iattribut)->sLabel == ATTRIBUT_CONTROL_COORDS) // referentiel
			nbCoords++ ;
*/
		else
    {
      iParsingError = ECONTROL_ATTR ;
      return false; // erreur (attribut incorrect)
    }
  }

	if ((nbValue != 1) || (nbTab > 1) || (nbData > 1) || (nbFill > 1))
  {
    iParsingError = ECONTROL_NBATTR ;
    return false ; // erreur (nb attributs incorrect)
  }

  // ---------------------------------------------------------------------------
	// valeurs
	parseValue() ;

	if (!parser_valeurs())
		return false ;

	if (!vect_val.empty())
  {
    // erreur (cas normal : pas de valeur)
    iParsingError = ECONTROL_VAL_NOT_EMPTY ;
    return false ;
  }
	return true ;
}


bool
Ccontrol::verif()
{
  return true ;
}


bool
Ccontrol::compresser()
{
  return true ;
}


bool
Ccontrol::traiter()
{
  return true ;
}


string
Ccontrol::getValue()
{
  return getStringAttribute(ATTRIBUT_CONTROL_VALUE) ;
}


string
Ccontrol::getTab()
{
  return getStringAttribute(ATTRIBUT_CONTROL_ONGLET) ;
}


string
Ccontrol::getData()
{
  return getStringAttribute(ATTRIBUT_CONTROL_DATA) ;
}

string
Ccontrol::getFilling()
{
  return getStringAttribute(ATTRIBUT_CONTROL_FILLING) ;
}


void
Ccontrol::setIStyle(string style)
{
	if (style == string(""))
		return ;

  size_t  i        = 0 ;
  int     iStyle   = 0 ;
  size_t  iStylLen = strlen(style.c_str()) ;

  // on avance sur les blancs initiaux
  while ((i < iStylLen) && ((style[i] == ' ') || (style[i] == '|')))
    i++ ;

  while (i < iStylLen)
  {
    string attr = "" ;
    bool   bNot = false ;

    bool bCherche = true ;
    while (bCherche)
		{
    	while ((i < iStylLen) && (style[i] != ' ') && (style[i] != '|'))
      	attr += style[i++] ;

      if ((i >= iStylLen) || (style[i] == '|'))
      	bCherche = false ;
      else
      	while ((i < iStylLen) && (style[i] == ' '))
    			i++ ;

      pseumaj(&attr) ;
      if (attr == string("NOT"))
      {
      	bNot = true ;
        attr = "" ;
      }
		}
    while ((i < iStylLen) && ((style[i] == ' ') || (style[i] == '|')))
    	i++ ;

    if (attr == "BSS_RGROUP")
    	setStyleAttribute(&iStyle, BSS_RGROUP, bNot) ;
    else if (attr == "BSS_GROUP")
      setStyleAttribute(&iStyle, BSS_GROUP, bNot) ;
    else if (attr == "BSS_HDIP")
      setStyleAttribute(&iStyle, BSS_HDIP, bNot) ;
    else if (attr == "BSS_VDIP")
      setStyleAttribute(&iStyle, BSS_VDIP, bNot) ;
    else if (attr == "BSS_CAPTION")
      setStyleAttribute(&iStyle, BSS_CAPTION, bNot) ;
    else if (attr == "BSS_CENTER")
      setStyleAttribute(&iStyle, BSS_CENTER, bNot) ;
    else if (attr == "BSS_LEFT")
      setStyleAttribute(&iStyle, BSS_LEFT, bNot) ;
    else if (attr == "BS_GROUPBOX")
      setStyleAttribute(&iStyle, BS_GROUPBOX, bNot) ;
    else if (attr == "BS_PUSHBUTTON")
      setStyleAttribute(&iStyle, BS_PUSHBUTTON, bNot) ;
    else if (attr == "BS_DEFPUSHBUTTON")
      setStyleAttribute(&iStyle, BS_DEFPUSHBUTTON, bNot) ;
    else if (attr == "BS_RADIOBUTTON")
      setStyleAttribute(&iStyle, BS_RADIOBUTTON, bNot) ;
    else if (attr == "BS_AUTORADIOBUTTON")
      setStyleAttribute(&iStyle, BS_AUTORADIOBUTTON, bNot) ;
    else if (attr == "BS_CHECKBOX")
      setStyleAttribute(&iStyle, BS_CHECKBOX, bNot) ;
    else if (attr == "BS_AUTOCHECKBOX")
      setStyleAttribute(&iStyle, BS_AUTOCHECKBOX, bNot) ;
    else if (attr == "BS_CENTER")
      setStyleAttribute(&iStyle, BS_CENTER, bNot) ;
    else if (attr == "LVS_REPORT")
      setStyleAttribute(&iStyle, LVS_REPORT, bNot) ;
    else if (attr == "LVS_LIST")
      setStyleAttribute(&iStyle, LVS_LIST, bNot) ;
    else if (attr == "LVS_SINGLESEL")
      setStyleAttribute(&iStyle, LVS_SINGLESEL, bNot) ;
    else if (attr == "LVS_NOSORTHEADER")
      setStyleAttribute(&iStyle, LVS_NOSORTHEADER, bNot) ;
    else if (attr == "ES_LEFT")
      setStyleAttribute(&iStyle, ES_LEFT, bNot) ;
    else if (attr == "ES_CENTER")
      setStyleAttribute(&iStyle, ES_CENTER, bNot) ;
    else if (attr == "ES_RIGHT")
      setStyleAttribute(&iStyle, ES_RIGHT, bNot) ;
    else if (attr == "ES_READONLY")
      setStyleAttribute(&iStyle, ES_READONLY, bNot) ;
    else if (attr == "SS_LEFT")
      setStyleAttribute(&iStyle, SS_LEFT, bNot) ;
    else if (attr == "SS_CENTER")
      setStyleAttribute(&iStyle, SS_CENTER, bNot) ;
    else if (attr == "SS_ETCHEDFRAME")
      setStyleAttribute(&iStyle, SS_ETCHEDFRAME, bNot) ;
    else if (attr == "WS_BORDER")
      setStyleAttribute(&iStyle, WS_BORDER, bNot) ;
    else if (attr == "WS_CAPTION")
      setStyleAttribute(&iStyle, WS_CAPTION, bNot) ;
    else if (attr == "WS_CHILD")
      setStyleAttribute(&iStyle, WS_CHILD, bNot) ;
    else if (attr == "WS_CHILDWINDOW")
      setStyleAttribute(&iStyle, WS_CHILDWINDOW, bNot) ;
    else if (attr == "WS_CLIPCHILDREN")
      setStyleAttribute(&iStyle, WS_CLIPCHILDREN, bNot) ;
    else if (attr == "WS_CLIPSIBLINGS")
      setStyleAttribute(&iStyle, WS_CLIPSIBLINGS, bNot) ;
    else if (attr == "WS_DISABLED")
      setStyleAttribute(&iStyle, WS_DISABLED, bNot) ;
    else if (attr == "WS_DLGFRAME")
      setStyleAttribute(&iStyle, WS_DLGFRAME, bNot) ;
    else if (attr == "WS_GROUP")
      setStyleAttribute(&iStyle, WS_GROUP, bNot) ;
    else if (attr == "WS_HSCROLL")
      setStyleAttribute(&iStyle, WS_HSCROLL, bNot) ;
    else if (attr == "WS_MAXIMIZE")
      setStyleAttribute(&iStyle, WS_MAXIMIZE, bNot) ;
    else if (attr == "WS_MAXIMIZEBOX")
      setStyleAttribute(&iStyle, WS_MAXIMIZEBOX, bNot) ;
    else if (attr == "WS_MINIMIZE")
      setStyleAttribute(&iStyle, WS_MINIMIZE, bNot) ;
    else if (attr == "WS_MINIMIZEBOX")
      setStyleAttribute(&iStyle, WS_MINIMIZEBOX, bNot) ;
    else if (attr == "WS_OVERLAPPED")
      setStyleAttribute(&iStyle, WS_OVERLAPPED, bNot) ;
    else if (attr == "WS_OVERLAPPEDWINDOW")
      setStyleAttribute(&iStyle, WS_OVERLAPPEDWINDOW, bNot) ;
    else if (attr == "WS_POPUP")
      setStyleAttribute(&iStyle, WS_POPUP, bNot) ;
    else if (attr == "WS_POPUPWINDOW")
      setStyleAttribute(&iStyle, WS_POPUPWINDOW, bNot) ;
    else if (attr == "WS_SYSMENU")
      setStyleAttribute(&iStyle, WS_SYSMENU, bNot) ;
    else if (attr == "WS_TABSTOP")
      setStyleAttribute(&iStyle, WS_TABSTOP, bNot) ;
    else if (attr == "WS_THICKFRAME")
      setStyleAttribute(&iStyle, WS_THICKFRAME, bNot) ;
    else if (attr == "WS_VISIBLE")
      setStyleAttribute(&iStyle, WS_VISIBLE, bNot) ;
    else if (attr == "WS_VSCROLL")
      setStyleAttribute(&iStyle, WS_VSCROLL, bNot) ;
    else if (attr == "CBS_DROPDOWNLIST")
      setStyleAttribute(&iStyle, CBS_DROPDOWNLIST, bNot) ;
    else if (attr == "CBS_SORT")
      setStyleAttribute(&iStyle, CBS_SORT, bNot) ;
    else if (attr == "TVS_HASBUTTONS")
      setStyleAttribute(&iStyle, TVS_HASBUTTONS, bNot) ;
    else if (attr == "TVS_HASLINES")
      setStyleAttribute(&iStyle, TVS_HASLINES, bNot) ;
    else if (attr == "TVS_LINESATROOT")
      setStyleAttribute(&iStyle, TVS_LINESATROOT, bNot) ;
    else if (attr == "TVS_EDITLABELS")
      setStyleAttribute(&iStyle, TVS_EDITLABELS, bNot) ;
    else if (attr == "TVS_SHOWSELALWAYS")
      setStyleAttribute(&iStyle, TVS_SHOWSELALWAYS, bNot) ;
    else if (attr == "TVS_NOTOOLTIPS")
      setStyleAttribute(&iStyle, TVS_NOTOOLTIPS, bNot) ;
    else if (attr == "TVS_CHECKBOXES")
      setStyleAttribute(&iStyle, TVS_CHECKBOXES, bNot) ;
    else if (attr == "TVS_TRACKSELECT")
      setStyleAttribute(&iStyle, TVS_TRACKSELECT, bNot) ;
    else if (attr == "TVS_SINGLEEXPAND")
      setStyleAttribute(&iStyle, TVS_SINGLEEXPAND, bNot) ;
    else if (attr == "TVS_INFOTIP")
      setStyleAttribute(&iStyle, TVS_INFOTIP, bNot) ;
    else if (attr == "TVS_FULLROWSELECT")
      setStyleAttribute(&iStyle, TVS_FULLROWSELECT, bNot) ;
    else if (attr == "TVS_NOSCROLL")
      setStyleAttribute(&iStyle, TVS_NOSCROLL, bNot) ;
    else if (attr == "TVS_NONEVENHEIGHT")
      setStyleAttribute(&iStyle, TVS_NONEVENHEIGHT, bNot) ;
    else
    {
      char msg[255] ;
      sprintf(msg, "Le style [%s] n'est pas encore d�fini dans le parseur.", attr.c_str()) ;
      erreur(msg, standardError, 0) ;
    }
  }

  value.iStyle = iStyle ;
}

void
Ccontrol::setStyleAttribute(int* iStyle, int iAttribute, bool bNot)
{
	if (bNot)
  	*iStyle &= ~iAttribute ;
	else
		*iStyle |= iAttribute ;
}

int
Ccontrol::getIStyle()
{
  return value.iStyle ;
}


bool
Ccontrol::parseValue()
{
  string  sValue = getValue() ;
  size_t  deb, fin ;

  // Parsing de la Caption
  deb = sValue.find("\"") ;
  if (deb == string::npos)
    return false ;
  fin = sValue.find("\"", deb + 1) ;
  if (fin == string::npos)
    return false ;
  value.caption = string(sValue, deb + 1, fin - deb - 1) ;

  // Parsing du RefId
  deb = sValue.find(",", fin + 1) ;
  if (deb == string::npos)
    return false ;
  fin = sValue.find(",", deb + 1) ;
  if (fin == string::npos)
    return false ;
  string sRefId = string(sValue, deb+1, fin - deb - 1) ;
  strip(sRefId) ;
  int iRefId ;

  // parsing des ID syst�me
  if      (sRefId == "IDOK")
    iRefId = IDOK ;
  else if (sRefId == "IDCANCEL")
    iRefId = IDCANCEL ;
  else if (sRefId == "IDB_OK")
    iRefId = IDB_OK ;
  else if (sRefId == "IDB_CANCEL")
    iRefId = IDB_CANCEL ;
  else if (sRefId == "IDRETOUR")
    iRefId = IDRETOUR ;
  else if (sRefId == "IDSUITE")
    iRefId = IDSUITE ;
  else if (sRefId == "IDHELP")
    iRefId = IDHELP ;
  else if (sRefId == "IDHELPWWW")
    iRefId = IDHELPWWW ;
  else if (sRefId == "IDHELPNEW")
    iRefId = IDHELPNEW ;
  else if (sRefId == "IDTREEPASTE")
    iRefId = IDTREEPASTE ;
  else if (sRefId == "IDCONCLUSION")
    iRefId = IDCONCLUSION ;
  else if (sRefId == "IDBBKCALCUL")
    iRefId = IDBBKCALCUL ;
  else
    iRefId = atoi(sRefId.c_str()) ;

  value.refId = iRefId ;

  // Parsing du type
  deb = sValue.find("\"", fin + 1) ;
  if (deb == string::npos)
    return false ;
  fin = sValue.find("\"", deb + 1) ;
  if (fin == string::npos)
    return false ;
  value.type = string(sValue, deb + 1, fin - deb - 1) ;

  // Parsing du style
  deb = sValue.find(",", fin + 1) ;
  if (deb == string::npos)
    return false ;
  fin = sValue.find(",", deb + 1) ;
  if (fin == string::npos)
    return false ;
  value.style = string(sValue, deb + 1, fin - deb - 1) ;
  setIStyle(value.style) ;

  // Parsing des coordonn�es
  deb = fin ;
  fin = strlen(sValue.c_str()) ;
  value.coords = string(sValue, deb + 1, fin - deb - 1) ;

  fin = sValue.find(",", deb + 1) ;
  if (fin == string::npos)
    return false ;
  string sX = string(sValue, deb + 1, fin - deb - 1) ;
  value.x = atoi(sX.c_str()) ;

  deb = fin ;
  fin = sValue.find(",", deb + 1) ;
  if (fin == string::npos)
    return false ;
  string sY = string(sValue, deb + 1, fin - deb - 1) ;
  value.y = atoi(sY.c_str()) ;

  deb = fin ;
  fin = sValue.find(",", deb + 1) ;
  if (fin == string::npos)
    return false ;
  string sW = string(sValue, deb + 1, fin - deb - 1) ;
  value.w = atoi(sW.c_str()) ;

  deb = fin ;
  fin = strlen(sValue.c_str()) ;
  string sH = string(sValue, deb + 1, fin - deb - 1) ;
  value.h = atoi(sH.c_str()) ;

  return true ;
}

// for the future - do not care about it for the moment
string
Ccontrol::getCaption()
{
  return texteCourant(value.caption) ;
}

// for the future - do not care about it for the moment
int
Ccontrol::getRefId()
{
  return value.refId ;
}


// for the future - do not care about it for the moment
string
Ccontrol::getType()
{
  return texteCourant(value.type) ;
}


// for the future - do not care about it for the moment
string
Ccontrol::getStyle()
{
  return texteCourant(value.style) ;
}


// for the future - do not care about it for the moment
string
Ccontrol::getCoords()
{
  return texteCourant(value.coords) ;
}


int
Ccontrol::getX()
{
  return value.x ;
}


int
Ccontrol::getY()
{
  return value.y ;
}


int
Ccontrol::getW()
{
  return value.w ;
}


int
Ccontrol::getH()
{
  return value.h ;
}


Crcdata::Crcdata(string attributes, string values, Cbalise *father)
  : Cbalise(attributes, values, father)
{
}


Crcdata::~Crcdata()
{
}


bool
Crcdata::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (vect_attr.empty())
  {
    // erreur (pas d'attribut)
    iParsingError = ERCDATA_ATTR_EMPTY ;
    return false ;
  }

  int nbNSTitre  = 0 ;
  int nbNSContro = 0 ;
	for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
  {
		if      ((*iattribut)->getLabel() == ATTRIBUT_RCDATA_NSTITRE)      // nstitre du rcdata
			nbNSTitre++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_RCDATA_NSCONTRO)
      nbNSContro++ ;
		else
    {
      // erreur (attribut incorrect)
      iParsingError = ERCDATA_ATTR ;
      return false ;
    }
  }

	if ((nbNSTitre > 1) || (nbNSContro != 1))
  {
    // erreur (nb attributs incorrect)
    iParsingError = ERCDATA_NBATTR ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;
	if (!vect_val.empty())
  {
    // erreur (cas normal : pas de valeur)
    iParsingError = ERCDATA_VAL_NOT_EMPTY;
    return false ;
  }
	return true ;
}


bool
Crcdata::verif()
{
  return true ;
}


bool
Crcdata::compresser()
{
  return true ;
}


bool
Crcdata::traiter()
{
  return true ;
}


string
Crcdata::getNSTitre()
{
  return getStringAttribute(ATTRIBUT_RCDATA_NSTITRE) ;
}


string
Crcdata::getNSContro()
{
  return getStringAttribute(ATTRIBUT_RCDATA_NSCONTRO) ;
}


string
Crcdata::getValue()
{
  char    pcReturn[1024] ;
  sprintf(pcReturn, "\"NSTITRE\"\n\"%s\"\n\"NSCONTRO\"\n\"%s\"\n\"FINRCDAT\"\n", getNSTitre().c_str(), getNSContro().c_str()) ;
  string  sReturn = pcReturn ;

  delete [] pcReturn ;
  return sReturn ;
}


// -----------------------------------------------------------------------------
//
// Classe Ctabcontrol
//
// -----------------------------------------------------------------------------

Ctabcontrol::Ctabcontrol(string attributs, string values, Cbalise *father)
  : Cbalise(attributs, values, father)
{
}


Ctabcontrol::~Ctabcontrol()
{
}


bool
Ctabcontrol::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

	if (vect_val.empty())
  {
    // erreur (pas de valeur)
    iParsingError = ETABCONTROL_VAL_EMPTY ;
    return false ;
  }

	for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
  {
    if ((*ival)->sLabel == LABEL_ONGLET) // dialogue
    {
      (*ival)->pObject = new Ctab((*ival)->sAttribute, (*ival)->sValue, this) ;
      if (!(*ival)->pObject->parser())
      {
        // erreur parsing dialogue
        iParsingError = (*ival)->pObject->iParsingError ;
        return false ;
      }
    }
    else
    {
      // erreur (valeur incorrecte)
      iParsingError = ETABCONTROL_VAL ;
      return false ;
    }
  }
	return true ;
}boolCtabcontrol::verif(){
  return true ;
}


bool
Ctabcontrol::compresser()
{
  return true ;
}


bool
Ctabcontrol::traiter()
{
  return true ;
}


Ctab *
Ctabcontrol::getFirstTab()
{
  Ctab      *pTab = NULL ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if ((*ival)->sLabel == LABEL_ONGLET)
      {
        pTab = dynamic_cast<Ctab *>((*ival)->pObject) ;
        break ;
      }
    }
  }
  return pTab ;
}


Ctab *
Ctabcontrol::getNextTab(Ctab *pLastTab)
{
  Ctab      *pTab       = NULL ;
  Ctab      *pBuf ;
  bool      bReturnNext = false ;
  if (!pLastTab)
  	bReturnNext = true ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if ((*ival)->sLabel == LABEL_ONGLET)
      {
        pBuf = dynamic_cast<Ctab *>((*ival)->pObject) ;
        if (bReturnNext && pBuf)
        {
          pTab = pBuf ;
          break ;
        }
        if (pBuf == pLastTab)
          bReturnNext = true ;
      }
    }
  }
  return pTab ;
}


int
Ctabcontrol::getNbTabs()
{
  Ctab      *pTab   = NULL ;
  int       nbTabs  = 0 ;

  if (!vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if ((*ival)->sLabel == LABEL_ONGLET)
      {
        pTab = dynamic_cast<Ctab *>((*ival)->pObject) ;
        if (pTab != NULL)
          nbTabs++ ;
      }
    }
  }
  return nbTabs ;
}


// -----------------------------------------------------------------------------
//
// Classe Ctab
//
// -----------------------------------------------------------------------------

Ctab::Ctab(string attributes, string values, Cbalise *father)
  : Cbalise(attributes, values, father)
{
}


Ctab::~Ctab()
{
}


bool
Ctab::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (vect_attr.empty())
  {
    // erreur (pas d'attribut)
    iParsingError = ETAB_ATTR_EMPTY ;
    return false ;
  }

  int       nbTitle = 0 ;
  int       nbOrder = 0 ;
	for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
  {
		if      ((*iattribut)->getLabel() == ATTRIBUT_ONGLET_TITRE)      // titre de l'onglet
			nbTitle++ ;
    else if ((*iattribut)->getLabel() == ATTRIBUT_ONGLET_NUM)       // index
      nbOrder++ ;
		else
    {
      // erreur (attribut incorrect)
      iParsingError = ETAB_ATTR ;
      return false ;
    }
  }

	if ((nbTitle != 1) || (nbOrder != 1))
  {
    // erreur (nb attributs incorrect)
    iParsingError = ETAB_NBATTR ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;
	if (!vect_val.empty())
  {
    // erreur (cas normal : pas de valeur)
    iParsingError = ETAB_VAL_NOT_EMPTY;
    return false ;
  }
	return true ;
}


bool
Ctab::verif()
{
  return true ;
}


bool
Ctab::compresser()
{
  return true ;
}


bool
Ctab::traiter()
{
  return true ;
}


string
Ctab::getTitle()
{
  return getStringAttribute(ATTRIBUT_ONGLET_TITRE) ;
}


string
Ctab::getOrder()
{
  return getStringAttribute(ATTRIBUT_ONGLET_NUM) ;
}


// -----------------------------------------------------------------------------
//
// Classe Cpresentation
//
// -----------------------------------------------------------------------------

Cpresentation::Cpresentation(string attributes, string values, Cbalise *father)
  : Cbalise(attributes, values, father)
{
}


Cpresentation::~Cpresentation()
{
}


bool
Cpresentation::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  if (vect_attr.empty())
  {
    // erreur (pas d'attribut)
    iParsingError = EPRESENT_ATTR_EMPTY ;
    return false ;
  }

  int       nbVal   = 0 ;
	for (AttrIter iattribut = vect_attr.begin() ; iattribut != vect_attr.end() ; iattribut++)
  {
		if      ((*iattribut)->getLabel() == ATTRIBUT_PRESENT_VALUE)      // valeur (string html)
			nbVal++ ;
		else
    {
      // erreur (attribut incorrect)
      iParsingError = EPRESENT_ATTR ;
      return false ;
    }
  }

	if (nbVal != 1)
  {
    // erreur (nb attributs incorrect)
    iParsingError = EPRESENT_NBATTR ;
    return false ;
  }

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;
	if (!vect_val.empty())
  {
    // erreur (cas normal : pas de valeur)
    iParsingError = EPRESENT_VAL_NOT_EMPTY ;
    return false ;
  }
	return true ;
}


bool
Cpresentation::verif()
{
  return true ;
}


bool
Cpresentation::compresser()
{
  return true ;
}


bool
Cpresentation::traiter()
{
  return true ;
}


string
Cpresentation::getValue()
{
  return getStringAttribute(ATTRIBUT_PRESENT_VALUE) ;
}


// -----------------------------------------------------------------------------
// classe Cglobalvars
// -----------------------------------------------------------------------------
// Cette classe repr�sente les variables globales qui peuvent �tre pr�sentes au
// sein d'un r�f�rentiel.
// --
// This class contains global vars that can be present in a referential.
// -----------------------------------------------------------------------------

Cglobalvars::Cglobalvars(string attributs, string values, Cbalise *father, NSContexte *pCtx)
            :Cbalise(attributs, values, father)
{
  pContexte  = pCtx ;
  _pGVars    = new GlobalVarArray() ;
  _processed = false ;
}

Cglobalvars::~Cglobalvars()
{
  delete _pGVars ;
}

bool
Cglobalvars::parser()
{
  // ---------------------------------------------------------------------------
  // attributs
  if (!parser_attributs())
    return false ;

  // ---------------------------------------------------------------------------
	// valeurs
	if (!parser_valeurs())
		return false ;

  if (vect_val.empty())
  {
    // erreur (pas de valeur)
    iParsingError = EGVARS_VAL_EMPTY ;
    return false ;
  }

  if (false == vect_val.empty())
  {
    for (ValIter ival = vect_val.begin() ; ival != vect_val.end() ; ival++)
    {
      if      ((*ival)->sLabel == LABEL_CONTRAINTE) // contrainte
      {
        (*ival)->pObject = new Ccontrainte((*ival)->sAttribute, (*ival)->sValue, this) ;
        if (!(*ival)->pObject->parser())
        {
          // erreur parsing contrainte
          iParsingError = (*ival)->pObject->iParsingError ;
          return false ;
        }
        _pGVars->push_back(new GlobalVar((*ival)->pObject, GlobalVar::constraint, this)) ;
      }
      else if ((*ival)->sLabel == LABEL_VARIABLE)
      {
        (*ival)->pObject = new Cvariable((*ival)->sAttribute, (*ival)->sValue, this) ;
        if (!(*ival)->pObject->parser())
        {
          // erreur parsing variable
          iParsingError = (*ival)->pObject->iParsingError ;
          return false ;
        }
        _pGVars->push_back(new GlobalVar((*ival)->pObject, GlobalVar::variable, this)) ;
      }
      else if ((*ival)->sLabel == LABEL_VALIDATEUR)
      {
        (*ival)->pObject = new Cvalidateur((*ival)->sAttribute, (*ival)->sValue, this) ;
        if (!(*ival)->pObject->parser())
        {
          // erreur parsing validateur
          iParsingError = (*ival)->pObject->iParsingError ;
          return false ;
        }
        _pGVars->push_back(new GlobalVar((*ival)->pObject, GlobalVar::validator, this)) ;
      }
      else
      {
        // erreur (valeur incorrecte)
        iParsingError = EGVARS_VAL ;
        return false ;
      }
    }
  }
	return true ;
}

bool
Cglobalvars::verif()
{
  return true ;
}

bool
Cglobalvars::compresser()
{
  return true ;
}

bool
Cglobalvars::traiter()
{
  return true ;
}

Valeur_array *
Cglobalvars::getValArray()
{
  return (&vect_val) ;
}

bool
Cglobalvars::isProcessed()
{
  return (_processed) ;
}

bool
Cglobalvars::process(bool bUserIsWaiting, HWND interfaceHandle)
{
  if (_pGVars->empty() || isProcessed())
    return false ;

  // First step, process the real variables
  //
  for (GlobalVarCIter gvIter = _pGVars->begin() ; _pGVars->end() != gvIter ; gvIter++)
    if ((GlobalVar::variable == (*gvIter)->getType()) &&
        (GlobalVar::plainVar == (*gvIter)->getSubtype()))
      (*gvIter)->process(pContexte, bUserIsWaiting, interfaceHandle) ;

  // Second step, process the variables of variables (compound variables)
  //
  for (GlobalVarCIter gvIter = _pGVars->begin() ; _pGVars->end() != gvIter ; gvIter++)
    if ((GlobalVar::variable == (*gvIter)->getType()) &&
        (GlobalVar::compoundVar == (*gvIter)->getSubtype()))
      (*gvIter)->process(pContexte, bUserIsWaiting, interfaceHandle) ;

  // Third step, process constraints and validators
  //
  for (GlobalVarCIter gvIter = _pGVars->begin() ; _pGVars->end() != gvIter ; gvIter++)
    if (GlobalVar::variable != (*gvIter)->getType()) 
      (*gvIter)->process(pContexte, bUserIsWaiting, interfaceHandle) ;

  _processed = true ;

  return true ;
}

void
Cglobalvars::resetProcessState()
{
  _processed = false ;

  if (_pGVars->empty())
    return ;

  for (GlobalVarCIter gvIter = _pGVars->begin() ; _pGVars->end() != gvIter ; gvIter++)
    (*gvIter)->resetProcessState() ;
}

bool
Cglobalvars::isVarP(string sLabel, GlobalVar::gvType typ)
{
  if (_pGVars->empty() || (sLabel == ""))
    return false ;

  for (GlobalVarCIter gvIter = _pGVars->begin() ; _pGVars->end() != gvIter ; gvIter++)
    if (((*gvIter)->getName() == sLabel) && ((*gvIter)->getType() == typ))
      return true ;

  return false ;
}

NSPatPathoArray *
Cglobalvars::getPPT(string sLabel, GlobalVar::gvType typ)
{
  if (!isVarP(sLabel, typ))
    return NULL ;

  for (GlobalVarCIter gvIter = _pGVars->begin() ; _pGVars->end() != gvIter ; gvIter++)
    if (((*gvIter)->getName() == sLabel) && ((*gvIter)->getType() == typ))
      return ((*gvIter)->getPPT()) ;

  return NULL ;
}

GlobalVar::gvState
Cglobalvars::getState(string sLabel, GlobalVar::gvType typ)
{
  if (!isVarP(sLabel, typ))
    return (GlobalVar::stateNotDef) ;

  for (GlobalVarCIter gvIter = _pGVars->begin() ; _pGVars->end() != gvIter ; gvIter++)
    if (((*gvIter)->getName() == sLabel) && ((*gvIter)->getType() == typ))
      return ((*gvIter)->getState()) ;

  return (GlobalVar::stateNotDef) ;
}

Cbalise *
Cglobalvars::getBalise(string sLabel, GlobalVar::gvType typ)
{
  if (!isVarP(sLabel, typ))
    return NULL ;

  for (GlobalVarCIter gvIter = _pGVars->begin() ; _pGVars->end() != gvIter ; gvIter++)
    if (((*gvIter)->getName() == sLabel) && ((*gvIter)->getType() == typ))
      return ((*gvIter)->getBalise()) ;

  return NULL ;
}

string
Cglobalvars::getPublishingString()
{
	if (_pGVars->empty())
		return string("") ;

	string sToPublish = string("") ;

	for (GlobalVarCIter gvIter = _pGVars->begin() ; _pGVars->end() != gvIter ; gvIter++)
  {
    if (((*gvIter)->getState() == GlobalVar::found) &&
    	  ((*gvIter)->getLabel() != "") && ((*gvIter)->getToPublish()))
		{
    	sToPublish += string("<li>") + (*gvIter)->getLabel() + string("</li>\r\n") ;
      pContexte->getSuperviseur()->getDPIO()->addToLogPage((*gvIter)->getLabel(), string("<li>"), string("</li>\r\n")) ;
		}
  }

	return sToPublish ;
}

bool
Cglobalvars::existPublishingString()
{
	if (_pGVars->empty())
		return false ;

	for (GlobalVarCIter gvIter = _pGVars->begin() ; _pGVars->end() != gvIter ; gvIter++)
    if (((*gvIter)->getState() == GlobalVar::found) &&
    	  ((*gvIter)->getLabel() != "") && ((*gvIter)->getToPublish()))
    	return true ;

	return false ;
}

// -----------------------------------------------------------------------------
// classe GlobalVar
// -----------------------------------------------------------------------------
// Cette classe repr�sente une variable globale utilisable au sein d'une contrainte.
// --
// This class contains a global var that can be used inside validity constraints
// -----------------------------------------------------------------------------

GlobalVar::GlobalVar(Cbalise *bal, gvType typ, Cglobalvars *pGlobalVars)
{
  _state   = stateNotDef ;
  _balise  = bal ;
  _type    = typ ;
  _subtype = subtypeNotDef ;

  _globalVars = pGlobalVars ;

  switch (_type)
  {
    case variable   :
    {
      Cvariable * pCvariable = dynamic_cast<Cvariable *>(_balise) ;
      if (pCvariable)
      {
        _name  = pCvariable->getStringAttribute(ATTRIBUT_VAR_NOM) ;
        _label = pCvariable->getStringAttribute(ATTRIBUT_VAR_LABEL) ;
        _bPublish       = false ;
        _classification = string("") ;

        string sExpression = pCvariable->getExpression() ;
        if (string("") == sExpression)
          _subtype = plainVar ;
        else
          _subtype = compoundVar ;

        break ;
      }
    }
    case constraint :
    {
      Ccontrainte * pCcontrainte = dynamic_cast<Ccontrainte *>(_balise) ;
      if (pCcontrainte)
      {
        _name  = pCcontrainte->getStringAttribute(ATTRIBUT_CONTR_NOM) ;
        _label = pCcontrainte->getStringAttribute(ATTRIBUT_CONTR_LABEL) ;
        _bPublish       = pCcontrainte->mustPublish() ;
        _classification = pCcontrainte->getStringAttribute(ATTRIBUT_CONTR_CLASSIFY) ;
        break ;
      }
    }
    case validator  :
    default         :
      _name  = "" ;
      _label = "" ;
      _bPublish       = false ;
      _classification = "" ;
      break ;
  }

  _alias   = "" ;
  _ppt     = NULL ;
}

GlobalVar::~GlobalVar()
{
  if (_ppt != NULL)
    delete _ppt ;
}

bool
GlobalVar::process(NSContexte *pCtx, bool bUserIsWaiting, HWND interfaceHandle)
{
  if (_state == notFound)
    return false ;
  if (_state == found)
    return true ;

  // fabFIXME
  _alias = "" ;
  Cvariable* pCvar = dynamic_cast<Cvariable *>(_balise) ;
  if (pCvar != NULL)
  {
    if ((plainVar == getSubtype()) && (pCvar->getStringAttribute(ATTRIBUT_VAR_NOM) == _name) && (false == pCvar->vect_val.empty()))
    {
      // Parcours des alias avec question au blackboard
      for (ValIter ival = pCvar->vect_val.begin() ; pCvar->vect_val.end() != ival ; ival++)
      {
        if (LABEL_ALIAS == (*ival)->sLabel) // items
        {
          Calias *pAlias = dynamic_cast<Calias *>((*ival)->pObject) ;
          if (NULL == pAlias)
            break ;

          string sVarAlias = pAlias->getValue() ;
          sVarAlias = getRegularPath(sVarAlias, cheminSeparationMARK, intranodeSeparationMARK) ;

          // pour l'instant le blackboard ne r�pond qu'� une question oui/non
          // L'alias doit etre un chemin de codes sens (s�parateur : '/')
          NSPatPathoArray* pPatPathoLocale = NULL ;
          // on pose la question au blackboard
  #ifdef __OB1__
          // int res = pCtx->getSuperviseur()->getBBinterface()->getAnswer2Question(sVarAlias, "", &pPatPathoLocale, false) ;

          // It is useful to compute, elswhere if the KS creates some information
          // the referential will ignore it
          string sAnswerDate ;
          int res = pCtx->getSuperviseur()->getBBinterface()->getAnswer2Question(sVarAlias, "", &pPatPathoLocale, sAnswerDate, true, bUserIsWaiting, interfaceHandle) ;
  #else
          int res = pCtx->getSuperviseur()->getBlackboard()->getAnswer2Question(sVarAlias, "", &pPatPathoLocale, false) ;
  #endif
          if (res == 1)
          {
            // on teste d'abord l'existence de la variable
            // (la patpatho r�sultat est non vide ==> la variable existe)
            if ((pPatPathoLocale) && (!((pPatPathoLocale)->empty())))
            {
              _alias  = sVarAlias ;
              _ppt    = pPatPathoLocale ;
              _type   = variable ;
              _state  = found ;
              return true ;
            }
          }
          if (pPatPathoLocale)
            delete pPatPathoLocale ;
        }
      } // fin du for sur les alias
      _type   = variable ;
      _state  = notFound ;
    } // fin du if (pCvar->getStringAttribute(ATTRIBUT_VAR_NOM) == sName)
    else if ((compoundVar == getSubtype()) && (string("") != pCvar->getExpression()))
    {
      string sReservedOperators = string("()+-*/^�") ;

      string sExpression = pCvar->getExpression() ;

      // First step: get other vars names
      //
      VectString aProcessedVars ;

      size_t iBlockStart = 0 ;
      size_t iCurseur = 0 ;
      while (iCurseur < strlen(sExpression.c_str()))
      {
        // This char is a reserved char
        //
        if (sReservedOperators.find(sExpression[iCurseur]) != string::npos)
        {
          string sBlockContent = string(sExpression, iBlockStart, iCurseur - iBlockStart) ;
          strip(sBlockContent, stripBoth) ;

          // If can be a var or a number
          //
          if ((string("") != sBlockContent) && (false == aProcessedVars.contains(sBlockContent)))
          {
            if (_globalVars->isVarP(sBlockContent, variable))
              aProcessedVars.push_back(new string(sBlockContent)) ;
            else
            {
              double dValue = StringToDouble(sBlockContent) ;
              if (0 == dValue)
              {
                strip(sBlockContent, stripBoth, '0') ;
                if ((string("") != sBlockContent) && (string(".") != sBlockContent))
                  return false ;
              }
            }
          }

          iCurseur++ ;

          // Looking for the starting char of next block (not a separator)
          //
          while ((iCurseur < strlen(sExpression.c_str())) &&
             (sReservedOperators.find(sExpression[iCurseur]) != string::npos))
            iCurseur++ ;

          iBlockStart = iCurseur ;
        }
        else
          iCurseur++ ;
      }
      string sBlockContent = string(sExpression, iBlockStart, iCurseur - iBlockStart) ;
      strip(sBlockContent, stripBoth) ;
      // If can be a var or a number
      //
      if ((string("") != sBlockContent) && (false == aProcessedVars.contains(sBlockContent)))
      {
        if (_globalVars->isVarP(sBlockContent, variable))
          aProcessedVars.push_back(new string(sBlockContent)) ;
        else
        {
          double dValue = StringToDouble(sBlockContent) ;
          if (0 == dValue)
          {
            strip(sBlockContent, stripBoth, '0') ;
            if ((string("") != sBlockContent) && (string(".") != sBlockContent))
              return false ;
          }
        }
      }

      // No vars: compute the expression
      //
      if (aProcessedVars.empty())
      {
        double dResult = calculate(NULL, sExpression) ;
        string sResult = DoubleToString(&dResult, 8, 3) ;
        string sUnit   = pCvar->getUnit() ;
        if (string("") == sUnit)
          sUnit = string("200001") ;

        _ppt = new NSPatPathoArray(_globalVars->pContexte) ;
        Message msg ;
        msg.SetUnit(sUnit.c_str()) ;
        msg.SetComplement(sResult.c_str()) ;
        _ppt->ajoutePatho("�N08;3", &msg, 0) ;

        _state  = found ;
        return true ;
      }

      // Get vars values
      //
      map<string, double> aValues ;

      for (IterString it = aProcessedVars.begin() ; aProcessedVars.end() != it ; it++)
      {
        // Just check if this path exists, or "left value operator right value"?
        //
        string sVarName = **it ;

        // A needed var has not been found; nothing can get done
        //
        gvState varState = _globalVars->getState(sVarName, variable) ;
        if (found != varState)
          return false ;

        NSPatPathoArray *pPPT = _globalVars->getPPT(sVarName, variable) ;
        if ((NULL == pPPT) || (pPPT->empty()))
          return false ;

        string sFormat  = string("") ;
        string sValeur1 = string("") ;
        string sUnite1  = string("") ;
        PatPathoIter iter = pPPT->begin() ;
        while (pPPT->end() != iter)
        {
          if (((*iter)->pDonnees->lexique)[0] == '�')
          {
            sFormat  = (*iter)->getLexiqueSens(_globalVars->pContexte) ;
            sValeur1 = (*iter)->getComplement() ;
            sUnite1  = (*iter)->getUnitSens(_globalVars->pContexte) ;
            break ;
          }
          iter++ ;
        }
        if (string("") == sValeur1)
          return false ;
        double dLatestVarValue = StringToDouble(sValeur1) ;

        aValues[sVarName] = dLatestVarValue ;
      }

      double dResult = calculate(&aValues, sExpression) ;
      string sResult = DoubleToString(&dResult, 8, 3) ;
      string sUnit   = pCvar->getUnit() ;
      if (string("") == sUnit)
        sUnit = string("200001") ;

      _ppt = new NSPatPathoArray(_globalVars->pContexte) ;
      Message msg ;
      msg.SetUnit(sUnit.c_str()) ;
      msg.SetComplement(sResult.c_str()) ;
      _ppt->ajoutePatho("�N08;3", &msg, 0) ;

      _state  = found ;
      return true ;
    }
  }

  Ccontrainte* pCconstraint = dynamic_cast<Ccontrainte *>(_balise) ;
  if ((pCconstraint != NULL) && (pCconstraint->getStringAttribute(ATTRIBUT_CONTR_NOM) == _name))
  {
    NSValidateur	valid(pCconstraint, pCtx) ;
    if (valid.getValeurContrainte(_name))    {      _type   = constraint ;      _state  = found ;      return true ;    }    _type   = constraint ;    _state  = notFound ;  }

  return false ;
}

void
GlobalVar::resetProcessState()
{
  _state = stateNotDef ;
}

NSPatPathoArray *
GlobalVar::getPPT()
{
  if (_type == variable)
    return _ppt ;
  return NULL ;
}

string
GlobalVar::getName()
{
  return _name ;
}

string
GlobalVar::getLabel()
{
  return _label ;
}

bool
GlobalVar::getToPublish()
{
	return _bPublish ;
}

string
GlobalVar::getClassification()
{
  return _classification ;
}

GlobalVar::gvState
GlobalVar::getState()
{
  return _state ;
}


GlobalVar::gvType
GlobalVar::getType()
{
  return _type ;
}

GlobalVar::gvSubType
GlobalVar::getSubtype()
{
  return _subtype ;
}

Cbalise *
GlobalVar::getBalise()
{
  return _balise ;
}

