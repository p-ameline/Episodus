//Kaddachi Hafedh#include <owl\applicat.h>
#include <owl\olemdifr.h>
#include <owl\dialog.h>
#include <stdio.h>
#include <string.h>
#include <bde.hpp>
#include <owl/button.h>

#include "partage\nsdivfct.h"
#include "nsbb\ns_multi.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\ns_multi.rh"

       //??????????????????????????????????????????
       // REVOIR POSITION FENETRES ET CANCEL
       //??????????????????????????????????????????

// -------------------------------------------------------------------------
// -------------------- METHODES DE NSVectNSDialog ------------------------
// -------------------------------------------------------------------------
NSVectNSDialog::NSVectNSDialog()
		           :NSVecteurNSDialog()
{}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSVectNSDialog::NSVectNSDialog(NSVectNSDialog& rv)
               :NSVecteurNSDialog()
{
try
{
	if (!(rv.empty()))
		for (NSDialogIterVect i = rv.begin(); i != rv.end(); i++)
			push_back(new NSDialog((*i)->pContexte, AParent, ressource)) ;
}
catch (...)
{
	erreur("Exception NSVectNSDialog copy ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
void
NSVectNSDialog::vider()
{
    if (empty())
        return ;

    for (NSDialogIterVect i = begin(); i != end(); )
    {
        // delete *i;
        erase(i);
    }
}

NSVectNSDialog::~NSVectNSDialog(){
	vider();
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSVectNSDialog&
NSVectNSDialog::operator=(NSVectNSDialog src)
{
try
{
  if (this == &src)
    return *this ;

  //
  // Effacement des �l�ments d�j� contenus dans le vecteur destination
  //
	vider() ;
	//
  // Copie et insertion des �l�ments de la source
  //
  if (!(src.empty()))
    for (NSDialogIterVect i = src.begin(); i != src.end(); i++)
      push_back(new NSDialog((*i)->pContexte, AParent, ressource)) ;

	return *this ;
}
catch (...)
{
  erreur("Exception NSVectNSDialog = operator.", standardError, 0) ;
	return *this ;
}
}

// -----------------------------------------------------------------//
//  M�thodes de NsMultiDialog
//
// -----------------------------------------------------------------
#ifdef _INCLUS
DEFINE_RESPONSE_TABLE1(NsMultiDialog, NSDialogWrapper)
#else
DEFINE_RESPONSE_TABLE1(NsMultiDialog, TDialog)
#endif
	EV_COMMAND(IDOK, CmOk),
	EV_COMMAND(IDCANCEL,	CmCancel),
	EV_COMMAND(IDC_MULT_AJOUT, EvAjouter),
	EV_COMMAND(IDC_MULT_DETRUIT, EvDetruire),
    EV_WM_DESTROY,
END_RESPONSE_TABLE ;

NsMultiDialog::NsMultiDialog(TWindow* parent , TResId resId, BBFilsItem* pBBitemFils, TModule* module)              :TDialog(parent, resId, module)
{
try
{
    pMultiDialog            = new NSVectNSDialog();
    //
    // Vecteurs des bo�tes pr�sentes � l'ouverture
    //
    pAjoutMultiDialog       = new NSVectNSDialog();
    //
    // Vecteurs des bo�tes pr�sentes � l'ouverture qui ont �t� supprim�es
    //
    pDeleteMultiDialog      = new NSVectNSDialog();

    ressource               = resId;
    AParent 		        = parent;
    pBBItemFilsMultiDialog  = pBBitemFils;
    pActive                 = 0;
    compteur                = 1;

    new TButton(parent, IDC_MULT_AJOUT);
    new TButton(parent, IDC_MULT_DETRUIT);
}
catch (...)
{
    erreur("Exception NsMultiDialog ctor.", standardError, 0) ;
}
}

NsMultiDialog::~NsMultiDialog()
{
    delete pMultiDialog;

    //
    // Les pointeurs pr�sents dans pAjoutMultiDialog �taient �galement
    // pr�sents dans pMultiDialog et ont donc d�j� fait l'objet d'un delete.
    // On les supprime donc de pAjoutMultiDialog avant d'appeler le destructeur
    // pour �viter un double delete
    //
    if (!(pAjoutMultiDialog->empty()))
        for (NSDialogIterVect iter = pAjoutMultiDialog->begin();
   			                            iter != pAjoutMultiDialog->end(); )
   	        pAjoutMultiDialog->erase(iter);

    delete pAjoutMultiDialog;

    // Le commentaire ci-dessus s'applique � pDeleteMultiDialog puisque
    // - CmOk ent�rine la destruction en tuant la bo�te
    // - CmCancel annule la destruction en repla�ant la bo�te dans pMultiDialog
    if (!(pDeleteMultiDialog->empty()))
        for (NSDialogIterVect iter = pDeleteMultiDialog->begin();
   						            iter != pDeleteMultiDialog->end(); )
   	        pDeleteMultiDialog->erase(iter);

    delete pDeleteMultiDialog;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NsMultiDialog::NsMultiDialog(NsMultiDialog& src)
              :TDialog(src.AParent, src.ressource)
{
try
{
    pMultiDialog		    = new NSVectNSDialog(*(src.pMultiDialog));
    ressource			    = src.ressource;
    AParent				    = src.AParent;
    pBBItemFilsMultiDialog  = src.pBBItemFilsMultiDialog;
    pActive				    = src.pActive;
    compteur			    = src.compteur;
}
catch (...)
{
	erreur("Exception NsMultiDialog copy ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Op�rateur d'affectation
//---------------------------------------------------------------------------
inline NsMultiDialog&
NsMultiDialog::operator= (NsMultiDialog src)
{
	pMultiDialog           = src.pMultiDialog ;
	ressource              = src.ressource ;
	AParent                = src.AParent ;
	pBBItemFilsMultiDialog = src.pBBItemFilsMultiDialog ;
	pActive                = src.pActive ;
	compteur               = src.compteur ;

	return *this ;
}

//-------------------------------------------------------------------------//ajouter vune nouvelle bo�te dans pMultiDialog et pAjoutMultiDialog
//-------------------------------------------------------------------------
void
NsMultiDialog::referenceDialogue(NSDialog* pNSDialog)
{
	pMultiDialog->push_back(pNSDialog);
}

//-----------------------------------------------------------------------
// 	ajouter une nouvelle bo�te de dialogue correspondant au BBItem en cours
// 	mettre � jour les titres des bo�tes existantes
//    mettre � jour les vecteurs des bo�tes : pMultiDialog
//-----------------------------------------------------------------------
void
NsMultiDialog::EvAjouter()
{
    compteur++ ;

    char taille[25], titre[100];
    string Nom, temp;
    // size_t pos;
    pBBItemFilsMultiDialog->creerNouveauFils();
    //convertir pMultiDialog->size() en chaine : taille
    itoa(pMultiDialog->size(),taille, 10);

    if (!(pMultiDialog->empty()))
    {
        for (NSDialogIterVect iter = pMultiDialog->begin(); (iter != pMultiDialog->end()); iter++)
        {
   	        // r�cup�rer le titre de la bo�te
   	        (*iter)->GetWindowText(titre, 100) ;
            temp = string(titre);
            if (strchr(titre, '/') == 0)
	            Nom = string(titre) + string("/") + string(taille);
            else
            {
                string sChaine;
                if (pMultiDialog->size() < 10)
                {
                    sChaine = string(temp, 0, strlen(temp.c_str()) - 1);
         	        Nom = sChaine + string(taille);
                }
                else
                {
                    sChaine = string(temp, 0, strlen(temp.c_str()) - strlen(taille));
                    if (sChaine.find(string("/")) == NPOS)
            	        Nom = sChaine + string("/") + string(taille);
                    else
                        Nom = sChaine + string(taille);
                }
            }
   	        //mettre � jour le nouveau titre
            (*iter)->SetCaption(Nom.c_str());
        }
    }
}

//-----------------------------------------------------------------------// D�truire une  bo�te de dialogue correspondant au BBItem en cours
// et enlever le pPPTenCours correspondant du NSVECT du BBitemFils
// mettre � jour les titres des bo�tes existantes
// mettre � jour les vecteurs des bo�tes : pMultiDialog
//
//-----------------------------------------------------------------------
void
NsMultiDialog::EvDetruire()
{
	if (pMultiDialog->empty()) //pas de bo�tes � deleter
		return ;

	if (!pActive)
		pActive = pMultiDialog->back() ;

	char valeurentiere[100], titre[100] ;
	string Nom ;

  FatheredPatPathoIterVect iterPatPatho = 0 ;
	// Vecteurs des patpatho
	NSVectFatheredPatPathoArray* pVect = pBBItemFilsMultiDialog->getPatPatho() ;
	if ((NULL != pVect) && (false == pVect->empty()))
	{
		// it�rateur
    iterPatPatho = pVect->begin() ;

    //trouver la patpatho correspondante
    for ( ; (pVect->end() != iterPatPatho) &&
          ((*iterPatPatho)->getPatPatho() != pActive->pBBItem->pPPTEnCours) ;
                                                            iterPatPatho++) ;
	}

  BBiterFils itBBitem = 0 ;
	// trouver le BBitem de la boite � d�truire
	if (false == pBBItemFilsMultiDialog->VectorFils.empty())
	{
  	itBBitem = pBBItemFilsMultiDialog->VectorFils.begin() ;

    for ( ; (itBBitem != pBBItemFilsMultiDialog->VectorFils.end())
                        && ((*itBBitem) != pActive->pBBItem); itBBitem++) ;
	}

	//
	// Trouver la bo�te � d�truire
	//
	NSDialogIterVect iterBoite = pMultiDialog->begin() ;
	for ( ; (iterBoite != pMultiDialog->end()) && (pActive != (*iterBoite)); iterBoite++) ;
  //
  // Destruction de la boite de dialogue
  //
  if (iterBoite != pMultiDialog->end())
  	(*iterBoite)->Destroy() ;
  //
  // ATTENTION : pDeleteMultiDialog est r�serv� aux bo�tes anciennes (qui
  //					pourront �tre ressucit�es par CANCEL) les bo�tes nouvelles
  //					(non pr�sentes dans pAjoutMultiDialog) sont ignor�es
  //
  // On cherche si la bo�te est pr�sente dans pAjoutMultiDialog
  //
  if (!(pAjoutMultiDialog->empty()))
  {
  	NSDialogIterVect iterAjout = pAjoutMultiDialog->begin() ;
    for (; (iterAjout != pAjoutMultiDialog->end()) && (pActive != (*iterAjout));
   		                                                iterAjout++) ;
    if (iterAjout != pAjoutMultiDialog->end())
    	pDeleteMultiDialog->push_back(*iterBoite) ;
    // New box, kill bbitem and patpatho
    else
    {
    	if ((false == pBBItemFilsMultiDialog->VectorFils.empty()) &&
          (pBBItemFilsMultiDialog->VectorFils.end() != itBBitem))
      {
      	delete (*itBBitem) ;
      	pBBItemFilsMultiDialog->VectorFils.erase(itBBitem);
      }
      if ((pVect) && (false == pVect->empty()) && (pVect->end() != iterPatPatho))
      {
      	delete (*iterPatPatho) ;
     		pVect->erase(iterPatPatho) ;
      }
    }
	}
	//
	// On supprime la bo�te de la liste des bo�tes actives
	//
	pMultiDialog->erase(iterBoite) ;
	pActive = 0 ;

 /* 	//tuer le BBitem de la boite d�truite : mettre � jour VectorFils
  	if(itBBitem != pBBItemFilsMultiDialog->VectorFils.end())
  	{
  		delete (*itBBitem);
      pBBItemFilsMultiDialog->VectorFils.erase(itBBitem);
  	}

  	//tuer la boite de dialogue
  	if(iterBoite != pMultiDialog->end())
  	{
  		pActive->Desactive();
  		(*iterBoite)->Destroy();
  		pMultiDialog->erase(iterBoite);
  		pActive = 0;
  		compteur--;
  	}

   //enlever la patpatho correspondante
   if(iterPatPtho != pVect->end() )
   {
     delete (*iterPatPtho);
     pVect->erase(iterPatPtho);
   }
*/

	// mise � jour des titres
	int i = 1 ;
	char taille[25] ;
	size_t pos ;
	itoa(pMultiDialog->size(),taille, 10) ;
	NSDialogIterVect iter = pMultiDialog->begin() ;
	for (iter = pMultiDialog->begin(), i = 1; (iter != pMultiDialog->end()) ; iter++, i++)
	{
		string titreMiseAjour ;

    //r�cup�rer le titre de la bo�te
    (*iter)->GetWindowText(titre, 100) ;
    titreMiseAjour = string(titre) ;
    pos = titreMiseAjour.find(string(": ")) ;
    itoa(i,valeurentiere, 10) ;

    if (pos != NPOS)
    	Nom = string(titreMiseAjour, 0, pos + 2) + string(valeurentiere)
            		+ string("/") + string(taille) ;
    else
    	Nom = titreMiseAjour ;

    // Mettre � jour le nouveau titre
    (*iter)->SetCaption(Nom.c_str()) ;
	}
}

//-----------------------------------------------------------------------//d�truire une bo�te de dialogue
//-----------------------------------------------------------------------
void
NsMultiDialog::DetruireNSDialog(NSDialog* pNSDialog, NSVectNSDialog* pMulti)
{
	if ((!pNSDialog) || (!pMulti))
		return ;

	// Vecteurs des patptho
	NSVectFatheredPatPathoArray* pVect = pBBItemFilsMultiDialog->getPatPatho() ;
	if ((NULL == pVect) || (pVect->empty()))
		return ;

	//it�rateur
	FatheredPatPathoIterVect iterPatPatho = pVect->begin() ;
	//trouver la patpatho correspondante
	for ( ; (iterPatPatho != pVect->end()) &&
        ((*iterPatPatho)->getPatPatho() != pNSDialog->pBBItem->pPPTEnCours) ;
       		                                                iterPatPatho++) ;

	//trouver le BBitem de la boite � d�truire
	BBiterFils itBBitem = pBBItemFilsMultiDialog->VectorFils.begin() ;

	for (itBBitem = pBBItemFilsMultiDialog->VectorFils.begin();
       	    (itBBitem != pBBItemFilsMultiDialog->VectorFils.end())
                    && ((*itBBitem) != pNSDialog->pBBItem); itBBitem++) ;

	NSDialogIterVect iterBoite = pMulti->begin();
	//trouver la bo�te � d�truire
	for (iterBoite = pMulti->begin();
           (iterBoite != pMulti->end()) && (pNSDialog != (*iterBoite));
                                                                iterBoite++) ;

	//tuer le BBitem de la boite d�truite : mettre � jour VectorFils
	if (itBBitem != pBBItemFilsMultiDialog->VectorFils.end())
	{
  	delete (*itBBitem) ;
    pBBItemFilsMultiDialog->VectorFils.erase(itBBitem) ;
	}

	//tuer la boite de dialogue
	if (iterBoite != pMulti->end())
	{
  	pNSDialog->Desactive() ;
    (*iterBoite)->Destroy() ;
    pMulti->erase(iterBoite) ;
    pActive = 0 ;
    compteur-- ;
	}

	//enlever la patpatho correspondante
	if (iterPatPatho != pVect->end())
	{
  	delete (*iterPatPatho) ;
    pVect->erase(iterPatPatho) ;
	}
}

//-----------------------------------------------------------------------// en cliquant suo OK, on  active la boite de dialogue suivante
//-----------------------------------------------------------------------
void
NsMultiDialog::idOk(NSDialog* pFocus)
{
	if ((!pFocus) || (pMultiDialog->empty()))
  	return ;

	NSDialogIterVect iter     = pMultiDialog->begin() ;
	NSDialogIterVect itertemp = pMultiDialog->begin() ; //temporaire

	NS_CLASSLIB::TRect rect, rect2 ;
	// int x,y,h, z;

	//
	// si une seule bo�te , alors activer la bo�te multidialogue
	//
	if (pMultiDialog->size() == 1)
	{
  	SetFocus() ;
    return ;
	}

	//chercher la bo�te activ�e
	for (iter = pMultiDialog->begin(); (iter != pMultiDialog->end()) &&
   		                                    ((*iter) != pFocus); iter++) ;

	if (iter != pMultiDialog->end())
	{
  	itertemp = iter ;
    itertemp++ ;
    if (itertemp != pMultiDialog->end())
    	(*itertemp)->SetFocus() ; //activer la suivante
    else
    {
    	itertemp  = pMultiDialog->begin() ;
      (*itertemp)->SetFocus() ; //activer la premi�re
    }
	}
}

//-----------------------------------------------------------------------// fixer la position de la bo�te  de dialogue en fonction de la bo�te pr�c�dente
//-----------------------------------------------------------------------
void
NsMultiDialog::setPosition(NSDialog* pDialog)
{
	if ((!pDialog) || (pMultiDialog->empty()))
		return ;

	NSDialogIterVect iter     = pMultiDialog->begin() ;
	NSDialogIterVect itertemp = pMultiDialog->begin() ; //temporaire
	NS_CLASSLIB::TRect rect ;

	int x, y ;
	int lTW_X = 50 ;
	int lTW_Y = 50 ;

	for (iter = pMultiDialog->begin(); (iter != pMultiDialog->end()) &&
   		((*iter) != pDialog); iter++) ;

	if (iter == pMultiDialog->begin())
		return ;

	itertemp = iter ;
	itertemp-- ;
	rect = (*itertemp)->GetWindowRect() ;

	x = rect.left + lTW_X ;
	y = rect.top  + lTW_Y ;

	pDialog->SetWindowPos(0, x, y, rect.Width(), rect.Height(), SWP_NOZORDER) ;
}

//-----------------------------------------------------------------------// titre de la boite pDialog, cardinal est le nombre de bo�tes de dialogue
// donn� par le BBItem
// mettre � jour les titres des autres bo�tes
// et mettre � jour pMultiDialog
//-----------------------------------------------------------------------
void
NsMultiDialog::setTitre(NSDialog* pDialog, int cardinal)
{
  if (!pDialog)
		return ;

  char valeurentiere[100], titre[100], taille[25] ;
  string Nom ;

  int nombreBoite = 0 ;
  if (!(pMultiDialog->empty()))
  	nombreBoite = pMultiDialog->size() ;
  else
  	nombreBoite = 1 ;

  itoa(nombreBoite,valeurentiere, 10) ;
  itoa(cardinal,taille, 10) ;

  //titre contient le titre de la fen�tre  pDialog->GetWindowText(titre, 100 ) ;
  string Nominitial = string(titre) ;

  if (cardinal == 1)
  	Nom = Nominitial + string(" : ") + string(valeurentiere) ;
  else
  	Nom = Nominitial + string(" : ") + string(valeurentiere) + string("/")
          + string(taille) ;

  //si cette bo�te n'appartient pas � pMultiDialog , l'ajouter
  NSDialogIterVect iter = pMultiDialog->begin() ;
  for(NSDialogIterVect iter = pMultiDialog->begin();
       (iter != pMultiDialog->end()) && (pDialog != (*iter)) ; iter++) ;

  if(iter == pMultiDialog->end() )
  {
  	pMultiDialog->push_back(pDialog) ;
    compteur++ ;
  }

  //mettre � jour le nouveau titre
  pDialog->SetCaption(Nom.c_str()) ;
}

//-----------------------------------------------------------------------// confirmer le choix : ok
//-----------------------------------------------------------------------
void
NsMultiDialog::CmOkFermer(NSDialog* pDialog)
{
	if ((!pDialog) || (!(pDialog->pBBItem)))
		return ;

	pDialog->pBBItem->donneRetourDlg(0) ;
	if (pDialog->pBBItem->okFermerDialogue(true))
  	pDialog->CloseWindow(IDOK) ;
	pDialog->Desactive() ;
	pDialog = 0 ;
}

void
NsMultiDialog::CmOk()
{
	//
	// confirmer la suppression des bo�tes par le bouton "D�truire"
	//
	if (!(pDeleteMultiDialog->empty()))
  	for (NSDialogIterVect iter = pDeleteMultiDialog->begin();
   										iter != pDeleteMultiDialog->end();)
    	DetruireNSDialog(*iter, pDeleteMultiDialog) ;

	if (!(pMultiDialog->empty()))
  	for (NSDialogIterVect iter = pMultiDialog->begin();
                                        iter != pMultiDialog->end(); iter++)
  		//cette fen�tre doit fermer ses fen�tres filles si elles sont ouvertes
      //avant de se refermer elle m�me
      //(*iter)->CmOkFermer();
      CmOkFermer((*iter)) ;

	pBBItemFilsMultiDialog->tuerFils() ;

	//delete pBBItemFilsMultiDialog->pNsMultiDialog;
	pBBItemFilsMultiDialog->pNsMultiDialog = 0 ;
	CloseWindow(IDOK) ;
}

//-----------------------------------------------------------------------// annuler le choix : cancel
//-----------------------------------------------------------------------
void
NsMultiDialog::CmCancel()
{
	//
  // Si on vient de rajouter une ou plusieurs bo�tes, il faut les supprimer
  //
  if ((!(pMultiDialog->empty())) && (!(pAjoutMultiDialog->empty())))
  {
  	for (NSDialogIterVect iter = pMultiDialog->begin();
   		                                iter != pMultiDialog->end(); )
    {
    	//
      // Une bo�te est nouvelle si elle n'est pas dans pAjoutMultiDialog
      //
      NSDialogIterVect jter = pAjoutMultiDialog->begin() ;
      while ((jter != pAjoutMultiDialog->end()) && (!(*iter == *jter)))
      	jter++ ;

      if (jter == pAjoutMultiDialog->end())
      	DetruireNSDialog(*iter, pMultiDialog) ;
      else
      	iter++ ;
    }
  }
  //
  // recup�rer les bo�tes supprim�es
  //
  if (!(pDeleteMultiDialog->empty()))
  	for (NSDialogIterVect iter = pDeleteMultiDialog->begin();
                                iter != pDeleteMultiDialog->end(); iter++)
    	pMultiDialog->push_back(*iter) ;

	if (!(pMultiDialog->empty()))
	{
  	for (NSDialogIterVect iter = pMultiDialog->begin(); iter != pMultiDialog->end(); iter++)
    {
    	//cette fen�tre doit fermer ses fen�tres filles si elles sont ouvertes
      //avant de se refermer elle m�me
      //(*iter)->CmCancelFermer();
      //(*iter)= 0;
      (*iter)->pBBItem->donneRetourDlg(-1) ;
      (*iter)->pBBItem->okFermerDialogue(false) ;
      (*iter)->Destroy(IDCANCEL) ;
    }
	}

	pBBItemFilsMultiDialog->tuerFils() ;
	pBBItemFilsMultiDialog->pNsMultiDialog = 0 ;
	Destroy(IDCANCEL) ;
}

//-----------------------------------------------------------------------// SetupWindow
//-----------------------------------------------------------------------
void
NsMultiDialog::SetupWindow()
{
	//
	// Appel obligatoire au SetupWindow() de l'anc�tre
	//
	TDialog::SetupWindow() ;

	NS_CLASSLIB::TRect rect, rectMulti ;
  int x, y ;
  int lTW_X = 10 ;
  rectMulti = GetWindowRect() ;

  //
  // positionner la boite multidialogue par rapport � la premi�re boite NSDialog
  // pilot�e par pFilsIt en tant que BBItem
  //

	//
  //coordonn�es de l'�cran en pixels
  //
  TIC* pTic = new TIC("DISPLAY", 0, 0) ;
  int XScreen = pTic->GetDeviceCaps(HORZRES) ;
  int YScreen = pTic->GetDeviceCaps(VERTRES) ;
  delete pTic ;

	if (!(pMultiDialog->empty()))
	{
  	NSDialogIterVect iterBoite = pMultiDialog->begin() ;
    if (iterBoite != pMultiDialog->end())
    {
      rect = (*iterBoite)->GetWindowRect() ;
      x = rect.left + rect.Width() + lTW_X ;
      y = rect.top ;

      if ((x + rectMulti.Width()) >= XScreen)//si elle ne tient pas � droite
      {
      	//si elle tient � gauche
        if ( rect.left  - rectMulti.Width() -  lTW_X >= 0 )
        	x = rect.left  - rectMulti.Width() - lTW_X ;
        //si elle ne tient pas � gauche
        else
        {
        	//on la cale � droite
          if (XScreen - rect.left - rect.Width() > rect.left)
          	x = XScreen - rectMulti.Width() ;
          else
          	x = 0 ;
        }
      }
      if ((y + rectMulti.Height()) >= YScreen)
      	y = YScreen - rectMulti.bottom + rectMulti.top ;

      SetWindowPos(0,x,y, rectMulti.Width(),rectMulti.Height(),SWP_NOZORDER) ;
    }
  }
    //
    // On indique dans pAjoutMultiDialog les bo�tes pr�sentes � l'ouverture
    //
    if (!(pMultiDialog->empty()))
        for (NSDialogIterVect iter = pMultiDialog->begin();
   		                    iter != pMultiDialog->end(); iter++)
   	        pAjoutMultiDialog->push_back(*iter);
}

