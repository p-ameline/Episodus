#include <stdio.h>
#include "nautilus\nssuper.h"#include "nssavoir\nspathor.h"#include "nsbb\nsednum.h"
#include "nsbb\nsutidlg.h"
#include "nsbb\nsbb.h"
#include "partage\nsdivfct.h"
#include "nautilus\nsepicap.h"

//
// General Controls diagnostic group
//
DIAG_DEFINE_GROUP_INIT(OWL_INI, OwlControl, 1, 0);

const char decimSepar = ',';   // Edit double bouton

// ----------------------------------------------------------------------
//
//
// ----------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSUtilEdit, TEdit)
	// EV_WM_SETFOCUS,
	EV_WM_KEYUP,
	EV_WM_GETDLGCODE,
	EV_WM_CHAR,
	EV_WM_KILLFOCUS,
END_RESPONSE_TABLE;

//
// Constructeur
//
NSUtilEdit::NSUtilEdit(NSContexte* pCtx, NSUtilDialog* pUtilDialog, int resId, int iTextLen, bool bReturn, TModule* module)
           :TEdit((TWindow*)pUtilDialog, resId, iTextLen+1, module), NSRoot(pCtx)
{
	pNSUtilDialog = pUtilDialog ;
  bIntercepte = bReturn ;        // permet de shunter le 1er Return ou Tab

  initCommonData() ;
}

NSUtilEdit::NSUtilEdit(NSContexte* pCtx, NSUtilDialog* pUtilDialog, int Id, const char far* text, int x, int y, int w, int h, int iTextLen, bool multiline, bool bReturn, TModule* module)
           :TEdit((TWindow*)pUtilDialog, Id, text, x, y, w, h, iTextLen+1, multiline, module), NSRoot(pCtx)
{
	pNSUtilDialog = pUtilDialog ;
  bIntercepte = bReturn ;        // permet de shunter le 1er Return ou Tab

  initCommonData() ;
}

void
NSUtilEdit::initCommonData()
{
	if (NULL != pNSUtilDialog)
		pNSUtilDialog->ReferenceControl(this) ;

	_LostFocusFunctor = NULL ;

	bWinStd = false ;
	if (pNSUtilDialog && pNSUtilDialog->pContexte)
	{
  	NSSuper* pSuper = pNSUtilDialog->pContexte->getSuperviseur() ;
    if ((pSuper && pSuper->getDPIO()) && (pSuper->getDPIO()->bReturnCloses))
    	bWinStd = true ;
	}
}

//
// Destructeur
//
NSUtilEdit::~NSUtilEdit()
{
}

void
NSUtilEdit::SetupWindow()
{
	TEdit::SetupWindow();
}

//fonction permettant � la touche ENTREE d'avoir le m�me effet que TAB
void
NSUtilEdit::EvKeyUp(uint key, uint repeatcount, uint flags)
{
    // Gestion windows standard
    // Windows standard behaviour
     if (bWinStd)
    {
        // return TEdit::EvKeyUp(key, repeatcount, flags) ;
        TEdit::EvKeyUp(key, repeatcount, flags) ;
        return ;
    }

    switch(key)
    {
        //return
   	    case VK_RETURN  :
        case VK_DOWN    :
            //
            //demander � la bo�te de dialogue m�re d'activer le controle
            //suivant pControle sinon le premier
            //
            if (bIntercepte)
                pNSUtilDialog->ActiveControlSuivant(this);
            else
                bIntercepte = true;
            break;

      //?????????????? PENSER A LE FAIRE      /*
      case VK_UP     : 	//
      						//demander � la bo�te de dialogue m�re d'activer le controle
                        //pr�c�dent pControle sinon le dernier
                        //
                        if (bIntercepte)
	      						pNSUtilDialog->ActiveControlPrecedent(this);
                        else
                        	bIntercepte = true;
                        break;
      */
      //tabulation
        case VK_TAB	:
            //
            //demander � la bo�te de dialogue m�re d'activer le controle
            //suivant pControle sinon le premier
            //
            if (!bIntercepte)
                bIntercepte = true;
            pNSUtilDialog->ActiveControlSuivant(this);
            break;

        default       :
            if (key == VK_F1)
                pNSUtilDialog->CmHelp();
            if (!bIntercepte)
                bIntercepte = true;
            TEdit::EvKeyUp(key, repeatcount, flags);
   }
}

//-------------------------------------------------------------------------
// enlever les beeps
//-------------------------------------------------------------------------
void
NSUtilEdit::EvChar(uint key, uint repeatCount, uint flags)
{
	if (!bWinStd && ((key == VK_RETURN) || (key == VK_TAB)))
		//Process this message to avoid message beeps.
		return ;
	else
		TEdit::EvChar(key, repeatCount, flags) ;
}

//fonction permettant � la touche ENTREE d'avoir le m�me effet que TAB
uint
NSUtilEdit::EvGetDlgCode(MSG far* /* msg */)
{
	uint retVal = (uint)DefaultProcessing() ;
	if (!bWinStd)
		retVal |= DLGC_WANTALLKEYS ;
	return retVal ;
}

void
NSUtilEdit::EvKillFocus(HWND hWndGetFocus)
{
  fireLostFocusFunctor() ;

  if (0 != hWndGetFocus)
    TEdit::EvKillFocus(hWndGetFocus) ;
}

void
NSUtilEdit::fireLostFocusFunctor()
{
	if (NULL != _LostFocusFunctor)
		(*_LostFocusFunctor)() ;
}

// ----------------------------------------------------------------------
//
//						NSUtilEdit2 : pour les saisies
//
// ----------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSUtilEdit2, NSUtilEdit)
END_RESPONSE_TABLE;

//
// Constructeur
//
NSUtilEdit2::NSUtilEdit2(NSContexte* pCtx, NSUtilDialog* pUtilDialog, int resId, int iTextLen)
            :NSUtilEdit(pCtx, pUtilDialog, resId, iTextLen)
{
	ciTexteLen = iTextLen + 1;
}

//
// Destructeur
//
NSUtilEdit2::~NSUtilEdit2()
{
}

void
NSUtilEdit2::SetupWindow()
{
	NSUtilEdit::SetupWindow();
}

//
// Fonction red�finie GetText pour r�cup�rer une string
//
void
NSUtilEdit2::GetText(string& sResultText)
{
	char far *texte;

   texte = new char[ciTexteLen];

   TEdit::GetText(texte, ciTexteLen);
   sTexte = string(texte);

   sResultText = sTexte;

   delete[] texte;
}

// ----------------------------------------------------------------------
//
//				 NSMultiEdit : pour les NSUtilEdit multilignes
//
// ----------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSMultiEdit, NSUtilEdit2)
    EV_WM_KEYUP,
    EV_WM_CHAR,
END_RESPONSE_TABLE;

//
// Constructeur
//
NSMultiEdit::NSMultiEdit(NSContexte* pCtx, NSUtilDialog* pUtilDialog, int resId, int iTextLen)
            :NSUtilEdit2(pCtx, pUtilDialog, resId, iTextLen)
{
}

//// Destructeur
//
NSMultiEdit::~NSMultiEdit()
{
}

void
NSMultiEdit::SetupWindow()
{
	NSUtilEdit2::SetupWindow() ;
}

voidNSMultiEdit::EvKeyUp(uint key, uint repeatcount, uint flags)
{
  if ((key == VK_RETURN) || (VK_DOWN))
    TEdit::EvKeyUp(key, repeatcount, flags) ;
  else
    NSUtilEdit::EvKeyUp(key, repeatcount, flags) ;
}

voidNSMultiEdit::EvChar(uint key, uint repeatCount, uint flags)
{
  if (key == VK_RETURN)
    TEdit::EvChar(key, repeatCount, flags) ;
  else
    NSUtilEdit::EvChar(key, repeatCount, flags) ;
}

// ----------------------------------------------------------------------
//
//           		 classe NSFilterValidator (pour NSEditNum)
//
// ----------------------------------------------------------------------

NSFilterValidator::NSFilterValidator(NSContexte* pCtx, string sCharSet)		  :TFilterValidator(sCharSet.c_str()), NSRoot(pCtx)
{
	sValidator = sCharSet ;
}

NSFilterValidator::~NSFilterValidator()
{
}

// on red�finit la fonction Error
void
NSFilterValidator::Error(TWindow* /* owner */)
{
	char far msg[255] ;

	// PRECONDITION(owner) ;
	sprintf(msg, "Caract�re non valide : CharSet = [%s].", sValidator.c_str()) ;
	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
	pContexte->GetMainWindow()->MessageBox(msg, sCaption.c_str(), MB_OK) ;
}

// ----------------------------------------------------------------------
//
//           					classe NSEditNum
//
// ----------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSEditNum, NSUtilEdit)
	EV_WM_KILLFOCUS,
	EV_WM_SETFOCUS,
END_RESPONSE_TABLE;

NSEditNum::NSEditNum(NSContexte* pCtx, NSUtilDialog* pUtilDialog, int resId, int iTextLen, int iDecimales,
						string sValidator)
          :NSUtilEdit(pCtx, pUtilDialog, resId, iTextLen + 1)
{
	string sValidateur = "" ;
	sContenuBrut      = "" ;
	sContenuTransfert = "" ;

  //ParentNSEditNum  = (TWindow*)pNSUtilDialog;
  dValeur = 0 ;

	DisableTransfer() ;
  //
  iDecimale = iDecimales ;
	iMaxInput = iTextLen ;

	//
	// Mise en place du validateur
	//
  pFilterValidator = new NSFilterValidator(pNSUtilDialog->pContexte, sValidator) ;
  SetValidator(pFilterValidator) ;

  	/* if (iDecimale == 0)
   			SetValidator(new TFilterValidator("0-9"));*/
    /* else
   		{
   			sValidateur = string(iMaxInput+1, '#');
      		sValidateur[iMaxInput-iDecimale-1] = ';';
      		sValidateur[iMaxInput-iDecimale]   = decimSepar;
      		SetValidator(new TPXPictureValidator(sValidateur.c_str(), 1));
   		}  */
}

//
// Destructeur
//
NSEditNum::~NSEditNum()
{
	// delete pFilterValidator;
}

void
NSEditNum::MettreAJourValeur(string sContenu)
{
	//
	// Elaboration de sContenuTransfert
	//
   sContenuBrut = sContenu;
   donneTransfert();
   donneValeur();
}

//// Fonction d�clench� lorsque l'Edit perd le focus.
//
void
NSEditNum::EvKillFocus(HWND hWndGetFocus)
{
	//
	// R�cup�re le texte
	//
	/*str = new char[iMaxInput + 1];
	GetLine(str, iMaxInput, 0);
	sContenu = string(str);
	delete[] str;
    */
	int oldBuffLen = GetTextLen() ;
	char far* str = new char[oldBuffLen + 1] ;
	GetText(str, oldBuffLen + 1) ;
	string sContenu = string(str) ;
	delete[] str ;

	//
	// Elaboration de sContenuTransfert
	//
	MettreAJourValeur(sContenu) ;

  fireLostFocusFunctor() ;

  if (0 != hWndGetFocus)
    TEdit::EvKillFocus(hWndGetFocus) ;
}

//---------------------------------------------------------------------------//  Function: 		NSEditNum::donneBrut()
//
//  Description:	Transforme les donn�es NAUTILUS en donn�es � saisir par
//						l'utilisateur
//
//  Arguments:		Aucun
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void
NSEditNum::donneBrut()
{
	size_t i, j ;
	int iDecimale = 0 ;
	//
	// Pour les entiers, on supprime les '0' initiaux
	//
	if (iDecimale == 0)
	{
  	if (sContenuTransfert == "")
    	sContenuBrut = "" ;
    else
    {
    	i = sContenuTransfert.find_first_not_of('0') ;
      if (i == NPOS)
      	sContenuBrut = "0" ;
      else
      	sContenuBrut = string(sContenuTransfert, i, strlen(sContenuTransfert.c_str())-i) ;
    }
  }
  //
	// Pour les d�cimaux, on positionne d'abord la virgule
	//
	else
	{
  	if (sContenuTransfert == "")
    	//sContenuBrut = "0" + "," + string(iDecimale, '0');
    	sContenuBrut = "" ;
    else
    {
    	string sDecimalSeparator = string(1, decimSepar) ;
    	if (pNSUtilDialog && pNSUtilDialog->pContexte)
  			sDecimalSeparator = pNSUtilDialog->pContexte->getSuperviseur()->getText("0localInformation", "decimalSeparator") ;

    	sContenuBrut = string(sContenuTransfert, 0, iMaxInput-2-iDecimale)
         				+ sDecimalSeparator
                        + string(sContenuTransfert, iMaxInput-2-iDecimale, iDecimale);

         i = sContenuBrut.find_first_not_of('0');
         j = min(i, iMaxInput-3-iDecimale);
         if (j > 0)
         	sContenuBrut = string(sContenuBrut, i, strlen(sContenuBrut.c_str())-i) ;
      }
   }
}

//---------------------------------------------------------------------------//  Function: 		NSEditNum::donneTransfert()
//
//  Description:	Transforme les donn�es saisies par l'utilisateur
//					   en donn�es NAUTILUS
//
//  Arguments:		Aucun
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void
NSEditNum::donneTransfert()
{
	strip(sContenuBrut) ;

	if ((sContenuBrut == "") || (!sContenuBrut.find_first_of("0123456789") == 0))
	{
  	sContenuTransfert = "" ;
    return ;
  }

  // Recherche du premier caract diff�rent de '0'
  //
  size_t k = sContenuBrut.find_first_not_of('0') ;
  //
  // ATTENTION : on suppose que 0 = rien
  //
  if (k == NPOS)
  {
  	sContenuTransfert = "" ;
    return ;
  }

  string sDecimalSeparator = string(1, decimSepar) ;
	if (pNSUtilDialog && pNSUtilDialog->pContexte)
		sDecimalSeparator = pNSUtilDialog->pContexte->getSuperviseur()->getText("0localInformation", "decimalSeparator") ;
  size_t i = sContenuTransfert.find(sDecimalSeparator) ;

  // on teste si on a 0,XX (il ne faut pas �ter le 0)
  // ou 00035,XX (il faut �ter les 0 initiaux)
  if (i == k)
  {
  	if (k == 0)
    	sContenuTransfert = "0" + sContenuBrut ;
    else
    	sContenuTransfert = string(sContenuBrut, k-1, strlen(sContenuBrut.c_str())-k+1) ;
  }
	else
		sContenuTransfert = string(sContenuBrut, k, strlen(sContenuBrut.c_str())-k) ;

	// Replace local decimal separator by '.'
	if (i != NPOS)
	{
		size_t iSeparLen = strlen(sDecimalSeparator.c_str()) ;
    size_t iTextLen  = strlen(sContenuTransfert.c_str()) ;
    
		if (i == 0)
    	sContenuTransfert = string("0") + string(".") + string(sContenuTransfert, iSeparLen, iTextLen - iSeparLen) ;
    else if (i + iSeparLen >= iTextLen)
			sContenuTransfert = string(sContenuTransfert, 0, i) ;
    else
    	sContenuTransfert = string(sContenuTransfert, 0, i) + string(".") + string(sContenuTransfert, i + iSeparLen, iTextLen - i - iSeparLen) ;
  }
}

//---------------------------------------------------------------------------//  Function: 		NSEditNum::donneValeur()
//
//  Description:	Calcule la valeur � partir de sContenuTransfert
//
//  Arguments:		Aucun
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void
NSEditNum::donneValeur()
{
	dValeur = 0 ;
	if (sContenuTransfert == "")
		return ;

	dValeur = StringToDouble(sContenuBrut) ;
}

// ----------------------------------------------------------------------
//
//           					classe NSEditNumTel
//
// ----------------------------------------------------------------------

NSEditNumTel::NSEditNumTel(NSContexte* pCtx, NSUtilDialog* pNSUtilDialog, int resId, int iTextLen)             :NSEditNum(pCtx, pNSUtilDialog, resId, iTextLen, 0, "0-9. -"){
}

NSEditNumTel::~NSEditNumTel(){
}

// ----------------------------------------------------------------------//
//           					classe NSUtilEditDate
//
// ----------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSUtilEditDate, NSUtilEdit)
   EV_WM_CHAR,
   EV_WM_KEYDOWN,
END_RESPONSE_TABLE;

//
// Constructeur
//
NSUtilEditDate::NSUtilEditDate(NSContexte* pCtx, NSUtilDialog* parent, int resId, uint textLen, bool b2000, string sLang)
               :NSUtilEdit(pCtx, parent, resId, textLen)
{
  _sLang = sLang ;

  // Date pattern
  //
  if ((NULL != parent) && (NULL != parent->pContexte))
    sFormat = parent->pContexte->getSuperviseur()->getText("0localInformation", "dateFormat") ;
  if (string("") == sFormat)
  {
    sFormat = string("DD/MM/AAAA") ;
    sFormat[2] = dateSeparationMARK ;
    sFormat[5] = dateSeparationMARK ;
  }

	// Validator setting
	//
  string sValidator = sFormat ;
  for (size_t i = 0 ; i < strlen(sValidator.c_str()) ; i++)
    if (('A' == sValidator[i]) || ('D' == sValidator[i]) || ('M' == sValidator[i]))
      sValidator[i] = '#' ;

  SetValidator(new TPXPictureValidator(sValidator.c_str())) ;

  // Mask setting
  //
  sMask = sFormat ;
  for (size_t i = 0 ; i < strlen(sMask.c_str()) ; i++)
    if (('A' == sMask[i]) || ('D' == sMask[i]) || ('M' == sMask[i]))
      sMask[i] = '0' ;

  size_t iPos = sFormat.find("AAAA") ;
  if (NPOS != iPos)
  {
    if (b2000)
      sMask.replace(iPos, 4, "2000") ;
    else
      sMask.replace(iPos, 4, "1900") ;
  }

  sContenuTransfert = "" ;
}

//// Destructeur
//
NSUtilEditDate::~NSUtilEditDate()
{
}

void
NSUtilEditDate::SetupWindow()
{
    NSUtilEdit::SetupWindow();
	donneBrut();
    SetText(sContenuBrut.c_str());
}

voidNSUtilEditDate::setDate(string sAAAAMMJJ)
{
	sContenuTransfert = sAAAAMMJJ;
   donneBrut();
   SetText(sContenuBrut.c_str());
}

void
NSUtilEditDate::getDate(string* pAAAAMMJJ)
{
	int iBuffLen = GetTextLen() ;
	char far* pszBuff = new char[iBuffLen + 1] ;
	GetText(pszBuff, iBuffLen + 1) ;
	sContenuBrut = string(pszBuff) ;
	delete[] pszBuff ;

	donneTransfert() ;
	*pAAAAMMJJ = sContenuTransfert ;
}

//---------------------------------------------------------------------------
//  Function: 		NSUtilEditDate::donneBrut()
//
//  Description:	Transforme les donn�es NAUTILUS en donn�es � saisir par
//						l'utilisateur
//---------------------------------------------------------------------------
void
NSUtilEditDate::donneBrut()
{
	int i;

  string sDateFormat = string("") ;
  if ((NULL != pNSUtilDialog) && (NULL != pNSUtilDialog->pContexte))
    sDateFormat = pNSUtilDialog->pContexte->getSuperviseur()->getText("0localInformation", "dateFormat") ;

	sContenuBrut = sMask ;
	sContenuBrut[2] = dateSeparationMARK ;
	sContenuBrut[5] = dateSeparationMARK ;
	//
	// On passe de AAAAMMJJ � JJ/MM/AAAA
	//
  size_t iTransfertSize = strlen(sContenuTransfert.c_str()) ;

	if (sContenuTransfert != "")
	{
  	if (iTransfertSize >= 4)
    	for (i = 0; i < 4; i++)
      	sContenuBrut[i+6] = sContenuTransfert[i] ;
    if (iTransfertSize >= 6)
    	for (i = 0; i < 2; i++)
      	sContenuBrut[i+3] = sContenuTransfert[i+4] ;
    if (iTransfertSize >= 8)
    	for (i = 0; i < 2; i++)
      	sContenuBrut[i] = sContenuTransfert[i+6] ;
	}
}

//---------------------------------------------------------------------------//  Function: 		NSEditDate::donneTransfert()
//
//  Description:	Transforme les donn�es saisies par l'utilisateur
//					   en donn�es NAUTILUS
//---------------------------------------------------------------------------
void
NSUtilEditDate::donneTransfert()
{
	sContenuTransfert = "" ;
	//
  // On passe de JJ/MM/AAAA � AAAAMMJJ
  //
	char cValidateur[11] = "" ;

	strcpy(cValidateur, sMask.c_str());
	cValidateur[2] = dateSeparationMARK;
	cValidateur[5] = dateSeparationMARK;
	if (sContenuBrut != cValidateur)
	{
  	sContenuTransfert  = string(sContenuBrut, 6, 4) ;
    sContenuTransfert += string(sContenuBrut, 3, 2) ;
    sContenuTransfert += string(sContenuBrut, 0, 2) ;
	}
}

////  TStatic
//
void
NSUtilEditDate::EvChar(uint key, uint repeatCount, uint flags)
{
  if (Validator && (key != VK_BACK) 	&&
                    (key != VK_RETURN) &&
                    (key != VK_SPACE) 	&&
                    (key != VK_DELETE) &&
                    (key != VK_TAB))
  {
    int oldBuffLen = GetTextLen() ;
    char far* oldBuff = new char[oldBuffLen+1] ;
    GetText(oldBuff, oldBuffLen+1) ;

    uint startSel, endSel ;
    GetSelection(startSel, endSel) ;

    // On saute les '/'
    if (startSel == 2)
      startSel = 3 ;
    if (startSel == 5)
      startSel = 8 ;

    //Si la s�lection est multi-caract�res, on la ram�ne � 1 car.
    endSel = startSel ;
    SetSelection(startSel, endSel) ;

    bool wasAppending = endSel == oldBuffLen ;

    if ((!wasAppending) && (startSel == endSel))
    {
      for (int i = startSel; i < oldBuffLen; i++)
        oldBuff[i] = oldBuff[i+1] ;
      SetText(oldBuff) ;
      SetSelection(startSel, endSel) ;
    }

    bool preMsgModify = IsModified() ;           // Save (pre)  MODIFY flag

    TStatic::EvChar(key, repeatCount, flags) ;   // Process the new char...

    bool postMsgModify = IsModified() ;          // Save (post) MODIFY flag

    GetSelection(startSel, endSel) ;
    int buffLen = GetTextLen() ;
    char far* buff = LockBuffer(max((int)TextLimit,max(oldBuffLen,buffLen))+1) ;

    // Run the result of the edit through the validator.  If incorrect,
    // then restore the original text.  Otherwise, range check & position
    // the selection as needed.
    //
    if (!Validator->HasOption(voOnAppend) || wasAppending && endSel == buffLen)
    {
      if (!Validator->IsValidInput(buff, false))
      {
        strcpy(buff, oldBuff) ;          // Restore old buffer
        postMsgModify = preMsgModify ;   // Restore old modify state too!
      }
      else
      {
        if (wasAppending)
          startSel = endSel = strlen(buff) ; // may have autoFilled--move to end
      }
      UnlockBuffer(buff, true) ;
      SetSelection(startSel, endSel) ;
    }
    else
    {
      if (endSel == buffLen && !Validator->IsValidInput(buff, false))
        Validator->Error(this) ;
      UnlockBuffer(buff) ;
    }
    SendMessage(EM_SETMODIFY, (TParam1)postMsgModify) ;

    //
    // On saute les caract�res inutiles
    //
    GetSelection(startSel, endSel) ;
    if (startSel == endSel)
    {
      if (startSel == 2)
        SetSelection(3, 3) ;
      if (startSel == 5)
        SetSelection(8, 8) ;
    }
    delete[] oldBuff ;
  }
  else if (VK_BACK == key)
  {
    uint   startSel, endSel ;
    GetSelection(startSel, endSel) ;

    // On saute les '/'
    if (startSel == 3)
      startSel = 2 ;
    if (startSel == 6)
      startSel = 5 ;

    int oldBuffLen = GetTextLen() ;
    char far* oldBuff = new char[oldBuffLen+1] ;
    GetText(oldBuff, oldBuffLen+1) ;

    if (startSel > 0)
    {
      startSel-- ;
      oldBuff[startSel] = '0' ;
    }
    endSel = startSel;
    SetText(oldBuff) ;
    SetSelection(startSel, endSel) ;
    delete[] oldBuff ;
  }
  else if ((VK_RETURN == key) || (VK_TAB == key) || (VK_SPACE == key))
    //Process this message to avoid message beeps.
    return ;
  else
    TStatic::EvChar(key, repeatCount, flags) ;
}

void
NSUtilEditDate::EvKeyDown(uint key, uint repeatCount, uint flags)
{
  if (VK_DELETE == key)
  {
    uint startSel, endSel ;
    GetSelection(startSel, endSel) ;

    int oldBuffLen = GetTextLen() ;
    char far* oldBuff = new char[oldBuffLen+1] ;
    GetText(oldBuff, oldBuffLen+1) ;

    string dateVide = sMask ;
    string dateEdit = string(oldBuff) ;

    if (startSel == endSel)
    {
      dateEdit.replace(startSel, 1, dateVide, startSel, 1) ;
      startSel++ ;
      endSel++ ;
    }
    else
    {
      dateEdit.replace(startSel, endSel-startSel, dateVide, startSel, endSel-startSel) ;
      startSel = endSel ;
    }

    strcpy(oldBuff, dateEdit.c_str()) ;

    SetText(oldBuff) ;
    SetSelection(startSel, endSel) ;
    delete[] oldBuff ;
  }
  else
    TStatic::EvKeyDown(key, repeatCount, flags) ;
}

// ----------------------------------------------------------------------
//
//           					classe NSUtilEditHeure
//
// ----------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSUtilEditHeure, NSUtilEdit)
   EV_WM_CHAR,
   EV_WM_KEYDOWN,
END_RESPONSE_TABLE;

//// Constructeur
//
NSUtilEditHeure::NSUtilEditHeure(NSContexte* pCtx, NSUtilDialog* parent, int resId, uint textLen, string sLang)
                :NSUtilEdit(pCtx, parent, resId, textLen)
{
  _sLang = sLang ;

	//
	// Mise en place du validateur
	//
  char cValidateur[] = "##:##" ;
  cValidateur[2] = heureSeparationMARK ;
  SetValidator(new TPXPictureValidator(cValidateur)) ;

  sContenuTransfert = "" ;
}

//// Destructeur
//
NSUtilEditHeure::~NSUtilEditHeure()
{
}

void
NSUtilEditHeure::SetupWindow()
{
    NSUtilEdit::SetupWindow();
	donneBrut();
    SetText(sContenuBrut.c_str());
}

void
NSUtilEditHeure::setHeure(string sHHMM)
{
	sContenuTransfert = sHHMM;
    donneBrut();
    SetText(sContenuBrut.c_str());
}

void
NSUtilEditHeure::getHeure(string* pHHMM)
{
    int iBuffLen = GetTextLen();
    char far* pszBuff = new char[iBuffLen + 1];
    GetText(pszBuff, iBuffLen + 1);
    sContenuBrut = string(pszBuff);
    delete[] pszBuff;

	donneTransfert();
    *pHHMM = sContenuTransfert;
}

//---------------------------------------------------------------------------
//  Function: 		NSUtilEditHeure::donneBrut()
//
//  Description:	Transforme les donn�es NAUTILUS en donn�es � saisir par
//						l'utilisateur
//---------------------------------------------------------------------------
void
NSUtilEditHeure::donneBrut()
{
	sContenuBrut = "00:00";
    sContenuBrut[2] = heureSeparationMARK;
    //
    // On passe de HHmm � HH:mm
    //
    if (sContenuTransfert != "")
    {
    	sContenuBrut = string(sContenuTransfert, 0, 2) + string(1,heureSeparationMARK) +
      					string(sContenuTransfert, 2, 2);
    }
}

//---------------------------------------------------------------------------//  Function: 		NSEditDate::donneTransfert()
//
//  Description:	Transforme les donn�es saisies par l'utilisateur
//					   en donn�es NAUTILUS
//---------------------------------------------------------------------------
void
NSUtilEditHeure::donneTransfert()
{
	sContenuTransfert = "";
   //
   // On passe de HH:mm � HHmm
   //
   char cValidateur[] = "00:00";
   cValidateur[2] = heureSeparationMARK;
   if (sContenuBrut != cValidateur)
   {
   	  sContenuTransfert  = string(sContenuBrut, 0, 2);
      sContenuTransfert += string(sContenuBrut, 3, 2);
   }
}

////  TStatic
//
void
NSUtilEditHeure::EvChar(uint key, uint repeatCount, uint flags)
{
    if (Validator && (key != VK_BACK) 	&&
                     (key != VK_RETURN) &&
                     (key != VK_SPACE) 	&&
                     (key != VK_DELETE) &&
                     (key != VK_TAB))
    {
   	    int oldBuffLen = GetTextLen();
    	char far* oldBuff = new char[oldBuffLen+1];
        GetText(oldBuff, oldBuffLen+1);

    	uint   startSel, endSel;
    	GetSelection(startSel, endSel);

        // On saute le ':'
        if (startSel == 2)
      	    startSel = 3;

        //Si la s�lection est multi-caract�res, on la ram�ne � 1 car.
        endSel = startSel;
        SetSelection(startSel, endSel);

        bool wasAppending = endSel == oldBuffLen;

  		if ((!wasAppending) && (startSel == endSel))
    	{
            for (int i = startSel; i < oldBuffLen; i++)
         	    oldBuff[i] = oldBuff[i+1];
            SetText(oldBuff);
            SetSelection(startSel, endSel);
        }

    	bool preMsgModify = IsModified();             // Save (pre)  MODIFY flag

    	TStatic::EvChar(key, repeatCount, flags);     // Process the new char...

    	bool postMsgModify= IsModified();             // Save (post) MODIFY flag

    	GetSelection(startSel, endSel);
    	int buffLen = GetTextLen();
    	char far* buff = LockBuffer(max((int)TextLimit,max(oldBuffLen,buffLen))+1);

    	// Run the result of the edit through the validator.  If incorrect,
    	// then restore the original text.  Otherwise, range check & position
    	// the selection as needed.
    	//
    	if (!Validator->HasOption(voOnAppend) || wasAppending && int(endSel) == buffLen)
        {
      	    if (!Validator->IsValidInput(buff, false))
            {
        		strcpy(buff, oldBuff);          // Restore old buffer
        		postMsgModify = preMsgModify;   // Restore old modify state too!
      	    }
      	    else
            {
                if (wasAppending)
          		    startSel = endSel = strlen(buff); // may have autoFilled--move to end
      	    }
      	    UnlockBuffer(buff, true);
      	    SetSelection(startSel, endSel);
        }
    	else
        {
      	    if (endSel == buffLen && !Validator->IsValidInput(buff, false))
        		Validator->Error(this);
      	    UnlockBuffer(buff);
        }
    	SendMessage(EM_SETMODIFY, (TParam1)postMsgModify);

        //
        // On saute les caract�res inutiles
        //
    	GetSelection(startSel, endSel);
        if (startSel == endSel)
        {
      	    if (startSel == 2)
      		    SetSelection(3, 3);
   	    }

    	delete[] oldBuff;
    }
    else if (key == VK_BACK)
    {
        uint   startSel, endSel;
    	GetSelection(startSel, endSel);

        // On saute le ':'
        if (startSel == 3)
      	    startSel = 2;

   	    int oldBuffLen = GetTextLen();
    	char far* oldBuff = new char[oldBuffLen+1];
        GetText(oldBuff, oldBuffLen+1);

        if (startSel > 0)
        {
      	    startSel--;
      	    oldBuff[startSel] = '0';
        }
        endSel = startSel;
        SetText(oldBuff);
   	    SetSelection(startSel, endSel);
        delete[] oldBuff;
    }
    else if ((key == VK_RETURN) || (key == VK_TAB))
   	    //Process this message to avoid message beeps.
        return ;
    else if ((key == VK_SPACE))
   	    //Process this message to avoid message beeps.
        return ;
    else
        TStatic::EvChar(key, repeatCount, flags);
}

void
NSUtilEditHeure::EvKeyDown(uint key, uint repeatCount, uint flags)
{
    if (key == VK_DELETE)
    {
        uint   startSel, endSel;
        GetSelection(startSel, endSel);

        int oldBuffLen = GetTextLen();
        char far* oldBuff = new char[oldBuffLen+1];
        GetText(oldBuff, oldBuffLen+1);

        string heureVide = "00:00";
        string heureEdit = string(oldBuff);

        if (startSel == endSel)
        {
            heureEdit.replace(startSel, 1, heureVide, startSel, 1);
            startSel++;
            endSel++;
        }
        else
        {
            heureEdit.replace(startSel, endSel-startSel, heureVide, startSel, endSel-startSel);
            startSel = endSel;
        }

        strcpy(oldBuff, heureEdit.c_str());
        SetText(oldBuff);
        SetSelection(startSel, endSel);
        delete[] oldBuff;
    }
    else
        TStatic::EvKeyDown(key, repeatCount, flags);
}


// ----------------------------------------------------------------------
//
//           					classe NSUtilEditDateHeure
//
// ----------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSUtilEditDateHeure, NSUtilEdit)
	EV_WM_CHAR,
	EV_WM_KEYDOWN,
END_RESPONSE_TABLE;

//
// Constructeur
//
NSUtilEditDateHeure::NSUtilEditDateHeure(NSContexte* pCtx, NSUtilDialog* parent, int resId, uint textLen, bool b2000, string sLang)
                    :NSUtilEdit(pCtx, parent, resId, textLen)
{
  _sLang = sLang ;

	initCommonData() ;

  size_t iPos = sFormat.find("AAAA") ;
  if (NPOS != iPos)
  {
    if (b2000)
      sMask.replace(iPos, 4, "2000") ;
    else
      sMask.replace(iPos, 4, "1900") ;
  }
}

NSUtilEditDateHeure::NSUtilEditDateHeure(NSContexte* pCtx, NSUtilDialog* parent, int Id, const char far* text, int x, int y, int w, int h, int iTextLen, bool b2000, string sLang)
                    :NSUtilEdit(pCtx, parent, Id, text, x, y, w, h, iTextLen)
{
  _sLang = sLang ;

	initCommonData() ;

  size_t iPos = sFormat.find("AAAA") ;
  if (NPOS != iPos)
  {
    if (b2000)
      sMask.replace(iPos, 4, "2000") ;
    else
      sMask.replace(iPos, 4, "1900") ;
  }
}

//// Destructeur
//
NSUtilEditDateHeure::~NSUtilEditDateHeure()
{
}

void
NSUtilEditDateHeure::initCommonData()
{
  // Date pattern
  //
  if ((NULL != pNSUtilDialog) && (NULL != pNSUtilDialog->pContexte))
    sFormat = pNSUtilDialog->pContexte->getSuperviseur()->getText("0localInformation", "timeFormat") ;
  if (string("") == sFormat)
  {
    sFormat = string("DD/MM/AAAA hh:mm:ss") ;
    sFormat[2]  = dateSeparationMARK ;
    sFormat[5]  = dateSeparationMARK ;
    sFormat[13] = heureSeparationMARK ;
    sFormat[16] = heureSeparationMARK ;
  }

	// Validator setting
	//
  string sValidator = sFormat ;
  for (size_t i = 0 ; i < strlen(sValidator.c_str()) ; i++)
    if (('A' == sValidator[i]) || ('D' == sValidator[i]) || ('M' == sValidator[i]) ||
        ('h' == sValidator[i]) || ('m' == sValidator[i]) || ('s' == sValidator[i]))
      sValidator[i] = '#' ;

  SetValidator(new TPXPictureValidator(sValidator.c_str())) ;

  // Mask setting
  //
  sMask = sFormat ;
  for (size_t i = 0 ; i < strlen(sMask.c_str()) ; i++)
    if (('A' == sMask[i]) || ('D' == sMask[i]) || ('M' == sMask[i]) ||
        ('h' == sMask[i]) || ('m' == sMask[i]) || ('s' == sMask[i]))
      sMask[i] = '0' ;

  sContenuTransfert = "" ;
}

void
NSUtilEditDateHeure::SetupWindow()
{
	NSUtilEdit::SetupWindow() ;
	donneBrut() ;
	SetText(sContenuBrut.c_str()) ;
}

voidNSUtilEditDateHeure::setDate(string sAAAAMMJJ)
{
	sContenuTransfert = sAAAAMMJJ ;
	donneBrut() ;
	SetText(sContenuBrut.c_str()) ;
}

void
NSUtilEditDateHeure::getDate(string* pAAAAMMJJ)
{
  if (NULL == pAAAAMMJJ)
    return ;

	int iBuffLen = GetTextLen() ;
	char far* pszBuff = new char[iBuffLen + 1] ;
	GetText(pszBuff, iBuffLen + 1) ;
	sContenuBrut = string(pszBuff) ;
	delete[] pszBuff ;

	donneTransfert() ;
	*pAAAAMMJJ = sContenuTransfert ;
}

//---------------------------------------------------------------------------
//  Function: 		NSUtilEditDate::donneBrut()
//
//  Description:	Transforme les donn�es NAUTILUS en donn�es � saisir par
//						l'utilisateur
//---------------------------------------------------------------------------
void
NSUtilEditDateHeure::donneBrut()
{
	sContenuBrut = sMask ;
  //
  // On passe de AAAAMMDDhhmmss � DD/MM/AAAA hh:mm:ss
  //             01234567890123   0123456789012345678
  //
  if ((string("") != sContenuTransfert) && (strlen(sContenuTransfert.c_str()) >= 8))
    sContenuBrut = getFormatedTime(sContenuTransfert, _sLang, sFormat) ;
}

//---------------------------------------------------------------------------//  Function: 		NSEditDate::donneTransfert()
//
//  Description:	Transforme les donn�es saisies par l'utilisateur
//                en donn�es NAUTILUS
//---------------------------------------------------------------------------
void
NSUtilEditDateHeure::donneTransfert()
{
  sContenuTransfert = "" ;

  if ((sMask == sContenuBrut) || (strlen(sContenuBrut.c_str()) != strlen(sFormat.c_str())))
    return ;

  sContenuTransfert = getRawTime(sContenuBrut, _sLang, sFormat) ;
}

bool
NSUtilEditDateHeure::isFormatChar(char c)
{
  switch(c)
  {
    case 'A' :
    case 'M' :
    case 'D' :
    case 'h' :
    case 'm' :
    case 's' : return true ;
  }
  return false ;
}

////
void
NSUtilEditDateHeure::EvChar(uint key, uint repeatCount, uint flags)
{
  if (Validator && (key != VK_BACK) 	&&
                   (key != VK_RETURN) &&
                   (key != VK_SPACE) 	&&
                   (key != VK_DELETE) &&
                   (key != VK_TAB))
  {
    int oldBuffLen = GetTextLen() ;
    char far* oldBuff = new char[oldBuffLen+1] ;
    GetText(oldBuff, oldBuffLen + 1) ;

    uint startSel, endSel ;
    GetSelection(startSel, endSel) ;

    // On saute les '/'
    if ((startSel > 0) && (startSel < strlen(oldBuff)) && (strlen(oldBuff) == strlen(sFormat.c_str())))
    {
      if (false == isFormatChar(sFormat[startSel]))
      {
        startSel++ ;
        while ((startSel < strlen(oldBuff)) && (false == isFormatChar(sFormat[startSel])))
          startSel++ ;
      }
    }

    //Si la s�lection est multi-caract�res, on la ram�ne � 1 car.
    endSel = startSel ;
    SetSelection(startSel, endSel) ;

    bool wasAppending = endSel == oldBuffLen ;

    if ((!wasAppending) && (startSel == endSel))
    {
      char far* newBuff = new char[oldBuffLen+1] ;
      strcpy(newBuff, oldBuff) ;
      for (int i = startSel; i < oldBuffLen; i++)
        newBuff[i] = newBuff[i+1] ;
      SetText(newBuff) ;
      SetSelection(startSel, endSel) ;
      delete[] newBuff ;
    }

    bool preMsgModify = IsModified() ;             // Save (pre)  MODIFY flag

    TStatic::EvChar(key, repeatCount, flags) ;    // Process the new char...

    bool postMsgModify= IsModified() ;            // Save (post) MODIFY flag

    GetSelection(startSel, endSel) ;
    int buffLen = GetTextLen() ;
    char far* buff = LockBuffer(max((int)TextLimit,max(oldBuffLen,buffLen))+1) ;

    // Run the result of the edit through the validator.  If incorrect,
    // then restore the original text.  Otherwise, range check & position
    // the selection as needed.
    //
/*
    if (!Validator->HasOption(voOnAppend) || wasAppending && endSel == buffLen)
    {
*/
      if (!Validator->IsValidInput(buff, false))
      {
        strcpy(buff, oldBuff) ;          // Restore old buffer
        postMsgModify = preMsgModify ;   // Restore old modify state too!
        if (startSel > 0)
          startSel-- ;
        endSel = startSel ;
      }
      else
      {
        if (wasAppending)
          startSel = endSel = strlen(buff) ; // may have autoFilled--move to end

        bool   bChecked = true ;
        string sChecker = string(buff) ;
        size_t iPos = sFormat.find("MM") ;
        if (NPOS != iPos)
        {
          if ((startSel-1 == iPos) && (buff[iPos] > '1'))
            bChecked = false ;
          if ((startSel-1 == iPos+1) && (buff[iPos] == '1') && (buff[iPos+1] > '2'))
            bChecked = false ;
        }
        iPos = sFormat.find("DD") ;
        if (NPOS != iPos)
        {
          if ((startSel-1 == iPos) && (buff[iPos] > '3'))
            bChecked = false ;
          if ((startSel-1 == iPos+1) && (buff[iPos] == '3') && (buff[iPos+1] > '1'))
            bChecked = false ;
        }
        iPos = sFormat.find("hh") ;
        if (NPOS != iPos)
        {
          if ((startSel-1 == iPos) && (buff[iPos] > '2'))
            bChecked = false ;
          if ((startSel-1 == iPos+1) && (buff[iPos] == '2') && (buff[iPos+1] > '3'))
            bChecked = false ;
        }
        iPos = sFormat.find("mm") ;
        if (NPOS != iPos)
        {
          if ((startSel-1 == iPos) && (buff[iPos] > '5'))
            bChecked = false ;
          if ((startSel-1 == iPos+1) && (buff[iPos] == '5') && (buff[iPos+1] > '9'))
            bChecked = false ;
        }
        iPos = sFormat.find("ss") ;
        if (NPOS != iPos)
        {
          if ((startSel-1 == iPos) && (buff[iPos] > '5'))
            bChecked = false ;
          if ((startSel-1 == iPos+1) && (buff[iPos] == '5') && (buff[iPos+1] > '9'))
            bChecked = false ;
        }
        if (false == bChecked)
        {
          strcpy(buff, oldBuff) ;          // Restore old buffer
          postMsgModify = preMsgModify ;   // Restore old modify state too!

          if (startSel > 0)
            startSel-- ;
          endSel = startSel ;
        }
      }
      UnlockBuffer(buff, true) ;
      SetSelection(startSel, endSel) ;
/*
    }
    else
    {
      if (endSel == buffLen && !Validator->IsValidInput(buff, true))
        Validator->Error(this) ;
      UnlockBuffer(buff) ;
    }
*/
    SendMessage(EM_SETMODIFY, (TParam1)postMsgModify) ;

    //
    // On saute les caract�res inutiles
    //
    GetSelection(startSel, endSel) ;
    if ((startSel == endSel) && (startSel < strlen(oldBuff)) && (strlen(oldBuff) == strlen(sFormat.c_str())-1))
    {
      if (false == isFormatChar(sFormat[startSel]))
      {
        startSel++ ;
        while ((startSel < strlen(oldBuff)) && (false == isFormatChar(sFormat[startSel])))
          startSel++ ;
      }
      SetSelection(startSel, startSel) ;
    }
    delete[] oldBuff ;
  }
  else if (key == VK_BACK)
  {
    uint startSel, endSel ;
    GetSelection(startSel, endSel) ;

    int oldBuffLen = GetTextLen() ;
    char far* oldBuff = new char[oldBuffLen+1] ;
    GetText(oldBuff, oldBuffLen+1) ;

    // On saute les '/'
    if ((startSel > 0) && (startSel < strlen(oldBuff)) && (strlen(oldBuff) == strlen(sFormat.c_str())))
    {
      if (false == isFormatChar(sFormat[startSel-1]))
      {
        startSel-- ;
        while ((startSel > 0) && (false == isFormatChar(sFormat[startSel-1])))
          startSel-- ;
      }
    }

    string dateVide = sMask ;
    if (startSel > 0)
    {
      startSel-- ;
      oldBuff[startSel] = dateVide[startSel] ;
    }
    endSel = startSel ;
    SetText(oldBuff) ;
    SetSelection(startSel, endSel) ;
    delete[] oldBuff ;
  }
  else if ((key == VK_RETURN) || (key == VK_TAB) || (key == VK_SPACE))
    //Process this message to avoid message beeps.
    return ;
  else
    TStatic::EvChar(key, repeatCount, flags) ;
}

void
NSUtilEditDateHeure::EvKeyDown(uint key, uint repeatCount, uint flags)
{
  if (VK_DELETE == key)
  {
    uint startSel, endSel ;
    GetSelection(startSel, endSel) ;

    int oldBuffLen = GetTextLen() ;
    char far* oldBuff = new char[oldBuffLen+1] ;
    GetText(oldBuff, oldBuffLen+1) ;

    string dateVide = sMask ;
    string dateEdit = string(oldBuff) ;

    if (startSel == endSel)
    {
      dateEdit.replace(startSel, 1, dateVide, startSel, 1) ;
      startSel++ ;
      endSel++ ;
    }
    else
    {
      dateEdit.replace(startSel, endSel-startSel, dateVide, startSel, endSel-startSel) ;
      startSel = endSel ;
    }

    strcpy(oldBuff, dateEdit.c_str()) ;

    SetText(oldBuff) ;
    SetSelection(startSel, endSel) ;
    delete[] oldBuff ;
  }
  else
    TStatic::EvKeyDown(key, repeatCount, flags) ;
}

// ----------------------------------------------------------------------
//
//           					classe NSUtilEditSomme
//
// ----------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSUtilEditSomme, NSUtilEdit)   EV_WM_CHAR,
   EV_WM_KEYDOWN,
END_RESPONSE_TABLE;

//// Constructeur
//
NSUtilEditSomme::NSUtilEditSomme(NSContexte* pCtx, NSUtilDialog* parent, int resId, uint iTextLen, string sLang)
                :NSUtilEdit(pCtx, parent, resId, iTextLen)
{
  _sLang = sLang ;

	textLen = iTextLen ;

	if (textLen < 4)
		erreur("La longueur du champ EditSomme est trop courte.", standardError, 0) ;

    /*********************************************
	// Mise en place du validateur
	//
    char* cValidateur = new char[textLen + 1];

    for (int i = 0; i < textLen; i++)
   	    cValidateur[i] = '#';

    cValidateur[textLen + 1] = '\0';

    cValidateur[textLen - 2] = sommeSeparationMARK;
    SetValidator(new TPXPictureValidator(cValidateur));
	delete[] cValidateur;
    ***************************************************/

    sZero = "";

    for (int i = 0; i < 4; i++)
   	    sZero += ' ';

    sZero[0] = '0' ;
    sZero[1] = sommeSeparationMARK ;
    sZero[2] = '0' ;
    sZero[3] = '0' ;

    sContenuTransfert = "" ;
}

//// Destructeur
//
NSUtilEditSomme::~NSUtilEditSomme()
{
}

void
NSUtilEditSomme::SetupWindow()
{
   NSUtilEdit::SetupWindow();
	donneBrut();
   SetText(sContenuBrut.c_str());
}

voidNSUtilEditSomme::setSomme(string sSomme)
{
	sContenuTransfert = sSomme;
   donneBrut();
   SetText(sContenuBrut.c_str());
}

void
NSUtilEditSomme::getSomme(string* pSomme)
{
    int iBuffLen = GetTextLen();
    char far* pszBuff = new char[iBuffLen + 1];
    GetText(pszBuff, iBuffLen + 1);
    sContenuBrut = string(pszBuff);
    delete[] pszBuff;

	donneTransfert();
    *pSomme = sContenuTransfert;
}

//---------------------------------------------------------------------------
//  Function: 		NSUtilEditSomme::donneBrut()
//
//  Description:	Transforme les donn�es NAUTILUS en donn�es � saisir par
//						l'utilisateur
//---------------------------------------------------------------------------
void
NSUtilEditSomme::donneBrut()
{
    int   transfert;
    char  nbDec[3];
    char* nbEnt = new char[textLen - 2];

	sContenuBrut = sZero;

    //
    // On passe d'un montant en centimes � un montant en francs
    //
    if (sContenuTransfert != "")
    {
   	    transfert = atoi(sContenuTransfert.c_str());
        sprintf(nbEnt, "%d", transfert/100);
        sprintf(nbDec, "%02d", transfert%100);

        sContenuBrut = string(nbEnt) + string(1,sommeSeparationMARK) + string(nbDec);
    }

    delete[] nbEnt;
}

//---------------------------------------------------------------------------//  Function: 		NSEditDate::donneTransfert()
//
//  Description:	Transforme les donn�es saisies par l'utilisateur
//					   en donn�es NAUTILUS
//---------------------------------------------------------------------------
void
NSUtilEditSomme::donneTransfert()
{
	size_t i ;

	sContenuTransfert = "" ;

	//
	// On passe d'un montant en franc � un montant en centimes
	//
	if (!(sContenuBrut == sZero))
	{
  	for (i = 0; (i < strlen(sContenuBrut.c_str())) && (sContenuBrut[i] != ','); i++)
    	sContenuTransfert += sContenuBrut[i] ;

		if ((i < strlen(sContenuBrut.c_str())) && (sContenuBrut[i] == ','))
    	i++ ;

    int j = 0;
    for (; i < strlen(sContenuBrut.c_str()); i++, j++)
    	sContenuTransfert += sContenuBrut[i] ;
    for (; j < 2; j++)
    	sContenuTransfert += "0" ;
	}
}

//
//  TStatic
//
void
NSUtilEditSomme::EvChar(uint key, uint repeatCount, uint flags)
{
    int 	  oldBuffLen = GetTextLen();
    char far* oldBuff = new char[textLen + 1];
    uint   	  startSel, endSel;
    int		  posvir;
    int		  nbMaxEntier = textLen - 3;

    GetText(oldBuff, oldBuffLen + 1);
    GetSelection(startSel, endSel);

    string sEntree = oldBuff;

    // Si la s�lection est multi-caract�res, on la ram�ne � 1 car.
    //endSel = startSel;
    //SetSelection(startSel, endSel);

    // Recherche de la virgule
    for (	posvir = 0;
   		(posvir < oldBuffLen) && (oldBuff[posvir] != sommeSeparationMARK);
         posvir++ );

    if (posvir == oldBuffLen)
        posvir = -1;

    // Le caract�re tap� est un chiffre
    //
    if ((key >= '0') && (key <= '9'))
    {
        bool bEcraser = false;
        bool bBeep = false;

        // s'il y a une virgule...
        if (posvir >= 0)
        {
      	    // si on est avant
      	    if (startSel <= posvir)
            {
         	    if (posvir == nbMaxEntier)
                {
            	    if (startSel == posvir)
               	        startSel += 1;

                    bEcraser = true;
                }
            }
            else // apr�s la ','
            {
         	    // si le nombre max apr�s la ',' est atteint
         	    if ((oldBuffLen - posvir - 1) == 2)
                {
                    if (startSel < posvir + 3)
            		    bEcraser = true;
                    else
               	        bBeep = true;
                }            }
        }
        else // nombre sans ','
        {
      	    if (oldBuffLen == nbMaxEntier)
            {
                oldBuff[oldBuffLen] = sommeSeparationMARK;
                oldBuff[oldBuffLen + 1] = '0';
                oldBuff[oldBuffLen + 2] = '0';
                oldBuff[oldBuffLen + 3] = '\0';

                startSel = oldBuffLen + 1;
                oldBuffLen += 3;
                bEcraser = true;
            }
        }

  		if (bEcraser)
    	{
    		for (int i = startSel; i < oldBuffLen; i++)
         	    oldBuff[i] = oldBuff[i+1];
            SetText(oldBuff);
            SetSelection(startSel, endSel);
        }

        if (!bBeep)
        {
    		TStatic::EvChar(key, repeatCount, flags);     // Process the new char...
        }
        else
        {
      	    ::MessageBeep(0);     // BEEP
        }
    }
    else if ((key == ',') || (key == '.'))
    {
        if (posvir == -1)
        {
            int nbDecim = oldBuffLen - endSel;
            if (nbDecim > 2)
                ::MessageBeep(0);     // BEEP
            else if (nbDecim == 0)
            {
                string sResult;
                if (startSel == 0)
                    sResult = "0" + string(1, sommeSeparationMARK) + "00";
                else
                    sResult = string(sEntree, 0, startSel) +
                              string(1, sommeSeparationMARK) + "00";

                strcpy(oldBuff, sResult.c_str());
                SetText(oldBuff);
                startSel++;
                SetSelection(startSel, startSel);
            }
            else
            {
                string sResult;
                if (startSel == 0)
                    sResult = "0" +
                              string(1, sommeSeparationMARK) +
                              string(sEntree, endSel, nbDecim);
                else
                    sResult = string(sEntree, 0, startSel) +
                              string(1, sommeSeparationMARK) +
                              string(sEntree, endSel, nbDecim);

                strcpy(oldBuff, sResult.c_str());
                SetText(oldBuff);
                startSel++;
                SetSelection(startSel, startSel);
            }
        }
        else
        {
      	    ::MessageBeep(0);     // BEEP
        }
    }
    else if (key == VK_BACK)
    {
        // Si des caract�res sont s�lectionn�s, Back fonctionne comme Suppr
        //
        if (endSel > startSel)
        {
            string sResult = "";
            if (startSel > 0)
                sResult = string(sEntree, 0, startSel);
            int nbDecim = oldBuffLen - endSel;
            if (nbDecim > 0)
                sResult += string(sEntree, endSel, nbDecim);
            strcpy(oldBuff, sResult.c_str());
            SetText(oldBuff);
            SetSelection(startSel, startSel);
        }
   	    else if (startSel > 0)
        {
      	    // On saute la ',' si le nombre de chiffres peut d�passer nbMaxEntier
      	    if ((startSel == posvir + 1) && (oldBuffLen > nbMaxEntier + 1))
      		    startSel = posvir;

            if (startSel > 0)
         	    startSel -= 1;

   		    for (int i = startSel; i < oldBuffLen; i++)
         	    oldBuff[i] = oldBuff[i+1];
      	    SetText(oldBuff);
      	    SetSelection(startSel, startSel);
        }
        else
        {
      	    ::MessageBeep(0);     // BEEP
        }
    }
    else if ((key == VK_RETURN) || (key == VK_TAB))
    {
   	//Process this message to avoid message beeps.
        delete[] oldBuff;
        return ;
    }
    else if ((key == VK_SPACE))
    {
   	//Process this message to avoid message beeps.
        delete[] oldBuff;
        return ;
    }
    else
    {
   	    ::MessageBeep(0);     // BEEP
    }

    delete[] oldBuff;
}

voidNSUtilEditSomme::EvKeyDown(uint key, uint repeatCount, uint flags)
{
	int 	  oldBuffLen = GetTextLen();
    char far* oldBuff = new char[textLen + 1];
    uint   	  startSel, endSel;
    int		  posvir;
    int		  nbMaxEntier = textLen - 3;

    GetText(oldBuff, oldBuffLen + 1);
    GetSelection(startSel, endSel);

    //Si la s�lection est multi-caract�res, on la ram�ne � 1 car.
    //endSel = startSel;
    //SetSelection(startSel, endSel);

    for (posvir = 0;
   		(posvir < oldBuffLen) && (oldBuff[posvir] != sommeSeparationMARK);
         posvir++ );

    if (posvir == oldBuffLen)
        posvir = -1;

    if (key == VK_DELETE)
    {
        if (startSel < oldBuffLen)
        {
            if ((startSel == posvir) && (oldBuffLen > nbMaxEntier + 1))
         	    startSel += 1;

            int nbCar = endSel - startSel;
            for (int j = 0; j < nbCar; j++)
            {
      	        for (int i = startSel; i < oldBuffLen; i++)
         	        oldBuff[i] = oldBuff[i+1];
                startSel++;
            }
      	    SetText(oldBuff);
      	    SetSelection(startSel, startSel);
        }
        else
        {
      	    ::MessageBeep(MB_ICONEXCLAMATION);     // BEEP
        }
    }
    else
        TStatic::EvKeyDown(key, repeatCount, flags);

    delete[] oldBuff;
}

bool
NSUtilEditSomme::estValide(string sTest)
{
	string sEntier = "0" ;
	string sDecima = "" ;
	// Recherche de la virgule
	size_t posvir = sTest.find(string(1, sommeSeparationMARK)) ;
	if (posvir != NPOS)	{
		int iTaille = strlen(sTest.c_str()) ;

    if (posvir > 0)
    	sEntier = string(sTest, 0, posvir);
    if (posvir < iTaille - 1)
    {
    	sDecima = string(sTest, posvir + 1, iTaille - posvir) ;
      // Y-a-t'il deux vigules ?
      int biposvir = sDecima.find(string(1, sommeSeparationMARK)) ;
      if (biposvir != NPOS)
      	return false ;
    }
	}
  return true ;
}

//**********************************************************************// classe NSUtilLexique : acc�s g�n�rique au lexique
//**********************************************************************

DEFINE_RESPONSE_TABLE1(NSUtilLexique, NSEditDicoGlobal)
	EV_WM_CHAR,
	EV_WM_KEYDOWN,
  EV_WM_GETDLGCODE,
  EV_WM_SETFOCUS,
	EV_WM_KILLFOCUS,
END_RESPONSE_TABLE;

//
// Constructeurs
//
NSUtilLexique::NSUtilLexique(NSContexte* pCtx, TWindow* parent, int resId, NSDico* pDictio,
                     uint textLen, TModule* module)
              :NSEditDicoGlobal(pCtx, parent, resId, pDictio, "", textLen, module)
{
  sContenuTransfert = "" ;
  sCode = "" ;
  _LostFocusFunctor = NULL ;
}

NSUtilLexique::NSUtilLexique(NSContexte* pCtx, NSUtilDialog* pUtilDialog, int resId, NSDico* pDictio,
                     uint textLen, TModule* module)
              :NSEditDicoGlobal(pCtx, pUtilDialog, resId, pDictio, "", textLen, module)
{
  pNSUtilDialog = pUtilDialog ;
  pNSUtilDialog->ReferenceControl(this) ;
  sContenuTransfert = "" ;
  sCode = "" ;
  _LostFocusFunctor = NULL ;
}

NSUtilLexique::NSUtilLexique(NSContexte* pCtx, TWindow* parent, int resourceId, NSDico* pDictio,
                       const char far* text,
                       int x, int y, int w, int h,
                       uint textLimit, bool multiline, TModule* module)
              :NSEditDicoGlobal(pCtx, parent, resourceId, pDictio, text, x, y, w, h,
                       textLimit, multiline, "", module)
{
  sContenuTransfert = "" ;
  sCode = "" ;
  _LostFocusFunctor = NULL ;
}

NSUtilLexique::NSUtilLexique(NSContexte* pCtx, NSUtilDialog* pUtilDialog, int resourceId, NSDico* pDictio,
                       const char far* text,
                       int x, int y, int w, int h,
                       uint textLimit, bool multiline, TModule* module)
              :NSEditDicoGlobal(pCtx, pUtilDialog,resourceId, pDictio, text, x, y, w, h,
                       textLimit, multiline, "", module)
{
  pNSUtilDialog = pUtilDialog ;
  pNSUtilDialog->ReferenceControl(this) ;
  sContenuTransfert = "" ;
  sCode = "" ;
  _LostFocusFunctor = NULL ;
}

NSUtilLexique::~NSUtilLexique()
{
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSUtilLexique::SetupWindow()
{
  NSEditDicoGlobal::SetupWindow() ;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSUtilLexique::UpdateDico()
{
  //
  // R�cup�ration du contenu du contr�le
  //
  int oldBuffLen = GetTextLen() ;
	char far* oldBuff = new char[oldBuffLen+1] ;
  GetText(oldBuff, oldBuffLen+1) ;
  string sContenu = string(oldBuff) ;
  delete[] oldBuff ;

  strip(sContenu) ;
  //
  // Transmission du contenu � la boite de dialogue
  //
	int OouF = pDico->pDicoDialog->DonneAmmorce(&sContenu) ;
  if (OouF == 1)
  {
    bGardeFocus = true ;
    //position du lexique
    NS_CLASSLIB::TRect rectPere = Parent->GetWindowRect() ;
    NS_CLASSLIB::TRect rectEdition = GetWindowRect() ;

    int x = Attr.X + Attr.W + rectPere.left  + 50 ;
    int y = rectEdition.top ;

    NS_CLASSLIB::TRect rectLex = pDico->pDicoDialog->GetWindowRect() ;
    pDico->pDicoDialog->SetWindowPos(0,x,y,rectLex.Width(),rectLex.Height(),SWP_NOZORDER) ;
    pDico->pDicoDialog->montrerDialogue() ;
    SetFocus() ;
  }
  else if (OouF == 2)
    pDico->pDicoDialog->cacherDialogue() ;
}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
void
NSUtilLexique::EvChar(uint key, uint repeatCount, uint flags)
{
    TEdit::EvChar(key, repeatCount, flags);
    //
    // Transmission du contenu � la boite de dialogue
    //
    if (key == VK_RETURN)
        return;
    else
    {
   	    //fl�che basse
   	    if (key == VK_DOWN)
        {
      	    if (pDico->pDicoDialog->sAmmorce == "")
                return;
            // sinon r�cup�rer un �l�ment dans le lexique
            else
         	    pDico->pDicoDialog->ElementSuivant();
        }

        //fl�che haut
        else if(key == VK_UP)
        {
            //si ammorce vide alors passer au NStrreNode suivant
      	    if (pDico->pDicoDialog->sAmmorce == "")
				return;
			//sinon r�cup�rer un �l�ment dans le lexique
            else
         	    pDico->pDicoDialog->ElementPrecedent();
        }
        else if(key == VK_INSERT)
      	    pDico->pDicoDialog->InsererElementLexique();
   	    else
      	    UpdateDico();
    }
}

//---------------------------------------------------------------------------//---------------------------------------------------------------------------
void
NSUtilLexique::EvKeyDown(uint key, uint repeatCount, uint flags)
{
    TEdit::EvKeyDown(key, repeatCount, flags);
    Parent->SendNotification(Attr.Id, 200, HWindow);
    //
    // Transmission du contenu � la boite de dialogue
    //
    //fl�che basse
   	if (key == VK_DOWN)
    {
        if (pDico->pDicoDialog->sAmmorce == "")
            return;
        else
            pDico->pDicoDialog->ElementSuivant();
    }

    //fl�che haut
    else if (key == VK_UP)
    {
        //si ammorce vide alors passer au NStrreNode suivant
        if (pDico->pDicoDialog->sAmmorce == "" )
            return;
        else
            pDico->pDicoDialog->ElementPrecedent();
    }
    else if ((key == VK_INSERT) || (key == VK_RETURN))
        pDico->pDicoDialog->InsererElementLexique();
    else if (key == VK_F1)
    {
        NSUtilDialog* pUtilDlg = TYPESAFE_DOWNCAST(Parent, NSUtilDialog);
        if ( pUtilDlg )
          pUtilDlg->EvKeyDown(key, repeatCount, flags);
    }
   	else
      	UpdateDico();
}

//fonction permettant � la touche ENTREE d'avoir le m�me effet que TABvoid
NSUtilLexique::EvKeyUp(uint key, uint repeatcount, uint flags)
{
    THandle NextControl = 0;
    switch (key)
    {
        //return
        case VK_RETURN :
            //
            // demander � la bo�te de dialogue m�re d'activer le controle
            // suivant pControle sinon le premier
            //
            /*if (pControle && pControle->getNSDialog())
                pControle->getNSDialog()->ActiveControlSuivant(pControle);
            else
            {
                if (parentEdit->Parent->ChildWithId(1))
                    parentEdit->Parent->ChildWithId(1)->SetFocus();
                else
                    parentEdit->CloseWindow(IDOK);
            } */
            break;

        default		:
            TEdit::EvKeyUp(key, repeatcount, flags);
    }
}

//fonction permettant � la touche ENTREE d'avoir le m�me effet que TAB
uint
NSUtilLexique::EvGetDlgCode(MSG far* msg)
{
	uint retVal = (uint)DefaultProcessing() ;

	if (msg && (msg->wParam == VK_RETURN))
	{
		if (pDico && pDico->pDicoDialog && pDico->pDicoDialog->IsWindow())
			pDico->pDicoDialog->InsererElementLexique() ;
		retVal |= DLGC_WANTALLKEYS ;
	}
	return retVal ;
}

//-------------------------------------------------------------------------// 					l'utilisateur a choisi un �l�ment dans le lexique
//-------------------------------------------------------------------------
void
NSUtilLexique::ElementSelectionne()
{
	char code[BASE_LEXI_LEN+1] ;
	GetCodeLexiqueChoisi(code) ;
	GetLabelChoisi(&sContenuTransfert) ;
	SetText(sContenuTransfert.c_str()) ;
	sCode = string(code) ;
	pDico->pDicoDialog->cacherDialogue() ;
}

void
NSUtilLexique::setLabel(string code, string texteFictif)
{
    sCode = code;

    if (sCode != "")
    {
        string sLang = "";
        if (pDico->pContexte->getUtilisateur())
            sLang = pDico->pContexte->getUtilisateur()->donneLang();

        pDico->donneLibelle(sLang, &sCode, &sContenuTransfert);
    }
    else
        sContenuTransfert = "";

    // texteFictif est utilis� pour r�soudre le probl�me des jokers
    // Dans ce cas sContenuTransfert est vide et on peut alors
    // forcer sa valeur avec texteFictif != "" pour que l'on ne
    // change pas la valeur de sCode sur le KillFocus.
    if (texteFictif != "")
        sContenuTransfert = texteFictif;

    SetText(sContenuTransfert.c_str());
}

//------------------------------------------------------------------------
// le champ edit perd son focus
//------------------------------------------------------------------------
void
NSUtilLexique::EvKillFocus(HWND hWndGetFocus)
{
	//
	// R�cup�re le texte
	//
	int oldBuffLen = GetTextLen() ;
	char far* str = new char[oldBuffLen + 1] ;
	GetText(str, oldBuffLen + 1) ;
	string sContenu = string(str) ;
	delete[] str ;

	//
	// si le texte recup�r� est != de sContenuTransfert c'est qu'il s'agit d'un texte libre
	// mettre dans sCode string("�?????")
	//
	if (!(sContenu == sContenuTransfert))
		sCode = string("�?????") ;

	if (hWndGetFocus != HWindow)
	{
		if ((pDico->pDicoDialog) && (hWndGetFocus != pDico->pDicoDialog->HWindow) &&
			  (!(pDico->pDicoDialog->IsChild(hWndGetFocus))))
		{
    	pDico->pDicoDialog->cacherDialogue() ;
			NSEditDicoGlobal::EvKillFocus(hWndGetFocus) ;
			if (NULL != _LostFocusFunctor)
				(*_LostFocusFunctor)() ;
		}
		else
			TEdit::EvKillFocus(hWndGetFocus) ;
	}
}

voidNSUtilLexique::EvSetFocus(HWND hWndLostFocus)
{
	NSEditDicoGlobal::EvSetFocus(hWndLostFocus) ;
}

/*********************************************************************/
/*                        CLASSES NSUTILUPDOWN                       */
/*********************************************************************/

DEFINE_RESPONSE_TABLE1(NSUtilEditNumSimpl, TEdit)
   // EV_WM_SETFOCUS,
   EV_WM_KEYUP,
   EV_WM_KEYDOWN,
   EV_WM_CHAR,
   EV_WM_GETDLGCODE,
END_RESPONSE_TABLE;

NSUtilEditNumSimpl::NSUtilEditNumSimpl(NSContexte* pCtx, TWindow *windowParent, int resId, NSUtilUpDownEdit *NSparent)
                   :TEdit(windowParent, resId), NSRoot(pCtx)
{
    pFather     = NSparent ;
    pDlgParent  = windowParent;
}

NSUtilEditNumSimpl::~NSUtilEditNumSimpl()
{
}

void
NSUtilEditNumSimpl::incremente()
{
  int  iBuffLen = GetTextLen() ;
  char *pszBuff = new char[iBuffLen + 1] ;
  GetText(pszBuff, iBuffLen + 1) ;
  string sContenu = string(pszBuff) ;
  delete pszBuff ;

  int iContenu = atoi(sContenu.c_str()) ;

  iContenu++ ;

  char szNewContenu[255] ;
  itoa(iContenu, szNewContenu, 10) ;

  sContenu = string(szNewContenu) ;
  SetText(sContenu.c_str()) ;
}

void
NSUtilEditNumSimpl::decremente()
{
  int  iBuffLen = GetTextLen() ;
  char *pszBuff = new char[iBuffLen + 1] ;
  GetText(pszBuff, iBuffLen + 1) ;
  string sContenu = string(pszBuff) ;
  delete pszBuff ;

  int iContenu = atoi(sContenu.c_str()) ;

  if (iContenu > 0)
      iContenu-- ;

  char szNewContenu[255] ;
  itoa(iContenu, szNewContenu, 10) ;

  sContenu = string(szNewContenu) ;
  SetText(sContenu.c_str()) ;
}

void
NSUtilEditNumSimpl::setVal(int iValue)
{
  // 23 est le nombre de digit maximal renvoy� par atoi
  char *pszBuff = new char[23 + 1] ;

  int       i = 0 ;
  while (iValue > 9)
  {
    pszBuff[i++] = (char) ((iValue / 10) + '0') ;
    iValue       = iValue % 10 ;
  }
  pszBuff[i++] = (char) (iValue + '0') ;
  pszBuff[i] = '\0' ;
  SetText(pszBuff) ;

  delete[] pszBuff ;
}

int
NSUtilEditNumSimpl::getVal()
{
  int       iBuffLen = GetTextLen() ;
  char far  *pszBuff = new char[iBuffLen + 1] ;
  GetText(pszBuff, iBuffLen + 1) ;

  size_t    iLen      = strlen(pszBuff) ;
  int       iVal      = 0 ;
  for (size_t i = 0 ; i != iLen ; i++)
    iVal = iVal * 10 + (pszBuff[i] - '0') ;

  delete[] pszBuff ;

  return iVal ;
}

void
NSUtilEditNumSimpl::EvKeyDown(uint key, uint repeatCount, uint flags)
{
  NSUtilDialog* pNSUtilDialog = TYPESAFE_DOWNCAST(pDlgParent, NSUtilDialog) ;
  if (NULL == pNSUtilDialog)
    return ;

  switch(key)
  {
    case VK_TAB	:
        pNSUtilDialog->ActiveControlSuivant(this) ;
        break ;
    case VK_RETURN  :
    case VK_DOWN  :
        pNSUtilDialog->ActiveControlSuivant(this) ;
        break ;
    default       :
        TEdit::EvKeyDown(key, repeatCount, flags) ;
  }
}


void
NSUtilEditNumSimpl::EvKeyUp(uint key, uint repeatcount, uint flags)
{
  NSUtilDialog* pNSUtilDialog = TYPESAFE_DOWNCAST(pDlgParent, NSUtilDialog);
  if (NULL == pNSUtilDialog)
    return ;

  switch(key)
  {
    //return
    case VK_RETURN :
    case VK_DOWN   :
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // suivant pControle sinon le premier
      //
      pNSUtilDialog->ActiveControlSuivant(this) ;

    default       :

      TEdit::EvKeyUp(key, repeatcount, flags) ;
  }
}

void
NSUtilEditNumSimpl::EvChar(uint key, uint repeatCount, uint flags)
{
  TEdit::EvChar(key, repeatCount, flags) ;     // Process the new char...
}

//fonction permettant � la touche ENTREE d'avoir le m�me effet que TAB
uint
NSUtilEditNumSimpl::EvGetDlgCode(MSG far* /* msg */)
{
	uint retVal = (uint)DefaultProcessing() ;
  retVal |= DLGC_WANTALLKEYS ;
  return retVal ;
}

void
NSUtilEditNumSimpl::SetupWindow()
{
	TEdit::SetupWindow() ;
}

//------------------------------------------------------------------------------
//                     classe  NSUtilUpDown
//------------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSUtilUpDown, TUpDown)
  EV_WM_LBUTTONDOWN,
END_RESPONSE_TABLE ;


NSUtilUpDown::NSUtilUpDown(NSContexte* pCtx, TWindow *windowParent, int resId, NSUtilUpDownEdit *parent)
             :TUpDown(windowParent, resId), NSRoot(pCtx)
{
  pFather = parent ;
}


NSUtilUpDown::~NSUtilUpDown()
{
}

void
NSUtilUpDown::EvLButtonDown(uint /* modKeys */, ClassLib::TPoint& point)
{
	ClassLib::TRect rect ;
	uint            state = GetSpinRectFromPoint(rect, point) ;
	if      (state == csIncrement)
		pFather->getEditNum()->incremente() ;
	else if (state == csDecrement)
		pFather->getEditNum()->decremente() ;
}

void
NSUtilUpDown::SetupWindow()
{
  TUpDown::SetupWindow() ;
}

//------------------------------------------------------------------------------
//                      classe  NSUtilUpDownEdit
//------------------------------------------------------------------------------

NSUtilUpDownEdit::NSUtilUpDownEdit(TWindow *windowParent, NSContexte* pCtx, int resEditId, int resUpDownId)
                 :NSRoot(pCtx)
{
	pEditNumControl = new NSUtilEditNumSimpl(pContexte, windowParent, resEditId, this) ;
	pUpDownControl  = new NSUtilUpDown(pContexte, windowParent, resUpDownId, this) ;
}


NSUtilUpDownEdit::~NSUtilUpDownEdit()
{
  delete pEditNumControl ;
  delete pUpDownControl ;
}

//-------------------------------------------------------------------------

