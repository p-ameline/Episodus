#include "nautilus\nssuper.h"
#include "nsbb\nschkbox.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbbtran.h"
#include "nsbb\nsbb_dlg.h"
#include "nsbb\nsdlg.h"

DEFINE_RESPONSE_TABLE1(NSCheckBox, TCheckBox)
	EV_NOTIFY_AT_CHILD(BN_CLICKED, BNClicked),
  EV_WM_KEYUP,
END_RESPONSE_TABLE;

//
// Constructeur
//
NSCheckBox::NSCheckBox(NSContexte *pCtx, TWindow* parent, int resId, TGroupBox* group)
           :TCheckBox(parent, resId, group), NSRoot(pCtx)
{
  pControle = 0 ;
  ActiveToi = true ;
	DisableTransfer() ;
}

NSCheckBox::NSCheckBox(NSContexte *pCtx, TWindow* parent, int resId, const char far* title,
                             int x, int y, int w, int h, TGroupBox *group,
                             TModule* module)
           :TCheckBox(parent, resId, title, x, y, w, h, group, module), NSRoot(pCtx)
{
  pControle = 0 ;
  ActiveToi = true ;
	DisableTransfer() ;
  //
  // Attention, le constructeur de TCheckBox employ� ici attribue le style
  // BS_AUTOCHECKBOX, que nous rempla�ons par BS_CHECKBOX
  //
  Attr.Style    = (Attr.Style ^ BS_AUTOCHECKBOX) | BS_CHECKBOX ;
  Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;
  SetWindowFont(*(pSuper->getDialogFont()), false) ;
}

//
// Destructeur
//
NSCheckBox::~NSCheckBox()
{
  if ((pControle) && (pControle->getControle()))
    pControle->setControle(0) ;
}

void
NSCheckBox::SetupWindow()
{
	TCheckBox::SetupWindow() ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;
  SetWindowFont(*(pSuper->getDialogFont()), false) ;
}

bool
NSCheckBox::canWeClose()
{
	return true ;
}

void
NSCheckBox::activeControle(int activation, Message* /* pMessage */)
{
	SetCheck(activation) ;
}

//
// Fonction d�clench�e lorsque la boite � cocher est activ�e.
//void
NSCheckBox::BNClicked()
{
  if (!ActiveToi)
  {
    ActiveToi = true ;
    return ;
  }
	//
	// Pr�vient Big Brother
	//
  if (GetCheck() == BF_CHECKED)
  {
    if (pControle->getTransfert())
      pControle->getTransfert()->ctrlNotification(BF_CHECKED, BF_UNCHECKED) ;
  }
	else
  {
    if (pControle->getFonction())
      pControle->getFonction()->execute(NSDLGFCT_EXECUTE) ;

    if (pControle->getTransfert())
      pControle->getTransfert()->ctrlNotification(BF_UNCHECKED, BF_CHECKED) ;

    if (pControle->getFonction())
      pControle->getFonction()->execute(NSDLGFCT_POSTEXEC) ;
  }

  string sEtiquette = string("") ;
  if (pControle->getTransfert())
    sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

	TCheckBox::BNClicked() ;
}

//---------------------------------------------------------------------------
//  Function: 		NSCheckBox::Transfer(TTransferDirection direction,
//																int* pActif, string* pMessage)
//
//  Description:	Si direction = tdSetData
//							Initialise le contr�le
//						Si direction = tdGetData
//							Initialise pActif et pMessage
//
//  Arguments:		direction : tdGetData ou tdSetData
//
//  Returns:		1 si le transfert a fonctionn�
//						0 sinon
//---------------------------------------------------------------------------
uint
NSCheckBox::Transferer(TTransferDirection direction, int* pActif,
                                                            Message* pMessage)
{
	if (direction == tdSetData)
	{
    switch (*pActif)
    {
      case  0 : SetCheck(BF_UNCHECKED) ; break ;
      case  1 : SetCheck(BF_CHECKED) ;   break ;
      default : SetCheck(BF_GRAYED) ;    break ;
		}
	}
	else if (direction == tdGetData)
	{
		switch (GetCheck())
    {
      case BF_UNCHECKED : *pActif =  0 ; break ;
      case BF_CHECKED   : *pActif =  1 ; break ;
      case BF_GRAYED 	  : *pActif = -1 ; break ;
		}

    if (pMessage)
    {
      string sEtiquette = string("") ;
      if (pControle->getTransfert())
        sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

      pMessage->MettreAJourCertitudePluriel(sEtiquette) ;
    }
  }
  return 1 ;
}

uint
NSCheckBox::TempTransferer(int* pActif, Message* pMessage)
{
  switch (GetCheck())
  {
    case BF_UNCHECKED : *pActif =  0 ; break ;
    case BF_CHECKED   : *pActif =  1 ; break ;
    case BF_GRAYED 	  : *pActif = -1 ; break ;
  }

  if (pMessage)
  {
    string sEtiquette = string("") ; 
    if (pControle->getTransfert())
      sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

    pMessage->MettreAJourCertitudePluriel(sEtiquette) ;
  }

  return 1 ;
}

void
NSCheckBox::EvKeyUp(uint key, uint repeatcount, uint flags)
{
  // Gestion windows standard
  // Windows standard behaviour
  if (pControle->getNSDialog())
  {
    // return TEdit::EvKeyUp(key, repeatcount, flags) ;
    TCheckBox::EvKeyUp(key, repeatcount, flags) ;
    return ;
  }

  // THandle NextControl = 0;
  switch (key)
  {
    //return
    case VK_DOWN   :
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // suivant pControle sinon le premier
      //
      if (pControle && pControle->getNSDialog())
        pControle->getNSDialog()->ActiveControlSuivant(pControle) ;
      else if (pControle && pControle->getMUEView())
        pControle->getMUEView()->SetFocusToNextControl((TControl*)this) ;
      break ;

    case VK_UP    :
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // pr�c�dent pControle sinon le dernier
      //
      if (pControle && pControle->getNSDialog())
        pControle->getNSDialog()->ActiveControlPrecedent(pControle) ;
      else if (pControle && pControle->getMUEView())
        pControle->getMUEView()->SetFocusToPreviousControl((TControl*)this) ;
      break ;

    //tabulation
    case VK_TAB	:
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // suivant pControle sinon le premier
      //
      if (pControle && pControle->getNSDialog())
        pControle->getNSDialog()->ActiveControlSuivant(pControle) ;
      else if (pControle && pControle->getMUEView())
      {
        if (GetKeyState(VK_SHIFT) < 0)
          pControle->getMUEView()->SetFocusToPreviousControl((TControl*)this) ;
        else
          pControle->getMUEView()->SetFocusToNextControl((TControl*)this) ;
      }
      break ;

    default		:
      TCheckBox::EvKeyUp(key, repeatcount, flags) ;
      return ;
  }
}

