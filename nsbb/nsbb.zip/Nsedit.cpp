#include <owl\checkbox.h>
#include "nsbb\nsedit.h"
#include "partage\nsdivfct.h"
// #include "partage\nsperson.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbbsmal.h"
#include "nsbb\nsbbtran.h"
#include "nsbb\nsutiDlg.h"
#include "nsbb\nslistwind.h"
#include "nsbb\nsdlg.h"
#include "nautilus\nsepicap.h"

const char codeMARK   = 'O' ;

const char decimSepar = ',' ;   // Edit double bouton

DEFINE_RESPONSE_TABLE1(NSEdit, TEdit)
	EV_WM_KILLFOCUS,
	EV_WM_SETFOCUS,
	EV_WM_KEYUP,
	EV_WM_KEYDOWN,
	EV_WM_GETDLGCODE,
	EV_WM_CHAR,
END_RESPONSE_TABLE ;

//Type of character	Character	Description
//
//			Special				#		Accept only a digit
//									?		Accept only a letter (case_insensitive)
//									&		Accept only a letter, force to uppercase
//									@		Accept any character
//									!		Accept any character, force to uppercase
//			Match					;		Take next character literally
//									*		Repetition count
//									[]		Option
//									{}		Grouping operators
//									,		Set of alternatives
//			All others					Taken literally
//
// {A{1[#[#]],2{[{0,1,2,3,4}[#],5[{0,1,2,3,4,5}],6,7,8,9]},{3,4,5,6,7,8,9}[#]},B,D,F,G,I,L,M,N,O,R,S,T,$,;#,;@,+}

//
// Constructeur
//
NSEdit::NSEdit(NSContexte* pCtx, TWindow* parent, int resId,  char* szTypeEdit, string sUserLang)
       :TEdit(parent, resId, 0), NSRoot(pCtx)
{
	strcpy(szType, szTypeEdit) ;
	DisableTransfer() ;

  initCommonData() ;

	sContenuBrut        = "" ;
	sContenuTransfert   = "" ;
	pControle           = 0 ;
	EncoursEdition      = false ;
	parentEdit          = parent ;
	TextLimit           = 15 ;
	bWinStd             = false ;
	bValidContent       = true ;
	bCurrentlyWarning   = false ;
	bHistoryOpen        = false ;
  sLang               = sUserLang ;

	//
	// Mise en place du validateur
	//
	string  sValidateur = "" ;
	// int     iDecimale   = 0 ;
	switch (szType[0])
	{
		// Saisie des chiffres
		//
		// ATTENTION : textLen = iMaxInput + 1
		//
		case nbMARK :
			sValidateur = "0-9,-" ;
			sValidateur[3] = decimSepar ;
			SetValidator(new TFilterValidator(sValidateur.c_str())) ;
			break ;
		//
		// Saisie des lettres
		//
		case charMARK  :
			SetValidator(new TFilterValidator("0-9A-Za-z. ")) ;
			break ;
		//
		// Saisie des dates
		//
		case dateMARK :
			SetValidator(new TPXPictureValidator("##/##/####")) ;
			break ;
		//
		// Saisie des dates et heures
		//
    case dateHeureMARK :
			SetValidator(new TPXPictureValidator("##/##/#### ##:##:##")) ;
      TextLimit = 20 ;
			break ;

		case codeMARK :
			sValidateur = ",.0-9A-Za-z";
			//sValidateur[4] = decimSepar;
			SetValidator(new TFilterValidator(sValidateur.c_str()));
			break ;
	}
}

NSEdit::NSEdit(NSContexte* pCtx, TWindow* parent, int resId, string sUserLang)
       :TEdit(parent, resId, 0), NSRoot(pCtx)
{
	DisableTransfer();

  initCommonData() ;

	sContenuBrut        = "" ;
	sContenuTransfert   = "" ;
	pControle           = 0 ;
	EncoursEdition      = false ;
	parentEdit          = parent ;
	bWinStd             = false ;
	bValidContent       = true ;
	bCurrentlyWarning   = false ;
	bHistoryOpen        = false ;
  sLang               = sUserLang ;
}

NSEdit::NSEdit(NSContexte* pCtx, TWindow* parent, int resId, char* szTypeEdit,
                const char far* text, int x, int y, int w, int h, string sUserLang,
                uint textLimit, bool multiline, TModule* module)
        :TEdit(parent, resId, text, x, y, w, h, textLimit, multiline, module), NSRoot(pCtx)
{
	strcpy(szType, szTypeEdit) ;
	DisableTransfer() ;

  initCommonData() ;

	sContenuBrut        = "" ;
	sContenuTransfert   = "" ;
	pControle           = 0 ;
  EncoursEdition      = false ;
  parentEdit          = parent ;
  TextLimit           = 15 ;
  bWinStd             = false ;
  bValidContent       = true ;
  bCurrentlyWarning   = false ;
  bHistoryOpen        = false ;
  sLang               = sUserLang ;

	//
	// Mise en place du validateur
	//
	string  sValidateur = "" ;
	// int     iDecimale   = 0 ;
	switch (szType[0])
	{
    // Saisie des chiffres
    //
    // ATTENTION : textLen = iMaxInput + 1
    //
		case nbMARK :
      sValidateur = "0-9,-" ;
      sValidateur[3] = decimSepar ;
      SetValidator(new TFilterValidator(sValidateur.c_str())) ;
      break ;

		// Saisie des lettres
    //
		case charMARK  :
      SetValidator(new TFilterValidator("0-9A-Za-z. ")) ;
      break ;

		// Saisie des dates
    //
		case dateMARK :
      SetValidator(new TPXPictureValidator("##/##/####")) ;
      break ;

		// Saisie des dates et heures
		//
    case dateHeureMARK :
			SetValidator(new TPXPictureValidator("##/##/#### ##:##:##")) ;
      TextLimit = 20 ;
			break ;

    case codeMARK :
      sValidateur = ",.0-9A-Za-z" ;
      //sValidateur[4] = decimSepar;
      SetValidator(new TFilterValidator(sValidateur.c_str())) ;
      break ;
	}
}

//
// Destructeur
//
NSEdit::~NSEdit()
{}

// SetupWindow : on fixe la police du dialogue
void
NSEdit::SetupWindow()
{
	TEdit::SetupWindow() ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;
  SetWindowFont(*(pSuper->getDialogFont()), false) ;
}

void
NSEdit::initCommonData()
{
  bWinStd = false ;
	if (NULL != pContexte)
	{
  	NSSuper* pSuper = pContexte->getSuperviseur() ;
    if ((pSuper && pSuper->getDPIO()) && (pSuper->getDPIO()->bReturnCloses))
    	bWinStd = true ;
	}
}

//fonction permettant � la touche ENTREE d'avoir le m�me effet que TAB
void
NSEdit::EvKeyUp(uint key, uint repeatcount, uint flags)
{
  // Gestion windows standard
  // Windows standard behaviour
  if (bWinStd && (pControle->getNSDialog()))
  {
    // return TEdit::EvKeyUp(key, repeatcount, flags) ;
    TEdit::EvKeyUp(key, repeatcount, flags) ;
    return ;
  }

  // THandle NextControl = 0;
  switch (key)
  {
    //return
    case VK_RETURN :
    case VK_DOWN   :
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // suivant pControle sinon le premier
      //
      if (pControle && pControle->getNSDialog())
        pControle->getNSDialog()->ActiveControlSuivant(pControle) ;
      else if (pControle && pControle->getMUEView())
        pControle->getMUEView()->SetFocusToNextControl((TControl*)this) ;
      else
      {
        if (parentEdit->Parent->ChildWithId(1))
          parentEdit->Parent->ChildWithId(1)->SetFocus() ;
        else
          parentEdit->CloseWindow(IDOK) ;
      }
      break ;

    case VK_UP    :
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // pr�c�dent pControle sinon le dernier
      //
      if (pControle && pControle->getNSDialog())
        pControle->getNSDialog()->ActiveControlPrecedent(pControle) ;
      else if (pControle && pControle->getMUEView())
        pControle->getMUEView()->SetFocusToPreviousControl((TControl*)this) ;
      break ;

    //tabulation
    case VK_TAB	:
      //
      // demander � la bo�te de dialogue m�re d'activer le controle
      // suivant pControle sinon le premier
      //
      if (pControle && pControle->getNSDialog())
        pControle->getNSDialog()->ActiveControlSuivant(pControle) ;
      else if (pControle && pControle->getMUEView())
      {
        if (GetKeyState(VK_SHIFT) < 0)
          pControle->getMUEView()->SetFocusToPreviousControl((TControl*)this) ;
        else
          pControle->getMUEView()->SetFocusToNextControl((TControl*)this) ;
      }
      break ;

    default		:
      //return TEdit::EvKeyUp(key, repeatcount, flags);
      TEdit::EvKeyUp(key, repeatcount, flags) ;
      return ;
  }
}

void
NSEdit::EvKeyDown(uint key, uint repeatcount, uint flags)
{
try
{
  if ((GetKeyState(VK_CONTROL) < 0) && ((key == 'H') || (key == 'h')))
  {
    if (pControle && pControle->getTransfert() && pControle->getTransfert()->pBBFilsItem)
    {
      NSContexte* pContexte = pControle->getInterfaceContext() ;

      // On r�cup�re la fiche avec l'unit�
      BBFilsItem*	pBBFilsItemUnit = pControle->getTransfert()->pBBFilsItem ;

      if ((pBBFilsItemUnit->getItemFather()) && (pBBFilsItemUnit->getItemFather()->pBBFilsPere))
      {
        BBFilsItem*	pBBFilsItemElement = pBBFilsItemUnit->getItemFather()->pBBFilsPere ;
        string sItemValue = pBBFilsItemElement->getItemLabel() ;
        //
        // Unit�
        //
        string sUnit        = "" ;
        string sItemUnit    = pBBFilsItemUnit->getItemLabel() ;
        size_t posit = sItemUnit.find(string(1, cheminSeparationMARK)) ;
        if (posit != NPOS)
          sUnit = string(sItemUnit, 0, posit) ;

        BBItem* pPereItem = pBBFilsItemElement->getItemFather() ;
        // string 	sLoc = pPereItem->sLocalisation ;
        string sLoc = pPereItem->donneVraiChemin() ;
        string sResult = "" ;

        bHistoryOpen = true ;

        NSValListHistoryDialog* pDialogHistory = new NSValListHistoryDialog(Parent, pContexte, sItemValue, sLoc, sUnit, &sResult) ;
        pDialogHistory->Execute() ;
        delete pDialogHistory ;

        bHistoryOpen = false ;

        if (sResult != "")
          SetText(sResult.c_str()) ;

        return ;
      }
    }
  }

  TEdit::EvKeyDown(key, repeatcount, flags) ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception NSEdit::EvKeyDown : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
  return ;
}
catch (...)
{
  erreur("Exception NSEdit::EvKeyDown.", standardError, 0) ;
  return ;
}
}

//-------------------------------------------------------------------------
// enlever les beeps
//-------------------------------------------------------------------------
void
NSEdit::EvChar(uint key, uint repeatCount, uint flags)
{
	// Usually Ctrl-H = Back-space
	if (bHistoryOpen)
		return ;

	if ((false == bWinStd) && ((VK_RETURN == key) || (VK_TAB == key)))
		// Process this message to avoid message beeps.
		return ;
	else if (Validator && (szType[0] == nbMARK))
	{
  	if ((key == ',') || (key == '.'))
    	key = decimSepar ;

    if ((VK_DECIMAL == key) || (VK_SEPARATOR == key))
    	key = decimSepar ;

    if (key == decimSepar)
    {
    	string sChaineFin = string("") ;
      uint startSel = 0 ;

    	int oldBuffLen = GetTextLen() ;
      if (oldBuffLen > 0)
      {
      	char far* oldBuff = new char[oldBuffLen+1] ;
        GetText(oldBuff, oldBuffLen + 1) ;
        uint endSel ;
        GetSelection(startSel, endSel) ;

      	for (int i = 0; i < oldBuffLen; i++)
      	{
      		if (oldBuff[i] == decimSepar)
          {
          	delete[] oldBuff ;
            return ;
          }
        }

        string sChaineDeb = string(oldBuff) ;
        delete[] oldBuff ;

        sChaineFin = string(sChaineDeb, 0, startSel) + string(1,decimSepar)
                + string(sChaineDeb, endSel, strlen(sChaineDeb.c_str())-endSel) ;
      }

      SetText(sChaineFin.c_str()) ;
      SetSelection(startSel+1, startSel+1) ;
    }
    else
    	TEdit::EvChar(key, repeatCount, flags) ;
	}
  else
  	TEdit::EvChar(key, repeatCount, flags) ;
}

//fonction permettant � la touche ENTREE d'avoir le m�me effet que TAB
uint
NSEdit::EvGetDlgCode(MSG far* /* msg */)
{
	//if (bWinStd)
	//    return 0 ;

	uint retVal = (uint)DefaultProcessing() ;
	if (false == bWinStd)
		retVal |= DLGC_WANTALLKEYS ;
	return retVal ;
	//return DLGC_WANTALLKEYS;
}

//
// Fonction d�clench� lorsque l'Edit perd le focus.
//
void
NSEdit::EvKillFocus(HWND hWndGetFocus)
{
	int iNotifier = 1 ;

	string sContenu = string("") ;

	//
	// R�cup�re le texte
	//
  int oldBuffLen = GetTextLen() ;
  if (oldBuffLen > 0)
  {
		char far* str = new char[oldBuffLen + 1] ;
    GetText(str, oldBuffLen + 1) ;
		sContenu = string(str) ;
		delete[] str ;
	}

	EncoursEdition = false ;

	//
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle && pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_EXECUTE);
	//
	// Pr�vient Big Brother (si l'�ventuelle fonction l'autorise)
	//

	Message theMessage ;

	if (iNotifier == 1)
	{
		if (sContenu == "")
		{
			if (sContenuBrut != "")
			{
				sContenuBrut = "" ;
				donneTransfert() ;
        theMessage.SetComplement(sContenuTransfert) ;
        theMessage.SetType(Type) ;
        if (pControle && pControle->getTransfert())
        	pControle->getTransfert()->ctrlNotification(BF_CHECKED,
                                                      BF_UNCHECKED,
                                                      &theMessage) ;
      }
    }
		else
		{
    	sContenuBrut = sContenu ;
      donneTransfert() ;
      theMessage.SetComplement(sContenuTransfert) ;
      theMessage.SetType(Type) ;

      if (pControle && pControle->getTransfert())
      {
				if (sContenuBrut == "")
        	pControle->getTransfert()->ctrlNotification(BF_UNCHECKED,
                                                      BF_CHECKED,
                                                      &theMessage) ;
				else
        	pControle->getTransfert()->ctrlNotification(BF_CHECKED,
                                                      BF_CHECKED,
                                                      &theMessage) ;
      }
    }	}
	/************************************************************
	//
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle && pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_POSTEXEC, hWndGetFocus);
    *****************************************************************/

	TEdit::EvKillFocus(hWndGetFocus) ;

	//
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle && pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_POSTEXEC, hWndGetFocus) ;
}

//---------------------------------------------------------------------------//  Function: 		NSEdit::Transfer(TTransferDirection direction,
//															 int* pActif, string* pMessage)
//
//  Description:	Si direction = tdSetData
//							Initialise le contr�le
//						Si direction = tdGetData
//							Initialise pActif et pMessage
//
//  Arguments:		direction : tdGetData ou tdSetData
//
//  Returns:		1 si le transfert a fonctionn�
//						0 sinon
//---------------------------------------------------------------------------
uint
NSEdit::Transferer(TTransferDirection direction, int* pActif, Message* pMessage)
{
	if (direction == tdSetData)
	{
		switch (*pActif)
		{
			case 0 :
      	sContenuTransfert = "" ;
        donneBrut() ;
        SetText(sContenuBrut.c_str()) ;
        break ;

			case 1 :
      	if (pMessage)
        {
      		sContenuTransfert = pMessage->GetComplement() ;
          Type = pMessage->GetType() ;
        }
        donneBrut() ;
        SetText(sContenuBrut.c_str()) ;
        break ;
		}
	}
  else if (direction == tdGetData)
	{
  	if (EncoursEdition)
    {
    	//
			// R�cup�re le texte
			//
      int oldBuffLen = GetTextLen() ;
      if (oldBuffLen > 0)
      {
      	char far* str = new char[oldBuffLen + 1] ;
        GetText(str, oldBuffLen + 1) ;
				sContenuBrut = string(str) ;
				delete[] str ;
      }
      else
      	sContenuBrut = string("") ;
    }

    donneTransfert() ;
    if (sContenuTransfert == "")
    	*pActif = 0 ;
    else
    	*pActif = 1 ;

    //
    //transformer la virgule si elle existe en un point
    //
    size_t pos = sContenuTransfert.find(decimSepar) ;
    if (pos != NPOS)
    	sContenuTransfert.replace(pos, 1, ".") ;

    if (pMessage)
    {
    	pMessage->SetComplement(sContenuTransfert) ;
      pMessage->SetType(Type) ;

      string sEtiquette = string("") ;
      if (pControle->getTransfert())
      	sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

      pMessage->MettreAJourCertitudePluriel(sEtiquette) ;
    }
  }
	return 1 ;
}

uint
NSEdit::TempTransferer(int* pActif, Message* pMessage)
{
	if (EncoursEdition)
  {
  	//
    // R�cup�re le texte
    //
    int oldBuffLen = GetTextLen() ;
    if (oldBuffLen > 0)
    {
    	char far* str = new char[oldBuffLen + 1] ;
      GetText(str, oldBuffLen + 1) ;
      sContenuBrut = string(str) ;
      delete[] str ;
    }
    else
    	sContenuBrut = string("") ;
  }

  donneTransfert() ;

  if (sContenuTransfert == "")
  	*pActif = 0 ;
  else
  	*pActif = 1 ;

  //
  //transformer la virgule si elle existe en un point
  //
  size_t pos = sContenuTransfert.find(decimSepar) ;
  if (pos != NPOS)
  	sContenuTransfert.replace(pos, 1, ".") ;

	pMessage->SetComplement(sContenuTransfert) ;
  pMessage->SetType(Type) ;

  string sEtiquette = string("") ;
  if (pControle->getTransfert())
    sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

  pMessage->MettreAJourCertitudePluriel(sEtiquette) ;

	return 1 ;
}

//---------------------------------------------------------------------------//  Function: 		NSEdit::activeControle(int activation, string message)
//
//  Description:	Initialise le contr�le avant affichage de la bo�te de
//						dialogue
//
//  Arguments:		activation : BF_CHECKED ou BF_UNCHECKED
//						message    : Contenu de la bo�te
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void
NSEdit::activeControle(int activation, Message* pMessage)
{
	// Gestion windows standard
	// Windows standard behaviour
	if (pControle && pControle->getInterfaceContext())
	{
		NSSuper* pSuper = pControle->getInterfaceContext()->getSuperviseur() ;
		if ((pSuper && pSuper->getDPIO()) && (pSuper->getDPIO()->bReturnCloses))
			bWinStd = true ;
	}

	switch (activation)
	{
		case BF_CHECKED   :

      if (sContenuTransfert != pMessage->GetComplement())
      {
        sContenuTransfert = pMessage->GetComplement() ;
        Type = pMessage->GetType() ;
        donneBrut() ;
        SetText(sContenuBrut.c_str()) ;

        //
	      // Si une fonction est attach�e au contr�le, on l'ex�cute
	      //
	      if (pControle && pControle->getFonction())
          pControle->getFonction()->execute(NSDLGFCT_POSTEXEC, 0) ;
      }

      break ;

		case BF_UNCHECKED :

      sContenuTransfert = "" ;
      donneBrut() ;
      SetText(sContenuBrut.c_str()) ;
      break ;
  }
}

bool
NSEdit::canWeClose()
{
  return bValidContent ;
}

//---------------------------------------------------------------------------
//  Function: 		NSEdit::donneBrut()
//
//  Description:	Transforme les donn�es NAUTILUS en donn�es � saisir par//						l'utilisateur
//
//  Arguments:		Aucun
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void NSEdit::donneBrut()
{
	size_t i ;

	switch (szType[0])
	{
		// Saisie des chiffres
    case nbMARK  	:

      sContenuBrut = sContenuTransfert ;
      if (string("") == sContenuBrut)
        break ;
      //
      // On remplace le '.' par decimSepar
      //
      i = sContenuBrut.find(".") ;
      if (NPOS != i)
        sContenuBrut[i] = decimSepar ;
      break ;

		// Saisie des lettres
		case charMARK	:
    case codeMARK	:

      sContenuBrut = sContenuTransfert ;
      break ;

		// Saisie des dates
		case dateMARK 	:

      sContenuBrut = "00/00/1900" ;
      //
      // On passe de AAAAMMJJ � JJ/MM/AAAA
      //
      if (sContenuTransfert != "")
      {
        for (i = 0; i < 4; i++)
          sContenuBrut[i+6] = sContenuTransfert[i] ;
        for (i = 0; i < 2; i++)
          sContenuBrut[i+3] = sContenuTransfert[i+4] ;
        for (i = 0; i < 2; i++)
          sContenuBrut[i] = sContenuTransfert[i+6] ;
      }
      break ;
  }
}

//---------------------------------------------------------------------------//  Function: 		NSEdit::donneTransfert()
//
//  Description:	Transforme les donn�es saisies par l'utilisateur
//					   en donn�es NAUTILUS
//
//  Arguments:		Aucun
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void
NSEdit::donneTransfert()
{
	size_t      i ;
	size_t      k ;
	char        ptgag[3];

	switch (szType[0])
	{
		// Saisie des chiffres
		case nbMARK  	:

      strip(sContenuBrut) ;

      if ((sContenuBrut == "") ||
            	(!sContenuBrut.find_first_of("-0123456789") == 0))
      {
        sContenuTransfert = "" ;
        break ;
      }
      else
      {
        // If there is a '-' in first position, remove it and put it back later
        //
        bool bIsNegative = false ;

        size_t iPos = sContenuBrut.find("-") ;
        if (NPOS != iPos)
        {
          if (iPos > 0)
            break ;

          if (strlen(sContenuBrut.c_str()) == 1)
            break ;

          size_t iPos = sContenuBrut.find("-", 1) ;
          if (NPOS != iPos)
            break ;

          bIsNegative = true ;
          sContenuBrut = string(sContenuBrut, 1, strlen(sContenuBrut.c_str()) - 1) ;
        }

        // Recherche du premier caract diff�rent de '0'
        k = sContenuBrut.find_first_not_of('0') ;
        //
        // ATTENTION : on ne suppose plus que 0 = rien
        //
        if (NPOS == k)
        {
          sContenuTransfert = string("0") ;
          break ;
        }
        // on teste si on a 0,XX (il ne faut pas �ter le 0)
        // ou 00035,XX (il faut �ter les 0 initiaux)
        if (sContenuBrut[k] == decimSepar)
        {
          if (0 == k)
            sContenuTransfert = "0" + sContenuBrut ;
          else
            sContenuTransfert = string(sContenuBrut, k-1, strlen(sContenuBrut.c_str())-k+1) ;
        }
        else
          sContenuTransfert = string(sContenuBrut, k, strlen(sContenuBrut.c_str())-k) ;

        i = sContenuTransfert.find(decimSepar) ;
        if (NPOS != i)
          sContenuTransfert[i] = '.' ;

        if (bIsNegative)
        {
          sContenuTransfert = string("-") + sContenuTransfert ;
          sContenuBrut      = string("-") + sContenuBrut ;
        }
      }
      break ;

		// Saisie des lettres
    case codeMARK	:
		case charMARK	:

      // On ajoute l'indicateur de taille (2 premiers car.)
      strip(sContenuBrut, stripRight) ;
      if (sContenuBrut != "")
      {
        i = strlen(sContenuBrut.c_str()) ;
        numacar(ptgag, i+1, 2) ;
        sContenuTransfert = ptgag + sContenuBrut ;
      }
      else
        sContenuTransfert = "" ;
      break ;

		// Saisie des dates
		case dateMARK 	:

      sContenuTransfert = "" ;
      //
      // On passe de JJ/MM/AAAA � AAAAMMJJ
      //
      if (sContenuBrut != "00/00/1900")
      {
        sContenuTransfert  = string(sContenuBrut, 6, 4) ;
        sContenuTransfert += string(sContenuBrut, 3, 2) ;
        sContenuTransfert += string(sContenuBrut, 0, 2) ;
      }
      break ;
	}
}

voidNSEdit::EvSetFocus(HWND hWndLostFocus)
{
	EncoursEdition = true ;
  //pControle->SetFocus() ;
  //Parent->SetFocus() ;

  if (NULL != pControle)
    pControle->activateParent() ;

  TEdit::EvSetFocus(hWndLostFocus) ;
  // SetSelection(0,0) ;
}

//******************************************************************
//									TRAITEMENT DES DATES
//******************************************************************

//
//----------------------------------------------------------------------
//
DEFINE_RESPONSE_TABLE1(NSEditDate, NSEdit)
	EV_WM_KILLFOCUS,
    EV_WM_KEYDOWN,
    EV_WM_CHAR,
END_RESPONSE_TABLE;

//
// Constructeur
//
NSEditDate::NSEditDate(NSContexte* pCtx, TWindow* parent, int resId, char* szTypeEdit, string sUserLang, char cRefDate)
           :NSEdit(pCtx, parent, resId, szTypeEdit, sUserLang)
{
	strcpy(szType, szTypeEdit) ;
	//
	// Mise en place du validateur
	//
  char cValidateur[] = "##/##/####" ;
  cValidateur[2] = dateSeparationMARK ;
  cValidateur[5] = dateSeparationMARK ;  SetValidator(new TPXPictureValidator(cValidateur)) ;
  cRefYear = cRefDate ;
}

NSEditDate::NSEditDate(NSContexte* pCtx, TWindow* parent, int resId, char* szTypeEdit,
                const char far* text, int x, int y, int w, int h, string sUserLang, char cRefDate,
                uint textLimit, bool multiline, TModule* module)
            : NSEdit(pCtx, parent, resId, szTypeEdit, text, x, y, w, h, sUserLang, textLimit, multiline, module)
{
	strcpy(szType, szTypeEdit) ;
	//
	// Mise en place du validateur
	//
	char cValidateur[] = "##/##/####" ;
	cValidateur[2] = dateSeparationMARK ;
	cValidateur[5] = dateSeparationMARK ;	SetValidator(new TPXPictureValidator(cValidateur)) ;
	cRefYear = cRefDate ;
}

//
// Destructeur
//
NSEditDate::~NSEditDate()
{}

//
// Fonction d�clench� lorsque l'Edit perd le focus.
//
void
NSEditDate::EvKillFocus(HWND hWndGetFocus)
{
try
{
	if (bCurrentlyWarning)
		return ;

  bool bCanLetItBe = true ;
  actionForKillFocus(bCanLetItBe) ;

  if (false == bCanLetItBe)
  {
    // TEdit::EvKillFocus(hWndGetFocus) ;
		// SetFocus() ;
    return ;
  }

	TEdit::EvKillFocus(hWndGetFocus) ;
}
catch (...)
{
	erreur("Exception NSEditDate::EvKillFocus.", standardError, 0) ;
}
}

void
NSEditDate::actionForKillFocus(bool &bCanLetItBe)
{
	//
	// Get content
	//
  string sContent = string("") ;

	int oldBuffLen = GetTextLen() ;
  if (oldBuffLen > 0)
  {
		char far* str = new char[oldBuffLen + 1] ;
		GetText(str, oldBuffLen + 1) ;
		sContent = string(str) ;
		delete[] str ;
  }

	EncoursEdition = false ;

	// V�rification de la validit� de la date
	string sMessage ;
	donne_date_inverse(sContent, sMessage, sLang) ;
	if (string("") == sMessage)
	{
		bCurrentlyWarning = true ;
		erreur("Date invalide.", standardError, 0) ;
		bCurrentlyWarning = false ;
		bValidContent = false ;

    // To prevent an unescapable wrong date
    sContenuTransfert = string(8, '0') ;
    donneBrut() ;

		SetText(sContenuBrut.c_str()) ;
		// sContenu = sContenuBrut;

    bCanLetItBe = false ;

		return ;
	}
  bCanLetItBe = true ;

	bValidContent = true ;

  int iNotifier = 1 ;
	//
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle && pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_EXECUTE) ;

	//
	// Pr�vient Big Brother (si l'�ventuelle fonction l'autorise)
	//
  Message theMessage("", "", "", "A", "", "", "1") ;

	if (1 == iNotifier)
	{		if (string("") == sContent)
		{
			if (string("") != sContenuBrut)
			{
				sContenuBrut = string("") ;
				donneTransfert() ;
        theMessage.SetComplement(sContenuTransfert) ;
        theMessage.SetType(Type) ;
        if (pControle && pControle->getTransfert())
        	pControle->getTransfert()->ctrlNotification(BF_CHECKED,
                                                      BF_UNCHECKED,
                                                      &theMessage) ;
			}
		}
		else
		{
    	sContenuBrut = sContent ;
      donneTransfert() ;
      theMessage.SetComplement(sContenuTransfert) ;
      theMessage.SetType(Type) ;

      if (pControle && pControle->getTransfert())
      {
				if (sContenuBrut == "")
      		pControle->getTransfert()->ctrlNotification(BF_UNCHECKED,
                                                      BF_CHECKED,
                                                      &theMessage) ;
				else
        	pControle->getTransfert()->ctrlNotification(BF_CHECKED,
                                                      BF_CHECKED,
                                                      &theMessage) ;
			}
		}
	}

	//
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle && pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_POSTEXEC) ;
}

//---------------------------------------------------------------------------//  Function: 		NSEditDate::donneBrut()
//
//  Description:	Transforme les donn�es NAUTILUS en donn�es � saisir par
//						l'utilisateur
//
//  Arguments:		Aucun
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void
NSEditDate::donneBrut()
{
	int i ;

	sContenuBrut = "00/00/0000" ;
	sContenuBrut[2] = dateSeparationMARK ;
	sContenuBrut[5] = dateSeparationMARK ;
	char date[11] ;

	//
	// On passe de AAAAMMJJ � JJ/MM/AAAA
	//
	if (sContenuTransfert != "")
	{
  	for (i = 0; i < 4; i++)
    	sContenuBrut[i+6] = sContenuTransfert[i] ;
    for (i = 0; i < 2; i++)
    	sContenuBrut[i+3] = sContenuTransfert[i+4] ;
    for (i = 0; i < 2; i++)
    	sContenuBrut[i] = sContenuTransfert[i+6] ;

    return ;
	}

  TWindow* pParent = TWindow::GetParentO() ;
	NSDialog* pDlg = TYPESAFE_DOWNCAST(pParent, NSDialog) ;
	NSContexte *pContexte ;
	if ((pDlg) &&(pDlg->pBBItem) && (pDlg->pBBItem->pBigBoss) &&
                                        (pDlg->pBBItem->pBigBoss->pContexte))
		pContexte = (pDlg->pBBItem->pBigBoss->pContexte) ;

	switch (cRefYear)
  {
  	case 'B' :   //birthday
    	pContexte->getPatient()->donneNaissance(date) ;
      donne_date(date, (char*)sContenuBrut.c_str(), sLang) ;
      break ;

    case 'N' :    //now
    	donne_date_duJour(date) ;
      donne_date(date, (char*)sContenuBrut.c_str(), sLang) ;
      break ;
  }
}

//---------------------------------------------------------------------------
//  Function: 		NSEditDate::donneTransfert()
//
//  Description:	Transforme les donn�es saisies par l'utilisateur
//					   en donn�es NAUTILUS
//
//  Arguments:		Aucun
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void
NSEditDate::donneTransfert()
{
	sContenuTransfert = "";
  //
  // On passe de JJ/MM/AAAA � AAAAMMJJ
  //
  char cValidateur[] = "00/00/0000" ;

  cValidateur[2] = dateSeparationMARK;
  cValidateur[5] = dateSeparationMARK;

  if (sContenuBrut != cValidateur)
  {
  	sContenuTransfert  = string(sContenuBrut, 6, 4) ;
    sContenuTransfert += string(sContenuBrut, 3, 2) ;
    sContenuTransfert += string(sContenuBrut, 0, 2) ;
  }
}

//
//  TStatic
//
void
NSEditDate::EvChar(uint key, uint repeatCount, uint flags)
{
	if (Validator && (key != VK_BACK)   &&
                   (key != VK_RETURN) &&
                   (key != VK_SPACE) 	&&
                   (key != VK_DELETE) &&
                   (key != VK_TAB))
	{
  	if ((key < '0') || (key > '9'))
    	return ;

    uint startSel, endSel ;
    GetSelection(startSel, endSel) ;

    int oldBuffLen = GetTextLen() ;
        char far* oldBuff = new char[oldBuffLen+1] ;

        GetText(oldBuff, oldBuffLen+1);
        size_t iGenuineLength = strlen(oldBuff) ;

        endSel = startSel ;
        // On doit �tre certain de ne pas �craser les '/'
        if (startSel == 2)
      	    startSel = 3 ;
        if (startSel == 5)
      	    startSel = 8 ;
        endSel = startSel ;

        if (startSel < iGenuineLength)
        {
            oldBuff[startSel] = char(key) ;
            startSel++ ;
            endSel++ ;

            switch (cRefYear)
            {
                case 'F' :    //  future  >=2000
                     // An 20xx
                    if (oldBuff[6] == '0')
                        oldBuff[6] = '2' ;
                    break;
                case 'P' :       //past   <2000
                    if (oldBuff[6] == '0')
                    {
                        oldBuff[6] = '1' ;
                        oldBuff[7] = '9' ;
                    }
                    break;
            }
        }

        // On saute les '/'
        if (startSel == 2)
      	    startSel = 3 ;
        if (startSel == 5)
        {
            if ((cRefYear == 'F') || (cRefYear == 'O'))
      	        startSel = 8 ;
            else
                startSel = 6 ;
        }
        endSel = startSel ;

        SetText(oldBuff) ;
   	    SetSelection(startSel, endSel) ;
        delete[] oldBuff ;

/*
        int oldBuffLen = GetTextLen();
    	char far* oldBuff = new char[oldBuffLen+1];
        GetText(oldBuff, oldBuffLen+1);

    	uint   startSel, endSel;
    	GetSelection(startSel, endSel);

        // On saute les '/'
        if (startSel == 2)
      	    startSel = 3;
        if (startSel == 5)
      	    startSel = 8;

        //Si la s�lection est multi-caract�res, on la ram�ne � 1 car.
        endSel = startSel;
        SetSelection(startSel, endSel);

        bool wasAppending = endSel == oldBuffLen;

  		if ((!wasAppending) && (startSel == endSel))
    	{
            for (int i = startSel; i < oldBuffLen; i++)
         	    oldBuff[i] = oldBuff[i+1];
            SetText(oldBuff);
            SetSelection(startSel, endSel);
        }

    	bool preMsgModify = IsModified();             // Save (pre)  MODIFY flag

    	TStatic::EvChar(key, repeatCount, flags);     // Process the new char...

    	bool postMsgModify= IsModified();             // Save (post) MODIFY flag

    	GetSelection(startSel, endSel);
    	int buffLen = GetTextLen();
    	char far* buff = LockBuffer(max((int)TextLimit,max(oldBuffLen,buffLen))+1);

    	// Run the result of the edit through the validator.  If incorrect,
    	// then restore the original text.  Otherwise, range check & position
    	// the selection as needed.
    	//
    	if (!Validator->HasOption(voOnAppend) || wasAppending && endSel == buffLen)
        {
      	    if (!Validator->IsValidInput(buff, false))
            {
        		strcpy(buff, oldBuff);          // Restore old buffer
        		postMsgModify = preMsgModify;   // Restore old modify state too!
      	    }
      	    else
            {
                if (wasAppending)
          		    startSel = endSel = strlen(buff); // may have autoFilled--move to end
      	    }
      	    UnlockBuffer(buff, true);
      	    SetSelection(startSel, endSel);
        }
    	else
        {
      	    if (endSel == buffLen && !Validator->IsValidInput(buff, false))
                Validator->Error(this);
      	    UnlockBuffer(buff);
    	}
    	SendMessage(EM_SETMODIFY, (TParam1)postMsgModify);

        //
        // On saute les caract�res inutiles
        //
    	GetSelection(startSel, endSel);
        if (startSel == endSel)
        {
      	    if (startSel == 2)
      		    SetSelection(3, 3);
      	    if (startSel == 5)
      		    SetSelection(8, 8);
   	    }

    	delete[] oldBuff;
*/
	}
    else if (key == VK_BACK)
    {
        uint   startSel, endSel;
        GetSelection(startSel, endSel);

        // On saute les '/'
        if (startSel == 3)
      	    startSel = 2;
        if (startSel == 6)
      	    startSel = 5;

        int oldBuffLen = GetTextLen();
        char far* oldBuff = new char[oldBuffLen+1];

        GetText(oldBuff, oldBuffLen+1);

        endSel = startSel;
        if (startSel > 0)
        {
            startSel--;
            oldBuff[startSel] = '0';
        }
        SetText(oldBuff);
   	    SetSelection(startSel, endSel);
        delete[] oldBuff;
    }
    else if ((key == VK_RETURN) || (key == VK_TAB) || (key == VK_SPACE))
   	    //Process this message to avoid message beeps.
        return ;
    else
        TStatic::EvChar(key, repeatCount, flags);
}

void
NSEditDate::EvKeyDown(uint key, uint repeatCount, uint flags)
{
    if (key == VK_DELETE)
    {
        uint   startSel, endSel;
        GetSelection(startSel, endSel);

        int oldBuffLen = GetTextLen();
        char far* oldBuff = new char[oldBuffLen+1];
        GetText(oldBuff, oldBuffLen+1);

        string dateVide = "00/00/0000";
        string dateEdit = string(oldBuff);

        if (startSel == endSel)
        {
            dateEdit.replace(startSel, 1, dateVide, startSel, 1);
            startSel++;
            endSel++;
        }
        else
        {
            dateEdit.replace(startSel, endSel-startSel, dateVide, startSel, endSel-startSel);
            startSel = endSel;
        }

        strcpy(oldBuff, dateEdit.c_str());

        SetText(oldBuff);
   	    SetSelection(startSel, endSel);
        delete[] oldBuff;
    }
    else
    	TStatic::EvKeyDown(key, repeatCount, flags);
}

bool
NSEditDate::canWeClose()
{
	if (!bValidContent)
  	erreur("Date invalide.", standardError, 0) ;
	return bValidContent ;
}

//******************************************************************
//						TRAITEMENT DES DATES + HEURE
//******************************************************************

//
//----------------------------------------------------------------------
//
DEFINE_RESPONSE_TABLE1(NSEditDateHeure, NSEdit)
	EV_WM_KILLFOCUS,
	EV_WM_KEYDOWN,
	EV_WM_CHAR,
END_RESPONSE_TABLE ;

//
// Constructeur
//
NSEditDateHeure::NSEditDateHeure(NSContexte* pCtx, TWindow* parent, int resId,  char* szTypeEdit, string sUserLang, char cRefDate)
                :NSEdit(pCtx, parent, resId, szTypeEdit, sUserLang)
{
	strcpy(szType, szTypeEdit);
	//
	// Mise en place du validateur
	//
	char cValidateur[] = "##/##/#### ##:##:##" ;
	cValidateur[2]  = dateSeparationMARK ;
	cValidateur[5]  = dateSeparationMARK ;	cValidateur[13] = heureSeparationMARK ;	cValidateur[16] = heureSeparationMARK ;	SetValidator(new TPXPictureValidator(cValidateur)) ;

	cRefYear = cRefDate ;
}

NSEditDateHeure::NSEditDateHeure(NSContexte* pCtx, TWindow* parent, int resId, char* szTypeEdit,
                const char far* text, int x, int y, int w, int h, string sUserLang, char cRefDate,
                uint textLimit, bool multiline, TModule* module)
                :NSEdit(pCtx, parent, resId, szTypeEdit, text, x, y, w, h, sUserLang, textLimit, multiline, module)
{
	strcpy(szType, szTypeEdit) ;
	//
	// Mise en place du validateur
	//
	char cValidateur[] = "##/##/#### ##:##:##" ;
	cValidateur[2] = dateSeparationMARK ;
	cValidateur[5] = dateSeparationMARK ;	cValidateur[13] = heureSeparationMARK ;	cValidateur[16] = heureSeparationMARK ;	SetValidator(new TPXPictureValidator(cValidateur)) ;

	cRefYear = cRefDate ;
}

//
// Destructeur
//
NSEditDateHeure::~NSEditDateHeure()
{}

//
// Fonction d�clench� lorsque l'Edit perd le focus.
//
void
NSEditDateHeure::EvKillFocus(HWND hWndGetFocus)
{
try
{
	if (bCurrentlyWarning)
		return ;

  bool bCanLetItBe = true ;
  actionForKillFocus(bCanLetItBe) ;

  if (false == bCanLetItBe)
  {
    TEdit::EvKillFocus(hWndGetFocus) ;
    SetFocus() ;
  }

	TEdit::EvKillFocus(hWndGetFocus) ;
}
catch (...)
{
  erreur("Exception NSEditDateHeure::EvKillFocus.", standardError, 0) ;
}
}

void
NSEditDateHeure::actionForKillFocus(bool &bCanLetItBe)
{
	string sContent = string("") ;
	//
	// R�cup�ration du texte
	//
	int oldBuffLen = GetTextLen() ;
  if (oldBuffLen > 0)
  {
		char far* str = new char[oldBuffLen + 1] ;
    GetText(str, oldBuffLen + 1) ;
		sContent = string(str) ;
		delete[] str ;
	}
	EncoursEdition = false ;

	// V�rification de la validit� de la date
	string sMessage ;
	donne_date_inverse(sContent, sMessage, sLang) ;
	if (string("") == sMessage)
	{
		bCurrentlyWarning = true ;
    erreur("Date invalide.", standardError, 0) ;
    bCurrentlyWarning = false ;
    bValidContent = false ;

    // To prevent an unescapable wrong date
    sContenuTransfert = string(14, '0') ;
    donneBrut() ;

    SetText(sContenuBrut.c_str()) ;
    // sContenu = sContenuBrut;

    bCanLetItBe = false ;

    return ;
	}
  bCanLetItBe = true ;

	bValidContent = true ;

  int iNotifier = 1 ;
	//
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle && pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_EXECUTE) ;

	//
	// Pr�vient Big Brother (si l'�ventuelle fonction l'autorise)
	//
  Message theMessage("", "", "", "A", "", "", "1") ;

	if (iNotifier == 1)
	{		if (string("") == sContent)
		{
			if (string("") != sContenuBrut)
			{
				sContenuBrut = string("") ;
				donneTransfert() ;
        theMessage.SetComplement(sContenuTransfert) ;
        theMessage.SetType(Type) ;
        if (pControle && pControle->getTransfert())
        	pControle->getTransfert()->ctrlNotification(BF_CHECKED,
                                                      BF_UNCHECKED,
                                                      &theMessage) ;
      }
    }
		else
		{
    	sContenuBrut = sContent ;
      donneTransfert() ;
      theMessage.SetComplement(sContenuTransfert) ;
      theMessage.SetType(Type) ;

      if (pControle && pControle->getTransfert())
      {
				if (sContenuBrut == "")
        	pControle->getTransfert()->ctrlNotification(BF_UNCHECKED,
                                                      BF_CHECKED,
                                                      &theMessage) ;
				else
					pControle->getTransfert()->ctrlNotification(BF_CHECKED,
                                                      BF_CHECKED,
                                                      &theMessage) ;
			}
		}
	}

  //
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle && pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_POSTEXEC) ;
}

//---------------------------------------------------------------------------//  Description:	Transforme les donn�es NAUTILUS en donn�es � saisir par
//					l'utilisateur
//---------------------------------------------------------------------------
void
NSEditDateHeure::donneBrut()
{
	sContenuBrut = "00/00/0000 00:00:00" ;
	sContenuBrut[2] = dateSeparationMARK ;
	sContenuBrut[5] = dateSeparationMARK ;
	sContenuBrut[13] = heureSeparationMARK ;
	sContenuBrut[16] = heureSeparationMARK ;

	char date[20] ;

	TWindow* pParent = TWindow::GetParentO() ;
  NSDialog* pDlg = TYPESAFE_DOWNCAST(pParent, NSDialog) ;
  NSContexte *pContexte ;
  if ((pDlg) &&(pDlg->pBBItem) && (pDlg->pBBItem->pBigBoss) &&
                                        (pDlg->pBBItem->pBigBoss->pContexte))
		pContexte = (pDlg->pBBItem->pBigBoss->pContexte);

	string sProcessedDate = sContenuTransfert ;

	if ((sProcessedDate == string("")) || (strlen(sProcessedDate.c_str()) < 8))
  {
  	sProcessedDate = string("") ;

  	// char szMessage[11] ;

  	switch (cRefYear)
    {
    	case 'B' :   //birthday
      	pContexte->getPatient()->donneNaissance(date) ;
        sProcessedDate = string(date) ;
        break ;

      case 'N' :    //now
      {
      	NVLdVTemps tpsNow ;
    		tpsNow.takeTime() ;
				sProcessedDate = tpsNow.donneDateHeure() ;
        break ;
      }
    }
  }

	//
	// On passe de AAAAMMJJhhmmss � JJ/MM/AAAA hh:mm:ss
	//
	if (sProcessedDate != string(""))
	{
  	if (strlen(sProcessedDate.c_str()) >= 8)
    {
  		char szMessage[11] ;
    	char szDate[9] ;
    	strcpy(szDate, string(sProcessedDate, 0, 8).c_str()) ;
  		donne_date(szDate, szMessage, sLang) ;

    	sContenuBrut = string(szMessage) + string(" 00:00:00") ;

      if (strlen(sProcessedDate.c_str()) >= 14)
      {
        for (int i = 0; i < 2; i++)
        {
        	sContenuBrut[i+11] = sProcessedDate[i+8] ;
          sContenuBrut[i+14] = sProcessedDate[i+10] ;
          sContenuBrut[i+17] = sProcessedDate[i+12] ;
        }
      }
    }
	}
}

//---------------------------------------------------------------------------
//  Description:	Transforme les donn�es saisies par l'utilisateur
//					en donn�es NAUTILUS
//---------------------------------------------------------------------------
void
NSEditDateHeure::donneTransfert()
{
	sContenuTransfert = "";
	//
	// On passe de JJ/MM/AAAA hh:mm:ss � AAAAMMJJhhmmss
	//
	char cValidateur[] = "00/00/0000 00:00:00" ;

	cValidateur[2] = dateSeparationMARK ;
	cValidateur[5] = dateSeparationMARK ;
	cValidateur[13] = heureSeparationMARK ;
	cValidateur[16] = heureSeparationMARK ;

	if (sContenuBrut != cValidateur)
	{
  	donne_date_inverse(sContenuBrut, sContenuTransfert, sLang) ;
    if (strlen(sContenuBrut.c_str()) >= strlen(cValidateur))
    {
			sContenuTransfert += string(sContenuBrut, 11, 2) ;
			sContenuTransfert += string(sContenuBrut, 14, 2) ;
			sContenuTransfert += string(sContenuBrut, 17, 2) ;
    }
	}
}

//
//  TStatic
//
void
NSEditDateHeure::EvChar(uint key, uint repeatCount, uint flags)
{
	if (Validator && (key != VK_BACK) 	&&
                   (key != VK_RETURN) &&
                   (key != VK_SPACE) 	&&
                   (key != VK_DELETE) &&
                   (key != VK_TAB))
	{
  	if ((key < '0') || (key > '9'))
    	return ;

    uint   startSel, endSel ;
    GetSelection(startSel, endSel) ;

    int oldBuffLen = GetTextLen() ;
    char far* oldBuff = new char[oldBuffLen+1] ;

    GetText(oldBuff, oldBuffLen+1) ;
    size_t iGenuineLength = strlen(oldBuff) ;

    endSel = startSel ;

    // On doit �tre certain de ne pas �craser les '/'
    if      (startSel == 2)
    	startSel = 3 ;
    else if (startSel == 5)
    	startSel = 8 ;
    else if (startSel == 10)
    	startSel = 11 ;
    else if (startSel == 13)
    	startSel = 14 ;
    else if (startSel == 16)
    	startSel = 17 ;

    endSel = startSel ;

    if (startSel < iGenuineLength)
    {
    	oldBuff[startSel] = char(key) ;
      startSel++ ;
      endSel++ ;

      switch (cRefYear)
      {
      	case 'F' :    //  future  >=2000
        	// An 20xx
          if (oldBuff[6] == '0')
          	oldBuff[6] = '2' ;
          break ;
        case 'P' :       //past   <2000
        	if (oldBuff[6] == '0')
          {
          	oldBuff[6] = '1' ;
            oldBuff[7] = '9' ;
          }
          break ;
      }
    }

    // On saute les '/'
    if      (startSel == 2)
    	startSel = 3 ;
    else if (startSel == 5)
    {
    	if ((cRefYear == 'F') || (cRefYear == 'O'))
      	startSel = 8 ;
      else
      	startSel = 6 ;
    }
    else if (startSel == 10)
    	startSel = 11 ;
    else if (startSel == 13)
    	startSel = 14 ;
    else if (startSel == 16)
    	startSel = 17 ;

    endSel = startSel ;

    SetText(oldBuff) ;
    SetSelection(startSel, endSel) ;
    delete[] oldBuff ;
	}
  else if (key == VK_BACK)
  {
    uint   startSel, endSel ;
    GetSelection(startSel, endSel) ;

    // On saute les '/'
    if      (startSel == 3)
    	startSel = 2;
    else if (startSel == 6)
    	startSel = 5;
    else if (startSel == 11)
    	startSel = 10 ;
    else if (startSel == 14)
    	startSel = 13 ;
    else if (startSel == 17)
    	startSel = 16 ;

    int oldBuffLen = GetTextLen() ;
    char far* oldBuff = new char[oldBuffLen+1] ;

    GetText(oldBuff, oldBuffLen+1) ;

    endSel = startSel ;
    if (startSel > 0)
    {
    	startSel-- ;
      oldBuff[startSel] = '0' ;
    }
    SetText(oldBuff) ;
    SetSelection(startSel, endSel) ;
    delete[] oldBuff ;
  }
  else if ((key == VK_RETURN) || (key == VK_TAB) || (key == VK_SPACE))
  	//Process this message to avoid message beeps.
    return ;
  else
  	TStatic::EvChar(key, repeatCount, flags) ;
}

void
NSEditDateHeure::EvKeyDown(uint key, uint repeatCount, uint flags)
{
	if (key == VK_DELETE)
	{
		string dateVide = "00/00/0000 00:00:00" ;

    uint startSel, endSel ;
    GetSelection(startSel, endSel) ;

    int oldBuffLen = GetTextLen();
    if ((oldBuffLen <= 0) || (uint(oldBuffLen) < strlen(dateVide.c_str())))
    {
    	SetText(dateVide.c_str()) ;
      SetSelection(startSel, endSel) ;
      return ;
    }

    char far* oldBuff = new char[oldBuffLen + 1] ;
    GetText(oldBuff, oldBuffLen + 1) ;

    string dateEdit = string(oldBuff) ;

    if (startSel == endSel)
    {
    	dateEdit.replace(startSel, 1, dateVide, startSel, 1) ;
      startSel++ ;
      endSel++ ;
    }
    else
    {
    	dateEdit.replace(startSel, endSel-startSel, dateVide, startSel, endSel-startSel) ;
      startSel = endSel ;
    }

    strcpy(oldBuff, dateEdit.c_str()) ;

    SetText(oldBuff) ;
    SetSelection(startSel, endSel) ;
    delete[] oldBuff ;
	}
	else
		TStatic::EvKeyDown(key, repeatCount, flags) ;
}

bool
NSEditDateHeure::canWeClose()
{
	if (!bValidContent)
  	erreur("Date invalide.", standardError, 0) ;
	return bValidContent ;
}

//******************************************************************
//									TRAITEMENT DES HEURES
//******************************************************************

////----------------------------------------------------------------------
//
DEFINE_RESPONSE_TABLE1(NSEditHeure, NSEdit)
    EV_WM_KILLFOCUS,
    EV_WM_CHAR,
END_RESPONSE_TABLE;

//
// Constructeur
//
NSEditHeure::NSEditHeure(NSContexte* pCtx, TWindow* parent, int resId,  char* szTypeEdit, string sUserLang)
            :NSEdit(pCtx, parent, resId, szTypeEdit, sUserLang)
{
	strcpy(szType, szTypeEdit) ;
	//
	// Mise en place du validateur
	//
  char cValidateur[] = "##:##" ;
  cValidateur[2] = heureSeparationMARK ;
  SetValidator(new TPXPictureValidator(cValidateur)) ;
}

NSEditHeure::NSEditHeure(NSContexte* pCtx, TWindow* parent, int resId, char* szTypeEdit,
                const char far* text, int x, int y, int w, int h, string sUserLang,
                uint textLimit, bool multiline, TModule* module)
            : NSEdit(pCtx, parent, resId, szTypeEdit, text, x, y, w, h, sUserLang, textLimit, multiline, module)
{
	strcpy(szType, szTypeEdit) ;
	//
	// Mise en place du validateur
	//
  char cValidateur[] = "##:##" ;
  cValidateur[2] = heureSeparationMARK ;
  SetValidator(new TPXPictureValidator(cValidateur)) ;
}

//
// Destructeur
//
NSEditHeure::~NSEditHeure()
{}

//---------------------------------------------------------------------------//  Fonction: 		NSEditHeure::donneBrut()
//
//  Description:	Transforme les donn�es NAUTILUS en donn�es � saisir par
//						l'utilisateur
//---------------------------------------------------------------------------
void
NSEditHeure::donneBrut()
{
	//
  // On passe de mmss � mm:ss
  //
  if (strlen(sContenuTransfert.c_str()) >= 4)
        sContenuBrut =  string(sContenuTransfert, 0, 2) +
                        string(1,heureSeparationMARK) +
                        string(sContenuTransfert, 2, 2) ;
	else
	{
  	sContenuBrut = "00:00" ;
    sContenuBrut[2] = heureSeparationMARK ;
	}
}

//---------------------------------------------------------------------------//  Fonction: 		NSEditHeure::donneTransfert()
//
//  Description:	Transforme les donn�es saisies par l'utilisateur
//					   en donn�es NAUTILUS
//---------------------------------------------------------------------------
void
NSEditHeure::donneTransfert()
{
	sContenuTransfert = "" ;
  //
  // On passe de mm:ss � mmss
  //
  char cValidateur[] = "00:00" ;
  cValidateur[2] = heureSeparationMARK ;
  if (sContenuBrut != cValidateur)
   	    sContenuTransfert = string(sContenuBrut, 0, 2) +
                            string(sContenuBrut, 3, 2) ;
}
//
//  TStatic
//
void
NSEditHeure::EvChar(uint key, uint repeatCount, uint flags)
{
    if (Validator && (key != VK_BACK)   &&
   					 (key != VK_RETURN) &&
                     (key != VK_SPACE) 	&&
                     (key != VK_DELETE) &&
                     (key != VK_TAB))
    {
        int oldBuffLen = GetTextLen();
    	char far* oldBuff = new char[oldBuffLen+1];
        GetText(oldBuff, oldBuffLen+1);
        size_t  iGenuineSize = strlen(oldBuff) ;

    	size_t  startSel, endSel;
    	GetSelection(startSel, endSel);

        // On saute le ':'
        if (startSel == 2)
      	    startSel = 3;

        //Si la s�lection est multi-caract�res, on la ram�ne � 1 car.
        endSel = startSel;
        SetSelection(startSel, endSel);

    	bool wasAppending = endSel == iGenuineSize ;

  		if ((!wasAppending) && (startSel == endSel))
    	{
    		for (int i = startSel; i < oldBuffLen; i++)
         	    oldBuff[i] = oldBuff[i+1] ;
            SetText(oldBuff) ;
            SetSelection(startSel, endSel) ;
        }

    	bool preMsgModify = IsModified();             // Save (pre)  MODIFY flag

    	TStatic::EvChar(key, repeatCount, flags);     // Process the new char...

    	bool postMsgModify= IsModified();             // Save (post) MODIFY flag

    	GetSelection(startSel, endSel);
    	int buffLen = GetTextLen();
    	char far* buff = LockBuffer(max((int)TextLimit,max(oldBuffLen,buffLen))+1) ;

    	// Run the result of the edit through the validator.  If incorrect,
    	// then restore the original text.  Otherwise, range check & position
    	// the selection as needed.
    	//
    	if (!Validator->HasOption(voOnAppend) || wasAppending && (int(endSel) == buffLen))
        {
      	    if (!Validator->IsValidInput(buff, false))
            {
                strcpy(buff, oldBuff);          // Restore old buffer
        		postMsgModify = preMsgModify;   // Restore old modify state too!
      	    }
      	    else
            {
                if (wasAppending)
          		    startSel = endSel = strlen(buff); // may have autoFilled--move to end
      	    }
      	    UnlockBuffer(buff, true);
      	    SetSelection(startSel, endSel);
        }
    	else
        {
      	    if ((int(endSel) == buffLen) && !Validator->IsValidInput(buff, false))
                Validator->Error(this);
      	    UnlockBuffer(buff);
        }
    	SendMessage(EM_SETMODIFY, (TParam1)postMsgModify);

        //
        // On saute les caract�res inutiles
        //
    	GetSelection(startSel, endSel);
        if (startSel == endSel)
        {
      	    if (startSel == 2)
      		    SetSelection(3, 3);
   	    }

    	delete[] oldBuff;
	}
    else if (key == VK_BACK)
    {
        uint   startSel, endSel;
    	GetSelection(startSel, endSel);

        // On saute le ':'
        if (startSel == 3)
      	    startSel = 2;

   	    int oldBuffLen = GetTextLen();
    	char far* oldBuff = new char[oldBuffLen+1];
        GetText(oldBuff, oldBuffLen+1);

        if (startSel > 0)
        {
      	    startSel--;
      	    oldBuff[startSel] = '0';
        }
        endSel = startSel;
        SetText(oldBuff);
   	    SetSelection(startSel, endSel);
        delete[] oldBuff;
    }
    else if ((key == VK_RETURN) || (key == VK_TAB))
   	    //Process this message to avoid message beeps.
        return ;
    else if ((key == VK_SPACE))
   	    //Process this message to avoid message beeps.
        return ;
  	else
    	TStatic::EvChar(key, repeatCount, flags);
}

//// Fonction d�clench� lorsque l'Edit perd le focus.
//
void
NSEditHeure::EvKillFocus(HWND hWndGetFocus)
{
	int iNotifier = 1 ;

	string sContenu = string("") ;

	//
	// R�cup�re le texte
	//
	int oldBuffLen = GetTextLen() ;
  if (oldBuffLen > 0)
	{
		char far* str = new char[oldBuffLen + 1] ;
    GetText(str, oldBuffLen + 1) ;
		sContenu = string(str) ;
		delete[] str ;
	}
	EncoursEdition = false ;

	//
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle && pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_EXECUTE) ;

	//	// Pr�vient Big Brother (si l'�ventuelle fonction l'autorise)
	//
  Message theMessage("", "", "", "A", "", "", "1") ;

	if (iNotifier == 1)
	{
		if (sContenu == "")
		{
			if (sContenuBrut != "")
			{
				sContenuBrut = "" ;
				donneTransfert() ;
        theMessage.SetComplement(sContenuTransfert) ;
        theMessage.SetType(Type) ;
        if (pControle && pControle->getTransfert())
					pControle->getTransfert()->ctrlNotification(BF_CHECKED,
                                                      BF_UNCHECKED,
                                                      &theMessage) ;
			}
		}
		else
		{
    	sContenuBrut = sContenu ;
      donneTransfert() ;
      theMessage.SetComplement(sContenuTransfert) ;
      theMessage.SetType(Type) ;

      if (pControle && pControle->getTransfert())
      {
				if (sContenuBrut == "")
					pControle->getTransfert()->ctrlNotification(BF_UNCHECKED,
                                                      BF_CHECKED,
                                                      &theMessage) ;
				else
					pControle->getTransfert()->ctrlNotification(BF_CHECKED,
                                                      BF_CHECKED,
                                                      &theMessage) ;
			}
		}
	}

	//
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle && pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_POSTEXEC) ;

	TEdit::EvKillFocus(hWndGetFocus) ;
}

//******************************************************************////                  TRAITEMENT DES EDIT NO LEXIQUE////******************************************************************DEFINE_RESPONSE_TABLE1(NSEditNoLex, NSEdit)	EV_WM_KEYUP,
	EV_WM_CHAR,
	EV_WM_KILLFOCUS,
END_RESPONSE_TABLE;

//// Constructeur
//
NSEditNoLex::NSEditNoLex(NSContexte* pCtx, TWindow* parent, int resId,  char* szTypeEdit, string sUserLang, int iTextLimit)
            :NSEdit(pCtx, parent, resId, szTypeEdit, sUserLang)
{
	string sValidateur = "" ;
	sContenuBrut = "" ;
	sContenuTransfert = "" ;
	pControle = 0 ;
	DisableTransfer() ;
	strcpy(szType, szTypeEdit) ;

	EncoursEdition = false ;	parentEdit = parent ;
	TextLimit = iTextLimit ;

	//	// Mise en place du validateur
	//

	// SetValidator(new TFilterValidator("0-9A-Za-z. "));}

NSEditNoLex::NSEditNoLex(NSContexte* pCtx, TWindow* parent, int resId, char* szTypeEdit,
                const char far* text, int x, int y, int w, int h, string sUserLang,
                uint textLimit, bool multiline, TModule* module)
            : NSEdit(pCtx, parent, resId, szTypeEdit, text, x, y, w, h, sUserLang, textLimit, multiline, module)
{
	string sValidateur = "" ;
	sContenuBrut = "" ;
	sContenuTransfert = "" ;
	pControle = 0 ;
	DisableTransfer() ;
	strcpy(szType, szTypeEdit) ;

	EncoursEdition = false ;	parentEdit = parent ;
	TextLimit = textLimit ;

	//	// Mise en place du validateur
	//

	// SetValidator(new TFilterValidator("0-9A-Za-z. "));
}

//// Destructeur
//
NSEditNoLex::~NSEditNoLex()
{}

//// Fonction d�clench� lorsque l'Edit perd le focus.
//
void
NSEditNoLex::EvKillFocus(HWND hWndGetFocus)
{
  bool bCanLetItBe = false ;
  actionForKillFocus(bCanLetItBe) ;
  if (false == bCanLetItBe)
    return ;

  /*********************************************
  //
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle && pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_POSTEXEC, hWndGetFocus);
    *******************************************/

	TEdit::EvKillFocus(hWndGetFocus) ;

	if (pControle && pControle->getFonction())
		pControle->getFonction()->execute(NSDLGFCT_POSTEXEC, hWndGetFocus) ;
}

void
NSEditNoLex::actionForKillFocus(bool &bCanLetItBe)
{
  bool bExecPostExec = bCanLetItBe ;

	int iNotifier = 1 ;

	string sContent = string("") ;
	//
	// R�cup�re le texte
	//
	int oldBuffLen = GetTextLen() ;
	if (oldBuffLen > 0)
	{
		char far* str = new char[oldBuffLen + 1] ;
    GetText(str, oldBuffLen + 1) ;
		sContent = string(str) ;
		delete[] str ;
	}
	EncoursEdition = false ;

	//
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle && pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_EXECUTE) ;

	//
	// Pr�vient Big Brother (si l'�ventuelle fonction l'autorise)
	//
  Message theMessage ;

	if (iNotifier == 1)
	{
		if (string("") == sContent)
		{
			if (string("") != sContenuBrut)
			{
				sContenuBrut = string("") ;
				donneTransfert();
        if (szType[0] == 'L')
        	theMessage.SetTexteLibre(sContenuTransfert) ;
        else
        	theMessage.SetComplement(sContenuTransfert) ;
        theMessage.SetType(Type);
        if (pControle && pControle->getTransfert())
        	pControle->getTransfert()->ctrlNotification(BF_CHECKED,
                                                      BF_UNCHECKED,
                                                      &theMessage) ;
      }
    }
		else
		{
    	sContenuBrut = sContent ;
      if      ('N' == szType[1])
      	vraiemaj(&sContenuBrut) ;
      else if ('P' == szType[1])
      	// firstmaj(&sContenuBrut) ;
        sContenuBrut = getProperFirstName(sContenuBrut) ;

      donneTransfert() ;
      if ('L' == szType[0])
      	theMessage.SetTexteLibre(sContenuTransfert) ;
      else
      	theMessage.SetComplement(sContenuTransfert) ;
      theMessage.SetType(Type) ;

      if (pControle && pControle->getTransfert())
      {
				if (string("") == sContenuBrut)
        	pControle->getTransfert()->ctrlNotification(BF_UNCHECKED,
                                                      BF_CHECKED,
                                                      &theMessage) ;
				else
        	pControle->getTransfert()->ctrlNotification(BF_CHECKED,
                                                      BF_CHECKED,
                                                      &theMessage) ;
      }
    }  }

  //
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (bExecPostExec && pControle && pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_POSTEXEC) ;

  bCanLetItBe = true ;
}
voidNSEditNoLex::executeKillFocusBehaviour(){	string sDataToCome = pControle->getTransfert()->pTransfertMessage->GetTexteLibre() ;	if (szType[1] == 'N')  	vraiemaj(&sDataToCome) ;
  else if (szType[1] == 'P')
    // firstmaj(&sDataToCome) ;    sDataToCome = getProperFirstName(sDataToCome) ;	pControle->getTransfert()->pTransfertMessage->SetTexteLibre(sDataToCome) ;}//---------------------------------------------------------------------------
//  Function: 		NSEditNoLex::donneTransfert()
//
//  Description:	Transforme les donn�es saisies par l'utilisateur
//					   en donn�es NAUTILUS
//
//  Arguments:		Aucun
//
//  Returns:		Rien
//---------------------------------------------------------------------------

voidNSEditNoLex::donneTransfert()
{
	signed int i = strlen(sContenuBrut.c_str()) ;
	if (i > 0)
  {
  	i-- ;
    for (; (i >= 0) && (sContenuBrut[i] == ' '); i--)
    	sContenuBrut[i] = '\0' ;
  }
  if (sContenuBrut != "")
  	sContenuTransfert = sContenuBrut ;
  else
  	sContenuTransfert = "" ;
}

//---------------------------------------------------------------------------
//  Function: 		NSEdit::donneBrut()
//
//  Description:	Transforme les donn�es NAUTILUS en donn�es � saisir par//						l'utilisateur
//
//  Arguments:		Aucun
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void NSEditNoLex::donneBrut()
{
	sContenuBrut = sContenuTransfert ;
}

//---------------------------------------------------------------------------
//  Function: 		NSEdit::activeControle(int activation, string message)
//
//  Description:	Initialise le contr�le avant affichage de la bo�te de
//						dialogue
//
//  Arguments:		activation : BF_CHECKED ou BF_UNCHECKED
//						message    : Contenu de la bo�te
//
//  Returns:		Rien
//---------------------------------------------------------------------------
void
NSEditNoLex::activeControle(int activation, Message* pMessage)
{
  // Gestion windows standard
  // Windows standard behaviour
  if (pControle && pControle->getNSDialog())
  {
    NSSuper* pSuper = pControle->getNSDialog()->pBBItem->pBigBoss->pContexte->getSuperviseur() ;
    if ((pSuper && pSuper->getDPIO()) && (pSuper->getDPIO()->bReturnCloses))
      bWinStd = true ;
  }

	switch (activation)
	{
		case BF_CHECKED   :

      sContenuTransfert = pMessage->GetTexteLibre() ;
      Type = pMessage->GetType() ;
      donneBrut() ;
      SetText(sContenuBrut.c_str()) ;
      break ;

		case BF_UNCHECKED :

      sContenuTransfert = "" ;
      donneBrut() ;
      SetText(sContenuBrut.c_str()) ;
      break ;
  }
}

//---------------------------------------------------------------------------
//  Function: 		NSEdit::Transfer(TTransferDirection direction,
//															 int* pActif, string* pMessage)
//
//  Description:	Si direction = tdSetData
//							Initialise le contr�le
//						Si direction = tdGetData
//							Initialise pActif et pMessage
//
//  Arguments:		direction : tdGetData ou tdSetData
//
//  Returns:		1 si le transfert a fonctionn�
//						0 sinon
//---------------------------------------------------------------------------
uint
NSEditNoLex::Transferer(TTransferDirection direction, int* pActif, Message* pMessage)
{
	if (direction == tdSetData)
	{
		switch (*pActif)
		{
			case 0 :

      	sContenuTransfert = "" ;
        donneBrut() ;
        SetText(sContenuBrut.c_str()) ;
        break ;

			case 1 :

      	if (szType[0] == 'L')
        	sContenuTransfert = pMessage->GetTexteLibre() ;
        else
        	sContenuTransfert = pMessage->GetComplement() ;
        Type = pMessage->GetType() ;
        donneBrut() ;
        SetText(sContenuBrut.c_str()) ;
        break ;
		}
	}
  else if (direction == tdGetData)
	{
  	if (EncoursEdition)
    {
    	//
			// R�cup�re le texte
			//
      int oldBuffLen = GetTextLen() ;
      if (oldBuffLen > 0)
      {
      	char far* str = new char[oldBuffLen + 1] ;
      	GetText(str, oldBuffLen + 1) ;
				sContenuBrut = string(str) ;
				delete[] str ;
      }
      else
      	sContenuBrut = string("") ;
    }

    donneTransfert() ;
    if (sContenuTransfert == "")
    	*pActif = 0 ;
    else
    	*pActif = 1 ;

    if (pMessage)
    {
    	if (szType[0] == 'L')
      	pMessage->SetTexteLibre(sContenuTransfert) ;
      else
      	pMessage->SetComplement(sContenuTransfert) ;
      pMessage->SetType(Type) ;

      string sEtiquette = string("") ;
      if (pControle->getTransfert())
      	sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

      pMessage->MettreAJourCertitudePluriel(sEtiquette) ;
    }
  }
	return 1 ;
}

uint
NSEditNoLex::TempTransferer(int* pActif, Message* pMessage)
{
	if (EncoursEdition)
	{
  	//
    // R�cup�re le texte
    //
    int oldBuffLen = GetTextLen() ;
    if (oldBuffLen > 0)
    {
    	char far* str = new char[oldBuffLen + 1] ;
      GetText(str, oldBuffLen + 1) ;
      sContenuBrut = string(str) ;
      delete[] str ;
  	}
    else
    	sContenuBrut = string("") ;
  }

  donneTransfert() ;

  if (sContenuTransfert == "")
  	*pActif = 0 ;
  else
  	*pActif = 1 ;

  if (szType[0] == 'L')
  	pMessage->SetTexteLibre(sContenuTransfert) ;
  else
  	pMessage->SetComplement(sContenuTransfert) ;
  pMessage->SetType(Type) ;

  string sEtiquette = string("") ;
  if (pControle->getTransfert())
  	sEtiquette = pControle->getTransfert()->pBBFilsItem->getItemLabel() ;

  pMessage->MettreAJourCertitudePluriel(sEtiquette) ;

	return 1 ;
}

string
NSEditNoLex::getProperFirstName(string sInitialEntry)
{
  if (string("") == sInitialEntry)
    return string("") ;

  string sReturn = sInitialEntry ;
  firstmaj(&sReturn) ;

  //
  // Load the file
  //
  string sFileName = pContexte->PathName("FPER") + string("firstNames.txt") ;

  ifstream inFile ;
  inFile.open(sFileName.c_str()) ;
  if (!inFile)
    return sReturn ;

  int iCounter = 0 ;
  int iLoopThreshold = 100 ;

  string sPseumajEntry = pseumaj(sInitialEntry) ;

  string sLine ;
  while (false == inFile.eof())
  {
		getline(inFile, sLine) ;

    strip(sLine, stripBoth) ;
    string sLineText = pseumaj(sLine) ;

    if (sLineText == sPseumajEntry)
    {
      sReturn = sLine ;
      break ;
    }

    iCounter++ ;
    if (iCounter > iLoopThreshold)
    {
      iCounter = 0 ;
      pContexte->getSuperviseur()->getApplication()->PumpWaitingMessages() ;
    }
  }

  inFile.close() ;

  return sReturn ;
}

//******************************************************************//						  TRAITEMENT DES STATICS
//******************************************************************

DEFINE_RESPONSE_TABLE1(NSStatic, TStatic)
	EV_WM_SETFOCUS,
END_RESPONSE_TABLE;

// Constructeur
NSStatic::NSStatic(NSContexte* pCtx, TWindow* parent, int resId)
         :TStatic(parent, resId), NSRoot(pCtx)
{
	pControle = 0 ;
	DisableTransfer() ;
}

NSStatic::NSStatic(NSContexte* pCtx, TWindow* parent, int resId, const char far* title,
                    int x, int y, int w, int h,
                    uint textLimit, TModule* module)
            :TStatic(parent, resId, title, x, y, w, h, textLimit, module), NSRoot(pCtx)
{
	pControle = 0 ;
	DisableTransfer() ;
}

// Destructeur
NSStatic::~NSStatic()
{
}

// Fonction de transfert de donn�es entre big brother et le contr�le// Pour un contr�le Static, il ne se passe rien
uint
NSStatic::Transferer(TTransferDirection /* direction */, int* /* pActif */,
                                                            Message* /* pMessage */)
{
	return 1 ;
}

uint
NSStatic::TempTransferer(int* /* pActif */, Message* /* pMessage */)
{
	return 1 ;
}

void
NSStatic::SetupWindow()
{
	TStatic::SetupWindow() ;

	// TWindow*  pParent = TWindow::GetParentO() ;
	// NSDialog* pDlg    = TYPESAFE_DOWNCAST(pParent, NSDialog) ;

  NSSuper*  pSuper  = pContexte->getSuperviseur() ;
  SetWindowFont(*(pSuper->getDialogFont()), false) ;
}

void
NSStatic::EvSetFocus(HWND /* hWndLostFocus */)
{
	// si on gagne le focus, on s'en d�barrasse aussit�t
	if (pControle && pControle->getNSDialog())
		pControle->getNSDialog()->ActiveControlSuivant(pControle) ;
}

bool
NSStatic::canWeClose()
{
	return true ;
}

