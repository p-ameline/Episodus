#include<owl\window.h>
#include "nsbb\nspatpat.h"

#include "nsbb\nschkbox.h"#include "nsbb\nsbouton.h"
#include "nsbb\nsradiob.h"
#include "nsbb\nsedit.h"
#include "nsbb\nscombo.h"
#include "nsbb\nsgroupe.h"
#include "nautilus\nssuper.h"
#include "nautilus\nscsvue.h"
#include "nsbb\nsedilex.h"
#include "partage\nsdivfct.h"

#include "nsbb\nsbb.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbbsmal.h"
#include "nsbb\nsdlg.h"
#include "nsbb\nsbb_dlg.h"
#include "nsbb\nsbbdivfct.h"
#include "nsbb\nstrnode.h"
#include "nsbb\nslistwind.h"
#include "nssavoir\nsguide.h"
#include "nsepisod\nsldvuti.h"
//#include "nautilus\nscsvue.h"

//***************************************************************************
// Impl�mentation des m�thodes NSControle
//***************************************************************************

//
// Constructeur par d�faut
//
NSControle::NSControle(NSContexte* pCtx)
           :NSRoot(pCtx)
{
	pNSDialog         = 0 ;
	pTransfert        = 0 ;
	pNSCtrl           = 0 ;
	sIdentite         = string("") ;
	iType             = isUndefined ;
	pNSDlgFct         = 0 ;
	bGestionMultiple  = false ;
  bVisible          = true ;

	sFilling          = string("") ;
	sFillingFilter    = string("") ;
  sFillingStarter   = string("") ;
	sFillingEndPeriod = string("") ;
	sPathControl      = string("") ;
}

////  Constructeur avec recherche de liaison
//
NSControle::NSControle(NSContexte* pCtx, BBItem* pBBItem, string sIdent, string sDlgFct)
           :NSRoot(pCtx)
{
try
{
	sIdentite  = sIdent ;
	iType      = isUndefined ;
	pNSDialog  = 0 ;
	pNSCtrl	   = 0 ;
	pTransfert = 0 ;
	bGestionMultiple = false ;
  bVisible   = true ;

	sFilling          = string("") ;
	sFillingFilter    = string("") ;
  sFillingStarter   = string("") ;
	sFillingEndPeriod = string("") ;
	sPathControl      = string("") ;

	lierTransfert(pBBItem) ;

	if (string("") != sDlgFct)
		pNSDlgFct = new NSDlgFonction(pContexte, pBBItem->pBigBoss, pBBItem,
                                                  sDlgFct, this, pNSResModule) ;
	else
		pNSDlgFct = 0 ;
}
catch (...)
{
	erreur("Exception NSControle ctor.", standardError, 0);
}
}

////  Destructeur
//
NSControle::~NSControle()
{
	//
	// Ne pas faire "delete pTransfert", car l'objet point� par pTransfert est
	// cr�� et d�truit par un objet de type BBFilsItem
	//
	// En th�orie, le travail a d�j� �t� r�alis� par le BBFilsItem
	// lorsqu'il effectue okFermerDialogue()
	//
 	if (pNSDlgFct)
  {
  	delete pNSDlgFct ;
    pNSDlgFct = 0 ;
  }

  if (pNSCtrl)
  {
    switch (iType)
    {
    	case isCaseACocher :
      	(static_cast<NSCheckBox*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isRadioBtn	:
      	(static_cast<NSRadioButton*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isEdit	:
      	(static_cast<NSEdit*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isEditDate	:
      	(static_cast<NSEditDate*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isEditDateHeure	:
      	(static_cast<NSEditDateHeure*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isTreeNode	:      	(static_cast<NSTreeNode*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isTreeWindow :
      	(static_cast<NSTreeWindow*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isAdrListWindow :
      	(static_cast<NSAdrListWindow*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isCorListWindow :
      	(static_cast<NSCorListWindow*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isNSCSVue :      	(static_cast<NSCsVue*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isEditLexique :
      	(static_cast<NSEditLexique*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isEditLexiqueDerive :      	(static_cast<NSEditLexiqueDerive*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isEditNoLexique :
      	(static_cast<NSEditNoLex*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isStatic :
      	(static_cast<NSStatic*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isComboClassif :
      	(static_cast<NSComboClassif*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isComboSemantique :
      	(static_cast<NSComboSemantique*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isHistoryListWindow :
      	(static_cast<NSHistorizedListWindow*>(pNSCtrl))->pControle = 0 ;
        break ;

      case isHistoryValListWindow :
      	(static_cast<NSHistorizedValListWindow*>(pNSCtrl))->pControle = 0 ;
        break ;
    }
	}

	if (pTransfert)
	{
  	pTransfert->pControle = 0 ;
    pTransfert = 0 ;
	}
}
//
// Can we close the mother dialog box ?
//
bool
NSControle::canWeClose()
{
	if (!pNSCtrl)
		return true ;

	switch (iType)
	{
  	case isCaseACocher :
    	return (static_cast<NSCheckBox*>(pNSCtrl))->canWeClose() ;

    case isRadioBtn	:
    	return (static_cast<NSRadioButton*>(pNSCtrl))->canWeClose() ;

    case isEdit	:
    	return (static_cast<NSEdit*>(pNSCtrl))->canWeClose() ;

    case isEditDate	:
    	return (static_cast<NSEditDate*>(pNSCtrl))->canWeClose() ;

    case isEditDateHeure	:
    	return (static_cast<NSEditDateHeure*>(pNSCtrl))->canWeClose() ;

    case isTreeNode	:
    	return (static_cast<NSTreeNode*>(pNSCtrl))->canWeClose() ;

    case isTreeWindow :
    	return (static_cast<NSTreeWindow*>(pNSCtrl))->canWeClose() ;

    case isAdrListWindow :
    	return (static_cast<NSAdrListWindow*>(pNSCtrl))->canWeClose();

    case isCorListWindow :
    	return (static_cast<NSCorListWindow*>(pNSCtrl))->canWeClose();

    case isNSCSVue :    	return (static_cast<NSCsVue*>(pNSCtrl))->canWeClose() ;
    case isEditLexique :
    	return (static_cast<NSEditLexique*>(pNSCtrl))->canWeClose() ;

    case isEditLexiqueDerive :    	return (static_cast<NSEditLexiqueDerive*>(pNSCtrl))->canWeClose() ;
    case isEditNoLexique :
    	return (static_cast<NSEditNoLex*>(pNSCtrl))->canWeClose() ;

    case isStatic :
    	return (static_cast<NSStatic*>(pNSCtrl))->canWeClose() ;

    case isGroup :
    	return (static_cast<NSGroupBox*>(pNSCtrl))->canWeClose() ;

    case isComboClassif :
    	return (static_cast<NSComboClassif*>(pNSCtrl))->canWeClose() ;

    case isComboSemantique :
    	return (static_cast<NSComboSemantique*>(pNSCtrl))->canWeClose() ;

    case isHistoryListWindow :
    	return (static_cast<NSHistorizedListWindow*>(pNSCtrl))->canWeClose() ;

    case isHistoryValListWindow :
    	return (static_cast<NSHistorizedValListWindow*>(pNSCtrl))->canWeClose() ;
	}

	return true ;
}

HWND
NSControle::getHWND()
{
	if (!pNSCtrl)
  	return 0 ;

  switch (iType)
  {
    case isCaseACocher :
    	return (static_cast<NSCheckBox*>(pNSCtrl))->HWindow ;

    case isRadioBtn	:
    	return (static_cast<NSRadioButton*>(pNSCtrl))->HWindow ;

    case isEdit	:
    	return (static_cast<NSEdit*>(pNSCtrl))->HWindow ;

    case isEditDate	:
    	return (static_cast<NSEditDate*>(pNSCtrl))->HWindow ;

    case isEditDateHeure	:
    	return (static_cast<NSEditDateHeure*>(pNSCtrl))->HWindow ;

    case isTreeNode	:
    	return 0 ;

    case isTreeWindow :
    	return (static_cast<NSTreeWindow*>(pNSCtrl))->HWindow ;

    case isAdrListWindow :
    	return (static_cast<NSAdrListWindow*>(pNSCtrl))->HWindow ;

    case isCorListWindow :
    	return (static_cast<NSCorListWindow*>(pNSCtrl))->HWindow ;

    case isNSCSVue :    	return (static_cast<NSCsVue*>(pNSCtrl))->HWindow ;
    case isEditLexique :
    	return (static_cast<NSEditLexique*>(pNSCtrl))->HWindow ;

    case isEditLexiqueDerive :    	return 0 ;
    case isEditNoLexique :
    	return (static_cast<NSEditNoLex*>(pNSCtrl))->HWindow ;

    case isStatic :
    	return (static_cast<NSStatic*>(pNSCtrl))->HWindow ;

    case isGroup :
    	return (static_cast<NSGroupBox*>(pNSCtrl))->HWindow ;

    case isComboClassif :
    	return (static_cast<NSComboClassif*>(pNSCtrl))->HWindow ;

    case isComboSemantique :
    	return (static_cast<NSComboSemantique*>(pNSCtrl))->HWindow ;

    case isHistoryListWindow :
    	return (static_cast<NSHistorizedListWindow*>(pNSCtrl))->HWindow ;

  	case isHistoryValListWindow :
    	return (static_cast<NSHistorizedValListWindow*>(pNSCtrl))->HWindow ;
  }

	return 0 ;
}

//
// Constructeur copie
//
NSControle::NSControle(const NSControle& src)
           :NSRoot(src.pContexte)
{
try
{
	// Attention : l'objet point� par pTransfert doit rester unique.
	//             Ne pas le dupliquer.
	pTransfert = src.pTransfert ;
	pNSDialog  = src.pNSDialog ;
	pNSCtrl	   = src.pNSCtrl ;
	sIdentite  = src.sIdentite ;
	iType      = src.iType ;
  bVisible   = src.bVisible ;
	bGestionMultiple = src.bGestionMultiple ;

	if (src.pNSDlgFct)
		pNSDlgFct = new NSDlgFonction(pContexte, src.pNSDlgFct->pBigBoss,
                                      src.pNSDlgFct->pBBItem,
                                      src.pNSDlgFct->sNomFonction, this) ;
	else
		pNSDlgFct = 0 ;

	sFilling          = src.sFilling ;
	sFillingFilter    = src.sFillingFilter ;
  sFillingStarter   = src.sFillingStarter ;
	sFillingEndPeriod = src.sFillingEndPeriod ;
	sPathControl      = src.sPathControl ;
}
catch (...)
{
	erreur("Exception NSControle copy ctor.", standardError, 0) ;
}
}

void
NSControle::activateParent()
{
	if (pNSDialog)
		pNSDialog->activateParent() ;
}

/*void
NSControle::SetFocus()
{
    activateParent();
}   */


// --------------------------------------------------------------------------// -------------------- M�thodes de NSControleVector ------------------------
// --------------------------------------------------------------------------

//
// Constructeur copie
//
NSControleVector::NSControleVector(NSControleVector& rv)
                 :NSControleVectorCtrl()
{
try
{
	if (!(rv.empty()))
		for (iterNSControle i = rv.begin(); i != rv.end(); i++)
			push_back(new NSControle((*i)->pContexte)) ;
}
catch (...)
{
	erreur("Exception NSControleVector copy ctor.", standardError, 0) ;
}
}

//
// Destructeur
//
void
NSControleVector::vider()
{
	if (empty())
  	return ;

	for (iterNSControle i = begin(); i != end(); )
	{
  	delete *i ;
    erase(i) ;
  }
}

NSControleVector::~NSControleVector(){
	vider() ;
}

//// Op�rateur d'affectation
//
NSControleVector&
NSControleVector::operator=(NSControleVector src)
{
	if (this == &src)
  	return *this ;

try
{
	vider() ;

  if (!(src.empty()))  	for (iterNSControle i = src.begin(); i != src.end(); i++)
    	push_back(new NSControle((*i)->pContexte)) ;
  return *this ;
}
catch (...)
{
	erreur("Exception NSControleVector (=).", standardError, 0) ;
	return *this ;
}
}

//// Demande au contr�le de se mettre dans l'�tat voulu
//
// Arguments:  activation : �tat souhait�
//             message	  : renseignements compl�mentaires
//
void
NSControle::activeControle(int activation, Message* pMessage)
{
	if (NULL == pNSCtrl)
  	return ;

	switch (iType)  {
  	case isCaseACocher :
    	(static_cast<NSCheckBox*>(pNSCtrl))->
                                        activeControle(activation, pMessage ) ;
      break ;

    case isRadioBtn	:
    	(static_cast<NSRadioButton*>(pNSCtrl))->
                                        activeControle(activation, pMessage ) ;
      break ;

    case isEdit	 	   :    case isEditDate  :    case isEditDateHeure :    	(static_cast<NSEdit*>(pNSCtrl))->
                                        activeControle(activation, pMessage ) ;
      break ;

    case isTreeNode	   :
    	(static_cast<NSTreeNode*>(pNSCtrl))->
                                        activeControle(activation, pMessage ) ;
      break ;

    case isTreeWindow  :
            (static_cast<NSTreeWindow*>(pNSCtrl))->
                                        activeControle(activation, pMessage );
            break ;

        case isAdrListWindow  :
            (static_cast<NSAdrListWindow*>(pNSCtrl))->
                                        activeControle(activation, pMessage );
            break ;

        case isCorListWindow  :
            (static_cast<NSCorListWindow*>(pNSCtrl))->
                                        activeControle(activation, pMessage );
            break ;

        case isNSCSVue     :            (static_cast<NSCsVue*>(pNSCtrl))->
                                        activeControle(activation, pMessage );
            break ;

        case isBtn		   :            (static_cast<NSButton*>(pNSCtrl))->
                                        activeControle(activation, pMessage );
            break ;

        case isEditLexique :            (static_cast<NSEditLexique*>(pNSCtrl))->
                                        activeControle(activation, pMessage );
            break ;

        case isEditLexiqueDerive :            (static_cast<NSEditLexiqueDerive*>(pNSCtrl))->
                                        activeControle(activation, pMessage );
            break ;

        case isEditNoLexique :
            (static_cast<NSEditNoLex*>(pNSCtrl))->
                                        activeControle(activation, pMessage );
            break ;

        case isComboClassif :
            (static_cast<NSComboClassif*>(pNSCtrl))->
                                        activeControle(activation, pMessage );
            break ;

        case isComboSemantique :
            (static_cast<NSComboSemantique*>(pNSCtrl))->
                                        activeControle(activation, pMessage );
            break ;

        case isHistoryListWindow :
            (static_cast<NSHistorizedListWindow*>(pNSCtrl))->
                                        activeControle(activation, pMessage );
            break ;

        case isHistoryValListWindow :
            (static_cast<NSHistorizedValListWindow*>(pNSCtrl))->
                                        activeControle(activation, pMessage );
            break ;
    }
}

////  Transf�re les donn�es du contr�le vers le TransfertInfo
//						et vice-versa suivant la direction
//
//  Arguments :	direction : tdGetData ou tdSetData
//
//  Returns :	1 si le transfert a fonctionn�
//				0 sinon
uint
NSControle::Transfer(TTransferDirection direction)
{
	if (NULL == pNSCtrl)
		return 0 ;

	switch (iType)
	{
    case isCaseACocher :
        return (static_cast<NSCheckBox*>(pNSCtrl))->
                            Transferer(direction,
                                       &(pTransfert->iActif),
                                       (pTransfert->pTransfertMessage ));

    case isRadioBtn	 :
        return (static_cast<NSRadioButton*>(pNSCtrl))->
                            Transferer(direction,
                                       &(pTransfert->iActif),
                                       (pTransfert->pTransfertMessage ));

    case isTreeNode	 :
        return (static_cast<NSTreeNode*>(pNSCtrl))->
                            Transferer(direction,
                                       &(pTransfert->iActif),
                                       (pTransfert->pTransfertMessage));

    case isEdit	 	       :
    case isEditDate      :
    case isEditDateHeure :
        return (static_cast<NSEdit*>(pNSCtrl))->
                            Transferer(direction,
                                       &(pTransfert->iActif),
                                       (pTransfert->pTransfertMessage ));

    case isEditLexique :
        return (static_cast<NSEditLexique*>(pNSCtrl))->
                            Transferer(direction,
                                       &(pTransfert->iActif),
                                       (pTransfert->pTransfertMessage ));

    case isEditLexiqueDerive :
        return (static_cast<NSEditLexiqueDerive*>(pNSCtrl))->
                            Transferer(direction,
                                       &(pTransfert->iActif),
                                       (pTransfert->pTransfertMessage ));

    case isEditNoLexique :
            return (static_cast<NSEditNoLex*>(pNSCtrl))->
                                Transferer(direction,
                                           &(pTransfert->iActif),
                                           (pTransfert->pTransfertMessage ));

    case isComboClassif :
          return (static_cast<NSComboClassif*>(pNSCtrl))->
                              Transferer(direction,
                                         &(pTransfert->iActif),
                                         (pTransfert->pTransfertMessage ));

    case isComboSemantique :
          return (static_cast<NSComboSemantique*>(pNSCtrl))->
                              Transferer(direction,
                                         &(pTransfert->iActif),
                                         (pTransfert->pTransfertMessage ));

	}
	return 1 ;
}

uintNSControle::TransferFinal(TTransferDirection direction)
{
    if (!pNSCtrl)
        return 0;


    switch (iType)
    {

        case isCaseACocher :
            return (static_cast<NSCheckBox*>(pNSCtrl))->Transferer(direction,
                                            &(pTransfert->iActif),
                                            (pTransfert->pTransfertMessage));

        case isRadioBtn	:
            return (static_cast<NSRadioButton*>(pNSCtrl))->Transferer(direction,
                                            &(pTransfert->iActif),
                                            (pTransfert->pTransfertMessage)) ;

        case isTreeNode	:
            return (static_cast<NSTreeNode*>(pNSCtrl))->TransfererFinal(direction,
                                            &(pTransfert->iActif),
                                            (pTransfert->pTransfertMessage)) ;

        case isEdit	:
            return (static_cast<NSEdit*>(pNSCtrl))->Transferer(direction,
                                            &(pTransfert->iActif),
                                            (pTransfert->pTransfertMessage)) ;

        case isEditDate	:
            return (static_cast<NSEditDate*>(pNSCtrl))->Transferer(direction,
                                            &(pTransfert->iActif),
                                            (pTransfert->pTransfertMessage)) ;

        case isEditDateHeure	:
            return (static_cast<NSEditDateHeure*>(pNSCtrl))->Transferer(direction,
                                            &(pTransfert->iActif),
                                            (pTransfert->pTransfertMessage)) ;

        case isEditLexique :
            return (static_cast<NSEditLexique*>(pNSCtrl))->Transferer(direction,
                                            &(pTransfert->iActif),
                                            (pTransfert->pTransfertMessage)) ;

        case isEditLexiqueDerive :
            return (static_cast<NSEditLexiqueDerive*>(pNSCtrl))->Transferer(direction,
                                            &(pTransfert->iActif),
                                            (pTransfert->pTransfertMessage));

        case isEditNoLexique :
            return (static_cast<NSEditNoLex*>(pNSCtrl))->Transferer(direction,
                                            &(pTransfert->iActif),
                                            (pTransfert->pTransfertMessage));

        case isComboClassif :
            return (static_cast<NSComboClassif*>(pNSCtrl))->Transferer(direction,
                                            &(pTransfert->iActif),
                                            (pTransfert->pTransfertMessage));

        case isComboSemantique :
            return (static_cast<NSComboSemantique*>(pNSCtrl))->Transferer(direction,
                                            &(pTransfert->iActif),
                                            (pTransfert->pTransfertMessage));

       /* case isHistoryListWindow :
            return (static_cast<NSHistorizedListWindow*>(pNSCtrl))->Transferer(direction,
                                            &(pTransfert->iActif),
                                            (pTransfert->pTransfertMessage ));  */


	}
	return 1;
}

uint
NSControle::TempTransfer()
{
    if (!pNSCtrl)
        return 0;

    switch (iType)
    {

        case isCaseACocher :
            return (static_cast<NSCheckBox*>(pNSCtrl))->
                                TempTransferer(&(pTransfert->iTmpActif),
                                           (pTransfert->pTmpTransfertMessage ));

        case isRadioBtn	 :
            return (static_cast<NSRadioButton*>(pNSCtrl))->
                                TempTransferer(&(pTransfert->iTmpActif),
                                           (pTransfert->pTmpTransfertMessage ));

        case isTreeNode	 :
            return (static_cast<NSTreeNode*>(pNSCtrl))->
                                TempTransferer(&(pTransfert->iTmpActif),
                                           (pTransfert->pTmpTransfertMessage));

        case isEdit	 	       :
        case isEditDate	 	   :
        case isEditDateHeure :
            return (static_cast<NSEdit*>(pNSCtrl))->
                                TempTransferer(&(pTransfert->iTmpActif),
                                           (pTransfert->pTmpTransfertMessage ));

        case isEditLexique :
            return (static_cast<NSEditLexique*>(pNSCtrl))->
                                TempTransferer(&(pTransfert->iTmpActif),
                                           (pTransfert->pTmpTransfertMessage ));

        case isEditLexiqueDerive :
            return (static_cast<NSEditLexiqueDerive*>(pNSCtrl))->
                                TempTransferer(&(pTransfert->iTmpActif),
                                           (pTransfert->pTmpTransfertMessage ));

        case isEditNoLexique :
            return (static_cast<NSEditNoLex*>(pNSCtrl))->
                                TempTransferer(&(pTransfert->iTmpActif),
                                           (pTransfert->pTmpTransfertMessage ));
    }
	return 1;
}

//// Surcharge de l'op�rateur d'affectation
//
NSControle&
NSControle::operator = (NSControle src)
{
	if (this == &src)
		return *this ;

	// Attention : l'objets point� par pTransfert doit rester unique.
	//             Ne pas le dupliquer.
	pTransfert  = src.pTransfert ;
	pNSDialog   = src.pNSDialog ;
	pNSCtrl	    = src.pNSCtrl ;
	sIdentite   = src.sIdentite ;
	iType       = src.iType ;
  bVisible    = src.bVisible ;
	bGestionMultiple = src.bGestionMultiple ;

	if (src.pNSDlgFct)
		pNSDlgFct = new NSDlgFonction(*(src.pNSDlgFct)) ;
	else
		pNSDlgFct = 0 ;

	sFilling          = src.sFilling ;
	sFillingFilter    = src.sFillingFilter ;
  sFillingStarter   = src.sFillingStarter ;
	sFillingEndPeriod = src.sFillingEndPeriod ;
	sPathControl      = src.sPathControl ;

	return *this ;
}

//
// Surcharge de l'op�rateur ==
//
int
NSControle::operator == (const NSControle& o)
{
	if	(pTransfert == o.pTransfert)
		return 1 ;
	else
		return 0 ;
}

//
// Activer physiquement le controle
//
void
NSControle::SetFocus()
{
	if (!pNSCtrl)
  	return ;

  switch (iType)
  {
  	case isCaseACocher :

    	(static_cast<NSCheckBox*>(pNSCtrl))->ActiveToi = false ;
      break ;

    case isRadioBtn	 :

    	(static_cast<NSRadioButton*>(pNSCtrl))->ActiveToi = false ;
      break ;

    case isBtn :

    	(static_cast<NSButton*>(pNSCtrl))->ActiveToi = false ;
      break ;
  }
  (static_cast<TControl*>(pNSCtrl))->SetFocus() ;
  activateParent() ;
}

BBItem*
NSControle::getInterfaceElementItem()
{
  if (NULL != pNSDialog)
    return pNSDialog->pBBItem ;

  if (NULL != pMUEView)
    return pMUEView->pBBItem ;

  return 0 ;
}

TWindow*
NSControle::getInterfacePointer()
{
  if (NULL != pNSDialog)
    return (TWindow*) pNSDialog ;

  if (NULL != pMUEView)
    return (TWindow*) pMUEView ;

  return 0 ;
}

NSContexte*
NSControle::getInterfaceContext()
{
  if (NULL != pNSDialog)
    return pNSDialog->pContexte ;

  if (NULL != pMUEView)
    return pMUEView->pContexte ;

  return 0 ;
}

NSControleVector*
NSControle::getInterfaceControls()
{
  if (NULL != pNSDialog)
    return pNSDialog->pNSCtrl ;

  if (NULL != pMUEView)
    return pMUEView->getControls() ;

  return 0 ;
}

//
// Etablit un pont entre le versant Windows (NSDialog) et le
// versant BigBrother (BBItem et BBFilsItem) par l'interm�diaire des
// objets NSTransferInfo selon le sch�ma ci-dessous :
//
//    BBItem -> BBFilsItem -> NSTransferInfo <- NSControle <- NSDialog
//
//  Au lancement de la fonction, l'objet NSTransferInfo a d�j� �t� cr��
//	sous forme neutre par l'objet BBFilsItem correspondant.
//	L'objet NSControle s'y r�f�rence et lui donne une structure de
//	transfert appropri�e.
//
int
NSControle::lierTransfert(BBItem* pBBItem)
{
	if (!pBBItem)
  	return 0 ;

  BBFilsItem* pBBFilsIt;
	//
	// Un �l�ment d'Identit� vide n'est, par d�finition, pas liable
  // Un texte libre non plus ???
	//
	if (("" == sIdentite) || ("#" == sIdentite))
  	return 0 ;
	//
	// Demande au BBItem qui a ouvert la fen�tre de localiser le BBFilsItem
	// qui correspond � ce groupe et ce code
	//
	pBBFilsIt = pBBItem->ChercheFils(sIdentite) ;
	//
	// Si le BBFilsItem a �t� localis�, on traite son NSTransferInfo
	//
	if (pBBFilsIt)
	{
		pTransfert = pBBFilsIt->getItemTransfertData() ;
		pTransfert->referenceControle(this) ;
		if (pBBFilsIt->Actif())
			activeControle(BF_CHECKED) ;
	}
	else if (pNSDialog)
	{
		string errmess = "ATTENTION !!! Controle orphelin (groupe " ;
		errmess += " - identit� " ;
		errmess += sIdentite ;
		errmess += ")" ;
		erreur(errmess.c_str(), standardError, 0) ;
		pTransfert = 0 ;
	}
	return 0 ;
}

void
NSControle::initFromArray(NSPatPathoArray* pPatPathoArray)
{
  if ((NULL == pPatPathoArray) || pPatPathoArray->empty())
  	return ;

  PatPathoIter iter = pPatPathoArray->begin() ;

  int iLigne = (*iter)->getLigne() ;
  string sEtiquettePatpatho = (*iter)->getLexique() ;
  string sNoeud             = (*iter)->getNodeID() ;
  string sComplement        = (*iter)->getComplement() ;
  string sInteret           = (*iter)->getInteret() ;
  string sPluriel           = (*iter)->getPluriel() ;
  string sVisible           = (*iter)->getVisible() ;
  string sCertitude         = (*iter)->getCertitude() ;
  string sTexteLibre        = (*iter)->getTexteLibre() ;

  iter++ ;

  if ((pPatPathoArray->end() != iter) && ((*iter)->getLigne() == iLigne))
  {
  	sEtiquettePatpatho += string(1, cheminSeparationMARK) + (*iter)->getLexique() ;
    sNoeud             += string(1, cheminSeparationMARK) + (*iter)->getNodeID() ;
    sComplement = (*iter)->getComplement() ;
    sInteret    = (*iter)->getInteret() ;
    sPluriel    = (*iter)->getPluriel() ;
    sVisible    = (*iter)->getVisible() ;
    sCertitude  = (*iter)->getCertitude() ;
    sTexteLibre = (*iter)->getTexteLibre();
  }

  pTransfert->pTransfertMessage->SetNoeud(sNoeud) ;
  pTransfert->pTransfertMessage->SetLexique(sEtiquettePatpatho) ;
  pTransfert->pTransfertMessage->SetComplement(sComplement) ;
  pTransfert->pTransfertMessage->SetPluriel(sPluriel) ;
  pTransfert->pTransfertMessage->SetVisible(sVisible) ;
  pTransfert->pTransfertMessage->SetCertitude(sCertitude) ;
  pTransfert->pTransfertMessage->SetInteret(sInteret) ;
  pTransfert->pTransfertMessage->SetTexteLibre(sTexteLibre) ;

  pTransfert->pBBFilsItem->Active() ; //rendre ce fils actif
  prepareControle() ;
}

//
// Initialise le contr�le en fonction de l'�tat du BBFilsItem qui lui correspond
//
void NSControle::prepareControle()
{
	if (pTransfert)
	{
		if (pTransfert->iActif)
			activeControle(BF_CHECKED, pTransfert->pTransfertMessage);
		else
			activeControle(BF_UNCHECKED, pTransfert->pTransfertMessage);
	}
	if (pNSDlgFct)
		pNSDlgFct->execute(NSDLGFCT_REINIT);
}

void
NSControle::executeKillFocusBehaviour()
{
	if (!pNSCtrl)
  	return ;

	switch (iType)
	{
/*
		case isCaseACocher :
            return (static_cast<NSCheckBox*>(pNSCtrl))->
                                Transferer(direction,
                                           &(pTransfert->iActif),
                                           (pTransfert->pTransfertMessage ));

        case isRadioBtn	 :
            return (static_cast<NSRadioButton*>(pNSCtrl))->
                                Transferer(direction,
                                           &(pTransfert->iActif),
                                           (pTransfert->pTransfertMessage ));

        case isTreeNode	 :
            return (static_cast<NSTreeNode*>(pNSCtrl))->
                                Transferer(direction,
                                           &(pTransfert->iActif),
                                           (pTransfert->pTransfertMessage));

        case isEdit	 	       :
        case isEditDate      :
        case isEditDateHeure :
            return (static_cast<NSEdit*>(pNSCtrl))->
                                Transferer(direction,
                                           &(pTransfert->iActif),
                                           (pTransfert->pTransfertMessage ));

        case isEditLexique :
            return (static_cast<NSEditLexique*>(pNSCtrl))->
                                Transferer(direction,
                                           &(pTransfert->iActif),
                                           (pTransfert->pTransfertMessage ));

        case isEditLexiqueDerive :
            return (static_cast<NSEditLexiqueDerive*>(pNSCtrl))->
                                Transferer(direction,
                                           &(pTransfert->iActif),
                                           (pTransfert->pTransfertMessage ));
*/

		case isEditNoLexique :
    	(static_cast<NSEditNoLex*>(pNSCtrl))->executeKillFocusBehaviour() ;
      
/*
      case isComboClassif :
            return (static_cast<NSComboClassif*>(pNSCtrl))->
                                Transferer(direction,
                                           &(pTransfert->iActif),
                                           (pTransfert->pTransfertMessage ));

      case isComboSemantique :
            return (static_cast<NSComboSemantique*>(pNSCtrl))->
                                Transferer(direction,
                                           &(pTransfert->iActif),
                                           (pTransfert->pTransfertMessage ));
*/
	}
	return ;
}

void
NSControle::setFilling(string sFil)
{
	if (string("") == sFil)
		return ;

	size_t pos ;
  size_t equ ;
  string sField ;
  bool progress = true ;

  // valeurs par d�faut
  sFillingFilter = "/0QUES/" ;
  sFillingEndPeriod = "" ;
  sPathControl = "" ;

  do
  {
  	pos = sFil.find("|") ;

    if (pos != string::npos)
    {
    	sField = string(sFil, 0, pos) ;
      sFil   = string(sFil, pos+1, strlen(sFil.c_str()) - pos - 1) ;
    }
    else
    {
    	sField = sFil ;
      progress = false ;
    }

    equ = sField.find("=") ;
    if (string::npos == equ)
    	sFilling = sField ;
    else
    {
      string sValue = string("") ;
      if (equ < strlen(sField.c_str()) - 1)
        sValue = string(sField, equ + 1, strlen(sField.c_str()) - equ - 1) ;
      strip(sValue, stripBoth) ;

    	if      ('F' == sField[0])
      	sFillingFilter = string("/") + sValue + string("/") ;
      else if ('R' == sField[0])
      	sFillingStarter = sValue + string("/") ;
      else if ('D' == sField[0])
      	sFillingEndPeriod = sValue ;
      else if ('C' == sField[0])
      	sPathControl = sValue ;
    }
  }
  while(progress) ;
}

bool
NSControle::initOnSetupWindow()
{
	if (strstr(sFilling.c_str(), "S") != NULL)
  	return true ;
	return false ;
}

bool
NSControle::initOnFocus()
{
	if (strstr(sFilling.c_str(), "F") != NULL)
  	return true ;
  return false ;
}

bool
NSControle::initOnTimer()
{
	if (strstr(sFilling.c_str(), "T") != NULL)
  	return true ;
  return false ;
}

bool
NSControle::isToFilling(string sAction)
{
	if ((sAction == "SetupWindow" ) && (strstr(sFilling.c_str(), "S") != NULL ))
  	return true ;
  if ((sAction == "SetFocus" )&& (strstr(sFilling.c_str(), "F") != NULL ))
  	return true ;
  if ((sAction == "onTimer" )&& (strstr(sFilling.c_str(), "T") != NULL ))
  	return true ;

  return false ;
}

string
NSControle::getPath()
{
  if ((NULL == pTransfert) || (NULL == pTransfert->pBBFilsItem))
  	return string("") ;

  return pTransfert->pBBFilsItem->getLocalisation() ;
}

string
NSControle::cutPath(string *psPath, string sCutElement, bool bInclude)
{
  if ((NULL == psPath) || (string("") == *psPath))
    return string("") ;

  string sElementPath = *psPath ;

  if (string("") != sCutElement)
  {
  	size_t pos = psPath->find(sCutElement) ;    if (NPOS != pos)    {      size_t iCutLen = strlen(sCutElement.c_str()) ;      if (false == bInclude)			  sElementPath = string(*psPath, pos+iCutLen, strlen(psPath->c_str())-pos-iCutLen) ;
      else
        sElementPath = string(*psPath, pos, strlen(psPath->c_str())-pos) ;
    }
  }

  return sElementPath ;
}

bool
NSControle::getPathForBlackboard(string* psPathForBB)
{
	if (NULL == psPathForBB)
  	return false ;

  *psPathForBB = getPath() ;

  // We apply the filter before the starter
  //
  if (string("") != sFillingFilter)
    *psPathForBB = cutPath(psPathForBB, sFillingFilter, false) ;
  if (string("") != sFillingStarter)
    *psPathForBB = cutPath(psPathForBB, sFillingStarter, true) ;

  if (string("") == *psPathForBB)
    return false ;

/*
	*psPathForBB = string("") ;

  if ((NULL == pTransfert) || (NULL == pTransfert->pBBFilsItem))
  	return false ;
  BBFilsItem* pFilsItem = pTransfert->pBBFilsItem ;

  *psPathForBB = pFilsItem->getLocalisation() ;

	// on r�cup�re le chemin du BBItem pere du BBFilsItem associ�
  // au NSControle via son pTransfert  if (pFilsItem->getItemFather())  	*psPathForBB = pFilsItem->getItemFather()->sLocalisation ;  // on rajoute l'�tiquette du fils  string sEtiquette = pFilsItem->getItemLabel() ;  if (sEtiquette != "")  {  	string sEtiq ;    NSSuper* pSuper = pContexte->getSuperviseur() ;  	pSuper->getDico()->donneCodeSens(&sEtiquette, &sEtiq) ;    if (*psPathForBB != string(""))
  		*psPathForBB += string(1, cheminSeparationMARK) ;
    *psPathForBB += sEtiq ;
  }

  // on enleve le chemin jusqu'� "0QUES1"
  if (sFillingFilter != "")
  {
  	size_t pos = psPathForBB->find(sFillingFilter) ;    if (pos != NPOS)			*psPathForBB = string(*psPathForBB, pos+7, strlen(psPathForBB->c_str())-pos-7) ;
  }
*/

  *psPathForBB = getRegularPath(*psPathForBB, cheminSeparationMARK, intranodeSeparationMARK) ;

  return true ;
}

bool
NSControle::getEndValidityDate(string* psValidityEndingDate)
{
	if (NULL == psValidityEndingDate)
  	return false ;

  *psValidityEndingDate = string("") ;

  if (string("") == sFillingEndPeriod)
  	return true ;

  NVLdVTemps tpsObj ;
  tpsObj.takeTime() ;

  string sAjoutAns  = string(sFillingEndPeriod, 0, 2) ;
  string sAjoutMois = string(sFillingEndPeriod, 2, 2) ;
  string sAjoutJour = string(sFillingEndPeriod, 4, 2) ;

  if (sAjoutAns != "00")
  	tpsObj.ajouteAns((-1) * atoi(sAjoutAns.c_str()), false /* don't normalize */) ;
  if (sAjoutMois != "00")
  	tpsObj.ajouteMois((-1) * atoi(sAjoutMois.c_str()), false /* don't normalize */) ;
  if (sAjoutJour != "00")
  	tpsObj.ajouteJours((-1) * atoi(sAjoutJour.c_str())) ;

  *psValidityEndingDate = tpsObj.donneDateHeure() ;

  return true ;
}

bool
NSControle::isEmpty()
{
	if (NULL == pNSCtrl)
  	return false ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  if (isEditDate == iType)
  {
		NSEditDate* pDate = static_cast<NSEditDate*> (pNSCtrl) ;

    int oldBuffLen = pDate->GetTextLen() ;
    if (oldBuffLen <= 0)
    	return true ;

		char far* str = new char[oldBuffLen + 1] ;
    pDate->GetText(str, oldBuffLen + 1) ;
		string sContenu = string(str) ;
		delete[] str ;

    string sMessage ;
    donne_date_inverse(sContenu, sMessage, sLang) ;
    if ((string("") == sMessage) || (string("00000000") == sMessage))
    	return true ;

    return false ;
	}

  if (isEditDateHeure == iType)
  {
		NSEditDateHeure* pDateHeure = static_cast<NSEditDateHeure*> (pNSCtrl) ;

    int oldBuffLen = pDateHeure->GetTextLen() ;
    if (oldBuffLen <= 0)
    	return true ;

		char far* str = new char[oldBuffLen + 1] ;
    pDateHeure->GetText(str, oldBuffLen + 1) ;
		string sContenu = string(str) ;
		delete[] str ;

    string sMessage ;
    donne_date_inverse(sContenu, sMessage, sLang) ;
    if ((string("") == sMessage) || (string("00000000") == sMessage))
    	return true ;

    return false ;
	}

  switch (iType)
  {
    case isEdit	:
    	return (0 == (static_cast<NSEdit*>(pNSCtrl))->GetTextLen()) ;

    case isEditLexique :
    	return (0 == (static_cast<NSEditLexique*>(pNSCtrl))->GetTextLen()) ;

    //case isEditLexiqueDerive :
    //	return ((static_cast<NSEditLexiqueDerive*>(pNSCtrl))->GetTextLen() == 0) ;

    case isEditNoLexique :
    	return (0 == (static_cast<NSEditNoLex*>(pNSCtrl))->GetTextLen()) ;
	}

  return false ;
}

//***************************************************************************
// Impl�mentation des m�thodes NSDlgFonction
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur par d�faut
//---------------------------------------------------------------------------
NSDlgFonction::NSDlgFonction(NSContexte* pCtx, NSSmallBrother* pBig, BBItem* pbBItem, string sNomFonct, NSControle* pCtrl, TModule* /* pResModule */)
              :NSRoot(pCtx), pBigBoss(pBig)
{
	pControle    = pCtrl ;
  sNomFonction = sNomFonct ;
  pBBItem      = pbBItem ;
  pAdresseFct  = NULL ;

  char szFichMaj[BB_FICHIER_DIALOGUE_LEN + 1] ;
  strcpy(szFichMaj, pBBItem->pDonnees->fichierDialogue) ;
  pseumaj(szFichMaj) ;

  if ((strcmp(szFichMaj, "NSBB")) && (strcmp(szFichMaj, "NSMBB")))
  {
  	pNSResModule = pBig->TrouverModule(pBBItem->pDonnees->fichierDialogue) ;
    if (pNSResModule)
    	(FARPROC) pAdresseFct = pNSResModule->GetProcAddress(MAKEINTRESOURCE(3)) ;
  }
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSDlgFonction::NSDlgFonction(const NSDlgFonction& src)
              :NSRoot(src.pContexte)
{
	pBigBoss 	   = src.pBigBoss ;
	pControle	   = src.pControle ;
	sNomFonction = src.sNomFonction ;
	pAdresseFct	 = src.pAdresseFct ;
  pNSResModule = src.pNSResModule ;
  pBBItem		   = src.pBBItem ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSDlgFonction::~NSDlgFonction()
{
	sNomFonction = "" ;
}

//---------------------------------------------------------------------------
//  Fonction :		int NSDlgFonction::::execute(int iParam)
//
//  Param�tres :	iParam -> moment dans la vie du Ctrl o� est lanc� la fct
//									 iParam est de la forme NSDLGFCT_XXXX
//
//	 Retour :      0 si l'ex�cution interdit la communication avec BigBrother
//						1 sinon
//---------------------------------------------------------------------------
int
NSDlgFonction::execute(int iParam, HWND hWndFocus)
{
	int j = 0;
	if (pAdresseFct)
	{
		j = (*pAdresseFct)((NSDlgFonction far *) this,
    															(NSSmallBrother far*) pBigBoss, iParam) ;
		return j ;
	}

	char szFichMaj[BB_FICHIER_DIALOGUE_LEN + 1] ;
	strcpy(szFichMaj, pBBItem->pDonnees->fichierDialogue) ;
	pseumaj(szFichMaj) ;

	if ((szFichMaj[0] != '\0') && (strcmp(szFichMaj, "NSBB")) && (strcmp(szFichMaj, "NSMBB")))
		return j ;

	string sCurrentFonction ;
  string sRmnFct = sNomFonction ;
	size_t iPos    = sRmnFct.find("/") ;
	if (iPos == string::npos)
	{
		sCurrentFonction = sNomFonction ;
    sRmnFct = "" ;
	}
	else
  {
		sCurrentFonction = string(sRmnFct, 0, iPos) ;
    sRmnFct = string(sRmnFct, iPos + 1, strlen(sRmnFct.c_str()) - iPos - 1) ;
	}

  bool bLetDefaultProcessing = true ;

	while (sCurrentFonction != "")
	{
		if (sCurrentFonction == "NOW")
		{
			switch (iParam)
			{
				case NSDLGFCT_CREATION :
					FixerDateDuJour(this) ;
					// return 0 ;
          bLetDefaultProcessing = false ;
          break ;
			}
		}
		else if (sCurrentFonction == "BEGINNOW")
		{
			switch (iParam)
			{
				case NSDLGFCT_CREATION :
					FixerDateDuJour(this) ;
					// return 0 ;
          bLetDefaultProcessing = false ;
          break ;

				case NSDLGFCT_POSTEXEC :					AdaptLastingTime(this) ;
					// return 1 ;
          break ;
			}
		}
		else if (sCurrentFonction == "ENDING")
		{
			switch (iParam)
			{
				case NSDLGFCT_POSTEXEC :
					AdaptLastingTime(this) ;
					// return 1 ;
          break ;
			}
		}
		else if (sCurrentFonction == "LASTING_TIME")
		{
			switch (iParam)
			{
				case NSDLGFCT_CREATION :
					FixLastingTime(this) ;
					// return 0 ;
          bLetDefaultProcessing = false ;
          break ;

				case NSDLGFCT_POSTEXEC :					AdaptEnding(this) ;
					// return 1 ;
          break ;
			}
		}
    else if (sCurrentFonction == "LASTING_TIME_FORCE")
		{
			switch (iParam)
			{
				case NSDLGFCT_CREATION :
					FixLastingTime(this) ;
					// return 0 ;
          bLetDefaultProcessing = false ;
          break ;

				case NSDLGFCT_POSTEXEC :					AdaptEnding(this, true) ;
					// return 1 ;
          break ;
			}
		}
		else if (sCurrentFonction == "NOENDING")
		{
			switch (iParam)
			{
				case NSDLGFCT_CREATION :
					FixNoEnding(this) ;
					// return 0 ;
          bLetDefaultProcessing = false ;
          break ;

				case NSDLGFCT_POSTEXEC :					CancelEnding(this) ;
					// return 1 ;
          break ;
			}
		}
		else if (sCurrentFonction == "NUMSYNCHRO")
		{
			switch (iParam)
			{
				case NSDLGFCT_POSTEXEC :
					SynchroNumValues(this) ;
					// return 1 ;
          break ;
			}
		}
    else if (sCurrentFonction == "SETDATEMAX")
		{
			switch (iParam)
			{
				case NSDLGFCT_POSTEXEC :
					RemplirDateMax(this) ;
					// return 1 ;
                break ;
			}
		}
		else if (sCurrentFonction == "CAPTION")
		{
			switch (iParam)
			{
				case NSDLGFCT_CREATION :
					FixCaption(this) ;
					// return 0 ;
          bLetDefaultProcessing = false ;
          break ;
			}
		}
		else if (sCurrentFonction == "CREEPREO")
		{
			switch (iParam)
			{
      	case NSDLGFCT_EXECUTE :
				case NSDLGFCT_POSTEXEC :
					CreatePreoccup(this) ;
          break ;
			}
		}
    else if (sCurrentFonction == "ADDALLPS")
		{
			switch (iParam)
			{
				case NSDLGFCT_CREATION :
					// EditAddress(this);
          initFromCurrentHealthProblems(this) ;
          bLetDefaultProcessing = false ;
					// return 0 ;
          break ;

				case NSDLGFCT_EXECUTE :
          // bLetDefaultProcessing = false ;
					// return 0;
          break ;
			}
		}
		else if (sCurrentFonction == "EDITADR")
		{
			switch (iParam)
			{
				case NSDLGFCT_CREATION :
					// EditAddress(this);
					ModifyAddress(this) ;
          bLetDefaultProcessing = false ;
					// return 0 ;
          break ;

				case NSDLGFCT_EXECUTE :
					ModifyAddress(this) ;
          bLetDefaultProcessing = false ;
					// return 0;
          break ;
			}
		}
		else if (sCurrentFonction == "EDITADR2")
		{
			switch (iParam)
			{
				case NSDLGFCT_EXECUTE :
					EditAddressButton(this);
					// return 0;
          bLetDefaultProcessing = false ;
          break ;
			}
		}
		else if (sCurrentFonction == "CHOIXADR")
		{
			switch (iParam)
			{
				case NSDLGFCT_EXECUTE :
					ChooseAddress(this);
					// return 0;
          bLetDefaultProcessing = false ;
          break ;
			}
		}
		else if (sCurrentFonction == "CHOIXADRPAT")
		{
			switch (iParam)
			{
				case NSDLGFCT_EXECUTE :
					ChoosePatAddress(this);
					// return 0;
          bLetDefaultProcessing = false ;
          break ;
			}
		}
		else if (sCurrentFonction == "CHOIXADRCOR")
		{
			switch (iParam)
			{
				case NSDLGFCT_EXECUTE :
					ChooseCorAddress(this);
					// return 0;
          bLetDefaultProcessing = false ;
          break ;
			}
		}
		else if (sCurrentFonction == "EDITCOR")
		{
			switch (iParam)
			{
				case NSDLGFCT_CREATION :
					ShowCorresp(this);
					// return 0;
          bLetDefaultProcessing = false ;
          break ;

				case NSDLGFCT_EXECUTE :
					EditCorresp(this);
					// return 0;
          bLetDefaultProcessing = false ;
          break ;
			}
		}
		else if (sCurrentFonction == "EDITREFCOR")
		{
			switch (iParam)
			{
				case NSDLGFCT_CREATION :
					ShowRefCorresp(this);
					// return 0;
          bLetDefaultProcessing = false ;
          break ;

				case NSDLGFCT_EXECUTE :
					EditRefCorresp(this);
					// return 0;
          bLetDefaultProcessing = false ;
          break ;
			}
		}
    else if (sCurrentFonction == "PIDSADR_SITE")
    {
			switch (iParam)
			{
				case NSDLGFCT_POSTEXEC :
					PidsAdrSite(this);
					//return 0;
          bLetDefaultProcessing = false ;
          break ;
			}
		}
    else if (sCurrentFonction == "PIDSADR_VOIE")
    {
			switch (iParam)
			{
				case NSDLGFCT_POSTEXEC :
					if (isFrereApres(hWndFocus))
						PidsAdrVoie(this) ;
					//return 0;
          bLetDefaultProcessing = false ;
					break ;
        }
    }
    else if (sCurrentFonction == "PIDSADR_ZIP")
    {
    	switch (iParam)
      {
      	case NSDLGFCT_POSTEXEC :
        	if (isFrereApres(hWndFocus))
          	PidsAdrZip(this) ;
              //return 0;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "GET_IPP")
    {
    	switch (iParam)
      {
      	case NSDLGFCT_CREATION :
        	GetIPP(this) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "GET_LOCALIPP")
    {
    	switch (iParam)
      {
      	case NSDLGFCT_CREATION :
        	GetLocalIPP(this, false) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "GET_MANUAL_LOCALIPP")
    {
    	switch (iParam)
      {
      	case NSDLGFCT_CREATION :
        	GetLocalIPP(this, true) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "ZIP_CITYNAME")
    {
    	switch (iParam)
      {
      	case NSDLGFCT_POSTEXEC :
        	if (isFrereApres(hWndFocus))
          	PidsZipFillCity(this) ;
              //return 0;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "SURF_ONMAP")
    {
    	switch (iParam)
      {
      	case NSDLGFCT_POSTEXEC :
        	SurfOnTheMap(this) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "CALCIMC")
    {
      switch (iParam)
      {
        case NSDLGFCT_CREATION :
          CalcIMC(this);
          //return 0;
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_POSTEXEC :
          CalcIMC(this);
          //return 0;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "WEIGHTGAIN")
    {
      switch (iParam)
      {
        case NSDLGFCT_CREATION :
          CalcWeigthGain(this);
          //return 0;
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_POSTEXEC :
          CalcWeigthGain(this);
          //return 0;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "CALCSC")
    {
      switch (iParam)
      {
        case NSDLGFCT_CREATION :
          CalcSC(this);
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_POSTEXEC :
          CalcSC(this);
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "CALCVCHAL")
    {
      switch (iParam)
      {
        case NSDLGFCT_CREATION :
          CalcVCHAL(this);
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_POSTEXEC :
          CalcVCHAL(this);
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "CALCVDATA")
    {
      switch (iParam)
      {
        case NSDLGFCT_CREATION :
          CalcVDATA(this);
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_POSTEXEC :
          CalcVDATA(this);
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "FRIEDGPL")
    {
      switch (iParam)
      {
        case NSDLGFCT_CREATION :
          CalcFriedwaldGpl(this);
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_POSTEXEC :
          CalcFriedwaldGpl(this);
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "CALCVM8AL")
    {
      switch (iParam)
      {
        case NSDLGFCT_CREATION :
          CalcMicroAlb24(this);
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_POSTEXEC :
          CalcMicroAlb24(this);
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "CALCVCSEL")
    {
      switch (iParam)
      {
        case NSDLGFCT_CREATION :
          CalcConsoSel(this);
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_POSTEXEC :
          CalcConsoSel(this);
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "CALCCOCKROFTMGPL")
    {
      switch (iParam)
      {
        case NSDLGFCT_CREATION :
          CalcCockroftMGPL(this);
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_POSTEXEC :
          CalcCockroftMGPL(this);
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "CLASSIFY")
    {
    	switch (iParam)
      {
      	case NSDLGFCT_POSTEXEC :
        	Classify(this) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "MATERIAL")
    {
    	switch (iParam)
      {
      	case NSDLGFCT_CREATION :
          InitTitleOfMaterial(this) ;
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_EXECUTE :
					SelectMaterial(this) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "PERSON")
    {
    	switch (iParam)
      {
      	case NSDLGFCT_CREATION :
          InitTitleOfPerson(this) ;
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_EXECUTE :
					SelectPerson(this) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "CROSSOVER")
    {
    	switch (iParam)
      {
      	case NSDLGFCT_CREATION :
          GetPrescriptionCrossover(this) ;
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_POSTEXEC :
					GetPrescriptionCrossover(this) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "SETCROSSOVER")
    {
    	switch (iParam)
      {
        case NSDLGFCT_POSTEXEC :
					SetPrescriptionCrossover(this) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "SETDDR")
    {
    	switch (iParam)
      {
        case NSDLGFCT_POSTEXEC :
					SetGestationDDR(this) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "SETGESTDDR")
    {
    	switch (iParam)
      {
        case NSDLGFCT_POSTEXEC :
					SetGestationDatesDDR(this) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "SETGESTECHO")
    {
    	switch (iParam)
      {
        case NSDLGFCT_POSTEXEC :
					SetGestationDatesEcho(this) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "SETGESTDATES")
    {
    	switch (iParam)
      {
        case NSDLGFCT_POSTEXEC :
					SetGestationDates(this) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }
    else if (sCurrentFonction == "SURG_HISTORY")
    {
    	switch (iParam)
      {
      	case NSDLGFCT_CREATION :
          CheckSurgicalHistory(this) ;
          bLetDefaultProcessing = false ;
          break ;
        case NSDLGFCT_POSTEXEC :
					RecordInSynthesis(this, string("ZSYNT/QANTP/QANTC")) ;
          bLetDefaultProcessing = false ;
          break ;
      }
    }

		//
		// Retourner 1 pour laisser le noyau effectuer le traitement par d�faut
		//
		// return 1 ;

		if (sRmnFct != "")
		{
			iPos = sRmnFct.find("/") ;
			if (iPos == string::npos)
			{
				sCurrentFonction = sRmnFct ;
				sRmnFct = "" ;
			}
			else
			{
				sCurrentFonction = string(sRmnFct, 0, iPos) ;
				sRmnFct = string(sRmnFct, iPos + 1, strlen(sRmnFct.c_str()) - iPos - 1) ;
			}
		}
		else
			sCurrentFonction = "" ;
	}

	if (bLetDefaultProcessing)
		return 1 ;
	else
		return 0 ;
}

//---------------------------------------------------------------------------
//  Function:		NSDlgFonction& NSDlgFonction::operator = (NSDlgFonction src)
//
//  Description:	Surcharge de l'op�rateur d'affectation
//---------------------------------------------------------------------------
NSDlgFonction&
NSDlgFonction::operator = (NSDlgFonction src)
{
  if (this == &src)
    return *this ;

	pBigBoss     = src.pBigBoss ;
	pControle    = src.pControle ;
	sNomFonction = src.sNomFonction ;
	pAdresseFct  = src.pAdresseFct ;
  pBBItem      = src.pBBItem ;

  return *this ;
}

//---------------------------------------------------------------------------
//  Function:		int NSControle::operator == (const NSControle& o)
//
//  Description:	Surcharge de l'op�rateur ==
//---------------------------------------------------------------------------
int
NSDlgFonction::operator == (const NSDlgFonction& x)
{
	if (pControle == x.pControle)
		return 1 ;
	else
		return 0 ;
}

//--------------------------------------------------------------------
//rafraichir la bo�te de dialogue contr�l�e par pControle
//--------------------------------------------------------------------
void
NSDlgFonction::rafraichitControles()
{
  if (NULL == pControle)
    return ;

  if      (pControle->getNSDialog())
    pControle->getNSDialog()->rafraichitControles() ;
  else if (pControle->getMUEView())
    pControle->getMUEView()->rafraichitControles() ;
}

bool
NSDlgFonction::isFrere(HWND hWndGetFocus)
{
  bool bIsFrere = false ;

  if (hWndGetFocus != 0)
  {
    NSControleVector *pVectNSCtrl = pControle->getInterfaceControls() ;
    if (pVectNSCtrl && (false == pVectNSCtrl->empty()))
    {
      for (iterNSControle i = pVectNSCtrl->begin(); i != pVectNSCtrl->end(); i++)
      {
        if ((*i)->getHWND() == hWndGetFocus)
        {
          bIsFrere = true ;
          break ;
        }
      }
    }
  }

  return bIsFrere ;
}

bool
NSDlgFonction::isFrereAvant(HWND hWndGetFocus)
{
  bool bIsFrereAvant = false ;

  if (hWndGetFocus != 0)
  {
    NSControleVector *pVectNSCtrl = pControle->getInterfaceControls() ;
    if (pVectNSCtrl && (false == pVectNSCtrl->empty()))
    {
      for (iterNSControle i = pVectNSCtrl->begin(); i != pVectNSCtrl->end(); i++)
      {
        // Si on retrouve le controle en cours avant son frere
        // le bIsFrereAvant reste � false
        if (pControle->getHWND() == (*i)->getHWND())
          break ;

        if ((*i)->getHWND() == hWndGetFocus)
        {
          bIsFrereAvant = true ;
          break ;
        }
      }
    }
  }

  return bIsFrereAvant ;
}

bool
NSDlgFonction::isFrereApres(HWND hWndGetFocus)
{
  bool bIsFrereApres = false ;
  bool bIsControle   = false ;

  if (hWndGetFocus != 0)
  {
    NSControleVector *pVectNSCtrl = pControle->getInterfaceControls() ;
    if (pVectNSCtrl && (false == pVectNSCtrl->empty()))
    {
      for (iterNSControle i = pVectNSCtrl->begin(); i != pVectNSCtrl->end(); i++)
      {
        // Si on retrouve le controle en cours avant son frere
        if (pControle->getHWND() == (*i)->getHWND())
        {
          bIsControle = true ;
          continue ;   // le controle en cours n'est pas suppos� avoir le focus
        }

        if ((*i)->getHWND() == hWndGetFocus)
        {
          if (bIsControle)
            bIsFrereApres = true ;
          break ;
        }
      }
    }
  }

  return bIsFrereApres ;
}

bool
NSDlgFonction::containFonction(string sFctName)
{
  if ((string("") == sNomFonction) || (string("") == sFctName))
    return false ;

  ClasseStringVector aVect ;
  DecomposeChaine(&sNomFonction, &aVect, string("/")) ;

  if (aVect.empty())
    return false ;

  for (iterString it = aVect.begin() ; aVect.end() != it ; it++)
    if ((*it)->sItem == sFctName)
      return true ;

  return false ;
}

