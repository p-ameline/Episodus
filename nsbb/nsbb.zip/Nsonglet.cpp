#include <owl/pch.h>#include <owl/tabctrl.h>
#include <owl/inputdia.h>
#include <owl/notetab.h>
#include <owl/commctrl.h>

#include "partage\nsglobal.h"
#include "nsbb\nsbb_msg.h"
#include "nsbb\nsdlg.h"
#include "nsbb\nsonglet.h"

DEFINE_RESPONSE_TABLE1(NSOnglet, TTabControl)
	// Tab Control Notifications
	//
	//EV_NOTIFY_AT_CHILD(TCN_SELCHANGE, TabSelChange),
	//EV_NOTIFY_AT_CHILD(TCN_SELCHANGING, TabSelChanging),
	//EV_NOTIFY_AT_CHILD(EV_TCN_KEYDOWN, TabKeyDown),
	EV_WM_LBUTTONDOWN,
END_RESPONSE_TABLE;

//// Constructeur
//
NSOnglet::NSOnglet(NSContexte *pCtx, TWindow* parent, int resId)
         :TTabControl(parent, resId), NSRoot(pCtx)
{
	pControle = 0 ;
	DisableTransfer() ;
}

NSOnglet::NSOnglet(NSContexte *pCtx, TWindow* parent, int resId, int x, int y, int w, int h, TModule* module)         :TTabControl(parent, resId, x, y, w, h, module), NSRoot(pCtx){	pControle = 0 ;	DisableTransfer() ;}
//// Destructeur
//
NSOnglet::~NSOnglet()
{
 /*	if (pControle)
	{
		delete pControle;
		pControle = 0;
	} */
}

void
NSOnglet::SetupWindow()
{
  // This method is private
  // OWL::TTabControl::SetupWindow() ;

  TControl::SetupWindow() ;
}

voidNSOnglet::InitialiseTabs(NSDialogOnglet* pConfigOnglet)
{
	int iTabIndex ;
	for (int i = 0; i < pConfigOnglet->nNbOnglets; i++)
	{
  	iTabIndex = Add((pConfigOnglet->pTexteOnglets[i])->c_str()) ;
    if (*(pConfigOnglet->pTexteOnglets[i]) == pConfigOnglet->sOngletActif)
    {
    	SetSel(iTabIndex) ;
      iOngletActif = iTabIndex ;
    }
	}
}

//// Fonction utilis�e lorsque l'onglet est cliqu�
//
void
NSOnglet::EvLButtonDown(uint /* modKeys */, NS_CLASSLIB::TPoint& point)
{
	int iOngletClick ;
	int iNotifier = 1 ;
	//
	// Si une fonction est attach�e au contr�le, on l'ex�cute
	//
	if (pControle->getFonction())
		iNotifier = pControle->getFonction()->execute(NSDLGFCT_EXECUTE) ;
	//
	// Pr�vient Big Brother (si l'�ventuelle fonction l'autorise)
	//
	if (iNotifier == 1)
	{
  	TTabHitTestInfo TabInfo ;
    TabInfo.pt = point ;
		iOngletClick = HitTest(TabInfo) ;
    if ((iOngletClick != -1) && (iOngletClick != iOngletActif))
			pControle->getNSDialog()->CmOkMessage(int(NSDLGRETOUR_DIRECT + iOngletClick)) ;
	}
	//
	// Pr�vient la boite de dialogue
	//
	/*#if defined(__WIN32__)
		Parent->HandleMessage(WM_CORRECT, MAKEWPARAM(Attr.Id, WM_CORRECT),
									 LPARAM(HWindow));
	#else
		Parent->HandleMessage(WM_CORRECT, Attr.Id, MAKELPARAM(HWindow, WM_CORRECT));
	#endif */
}

