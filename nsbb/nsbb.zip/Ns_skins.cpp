
#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"

#include "nsbb\ns_skins.h"

nsSkin::nsSkin(string sPath)
{
  sSkinPath       = sPath ;

  pBackColor      = 0 ;
  pBackBmp        = 0 ;
  sName           = "" ;
  sBmp            = "" ;  iBmpDraw        = DrawUndefined ;

  pFontDesc       = 0 ;  pFontColor      = 0 ;
  pFontBackColor  = 0 ;
  iCon 						= NULL;
}

nsSkin::nsSkin(nsSkin& rv)
{
  sName       = rv.sName ;
  sSkinPath   = rv.sSkinPath ;
  setBackColor(rv.pBackColor) ;
  if (rv.pBackBmp)  	pBackBmp = new TDib(rv.pBackBmp) ;  else  	pBackBmp = 0 ;  sBmp        = rv.sBmp ;  iBmpDraw    = rv.iBmpDraw ;  setIco(rv.iCon);  setLogFont(rv.pFontDesc) ;
  setFontColor(rv.pFontColor) ;
  setFontBackColor(rv.pFontBackColor) ;

  boxPos = rv.boxPos ;
}

nsSkin::~nsSkin()
{
  if (pBackColor)
  	delete pBackColor ;
  if (pFontDesc)
  	delete pFontDesc ;
  if (pFontColor)
  	delete pFontColor ;
  if (pFontBackColor)
  	delete pFontBackColor ;
  if (pBackBmp)
  	delete pBackBmp ;
  if (NULL != iCon)
    delete (iCon) ;
}

void
nsSkin::setBackBmp(string sB)
{
try
{
	if (pBackBmp)
  	delete pBackBmp ;

	sBmp = sB ;

	if (sB == "")
  	return ;

	sB = sSkinPath + sB ;
	//
	// On v�rifie que le fichier existe bien
	// Checking that file really exists
	//
	WIN32_FIND_DATA stRecherche ;
	HANDLE			hFichierTrouve ;
	hFichierTrouve = FindFirstFile(sB.c_str(), &stRecherche) ;
	//	if (hFichierTrouve == INVALID_HANDLE_VALUE)
		return ;

	pBackBmp = new TDib(sB.c_str()) ;
}
catch (...){
	erreur("Exception nsSkin::setBackBmp.", standardError, 0) ;
}
}

void
nsSkin::setBackIco(string sB)
{
try
{
	if (pBackBmp)
  	delete pBackBmp ;

	sBmp = sB ;

	if (sB == "")
  	return ;

  sB = sSkinPath + sB ;
  //
  // On v�rifie que le fichier existe bien
  // Checking that file really exists
  //
	WIN32_FIND_DATA stRecherche ;
  HANDLE			hFichierTrouve ;
	hFichierTrouve = FindFirstFile(sB.c_str(), &stRecherche) ;
	//  if (hFichierTrouve == INVALID_HANDLE_VALUE)
  	return ;

	iCon = new OWL::TIcon(0, sB.c_str(), 0) ;
}
catch (...){
	erreur("Exception nsSkin::setBackIco.", standardError, 0) ;
}
}

void
nsSkin::setBackColor(ClassLib::TColor* color)
{
try
{
	if (pBackColor)
	{
  	delete pBackColor ;
    pBackColor = 0 ;
  }

  if (!color)
  	return ;

	pBackColor = new ClassLib::TColor(COLORREF(*color)) ;
}
catch (...){
	erreur("Exception nsSkin::setBackColor.", standardError, 0) ;
}
}

void
nsSkin::setLogFont(LOGFONT* lFT)
{
try
{
	if (pFontDesc)
	{
		delete pFontDesc ;
    pFontDesc = 0 ;
	}

	if (!lFT)
		return ;

  pFontDesc = new LOGFONT ;
  pFontDesc->lfHeight         = lFT->lfHeight ;
  pFontDesc->lfWidth          = lFT->lfWidth ;  pFontDesc->lfEscapement     = lFT->lfEscapement ;
  pFontDesc->lfOrientation    = lFT->lfOrientation ;
  pFontDesc->lfWeight         = lFT->lfWeight ;
  pFontDesc->lfItalic         = lFT->lfItalic ;
  pFontDesc->lfUnderline      = lFT->lfUnderline ;
  pFontDesc->lfStrikeOut      = lFT->lfStrikeOut ;
  pFontDesc->lfCharSet        = lFT->lfCharSet ;
  pFontDesc->lfOutPrecision   = lFT->lfOutPrecision ;
  pFontDesc->lfClipPrecision  = lFT->lfClipPrecision ;
  pFontDesc->lfQuality        = lFT->lfQuality ;
  pFontDesc->lfPitchAndFamily = lFT->lfPitchAndFamily ;
  strcpy(pFontDesc->lfFaceName, lFT->lfFaceName) ;
}
catch (...){
	erreur("Exception nsSkin::setLogFont.", standardError, 0) ;
}
}

void
nsSkin::setFontColor(ClassLib::TColor* color)
{
try
{
	if (pFontColor)
	{
  	delete pFontColor ;
    pFontColor = 0 ;
  }
  if (!color)
  	return ;

	pFontColor = new ClassLib::TColor(COLORREF(*color)) ;
}
catch (...){
	erreur("Exception nsSkin::setFontColor.", standardError, 0) ;
}
}

void
nsSkin::setFontBackColor(ClassLib::TColor* color)
{
try
{
	if (pFontBackColor)
  {
  	delete pFontBackColor ;
    pFontBackColor = 0 ;
  }
  if (!color)
  	return ;

	pFontBackColor = new ClassLib::TColor(COLORREF(*color)) ;
}
catch (...){
	erreur("Exception nsSkin::setFontBackColor.", standardError, 0) ;
}
}

nsSkin&
nsSkin::operator=(nsSkin& src)
{
try
{
	if (this == &src)
		return *this ;

	sName       = src.sName ;

	setBackColor(src.pBackColor) ;	if (pBackBmp)  	delete pBackBmp ;  if (src.pBackBmp)  	pBackBmp = new TDib(src.pBackBmp) ;  else  	pBackBmp = 0 ;	sBmp        = src.sBmp ;	iBmpDraw    = src.iBmpDraw ;	setLogFont(src.pFontDesc) ;
	setFontColor(src.pFontColor) ;

  boxPos = src.boxPos ;

	return *this ;
}
catch (...){
	erreur("Exception nsSkin (= operator).", standardError, 0);
  return *this ;
}
}

skinArray::skinArray(NSContexte* pCtx)
          :skinsArray(), NSRoot(pCtx)
{
	sTitle      = "";
	sAuthor     = "";
	sComment    = "";

	sAppName    = "";
}

skinArray::skinArray(skinArray& rv)
          :skinsArray(), NSRoot(rv.pContexte){
try
{
	if (!(rv.empty()))
		for (skin_iter i = rv.begin(); i != rv.end(); i++)
			push_back(new nsSkin(*(*i))) ;
}
catch (...)
{
	erreur("Exception skinArray copy ctor.", standardError, 0) ;
}
}

void
skinArray::vider(){
	if (empty())
		return ;

	for (skin_iter i = begin(); i != end(); )
	{
		delete *i ;
    erase(i) ;
	}
}

skinArray::~skinArray()
{
	vider() ;
}

void
skinArray::init(string sPath)
{
try
{
	ifstream    inFile ;

	string sLang = "" ;
	string sFichierTempo = sPath + string("skin.ini") ;

	inFile.open(sFichierTempo.c_str()) ;
	if (!inFile)
		return ;

	string              _sTitre     = "" ;

	string              _sBmp       = "" ;
	nsSkin::TYPEBMPDRAW _iDraw      = nsSkin::DrawUndefined ;
	TColor*             _pBackColor = 0 ;

	LOGFONT*            _pFontDesc  = 0 ;
	TColor*             _pFontColor = 0 ;
	TColor*             _pFontBackColor = 0 ;
	std::string	        _Ico        = "" ;

  nsBoxPosition boxPos ;

	// int     inumLigne = 0 ;

	while (!inFile.eof())
	{
    string _sLine ;

		getline(inFile, _sLine) ;
    strip(_sLine, stripBoth) ;

    if (_sLine != "")
    {
    	if (_sLine[0] == '[')
      {
      	if (_sTitre != "")
        {
        	nsSkin* pSkin = new nsSkin(sPath) ;

          pSkin->setName(_sTitre) ;

          if (_pBackColor)
          {
          	pSkin->setBackColor(_pBackColor) ;
            delete _pBackColor ;
            _pBackColor = 0 ;
          }

          pSkin->setBackBmp(_sBmp) ;
          if (nsSkin::DrawUndefined != _iDraw)
          {
          	pSkin->setBackDraw(_iDraw) ;
          	_iDraw = nsSkin::DrawUndefined ;
          }

          if (_Ico != "")
    				pSkin->setBackIco(_Ico) ;

          if (_pFontColor)
          {
          	pSkin->setFontColor(_pFontColor) ;
          	delete _pFontColor ;
          	_pFontColor = 0 ;
          }
          if (_pFontBackColor)
          {
          	pSkin->setFontBackColor(_pFontBackColor) ;
            delete _pFontBackColor ;
            _pFontBackColor = 0 ;
          }
          if (_pFontDesc)
          {
          	pSkin->setLogFont(_pFontDesc) ;
            delete _pFontDesc ;
            _pFontDesc = 0 ;
          }

          *(pSkin->getBoxPosition()) = boxPos ;
          boxPos.initDefault() ;

          push_back(pSkin) ;

          _sBmp = "" ;
          _Ico  = "" ;
        }

        _sTitre = "" ;
        size_t iPos = _sLine.find(']') ;
        if (iPos != NPOS)
        	_sTitre = string(_sLine, 1, iPos-1) ;
      }
      else if (_sLine[0] != '/')
      {
      	size_t iPos = _sLine.find('=') ;
        if ((iPos != NPOS) && (iPos != strlen(_sLine.c_str())-1))
        {
        	string _sType  = string(_sLine, 0, iPos) ;
          string _sLibel = string(_sLine, iPos+1, strlen(_sLine.c_str())-iPos-1) ;
          strip(_sType, stripBoth) ;
          strip(_sLibel, stripBoth) ;
          _sType = pseumaj(_sType) ;

          //
          // Bitmap
          //
          if      (string("BMP") == _sType)
          	_sBmp = _sLibel ;

          //
          // ICO
          //
          else if (string("ICO") == _sType)
          	_Ico = _sLibel ;

          //
          // Draw type
          //
          else if (string("DRAW") == _sType)
          {
            _sLibel = pseumaj(_sLibel) ;

            if      (string("CENTER")  == _sLibel)
            	_iDraw = nsSkin::DrawCenter ;
            else if (string("STRETCH") == _sLibel)
            	_iDraw = nsSkin::DrawStretch ;
            else if (string("TILE")    == _sLibel)
            	_iDraw = nsSkin::DrawTile ;
            else if (string("MAX")     == _sLibel)
            	_iDraw = nsSkin::DrawMax ;
            else if (string("FORM")    == _sLibel)
              _iDraw = nsSkin::DrawAsForm ;
          }
          //
          // Couleur
          //
          else if ((string("TEXTCOLOR")     == _sType) ||
                   (string("BACKCOLOR")     == _sType) ||
                   (string("TEXTBACKCOLOR") == _sType))
          {
            int iNumCol = 0 ;

            int iRed    = 0 ;
            int iGreen  = 0 ;
            int iBlue   = 0 ;

            size_t iLibPos = _sLibel.find(',') ;
            while (NPOS != iLibPos)
            {
            	string sColor = string(_sLibel, 0, iLibPos) ;
              _sLibel = string(_sLibel, iLibPos+1, strlen(_sLibel.c_str())-iLibPos-1) ;

              if      (0 == iNumCol)
              	iRed    = atoi(sColor.c_str()) ;
              else if (1 == iNumCol)
              	iGreen  = atoi(sColor.c_str()) ;
              else if (2 == iNumCol)
              	iBlue   = atoi(sColor.c_str()) ;

              iNumCol++ ;

              iLibPos = _sLibel.find(',') ;
            }

            string sColor = _sLibel ;

            if      (0 == iNumCol)
            	iRed    = atoi(sColor.c_str()) ;
            else if (1 == iNumCol)
            	iGreen  = atoi(sColor.c_str()) ;
            else if (2 == iNumCol)
            	iBlue   = atoi(sColor.c_str()) ;

            if      (string("TEXTCOLOR") == _sType)
            	_pFontColor = new TColor(iRed, iGreen, iBlue) ;
            else if (string("BACKCOLOR") == _sType)
            	_pBackColor = new TColor(iRed, iGreen, iBlue) ;
            else if (string("TEXTBACKCOLOR") == _sType)
            	_pFontBackColor = new TColor(iRed, iGreen, iBlue) ;
          }
          //
          // Position
          //
          else if (string("POS") == string(_sType, 0, 3))
            boxPos.initValue(_sType, _sLibel) ;
            
          else if (string("NAME") == _sType)
          {
          	if (string("Skin") == _sTitre)
            	sTitle = _sLibel ;
          }
          else if (string("AUTHOR") == _sType)
          {
          	if (string("Skin") == _sTitre)
            	sAuthor = _sLibel ;
          }
          else if (string("COMMENT") == _sType)
          {
          	if (string("Skin") == _sTitre)
            	sComment = _sLibel ;
          }
          else if (string("APPNAME") == _sType)
          {
          	if (string("Skin") == _sTitre)
            	sAppName = _sLibel ;
          }
        }
      }
    }
  }

  if (string("") != _sTitre)
  {
    nsSkin* pSkin = new nsSkin(sPath) ;

    pSkin->setName(_sTitre) ;

    if (_pBackColor)
    {
    	pSkin->setBackColor(_pBackColor) ;
      delete _pBackColor ;
    }

    pSkin->setBackBmp(_sBmp) ;
    if (nsSkin::DrawUndefined != _iDraw)
    	pSkin->setBackDraw(_iDraw) ;

    if (_pFontColor)
    {
    	pSkin->setFontColor(_pFontColor) ;
      delete _pFontColor ;
    }
    if (_pFontBackColor)
    {
    	pSkin->setFontBackColor(_pFontBackColor) ;
      delete _pFontBackColor ;
    }
    if (_pFontDesc)
    {
    	pSkin->setLogFont(_pFontDesc) ;
      delete _pFontDesc ;
    }

    if (_Ico != "")
    	pSkin->setBackIco(_Ico) ;

    *(pSkin->getBoxPosition()) = boxPos ;

    push_back(pSkin) ;
  }

  inFile.close() ;
  return ;
}
catch (...)
{
	erreur("Exception skinArray::init", standardError, 0) ;
}
}

nsSkin*
skinArray::donneSkin(string sName)
{
	if (empty())
		return 0 ;

	for (skin_iter i = begin(); i != end(); i++)
  	if (*((*i)->getName()) == sName)
    	return *i ;

	return 0 ;
}

skinArray&
skinArray::operator=(skinArray src)
{
try
{
	if (this == &src)
		return *this ;

	vider();

	if (!(src.empty()))
		for (skin_iter i = src.begin(); i != src.end(); i++)
    	push_back(new nsSkin(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception skinArray::operator=", standardError, 0) ;
	return *this;
}
}

//
// --------------------- nsBoxPosition ---------------------
//

nsBoxPosition::nsBoxPosition()
{
  initDefault() ;
}

nsBoxPosition::nsBoxPosition(nsBoxPosition& rv)
{
  initDefault() ;
  initFromBP(&rv) ;
}

nsBoxPosition::~nsBoxPosition()
{
}

nsBoxPosition&
nsBoxPosition::operator=(nsBoxPosition& src)
{
  if (this == &src)
    return *this ;

  initDefault() ;
  initFromBP(&src) ;

  return *this ;
}

void
nsBoxPosition::initDefault()
{
  sGlobalVPos     = string("") ;
  sGlobalVPosRef  = string("") ;

  sGlobalHPos     = string("") ;
  sGlobalHPosRef  = string("") ;

  sTopPosRef      = string("") ;
  sTopUnit        = string("") ;
  iTopValue       = 0 ;

  sRightPosRef    = string("") ;
  sRightUnit      = string("") ;
  iRightValue     = 0 ;

  sBottomPosRef   = string("") ;
  sBottomUnit     = string("") ;
  iBottomValue    = 0 ;

  sLeftPosRef     = string("") ;
  sLeftUnit       = string("") ;
  iLeftValue      = 0 ;

  sHeightUnit     = string("") ;
  iHeightValue    = 0 ;
  sMinHeightUnit  = string("") ;
  iMinHeightValue = 0 ;

  sWidthUnit      = string("") ;
  iWidthValue     = 0 ;
  sMinWidthUnit   = string("") ;
  iMinWidthValue  = 0 ;
}

void
nsBoxPosition::initFromBP(nsBoxPosition* pBP)
{
  if (NULL == pBP)
    return ;

  sGlobalVPos     = pBP->sGlobalVPos ;
  sGlobalVPosRef  = pBP->sGlobalVPosRef ;

  sGlobalHPos     = pBP->sGlobalHPos ;
  sGlobalHPosRef  = pBP->sGlobalHPosRef ;

  sTopPosRef      = pBP->sTopPosRef ;
  sTopUnit        = pBP->sTopUnit ;
  iTopValue       = pBP->iTopValue ;

  sRightPosRef    = pBP->sRightPosRef ;
  sRightUnit      = pBP->sRightUnit ;
  iRightValue     = pBP->iRightValue ;

  sBottomPosRef   = pBP->sBottomPosRef ;
  sBottomUnit     = pBP->sBottomUnit ;
  iBottomValue    = pBP->iBottomValue ;

  sLeftPosRef     = pBP->sLeftPosRef ;
  sLeftUnit       = pBP->sLeftUnit ;
  iLeftValue      = pBP->iLeftValue ;

  sHeightUnit     = pBP->sHeightUnit ;
  iHeightValue    = pBP->iHeightValue ;
  sMinHeightUnit  = pBP->sMinHeightUnit ;
  iMinHeightValue = pBP->iMinHeightValue ;

  sWidthUnit      = pBP->sWidthUnit ;
  iWidthValue     = pBP->iWidthValue ;
  sMinWidthUnit   = pBP->sMinWidthUnit ;
  iMinWidthValue  = pBP->iMinWidthValue ;
}

string
nsBoxPosition::initValue(string sAttribute, string sValue)
{
  if      (string("POSVERTICAL") == sAttribute)
    return setVPos(sValue) ;
  else if (string("POSHORIZONTAL") == sAttribute)
    return setHPos(sValue) ;
  else if (string("POSTOP") == sAttribute)
    return setTop(sValue) ;
  else if (string("POSRIGHT") == sAttribute)
    return setRight(sValue) ;
  else if (string("POSBOTTOM") == sAttribute)
    return setBottom(sValue) ;
  else if (string("POSLEFT") == sAttribute)
    return setLeft(sValue) ;
  else if (string("POSHEIGHT") == sAttribute)
    return setHeight(sValue) ;
  else if (string("POSWIDTH") == sAttribute)
    return setWidth(sValue) ;
  else
    return string("BadAttribute") ;
}

string
nsBoxPosition::setVPos(string sValue)
{
  return setPosAndRef(sValue, string("CENTER:TOP:BOTTOM"), &sGlobalVPos, &sGlobalVPosRef) ;
}

string
nsBoxPosition::setHPos(string sValue)
{
  return setPosAndRef(sValue, string("CENTER:LEFT:RIGHT"), &sGlobalHPos, &sGlobalHPosRef) ;
}

string
nsBoxPosition::setPosAndRef(string sValue, string sPosLegalValues, string* psPos, string* psRef)
{
  *psPos = string("") ;
  *psRef = string("") ;

  // Model: "Reference,value" or just "value"
  //
  if (string("") == sValue)
    return string("") ;

  strip(sValue, stripBoth) ;

  string sPos ;
  string sRef ;

  size_t iLibPos = sValue.find(',') ;
  if (NPOS != iLibPos)
  {
    sRef = string(sValue, 0, iLibPos) ;
    sPos = string(sValue, iLibPos+1, strlen(sValue.c_str()) - iLibPos - 1) ;

    strip(sRef, stripBoth) ;
    strip(sPos, stripBoth) ;

    sRef = pseumaj(sRef) ;
    sPos = pseumaj(sPos) ;

    // Check that the order is not wrong
    //
    size_t iPosPos = sPosLegalValues.find(sRef) ;
    if (NPOS != iPosPos)
    {
      string sSwitch = sRef ;
      sRef = sPos ;
      sPos = sSwitch ;
    }
  }
  else
  {
    sPos = pseumaj(sValue) ;
    sRef = string("WINDOW") ;
  }

  size_t iPosPos = sPosLegalValues.find(sPos) ;
  if (NPOS == iPosPos)
    return string("BadPosValue") ;

  *psPos = sPos ;
  *psRef = sRef ;

  return string("") ;
}

string
nsBoxPosition::setTop(string sValue)
{
  return setNumericPosAndRef(sValue, &sTopPosRef, &iTopValue, &sTopUnit) ;
}

string
nsBoxPosition::setRight(string sValue)
{
  return setNumericPosAndRef(sValue, &sRightPosRef, &iRightValue, &sRightUnit) ;
}

string
nsBoxPosition::setBottom(string sValue)
{
  return setNumericPosAndRef(sValue, &sBottomPosRef, &iBottomValue, &sBottomUnit) ;
}

string
nsBoxPosition::setLeft(string sValue)
{
  return setNumericPosAndRef(sValue, &sLeftPosRef, &iLeftValue, &sLeftUnit) ;
}

string
nsBoxPosition::setNumericPosAndRef(string sValue, string* psRef, int* piNum, string* psUnit)
{
  *psUnit = string("") ;
  *psRef  = string("") ;
  *piNum  = 0 ;

  // Model: "Reference,value" or just "value"
  //
  if (string("") == sValue)
    return string("") ;

  strip(sValue, stripBoth) ;

  string sRef ;
  string sNum ;

  size_t iLibPos = sValue.find(',') ;
  if (NPOS != iLibPos)
  {
    sRef = string(sValue, 0, iLibPos) ;
    sNum = string(sValue, iLibPos+1, strlen(sValue.c_str()) - iLibPos - 1) ;

    strip(sRef, stripBoth) ;
    strip(sNum, stripBoth) ;

    sRef = pseumaj(sRef) ;
    sNum = pseumaj(sNum) ;

    // Check that the order is not wrong
    //
    if (isNumAndUnit(sRef))
    {
      string sSwitch = sRef ;
      sRef = sNum ;
      sNum = sSwitch ;
    }
  }
  else
  {
    sNum = pseumaj(sValue) ;
    sRef = string("PARENT") ;
  }

  if (false == isNumAndUnit(sNum))
    return string("BadNumValue") ;

  *psRef = sRef ;

  return setNumericPos(sNum, piNum, psUnit) ;
}

string
nsBoxPosition::setHeight(string sValue)
{
  return setNumericPos(sValue, &iHeightValue, &sHeightUnit) ;
}

string
nsBoxPosition::setWidth(string sValue)
{
  return setNumericPos(sValue, &iWidthValue, &sWidthUnit) ;
}

string
nsBoxPosition::setNumericPos(string sValue, int* piNum, string* psUnit)
{
  *psUnit = string("") ;
  *piNum  = 0 ;

  // Model: "Reference,value" or just "value"
  //
  if (string("") == sValue)
    return string("") ;

  if (string("AUTO") == sValue)
  {
    *psUnit = string("AUTO") ;
    return string("") ;
  }

  strip(sValue, stripBoth) ;

  if (false == isNumAndUnit(sValue))
    return string("BadNumValue") ;

  string sNum ;
  string sUnit ;

  size_t iLibPos = sValue.find('%') ;
  if (NPOS != iLibPos)
  {
    sNum  = string(sValue, 0, iLibPos) ;
    sUnit = string(sValue, iLibPos, strlen(sValue.c_str()) - iLibPos) ;

    strip(sUnit, stripBoth) ;
    strip(sNum, stripBoth) ;

    sUnit = pseumaj(sUnit) ;
    sNum  = pseumaj(sNum) ;
  }
  else
  {
    sNum  = sValue ;
    sUnit = string("PIX") ;
  }

  if (strlen(sNum.c_str()) > 32)
    return string("BadNumValue") ;

  for (size_t i = 0 ; i < strlen(sNum.c_str()); i++)
    if (!isdigit(sNum[i]))
      return string("BadNumValue") ;

  *psUnit = sUnit ;
  *piNum  = atoi(sNum.c_str()) ;

  return string("") ;
}

bool
nsBoxPosition::isNumAndUnit(string sValue)
{
  if (string("") == sValue)
    return false ;

  if (string("AUTO") == sValue)
    return true ;

  string sNum ;

  size_t iLibPos = sValue.find('%') ;
  if (NPOS != iLibPos)
    sNum = string(sValue, 0, iLibPos) ;
  else
    sNum = sValue ;

  if (strlen(sNum.c_str()) > 32)
    return false ;

  for (size_t i = 0 ; i < strlen(sNum.c_str()); i++)
    if (!isdigit(sNum[i]))
      return false ;

  return true ;
}

