// Fichier nschemin.cpp - M�thodes de la classe NSChemins - RS Janvier 1998///////////////////////////////////////////////////////////////////////////

#include "ns_sgbd\nschemin.h"

//***************************************************************************
//
// Impl�mentation des m�thodes NSCheminsData
//
//***************************************************************************

//---------------------------------------------------------------------------
//  Function:  NSCheminsData::NSCheminsData()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSCheminsData::NSCheminsData()
{
	metAZero();
}

//---------------------------------------------------------------------------
//  Fonction:		NSCheminsData::NSCheminsData(NSCheminsData& rv)
//  Description:	Constructeur copie

//  Retour:			Rien
//---------------------------------------------------------------------------
NSCheminsData::NSCheminsData(NSCheminsData& rv){
   strcpy(code,   	rv.code);
   strcpy(nom,			rv.nom);
   strcpy(chemin,		rv.chemin);
   strcpy(support,	rv.support);
   strcpy(type_doc,	rv.type_doc);
}

//---------------------------------------------------------------------------//  Fonction:		NSCheminsData::operator=(NSCheminsData src)
//  Description:	Op�rateur =
//  Retour:			R�f�rence sur l'objet cible
//---------------------------------------------------------------------------
NSCheminsData&
NSCheminsData::operator=(NSCheminsData src)
{
	if (this == &src)
		return *this ;

  strcpy(code,   	 src.code) ;
  strcpy(nom,			 src.nom) ;
  strcpy(chemin,	 src.chemin) ;
  strcpy(support,	 src.support) ;
  strcpy(type_doc, src.type_doc) ;

	return *this;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCheminsData::operator==(NSCheminsData& o)
//  Description:	Op�rateur de comparaison
//  Retour:			0 ou 1
//---------------------------------------------------------------------------
int
NSCheminsData::operator == ( NSCheminsData& o )
{
	if ((strcmp(code,   	  o.code) 		== 0) &&
		 (strcmp(nom,  	  o.nom) 		== 0) &&
       (strcmp(chemin,	  o.chemin)		== 0) &&
       (strcmp(support,	  o.support)	== 0) &&
       (strcmp(type_doc,  o.type_doc)	== 0))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------//  Function:		NSCheminsData::metAZero()
//  Description:	Initialise les champs de donn�es � z�ro.
//  Retour:			Aucun
//---------------------------------------------------------------------------
void
NSCheminsData::metAZero()
{
  // Met les champs de donn�es � z�ro
  memset(code,      0, CHM_CODE_LEN + 1);
  memset(nom,	    0, CHM_NOM_LEN + 1);
  memset(chemin,    0, CHM_CHEMIN_LEN + 1);
  memset(support,   0, CHM_SUPPORT_LEN + 1);
  memset(type_doc,  0, CHM_TYPE_DOC_LEN + 1);
}

//***************************************************************************//
// Impl�mentation des m�thodes NSCheminsInfo
//
//***************************************************************************

//---------------------------------------------------------------------------
//  Fonction:		NSCheminsInfo::NSCheminsInfo()
//  Description:	Constructeur par d�faut
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCheminsInfo::NSCheminsInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSCheminsData();
}

//---------------------------------------------------------------------------//  Fonction:		NSCheminsInfo::NSCheminsInfo(NSChemins*)
//  Description:	Constructeur � partir d'un NSChemins
//  Retour:			Rien
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------//  Fonction:		NSCheminsInfo::~NSCheminsInfo()
//  Description:	Destructeur
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCheminsInfo::~NSCheminsInfo()
{
	delete pDonnees ;
}

//---------------------------------------------------------------------------//  Fonction:		NSCheminsInfo::NSCheminsInfo(NSCheminsInfo& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCheminsInfo::NSCheminsInfo(NSCheminsInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCheminsData();
	//
	// Copie les valeurs du NSCheminsInfo d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------//  Fonction:		NSCheminsInfo::operator=(NSCheminsInfo src)
//  Description:	Op�rateur d'affectation
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
NSCheminsInfo&
NSCheminsInfo::operator=(NSCheminsInfo src)
{
	if (this == &src)
		return *this ;

	*pDonnees = *(src.pDonnees) ;

	return *this ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCheminsInfo::operator==(NSCheminsInfo src)
//  Description:	Op�rateur de comparaison
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
int NSCheminsInfo::operator == ( NSCheminsInfo& o )
{
	 return (*pDonnees == *(o.pDonnees));
}

///////////////////////////////////////////////////////////////////////////////
// Impl�mentation des m�thodes de la classe NSSupports
//
/////////////////////////////////////////////////////////////////////////////


//***************************************************************************
//
// Impl�mentation des m�thodes NSSupportsData
//
//***************************************************************************

//---------------------------------------------------------------------------
//  Function:  NSSupportsData::NSSupportsData()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSSupportsData::NSSupportsData()
{
	metAZero();
}

//---------------------------------------------------------------------------
//  Fonction:		NSSupportsData::NSSupportsData(NSSupportsData& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSSupportsData::NSSupportsData(const NSSupportsData& rv)
{
  strcpy(code,        rv.code) ;
  strcpy(nom,         rv.nom) ;
  strcpy(nom_serveur, rv.nom_serveur) ;
  strcpy(unite,       rv.unite) ;
  strcpy(fixe,        rv.fixe) ;

	sNomServeur = rv.sNomServeur ;
}

//---------------------------------------------------------------------------//  Fonction:		NSSupportsData::operator=(NSSupportsData src)
//  Description:	Op�rateur =
//  Retour:			R�f�rence sur l'objet cible
//---------------------------------------------------------------------------
NSSupportsData&
NSSupportsData::operator=(const NSSupportsData& src)
{
	if (this == &src)
		return *this ;

  strcpy(code,        src.code) ;
  strcpy(nom,         src.nom) ;
  strcpy(nom_serveur, src.nom_serveur) ;
  strcpy(unite,       src.unite) ;
  strcpy(fixe,        src.fixe) ;

  sNomServeur = src.sNomServeur ;

  return (*this) ;
}

//---------------------------------------------------------------------------//  Fonction:		NSSupportsData::operator==(NSSupportsData& o)
//  Description:	Op�rateur de comparaison
//  Retour:			0 ou 1
//---------------------------------------------------------------------------
int
NSSupportsData::operator==(NSSupportsData& o)
{
	if ((strcmp(code,   	    o.code) 	    == 0) &&
        (strcmp(nom,  	  		o.nom) 		    == 0) &&
        (strcmp(nom_serveur,    o.nom_serveur)  == 0) &&
        (sNomServeur == o.sNomServeur) &&
        (strcmp(unite,	  		o.unite)	    == 0) &&
        (strcmp(fixe,  			o.fixe)			== 0))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------//  Function:		NSSupportsData::metAZero()
//  Description:	Initialise les champs de donn�es � z�ro.
//  Retour:			Aucun
//---------------------------------------------------------------------------
void NSSupportsData::metAZero()
{
    // Met les champs de donn�es � z�ro
    memset(code,        0, SUP_CODE_LEN + 1);
    memset(nom,			0, SUP_NOM_LEN + 1);
    memset(nom_serveur, 0, SUP_NOM_SERVEUR_LEN + 1);

    sNomServeur = "" ;

    memset(unite,	    0, SUP_UNITE_LEN + 1);
    memset(fixe,	    0, SUP_FIXE_LEN + 1);
}

//***************************************************************************//
// Impl�mentation des m�thodes NSSupportsInfo
//
//***************************************************************************
//---------------------------------------------------------------------------
//  Fonction:		NSSupportsInfo::NSSupportsInfo()
//  Description:	Constructeur par d�faut
//  Retour:			Rien
//---------------------------------------------------------------------------
NSSupportsInfo::NSSupportsInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSSupportsData() ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSSupportsInfo::~NSSupportsInfo()
//  Description:	Destructeur
//  Retour:			Rien
//---------------------------------------------------------------------------
NSSupportsInfo::~NSSupportsInfo()
{
	delete pDonnees;
}

string
NSSupportsInfo::getRootPath()
{
	return pDonnees->sNomServeur ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSSupportsInfo::NSSupportsInfo(NSSupportsInfo& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSSupportsInfo::NSSupportsInfo(NSSupportsInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSSupportsData() ;
	//
	// Copie les valeurs du NSSupportsInfo d'origine
	//
	*pDonnees = *(rv.pDonnees) ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSSupportsInfo::operator=(NSSupportsInfo src)
//  Description:	Op�rateur d'affectation
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
NSSupportsInfo&
NSSupportsInfo::operator=(NSSupportsInfo src)
{
	if (this == &src)
		return *this ;

	*pDonnees = *(src.pDonnees) ;

	return *this ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSSupportsInfo::operator==(NSSupportsInfo src)
//  Description:	Op�rateur de comparaison
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
int NSSupportsInfo::operator == ( NSSupportsInfo& o )
{
	return (*pDonnees == *(o.pDonnees)) ;
}

//***************************************************************************// Impl�mentation des m�thodes NSSupportsArray//***************************************************************************

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------

NSSupportsArray::NSSupportsArray(NSSupportsArray& rv)					:NSSupportsVector()
{
	if (!(rv.empty()))
		for (SupportsIter i = rv.begin(); i != rv.end(); i++)
    	push_back(new NSSupportsInfo(*(*i))) ;
}

//---------------------------------------------------------------------------
//  Operateur =
//---------------------------------------------------------------------------

NSSupportsArray&
NSSupportsArray::operator=(NSSupportsArray& src)
{
	if (this == &src)
		return *this ;

	vider() ;

	if (!(src.empty()))
  	for (SupportsIter i = src.begin(); i != src.end(); i++)    	push_back(new NSSupportsInfo(*(*i))) ;

	return *this ;}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------

voidNSSupportsArray::vider()
{
	if (empty())
  	return ;

	for (SupportsIter i = begin(); i != end();)
  {
  	delete *i ;
    erase(i) ;
  }
}

NSSupportsArray::~NSSupportsArray(){
	vider() ;
}
// Fin du fichier NSChemin.cpp
///////////////////////////////////////

