/*
**
** BB1Event.h
**
*/

/*
** An event is a record of a change of a single object on the blackboard.
** The object can be added or deleted, or any number of attributes and
** links can have been modified.
*/

#ifndef _BB1Event_h
# define _BB1Event_h 1

# ifdef __GNUC__
#  pragma interface
# endif // __GNUC__

# include "BB1Object.h"

#ifndef __TCONTROLER__

//class ostream; // for operator<<(...)
class BB1BB ;
class BB1KB ;

string&		decToString(string& S, const int i) ;


class BB1Event : public BB1Object
{

  // -------------------------------------------------------------------------
	// friend class

  /* Allowed to call BB1Event() */
  friend class BB1BB;

  friend class BB1Object ;

  friend class ObjectList ;
	friend class EventSet ;
	friend class ObjectSet ;

	// -------------------------------------------------------------------------
	// public functions

 public: // API
	BB1Event(	const string&		oname,
						BB1KB&					kb,
						BB1Class				*c,
						const AVPSet		*chgAttributes,
						const LinkSet		*chgLinks,
						EventType				changeType,
						BB1Object&			Object) ;

	BB1Event(const BB1Event& src) ;

	~BB1Event() ;

	bool							ChangedAttributeIsP(const string &attribute) const
	{
		if (changedAttributes && !changedAttributes->empty())
			for (AVPCIter a = changedAttributes->begin() ; a != changedAttributes->end() ; a++)
			{
				if ((*a)->AttributeName() == attribute)
					return (true) ;
			}
		return (false) ;
	} ;

	bool							ChangedLinkIsP(const string &linkName) const ;
	bool							EventKBNamedP(const string& eventName) const ;

	/* Is the event of the specified type? */
	bool							EventTypeIsP(const EventType eventType) const { return (type == eventType) ; } ;

	/* Return the object whose creation or modification engendered the event */
	BB1Object&				Object() const { return (object) ; } ;

	const string&			TypeString() const ;

	const AVPSet			*ChangeAttributes() const { return changedAttributes ; }


	// -------------------------------------------------------------------------
	// private functions

 private:
	/* Return the kind of blackboard change that the event represents */
	EventType					Type() const { return (type) ; } ;

	void							Save(ofstream& KBstream) { } ; // Events can't be saved
	void							IncrementKSARCount(int inc = 1) { BB1EventKSARcount += inc ; } ;
	bool							KSARlessP() const { return (BB1EventKSARcount == 0) ; } ;



  // -------------------------------------------------------------------------
	// private members

 private:
	const EventType		type ;								// what kind of blackboard modification
	BB1Object&				object ;							// the object added, deleted, or modified
	AVPSet						*changedAttributes ;	// list of attributes added, deleted, or modified
	LinkSet						*changedLinks ;				// list of links added or deleted
	int								BB1EventKSARcount ;		// # of KSARs for which this is trigger event

};

std::ostream& operator<<(std::ostream& os, const BB1Event& obj) ;

#endif

#endif // _BB1Event_h
