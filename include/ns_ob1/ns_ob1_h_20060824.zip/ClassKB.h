#ifndef _ClassKB_h
#define _ClassKB_h

class BB1BB ;

void	loadClassKB(BB1BB& bb) ;

#endif // _ClassKB_h
