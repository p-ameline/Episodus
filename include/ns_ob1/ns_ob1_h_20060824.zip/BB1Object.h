/*
** Copyright Nautilus, (10/9/2004)
** fabrice.le_perru@nautilus-info.com
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/
// All blackboard elements are objects.  Since anything that one can reason
// about should be on the blackboard, that can be almost anything. In practice,
// only things expected to be reasoned about should be objects.

#ifndef _BB1Object_h
  #define _BB1Object_h 1

#ifdef __GNUC__
  #pragma interface
#endif // __GNUC__

#include <fstream.h>         // for Save(...)
#include "TypedVal.h"
#include "AttValPair.h"
#include "BB1types.h"
#include "BB1KB.h"
#include "ns_ob1\toolbox.h"

class BB1BB ;
class BB1Class ;
class BB1Decision ;
class BB1Event ;
class BB1KB ;     // for friend delclaration
class BB1Link ;
class BB1Message ;
class BB1Object ; // for declaration of ::ModifyObject(...)


extern const AVPSet			NULLAVPSET ;
extern const LinkSet		NULLLINKSET ;




 Errcode _BBKEXPORT	ModifyObject(	BB1Object&		object,
																const AVPSet	*attSpec,
																const LinkSet	*linkSpec,
																const AVPSet	*delAttSpec,
																const LinkSet	*delLinkSpec,
																const int			eventP,
                                bool  temp) ;


NSPatPathoArray* _BBKEXPORT getPatPatho2(BB1Object* temp, const std::string& pathpathoname);

bool  _BBKEXPORT    getBoolAnswer(Transfert& reponse  ,  std::string& sQuestion);

class _BBKEXPORT BB1Object
{
	friend class NBBKB ;
	friend class NautilusBB ;
	
  // Allowed to call BB1Object()
	friend class BB1AppInst ;
	friend class BB1BB ;
	friend class BB1Class ;
	friend class BB1Decision ;
	friend class BB1Event ;
	friend class BB1KS ;
	friend class BB1KSAR ;
	friend class BB1Message ;
  friend NSPatPathoArray* getPatPatho(BB1Object* temp, std::string& pathpathoname);

	// Allowed to call ~BB1Object() and Attributes()
	friend class BB1KB ;


  friend class ObjectList ;
	friend class ObjectSet ;

	// Allowed to access attributes and links
	friend std::ostream&	operator<<(std::ostream& os, const BB1Object& obj) ;

	// Allowed to call ProcessAttributes(...) and ProcessLinksNN(...)
	friend Errcode	ModifyObject(	BB1Object&		object,
																const AVPSet	*attSpec,
																const LinkSet	*linkSpec,
																const AVPSet	*delAttSpec,
																const LinkSet	*delLinkSpec,
																const int			eventP,
                                bool  temp) ;

 public: // API

  BB1Object(const string& oname,AttValPair&   dispatch , BB1KB& kb, BB1Class *Class) ;

	BB1Object(const BB1Object& bbObj) ;
	~BB1Object() ;

  inline
	BB1BB&					BB() const 																						{ return (KB().BB()) ; }

	// Return a pointer to the class of this instance
	const BB1Class	*Class() const 																				{ return ((BB1Class *) Object("Exemplifies")) ; }

	// Return the cycle upon which the object was created
	Cycle						CycleCreated() const 																	{ return (cycleCreated) ; }

	bool						ExemplifiesP(const string& c) const ;


  Errcode				 AddLink(const string& forwardLinkName, const string& inverseLinkName, BB1Object& toObject) ;


	// If the attribute is bound locally, return TRUE; otherwise, return FALSE.
	bool						HasAttributeP(const AttValPair& avp) const						{ return (GetLocalAttribute(avp) ? true : false) ; }

	bool						HasLinkP(const string& linkName, const BB1Object& ToObject) const
		{ return (GetLocalLink(linkName, ToObject) ? true : false) ; } ;

	// Return a reference to the object's knowledge base
  inline
	BB1KB&					KB() const 																						{ return (knowledgeBase) ; } ;

  inline
	string					LongName() const ;



	Errcode					Modify( const AVPSet		*attSpec			= NULL,
													const LinkSet		*linkSpec			= NULL,
													const AVPSet		*delAttSpec		= NULL,
													const LinkSet		*delLinkSpec	= NULL,
													const int				eventP				= TRUE,
                          bool createToken = true)
  { return (ModifyObject(*this, attSpec, linkSpec, delAttSpec, delLinkSpec, eventP,createToken)) ; } ;



	// Return a reference to the object's name
	const string&		Name() const 																					{ return (name) ; } ;

	BB1Object				*Object(const string& oname) const ;
	ObjectList				*Objects(const string& oname, ObjectList *retval) const ;

	// Is this BB1Object a strategy control-plan object?
	bool						Value(const string& attribute, bool&						 			b ) const ;
  NautilusQuestion* Value(const string & attribute,NautilusQuestion*      c) const ;
	double					Value(const string& attribute, double&					 			d ) const ;
   long						Value(const string& attribute, long&						 			l ) const ;
	const string		Value(const string& attribute, const string&			 		s ) const ;
	NSPatPathoArray	*Value(const string& attribute, NSPatPathoArray 	*patho) const ;
	BB1Object				*Value(const string& attribute, BB1Object					*objet) const ;
  #ifdef __OB1__UNOPTIM__
  int							Value(const string& attribute, int&							 			i ) const ;
  float						Value(const string& attribute, float&						 			f ) const ;
  char						Value(const string& attribute, char&						 			c ) const ;
  short						Value(const string& attribute, short&						 			s ) const ;
  unsigned char		Value(const string& attribute, unsigned char&			 		uc) const ;
	unsigned int		Value(const string& attribute, unsigned int&			 		ui) const ;
	unsigned long		Value(const string& attribute, unsigned long&			 		ul) const ;
	unsigned short	Value(const string& attribute, unsigned short&		 		us) const ;
  PathsList				*Value(const string& attribute, PathsList       	*paths) const ;
  #endif

  std::string     getQuestionPath() ;

  inline
  const TypedVal&        Attributes(const std::string&  attributes);  /*renvoie the first type val of a name */

	// For user interfaces
	const AVPSet		*Attributes() const																		{ return (attributes) ; } ;
	const LinkSet		*Links() const 																				{ return (links) ; } ;
	const Voidptr		Value(const string& attribute, Voidptr& p) const ;
	virtual bool		IsAP(const string& c) const ;
	virtual bool		UpdatePrescriptionTCAux() const ;
	virtual bool		UpdatePrescriptionOCAux() const ;
	virtual Errcode	UpdatePrescriptionACAux() ;
	virtual bool		TerminatePrescriptionTCAux() const ;
	virtual bool		TerminatePrescriptionPCAux() const ;
	virtual bool		TerminatePrescriptionOCAux() const ;
	virtual Errcode	TerminatePrescriptionACAux() ;
	virtual void		DeleteParentDecision(BB1Decision *decision) ;

	BB1Object&			operator=(BB1Object& src) ;

 protected:

 void CreateToken(const EventType et, const AVPSet *attSpec, const LinkSet *linkSpec,
                   const AVPSet *delAttSpec, const LinkSet *delLinkSpec, bool createStrat = false);


	Errcode					ProcessAttributes(const AVPSet 	*attSpec 	= NULL, const AVPSet 	*delAttSpec 	= NULL) ;
	Errcode					ProcessLinksNN(const LinkSet 		*linkSpec = NULL, const LinkSet *delLinkSpec 	= NULL) ;
	Errcode					ProcessLinkAdd(const BB1Link& 	newLink) ;
	Errcode					ProcessLinkDel(const BB1Link& 	delLink) ;

	//Errcode					AddLink(const string& forwardLinkName, const string& inverseLinkName, BB1Object& toObject) ;
	Errcode					DeleteAllAttributes() ;
	Errcode					DeleteAllLinks() ;
	void						DeleteLink(BB1Link *flptr, const BB1Class& c) ;
  inline
	bool						AVPMatch(const AttValPair& avp1, const AttValPair& avp2) const ;
	AttValPair			*GetInheritedAttribute(const AttValPair& avp) const ;
	AttValPair			*GetLocalAttribute(const AttValPair& avp) const ;
	BB1Link					*GetLocalLink(const string& linkName, const BB1Object& ToObject) const ;
	bool						ValidLinkP(const string& linkName, const BB1Object& toObject) const ;
	virtual void		Save(ofstream& KBstream) = 0 ;
	void						SaveClass(ofstream& KBstream) 												{ KBstream << ((BB1Object *) Class())->Name() ; } ;
	void						SaveName(ofstream& KBstream) 													{ KBstream << Name() << "\n" ; } ;
	void						SaveAttributes(ofstream& KBstream) ;
	void						SaveLinks(ofstream& KBstream) ;

 protected:

	Errcode					Instantiate(BB1Class& c) ;

	// ---------------------------------------------------------------------------
	// Is the object allowed to have the attribute? Default; BB1Class, BB1KSAR,
	// and BB1Message override.
	// ---------------------------------------------------------------------------

	virtual bool		ValidAttributeP(const AttValPair& avp) const ;


 private:

	AVPSet					*attributes ;			    /* The object's attribute list */
	int							strategyP ;				    /* TRUE iff instance of BB1Strategy */
	const Cycle			cycleCreated ;		    /* The cycle upon which the object was created */
	BB1KB&					knowledgeBase ;		    /* The object's KB */
	LinkSet					*links ;					    /* The object's link list */
	const std::string		name ;						/* The object's name */
} ;

inline
const TypedVal&   BB1Object::Attributes(const std::string&  attribut)
{
  if (attributes != NULL)
  {
    register unsigned int end =  attributes->size();
    for (register unsigned int i = 0; i < end; i++)
    {
      if ( (*attributes)[i] != NULL)
        {
          std::string temp =  (*attributes)[i]->AttributeName();
          if (temp == attribut)
            return (( (*attributes)[i]->AttributeValue()) );
        }
    }
  }
  TypedVal *typ = new TypedVal();
  return (*typ);
}

typedef BB1Object	*Objptr ;

std::ostream&			operator<<(std::ostream& os, const BB1Object& obj) ;


#endif // _BB1Object_h


