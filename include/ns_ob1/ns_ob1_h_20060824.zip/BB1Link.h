/*
**
** BB1Link.h
**
*/

/*
** A link is an element of a binary relation on pairs of objects.
** A link is multiply labeled.  Its link type is a required symbolic label.
** In addition, links can be labeled with an arbitrary set of attribute-value pairs.
*/


#ifndef _BB1Link_h
# define _BB1Link_h 1

# ifdef __GNUC__
#  pragma interface
# endif

# include "BB1types.h"

//class ostream; // for operator<<(...)
class BB1BB ;
class BB1Class ;
class BB1Object ;



class BB1LinkPair
{

  // Allowed to call consructor
  friend class BB1BB;

  friend class LinkPairSet ;


 public: // Applications don't use this class directly
	BB1LinkPair(const string& ForwardLink, const string& InverseLink, const string& FromClassName, const string& ToClassName);
	BB1LinkPair(const BB1LinkPair& src) ;
	~BB1LinkPair() ;

 private:

  const string&	ForwardLink() const
  { return (m_ForwardLink) ; } ;

  const string&	InverseLink() const
  { return (m_InverseLink) ; } ;

  const string&	FromClassName() const
  { return (m_FromClassName) ; } ;

  const string&	ToClassName() const
  { return (m_ToClassName) ; } ;


private:
  const string	m_ForwardLink;
  const string	m_InverseLink;
  const string	m_FromClassName;
  const string	m_ToClassName;

} ;



typedef BB1LinkPair* LnPrptr ;


class BB1Link
{

  // Allowed to call BB1Link()
  friend class BB1Object;


public: // API
  BB1Link(const string& Name, BB1Object& ToObject);
  BB1Link(const string& Name, BB1Object& ToObject, const Cycle cycle, int ReflexiveP);

  BB1Link(const BB1Link& src) ;

  ~BB1Link() ;
  
  // Return the name of the forward link
  const string&	Name() const { return (m_Name) ; } ;

  const string&	OppositeLinkName(const BB1Class& c) const ;

  // Return the second element of the relation pair
  BB1Object&		ToObject() const
  { return (m_ToObject) ; } ;

  // Are the from class and to class the same?
  int			ReflexiveP() const
  { return (m_ReflexiveP) ; } ;

  // Has the other of two reflexive links been handled yet?
  int			HandledP() const
  { return (m_HandledP) ; } ;

  // Mark the opposite link as having been handled
  void			MarkAsHandled()
  { m_HandledP = TRUE ; }


  // -------------------------------------------------------------------------
  //
  // private members
  //
  // -------------------------------------------------------------------------

 private:
  const string	m_Name ;		// name R of the relation pair R(f, t)
  BB1Object&	m_ToObject ;		// 2nd element t of the relation pair R(f, t)
  const Cycle	m_CycleCreated ;	// The execution cycle on which the link was created
  int		m_ReflexiveP ;		// Are the from class and to class the same?
  int		m_HandledP ;		// In cleanup, has the link been handled yet?

};


typedef BB1Link* Linkptr ;


std::ostream&		operator<<(std::ostream& os, const BB1Link& link) ;


void			ClearSetOfBB1Link(LinkSet *linkset) ;


#endif // _BB1Link_h
