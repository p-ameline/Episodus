/*
** Copyright Nautilus, (10/9/2004)
** fabrice.le_perru@nautilus-info.com
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/
// -----------------------------------------------------------------------------
// The blackboard is a set of objects.
// -----------------------------------------------------------------------------
// In addition, this class represents all state, so that there can be multiple
// BB1s. All utility functions that have no other class should be members of
// this class.
// -----------------------------------------------------------------------------

#ifndef _BB1BB_h
#define _BB1BB_h 1

//#define __DEBUG_ 1		// for debug

#include <stdlib.h>		// for abort();

//#ifdef __GNUC__
#include <values.h>		// for BB1BB::GoNCycles(...)
//#endif

#include "ns_ob1\BB1types.h"
#include "ns_ob1\NSKS.h"

#ifdef _MSC_VER
#include <limits.h>
#define MAXINT INT_MAX
#endif


#include "ns_ob1\OB1Controler.h"
#include "nautilus\nssuper.h"



const int			BS					= 100 ;	// avoid loading stdio.h
extern const	StringList	NULLSTRINGLIST ;
extern const	AVPSet			NULLAVPSET ;
extern const	LinkSet			NULLLINKSET ;


class BB1AppInst ;
class BB1Class ;
class BB1KB ;
class BB1KS ;
class BB1Link ;
class BB1Message ;
class BB1Object ;

// Defini pour la fonction DefineGeneralizeKS
class FunctorValidity;
class FunctorAction;
class FunctorObviation;
class FunctorPrecondition;
class FunctorPublication;

const string		EventPrefix("Event-") ;
const string		KSARPrefix("KSAR-") ;
const string		MessagePrefix("Message-") ;


/**
* \brief The blackboard
*/
/**
* The blackboard conains the KS representation, the shared memory and the controler  <BR>
* Le blackboard contient la repr�sentation des KSs, la m�moire et le controler
*/
class _BBKEXPORT BB1BB : public NSRoot
{

	friend class				BB1Link ;
  friend class        OB1Controler;
	friend class				BB1Object ;
	friend char					**EventNames(BB1BB& bb, int& i) ;
	friend void					MenuCallbackInternals(const char *const label, BB1BB& bb) ;


	friend BB1AppInst		*MakeAppInst(	BB1Class&			c,
																		const std::string&	Name,
                                    AttValPair&   dispatch,
																		BB1KB&				kb,
																		/*const*/ AVPSet	*attSpec,
																		const LinkSet	*linkSpec,
                                    bool createEvent,
                                    bool creatStrat
                                    ) ;



  friend Errcode			ModifyObject(	BB1Object&		object,
																	const AVPSet		*attSpec,
																	const LinkSet		*linkSpec,
																	const AVPSet		*delAttSpec,
																	const LinkSet		*delLinkSpec,
																	const int				eventP,
                                  bool  creat) ;




	// Allowed to call ClassMissing()
	friend class				BB1KB ;



 public: // API.  See "BB1API.c".

	BB1BB(NSContexte									*pCtx,
				const InitFunctionT					initFn 					= NULLINITFN,
				const TerminationConditionT	terminationCond	= NULLTERMCOND,
				int													argc 						= 0,
				char												**argv 					= (char**)0) ;

	BB1BB(const BB1BB& bb) ;
	~BB1BB() ;

	bool													reinit() ;





	// ---------------------------------------------------------------------------
	// Knowledge base operations
	// ---------------------------------------------------------------------------
  BB1Class											*DefineClass(	const string&					name,
                                               AttValPair&          dispatch,
																							const StringList			*directSuperclasses 	= NULL,
																							/*const*/ AVPSet					*allowedAttributes  	= NULL) ;


	BB1KB													*DefineKB(const string& name) ;


  BB1KS													*DefineKS(const string&							name,
                                          BB1KB&										kb,
                                          const PublicationT        tpub                 = NULLPUB,
                                          const ValidityT           tval                  = NULLVALI,
																					const PreconditionT				pCond 								= NULLPC,
																					const ActionT							action 								= NULLAC,
																					/*const*/ AVPSet							*attSpec 							= NULL,
																					const LinkSet							*linkSpec 						= NULL,
																					const ContextGeneratorT		contextGenerator			= NULLCONTEXTGENERATOR);

  //
  // Fonction permet de d�finir des KS dans le Blackboard
  // Definir un KS dans le Blackboard sert � le r�fencer pour utilisation
  // Le r�ferencement g�n�raliser permet de se connecter � des M�thodes de classes et � des fonctions
	 BB1KS													*DefineGeneralizedKS(const std::string& 						name,
                                                     	BB1KB&								 				kb,
                                                      const FunctorPublication*     tpub,
                                                      const FunctorValidity*    		tval,
                                                      const FunctorPrecondition*		pCond,
                                                      const FunctorAction*					action,
                                                      const FunctorObviation*				oBViated,
                                                      AVPSet							*attSpec );



	Errcode												DefineRelation(	const string&				ForwardRelation,
																								const string&				InverseRelation,
																								const string&				FromClass,
																								const string&				ToClass) ;

	// Is the system on the first execution cycle?
  inline
	bool														FirstCycleP() const; 		


  inline
	const KBSet										*AllKBs() const												{ return (kbs) ; }


	const BB1KS										*KS() const ;



	PhaseT												Phase() const													{ return (BB1BBphase) ; }


	// Return the current execution cycle
  inline
	Cycle													ThisCycle() const	;

	// BB1String-to-object mapping
	BB1Class											*ClassNamed(const string& c) const ;
	BB1Event											*EventNamed(const string& eventName) const ;
	BB1KB													*KBNamed(const string& KBName) const ;

  
	BB1Object											*ObjectNamed(const string& LongName) const ;
	BB1Object											*ObjectNamed(const string& KBname, const string& ObjName) const ;

	// Return the error notification level
	ErrNotify											ErrorNotify() const 									{ return (errorNotify) ; }

	// Return a pointer to the error handler function
	ErrHandler										ErrorHandler() const 									{ return (errorHandler) ; }

	// Return the error action option
	ErrAction											ErrorAction() const 									{ return (errorAction) ; }

	// Establish what is to be done when an error condition arises
	void													SetErrorAction(const ErrAction a) 		{ errorAction = a ; }

	// Establish what function is to be called by the exception handler
	void													SetErrorHandler(const ErrHandler h) 	{ errorHandler = h ; }

	// Establish what is to be written to cerr whan an error condition arises
	void													SetErrorNotify(const ErrNotify n) 		{ errorNotify = n ; }


  Errcode												SetTraceCycle(const int traceP) ;


	// The body uses global variables; isolate them in KBLangFns.c
	void													LoadKB(const string& KBPathName) 			{ LoadKBAux(KBPathName) ; }

	void    											dispatchLogMessage(string sMessage, int iAlertLevel, string sBefore = "", string sAfter = "") ;

  void RunInOpportunisticMode(int nb_tour);   // give a number process turn
  BB1Object*                    find(TypedVal& path,std::string clas, bool depp = false); //find a question on blackboard
  BB1Object*                    askQuestion(std::string& sQuestion, bool createToken = true);
  bool                          PutInformation(BB1Object* respp);
  bool                          Execute(); /* Execute bb during one cycle */

	void                          addToSubStratGarbage(OB1SubStrategy* pSubStrat) ;

 protected: // See "BB1BBB.c".


 BB1Object*                    searchInKB(TypedVal& question,  std::string& kbName);

	string												GenerateEventName() ;
	string												GenerateMessageName() ;


	bool													CheckAnswers(BB1Object *obj) ;
	bool													CheckDPIODialog() ;
	bool													evalDPIODialog() ;



	bool													TerminateP(TerminationConditionT tc)
	{
		PhaseT	savePhase = Phase() ; SetPhase(TERMCOND) ;
		bool	retval = (tc ? ((*tc)(*this)) : false) ;

		SetPhase(savePhase) ;
		return (retval) ;
	}


	// ---------------------------------------------------------------------------
	// Agenda management
	// ---------------------------------------------------------------------------



	// Phase checking
	void													SetPhase(PhaseT phase)								{ BB1BBphase = phase ; }

	bool													CreatePhaseCheck(const string &method) const ;

	int														ClearPhaseCheck() const ;
	bool													GoNCyclesPhaseCheck() const ;
	bool													KSPhaseCheck() const ;
	bool													KSARPhaseCheck() const ;

 // bool													TracePhaseCheck() const ;

	bool													CheckAllowedAttributes(const AVPSet *allowedAttributes) ;
	bool													CheckDirectSuperclasses(const StringList *dscNamed, ObjectSet *dscObjects) ;

	Errcode												ClearLinkPairs() ;

//	Errcode												ClearKSs() 														{ kss->clear(); return (SUCCESS) ; }

 // #ifdef __TCONTROLER__
  int BB1BB::CreateToken(EventType type, BB1Object& object,
                                const AVPSet *attSpec = NULL,
                                const LinkSet *linkSpec = NULL,
                                bool createStrat = false);
  /*#else
	BB1Event											*CreateEvent(	EventType			type,
																							BB1Object&		object,
																							const AVPSet	*changedAttributes = NULL,
																							const LinkSet	*changedLinks = NULL) ;
  #endif  */

	void													DoOneContext(ObjectList	*olist, StringList *variables, BB1KS& ks, BB1Event& te) ;
	Errcode												ExecuteInitFunction() ;

	Errcode												GoOneCycle() ;

	// Advance the cycle count to the next cycle
	void													IncrementCycle() 											{ cycle++ ; }

	InitFunctionT									InitFunction() const 									{ return (initFunction) ; }


	BB1AppInst										*NewAppInst(const string&		objName,
                                            AttValPair&   dispatch,
																						BB1KB&					kb,
																						BB1Class&				c,
																						/*const*/ AVPSet		*attSpec,
																						const LinkSet		*linkSpec,
																						const int				eventP,
                                            bool createTok=true,
                                            bool createStrat = false) ;


	const string&									OppositeLinkName(const string& name, const BB1Class& c) const ;
	Errcode												ClearKBs() ;
	bool													ReservedLinkP(const string& linkName) const ;


	const	TerminationConditionT		TerminationCondition() const { return (terminationCondition) ; }


	// Are trace messages enabled for the execution cycle?
	int														TraceCycleP() const
  { return (traceCycle) ; }

	// Are trace messages enabled for event creation?
	int														TraceEventP() const 									{ return (traceEvent) ; }

	// Are trace messages enabled for KSAR creation?
	int														TraceKSARP() const 										{ return (traceKSAR) ; }

	// Are trace messages enabled for message creation?
	int														TraceMessageP() const 								{ return (traceMessage) ; }



	void													LoadKBAux(const string& KBPathName) ;


	// ---------------------------------------------------------------------------
	// Reclaim memory
	// ---------------------------------------------------------------------------

	void													BB1BB_Intern(const string& n, void *p, AVPSet& avpset) ;
	void													*BB1BB_Lookup(const string& name, const AVPSet& avpset) ;


 public:
	vector<NSKS *>								*nskss ;
// -----------------------------------------------------------------------------
// DPIO add
	AKSSet												*Akss ;
// -----------------------------------------------------------------------------


  public:
  long int getNBObject() {return (_nbObject); }
  void      incNBObject(){_nbObject++; }
  inline
  OB1Controler* Controler() ;
  std::vector<OB1NKS* >*  getKSOfType(KSType typ) ;
  std::vector<OB1NKS* >*  getKSOfKB(std::vector<OB1NKS* >* ks,std::string& kbName) ;
  std::vector<OB1NKS* >*  getValidKs(std::vector<OB1NKS* >* temp, ValidityContextType type) ;

 protected:

  OB1Controler*                      _kenoby;  // Controler
  long int                           _nbObject;   //  numbers of objects in the BB

	const InitFunctionT						initFunction ;					// function called on cycle 0
	const TerminationConditionT		terminationCondition ;	// termination predicate
 //	int														socket ;								// socket for external messages
	Cycle													cycle ;									// iteration of recognize-act cycle
	BB1KS													*ks ;										// during triggering, current KS
	BB1Event											*triggerEvent ;					// the current event
	PhaseT												BB1BBphase ;						// internal state; to check validity of API actions
	int														eventCount ;						// event enumerator for unique names

	int														messageCount ;					// message enumerator for unique names
 //	KSSet													*kss ;									// cached set of all KSs

	KBSet													*kbs ;									// cached set of all KBs
	int														traceCycle ;						// trace each cycle?
	int														traceEvent ;						// trace event creation?
	int														traceKSAR ;							// trace KSAR creation?
	int														traceMessage ;					// trace external messages?

	LinkPairSet										*linkPairs ;						// set of all declared link pairs
	BB1KB													*classKB ;							// cached pointer to Class KB

	ErrAction											errorAction ;						// error action
	ErrNotify											errorNotify ;						// error notification level
	ErrHandler										errorHandler ;					// error handler function
	std::ostream&									trout ;									// trace output

	int														cycles2add ;

  NTArray<OB1SubStrategy>       subStratGarbagge ;
} ;


// -----------------------------------------------------------------------------
// The following are non-member utility functions
// -----------------------------------------------------------------------------

inline bool					Not(const int b) { return (b ? false : true) ; }

inline
Cycle								BB1BB::ThisCycle() const											{ return (cycle) ; }

inline
bool									BB1BB::FirstCycleP() const								{ return ((ThisCycle() == 0) ? true : false) ; }

inline
OB1Controler* 			BB1BB::Controler() { return (_kenoby); }

// -----------------------------------------------------------------------------
// Generate an enumerated name
// -----------------------------------------------------------------------------

string							GenerateName(const string& prefix, const int count) ;


// -----------------------------------------------------------------------------
// construct a set
// -----------------------------------------------------------------------------

AVPSet							* _BBKEXPORT Collect(	AttValPair* a1     , AttValPair* a2  = 0,
																					AttValPair* a3  = 0, AttValPair* a4  = 0,
																					AttValPair* a5  = 0, AttValPair* a6  = 0,
																					AttValPair* a7  = 0, AttValPair* a8  = 0,
																					AttValPair* a9  = 0, AttValPair* a10 = 0,
																					AttValPair* a11 = 0, AttValPair* a12 = 0,
																					AttValPair* a13 = 0, AttValPair* a14 = 0,
																					AttValPair* a15 = 0, AttValPair* a16 = 0) ;

LinkSet							*Collect(	BB1Link* a1     , BB1Link* a2  = 0,
															BB1Link* a3  = 0, BB1Link* a4  = 0,
															BB1Link* a5  = 0, BB1Link* a6  = 0,
															BB1Link* a7  = 0, BB1Link* a8  = 0,
															BB1Link* a9  = 0, BB1Link* a10 = 0,
															BB1Link* a11 = 0, BB1Link* a12 = 0,
															BB1Link* a13 = 0, BB1Link* a14 = 0,
															BB1Link* a15 = 0, BB1Link* a16 = 0) ;


// -----------------------------------------------------------------------------
// contstruct a list
// -----------------------------------------------------------------------------

ObjectList					*List(BB1Object* a1     , BB1Object* a2  = 0,
													BB1Object* a3  = 0, BB1Object* a4  = 0,
													BB1Object* a5  = 0, BB1Object* a6  = 0,
													BB1Object* a7  = 0, BB1Object* a8  = 0,
													BB1Object* a9  = 0, BB1Object* a10 = 0,
													BB1Object* a11 = 0, BB1Object* a12 = 0,
													BB1Object* a13 = 0, BB1Object* a14 = 0,
													BB1Object* a15 = 0, BB1Object* a16 = 0) ;

StringList					*List(string a1              , string a2  = NULLSTRING,
													string a3  = NULLSTRING, string a4  = NULLSTRING,
													string a5  = NULLSTRING, string a6  = NULLSTRING,
													string a7  = NULLSTRING, string a8  = NULLSTRING,
													string a9  = NULLSTRING, string a10 = NULLSTRING,
													string a11 = NULLSTRING, string a12 = NULLSTRING,
													string a13 = NULLSTRING, string a14 = NULLSTRING,
													string a15 = NULLSTRING, string a16 = NULLSTRING) ;

bool								Member(const string& s, const StringList *l) ;

Rating							NormalizeRating(const Rating rating) ;

string&							decToString(string& S, const int i) ;


// -----------------------------------------------------------------------------
// These 5 lookup functions are to be library defaults.  The application will
// have to override these defaults if it is to read KS definitions from a file.
// -----------------------------------------------------------------------------
 /*
ActionT							lookupAC(const string& ac) ;
ContextGeneratorT		lookupCG(const string& cg) ;
ObviationConditionT	lookupOC(const string& oc) ;
PreconditionT				lookupPC(const string& pc) ;
TriggerConditionT		lookupTC(const string& tc) ;
     */
#endif // _BB1BB_h
