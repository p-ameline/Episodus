/*
** Copyright Nautilus, (10/9/2004)
** fabrice.le_perru@nautilus-info.com
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/

#ifndef __ATTVALPAIR_H__
#define __ATTVALPAIR_H__ 1

#ifdef __GNUC__
//#  pragma interface
#endif // __GNUC__

#include "nsbb\nspatpat.h"
#include "ns_ob1\TypedVal.h"

//class ostream;   // for operator<<(...)
class TypedVal ;
class BB1Object ;
class BB1Event ;

/**
* \brief Variable of a \relates BB1Object
*/
/**
*  Variable of a \relates BB1Object   <BR>
* Variable d'un objet de type   \relates BB1Object
*/
class _BBKEXPORT AttValPair
{
	// Allowed to call setValue(...)
	friend class BB1Object ;

 public: // API
	//AttValPair() : att(NULLSTRING), val(NULL) {} ;

	AttValPair(const AttValPair& avp) ;

	AttValPair(const string& a, const TypedVal&      				tv) ;
	AttValPair(const string& a, const bool					 				b )                     : att(a), val(b )			      {} ;
	AttValPair(const string& a, const double         				d )                     : att(a), val(d )			      {} ;
	AttValPair(const string& a, const long           				l )                     : att(a), val(l )			      {} ;
	AttValPair(const string& a, const string&        				s )                     : att(a), val(s )			      {} ;
	AttValPair(const string& a, const Voidptr        				p )                     : att(a), val(p ) 		      {} ;
  AttValPair(const string& a, NautilusQuestion 							*quest)               : att(a), val(quest) 	      {} ;
//	AttValPair(const string& a, NSPatPathoArray					*patho)                     : att(a), val(patho) 	      {} ;
	AttValPair(const string& a, NSPatPathoArray					*patho, bool bExt = false)  : att(a), val(patho, bExt) 	{} ;
	AttValPair(const string& a, BB1Object								*objet)                     : att(a), val(objet)	      {} ;

  #ifdef __OB1__UNOPTIM__
  AttValPair(const string& a, const float          				f )                     : att(a), val(f )			      {} ;
	AttValPair(const string& a, const int            				i )                     : att(a), val(i )			      {} ;
  AttValPair(const string& a, PathsList 							*paths)                     : att(a), val(paths) 	      {} ;
  AttValPair(const string& a, const short          				s )                     : att(a), val(s )			      {} ;
  AttValPair(const string& a, const char           				c )                     : att(a), val(c )			      {} ;
  AttValPair(const string& a, const unsigned char  				uc)                     : att(a), val(uc)			      {} ;
	AttValPair(const string& a, const unsigned int   				ui)                     : att(a), val(ui)			      {} ;
	AttValPair(const string& a, const unsigned long  				ul)                     : att(a), val(ul)			      {} ;
	AttValPair(const string& a, const unsigned short 				us)                     : att(a), val(us)			      {} ;
  #endif

	//~AttValPair() ;

	// Attribute name accessor
	const string& AttributeName() const						{ return (att) ; } ;

	// Attribute value accessor
	const TypedVal& AttributeValue(void) const		{ return (val) ; } ;

	AttValPair&	operator=(AttValPair& avp) ;
	// Equal relop
	bool operator==(const AttValPair& avp) const	{ return ((att == avp.att) && (val == avp.val)) ; } ;

	// Not-equal relop
	bool operator!=(const AttValPair& avp) const	{ return ((*this) == avp) ; } ;


 private:
	// Value write accessor; operator= is overloaded for TypedVal
	Errcode setValue(const AttValPair& avp)				{ val = avp.AttributeValue() ; return (SUCCESS) ; } ;

 private:
  std::string       att;          // attribute internal representation
  TypedVal          val;          // value internal representation

};


typedef AttValPair* AVPptr ;

std::ostream& operator <<(std::ostream& os, const AttValPair& avp) ;

void ClearSetOfAVP(AVPSet *avpset) ;

#endif // __ATTVALPAIR_H__
