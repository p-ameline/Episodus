/*
** Copyright Nautilus, (10/9/2004)
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/

#ifndef   OB1GRAPH_H_
#define   OB1GRAPH_H_

#include "ns_ob1\OB1Types.h"
#include "ns_ob1\OB1Node.h"
#include <map>

typedef  std::vector<OB1Node* > PointerBBNodeVector;

/**
* \brief Graph used int the controler
*/
/**
* Graph used in the controler <BR>
* Graph utilis� par le controleur. <BR>
* Le Graph contient tous les noeud par type (noeud KS, Noued resultats , ... )
*/
class OB1Graph
{

  friend class OB1Graph;

  protected:
  std::vector<OB1Node* >*         			_AllNode ;        /**< All node in the KS \brief  All node in the KS */
  std::vector<OB1NKS* >*          			_Ks_nodes ;       /**< All KS Node \brief  All KS Node  */
  std::vector<OB1NValidity* >*    			_Validity_nodes ; /**< All validity Node \brief All validity Node */
  std::vector<OB1NTrigger* >*     			_Trigger_nodes ;  /**< All trigger Node \brief  All trigger Node*/
  std::vector<OB1NAnd* >*         			_And_nodes ;      /**< And node \brief  And node  */
  std::vector<OB1NResult* >*       			_Result_Nodes ;   /**< All result Node \brief All result Node */
  std::vector<OB1NLevel* >*        			_Level_node ;     /**< All Level Node \brief All Level Node */
  std::map<std::string, OB1NOther* >*   _Other_nodes ;    /**< All Other Node \brief All Other Node  */
  unsigned int                    			_graph_size ;


  public:
  /**
  * \brief Constructor
  */
  /**
  *  Constructor
  */
  OB1Graph();

  /**
  * \brief Copy Constructor
  */
  /**
  * Copy Constructor
  */
  OB1Graph(OB1Graph& gr);

  /**
  * \brief Destructor
  */
  /**
  * Copy Destructor
  */
  ~OB1Graph();

  /**
  * \brief Return the number of vertices in the graph
  */
  /**
  * Return the number of vertices in the graph  <BR>
  * Retourne le nombre de noeud dans le graphe
  * @return vertices number
  */
  inline
  const int     numVertices() const;                                 

  /**
  * \brief Add a node in the graph
  */
  /**
  * Add a node in the graph <BR>
  * Ajoute un noueud dans le graph.
	* @param nod Noeud to add
  */
  void          AddVertex(OB1Node* nod);

  /**
  * \brief Tells if the graph is empty 
  */
 	/*
  * Tells if the graph is empty   <BR>
  * Indique si le graph est vide
  * @return true if the graph is empty and false else
  */
  bool          isEmpty() const;

  /**
  * \brief  full the graph with the list of vertex :temp
  */
  /**
  * full the graph with the list of vertex
  * @param temp pointer to full
  */
  void          putAllVertex(PointerBBNodeVector& temp);
  #ifdef __OB1__UNOPTIM__
  void          print(std::ostream& ostr) const;                      /* Print information contains in the Graph */
  #endif
  inline
  OB1Node*    operator[] (unsigned int i) const;
  const int OB1Graph::Degree(OB1Node& vert) const;

  /*
  ** \brief return all vertex of the graph
  */
  inline
  PointerBBNodeVector& getAllVertex();


  /**
  *  \brief export graph in a file
  */
  /**
  * export graph in a file
  * @param Nam of th file
  */
  void save(std::string& FileName);

  /**
  * \brief Return an arbitrary vertex
  */
  /**
  * Return an arbitrary vertex <BR>
  * Renvoie un noeud arbitraire
  */
  OB1Node* aVertex();


  /**
  * \brief find a node
  */
  int find(OB1Node* temp);

  /**
  * \brief Find a ks node
  */
 	/*
  * Find a ks node  <BR>
  * Recherche un KS
  * @param temp KS to find
  * @return KS if it has been find and NULL else
  */
  inline
  OB1NKS*         find_ks_nodes(OB1NKS* temp) ;

  /**
  * \brief Find a other node
  */
 	/*
  * Find a other node  <BR>
  * Recherche un noeud other
  * @param temp other node to find
  * @return other node if it has been find and NULL else
  */
  inline
  OB1NOther*      find_other_nodes(OB1NOther* temp) ;

  /**
  * \brief Find a other node
  */
 	/*
  * Find a level node   <BR>
  * Recherche un noeud level
  * @param temp level node to find
  * @return level node if it has been find and NULL else
  */
  inline
  OB1NLevel*      find_level_nodes(OB1NLevel* temp) ;

  /**
  * \brief Find a trigger node
  */
 	/*
  * Find a trigger node   <BR>
  * Recherche un noeud trigger
  * @param temp trigger node to find
  * @return trigger  node if it has been find and NULL else
  */
  inline
  OB1NTrigger*    find_trigger_nodes(OB1NTrigger* temp) ;

  /**
  * \brief Find a and node
  */
 	/*
  * Find a and node   <BR>
  * Recherche un noeud and
  * @param temp and node to find
  * @return and node if it has been find and NULL else
  */
  inline
  OB1NAnd*        find_and_nodes(OB1NAnd* temp) ;

  /**
  * \brief Find a validity node
  */
 	/*
  * Find a validity node   <BR>
  * Recherche un noeud validity
  * @param temp validity node to find
  * @return validity node if it has been find and NULL else
  */
  inline
  OB1NValidity*   find_validity_nodes(OB1NValidity* temp) ;

  /**
  * \brief Find a result node
  */
 	/*
  * Find a result node   <BR>
  * Recherche un noeud result
  * @param temp result node to find
  * @return result node if it has been find and NULL else
  */
  inline
  OB1NResult*     find_result_nodes(OB1NResult* temp) ;

  /**
  * \brief Find a other node
  */
 	/*
  * Find a other node   <BR>
  * Recherche un noeud other
  * @param temp other node to find
  * @return other node if it has been find and NULL else
  */
  inline
  OB1NOther*      find_other_nodes(TypedVal& val) ;

  /**
  * \brief get all KSs
  */
  /**
  * get all KSs <BR>
  * Renvoie tous les KS
  * @return List of all KSs
  */
  inline
  std::vector<OB1NKS* >*  getKSs();

  /**
  * \brief get a pointer on the map of OB1NOther nodes
  */
  /**
  * get a pointer on the map of OB1NOther nodes <BR>
  * Renvoie un pointeur sur la map de otherNodes
  * @return a pointer on the map of otherNodes
  */
  inline
  std::map<std::string, OB1NOther* >* getOtherNodes();

  /**
  * \brief get all KSs of a certain type
  */
  /**
  * get all KSs of a certain type <BR>
  * Renvoie tous les KS d'un certains type
  * @param typ Type to find
  * @return List of all KSs
  */
  inline
  std::vector<OB1NKS* >*  getKSOfType(KSType typ) ;

  /**
  * \brief get a KSs by its name
  */
  /**
  * get the KS of a given name <BR>
  * Renvoie le KS par son nom
  * @param typ Type to find
  * @return List of all KSs
  */
  inline
  OB1NKS* getKSByName(string sName) ;
};

inline
OB1Node*  OB1Graph::operator[] (unsigned int i) const
{
  return  ((* _AllNode)[i]);
}

inline
void  OB1Graph::putAllVertex(std::vector<OB1Node* >& temp)
{
  for (unsigned int i = 0; i < temp.size(); i++)
    this->_AllNode->push_back(temp[i]);

}


/**
* \brief Return vertices numbers
*/
/**
* Return vertices numbers <BR>
* Renvoie le nombre de sommet total pr�sent dans le graph
* @return vertices number
*/
inline
const int     OB1Graph::numVertices() const
{
    return    (_AllNode->size());
}

// Recherche un KS dans la lsite des KS
inline
OB1NKS*         OB1Graph::find_ks_nodes(OB1NKS* temp)
{
  register unsigned int end = _Ks_nodes->size() ;
  for (register unsigned int i = 0;i < end ; i++)
    if (true ==  testKS((*_Ks_nodes)[i], temp))
      return ( (*_Ks_nodes)[i]);
  return NULL;
}

inline
OB1NOther*
OB1Graph::find_other_nodes(OB1NOther* temp)
{
	return (find_other_nodes(temp->getName())) ;
}

//
// Remember: there is only one node with a given path
//
inline
OB1NOther*
OB1Graph::find_other_nodes(TypedVal& val)
{
	if (!_Other_nodes || (_Other_nodes->empty()))
		return NULL ;

	return (((*_Other_nodes)[ComputeSortingId(val)])) ;
}

inline
OB1NLevel*
OB1Graph::find_level_nodes(OB1NLevel* temp)
{
	register unsigned int end = _Level_node->size() ;
  for (register unsigned int i = 0; i < end ; i++)
  	if (true == testLevel((*_Level_node)[i], temp))
    	return ((*_Level_node)[i]) ;
  return NULL ;
}

inline
OB1NTrigger*    OB1Graph::find_trigger_nodes(OB1NTrigger* temp)
{
  register unsigned int end = _Trigger_nodes->size() ;
  for (register unsigned int i = 0;i < end ; i++)
    if (true == testTrigger((*_Trigger_nodes)[i], temp))
      return ((*_Trigger_nodes)[i]) ;
  return NULL;
}

inline
OB1NAnd*        OB1Graph::find_and_nodes(OB1NAnd* temp)
{
  register unsigned int end = _And_nodes->size();
  for (register unsigned int i = 0;i < end ; i++)
    if (true ==  testAnd( (*_And_nodes)[i], temp ))
      return ((*_And_nodes)[i]);
  return NULL;
}

inline
OB1NValidity*   OB1Graph::find_validity_nodes(OB1NValidity* temp)
{
  register unsigned int end = _Validity_nodes->size();
  for (register unsigned int i = 0;i < end ; i++)
           if (true == testValidity((*_Validity_nodes)[i], temp))
      return ( (*_Validity_nodes)[i]);
  return NULL;
}

inline
OB1NResult*     OB1Graph::find_result_nodes(OB1NResult* temp)
{
  register unsigned int end = _Result_Nodes->size();
  for (register unsigned int i = 0;i < end ; i++)
    if (true == testResult((*_Result_Nodes)[i],temp ))
      return ( (*_Result_Nodes)[i]);
  return NULL;
}

/**
* \brief Return the list of KS
*/
/**
/**
* Return the list of all KS <BR>
* Renvoie la liste de tous les KSs
* @return KS' list
*/
inline
std::vector<OB1NKS* >*  OB1Graph::getKSs()
{
	return (_Ks_nodes) ;
}

inline
std::map<std::string, OB1NOther* >* OB1Graph::getOtherNodes()
{
	return (_Other_nodes) ;
}

inline
std::vector<OB1NKS* >*
OB1Graph::getKSOfType(KSType typ)
{
	std::vector<OB1NKS* >* res = new  std::vector<OB1NKS* >() ;

	register unsigned int end = _Ks_nodes->size() ;
	for (register unsigned int i = 0; i < end; i++)
		if ((*_Ks_nodes)[i]->KsType() == typ)
			res->push_back((*_Ks_nodes)[i]) ;

	return (res) ;
}

inline
OB1NKS*
OB1Graph::getKSByName(string sName)
{
	register unsigned int end = _Ks_nodes->size() ;
	for (register unsigned int i = 0; i < end; i++)
		if ((*_Ks_nodes)[i]->getKSName() == sName)
		 	return (*_Ks_nodes)[i] ;

	return NULL ;
}

/**
* \brief Return all node
*/
/**
* Return all node <BR>
* Renvoie une liste contenant tous les noeuds
* @return list of all node
*/
inline
PointerBBNodeVector& OB1Graph::getAllVertex()
{
	return (*_AllNode);
}

#endif