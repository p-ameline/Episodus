// -----------------------------------------------------------------------------
// InterfaceForKs.h
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// $Revision: 1.11 $
// $Author: PA $
// $Date: 2005/11/12 17:17:40 $
// -----------------------------------------------------------------------------
// PA  - november 2005
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Copyright Odyssee, 2004
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � g�rer et traiter les
// informations de sant� d'une personne.
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to manage and process
// a person's health data.
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------

#ifndef __INTERFACEFORKS_H__
# define __INTERFACEFORKS_H__

# ifndef _DANSBBKDLL
#  define _BBKEXPORT __import
# else
#  define _BBKEXPORT __export
# endif

//! \brief Object made for KS command from MMI

// -----------------------------------------------------------------------------
// OB1 InterfaceForKs <BR>
// Interface de contr�le d'un KS depuis l'interface
// -----------------------------------------------------------------------------
class _BBKEXPORT BB1BBInterfaceForKs
{
	protected:

  	string sArchetypeID ;  //!< Archetype ID \brief Archetype ID
  	string sKsName ;       //!< Nom du KS \brief Nom du KS
    bool   bInitFromBbk ;  //!< Utiliser le blackboard pour initialiser le dialogue \brief Utiliser le blackboard pour initialiser le dialogue

	public:

		//! \brief  constructor
  	BB1BBInterfaceForKs(string sKS = "", string sArchID = "", bool bInit = false) ;

  	//! \brief  Destructor
  	~BB1BBInterfaceForKs() {} ;

  	BB1BBInterfaceForKs(BB1BBInterfaceForKs& rv) ;

		BB1BBInterfaceForKs& operator=(BB1BBInterfaceForKs src) ;
		int                  operator==(BB1BBInterfaceForKs& o) ;

    string getArchetypeID() { return sArchetypeID ; }
    string getKsName()      { return sKsName ; }
    bool   getInitFromBbk() { return bInitFromBbk ; }

    void   setArchetypeID(string sArID) { sArchetypeID = sArID ; }
    void   setKsName(string sKS)        { sKsName      = sKS ; }
    void   setInitFromBbk(bool bInit)   { bInitFromBbk = bInit ; }
} ;

inline BB1BBInterfaceForKs::BB1BBInterfaceForKs(string sKS, string sArchID, bool bInit)
{
	sArchetypeID = sArchID ;
	sKsName      = sKS ;
  bInitFromBbk = bInit ;
}

inline BB1BBInterfaceForKs::BB1BBInterfaceForKs(BB1BBInterfaceForKs& rv)
{
	sArchetypeID = rv.sArchetypeID ;
	sKsName      = rv.sKsName ;
  bInitFromBbk = rv.bInitFromBbk ;
}

inline BB1BBInterfaceForKs&
BB1BBInterfaceForKs::operator=(BB1BBInterfaceForKs src)
{
	sArchetypeID = src.sArchetypeID ;
	sKsName      = src.sKsName ;
  bInitFromBbk = src.bInitFromBbk ;

  return *this ;
}

inline int
BB1BBInterfaceForKs::operator==(BB1BBInterfaceForKs& o)
{
	if ((sArchetypeID == o.sArchetypeID) &&
      (sKsName      == o.sKsName))
		return 1 ;

	return 0 ;
}

#endif // !__INTERFACEFORKS_H__

