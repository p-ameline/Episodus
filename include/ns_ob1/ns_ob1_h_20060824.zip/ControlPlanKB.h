#ifndef _ControlPlanKB_h
# define _ControlPlanKB_h 1

class BB1BB ;

#ifndef __TCONTROLER__
void	loadControlPlanKB(BB1BB& bb) ;
#endif

#endif // _ControlPlanKB_h
