/*
** Copyright Nautilus, (10/9/2004)
** fabrice.le_perru@nautilus-info.com
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/
// -----------------------------------------------------------------------------
// A TypedVal is a manifest type: a combination of a discriminant, identifying
// the type, and a union, carrying the value. Their purpose is to represent the
// values of BB1 object attributes. Values of user-defined types must
// necessarily be carried as void pointers.
// There are no assignment operators.
// -----------------------------------------------------------------------------

#ifndef __TYPEDVAL_H__
#define __TYPEDVAL_H__ 1

#ifdef __GNUC__
#pragma interface
#endif // __GNUC__

#include "ns_ob1\BB1types.h"
#include "nsbb\nspatpat.h"
#include "ns_ob1\NautilusType.h"

/**
*  for friend declaration
*/
class BB1Object ;     


// -----------------------------------------------------------------------------
// These are the types that an attribute can take. This enumeration type is used
// as a discriminant for the union, and as a property of the attribute.
// -----------------------------------------------------------------------------

/**
* \brief Type-Value pair
*/
/**
* Representation of a variable  and it's value  <BR>
* Repr�senation d'une variable (Paire Type-Valeur)
*/
class _BBKEXPORT TypedVal
{
  // Allowed to call Discriminant(void)
  friend class BB1Object ;
  friend std::string ComputeSortingId(TypedVal& temp) ;
  friend std::string GetStringFromSortingId(std::string sortingID) ;

 public:

  // ---------------------------------------------------------------------------
  // These are the constructors. There is one for each built-in data type and
  // for a few others. As an escape mechanism, a (void *) can be passed.
  // ---------------------------------------------------------------------------

	/**
  * default constructor
  */
	TypedVal()
		: discr(UNBOUND)
	{
		// assign the default value
		boolVal			= false ;
		doubleVal		= 0 ;
		longVal			= 0 ;
		StringVal		= NULLSTRING ;
		ptrVal			= NULLPTR ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter = NULLPATPATHOITER;
		objectVal		= NULLOBJECT ;
    squest      = NULLLNAUTQUEST;
    squest = NULLLNAUTQUEST;

    #ifdef __OB1__UNOPTIM__
    intVal			= 0 ;
    floatVal		= 0 ;
    charVal			= 0 ;
    shortVal		= 0 ;
    uCharVal		= 0 ;
		uIntVal			= 0 ;
		uLongVal		= 0 ;
		uShortVal		= 0 ;
    pathsVal		= NULLPATHS ;
    #endif
	} ;


	/**
  * copy constructor
  * @param v typedVal to clone
  */
	TypedVal(const TypedVal& v)
	{
		// assign the discriminant
		discr = v.discr ;

		// assign the default value
		boolVal			= false ;
		doubleVal		= 0 ;
		longVal			= 0 ;
		StringVal		= NULLSTRING ;
		ptrVal			= NULLPTR ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER;
		objectVal		= NULLOBJECT ;
    squest      = NULLLNAUTQUEST;
    #ifdef __OB1__UNOPTIM__
    floatVal		= 0 ;
		intVal			= 0 ;
    charVal			= 0 ;
    uCharVal		= 0 ;
		uIntVal			= 0 ;
		uLongVal		= 0 ;
		uShortVal		= 0 ;
    shortVal		= 0 ;
    pathsVal		= NULLPATHS ;
    shortVal		= 0 ;
    #endif

		// assign the real value
		switch (discr)
		{
			case BB1BOOL			: boolVal			= v.boolVal ;															break ;
			case BB1DOUBLE		:	doubleVal 	= v.doubleVal ;														break ;
			case BB1LONG			:	longVal   	= v.longVal ;															break ;
			case BB1STRING		:	StringVal 	= v.StringVal ;	 break ;
			case BB1POINTER		:	ptrVal    	= v.ptrVal ;															break ;
      case BB1PATPATHOITER : papeCathoIter = new PatPathoIter(*(v.papeCathoIter)); break;
			case BB1PATPATHO	:
      		if (v.IsExtPatho() == true)
        {
        	_extPatho = true;
        	patpathoVal = v.patpathoVal;
        }
        else
        {
          _extPatho = false;
      		patpathoVal	= new NSPatPathoArray(*(v.patpathoVal)) ;
      	}
      break ;
			//case BB1OBJ				: *objectVal	= *(v.objectVal) ; break ;
      case OB1QEST      : squest = new NautilusQuestion(v.squest); break;

      #ifdef __OB1__UNOPTIM__
      case BB1FLOAT			:	floatVal  	= v.floatVal ;														break ;
			case BB1INT				:	intVal    	= v.intVal ;															break ;
      case BB1PATHS			:	pathsVal		= new PathsList(*(v.pathsVal)) ; 					break ;
      case BB1CHAR			:	charVal   	= v.charVal ; break;
      case BB1SHORT			:	shortVal  	= v.shortVal ;  break;
      case BB1ULONG			:	uLongVal  	= v.uLongVal ;	 break ;
      case BB1USHORT		:	uShortVal 	= v.uShortVal ; 	break ;
      case BB1UCHAR			:	uCharVal  	= v.uCharVal ; break;
      case BB1UINT			:	uIntVal   	= v.uIntVal ;	break ;
      #endif
		}
	} ;


	/**
  * Boolean Constructeur
  */
	TypedVal(const bool boolArg)
		: discr(BB1BOOL),
			boolVal(boolArg)
	{
		// assign the default value
		StringVal				= NULLSTRING ;
		patpathoVal			= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER;
		objectVal				= NULLOBJECT ;
    squest 					= NULL;

    #ifdef __OB1__UNOPTIM__
    pathsVal		= NULLPATHS ;
    #endif

	} ;

  #ifdef __OB1__UNOPTIM__
	TypedVal(const char charArg)
		: discr(BB1CHAR),
			charVal(charArg)
	{
		// assign the default value
		StringVal		= NULLSTRING ;
		pathsVal		= NULLPATHS ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;
	} ;
  #endif


	TypedVal(const double doubleArg)
		: discr(BB1DOUBLE),
			doubleVal(doubleArg)
	{
		// assign the default value
		StringVal		= NULLSTRING ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;

    #ifdef __OB1__UNOPTIM__
    pathsVal		= NULLPATHS ;
    #endif

	} ;



  #ifdef __OB1__UNOPTIM__
	TypedVal(const float floatArg)
		: discr(BB1FLOAT),
			floatVal(floatArg)
	{
		// assign the default value
		StringVal		= NULLSTRING ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;
    pathsVal		= NULLPATHS ;
	} ;
  #endif

   #ifdef __OB1__UNOPTIM__
	TypedVal(const int intArg)
		: discr(BB1INT),
			intVal(intArg)
	{
		// assign the default value
		StringVal		= NULLSTRING ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;
    #ifndef  __OB1__UNOPTIM__
    	pathsVal		= NULLPATHS ;
    #endif
	} ;
   #endif


  /**
  * Long constructror
  * @param  longArg for initialisation
  */
	TypedVal(const long longArg)
		: discr(BB1LONG),
			longVal(longArg)
	{
		// assign the default value
		StringVal		= NULLSTRING ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER ;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;

    #ifdef __OB1__UNOPTIM__
    pathsVal		= NULLPATHS ;
    #endif
	} ;


  #ifdef __OB1__UNOPTIM__
	TypedVal(const short shortArg)
		: discr(BB1SHORT),
			shortVal(shortArg)
	{
		// assign the default value
		StringVal		= NULLSTRING ;
		pathsVal		= NULLPATHS ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER ;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;
    #ifdef __OB1__UNOPTIM__
    pathsVal		= NULLPATHS ;
    #endif
	} ;
  #endif


	TypedVal(const string& StringArg)
		: discr(BB1STRING),
			StringVal(StringArg)
	{
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER ;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;
    #ifdef __OB1__UNOPTIM__
    pathsVal		= NULLPATHS ;
    #endif
	} ;

  #ifdef __OB1__UNOPTIM__
	TypedVal(const unsigned char uCharArg)
		: discr(BB1UCHAR),
			uCharVal(uCharArg)
	{
		// assign the default value
		StringVal		= NULLSTRING ;
		pathsVal		= NULLPATHS ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER ;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;
	} ;
  #endif

  #ifdef __OB1__UNOPTIM__
	TypedVal(const unsigned int uIntArg)
		: discr(BB1UINT),
			uIntVal(uIntArg)
	{
		// assign the default value
		StringVal		= NULLSTRING ;
		pathsVal		= NULLPATHS ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER ;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;
	} ;
  #endif

  #ifdef __OB1__UNOPTIM__
	TypedVal(const unsigned long uLongArg)
		: discr(BB1ULONG),
			uLongVal(uLongArg)
	{
		// assign the default value
		StringVal		= NULLSTRING ;
		pathsVal		= NULLPATHS ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER ;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;
	} ;
  #endif

  #ifdef __OB1__UNOPTIM__
	TypedVal(const unsigned short uShortArg)
		: discr(BB1USHORT),
			uShortVal(uShortArg)
	{
		// assign the default value
		StringVal		= NULLSTRING ;
		pathsVal		= NULLPATHS ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER ;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;
	} ;
  #endif


 	TypedVal(const Voidptr ptrArg)
		:	discr(BB1POINTER),
			ptrVal(ptrArg)
	{
		// assign the default value
		StringVal		= NULLSTRING ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER ;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;
    #ifdef __OB1__UNOPTIM__
    pathsVal		= NULLPATHS ;
    #endif
	} ;

  TypedVal(const NautilusQuestion* arg)
		:	discr(OB1QEST)
	{
		// assign the default value
		StringVal		= NULLSTRING ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER ;
		objectVal		= NULLOBJECT ;
    if ((arg == NULL) || (arg == NULLLNAUTQUEST))
      squest = NULLLNAUTQUEST;
    else
    	squest      = new NautilusQuestion(arg);
    #ifdef __OB1__UNOPTIM__
    pathsVal		= NULLPATHS ;
    #endif
	} ;


  #ifdef __OB1__UNOPTIM__
	TypedVal(PathsList *paths)
		: discr(BB1PATHS)
	{
		if (paths)
			pathsVal		= new PathsList(*paths) ;
		else
			pathsVal		= new PathsList() ;

		// assign the default value
		StringVal		= NULLSTRING ;
		patpathoVal	= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER ;
		objectVal		= NULLOBJECT ;
    squest = NULLLNAUTQUEST;
	} ;
  #endif


	TypedVal(NSPatPathoArray *patPatho, bool bExt = false)
	{
  	discr = BB1PATPATHO ;

    if (bExt)
    {
      _extPatho = true;
		  if (NULLPATHO != patPatho)
			  patpathoVal	= patPatho ;
		  else
			  // patpathoVal	= new NSPatPathoArray(NULL) ;
        patpathoVal	= NULL ;
    }
    else
    {
      _extPatho = false;
	  	if (NULLPATHO != patPatho)
		  	patpathoVal	= new NSPatPathoArray(*patPatho) ;
  		else
	  		patpathoVal	= new NSPatPathoArray(NULL) ;
    }

		// assign the default value
		StringVal				= NULLSTRING ;
		objectVal				= NULLOBJECT ;
    papeCathoIter   = NULLPATPATHOITER;
    squest 					= NULLLNAUTQUEST;
    #ifdef __OB1__UNOPTIM__
    pathsVal				= NULLPATHS ;
    #endif
	} ;

  TypedVal(PatPathoIter *jeanPaul)
  : discr(BB1PATPATHOITER)
	{
		StringVal				= NULLSTRING ;
    patpathoVal	= NULLPATHO ;
		objectVal		= NULLOBJECT ;
    papeCathoIter   = jeanPaul;
    squest 					= NULLLNAUTQUEST;
    #ifdef __OB1__UNOPTIM__
    pathsVal				= NULLPATHS ;
    #endif
	} ;


	TypedVal(BB1Object *obj)
		: discr(BB1OBJ),
			objectVal(obj)
	{
		// assign the default value
		StringVal				= NULLSTRING ;
		patpathoVal			= NULLPATHO ;
    papeCathoIter   = NULLPATPATHOITER;
    squest 					= NULLLNAUTQUEST;
    #ifdef __OB1__UNOPTIM__
    pathsVal				= NULLPATHS ;
    #endif
	} ;


	~TypedVal()
	{
    #ifdef __OB1__UNOPTIM__
		if ((discr == BB1PATHS)&&(pathsVal != NULL))
    {
			delete pathsVal ;
      pathsVal = NULL;
    }
    #endif

    if ((discr == OB1QEST)  && (NULL != squest))
    {
      delete (squest);
      squest = NULL;
    }

		if ((discr == BB1PATPATHO) &&  (NULLPATHO != patpathoVal) &&  (_extPatho == false))
			delete patpathoVal ;
    patpathoVal = NULLPATHO ;

	} ;

	TypedVal&					operator=(const TypedVal& v) ;
  
  inline
	bool							operator==(const TypedVal& v) const ;

	// ---------------------------------------------------------------------------
	// These are the read accessors: they extract the primitive value from the
	// instance. There is one for each built-in data type and for a few others. As
	// an escape mechanism, a void * can be returned. If there is a type mismatch,
	// a null value is returned.
	// ---------------------------------------------------------------------------

  /**
  * Return the bool value is the variable is bolean <BR>
  * Renvoie la valeur bool de la classe si cette variable est de type booleen
  * @return
  * <ul>
  *     <li> the boolean value if the variable is boolean </li>
  *     <li> false if the vairable is not bool's type</li>
  *</ul>
  */
	bool							getBool() const   { return (discr == BB1BOOL)			? boolVal 		: bool(false) ;				}
  NautilusQuestion*  getNautQuest () const {return (discr == OB1QEST)  ? squest      : NULL; 							}
	double						getDouble() const { return (discr == BB1DOUBLE)		? doubleVal 	: double(0) ;					}
	long							getLong() const		{ return (discr == BB1LONG)			? longVal   	: long(0) ;						}
  inline
	const string			getString() const { return (discr == BB1STRING)		? StringVal		: NULLSTRING ;				}


	const Voidptr			getPtr() const		{ return (discr == BB1POINTER)	? ptrVal			: 0 ;									}
  #ifdef __OB1__UNOPTIM__
  float							getFloat() const	{ return (discr == BB1FLOAT)		? floatVal  	: float(0) ;					}
	int								getInt() const		{ return (discr == BB1INT)			? intVal 			: int(0) ;						}
	char							getChar() const		{ return (discr == BB1CHAR)			? charVal 		: char(0) ;						}
  short							getShort() const	{ return (discr == BB1SHORT)		? shortVal  	: short(0) ;					}
  unsigned char			getUChar() const	{ return (discr == BB1UCHAR)		? uCharVal 		: (unsigned char)0 ;	}
	unsigned int			getUInt() const		{ return (discr == BB1UINT)			? uIntVal 		: (unsigned int)0 ;		}
	unsigned long			getULong() const	{ return (discr == BB1ULONG)		? uLongVal 		: (unsigned long)0 ; 	}
	unsigned short		getUShort() const	{ return (discr == BB1USHORT)		? uShortVal		: (unsigned short)0 ;	}
  PathsList					*getPaths()				{ return (discr == BB1PATHS)		? pathsVal		:	0	;									}
  #endif

	NSPatPathoArray		*getPatPatho()		{ return (discr == BB1PATPATHO)	?	patpathoVal	:	NULL	;							}
  bool 							IsExtPatho() const     { return  _extPatho; }
  PatPathoIter      *getPatPathoIter() { return (discr == BB1PATPATHOITER) ?  papeCathoIter : NULL ; 			}
	BB1Object					*getObj()					{ return (discr == BB1OBJ)			? objectVal		:	NULLOBJECT	;				}
  std::string       TypedVal::toString() const;

	char							*typeName() const ;
	void							putTypedVal(std::ostream& os) const ;



 private:
  inline
	AttType						Discriminant() const { return (discr) ; }

 private:
	AttType						discr ;			// The type of the value

  /**
  * Different primitive type that the variable can be
  */
  union						// The primitive value itself
	{
		bool						boolVal ;       /**< boolean value */
		double					doubleVal ;     /**< double value */
		long						longVal ;       /**< long value */
		Voidptr					ptrVal ;        /**< pointer value */
    #ifdef __OB1__UNOPTIM__
    char						charVal ;
    unsigned char		uCharVal ;
		unsigned int		uIntVal ;
		unsigned long		uLongVal ;
		unsigned short	uShortVal ;
    short						shortVal ;
    float						floatVal ;
		int							intVal ;
    #endif
  } ;

  // types with constructors can't appear in unions.
	string						  StringVal ;
	NSPatPathoArray		  *patpathoVal ;
  bool 								 _extPatho;  // Vraie si la patho est exterieur au blackboard
  PatPathoIter        *papeCathoIter;
  NautilusQuestion*   squest;
	BB1Object					  *objectVal ;
  #ifdef __OB1__UNOPTIM__
  PathsList					*pathsVal ;
  #endif
} ;

inline
bool TypedVal::operator==(const TypedVal& v) const
{
  if (this == &v)
		return (true) ;

	if (discr != v.discr)
		return (false) ;
	else
  {
    switch (discr)
    {
			case BB1DOUBLE		:	return (doubleVal 	== v.doubleVal) ;
			case BB1LONG			:	return (longVal   	== v.longVal) ;
			case BB1STRING		:	return (StringVal 	== v.StringVal) ;
			case BB1POINTER		:	return (ptrVal    	== v.ptrVal) ;
			case BB1PATPATHO	: return (patpathoVal	== v.patpathoVal) ;
      case BB1PATPATHOITER : return (papeCathoIter == v.papeCathoIter);
			case BB1OBJ				: return (objectVal		== v.objectVal) ;
      case OB1QEST      : return (*squest      == *(v.squest) );
      #ifdef __OB1__UNOPTIM__
      case BB1SHORT			:	return (shortVal  	== v.shortVal) ;
      case BB1INT				:	return (intVal    	== v.intVal) ;
      case BB1FLOAT			:	return (floatVal  	== v.floatVal) ;
      case BB1CHAR			:	return (charVal   	== v.charVal) ;
      case BB1PATHS			:	return (pathsVal 		== v.pathsVal) ;
      case BB1UCHAR			:	return (uCharVal  	== v.uCharVal) ;
			case BB1UINT			:	return (uIntVal   	== v.uIntVal) ;
			case BB1ULONG			:	return (uLongVal  	== v.uLongVal) ;
			case BB1USHORT		:	return (uShortVal 	== v.uShortVal) ;
      #endif
			default           :	return (false) ;
    }
  }
}


std::string _BBKEXPORT ComputeSortingId(TypedVal& temp) ;
std::string _BBKEXPORT GetStringFromSortingId(std::string sortingID) ;

std::ostream&		operator<<(std::ostream& os, const TypedVal& tv) ;


#endif // __TYPEDVAL_H__
