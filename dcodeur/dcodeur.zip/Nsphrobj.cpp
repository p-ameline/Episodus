#include "partage\nsdivfct.h"
#include "dcodeur\nsphrase.h"
#include "dcodeur\nsphrobj.h"
#include "nautilus\nssuper.h"
#include "dcodeur\nsgenlan.h"

// -------------------------------------------------------------------------
// ------------------- METHODES DE NSPhraseLesion --------------------------
// -------------------------------------------------------------------------
NSPhraseObjet::NSPhraseObjet(NSContexte* pCtx, int iDecoType, string sLangue)
              :decodageBase(pCtx, sLangue)
{
  iDcType = iDecoType ;
}

NSPhraseObjet::NSPhraseObjet(decodageBase* pBase, int iDecoType, string sLang)
              :decodageBase(pBase)
{
  iDcType = iDecoType ;
  sLangue = sLang ;
}

NSPhraseObjet::NSPhraseObjet(NSPhraseObjet& rv)
              :decodageBase(rv.pContexte, rv.sLangue)
{
  Objet 	= rv.Objet ;
  iDcType = rv.iDcType ;
}

void
NSPhraseObjet::ammorce()
{
  Objet = *(*(getitDcode())) ;
}

void
NSPhraseObjet::decode(int /* colonne */)
{
  return ;
}

NSPhraseObjet&
NSPhraseObjet::operator=(NSPhraseObjet src)
{
  if (&src == this)
    return *this ;

	Objet 	= src.Objet ;
  iDcType = src.iDcType ;

  return *this ;
}

// -------------------------------------------------------------------------
// ------------------- METHODES DE NSPhraseLesion --------------------------
// -------------------------------------------------------------------------
NSPhraseLesion::NSPhraseLesion(NSContexte* pCtx, int iDecoType, string sLangue)
               :NSPhraseObjet(pCtx, iDecoType, sLangue)
{
}

NSPhraseLesion::NSPhraseLesion(decodageBase* pBase, int iDecoType, string sLangue)
               :NSPhraseObjet(pBase, iDecoType, sLangue)
{
}

void
NSPhraseLesion::decode(int colonne)
{                             // 0LOCA1|0FORM1|VEPAI1|0ASPV1
  NSPhraseTemporel* pDate = 0 ;

  int refCol = getCol() ;
  int refCol2 ;

  while ((getCol() > colonne) && iBon())
	{
    // Aspect
    if 	    (*getSt() == "0ASPV")
    {
      Avance() ;
      refCol2 = getCol() ;

      while ((getCol() > refCol) && iBon())
      {
        if 	  ((*getSt())[0] == 'A')
        {
          NSPhraseOrgane* pLoca = new NSPhraseOrgane(this) ;
          pLoca->ammorce() ;
          Avance() ;
          pLoca->decode(refCol2) ;
          Aspect.push_back(pLoca) ;
        }
        else
          Recupere() ;
      }
    }
    // Dimension
    // Localisation
    else if (*getSt() == "0LOCA")
    {
      Avance() ;
      refCol2 = getCol() ;

      while ((getCol() > refCol) && iBon())
      {
        if 	  ((*getSt())[0] == 'A')
        {
          NSPhraseOrgane* pLoca = new NSPhraseOrgane(this) ;
          pLoca->ammorce() ;
          Avance() ;
          pLoca->decode(refCol2) ;
          Localisations.push_back(pLoca) ;
        }
        else
          Recupere() ;
      }
    }
    else if ((*getSt())[0] == 'A')
    {
      NSPhraseOrgane* pLoca = new NSPhraseOrgane(this) ;
      pLoca->ammorce() ;
      Avance() ;
      pLoca->decode(refCol) ;
      Localisations.push_back(pLoca) ;
    }
    // Date d'ouverture
    else if (*getSt() == "KOUVR")
    {
      Avance() ;

      if (NULL == pDate)
        pDate = new NSPhraseTemporel(this) ;

      //
      // On ne sait pas s'il y aura un max, donc on param�tre
      // pour une phrase du type "� partir du"
      //
      pDate->iTypeTps    = TpsDate ;
      pDate->iFormeTps   = TpsInterval ;
      pDate->iRepererTps = TpsFutur ;

      pDate->decode(refCol, true) ;
    }
    // Date de fermeture
    else if (*getSt() == "KFERM")
    {
      Avance() ;

      if (NULL == pDate)
        pDate = new NSPhraseTemporel(this) ;

      //
      // Date pass�e d'un �v�nement ponctuel
      //
      pDate->iTypeTps    = TpsDate ;
      pDate->iRepererTps = TpsFutur ;

      if (string("") != pDate->ValeurMin.getLexique())
      {
        // Date de d�but == Date de fin / Starting date == Ending date
        if ((pDate->ValeurMin.getComplement() == pDate->ValeurMax.getComplement()) &&
                    (pDate->ValeurMin.getUnit() == pDate->ValeurMax.getUnit()))
          pDate->iFormeTps = TpsInstant ;
        else
          pDate->iFormeTps = TpsInterval ;

        pDate->bMinNow = false ;
      }
      else
      {
        pDate->iFormeTps = TpsInterval ;
        pDate->bMinNow   = true ;
      }

      pDate->decode(refCol, false) ;
    }
		else
      Recupere() ;
  }

  if (NULL != pDate)
    Temporalite.push_back(pDate) ;

	return ;
}

void
NSPhraseLesion::metPhrase()
{
  NSPathologData Data ;
  bool     trouve ;
  NSSuper* pSuper = pContexte->getSuperviseur() ;

  pPhraseur->initialise() ;
  *sDcodeur() = "" ;
  //
  // La premi�re phase consiste � annoncer l'existence de la l�sion,
  // sous forme d'un COD (ex, "Il existe un polype")
  //
  NSPhraseMot Lesion(Objet.pDonnees, pContexte) ;
  Lesion.setArticle(NSPhraseMot::articleIndefini) ;
  //
  // Dans l'ordre, on d�crit l'aspect, la dimension puis la localisation
  // (ex, "Il existe un polype sessile, de 3 mm, au niveau du sigmo�de"
  //
  bool bLesionComplement = false ;
  //
  // L'aspect est un compl�ment du nom de la l�sion
  //
  if (!(Aspect.empty()))
  {
    if (!bLesionComplement)
    {
      Lesion.initComplement() ;
      bLesionComplement = true ;
    }
    iterPhraseObj i = Aspect.begin() ;
    for (; i != Aspect.end(); i++)
    {
      string sLexique = string((*i)->Objet.pDonnees->lexique) ;
      trouve = pSuper->getDico()->trouvePathologData(sLangue, &sLexique, &Data) ;
      if (trouve)
      {
        if (Data.estAdjectif())
          Lesion.getComplementPhr()->adjEpithete.push_back(new NSPhraseMot((*i)->Objet.pDonnees, pContexte)) ;
      }
    }
  }
  //
  // La dimension est �galement un compl�ment du nom de la l�sion
  //

  //
  // La localisation est un �pith�te si c'est un adjectif, un compl�ment de
  // lieu si c'est un nom
  //
  if (!(Localisations.empty()))
  {
    iterPhraseObj i = Localisations.begin() ;
    for (; i != Localisations.end(); i++)
    {
      string sLexique = string((*i)->Objet.pDonnees->lexique) ;
      trouve = pSuper->getDico()->trouvePathologData(sLangue, &sLexique, &Data) ;
      if (trouve)
      {
        if      (Data.estAdjectif())
        {
          if (!bLesionComplement)
          {
            Lesion.initComplement() ;
            bLesionComplement = true ;
          }
          Lesion.getComplementPhr()->adjEpithete.push_back(new NSPhraseMot((*i)->Objet.pDonnees, pContexte)) ;
        }
        else if (Data.estNom())
          pPhraseur->CCLieu.push_back(new NSPhraseMot((*i)->Objet.pDonnees, pContexte)) ;
      }
    }
  }

  //
  // Si la date a �t� saisie
  //
  if (false == Temporalite.empty())
  {
    if (false == bLesionComplement)
    {
      Lesion.initComplement() ;
      bLesionComplement = true ;
    }
    NSPhraseMot donnee(pContexte) ;

    iterPhraseObj i = Temporalite.begin() ;
    for (; i != Temporalite.end(); i++)

/*
    {
      NSPhraseTemporel* pTp = (NSPhraseTemporel*)(*i) ;

      donnee.metAZero() ;
      donnee.setLexique(string(pTp->Objet.pDonnees->lexique)) ;

      donnee.setComplement(string(pTp->ValeurMin.pDonnees->complement)) ;
      donnee.setUnite(pTp->ValeurMin.getUnit()) ;

      donnee.setformat(string(pTp->ValeurMin.pDonnees->lexique)) ;
      Lesion.pComplement->CCTemps.push_back(new NSPhraseMot(donnee)) ;
    }
*/

    {
      NSPhraseTemporel* pTp = (NSPhraseTemporel*)(*i) ;

      NSPhraseMotTime* pDate = new NSPhraseMotTime(pContexte) ;
      pTp->initPhraseMotTime(pDate) ;

      Lesion.getComplementPhr()->CCTemps.push_back(pDate) ;
    }
  }

  //
  // La localisation est compl�ment de lieu de la phrase
  //
  pPhraseur->COD.push_back(new NSPhraseMot(Lesion)) ;

  if (pGenerateur->genereProposition(dcTiret))
    *sDcodeur() = pGenerateur->getPropositionPhrase() ;
}

NSPhraseLesion::NSPhraseLesion(NSPhraseLesion& rv)
               :NSPhraseObjet(rv.pContexte)
{
  Objet 			= rv.Objet;
  iDcType 		= rv.iDcType;

  Aspect          = rv.Aspect;
  Dimensions      = rv.Dimensions;
  Localisations   = rv.Localisations;
  Etiologies      = rv.Etiologies;
  Evoquant        = rv.Evoquant;
  Semiologie      = rv.Semiologie;

  SousLesions     = rv.SousLesions;

  Traitements     = rv.Traitements;
  CAS             = rv.CAS;

  Temporalite     = rv.Temporalite;
  Garbage         = rv.Garbage;
}

NSPhraseLesion&
NSPhraseLesion::operator=(NSPhraseLesion src)
{
  if (&src == this)
    return *this ;

	Objet 			= src.Objet;
  iDcType 		= src.iDcType;

  Aspect          = src.Aspect;
  Dimensions      = src.Dimensions;
  Localisations   = src.Localisations;
  Etiologies      = src.Etiologies;
  Evoquant        = src.Evoquant;
  Semiologie      = src.Semiologie;

  SousLesions     = src.SousLesions;

  Traitements     = src.Traitements;
  CAS             = src.CAS;

  Temporalite     = src.Temporalite;
  Garbage         = src.Garbage;

  return *this ;
}

// -------------------------------------------------------------------------
// ------------------- METHODES DE NSPhraseGeste --------------------------
// -------------------------------------------------------------------------
NSPhraseGeste::NSPhraseGeste(NSContexte* pCtx, int iDecoType, string sLangue)
              :NSPhraseObjet(pCtx, iDecoType, sLangue)
{
}

NSPhraseGeste::NSPhraseGeste(decodageBase* pBase, int iDecoType, string sLangue)
              :NSPhraseObjet(pBase, iDecoType, sLangue)
{
}

void
NSPhraseGeste::decode(int colonne)
{
  int refCol = getCol() ;

  while ((getCol() > colonne) && iBon())
	{
    // Date
    if 	    (*getSt() == "KCHIR")
    {
      NSPhraseTemporel* pDate = new NSPhraseTemporel(this) ;
      pDate->ammorce() ;
      Avance() ;
      //
      // Past date for a ponctual event
      // Date pass�e d'un �v�nement ponctuel
      //
      pDate->iTypeTps    = TpsDate ;
      pDate->iFormeTps   = TpsInstant ;
      pDate->iRepererTps = TpsPast ;

      pDate->decode(refCol) ;
      Temporalite.push_back(pDate) ;
    }
    else
      Recupere() ;
  }
	return ;
}

void
NSPhraseGeste::metPhrase()
{
  NSPathologData Data ;

  pPhraseur->initialise() ;
  *sDcodeur() = "" ;
  //
  // La premi�re phase consiste � annoncer l'existence du geste,
  // sous forme d'un COD
  //
  NSPhraseMot Geste(Objet.pDonnees, pContexte) ;
  Geste.setArticle(NSPhraseMot::articleIndefini) ;
  //
  //
  bool bLesionComplement = false ;
  //
  // Si la date a �t� saisie
  //
  if (false == Temporalite.empty())
  {
    if (false == bLesionComplement)
    {
      Geste.initComplement() ;
      bLesionComplement = true ;
    }
    NSPhraseMot donnee(pContexte) ;

    iterPhraseObj i = Temporalite.begin() ;
    for (; i != Temporalite.end(); i++)
    {
      NSPhraseTemporel* pTp = (NSPhraseTemporel*)(*i) ;

      donnee.metAZero() ;
      donnee.setLexique(string(pTp->Objet.pDonnees->lexique)) ;

      donnee.setComplement(string(pTp->ValeurMin.pDonnees->complement)) ;
      donnee.setUnite(pTp->ValeurMin.getUnit()) ;

      donnee.setFormat(string(pTp->ValeurMin.pDonnees->lexique)) ;
      Geste.getComplementPhr()->CCTemps.push_back(new NSPhraseMot(donnee)) ;
    }
  }
  pPhraseur->COD.push_back(new NSPhraseMot(Geste)) ;
  if (pGenerateur->genereProposition(dcTiret))
    *sDcodeur() = pGenerateur->getPropositionPhrase() ;
}

NSPhraseGeste::NSPhraseGeste(NSPhraseGeste& rv)
              :NSPhraseObjet(rv.pContexte)
{
	Objet       = rv.Objet ;
  iDcType     = rv.iDcType ;

  Temporalite = rv.Temporalite ;
  Garbage     = rv.Garbage ;
}

NSPhraseGeste&
NSPhraseGeste::operator=(NSPhraseGeste src)
{
  if (&src == this)
    return *this ;

	Objet       = src.Objet ;
  iDcType     = src.iDcType ;

  Temporalite = src.Temporalite ;
  Garbage     = src.Garbage ;

  return *this ;
}

// -------------------------------------------------------------------------
// ------------------ METHODES DE NSPhrasePrescript ------------------------
// -------------------------------------------------------------------------
NSPhrasePrescript::NSPhrasePrescript(NSContexte* pCtx, int iDecoType, string sLangue)
              	  :NSPhraseObjet(pCtx, iDecoType, sLangue), Forme((decodageBase*)this), Event((decodageBase*)this), Dates(pCtx)
{
  iQuantitePhases = 0 ;
}

NSPhrasePrescript::NSPhrasePrescript(decodageBase* pBase, int iDecoType, string sLangue)
				  :NSPhraseObjet(pBase, iDecoType, sLangue), Forme((decodageBase*)this), Event((decodageBase*)this), Dates(pBase->pContexte)
{
  iQuantitePhases = 0 ;
}

void
NSPhrasePrescript::decode(int colonne)
{
try
{
  int refCol = getCol() ;
  // int refCol2 ;

  while ((getCol() > colonne) && iBon())
	{
    // Date d'ouverture
    if      (*getSt() == "KOUVR")
    {
      Avance() ;

      strcpy(Dates.valeurMin, (*(getitDcode()))->pDonnees->complement) ;
      strcpy(Dates.uniteMin,  (*(getitDcode()))->pDonnees->unit) ;
      strcpy(Dates.formatMin, (*(getitDcode()))->pDonnees->lexique) ;

      //
      // On ne sait pas s'il y aura un max, donc on param�tre
      // pour une phrase du type "� partir du"
      //
      Dates.iTypeTps    = TpsDate ;
      Dates.iFormeTps   = TpsInterval ;
      Dates.iRepererTps = TpsFutur ;

      Avance() ;
    }
    // Date de fermeture
    else if (*getSt() == "KFERM")
    {
      Avance() ;
      //
      // Date pass�e d'un �v�nement ponctuel
      //
      strcpy(Dates.valeurMax, (*(getitDcode()))->pDonnees->complement) ;
      strcpy(Dates.uniteMax,  (*(getitDcode()))->pDonnees->unit) ;
      strcpy(Dates.formatMax, (*(getitDcode()))->pDonnees->lexique) ;

      Dates.iTypeTps    = TpsDate ;
      Dates.iRepererTps = TpsFutur ;

      if ((Dates.valeurMin)[0] != '\0')
      {
        // Date de d�but == Date de fin / Starting date == Ending date
        if ((strcmp(Dates.valeurMin, Dates.valeurMax) == 0) &&
                    (strcmp(Dates.uniteMin, Dates.uniteMax) == 0))
          Dates.iFormeTps = TpsInstant ;
        else
          Dates.iFormeTps = TpsInterval ;

        Dates.bMinNow = false ;
      }
      else
      {
        Dates.iFormeTps = TpsInterval ;
        Dates.bMinNow   = true ;
      }

      Avance() ;
    }
    else if (*getSt() == "KEVEI")
    {
      Avance() ;

      while ((getCol() > refCol) && iBon())
      {
        Event.ammorce() ;
        Avance() ;
      }
    }
    // Forme (par exemple "comprim�")
    else if (*getSt() == "0MEDF")
    {
      Avance() ;
      while ((getCol() > refCol) && iBon())
      {
        Forme.ammorce() ;
        Avance() ;
      }
    }
    // Type d'administration
    else if (*getSt() == "0ADMI")
    {
      Avance() ;
      while ((getCol() > refCol) && iBon())
      {
        NSPhraseObjet Type(this) ;
        Type.ammorce() ;
        Administration.push_back(new NSPhraseObjet(Type)) ;
        Avance() ;
      }
    }
    // Voie d'administration
    else if (*getSt() == "0VADM")
    {
      Avance() ;
      while ((getCol() > refCol) && iBon())
      {
        NSPhraseObjet Type(this) ;
        Type.ammorce();
        //VoieAdministration.push_back(pType);
        Avance() ;
      }
    }
    // Phases
    else if (*getSt() == "KPHAT")
    {
      Avance() ;
      while ((getCol() > refCol) && iBon())
      {
        NSPhrasePhase* pPhase = new NSPhrasePhase(this) ;
        pPhase->pPrescript    = this ;
        pPhase->decode(refCol) ;

        if (iBon())
        {
          iQuantitePhases++ ;
          Phases.push_back(pPhase) ;
        }
        else
          delete pPhase ;
      }
    }
    // D�tails
    else if (*getSt() == "0DETA")
    {
      Avance() ;
      while ((getCol() > refCol) && iBon())
      {
        if (*getSt() == "�??")
        {
          NSPhraseMot* pTL = new NSPhraseMot((*(getitDcode()))->pDonnees, pContexte) ;
          Avance() ;
          Details.push_back(pTL) ;
        }
        else
          Recupere() ;
      }
    }
    // Texte libre
    else if (*getSt() == "#TLI#")
    {
      Avance() ;
      while ((getCol() > refCol) && iBon())
      {
        NSPhraseObjet* pTL = new NSPhraseObjet(this) ;
        pTL->ammorce() ;
        FreeText.push_back(pTL) ;
        Avance() ;
      }
    }
    else if (*getSt() == "�C;")
    {
      NSPhraseObjet* pTL = new NSPhraseObjet(this) ;
      pTL->ammorce() ;
      FreeText.push_back(pTL) ;
      Avance() ;
    }
    // Admin informations: skipped so far
    //
    else if (string("LADMI") == *getSt())
    {
      Avance() ;
      while ((getCol() > refCol) && iBon())
        Avance() ;
    }
    //
    // Id of proposal this prescription was created from (inside a referential)
    //
    else if (string("�RE") == *getSt())
      Avance() ;
    else
      Recupere() ;
  }

	return ;
}
catch (...)
{
	erreur("Exception NSPhrasePrescript::decode", standardError, 0) ;
}
}

void
NSPhrasePrescript::metPhrase(string decDeb, string decFin, int sautLigne)
{
  NSPathologData Data ;

  pPhraseur->initialise() ;
  *sDcodeur() = "" ;

  if (Event.Objet.pDonnees->lexique[0] != '\0')
  {
    NSPhraseur* pPhraEvent = new NSPhraseur(pContexte) ;
    pPhraEvent->iPhraseType = NSPhraseur::phraseComplement ;
    NsProposition* pPropEvent = new NsProposition(pContexte, &pPhraEvent, NsProposition::principale, NsProposition::notSetConjonct) ;
    pPhraEvent->CCHypoth.push_back(new NSPhraseMot(Event.Objet.pDonnees, pContexte)) ;
    if (pGenerateur->genereProposition(dcTiret, pPropEvent))
    {
      *sDcodeur() = pPropEvent->sPhrase ;
      if (*sDcodeur() != "")
      {
        (*sDcodeur())[0] = pseumaj((*sDcodeur())[0]) ;
        *sDcodeur() += " :" ;
        decodageBase::metPhrase(decDeb, decFin, sautLigne) ;
      }
    }
    delete pPropEvent ;
  }

  if (Phases.empty())
  {
    metPhraseFreeText(decDeb, decFin, sautLigne) ;
    return ;
  }

  iterPhraseObj iterPhrase = Phases.begin() ;
  for ( ; iterPhrase != Phases.end() ; iterPhrase++)
  {
    NSPhrasePhase* pPhase = dynamic_cast<NSPhrasePhase*>(*iterPhrase) ;
    if (pPhase)
    {
      pPhase->metPhrase() ;
      *sDcodeur() += pGenerateur->getPropositionPhrase() ;
      decodageBase::metPhrase(decDeb, decFin, sautLigne) ;
    }
  }

  metPhraseFreeText(decDeb, decFin, sautLigne) ;

  return ;

/*
    //
    // La premi�re phase consiste � annoncer le mode d'administration,
    // sous forme d'un COD (ex, "r�aliser une injection par voie IV")
    //
    //
    // Si le type d'administration a �t� saisi, c'est lui le COD
    // la forme est alors son compl�ment de nom
    //
    if (!(Administration.empty()))
    {
    	iterPhraseObj i = Administration.begin();
        for (; i != Administration.end(); i++)
        	pPhraseur->COD.push_back(new NSPhraseMot((*i)->Objet.pDonnees, pContexte));
    }
    // Pas de type d'administration : c'est la forme qui devient COD
    //
    else
    {
        // pPhraseur->COD.push_back(new NSPhraseMot(Forme.Objet.pDonnees, pContexte));
        //
        if (!(PrisesJour.empty()))
        {
            // NSPhraseMot* pMotCOD = new NSPhraseMot(pContexte) ;
            // pMotCOD->initComplement() ;
            for (iterPhraseObj itPrise = PrisesJour.begin() ; itPrise != PrisesJour.end() ; itPrise++)
            {
                NSPhrasePrise* pPrise = static_cast<NSPhrasePrise*>(*itPrise);
                if (pPrise)
   	            {
                    NSPhraseMot* pUnePrise = new NSPhraseMot(Forme.Objet.pDonnees, pContexte) ;
                    pUnePrise->initComplement() ;
                    pUnePrise->pComplement->adjNumeralCardinal = NSPhraseMot(pPrise->nbDose.pDonnees, pContexte) ;
                    pUnePrise->pComplement->CCTemps.push_back(new NSPhraseMot(pPrise->Moment.pDonnees, pContexte)) ;
                    pPhraseur->COD.push_back(pUnePrise) ;
                }
            }
        }
    }

    // Les dates sont-elles pr�cis�es
    if (((Dates.valeurMin)[0] != '\0') || ((Dates.valeurMax)[0] != '\0'))
        pPhraseur->CCTemps.push_back(new NSPhraseMotTime(Dates)) ;

    if (pGenerateur->genereProposition(dcTiret))
    {
    	*sDcodeur() = pGenerateur->getPropositionPhrase() ;
        decodageBase::metPhrase(decDeb, decFin, sautLigne) ;

        if (!(Details.empty()))
        {
            for (iterPhraseMot itDet = Details.begin() ; itDet != Details.end() ; itDet++)
            {
                *sDcodeur() = (*itDet)->sTexteLibre;
                decodageBase::metPhrase(decDeb, decFin, sautLigne) ;
            }
        }
    }
*/
}

void
NSPhrasePrescript::metPhraseFreeText(string decDeb, string decFin, int sautLigne)
{
  if (FreeText.empty())
    return ;

  iterPhraseObj iterPhrase = FreeText.begin() ;
  for ( ; iterPhrase != FreeText.end() ; iterPhrase++)
  {
    string sCodeLexique = (*iterPhrase)->Objet.getLexique() ;
    string sSens ;
    pContexte->getDico()->donneCodeSens(&sCodeLexique, &sSens) ;

    if ((sSens == "�??") || (sSens == "�C;"))
    {
      *(sDcodeur()) = (*iterPhrase)->Objet.getTexteLibre();
      decodageBase::metPhrase(decDeb, decFin, sautLigne);
    }
    else
    {
      pContexte->getDico()->donneLibelle(sLangue, &sCodeLexique, sDcodeur());
      if (*sDcodeur() != "")
      {
        (*sDcodeur())[0] = pseumaj((*sDcodeur())[0]) ;
        *sDcodeur() += "." ;
      }
      decodageBase::metPhrase(decDeb, decFin, sautLigne);
    }
  }
  return ;
}

NSPhrasePrescript::NSPhrasePrescript(NSPhrasePrescript& rv)
              	  :NSPhraseObjet(rv.pContexte), Forme(rv.Forme), Event(rv.Event), Dates(rv.Dates)
{
    Objet 			= rv.Objet;
    iDcType 		= rv.iDcType;

    Forme           = rv.Forme ;
    Dates           = rv.Dates ;

    Administration  = rv.Administration ;

    iQuantitePhases = rv.iQuantitePhases ;
    Phases          = rv.Phases ;

    Garbage         = rv.Garbage ;
    Details         = rv.Details ;
}

NSPhrasePrescript&
NSPhrasePrescript::operator=(NSPhrasePrescript src)
{
    Objet 			= src.Objet;
    iDcType 		= src.iDcType;

	Forme           = src.Forme ;
    Dates           = src.Dates ;

    Administration  = src.Administration ;
    Event           = src.Event ;

    iQuantitePhases = src.iQuantitePhases ;
    Phases          = src.Phases ;

    Garbage         = src.Garbage ;
    Details         = src.Details ;

    return *this;
}

// -------------------------------------------------------------------------
// ------------------ METHODES DE NSPhrasePhase ------------------------
// -------------------------------------------------------------------------

NSPhrasePhase::NSPhrasePhase(NSContexte* pCtx, int iDecoType, string sLangue)
              :NSPhraseObjet(pCtx, iDecoType, sLangue), phrDuree((NSPhrasePhase*)this), DatePhase(pCtx), DateRenouv(pCtx)
{
	isDuration  = false ;
	iNbRenouv   = 0 ;
	iQuantiteCycles = 0 ;
	pPrescript  = 0 ;
}

NSPhrasePhase::NSPhrasePhase(decodageBase* pBase, int iDecoType, string sLangue)
              :NSPhraseObjet(pBase, iDecoType, sLangue), phrDuree(pBase), DatePhase(pBase->pContexte), DateRenouv(pBase->pContexte)
{
  isDuration  = false ;
  iNbRenouv   = 0 ;
  iQuantiteCycles = 0 ;
  pPrescript  = 0 ;
}

void
NSPhrasePhase::decode(int colonne)
{
try
{
	NSPhraseTemporel* pTemps = 0 ;

	int refCol = getCol();

	while ((getCol() > colonne) && iBon())
	{
  	// Date de d�but de la phase
    if      (*getSt() == "KOUVR")
    {
      Avance();

      strcpy(DatePhase.valeurMin, (*(getitDcode()))->pDonnees->complement) ;
      strcpy(DatePhase.uniteMin,  (*(getitDcode()))->pDonnees->unit) ;
      strcpy(DatePhase.formatMin, (*(getitDcode()))->pDonnees->lexique) ;

      //
      // On ne sait pas s'il y aura un max, dont on param�tre
      // pour une phrase du type "� partir du"
      //
      DatePhase.iTypeTps    = TpsDate ;
      DatePhase.iFormeTps   = TpsInterval ;
      DatePhase.iRepererTps = TpsFutur ;

      Avance();
    }
    // Date de fin de la phase
    else if (*getSt() == "KFERM")
    {
      Avance();

      strcpy(DatePhase.valeurMax, (*(getitDcode()))->pDonnees->complement) ;
      strcpy(DatePhase.uniteMax,  (*(getitDcode()))->pDonnees->unit) ;
      strcpy(DatePhase.formatMax, (*(getitDcode()))->pDonnees->lexique) ;

      Avance();
    }
  	// Cycle(s)
    else if (*getSt() == "KCYTR")
    {
    	Avance() ;
      // int refCol2 = getCol() ;
      while ((getCol() > refCol) && iBon())
      {
      	NSPhraseCycle* pCycle = new NSPhraseCycle(this) ;
        pCycle->decode(refCol) ;

        if (iBon())
        {
        	iQuantiteCycles++ ;
          Cycles.push_back(pCycle) ;
        }
        else
        	delete pCycle ;
      }
    }
    // Dur�e de la phase
    else if (*getSt() == "VDURE")
    {
    	phrDuree.ammorce() ;
      isDuration = true ;
      phrDuree.iTypeTps  = TpsDuration ;
      phrDuree.iFormeTps = TpsInterval ;

      Avance() ;

      phrDuree.decode(refCol, false, TpsDuration) ;
    }
    // Nombre de renouvellements posibles
    else if (*getSt() == "VRENO")
    {
    	Avance() ;
      while ((getCol() > refCol) && iBon())
      {
        NSPatPathoInfo PPTinfo = *(*(getitDcode())) ;
        gereNum numNbEvent(pContexte, sLangue) ;
        NSPatPathoInfo nbEventInfo ;
        if ((PPTinfo.pDonnees->lexique)[0] == '�')
        {
        	nbEventInfo = PPTinfo ;
          Avance() ;
        }
        else
        	Recupere() ;

        string sEventCplmt = nbEventInfo.getComplement() ;
        string sEventUnit  = nbEventInfo.getUnit() ;
        string sEventFrmt  = nbEventInfo.getLexique() ;
        numNbEvent.instancier(&sEventCplmt, &sEventUnit, &sEventFrmt) ;

        iNbRenouv = int(numNbEvent.getValeur()) ;
      }
    }
    // renouvellement
    else if (*getSt() == "GRENT")
    {
      int refCol2 = getCol() ;
      Avance() ;

      while ((getCol() > refCol) && iBon())
      {
        if (*getSt() == "VDURE")
        {
          phrDuree.ammorce() ;
          isDuration = true ;
          phrDuree.iTypeTps   = TpsDuration ;
          phrDuree.iFormeTps  = TpsInterval ;

          int refCol3 = getCol() ;

          Avance() ;

          phrDuree.decode(refCol3, false, TpsDuration) ;
        }
        // Nombre de renouvellements posibles
        else if (*getSt() == "VRENO")
        {
          Avance() ;
          while ((getCol() > refCol2) && iBon())
          {
            NSPatPathoInfo PPTinfo = *(*(getitDcode())) ;
            gereNum numNbEvent(pContexte, sLangue) ;
            NSPatPathoInfo nbEventInfo ;
            if ((PPTinfo.pDonnees->lexique)[0] == '�')
            {
            	nbEventInfo = PPTinfo ;
              Avance() ;
            }
            else
            	Recupere() ;

            string sEventCplmt = nbEventInfo.getComplement() ;
            string sEventUnit  = nbEventInfo.getUnit() ;
            string sEventFrmt  = nbEventInfo.getLexique() ;
            numNbEvent.instancier(&sEventCplmt, &sEventUnit, &sEventFrmt) ;

            iNbRenouv = int(numNbEvent.getValeur()) ;
          }
        }
        // Date d'ouverture
        else if (*getSt() == "KOUVR")
        {
          Avance();

          strcpy(DateRenouv.valeurMin, (*(getitDcode()))->pDonnees->complement) ;
          strcpy(DateRenouv.uniteMin,  (*(getitDcode()))->pDonnees->unit) ;
          strcpy(DateRenouv.formatMin, (*(getitDcode()))->pDonnees->lexique) ;

          //
          // On ne sait pas s'il y aura un max, dont on param�tre
          // pour une phrase du type "� partir du"
          //
          DateRenouv.iTypeTps    = TpsDate ;
          DateRenouv.iFormeTps   = TpsInterval ;
          DateRenouv.iRepererTps = TpsFutur ;

          Avance();
        }
        else
            Recupere() ;
      }
    }
    else
    	Recupere() ;
	}
  if (pTemps)
	{
  	// Temporalite.push_back(new NSPhraseTemporel(*pTemps));
    delete pTemps ;
	}
	return ;
}
catch (...)
{
	erreur("Exception NSPhrasePhase::decode", standardError, 0) ;
}
}

void
NSPhrasePhase::metPhrase()
{
try
{
  NSPathologData Data ;

  pPhraseur->initialise() ;
  *sDcodeur() = "" ;

  NsProposition* pPropos = new NsProposition(pContexte) ;
  NSPropositionArray* pPropArray = new NSPropositionArray() ;

  if (false == Cycles.empty())
  {
    iterPhraseObj iterCycle = Cycles.begin() ;
    for ( ; iterCycle != Cycles.end() ; iterCycle++)
    {
      NSPhraseCycle* pCycle = dynamic_cast<NSPhraseCycle*>(*iterCycle) ;
      // NSPhraseCycle* pCycle = TYPESAFE_DOWNCAST(*iterCycle, NSPhraseCycle) ;
      if (pCycle)
      {
        // Cycle circadien
        //
        if (false == pCycle->Cycle_circadien.empty())
        {
          NsProposition* pPrCyCir = new NsProposition(pContexte) ;
          NSPropositionArray* pPropCyCirArray = new NSPropositionArray() ;
          pPrCyCir->pProposition  = pPropCyCirArray ;
          pPrCyCir->iObjectType   = NsProposition::isPropositionArray ;

          iterPhraseObj iterCircadien = pCycle->Cycle_circadien.begin() ;
          for ( ; iterCircadien != pCycle->Cycle_circadien.end() ; iterCircadien++)
          {
            NSPhrasePrise* pPrise = dynamic_cast<NSPhrasePrise*>(*iterCircadien) ;
            // NSPhrasePrise* pPrise = TYPESAFE_DOWNCAST(*iterCircadien, NSPhrasePrise) ;
            if (pPrise)
            {
              NSPhraseur* pPhraCycle = new NSPhraseur(pContexte) ;
              NSPhraseMot* pMot = new NSPhraseMot(pPrescript->Forme.Objet.pDonnees, pContexte) ;
              pMot->initComplement() ;
              pMot->getComplementPhr()->adjNumeralCardinal = NSPhraseMot(pPrise->nbDose.pDonnees, pContexte) ;
              // NSPhraseMot* pMot = new NSPhraseMot(pPrise->nbDose.pDonnees, pContexte) ;
              pPhraCycle->COD.push_back(pMot) ;
              if (pPrise->Moment.pDonnees->lexique[0] != '\0')
                pPhraCycle->CCTemps.push_back(new NSPhraseMot(pPrise->Moment.pDonnees, pContexte)) ;
              if (false == pPrise->Temporalite.estVide())
                pPhraCycle->CCTemps.push_back(new NSPhraseMotTime(pPrise->Temporalite)) ;
              if (false == pPrise->TempoCycle.estVide())
              {
                NSPhraseMotTimeCycle* pMotCycle = new NSPhraseMotTimeCycle(pContexte) ;
                pPrise->TempoCycle.initCycle(pMotCycle) ;
                pPhraCycle->CCTemps.push_back(pMotCycle) ;
              }

              pPropCyCirArray->push_back(new NsProposition(pContexte, &pPhraCycle, NsProposition::principale, NsProposition::notSetConjonct)) ;
            }
          }

          pPropArray->push_back(pPrCyCir) ;
        }
        // Rythme
        //
        if (false == pCycle->Rythme.empty())
        {
          NsProposition* pPrRythm = new NsProposition(pContexte) ;
          NSPropositionArray* pPropRythmArray = new NSPropositionArray() ;
          pPrRythm->pProposition      = pPropRythmArray ;
          pPrRythm->iObjectType       = NsProposition::isPropositionArray ;
          pPrRythm->iPropositionType  = NsProposition::principale ;

          iterPhraseObj iterRythme = pCycle->Rythme.begin() ;
          for ( ; iterRythme != pCycle->Rythme.end() ; iterRythme++)
          {
            NSPhraseTempoCycle* pRythme = dynamic_cast<NSPhraseTempoCycle*>(*iterRythme) ;
            // NSPhrasePrise* pPrise = TYPESAFE_DOWNCAST(*iterCircadien, NSPhrasePrise) ;
            if (pRythme)
            {
              NSPhraseur* pPhraRythme = new NSPhraseur(pContexte) ;
              pPhraRythme->iPhraseType = NSPhraseur::phraseComplement ;
              NsProposition* pProposRythme = new NsProposition(pContexte, &pPhraRythme, NsProposition::notSetType, NsProposition::notSetConjonct) ;

              NSPhraseMotTimeCycle* pMotCycle = new NSPhraseMotTimeCycle(pContexte) ;
              pRythme->initCycle(pMotCycle) ;
              pPhraRythme->CCTemps.push_back(pMotCycle) ;

              pPropRythmArray->push_back(pProposRythme) ;
            }
            else
            {
              NSPhraseur* pPhraRythme = new NSPhraseur(pContexte) ;
              pPhraRythme->iPhraseType = NSPhraseur::phraseComplement ;
              NsProposition* pProposRythme = new NsProposition(pContexte, &pPhraRythme, NsProposition::notSetType, NsProposition::notSetConjonct) ;

              pPhraRythme->CCTemps.push_back(new NSPhraseMot((*iterRythme)->Objet.pDonnees, pContexte)) ;

              pPropRythmArray->push_back(pProposRythme) ;
            }
          }

          pPropArray->push_back(pPrRythm) ;
        }
      }
      //if (!((*iterCycle)->Rythme.empty()))
      //{
      //}
    }
  }

  if (isDuration)
  {
    NSPhraseur* pPhraDuree      = new NSPhraseur(pContexte) ;
    NsProposition* pProposDuree = new NsProposition(pContexte, &pPhraDuree, NsProposition::notSetType, NsProposition::notSetConjonct) ;

    NSPhraseMotTime* pDate = new NSPhraseMotTime(pContexte) ;

    strcpy(pDate->formatDuree, phrDuree.ValeurDuree.pDonnees->lexique) ;
    strcpy(pDate->valeurDuree, phrDuree.ValeurDuree.pDonnees->complement) ;
    strcpy(pDate->uniteDuree,  phrDuree.ValeurDuree.pDonnees->unit) ;
    pPhraDuree->CCTemps.push_back(pDate) ;

    if (iNbRenouv > 0)
    {
      NSPhraseMot* pPhraseMot = new NSPhraseMot(pContexte) ;
      pPhraseMot->setLexique(string("VRENO2")) ;
      char szNbre[33] ;
      itoa(iNbRenouv, szNbre, 10) ;
      pPhraseMot->setComplement(string(szNbre)) ;
      pPhraseMot->setFormat(string("�N0;02")) ;
      pPhraseMot->setUnite(string("2FOIS1")) ;      pPhraseMot->setNumForme(NSPhraseMot::numTiret) ;      pPhraDuree->CCChiffre.push_back(pPhraseMot) ;    }

    pPhraDuree->iPhraseType = NSPhraseur::phraseComplement ;
    pPropArray->push_back(pProposDuree) ;
  }

  pPropos->pProposition   = pPropArray ;
  pPropos->iObjectType    = NsProposition::isPropositionArray ;

  //
  // La premi�re phase consiste � annoncer le mode d'administration,
  // sous forme d'un COD (ex, "r�aliser une injection par voie IV")
  //
  //
  // Si la date a �t� saisie
  //
  // if (!(Administration.empty()))
  // {
  // 	iterPhraseObj i = Administration.begin();
  //    for (; i != Administration.end(); i++)
  //    	pPhraseur->COD.push_back(new NSPhraseMot((*i)->Objet.pDonnees, pContexte));
  // }
  if (pGenerateur->genereProposition(dcTiret, pPropos))
  {
    //*sDcodeur() = pGenerateur->getPropositionPhrase() ;
    pGenerateur->termineProposition(pPropos) ;
    *sDcodeur() = pPropos->sPhrase ;
  }

  delete pPropos ;
}
catch (...)
{
	erreur("Exception NSPhrasePhase::metPhrase", standardError, 0) ;
}
}

NSPhrasePhase::NSPhrasePhase(NSPhrasePhase& rv)
              :NSPhraseObjet(rv.pContexte), phrDuree(rv.pContexte), DatePhase(rv.pContexte), DateRenouv(rv.pContexte)
{
  Objet 			= rv.Objet;
  iDcType 		= rv.iDcType;

  phrDuree        = rv.phrDuree ;
  DatePhase       = rv.DatePhase ;
  iNbRenouv       = rv.iNbRenouv ;
  DateRenouv      = rv.DateRenouv ;

  iQuantiteCycles = rv.iQuantiteCycles ;
  Cycles          = rv.Cycles ;
}

NSPhrasePhase&
NSPhrasePhase::operator=(NSPhrasePhase src)
{
	if (this == &src)
		return *this ;

	Objet 			= src.Objet ;
	iDcType 		= src.iDcType ;

	phrDuree        = src.phrDuree ;
	DatePhase       = src.DatePhase ;
  DateRenouv      = src.DateRenouv ;
	iNbRenouv       = src.iNbRenouv ;

	iQuantiteCycles = src.iQuantiteCycles ;
	Cycles          = src.Cycles ;

	return *this ;
}

// -------------------------------------------------------------------------
// ------------------ METHODES DE NSPhraseCycle ------------------------
// -------------------------------------------------------------------------

NSPhraseCycle::NSPhraseCycle(NSContexte* pCtx, int iDecoType, string sLangue)
              :NSPhraseObjet(pCtx, iDecoType, sLangue)
{
}

NSPhraseCycle::NSPhraseCycle(decodageBase* pBase, int iDecoType, string sLangue)
              :NSPhraseObjet(pBase, iDecoType, sLangue)
{
}

void
NSPhraseCycle::decode(int colonne)
{
try
{
	// NSPhraseTemporel* pTemps = 0 ;
	NSPatPathoInfo PPTinfo ;

	int refCol = getCol() ;

	while ((getCol() > colonne) && iBon())
	{
  	// Rythme circadien
    if      (*getSt() == "KRYTH")
    {
    	Avance() ;
      int refCol2 = getCol() ;
      while ((getCol() > refCol) && iBon())
      {
      	if (*getSt() == "KHHMM")
        {
        	Avance() ;

          NSPhrasePrise* pPrise = new NSPhrasePrise(this) ;
          pPrise->decode(refCol2) ;

          if (iBon())
          	Cycle_circadien.push_back(pPrise) ;
          else
          	delete pPrise ;
        }
        else if (*getSt() == "KCYCI")
        {
        	Avance() ;
          int refCol3 = getCol() ;

          while ((getCol() > refCol2) && iBon())
          {
          	if (*getSt() == "KRYLI")
            {
            	Avance() ;
              NSPhraseTempoCycle* pTmpCycle = new NSPhraseTempoCycle(this) ;
              pTmpCycle->iTypeCycle = NSPhraseTempoCycle::Libre ;
              pTmpCycle->decode(refCol3) ;
              if (iBon())
              {
              	NSPhrasePrise* pPrise = new NSPhrasePrise(this) ;
                pPrise->TempoCycle = *pTmpCycle ;
                pPrise->decode(refCol2) ;
                if (iBon())
                	Cycle_circadien.push_back(pPrise) ;
                else
                	delete pPrise ;
              }
              delete pTmpCycle ;
            }
            else if (*getSt() == "KRYRE")
            {
            	Avance() ;
              NSPhraseTempoCycle* pTmpCycle = new NSPhraseTempoCycle(this) ;
              pTmpCycle->iTypeCycle = NSPhraseTempoCycle::Regulier ;
              pTmpCycle->decode(refCol3) ;
              if (iBon())
              {
              	NSPhrasePrise* pPrise = new NSPhrasePrise(this) ;
                pPrise->TempoCycle = *pTmpCycle ;
                pPrise->decode(refCol2) ;
                if (iBon())
                	Cycle_circadien.push_back(pPrise) ;
                else
                	delete pPrise ;
              }
              delete pTmpCycle ;
            }
            else
            	Recupere() ;
          }
        }
        else
        {
        	//
          PPTinfo = *(*(getitDcode())) ;
          string sCodeLexique = PPTinfo.getLexique() ;
          string sSens ;
          pContexte->getDico()->donneCodeSens(&sCodeLexique, &sSens) ;

          Avance() ;

          // Moment de la journ�e
          //
          if ((pContexte->getSuperviseur()->getFilGuide()->VraiOuFaux(sSens, string("ES"), "KMOME")) ||
              (pContexte->getSuperviseur()->getFilGuide()->VraiOuFaux(sSens, string("ES"), "KEVEQ")))
          {
          	NSPhrasePrise* pPrise = new NSPhrasePrise(this) ;
            pPrise->Moment = PPTinfo ;
            pPrise->decode(refCol2) ;

            if (iBon())
            	Cycle_circadien.push_back(pPrise) ;
            else
            	delete pPrise ;
          }
        }
      }
    }
    // Rythme de cure
    else if (*getSt() == "KRYTP")
    {
    	Avance() ;
      int refCol2 = getCol() ;
      while ((getCol() > refCol) && iBon())
      {
      	if (*getSt() == "KRYLI")
        {
        	Avance() ;
          NSPhraseTempoCycle* pTmpCycle = new NSPhraseTempoCycle(this) ;
          pTmpCycle->iTypeCycle = NSPhraseTempoCycle::Libre ;

          pTmpCycle->decode(refCol2) ;
          if (iBon())
          	Rythme.push_back(pTmpCycle) ;
          else
          	delete pTmpCycle ;
        }
        else if (*getSt() == "KRYRE")
        {
        	Avance() ;
          NSPhraseTempoCycle* pTmpCycle = new NSPhraseTempoCycle(this) ;
          pTmpCycle->iTypeCycle = NSPhraseTempoCycle::Regulier ;

          pTmpCycle->decode(refCol2) ;
          if (iBon())
          	Rythme.push_back(pTmpCycle) ;
          else
          	delete pTmpCycle ;
        }
        else
        {
        	PPTinfo = *(*(getitDcode())) ;
          string sSens = PPTinfo.getLexiqueSens(pContexte) ;

          // For Day 1, day 2, day 3
          if (sSens == string("2DAT0"))
          {
          	int refCol3 = getCol() ;

            NSPhraseObjet* pJour = new NSPhraseObjet(this) ;
            pJour->ammorce() ;

          	Avance() ;

            if (iBon())
      				while ((getCol() > refCol3) && iBon())
              {
              	if (*getSt() == "VNUMT")
                {
                	Avance() ;
                  while ((getCol() > refCol3 + 1) && iBon())
            			{
                  	NSPatPathoInfo PPTinfo = *(*(getitDcode())) ;
                		gereNum numNbEvent(pContexte, sLangue) ;
                		NSPatPathoInfo nbEventInfo ;
                		if ((PPTinfo.pDonnees->lexique)[0] == '�')
                		{
                    	nbEventInfo = PPTinfo ;
                    	Avance() ;
                		}
                		else
                    	Recupere() ;

                		string sEventCplmt  = nbEventInfo.getComplement() ;
                		string sEventUnit   = nbEventInfo.getUnit() ;
                		string sEventFrmt   = nbEventInfo.getLexique() ;
                		numNbEvent.instancier(&sEventCplmt, &sEventUnit, &sEventFrmt) ;

                		// iNbRenouv = int(numNbEvent.getValeur()) ;
                  }
                }
              }

            if (iBon())
            	Rythme.push_back(pJour) ;
            else
            	delete pJour ;
          }
          // For Day 1, day 2, day 3
          else if (sSens == string("9VOID"))
          {
          	Avance() ;
          }
          // for day(s) of the week
          else if (pContexte->getSuperviseur()->getFilGuide()->VraiOuFaux(sSens, string("ES"), "KJSEM"))
          {
          	NSPhraseObjet* pJour = new NSPhraseObjet(this) ;
            pJour->ammorce() ;

            Avance() ;

            if (iBon())
            	Rythme.push_back(pJour) ;
            else
            	delete pJour ;
          }
          else
          	Recupere() ;
        }
      }
    }
    else
    	Recupere() ;
  }
	return ;
}
catch (...)
{
	erreur("Exception NSPhraseCycle::decode", standardError, 0) ;
}
}

void
NSPhraseCycle::metPhrase()
{
  NSPathologData Data ;

  pPhraseur->initialise() ;
  *sDcodeur() = "" ;

  NsProposition* pPropos = new NsProposition(pContexte) ;
  NSPropositionArray* pPropArray = new NSPropositionArray() ;

  // Cycle circadien
  //
  if (false == Cycle_circadien.empty())
  {
    NsProposition* pPrCyCir = new NsProposition(pContexte) ;
    NSPropositionArray* pPropCyCirArray = new NSPropositionArray() ;
    pPrCyCir->pProposition  = pPropCyCirArray ;
    pPrCyCir->iObjectType   = NsProposition::isPropositionArray ;

    iterPhraseObj iterCircadien = Cycle_circadien.begin() ;
    for ( ; iterCircadien != Cycle_circadien.end() ; iterCircadien++)
    {
      NSPhrasePrise* pPrise = dynamic_cast<NSPhrasePrise*>(*iterCircadien) ;
      // NSPhrasePrise* pPrise = TYPESAFE_DOWNCAST(*iterCircadien, NSPhrasePrise) ;
      if (NULL != pPrise)
      {
        NSPhraseur* pPhraCycle = new NSPhraseur(pContexte) ;
        if (pPrise->Moment.pDonnees->lexique[0] != '\0')
          pPhraCycle->CCTemps.push_back(new NSPhraseMot(pPrise->Moment.pDonnees, pContexte)) ;
        if (false == pPrise->Temporalite.estVide())
          pPhraCycle->CCTemps.push_back(new NSPhraseMotTime(pPrise->Temporalite)) ;
        if (false == pPrise->TempoCycle.estVide())
        {
          NSPhraseMotTimeCycle* pMotCycle = new NSPhraseMotTimeCycle(pContexte) ;
          pPrise->TempoCycle.initCycle(pMotCycle) ;
          pPhraCycle->CCTemps.push_back(pMotCycle) ;
        }

        pPropCyCirArray->push_back(new NsProposition(pContexte, &pPhraCycle, NsProposition::principale, NsProposition::notSetConjonct)) ;
      }
    }

    pPropArray->push_back(pPrCyCir) ;
  }
  // Rythme
  //
  if (!(Rythme.empty()))
  {
    NsProposition* pPrRythm = new NsProposition(pContexte) ;
    NSPropositionArray* pPropRythmArray = new NSPropositionArray() ;
    pPrRythm->pProposition     = pPropRythmArray ;
    pPrRythm->iObjectType      = NsProposition::isPropositionArray ;
    pPrRythm->iPropositionType = NsProposition::principale ;

    iterPhraseObj iterRythme = Rythme.begin() ;
    for ( ; iterRythme != Rythme.end() ; iterRythme++)
    {
      NSPhraseTempoCycle* pRythme = dynamic_cast<NSPhraseTempoCycle*>(*iterRythme) ;
      // NSPhrasePrise* pPrise = TYPESAFE_DOWNCAST(*iterCircadien, NSPhrasePrise) ;
      if (pRythme)
      {
        NSPhraseur* pPhraRythme = new NSPhraseur(pContexte) ;
        pPhraRythme->iPhraseType = NSPhraseur::phrasePrincipale ;
        NsProposition* pProposRythme = new NsProposition(pContexte, &pPhraRythme, NsProposition::notSetType, NsProposition::notSetConjonct) ;

        NSPhraseMotTimeCycle* pMotCycle = new NSPhraseMotTimeCycle(pContexte) ;
        pRythme->initCycle(pMotCycle) ;
        pPhraRythme->CCTemps.push_back(pMotCycle) ;

        pPropRythmArray->push_back(pProposRythme) ;
      }
      else
      {
        NSPhraseur* pPhraRythme = new NSPhraseur(pContexte) ;
        pPhraRythme->iPhraseType = NSPhraseur::phrasePrincipale ;
        NsProposition* pProposRythme = new NsProposition(pContexte, &pPhraRythme, NsProposition::notSetType, NsProposition::notSetConjonct) ;

        pPhraRythme->COD.push_back(new NSPhraseMot((*iterRythme)->Objet.pDonnees, pContexte)) ;

        pPropRythmArray->push_back(pProposRythme) ;
      }
    }

    pPropArray->push_back(pPrRythm) ;
  }

  pPropos->pProposition = pPropArray ;
  pPropos->iObjectType  = NsProposition::isPropositionArray ;

  if (pGenerateur->genereProposition(dcTiret, pPropos))
  {
    pGenerateur->termineProposition(pPropos) ;
    *sDcodeur() = pPropos->sPhrase ;
  }

  delete pPropos ;
}

NSPhraseCycle::NSPhraseCycle(NSPhraseCycle& rv)
              :NSPhraseObjet(rv.pContexte)
{
    Objet 			= rv.Objet;
    iDcType 		= rv.iDcType;

    Cycle_circadien = rv.Cycle_circadien ;
    Rythme          = rv.Rythme ;
}

NSPhraseCycle&
NSPhraseCycle::operator=(NSPhraseCycle src)
{
    Objet 			= src.Objet;
    iDcType 		= src.iDcType;

    Cycle_circadien = src.Cycle_circadien ;
    Rythme          = src.Rythme ;

    return *this;
}

// -------------------------------------------------------------------------
// ------------------ METHODES DE NSPhrasePrise ------------------------
// -------------------------------------------------------------------------
NSPhrasePrise::NSPhrasePrise(NSContexte* pCtx, int iDecoType, string sLangue)
              :NSPhraseObjet(pCtx, iDecoType, sLangue), Temporalite(pCtx), TempoCycle(pCtx)
{
}

NSPhrasePrise::NSPhrasePrise(decodageBase* pBase, int iDecoType, string sLangue)
              :NSPhraseObjet(pBase, iDecoType, sLangue), Temporalite(pBase->pContexte), TempoCycle(pBase->pContexte)
{
}

void
NSPhrasePrise::decode(int colonne)
{
try
{
  NSPhraseTemporel* pTemps = 0 ;

  int refCol = getCol() ;

  while ((getCol() > colonne) && iBon())
	{
    // Nombre de doses
    if      (*getSt() == "VNBDO")
    {
      Avance() ;

      NSPatPathoInfo PPTinfo ;

      while ((getCol() > refCol) && iBon())
      {
        //
        PPTinfo = *(*(getitDcode())) ;

        if ('�' == (PPTinfo.pDonnees->lexique)[0])
        {
          nbDose = PPTinfo ;
          Avance() ;
        }
        else
          Recupere() ;
      }
    }
    // Date de fermeture
    else if (*getSt() == "KFERM")
    {
      if (NULL == pTemps)
      {
        pTemps = new NSPhraseTemporel(this) ;
        pTemps->ammorce() ;
      }
      Avance() ;
      //
      // Date pass�e d'un �v�nement ponctuel
      //
      pTemps->iTypeTps    = TpsDate;
      pTemps->iFormeTps   = TpsInstant;
      pTemps->iRepererTps = TpsFutur;

      pTemps->decode(refCol, false);
    }
    // Type d'administration
    else if (*getSt() == "0ADMI")
    {
      Avance() ;
      while ((getCol() > refCol) && iBon())
      {
        NSPhraseObjet* pType = new NSPhraseObjet(this) ;
        pType->ammorce() ;
        // Administration.push_back(new NSPhraseObjet(*pType));
        delete pType ;
        Avance() ;
      }
    }
    // Voie d'administration
    else if (*getSt() == "0VADM")
    {
      Avance();
      while ((getCol() > refCol) && iBon())
      {
        NSPhraseObjet* pType = new NSPhraseObjet(this) ;
        pType->ammorce() ;
        // VoieAdministration.push_back(new NSPhraseObjet(*pType));
        delete pType ;
        Avance() ;
      }
    }
    else
    {
      gereHeure heure(pContexte, sLangue) ;
      donneHeure(colonne, &heure) ;

      if (!(heure.estVide()))
      {
        strcpy(Temporalite.valeurMin, heure.getHeure().c_str()) ;
        strcpy(Temporalite.uniteMin,  heure.sUnite.c_str()) ;
        strcpy(Temporalite.formatMin, heure.sFormatage.c_str()) ;
        Temporalite.setSharpDate() ;
        //
        Temporalite.iTypeTps    = TpsDate ;
        Temporalite.iFormeTps   = TpsInstant ;
        Temporalite.iRepererTps = TpsFutur ;
      }
      else
        Recupere() ;
    }
  }
  if (pTemps)
    //Temporalite.push_back(new NSPhraseTemporel(*pTemps));
    delete pTemps ;

	return ;
}
catch (...)
{
	erreur("Exception NSPhrasePrise::decode", standardError, 0) ;
}
}

void
NSPhrasePrise::metPhrase()
{
    NSPathologData Data;

    pPhraseur->initialise();
    *sDcodeur() = "";
    //
    // La premi�re phase consiste � annoncer le mode d'administration,
    // sous forme d'un COD (ex, "r�aliser une injection par voie IV")
    //
    //
    // Si la date a �t� saisie
    //
    // if (!(Administration.empty()))
    // {
    // 	iterPhraseObj i = Administration.begin();
    //    for (; i != Administration.end(); i++)
    //    	pPhraseur->COD.push_back(new NSPhraseMot((*i)->Objet.pDonnees, pContexte));
    // }
    if (pGenerateur->genereProposition(dcTiret))
    	*sDcodeur() = pGenerateur->getPropositionPhrase() ;
}

NSPhrasePrise::NSPhrasePrise(NSPhrasePrise& rv)
              :NSPhraseObjet(rv.pContexte), Temporalite(rv.pContexte), TempoCycle(rv.pContexte)
{
	Objet       = rv.Objet ;
    iDcType     = rv.iDcType ;

    nbDose	   	= rv.nbDose ;
    ValeurDose  = rv.ValeurDose ;
    ObjetDose   = rv.ObjetDose ;

    Moment      = rv.Moment ;
    Temporalite = rv.Temporalite ;
    TempoCycle  = rv.TempoCycle ;
}

NSPhrasePrise&
NSPhrasePrise::operator=(NSPhrasePrise src)
{
	Objet       = src.Objet ;
    iDcType     = src.iDcType ;

    nbDose	   	= src.nbDose ;
    ValeurDose  = src.ValeurDose ;
    ObjetDose   = src.ObjetDose ;

    Moment      = src.Moment ;
    Temporalite = src.Temporalite ;
    TempoCycle  = src.TempoCycle ;

    return *this;
}

// -------------------------------------------------------------------------
// ------------------ METHODES DE NSPhrasePrise ------------------------
// -------------------------------------------------------------------------
/*
NSPhrasePrise::NSPhrasePrise(NSContexte* pCtx, int iDecoType, string sLangue)
              :NSPhraseObjet(pCtx, iDecoType, sLangue), Temporalite(pCtx)
{
}

NSPhrasePrise::NSPhrasePrise(decodageBase* pBase, int iDecoType, string sLangue)
              :NSPhraseObjet(pBase, iDecoType, sLangue), Temporalite(pBase->pContexte)
{
}

void
NSPhrasePrise::decode(int colonne)
{
    NSPhraseTemporel* pTemps = 0 ;

    int refCol = getCol();

    while ((getCol() > colonne) && iBon())
	{
        // Date d'ouverture
        if      (*getSt() == "KOUVR")
        {
            if (!pTemps)
            {
                pTemps = new NSPhraseTemporel(this);
                pTemps->ammorce();
            }
            Avance();
            //
            // Date pass�e d'un �v�nement ponctuel
            //
            pTemps->iTypeTps    = NSPhraseTemporel::TpsDate;
            pTemps->iFormeTps   = NSPhraseTemporel::TpsInstant;
            pTemps->iRepererTps = NSPhraseTemporel::TpsFutur;

            pTemps->decode(refCol, true);
        }
        // Date de fermeture
        else if (*getSt() == "KFERM")
        {
            if (!pTemps)
            {
                pTemps = new NSPhraseTemporel(this);
                pTemps->ammorce();
            }
            Avance();
            //
            // Date pass�e d'un �v�nement ponctuel
            //
            pTemps->iTypeTps    = NSPhraseTemporel::TpsDate;
            pTemps->iFormeTps   = NSPhraseTemporel::TpsInstant;
            pTemps->iRepererTps = NSPhraseTemporel::TpsFutur;

            pTemps->decode(refCol, false);
        }
        // Type d'administration
        else if (*getSt() == "0ADMI")
        {
            Avance();
            while ((getCol() > refCol) && iBon())
            {
            	NSPhraseObjet* pType = new NSPhraseObjet(this);
            	pType->ammorce();
            	Administration.push_back(new NSPhraseObjet(*pType));
            	delete pType;
                Avance();
            }
        }
        // Voie d'administration
        else if (*getSt() == "0VADM")
        {
            Avance();
            while ((getCol() > refCol) && iBon())
            {
            	NSPhraseObjet* pType = new NSPhraseObjet(this);
            	pType->ammorce();
            	VoieAdministration.push_back(new NSPhraseObjet(*pType));
            	delete pType;
                Avance();
            }
        }
        else
            Recupere();
    }
    if (pTemps)
    {
        Temporalite.push_back(new NSPhraseTemporel(*pTemps));
        delete pTemps;
    }
	return;
}

void
NSPhrasePrise::metPhrase()
{
    NSPathologData Data;

    pPhraseur->initialise();
    *sDcodeur() = "";
    //
    // La premi�re phase consiste � annoncer le mode d'administration,
    // sous forme d'un COD (ex, "r�aliser une injection par voie IV")
    //
    //
    // Si la date a �t� saisie
    //
    // if (!(Administration.empty()))
    // {
    // 	iterPhraseObj i = Administration.begin();
    //    for (; i != Administration.end(); i++)
    //    	pPhraseur->COD.push_back(new NSPhraseMot((*i)->Objet.pDonnees, pContexte));
    // }
    if (pGenerateur->generePhrase(dcTiret))
    	*sDcodeur() = pGenerateur->getPhrase();
}

NSPhrasePrise::NSPhrasePrise(NSPhrasePrise& rv)
              :NSPhraseObjet(rv.pContexte), Temporalite(rv.pContexte)
{
	Objet       = rv.Objet ;
    iDcType     = rv.iDcType ;

    nbDose	   	= rv.nbDose ;
    ValeurDose  = rv.ValeurDose ;
    ObjetDose   = rv.ObjetDose ;

    Moment      = rv.Moment ;
    Temporalite = rv.Temporalite ;
}

NSPhrasePrise&
NSPhrasePrise::operator=(NSPhrasePrise src)
{
	Objet       = src.Objet ;
    iDcType     = src.iDcType ;

    nbDose	   	= src.nbDose ;
    ValeurDose  = src.ValeurDose ;
    ObjetDose   = src.ObjetDose ;

    Moment      = src.Moment ;
    Temporalite = src.Temporalite ;

    return *this;
}
*/

// -------------------------------------------------------------------------
// ------------------- METHODES DE NSPhraseOrgane --------------------------
// -------------------------------------------------------------------------
NSPhraseOrgane::NSPhraseOrgane(NSContexte* pCtx, int iDecoType, string sLangue)
               :NSPhraseObjet(pCtx, iDecoType, sLangue)
{
}

NSPhraseOrgane::NSPhraseOrgane(decodageBase* pBase, int iDecoType, string sLangue)
               :NSPhraseObjet(pBase, iDecoType, sLangue)
{
}

void
NSPhraseOrgane::decode(int colonne)
{
    int refCol = getCol();

    while ((getCol() > colonne) && iBon())
	{
        // Date
        if 	    (*getSt() == "KCHIR")
        {
            gereDate date(pContexte, sLangue);
            Avance();
            donneDate(refCol, &date);
            if (!(date.estVide()))
            {
/*         	    pGeste->chir_date += date.getDate();
         	    string sMessage, sIntro;
         	    date.donne_date_breve(&sMessage, &sIntro);
				pGeste->chir_date_libelle = " " + sIntro + sMessage; */
            }
        }
        else
            Recupere();
    }
	return;
}

void
NSPhraseOrgane::metPhrase()
{
  NSPathologData Data;

  pPhraseur->initialise() ;
  *sDcodeur() = "" ;
  //
  // La premi�re phase consiste � annoncer l'existence de la l�sion,
  // sous forme d'un COD (ex, "Il existe un polype")
  //
  NSPhraseMot Lesion(Objet.pDonnees, pContexte) ;
  Lesion.setArticle(NSPhraseMot::articleIndefini) ;
  //
  // Dans l'ordre, on d�crit l'aspect, la dimension puis la localisation
  // (ex, "Il existe un polype sessile, de 3 mm, au niveau du sigmo�de"
  //
  /*bool bLesionComplement = false;
  //
  // L'aspect est un compl�ment du nom de la l�sion
  //
  if (!(Aspect.empty()))
    {
        if (!bLesionComplement)
        {
            Lesion.initComplement();
            bLesionComplement = true;
        }
        iterPhraseObj i = Aspect.begin();
        for (; i != Aspect.end(); i++)
        {
            string sLexique = string((*i)->Objet.pDonnees->lexique);
            trouve = pSuper->getDico()->trouvePathologData(&sLexique, &Data);
            if (trouve)
            {
                if (Data.estAdjectif())
                    Lesion.pComplement->adjEpithete.push_back(new NSPhraseMot((NSPathoBaseData*)(*i)->Objet.pDonnees, pContexte));
            }
        }
    } */
    //
    // La dimension est �galement un compl�ment du nom de la l�sion
    //

  //
  // La localisation est compl�ment de lieu de la phrase
  //
  pPhraseur->COD.push_back(new NSPhraseMot(Lesion)) ;
}

NSPhraseOrgane::NSPhraseOrgane(NSPhraseOrgane& rv)
               :NSPhraseObjet(rv.pContexte)
{
	Objet 			= rv.Objet;
    iDcType 		= rv.iDcType;

    Dimensions		= rv.Dimensions;
    Lesions			= rv.Lesions;
    Aspect			= rv.Aspect;

    Temporalite     = rv.Temporalite;
    Garbage         = rv.Garbage;
}

// -------------------------------------------------------------------------
// ------------------- METHODES DE NSPhraseTemporel ------------------------
// -------------------------------------------------------------------------
NSPhraseTemporel::NSPhraseTemporel(NSContexte* pCtx, int iDecoType, string sLangue)
                 :NSPhraseObjet(pCtx, iDecoType, sLangue)
{
}

NSPhraseTemporel::NSPhraseTemporel(decodageBase* pBase, int iDecoType, string sLangue)
                 :NSPhraseObjet(pBase, iDecoType, sLangue)
{
}

void
NSPhraseTemporel::decode(int colonne, bool bMinValue, TIME_EVENT iEvnt)
{
  NSPatPathoInfo PPTinfo ;

  TIME_EVENT iEvntType = iTypeTps ;
  // Forcing
  if (TpsTypeUndefined != iEvnt)
    iEvntType = iEvnt ;

  while ((getCol() > colonne) && iBon())
  {
    //
    PPTinfo = *(*(getitDcode())) ;

    if ((PPTinfo.pDonnees->lexique)[0] == '�')
    {
      if (TpsDate == iEvntType)
      {
        if (bMinValue)
          ValeurMin = PPTinfo ;
        else
          ValeurMax = PPTinfo ;
      }
      else
        ValeurDuree = PPTinfo ;
      Avance();
    }
    else
      Recupere() ;
  }
	return ;
}

void
NSPhraseTemporel::metPhrase()
{
  NSPathologData Data ;

  pPhraseur->initialise() ;

  NSPhraseMot* pMot = new NSPhraseMot(Objet.pDonnees, pContexte) ;

  pPhraseur->COD.push_back(pMot) ;

  NSPhraseMotTime* pDate = new NSPhraseMotTime(pContexte) ;

  strcpy(pDate->formatMin, ValeurMin.pDonnees->lexique) ;
  strcpy(pDate->valeurMin, ValeurMin.pDonnees->complement) ;
  strcpy(pDate->uniteMin,  ValeurMin.pDonnees->unit) ;
  pDate->bMinNow = bMinNow ;

  if (pDate->formatMin[0] != '\0')
    pDate->setFormat(string(pDate->formatMin)) ;

  strcpy(pDate->formatMax, ValeurMax.pDonnees->lexique) ;
  strcpy(pDate->valeurMax, ValeurMax.pDonnees->complement) ;
  strcpy(pDate->uniteMax,  ValeurMax.pDonnees->unit) ;
  pDate->bMaxNow = bMaxNow ;

  if (pDate->formatMax[0] != '\0')
    pDate->setFormat(string(pDate->formatMax)) ;

  pPhraseur->CCTemps.push_back(pDate) ;

  if (pGenerateur->genereProposition(dcTiret))
    *sDcodeur() = pGenerateur->getPropositionPhrase() ;
}

void
NSPhraseTemporel::initPhraseMotTime(NSPhraseMotTime* pPMT)
{
  if (NULL == pPMT)
    return ;

  pPMT->iTypeTps    = iTypeTps ;
  pPMT->iFormeTps   = iFormeTps ;
  pPMT->iRepererTps = iRepererTps ;

  // Min time
  //
  strcpy(pPMT->valeurMin, ValeurMin.getComplement().c_str()) ;
  strcpy(pPMT->uniteMin,  ValeurMin.getUnit().c_str()) ;
  strcpy(pPMT->formatMin, ValeurMin.getLexique().c_str()) ;
  pPMT->bMinNow = bMinNow ;

  //
  // Max time
  //
  strcpy(pPMT->valeurMax, ValeurMax.getComplement().c_str()) ;
  strcpy(pPMT->uniteMax,  ValeurMax.getUnit().c_str()) ;
  strcpy(pPMT->formatMax, ValeurMax.getLexique().c_str()) ;
  pPMT->bMaxNow = bMaxNow ;

  //
  // Dur�e (3 mois...)
  //
  strcpy(pPMT->valeurDuree, ValeurDuree.getComplement().c_str()) ;
  strcpy(pPMT->uniteDuree,  ValeurDuree.getUnit().c_str()) ;
  strcpy(pPMT->formatDuree, ValeurDuree.getLexique().c_str()) ;
}

NSPhraseTemporel::NSPhraseTemporel(NSPhraseTemporel& rv)
				 :NSPhraseObjet(rv.pContexte)
{
	Objet 		= rv.Objet ;
  iDcType 	= rv.iDcType ;

  iTypeTps    = rv.iTypeTps ;
  iFormeTps   = rv.iFormeTps ;
  iRepererTps = rv.iRepererTps ;

  ValeurMin   = rv.ValeurMin ;
  bMinNow     = rv.bMinNow ;

  ValeurMax   = rv.ValeurMax ;
  bMaxNow     = rv.bMaxNow ;
}

NSPhraseTemporel&
NSPhraseTemporel::operator=(NSPhraseTemporel src)
{
  if (&src == this)
    return *this ;

	Objet 		  = src.Objet ;
	iDcType 	  = src.iDcType ;

	iTypeTps    = src.iTypeTps ;
	iFormeTps   = src.iFormeTps ;
	iRepererTps = src.iRepererTps ;

	ValeurMin   = src.ValeurMin ;
	bMinNow     = src.bMinNow ;

	ValeurMax   = src.ValeurMax ;
	bMaxNow     = src.bMaxNow ;

	return *this ;
}

// -------------------------------------------------------------------------
// ------------------- METHODES DE NSPhraseTempoCycle ----------------------
// -------------------------------------------------------------------------
NSPhraseTempoCycle::NSPhraseTempoCycle(NSContexte* pCtx, int iDecoType, string sLangue)
                    :NSPhraseObjet(pCtx, iDecoType, sLangue)
{
}

NSPhraseTempoCycle::NSPhraseTempoCycle(decodageBase* pBase, int iDecoType, string sLangue)
                    :NSPhraseObjet(pBase, iDecoType, sLangue)
{
}

void
NSPhraseTempoCycle::decode(int colonne)
{
	int refCol = getCol() ;

	NSPatPathoInfo PPTinfo ;

	while ((getCol() > colonne) && iBon())
	{
		// Dur�e de l'�v�nement
    //
    if      (*getSt() == "KDURA")
    {
    	Avance() ;

      while ((getCol() > refCol) && iBon())
      {
      	PPTinfo = *(*(getitDcode())) ;
        if ((PPTinfo.pDonnees->lexique)[0] == '�')
        {
        	eventDuration = PPTinfo ;
          Avance() ;
        }
        else
        	Recupere() ;
      }
    }
    // Dur�e du cycle
    //
    else if (*getSt() == "KDURC")
    {
    	Avance() ;

      while ((getCol() > refCol) && iBon())
      {
      	PPTinfo = *(*(getitDcode())) ;

        if ((PPTinfo.pDonnees->lexique)[0] == '�')
        {
        	cycleDuration = PPTinfo ;
          Avance() ;
        }
        else
        	Recupere() ;
      }
    }
    else if (*getSt() == "VAINC")
    {
    	Avance() ;

      while ((getCol() > refCol) && iBon())
      {
        PPTinfo = *(*(getitDcode())) ;
        gereNum numNbEvent(pContexte, sLangue) ;
        NSPatPathoInfo nbEventInfo ;
        donneDimension(refCol, &numNbEvent) ;

        if ((iBon()) && (numNbEvent.getUnite() == "2FOIS1"))
            iEventNb = int(numNbEvent.getValeur()) ;

        /*
        if ((PPTinfo.pDonnees->lexique)[0] == '�')
        {
            nbEventInfo = PPTinfo ;
            Avance() ;
        }
        else
            Recupere() ;

        string sEventCplmt  = nbEventInfo.getComplement() ;
        string sEventUnit   = nbEventInfo.getUnit() ;
        string sEventFrmt   = nbEventInfo.getLexique() ;
        numNbEvent.instancier(&sEventCplmt, &sEventUnit, &sEventFrmt) ;
        */
      }
    }
    else
    	Recupere() ;
	}
	return ;
}

void
NSPhraseTempoCycle::metPhrase()
{
    NSPathologData Data ;

    pPhraseur->initialise() ;

    if (pGenerateur->genereProposition(dcTiret))
        *sDcodeur() = pGenerateur->getPropositionPhrase() ;
}

void
NSPhraseTempoCycle::initCycle(NSPhraseMotTimeCycle* pCycle)
{
	if (!pCycle)
		return ;

	if (iTypeCycle == Regulier)
		pCycle->iCycleType = NSPhraseMotTimeCycle::CycRegular ;
	if (iTypeCycle == Libre)
		pCycle->iCycleType = NSPhraseMotTimeCycle::CycFree ;

	strcpy(pCycle->cycleDurationValue,   cycleDuration.pDonnees->complement) ;
	strcpy(pCycle->cycleDurationFormat,  cycleDuration.pDonnees->lexique) ;
	strcpy(pCycle->cycleDurationUnit,    cycleDuration.pDonnees->unit) ;

	strcpy(pCycle->actionDurationValue,  eventDuration.pDonnees->complement) ;
	strcpy(pCycle->actionDurationFormat, eventDuration.pDonnees->lexique) ;
	strcpy(pCycle->actionDurationUnit,   eventDuration.pDonnees->unit) ;

	itoa(iEventNb, pCycle->numberOfAction, 10) ;
}

bool
NSPhraseTempoCycle::estVide()
{
	if ((eventDuration.pDonnees->lexique[0] == '\0') &&
      (cycleDuration.pDonnees->lexique[0] == '\0'))
		return true ;
	return false ;
}

NSPhraseTempoCycle::NSPhraseTempoCycle(NSPhraseTempoCycle& rv)
                    :NSPhraseObjet(rv.pContexte)
{
	Objet 		        = rv.Objet ;
    iDcType 	        = rv.iDcType ;

    iTypeCycle          = rv.iTypeCycle ;

    eventDuration       = rv.eventDuration ;
    cycleDuration       = rv.cycleDuration ;
    iEventNb            = rv.iEventNb ;
}

NSPhraseTempoCycle&
NSPhraseTempoCycle::operator=(NSPhraseTempoCycle src)
{
	Objet 		        = src.Objet;
    iDcType 	        = src.iDcType;

    iTypeCycle          = src.iTypeCycle ;

    eventDuration       = src.eventDuration ;
    cycleDuration       = src.cycleDuration ;
    iEventNb            = src.iEventNb ;

    return *this;
}

// -------------------------------------------------------------------------
// ------------------- METHODES DE NSPhraseBiometrie -----------------------
// -------------------------------------------------------------------------
NSPhraseBiometrie::NSPhraseBiometrie(NSContexte* pCtx, int iDecoType, string sLangue)
                  :NSPhraseObjet(pCtx, iDecoType, sLangue)
{
}

NSPhraseBiometrie::NSPhraseBiometrie(decodageBase* pBase, int iDecoType, string sLangue)
                  :NSPhraseObjet(pBase, iDecoType, sLangue)
{
}

void
NSPhraseBiometrie::decode(int colonne)
{
    NSPatPathoInfo PPTinfo;

    while ((getCol() > colonne) && iBon())
	{
        //
    	PPTinfo = *(*(getitDcode()));

        if ((PPTinfo.pDonnees->lexique)[0] == '�')
        {
            Valeur = PPTinfo;
            Avance();
        }
        else
        	Recupere();
    }
	return;
}

void
NSPhraseBiometrie::metPhrase()
{
  *sDcodeur() = "" ;

  NSPathologData Data ;

  pPhraseur->initialise() ;

  NSPhraseMot* pMot = new NSPhraseMot(Objet.pDonnees, pContexte) ;
  pMot->setComplement(string(Valeur.pDonnees->complement)) ;
  pMot->setFormat(string(Valeur.pDonnees->lexique)) ;
  pMot->setUnite(Valeur.getUnit()) ;
  pMot->setNumForme(NSPhraseMot::numTiret) ;

  pPhraseur->CCChiffre.push_back(pMot) ;

  if (pGenerateur->genereProposition(dcTiret))
    *sDcodeur() = pGenerateur->getPropositionPhrase() ;
}

NSPhraseBiometrie::NSPhraseBiometrie(NSPhraseBiometrie& rv)
				  :NSPhraseObjet(rv.pContexte)
{
	Objet 		 = rv.Objet;
    iDcType 	 = rv.iDcType;

    Valeur       = rv.Valeur;
    Normales     = rv.Normales;

    Methode      = rv.Methode;
    Localisation = rv.Localisation;

    Temporalite  = rv.Temporalite;
    Garbage      = rv.Garbage;
}

NSPhraseBiometrie&
NSPhraseBiometrie::operator=(NSPhraseBiometrie src)
{
	Objet 		 = src.Objet;
    iDcType 	 = src.iDcType;

    Valeur       = src.Valeur;
    Normales     = src.Normales;

    Methode      = src.Methode;
    Localisation = src.Localisation;

    Temporalite  = src.Temporalite;
    Garbage      = src.Garbage;

    return *this;
}

// *************************************************************************
// -------------------- METHODES DE NSPhraseObjArray -----------------------
// *************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSPhraseObjArray::NSPhraseObjArray(NSPhraseObjArray& rv)
                 :NSPhraObjArray()
{
try
{
	if (!(empty()))
		for (iterPhraseObj i = rv.begin(); i != rv.end();i++)
			push_back(new NSPhraseObjet(*(*i))) ;
}
catch (...)
{
	erreur("Exception NSPhraseObjArray copy ctor", standardError, 0);
}
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSPhraseObjArray::vider()
{
    if (empty())
        return ;

    for (iterPhraseObj i = begin(); i != end(); )
    {
   	    delete *i ;
        erase(i) ;
    }
}

NSPhraseObjArray::~NSPhraseObjArray()
{
    vider() ;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSPhraseObjArray&
NSPhraseObjArray::operator=(NSPhraseObjArray src)
{
try
{
	if (this == &src)
  	return *this ;

	//
  // Effacement des �l�ments d�j� contenus dans le vecteur destination
  //
  vider() ;
	//
  // Copie et insertion des �l�ments de la source
  //
	if (!(empty()))
  	for (iterPhraseObj i = src.begin(); i != src.end(); i++)
    	push_back(new NSPhraseObjet(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception NSPhraseObjArray = operator", standardError, 0) ;
	return *this ;
}
}

