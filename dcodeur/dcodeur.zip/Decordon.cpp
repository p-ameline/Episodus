#ifdef _CSK
  #include "partage\Nsglobal.h"
  #include "nsbb\nsutidlg.h"
#endif

#include "partage\nsdivfct.h"
#include "partage\nscim10.h"
#include "nssavoir\nsfilgd.h"
#include "dcodeur\decordon.h"
#include "nssavoir\nsguide.h"

//  +-----------------------------------------------------------------+
//  �               D�code la prescription m�dicamenteuse             �
//  +-----------------------------------------------------------------+
//  Cr�� le 14/11/1988 Derni�re mise � jour 23/08/1989
decodeMedicament::decodeMedicament(NSContexte* pCtx, string sLangue)
                 :decodageBase(pCtx, sLangue)
{
	pAdministration = new decodeMediAdmin(this) ;
	pDose           = new gereNum(pContexte, sLangue) ;
	sUniteAnthropo  = "" ;
	sMedicament     = "" ;
}

decodeMedicament::decodeMedicament(decodageBase* pBase)
                 :decodageBase(pBase)
{
  pAdministration = new decodeMediAdmin(this) ;
  pDose           = new gereNum(pContexte, sLangue) ;
  sUniteAnthropo  = "" ;
  sMedicament     = "" ;
}

decodeMedicament::~decodeMedicament()
{
	delete pAdministration ;
  delete pDose ;
}

void
decodeMedicament::decode(int colonne)
{
	int refCol = getCol() ;
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	while ((getCol() > colonne) && iBon())
	{
    if      (*getSt() == "GADMI")
    {
    	Avance() ;
      pAdministration->decode(refCol) ;
    }
    else if (*getSt() == "VDOSM")
    {
    	Avance() ;
      donneDimension(refCol, pDose) ;
    }
    else if (*getSt() == "0UNAN")
    {
    	Avance() ;
      pSuper->getDico()->donneLibelle(sLangue, getSt(), &sUniteAnthropo) ;
      Avance() ;
    }
    else
    	Recupere() ;
	}
}

void
decodeMedicament::donnePhrase()
{
	*sDcodeur() = "" ;

	if (!(pDose->estVide()))
	{
  	*sDcodeur() = pDose->getNum("") + " " + pDose->donneLibelleUnite() ;
    if (CommenceParVoyelle(&sMedicament))
    	*sDcodeur() += " d'" ;
    else
    	*sDcodeur() += " de " ;
	}
	*sDcodeur() += sMedicament ;

	if (sUniteAnthropo != "")
		*sDcodeur() += " par " + sUniteAnthropo ;
}

//  +-----------------------------------------------------------------+
//  �               D�code l'administration m�dicamenteuse            �
//  +-----------------------------------------------------------------+
//  Cr�� le 14/11/1988 Derni�re mise � jour 23/08/1989
decodeMediAdmin::decodeMediAdmin(NSContexte* pCtx, string sLangue)
                :decodageBase(pCtx, sLangue)
{
   voieAdmin = "";
   lieuAdmin = "";
}

decodeMediAdmin::decodeMediAdmin(decodageBase* pBase)
                :decodageBase(pBase)
{
   voieAdmin = "";
   lieuAdmin = "";
}

void
decodeMediAdmin::decode(int colonne)
{
    int refCol = getCol();
    NSSuper* pSuper = pContexte->getSuperviseur();

  	while ((getCol() > colonne) && iBon())
    {
        if      (*getSt() == "0VADM")
        {
      	    Avance();

            string 	sLabel1, sLabel2;
            sLabel1 = sLabel2 = "";

	        while ((getCol() > refCol) && iBon())
	        {
   	            pSuper->getDico()->donneLibelle(sLangue, getStL(), &sLabel2);
   	            Avance();
                etDuMilieu(&voieAdmin, &sLabel1, &sLabel2, ", ");
            }
            etFinal(&voieAdmin, &sLabel1, " et ");
        }
        else if (*getSt() == "0LOCA")
        {
      	    Avance();

            string 	sLabel1, sLabel2;
            sLabel1 = sLabel2 = "";

	        while ((getCol() > refCol) && iBon())
	        {
   	            pSuper->getDico()->donneLibelle(sLangue, getStL(), &sLabel2);
   	            Avance();
                etDuMilieu(&lieuAdmin, &sLabel1, &sLabel2, ", ");
            }
            etFinal(&lieuAdmin, &sLabel1, " et ");
        }
        else
            Recupere();
    }
}

