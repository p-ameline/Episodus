#include "partage\nsdivfct.h"
#include "partage\nscim10.h"
#include "partage\nsmatfic.h"
#include "nssavoir\nsfilgd.h"
#include "dcodeur\decoder.h"
#include "nssavoir\nsguide.h"
#include "dcodeur\nsphrase.h"
#include "dcodeur\nsphrobj.h"
#include "dcodeur\nsgenlan.h"

GlobalDkd::GlobalDkd(NSContexte* pCtx, string langue, string sChem,
                     NSPatPathoArray* pSPP, ClasseStringVector* pCSV)
          :decodageBase(pCtx, langue)
{
  sChemin       = sChem ;
  pSousPatPatho = pSPP ;
  pVect         = pCSV ;

  sLangue       = langue ;
}

bool
GlobalDkd::decode(int precision)
{
  setPPtArray(pSousPatPatho) ;

  if (decodeSpecifique(precision))
    return true ;

  return decodeGenerique(precision) ;
}

bool
GlobalDkd::decodeSpecifique(int precision)
{
  if (pSousPatPatho->empty())
    return false;

  string sTexte = "";
  char   cTexte[256];

  NSSuper* pSuper = pContexte->getSuperviseur();
  if (sLangue == "fr")
  {
        sTexte = "D�but du d�codage sp�cifique";
    }
    else if (sLangue == "en")
    {
        sTexte = "Starting specific langage generation";
    }
    strcpy(cTexte, sTexte.c_str());
    pSuper->afficheStatusMessage(cTexte);

    // Fabrication du vecteur des "fils" � chercher (sur le mod�le des
    // fils guides) ; ici il est r�duit � un seul �l�ment : la racine de
    // pSousPatPatho
    //
    VecteurRechercheSelonCritere* pVecteurSelonCritere =
                                    new VecteurRechercheSelonCritere(DECODE);
    //
    // Recherche de l'Etiquette de la racine de pSousPatPatho
    //
    // On traite le cas simple d'un �l�ment seul sur sa ligne
    //
    PatPathoIter i = pSousPatPatho->begin();
    string sEtiquette = string((*i)->pDonnees->lexique);
    string sPluriel   = string((*i)->pDonnees->pluriel);
    string sCertitude = string((*i)->pDonnees->certitude);

    if (!(sPluriel == string("")))
        sEtiquette += string(1, cheminSeparationMARK) + sPluriel;

    if (!(sCertitude == string("")))
        sEtiquette += string(1, cheminSeparationMARK) + sCertitude;
    //
    // On ajoute l'Etiquette au vecteur de recherche
    //
    string sCodeSens;
    pSuper->getDico()->donneCodeSens(&sEtiquette, &sCodeSens);
    pVecteurSelonCritere->AjouteEtiquette(sCodeSens);
    //
    // Recherche d'un d�codage compatible
    //
    if (sLangue == "fr")
    {
        sTexte = "Recherche du chemin";
    }
    else if (sLangue == "en")
    {
        sTexte = "Searching path";
    }
    strcpy(cTexte, sTexte.c_str());
    pSuper->afficheStatusMessage(cTexte);
    pSuper->getFilDecode()->chercheChemin(&sChemin,
                             pVecteurSelonCritere, NSFilGuide::compReseau);
    //
    bool trouve;
    BBDecodeData decodageData;

    pVecteurSelonCritere->SetData(sCodeSens, &trouve, &decodageData);

    delete pVecteurSelonCritere;

    if (!trouve)
        return false;

    //
    // Ouverture de la DLL de d�codage
    //
    if (sLangue == "fr")
    {
        sTexte = "Ouverture de la DLL";
    }
    else if (sLangue == "en")
    {
        sTexte = "DLL opening";
    }
    strcpy(cTexte, sTexte.c_str());
    pSuper->afficheStatusMessage(cTexte);
    string sLib      = string(decodageData.fichier);
    string sFonction = string(decodageData.nomFonction);
    if ((sLib == "") || (sFonction == ""))
        return false;

    string sNomDLL = sLib + string(".DLL");
    TModule* pDCModule = new TModule(sNomDLL.c_str(), true);
    if (!pDCModule)
    {
        if (sLangue == "fr")
        {
            sTexte = "La DLL sp�cifique est introuvable (" + sNomDLL + ")";
        }
        else if (sLangue == "en")
        {
            sTexte = "Unable to open DLL (" + sNomDLL + ")";
        }
        erreur(sTexte.c_str(), standardError, -1);
        return false;
    }

    //
    // Pr�paration des param�tres de d�codage
    //
    bool (FAR *pAdresseFct) (char, NSPatPathoArray far *, char far *,
                             NSContexte far *, NSCRPhraseArray far *,
                             string far *, int);

    (FARPROC) pAdresseFct = pDCModule->GetProcAddress(MAKEINTRESOURCE(2));
    if (!pAdresseFct)
    {
        if (sLangue == "fr")
        {
            sTexte = "La DLL sp�cifique est endommag�e (" + sNomDLL + ")";
        }
        else if (sLangue == "en")
        {
            sTexte = "Damaged DLL (" + sNomDLL + ")";
        }
        erreur(sTexte.c_str(), standardError, -1);
        delete pDCModule;
        return false;
    }

    if (sLangue == "fr")
    {
        sTexte = "Elaboration du texte";
    }
    else if (sLangue == "en")
    {
        sTexte = "Text elaboration";
    }
    strcpy(cTexte, sTexte.c_str());
    pSuper->afficheStatusMessage(cTexte);

    NSCRPhraseArray* pPhrasesDecode = new NSCRPhraseArray();

    bool Reussi = ((*pAdresseFct)
                   (' ',
                   (NSPatPathoArray far *) pSousPatPatho,
                   /*(char far *) sFichDecod.c_str()*/ "",
                   (NSContexte far *) pContexte,
                   (NSCRPhraseArray far *) pPhrasesDecode,
                   (string far *) &sFonction,
                   precision)
         		   );

    delete pDCModule;

    if (!Reussi)
    {
        delete pPhrasesDecode;
        return false;
    }

    //
    // Remplissage de pVect avec le contenu de pPhrases
    //
    if (pPhrasesDecode->empty())
    {
        delete pPhrasesDecode;
        return false;
    }

    //
    // Recopie des phrases du d�codeur dans pNoyau->pPhrases
    //
    NSCRPhraseArray* pPhrases = getPhA();

    if (pPhrases == 0)
    {
        pPhrases = new NSCRPhraseArray();
        setPhA(pPhrases);
    }

    *pPhrases = *pPhrasesDecode;

    *sDcodeur() = ((*pPhrases)[0])->sTexte;

    if (sLangue == "fr")
    {
        sTexte = "D�codage termin�";
    }
    else if (sLangue == "en")
    {
        sTexte = "Text elaborated";
    }
    strcpy(cTexte, sTexte.c_str());
    pSuper->afficheStatusMessage(cTexte);

    delete pPhrasesDecode;
    return true;
}

bool
GlobalDkd::decodeGenerique(int precision)
{
  setPPtArray(pSousPatPatho) ;
  initialiseIterateurs() ;

  int refCol = getCol() ;
  *sDcodeur() = "" ;

  if (refCol == -1)
    return true ;

// -------------------------------------------------
// VERSION EXPERIMENTALE
// -------------------------------------------------

  while ((getCol() >= refCol) && iBon())
  {
    if 	    ((*getSt())[0] == 'G')
    {
      NSPhraseGeste* pGeste = new NSPhraseGeste(this, precision, sLangue) ;
      pGeste->ammorce();
      Avance();
      pGeste->decode(refCol);
      if (iBon())
        pGeste->metPhrase();
      delete pGeste;
      if (iBon())
        return true;
    }
    else if ((*getSt())[0] == 'A')
    {
      NSPhraseOrgane* pOrga = new NSPhraseOrgane(this, precision, sLangue) ;
      pOrga->ammorce() ;
      Avance() ;
      pOrga->decode(refCol) ;
      if (iBon())
        pOrga->metPhrase() ;
      delete pOrga ;
      if (iBon())
        return true ;
    }
    else if (((*getSt())[0] == 'P') || ((*getSt())[0] == 'S'))
    {
      NSPhraseLesion* pLesi = new NSPhraseLesion(this, precision, sLangue) ;
      pLesi->ammorce() ;
      Avance() ;
      pLesi->decode(refCol) ;
      if (iBon())
        pLesi->metPhrase() ;
      delete pLesi ;
      if (iBon())
        return true ;
    }
    else if ((*getSt())[0] == 'V')
    {
      NSPhraseBiometrie* pChif = new NSPhraseBiometrie(this, precision, sLangue) ;
      pChif->ammorce() ;
      Avance() ;
      pChif->decode(refCol) ;
      if (iBon())
        pChif->metPhrase() ;
      delete pChif ;
      if (iBon())
        return true ;
    }
    else if ((*getSt())[0] == 'K')
    {
      NSPhraseTemporel* pTemp = new NSPhraseTemporel(this, precision, sLangue) ;
      pTemp->ammorce() ;
      Avance() ;
      pTemp->decode(refCol) ;
      if (iBon())
        pTemp->metPhrase() ;
      delete pTemp ;
      if (iBon())
        return true ;
    }
    else
      break ;
  }

	initialiseIterateurs() ;

// -------------------------------------------------
// FIN VERSION EXPERIMENTALE
// -------------------------------------------------

  string sCode = *(getStL()) ;
  //
  // Si c'est un texte libre, on arr�te tout
  //
  if (sCode[0] == '#')
  {
    *sDcodeur() = "..." ;
    return true ;
  }
  //
  // Fabrication du r�seau de lots
  //
  lot* pLot = new lot(pContexte) ;
  assembleLots(-1, pLot) ;
  decodeLots(pLot, "", genreMS) ;
  delete pLot ;
  return true ;
}

void
GlobalDkd::assembleLots(int colonne, lot* pLotPere)
{
  if (NULL == pLotPere)
    return ;

  string sLibelle = string("") ;

  set_iBon(1) ;

  int          refCol = getCol() ;

  while ((getCol() > colonne) && iBon())
  {
    //
    // On met dans sTemp, l'ensemble des �l�ments d'une m�me ligne
    //
    //
    // On synchronise itDcodeTemp avec itDcode
    //
    PatPathoIter itDcodeTemp = getPPtArray()->begin() ;
    while ((getPPtArray()->end() != itDcodeTemp) &&
           (strcmp((*itDcodeTemp)->pDonnees->codeLocalisation, (*(getitDcode()))->pDonnees->codeLocalisation) != 0))
      itDcodeTemp++ ;

    if (getPPtArray()->end() == itDcodeTemp)
      return ;

    //
    // On remplit sTemp
    //
    string sTemp = (*itDcodeTemp)->getNodeLabel() ;
    //
    // Si c'est un texte libre, on arr�te tout
    //
    string sCode = *(getStL()) ;
    if ((sCode == "�?????") || (sCode[0] == '#'))
      return ;

    string sLibelle = "" ;
    //
    // On regarde si c'est une valeur num�rique
    //
    gereNum num(pContexte, sLangue) ;
    donneDimension(refCol-1, &num) ;
    if (iBon())
    {
      decodeNum(&sLibelle, &num) ;
      pLotPere->ajouteValeurChiffree(sLibelle) ;
    }
    else
    {
      set_iBon(1) ;
      //
      // On regarde si c'est une date
      //
      gereDate date(pContexte, sLangue) ;
      donneDate(refCol-1, &date) ;
      if (iBon())
      {
        decodeDate(&sLibelle, &date) ;
        pLotPere->ajouteDate(sLibelle) ;
      }
      else
      {
        set_iBon(1) ;
        //
        // On regarde si c'est une heure
        //
        gereHeure heure(pContexte, sLangue) ;
        donneHeure(refCol-1, &heure) ;
        if (iBon())
        {
          decodeHeure(&sLibelle, &heure) ;
          pLotPere->ajouteHeure(sLibelle) ;
        }
        else
        {
          set_iBon(1);
          refCol = getCol();
          LotIter itLot;
          //
          // Si ce n'est ni une date, ni une heure, ni une valeur
          // chiffr�e, on classe en fonction du type
          //
          switch (sTemp[0])
          {
            // Connecteur
            case '0' :
              pLotPere->pLotsLies->push_back(new lot(pContexte)) ;
              itLot = pLotPere->pLotsLies->end() ;
              itLot-- ;
              (*itLot)->setLotPere(pLotPere) ;
              //(*itLot)->setConnection(sTemp);
              (*itLot)->setObjet(sTemp) ;
              Avance() ;
              assembleLots(refCol, *itLot) ;
              break ;
              // L�sion ou symptome ou malformation
              case 'S' :
              case 'P' :
              case 'F' :
              // Localisation anatomique
              case 'A' :
              // Geste ou traitement
              case 'G' :
              case 'N' :
                Avance() ;
                if (pLotPere->donneObjet() == "")
                {
                  pLotPere->setObjet(sTemp) ;
                  assembleLots(refCol, pLotPere) ;
                }
                else
                {
                  pLotPere->pLotsLies->push_back(new lot(pContexte)) ;
                  itLot = pLotPere->pLotsLies->end() ;
                  itLot-- ;
                  (*itLot)->setLotPere(pLotPere) ;
                  (*itLot)->setObjet(sTemp) ;
                  assembleLots(refCol, *itLot) ;
                }
                break ;
              default :
                Avance() ;

                size_t posit1 = sTemp.find(string(1, cheminSeparationMARK)) ;
                size_t posit2 = sTemp.find(string(1, nodeSeparationMARK)) ;
                size_t posit = min(posit1, posit2) ;
                string sLexique = string(sTemp, 0, posit) ;

                NSSuper* pSuper = pContexte->getSuperviseur();
                NSPathologData* pData = new NSPathologData;
                bool trouve = pSuper->getDico()->trouvePathologData(sLangue, &sLexique, pData);
                // Si le mot est un adjectif
                if ((pData->estNom()) || (pData->estVerbe()))
                {
                  pLotPere->pLotsLies->push_back(new lot(pContexte)) ;
                  itLot = pLotPere->pLotsLies->end() ;
                  itLot-- ;
                  (*itLot)->setLotPere(pLotPere) ;
                  (*itLot)->setObjet(sTemp) ;
                  assembleLots(refCol, *itLot) ;
                }
                else if (pData->estInvariable())
                {
                  pLotPere->pLotsLies->push_back(new lot(pContexte)) ;
                  itLot = pLotPere->pLotsLies->end() ;
                  itLot-- ;
                  (*itLot)->setLotPere(pLotPere) ;
                  (*itLot)->setConnection(sTemp) ;
                  assembleLots(refCol, *itLot) ;
                }
                else
                {
                  pLotPere->ajouteQualifiant(sTemp) ;
                  assembleLots(refCol, pLotPere) ;
                }
                break ;
          }
        }
      }
    }
  }
}

void
GlobalDkd::decodeLots(lot* pLot, string sObjetMaitre, int iGenreMaitre)
{
    int     iNewGenreMaitre = iGenreMaitre;
    string  sNewObjetMaitre = sObjetMaitre;

    string sConnect;
    int iGenreConnect, iCertConnect;
    if (pLot->sConnection != "")
    {
        if (sObjetMaitre != "")
            sConnect = decodeMot(&(pLot->sConnection), iGenreMaitre, &iGenreConnect, &iCertConnect);
        else
            sConnect = decodeMot(&(pLot->sConnection), 1, &iGenreConnect, &iCertConnect);
        if (*sDcodeur() != "")
            *sDcodeur() += " ";
        *sDcodeur() += sConnect;
    }

    string sObj;
    int iGenreObj, iCertObj;
    if (pLot->sObjet != "")
    {
        sObj = decodeMot(&(pLot->sObjet), 1, &iGenreObj, &iCertObj);
        if (*sDcodeur() != "")
            *sDcodeur() += " ";
        *sDcodeur() += sObj;
        if (iGenreObj != -1)
        {
            iNewGenreMaitre = iGenreObj;
            sNewObjetMaitre = sObj;
        }
    }

    string sQualif;
    if (pLot->sQualifiant != "")
    {
        sQualif = decodeGroupe(&(pLot->sQualifiant), iNewGenreMaitre);
        if (*sDcodeur() != "")
            *sDcodeur() += " ";
        *sDcodeur() += sQualif;
    }

    string sChiffres;
    if (pLot->sValeurChiffree != "")
    {
        sChiffres = decodeGroupeDecode(&(pLot->sValeurChiffree), iNewGenreMaitre);
        if (*sDcodeur() != "")
            *sDcodeur() += " ";
        *sDcodeur() += sChiffres;
    }

    string sDates;
    if (pLot->sDate != "")
    {
        sDates = decodeGroupeDecode(&(pLot->sDate), iNewGenreMaitre);
        if (*sDcodeur() != "")
            *sDcodeur() += " ";
        *sDcodeur() += sDates;
    }

    string sHeures;
    if (pLot->sHeure != "")
    {
        sHeures = decodeGroupeDecode(&(pLot->sHeure), iNewGenreMaitre);
        if (*sDcodeur() != "")
            *sDcodeur() += " ";
        *sDcodeur() += sHeures;
    }

    // Traitement des lots li�s
    if (!(pLot->pLotsLies->empty()))
    {
        for (LotIter i = pLot->pLotsLies->begin(); i != pLot->pLotsLies->end(); i++)
            decodeLots(*i, sNewObjetMaitre, iNewGenreMaitre);
    }
}

string
GlobalDkd::decodeMot(string* pCode, int iGenre, int* iGenreMot, int* iCertMot)
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	string sLexique    = "" ;
  string sComplement = "" ;
  string sPluriel    = "" ;
  string sCertitude  = "" ;

	//
  // S�paration de la chaine en ses 4 composants
  //

  string sousChaine ;
	int    iIndex = 0 ;

  size_t debut = 0 ;
  size_t fin   = pCode->find(string(1, intranodeSeparationMARK)) ;

	while (fin != NPOS)
  {
  	if (fin > debut)
    	sousChaine = string(*pCode, debut, fin - debut) ;
    else
    	sousChaine = "" ;

    if      ((strlen(sousChaine.c_str()) > 3) && (string(sousChaine, 0, 3) == string("WCE")))
      sCertitude = sousChaine ;
    else if ((strlen(sousChaine.c_str()) > 4) && (string(sousChaine, 0, 4) == string("WPLU")))
      sPluriel = sousChaine ;
    else if ((strlen(sousChaine.c_str()) > 1) && (string(sousChaine, 0, 4) == string("$")))
      sComplement = sousChaine ;
    else
    {
      switch (iIndex)
      {
    	  case 0 : sLexique    = sousChaine; break;
        case 1 : sComplement = sousChaine; break;
        case 2 : sPluriel    = sousChaine; break;
        case 3 : sCertitude  = sousChaine; break;
      }
    }
    iIndex++ ;
    debut = fin + 1 ;
    fin   = pCode->find(string(1, intranodeSeparationMARK), debut) ;
  }

  size_t iTaille = strlen(pCode->c_str());
  if (iTaille > debut)
  	sousChaine = string(*pCode, debut, iTaille - debut) ;
  else
  	sousChaine = "" ;

  if      ((strlen(sousChaine.c_str()) > 3) && (string(sousChaine, 0, 3) == string("WCE")))
    sCertitude = sousChaine ;
  else if ((strlen(sousChaine.c_str()) > 4) && (string(sousChaine, 0, 4) == string("WPLU")))
    sPluriel = sousChaine ;
  else if ((strlen(sousChaine.c_str()) > 1) && (string(sousChaine, 0, 4) == string("$")))
    sComplement = sousChaine ;
  else
  {
    switch (iIndex)
    {
  	  case 0 : sLexique    = sousChaine; break;
      case 1 : sComplement = sousChaine; break;
      case 2 : sPluriel    = sousChaine; break;
      case 3 : sCertitude  = sousChaine; break;
    }
  }

  //
  // Elaboration du mot
  //
  NSPathologData Data ;
  bool trouve = pSuper->getDico()->trouvePathologData(sLangue, &sLexique, &Data) ;
  if (!trouve)
  	return string("") ;

  string sLabel = "" ;
  //
  // Si le mot est un adjectif
  //
  if (Data.estAdjectif())
  {
  	pGenerateur->donneLibelleAffiche(&sLabel, &Data, iGenre) ;
    //
    // Gestion de la certitude
    //
    int iCert = donneCertitude(sCertitude) ;
    sLabel = donneLibelleAdjectif(sLabel, iCert) ;

    *iGenreMot = -1 ;
    *iCertMot  = -1 ;

    return sLabel ;
  }
  //
  // Si le mot est un nom
  //
  if (Data.estNom())
  {
  	int iGenreNom ;
    Data.donneGenre(&iGenreNom) ;
    if (sPluriel != "")
    	Data.donneGenrePluriel(&iGenreNom) ;
    pGenerateur->donneLibelleAffiche(&sLabel, &Data, iGenreNom) ;
    *iGenreMot = iGenreNom ;
    //
    // Gestion de la certitude
    //
    int iCert = donneCertitude(sCertitude) ;
    sLabel = donneLibelleNom(sLabel, iCert) ;
    *iCertMot = iCert ;
    return sLabel ;
  }

  pGenerateur->donneLibelleAffiche(&sLabel, &Data, iGenre) ;

  *iGenreMot = -1 ;
  *iCertMot  = -1 ;

	return sLabel ;
}

string
GlobalDkd::decodeGroupe(string* pCode, int iGenre)
{
    string sLabel = "";
    string sLab1  = "";
    string sLab2  = "";
    int iGen, iCer;

    string sousChaine;
    size_t debut = 0;
    size_t fin   = pCode->find("||");

    while (fin != NPOS)
    {
        if (fin > debut)
            sousChaine = string(*pCode, debut, fin - debut);
        else
            sousChaine = "";

        sLab2 = decodeMot(&sousChaine, iGenre, &iGen, &iCer);
        etDuMilieu(&sLabel, &sLab1, &sLab2, ", ");

        debut = fin + 2;
        fin   = pCode->find("||", debut);
    }

    size_t iTaille = strlen(pCode->c_str());
    if (iTaille > debut)
        sousChaine = string(*pCode, debut, iTaille - debut);
    else
        sousChaine = "";

    sLab2 = decodeMot(&sousChaine, iGenre, &iGen, &iCer);
    etDuMilieu(&sLabel, &sLab1, &sLab2, ", ");

    etFinal(&sLabel, &sLab1, " et ");
    return sLabel;
}

string
GlobalDkd::decodeGroupeDecode(string* pCode, int iGenre)
{
    string sLabel = "";
    string sLab1  = "";
    string sLab2  = "";

    string sousChaine;
    size_t debut = 0;
    size_t fin   = pCode->find("|");

    while (fin != NPOS)
    {
        if (fin > debut)
            sLab2 = string(*pCode, debut, fin - debut);
        else
            sLab2 = "";

        etDuMilieu(&sLabel, &sLab1, &sLab2, ", ");

        debut = fin + 1;
        fin   = pCode->find("|", debut);
    }

    size_t iTaille = strlen(pCode->c_str());
    if (iTaille > debut)
        sLab2 = string(*pCode, debut, iTaille - debut);
    else
        sLab2 = "";

    etDuMilieu(&sLabel, &sLab1, &sLab2, ", ");

    etFinal(&sLabel, &sLab1, " et ");
    return sLabel;
}

bool
GlobalDkd::decodeNum(string* sLibelle, gereNum* pNum)
{
	if ((pNum->estExact()) || (pNum->estInf()) || (pNum->estSup()))
  {
  	bool bPluriel = false ;

    if (pNum->estExact())
    {
    	*sLibelle = pNum->getNum("") ;
      if (pNum->getValeur() > 1)
      	bPluriel = true ;
    }
        else
        {
            if ((pNum->estInf()) && (pNum->estSup()))
            {
                if (sLangue == "fr")
                {
                    *sLibelle = "entre " + pNum->getNumInf() + " et " + pNum->getNumSup();
                }
                else if (sLangue == "en")
                {
                    *sLibelle = "between " + pNum->getNumInf() + " and " + pNum->getNumSup();
                }
            }
            else if (pNum->estInf())
            {
                if (sLangue == "fr")
                {
                    *sLibelle = "plus de " + pNum->getNumInf();
                }
                else if (sLangue == "en")
                {
                    *sLibelle = "more than " + pNum->getNumInf();
                }
            }
            else if (pNum->estSup())
            {
                if (sLangue == "fr")
                {
                    *sLibelle = "moins de " + pNum->getNumSup();
                }
                else if (sLangue == "en")
                {
                    *sLibelle = "less than " + pNum->getNumSup();
                }
            }
            if ((pNum->getValeurInf() > 1) || (pNum->getValeurSup() > 1))
                bPluriel = true;
        }
        //
        // Libell� de l'unit� de l'unit�
        //
        if (*sLibelle != "")
        {
            string sUniteLibel = pNum->donneLibelleUnite();

            if (sUniteLibel != "")
                *sLibelle += string(" ") + sUniteLibel;
        }
    }
    return true ;
}

bool
GlobalDkd::decodeDate(string* sLibelle, gereDate* pDate)
{
    string sMessage, sIntro;
    pDate->donne_date_breve(&sMessage, &sIntro);
    *sLibelle = sIntro + sMessage;
    return true ;
}

bool
GlobalDkd::decodeHeure(string* sLibelle, gereHeure* pHeure)
{
    string sMessage;
    pHeure->donne_heure(&sMessage);
    *sLibelle = sMessage;
    return true ;
}

//
// D�code uniquement le premier noeud
//
bool
GlobalDkd::decodeNoeud(string sCheminLocal, bool bClassifJustLabel)
{
	setPPtArray(pSousPatPatho) ;
	initialiseIterateurs() ;
	int refCol = getCol() ;
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	string sLabel = "" ;
	*sDcodeur() = "" ;

	//
	// Codes sp�ciaux : saisie libre
	//
	if (isChampLibre())
	{
		Avance() ;
    if (!(iBon()) || (getCol() != refCol+1))
    	return false ;
	}

	//
	// Codes sp�ciaux : texte libre
	//
	if ((string("�??") == *getSt()) || (string("�CL") == *getSt()))
	{
		*(sDcodeur()) = getTexteLibre() ;
    return true ;
	}

	//
	// Codes sp�ciaux : CDAM
	//
	if (string("�CI") == *getSt())
	{
		NSCim10Info CimInfo ;
    DBIResult DBIError = getCIM10(&CimInfo) ;
    if (DBIERR_NONE == DBIError)
    {
    	*sDcodeur() = string(CimInfo.pDonnees->code) + string(" ")
            						+ string(CimInfo.pDonnees->libelle) ;
      return true ;
    }
	}

  //
	// Codes sp�ciaux : Personne
	//
  NSPersonInfo personInfo(pContexte) ;
  bool bGotPerson = getCorresp(&personInfo) ;
  if (true == bGotPerson)
  {
    *sDcodeur() = personInfo.getNomLong() ;
    return true ;
  }

  //
	// Codes sp�ciaux : Mat�riels
	//
  NSMaterielInfo matInfo ;
  DBIResult iRes = getMateriel(&matInfo) ;
  if ((NULL != matInfo.pDonnees) && ('\0' != matInfo.pDonnees->libelle[0]))
  {
    *sDcodeur() = matInfo.pDonnees->libelle_complet ;
    return true ;
  }

  //
	// R�f�rentiel
	//
	if (string("�RE") == *getSt())
	{

    *sDcodeur() = string("[") + *getCpl() + string("]") ;
    return true ;
	}

	//
	// On regarde si c'est une valeur num�rique
	//
	gereNum num(pContexte, sLangue) ;

	donneDimension(-1, &num) ;
	if (iBon())
	{
  	string sLibelle = "" ;
    if (decodeNum(&sLibelle, &num))
    	*sDcodeur() = sLibelle ;
    return true ;
	}
	set_iBon(true) ;

	//
  // On regarde si c'est une date
  //
  gereDate date(pContexte, sLangue) ;

  donneDate(-1, &date) ;
  if (iBon())
  {
  	string sMessage, sIntro ;
    date.donne_date_breve(&sMessage, &sIntro) ;
    *sDcodeur() = sIntro + sMessage ;
    return true ;
	}
  set_iBon(true) ;

	//
	// On regarde si c'est une date
	//
	gereHeure heure(pContexte, sLangue) ;

	donneHeure(-1, &heure) ;
	if (iBon())
	{
  	string sMessage ;
    heure.donne_heure(&sMessage) ;
    *sDcodeur() = sMessage ;
    return true ;
	}
	set_iBon(true) ;

	//
	// On d�code le libelle
	//
	// string sCode = *getStL() ;
  string sCode = getLexique() ;

	NSPathologData Data ;
	bool trouve = pSuper->getDico()->trouvePathologData(sLangue, &sCode, &Data) ;

	if (!trouve)
		*sDcodeur() = "???" ;

	int iGenre ;

	//
	// On regarde si c'est un code de classification
	//
	gereCode codage(pContexte, sLangue) ;

	donneCode(-1, &codage);
	if (iBon())
	{
		string sMessage ;
    codage.donne_code(&sMessage) ;
    Data.donneGenre(&iGenre) ;
    pGenerateur->donneLibelleAffiche(&sLabel, &Data, iGenre) ;

    if ((sCode == "6MGIT1") || bClassifJustLabel)
    {
    	codage.donne_code(&sMessage, false) ;
      *sDcodeur() = sMessage ;
    }
    else
    {
    	codage.donne_code(&sMessage) ;
      Data.donneGenre(&iGenre) ;
      pGenerateur->donneLibelleAffiche(&sLabel, &Data, iGenre) ;
      *sDcodeur() = sLabel + string(" : ") + sMessage ;
    }
    return true ;
	}
	set_iBon(true) ;

	//
	// Si le mot est un adjectif
	//
	if (Data.estAdjectif())
	{
  	// Conjugaison de l'adjectif
    //
    // On cherche dans le chemin local le nom qui pilote cet adjectif
    //
    int    posit  = strlen(sCheminLocal.c_str()) ;
    bool   trouve = false ;
    string sBoutDeChemin = "" ;
    string sBoutPluriel  = "" ;
    string sBoutCertitud = "" ;
    NSPathologData BufData ;

    while ((posit > 0) && (!trouve))
    {
    	if (string("") != sBoutDeChemin)
      {
      	sBoutPluriel  = "" ;
        sBoutCertitud = "" ;
      }
      sBoutDeChemin = "" ;

      posit-- ;
      while ((posit >= 0) && (sCheminLocal[posit] != cheminSeparationMARK))
      {
      	sBoutDeChemin = sCheminLocal[posit] + sBoutDeChemin ;
        posit-- ;
      }

      if (string(sBoutDeChemin, 0, 3) == "WCE")
      {
      	sBoutCertitud = sBoutDeChemin ;
        sBoutDeChemin = "" ;
      }
      else if (string(sBoutDeChemin, 0, 4) == "WPLU")
      {
      	sBoutPluriel = sBoutDeChemin ;
        sBoutDeChemin = "" ;
      }
      else if (pSuper->getDico()->trouvePathologData(sLangue, &sBoutDeChemin, &BufData))
      {
      	if (BufData.estNom())
        {
        	int iGenre ;
          BufData.donneGenre(&iGenre) ;

          if (string("") != sBoutPluriel)
          	BufData.donneGenrePluriel(&iGenre) ;

          pGenerateur->donneLibelleAffiche(&sLabel, &Data, iGenre) ;
          trouve = true ;
        }
      }
    }

    if (!trouve)
    	pGenerateur->donneLibelleAffiche(&sLabel, &Data) ;

    //
    // Gestion de la certitude
    //
    string sCert ;
    getCert(&sCert) ;
    int iCert = donneCertitude(sCert) ;
    sLabel = donneLibelleAdjectif(sLabel, iCert) ;

    *sDcodeur() = sLabel ;
    return true ;
	}

	//
	// Si le mot est un nom
	//
	if (Data.estNom())
	{
		Data.donneGenre(&iGenre) ;
    string sPlur ;
    getPlur(&sPlur) ;
    if (string("") != sPlur)
    	Data.donneGenrePluriel(&iGenre) ;

		pGenerateur->donneLibelleAffiche(&sLabel, &Data, iGenre) ;

    //
    // Gestion de la certitude
    //
    string sCert ;
    getCert(&sCert) ;
    int iCert = donneCertitude(sCert) ;
    sLabel = donneLibelleNom(sLabel, iCert) ;

    *sDcodeur() = sLabel ;
    return true ;
	}

	//
  // Si le mot n'est ni un nom ni un adjectif (invariable, adverbe...)
  //
  pGenerateur->donneLibelleAffiche(&sLabel, &Data) ;

  if (string("") == sLabel)
    return true ;

	//
	// Gestion de la certitude
	//
	string sCert ;
	getCert(&sCert) ;
	int iCert = donneCertitude(sCert) ;
	sLabel = donneLibelleAutre(sLabel, iCert) ;

	*sDcodeur() = sLabel ;

	return true ;
}

bool
GlobalDkd::CommenceParVoyelle(string* pLib)
{
	return pGenerateur->CommenceParVoyelle(pLib) ;
}

string
GlobalDkd::donneLibelleAdjectif(string sLabel, int iCertitude)
{
	if      (iCertitude == 0)
	{
		if      (sLangue == "fr")
    	sLabel = "non " + sLabel ;
    else if (sLangue == "en")
    	sLabel = "not " + sLabel ;
	}
    else if ((iCertitude > 0) && (iCertitude < 40)) //25%
    {
        if      (sLangue == "fr")
            sLabel = "probablement pas " + sLabel;
        else if (sLangue == "en")
            sLabel = "probably not " + sLabel;
    }
    else if ((iCertitude > 39) && (iCertitude < 60)) //50%
    {
        if      (sLangue == "fr")
            sLabel = "�ventuellement " + sLabel;
        else if (sLangue == "en")
            sLabel = "maybe " + sLabel;
    }
    else if ((iCertitude > 59) && (iCertitude < 90)) //75%
    {
        if      (sLangue == "fr")
            sLabel = "probablement " + sLabel;
        else if (sLangue == "en")
            sLabel = "probably " + sLabel;
    }
    else if ((iCertitude > 89) && (iCertitude < 100)) //95%
    {
        if      (sLangue == "fr")
            sLabel = "typiquement " + sLabel;
        else if (sLangue == "en")
            sLabel = "typically " + sLabel;
    }
    else if (iCertitude == -1) // NC
        sLabel = sLabel + " (?)" ;
    return sLabel;
}

string
GlobalDkd::donneLibelleNom(string sLabel, int iCertitude)
{
    if    (iCertitude == 0)
    {
        if      (sLangue == "fr")
        {
            if (CommenceParVoyelle(&sLabel))
                sLabel = "absence d'" + sLabel;
            else
                sLabel = "absence de " + sLabel;
        }
        else if (sLangue == "en")
            sLabel = "no " + sLabel;
    }
    else if ((iCertitude > 0) && (iCertitude < 40)) //25%
    {
        if      (sLangue == "fr")
            sLabel = "improbable " + sLabel;
        else if (sLangue == "en")
            sLabel = "improbable " + sLabel;
    }
    else if ((iCertitude > 39) && (iCertitude < 60)) //50%
    {
        if      (sLangue == "fr")
            sLabel = "possible " + sLabel;
        else if (sLangue == "en")
            sLabel = "possible " + sLabel;
    }
    else if ((iCertitude > 59) && (iCertitude < 90)) //75%
    {
        if      (sLangue == "fr")
            sLabel = "probable " + sLabel;
        else if (sLangue == "en")
            sLabel = "probable " + sLabel;
    }
    else if ((iCertitude > 89) && (iCertitude < 100)) //95%
    {
        if      (sLangue == "fr")
        {
            if (CommenceParVoyelle(&sLabel))
                sLabel = "aspect typique d'" + sLabel;
            else
                sLabel = "aspect typique de " + sLabel;
        }
        else if (sLangue == "en")
            sLabel = "typical aspect of " + sLabel;
    }
    else if (iCertitude == -1) // NC
        sLabel = sLabel + string(" (?)");
    return sLabel;
}

string
GlobalDkd::donneLibelleAutre(string sLabel, int iCertitude)
{
    if    (iCertitude == 0)
    {
        if      (sLangue == "fr")
            sLabel = "pas par " + sLabel;
        else if (sLangue == "en")
            sLabel = "not by " + sLabel;
    }
    else if ((iCertitude > 0) && (iCertitude < 40)) //25%
    {
        if      (sLangue == "fr")
            sLabel = "probablement pas par " + sLabel;
        else if (sLangue == "en")
            sLabel = "probably not by " + sLabel;
    }
    else if ((iCertitude > 39) && (iCertitude < 60)) //50%
    {
        if      (sLangue == "fr")
            sLabel = "�ventuellement par " + sLabel;
        else if (sLangue == "en")
            sLabel = "maybe by " + sLabel;
    }
    else if ((iCertitude > 59) && (iCertitude < 90)) //75%
    {
        if      (sLangue == "fr")
            sLabel = "si possible par " + sLabel;
        else if (sLangue == "en")
            sLabel = " " + sLabel;
    }
    else if ((iCertitude > 89) && (iCertitude < 100)) //95%
    {
        if      (sLangue == "fr")
            sLabel = "typiquement par " + sLabel;
        else if (sLangue == "en")
            sLabel = "typically by " + sLabel;
    }
    else if (iCertitude == -1) // NC
        sLabel = sLabel + string(" (?)");
    return sLabel;
}

// -------------------------------------------------------------------------
// ------------------------- METHODES DE lot -------------------------------
// -------------------------------------------------------------------------

lot::lot(NSContexte* pCtx)
    :NSRoot(pCtx)
{
    pLotPere    = 0;
    sConnection = "";

    sObjet = "";

    sDate           = "";
    sHeure          = "";
    sValeurChiffree = "";

    sQualifiant = "";

    pLotsLies = new NSlotArray(pCtx);
}

void
lot::ajouteDate(string sDateAjout)
{
    if (sDate != "")
        sDate += "|";
    sDate += sDateAjout;
}

void
lot::ajouteHeure(string sHeureAjout)
{
    if (sHeure != "")
        sHeure += "|";
    sHeure += sHeureAjout;
}

void
lot::ajouteValeurChiffree(string sValeurChiffreeAjout)
{
    if (sValeurChiffree != "")
        sValeurChiffree += "|";
    sValeurChiffree += sValeurChiffreeAjout;
}

void
lot::ajouteQualifiant(string sQualifiantAjout)
{
    if (sQualifiant != "")
        sQualifiant += "||";
    sQualifiant += sQualifiantAjout;
}

lot::lot(lot& rv)
    :NSRoot(rv.pContexte)
{
    pLotPere    = rv.pLotPere;
    sConnection = rv.sConnection;

    sObjet = rv.sObjet;

    sDate           = rv.sDate;
    sHeure          = rv.sHeure;
    sValeurChiffree = rv.sValeurChiffree;

    sQualifiant = rv.sQualifiant;

    if (pLotsLies)
        delete pLotsLies;
    pLotsLies = new NSlotArray(*(rv.pLotsLies));
}

lot::~lot()
{
    if (pLotsLies)
        delete pLotsLies;
}

// -------------------------------------------------------------------------
// ---------------------- METHODES DE NSlotArray ---------------------------
// -------------------------------------------------------------------------
NSlotArray::NSlotArray(NSContexte* pCtx)
           :NSLotsArray(), NSRoot(pCtx)
{}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSlotArray::NSlotArray(NSlotArray& rv)
           :NSLotsArray(), NSRoot(rv.pContexte)
{
    if (!(rv.empty()))
        for (LotIter i = rv.begin(); i != rv.end(); i++)
            push_back(new lot(*(*i)));
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSlotArray::vider()
{
    if (empty())
        return;
    for (LotIter i = begin(); i != end(); )
    {
   	    delete *i;
        erase(i);
    }
}

NSlotArray::~NSlotArray()
{
    vider();
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSlotArray&
NSlotArray::operator=(NSlotArray src)
{
    LotIter i;
    //
    // Effacement des �l�ments d�j� contenus dans le vecteur destination
    //
	vider();
	//
    // Copie et insertion des �l�ments de la source
    //
    if (!(src.empty()))
  	    for (i = src.begin(); i != src.end(); i++)
   	        push_back(new lot(*(*i)));
    return *this;
}

