#include "dcodeur\nsgen.h"
#include "partage\nsdivfct.h"
#include "dcodeur\nsphrase.h"
#include "dcodeur\nsdkd.h"
#include "nautilus\nssuper.h"

// -------------------------------------------------------------------------
// ---------------------- METHODES DE generateur ---------------------------
// -------------------------------------------------------------------------
NSGenerateur::NSGenerateur(NSContexte* pCtx, NsProposition* pPropos, string sLangue)
             :NSRoot(pCtx)
{
    // pPhraseur->nettoye();
    pCCArray        = new NSGenereCompArray(pCtx, this) ;
    pProposition    = pPropos ;
    initialise() ;
    sPhrase         = "" ;
    sLang           = sLangue ;
    pPh             = 0 ;
    if (pProposition->iObjectType == NsProposition::isPhraseur)
        pPh = (static_cast<NSPhraseur*>(pProposition->pProposition)) ;
}

NSGenerateur::NSGenerateur(NSGenerateur& rv)
             :NSRoot(rv.pContexte)
{
    pCCArray = new NSGenereCompArray(*(rv.pCCArray)) ;
    initialise() ;
    sPhrase = "" ;
    copieTout(&rv) ;
}

NSGenerateur::~NSGenerateur()
{
    delete pCCArray;

    if (pAdjEpitheteAvPos)
        delete pAdjEpitheteAvPos;
    if (pAdjEpitheteAvNeg)
        delete pAdjEpitheteAvNeg;
    if (pAdjEpitheteApPos)
        delete pAdjEpitheteApPos;
    if (pAdjEpitheteApNeg)
        delete pAdjEpitheteApNeg;
    if (pCompNomPos)
        delete pCompNomPos;
    if (pCompNomNeg)
        delete pCompNomNeg;
    if (pAdverbePos)
        delete pAdverbePos;
    if (pAdverbeNeg)
        delete pAdverbeNeg;
    if (pCODPos)
        delete pCODPos;
    if (pCODNeg)
        delete pCODNeg;
    if (pAttSujetPos)
        delete pAttSujetPos;
    if (pAttSujetNeg)
        delete pAttSujetNeg;
    if (pAttCODPos)
        delete pAttCODPos;
    if (pAttCODNeg)
        delete pAttCODNeg;
}

void
NSGenerateur::initialise()
{
    pAdjEpitheteAvPos = 0;
    pAdjEpitheteAvNeg = 0;
    pAdjEpitheteApPos = 0;
    pAdjEpitheteApNeg = 0;
    pCompNomPos       = 0;
    pCompNomNeg       = 0;
    pAdverbePos       = 0;
    pAdverbeNeg       = 0;
    pCODPos           = 0;
    pCODNeg           = 0;
    pAttSujetPos      = 0;
    pAttSujetNeg      = 0;
    pAttCODPos        = 0;
    pAttCODNeg        = 0;

    pCCArray->initialise();
}

void
NSGenerateur::reinitialise()
{
    if (pAdjEpitheteAvPos)
        delete pAdjEpitheteAvPos;
    if (pAdjEpitheteAvNeg)
        delete pAdjEpitheteAvNeg;
    if (pAdjEpitheteApPos)
        delete pAdjEpitheteApPos;
    if (pAdjEpitheteApNeg)
        delete pAdjEpitheteApNeg;
    if (pCompNomPos)
        delete pCompNomPos;
    if (pCompNomNeg)
        delete pCompNomNeg;
    if (pAdverbePos)
        delete pAdverbePos;
    if (pAdverbeNeg)
        delete pAdverbeNeg;
    if (pCODPos)
        delete pCODPos;
    if (pCODNeg)
        delete pCODNeg;
    if (pAttSujetPos)
        delete pAttSujetPos;
    if (pAttSujetNeg)
        delete pAttSujetNeg;
    if (pAttCODPos)
        delete pAttCODPos;
    if (pAttCODNeg)
        delete pAttCODNeg;

    initialise();
}

void
NSGenerateur::copieTout(NSGenerateur* rv)
{
    if (rv->pProposition)
    {
        pProposition = new NsProposition(*(rv->pProposition)) ;
        if (pProposition->iObjectType == NsProposition::isPhraseur)
            pPh = (static_cast<NSPhraseur*>(pProposition->pProposition)) ;
    }
    else
        pProposition = 0 ;


    sPhrase = rv->sPhrase;
    sLang   = rv->sLang;

    if (rv->pAdjEpitheteAvPos)
        pAdjEpitheteAvPos = new NSPhraseMotArray(*(rv->pAdjEpitheteAvPos));
    else
        pAdjEpitheteAvPos = 0;

    if (rv->pAdjEpitheteAvNeg)
        pAdjEpitheteAvNeg = new NSPhraseMotArray(*(rv->pAdjEpitheteAvNeg));
    else
        pAdjEpitheteAvNeg = 0;

    if (rv->pAdjEpitheteApPos)
        pAdjEpitheteApPos = new NSPhraseMotArray(*(rv->pAdjEpitheteApPos));
    else
        pAdjEpitheteApPos = 0;

    if (rv->pAdjEpitheteApNeg)
        pAdjEpitheteApNeg = new NSPhraseMotArray(*(rv->pAdjEpitheteApNeg));
    else
        pAdjEpitheteApNeg = 0;

    if (rv->pCompNomPos)
        pCompNomPos = new NSPhraseMotArray(*(rv->pCompNomPos));
    else
        pCompNomPos = 0;

    if (rv->pCompNomNeg)
        pCompNomNeg = new NSPhraseMotArray(*(rv->pCompNomNeg));
    else
        pCompNomNeg = 0;

    if (rv->pAdverbePos)
        pAdverbePos = new NSPhraseMotArray(*(rv->pAdverbePos));
    else
        pAdverbePos = 0;

    if (rv->pAdverbeNeg)
        pAdverbeNeg = new NSPhraseMotArray(*(rv->pAdverbeNeg));
    else
        pAdverbeNeg = 0;

    if (rv->pCODPos)
        pCODPos = new NSPhraseMotArray(*(rv->pCODPos));
    else
        pCODPos = 0;

    if (rv->pCODNeg)
        pCODNeg = new NSPhraseMotArray(*(rv->pCODNeg));
    else
        pCODNeg = 0;

    if (rv->pAttSujetPos)
        pAttSujetPos = new NSPhraseMotArray(*(rv->pAttSujetPos));
    else
        pAttSujetPos = 0;

    if (rv->pAttSujetNeg)
        pAttSujetNeg = new NSPhraseMotArray(*(rv->pAttSujetNeg));
    else
        pAttSujetNeg = 0;

    if (rv->pAttCODPos)
        pAttCODPos = new NSPhraseMotArray(*(rv->pAttCODPos));
    else
        pAttCODPos = 0;

    if (rv->pAttCODNeg)
        pAttCODNeg = new NSPhraseMotArray(*(rv->pAttCODNeg));
    else
        pAttCODNeg = 0;


    *pCCArray         = *(rv->pCCArray);
}

bool
NSGenerateur::genereProposition(int iStyle, NsProposition* pPropos)
{
    NsProposition* pCurrentProp ;
    if (pPropos)
        pCurrentProp = pPropos ;
    else
        pCurrentProp = pProposition ;

    if (!pCurrentProp)
        return false ;
try
{
    pCurrentProp->sPhrase = "" ;
    pCurrentProp->sLang   = sLang ;

    //
    // Proposition isol�e : on se contente de la d�coder
    // Lone proposition : we just generate it
    //
    if (pCurrentProp->iObjectType == NsProposition::isPhraseur)
    {
        pPh = (static_cast<NSPhraseur*>(pCurrentProp->pProposition)) ;
        bool bResult = generePhrase(iStyle) ;
        if (bResult)
            pCurrentProp->sPhrase = sPhrase ;
        return bResult ;
    }
    //
    // Propositions multiples : on d�code, puis on assemble
    // Multiple propositions : we generate each one, then we build the sentence
    //
    if (pCurrentProp->iObjectType == NsProposition::isPropositionArray)
    {
        NSPropositionArray* pPropArray = (static_cast<NSPropositionArray*>(pCurrentProp->pProposition)) ;
        if (pPropArray->empty())
            return true ;
        for (iterProposition i = pPropArray->begin(); i != pPropArray->end(); i++)
        {
            bool bResult = genereProposition(iStyle, *i) ;
            if (!bResult)
                return false ;
        }
        return assembleProposition(iStyle, pCurrentProp) ;
    }
    return false ;
}
catch (...)
{
	erreur("Exception NSGenerateurFr::generePhrase.", standardError, 0) ;
  return false ;
}
}

bool
NSGenerateur::ajouteMot(NSPhraseMotArray** ppMotArray, NSPhraseMot* pMot)
{
try
{
	if (NULL == pMot)
  	return true ;

	if (NULL == *ppMotArray)
  	*ppMotArray = new NSPhraseMotArray() ;

	(*ppMotArray)->push_back(pMot) ;

	return true ;
}
catch (...)
{
	erreur("Exception NSGenerateur::ajouteMot.", standardError, 0) ;
	return false ;
}
}

bool
NSGenerateur::ajouteCopieMot(NSPhraseMotArray** ppMotArray, NSPhraseMot* pMot)
{
try
{
  if (NULL == pMot)
    return true ;

  if (NULL == *ppMotArray)
    *ppMotArray = new NSPhraseMotArray();

  //
  // NSPhraseMotTime ?
  //
  NSPhraseMotTime* pDate = dynamic_cast<NSPhraseMotTime*>(pMot) ;
  if (pDate)
    (*ppMotArray)->push_back(new NSPhraseMotTime(*pDate));
  else
  {
    NSPhraseMotTimeCycle* pCycle = dynamic_cast<NSPhraseMotTimeCycle*>(pMot) ;
    if ( pCycle )
      (*ppMotArray)->push_back(new NSPhraseMotTimeCycle(*pCycle)) ;
    else
      (*ppMotArray)->push_back(new NSPhraseMot(*pMot)) ;
  }

  return true ;
}
catch (...)
{
	erreur("Exception NSGenerateur::ajouteCopieMot.", standardError, 0) ;
	return false ;
}
}

bool
NSGenerateur::terminePhrase()
{
  if (sPhrase != "")
  {
    sPhrase[0] = pseumaj(sPhrase[0]) ;
    sPhrase += string(".") ;
  }
  return true ;
}

bool
NSGenerateur::termineProposition(NsProposition* pPropos)
{
  string* pPhrase = 0 ;
  if (NULL != pPropos)
    pPhrase = &(pPropos->sPhrase) ;
  else
    pPhrase = &(pProposition->sPhrase) ;

  if ((NULL != pPhrase) && (string("") != *pPhrase))
  {
    (*pPhrase)[0] = pseumaj((*pPhrase)[0]) ;
    *pPhrase += string(".") ;
  }
  return true ;
}

bool
NSGenerateur::CommenceParVoyelle(string* pLib)
{
  if ((NULL == pLib) || (strlen(pLib->c_str()) == 0))
    return false ;

	switch ((*pLib)[0])
  {
    case '�' ://200
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case 'e' :
    case 'E' :
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case 'a' :
    case 'A' :
    case '�' :
    case '�' :
    case '�' :
    case '�' : //197
    case '�' :
    case '�' : //226
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case 'i' :
    case 'I' :
    case '�' :
    case '�' :
    case '�' ://220
    case '�' :
    case '�' :
    case '�' : //216
    case '�' :
    case '�' :
    case 'u' :
    case 'U' :
    case '�' :
    case '�' :
    case '�' : //213
    case '�' :
    case '�' :
    case 'o' :
    case 'O' :
    case '�' :
    case '�' :
    case '�' : //242
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case '�' :
    case 'y' :
    case 'Y' :
    case '�' :  return true;
  }
  return false ;
}

void
NSGenerateur::etDuMilieu(string *type, string *type1, string *type2)
{
	if (*type2 == "")
		return;
	if (*type != "")
		*type += ", ";
	*type += *type1;
	*type1 = *type2;
	*type2 = "";
	return;
}

// -------------------------------------------------------------------------
// -------------------- METHODES DE NSGenComplement ------------------------
// -------------------------------------------------------------------------
NSGenComplement::NSGenComplement(NSContexte* pCtx, NSGenerateur* pGener)
                :NSRoot(pCtx)
{
  pGenerateur  = pGener ;

  sType        = "" ;
  sPositif     = "" ;
  sNegatif     = "" ;
  pMotsPos     =  0 ;
  pMotsNeg     =  0 ;
  iPriorite    = 50 ;
}

NSGenComplement::NSGenComplement(NSGenComplement& rv)
                :NSRoot(rv.pContexte)
{
try
{
  sType        = rv.sType ;
  sPositif     = rv.sPositif ;
  sNegatif     = rv.sNegatif ;
  iPriorite    = rv.iPriorite ;
  pGenerateur  = rv.pGenerateur ;

  if (rv.pMotsPos)
    pMotsPos = new NSPhraseMotArray(*(rv.pMotsPos)) ;
  else
    pMotsPos = 0 ;
  if (rv.pMotsNeg)
    pMotsNeg = new NSPhraseMotArray(*(rv.pMotsNeg)) ;
  else
    pMotsNeg = 0 ;
}
catch (...)
{
	erreur("Exception NSGenComplement copy ctor.", standardError, 0) ;
}
}

NSGenComplement::~NSGenComplement()
{
	if (pMotsPos)
  	delete pMotsPos ;
	if (pMotsNeg)
  	delete pMotsNeg ;
}

void
NSGenComplement::donnePhrElements(NSPhraseMot** ppLiaison, NSPhraseMot** ppPreposition, NSPhraseMotArray** ppMots)
{
  if ((NULL == pGenerateur) || (!(pGenerateur->getCurrentPhraseur())))
  {
    *ppLiaison     = 0 ;
    *ppPreposition = 0 ;
    *ppMots        = 0 ;
    return ;
  }

  NSPhraseur* pPhra = pGenerateur->getCurrentPhraseur() ;

  if      (sType == string(STR_CCLIEU))
  {
    *ppLiaison     = &(pPhra->LiaisonLieu) ;
    *ppPreposition = &(pPhra->PrepositionLieu) ;
    *ppMots        = &(pPhra->CCLieu) ;
  }
  else if (sType == string(STR_CCTEMPS))
  {
    *ppLiaison     = &(pPhra->LiaisonTemps) ;
    *ppPreposition = &(pPhra->PrepositionTemps) ;
    *ppMots        = &(pPhra->CCTemps) ;
  }
  else if (sType == string(STR_CCMANIERE))
  {
    *ppLiaison     = &(pPhra->LiaisonManiere) ;
    *ppPreposition = &(pPhra->PrepositionManiere) ;
    *ppMots        = &(pPhra->CCManiere) ;
  }
  else if (sType == string(STR_CCMOYEN))
  {
    *ppLiaison     = &(pPhra->LiaisonMoyen) ;
    *ppPreposition = &(pPhra->PrepositionMoyen) ;
    *ppMots        = &(pPhra->CCMoyen) ;
  }
  else if (sType == string(STR_CCCHIFFRE))
  {
    *ppLiaison     = &(pPhra->LiaisonChiffre) ;
    *ppPreposition = &(pPhra->PrepositionChiffre) ;
    *ppMots        = &(pPhra->CCChiffre) ;
  }
  else if (sType == string(STR_CCBUT))
  {
    *ppLiaison     = &(pPhra->LiaisonBut) ;
    *ppPreposition = &(pPhra->PrepositionBut) ;
    *ppMots        = &(pPhra->CCBut) ;
  }
  else if (sType == string(STR_CCCAUSE))
  {
    *ppLiaison     = &(pPhra->LiaisonCause) ;
    *ppPreposition = &(pPhra->PrepositionCause) ;
    *ppMots        = &(pPhra->CCCause) ;
  }
  else if (sType == string(STR_CCTYPE))
  {
    *ppLiaison     = &(pPhra->LiaisonType) ;
    *ppPreposition = &(pPhra->PrepositionType) ;
    *ppMots        = &(pPhra->CCType) ;
  }
  else if (sType == string(STR_CCHYPOTH))
  {
    *ppLiaison     = &(pPhra->LiaisonHypoth) ;
    *ppPreposition = &(pPhra->PrepositionHypoth) ;
    *ppMots        = &(pPhra->CCHypoth) ;
  }
  return ;
}

bool
NSGenComplement::donnePhrase()
{
  bool bSucces ;

  NSPhraseMot*      pLiaison ;
  NSPhraseMot*      pPreposition ;
  NSPhraseMotArray* pMots ;

  donnePhrElements(&pLiaison, &pPreposition, &pMots) ;

  if (STR_CCCHIFFRE == sType)
  {
    if ((pMotsPos) && (false == pMotsPos->empty()))
    {
      sPositif = pGenerateur->donnePhraseChiffree(pLiaison, pPreposition,
                                                        pMotsPos, &bSucces) ;
      if (false == bSucces)
        return false ;
    }

    if ((pMotsNeg) && (false == pMotsNeg->empty()))
    {
      sNegatif = pGenerateur->donnePhraseChiffree(pLiaison, pPreposition,
                                                        pMotsNeg, &bSucces) ;
      if (false == bSucces)
        return false ;
    }
  }
  else
  {
    if ((pMotsPos) && (false == pMotsPos->empty()))
    {
      sPositif = pGenerateur->donnePhraseComplement(pLiaison, pPreposition,
                                                          pMotsPos, &bSucces) ;
      if (false == bSucces)
        return false ;
    }

    if ((pMotsNeg) && (false == pMotsNeg->empty()))
    {
      sNegatif = pGenerateur->donnePhraseComplement(pLiaison, pPreposition,
                                                          pMotsNeg, &bSucces) ;
      if (false == bSucces)
        return false ;
    }
  }
  return true ;
}

void
NSGenComplement::initialise()
{
  sType     = "" ;
  sPositif  = "" ;
  sNegatif  = "" ;
  iPriorite = 0 ;

  if (pMotsPos)
    delete pMotsPos ;
  if (pMotsNeg)
    delete pMotsNeg ;
}

void
NSGenComplement::classe()
{
  iPriorite = 0 ;
  sPositif  = "" ;
  sNegatif  = "" ;
  if (pMotsPos)
    delete pMotsPos ;
  if (pMotsNeg)
    delete pMotsNeg ;

  NSPhraseMot*      pLiaison ;
  NSPhraseMot*      pPreposition ;
  NSPhraseMotArray* pMots ;

  donnePhrElements(&pLiaison, &pPreposition, &pMots) ;

  if (NULL == pMots)
    return ;

  iterPhraseMot  iterMots;
  NSPathologData Data;
  NSSuper* pSuper = pContexte->getSuperviseur();

  for (iterMots = pMots->begin(); iterMots != pMots->end(); iterMots++)
  {
    string sLexique = (*iterMots)->getLexique() ;

    if ((sLexique != "") && (false == (*iterMots)->estTexteLibre()))
    {
      bool trouve = pSuper->getDico()->trouvePathologData(pGenerateur->getLang(), &sLexique, &Data) ;
      if (false == trouve)
        return ;
      // if (!Data.estNom())
      //    return;

      string sCertitude = (*iterMots)->getCertitude() ;

      if ((string(sCertitude, 0, 3) == "WCE") &&
              (string(sCertitude, 0, 5) < "WCE50"))
        pGenerateur->ajouteCopieMot(&pMotsNeg, *iterMots) ;
      else if (((string(sCertitude, 0, 3) == "WCE") &&
                  (string(sCertitude, 0, 5) >= "WCE50")) || (sCertitude == ""))
        pGenerateur->ajouteCopieMot(&pMotsPos, *iterMots) ;
    }
    else
      pGenerateur->ajouteCopieMot(&pMotsPos, *iterMots) ;

    iPriorite = max(iPriorite, (*iterMots)->getPriority()) ;
  }
}

NSGenComplement&
NSGenComplement::operator=(const NSGenComplement& rv)
{
  if (&rv == this)
    return *this ;

  sType       = rv.sType ;
  sPositif    = rv.sPositif ;
  sNegatif    = rv.sNegatif ;
  iPriorite   = rv.iPriorite ;
  pGenerateur = rv.pGenerateur ;

  if (rv.pMotsPos)
  {
    if (pMotsPos)
      *pMotsPos = *(rv.pMotsPos) ;
    else
      pMotsPos = new NSPhraseMotArray(*(rv.pMotsPos)) ;
  }
  else if (pMotsPos)
    delete pMotsPos ;

  if (rv.pMotsNeg)
  {
    if (pMotsNeg)
      *pMotsNeg = *(rv.pMotsNeg) ;
    else
      pMotsNeg = new NSPhraseMotArray(*(rv.pMotsNeg)) ;
  }
  else if (pMotsNeg)
    delete pMotsNeg ;

  return *this ;
}

// -------------------------------------------------------------------------
// ------------------- METHODES DE NSGenereCompArray -----------------------
// -------------------------------------------------------------------------

NSGenereCompArray::NSGenereCompArray(NSContexte* pCtx, NSGenerateur* pGener)
                  :NSGenCompArray()
{
  pGenerateur = pGener ;
  pContexte   = pCtx ;
}

//--------------------------------------------------------------------------
//  Constructeur copie
//--------------------------------------------------------------------------
NSGenereCompArray::NSGenereCompArray(NSGenereCompArray& rv)
                  :NSGenCompArray()
{
  pGenerateur = rv.pGenerateur ;
  pContexte   = rv.pContexte ;

try
{
  if (false == rv.empty())
    for (GenCompIter i = rv.begin(); i != rv.end(); i++)
      push_back(new NSGenComplement(*(*i))) ;
}
catch (...)
{
	erreur("Exception NSGenereCompArray copy ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSGenereCompArray::vider()
{
  if (empty())
    return ;

  for (GenCompIter i = begin(); i != end(); )
  {
    delete *i ;
    erase(i) ;
  }
}

NSGenereCompArray::~NSGenereCompArray()
{
	vider() ;
}

void
NSGenereCompArray::initialise()
{
  vider() ;

    /*if (empty())
        return true;

    for (GenCompIter i = begin(); i != end(); i++)
        (*i)->initialise(); */

  return ;
}

void
NSGenereCompArray::classeTout()
{
try
{
  vider() ;

  if ((NULL == pGenerateur) || (NULL == pGenerateur->getCurrentPhraseur()))
    return ;

  NSPhraseur* pPh = pGenerateur->getCurrentPhraseur() ;

  if (false == pPh->CCLieu.empty())
  {
    NSGenComplement* pCCLieu = new NSGenComplement(pContexte, pGenerateur) ;
    pCCLieu->sType = STR_CCLIEU ;
    pCCLieu->classe() ;
    push_back(pCCLieu) ;
  }
  if (false == pPh->CCTemps.empty())
  {
    NSGenComplement* pCCTemps = new NSGenComplement(pContexte, pGenerateur) ;
    pCCTemps->sType = STR_CCTEMPS ;
    pCCTemps->classe() ;
    push_back(pCCTemps) ;
  }
  if (false == pPh->CCManiere.empty())
  {
    NSGenComplement* pCCManiere = new NSGenComplement(pContexte, pGenerateur) ;
    pCCManiere->sType = STR_CCMANIERE ;
    pCCManiere->classe() ;
    push_back(pCCManiere) ;
  }
  if (false == pPh->CCMoyen.empty())
  {
    NSGenComplement* pCCMoyen = new NSGenComplement(pContexte, pGenerateur) ;
    pCCMoyen->sType = STR_CCMOYEN ;
    pCCMoyen->classe() ;
    push_back(pCCMoyen) ;
  }
  if (false == pPh->CCCause.empty())
  {
    NSGenComplement* pCCCause = new NSGenComplement(pContexte, pGenerateur) ;
    pCCCause->sType = STR_CCCAUSE ;
    pCCCause->classe() ;
    push_back(pCCCause) ;
  }
  if (false == pPh->CCBut.empty())
  {
    NSGenComplement* pCCBut = new NSGenComplement(pContexte, pGenerateur) ;
    pCCBut->sType = STR_CCBUT ;
    pCCBut->classe() ;
    push_back(pCCBut) ;
  }
  if (false == pPh->CCType.empty())
  {
    NSGenComplement* pCCType = new NSGenComplement(pContexte, pGenerateur) ;
    pCCType->sType = STR_CCTYPE ;
    pCCType->classe() ;
    push_back(pCCType) ;
  }
  if (false == pPh->CCChiffre.empty())
  {
    NSGenComplement* pCCChiffre = new NSGenComplement(pContexte, pGenerateur) ;
    pCCChiffre->sType = STR_CCCHIFFRE ;
    pCCChiffre->classe() ;
    push_back(pCCChiffre) ;
  }
  if (false == pPh->CCHypoth.empty())
  {
    NSGenComplement* pCCHypoth = new NSGenComplement(pContexte, pGenerateur) ;
    pCCHypoth->sType = STR_CCHYPOTH ;
    pCCHypoth->classe() ;
    push_back(pCCHypoth) ;
  }
}
catch (...)
{
	erreur("Exception NSGenereCompArray::classeTout", standardError, 0) ;
	return ;
}
}

NSGenComplement*
NSGenereCompArray::donneComplement(string sType)
{
  if (empty())
    return 0 ;

  for (GenCompIter i = begin(); i != end(); i++)
    if ((*i)->sType == sType)
      return (*i) ;

  return 0 ;
}

bool
NSGenereCompArray::donnePhrase()
{
  if (empty())
    return true ;

  for (GenCompIter i = begin(); i != end(); i++)
    if (false == (*i)->donnePhrase())
      return false ;

  return true ;
}

NSGenereCompArray&
NSGenereCompArray::operator=(NSGenereCompArray src)
{
	if (this == &src)
		return *this ;

	pGenerateur = src.pGenerateur ;
	pContexte   = src.pContexte ;

try
{
	vider() ;

	if (!(src.empty()))
  	for (GenCompIter i = src.begin(); i != src.end(); i++)
    	push_back(new NSGenComplement(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception NSGenereCompArray::operator=", standardError, 0) ;
	return *this ;
}
}

