/*
** Copyright Nautilus, (10/9/2004)
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/
#include "ns_ob1\BB1Task.h"

NautilusEvent::NautilusEvent(NSPatPathoArray* root, PatPathoIter* pointer, int userEventType) // FIXME PATHO
              :BB1Task()
{
  _root          = root ;
  _pointer       = pointer ;
  _userEventType = userEventType ;
}

NautilusEvent::NautilusEvent()
              :BB1Task()
{
  _root    = NULL ;
  _pointer = NULL ;
}

NautilusEvent::NautilusEvent(const NautilusEvent& src)
              :BB1Task(src)
{
	_root          = src._root ;
  _pointer       = src._pointer ;
  _userEventType = src._userEventType ;
}

NautilusEvent&
NautilusEvent::operator=(NautilusEvent& src)
{
	if (&src == this)
		return *this ;

	// using BB1Task = operator
	BB1Task *dest   = this ;
	BB1Task *source = &src ;
	*dest = *source ;

  _root          = src._root ;
  _pointer       = src._pointer ;
  _userEventType = src._userEventType ;

	return *this ;
}

NautilusEvent::~NautilusEvent()
{
}

insertObjectOnBlacBoard::insertObjectOnBlacBoard(NSPatPathoArray* doc, TypedVal* path)     // FIXME PATHO
                        :BB1Task()
{
  _doc  = doc ;
  _path = new TypedVal(*path) ;
}

insertObjectOnBlacBoard::insertObjectOnBlacBoard()
                        :BB1Task()
{
  _doc = NULL ;
}

insertObjectOnBlacBoard::insertObjectOnBlacBoard(const insertObjectOnBlacBoard& src)
                        :BB1Task(src)
{
	_doc = src._doc ;
}

insertObjectOnBlacBoard&
insertObjectOnBlacBoard::operator=(insertObjectOnBlacBoard& src)
{
	if (&src == this)
		return *this ;

	// using BB1Task = operator
	BB1Task *dest   = this ;
	BB1Task *source = &src ;
	*dest = *source ;

	_doc = src._doc ;

  return *this ;
}

insertObjectOnBlacBoard::~insertObjectOnBlacBoard()
{
}

AskDeterministicQuestion::AskDeterministicQuestion(std::string label ,TypedVal* question, int pririty)
                         :BB1Task()
{
  _label = label;
  _path = new TypedVal(*question);
  _priority = pririty ;
}

AskDeterministicQuestion::AskDeterministicQuestion()
                         :BB1Task()
{
   _path = NULL;
   _priority = 1;
}

AskDeterministicQuestion::AskDeterministicQuestion(const AskDeterministicQuestion& src)
                         :BB1Task(src)
{
	_priority = src._priority ;
}

AskDeterministicQuestion&
AskDeterministicQuestion::operator=(AskDeterministicQuestion& src)
{
	if (&src == this)
		return *this ;

	// using BB1Task = operator
	BB1Task *dest   = this ;
	BB1Task *source = &src ;
	*dest = *source ;

	_priority = src._priority ;

  return *this ;
}

AskDeterministicQuestion::~AskDeterministicQuestion()
{
}

BB1Order::BB1Order()
         :BB1Task()
{
}

BB1Order::BB1Order(BB1ORDER order, std::string tochange, std::string change)
         :BB1Task()
{
	_order     = order ;          // Typed'ordre
	toChange   = tochange ;    // Chose a modifier ddans le fonctionnement
	changement = change ;
}

BB1Order::BB1Order(const BB1Order& src)
         :BB1Task(src)
{
	_order     = src._order ;
	toChange   = src.toChange ;
	changement = src.changement ;
}

BB1Order&
BB1Order::operator=(BB1Order& src)
{
	if (&src == this)
		return *this ;

	// using BB1Task = operator
	BB1Task *dest   = this ;
	BB1Task *source = &src ;
	*dest = *source ;

	_order     = src._order ;
	toChange   = src.toChange ;
	changement = src.changement ;

  return *this ;
}

BB1Order::~BB1Order()
{
}

IsAnswerPresentOnBlackBoard::IsAnswerPresentOnBlackBoard()
                            :BB1Task()
{
  _path = NULL;
}

IsAnswerPresentOnBlackBoard::IsAnswerPresentOnBlackBoard(TypedVal* path, bool deepResult)
                            :BB1Task()
{
  _path = new TypedVal(*path);
  _deepResearch = deepResult;
}

IsAnswerPresentOnBlackBoard::IsAnswerPresentOnBlackBoard(const IsAnswerPresentOnBlackBoard& src)
                            :BB1Task(src)
{
	_deepResearch = src._deepResearch ;
}

IsAnswerPresentOnBlackBoard&
IsAnswerPresentOnBlackBoard::operator=(IsAnswerPresentOnBlackBoard& src)
{
	if (&src == this)
		return *this ;

	// using BB1Task = operator
	BB1Task *dest   = this ;
	BB1Task *source = &src ;
	*dest = *source ;

	_deepResearch = src._deepResearch ;

  return *this ;
}

IsAnswerPresentOnBlackBoard::~IsAnswerPresentOnBlackBoard()
{
}

TaskStructure::TaskStructure(BB1Task* temp)
{
  _task     = temp ;
  _toDelete = false ;
  _answer   = NULL ;
}

TaskStructure::~TaskStructure()
{
  if (NULL != _task)
    deleteTask() ;
  if (NULL != _answer)
  	delete(_answer) ;
}

TaskStructure::TaskStructure(const TaskStructure& src)
{
  if (NULL != src._task)
		setTask(src._task) ;
  else
  	_task = NULL ;
	_answer   = src._answer ;
	_toDelete = src._toDelete ;
}

TaskStructure&
TaskStructure::operator=(TaskStructure& src)
{
	if (&src == this)
		return *this ;

  if (NULL!= _task)
    deleteTask() ;

  if (NULL != src._task)
		setTask(src._task) ;
  else
  	_task = NULL ;
	_answer   = src._answer ;
	_toDelete = src._toDelete ;

  return *this ;
}

void
TaskStructure::setTask(BB1Task* pTask)
{
	if (NULL == pTask)
  {
  	_task = NULL ;
  	return ;
  }

	NautilusEvent* pEvent = dynamic_cast<NautilusEvent*>(pTask);
  if (pEvent != NULL)
  {
  	_task = new NautilusEvent(*pEvent) ;
    return ;
  }

	IsAnswerPresentOnBlackBoard* pIsAnswer = dynamic_cast<IsAnswerPresentOnBlackBoard*>(pTask);
  if (pIsAnswer != NULL)
  {
  	_task = new IsAnswerPresentOnBlackBoard(*pIsAnswer) ;
    return ;
  }

	AskDeterministicQuestion* pAskDeterministic = dynamic_cast<AskDeterministicQuestion*>(pTask);
  if (pAskDeterministic != NULL)
  {
  	_task = new AskDeterministicQuestion(*pAskDeterministic) ;
    return ;
  }

	BB1Order* pOrder = dynamic_cast<BB1Order*>(pTask);
  if (pOrder != NULL)
  {
  	_task = new BB1Order(*pOrder) ;
    return ;
  }

	insertObjectOnBlacBoard* pInsertObject = dynamic_cast<insertObjectOnBlacBoard*>(pTask);
  if (pInsertObject != NULL)
  {
  	_task = new insertObjectOnBlacBoard(*pInsertObject) ;
    return ;
  }

/*
	Precoche* pPrecoche = dynamic_cast<Precoche*>(pTask);
  if (pPrecoche != NULL)
  {
  	_task = new Precoche(*pPrecoche) ;
    return ;
  }
*/

  _task = NULL ;
	return ;
}

void
TaskStructure::deleteTask()
{
	if (NULL == _task)
  	return ;

  BB1TaskType iType = _task->Type() ;

  if (iType == NAUTILUS_EVENT_TASK)
  {
		NautilusEvent* pEvent = dynamic_cast<NautilusEvent*>(_task) ;
  	if (pEvent != NULL)
  	{
  		delete pEvent ;
  		_task = NULL ;
    	return ;
  	}
  }

  if (iType == IS_ANSWER_PRESENT_ON_BLACKBOARD)
  {
		IsAnswerPresentOnBlackBoard* pIsAnswer = dynamic_cast<IsAnswerPresentOnBlackBoard*>(_task) ;
  	if (pIsAnswer != NULL)
  	{
  		delete pIsAnswer ;
  		_task = NULL ;
    	return ;
  	}
	}

  if (iType == ASK_DETERMINISTIC_QUESTION)
  {
		AskDeterministicQuestion* pAskDeterministic = dynamic_cast<AskDeterministicQuestion*>(_task) ;
  	if (pAskDeterministic != NULL)
  	{
  		delete pAskDeterministic ;
  		_task = NULL ;
    	return ;
  	}
	}

  if (iType == ORDER)
  {
		BB1Order* pOrder = dynamic_cast<BB1Order*>(_task) ;
  	if (pOrder != NULL)
  	{
    	delete pOrder ;
  		_task = NULL ;
    	return ;
		}
  }

  if (iType == INSERT_OBJECT_ON_BLACKOARD)
  {
		insertObjectOnBlacBoard* pInsertObject = dynamic_cast<insertObjectOnBlacBoard*>(_task) ;
  	if (pInsertObject != NULL)
  	{
  		delete pInsertObject ;
  		_task = NULL ;
    	return ;
  	}
	}

  delete _task ;
  _task = NULL ;
	return ;
}

BB1TaskList::BB1TaskList()
{
}

BB1TaskList::~BB1TaskList()
{
	vider() ;
}

TaskStructure*
BB1TaskList::getTask(TypedVal* val)
{
	if (!val)
  	return NULL ;

	if (_TaskStructureList.empty())
		return NULL ;

  register unsigned int end = _TaskStructureList.size() ;
  for (register unsigned int i = 0; i < end; i++)
	{
		TaskStructure* temp = _TaskStructureList[i] ;
		if (temp->Task()->Path() == val)
			return (temp) ;
	}

	return NULL ;
}

void
BB1TaskList::AddTask(TaskStructure* temp)
{
	if (!temp)
  	return ;

	_TaskStructureList.push_back(temp) ;
}

/*
void                BB1TaskList::remove(BB1Task* temp)
{
}
   */

void
BB1TaskList::GarbageCollecting()
{
	if (_TaskStructureList.empty())
		return ;

  std::vector<TaskStructure* >::iterator iter ;
  for (iter = _TaskStructureList.begin(); iter != _TaskStructureList.end(); )
  {
  	if (NULL == *iter)
    	_TaskStructureList.erase(iter) ;
		else if (true == (*iter)->Delete())
		{
			delete(*iter) ;
			_TaskStructureList.erase(iter) ;
		}
    else
    	iter++ ;
  }
}

BB1TaskList::BB1TaskList(BB1TaskList& src)
{
	if (src._TaskStructureList.empty())
		return ;

  std::vector<TaskStructure* >::iterator iter ;
  for (iter = src._TaskStructureList.begin(); iter != src._TaskStructureList.end(); iter++)
  	if (NULL != *iter)
  		_TaskStructureList.push_back(new TaskStructure(**iter)) ;
}

BB1TaskList&
BB1TaskList::operator=(BB1TaskList& src)
{
	if (&src == this)
		return *this ;

  vider() ;

  if (src._TaskStructureList.empty())
		return *this ;

  std::vector<TaskStructure* >::iterator iter ;
  for (iter = src._TaskStructureList.begin(); iter != src._TaskStructureList.end(); iter++)
  	if (NULL != *iter)
  		_TaskStructureList.push_back(new TaskStructure(**iter)) ;

  return *this ;
}

void
BB1TaskList::vider()
{
	if (_TaskStructureList.empty())
		return ;

  std::vector<TaskStructure* >::iterator iter ;
  for (iter = _TaskStructureList.begin(); iter != _TaskStructureList.end(); )
  {
  	if (NULL != *iter)
  		delete *iter ;
    _TaskStructureList.erase(iter) ;
  }
}

//FIXME
// Precochage
// - handle de fenetre
// - question
// - label
// - void * reponse

// Alert
// - label
// - path
// - priorit� de l'alerte
// -
