/*
** Copyright Nautilus, (10/9/2004)
** fabrice.le_perru@nautilus-info.com
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/
#ifndef _OWLDLL
# include "AttValPair.h"   // for BB1BB::CreateEvent(...)
# include "BB1Link.h"      // for BB1BB::CreateEvent(...)
# include "BB1BB.h"
# include "BB1Event.h"     // for BB1BB::CreateEvent(...)
# include "BB1KB.h"        // for BB1BB::CreateEvent(...)
# include "BB1Exception.h"    // add fab
#else
# include "ns_ob1\AttValPair.h"   // for BB1BB::CreateEvent(...)
# include "ns_ob1\BB1Link.h"      // for BB1BB::CreateEvent(...)
# include "ns_ob1\BB1BB.h"
# include "ns_ob1\BB1Event.h"     // for BB1BB::CreateEvent(...)
# include "ns_ob1\BB1KB.h"        // for BB1BB::CreateEvent(...)
# include "ns_ob1\BB1Exception.h"    // add fab
#endif


// -----------------------------------------------------------------------------
// Create an event object and place it in the event knowledge base. Called from
// BB1BB::ProposeFocus(...), BB1BB::ProposeStrategy(...), ::ModifyObject(...),
// BB1BB::NewAppInst(...), BB1BB::CreateMessage(...), BB1Decision::TurnOff(...),
// BB1Strategy::{AdvanceStrategicGenerator(...), RemoveCurrentPrescription(...)}.
// -----------------------------------------------------------------------------
// Do NOT create an event when any of the following are created: BB1Event,
// BB1KSAR.
// -----------------------------------------------------------------------------
// LSB: Should there be an event when the following are created: BB1Class,
// BB1KS?
// -----------------------------------------------------------------------------

int BB1BB::CreateToken(EventType type, BB1Object& object, const AVPSet *attSpec, const LinkSet *linkSpec, bool createStrat)
{

  //attribut ayant changer
  AVPSet *changedAttributes = new AVPSet() ;
  if (attSpec && !attSpec->empty())
  for (AVPCIter ap = attSpec->begin() ; ap != attSpec->end() ; ap++)
    changedAttributes->push_back(new AttValPair((*ap)->AttributeName(), (*ap)->AttributeValue())) ;

  // Check les liens qui ont changer
  LinkSet *changedLinks = new LinkSet() ;
  if (linkSpec && !linkSpec->empty())
    for (LinkCIter lp = linkSpec->begin() ; lp != linkSpec->end() ; lp++)
    changedLinks->push_back(new BB1Link((*lp)->Name(), (*lp)->ToObject())) ;

  OB1Token* temp = new  OB1Token(ADD, &object,changedAttributes,changedLinks );
  _kenoby->Dispatch(temp,createStrat);

   return 0;
}



