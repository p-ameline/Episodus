/*
** Copyright Nautilus, (10/9/2004)
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/
#include "ns_ob1\OB1Controler.h"
#include "ns_ob1\InitStructure.h"
#include "ns_ob1\BB1KS.h"
#include "ns_ob1\OB1Token.h"
//#include "ns_ob1\DFS.h"
#include "ns_ob1\OB1Heuristix.h"
#include "ns_ob1\OB1Agenda.h"
#include "ns_ob1\BB1Object.h"
#include "ns_ob1\OB1Functor.h"
#include "ns_ob1\OB1Strategy.h"
#include "ns_ob1\BB1Class.h"

//Controler* _globalControler; //sert a recuperer un lien sur le controelr et le blackboard


Heuristix*    OB1Controler::GetHeuristix()
{
  return (_choice->getHeuristix());
}


OB1Controler::OB1Controler(BB1BB* bbb) : _sheduler(this)
{
try
{
  bb = bbb ;
  _StrategyCounter = 0 ;
  _choice = new HeuristixGenerator(this) ;
  _IClass = new BB1ClassIndex() ;
  _Agenda = new OB1Agenda(this) ;
}
catch (...)
{
	erreur("Exception BB1 OB1Controler ctor.", standardError, 0) ;
}
}

void OB1Controler::save()
{
  std::string res = "";
  res += "<br />" + (*_IClass).toHTML();
  std::ofstream file("KSPUBLICATION.htm");
  for (int i = 0; i < _bb_state.numVertices(); i++)
  if (_bb_state[i]->getType() == KS_NODE)
  {
  OB1NKS* tp = dynamic_cast<OB1NKS*>(_bb_state[i]);
  if (tp != NULL)
    {
      const FunctorPublication*  funcP  =  tp->getKS()->Publication();
      KsInitStructure* toPlace = (*funcP)(); //tp->getKS()->Publication()();
      res += toPlace->toHTML();
      delete(toPlace);
    }
  }
  if (file.is_open())
  {
    file << res;
    file.close();
  }
}

void OB1Controler::addBB1Class(std::string name)
{
  (*_IClass).insertItem(name);
}


OB1Controler::~OB1Controler()
{
 delete(_IClass);
 delete(_choice);
  #ifdef __DEBUG__
  //std::string nem = "graphe2.htm";
  //_bb_state.save(nem);
  #endif
}

void OB1Controler::addKS(BB1KS* ks)
{
try
{
  if (NULL == ks)
		return ;

	const FunctorPublication* FuncP = ks->Publication();
	KsInitStructure* toPlace = (*FuncP)(); //ks->Publication()();
	if (NULL == toPlace)
		return ;

	std::string name = toPlace->getKsName();
	OB1NKS* ksi = new  OB1NKS(this, name, ks);
	ksi->putKsType(toPlace->KsType());
	int ind =_bb_state.find(ksi);
	if ( ind  == -42)
	{
		_bb_state.AddVertex(ksi); // add the KS node int he graph
		CreateLevel(toPlace, ksi);
		CreateTrigger(toPlace, ksi);
		CreateResult(toPlace, ksi);
		CreateValidity(toPlace, ksi);
	}
	delete(toPlace);
}
catch (...)
{
	erreur("Exception BB1 OB1Controler::addKS.", standardError, 0) ;
}
}

bool
OB1Controler::CreateLevel(KsInitStructure* toPlace, OB1NKS* ksi )
{
try
{
	if ((!toPlace) || (!ksi))
		return false ;

  if ((toPlace->Required() == NULL) || (toPlace->Required()->getLevelsize() <= 0))
  	return false ;

	OB1NLevel* lev = new OB1NLevel(this) ;
  ksi->addBijection(new OB1NodeLink(lev, new OB1Edge(REQUIRES))) ;
  _bb_state.AddVertex(lev) ;
  addRecquired(toPlace->Required(),lev) ;
  if (toPlace->getLevel()->size() > 0)
  	AddLevel(toPlace->getLevel(), lev) ;

	return true ;
}
catch (...)
{
	erreur("Exception BB1 OB1Controler::CreateLevel.", standardError, 0) ;
	return false ;
}
}

bool
OB1Controler::CreateTrigger(KsInitStructure* toPlace, OB1NKS* ksi )
{
try
{
	if ((!toPlace) || (!ksi))
		return false ;

  if (toPlace->Trigger()->size() <= 0)
  	return false ;

	OB1NTrigger* trig = new OB1NTrigger(this) ;
  ksi->addBijection(new OB1NodeLink(trig, new OB1Edge(TRIGERS))) ;
  _bb_state.AddVertex(trig) ;
  AddTrigger(toPlace->Trigger(), trig) ;
  
  return true ;
}
catch (...)
{
	erreur("Exception BB1 OB1Controler::CreateTrigger.", standardError, 0) ;
	return false ;
}
}

bool
OB1Controler::CreateValidity(KsInitStructure* toPlace, OB1NKS* ksi )
{
try
{
	if ((!toPlace) || (!ksi))
		return false ;

  if ((toPlace->Validity() == NULL) || (toPlace->Validity()->getLevelsize() <= 0))
  	return false ;

  OB1NValidity* validity = new OB1NValidity(this) ;
  ksi->addBijection(new OB1NodeLink(validity, new OB1Edge(VALIDATED))) ;
  _bb_state.AddVertex(validity) ;
  AddValidity(toPlace->Validity(), validity) ;

  return true ;
}
catch (...)
{
	erreur("Exception BB1 OB1Controler::CreateValidity.", standardError, 0) ;
	return false ;
}
}

bool
OB1Controler::CreateResult(KsInitStructure* toPlace, OB1NKS* ksi )
{
try
{
	if ((!toPlace) || (!ksi))
		return false ;

  if (toPlace->getResult()->size() <= 0)
  	return false ;

	OB1NResult* res = new OB1NResult(this) ;
	ksi->addBijection(new OB1NodeLink(res, new OB1Edge(CREATES))) ;
	_bb_state.AddVertex(res) ;
	AddResult(toPlace->getResult(), res) ;

	return true ;
}
catch (...)
{
	erreur("Exception BB1 OB1Controler::CreateResult.", standardError, 0) ;
	return false ;
}
}

void
OB1Controler::AddValidity(Level* levels, OB1NValidity* lev)
{
try
{
	if ((!levels) || (!lev))
		return ;

  register unsigned int validitySize = levels->getLevelsize();
  int complexite = levels->Complexity();
  int fiabilite =  levels->Quality();
  for (register unsigned i = 0; i < validitySize; i++)
  {
		INode* temp = &(*levels)[i];

		OB1NOther* va = new OB1NOther(this, new TypedVal(*(temp->labeled)));

		OB1NOther* va_temp = _bb_state.find_other_nodes(va);
		if (NULL != va_temp)
		{
			delete (va);
			va = va_temp;
		}
       // int ind =_bb_state.find(va);
        /*if (ind != -42)
          {
            delete (va);
            va =  dynamic_cast<OB1NOther* >(_bb_state[ind]);
          }*/
		else
			_bb_state.AddVertex(va);
		OB1EdgeLevel* ed00;
		ed00 = new OB1EdgeLevel(VALIDATED, createMask(temp->classTo), complexite, fiabilite, i);
		lev->addBijection(new OB1NodeLink(va,ed00), createMask(temp->classFrom));
	}
}
catch (...)
{
	erreur("Exception BB1 OB1Controler::AddValidity.", standardError, 0) ;
}
}

void
OB1Controler::AddLevel(std::vector<Level*>* level, OB1NLevel* lev)
{
try
{
	if ((!level) || (!lev))
		return ;

  if (level->empty())
		return ;

	int i = 0 ;
	for (std::vector<Level*>::iterator levelIter = level->begin() ; levelIter != level->end() ; levelIter++, i++)
  {
		//On detecte le nombre de variable present dans le level
		register unsigned int obliSize2 = (*levelIter)->getLevelsize() ;

		// Creation du noeud et du niveaux
		OB1NAnd* lev_i =  new OB1NAnd(this) ;
		OB1EdgeLevel* ed_i = new OB1EdgeLevel(IMPLIES, i) ;

		//ajout du noueud ET au noeud de level
		lev->addBijection(new OB1NodeLink(lev_i, ed_i)) ;

		// ajout du noeud et dans le graphe
		_bb_state.AddVertex(lev_i) ;
		int complexite = (*levelIter)->Complexity() ;
		int fiabilite = (*levelIter)->Quality() ;
		// Pour chaque variable du nievaux
		for (register unsigned  j = 0; j < obliSize2; j++)
		{
			// Creation du noeux
			INode* temp = &(*(*levelIter))[j] ;
			OB1NOther* va = new OB1NOther(this, new TypedVal(*(temp->labeled))) ;
			OB1NOther* va_temp = _bb_state.find_other_nodes(va) ;
			if (NULL != va_temp)
			{
				delete (va) ;
				va = va_temp ;
			}
			else
				_bb_state.AddVertex(va) ;

			OB1EdgeLevel* ed00 = new OB1EdgeLevel(IMPLIES, createMask(temp->classTo), complexite, fiabilite, i) ;
			lev_i->addBijection(new OB1NodeLink(va, ed00), createMask(temp->classFrom)) ;
		}
	}
}
catch (...)
{
	erreur("Exception BB1 OB1Controler::AddLevel.", standardError, 0) ;
}
}

void OB1Controler::addRecquired(Level* levels,OB1NLevel* lev)
{
try
{
  register unsigned int RecquiredSize = levels->getLevelsize();
  int complexite = levels->Complexity();
  int fiabilite =  levels->Quality();

  OB1NAnd* and =  new OB1NAnd(this);
  OB1EdgeLevel* ed = new OB1EdgeLevel(REQUIRES,0);
  lev->addBijection(new OB1NodeLink(and, ed));
  _bb_state.AddVertex(and);
  for (register unsigned int i =0; i < RecquiredSize; i++)
  {
        INode* temp = &(*levels)[i];
        OB1NOther* va = new OB1NOther(this,new TypedVal(*(temp->labeled)));
        OB1NOther* va_temp = _bb_state.find_other_nodes(va);
        if (NULL != va_temp)
        {
          delete (va);
          va = va_temp;
        }
        else
          _bb_state.AddVertex(va);
        OB1EdgeLevel* ed00 = new OB1EdgeLevel(REQUIRES, createMask(temp->classTo), complexite, fiabilite, i);
        and->addBijection(new OB1NodeLink(va,ed00), createMask(temp->classFrom));
  }
}
catch (...)
{
	erreur("Exception BB1 OB1Controler::addRecquired.", standardError, 0) ;
}
}

void
OB1Controler::AddTrigger(std::vector< Level* >* trigger,OB1NTrigger* trig)
{
try
{
	if ((!trigger) || (!trig))
		return ;

  if (trigger->empty())
		return ;

  register unsigned int levelSize = trigger->size();
  // Si les variables obligatoire existent

  // Pour chaque niveaux
  for (register unsigned i = 0; i <  levelSize; i++)
  {
    //On detecte le nombre de variable present dans le level
    register unsigned int obliSize2 = (*trigger)[i]->getLevelsize();
    if (obliSize2 > 1)
    {
    	// Creation du noeud et du niveaux
      OB1NAnd* lev_i =  new OB1NAnd(this) ;
      OB1Edge* ed_i = new OB1Edge(TRIGERS) ;

      //ajout du noueud ET au noeud de level
      trig->addBijection(new OB1NodeLink(lev_i, ed_i)) ;
      // ajout du noeud et dans le graphe
      _bb_state.AddVertex(lev_i) ;

      // Pour chaque variable du nievaux
      for (register unsigned j = 0; j < obliSize2; j++)
      {
        // Creation du noeux
        INode* temp = &(*(*trigger)[i])[j] ;
        OB1NOther* va = new OB1NOther(this,new TypedVal(*(temp->labeled))) ;
        //int ind =_bb_state.find(va);
        OB1NOther* va_temp = _bb_state.find_other_nodes(va) ;
        if (NULL != va_temp)
        {
          delete (va) ;
          va = va_temp ;
        }
        else
        	_bb_state.AddVertex(va) ;

        OB1Edge* ed00 ;
        ed00 = new OB1Edge( TRIGERS, createMask(temp->classTo) ) ;
        lev_i->addBijection(new OB1NodeLink(va,ed00), createMask(temp->classFrom)) ;
      }
    }
    else
    {
      INode* temp = &(*(*trigger)[i])[0] ;
      OB1NOther* va = new OB1NOther(this,new TypedVal(*(temp->labeled))) ;
      OB1Edge* ed = new OB1Edge(TRIGERS, createMask(temp->classTo)) ;

      OB1NOther* va_temp = _bb_state.find_other_nodes(va) ;
      if (NULL != va_temp)
      {
        delete (va) ;
        va = va_temp ;
      }

      //int ind =_bb_state.find(va);
      //if (ind != -42)
        //{
           //   delete (va);
          //    va =  dynamic_cast<OB1NOther* >(_bb_state[ind]);
        //}
      else
        _bb_state.AddVertex(va) ;
      trig->addBijection(new OB1NodeLink(va, ed), createMask(temp->classFrom)) ;
		}
	}
}
catch (...)
{
	erreur("Exception BB1 OB1Controler::AddTrigger.", standardError, 0) ;
}
}

int
OB1Controler::createMask(std::string mask)
{
  int result = 0;
  std::vector<std::string>* temp = parseClass(mask) ;

  register unsigned int taille = temp->size() ;
  register unsigned int i ;

	for (i = 0; i < taille; i++)
		result += (*_IClass)[ (*temp)[i] ] ;

  delete temp ;

	return result ;
}

// This function finds a node whose path is equal to the token's path
// If it doesn't find it, then it looks for a semantically equivalent node
//
// On cherche un noeud d'acceuil pour ce token (retour = true si on a trouv�)
// We look for a node to shelter this token (return true if found)
//
bool
OB1Controler::Dispatch(OB1Token* dis, bool createStat)
{
	if (dis == NULL)
		return false ;

  string sActionLog = string("Token ") + IntToString(dis->getNumero()) + string(" dispatch") ;

  bool result = false ;

  // R�cup�ration de l'objet blackboard attach� � ce token
  // We get the blackboard object related to this token
  //
	BB1Object* obj = dis->getObject() ;
	if (NULL == obj)
  {
  	sActionLog += string(" failed (no BB1Object)") ;
    BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trError) ;
  	return false ;
  }

	std::string explication("explication") ;
	const TypedVal& dispinf =  obj->Attributes(explication) ;
	TypedVal cher = dispinf ;
	if (&dispinf == NULL)
  {
  	sActionLog += string(" failed: no \"explication\" attribute found") ;
    BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trError) ;
		return false ;
  }

	// On cherche si un noeud h�berge d�j� un token de m�me chemin
  // We look for a node
	//
  // This OB1NOther node must be son of a Result or a Trigger
  //
	OB1NOther* tp = _bb_state.find_other_nodes(cher) ;
  if (NULL == tp)
  {
  	std::string	sSearched = cher.getString() ;
  	//
  	// Semantic search
  	//
    std::map<std::string, OB1NOther* >* pMapOfOtherNodes = _bb_state.getOtherNodes() ;
    if (pMapOfOtherNodes->empty())
    	return NULL ;

    int iMinimalDistance = pathDistanceInfinite ;
    OB1NOther* pBestCandidate = NULL ;

    NSFilGuide* pFilGuide = BB()->pContexte->getSuperviseur()->getFilGuide() ;

    std::map<std::string, OB1NOther*>::iterator curOnOther = pMapOfOtherNodes->begin() ;
    for (; curOnOther != pMapOfOtherNodes->end() ; curOnOther++)
    {
    	std::string sSortingId = (*curOnOther).first ;
      std::string sNodePath  = GetStringFromSortingId(sSortingId) ;

      if (sNodePath != std::string(""))
      {
      	// For the moment, we don't use semantics
        //
      	int iDistance = pFilGuide->pathDistance(&sNodePath, &sSearched, false) ;
      	if (iDistance < iMinimalDistance)
        	pBestCandidate = (*curOnOther).second ;
    	}
    }

    if (pBestCandidate != NULL)
    	tp = pBestCandidate ;
    else
    {
  		sActionLog += string(" failed: can't find a Node with same path") ;
    	BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trError) ;
    	return false ;
    }
  }
  if (tp->isLeaf())
  {
  	sActionLog += string(" on a leaf") ;
  	// sActionLog += string(" failed: can't find a result or trigger Node with same path") ;
    // BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trError) ;
    // return false ;
  }

  //
  // If the node didn't accept the token...
  //
	if (tp->IsPlace(dis, cher) == false)
  {
  	sActionLog += string(" failed: token refused by Node ") + tp->getString() ;
    BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trError) ;
    return false ;
  }

  //
  // If the node accepted the token...
  //
  result = true ;
  _lastTokenCreated = dis ;

  sActionLog += string(" succeeded on Node ") + tp->getString() ;
  BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubSteps) ;

  if (createStat)
  {
    std::vector<OB1Node*>* vect_result = tp->startNode() ;
    int size = vect_result->size();
    if (size > 0)
      for (int i =0; i < size; i++)
        AskTriggerOrder(dis, 5) ;
    delete(vect_result) ;
  }

	//run trigger
  return (result);
}

bool
OB1Controler::DispatchAgain(OB1Token* dis, bool createStat)
{
	if (dis == NULL)
		return false ;

  string sActionLog = string("Token ") + IntToString(dis->getNumero()) + string(" dispatch again") ;

  // R�cup�ration de l'objet blackboard attach� � ce token
  // We get the blackboard object related to this token
  //
	BB1Object* obj = dis->getObject();
	if (NULL == obj)
  {
  	sActionLog += string(" failed (no BB1Object)") ;
    BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trError) ;
  	return false ;
  }

  OB1Node* pPrevNode = dis->Node() ;
  if (!pPrevNode)
  {
  	sActionLog += string(" failed (no previous node)") ;
    BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trError) ;
  	return false ;
  }
  OB1NOther* pPreviousNode = static_cast <OB1NOther*>(pPrevNode) ;
  if (!pPreviousNode)
  {
  	sActionLog += string(" failed (previous node is not a OB1NOther)") ;
    BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trError) ;
  	return false ;
  }

	std::string explication("explication") ;
	const TypedVal& dispinf =  obj->Attributes(explication) ;
	TypedVal cher = dispinf ;
	if (&dispinf == NULL)
  {
  	sActionLog += string(" failed: no \"explication\" attribute found") ;
    BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trError) ;
		return false ;
  }

	// On cherche si un noeud h�berge d�j� un token de m�me chemin
  // We look for a node
	//
  // This OB1NOther node must be son of a Result or a Trigger
  //

  std::string	sSearched = cher.getString() ;
  //
  // Semantic search
  //
  std::map<std::string, OB1NOther* >* pMapOfOtherNodes = _bb_state.getOtherNodes() ;
  if (pMapOfOtherNodes->empty())
    return false ;

  int iMinimalDistance = pathDistanceInfinite ;
  OB1NOther* pBestCandidate = NULL ;

  NSFilGuide* pFilGuide = BB()->pContexte->getSuperviseur()->getFilGuide() ;

  std::map<std::string, OB1NOther*>::iterator curOnOther = pMapOfOtherNodes->begin() ;
  for (; curOnOther != pMapOfOtherNodes->end() ; curOnOther++)
  {
  	OB1NOther* pCandidateNode = (*curOnOther).second ;

    // Don't accept the previous node or leaf nodes
    //
    if ((NULL != pCandidateNode) && (pCandidateNode != pPreviousNode) && (!(pCandidateNode->isLeaf())))
    {
    	std::string sSortingId = (*curOnOther).first ;
    	std::string sNodePath  = GetStringFromSortingId(sSortingId) ;

    	if (sNodePath != std::string(""))
    	{
      	// For the moment, we don't use semantics
      	//
      	int iDistance = pFilGuide->pathDistance(&sNodePath, &sSearched, false) ;
      	if (iDistance < iMinimalDistance)
        	pBestCandidate = (*curOnOther).second ;
      }
    }
  }

  if (pBestCandidate == NULL)
  {
    sActionLog += string(" failed: can't find a Node") ;
    BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trError) ;
    return false ;
  }

  //
  // If the node, didn't accept the token...
  //
	if (pBestCandidate->IsPlace(dis, cher) == false)
  {
  	sActionLog += string(" failed: token refused by Node ") + pBestCandidate->getString() ;
    BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trError) ;
    return false ;
  }

  // _lastTokenCreated = dis ;  token is not new

  // modifying the token
  //


  sActionLog += string(" succeeded on Node ") + pBestCandidate->getString() ;
  BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubSteps) ;

  if (createStat)
  {
    std::vector<OB1Node*>* vect_result = pBestCandidate->startNode() ;
    int size = vect_result->size();
    if (size > 0)
      for (int i =0; i < size; i++)
        AskTriggerOrder(dis, 5) ;
    delete(vect_result) ;
  }

	//run trigger
  return true ;
}

void
OB1Controler::AddResult(std::vector<INode *>* temp, OB1NResult *res)
{
try
{
	if ((!temp) || (!res))
		return ;

	if (temp->empty())
		return ;

  register unsigned int i ;
  register unsigned int resSize = temp->size() ;

  for (i = 0; i < resSize; i++)
  {
    INode* in = (*temp)[i] ;
    OB1NOther* va = new OB1NOther(this, new TypedVal(*(in->labeled))) ;
    OB1NOther* va_temp = _bb_state.find_other_nodes(va) ;
    if (NULL != va_temp)
    {
      delete (va) ;
      va = va_temp ;
    }
    else
      _bb_state.AddVertex(va) ;
      
    OB1Edge *ed = new OB1Edge(CREATES, createMask(in->classTo)) ;
    res->addBijection(new OB1NodeLink(va, ed), createMask(in->classFrom)) ;
  }
}
catch (...)
{
	erreur("Exception BB1 OB1Controler::AddResult.", standardError, 0) ;
}
}

// fonction utilitaire
std::vector<std::string>*
parseClass(std::string& inp)
{
try
{
  std::vector<std::string>* result = new std::vector<std::string>();
  while (inp.find(" ") != -1)
  {
    int temp = inp.find(" ");
    inp = inp.erase( temp,1);
  }
  while (inp.size() != 0)
  {
    int temp = inp.find("||");
    if (temp != -1)
      {
      result->push_back(inp.substr( 0, temp));
      inp = inp.erase( 0,temp+2);
      }
    else
      {
      result->push_back(inp);
      inp = inp.erase( 0,inp.size());
      }
  }
  return (result);
}
catch (...)
{
	erreur("Exception BB1 OB1Controler parseClass.", standardError, 0) ;
	return NULL ;
}
}

// FIXME
// Ameliorer l'ago : le plus bourrin possible actuellment
OB1Token*
OB1Controler::find(TypedVal& temp, std::string clasName)
{
	std::string	sSearched = temp.getString() ;
  if (sSearched == std::string(""))
  	return NULL ;

	// Exact search
  //
  OB1NOther* nod = _bb_state.find_other_nodes(temp) ;

/*
  if (NULL == nod)
  {
  	//
  	// Semantic search
  	//
    std::map<std::string, OB1NOther* >* pMapOfOtherNodes = _bb_state.getOtherNodes() ;
    if (pMapOfOtherNodes->empty())
    	return NULL ;

    int iMinimalDistance = pathDistanceInfinite ;
    OB1NOther* pBestCandidate = NULL ;

    NSFilGuide* pFilGuide = BB()->pContexte->getSuperviseur()->getFilGuide() ;

    std::map<std::string, OB1NOther*>::iterator curOnOther = pMapOfOtherNodes->begin() ;
    for (; curOnOther != pMapOfOtherNodes->end() ; curOnOther++)
    {
    	std::string sSortingId = (*curOnOther).first ;
      std::string sNodePath  = GetStringFromSortingId(sSortingId) ;

      if (sNodePath != std::string(""))
      {
      	// For the moment, we don't use semantics
        //
      	int iDistance = pFilGuide->pathDistance(&sNodePath, &sSearched, false) ;
      	if (iDistance < iMinimalDistance)
        	pBestCandidate = (*curOnOther).second ;
    	}
    }

    if (pBestCandidate != NULL)
    	nod = pBestCandidate ;
  }
*/

  if (NULL != nod)
  {
  	int clas = (*_IClass)[clasName] ;
  	OB1Token* test_tok =  nod->getLastToken(clas) ;
    return (test_tok) ;
  }

  return NULL ;
}

std::string
OB1Controler::StrategyCount()
{
  std::string result="" ;
  char* id = new char [16] ;
  itoa(_StrategyCounter, id, 10) ;
  result.append(id) ;
  delete[] id ;
  _StrategyCounter++ ;
  return (result) ;
}

// Cherche un noeud d'accueil, puis (si on l'a trouv�), lance une strat�gie
//
OB1Strategy*
OB1Controler::AskDeterminicOrder(OB1Token* token, int priority)
{
	if (!token)
		return NULL ;

  OB1Strategy* result = NULL;
	//
	// On cherche si on peut placer le token sur un noeud
	//
  bool havePlace = Dispatch(token);
  int token_clas = token->Class();
  int clas =  token_clas;
	//
	// Si c'est le cas, on peut lancer une strat�gie
	//
  if (true == havePlace)           /* you can run a strategy */
    result = _sheduler.addStrategie(token, priority, clas) ;   // FIXME EROOR

  return (result);
}

OB1Strategy* OB1Controler::AskTriggerOrder(OB1Token* token, int priority)
{
	if (!token)
		return NULL ;

  OB1Strategy* result = NULL ;
  int token_clas = token->Class() ;
  int clas =  token_clas ;
  result = _sheduler.addStrategie(token, priority, clas) ;   // FIXME EROOR
  return (result) ;
}

void OB1Controler::Execute()
{
  OB1Strategy* strat2Compute = _sheduler.NextStrategyToCompute() ; /* get the strategy to execute */
  if (NULL == strat2Compute)
  	return ;

  TStrategyType stType =  strat2Compute->geStratType() ;
  if (stType == DETERMINISTIC)
  	ExecuteDeterministicAction(&strat2Compute) ;
  else if (stType == OPPORTUNIST)
  	ExecuteOpportunisticAction(strat2Compute) ;
}

bool OB1Controler::ExecuteDeterministicAction(OB1Strategy** temp)
{
	if (*temp == NULL)
		return true ;

  if ((*temp)->getStrategyState() == ANSWER)  //we' have the result
  {
    (*temp)->ToDelete() ;
    _sheduler.GarbageCollecting() ;
    *temp = NULL ;
    return (true) ;
  }
  if ((*temp)->getStrategyState() == NO_ANSWER)  //we cannot have the result
  {
    (*temp)->ToDelete() ;
    _sheduler.GarbageCollecting() ;
    *temp = NULL ;
    return (true) ;
  }
  if ((*temp)->getStrategyState() == IN_EXECUTION)  //we continue execution
  {
		StrategyState iState = Searching(*temp) ;
		if (iState == IN_EXECUTION)
			return (false) ;
		else
			return (true) ;
  }
  //
  // We shouldn't be there, so we clean and quit
  //
  (*temp)->inc() ;

  (*temp)->ToDelete() ;
	_sheduler.GarbageCollecting() ;
	*temp = NULL ;
	return (true) ;
}

StrategyState
OB1Controler::Searching(OB1Strategy* temp)
{
	if (!temp || temp->Delete())
		return NO_ANSWER ;

	// stupid, but sometime we get a bad object here
	if (temp->ID() == "")
		return NO_ANSWER ;

	OB1SubStrategy* tempo = (OB1SubStrategy*) temp ;
	while ((tempo != NULL) && (!(tempo->getSubStrategy().empty())))
	{
		//  if (tempo->getSubStrategy().back()->getStrategyState() != NO_ANSWER)
		tempo = tempo->getSubStrategy().back() ;
	}
  if ((tempo != NULL) && (tempo != temp->Root()))
	{
		switch(tempo->Node()->getType())
		{
			case KS_NODE:
        DeterministicKS(tempo);
        break;
			case OTHER_NODE:
        DeterministicNode(tempo);
        break;
		}
	}
	else
	{
		if ((temp->Node() != NULL) && (temp->Node()->getType() == OTHER_NODE) && (((OB1NOther*)temp->Node())->isLeaf() == true) && (((OB1NOther*)temp->Node())->IsComputed() == false ))
			DeterministicNode(temp) ;
		else if (tempo != NULL)
			tempo->putComputationState(NO_ANSWER) ;
    else
    	return NO_ANSWER ;
	}

  return IN_EXECUTION ;
}

bool
OB1Controler::DeterministicKS(OB1SubStrategy* strat)
{
	if (!strat)
		return false ;

  OB1NKS* ks = (OB1NKS*)strat->Node() ;
  if (!ks)
		return false ;

  ks->ComputeValidity() ; // Compute the validity of the concept
  switch (ks->ContextValidity())
  {
    case NO_COMPUTATION:    // We detect we are in the good case or we don't know and we consider it can be applied
    case PROPOSABLE:
    case VALID:
      if (true == ks->isActivable())
      {
        ks->ExecuteKS(ks->getActionStructure(strat), true) ;
        if (strat->Root() != NULL)
        	ks->UnFlag(strat->Root()->Priority());
        if (strat->Father() != NULL) // If it's not the root node
        {
        	OB1SubStrategy* pSubStrat = strat->Father() ;
          pSubStrat->RemoveStrategy();
      	}
      }
      // Add PA
      else
      {
        if (strat->Father() != NULL) // If it's not the root node
        {
        	OB1SubStrategy* pSubStrat = strat->Father() ;
          pSubStrat->RemoveStrategy();
      	}
      }
      // End Add PA
      break;
    case INVALID:           // We have to change the case
    default:                // For robustness : if ComputeValidity is berzeck,
                            //                  we don't enter an infinite loop
    	if (strat->Root() != NULL)
      	ks->UnFlag(strat->Root()->Priority());
      if (strat->Father() != NULL) // If it's not the root node
      	strat->Father()->RemoveStrategy();
    break;
  }
  return true ;
}

bool
OB1Controler::DeterministicNode(OB1SubStrategy* strat)
{
	if (!strat)
		return false ;

  OB1NOther* other = (OB1NOther*)strat->Node() ;
  switch (strat->getStrategyState())
  {
    case IN_EXECUTION:
      if (true == strat->HasWantedClass())   // On a une reponse
        strat->Father()->RemoveStrategy(); //we remove the question
      else
      {
      	if (other)
        {
        	bool bInKsDirection = !(other->isLeaf()) ;
          int iResult = other->createStrategy(strat, bInKsDirection) ;  //We check we cannot find another strategy

          //
          // No KS seems to be able to do the job
          //
          if ((iResult != 1) || (strat->getSubStrategy().size() == 0))
          {
          	bool bMustStop = false ;

            if (true == other->isLeaf())  // If it is a leaf
            {
              if (other->IsComputed() == false) // SI on a pas d�ja execut� la fonction par d�fault
              {
                bool bSuccess = other->Controler()->_DefaultFunc(other->getName(), other->Controler()->BB()->pContexte->getSuperviseur()->getBBinterface());
                if (bSuccess)
                	other->Computed() ;
                else
                {
                	int iPriority = strat->Root()->Priority() ;
                	OB1Token* pToken = strat->Token() ;
                  bool bHasPlace = DispatchAgain(pToken) ;
  								if (true == bHasPlace)
    								OB1Strategy* pResult = _sheduler.addStrategie(pToken, iPriority, pToken->Class()) ;
                  else
                  {
                  	NSPatPathoArray* respat = NULL ;

                    std::string sDaf = other->getName().getString() ;
  									std::string temp = ParseNautilusPath(sDaf) ;

										// Creationd e la reponse
                    BB1KB				*informationKB = other->Controler()->BB()->KBNamed("InformationKB") ;
                    BB1Class		*answer 	   = other->Controler()->BB()->ClassNamed("Answer") ;

                    AttValPair	label		("label", string("Default calcul")) ;
                    AttValPair	sfrom		("sfrom", string("Default Control Calculus")) ;
                    AttValPair  Explication("explication", sDaf);
                    //
                    // true : because we don't duplicate respat, so we must not delete respat
                    //
                    AttValPair node ("node", respat, true) ;

                    std::string id = "default" ;
                    char* nb = new char[10] ;
                    itoa(other->Controler()->BB()->getNBObject(), nb, 10) ;
                    id.append(nb) ;
                    delete[] nb ;

                    // cr�ation de la r�ponse
                    /* BB1AppInst *objectAnswer = */ answer->MakeInstance(id,Explication, *informationKB,
                                                    Collect(&label, &node, &sfrom), NULL, true) ;

                    other->Computed() ;
                  }
                }
              }
              else
              	bMustStop = true ;
            }
            else
            	bMustStop = true ;

            if (bMustStop)
            {
            	// Modif PA : si seul Father est mis en NO_ANSWER, on continue
              // � boucler sur strat (faut-il le supprimer ?)
              strat->Father()->RemoveStrategy() ;
              // strat->putComputationState(NO_ANSWER); -> BOUCLE
              // Fin modif PA
              strat->Father()->putComputationState(NO_ANSWER) ; // On a pas de reponse est on arrivera pas au bout
            }
          }
        }
        else
        	strat->Father()->RemoveStrategy() ;
      }
      break ;
  	case ANSWER :
      strat->Father()->RemoveStrategy() ;
  		break ;
  }
  return (true);
}

bool OB1Controler::ExecuteOpportunisticAction(OB1Strategy* strat)
{
	if (!strat)
		return false ;

  OB1Node* pStratNode = strat->Node() ;
  if (NULL == pStratNode)
  	return false ;

  OB1NKS* pKSNode = NULL ;

	if      (pStratNode->getType() == KS_NODE)
  	pKSNode = dynamic_cast<OB1NKS * >(pStratNode) ;
	else if (pStratNode->getType() == OTHER_NODE)
  {
  	// to be developped
	}

  if (NULL == pKSNode)
		return false ;

	if (pKSNode->KsState() == FREE_AND_RUNNING)
	{
  	ValidityContextType valid = pKSNode->ContextValidity() ;
    bool                bActi = pKSNode->isActivable() ;
    KSType              ksTyp = pKSNode->KsType() ;

    if ((ksTyp == USER_WINDOWS_KS) || (ksTyp == USER_KS))
    {
    	string sActionLog = string("KS node ") + pKSNode->getKSName() + string(" is candidate for execute opportunistic action") ;
      BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSteps) ;
    }

    if ((ksTyp != SVCE_WINDOWS_KS) && (bActi) && (valid != INVALID))
    // we check if it has not been answered yet
    {
    	OB1NResult* result = pKSNode->getResultNode() ;
      if (result != NULL) // we check if only one result have been answer . It's only possible when the ks has a result
      {
      	bool bResult = result->hasResult() ;
        if (false == bResult)
        	pKSNode->ExecuteKS(pKSNode->getActionStructure(), true) ;
      }
      else     /* if the ks doesn't create BB1Object then we check if the executed attributes have been used */
      {
      	MarkerObject* tempMarker = pKSNode->Attributes(std::string("executed")) ;
        if (NULL == tempMarker)
        {
        	if (valid == NO_COMPUTATION)
          {
          	pKSNode->ComputeValidity() ;
            if (pKSNode->ContextValidity() == VALID)
            	pKSNode->ExecuteKS(pKSNode->getActionStructure(), true) ;
          }
        }
      }
    }
  }
  return (true) ;
}

/*
bool OB1Controler::ExecuteOpportunisticAction(OB1Strategy* temp)
{
  register unsigned int i ;
  register unsigned end = _bb_state.numVertices() ;
  for (i = 0; i < end; i++)  //for each ks
	{
		if (_bb_state[i]->getType() == KS_NODE)
		{
			OB1NKS* ks = dynamic_cast<OB1NKS*>(_bb_state[i]) ;
			if ((NULL != ks) && (ks->KsState() == FREE_AND_RUNNING))
			{
				ValidityContextType valid   = ks->ContextValidity() ;
        bool                bActi   = ks->isActivable() ;

        KSType              ksTyp   = ks->KsType() ;
        if ((ksTyp == USER_WINDOWS_KS) || (ksTyp == USER_KS))
        {
        	string sActionLog = string("KS node ") + ks->getKSName() + string(" is candidate for execute opportunistic action") ;
    			BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSteps) ;
        }

				// if ((ksTyp != WINDOWS_KS) && (bActi) && (valid != INVALID))
        if ((ksTyp != SVCE_WINDOWS_KS) && (bActi) && (valid != INVALID))

        // we check if it has not been answered yet
        // if ((bActi) && (valid != INVALID))
				{
					OB1NResult* result = ks->getResultNode();
					if (result != NULL) // we check if only one result have been answer . It's only possible when the ks has a result
					{
						bool reuslt = result->hasResult();
						if (false == reuslt)
							ks->ExecuteKS(ks->getActionStructure(), true) ;
					}
					else     // if the ks doesn't create BB1Object then we check if the executed attributes have been used
					{
						MarkerObject* tempMarker = ks->Attributes(std::string("executed"));
						if (NULL == tempMarker)
						{
							if (valid == NO_COMPUTATION)
							{
								ks->ComputeValidity() ;
								if (ks->ContextValidity() == VALID)
									ks->ExecuteKS(ks->getActionStructure(), true) ;
							}
						}
					}
				}
			}
		}
	}
  return (true) ;
}
*/

void OB1Controler::RunInOpportunisticMode(int nb_tour)
{
  _sheduler.runOppotunisticDuring(nb_tour);
}


void OB1Controler::ReInitControler()
{
  register unsigned end = _bb_state.numVertices();
  for (register unsigned i = 0; i < end; i++)
    _bb_state[i]->Reinit();
  _sheduler.ReInit();
  _StrategyCounter = 0;
  _lastTokenCreated = NULL;
}


