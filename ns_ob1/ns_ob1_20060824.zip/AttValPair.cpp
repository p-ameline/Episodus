/*! -----------------------------------------------------------------------------
* AttValPair.cpp
* -----------------------------------------------------------------------------
* $Revision: 1.2 $
* $Author: david $
* $Date: 2004/04/15 14:13:37 $
* -----------------------------------------------------------------------------
* -----------------------------------------------------------------------------
* FLP  - 2002
* -----------------------------------------------------------------------------   */

//#define _DEBUG_

#include <iostream.h>   // for operator<<(...)

#include <string>

#ifndef _OWLDLL
#include <stl.h>
#else
#include <vector.h>
#endif

#ifndef _OWLDLL
#include "AttValPair.h"
#include "nsbb\nspatpat.h"
#else
#include "ns_ob1\AttValPair.h"
#include "nsbb\nspatpat.h"
#endif

#include "partage\nsdivfct.h"

#ifdef __GNUC__
//#pragma implementation
#endif // __GNUC__

AttValPair::AttValPair(const string& a, const TypedVal& tv)
  : att(a)
{
  val = tv ; // Because using an initializer didn't work
}


// -----------------------------------------------------------------------------
// constructeur copie -- add fab
// -----------------------------------------------------------------------------

AttValPair::AttValPair(const AttValPair& avp)
  : att(avp.att)
{
	val = avp.val ;
}


AttValPair&	AttValPair::operator=(AttValPair& avp)
{
	att = avp.att ;
	val = avp.val ;

	return *this ;
}


//AttValPair::~AttValPair()
//{
	/*if (AttributeName() == "node")
	{
		NSPatPathoArray *pPatPatho = val.getPatPatho() ;
    if (pPatPatho != NULL)
		  delete pPatPatho ;
	}

	if (AttributeName() == "paths")
	{
		PathsList	*pPaths = val.getPaths() ;
		if (pPaths)
			delete pPaths ; // le vider se fait dans le destructeur
	}       */
 	//val = NULL ;
//} */


// -----------------------------------------------------------------------------
//  Send to the output stream a textual representation of the attribute-value
//  pair
// -----------------------------------------------------------------------------

std::ostream& operator <<(std::ostream& os, const AttValPair& avp)
{
	os << "(" << avp.AttributeName() << " " << avp.AttributeValue() << ")" ;
  return (os) ;
}


// -----------------------------------------------------------------------------
//  Empty out a set of AttValPair
// -----------------------------------------------------------------------------

void ClearSetOfAVP(AVPSet *avpset)
{
#ifdef _DEBUG_
  cout << "-- DEBUG:: void ClearSetOfAVP(avpset)\n\n" ;
#endif
  if ((NULL != avpset) || avpset->empty())
    return ;

  register unsigned int end =  avpset->size();
  for (register unsigned int i = 0; i < end; i++)
  {
    try{
    AttValPair* temp =   (*avpset)[i];
    if (NULL !=  temp)
    {
      delete (temp);
      temp = NULL;
    }
    }
    catch(...)
    {
      break;
    }
  }
	/*for (AVPIter p = avpset->begin() ; p != avpset->end() ; )
	{
    ///
    if (*p != NULL)  // Add by tabun
    delete (*p) ;
    avpset->erase(p) ;
  }    */
	avpset->clear() ;
}
