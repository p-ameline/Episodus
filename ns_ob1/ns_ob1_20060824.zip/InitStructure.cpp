/*
** Copyright Nautilus, (10/9/2004)
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/

#include "ns_ob1\InitStructure.h"
#include "ns_ob1\BB1Types.h"


INode::INode(TypedVal* label, std::string classo ,std::string clasorm)
{
  labeled = label;
  classTo = classo;
  classFrom = clasorm;
}

INode::INode(INode& temp)
{
  labeled   = temp.labeled;
  classFrom = temp.classFrom;
  classTo   = temp.classTo;
}

INode::~INode()
{
  if (labeled != NULL)
    delete(labeled);
}

std::string INode::toHTML()
{
  std::string result = "";
  //result= "[INODE : (" + labeled +"," + classType + ")]<br />";
  return (result);
}

/*
** Default constructeur
*/
Level::Level()
{
  level = new std::vector<INode*>();
  complexity = 0;
  quality =0;
}

/*
** Destructeur
*/
Level::~Level()
{
	if ((level != NULL) && (!(level->empty())))
  {
		unsigned int end =  level->size();
		for (unsigned int i = 0; i < end; i++)
    	if ((*level)[i] != NULL)
      	delete((*level)[i]) ;
		level->clear() ;
		delete(level) ;
  }
}

Level::Level(int complex, int qualit):complexity(complex), quality(qualit)
{
	level = new std::vector<INode* >();
}

/*
** Copy constructor
*/
Level::Level(Level& lev):complexity(lev.Complexity()), quality(lev.Quality())
{
  level = new std::vector<INode* >();
  unsigned int fin = lev.getLevelsize();
  for (unsigned int i = 0; i < fin; i++)
  {
    INode* temp = new INode( lev[i] ) ;
    level->push_back(temp );
  }
}

/*
** Add an optionnal triggered condition
*/
void Level::addLevelNode(TypedVal* tri, std::string& classto,std::string& classfrom)
{
  INode* temp = new INode(tri, classto, classfrom);
  level->push_back(temp);
}

inline
INode&	Level::operator[] (int i)
{
  return (  (*(*level)[i]) );
}


void  Level::print(std::ostream& ostr) const
{
ostr <<  "Level";
}

std::string Level::toHTML()
{
  char *qualit = new char[10];
  char *complex = new char[10];
  itoa(quality, qualit, 10);
  itoa(complexity, complex, 10);
  std::string temp="<br />[Level <br /> \n";

  temp += "<ul><li>quality:";
  temp.append(qualit);
  temp  += "</li><li>Complexity :";
  temp.append(complex);
  temp += "</li><li><ul>";
  for (unsigned int i = 0; i< level->size(); i++)
      temp +=  (*level)[i]->toHTML();
  temp+="]<br /></ul></li></ul>EndLevel]<br />" ;
  delete(qualit);
  delete(complex);
  return (temp);

}

/*
** Default constructor
*/
KsInitStructure::KsInitStructure()
{
	_Result = new std::vector<INode* >();
	_Levels = new std::vector<Level* >();
	_Trigerred = new std::vector<Level* >();
	_ValidityVar = NULL;
	_Required = NULL;
}

/*
** Default constructor
*/
KsInitStructure::KsInitStructure(char* name)
{
  _Result = new std::vector<INode* >();
  _Levels = new std::vector<Level* >();
  _Trigerred = new std::vector<Level* >();
  _ksName = std::string(name);
  _ValidityVar = NULL;
  _Required = NULL;
}

/*
** Destructor of  KsInitStructure
** Destroy all the data contains in the class
*/
KsInitStructure::~KsInitStructure()
{
  register unsigned int i = 0;
  unsigned int sizeLevels = _Levels->size();
  for (i = 0; i < sizeLevels; i++)
    delete ( (*_Levels)[i] );
  delete  (_Levels);
  if (_Result != NULL)
    {
    delete (_Result);
    _Result = NULL;
    }
  if (_Required != NULL)
  {
    delete (_Required);
    _Required = NULL;
  }
  if( NULL !=  _ValidityVar)
  {
    delete(_ValidityVar);
    _ValidityVar = NULL;
  }
  unsigned int sizeTRigerrered = _Trigerred->size();
  for (i = 0; i <   sizeTRigerrered; i ++)
    delete( (*_Trigerred)[i]);
  delete(_Trigerred);
}

/*
** Return the  KS name
*/
inline
std::string KsInitStructure::getKsName() const
{
  return _ksName;
}

/*
** overloading of operator =
*/
void KsInitStructure::operator=(KsInitStructure &temp)
{
  _Levels->clear();
  _Trigerred->clear();
  register unsigned int i = 0;
  unsigned int sizeLevel = temp.getExecutionNumber();

  for (i = 0; i < sizeLevel; i++)
  {
    _Levels->push_back(new Level(temp[i]) );
  }

  unsigned int sizeTrigerred =  temp.getNumberOfTrigerred();
  for (i = 0; i < sizeTrigerred; i++)
  {
    _Trigerred->push_back( new Level(*temp.getTrigerredAtRank(i)) );
  }

  for (int i = 0; i < getNumberOfResult(); i++)
    {
      (*_Result)[i] = new INode( *((*temp.getResult())[i]) );
    }
  _ksName = temp.getKsName();
}


/*
** copy constructor
*/
KsInitStructure::KsInitStructure(KsInitStructure& ini)
{
  _Levels = new std::vector<Level* >();
  _Trigerred = new std::vector<Level* > ();
  register unsigned int  i = 0;
  unsigned int sizeLevel = ini.getExecutionNumber();

  for (i = 0; i < sizeLevel; i++)
  {
    _Levels->push_back(new Level(ini[i] ) );
  }

  unsigned int sizeTrigerred =  ini.getNumberOfTrigerred();
  for (i = 0; i < sizeTrigerred; i++)
  {
    _Trigerred->push_back( new Level(*ini.getTrigerredAtRank(i)) );
  }

  for (int i = 0; i < getNumberOfResult(); i++)
  {
    (*_Result)[i] = new INode( *((*ini.getResult())[i]) );
  }
  _ksName = ini.getKsName();
}

inline
Level&	KsInitStructure::operator[] (int i)
{
  return ( *(*_Levels)[i]);
}



/*
** return the number of level
*/
inline
int KsInitStructure::getExecutionNumber()const
{
  return (_Levels->size());
}

std::string KsInitStructure::toHTML()
{
  std::string result ="";
  result += "<br />[InitStructure : <br />\n";
  result += "Nom du ks : " + _ksName + "<br />";
  result += "<br />Nombre de niveau de trigerred condition :";
  char* tn = new char[10];
  itoa(_Trigerred->size(), tn, 10);
  result.append(tn);
  delete(tn);
  result += "<br /> ->Details -><ul>" ;
  for (unsigned int i = 0; i < _Trigerred->size(); i++)
    {
      result += "<li>" + (*_Trigerred)[i]->toHTML();
      result += "</li>";
    }
  result += "</ul><br /> \n";
  result += "Nombre de niveaux de variables: ";
  char* tn2 = new char[10];
  itoa(_Levels->size(), tn2, 10);
  result.append(tn2);
  delete(tn2);
  result += "<br /> ->details -> <ul>";
  for (unsigned int i = 0; i < _Levels->size(); i++)
  {
    result += "<li>" + (*_Levels)[i]->toHTML();
    result += "</li>";
  }
  result += "</ul><br /> \n";
  result += "Nombre de r�sultats fournies: ";
  char* tn3 = new char[10];
  itoa(_Levels->size(), tn3, 10);
  result.append(tn3);
  delete(tn3);
  result += "<br /> ->details -> <ul>";
  for (unsigned int i = 0; i < _Result->size(); i++)
  {
    result += "<li>" + (*_Result)[i]->toHTML();
    result += "</li>";
  }
  result += "</ul><br /> ]\n";
  return result;
}

/*
** Return the i trigerred
*/
inline
Level* KsInitStructure::getTrigerredAtRank(int i)
{
	return ((*_Trigerred)[i]);
}

/*
** Methode naive : FIXME
*/
bool KsInitStructure::checkCourtCircuit()
{
   /*   std::vector<std::string> _buffer;
      register unsigned int i;
      unsigned int fin = _Trigerred->size();
      for (i = 0; i < fin; i++)
      {
        for (int j = 0; j <   (*_Trigerred)[i]->getLevelsize(); j++)
          {
            for (unsigned int k = 0; k < _buffer.size(); k++)
              if (_buffer[k] ==(*(*_Trigerred)[i])[j])
                return false;
            _buffer.push_back((*(*_Trigerred)[i])[j]);
          }
      }
      return true;    */
      return true;
}

