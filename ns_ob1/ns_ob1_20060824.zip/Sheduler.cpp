/*
** Copyright Nautilus, (10/9/2004)
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/
#include "ns_ob1\BB1BB.h"
#include "ns_ob1\OB1Controler.h"
#include "ns_ob1\OB1Node.h"
#include "ns_ob1\OB1Sheduler.h"

const int OPPORTUNISTIC_PRIORITY = 2;

Sheduler::Sheduler(OB1Controler* temp)
{
	control = temp;

	ReInit() ;
}

ShedulerAlgorithm Sheduler::getAlgorithm()
{
  return (_shedulingAlgorithm);
}

void Sheduler::putAlgoritm(ShedulerAlgorithm temp)
{
  _shedulingAlgorithm = temp;
}

void Sheduler::ReInit()
{
try
{
	ClearAllStrategies() ;
  current_problem = NULL ;

	// Ajout de la strategie opportuniste
  //
  OB1Strategy* Oppor = new OB1Strategy(control, control->StrategyCount(), 0, OPPORTUNIST, OPPORTUNISTIC_PRIORITY) ;
  _Controler_History_X.push_back(Oppor) ;
  _shedulingAlgorithm = STOCHASTIC ;
  _totalPriority = OPPORTUNISTIC_PRIORITY ;
}
catch (...)
{
	erreur("Exception BB1 Sheduler::ReInit.", standardError, 0) ;
}
}

void
Sheduler::createStrategyPath(OB1Strategy* temp)
{
	if (NULL == temp)
  	return ;

  OB1Token* tempoN = temp->Token() ;
  if (NULL == tempoN)
  	return ;

	OB1Node* no = tempoN->Node() ;
  if (no == NULL)
  	return ;

  OB1NOther* pOtherNode = dynamic_cast<OB1NOther*> (no) ;
  if (!pOtherNode)
  	no->createStrategy(temp, true) ;
  else
  {
  	bool bInKsDirection = !(pOtherNode->isLeaf()) ;
    int iResult = pOtherNode->createStrategy(temp, bInKsDirection) ;
  }
}

OB1Strategy*
Sheduler::addStrategie(OB1Token* token, int priority, int clas)
{
try
{
	if (!token)
		return NULL ;

  string sActionLog = string("Scheduler is creating a strategy for token ") + IntToString(token->getNumero()) ;
  control->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubSteps) ;

  OB1Strategy* temp = new OB1Strategy(control, control->StrategyCount(), clas, token, priority, token->getCreatedCycle()) ;
  createStrategyPath(temp) ;
  _totalPriority += priority ;
  _Controler_History_X.push_back(temp) ;

  sActionLog = string("Strategy created by Scheduler (") + string("Id=") + temp->ID() + string(")") ;
  control->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubSteps) ;

  return (temp) ;
}
catch (...)
{
	erreur("Exception BB1 Sheduler::addStrategie.", standardError, 0) ;
  return NULL ;
}
}

Sheduler::~Sheduler()
{
	ClearAllStrategies() ;
}

void Sheduler::putNewCurrentProblem(OB1Strategy* temp)
{
  current_problem = temp ;
}

void
Sheduler::runOppotunisticDuring(int Time)
{
  _during = Time;
}

int
Sheduler::getTotalOfPriority()
{
  int result = 0;
  if (!(_Controler_History_X.empty()))
		for (std::vector<OB1Strategy*>::iterator stratIter = _Controler_History_X.begin() ; stratIter != _Controler_History_X.end() ; stratIter++)
			result += (*stratIter)->Priority() ;

  return (result) ;
}

OB1Strategy*
Sheduler::NextStrategyToCompute()
{
	if (_Controler_History_X.empty())
		return NULL ;

  OB1Strategy* pCandidateStrat = NULL ;

  int min = 1000;
  int tot = _totalPriority;

  switch(_shedulingAlgorithm)
  {
		case DETERMINIST:
    	for (std::vector<OB1Strategy*>::iterator stratIter = _Controler_History_X.begin() ; stratIter != _Controler_History_X.end() ; stratIter++)
      {
      	float percent = (int)((*stratIter)->Priority() * 100) /tot ;
      	float calc = (*stratIter)->getCountCycle() /  percent ;
      	if (calc < min)
        {
          min = calc ;
          pCandidateStrat = *stratIter ;
        }
			}
  		break ;

		case STOCHASTIC:
			int incSum = 0 ;
			int left = random(_totalPriority) ;
			for (std::vector<OB1Strategy*>::iterator stratIter = _Controler_History_X.begin() ; stratIter != _Controler_History_X.end() ; stratIter++)
      {
      	pCandidateStrat = *stratIter ;

				incSum +=  (int)(*stratIter)->Priority();
				if (incSum >= left)
          break ;
			}
			break ;
	}

	return pCandidateStrat ;
}

OB1Strategy*
Sheduler::GetCurrentStrategy()
{
  return (current_problem);
}

void
Sheduler::RemoveStrategy(std::vector<OB1Strategy*>::iterator& index)
{
	if (!index)
		return ;

  _totalPriority = (*index)->Priority();
  delete(*index);
  _Controler_History_X.erase(index);
}

void
Sheduler::ClearAllStrategies()
{
	if (_Controler_History_X.empty())
		return ;

	for (std::vector<OB1Strategy*>::iterator stratIter = _Controler_History_X.begin() ; stratIter != _Controler_History_X.end() ; )
	{
		if (*stratIter)
			delete *stratIter ;
		_Controler_History_X.erase(stratIter) ;
	}
}

void
Sheduler::GarbageCollecting()
{
	if (_Controler_History_X.empty())
		return ;

  for (std::vector<OB1Strategy* >::iterator iter = _Controler_History_X.begin(); iter != _Controler_History_X.end(); )
		if ((*iter)->Delete() == true)
		{
			delete(*iter) ;
			_Controler_History_X.erase(iter) ;
			break ;
		}
		else
			iter++ ;
}

std::vector<OB1Strategy*>::iterator& Sheduler::findStrategy(OB1Strategy* temp)
{
	std::vector<OB1Strategy*>::iterator* find = new std::vector<OB1Strategy*>::iterator() ;

try
{
	if (!(_Controler_History_X.empty()))
	{
		std::vector<OB1Strategy*>::iterator fin = _Controler_History_X.end() ;
  	for (*find = _Controler_History_X.begin(); *find != fin; *find++)
    {
			OB1Strategy* test = *(*find) ;
			if ( (test->Priority() == temp->Priority()) &&  (temp->getBeginCycle() == test->getBeginCycle())  && (test->Token() == temp->Token()) && (temp->geStratType() == test->geStratType())   )
				return (*find) ;
    }
	}
}
catch (...)
{
	erreur("Exception BB1 Sheduler::findStrategy.", standardError, 0) ;
}

  find = NULL ;
  return (*find) ;
}

