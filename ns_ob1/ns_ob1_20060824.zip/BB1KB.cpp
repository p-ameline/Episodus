/*
** Copyright Nautilus, (10/9/2004)
** fabrice.le_perru@nautilus-info.com
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/

#ifdef __GNUC__
# pragma implementation
#endif

#include <fstream.h>      // for BB1KB::Load(...) and BB1KB::Save(...)

#ifndef _OWLDLL
#include "BB1KB.h"
#include "AttValPair.h"   // for BB1KB::Save(...)
#include "BB1BB.h"        // for BB1KB::ThisCycle(...)
#include "BB1Class.h"     // for BB1KB::DeleteClassSubtree(...)
#include "BB1Link.h"      // for BB1KB::Save(...)
#include "BB1Exception.h"    // add fab
#else
#include "ns_ob1\BB1KB.h"
#include "ns_ob1\AttValPair.h"   // for BB1KB::Save(...)
#include "ns_ob1\BB1BB.h"        // for BB1KB::ThisCycle(...)
#include "ns_ob1\BB1Class.h"     // for BB1KB::DeleteClassSubtree(...)
#include "ns_ob1\BB1Link.h"      // for BB1KB::Save(...)
#include "ns_ob1\BB1Exception.h"    // add fab
#endif


// -----------------------------------------------------------------------------
// I don't know if KBs will ever be associated with a file
// -----------------------------------------------------------------------------

BB1KB::BB1KB(const string& kbname, BB1BB& BB, Cycle cycle)
  : name(kbname),
    filename(NULLSTRING),
    protectedP(false),
    bb(BB),
    cycleCreated(cycle)
{
  objects = new ObjectSet() ;
}


BB1KB::BB1KB(const BB1KB& src)
  : name(src.name),
    filename(src.filename),
    protectedP(src.protectedP),
    bb(src.bb),
    cycleCreated(src.cycleCreated)
{
  objects = new ObjectSet(*(src.objects)) ;
}


// -----------------------------------------------------------------------------
// Destroying a KB consists of (1) destroying its objects and then (2) clearing
// its object set. You can't delete elements from the object set while iterating
// over it.
// -----------------------------------------------------------------------------

BB1KB::~BB1KB()
{
  if (Name() == "Class")
  {
    // Classes must be deleted bottom up
    DeleteClasses() ;
  }
  else
  {
    // Non-classes may be deleted in an arbitrary order
    if (objects && !objects->empty())
      for (ObjectIter p = objects->begin() ; p != objects->end() ; )
      {
        //if (*p != NULL)
            delete (*p) ;
				objects->erase(p) ;
      }
  }
  objects->clear() ;
}


// -----------------------------------------------------------------------------
// Delete all elements of the KB named "Class"
// -----------------------------------------------------------------------------

void BB1KB::DeleteClasses()
{
  try
  {
    BB1Class *root = BB().ClassNamed("Class") ;
    if (root)
    {
      ObjectList *allClasses = new ObjectList() ;
      ObjectList *maximalClasses = new ObjectList() ;
      root->Instances(allClasses) ;

      ObjectCIter p ;
      if (allClasses && !allClasses->empty())
				for (p = allClasses->begin() ; p != allClasses->end() ; p++)
				{
					ObjectList *parents = new ObjectList() ;
					BB1Class *c = (BB1Class *)(*p) ;
					c->DirectSuperclasses(parents) ;
					if (parents->empty())
						maximalClasses->push_back(c) ;
				}

      if (maximalClasses && !maximalClasses->empty())
				for (p = maximalClasses->begin() ; p != maximalClasses->end() ; p++)
				{
					BB1Class *c = (BB1Class *)(*p) ;
					DeleteClassSubtree(c) ;
				}

			delete root ;
			delete maximalClasses ;
			delete allClasses ;
    }
    else
    {
      // throw cnf;
      ClassNotFound cnf(BB(), "BB1KB::DeleteClasses(...)", "Class");
		}
  } // end try
  catch (ClassNotFound& cnf)
    { } // constructor aborts
}



// -----------------------------------------------------------------------------
// Delete all the subclasses of root class, and then delete the root class.
// -----------------------------------------------------------------------------

void BB1KB::DeleteClassSubtree(BB1Class *root)
{
  try
  {
    if (root)
    {
      ObjectList *ds = new ObjectList() ;
      root->DirectSubclasses(ds) ;

      if (!ds->empty())
				for (ObjectCIter p = ds->begin() ; p != ds->end() ; p++)
					DeleteClassSubtree(Classptr(*p)) ; // The subclass had better be a class
			delete root ;
			delete ds ;
    }
    else
    {
      // throw nco;
      NullClassObject nco(BB(), "BB1KB::DeleteClassSubtree(...)") ;
		}
  } // end try
  catch (NullClassObject& nco)
    { }
}


// -----------------------------------------------------------------------------
// Return a pointer to the object whose name is the given name. If there is no
// such object, return a null pointer.
// -----------------------------------------------------------------------------

BB1Object* BB1KB::ObjectNamed(const string& ObjectName) const
{
  BB1Object *itemPtr ;

  if (objects && !objects->empty())
    for (ObjectCIter i = objects->begin() ; i != objects->end() ; i++)
    {
      itemPtr = *i ;
      if (ObjectName == itemPtr->Name())
				return (itemPtr) ;
    }

  return ((BB1Object *) NULL) ;
}


// -----------------------------------------------------------------------------
// Save the contents of the KB to the file. By default, the file name is that
// which was used to load the KB.
// -----------------------------------------------------------------------------

Errcode BB1KB::Save(const string& fileName)
{
  if (fileName == NULLSTRING)
    return (FAILURE) ;
  else
  {
    ofstream KBstream(fileName.c_str()) ;
    if (!KBstream)
      return (FAILURE) ; // cannot open output file path
    else
    {
      KBstream << "KB " << Name() << "\n\n";
      if (objects && !objects->empty())
				for (ObjectCIter p = objects->begin() ; p != objects->end() ; p++)
	  			(*p)->Save(KBstream) ; // write the object description to the file

      return (SUCCESS) ;
    }
  }
}


/*
// -----------------------------------------------------------------------------
// Convenience function for accessing BB1BB::ThisCycle(). This has to be defined
// here because "BB1KB.c" includes "BB1BB.h", which can not be included in
// "BB1KB.h".
// -----------------------------------------------------------------------------
// moving in BB1KB.h
Cycle BB1KB::ThisCycle(void) const
{
#ifdef _DEBUG_
	cout << "-- DEBUG:: BB1KB::ThisCycle() const\n\n" ;
#endif
	return (bb.ThisCycle()) ;
};
*/
