/*
** Copyright Nautilus, (10/9/2004)
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/

#include "ns_ob1\OB1Token.h"
#include "ns_ob1\BB1Object.h"
#include "ns_ob1\BB1Class.h"
#include "ns_ob1\BB1Link.h"


OB1Token::OB1Token()
{
  _type            = ADD ;
  _object          = NULL ;
  AttributesChange = NULL ;
  LinkChange       = NULL ;
  where_I_am       = NULL ;
  _class           = -42 ; /* not assigned */
  _token_numero = ++_token_counter ;
}

OB1Token::OB1Token(EventType /* type */, BB1Object* pTr)
{
  _type            = ADD ;
  _object          = pTr ;
  AttributesChange = NULL ;
  LinkChange       = NULL ;
  where_I_am       = NULL ;
  _class           = -42 ; /* not assigned */
  _token_numero = ++_token_counter ;
}

OB1Token::OB1Token(EventType /* type */, BB1Object* pTr, AVPSet* Change, LinkSet*  chan)
{
  _type            = ADD ;
  _object          = pTr ;
  LinkChange       = chan ;
  AttributesChange = Change ;
  where_I_am       = NULL ;
  _class           = -42 ; /* not assigned */
  _token_numero = ++_token_counter ;
}

OB1Token::OB1Token(const OB1Token& tok)
{
  _type            = tok.getEventType() ;
  _object          = tok.getObject() ;
  LinkChange       = tok.getChangeLinks() ;
  AttributesChange = tok.getAttributesChange() ;
  where_I_am       = tok.Node() ;
  _class           = tok._class ;

  _token_numero = ++_token_counter ;
}

OB1Token::~OB1Token()
{
  if (NULL != AttributesChange)
    delete (AttributesChange = NULL) ;
  if (NULL !=  LinkChange)
    delete (LinkChange) ;
}

EventType
OB1Token::getEventType()
{
  return (_type) ;
}

AVPSet*
OB1Token::getAttributesChange()
{
  return (AttributesChange) ;
}

LinkSet*
OB1Token::getChangeLinks()
{
  return (LinkChange) ;
}


/*
** Return -42 if it not exist
** else return the number of the class
*/

int
OB1Token::Class()
{
  return (_class) ;
}

void
OB1Token::PutStorageNode(OB1Node* input)
{
	where_I_am = input ;
	if (_object != NULL)
  {
    std::string clasName = _object->Class()->Name() ;
    _class = input->Controler()->getClassName(clasName) ;
  }
}

Cycle
OB1Token::getCreatedCycle()
{
  return (_object->CycleCreated()) ;
}


