/*
** Copyright Nautilus, (10/9/2004)
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/
#include "ns_ob1\OB1Node.h"
#include "ns_ob1\BB1Object.h"
#include "ns_ob1\BB1Link.h"
#include "ns_ob1\BB1KS.h"
#include "ns_ob1\OB1Heuristix.h"
#include "ns_ob1\OB1Functor.h"
#include "partage\nsdivfct.h"
#include "ns_ob1\OB1Types.h"
#include <algorithm>


/*---------------------------- Link method's -------------------------------- */

OB1NodeLink::OB1NodeLink(OB1Node* node, OB1Edge* temp, bool bijective)
{
  _Node       =  node ;
  _Edge       =  temp ;
  _bijective  =  bijective ;
}

bool
OB1NodeLink::Compare(OB1NodeLink* toComp)
{
	if (!toComp)
		return false ;

  return (this->Node()->Compares(toComp->Node())) ;
}

bool
OB1NKS::Precondition(Transfert* /* tr */)
{
	return (true) ;
}

OB1NodeLink::~OB1NodeLink()
{
  _Node = NULL ;
  if (_Edge != NULL)
    delete (_Edge) ;
}

void
OB1NodeLink::putEdge(OB1Edge*   edge)
{
  _Edge = edge ;
}

void
OB1NodeLink::putNode(OB1Node*   nod)
{
  _Node = nod ;
}

void
OB1NodeLink::putBijective(bool bijective)
{
  _bijective = bijective ;
}

OB1EdgeType
getInverseLabel(OB1EdgeType temp)
{
	for (unsigned int i = 0; i < 9; i++)
		if (temp == inverseLabel[i][0])
			return (inverseLabel[i][1]) ;

	return UNDEFINED ;
}

/*---------------------------- BB1TCNode Method ------------------------------*/
OB1NodeLink*
OB1Node::operator() (unsigned int i) /* return the i's parent */
{
	if ((_parent.empty()) || (i >= _parent.size()))
		return NULL ;

  return (_parent[i]);
}

OB1NodeLink*
OB1Node::operator[] (unsigned int i) /* return the i's children */
{
	if ((_children.empty()) || (i >= _children.size()))
		return NULL ;

  return (_children[i]);
}

int     OB1Node::getTokensCardinal()
{
  return (_tokens.size());
}

bool
OB1Node::AddChild(OB1NodeLink* link)
{
	if (!link)
		return false ;

  if (false == existChild(link->Node()) )
  {
    _children.push_back(link);
    return (true) ;
  }
  return (false) ;
}

MarkerObject*
OB1Node::Attributes(std::string& attr)
{
  return (_attributes.get(attr));
}

void
OB1Node::Flag(int priority)
{
  MarkerObject* priorit = _attributes.get(std::string("priority"));
  int value = priorit->intValue() + priority;
  MarkerInteger* temp = new MarkerInteger(value);
  _attributes.set(std::string("priority"), temp);
}

void
OB1Node::UnFlag(int priority)
{
  MarkerObject* priorit = _attributes.get(std::string("priority"));
  int value = priorit->intValue() - priority;
  MarkerInteger *temp = new MarkerInteger(value);
  _attributes.set(std::string("priority"),temp );
}

bool
OB1Node::AddParent(OB1NodeLink* link)
{
	if (!link)
		return false ;

  if (false == existParent(link->Node()))
  {
    _parent.push_back(link);
    return (true) ;
  }
  return (false) ;
}

void
OB1NOther::Computed()
{
  _DefaultCompute = true ;
}

void
OB1Node::EmptyToken()
{
	if (_tokens.empty())
		return ;

  for (std::vector< OB1Token* >::iterator iter = _tokens.begin() ; iter != _tokens.end() ; )
  {
		if (NULL != *iter)
			delete(*iter) ;
		_tokens.erase(iter) ;
  }
}

std::vector<OB1Node*>*
OB1Node::startNode()
{
  std::vector<OB1Node* >* res = new std::vector<OB1Node *>() ;

  if (!(_parent.empty()))
  	for (LinkIterator iter = _parent.begin() ; iter != _parent.end() ; iter++)
   		if (((*iter)->Node() != NULL) && ((*iter)->Node()->getType() == TRIGGER_NODE))
      	res->push_back((*iter)->Node()) ;

  return (res);
}

OB1NodeLink*
OB1Node::Children(OB1Node* toFind)
{
	if ((toFind == NULL) || (_children.empty()))
  	return NULL ;

  for (LinkIterator iter = _children.begin(); iter != _children.end(); iter++)
  	if (((*iter)->Node() != NULL) && (true == (*iter)->Node()->Compares(toFind)))
    	return (*iter) ;

  return NULL ;
}

OB1NodeLink*
OB1Node::Parent(OB1Node* toFind)
{
	if ((toFind != NULL) && (!(_parent.empty())))
		for (LinkIterator iter = _parent.begin(); iter != _parent.end(); iter++)
			if (((*iter)->Node() != NULL) && (true == (*iter)->Node()->Compares(toFind)))
				return (*iter) ;

  return (NULL) ;
}

bool
OB1NValidity::CanCompute()
{
	if (_children.empty())
		return true ;

	for (LinkIterator iter = _children.begin(); iter != _children.end(); iter++)
  {
  	// OB1NodeLink* temp = *iter ;
    OB1NodeLink* inv = Children(this) ;
    if (NULL != inv)
    {
    	int invers = inv->Edge()->Class() ;
      OB1Token* last = (*iter)->Node()->getLastToken(invers) ;
      if (NULL == last)
        return (false) ;
    }
	}
  return (true) ;
}

void
OB1Node::Reinit()
{
  EmptyToken() ;
  _attributes.Clear() ;
}

void
OB1NKS::Reinit()
{
  _ValidationContext = NO_COMPUTATION ;
  EmptyToken() ;
  _attributes.Clear() ;

  // Reinit the state
  if (_ksType == USER_WINDOWS_KS)
  	_ksState = WAITING_FOR_USER_INPUT ;
  else
  	_ksState = FREE_AND_RUNNING ;
}

void
OB1NOther::Reinit()
{
  _DefaultCompute = false ;
  EmptyToken() ;
  _attributes.Clear() ;
}

LinkIterator
OB1Node::findChild(OB1Node* toFind)
{
	if (_children.empty())
		return (NULL) ;

  LinkIterator compteur ;
  for (compteur = _children.begin() ; compteur != _children.end() ; compteur++)
  	if (true == (*compteur)->Node()->Compares(toFind))
      return (compteur) ;

  return (NULL) ;
}

LinkIterator
OB1Node::findParent(OB1Node* toFind)
{
	if (_parent.empty())
		return (NULL) ;

  LinkIterator compteur ;
  for (compteur = _parent.begin(); compteur != _parent.end() ; compteur++)
    if (true == (*compteur)->Node()->Compares(toFind))
      return (compteur) ;

  return (NULL) ;
}

bool
OB1NKS::ComputeValidity()
{
	// La validit� peut-elle �tre �valu�e (variables "computables")
  // Can we evaluate the validity (computable variables
  //
	OB1NValidity* val = getValidityNode() ;

  // Si non, on part du principe que c'est valide
  // If not evaluable, we say it is valid
  //
	if ((NULL == val) || (!(val->CanCompute())))
  {
  	_ValidationContext = VALID ;
    return true ;
  }

  BB1BB* bb = _controlers->BB() ;
  Transfert* trans = val->getActionStructure() ;
  const FunctorValidity* FuncV = _ks->ValidityContext() ;
  _ValidationContext = (*FuncV)(*bb, trans) ;
  //  delete(trans);

  // For robustness : if the KS is berzeck, we take care that something
  // understandable is returned
  switch (_ValidationContext)
  {
    case NO_COMPUTATION :
    case VALID :
    case PROPOSABLE :
    case INVALID :
      return true ;
    default :
      _ValidationContext = INVALID ;
      string sErreur = string("Bad validity answer for ks ") + _ksName ;
      erreur(sErreur.c_str(), standardError, 0) ;
      return false ;
  }
}

Transfert*
OB1NValidity::getActionStructure()
{
try
{
  Transfert* result = new Transfert() ;

  if (!(_children.empty()))
  	for (LinkIterator iter = _children.begin() ; iter != _children.end() ; iter++)
  	{
			OB1NOther* OTH = (OB1NOther*) (*iter)->Node() ;
    	if (NULL != OTH)
    		OTH->addActionStructure(result, (*iter)->Edge()->Class()) ;
		}

  return (result);
}
catch (...)
{
	erreur("Exception OB1NValidity::getActionStructure", standardError, 0) ;
  return NULL ;
}
}

bool
OB1NOther::isLeaf()
{
	if (!(_parent.empty()))
  	for (LinkIterator iter = _parent.begin() ; iter != _parent.end() ; iter++)
			if (((*iter)->Edge()->TypeOf() == IS_CREATED) || ((*iter)->Edge()->TypeOf() == TRIGERS))
				return (false) ;

  return true;
}

bool
OB1Node::existChild(OB1Node* toFind)
{
	if (!(_children.empty()))
  	for (LinkIterator compteur = _children.begin(); compteur != _children.end(); compteur++)
    	if (true == (*compteur)->Node()->Compares(toFind))
      	return (true) ;

  return (false) ;
}

bool
OB1Node::existParent(OB1Node* toFind)
{
	if (!(_parent.empty()))
  	for (LinkIterator compteur = _parent.begin(); compteur != _parent.end(); compteur++)
    	if (true == (*compteur)->Node()->Compares(toFind))
      	return (true) ;

  return (false) ;
}

void
OB1Node::htmlPrint(std::string& input)
{
	input +=  "[VERTEX : <br /> \n" ;
	input += "Nombre de Fils : " ;
	char* nc = new char [16] ;
	itoa(ChildrenCardinal(), nc, 10) ;
	input.append(nc) ;
	delete[] (nc) ;
	input += " <br />" ;
	input += "Nombre de Parents : " ;
	char* np = new char [16];
	itoa(ParentCardinal(),np, 10);
	input.append(np);
	delete[] (np) ;
	input += " <br />";
	input += "] <br /> \n";
}

string
OB1Node::getString()
{
	return "Noeud" ;
}

/*----------------------------------------------------------------------------*/
/*------------------------ CONSTRUCTEUR --------------------------------------*/
/*----------------------------------------------------------------------------*/

OB1Node::OB1Node(OB1Controler* control)
{
  _controlers = control;
  type = ABSTRACT_NODE;
  MarkerObject* priority = new MarkerInteger(0) ;
  _attributes.insert(std::string("priority"),  priority);
}

OB1NLevel::OB1NLevel(OB1Controler* control) :OB1Node(control)
{
  type = LEVEL_NODE;
}

OB1NResult::OB1NResult(OB1Controler* control)  :OB1Node(control)
{
  type = RESULT_NODE;
}

OB1NTrigger::OB1NTrigger(OB1Controler* control)  :OB1Node(control)
{
  type = TRIGGER_NODE;
}

OB1NAnd::OB1NAnd(OB1Controler* control) :OB1Node(control)
{
  type = AND_NODE;
}

OB1NOther::OB1NOther(OB1Controler* control)  :OB1Node(control)
{
  _DefaultCompute = false;
  type = OTHER_NODE;
}

OB1NOther::OB1NOther(OB1Controler* control,TypedVal* val)  :OB1Node(control)
{
  type = OTHER_NODE;
  _DefaultCompute = false;
  name = new TypedVal(*val);
 // _SortingID = ComputeSortingId(*val);
}

OB1NKS::OB1NKS(OB1Controler* control, std::string& name)  :OB1Node(control)
{
  type = KS_NODE;
  _ValidationContext = NO_COMPUTATION;
  _ksName = std::string(name);
}

OB1NKS::OB1NKS(OB1Controler* control,std::string& temp, BB1KS* ks) : OB1Node(control)
{
  _ValidationContext =   NO_COMPUTATION;
  type = KS_NODE;
  _ksName = std::string(temp);
  _ks = ks;
}

OB1NValidity::OB1NValidity(OB1Controler* control) : OB1Node(control)
{
  type = VALIDITY_NODE;
}

//------------------------ ACtivable function ----------------------------------
bool
OB1NKS::isActivable()
{
  OB1NLevel* level = getLevelNode();
  if (level == NULL) // no level needed for execution
    return (true);
  else
    return (level->isActivable());
}

bool
OB1NLevel::isActivable()
{
  if (_children.empty())
  	return true ;

  bool result = true ;

  for (LinkIterator iter = _children.begin(); iter != _children.end(); iter++)
    if ((*iter)->Edge()->TypeOf() == REQUIRES)
    {
      result &= (*iter)->Node()->isActivable() ;
      break ;
    }

  return result;
}

bool
OB1NAnd::isActivable()
{
  if (_children.empty())
  	return true ;

  bool result = true ;

  for (LinkIterator iter = _children.begin(); iter != _children.end(); iter++)
  {
    int clas = (*iter)->Edge()->Class() ;
    result &= ((OB1NOther*)(*iter)->Node())->isActivableExt(clas) ;
    if (result == false)
      break ;
  }

  return (result) ;
}

bool
OB1NOther::isActivableExt(int clas)
{
  OB1Token* last_tok = getLastToken(clas);
  if (last_tok != NULL)
      return (true);    // watch is token has anwser or if answer is different of no_anwser
  return (false);
}

//--------------------------------- DESTRUCTOR ---------------------------------

OB1Node::~OB1Node()
{
  EmptyToken() ;
  _tokens.clear() ;
  _attributes.Clear() ;

  if (!(_parent.empty()))
  	for (LinkIterator iter = _parent.begin() ; iter != _parent.end() ; )
    {
    	if (*iter != NULL)
      	delete(*iter) ;
      _parent.erase(iter) ;
    }

	if (!(_children.empty()))
  	for (LinkIterator iter = _children.begin() ; iter != _children.end() ; )
    {
    	if (*iter != NULL)
      	delete(*iter) ;
      _children.erase(iter) ;
    }
}

OB1NOther::~OB1NOther()
{
	EmptyToken() ;
  _tokens.clear() ;
  _attributes.Clear() ;
  if (name)
  	delete(name) ;
}

OB1NValidity::~OB1NValidity()
{
}

OB1NResult::~OB1NResult()
{
}

OB1NLevel::~OB1NLevel()
{
}

OB1NTrigger::~OB1NTrigger()
{
}

OB1NAnd::~OB1NAnd()
{
}

OB1NKS::~OB1NKS()
{
}

//------------------------------ Tokens functions ------------------------------

void
OB1Node::addToken(OB1Token* token)
{
  _tokens.push_back(token);
}

OB1Token*
OB1Node::getLastToken(int clas)
{
  if (_tokens.empty())
  	return NULL ;

  for ( std::vector<OB1Token* >::reverse_iterator iter = _tokens.rbegin(); iter != _tokens.rend(); iter++ )
  	if ((*iter)->Class() == clas)
    	return (*iter) ;

  return NULL ;
}

bool
OB1Node::isReferencedToken(OB1Token* token)
{
	if ((NULL == token) || (_tokens.empty()))
  	return false ;

  for ( std::vector<OB1Token* >::reverse_iterator iter = _tokens.rbegin(); iter != _tokens.rend(); iter++ )
  	if ((*iter) == token)
    	return true ;

  return false ;
}

//------------------------------ Visitor Functions -----------------------------

// Si le chemin de r�f�rence du noeud est dispat, on place le token sur ce noeud
bool
OB1NOther::IsPlace(OB1Token* temp, TypedVal& /* dispat */)
{
	if (NULL == temp)
		return false ;

  // if (*name != dispat)
  // 	return false ;

  addToken(temp) ;
  temp->PutStorageNode(this) ;
  return true ;
}


bool
OB1Node::hasParent(OB1NodeTypes temp)
{
	if (_parent.empty())
  	return false ;

  for (LinkIterator iter = _parent.begin() ; iter != _parent.end() ; iter++)
  	if (((*iter)->Node()) && ((*iter)->Node()->getType() == temp))
    	return true ;

  return false ;
}


//------------------------------------------------------------------------------

bool
testKS(OB1Node* temp, OB1Node* temp2)
{
	if ((temp == NULL) || (temp2 == NULL))
  	return false ;

  OB1NKS *temp11 = dynamic_cast<OB1NKS* >(temp) ;
  OB1NKS *temp12 = dynamic_cast<OB1NKS* >(temp2) ;
  if ((temp11 == NULL) || (temp12 == NULL))
  	return false ;

  return (temp11->getKSName() == temp12->getKSName()) ;
}

bool
testOther(OB1Node* temp, OB1Node* temp2)
{
	if ((temp == NULL) || (temp2 == NULL))
  	return false ;

  OB1NOther *temp11 = dynamic_cast<OB1NOther* >(temp) ;
  OB1NOther *temp12 = dynamic_cast<OB1NOther* >(temp2) ;
  if ((temp11 == NULL) || (temp12 == NULL))
  	return false ;

  TypedVal& one = temp11->getName() ;
  TypedVal& two = temp12->getName() ;
  return (one == two) ;
}

bool testAnd(OB1Node* temp, OB1Node* temp2)
{
	if ((temp == NULL) || (temp2 == NULL))
  	return false ;

	OB1NAnd* pAndTemp  = dynamic_cast<OB1NAnd* >(temp) ;
  OB1NAnd* pAndTemp2 = dynamic_cast<OB1NAnd* >(temp2) ;

  if ((NULL == pAndTemp) || (NULL == pAndTemp2))
  	return false ;

  return (temp == temp2) ;
}

bool testTrigger(OB1Node* temp, OB1Node* temp2)
{
	if ((temp == NULL) || (temp2 == NULL))
  	return false ;

  OB1NTrigger* pTrigerTemp  = dynamic_cast<OB1NTrigger* >(temp) ;
  OB1NTrigger* pTrigerTemp2 = dynamic_cast<OB1NTrigger* >(temp2) ;

  if ((NULL == pTrigerTemp) || (NULL == pTrigerTemp2))
  	return false ;

  return (pTrigerTemp->KS() == pTrigerTemp2->KS()) ;
}

bool testValidity(OB1Node* temp, OB1Node* temp2)
{
	if ((temp == NULL) || (temp2 == NULL))
  	return false ;

  OB1NValidity* pValidityTemp  = dynamic_cast<OB1NValidity* >(temp) ;
  OB1NValidity* pValidityTemp2 = dynamic_cast<OB1NValidity* >(temp2) ;

  if ((NULL == pValidityTemp) || (NULL == pValidityTemp2))
  	return false ;

  return (pValidityTemp->KS() == pValidityTemp2->KS()) ;
}

bool testLevel(OB1Node* temp, OB1Node* temp2)
{
	if ((temp == NULL) || (temp2 == NULL))
  	return false ;

  OB1NLevel* pLevelTemp  = dynamic_cast<OB1NLevel* >(temp) ;
  OB1NLevel* pLevelTemp2 = dynamic_cast<OB1NLevel* >(temp2) ;

  if ((NULL == pLevelTemp) || (NULL == pLevelTemp2))
  	return false ;

  return (pLevelTemp->KS() == pLevelTemp2->KS()) ;
}

bool testResult(OB1Node* temp, OB1Node* temp2)
{
	if ((temp == NULL) || (temp2 == NULL))
  	return false ;

	OB1NResult* pResultTemp  = dynamic_cast<OB1NResult* >(temp) ;
  OB1NResult* pResultTemp2 = dynamic_cast<OB1NResult* >(temp2) ;

  if ((NULL == pResultTemp) || (NULL == pResultTemp2))
  	return false ;

  return (pResultTemp->KS() == pResultTemp2->KS()) ;
}


typedef bool F(OB1Node* temp, OB1Node* temp2) ;
typedef F* func;
func castTab[] = {testKS, testTrigger, testLevel, testResult, testOther, testAnd, testValidity} ;

bool
OB1Node::Compares(OB1Node* test)
{
  if (test->getType() == type)
  	return  castTab[type](this, test) ;
  return (false) ;
}

//------------------------------------------------------------------------------

OB1NResult*
OB1NKS::getResultNode()
{
  if (_children.empty())
  	return NULL ;

  OB1NResult* result = NULL ;

  for (LinkIterator iter = _children.begin() ; iter != _children.end() ; iter++)
    if (((*iter)->Node() != NULL) && ((*iter)->Node()->getType() == RESULT_NODE))
    {
      result = (OB1NResult*)(*iter)->Node() ;
      break ;
    }

  return (result) ;
}

OB1NValidity*
OB1NKS::getValidityNode()
{
  if (_children.empty())
  	return NULL ;

  OB1NValidity* valid = NULL ;

  for (LinkIterator iter = _children.begin() ; iter != _children.end() ; iter++)
    if (((*iter)->Node() != NULL) && ((*iter)->Node()->getType() == VALIDITY_NODE))
    {
      valid = (OB1NValidity*)(*iter)->Node() ;
      break ;
    }

  return (valid) ;
}

OB1NLevel* OB1NKS::getLevelNode()
{
  if (_children.empty())
  	return NULL ;

  OB1NLevel* result = NULL ;

  for (LinkIterator iter = _children.begin() ; iter != _children.end() ; iter++)
    if (((*iter)->Node() != NULL) && ((*iter)->Node()->getType() == LEVEL_NODE))
    {
      result = (OB1NLevel* )(*iter)->Node() ;
      break ;
    }

  return (result) ;
}

OB1NTrigger*
OB1NKS::getTriggerNode()
{
  if (_children.empty())
  	return NULL ;

  OB1NTrigger* result = NULL ;

  for (LinkIterator iter = _children.begin() ; iter != _children.end() ; iter++)
    if (((*iter)->Node() != NULL) && ((*iter)->Node()->getType() == TRIGGER_NODE))
    {
      result = (OB1NTrigger*)(*iter)->Node() ;
      break ;
    }

  return (result) ;
}

/*--------- Fucntion servant a recuper la structure pour les actions ---------*/
Transfert*
OB1NKS::getActionStructure(OB1SubStrategy* strat)
{
  Transfert* result = new Transfert() ;

  //
  // Init Result network
  //
  OB1NLevel* temp = getLevelNode() ;
  if (NULL != temp)
  	temp->getActionStructure(result) ;

  OB1NResult* pResultNode = getResultNode() ;
  if (NULL != pResultNode)
  	pResultNode->getActionStructure(result, strat) ;

  OB1NTrigger* pTriggerNode = getTriggerNode() ;
  if (NULL != pTriggerNode)
  	pTriggerNode->getActionStructure(result) ;

  return (result) ;
}

Transfert*
OB1NKS::getActionStructure(int i)
{
  Transfert* result = new Transfert();
  OB1Node* temp = getLevelNode();
  if (temp)
  {
    OB1NLevel* leveltemp = dynamic_cast<OB1NLevel*>(temp);
    if (leveltemp)
      leveltemp->getActionStructure(result, i);
  }
  return (result);
}

void
OB1NLevel::getActionStructure(Transfert* temp)
{
	if (_children.empty())
		return ;

  for (LinkIterator iter = _children.begin() ; iter != _children.end() ; iter++)
  {
    OB1NAnd* and = (OB1NAnd*) (*iter)->Node() ;
    if (NULL != and)
      and->getActionStructure(temp) ;
  }
}

void
OB1NLevel::getActionStructure(Transfert* temp, int pas)
{
	if (_children.empty())
  	return ;

  int i = 0 ;
  for (LinkIterator iter = _children.begin() ;
                      (iter != _children.end()) && (i <= pas) ; iter++, i++)
  {
    OB1NAnd* and = (OB1NAnd*) (*iter)->Node() ;
    if (NULL != and)
      and->getActionStructure(temp) ;
  }
  // ((OB1NAnd*)(*iter)->Node())->getActionStructure(temp) ;
}

void
OB1NResult::getActionStructure(Transfert* temp, OB1SubStrategy* strat)
{
	if ((!temp) || (_children.empty()))
		return ;

  for (LinkIterator iter = _children.begin() ; iter != _children.end() ; iter++)
  {
    OB1NOther* OTH = dynamic_cast<OB1NOther * >((*iter)->Node()) ;
    if (NULL != OTH)
		{
    	OB1Token* pToken = NULL ;

    	if (NULL != strat)
      {
      	OB1Strategy* pRootStrat = strat->Root() ;
      	if (OTH->isReferencedToken(pRootStrat->Token()))
      		pToken = pRootStrat->Token() ;
      }

      OTH->addActionStructure(temp, (*iter)->Edge()->Class(), std::string("Result:"), pToken) ;
    }
  }
}

void
OB1NTrigger::getActionStructure(Transfert* temp)
{
	if ((!temp) || (_children.empty()))
		return ;

  for (LinkIterator iter = _children.begin() ; iter != _children.end() ; iter++)
  {
    OB1NOther* OTH = (OB1NOther*)(*iter)->Node();
    if (NULL != OTH)
      OTH->addActionStructure(temp, (*iter)->Edge()->Class(), std::string("Trigger:"));
  }
}

void
OB1NAnd::getActionStructure(Transfert* temp)
{
	if ((!temp) || (_children.empty()))
		return ;

  for (LinkIterator iter = _children.begin() ; iter != _children.end() ; iter++)
  {
    OB1NOther* OTH = (OB1NOther*)(*iter)->Node();
    if (NULL != OTH)
      OTH->addActionStructure(temp, (*iter)->Edge()->Class());
  }
}

void
OB1NOther::addActionStructure(Transfert* temp, int clas, std::string sPrefixe, OB1Token* pToken)
{
	if (!temp)
		return ;

  OB1Token* lasts = NULL ;
	if (NULL == pToken)
  	lasts = getLastToken(clas) ;  /* get the last token */
  else
		lasts = pToken ;
  if (!lasts)
		return ;

  BB1Object* obj = lasts->getObject() ;     /* get the question */
  if (!obj)
		return ;

	temp->_transfer_class += IntToString((int)lasts->getNumero()) + string("-") ;
	temp->insertItem(sPrefixe + name->toString(), obj) ;
}

OB1Controler*
OB1Node::Controler()
{
  return (_controlers) ;
}

void
OB1NKS::ExecuteKS(Transfert* tr, bool /* createToken */)
{
try
{
	if ((tr == NULL) || (_ks == NULL))
		return ;

	BB1BB* temp = _controlers->BB() ;
	if (temp == NULL)
	{
  	delete tr ;
		return ;
	}

	if ( (_attributes.hasStringAttributes("transfert_execute", tr->_transfer_class) == false) ||
       (_ksType == SVCE_WINDOWS_KS)  ||
       (_ksType == KS_SERVICE)
	   )
	{
    const FunctorAction* FuncA = _ks->Action() ;
    if (FuncA != NULL)
		{
			MarkerInteger* top = new MarkerInteger(1) ;
			_attributes.insert(std::string("executed"), top) ;

			_attributes.insert(std::string("transfert_execute"), new MarkerString(tr->_transfer_class)) ;
			(*FuncA)(*temp, tr, false) ;
		}
	}

  delete tr ;
}
catch (...)
{
	erreur("Exception OB1NKS::ExecuteKS", standardError, 0) ;
}
}

//------------------ADD Bijection function -------------------------------------
void OB1Node::addBijection(OB1NodeLink* link, int clas)
{
	if (!link)
		return ;

try
{
  AddChild(link) ;
  link->putBijective(true) ;
  OB1Edge* reci = new OB1Edge(getInverseLabel(link->Edge()->TypeOf()), clas) ;
  OB1NodeLink* linkinverse = new OB1NodeLink(this, reci, true) ;
  link->Node()->AddParent(linkinverse) ;
}
catch (...)
{
	erreur("Exception OB1Node::addBijection", standardError, 0) ;
}
}


//---------------PRINT METHOD --------------------------------------------------
void
OB1NResult::htmlPrint(std::string& input)
{
  input += "<table width ='100%' border='1' bgcolor ='gray'>" ;
  input += "<tr><td bgcolor='996600'>BB1TCNodeResult</td></tr>" ;
  printSonAndParent(this,input) ;
  input +="</table> <br /><br />" ;
}

string
OB1NResult::getString()
{
	return "NodeResult" ;
}

void
OB1NLevel::htmlPrint(std::string& input)
{
  input += "<table width ='100%' border='1' bgcolor ='gray'>";
  input +="<tr><td bgcolor='996600'>BB1TCNodeLevel</td></tr>";
  printSonAndParent(this,input);
  input +="</table> <br /><br />";
}

string
OB1NLevel::getString()
{
	return "NodeLevel" ;
}

void
OB1NTrigger::htmlPrint(std::string& input)
{
  input += "<table width ='100%' border='1' bgcolor ='gray'>" ;
  input += "<tr><td  bgcolor='996600'> BB1TCNodeTrigger</td></tr>" ;
  printSonAndParent(this,input) ;
  input += "</table> <br /><br />" ;
}

string
OB1NTrigger::getString()
{
	return "NodeTrigger" ;
}

void OB1NOther::htmlPrint(std::string& input)
{
  input += "<table width ='100%' border='1' bgcolor ='gray'>" ;
  input += "<tr><td  bgcolor='996600'> BB1TCNodeOther:" + name->toString() + "</td></tr>" ;
  printSonAndParent(this, input) ;
  input += "</table> <br /><br />" ;
}

string
OB1NOther::getString()
{
	return "NodeOther " + getName().toString() ;
}

void OB1NAnd::htmlPrint(std::string& input)
{
  input += "<table width ='100%' border='1' bgcolor ='gray'>" ;
  input += "<tr><td  bgcolor='996600'>BB1TCNodeAnd</td></tr>" ;
  printSonAndParent(this, input) ;
  input += "</table> <br /><br />" ;
}

string
OB1NAnd::getString()
{
	return "NodeAnd" ;
}

void OB1NValidity::htmlPrint(std::string& input)
{
  input += "<table width ='100%' border='1' bgcolor ='gray'>" ;
  input += "<tr><td  bgcolor='996600'>BB1TCNValidity</td></tr>" ;
  printSonAndParent(this,input) ;
  input += "</table> <br /><br />" ;
}

string
OB1NValidity::getString()
{
	return "NodeValidity" ;
}

void OB1NKS::htmlPrint(std::string& input)
{
  input += "<table width ='100%' border='1' bgcolor ='gray'>" ;
  input += "<tr><td  bgcolor='996600'>BB1TCNodeKS:" + _ksName +"</td></tr>" ;
  printSonAndParent(this,input) ;
  input += "</table> <br /><br />" ;
}

string
OB1NKS::getString()
{
	return "NodeKS " + _ksName ;
}

void
printSonAndParent(OB1Node* node, std::string& input)
{
  char* temp1 = new char[16] ;
  char* temp2 = new char[16] ;
  if (node->getTokensCardinal() != 0)
  {
    char *temp3 = new char[16] ;
    itoa( node->getTokensCardinal(), temp3, 10) ;
    input +="<tr><td  bgcolor='996602'>Number of token:" ;
    input.append(temp3) ;
    input += "</td></tr>" ;
    delete[] temp3 ;
  }

  itoa( node->ChildrenCardinal(), temp1, 10);
  itoa( node->ParentCardinal(), temp2, 10);
  input +=  "<tr><td><table width ='100%' bgcolor='33ffff'>";
	input += "<tr><td bgcolor='336600'>nombre de fils: ";
	input.append(temp1);
	input += "</td></tr>";
	unsigned int end = node->ChildrenCardinal();
	for (unsigned int  i =0; i < end; i++)
	{
		input +=  "<tr><td>" +  PrintBB1NodeType((*node)[i]->Node()->getType() );
		if (KS_NODE == (*node)[i]->Node()->getType())
		{
			OB1NKS* kstemp = dynamic_cast<OB1NKS*>( (*node)[i]->Node() );
			if (kstemp != NULL)
				input += ":" +  (kstemp)->getKSName();
		}
		if (OTHER_NODE ==  (*node)[i]->Node()->getType())
		{
    	OB1NOther* ksoth = dynamic_cast< OB1NOther*>( (*node)[i]->Node() );
      if (ksoth != NULL)
      	input += ":" + ksoth->getName().toString();
		}
		input += "<br /> Link Type : " + PrintBB1EdgeType( (*node)[i]->Edge()->TypeOf()  );
		char *temp4 = new char[16] ;
		itoa( (*node)[i]->Edge()->Class(), temp4, 10) ;
		input +=  "<br /> Class allowed : " ;
		input.append(temp4) ;
		delete[] temp4 ;
		input +="</td></tr>" ;
	}
  input +="</table></td></tr><tr><td><table width ='100%' bgcolor='ff99ff'>";

  input += "<tr><td bgcolor='336600'>nombre de parents:";
  input.append(temp2);
  input += "</td></tr>";
  unsigned int end2 = node->ParentCardinal();
  for (unsigned int i =0 ; i < end2 ; i++)
  {
    input += "<tr><td>" + PrintBB1NodeType((*node)(i)->Node()->getType() );
    if (KS_NODE == (*node)(i)->Node()->getType())
    {
      OB1NKS* kstemp = dynamic_cast<OB1NKS*>( (*node)(i)->Node() );
      if (kstemp != NULL)
        input += ":" +  (kstemp)->getKSName();
    }
    if (OTHER_NODE ==  (*node)(i)->Node()->getType())
    {
      OB1NOther* ksoth = dynamic_cast< OB1NOther*>( (*node)(i)->Node() );
      if (ksoth != NULL)
        input += ":" + ksoth->getName().toString();
    }
    input += "<br /> Link Type : " + PrintBB1EdgeType( (*node)(i)->Edge()->TypeOf()  );
    char *temp4 = new char[16];
    itoa((*node)(i)->Edge()->Class(), temp4, 10) ;
    input +=  "<br /> Class allowed : ";
    input.append(temp4);
    delete(temp4);
    input +="</td></tr>";
  }
  input += "</table></td></tr>" ;
  delete[] temp1 ;
  delete[] temp2 ;
}

std::string
PrintBB1EdgeType(OB1EdgeType temp)
{
  switch(temp)
  {
    case CREATES      : return ("creates") ;
    case IS_CREATED   : return ("is-create") ;
    case IMPLIES      : return ("implies") ;
    case REQUIRES     : return ("recquires") ;
    case IS_NEEDED    : return ("is-needed") ;
    case TRIGERS      : return ("triggers") ;
    case RESULT       : return ("result") ;
    case LEVEL        : return ("level") ;
    case UNDEFINED    : return ("undefined") ;
    case IS_VALIDATED : return ("is_validated") ;
    case VALIDATED    : return ("validated") ;
    default           : return ("Label definition Error") ;
  };
}

std::string
PrintBB1NodeType(OB1NodeTypes temp)
{
  switch(temp)
  {
    case KS_NODE          : return ("KS_NODE") ;
    case TRIGGER_NODE     : return ("TRIGGER_NODE") ;
    case LEVEL_NODE       : return ("LEVEL_NODE") ;
    case RESULT_NODE      : return ("RESULT_NODE") ;
    case OTHER_NODE       : return ("OTHER_NODE") ;
    case AND_NODE         : return ("AND_NODE") ;
    case ABSTRACT_NODE    : return ("ABSTRACT_NODE") ;
    case VALIDITY_NODE    : return ("VALIDITY_NODE") ;
    default               : return ("UNDEFINED") ;
  };
}

 /*
bool     OB1NKS::hasAlreadyBeAnswer()
{
  OB1NResult* temp = getResultNode();
  if (NULL != temp)
    return (temp->hasAlreadyBeAnswer());
  return (false);
} */


bool OB1NResult::hasResult()
{
	if (_children.empty())
		return (false) ;

  for (LinkIterator iter = _children.begin() ; iter != _children.end() ; iter++)
  {
    int clasAllowed = (*iter)->Edge()->Class() ;
    OB1Token* temp = (*iter)->Node()->getLastToken(clasAllowed) ;
    if (NULL != temp)
      return (true) ;
  }

  return (false) ;
}

OB1NKS*
OB1NLevel::KS()
{
  OB1NKS* result = NULL ;

  if (!(_parent.empty()))
  	for (LinkIterator iter = _parent.begin() ; iter != _parent.end() ; iter++)
      if (KS_NODE == (*iter)->Node()->getType())
      {
      	result = dynamic_cast<OB1NKS*> ((*iter)->Node()) ;
        return (result) ;
      }

	return (result) ;
}

OB1NKS*
OB1NTrigger::KS()
{
  OB1NKS* result = NULL ;

  if (!(_parent.empty()))
  	for (LinkIterator iter = _parent.begin() ; iter != _parent.end() ; iter++)
    	if (KS_NODE == (*iter)->Node()->getType())
      {
      	result = dynamic_cast<OB1NKS*> ((*iter)->Node()) ;
        return (result) ;
      }

	return (result) ;
}

OB1NKS*
OB1NResult::KS()
{
  OB1NKS* result = NULL ;

  if (!(_parent.empty()))
  	for (LinkIterator iter = _parent.begin() ; iter != _parent.end() ; iter++)
      if (KS_NODE == (*iter)->Node()->getType())
      {
      	result = dynamic_cast<OB1NKS*> ((*iter)->Node()) ;
        return (result) ;
      }

	return (result) ;
}

OB1NKS*
OB1NValidity::KS()
{
  OB1NKS* result = NULL ;

  if (!(_parent.empty()))
  	for (LinkIterator iter = _parent.begin() ; iter != _parent.end() ; iter++)
      if (KS_NODE == (*iter)->Node()->getType())
      {
      	result = dynamic_cast<OB1NKS*> ((*iter)->Node()) ;
        return (result) ;
      }

	return (result) ;
}

int
OB1NOther::createStrategy(OB1SubStrategy* strat, bool bInRootDirection) /* this algorithme forbid the use of one path for trigger and result */
{
try
{
	if (!strat)
		return 0 ;

	OB1Strategy* rootstrat = (OB1Strategy*)strat->Root() ; /* get the root strategy */
  if (!rootstrat)
		return 0 ;

  string sActionLog = string("Create strategy on Nother node ") + getString() + string(" for root strategy ") + rootstrat->ID() ;
  Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trDetails) ;

	Attribute().insert(rootstrat->ID(), new MarkerInteger(0)) ;
	strat->putNode(this) ;

  // If we are not going in the KSNode direction, we are on a leaf. Job is done
  //
  if (!bInRootDirection)
  	return 1 ;

  // If we are not on a leaf, it means we have to go up toward the KSNode.
  // In order not to cycle undefinitely, we must return 0 if we have not been
  // able to do it.
  //
  int iAction = 0 ;

  std::vector<OB1Node*> explore_choice ;
	bool Terminate = false ;

  if (!(_parent.empty()))
  {
  	sActionLog = string("Create strategy for parents nodes of node ") + getString() ;
  	Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;

  	for (LinkIterator iter = _parent.begin() ; iter != _parent.end() ; iter++)
		{
			OB1EdgeType ParentType = (*iter)->Edge()->TypeOf() ;

			if ((TRIGERS == ParentType) && (false == (*iter)->Node()->Attribute().Exist(rootstrat->ID())))
			{
      	sActionLog = string("The inter-node type is TRIGERS and the parent doesn't already have strategy ") + rootstrat->ID() + string(" in its attributes") ;

				if (strat->Class() == OB1_UNINITIALIZED)
				{
					OB1NodeLink* un = (*iter)->Node()->Children(this) ;
        	if (un)
        	{
        		int inverse = un->Edge()->Class() ;

            sActionLog += string("; strat class is \"uninitialized\" and the parent has a \"children\" link going to this node: we create a strategy for the parent with class ") + IntToString(inverse) ;

          	// OB1SubStrategy* newSubStrat = new OB1SubStrategy(strat,rootstrat, 0,  inverse);
          	OB1SubStrategy* newSubStrat = new OB1SubStrategy(_controlers, rootstrat, strat, 0,  inverse) ;
          	strat->AddSubStrategy(newSubStrat) ;
          	(*iter)->Node()->createStrategy(newSubStrat, true) ;
            iAction = 1 ;
        	}
				}
				else
					if (strat->Class() == (*iter)->Edge()->Class())
				{
					OB1NodeLink* un = (*iter)->Node()->Children(this) ;
          if (un)
					{
						int inverse = un->Edge()->Class() ;

            sActionLog += string("; strat class corresponds to inter-nodes class and the parent has a \"children\" link going to this node: we create a strategy for the parent with class ") + IntToString(inverse) ;

						// OB1SubStrategy* newSubStrat = new OB1SubStrategy(strat, rootstrat, 0, inverse);
          	OB1SubStrategy* newSubStrat = new OB1SubStrategy(_controlers, rootstrat, strat, 0, inverse) ;
						strat->AddSubStrategy(newSubStrat) ;
						(*iter)->Node()->createStrategy(newSubStrat, true) ;
            iAction = 1 ;
					}
				}

        Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;
			}
			if  (IS_CREATED == ParentType)
			{
      	sActionLog = string("The inter-node type is IS_CREATED") ;

				if (strat->Class() < 0)
        {
        	sActionLog += string("; the strat class is negative, we add this node to explore_choice") ;
					explore_choice.push_back((*iter)->Node()) ;
        }
				else
					if (strat->Class() == (*iter)->Edge()->Class() )
					{
						if (false == (*iter)->Node()->Attribute().Exist(rootstrat->ID()))
            {
            	sActionLog += string("; the strat class is positive and corresponds to inter-nodes class and the parent doesn't have this strategy in its attributes, we add this node to explore_choice") ;
							explore_choice.push_back((*iter)->Node()) ;
            }
					}

        Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;
    	}
  	}
  }

  //
  // The following part is only usefull for nodes in the result network
  //
  if (explore_choice.empty())
  	return (iAction) ;

	Heuristix* choice = Controler()->GetHeuristix() ;  // if the class are triger
  if (NULL == choice)
  	return (iAction) ;

  sActionLog = string("Getting next node to explore from parents of node ") + getString() ;

	OB1Node* next = choice->NextNode(explore_choice) ;
	if (NULL == next)
  {
  	sActionLog += string(" (result is none... exiting)") ;
  	Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;
  	return (iAction) ;
  }

  sActionLog += string(" (result is node ") + next->getString() + string(")") ;
  Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;

  LinkIterator itLink = next->findChild(this) ;
  if (NULL == itLink)
  {
  	sActionLog = string("This parent node doesn't have a link with node ") + getString() + string(" (exiting)") ;
  	Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;
  	return (1) ;
  }

	OB1NodeLink* temp = *itLink ; // we check if we didn't have an answer
	if (NULL == temp)
  	return (1) ;

	int inverseClass = temp->Edge()->Class() ;

/*
	LinkIterator itLink = findParent(next) ;
  if (NULL == itLink)
  {
  	sActionLog = string("This parent node doesn't have a link with node ") + getString() + string(" (exiting)") ;
  	Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;
  	return (iAction) ;
  }

	OB1NodeLink* temp = *itLink ; // we check if we didn't have an answer
	if (NULL == temp)
  	return (iAction) ;

	int inverseClass = temp->Edge()->Class() ;
*/

  sActionLog = string("The inter-node class is ") + IntToString(inverseClass) ;

	OB1Token* res = getLastToken(inverseClass) ; // On verifie que l'on � pas d�ja la r�ponse a la question
	if (NULL != res)
	{
  	sActionLog += string(" and it corresponds to token ") + IntToString(res->getNumero()) ;
		if (Terminate == false)
    {
     	sActionLog += string(". Since Terminate is false, we put strat in computation state ANSWER") ;
			strat->putComputationState(ANSWER) ;     //FIXME
      //  next->createStrategy(strat);
      iAction = 1 ;
    }
	}
  else
  {
  	sActionLog += string(" and it doesn't correspond to a token, so we ask the parent node (") + next->getString() + string(") to create a strategy") ;
  	// OB1SubStrategy* newSubStrat =  new OB1SubStrategy(rootstrat,strat,0, inverseClass);
    //strat->AddSubStrategy(newSubStrat);
    next->createStrategy(strat, true) ;
    iAction = 1 ;
  }

  Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;

	return (iAction) ;
}
catch (...)
{
	erreur("Exception OB1NOther::createStrategy", standardError, 0) ;
  return 0 ;
}
}

int
OB1NAnd::createStrategy(OB1SubStrategy* strat, bool /* bInRootDirection */) /* this algorithme forbid the use of one path for trigger and result */
{
try
{
	if (!strat)
		return (0) ;

  OB1Strategy* rootstrat = (OB1Strategy*)strat->Root() ;
  if (!rootstrat)
		return (0) ;

  string sActionLog = string("Create strategy on NAnd node ") + getString() + string(" for root strategy ") + rootstrat->ID() ;
  Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trDetails) ;

  Attribute().insert(rootstrat->ID(), new MarkerInteger(0)) ;
  if (isActivable() == true)
  {
    string sActionLog = string("The node is activable, it asks its parent to create a strategy for root strategy ") + rootstrat->ID() ;
    Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;

    OB1Node* next = _parent[0]->Node() ;
    if (NULL != next)
      next->createStrategy(strat, true) ;
  }
  else
  {
  	string sActionLog = string("The node is not activable. Nothing done.") ;
    Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;
  }

  return (1) ;
}
catch (...)
{
	erreur("Exception OB1NAnd::createStrategy", standardError, 0) ;
  return 0 ;
}
}

int
OB1NLevel::createStrategy(OB1SubStrategy* strat, bool /* bInRootDirection */) /* this algorithme forbid the use of one path for trigger and result */
{
try
{
	if (!strat)
		return (0) ;

  OB1Strategy* rootstrat = (OB1Strategy*) strat->Root() ;
  if (!rootstrat)
		return (0) ;

  string sActionLog = string("Create strategy on NLevel node ") + getString() + string(" for root strategy ") + rootstrat->ID() ;
  Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trDetails) ;

  Attribute().insert(rootstrat->ID(), new MarkerInteger(0)) ;
  if (ChildrenCardinal() == 0)
		return (1) ;

	OB1Node* andNode = _children[0]->Node() ;
	if (NULL == andNode)
		return (1) ;

	std::vector<OB1NodeLink* >& andChidldren = andNode->getChildren() ;
  // std::vector<OB1SubStrategy* >& substrat = strat->getSubStrategy() ;

  if (!(andChidldren.empty()))
  {
    string sActionLog = string("Asking all the sons of the andNode to create a strategy for root strategy ") + rootstrat->ID() ;
  	Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;

  	for (LinkIterator iter = andChidldren.begin() ; iter != andChidldren.end() ; iter++)
  	{
    	// Taking the link going from the son node to the andNode
      //
  		OB1NodeLink* temp = (*iter)->Node()->Parent(andNode) ;
      if (temp != NULL)
      {
    		int inverse = temp->Edge()->Class() ;
    		OB1Token *res = (*iter)->Node()->getLastToken(inverse) ;
    		if (NULL == res)
    		{
        	string sActionLog = string("The son ") + (*iter)->Node()->getString() + string(" has no token for the class ") + IntToString(inverse) + string("; we ask him to create a strategy for root strategy ") + rootstrat->ID() ;
  				Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;

    			OB1SubStrategy* newSubStrat = new OB1SubStrategy(_controlers, rootstrat, strat, (*iter)->Edge()->Class(), inverse) ;
      		strat->AddSubStrategy(newSubStrat) ;
      		(*iter)->Node()->createStrategy(newSubStrat, false) ;
        }
        else
        {
        	string sActionLog = string("The son ") + (*iter)->Node()->getString() + string(" has already a token (") + IntToString(res->getNumero()) + string(") for the class ") + IntToString(inverse) ;
  				Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;
        }
    	}
  	}
  }
  return (1) ;
}
catch (...)
{
	erreur("Exception OB1NLevel::createStrategy", standardError, 0) ;
  return 0 ;
}
}

int
OB1NKS::createStrategy(OB1SubStrategy* strat, bool /* bInRootDirection */) /* this algorithme forbid the use of one path for trigger and result */
{
try
{
	if (!strat)
		return (0) ;

	OB1Strategy* rootstrat = (OB1Strategy*)strat->Root() ;
	if (!rootstrat)
		return (0) ;

  string sActionLog = string("Create strategy on KS node ") + getString() + string(" for root strategy ") + rootstrat->ID() ;
  Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trDetails) ;

	Attribute().insert(rootstrat->ID(), new MarkerInteger(0)) ;
	strat->putNode(this) ;

	Flag(rootstrat->Priority()) ;
	if (false == isActivable())
	{
    string sActionLog = string("KS node is not activable: asking Level node to create a strategy for root strategy ") + rootstrat->ID() ;
  	Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;

    OB1NLevel* level = getLevelNode() ;
    if (NULL != level)
    	level->createStrategy(strat, false) ;
	}

	return (1) ;
}
catch (...)
{
	erreur("Exception OB1NKS::createStrategy", standardError, 0) ;
  return 0 ;
}
}

int
OB1NTrigger::createStrategy(OB1SubStrategy* strat, bool /* bInRootDirection */)
{
try
{
	if (!strat)
		return (0) ;

  OB1Strategy* rootstrat = (OB1Strategy*)strat->Root() ;
  if (!rootstrat)
		return (0) ;

  string sActionLog = string("Create strategy on Trigger node ") + getString() + string(" for root strategy ") + rootstrat->ID() ;
  Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trDetails) ;

  Attribute().insert(rootstrat->ID(), new MarkerInteger(0)) ;
  OB1NodeLink* ks = _parent[0] ;
  if (ks == NULL)
  	return (0) ;

	if (false == ks->Node()->Attribute().Exist(rootstrat->ID()))
  {
  	string sActionLog = string("Trigger node asks ks node to connect to the strategy for root strategy ") + rootstrat->ID() ;
  	Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;

		ks->Node()->createStrategy(strat, true) ;
  }
  else
  {
  	string sActionLog = string("The ks node has already a strategy for root strategy ") + rootstrat->ID() + string(" (nothing to do)") ;
  	Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;
  }

	return 0 ;
}
catch (...)
{
	erreur("Exception OB1NTrigger::createStrategy", standardError, 0) ;
  return 0 ;
}
}

int
OB1NResult::createStrategy(OB1SubStrategy* strat, bool /* bInRootDirection */)
{
try
{
	if (!strat)
		return (0) ;

  OB1Strategy* rootstrat = (OB1Strategy*)strat->Root() ;
  if (!rootstrat)
		return (0) ;

  string sActionLog = string("Create strategy on Result node ") + getString() + string(" for root strategy ") + rootstrat->ID() ;
  Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trDetails) ;

  Attribute().insert(rootstrat->ID(), new MarkerInteger(0)) ;
  OB1NodeLink* ks = _parent[0] ;
  if (ks == NULL)
		return 0 ;

	if (false == ks->Node()->Attribute().Exist(rootstrat->ID()))
	{
    string sActionLog = string("Result node asks ks node to create a strategy for root strategy ") + rootstrat->ID() ;
  	Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;

		OB1SubStrategy* newSubStrat = new OB1SubStrategy(_controlers, rootstrat,strat,0, ks->Edge()->Class()) ;
		strat->AddSubStrategy(newSubStrat) ;
		ks->Node()->createStrategy(newSubStrat, true) ;
	}
  else
  {
  	string sActionLog = string("The ks node has already a strategy for root strategy ") + rootstrat->ID() + string(" (nothing to do)") ;
  	Controler()->BB()->pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubDetails) ;
  }

	return 0 ;
}
catch (...)
{
	erreur("Exception OB1NResult::createStrategy", standardError, 0) ;
  return 0 ;
}
}

