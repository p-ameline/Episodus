/*
** Copyright Nautilus, (10/9/2004)
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/

#include "ns_ob1\Interface.h"
#include "ns_ob1\BB1Task.h"
#include "ns_ob1\BB1BB.h"
#include "ns_ob1\BB1Object.h"
#include "ns_ob1\BB1Class.h"
#include "nautilus\nssuper.h"
#include "ns_ob1\BB1Task.h"
#include "ns_ob1\ns_bbk.h"
#include "ns_ob1\OB1Controler.h"
#include "ns_ob1\InterfaceExt.h"
#include "ns_ob1\OB1Token.h"
#include "partage\ns_timer.h"
#include "nssavoir\nsguide.h"
#include "OB1.rh"

/*
** Tableau d'affichage d'un onglet de linterface
*/
const int TabbedOne[] = {IDC_LIST_KS};           // Liste des KS : onglet 1
const int TabbedTwo[] = {IDC_LIST_ACTION};       // Liste des action : onget 2



const int ID_BBKList = 0x442;

//TMDIChild
DEFINE_RESPONSE_TABLE1(BB1BBInterface, TDialog)
    EV_COMMAND(IDM_BBKTODO, CmBBKEvent),
    EV_WM_TIMER,
    EV_TCN_SELCHANGE(IDC_SELECT_TODO, TabChanged),
    EV_LVN_GETDISPINFO(IDC_LIST_KS, DispInfoKs),
    EV_LVN_GETDISPINFO(IDC_LIST_ACTION, DispInfoAction),
    EV_BN_CLICKED(IDC_MASK, Mask),
    EV_COMMAND_ON_POINT(IDC_LIST_KS, WM_LBUTTONDBLCLK, KsDblClick),
END_RESPONSE_TABLE ;

BB1BBInterface::BB1BBInterface(TWindow* parent, NSContexte* Contexte, TModule* module )
               :TDialog(parent, "IDD_OB1", module)
{
  toDoNow                 = new NSTaskArray() ;
  bb                      = NULL ;
  pContexte               = Contexte ;
 	_AnswerList             = new BB1TaskList() ;
  isDeterministe          = false ;

  _ActionsPossible        = new TTabControl(this,IDC_SELECT_TODO) ;
  _KsList					        = new NSKSListWindow(this, IDC_LIST_KS) ;
  _actionsInOB1		        = new TListWindow(this, IDC_LIST_ACTION) ;

  _actionsLogLevel        = trSubDetails ;
  _interfaceTimerInterval = 100 ;
}

BB1BBInterface::~BB1BBInterface()
{
	KillTimer(ID_RCBBKTIMER) ;
  if (NULL != _AnswerList)
    delete(_AnswerList) ;

  // On efface les membre de visualisation
  if (NULL != _ActionsPossible)
		delete (_ActionsPossible) ;
  if (NULL !=_KsList)
  	delete (_KsList) ;
  if (NULL !=  _actionsInOB1)
  	delete (_actionsInOB1) ;

  if (NULL != toDoNow)
	{
  	toDoNow->vider() ;
		delete toDoNow ;
	}
}

void BB1BBInterface::putBB(BB1BB* temp)
{
    bb = temp;
}

/*
** Panque le blackboard
** Fenetre permettant de masquer ou de faire apparaitre le blackboard
** true : cache l'interface
** false montre l'interface
*/
void BB1BBInterface::MaskBB(bool hide)
{
	if (_parent == NULL)
  	return ;

	if (hide)
  {
		//ShowWindow(SW_HIDE);
    _parent->ShowWindow(SW_HIDE);
  }
  else
  {
   // ShowWindow(SW_SHOW);
     _parent->ShowWindow(SW_SHOW);
  }
}

void BB1BBInterface::Mask()
{
	MaskBB(true) ;
}

void BB1BBInterface::SetupWindow()
{
	//TMDIChild::SetupWindow();
	TDialog::SetupWindow() ;
	InitListView() ;
	InitTabbedControl() ; // Initialisation du TabbedControl
	PrintAgentList() ;
  SetTimer(ID_RCBBKTIMER, _interfaceTimerInterval) ;
}

void BB1BBInterface::ChangeTabbedControl(int index)
{
	 register unsigned int i;
   for (i = 0; i < 1; i++) EnableControl(TabbedOne[i],(index == 0) );
   for ( i = 0; i < 1; i++) EnableControl(TabbedTwo[i], (index == 1) );
}


void
BB1BBInterface::CmBBKEvent()
{
  getMessage();
}

void
BB1BBInterface::InitTabbedControl()
{
	char temp[] = "Liste des agents" ;
	TTabItem tab(temp) ;
	_ActionsPossible->Add(tab) ;

	char tem2[] = "Actions dans OB1" ;
	TTabItem tab2(tem2) ;
	_ActionsPossible->Add(tab2) ;
}

void
BB1BBInterface::InitListView()
{
	_KsList->InsertColumn(0,	TListWindColumn("Nom", 			 	100,	TListWindColumn::Left,   	0)) ;
	_KsList->InsertColumn(1, 	TListWindColumn("Type",			 		 50, 	TListWindColumn::Right,		1)) ;

  //_actionsInOB1->InsertColumn(0,	TListWindColumn("Action", 			 	50,	TListWindColumn::Left,   	0)) ;
	//_actionsInOB1->InsertColumn(1, 	TListWindColumn("Type",			 		 50, 	TListWindColumn::Right,		1)) ;
}

void
BB1BBInterface::TabChanged(TNotify far& /* nm */)
{
  int index = _ActionsPossible->GetSel() ;
  ChangeTabbedControl(index) ;
}

void
BB1BBInterface::EvTimer(uint id)
{
	if (id == ID_RCBBKTIMER)
	{
		if (isDeterministe == false)
    {
			computeMessage() ;
			bb->Execute() ;
		}
	}
}

/*
** Get the message in NSuper
** and token it
**
*/
void
BB1BBInterface::getMessage()
{
	if (!pContexte)
		return ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;
	if (!pSuper)
		return ;

	if (pSuper->aBBKToDo.empty())
		return ;

	NSTaskArray aLocalBBKToDo = pSuper->aBBKToDo ;
	pSuper->aBBKToDo.vider() ;

	for (TaskIter iTD = aLocalBBKToDo.begin(); iTD != aLocalBBKToDo.end(); )
	{
		toDoNow->push_back( (*iTD) ) ;
		//   delete *iTD;
		aLocalBBKToDo.erase(iTD);
	}
}

void
BB1BBInterface::computeMessage()
{
	if (toDoNow->empty())
		return ;

  NSSuper*  pSuper = pContexte->getSuperviseur() ;
  std::string ps ="";

	NSTaskArray aLocalBBKToDo = (*toDoNow);
	toDoNow->vider();

  for (TaskIter iTD = aLocalBBKToDo.begin(); iTD != aLocalBBKToDo.end(); )
	{
		ps = string("d�but Todo : ") + (*iTD)->sWhatToDo ;
    pSuper->trace(&ps, 1) ;

    if ((*iTD)->sWhatToDo == "NautilusEvent")
    {
    	NautilusEvent* temp = (static_cast<NautilusEvent*>((*iTD)->pPointer1)) ;
      if (temp != NULL)
      	addNautilusEvent(temp);
    }

    if ((*iTD)->sWhatToDo == "IsAnswerPresentOnBlackBoard")
    {
    	IsAnswerPresentOnBlackBoard* temp = (static_cast<IsAnswerPresentOnBlackBoard*>((*iTD)->pPointer1)) ;
      if (temp != NULL)
      	askIsAnswerPresentOnBlackBoard(temp) ;
    }

    if ((*iTD)->sWhatToDo == "AskDeterministicQuestion")
    {
    	AskDeterministicQuestion* temp = (static_cast<AskDeterministicQuestion*> ((*iTD)->pPointer1)) ;
      if (temp != NULL)
      {
      	OB1Strategy* pResult = addAskDeterministicQuestion(temp) ;
        if (pResult) // The order is possible and i wait in the response list
        	_AnswerList->AddTask(new TaskStructure((BB1Task*) temp)) ;
      }
    }

    if ((*iTD)->sWhatToDo == "BB1Order")
    {
    	BB1Order* temp = (static_cast<BB1Order*> ((*iTD)->pPointer1)) ;
      if (temp != NULL)
      	addBB1Order(temp) ;
    }

    if ((*iTD)->sWhatToDo == "insertObjectOnBlacBoard")
    {
    	insertObjectOnBlacBoard* temp = (static_cast<insertObjectOnBlacBoard*> ((*iTD)->pPointer1)) ;
      if (temp != NULL)
      {
      }
    }

    delete *iTD ;
    aLocalBBKToDo.erase(iTD) ;
  }
}

void
BB1BBInterface::DispInfoKs(TLwDispInfoNotify& dispInfo)
{
 	if (NULL == bb)
		return ;

	std::vector<OB1NKS* >* kss = bb->Controler()->Graph().getKSs() ;
	TListWindItem   &dispInfoItem = *(TListWindItem *) &dispInfo.item ;
	static char     buffer[100] ;

	int index = dispInfoItem.GetIndex() ;
	if ((index < 0) || ((unsigned int) index >= kss->size()))
  	return ;

  KSType type = (*kss)[index]->KsType() ;
  std::string name = (*kss)[index]->getKSName() ;

	switch (dispInfoItem.GetSubItem())
	{
		case 0  :
    	// std::string name = (*kss)[index]->getKSName() ;
      sprintf(buffer, "%s", name.c_str()) ;
      dispInfoItem.SetText(buffer) ;
      break ;

    case 1	:
    	std::string types = "" ;
      // KSType type = (*kss)[index]->KsType() ;
      switch(type)
      {
      	case USER_KS :
        	types = "user ks" ;
          break ;
        case KS_SERVICE :
        	types = "service ks" ;
          break ;
        case SVCE_WINDOWS_KS :
        	types = "service MMI ks" ;
          break ;
        case USER_WINDOWS_KS :
        	types = "user MMI ks" ;
          break ;
        default :
        	types = "unknow type" ;
          break ;
      }
      sprintf(buffer, "%s", types.c_str()) ;
      dispInfoItem.SetText(buffer) ;
    	break ;
  }
}

void
BB1BBInterface::DispInfoAction(TLwDispInfoNotify& /* dispInfo */)
{
}

void
BB1BBInterface::KsDblClick(uint /* modKeys */, ClassLib::TPoint& point)
{
	TLwHitTestInfo info(point) ;

  /* int indexItem = */ _KsList->HitTest(info) ;

	if (!(info.GetFlags() & LVHT_ONITEM))  	return ;
}

bool
BB1BBInterface::addNautilusEvent(NautilusEvent* ev)
{
	if (!ev)
		return false ;

  pContexte->getSuperviseur()->voidDebugPrintf(NSSuper::trSteps, "Ajout d'un evenement");
  pContexte->getSuperviseur()->DebugNewLine();

  NSPatPathoArray* pPatPatho = ev->getRoot() ;
	PatPathoIter     PPTiter  = ev->getPointer() ;

	if (NULL == pPatPatho)
  	return false ;

  string sEventPath = string("") ;
  if (PPTiter != NULL)
	{
  	sEventPath = pPatPatho->donneCheminItem(PPTiter) ;
    if (sEventPath != string(""))
    {
    	string sStandardPath = sEventPath ;
  		pContexte->getDico()->donneCodeSens(&sStandardPath, &sEventPath) ;
    }
	}

  AttValPair label			  ("label",         std::string("NautilusEvent")) ;
  // AttValPair node				  ("node",		      pPatPatho) ;
  // AttValPair whereIChange	("change",	      pPPTiter) ;
  AttValPair nsEvent	    ("event",         new NautilusEvent(*ev)) ;
  AttValPair expl         ("explication",   sEventPath) ;
  AttValPair userEventType("userEventType",	ev->getUserEvenType()) ;
  AttValPair Naut("control", string("NautEvent"));

  BB1KB*     EventKB		= bb->KBNamed("NautilusEventKB") ;
  BB1Class*  EventClass	= bb->ClassNamed("UserEvent") ;

  string sName = "NautilusEvent" ;
	char* num = new char[18] ;
	itoa(bb->getNBObject(), num, 10) ;
	sName.append(num) ;
  delete[] num ;

 	// BB1Object* creEv = EventClass->MakeInstance(sName, Naut, *EventKB, Collect(&label, &node, &whereIChange, &expl, &userEventType), NULL, false) ;
  BB1Object* creEv = EventClass->MakeInstance(sName, Naut, *EventKB, Collect(&label, &nsEvent, &expl, &userEventType), NULL, false) ;

  creEv->setAnswerStatus(AnswerStatus::astatusProcessing) ;
  creEv->setAnswerProcessStage(AnswerStatus::apstageStarting) ;

	addActionString("add NautilusEvent", BB1BBInterface::trSteps) ;

  return bb->Controler()->NextComputeAction(creEv, NULL) ;
}

bool
BB1BBInterface::addNautilusEvent(string sEventPath)
{
	if (sEventPath == string(""))
		return false ;

  pContexte->getSuperviseur()->voidDebugPrintf(NSSuper::trSteps, "Ajout d'un evenement");
  pContexte->getSuperviseur()->DebugNewLine();

  AttValPair label("label",       std::string("NautilusEvent")) ;
  AttValPair expl ("explication", sEventPath) ;
  AttValPair Naut ("control",     string("NautEvent")) ;

  BB1KB*     EventKB		= bb->KBNamed("NautilusEventKB") ;
  BB1Class*  EventClass	= bb->ClassNamed("UserEvent") ;

	string sName = "NautilusEvent" ;
	char* num = new char[18] ;
	itoa(bb->getNBObject(), num, 10) ;
	sName.append(num) ;
  delete[] num ;

 	BB1Object* creEv = EventClass->MakeInstance(sName, Naut, *EventKB, Collect(&label, &expl), NULL, false) ;

  creEv->setAnswerStatus(AnswerStatus::astatusProcessing) ;
  creEv->setAnswerProcessStage(AnswerStatus::apstageStarting) ;

	addActionString("add NautilusEvent", BB1BBInterface::trSteps) ;

	return bb->Controler()->NextComputeAction(creEv, NULL) ;
}

BB1Object*
BB1BBInterface::askIsAnswerPresentOnBlackBoard(IsAnswerPresentOnBlackBoard* /* isp */)
{
	// return  (bb->find(isp->Path(), isp->getDepthSearch()));
	return NULL ; //FIXME
}

OB1Strategy*
BB1BBInterface::addAskDeterministicQuestion(AskDeterministicQuestion* aq)
{
	if (!aq)
		return NULL ;

	pContexte->getSuperviseur()->voidDebugPrintf(NSSuper::trSteps, "On pose une question � OB1") ;
	pContexte->getSuperviseur()->DebugNewLine() ;

  string sActionLog = string("Ask deterministic question: ") +
                       string("label=\"") + aq->Label() + string("\"") +
                       string(" path=\"") + aq->Path()->getString() + string("\"") ;
  addActionString(sActionLog, BB1BBInterface::trSteps) ;

  //
  // First step : is there already a BB1Object with the same path, and whose
  // type is "Question"
  //

	BB1Class *question   = bb->ClassNamed("Question") ;
	BB1KB	   *questionKB = bb->KBNamed("QuestionKB") ;

  string sName = "Question";
	char* num = new char[18];
	itoa(bb->getNBObject(), num, 10);
	sName.append(num);
  delete[] num ;

	AttValPair 	labeldef   ("label",     aq->Label()) ;
	AttValPair  path("question",  *aq->Path()) ;     //fixme
	AttValPair  Explication("explication", *(aq->Path()));    //fixme

	TypedVal toFind(*aq->Path()) ;
	OB1Token* exist = bb->Controler()->find(toFind, std::string("Question")) ;

	if ((exist != NULL) && bb->Controler()->isValidToken(exist))
	{
  	//
    // Question already exists on BB1
    //
  	sActionLog = string("Question already there (token ") + IntToString(exist->getNumero()) + string(")") ;

		exist->getObject()->Modify(NULL, NULL, NULL, NULL, TRUE, false) ;
		exist->incNumero(); // Incremente le conmpteur pour indiquer au controler qu'il y a une nouvelle information differente

    sActionLog += string(" becomes token ") + IntToString(exist->getNumero()) + string(")") ;

  	addActionString(sActionLog, BB1BBInterface::trSubSteps) ;
	}
	else
	{
    //
    // Question doesn't already exists on BB1, we must create it
    //
  	sActionLog = string("New question") ;

		BB1Object* cre = question->MakeInstance(sName, Explication, *questionKB, Collect(&labeldef, &path), NULL, false) ;
		if (NULL != cre)
    {
			exist = bb->Controler()->createToken(ADD, cre) ;
      sActionLog += string(" (creates token ") + IntToString(exist->getNumero()) + string(")") ;
      addActionString(sActionLog, BB1BBInterface::trSubSteps) ;
    }
    else
    {
    	sActionLog += string(" (creation failed)") ;
      addActionString(sActionLog, BB1BBInterface::trError) ;
    }
	}

  if (exist !=  NULL)
    return (bb->Controler()->AskDeterminicOrder(exist, aq->Priority())) ;
  else
    return NULL ;

  //return (bb->AskDeterministicQuestion(aq->getLabel(), aq->getPath() , aq->getPriority()) ) ;
}

bool
BB1BBInterface::addBB1Order(BB1Order* bb1Temp)
{
  switch(bb1Temp->getOrder())
  {
    case BB1CLOSE:
    	break ;
    case BB1CHANGE:
    	break ;
    default:
    	break ;
  }
  return false ;
}

/*
void
BB1BBInterface::EvSize(uint sizeType, ClassLib::TSize& size)
{
    TWindow::EvSize(sizeType, size);
    EventList->MoveWindow(GetClientRect(), true);
}   */

bool
BB1BBInterface::addinsertObjectOnBlacBoard(insertObjectOnBlacBoard* /* temp */)
{
  return (true);
}

bool LeafDefaultComputation(TypedVal& daf, BB1BBInterface* interfa)
{
	if (!interfa)
  	return false ;

  std::string sDaf = daf.getString() ;
  if (sDaf == std::string(""))
		return false ;

  std::string temp = ParseNautilusPath(sDaf) ;
  PathsList que ;
  que.push_back(new std::string(temp)) ;

  string sAnswerDate = string("") ;

  NSPatPathoArray* respat = interfa->SearchInPatientFolder(&que, &sAnswerDate) ;

  // Nothing found in patient's record - we leave
  //
  if (!respat)
  	return false ;

  // if (!respat)  DON'T DO THAT BECAUSE THE TOKEN WOULD NOT BE CREATED
  //	return ;     FOR THE NODE AND THE FUNCTION isActivable() WOULD FAIL
  //               ON THE KS NODE

	// Creation de la reponse

  BB1Object* res = interfa->BB()->find(daf, std::string("Answer"), true) ;
  if (NULL == res)
  {
		BB1KB				*informationKB = interfa->BB()->KBNamed("InformationKB") ;
		BB1Class		*answer 	   = interfa->BB()->ClassNamed("Answer") ;

		AttValPair	label		("label", string("Default calcul")) ;
		AttValPair	sfrom		("sfrom", string("Default Control Calculus")) ;
		AttValPair  Explication("explication", sDaf);
		//
		// true : because we don't duplicate respat, so we must not delete respat
		//
		AttValPair node    ("node", respat, true) ;
    AttValPair dateNode("node_date", sAnswerDate) ;

		std::string id = "default" ;
		char* nb = new char[10] ;
		itoa(interfa->BB()->getNBObject(), nb, 10) ;
		id.append(nb) ;
		delete[] nb ;

		// cr�ation de la r�ponse
		/* BB1AppInst *objectAnswer = */ answer->MakeInstance(id,Explication, *informationKB,
                                  Collect(&label, &node, &dateNode, &sfrom), NULL, true) ;

		res = interfa->BB()->find(daf, std::string("Answer")) ;
	}
  else
  	res->updatePatPatho(respat, sAnswerDate) ;

  if (NULL != res)
  	res->setAnswerStatus(AnswerStatus::astatusProcessed) ;

  return true ;
}

void
BB1BBInterface::PrintAgentList()
{
	if (NULL == bb)
		return ;

	std::vector<OB1NKS* >* kss = bb->Controler()->Graph().getKSs() ;
  if ((!kss) || (kss->empty()))
		return ;

	for (std::vector<OB1NKS* >::reverse_iterator rIter = kss->rbegin() ; rIter != kss->rend() ; rIter++)
	{
		std::string temp = (*rIter)->getKSName();
		TListWindItem		item(temp.c_str(), 0) ;
		_KsList->InsertItem(item) ;
	}
}

bool
BB1BBInterface::insertAnswerOnBlackboard(string sPath, NSPatPathoArray * pAnswer, NautilusObjectType type)
{
  sPath = getRegularPath(sPath, cheminSeparationMARK, intranodeSeparationMARK) ;

  pContexte->getSuperviseur()->voidDebugPrintf(NSSuper::trSteps,"Ins�re une r�ponse sur OB1 : %s",  sPath.c_str()) ;
  pContexte->getSuperviseur()->DebugNewLine() ;

  string sActionLog = string("Insertion of an answer on BB ") +
                       string("(path=\"") + sPath + string("\"") ;

  AttValPair node("node", pAnswer) ;      // FIXME MERCREDI
  string dispatch ;
  TypedVal sear(sPath) ;

  string id = "" ;
  switch (type)
  {
    case Preocupation : id = "Preocupation" ; dispatch = id ;     break ;
    case Drug         : id = "Drug" ;         dispatch = id ;     break ;
    case Goal         : id = "Goal" ;         dispatch = id ;     break ;
    default           : id = sPath ;          dispatch = sPath ;  break ;
  }

  sActionLog += string(" type=\"") + dispatch + string("\"") ;

  int temp = pAnswer->Taille() ;
  pContexte->getSuperviseur()->voidDebugPrintf(NSSuper::trSteps,"Taille patho : %d",  temp) ;
  pContexte->getSuperviseur()->DebugNewLine() ;

  sActionLog += string(" pathoSize=\"") + IntToString(temp) + string("\"") ;
  addActionString(sActionLog, BB1BBInterface::trSteps) ;

  // Put the id
  char * nb = new char[10] ;
  itoa(BB()->getNBObject(), nb, 10) ;
  id.append(nb) ;
  delete[] nb ;

  if (isDeterministe == false)
  {
    OB1Token * exist ;
    // BB1Object * res = bb->find(sear, string("Answer")) ;
    BB1Object* res = bb->searchInKB(sear, std::string("InformationKB")) ;

    if (res != NULL)
    {
    	// ... so we can get its answer status
  		//
  		AnswerStatus* pAnswerStatus = res->Value("answerStatus", NULLLANSWERSTATUS) ;
  		if (!pAnswerStatus)
  			return false ;

      // To be modified
      //
    	sActionLog = string("Corresponding object exists") ;

      exist = bb->Controler()->find(sear, string("Answer")) ;
      if ((NULL != exist) && bb->Controler()->isValidToken(exist))
      {
      	sActionLog += string(" (token ") + IntToString(exist->getNumero()) ;
      	exist->incNumero() ;
        sActionLog += string(" becomes token ") + IntToString(exist->getNumero()) + string(")") ;
      }
      else
      	sActionLog += string(" (no token found)") ;

      addActionString(sActionLog, BB1BBInterface::trSubSteps) ;

      res->Modify(Collect(&node), NULL, NULL) ;
    }
    else
    {
    	sActionLog = string("Creating the corresponding object") ;

      BB1Class * answer = bb->ClassNamed("Answer") ;
      BB1KB * informationKB = bb->KBNamed("InformationKB") ;
      BB1AppInst * answ = answer->MakeInstance(id, AttValPair("explication", dispatch), *informationKB, Collect(&node), NULL, true) ;
      if (answ != NULL)
      {
      	answ->setAnswerStatus(AnswerStatus::astatusProcessing) ;
				answ->setAnswerProcessStage(AnswerStatus::apstageStarting) ;

        return bb->Controler()->NextComputeAction(answ, NULL) ;
/*
        exist = bb->Controler()->createToken(ADD, answ) ;

        sActionLog += string(" (token ") + IntToString(exist->getNumero()) + string(" created)") ;
        addActionString(sActionLog, BB1BBInterface::trSubSteps) ;

        BB()->Controler()->Dispatch(exist, true) ;
*/
      }
      else
      {
      	sActionLog += string(" (failed)") ;
        addActionString(sActionLog, BB1BBInterface::trError) ;
      }
    }
  }
  else
  	addActionString("Deterministic mode (nothing done)", BB1BBInterface::trSubSteps) ;

  return true ;
}

void
BB1BBInterface::insertLeavesOnBlackBoard(string sPath, NSPatPathoArray *pAnswers, NautilusObjectType type)
{
	if ((NULL == pAnswers) || pAnswers->empty())
		return ;

	NSSuper *pSuper = pContexte->getSuperviseur() ;

  PatPathoIter iterSuiv ;
	for (PatPathoIter i = pAnswers->begin(); pAnswers->end() != i ; i++)
  {
  	iterSuiv = i ;
    iterSuiv++ ;

    if ((pAnswers->end() == iterSuiv) || ((*iterSuiv)->getColonne() <= (*i)->getColonne()))
    {
    	// on est s�r ici que iterElement est une feuille
      NSPatPathoArray* pPatPatho = new NSPatPathoArray(pContexte, graphPerson) ;
      pPatPatho->ajoutePatho(i, 0, 0) ;
      string sCheminLex = pAnswers->donneCheminItem(i) ;
      if ((*i)->getUnit() != "")
      	sCheminLex += string(1, cheminSeparationMARK) + (*i)->getUnit() ;
      sCheminLex += string(1, cheminSeparationMARK) + (*i)->getLexique() ;
      string sCheminFils = "" ;
      string sElemLex, sCodeSens ;
      // on enl�ve d'abord la racine
      size_t pos = sCheminLex.find(string(1, cheminSeparationMARK)) ;
      if (pos != string::npos)
      	sCheminLex = string(sCheminLex, pos+1, strlen(sCheminLex.c_str())-pos-1) ;
      else
      	sCheminLex = "" ;

      while (sCheminLex != "")
      {
      	pos = sCheminLex.find(string(1, cheminSeparationMARK)) ;
        if (pos != string::npos)
        {
        	sElemLex = string(sCheminLex, 0, pos) ;
          pSuper->getDico()->donneCodeSens(&sElemLex, &sCodeSens) ;
          sCheminFils += string(1, cheminSeparationMARK) + sCodeSens ;
          sCheminLex = string(sCheminLex, pos+1, strlen(sCheminLex.c_str())-pos-1) ;
        }
        else
        {
        	sElemLex = sCheminLex ;
          pSuper->getDico()->donneCodeSens(&sElemLex, &sCodeSens) ;
          sCheminFils += string(1, cheminSeparationMARK) + sCodeSens ;
          sCheminLex = "" ;
        }
      }

      if (sCheminFils != "")
      	sCheminFils = sPath + sCheminFils ;
      else
      	sCheminFils = sPath ;

      sCheminFils = getRegularPath(sCheminFils, cheminSeparationMARK, intranodeSeparationMARK) ;

			insertAnswerOnBlackboard(sCheminFils, pPatPatho, type) ;
		}
	}
}

void
BB1BBInterface::signalThatPatpathoWasSaved(NSPatPathoArray* pPPT, bool bNew)
{
	if (NULL == bb)
		return ;

	bb->Controler()->deprecateProcessedTokens() ;
  bb->Controler()->resetProcessingTokens() ;
}

void
BB1BBInterface::driveKSfromDialog(long int iToken, KSCONTROL iControl)
{
 	if (NULL == bb)
		return ;

  string sActionLog = string("Driving a Token from a dialog ") +
                       string("(name=\"") + IntToString(iToken) + string("\"") ;
  if      (iControl == ksFree)
  	sActionLog += string(" new mode=\"free_and_running\")") ;
  else if (iControl == ksHold)
  	sActionLog += string(" new mode=\"waiting_for_user_input\")") ;

  addActionString(sActionLog, BB1BBInterface::trSteps) ;

  OB1Token* pTok = bb->Controler()->findTokenFromId(iToken) ;
  if ((NULL == pTok) || (bb->Controler()->isInvalidToken(pTok)))
	{
  	string sActionLog = string("Token ") + IntToString(iToken) + string(" not found") ;
  	addActionString("KS not found", BB1BBInterface::trError) ;
		return ;
	}

	if      (iControl == ksFree)
		pTok->setFree() ;
	else if (iControl == ksHold)
  	pTok->setWaiting() ;
}

/*
void
BB1BBInterface::driveKSfromDialog(string sKsName, KSCONTROL iControl)
{
 	if ((NULL == bb) || (sKsName == ""))
		return ;

  string sActionLog = string("Driving a KS from a dialog ") +
                       string("(name=\"") + sKsName + string("\"") ;
  if      (iControl == ksFree)
  	sActionLog += string(" new mode=\"free_and_running\")") ;
  else if (iControl == ksHold)
  	sActionLog += string(" new mode=\"waiting_for_user_input\")") ;

  addActionString(sActionLog, BB1BBInterface::trSteps) ;

	OB1NKS* ks = bb->Controler()->Graph().getKSByName(sKsName) ;
  if (!ks)
  {
  	addActionString("KS not found", BB1BBInterface::trError) ;
  	return ;
  }

	if      (iControl == ksFree)
		ks->putKsState(FREE_AND_RUNNING) ;
	else if (iControl == ksHold)
  	ks->putKsState(WAITING_FOR_USER_INPUT) ;
}
*/

void
BB1BBInterface::connectTokenToWindow(long int iToken, HWND hInterfaceWindow)
{
	if ((NULL == bb) || (NULL == bb->Controler()))
		return ;

	OB1Token* pTok = bb->Controler()->findTokenFromId(iToken) ;
  if (NULL == pTok)
		return ;

	pTok->setInterfaceWindowHandle(hInterfaceWindow) ;

  pTok->setMMIInDuty(false) ;
}

// Synchronous function : gives an answer if any, else just look in patient's record
//
// Returns : 1 if something found, 0 if not
//
AnswerStatus::ANSWERSTATUS
BB1BBInterface::precoche(string sPath, string /* sArchetype */, NSPatPathoArray ** pAnswer, string* pAnswerDate, string start_date, string end_date)
{
  sPath = getRegularPath(sPath, cheminSeparationMARK, intranodeSeparationMARK) ;

	pContexte->getSuperviseur()->voidDebugPrintf(NSSuper::trSteps, "Pr�cochage : %s", sPath.c_str());
  pContexte->getSuperviseur()->DebugNewLine();

  string sActionLog = string("Asking for precoche ") +
                       string("(path=\"") + sPath + string("\")") ;

  addActionString(sActionLog, BB1BBInterface::trSteps) ;

  //
  // First, look for an answer to such a question
  //
  AnswerStatus::ANSWERSTATUS iAnswerStatus = AnswerStatus::astatusUnknown ;

  TypedVal temp(sPath) ;
  BB1Object* res = bb->find(temp, std::string("Answer")) ;

  if ((NULL != res) &&
	           (res->getAnswerStatus() != AnswerStatus::astatusProcessing) &&
             (res->getAnswerStatus() != AnswerStatus::astatusDeprecated))
  {
    NSPatPathoArray *pTempAnswer = getPatPatho2(res, string("node")) ;// res->Value("node", NULLPATHO) ;
    if (NULL != pTempAnswer)
    	*pAnswer = new NSPatPathoArray(*pTempAnswer) ;
    else
      *pAnswer = new NSPatPathoArray(pContexte) ;

    if (pAnswerDate)
    	*pAnswerDate = res->Value("node_date", string("")) ;

    sActionLog = string("Information found on BB") ;
  	addActionString(sActionLog, BB1BBInterface::trSubSteps) ;

    return iAnswerStatus ;
  }

  //  New
  return getAnswer2Question(sPath, "", pAnswer, *pAnswerDate, true /* bool bCompute */) ;

/*
  // Search in patient's file
  //
  std::string pa_n = ParseNautilusPath(sPath) ;
  PathsList que ;
  que.push_back(new std::string(pa_n)) ;
  NSPatPathoArray* tem = SearchInPatientFolder(&que, pAnswerDate, start_date, end_date) ;

  if (tem == NULL)
  {
  	*pAnswer = new NSPatPathoArray(pContexte) ;

    sActionLog = string("Information not found in patient record") ;
  	addActionString(sActionLog, BB1BBInterface::trSubSteps) ;

    return 0 ;
  }

  // On a quelque chose dans le dossier patient
  // We have found something in patient's record

  *pAnswer = new NSPatPathoArray(*tem) ;

  BB1KB			 *informationKB = bb->KBNamed("InformationKB") ;
  BB1Class	 *answer 	   = bb->ClassNamed("Answer") ;

  AttValPair label		("label", string("Default calcul")) ;
  AttValPair Explication("explication", sPath) ;
  //
  // true : because we don't duplicate tem, so we must not delete tem
  //
  AttValPair node	("node", tem, true) ;   // FIXME MARDI

  std::string id = "default" ;
  char* nb = new char[10] ;
  itoa(bb->getNBObject(), nb, 10) ;
  id.append(nb) ;
  delete[] nb ;

  sActionLog = string("Information found in patient record, creating answer on BB") ;
  addActionString(sActionLog, BB1BBInterface::trSubSteps) ;

  // cr�ation de la r�ponse
  BB1AppInst	*objectAnswer =  answer->MakeInstance(id,Explication, *informationKB,
                              Collect(&label, &node), NULL, true) ;

	return 1 ;
*/
}

AnswerStatus::ANSWERSTATUS
BB1BBInterface::getAnswer2Question(string sPath, string /* sArchetype */, NSPatPathoArray** pAnswer, string &sAnswerDate, bool bCompute, bool bUserIsWaiting, HWND interfaceHandle)
{
  sPath = getRegularPath(sPath, cheminSeparationMARK, intranodeSeparationMARK) ;

	AnswerStatus::ANSWERSTATUS iAnswerStatus = AnswerStatus::astatusUnknown ;

try
{
	string sActionLog = string("Get answer to question ") +
                       string("(path=\"") + sPath + string("\" Compute=") ;
  if (bCompute)
  	sActionLog += string("true)") ;
  else
  	sActionLog += string("false)") ;

  addActionString(sActionLog, BB1BBInterface::trSteps) ;

  isDeterministe = true ;
  TypedVal temp(sPath) ;

  if (bCompute == true) // we have to compute if it possible
  {
  	COMPUTABILITYLEVEL iCLevel = ComputeQuestion(&temp, NULL, bUserIsWaiting, interfaceHandle) ;

    // No KS wants to work on it, then look in patient's file
    //
    if (iCLevel == clNotComputable)
    {
    	TypedVal toFind(sPath) ;
      LeafDefaultComputation(toFind, this) ;
    }
  }

  // true means "don't only look at the nodes"
  //
  BB1Object* res = bb->find(temp, std::string("Answer"), true) ;
  if (NULL == res)
  	res = bb->find(temp, std::string("InformationKB"), true) ;

  if (NULL != res)
  {
  	iAnswerStatus = res->getAnswerStatus() ;

    NSPatPathoArray *pTempAnswer = getPatPatho2(res, string("node")) ;
    if ((NULL != pTempAnswer) && (iAnswerStatus == AnswerStatus::astatusProcessed))
    {
    	*pAnswer = new NSPatPathoArray(*pTempAnswer) ;
      sAnswerDate = res->Value("node_date", string("")) ;
    }
    else
    	*pAnswer = new NSPatPathoArray(pContexte) ;
  }
  else
    *pAnswer = new NSPatPathoArray(pContexte) ;

  isDeterministe = false ;
}
catch(...)
{
	erreur("GetAnswer Erreur", standardError, 0, bb->pContexte->GetMainWindow()->GetHandle()) ;
	isDeterministe = false ;
}
  return iAnswerStatus ; // FIXME return
}

/*
BB1BBInterface::COMPUTABILITYLEVEL
BB1BBInterface::ComputeQuestion(TypedVal* quest)
{
	if (quest == NULL)
		return clError ;

	//
	// First, create an "answer" for follow up
  //
  BB1Object* res = bb->find(*quest, std::string("Answer")) ;
  if (NULL == res)
	{
    std::string sDaf = quest->getName().getString() ;
    std::string temp = ParseNautilusPath(sDaf) ;

    // Creation of the answer
    //
    BB1KB		 *informationKB = BB()->KBNamed("InformationKB") ;
    BB1Class *answer        = BB()->ClassNamed("Answer") ;

		AttValPair label      ("label",       string("Follow up answer")) ;
		AttValPair sfrom      ("sfrom",       string("Interface::ComputeQuestion")) ;
		AttValPair Explication("explication", sDaf) ;
    //
    // true : because we don't duplicate respat, so we must not delete respat
    //
    NSPatPathoArray* respat = NULL ;

    AttValPair node ("node", respat, true) ;

    std::string id = "default" ;
    char* nb = new char[10] ;
    itoa(other->Controler()->BB()->getNBObject(), nb, 10) ;
    id.append(nb) ;
    delete[] nb ;

    // cr�ation de la r�ponse
    BB1AppInst *objectAnswer =
    answer->MakeInstance(id,Explication, *informationKB,
                               Collect(&label, &node, &sfrom), NULL, true) ;

    res = bb->find(*quest, std::string("Answer")) ;
  }

  if (NULL != res)
  {
  	res->setAnswerStatus(AnswerStatus::astatusProcessing) ;
		res->setAnswerProcessStage(AnswerStatus::apstageUnknown) ;
  }

	AskDeterministicQuestion* question = new AskDeterministicQuestion("DeterministicQuestion", quest, 10) ;
	OB1Strategy* strat = addAskDeterministicQuestion(question) ;

  if (NULL == strat)
  {
  	if (NULL != res)
			res->setAnswerProcessStage(AnswerStatus::apstageRecord) ;
  	return clNotComputable ;
  }

  if (NULL != res)
			res->setAnswerProcessStage(AnswerStatus::apstageDirectKS) ;

	bool out = false ;
	while ((out != true) && (NULL != strat))
		out = bb->Controler()->ExecuteDeterministicAction(&strat) ;
	// return out ;
  return clComputable ;
}
*/

BB1BBInterface::COMPUTABILITYLEVEL
BB1BBInterface::ComputeQuestion(TypedVal* quest, OB1Token* pMasterToken, bool bUserIsWaiting, HWND interfaceHandle)
{
	if (quest == NULL)
		return clError ;

  bool bQuestionCreated = bb->Controler()->createQuestionAndAnswer(quest) ;
  if (!bQuestionCreated)
  	return clError ;

  BB1Object* pQuestion = bb->searchInKB(*quest, std::string("QuestionKB")) ;
  if (NULL == pQuestion)
		return clError ;

	bb->Controler()->NextComputeAction(pQuestion, pMasterToken, bUserIsWaiting, interfaceHandle) ;

  return clComputable ;
}

//
// Returns :
//    - NULL is nothing can be found in patient record
//    - A new NSPatPathoArray corresponding to the found node's array elsewhere
//
NSPatPathoArray*
BB1BBInterface::SearchInPatientFolder(PathsList* pPaths, string* pAnswerDate, string start_date, string end_date)
{
	NSPatPathoArray	*pAnswer = NULL ;

	if ((pPaths == NULL) || (pPaths->empty()))
		return pAnswer ;

	for (PathsIterator pathsIter = pPaths->begin() ; pathsIter != pPaths->end() ; pathsIter++)
	{
		NSSearchStruct searchStruct(NSSearchStruct::modeAsIs,
		                            NSSearchStruct::typeAsIs ,                                NSSearchStruct::positLastInTime,                                1, start_date, end_date, NULL) ;
		/*pSearchStruct->iMode            = NSSearchStruct::modeAsIs ;
			pSearchStruct->iType            = NSSearchStruct::typeAsIs ;
			pSearchStruct->sStartingDate    = "" ;
			pSearchStruct->sEndingDate      = "" ;
			pSearchStruct->psStartingNode   = NULL ;
			pSearchStruct->iNbNodes         = 1 ;
			pSearchStruct->iNodesPosit      = NSSearchStruct::positLastInTime ;*/

		bool bOk = pContexte->getPatient()->ChercheChemin(**pathsIter, &searchStruct) ;
		if (bOk)
		{
			std::string date = "" ;
			std::string sNoeud = "" ;
			if (!(searchStruct.aFoundNodes.empty()))
			{
				for (MappingNSSearchResult::MMapIt it = searchStruct.aFoundNodes.begin(); it != searchStruct.aFoundNodes.end(); it++)
        	searchStruct.aFoundNodes.fullRData(it, date, sNoeud) ;
				pAnswer = new NSPatPathoArray(pContexte) ;
        *pAnswerDate = date ;
				pContexte->getPatient()->DonneArray(sNoeud, pAnswer) ;
				pAnswer->clearAllIDs() ;
				break ;
			}
		}
	}
	return pAnswer ;
}

void
BB1BBInterface::EnableControl(int RessourceId, bool visible)
{
  if (visible)
  {
    ::ShowWindow(GetDlgItem(RessourceId),   SW_SHOW);
    ::EnableWindow(GetDlgItem(RessourceId), TRUE );
  }
  else
  {
    ::ShowWindow(GetDlgItem(RessourceId),   SW_HIDE);
    ::EnableWindow(GetDlgItem(RessourceId), FALSE );
  }
}

void
BB1BBInterface::showKsProperty(uint iIndex)
{
	std::vector<OB1NKS* >* kss = bb->Controler()->Graph().getKSs() ;
	if (iIndex >= kss->size())
		return ;

  NSOB1NodesTreeControl* pNodesCtrl = new NSOB1NodesTreeControl(0, this, (*kss)[iIndex], 0, 0, 0, 0, 0, TTreeWindow::twsNone, pNSResModule) ;
	OB1NodesInterfaceContainer* interfaceMDI = new OB1NodesInterfaceContainer(*(pContexte->getSuperviseur()->getApplication()->prendClient()), pContexte, pNodesCtrl) ;
	interfaceMDI->Create() ;
	pNodesCtrl->SetParent(interfaceMDI) ;
}

void
BB1BBInterface::addActionString(string sActionText, BBTRACETYPE iActionLevel)
{
	if ((iActionLevel > _actionsLogLevel) || (sActionText == string("")))
  	return ;

  string sActionTexteInList = string("") ;

  switch(iActionLevel)
  {
    case trError      : sActionTexteInList = string("* ") ; break ;
    case trWarning    : sActionTexteInList = string("! ") ; break ;
    case trSteps      : sActionTexteInList = string("> ") ; break ;
    case trSubSteps   : sActionTexteInList = string("    ") ; break ;
    case trDetails    : sActionTexteInList = string("      ") ; break ;
    case trSubDetails : sActionTexteInList = string("        ") ; break ;
  }

  sActionTexteInList += sActionText ;

  TListWindItem	item(sActionTexteInList.c_str(), 0) ;
  _actionsInOB1->InsertItem(item) ;
  _actionsInOB1->Invalidate() ;
}

// Check that a path of the kind VINR0/VMIN1/20000/�N0 get transformed into
//                                                       VINR0/VMIN1/20000.�N0
//
std::string
ParseNautilusPath(std::string& naut_path)
{
  return getRegularPath(naut_path, cheminSeparationMARK, intranodeSeparationMARK) ;

/*
  std::string result = naut_path ;
  for (register unsigned int i = 0; i < result.size(); i++)
  {
    if (cheminSeparationMARK == result[i])
    {
      bool change = false ;
      if (result.size() > i + 1)
      {
        if ('$' == result[i+1])
          change = true ;
        else if (result.size() > i + 2)
        {
          std::string temp = result.substr(i+1, 2) ;
          if ((temp == "�N") || (temp == "�D") || (temp == "�T"))
            change = true ;
          else if (result.size() > i + 3)
          {
            std::string temp = result.substr(i+1, 3) ;
            if (temp == "WCE")
              change = true ;
            else if (result.size() > i + 4)
            {
              std::string temp = result.substr(i+1, 4) ;
              if (temp == "WPLU")
                change = true ;
            }
          }
        }
      }
      if (true == change)
        result[i] = intranodeSeparationMARK ;
    }
  }
  return (result) ;
*/
}


/*******************************************************************************
************* Implementation de fenetre g�rant l'interface *********************
*******************************************************************************/

DEFINE_RESPONSE_TABLE1(OB1InterfaceContainer, TMDIChild)
    EV_WM_DESTROY,
    EV_WM_SIZE,
    EV_WM_CLOSE,
END_RESPONSE_TABLE ;

OB1InterfaceContainer::OB1InterfaceContainer(TMDIClient& parent, NSContexte *Contexte, BB1BBInterface* interf)
: TMDIChild(parent, "Blackboard History X")
{
	_interface = interf;
	_pContexte = Contexte;
	//Attr.Style = WS_CHILD |WS_THICKFRAME	| WS_VISIBLE ;
	Attr.X = 0 ;
	Attr.Y = 0 ;
	Attr.H = 700 ;
	Attr.W = 300 ;
}

OB1InterfaceContainer::~OB1InterfaceContainer()
{
}

void
OB1InterfaceContainer::SetupWindow()
{
	TMDIChild::SetupWindow();
  SetClientWindow(_interface);
}

void
OB1InterfaceContainer::EvSize(uint sizeType, ClassLib::TSize& size)
{
	TMDIChild::EvSize(sizeType, size) ;
}

void
OB1InterfaceContainer::EvDestroy()
{
}

bool
OB1InterfaceContainer::CanClose()
{
	// on ruse avec un bool�en dans PatientChoisi
	// pour r�soudre le bug de la sauvegarde lors de la fermeture historique
	if ((_pContexte->getPatient()) && (_pContexte->getPatient()->bCanCloseHisto))
		return true ;

	return false ;
}

// -----------------------------------------------------------------------------
//
// M�thodes de NSKSListWindow//
// -----------------------------------------------------------------------------DEFINE_RESPONSE_TABLE1(NSKSListWindow, TListWindow)  EV_WM_LBUTTONDBLCLK,
  EV_WM_RBUTTONDOWN,
  EV_WM_KEYDOWN,
  EV_WM_KILLFOCUS,
  EV_WM_SETFOCUS,
  EV_WM_LBUTTONUP,
END_RESPONSE_TABLE ;

NSKSListWindow::NSKSListWindow(BB1BBInterface *parent, int id, int x, int y, int w, int h, TModule *module)
               :TListWindow((TWindow *) parent, id, x, y, w, h, module)
{
  pInterface    = parent ;
  iRes          = id ;
  Attr.Style    |= LVS_REPORT | LVS_SHOWSELALWAYS ;
//  Attr.ExStyle  |= WS_EX_NOPARENTNOTIFY ;
}
NSKSListWindow::NSKSListWindow(BB1BBInterface *parent, int id, TModule *module)
               :TListWindow((TWindow *) parent, id, module)
{
  pInterface    = parent ;
  iRes          = id ;
  Attr.Style    |= LVS_REPORT | LVS_SHOWSELALWAYS ;
//  Attr.ExStyle  |= WS_EX_NOPARENTNOTIFY ;
}

void
NSKSListWindow::SetupWindow()
{
  ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;
  TListWindow::SetupWindow() ;
}


// -----------------------------------------------------------------------------
// Fonction de r�ponse au double-click
// -----------------------------------------------------------------------------
void
NSKSListWindow::EvLButtonDblClk(uint /* modKeys */, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point) ;

	int indexItem = HitTest(info) ;
	if (info.GetFlags() & LVHT_ONITEM)		pInterface->showKsProperty(indexItem) ;
}

void
NSKSListWindow::EvRButtonDown(uint /* modkeys */, NS_CLASSLIB::TPoint& /* point */)
{
}

void
NSKSListWindow::EvKeyDown(uint /* key */, uint /* repeatCount */, uint /* flags */)
{
}

void
NSKSListWindow::EvLButtonUp(uint /* modKeys */, NS_CLASSLIB::TPoint& /* pt */)
{
}

// -----------------------------------------------------------------------------
// Retourne l'index du premier item s�lectionn�
// -----------------------------------------------------------------------------
int
NSKSListWindow::IndexItemSelect()
{
	int count = GetItemCount() ;
	int index = -1 ;

	for (int i = 0 ; i < count ; i++)		if (GetItemState(i, LVIS_SELECTED))
    {
    	index = i ;
      break ;
    }

	return index ;}


void
NSKSListWindow::EvSetFocus(HWND /* hWndLostFocus */)
{
	SetBkColor(0x00fff0f0) ; // 0x00bbggrr
	SetTextBkColor(0x00fff0f0) ;
	Invalidate() ;

	int count = GetItemCount() ;

	for (int i = 0 ; i < count ; i++)
		if (GetItemState(i, LVIS_SELECTED))
			return ;

	SetItemState(0, LVIS_FOCUSED | LVIS_SELECTED, LVIS_SELECTED) ;
}

void
NSKSListWindow::EvKillFocus(HWND /* hWndGetFocus */)
{
	SetBkColor(0x00ffffff) ; // 0x00bbggrr
	SetTextBkColor(0x00ffffff) ;
	Invalidate() ;
}



