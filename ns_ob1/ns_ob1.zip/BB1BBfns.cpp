/*
** Copyright Nautilus, (10/9/2004)
** fabrice.le_perru@nautilus-info.com
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/

#ifndef _OWLDLL
# include "BB1BB.h"
# include "BB1KB.h"        // for BB1BB::CheckDirectSuperclasses(...)
# include "BB1Class.h"     // for BB1BB::OppositeLinkName(...)
# include "BB1Link.h"      // for BB1BB::OppositeLinkName(...)
# include "BB1Exception.h"    // add fab
#else
# include "ns_ob1\BB1BB.h"
# include "ns_ob1\BB1KB.h"        // for BB1BB::CheckDirectSuperclasses(...)
# include "ns_ob1\BB1Class.h"     // for BB1BB::OppositeLinkName(...)
# include "ns_ob1\BB1Link.h"      // for BB1BB::OppositeLinkName(...)
# include "ns_ob1\BB1Exception.h"    // add fab
#endif

// -----------------------------------------------------------------------------
// This file contains the non-exported methods for class BB1BB. The Application
// Programmer's Interface methods are defined in "BB1API.c".
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Check the validity of a class's set of allowed attributes. If this isn't
// going to get more complex, it should either be made an inline in BB1BB.h or,
// better yet, abolished.
// -----------------------------------------------------------------------------

bool		BB1BB::CheckAllowedAttributes(const AVPSet *allowedAttributes)
{

#ifdef _DEBUG_
  trout << "BB1BB::CheckAllowedAttributes(const SetOfAVP &)\n" ;
#endif

  // A class can have any attributes
  // Should we check for duplicates?
  return (true) ;
}


// -----------------------------------------------------------------------------
// Check the validity of a class's set of direct superclasses. Return the links
// in the dcLinks parameter.
// -----------------------------------------------------------------------------

bool		BB1BB::CheckDirectSuperclasses(const StringList	*dscNames,
					       ObjectSet	*dscObjects)
{

#ifdef _DEBUG_
  trout << "BB1BB::CheckDirectSuperclasses(const ListOfString &, SetOfBB1Object &)\n" ;
#endif

  try
  {
    dscObjects->clear() ;
    if (dscNames && !dscNames->empty())
    {
      for (StrCIter p = dscNames->begin() ; p != dscNames->end() ; p++)
      {
				BB1Object *dsc = classKB->ObjectNamed(*p) ;
				if (dsc)
					dscObjects->push_back(dsc) ; // don't worry about duplicates
				else
					ClassDoesNotExist cdne(*this, string("BB1BB:DefineClass(...)"), *p) ; // throw cdne
      }
    }
    if (dscNames)
      return (dscNames->size() == dscObjects->size()) ;
    else
      return (dscObjects->size() == 0) ;

  } // end try
  catch (ClassDoesNotExist& cdne)
    { return (false) ; }

 // return (false) ;
}



// -----------------------------------------------------------------------------
// Clear the data member BB1BB::linkPairs
// -----------------------------------------------------------------------------

Errcode		BB1BB::ClearLinkPairs()
{

#ifdef _DEBUG_
  trout << "BB1BB::ClearLinkPairs()\n" ;
#endif

  if (linkPairs && !linkPairs->empty())
  {
    for (LinkPairIter p = linkPairs->begin() ; p != linkPairs->end() ; )
    {
      delete (*p) ;
      linkPairs->erase(p) ;
    }
    linkPairs->clear() ;
  }

  return (SUCCESS) ;
}



// -----------------------------------------------------------------------------
// Return the link name which is the opposite of the given link name
// -----------------------------------------------------------------------------

const		string &BB1BB::OppositeLinkName(const string& name, const BB1Class& c) const
{

#ifdef _DEBUG_
  trout << "BB1BB::OppositeLinkName(" << name << ", const BB1Class &) const\n" ;
#endif

  static string	canBeA("CanBeA") ;
  static string isA("IsA") ;
  static string exemplifiedBy("ExemplifiedBy") ;
  static string exemplifies("Exemplifies") ;
  static string nullString("") ;

  try
  {
    // Handle built-in reserved links separately
    if (name == "IsA")
      return (canBeA) ;
    else
      if (name == "CanBeA")
				return (isA) ;
      else
				if (name == "Exemplifies")
					return (exemplifiedBy) ;
				else
					if (name == "ExemplifiedBy")
						return (exemplifies) ;
					else
					{
						if (linkPairs && !linkPairs->empty())
							for (LinkPairCIter p = linkPairs->begin() ; p != linkPairs->end() ; p++)
							{
								const BB1LinkPair& lp = **p ;
								if (lp.ForwardLink() == name && (c.Name() == "Class" || c.IsAP(lp.FromClassName())))
									return (lp.InverseLink()) ;
								else
									if (lp.InverseLink() == name && (c.Name() == "Class" || c.IsAP(lp.ToClassName())))
										return (lp.ForwardLink()) ;
							}
						LinkDoesNotExist ldne(*this, "", /* don't know method yet */ name) ;
						// throw ldne;
	  			}
  } // end try
  catch (LinkDoesNotExist& ldne)
    { return (nullString) ; }

  return (nullString) ;
}


// -----------------------------------------------------------------------------
// Is the link name one of the built-in reserved links? Since this doesn't use
// any member of class BB1BB, it doesn't have to be a member function.
// -----------------------------------------------------------------------------

bool		BB1BB::ReservedLinkP(const string& linkName) const
{

#ifdef _DEBUG_
  trout << "-- DEBUG:: BB1BB::ReservedLinkP(" << linkName << ")\n" ;
#endif

  return ((linkName == "IsA") || (linkName == "CanBeA") || (linkName == "Exemplifies") || (linkName == "ExemplifiedBy")) ;
}
