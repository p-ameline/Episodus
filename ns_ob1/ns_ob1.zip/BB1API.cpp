/*
** Copyright Nautilus, (10/9/2004)
** fabrice.le_perru@nautilus-info.com
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/

#include <iostream.h>      // for BB1BB::BB1BB(...)
#include <string.h>        // for BB1BB::Send(...)

#ifndef _OWLDLL

#include "AttValPair.h"    // for BB1BB::~BB1BB()
#include "BB1BB.h"
#include "BB1KB.h"         // for BB1BB::BB1BB(...)
#include "BB1KSKB.h"       // for BB1BB::BB1BB(...)
#include "ClassKB.h"       // for BB1BB::BB1BB(...)
#include "BB1Exception.h"    // add fab

#else

#include "ns_ob1/AttValPair.h"    // for BB1BB::~BB1BB()
#include "ns_ob1/BB1BB.h"
#include "ns_ob1/BB1KB.h"         // for BB1BB::BB1BB(...)
#include "ns_ob1/BB1KSKB.h"       // for BB1BB::BB1BB(...)
#include "ns_ob1/ClassKB.h"       // for BB1BB::BB1BB(...)
#include "ns_ob1/BB1Exception.h"    // add fab
#include "ns_ob1/OB1Token.h"
#include "ns_ob1/OB1Controler.h"
#include "ns_ob1/NSKS.h"

#endif

// from /a/bb1/ipc/io.h
//extern Controler* _globalControler;

/*
#ifdef __IPC__
extern "C"
{
  char 	*get_unique_id() ;
  int 	gethostname(char *name, int namelen) ;
  int 	net_connect(const char	*contact_name,
										char				*hostname,
										char				*unique_id,
										int					connect_block,
										int					comm_block,
										int					nohang) ;
	int 	send_buf(int sock, char *buf) ;
}
#endif     */

// -----------------------------------------------------------------------------
//  This file contains the Application Programmer's Interface methods. The
//  non-exported methods are defined in "BB1BB.c".
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
//  Construct a blackboard. It may be a restriction that the initialization
//  function take no arguments. This is not part of the API.
// -----------------------------------------------------------------------------

BB1BB::BB1BB(	NSContexte*                 pCtx,
							const InitFunctionT         initFn,
							const TerminationConditionT terminationCond,
							int                         /* argc */,
							char**                      /* argv */)
	: initFunction(initFn),
		terminationCondition(terminationCond),
		BB1BBphase(INITIALIZATION),
		cycle(PRECYCLE),
		eventCount(0),
		messageCount(0),
		triggerEvent((BB1Event *) NULL),
		traceCycle(false),
		traceEvent(false),
		traceKSAR(false),
		traceMessage(false),
		errorAction(ABORT_ANY),
		errorNotify(WARN),
		errorHandler(DefaultErrorHandler),
		trout(cout),
		cycles2add(0),
		NSRoot(pCtx)
{
  _nbObject = 0;
  //_globalControler =  &_controler;
  OB1Token::_token_counter = 1 ; // start with 1 since 0 means "no token"
  _kenoby = new OB1Controler(this) ;
  kbs = new KBSet() ;
	classKB = DefineKB("Class") ;
  cycle = 0;
  loadClassKB(*this) ;
  classKB->SetProtected(true) ;

  linkPairs = new LinkPairSet() ;

  DefineRelation("Implements", "ImplementedBy", "Decision", "Strategy") ;

 	nskss					= new vector<NSKS *> ;

	// ---------------------------------------------------------------------------
	// Built-in classes
	// Control-plan stuff
	// Communication interface stuff
	// ---------------------------------------------------------------------------
}


BB1BB::BB1BB(const BB1BB& bb)
  : initFunction(bb.initFunction),
    terminationCondition(bb.terminationCondition),
    BB1BBphase(bb.BB1BBphase),
    cycle(bb.cycle),
    eventCount(bb.eventCount),
    messageCount(bb.messageCount),
    triggerEvent(bb.triggerEvent),
    traceCycle(bb.traceCycle),
    traceEvent(bb.traceEvent),
    traceKSAR(bb.traceKSAR),
    traceMessage(bb.traceMessage),
    errorAction(bb.errorAction),
    errorNotify(bb.errorNotify),
    errorHandler(bb.errorHandler),
		trout(bb.trout),
		cycles2add(bb.cycles2add),
		NSRoot(bb.pContexte)
{

  _kenoby = new OB1Controler(this);
	ks						= bb.ks ;
  cycle = 0;

	BB1BBphase		= bb.BB1BBphase ;
  /*#ifndef __TCONTROLER__
	kss						= new KSSet(*(bb.kss)) ;
  #endif  */
	kbs						= new KBSet(*(bb.kbs)) ;
	linkPairs			= bb.linkPairs ;
	classKB				= bb.classKB ;
 OB1Token::_token_counter = 0 ; // start with 1 since 0 means "no token"


	nskss					= new vector<NSKS *> ;
	for (vector<NSKS *>::iterator iter = bb.nskss->begin() ; iter != bb.nskss->end() ; iter++)
		nskss->push_back(new NSKS(**iter)) ;

// -----------------------------------------------------------------------------
// DPIO add
	Akss					= new AKSSet(*(bb.Akss)) ;
// -----------------------------------------------------------------------------

}



// -----------------------------------------------------------------------------
// Destroy a blackboard. This is not part of the API.
// -----------------------------------------------------------------------------

BB1BB::~BB1BB()
{
 // _controler.ConstructNetWork();

	KBIter	cp;

	// Delete the KB instances. The destructor will delete the objects
	if (!kbs->empty())
	{
		for (KBIter p = kbs->begin() ; p != kbs->end() ; )
		{
			if ((*p)->Name() == "Class")
			{
				// Save to delete Class KB last
				cp = p ;
				p++ ;
			}
			else
			{
        delete (*p) ;
				kbs->erase(p) ;
			}
		}
		// Delete the Class KB
		delete (*cp) ;
		kbs->erase(cp) ;

		// Clear the set of its elements
		kbs->clear() ;
	}

	delete (kbs) ;

	// Delete the interned function pointers
	ClearLinkPairs() ;

/*	for (vector<NSKS *>::iterator iter = nskss->begin() ; iter != nskss->end() ; )
	{
		//delete (*iter) ;
		//nskss->erase(iter) ;
	}  */
 //	delete nskss ;

  delete(_kenoby) ;
}

