
#include "ns_bbk/TControler/KSMemory.h"


KSmemory::KSmemory()
{
  Answer = new std::vector<BB1Object* >();
}
