/*
** Copyright Nautilus, (10/9/2004)
** fabrice.le_perru@nautilus-info.com
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/

#include "ns_ob1\BB1BB.h"
#include "ns_ob1\AttValPair.h"
#include "ns_ob1\BB1Object.h"
#include "ns_ob1\BB1Class.h"
#include "ns_ob1\BB1KS.h"
#include "ns_ob1\OB1Controler.h"
#include "ns_ob1\BB1KB.h"
#include "ns_ob1\OB1Token.h"
#include "nautilus\nssuper.h"

void
BB1BB::RunInOpportunisticMode(int nb_tour)
{
	_kenoby->RunInOpportunisticMode(nb_tour) ;
}

BB1Object*
BB1BB::find(TypedVal& path, std::string clas, bool depp)
{
	BB1Object* result = NULL ;

  OB1Token* temp = _kenoby->find(path, clas) ;
  if (temp != NULL)
    return temp->getObject() ;

  if ((depp == true) && (!(kbs->empty())))
		//
		for (BB1List<BB1KB*>::iterator iter= kbs->begin(); (result == NULL) && (iter != kbs->end()); iter ++)
    	result = searchInKB(path, (*iter)->Name()) ;

	return result ;
}

BB1Object*
BB1BB::searchInKB(TypedVal& question, std::string& ksName)
{
  BB1KB	*EventKB = KBNamed(ksName) ;
	if (NULL == EventKB)
		return NULL ;

  const ObjectSet *datas = EventKB->ObjectsInKB() ;
	if ((NULL == datas) || (datas->empty()))
		return NULL ;

	string sExplication("explication") ;
  
	// AttValPair Explication("explication", question) ;

	// Old code. Don't do that since question is a TypedVal that could contain
  // anykind of object, and not only a string
  //
  // string sQuestion = question.getString() ;
  // if (!(datas->empty()))
  // 	for (ObjectCIter iter = datas->begin() ; iter != datas->end() ; iter++)
  //   	if ((*iter)->Value("explication", NULLSTRING) == sQuestion) don
	// 			return (*iter) ;

	for (ObjectCIter iter = datas->begin() ; iter != datas->end() ; iter++)
  	if (NULL != *iter)
    {
    	TypedVal* pTV = (*iter)->Attributes(sExplication) ;
      if ((NULL != pTV) && (*pTV == question))
	 			return (*iter) ;
    }

  return (NULL) ;
}

BB1Object*
BB1BB::askQuestion(std::string& sQuestion, bool createToken)
{
  return NULL ;
}

bool
BB1BB::PutInformation(BB1Object* respp)
{
  return true ;
}

std::vector<OB1NKS* >*
BB1BB::getKSOfType(KSType typ)
{
	OB1Graph& temp = Controler()->Graph() ;
  return temp.getKSOfType(typ) ;
}

std::vector<OB1NKS* >*
BB1BB::getValidKs(std::vector<OB1NKS* >* ks, ValidityContextType type)
{
	if (!ks || (ks->empty()))
		return (ks) ;

  for (std::vector<OB1NKS* >::iterator iter = ks->begin(); iter != ks->end(); )
	{
		(*iter)->ComputeValidity(NULL) ;
    if ((*iter)->ContextValidity() != type )
    	ks->erase(iter) ;
    else
    	iter++ ;
	}
	return (ks) ;
}

std::vector<OB1NKS* >*
BB1BB::getKSOfKB(std::vector<OB1NKS* >* ks, std::string& kbName)
{
	if (!ks || (ks->empty()))
		return (ks) ;

	for (std::vector<OB1NKS* >::iterator iter = ks->begin(); iter != ks->end();)
	{
  	if ((*iter)->getKS()->KB().Name() != kbName)
    	ks->erase(iter) ;
    else
    	iter++ ;
  }
	return (ks) ;
}

bool
BB1BB::Execute()
{
  // Incremente the count of the cycle int the BB
  IncrementCycle() ;
  // Execute the action
  _kenoby->Execute() ;
  return (true) ;
}

bool
BB1BB::giveAnswerToQuestion(TypedVal* pPathVal, NSPatPathoArray* pAnswerPatho, string sAnswerDate, bool bExt)
{
	BB1Object* pAnswer = searchInKB(*pPathVal, std::string("InformationKB")) ;
  if (NULL == pAnswer)
	{
  	// Creation of the answer
		//
		BB1KB		 *informationKB = KBNamed("InformationKB") ;
		BB1Class *answer        = ClassNamed("Answer") ;

		AttValPair label      ("label",       string("Follow up answer")) ;
		AttValPair sfrom      ("sfrom",       string("Interface::ComputeQuestion")) ;
		AttValPair AnswExplica("explication", *pPathVal) ;
		//
		// true : because we don't duplicate respat, so we must not delete respat
		//
		NSPatPathoArray* respat = NULL ;

		AttValPair node ("node", respat, true) ;

		std::string id = "default" ;
		char* nb = new char[10] ;
		itoa(getNBObject(), nb, 10) ;
		id.append(nb) ;
		delete[] nb ;

		pAnswer = answer->MakeInstance(id, AnswExplica, *informationKB, Collect(&label, &node, &sfrom), NULL, false) ;

  	string sActionLog = string("New answer") ;
  	if (NULL == pAnswer)
		{
  		sActionLog += string(" (creation failed)") ;
			pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trError) ;
    	return false ;
  	}

		sActionLog += string(" (creation succeeded)") ;
		pContexte->getSuperviseur()->getBBinterface()->addActionString(sActionLog, BB1BBInterface::trSubSteps) ;

		pAnswer->setAnswerStatus(AnswerStatus::astatusProcessed) ;
  	pAnswer->setAnswerProcessStage(AnswerStatus::apstageUnknown) ;
  }

	pAnswer->updatePatPatho(pAnswerPatho, sAnswerDate, bExt) ;

  return true ;
}

