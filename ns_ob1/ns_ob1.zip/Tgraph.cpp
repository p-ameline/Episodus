/*
** Copyright Nautilus, (10/9/2004)
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/

#include <iostream>
#include <fstream>

#include "ns_ob1\OB1graph.h"

OB1Graph::OB1Graph()
{
  _AllNode = new std::vector<OB1Node*>();
  _Ks_nodes = new std::vector<OB1NKS* >() ;
  _Other_nodes =  new std::map<std::string, OB1NOther* >();
  _Validity_nodes = new std::vector<OB1NValidity* >();
  _Trigger_nodes = new std::vector<OB1NTrigger* >();
  _And_nodes = new std::vector<OB1NAnd* >();
  _Result_Nodes = new std::vector<OB1NResult* >();
  _Level_node = new std::vector<OB1NLevel* >();
  _graph_size = 0;
}

OB1Graph::OB1Graph(OB1Graph& inp)
{
  _graph_size = 0;
  _AllNode = new std::vector<OB1Node*>();
  _Ks_nodes = new std::vector<OB1NKS* >() ;
  _Other_nodes = new std::map<std::string, OB1NOther* >();
  _Validity_nodes = new std::vector<OB1NValidity* >();
  _Trigger_nodes = new std::vector<OB1NTrigger* >();
  _And_nodes = new std::vector<OB1NAnd* >();
  _Result_Nodes = new std::vector<OB1NResult* >();
  _Level_node = new std::vector<OB1NLevel* >();
  putAllVertex(inp.getAllVertex());
}



OB1Graph::~OB1Graph()
{
 	//save("noeud.html");
  for (unsigned int i =0; i <  _AllNode->size(); i++)
    if ((*_AllNode)[i] != NULL)
    {
      delete ((*_AllNode)[i]);
      (*_AllNode)[i] = NULL;
    }
  _AllNode->clear();
  if (_AllNode != NULL)
      delete(_AllNode);

  _Ks_nodes->clear();
  delete(_Ks_nodes);         /* All KS Node */
  _Other_nodes->clear();
  delete(_Other_nodes);     /* All Other Node */
  _Validity_nodes->clear();
  delete(_Validity_nodes);   /* All validity Node */
  _Trigger_nodes->clear();
  delete(_Trigger_nodes);    /* All trigger Node */
  _And_nodes->clear();
  delete(_And_nodes);        /* And node */
  _Result_Nodes->clear();
  delete(_Result_Nodes);     /* All result Node */
  _Level_node->clear();
  delete( _Level_node);
}

/*
** find a node in the graph
** If the node does not exsit then return -42
** else return the numero of the node int the graph
*/
int  OB1Graph::find(OB1Node* temp)
{
  register unsigned int end= numVertices() ;
  for (register unsigned int i = 0; i< end; i++)
  	if ( (*temp).Compares((*_AllNode)[i]) )
    	return (i) ;
  return (-42) ;
}

void  OB1Graph::AddVertex(OB1Node* nod)
{
  _graph_size++ ;
  switch(nod->getType())
  {
    case KS_NODE:
    {
      OB1NKS* temp =  (OB1NKS*)nod;
      _Ks_nodes->push_back(temp);
    }
    break;
    case OTHER_NODE:
    {
      std::string id = ComputeSortingId(((OB1NOther*)nod)->getName());
      (*_Other_nodes)[ id] = (OB1NOther*)nod;
    }
    // sort(_Other_nodes->begin(),_Other_nodes->end(),tri_other);
    break;
    case VALIDITY_NODE:
      _Validity_nodes->push_back((OB1NValidity*)nod);
    break;
    case AND_NODE:
      _And_nodes->push_back((OB1NAnd*)nod);
    break;
    case RESULT_NODE:
      _Result_Nodes->push_back((OB1NResult*)nod);
    break;
    case LEVEL_NODE:
      _Level_node->push_back((OB1NLevel*)nod);
    break;
    case TRIGGER_NODE:
      _Trigger_nodes->push_back((OB1NTrigger*)nod);
    break;
  }
  this->_AllNode->push_back(nod);
}

const int OB1Graph::Degree(OB1Node& vert) const
{
	return (vert.ChildrenCardinal()) ;
}

#ifdef __OB1__UNOPTIM__
void  OB1Graph::print(std::ostream& ostr) const
{
	ostr << "Taille du graph :" << numVertices() << std::endl;
  for (unsigned int i = 0; i < this->_AllNode->size(); i++)
  	ostr << (*(*_AllNode)[i]) ;
}
#endif

void OB1Graph::save(std::string& FileName)
{
	ofstream file(FileName.c_str()) ;
	if (!(file.is_open()))
		return ;

  std::string temp = "<html><body BGCOLOR='663366'> <center><h1>Controler's state</h1></center><br />";

  for (unsigned int i = 0; i < (unsigned int)numVertices(); i++)
    (* _AllNode)[i]->htmlPrint(temp) ;

  temp += "<center>number of node : " ;
  char *ta = new char[16] ;
  itoa(numVertices(), ta, 10) ;
  temp.append(ta);
  delete[] ta ;
  temp += "</center></body></html>" ;
  file << temp ;
  file.close() ;
}



/*
bool tri_other(OB1NOther* un, OB1NOther* deux)
{
  if (un->SortingId() < deux->SortingId())
    return true;
  return false;
}  */
