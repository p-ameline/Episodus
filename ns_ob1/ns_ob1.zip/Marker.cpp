/*
** Copyright Nautilus, (10/9/2004)
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/

#include <iostream>
#include "ns_ob1\Marker.h"  



/* Return an int  */
int MarkerObject::intValue()const throw(std::string)
{
   return 0;
}


/* return an string */
std::string MarkerObject::stringValue() const throw (std::string)
{
  const MarkerString* p = dynamic_cast<const MarkerString* >(this);
  if (p == NULL)
    throw std::string("bad cast");
  else
    return (p->getValue());
}


/* Print teh information in a MarkerString Class */
void  MarkerString::print(std::ostream& ostr) const
{
  ostr << "MarkerString : " << _value <<std::endl;
}

/* Print the information present in MarkerInteger */
void  MarkerInteger::print(std::ostream& ostr) const
{
  ostr << "MarkerInteger: " << _value <<std::endl;
}

void MarkerInteger::htmlPrint(std::string& input)
{
  char *taille = new char[16];
  itoa(_value, taille, 10);
  input += "{<b>Marker (int) :</b>";
  input.append(taille);
  delete(taille);
  input += "}\n";
}

void MarkerString::htmlPrint(std::string& input)
{
  input += "{<b>Marker (string) :</b>" + _value;
  input += "} \n";
}

void Valeur::htmlPrint(std::string& input)
{
  input += "[KEY : " + key ;
  data->htmlPrint(input);
  input += "] <br /> \n";
}

/* Put a value in MarkerObject */
void Valeur::putValue(MarkerObject* temp)
{
  const MarkerString* p =  dynamic_cast<MarkerString *>(data);
  const MarkerString* p2 =  dynamic_cast<MarkerString *>(temp);
  if (data != NULL)
    delete(data);
  if (p != NULL)
  {
    if (p2 != NULL)
      data = temp;
  }
  else
    if (p2 == NULL)
      data =  temp;
  delete(p);
  delete(p2);
}



std::ostream&	operator<< (std::ostream& ostr, const MarkerObject& m)
{
  m.print(ostr);
  return (ostr);
}


