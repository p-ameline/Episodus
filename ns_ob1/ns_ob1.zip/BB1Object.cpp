/*
** Copyright Nautilus, (10/9/2004)
** fabrice.le_perru@nautilus-info.com
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/

#ifdef __GNUC__
#pragma implementation
#endif

#include <assert.h>                 // for BB1Object::ProcessLinkDel(...)
#include <iostream.h>               // for operator<<(...)

#ifndef _OWLDLL

#include "BB1Object.h"
#include "BB1Class.h"
#include "BB1KB.h"
#include "BB1Link.h"         // for BB1Object::AddLink(...)
#include "BB1Exception.h"    // add fab
#include "AttValPair.h"
#include "BB1types.h"
#ifndef __TCONTROLER__
#include "BB1Event.h"
#include "BB1Focus.h"
#endif
#include "BB1KS.h"
#ifndef __TCONTROLER__
#include "BB1KSAR.h"
#endif
#include "BB1Message.h"
#ifndef __TCONTROLER__
#include "BB1Strategy.h"
#endif

#else

#include "ns_ob1\BB1Object.h"
#include "ns_ob1\BB1Class.h"
#include "ns_ob1\BB1KB.h"
#include "ns_ob1\BB1Link.h"         // for BB1Object::AddLink(...)
#include "ns_ob1\BB1Exception.h"    // add fab
#include "ns_ob1\AttValPair.h"
#include "ns_ob1\BB1types.h"
#include "ns_ob1\BB1Event.h"
#include "ns_ob1\BB1KS.h"
#include "ns_ob1\BB1Message.h"

#endif

NSPatPathoArray* getPatPatho2(BB1Object* temp, const std::string& pathpathoname)
{
	if (NULL == temp)
  	return NULLPATHO ;
try
{
	// Old code
	// return (temp->Value(pathpathoname, NULLPATHO)) ;

  BB1Object* pAnswer = NULL ;

	// Is temp an answer?

  string sKbName = temp->KB().Name() ;
  if (sKbName == string("InformationKB"))
  	pAnswer = temp ;
  else
  {
  	TypedVal* pDispinf = temp->Attributes("explication") ;
  	if (pDispinf == NULL)
  		return NULLPATHO ;

		pAnswer = temp->BB().searchInKB(*pDispinf, std::string("InformationKB")) ;
  }

	if (NULL != pAnswer)
		return pAnswer->Value(pathpathoname, NULLPATHO) ;

	return NULLPATHO ;
}
catch (...)
{
	return NULLPATHO ;
}
}

// -----------------------------------------------------------------------------
// Create a BB1 object with the given name in the given kb with the given
// attributes and links. It is assumed name, kb, attributes, and links have
// already been checked for validity. Creation of the event is handled elsewhere.
// -----------------------------------------------------------------------------

BB1Object::BB1Object(const string& oname, AttValPair& dispatch, BB1KB& kb, BB1Class *c)
          :name(oname),
           knowledgeBase(kb),
           cycleCreated(kb.ThisCycle())
{
  attributes = new AVPSet() ;
  links		   = new LinkSet() ;
  attributes->push_back(new AttValPair(dispatch)) ;
  // Insert the object into its knowledge base
  knowledgeBase.InsertObject(this) ;

	// Specially handle the Exemplifies link to the class
  if (c)
		Instantiate(*c) ;

	DebugObjectCPT++ ;
}

BB1Object::BB1Object(const BB1Object& src)
	: name(src.name),
		knowledgeBase(src.knowledgeBase),
		cycleCreated(src.cycleCreated)
{
	attributes	= new AVPSet(*(src.attributes)) ;
	strategyP		= src.strategyP ;
	links				= new LinkSet(*(src.links)) ;

	DebugObjectCPT++ ;
}

BB1Object&
BB1Object::operator=(BB1Object& src)
{
	if (this == &src)
		return *this ;

/*
	name					= src.name ;
	knowledgeBase	= src.knowledgeBase ;
	cycleCreated	= src.CycleCreated() ;
*/

	if (attributes)
		delete attributes ;
  if (src.attributes)
		attributes = new AVPSet(*(src.attributes)) ;
  else
  	attributes = NULL ;

	strategyP		= src.strategyP ;

  if (links)
  	delete links ;
  if (src.links)
		links = new LinkSet(*(src.links)) ;
  else
  	links = NULL ;

  return (*this) ;
}

// -----------------------------------------------------------------------------
// Deallocate the object's attributes and its links
// -----------------------------------------------------------------------------

BB1Object::~BB1Object()
{
//	DeleteAllAttributes() ;
 //	DeleteAllLinks() ;

	if (attributes)
		delete attributes ;
	if (links)
		delete links ;

	DebugObjectCPT-- ;
}

BB1BB&
BB1Object::BB()
{
  return (KB().BB()) ;
}

// -----------------------------------------------------------------------------
// Send to the output stream a textual representation of the object
// -----------------------------------------------------------------------------

std::ostream& operator <<(std::ostream& os, const BB1Object& obj)
{
  os << obj.KB().Name() << ":" << obj.Name() << "[" << obj.CycleCreated() << "] {\n" ;
  os << "Attributes(\n" ;

  if (!obj.attributes->empty())
    for (AVPCIter a = obj.attributes->begin() ; a != obj.attributes->end() ; a++)
      os << *a ;

  os << ")\n";
  os << "Links(\n";

  if (!obj.links->empty())
    for (LinkCIter l = obj.links->begin() ; l != obj.links->end() ; l++)
      os << *l ;

  os << ")\n" ;
	os << "}\n" ;

  return (os) ;
}

// -----------------------------------------------------------------------------
// Add a link and its backward link.  All validity testing is assumed to have
// been done.
// -----------------------------------------------------------------------------

Errcode BB1Object::AddLink(	const string&	forwardLinkName,
														const string&	inverseLinkName,
			   										BB1Object&		toObject)
{
  try
  {
    int ReflexiveP = (this == &toObject) ;
    Cycle cycle = KB().ThisCycle() ;

    // add the forward link
    // Memory freed in BB1Object::DeleteAllLinks() and BB1Object::ProcessLinks()
    BB1Link *flp = new BB1Link(forwardLinkName, toObject, cycle, ReflexiveP) ;
    if (flp)
    {
      links->push_back(flp) ;

      // add backward link, even if forwardLinkName == newOppLinkName or this = toObject
      // Memory freed in BB1Object::DeleteAllLinks() and BB1Object::ProcessLinks()
      BB1Link *ilp = new BB1Link(inverseLinkName, *this, cycle, ReflexiveP) ;
      if (ilp)
      {
				toObject.links->push_back(ilp) ;
				return (SUCCESS) ;
      }
      else
			{
				// throw cf;
				ConstructFailure cf(BB(), "BB1Object::AddLink(...)", "BB1Link") ;
				return (FAILURE) ;
			}
		}
		else
		{
			// throw cf;
			ConstructFailure cf(BB(), "BB1Object::AddLink(...)", "BB1Link") ;
			return (FAILURE) ;
    }
  } // end try
  catch (ConstructFailure& cf)
    { } // constructor aborts

  return (FAILURE) ;
}

// -----------------------------------------------------------------------------
// Return a reference to the object's blackboard. Not defined in header because
// of call to BB1KB::BB(void)
// -----------------------------------------------------------------------------
// moving in BB1Object.h
/*
BB1BB& BB1Object::BB() const
{

#ifdef _DEBUG_
	cout << "-- DEBUG:: BB1Object::BB() const\n\n" ;
#endif

	return (KB().BB()) ;
};
*/


// -----------------------------------------------------------------------------
// Make the object attribute-free
// -----------------------------------------------------------------------------

Errcode BB1Object::DeleteAllAttributes()
{
  ClearSetOfAVP(attributes) ;
  return (SUCCESS) ;
}


// -----------------------------------------------------------------------------
// Make the object link-free. Be careful to take care of the inverse links too.
// -----------------------------------------------------------------------------

Errcode BB1Object::DeleteAllLinks()
{
  try
  {
    if ((LongName() == "Class.Class"))
    {
      // The only object without a class
      // Delete its links by way of its class instances
      return (SUCCESS) ;
    }
    const BB1Class * const c = Class() ;
    if (c)
    {
      // Delete all dynamic BB1Link instances -- Exemplifies link last
      BB1Link *elink = Linkptr(0) ;
      if (links && !links->empty())
                for (LinkIter fl = links->begin() ; fl != links->end() ; )
                {
                        BB1Link *flptr = *fl ;
                        if (flptr->Name() == "Exemplifies")
                        {
                        elink = flptr ; // There's at most one
                        fl++ ;
                }
					// For the time being, don't delete reflexive links: let there be a memory leak
      else
        	if (flptr->ReflexiveP() /* && !flptr->HandledP() */)
                {
                        fl++ ;
/*
              // Don't delete the reflexive link the first time it's seen, since
              // its inverse (in the same list) would also be deleted, which
              // would cause trouble when we got to it. Just mark the inverse
              // link, so that when the latter is seen, both can be safely
              // deleted

							const BB1String &bLinkName = flptr->OppositeLinkName(*c) ; // inverse link name
							if (bLinkName != "")
							{
								// it better exist!
								BB1Link *blptr = flptr->ToObject().GetLocalLink(bLinkName, *this) ;
								if (blptr)
								{
									// it better exist!
									blptr->MarkAsHandled() ;     // mark it
								}
							}
*/
                }
                else{
                        DeleteLink(flptr, *c) ;
                         delete (*fl) ;
                        links->erase(fl) ;
                }
        }
      if (elink)
      {
      	DeleteLink(elink, *c) ;
        delete (elink) ;
      }
      // Empty the link set
      links->clear() ;
      return (SUCCESS) ;
    }
    else
    {
      ObjectHasNoClass ohnc(BB(), "BB1Object::DeleteAllLinks()", Name()) ;
      return (FAILURE) ; // throw ohnc;
    }
  } // end try
  catch (ObjectHasNoClass& ohnc)
    { return (FAILURE) ; }

 // return (FAILURE) ;
}


// -----------------------------------------------------------------------------
// Delete the link pointed to by flptr and its backward link. c is the from
// object's class object
// -----------------------------------------------------------------------------

void    BB1Object::DeleteLink(BB1Link *flptr, const BB1Class& c)
{
  try
  {
    BB1Object& ToObject = flptr->ToObject() ;
    const string& bLinkName = flptr->OppositeLinkName(c) ;
    if (bLinkName != "")
    {
      BB1Link *blptr = ToObject.GetLocalLink(bLinkName, *this) ;
      // If there is a forward link, there must be a backward link
      if (blptr)
      {
				// Delete the backward link
				if (this == &ToObject)
					{ } // If the link is reflexive, it will be taken care of
				else
				{
					if (ToObject.links && !ToObject.links->empty())
						for (LinkIter l = ToObject.links->begin() ; l != ToObject.links->end() ; )
						{
							if ((*l == blptr) && (NULL != *l))
							{
								delete (*l) ;
								ToObject.links->erase(l) ;
							}
							else
								l++ ;
						}
				}
				// Delete the forward link
//			delete flptr ; // clear below takes the place of del here
      }
      else
      {
				// throw lnf ;
				LinkNotFound lnf(BB(), "BB1Object::DeleteLink(...)", bLinkName) ;
			}
    }
    else
    {
      // throw blnnf ;
      BackwardLinkNameNotFound blnnf(BB(), "BB1Object::DeleteLink(...)", flptr->Name()) ;
		}
  } // end try
  catch (LinkNotFound& lnf)
    { } // bad, but probably not fatal
  catch (BackwardLinkNameNotFound& blnnf)
    { } // bad, but probably not fatal
}


// -----------------------------------------------------------------------------
// Does the recipient have an "Exemplifies" link to a class which has a sequence
// of "IsA" links to an object whose name is c?
// -----------------------------------------------------------------------------

bool BB1Object::ExemplifiesP(const string& c) const
{
	BB1Object *parentClass = Object("Exemplifies") ;
	return (parentClass ? parentClass->IsAP(c) : false) ;
}

// -----------------------------------------------------------------------------
// Auxiliary to BB1Object::GetLocalAttribute(...). Two attribute-value pairs
// match if they have the same (1) AttributeName() and
// (2) AttributeValue().Discriminant(). Ignore the recipient (this). A method to
// take advantage of BB1Object's friendship with respect to
// TypedVal::Discriminant().
// -----------------------------------------------------------------------------

bool BB1Object::AVPMatch(const AttValPair& avp1, const AttValPair& avp2) const
{
  return ((avp1.AttributeName() == avp2.AttributeName()) && // name match
	  			(avp1.AttributeValue().Discriminant() == avp2.AttributeValue().Discriminant())) ;  // type match
}


// -----------------------------------------------------------------------------
// If the attribute is bound locally, return a pointer to it; otherwise, if the
// object's class allows the attribute, return a pointer to the class's
// attribute; otherwise, return a null pointer.
// -----------------------------------------------------------------------------

AttValPair*
BB1Object::GetInheritedAttribute(const AttValPair& avp) const
{
  try
  {
    AttValPair *lavp = GetLocalAttribute(avp) ;
    if (lavp)
    {
      // the attribute is stored on the object
      return (lavp) ;
    }
    else
    {
      // the attribute may be stored with the object's class
      const BB1Class *c = Class() ;
      if (c)
			{
				return (c->GetClassAttribute(avp)) ;
			}
      else
      {
				// ObjectHasNoClass ohnc(BB(), "BB1Object::GetInheritedAttribute(...)", Name()) ;
				return ((AttValPair *) NULL) ; // throw ohnc;
      }
    }
  } // end try
  catch (ObjectHasNoClass& ohnc)
    { return ((AttValPair *) NULL) ; }
}


// -----------------------------------------------------------------------------
// If the attribute is bound locally, return a pointer to it; otherwise, return
// a null pointer.
// -----------------------------------------------------------------------------

AttValPair*
BB1Object::GetLocalAttribute(const AttValPair& avp) const
{
//  static int i = 0; // count invocations
/*
	if (KB().Name() != "Class")
	{
		cout << i++ << " Object = " << LongName() << "\n" ;
	}
*/

	if ((NULL != attributes) && !attributes->empty())
		for (AVPCIter a = attributes->begin() ; a != attributes->end() ; a++)
		{
			/*
			if (KB().Name() != "Class")
			{
				cout << " Pix a = " << a << "\n";
				cout << " Att = "   << attributes(a)->AttributeName() << "\n";
			}
			*/
			AttValPair *cavp = *a ;
			if (AVPMatch(avp, *cavp))
				return *a ;
		}

	return ((AttValPair *) NULL) ;
}


// -----------------------------------------------------------------------------
// If there is a local link, return a pointer to it; otherwise return a null
// pointer
// -----------------------------------------------------------------------------

BB1Link*
BB1Object::GetLocalLink(const string& linkName, const BB1Object& ToObject) const
{
	if (links && !links->empty())
		for (LinkCIter l = links->begin() ; l != links->end() ; l++)
		{
      BB1Link *lp = *l ;
      if ((lp->Name() == linkName) && (lp->ToObject().Name() == ToObject.Name()))
				return (*l) ;
    }
  return (Linkptr(NULL));
}

// -----------------------------------------------------------------------------
// Create Exemplifies/ExemplifiedBy links with class c.
// -----------------------------------------------------------------------------

Errcode
BB1Object::Instantiate(BB1Class& c)
{
  return (AddLink("Exemplifies", "ExemplifiedBy", c)) ;
}

// -----------------------------------------------------------------------------
// Return a pointer to an arbitrary object that is linked by a link name
// -----------------------------------------------------------------------------

BB1Object*
BB1Object::Object(const string& oname) const
{
	ObjectList *s = new ObjectList() ;
	Objects(oname, s) ;

	if (s && !s->empty())
	{
		BB1Object *i = *(s->begin()) ;
		delete s ;
		if (i != NULL)
			return (i) ;
		else
			return ((BB1Object *) NULL) ;
	}
	else
		return ((BB1Object *) NULL) ;
}

// -----------------------------------------------------------------------------
// Return the set of all objects that is linked by a link named name.
// -----------------------------------------------------------------------------

ObjectList*
BB1Object::Objects(const string& oname, ObjectList *retval) const
{
	retval->clear();

	if (links && !links->empty())
		for (LinkCIter l = links->begin() ; l != links->end() ; l++)
		{
			BB1Link	*lp = *l ;
			if ((NULL != retval) && (lp->Name() == oname))
				retval->push_back(&(lp->ToObject())) ;
/*
			{
				BB1Object *o = &(lp->ToObject()) ;

				const BB1Class *pClass = dynamic_cast<const BB1Class *>(o) ;
				if (pClass)
					retval->push_back(new BB1Class(*pClass)) ;

				const BB1Event *pEvent = dynamic_cast<const BB1Event *>(o) ;
				if (pEvent)
					retval->push_back(new BB1Event(*pEvent)) ;

				const BB1Focus *pFocus = dynamic_cast<const BB1Focus *>(o) ;
				if (pFocus)
					retval->push_back(new BB1Focus(*pFocus)) ;

				const BB1KS	*pKS = dynamic_cast<const BB1KS *>(o) ;
				if (pKS)
					retval->push_back(new BB1KS(*pKS)) ;

				const BB1KSAR *pKSAR = dynamic_cast<const BB1KSAR *>(o) ;
				if (pKSAR)
					retval->push_back(new BB1KSAR(*pKSAR)) ;

				const BB1Message *pMessage = dynamic_cast<const BB1Message *>(o) ;
				if (pMessage)
					retval->push_back(new BB1Message(*pMessage)) ;

				// derivate from BB1Decision than derive from BB1Object
				const BB1Strategy *pStrategy = dynamic_cast<const BB1Strategy *>(o) ;
				if (pStrategy)
					retval->push_back(new BB1Strategy(*pStrategy)) ;
			}
*/
		}
	return (retval) ;
}

// -----------------------------------------------------------------------------
// Return the object's "long" name -- a BB1String of the form <KB name>.<Object name> --
// primarily for output purposes.
// -----------------------------------------------------------------------------

inline
string
BB1Object::LongName() const
{
  return (KB().Name() + "." + Name()) ;
}

// -----------------------------------------------------------------------------
// Assign the attributes as specified in the attribute specification. This is
// called whenever a BB1Object (BB1AppInst, BB1Class, BB1Decision, BB1KS,
// BB1KSAR, or BB1Message) is instantiated or modified.
// -----------------------------------------------------------------------------

Errcode
BB1Object::ProcessAttributes(const AVPSet *attSpec, const AVPSet *delAttSpec)
{
  if (attSpec && !attSpec->empty())
    for (AVPCIter n = attSpec->begin() ; n != attSpec->end() ; n++)
    {
      // each attribute specifier
try
{
			AttValPair *newAtt = *n ;              // cache the AVPptr
      if (ValidAttributeP(*newAtt))
      {
      	// does class allow it?
        AttValPair *a = GetLocalAttribute(*newAtt) ; // retrieve from object
        if (a)
        	a->setValue(*newAtt) ;            // modify it if present
        else
        {
        	// add it if absent
          /*
          Memory freed in BB1Object::DeleteAllAttributes()
          and BB1Object::ProcessAttributes()
          */
					// AttValPair *newAVP = new AttValPair(newAtt->AttributeName(), newAtt->AttributeValue()) ;
					AttValPair *newAVP = new AttValPair(*newAtt) ;
          if (newAVP)
          	attributes->push_back(newAVP) ;
          else
          {
          	ConstructFailure cf(BB(), "BB1Object::ProcessAttributes(...)", "AttValPair") ;
            return (FAILURE) ; // throw cf ;
          }
        }
      }
      else
      {
      	UndeclaredAttribute ex(BB(), "", Name(), newAtt->AttributeName()) ;
        // return (INVALIDATTRIBUTE) ; // throw ex ; Modif by PA: discard the bad attribute, but keep on processing 
      }
} // end try
catch (UndeclaredAttribute& ex)
{ return(INVALIDATTRIBUTE) ; }
catch (ConstructFailure& cf)
{ } // constructor aborts
		} // end for

	if (delAttSpec && !delAttSpec->empty())
		for (AVPCIter d = delAttSpec->begin() ; d != delAttSpec->end() ; d++)
		{
			AttValPair *delAtt = *d ;

			const string& delAttName = delAtt->AttributeName() ;
			AttValPair *aptr = GetLocalAttribute(*delAtt) ;
			if (aptr)
			{
				// Delete from the object, not delAttSpec
				if (attributes && !attributes->empty())
					for (AVPIter i = attributes->begin() ; i != attributes->end() ; )
					{
						if (*i == aptr)
						{
							delete (*i) ;
							attributes->erase(i) ;
						}
						else
							i++ ;
					}
				delete aptr;
      }
      else
      {
				// It is OK to specify for deletion an attribute that doesn't exist
      }
		} // end for
	return (SUCCESS) ;
}

// -----------------------------------------------------------------------------
// Add one link.
// -----------------------------------------------------------------------------

Errcode
BB1Object::ProcessLinkAdd(const BB1Link& newLink)
{
	const BB1Class *const c = Class() ;
	try
	{
		if (c)
		{
			const string &newLinkName    = newLink.Name() ;
			const string &newOppLinkName = newLink.OppositeLinkName(*c) ;

			if (newOppLinkName != NULLSTRING)
			{
				// relation declared
				BB1Object& toObject = newLink.ToObject() ;
				if (ValidLinkP(newLinkName, toObject))
				{
					// type OK
					if (!(HasLinkP(newLinkName, toObject)))
					{
						// no link exists yet
						return (AddLink(newLinkName, newOppLinkName, toObject)) ;
					}
					else
						{ return (SUCCESS) ; } // link already exists
				}
				else
				{
					UndeclaredLink ulex(BB(), "", Name(), newLinkName) ; // don't know method name yet
					return (INVALIDLINK) ; // throw ulex ;
				}
			}
			else
			{
				// relation undeclared
				LinkDoesNotExist ldne(BB(), "", newLinkName) ; // don't know method yet
				return (INVALIDLINK) ; // throw ldne ;
			}
		}
		else
		{
			ObjectHasNoClass ohnc(BB(), "BB1Object::ProcessLinkAdd(...)", Name()) ;
			return (FAILURE) ; // throw ohnc ;
		}
	} // end try
	catch (UndeclaredLink& ulex)
		{ return (INVALIDLINK) ; } // type not OK
	catch (LinkDoesNotExist& ldne)
		{ return (INVALIDLINK) ; }
	catch (ObjectHasNoClass& ohnc)
		{ } // constructor aborts
	return (FAILURE) ;
}

// -----------------------------------------------------------------------------
// Delete one link.
// -----------------------------------------------------------------------------

Errcode
BB1Object::ProcessLinkDel(const BB1Link& delLink)
{
	try
	{
		const BB1Class * const c = Class() ;
		if (c)
		{
			const string& fLinkName = delLink.Name() ;			// forward link name
			const string& bLinkName = delLink.OppositeLinkName(*c) ;		// reverse link name
			BB1Object& ToObject = delLink.ToObject() ;			// to object
			BB1Link *flptr = GetLocalLink(fLinkName, ToObject) ;		// ptr to forward link
			if (flptr)
			{
				BB1Link *blptr = ToObject.GetLocalLink(bLinkName, *this) ;	// ptr to reverse link
				if (blptr)
				{
					if (links && !links->empty())
						for (LinkIter l = links->begin() ; l != links->end() ; )
						{
							if (*l == flptr)
							{
								delete (*l) ;
								links->erase(l) ;
							}
							else
								l++ ;
						}
					delete flptr;							// delete forward link

					if (ToObject.links && !ToObject.links->empty())
						for (LinkIter l = ToObject.links->begin() ; l != ToObject.links->end() ; )
						{
							if (*l == blptr)
							{
								delete (*l) ;
								ToObject.links->erase(l) ;
							}
							else
								l++ ;
						}
					delete blptr ;						// delete reverse link

					return (SUCCESS) ;
				}
				else
				{
					BackwardLinkNotFound blnf(BB(), "BB1Object::ProcessLinksDel(...)", flptr->Name()) ;
					return (FAILURE) ; // throw blnf ;
				}
			}
			else
			{
				return (SUCCESS) ;						// It is OK to specify for deletion a link that doesn't exist
			}
			//return (SUCCESS) ;
		}
		else
		{
			ObjectHasNoClass ohnc(BB(), "BB1Object::ProcessLinkDel(...)", Name()) ;
			return (FAILURE) ; // throw ohnc ;
		}
	} // end try
	catch (ObjectHasNoClass& ohnc)
		{ } // constructor aborts
	catch (BackwardLinkNotFound& blnf)
		{ return (FAILURE) ; } // bad but probably not fatal
	return (FAILURE) ;
}

// -----------------------------------------------------------------------------
// Process the links as specified in the link specification. An error in a link
// specification will not prevent subsequent links from being processed. Thus,
// the values returned by ProcessLinkAdd and ProcessLinkDel are ignored, and the
// operation is always successful.
// -----------------------------------------------------------------------------

Errcode
BB1Object::ProcessLinksNN(const LinkSet *linkSpec, const LinkSet *delLinkSpec)
{
try
{
	if (linkSpec && !linkSpec->empty())
		for (LinkCIter l = linkSpec->begin() ; l != linkSpec->end() ; l++)
    {
    	if (ProcessLinkAdd(**l) != SUCCESS)
      {
      	// throw something
      }
    }

	if (delLinkSpec && !delLinkSpec->empty())
		for (LinkCIter l = delLinkSpec->begin() ; l != delLinkSpec->end() ; l++)
    {
    	if (ProcessLinkDel(**l) != SUCCESS)
      {
      	// throw something
      }
    }
  return (SUCCESS) ;
} // end try
catch (...)
{
	return (FAILURE);// rajouter par moi pas sur de l'incidence
} // every try must have a catch somewhere
}

void
BB1Object::SaveAttributes(ofstream& KBstream)
{

	KBstream << " (" ;
	const SetOfAVP *a = Attributes() ;

	if (a && !a->empty())
		for (AVPCIter pa = a->begin() ; pa != a->end() ; pa++)
			KBstream << "(" << (*pa)->AttributeName() << " " << (*pa)->AttributeValue() << ")" ;
	KBstream << " )\n" ;
}

void
BB1Object::SaveLinks(ofstream& KBstream)
{
	const SetOfBB1Link *l = links ;
	KBstream << " (" ;

	if (l && !l->empty())
		for (LinkCIter pl = l->begin() ; pl != l->end() ; pl++)
			KBstream << "(" << (*pl)->Name() << " " << (*pl)->ToObject().LongName() << ")" ;

	KBstream << " )\n" ;
}

// -----------------------------------------------------------------------------
// Is the object allowed to have the attribute? Overridden by BB1Class, BB1KSAR,
// and BB1Message.
// -----------------------------------------------------------------------------

bool
BB1Object::ValidAttributeP(const AttValPair& avp) const
{
	try
	{
		const BB1Class * const c = Class() ;
		if (c)
			return (c->AllowsAttributeP(avp)) ;
		else
		{
			// throw ohnc ;
			ObjectHasNoClass ohnc(BB(), "BB1Object::ValidAttributeP(...)", Name()) ;
			return (false) ;
		}
	} // end try
	catch (ObjectHasNoClass& ohnc)
		{ return (false) ; }
     //	return (false) ;
}

// -----------------------------------------------------------------------------
// Is the object allowed to have the link? Overridden by BB1Class.
// -----------------------------------------------------------------------------

bool
BB1Object::ValidLinkP(const string& linkName, const BB1Object& toObject) const
{
	try
	{
		const BB1Class *const fromClass = Class() ;
		if (fromClass)
		    {
        const BB1Class *const toClass   = toObject.Class() ;
        if (toClass)
				    {
              return (fromClass->AllowsLinkP(linkName, *toClass)) ;
            }
			  else
			      {
				      ObjectHasNoClass ohnc(BB(), "BB1Object::ValidLinkP(...)", toObject.Name()) ;
				    return (false) ; // throw ohnc ;
			      }
		    }
		else
		    {
			    ObjectHasNoClass ohnc(BB(), "BB1Object::ValidLinkP(...)", Name()) ;
			    return (false) ; // throw ohnc ;
	  	  }
	    } // end try
	  catch (ObjectHasNoClass& ohnc)
		  { return (false) ; }
	  //return (false) ;
}


// -----------------------------------------------------------------------------
// Return the value of the attribute for the object. If the attribute is
// unbound, it is an exception. The method is overloaded; there is one method
// for each possible data type of the value.
// -----------------------------------------------------------------------------

bool
BB1Object::Value(const string& attribute, bool& b) const
{
	try
	{
		AttValPair avp(attribute, b) ;
		AVPptr a = GetInheritedAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getBool()) ;
		else
		{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
			return (char(0)) ; // throw ola ;
		}
	} // end try
	catch (ObjectLacksAttribute& ola)
		{ return (char(0)) ; }
	//return (char(0)) ;
}

#ifdef __OB1__UNOPTIM__
char
BB1Object::Value(const string& attribute, char& c) const
{
	try
	{
		AttValPair avp(attribute, c) ;
		AVPptr a = GetInheritedAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getChar()) ;
		else
		{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
			return (char(0)) ; // throw ola ;
		}
	} // end try
	catch (ObjectLacksAttribute& ola)
		{ return (char(0)) ; }
	//return (char(0)) ;
}
#endif


double
BB1Object::Value(const string& attribute, double& d) const
{
	try
	{
		AttValPair avp(attribute, d) ;
		AVPptr a = GetInheritedAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getDouble()) ;
		else
		{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
			return (double(0)) ; // throw ola ;
		}
	} // end try
	catch (ObjectLacksAttribute& ola)
		{ return (double(0)) ; }
      //	return (double(0)) ;
}

#ifdef __OB1__UNOPTIM__
float
BB1Object::Value(const string& attribute, float& f) const
{
	try
	{
		AttValPair avp(attribute, f) ;
		AVPptr a = GetInheritedAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getFloat()) ;
		else
		{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
			return (float(0)) ; // throw ola ;
		}
	} // end try
	catch (ObjectLacksAttribute& ola)
		{ return (float(0)) ; }
      //	return (float(0)) ;
}


int
BB1Object::Value(const string& attribute, int& i) const
{
	try
	{
		AttValPair avp(attribute, i) ;
		AVPptr a = GetInheritedAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getInt()) ;
		else
		{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
			return (int(0)) ; // throw ola ;
		}
	} // end try
	catch (ObjectLacksAttribute& ola)
		{ return (int(0)) ; }
       //	return (int(0)) ;
}
#endif


long
BB1Object::Value(const string& attribute, long& l) const
{
	try
	{
		AttValPair avp(attribute, l) ;
		AVPptr a = GetInheritedAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getLong()) ;
		else
		{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
			return (long(0)) ; // throw ola ;
		}
	} // end try
	catch (ObjectLacksAttribute& ola)
		{ return (long(0)) ; }
      //	return (long(0)) ;
}

#ifdef __OB1__UNOPTIM__
short
BB1Object::Value(const string& attribute, short& s) const
{
  try
  {
    AttValPair avp(attribute, s) ;
    AVPptr a = GetInheritedAttribute(avp) ;
    if (a)
      return (a->AttributeValue().getShort()) ;
    else
    {
//      ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
      return (short(0)) ; // throw ola ;
    }
  } // end try
  catch (ObjectLacksAttribute& ola)
    { return (short(0)) ; }
 // return (short(0)) ;
}
#endif


const string
BB1Object::Value(const string& attribute, const string& s) const
{
	try
	{
		AttValPair avp(attribute, s) ;
		AVPptr a = GetInheritedAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getString()) ;
		else
		{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
			return (NULLSTRING) ; // throw ola ;
		}
	} // end try
	catch (ObjectLacksAttribute& ola)
		{ return (NULLSTRING) ; }
    //	return (NULLSTRING) ;
}

#ifdef __OB1__UNOPTIM__
unsigned char
BB1Object::Value(const string& attribute, unsigned char& uc) const
{
  try
  {
    AttValPair avp(attribute, uc) ;
    AVPptr a = GetInheritedAttribute(avp) ;
    if (a)
        return (a->AttributeValue().getUChar()) ;
    else
    {
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
        return ((unsigned char) 0) ; // throw ola ;
        }
        } // end try
  catch (ObjectLacksAttribute& ola)
    { return ((unsigned char) 0) ; }
 // return ((unsigned char) 0) ;
}
#endif

#ifdef __OB1__UNOPTIM__
unsigned int
BB1Object::Value(const string& attribute, unsigned int& ui) const
{
  try
  {
    AttValPair avp(attribute, ui) ;
    AVPptr a = GetInheritedAttribute(avp) ;
    if (a)
      return (a->AttributeValue().getUInt()) ;
    else
    {
//      ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
      return ((unsigned int) 0) ; // throw ola ;
    }
  } // end try
  catch (ObjectLacksAttribute& ola)
    { return ((unsigned int) 0) ; }
 // return ((unsigned int) 0) ;
}
#endif

#ifdef __OB1__UNOPTIM__
unsigned long
BB1Object::Value(const string& attribute, unsigned long& ul) const
{
	try
	{
		AttValPair avp(attribute, ul) ;
		AVPptr a = GetInheritedAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getULong()) ;
		else
		{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
			return ((unsigned long) 0) ; // throw ola ;
		}
  } // end try
  catch (ObjectLacksAttribute& ola)
    { return ((unsigned long) 0) ; }
  //return ((unsigned long) 0) ;
}
#endif

#ifdef __OB1__UNOPTIM__
unsigned short
BB1Object::Value(const string& attribute, unsigned short& us) const
{
	try
	{
		AttValPair avp(attribute, us) ;
		AVPptr a = GetInheritedAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getUShort()) ;
		else
		{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
			return ((unsigned short) 0) ; // throw ola ;
		}
	} // end try
	catch (ObjectLacksAttribute& ola)
		{ return ((unsigned short) 0) ; }
       //	return ((unsigned short) 0) ;
}
#endif

   /*
const TypedVal&   BB1Object::Attributes(const std::string&  attribut)
{
  if (attributes != NULL)
  {
    register unsigned int end =  attributes->size();
    for (register unsigned int i = 0; i < end; i++)
    {
      if ( (*attributes)[i] != NULL)
        {
          std::string temp =  (*attributes)[i]->AttributeName();
          if (temp == attribut)
            return (( (*attributes)[i]->AttributeValue()) );
        }
    }
  }
  TypedVal *typ = new TypedVal();
  return (*typ);
}    */

const Voidptr
BB1Object::Value(const string& attribute, Voidptr& p) const
{
  try
  {
    AttValPair avp(attribute, p) ;  
    AVPptr a = GetInheritedAttribute(avp) ;
    if (a)
       return (a->AttributeValue().getPtr()) ;
    else
	 	{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
	 		return ((void *) NULL) ; // throw ola ;
	 	}
	} // end try
	catch (ObjectLacksAttribute& ola)
		{ return ((void *) NULL) ; }
}

#ifdef __OB1__UNOPTIM__
PathsList*
BB1Object::Value(const string& attribute, PathsList *paths) const
{
	try
	{
		AttValPair avp(attribute, paths) ;
		AVPptr a = GetLocalAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getPaths()) ;
		else
		{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
			return ((PathsList *) NULL) ; // throw ola ;
		}
	} // end try
	catch (ObjectLacksAttribute& ola)
		{ return ((PathsList *) NULL) ; }

	//return ((PathsList *) NULL) ;
}
#endif

NautilusQuestion*
BB1Object::Value(const string& attribute, NautilusQuestion *paths) const
{
	try
	{
		AttValPair avp(attribute, paths) ;
		AVPptr a = GetLocalAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getNautQuest()) ;
		else
		{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
			return ((NautilusQuestion *) NULL) ; // throw ola ;
		}
	} // end try
	catch (ObjectLacksAttribute& ola)
		{ return ((NautilusQuestion *) NULL) ; }

	//return ((PathsList *) NULL) ;
}

AnswerStatus*
BB1Object::Value(const string& attribute, AnswerStatus *paths) const
{
	try
	{
		AttValPair avp(attribute, paths) ;
		AVPptr a = GetLocalAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getAnsStatus()) ;
		else
		{
//			ObjectLacksAttribute ola(BB(), "BB1Object::Value(...)", Name(), attribute) ;
			return ((AnswerStatus *) NULL) ; // throw ola ;
		}
	} // end try
	catch (ObjectLacksAttribute& ola)
		{ return ((AnswerStatus *) NULL) ; }

	//return ((PathsList *) NULL) ;
}

NSPatPathoArray*
BB1Object::Value(const string& attribute, NSPatPathoArray *patho) const
{
try
{
	AttValPair avp(attribute, patho) ;
	AVPptr a = GetLocalAttribute(avp) ;
	if (a)
		return (a->AttributeValue().getPatPatho()) ;
	else
		// L'attribut n'est pas trouv�
		// throw Exception(knowledgeBase.BB(), "BB1Object::Value", "Not Found", __FILE__, __LINE__);
		return NULLPATHO ;
} // end try
catch (ObjectLacksAttribute& ola)
{
	throw Exception(knowledgeBase.BB(), "BB1Object::Value", "Error", __FILE__, __LINE__);
}
}

BB1Object*
BB1Object::Value(const string& attribute, BB1Object *objet) const
{
	try
	{
		AttValPair	avp(attribute, objet) ;
		AVPptr a = GetLocalAttribute(avp) ;
		if (a)
			return (a->AttributeValue().getObj()) ;
		else
			return ((BB1Object *) NULL) ;
	}
	catch (ObjectLacksAttribute& ola)
		{ return ((BB1Object *) NULL) ; }
      //	return ((BB1Object *) NULL) ;
}

NautilusEvent*
BB1Object::Value(const string& attribute, NautilusEvent *pEvent) const
{
try
{
	AttValPair avp(attribute, pEvent) ;
	AVPptr a = GetLocalAttribute(avp) ;
	if (a)
		return (a->AttributeValue().getNautEvent()) ;
	else
		// L'attribut n'est pas trouv�
		// throw Exception(knowledgeBase.BB(), "BB1Object::Value", "Not Found", __FILE__, __LINE__);
		return NULLNAUTILUSEVENT ;
} // end try
catch (ObjectLacksAttribute& ola)
{
	throw Exception(knowledgeBase.BB(), "BB1Object::Value", "Error", __FILE__, __LINE__);
}
}

// -----------------------------------------------------------------------------
// Getting a question's path can be done through a question or a string pair
// this is the reason why we build this function
// -----------------------------------------------------------------------------
std::string
BB1Object::getQuestionPath()
{
	NautilusQuestion* pNsQuestion = NULL ;

  pNsQuestion = Value("question", NULLLNAUTQUEST) ;

  if (pNsQuestion != NULL)
		return pNsQuestion->Question() ;

	return Value("question", string("")) ;
}

AnswerStatus::ANSWERSTATUS
BB1Object::getAnswerStatus()
{
	AnswerStatus* pAnswerStatus = NULL ;

  pAnswerStatus = Value("answerStatus", NULLLANSWERSTATUS) ;

  if (pAnswerStatus == NULL)
  	return AnswerStatus::astatusUnknown ;

	return pAnswerStatus->Status() ;
}

AnswerStatus::ANSWERPROCESSINGSTAGE
BB1Object::getAnswerProcessStage()
{
	AnswerStatus* pAnswerStatus = Value("answerStatus", NULLLANSWERSTATUS) ;

  if (pAnswerStatus == NULL)
  	return AnswerStatus::apstageUnknown ;

	return pAnswerStatus->ProcessingStage() ;
}

void
BB1Object::setAnswerStatus(AnswerStatus::ANSWERSTATUS iStatus)
{
	AnswerStatus* pAnswerStatus = Value("answerStatus", NULLLANSWERSTATUS) ;

  if (pAnswerStatus != NULL)
  {
  	pAnswerStatus->setStatus(iStatus) ;
    return ;
  }

  AnswerStatus* pNewStatus = new AnswerStatus() ;
  pNewStatus->setStatus(iStatus) ;
  AttValPair *newAVP = new AttValPair("answerStatus", pNewStatus) ;
  if (newAVP)
  	attributes->push_back(newAVP) ;
}

void
BB1Object::setAnswerProcessStage(AnswerStatus::ANSWERPROCESSINGSTAGE iStage)
{
	AnswerStatus* pAnswerStatus = Value("answerStatus", NULLLANSWERSTATUS) ;

  if (pAnswerStatus != NULL)
  {
  	pAnswerStatus->setStage(iStage) ;
    return ;
  }

  AnswerStatus* pNewStatus = new AnswerStatus() ;
  pNewStatus->setStage(iStage) ;
  AttValPair *newAVP = new AttValPair("answerStatus", pNewStatus) ;
  if (newAVP)
  	attributes->push_back(newAVP) ;
}

bool
BB1Object::updatePatPatho(NSPatPathoArray* patho, string sAnswerDate, bool bExt)
{
	if (NULL == patho)
		return false ;

	AttValPair avp("node", patho) ;
	AVPptr a = GetLocalAttribute(avp) ;
	if (!a)
  	return false ;

	a->swapPatho(patho, bExt) ;

  AttValPair avpDate("node_date", sAnswerDate) ;
	AVPptr b = GetLocalAttribute(avpDate) ;
	if (!b)
	{
  	AttValPair *newAVP = new AttValPair("node_date", sAnswerDate) ;
		if (newAVP)
  		attributes->push_back(newAVP) ;
	}
  else
  {
  	TypedVal newTVal(sAnswerDate) ;
  	TypedVal* pVal = b->AttributeValuePtr() ;
    if (pVal)
    	*pVal = newTVal ;
  }

  return true ;
}

// -----------------------------------------------------------------------------
// Is this a subclass of the named class? Default; BB1Class overrides
// -----------------------------------------------------------------------------

bool
BB1Object::IsAP(const string& /* c */) const
{
  return (false) ;
}


// -----------------------------------------------------------------------------
// Does this object trigger KS UpdatePrescription? Default; BB1Strategy
// overrides
// -----------------------------------------------------------------------------

bool BB1Object::UpdatePrescriptionTCAux() const
{
  return (false) ;
}


// -----------------------------------------------------------------------------
// Does this object obviate KS UpdatePrescription? Default; BB1Strategy
// overrides
// -----------------------------------------------------------------------------

bool BB1Object::UpdatePrescriptionOCAux() const
{
  try
  {
    NotAStrategy nas(BB(), "UpdatePrescriptionOC(...)", Name()) ;
    return (true) ; // throw nas ;
  } // end try
  catch (NotAStrategy& nas)
    { return (true) ; }
  //return (true) ;
}


Errcode BB1Object::UpdatePrescriptionACAux()
{
  try
  {
    NotAStrategy nas(BB(), "UpdatePrescriptionAC(...)", Name()) ;
    return (FAILURE) ; // throw nas;
  } // end try
  catch (NotAStrategy& nas)
    { return (FAILURE) ; }
  //return (FAILURE) ;
}


// -----------------------------------------------------------------------------
// Does this object trigger KS TerminatePrescription? Default; BB1Decision
// overrides
// -----------------------------------------------------------------------------

bool BB1Object::TerminatePrescriptionTCAux() const
{
  return (false) ;
};


// -----------------------------------------------------------------------------
// Does this object satisfy the precondition of KS TerminatePrescription?
// Default; BB1Decision overrides
// -----------------------------------------------------------------------------

bool BB1Object::TerminatePrescriptionPCAux() const
{
  try
  {
    NotADecision nad(BB(), "TerminatePrescriptionPC(...)", Name()) ;
    return (false) ; // throw nad ;
  } // end try
  catch (NotADecision& nad)
    { return (false) ; }
  //return (false) ;
}


// -----------------------------------------------------------------------------
// Does this object obviate KS TerminatePrescription? Default; BB1Decision
// overrides
// -----------------------------------------------------------------------------

bool BB1Object::TerminatePrescriptionOCAux() const
{
  try
  {
    NotADecision nad(BB(), "TerminatePrescriptionOC(...)", Name()) ;
    return (true) ; // throw nad ;
  } // end try
  catch (NotADecision& nad)
    { return (true) ; }
 // return (true) ;
}


Errcode BB1Object::TerminatePrescriptionACAux()
{
  try
  {
    NotAStrategy nas(BB(), "TerminatePrescriptionAC(...)", Name()) ;
    return (FAILURE) ; // throw nas ;
  } // end try
  catch (NotAStrategy& nas)
    { return (FAILURE) ; }
  //return (FAILURE) ;
}


// -----------------------------------------------------------------------------
// Default; BB1Strategy overrides.
// -----------------------------------------------------------------------------

void
BB1Object::DeleteParentDecision(BB1Decision* /* decision */)
{
try
{
	NotAStrategy nas(BB(), "TerminatePrescriptionAC(...)", Name()) ;
  // throw nas ;
}
catch (NotAStrategy& nas)
{ }
}

