/*
** Copyright Nautilus, (10/9/2004)
** fabrice.le_perru@nautilus-info.com
** david.giocanti@nautilus-info.com

** Ce logiciel est un programme informatique servant � [rappeler les
** caract�ristiques techniques de votre logiciel].

** Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
** respectant les principes de diffusion des logiciels libres. Vous pouvez
** utiliser, modifier et/ou redistribuer ce programme sous les conditions
** de la licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA
** sur le site "http://www.cecill.info".

** En contrepartie de l'accessibilit� au code source et des droits de copie,
** de modification et de redistribution accord�s par cette licence, il n'est
** offert aux utilisateurs qu'une garantie limit�e.  Pour les m�mes raisons,
** seule une responsabilit� restreinte p�se sur l'auteur du programme,  le
** titulaire des droits patrimoniaux et les conc�dants successifs.

** A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
** associ�s au chargement,  � l'utilisation,  � la modification et/ou au
** d�veloppement et � la reproduction du logiciel par l'utilisateur �tant
** donn� sa sp�cificit� de logiciel libre, qui peut le rendre complexe �
** manipuler et qui le r�serve donc � des d�veloppeurs et des professionnels
** avertis poss�dant  des  connaissances  informatiques approfondies.  Les
** utilisateurs sont donc invit�s � charger  et  tester  l'ad�quation  du
** logiciel � leurs besoins dans des conditions permettant d'assurer la
** s�curit� de leurs syst�mes et ou de leurs donn�es et, plus g�n�ralement,
** � l'utiliser et l'exploiter dans les m�mes conditions de s�curit�.

** Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez
** pris connaissance de la licence CeCILL, et que vous en avez accept� les
** termes.
*/
#ifdef __GNUC__
#pragma implementation
#endif

#include <iostream.h>               // for operator<<(...)

#ifndef _OWLDLL
#include "AttValPair.h"
#include "BB1types.h"
#include "BB1Class.h"
//#include "BB1Event.h"


#include "BB1KB.h"
#include "BB1KS.h"
#include "BB1Link.h"
#include "BB1Message.h"
#include "BB1Object.h"

#else

#include "ns_ob1\AttValPair.h"
#include "ns_ob1\BB1types.h"
#include "ns_ob1\BB1Class.h"
#include "ns_ob1\BB1Event.h"
#include "ns_ob1\BB1KB.h"
#include "ns_ob1\BB1KS.h"
#include "ns_ob1\BB1Link.h"
#include "ns_ob1\BB1Message.h"
#include "ns_ob1\BB1Object.h"
#endif


ObjectList::ObjectList()
{
}


ObjectList::ObjectList(const ObjectList& src)
{
	if (!src.empty())

		for (ObjectCIter o = src.begin() ; o != src.end() ; o++)
			push_back(*o) ;
/*
		{
			const BB1Class *pClass = dynamic_cast<const BB1Class *>(*o) ;
			if (pClass)
				push_back(pClass) ;

			const BB1Event *pEvent = dynamic_cast<const BB1Event *>(*o) ;
			if (pEvent)
				push_back(pEvent) ;

			const BB1Focus *pFocus = dynamic_cast<const BB1Focus *>(*o) ;
			if (pFocus)
				push_back(pFocus) ;

			const BB1KS *pKS = dynamic_cast<const BB1KS *>(*o) ;
			if (pKS)
				push_back(pKS) ;

			const BB1KSAR *pKSAR = dynamic_cast<const BB1KSAR *>(*o) ;
			if (pKSAR)
				push_back(pKSAR) ;

			const BB1Message *pMessage = dynamic_cast<const BB1Message *>(*o) ;
			if (pMessage)
				push_back(pMessage) ;

			// derivate from BB1Decision than derive from BB1Object
			const BB1Strategy *pStrategy = dynamic_cast<const BB1Strategy *>(*o) ;
			if (pStrategy)
				push_back(pStrategy) ;
		}
*/
}


ObjectList::~ObjectList()
{
	vider() ;
}


void
ObjectList::vider()
{
	if (!empty())
		for (ObjectIter o = begin() ; o != end() ; )
			erase(o) ;
}


ObjectList&
ObjectList::operator=(ObjectList& src)
{
	if (this == &src)
		return (*this) ;

	vider() ;

	if (!src.empty())
		for (ObjectCIter o = src.begin() ; o != src.end() ; o++)
			push_back(*o) ;
/*
		{
			const BB1Class *pClass = dynamic_cast<const BB1Class *>(*o) ;
			if (pClass)
				push_back(pClass) ;

			const BB1Event *pEvent = dynamic_cast<const BB1Event *>(*o) ;
			if (pEvent)
				push_back(pEvent) ;

			const BB1Focus *pFocus = dynamic_cast<const BB1Focus *>(*o) ;
			if (pFocus)
				push_back(pFocus) ;

			const BB1KS *pKS = dynamic_cast<const BB1KS *>(*o) ;
			if (pKS)
				push_back(pKS) ;

			const BB1KSAR *pKSAR = dynamic_cast<const BB1KSAR *>(*o) ;
			if (pKSAR)
				push_back(pKSAR) ;

			const BB1Message *pMessage = dynamic_cast<const BB1Message *>(*o) ;
			if (pMessage)
				push_back(pMessage) ;

			// derivate from BB1Decision than derive from BB1Object
			const BB1Strategy *pStrategy = dynamic_cast<const BB1Strategy *>(*o) ;
			if (pStrategy)
				push_back(pStrategy) ;
		}
*/

	return (*this) ;
}


StringList::StringList()
{
}


StringList::StringList(const StringList& src)
{
	if (!src.empty())
		for (StrCIter s = src.begin() ; s != src.end() ; s++)
			push_back(*s) ;
}


StringList::~StringList()
{
	vider() ;
}


void
StringList::vider()
{
	if (!empty())
		for (StrIter s = begin() ; s != end() ; )
			erase(s) ;
}


StringList&
StringList::operator=(StringList& src)
{
	if (this == &src)
		return *this ;

	vider() ;

	if (!src.empty())
		for (StrCIter s = src.begin() ; s != src.end() ; s++)
			push_back(*s) ;

	return (*this) ;
}


PathsList::PathsList()
{
}


PathsList::PathsList(PathsList& src)
{
	if (!src.empty())
		for (PathsIterator p = src.begin() ; p != src.end() ; p++)
			push_back(new string(**p)) ;
}


PathsList::~PathsList()
{
	vider() ;
}

/*
void        PathsList::vider()
{
	if (!empty())
		for (PathsIterator p = begin() ; p != end() ; )
		{
			delete (*p) ;
			erase(p) ;
		}
	clear() ;
}
*/
/*
PathsList&	PathsList::operator=(PathsList& src)
{
	vider() ;

	if (!src.empty())
		for (PathsCIter p = src.begin() ; p != src.end() ; p++)
			push_back(new string(**p)) ;

	return (*this) ;
}
*/

AVPSet::AVPSet()
{
}


AVPSet::AVPSet(const AVPSet& src)
{
	if (!src.empty())
    for (AVPCIter avp = src.begin() ; avp != src.end() ; avp++)
      push_back(new AttValPair(**avp)) ;
}


AVPSet::~AVPSet()
{
	vider() ;
}

/*
AVPSet& AVPSet::operator=(AVPSet& src)
{
	vider() ;

	if (!src.empty())
		for (AVPIter avp = src.begin() ; avp != src.end() ; avp++)
			push_back(new AttValPair(**avp)) ;
	return (*this) ;
}
*/

// add takes care of duplicates

AVPSet&
AVPSet::operator|=(const AVPSet& src)
{
	if ((&src && !src.empty()) && (&src != this))
		for (AVPCIter p = src.begin() ; p != src.end() ; p++)
			push_back(new AttValPair(**p)) ;
	
	return (*this) ;
}


ContextSet::ContextSet()
{
}


ContextSet::ContextSet(const ContextSet& src)
{
	if (!src.empty())
		for (ContextCIter c = src.begin() ; c != src.end() ; c++)
			push_back(new Context(**c)) ;
}


ContextSet::~ContextSet()
{
	vider() ;
}

/*
ContextSet& ContextSet::operator=(ContextSet& src)
{
	vider() ;

	if (!src.empty())
		for (ContextCIter c = src.begin() ; c != src.end() ; c++)
			push_back(new Context(**c)) ;
	return (*this) ;
}
*/

#ifndef __TCONTROLER__
EventSet::EventSet()
{
}


EventSet::EventSet(const EventSet& src)
{
	if (!src.empty())
		for (EventCIter e = src.begin() ; e != src.end() ; e++)
			push_back(new BB1Event(**e)) ;
}


EventSet::~EventSet()
{
	vider() ;
}

/*
EventSet& EventSet::operator=(EventSet& src)
{
	vider() ;

	if (!src.empty())
		for (EventIter e = src.begin() ; e != src.end() ; e++)
			push_back(new BB1Event(**e)) ;
	return (*this) ;
}
*/


FocusSet::FocusSet()
{
}


FocusSet::FocusSet(const FocusSet& src)
{
  if (!src.empty())
    for (FocusCIter f = src.begin() ; f != src.end() ; f++)
      push_back(new BB1Focus(**f)) ;
}


FocusSet::~FocusSet()
{
	vider() ;
}

#endif

/*
FocusSet& FocusSet::operator=(FocusSet& src)
{
	vider() ;

	if (!src.empty())
		for (FocusIter f = src.begin() ; f != src.end() ; f++)
			push_back(new BB1Focus(**f)) ;
	return (*this) ;
}
*/

KBSet::KBSet()
{
}


KBSet::KBSet(const KBSet& src)
{
	if (!src.empty())
		for (KBCIter kb = src.begin() ; kb != src.end() ; kb++)
			push_back(new BB1KB(**kb)) ;
}


KBSet::~KBSet()
{
	vider() ;
}

/*
KBSet& KBSet::operator=(KBSet& src)
{
	if (!src.empty())
		for (KBIter kb = src.begin() ; kb != src.end() ; kb++)
			push_back(new BB1KB(**kb)) ;
	return (*this) ;
}
*/

KSSet::KSSet()
{
}


KSSet::KSSet(const KSSet& src)
{
	if (!src.empty())
		for (KSCIter ks = src.begin() ; ks != src.end() ; ks++)
			push_back(new BB1KS(**ks)) ;
}


KSSet::~KSSet()
{
	vider() ;
}


/*
KSSet& KSSet::operator=(KSSet& src)
{
	vider() ;
	if (!src.empty())
		for (KSIter ks = src.begin() ; ks != src.end() ; ks++)
			push_back(new BB1KS(**ks)) ;
	return (*this) ;
}
*/


AKSSet::AKSSet()
{
}


AKSSet::AKSSet(const AKSSet& src)
{
	if (!src.empty())
		for (AKSCIter aks = src.begin() ; aks != src.end() ; aks++)
			push_back(new AKS(**aks)) ;
}


AKSSet::~AKSSet()
{
	vider() ;
}


#ifndef __TCONTROLER__
KSARSet::KSARSet()
{
}


KSARSet::KSARSet(const KSARSet& src)
{
  if (!src.empty())
    for (KSARCIter ksar = src.begin() ; ksar != src.end() ; ksar++)
			push_back(*ksar) ;
}


KSARSet::~KSARSet()
{
	if (!empty())
		clear() ;
}


KSARSet&
KSARSet::operator=(KSARSet& src)
{
	if (this == &src)
		return *this ;

	if (!empty())
		clear() ;

	if (!src.empty())
		for (KSARIter ksar = src.begin() ; ksar != src.end() ; ksar++)
			push_back(*ksar) ;
      
	return (*this) ;
}


KSARSet&	KSARSet::operator-=(KSARSet& src)
{
	KSARSet	t(*this) ;

	if (!empty())
		clear() ;

	for (KSARIter p = t.begin() ; p != t.end() ; p++)
	{
		BB1KSAR *e = (*p) ;
		if (!src.seek(e))
			push_back(e) ;
	}

	t.clear() ;

	return (*this) ;
}

#endif

LinkSet::LinkSet()
{
}


LinkSet::LinkSet(const LinkSet& src)
{
	if (!src.empty())
		for (LinkCIter l = src.begin() ; l != src.end() ; l++)
			push_back(*l) ;
}


LinkSet::~LinkSet()
{
	if (!empty())
		clear() ;
}


LinkSet&
LinkSet::operator=(LinkSet& src)
{
	if (this == &src)
		return *this ;

  if (!empty())
		clear() ;

	if (!src.empty())
		for (LinkIter l = src.begin() ; l != src.end() ; l++)
			push_back(*l) ;

	return (*this) ;
}


LinkSet&	LinkSet::operator|=(const LinkSet& src)
{
	if ((&src && !src.empty()) && (&src != this))
	{
		for (LinkCIter p = src.begin() ; p != src.end() ; p++)
			push_back(*p) ;
	}
	return (*this) ;
}


LinkPairSet::LinkPairSet()
{
}


LinkPairSet::LinkPairSet(const LinkPairSet& src)
{
  if (!src.empty())
    for (LinkPairCIter l = src.begin() ; l != src.end() ; l++)
			push_back(*l) ;
}


LinkPairSet::~LinkPairSet()
{
	if (!empty())
		clear() ;
}


LinkPairSet& LinkPairSet::operator=(LinkPairSet& src)
{
	if (this == &src)
		return *this ;

	if (!empty())
		clear() ;

	if (!src.empty())
		for (LinkPairIter l = src.begin() ; l != src.end() ; l++)
			push_back(*l) ;

	return (*this) ;
}


ObjectSet::ObjectSet()
{
}


ObjectSet::ObjectSet(const ObjectSet& src)
{
	if (!src.empty())
		for (ObjectCIter o = src.begin() ; o != src.end() ; o++)
		{
			const BB1Class *pClass = dynamic_cast<const BB1Class *>(*o) ;
			if (pClass)
				push_back(new BB1Class(*pClass));

      #ifndef __TCONTROLER__
			const BB1Event *pEvent = dynamic_cast<const BB1Event *>(*o) ;
			if (pEvent)
				push_back(new BB1Event(*pEvent)) ;

			const BB1Focus *pFocus = dynamic_cast<const BB1Focus *>(*o) ;
			if (pFocus)
				push_back(new BB1Focus(*pFocus)) ;

      const BB1KSAR *pKSAR = dynamic_cast<const BB1KSAR *>(*o) ;
			if (pKSAR)
				push_back(new BB1KSAR(*pKSAR)) ;

      const BB1Strategy *pStrategy = dynamic_cast<const BB1Strategy *>(*o) ;
			if (pStrategy)
				push_back(new BB1Strategy(*pStrategy)) ;

      const BB1KS *pKS = dynamic_cast<const BB1KS *>(*o) ;
			if (pKS)
				push_back(new BB1KS(*pKS)) ;

      #endif

      //FIXME


			const BB1Message *pMessage = dynamic_cast<const BB1Message *>(*o) ;
			if (pMessage)
				push_back(new BB1Message(*pMessage)) ;

		}
}

/*
ObjectSet::ObjectSet(const ObjectList& src)
{
	if (!src.empty())
		for (ObjectCIter o = src.begin() ; o != src.end() ; o++)
		{
			const BB1Class *pClass = dynamic_cast<const BB1Class *>(*o) ;
			if (pClass)
				push_back(new BB1Class(*pClass)) ;

			const BB1Event *pEvent = dynamic_cast<const BB1Event *>(*o) ;
			if (pEvent)
				push_back(new BB1Event(*pEvent)) ;

			const BB1Focus *pFocus = dynamic_cast<const BB1Focus *>(*o) ;
			if (pFocus)
				push_back(new BB1Focus(*pFocus)) ;

			const BB1KS *pKS = dynamic_cast<const BB1KS *>(*o) ;
			if (pKS)
				push_back(new BB1KS(*pKS)) ;

			const BB1KSAR *pKSAR = dynamic_cast<const BB1KSAR *>(*o) ;
			if (pKSAR)
				push_back(new BB1KSAR(*pKSAR)) ;

			const BB1Message *pMessage = dynamic_cast<const BB1Message *>(*o) ;
			if (pMessage)
				push_back(new BB1Message(*pMessage)) ;

			// derivate from BB1Decision than derive from BB1Object
			const BB1Strategy *pStrategy = dynamic_cast<const BB1Strategy *>(*o) ;
			if (pStrategy)
				push_back(new BB1Strategy(*pStrategy)) ;
		}
}
*/

ObjectSet::~ObjectSet()
{
	vider() ;
}

/*
void				ObjectSet::vider()
{
	if (empty())
		return ;
	for (ObjectIter iter = begin() ; iter != end() ; )
	{
		delete (*iter) ;
		erase(iter) ;
	}
	clear() ;
}
*/

ObjectSet&
ObjectSet::operator=(ObjectSet& src)
{
	if (this == &src)
		return *this ;

	vider() ;

	if (!src.empty())
		for (ObjectIter o = src.begin() ; o != src.end() ; o++)
		{
			const BB1Class *pClass = dynamic_cast<const BB1Class *>(*o) ;
			if (pClass)
				push_back(new BB1Class(*pClass)) ;

      #ifndef __TCONTROLER__
			const BB1Event *pEvent = dynamic_cast<const BB1Event *>(*o) ;
      if (pEvent)
      	push_back(new BB1Event(*pEvent)) ;

      const BB1Focus *pFocus = dynamic_cast<const BB1Focus *>(*o) ;
      if (pFocus)
      	push_back(new BB1Focus(*pFocus)) ;

      const BB1KSAR *pKSAR = dynamic_cast<const BB1KSAR *>(*o) ;
      if (pKSAR)
      	push_back(new BB1KSAR(*pKSAR)) ;

        // derivate from BB1Decision than derive from BB1Object
      const BB1Strategy *pStrategy = dynamic_cast<const BB1Strategy *>(*o) ;
      if (pStrategy)
      	push_back(new BB1Strategy(*pStrategy)) ;

        const BB1KS *pKS = dynamic_cast<const BB1KS *>(*o) ;
      if (pKS)
      	push_back(new BB1KS(*pKS)) ;
      #endif

       //FIXME : KS

      const BB1Message *pMessage = dynamic_cast<const BB1Message *>(*o) ;
      if (pMessage)
      	push_back(new BB1Message(*pMessage)) ;
    }
    
  return (*this) ;
}
