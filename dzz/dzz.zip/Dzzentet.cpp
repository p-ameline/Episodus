//
//                  Programme secondaire DKENTETE
//
//                  Fabrication de l'ent�te du CR
//
//             D�but d'�criture :  7 Novembre 1990 (PA)
//             Derni�re version :  1 Novembre 1993 (PA)
//
#include <owl\olemdifr.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cstring.h>

#ifdef _INCLUS
  #include "partage\nsglobal.h"
  #include "nsbb\nsutidlg.h"
#endif

#include "partage\nsperson.h"

#include "partage\nsdivfct.h"
#include "dzz\dzzglob.h"
#include "dzz\nsdzz.h"

#include "dzz\dzzdecod.h"

//--------------------------------------------------------------------------
//  Function 	 : void entete(string* pCRString)
//
//  Description : Fabrique l'ent�te du C-R
//
//	 ARGUMENTS 	 :
//
//	 Retour	  	 :	Rien
//--------------------------------------------------------------------------
//  Cr�� le 14/11/1988  Derni�re mise � jour le 26/08/1994
void
decodage::entete(gereDate* pDateExam)
{
    signed int age;
    string	   intitulePat;
    char       datex[9], dateNaiss[9];
	//
	// Facilite l'�criture
	//
    NSPatientChoisi* pPatEnCours = pContexte->getPatient();
    NSSuper* 		 pSuper 	 = pContexte->getSuperviseur();

    strcpy(datex, (pDateExam->getDate()).c_str());

	//
	// Titre de l'examen
	//
    NSPathologData Data;
    bool bTrouve = pSuper->getDico()->trouvePathologData(sLangue, &(decodage::sExamen), &Data);
    if (!bTrouve)
    {
        Recupere();
        return;
    }
    string sTitre = "";
    Data.donneLibelleAffiche(&sTitre);

    for (size_t i = 0; i < strlen(sTitre.c_str()); i++)
        sTitre[i] = pseumaj(sTitre[i]);

    *sDcodeur() = sTitre + string(" de ");
	//
	// Intitul� du patient
	//
#ifndef _MUE
    if (!(pPatEnCours->donneNaissance(dateNaiss)))
        age = -1;
    else
		age = donne_age(datex, dateNaiss);

	donne_intitule_patient(&intitulePat, age, pPatEnCours->estFeminin(), false, sLangue);

	*sDcodeur() += intitulePat;
    *sDcodeur() += pPatEnCours->pDonnees->nom ;
	strip(*sDcodeur(), stripRight, ' '); // sDcodeur()->strip(string::Trailing, ' ');
    *sDcodeur() += " ";
	*sDcodeur() += pPatEnCours->pDonnees->prenom;
	strip(*sDcodeur(), stripRight, ' '); // sDcodeur()->strip(string::Trailing, ' ');
#else
    if (!(pPatEnCours->donneNaissance(dateNaiss)))
        age = -1;
    else
		age = donne_age(datex, dateNaiss);

	donne_intitule_patient(&intitulePat, age, pPatEnCours->estFeminin(), false, sLangue) ;

	*sDcodeur() += intitulePat;
    *sDcodeur() += pPatEnCours->getNom() ;
	strip(*sDcodeur(), stripRight, ' ');
    *sDcodeur() += " ";
	*sDcodeur() += pPatEnCours->getPrenom();
	strip(*sDcodeur(), stripRight, ' ');
#endif

	metPhrase("2", "2"/*, 1*/);
	//
	// Hospitalis� ou externe
	//
	*sDcodeur() = "";
	return;
}

