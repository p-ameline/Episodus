//  +-----------------------------------------------------------------+
//  �                PROGRAMME SECONDAIRE : DKEXMITR.C                �
//  �                                                                 �
//  �                    D�codage Valve mitrale                       �
//  �                                                                 �
//  �             D�but d'�criture :  7 Novembre 1990 (PA)            �
//  �             Derni�re version : 25 Avril 1994 (PA)               �
//  +-----------------------------------------------------------------+
#include <owl\olemdifr.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cstring.h>
#include <math.h>

#include "dcodeur\nsphrobj.h"

#include "dzz\dzzspeci.h"
#include "partage\nsdivfct.h"

decPrescription::decPrescription(NSContexte* pCtx)
                :decodage(pCtx)
{
	sLibelle = "" ;
}

decPrescription::decPrescription(decodageBase* pBase)
                :decodage(pBase)
{
	sLibelle = "" ;
}

//  +-----------------------------------------------------------------+  */
//  �             D�code code[], comlib[] et biop[]                   �  */
//  +-----------------------------------------------------------------+  */
//  Cr�� le 14/01/2001 Derni�re mise � jour 14/01/2001                   */
void
decPrescription::decode(int colonne)
{
	if (sLibelle != "")
  {
  	*sDcodeur() = "" ;
    metPhrase() ;
    *sDcodeur() = sLibelle ;
    metPhrase("3", "3"/*, 1*/) ;
    *sDcodeur() = "" ;
    metPhrase() ;
  }

  int refCol = getCol() ;

	while ((getCol() > colonne) && iBon())
	{
  	if (((*getSt())[0] == '_') || ((*getSt())[0] == 'I') ||
        ((*getSt())[0] == 'N') || ((*getSt())[0] == 'O') ||
        ((*getSt())[0] == 'G'))
    {
    	decSpecialite Specia(this, dcTiret) ;
      Specia.decode(refCol) ;
			Specia.donnePhrase() ;
      *sDcodeur() = "" ;
      metPhrase() ;
    }
		else
    	Recupere() ;
  }
	return ;
}

//  +-----------------------------------------------------------------+
//  �     D�codage d'une prescription de sp�cialit� pharmaceutique    �
//  +-----------------------------------------------------------------+
//  Cr�� le 07/11/1990 Derni�re mise � jour 22/07/1992

decSpecialite::decSpecialite(NSContexte* pCtx, int iDecodeType)
			  : decLesion(pCtx, iDecodeType), DkdPrescript(pCtx, dcTiret)
{
}

decSpecialite::decSpecialite(decodageBase* pBase, int iDecodeType)
			  : decLesion(pBase, iDecodeType), DkdPrescript(pBase, dcTiret)
{
}

void
decSpecialite::decode(int colonne)
{
	string 		 decal;

	DkdPrescript.ammorce();

	// Affichage du nom de la sp�cialit�
	//
	ajLL() ;
  NSPathologData Data ;
  NSSuper* pSuper = pContexte->getSuperviseur() ;
  bool bTrouve = pSuper->getDico()->trouvePathologData(sLangue, getStL(), &Data) ;
  if (!bTrouve)
  {
  	Recupere() ;
    return ;
  }
	Data.donneLibelleAffiche(sDcodeur()) ;
	if (*sDcodeur() != "")
	{
		(*sDcodeur())[0] = pseumaj((*sDcodeur())[0]) ;
    metPhrase("4", "4") ;
  }
	*sDcodeur() = "" ;
	int refCol = getCol() ;
	Avance() ;

	DkdPrescript.decode(refCol) ;

	return ;
}

void
decSpecialite::donnePhrase()
{
    if (!iBon())
		return ;

	DkdPrescript.metPhrase("4", "4") ;
}

