//  +-----------------------------------------------------------------+
//  |                   Programme secondaire DZZDECOD                 |
//  |                                                                 |
//  |          Oriente le d�codage vers les principaux chapitres      |
//  |                                                                 |
//  |             D�but d'�criture : 14 Janvier 2001 (PA)             |
//  |             Derni�re version : 14 Janvier 2001 (PA)             |
//  +-----------------------------------------------------------------+
#include <owl\olemdifr.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cstring.h>

#include "nssavoir\nssavoir.h"
#include "nsbb\nstlibre.h"
#include "dzz\dzzdecod.h"
#include "dzz\dzzglob.h"
#include "dzz\dzzspeci.h"
#include "partage\nsdivfct.h"

//  +-----------------------------------------------------------------+
//  �              Biopsies, Textes libres, Traitements               �
//  +-----------------------------------------------------------------+
//  Cr�� le 20/03/1989 Derni�re mise � jour 20/03/1989
void
decodage::BioLibre(int colonne, string decDeb, string decFin, int sautLigne)
{
	// int  		 i, j, k, l;
  // unsigned int iNum;
	// char 		 decal[3];

  int refCol = getCol();

	while ((getCol() > colonne) && iBon())
	{
  	if 	  (*getSt() ==	"#TLI#")
    {
    	// NSTlibre NSTlibre(pContexte) ;
      Avance() ;
      while ((getCol() > refCol) && iBon())
      {
      	if (*getSt() == "�??")
        {
					// bool bOK = NSTlibre.RecupereTexte(pContexte->getPatient()->getNss(), *getCpl(), sDcodeur()) ;
					Avance() ;
          // if (bOK)
          	metPhrase(decDeb, decFin, sautLigne) ;
				}
        else
        {
        	pContexte->getDico()->donneLibelle(sLangue, getStL(), sDcodeur()) ;
          Avance() ;
          *sDcodeur() += "." ;
					metPhrase(decDeb, decFin, sautLigne) ;
        }
			}
		}
    else
    	Recupere() ;
	}

	return ;
}

//  +-----------------------------------------------------------------+
//  �                   L�sion sans description                       �
//  +-----------------------------------------------------------------+
//  Cr�� le 19/01/1989 Derni�re mise � jour 19/01/1989
void
decodage::lesionVide(string phrase, int colonne)
{
	while (getCol() > colonne)
  	BioLibre(colonne) ;

  debutPhrase() ;
  *sDcodeur() += phrase ;
  *sDcodeur() += "." ;
  metPhrase() ;
  finPhrase() ;
  return ;
}

decGeneral::decGeneral(NSContexte* pCtx)
           :decodage(pCtx)
{
}

decGeneral::decGeneral(decodageBase* pBase)
           :decodage(pBase)
{
}

//  +-----------------------------------------------------------------+
//  �             D�code code[], comlib[] et biop[]                   �
//  +-----------------------------------------------------------------+
//  Cr�� le 10/11/1988 Derni�re mise � jour 23/06/1992
void
decGeneral::decode()
{
	// bool conclusion = false;

  NSSuper* pSuper = pContexte->getSuperviseur() ;

  gereDate dateExam(pContexte, sLangue) ;
  dateExam.setDate(&(decodage::pDocument->sDateCreation)) ;
  entete(&dateExam) ;

  int refCol = getCol() ;

	while ((getCol() >= refCol) && iBon())
	{
  	if 	    ((*getSt() == "GPALD") || (*getSt() == "GPCOD"))
    {
    	NSPathologData Data ;
      bool bTrouve = pSuper->getDico()->trouvePathologData(sLangue, getStL(), &Data) ;
      if (!bTrouve)
      {
      	Recupere() ;
        return ;
      }
      string sTitre = "" ;
      Data.donneLibelleAffiche(&sTitre) ;
      sTitre[0] = pseumaj(sTitre[0]) ;
      ajLL() ;
      Avance() ;
      decPrescription Prescri(this) ;
      Prescri.setLibelle(sTitre) ;
      Prescri.decode(refCol) ;
    }
    else if (((*getSt())[0] == '_') || ((*getSt())[0] == 'I') ||
             ((*getSt())[0] == 'N') || ((*getSt())[0] == 'O') ||
             ((*getSt())[0] == 'G'))
    {
    	decSpecialite Specia(this, dcTiret) ;
      Specia.decode(refCol) ;
      Specia.donnePhrase() ;
    	*sDcodeur() = "" ;
      metPhrase() ;
    }
		else
    	Recupere() ;
	}
	if (!iBon())
		return ;
	return ;
}

/*  +-----------------------------------------------------------------+  */
/*  �                  D�code le "time stamp"                         �  */
/*  +-----------------------------------------------------------------+  */
/*  Cr�� le 06/09/1991 Derni�re mise � jour 06/09/1991                   */
void
decGeneral::versi(int colonne)
{
	gereDate dateExam(pContexte, sLangue) ;
  string	codeOper = "" ;
  string	contexte = "" ;

  int refCol = getCol() ;

  while ((getCol() > colonne) && iBon())
	{
  	if 	    (*getSt() == "KCHIR")
    {
    	Avance() ;
      donneDate(refCol, &dateExam) ;
    }
    else if (*getSt() == "DOPER")
    {
    	codeOper = *(getCpl()) ;
      Avance() ;
    }
  }

  entete(&dateExam) ;

  NSPatientChoisi* pPatEnCours = pContexte->getPatient() ;
  string intituleAge ;
  char 	 dateNaiss[9], dateExamen[9], ptgag[11] ;

  if ((pPatEnCours->donneNaissance(dateNaiss)) &&
   	    (strcmp(dateNaiss, "00000000") != 0))
  {
  	if (contexte != "")
    	*sDcodeur() = "(" + contexte + ") " ;

    if (pPatEnCours->estFeminin())
    	*sDcodeur() += "N�e le " ;
    else
    	*sDcodeur() += "N� le " ;

    donne_date(dateNaiss, ptgag, sLangue) ;
    *sDcodeur() += ptgag ;
    //if (age != -1)
    //{
    *sDcodeur() += " (" ;
    strcpy(dateExamen, (dateExam.getDate()).c_str()) ;
    donne_intitule_age(&intituleAge, dateExamen, dateNaiss) ;
    *sDcodeur() += intituleAge ;
    *sDcodeur() += ")" ;
    //}
  }
  else
  	*sDcodeur() = contexte ;

  if (*sDcodeur() != "")
  	metPhrase("", ""/*, 1*/) ;

  return ;
}

