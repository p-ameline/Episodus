#include "nsepisod\objectif_viewer.rh"
#include "nsepisod\objectif_viewer.h"
#include "nsepisod\nsepisod.h"

// -----------------------------------------------------------------------------
//
// class ObjectifViewerDlg
//
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(ObjectifViewerDlg, NSUtilDialog)
    EV_WM_CLOSE,
    EV_WM_PAINT,
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_BN_CLICKED(IDC_ONE,CmPunctual),
    EV_BN_CLICKED(IDC_CYCLE,CmCyclic),
    EV_BN_CLICKED(IDC_PERMANENT,CmPermanent),
END_RESPONSE_TABLE;

ObjectifViewerDlg::ObjectifViewerDlg(TWindow* pere, NSContexte* pCtx, bool withCreat, NSLdvGoal* pRefObj)
                  :NSUtilDialog(pere, pCtx, "IDD_OBJECTIF_VIEW", pNSResModule)
{
try
{
  // Initialisation des donnees
	creatMod = withCreat ;

	pObjectifLexicon    = new NSUtilLexique(pContexte, this, IDC_OBJECTIF_NAME,pContexte->getDico()) ;
	pUnitValue          = new NSUtilLexique(pContexte, this, IDC_VALUE_UNIT,pContexte->getDico()) ;

	char *tempsUnit[]   = {"2HEUR1","2DAT01","2DAT21", "2DAT11"} ;
	pPeriodUnit         = new NSComboBox(this, IDC_PERIOD_UNIT, pContexte, tempsUnit) ;
	pStaticPeriod       = new TStatic((TWindow*)this, IDC_STATIC_PERIOD) ;
	pStaticMoments      = new TStatic((TWindow*)this, IDC_STATIC_MOMMENTS) ;

	pStartDate          = new NSUtilEditDateHeure(pContexte, this, IDC_DATE_DEBUT) ;
	pStartEveniment     = new NSUtilLexique(pContexte, this, IDC_EVENIMENT_DEBUT, pContexte->getDico()) ;

  pEndDate            = new NSUtilEditDateHeure(pContexte, this, IDC_DATE_END) ;
  pEndEveniment       = new NSUtilLexique(pContexte, this, IDC_EVENIMENT_END, pContexte->getDico()) ;

  //lines
  pStaticLines1       = new TStatic((TWindow*)this, IDC_LINE1) ;
  pStaticLines2       = new TStatic((TWindow*)this, IDC_LINE2) ;
  pStaticLines3       = new TStatic((TWindow*)this, IDC_LINE3) ;
  pStaticLines4       = new TStatic((TWindow*)this, IDC_LINE4) ;
  pStaticLines5       = new TStatic((TWindow*)this, IDC_LINE5) ;
  pStaticLines6       = new TStatic((TWindow*)this, IDC_LINE6) ;

  //period management
  pPeriodAuthorizeMax = new NSObjectifEditNum(pContexte, this, IDC_PERIOD_AUTHORIZE_MAX, 5, &NS_CLASSLIB::TColor::LtRed,    &NS_CLASSLIB::TColor::LtYellow) ;
  pPeriodRecommendMax = new NSObjectifEditNum(pContexte, this, IDC_PERIOD_RECOMMEND_MAX, 4, &NS_CLASSLIB::TColor::LtYellow, &NS_CLASSLIB::TColor::LtGreen) ;
  pPeriodIdealMax     = new NSObjectifEditNum(pContexte, this, IDC_PERIOD_IDEAL_MAX,     3, &NS_CLASSLIB::TColor::LtGreen,  &NS_CLASSLIB::TColor::LtBlue) ;
  pPeriodIdealMin     = new NSObjectifEditNum(pContexte, this, IDC_PERIOD_IDEAL_MIN,     2, &NS_CLASSLIB::TColor::LtBlue,   &NS_CLASSLIB::TColor::LtGreen) ;
  pPeriodRecommendMin = new NSObjectifEditNum(pContexte, this, IDC_PERIOD_RECOMMEND_MIN, 1, &NS_CLASSLIB::TColor::LtGreen,  &NS_CLASSLIB::TColor::LtYellow) ;
  pPeriodAuthorizeMin = new NSObjectifEditNum(pContexte, this, IDC_PERIOD_AUTHORIZE_MIN, 0, &NS_CLASSLIB::TColor::LtYellow, &NS_CLASSLIB::TColor::LtRed) ;

  pValueAuthorizeMax  = new NSObjectifEditNum(pContexte, this, IDC_VALUE_AUTHORIZE_MAX, 5, &NS_CLASSLIB::TColor::LtRed,    &NS_CLASSLIB::TColor::LtYellow) ;
  pValueRecommendMax  = new NSObjectifEditNum(pContexte, this, IDC_VALUE_RECOMMEND_MAX, 4, &NS_CLASSLIB::TColor::LtYellow, &NS_CLASSLIB::TColor::LtGreen) ;
  pValueIdealMax      = new NSObjectifEditNum(pContexte, this, IDC_VALUE_IDEAL_MAX,     3, &NS_CLASSLIB::TColor::LtGreen,  &NS_CLASSLIB::TColor::LtBlue) ;
  pValueIdealMin      = new NSObjectifEditNum(pContexte, this, IDC_VALUE_IDEAL_MIN,     2, &NS_CLASSLIB::TColor::LtBlue,   &NS_CLASSLIB::TColor::LtGreen) ;
  pValueRecommendMin  = new NSObjectifEditNum(pContexte, this, IDC_VALUE_RECOMMEND_MIN, 1, &NS_CLASSLIB::TColor::LtGreen,  &NS_CLASSLIB::TColor::LtYellow) ;
  pValueAuthorizeMin  = new NSObjectifEditNum(pContexte, this, IDC_VALUE_AUTHORIZE_MIN, 0, &NS_CLASSLIB::TColor::LtYellow, &NS_CLASSLIB::TColor::LtRed) ;

  //date management
  pDateAuthorizeMax   = new NSObjectifEditDateHeure(pContexte, this, IDC_DATE_AUTHORIZE_MAX, &NS_CLASSLIB::TColor::LtRed,    &NS_CLASSLIB::TColor::LtYellow) ;
  pDateRecommendMax   = new NSObjectifEditDateHeure(pContexte, this, IDC_DATE_RECOMMAND_MAX, &NS_CLASSLIB::TColor::LtYellow, &NS_CLASSLIB::TColor::LtGreen) ;
  pDateIdealMax       = new NSObjectifEditDateHeure(pContexte, this, IDC_DATE_IDEAL_MAX,     &NS_CLASSLIB::TColor::LtGreen,  &NS_CLASSLIB::TColor::LtBlue) ;
  pDateIdealMin       = new NSObjectifEditDateHeure(pContexte, this, IDC_DATE_IDEAL_MIN,     &NS_CLASSLIB::TColor::LtBlue,   &NS_CLASSLIB::TColor::LtGreen) ;
  pDateRecommendMin   = new NSObjectifEditDateHeure(pContexte, this, IDC_DATE_RECOMMAND_MIN, &NS_CLASSLIB::TColor::LtGreen,  &NS_CLASSLIB::TColor::LtYellow) ;
  pDateAuthorizeMin   = new NSObjectifEditDateHeure(pContexte, this, IDC_DATE_AUTHORIZE_MIN, &NS_CLASSLIB::TColor::LtYellow, &NS_CLASSLIB::TColor::LtRed) ;

  //mode
  pMode               = new TGroupBox(this, IDC_GROUP) ;
  pCycle              = new TRadioButton(this, IDC_CYCLE,pMode) ;
  pOne                = new TRadioButton(this, IDC_ONE,pMode) ;
  pPermanent          = new TRadioButton(this, IDC_PERMANENT, pMode) ;

  pObjGroup           = new TGroupBox(this, IDC_OBJECTIF_BOX) ;
  pPresence           = new TRadioButton(this, IDC_PRESENCE, pMode) ;
  pAbsence            = new TRadioButton(this, IDC_ABSENT, pMode) ;

  pComplement         = new TEdit((TWindow*)this, IDC_COMPLEMENT) ;

  objectifType        = ONE_OBJECTIF ;

  pObjectif           = pRefObj ;

	for (int i = 0 ; i < 6 ; i++)
	{
		arrayLeftNumControls[i]  = NULL ;
		arrayRightNumControls[i] = NULL ;
		arrayLeftDateControls[i] = NULL ;
	}
}
catch (...)
{
	erreur("Exception (new ObjectifViewerDlg)", standardError, 0) ;
}
}

ObjectifViewerDlg::~ObjectifViewerDlg()
{
  delete pObjectifLexicon ;
  delete pUnitValue ;
  delete pPeriodUnit ;
  delete pStaticPeriod ;
  delete pStaticMoments ;

  delete pStartDate ;
  delete pStartEveniment ;

  delete pEndDate ;
  delete pEndEveniment ;

  delete pStaticLines1 ;
  delete pStaticLines2 ;
  delete pStaticLines3 ;
  delete pStaticLines4 ;
  delete pStaticLines5 ;
  delete pStaticLines6 ;

  delete pPeriodIdealMin ;
  delete pPeriodIdealMax ;
  delete pPeriodRecommendMin ;
  delete pPeriodRecommendMax ;
  delete pPeriodAuthorizeMin ;
	delete pPeriodAuthorizeMax ;

  delete pDateIdealMin ;
  delete pDateIdealMax ;
  delete pDateRecommendMin ;
  delete pDateRecommendMax ;
  delete pDateAuthorizeMin ;
	delete pDateAuthorizeMax ;

  delete pValueIdealMin ;
  delete pValueIdealMax ;
  delete pValueRecommendMin ;
  delete pValueRecommendMax ;
  delete pValueAuthorizeMin ;
	delete pValueAuthorizeMax ;

  delete pMode ;
  delete pCycle ;
  delete pOne ;
  delete pPermanent ;

  delete pObjGroup ;
  delete pPresence ;
  delete pAbsence ;

  delete pComplement ;
}

bool
ObjectifViewerDlg::InitFromSavedObjectif()
{
  if (!pObjectif)
    return false ;

  //objectif name
  pObjectifLexicon->setLabel(pObjectif->sLexique) ;
  if (pObjectif->sCertitude != "")
    pAbsence->Check() ;
  else
    pPresence->Check() ;

    if (pObjectif->sComplementText != "")
        pComplement->SetText(pObjectif->sComplementText.c_str() ) ;
    //open data
    if(!pObjectif->tDateOuverture.estVide())
        pStartDate->setDate(pObjectif->tDateOuverture.donneDateHeure()) ;
    else
        if( pObjectif->sOpenEventNode != "")
            pStartEveniment->setLabel(pObjectif->sOpenEventNode) ;
        // else
        //    return false ;
    //close data
    if((!pObjectif->tDateFermeture.estVide())&&(!pObjectif->tDateFermeture.estNoLimit()))
        pEndDate->setDate(pObjectif->tDateFermeture.donneDateHeure()) ;
    else
        if( pObjectif->sCloseEventNode != "")
            pEndEveniment->setLabel(pObjectif->sCloseEventNode) ;
        // else
        //    return false ;

	switch(pObjectif->iRythme)
	{
		case NSLdvGoal::ponctuel :
			setDate() ;
			setValue() ;
			CmPunctual();
			pOne->Check() ;
			break ;
		case NSLdvGoal::cyclic :
			setPeriode() ;
			setValue() ;
			CmCyclic();
			pCycle->Check() ;
			break ;
		case NSLdvGoal::permanent :
			setValue() ;
			CmPermanent();
			pPermanent->Check() ;
			break ;
	}
	return true ;
	// decodeObjectif(pObjectif->iRythme) ;
}

//if a data is in 10 chars add 10
string completeData(string sDate, NSUtilEditDateHeure* /* pControl */)
{
	if (strlen(sDate.c_str()) == 8)
  	return sDate + "000000" ;
	return sDate ;
}

void
ObjectifViewerDlg::setDate()
{
    if(pObjectif->sDateDebutIdeal != "")
        pDateIdealMin->setDate(completeData(pObjectif->sDateDebutIdeal, pDateIdealMin)) ;
    if(pObjectif->sDateDebutIdealMax != "")
        pDateIdealMax->setDate(completeData(pObjectif->sDateDebutIdealMax, pDateIdealMax)) ;
    if(pObjectif->sDateDebutConseille != "")
        pDateRecommendMin->setDate(completeData(pObjectif->sDateDebutConseille, pDateRecommendMin)) ;
    if(pObjectif->sDateDebutConseilMax != "")
        pDateRecommendMax->setDate(completeData(pObjectif->sDateDebutConseilMax, pDateRecommendMax)) ;
    if(pObjectif->sDateDebutAutorise != "")
        pDateAuthorizeMin->setDate(completeData(pObjectif->sDateDebutAutorise, pDateAuthorizeMin)) ;
    if(pObjectif->sDateDebutCritique != "")
        pDateAuthorizeMax->setDate(completeData(pObjectif->sDateDebutCritique, pDateAuthorizeMax)) ;
}

void
ObjectifViewerDlg::setPeriode()
{
	bool found = false;
	string sUnit = "";
	if (pObjectif->dDelaiDebutIdeal > 0 )
	{
		pPeriodIdealMin->SetDoubleIntoEditNum(pObjectif->dDelaiDebutIdeal) ;
		sUnit = pObjectif->sUniteDebutIdeal ;
		found = true ;
	}
	if (pObjectif->dDelaiDebutIdealMax > 0 )
	{
		pPeriodIdealMax->SetDoubleIntoEditNum(pObjectif->dDelaiDebutIdealMax) ;
		sUnit = pObjectif->sUniteDebutIdealMax ;
		found = true ;
	}
	if (pObjectif->dDelaiDebutConseille > 0 )
	{
		pPeriodRecommendMin->SetDoubleIntoEditNum(pObjectif->dDelaiDebutConseille) ;
		sUnit = pObjectif->sUniteDebutConseille ;
		found = true ;
	}
	if (pObjectif->dDelaiDebutConseilMax > 0 )
	{
		pPeriodRecommendMax->SetDoubleIntoEditNum(pObjectif->dDelaiDebutConseilMax) ;
		sUnit = pObjectif->sUniteDebutConseilMax ;
		found = true ;
	}
	if (pObjectif->dDelaiDebutAutorise > 0)
	{
		pPeriodAuthorizeMin->SetDoubleIntoEditNum(pObjectif->dDelaiDebutAutorise) ;
		sUnit = pObjectif->sUniteDebutAutorise ;
		found = true ;
	}
	if(pObjectif->dDelaiDebutCritique > 0 )
	{
		pPeriodAuthorizeMax->SetDoubleIntoEditNum(pObjectif->dDelaiDebutCritique) ;
		sUnit = pObjectif->sUniteDebutCritique ;
		found = true ;
	}
	if ((found) && (sUnit == ""))
		return ;

	if (found)
		pPeriodUnit->setCode(sUnit + "1") ;
}


void
ObjectifViewerDlg::setValue()
{
	bool found = false;
	string sUnit = "" ;
  
	if (pObjectif->dValMinIdeal > 0)
	{
		pValueIdealMin->SetDoubleIntoEditNum(pObjectif->dValMinIdeal) ;
		sUnit = pObjectif->sUniteValMinIdeal ;
		found = true ;
	}
	if (pObjectif->dValMaxIdeal > 0)
	{
		pValueIdealMax->SetDoubleIntoEditNum(pObjectif->dValMaxIdeal) ;
		sUnit = pObjectif->sUniteValMaxIdeal ;
		found = true ;
	}
	if (pObjectif->dValMinConseille > 0)
	{
		pValueRecommendMin->SetDoubleIntoEditNum(pObjectif->dValMinConseille) ;
		sUnit = pObjectif->sUniteValMinConseille ;
		found = true ;
	}
	if (pObjectif->dValMaxConseille > 0)
	{
		pValueRecommendMax->SetDoubleIntoEditNum(pObjectif->dValMaxConseille) ;
		sUnit = pObjectif->sUniteValMaxConseille ;
		found = true ;
	}
	if (pObjectif->dValMinAutorise > 0)
	{
		pValueAuthorizeMin->SetDoubleIntoEditNum(pObjectif->dValMinAutorise) ;
		sUnit = pObjectif->sUniteValMinAutorise ;
		found = true ;
	}
	if (pObjectif->dValMaxAutorise > 0)
	{
		pValueAuthorizeMax->SetDoubleIntoEditNum(pObjectif->dValMaxAutorise) ;
		sUnit = pObjectif->sUniteValMaxAutorise ;
		found = true ;
	}

	if((found) && (sUnit == ""))
		return ;

	if (found)
		pUnitValue->setLabel(sUnit + "1") ;
}

void
ObjectifViewerDlg::SetupWindow()
{
	TDialog::SetupWindow() ;

	if (!creatMod)
		InitFromSavedObjectif() ;
	else
	{
		CmCyclic() ;
		pCycle->Check() ;
		pPresence->Check() ;
	}
}

void
ObjectifViewerDlg::decodeObjectif(int type)
{
  switch(type)
  {
    case CYCLE_OBJECTIF :
      pCycle->Check() ;
      CmCyclic() ;
      break ;

    case ONE_OBJECTIF :
      pOne->Check() ;
      CmPunctual() ;
      break ;

    case PERMANENT_OBJECTIF :
      pPermanent->Check() ;
      CmPermanent() ;
      break ;
  }
}

void
ObjectifViewerDlg::ShowLine(int cmdShow)
{
  pStaticLines1->Show(cmdShow) ;
  pStaticLines2->Show(cmdShow) ;
  pStaticLines3->Show(cmdShow) ;
  pStaticLines4->Show(cmdShow) ;
  pStaticLines5->Show(cmdShow) ;
  pStaticLines6->Show(cmdShow) ;
}

void
ObjectifViewerDlg::ShowPeriod(int cmdShow)
{
  pPeriodIdealMin->Show(cmdShow) ;
  pPeriodIdealMax->Show(cmdShow) ;
  pPeriodRecommendMin->Show(cmdShow) ;
  pPeriodRecommendMax->Show(cmdShow) ;
  pPeriodAuthorizeMin->Show(cmdShow) ;
	pPeriodAuthorizeMax->Show(cmdShow) ;

  pPeriodUnit->Show(cmdShow) ;
  pStaticPeriod->Show(cmdShow) ;
}

void
ObjectifViewerDlg::ShowDate(int cmdShow)
{
  pStaticMoments->Show(cmdShow) ;

  pDateIdealMin->Show(cmdShow) ;
  pDateIdealMax->Show(cmdShow) ;
  pDateRecommendMin->Show(cmdShow) ;
  pDateRecommendMax->Show(cmdShow) ;
  pDateAuthorizeMin->Show(cmdShow) ;
	pDateAuthorizeMax->Show(cmdShow) ;
}

void
ObjectifViewerDlg::ShowValue(int cmdShow)
{
  pValueIdealMin->Show(cmdShow) ;
  pValueIdealMax->Show(cmdShow) ;
  pValueRecommendMin->Show(cmdShow) ;
  pValueRecommendMax->Show(cmdShow) ;
  pValueAuthorizeMin->Show(cmdShow) ;
	pValueAuthorizeMax->Show(cmdShow) ;
}

//pos = 0 if left
//pos = 1 if right
void
ObjectifViewerDlg::getArrayNumControls(NSObjectifEditNum *pArray[6], int pos)
{
	if (pArray == NULL)
		return ;

	switch (pos)
	{
		case 0:
			pArray[5] = pPeriodAuthorizeMax ;
			pArray[4] = pPeriodRecommendMax ;
			pArray[3] = pPeriodIdealMax ;
			pArray[2] = pPeriodIdealMin ;
			pArray[1] = pPeriodRecommendMin ;
			pArray[0] = pPeriodAuthorizeMin ;
			break;

		case 1:
			pArray[5] = pValueAuthorizeMax ;
			pArray[4] = pValueRecommendMax ;
			pArray[3] = pValueIdealMax ;
			pArray[2] = pValueIdealMin ;
			pArray[1] = pValueRecommendMin ;
			pArray[0] = pValueAuthorizeMin ;
			break ;
	}
}

void
ObjectifViewerDlg::getArrayDateControls(NSObjectifEditDateHeure *pArray[6])
{
	if (pArray == NULL)
		return ;

	pArray[5] = pDateAuthorizeMax;
	pArray[4] = pDateRecommendMax;
	pArray[3] = pDateIdealMax;
	pArray[2] = pDateIdealMin;
	pArray[1] = pDateRecommendMin;
	pArray[0] = pDateAuthorizeMin;
}

void
ObjectifViewerDlg::CmCyclic()
{
  ShowDate(SW_HIDE) ;
  ShowPeriod(SW_SHOW) ;
  ShowLine(SW_SHOW) ;
  ShowValue(SW_SHOW);

  objectifType = CYCLE_OBJECTIF ;
  typeLeft = 1 ;
  getArrayNumControls(arrayLeftNumControls, LEFT);
  getArrayNumControls(arrayRightNumControls, RIGHT);

  TWindow::Invalidate();
}

void
ObjectifViewerDlg::CmPunctual()
{
  ShowDate(SW_SHOW) ;
  ShowPeriod(SW_HIDE) ;
  ShowValue(SW_SHOW) ;
  ShowLine(SW_SHOW) ;

  objectifType = ONE_OBJECTIF ;
  typeLeft = 2 ;

  getArrayDateControls(arrayLeftDateControls);
  getArrayNumControls(arrayRightNumControls, RIGHT);
  TWindow::Invalidate();
}

void
ObjectifViewerDlg::CmPermanent()
{
  ShowDate(SW_HIDE) ;
  ShowPeriod(SW_HIDE) ;
  ShowLine(SW_HIDE) ;
  ShowValue(SW_SHOW) ;

  typeLeft = 0 ;
  getArrayNumControls(arrayRightNumControls, RIGHT);
  objectifType = PERMANENT_OBJECTIF ;
  TWindow::Invalidate();
}

bool
ObjectifViewerDlg::hasControlValue(NSEditNum* pControl)
{
	if (!pControl || !(pControl->HWindow))
		return false ;

	char far val[40] ;
	pControl->GetText(val, 40) ;
	if (val && (string(val) != ""))
		return true ;
	return false ;
}

bool
ObjectifViewerDlg::hasControlValue(NSUtilEditDateHeure* pControl)
{
	if (!pControl || !(pControl->HWindow))
		return false ;

	string sDate;
	pControl->getDate(&sDate);
	if ((sDate != "") && (sDate != pControl->sMask) )
		return true ;
	return false ;
}

bool
ObjectifViewerDlg::hasControlValue(NSUtilLexique* pControl)
{
	if (!pControl || !(pControl->HWindow))
		return false ;

	if (pControl->sContenuTransfert != "")
		return true ;
	return false ;
}


/*void
ObjectifViewerDlg::getEditDateControlTree(NSUtilEditDateHeure* pControl, string codControl,
                                    NSPatPathoArray* pPatho, int col)
{
    char far val[40] ;
	pControl->GetText(val, 40) ;
    string sVal;
    pControl->getDate(&sVal);
    pPatho->ajoutePatho(codControl, col, 0) ;
    col++ ;
    pPatho->ajoutePatho("KDAT01", col, 0) ;
    col++ ;
    Message *pCodeMsg = new Message("", "", "", "A", "", "", "") ;

    pCodeMsg->SetUnit("2DA021") ;
    pCodeMsg->SetComplement(sVal) ;
    pPatho->ajoutePatho("�D0;10", pCodeMsg, col, 1) ;
    delete  pCodeMsg ;

}    */


/*void
ObjectifViewerDlg::getTreeCyclicObjectif(NSPatPathoArray* pPatho, int col)
{
    //TO DO KOUVR1 and KFERM1
    pPatho->ajoutePatho("1CYCL1", col, 0) ;
    //add period
    if( hasControlValue(pPeriodIdealMin) || hasControlValue(pPeriodIdealMax) ||
        hasControlValue(pPeriodRecommendMin) || hasControlValue(pPeriodRecommendMax) ||
        hasControlValue(pPeriodAuthorizeMin) || hasControlValue(pPeriodAuthorizeMax))
    {
        pPatho->ajoutePatho("KMOD01", col, 0) ;
        getPeriodTree(pPatho, col+1) ;
    }
    //add value
     if( hasControlValue(pValueIdealMin) || hasControlValue(pValueIdealMax) ||
        hasControlValue(pValueRecommendMin) || hasControlValue(pValueRecommendMax) ||
        hasControlValue(pValueAuthorizeMin) || hasControlValue(pValueAuthorizeMax))
    {
        pPatho->ajoutePatho("0ENVV1", col, 0) ;
        getValueTree(pPatho, col+1) ;
    }
}

void
ObjectifViewerDlg::getTreePunctualObjectif(NSPatPathoArray* pPatho, int col)
{
    //TO DO KOUVR1 and KFERM1
   //add period
    if( hasControlValue(pDateIdealMin) || hasControlValue(pDateIdealMax) ||
        hasControlValue(pDateRecommendMin) || hasControlValue(pDateRecommendMax) ||
        hasControlValue(pDateAuthorizeMin) || hasControlValue(pDateAuthorizeMax))
    {
        pPatho->ajoutePatho("KMOD01", col, 0) ;
        getDateTree(pPatho, col+1) ;
    }
    //add value
     if( hasControlValue(pValueIdealMin) || hasControlValue(pValueIdealMax) ||
        hasControlValue(pValueRecommendMin) || hasControlValue(pValueRecommendMax) ||
        hasControlValue(pValueAuthorizeMin) || hasControlValue(pValueAuthorizeMax))
    {
        pPatho->ajoutePatho("0ENVV1", col, 0) ;
        getValueTree(pPatho, col+1) ;
    }
}

void
ObjectifViewerDlg::getTreePermanentObjectif(NSPatPathoArray* pPatho, int col)
{

    pPatho->ajoutePatho("KPERM1", col, 0) ;
    //add value
    if( hasControlValue(pValueIdealMin) || hasControlValue(pValueIdealMax) ||
        hasControlValue(pValueRecommendMin) || hasControlValue(pValueRecommendMax) ||
        hasControlValue(pValueAuthorizeMin) || hasControlValue(pValueAuthorizeMax))
    {
        pPatho->ajoutePatho("0ENVV1", col, 0) ;
        getValueTree(pPatho, col+1) ;
    }
}
 */

bool
ObjectifViewerDlg::getPeriodData()
{
  string sPeriodUnitCode = pPeriodUnit->getSelCode() ;
  if ((sPeriodUnitCode == "") &&
      ((hasControlValue(pPeriodIdealMin))     || (hasControlValue(pPeriodIdealMax))     ||
       (hasControlValue(pPeriodRecommendMin)) || (hasControlValue(pPeriodRecommendMax)) ||
       (hasControlValue(pPeriodAuthorizeMin)) || (hasControlValue(pPeriodAuthorizeMax))))
  {
    string sErrorText = pContexte->getSuperviseur()->getText("goalsManagement", "mustUnitPeriod") ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
  }

  if (hasControlValue(pPeriodIdealMin))
  {
    pPeriodIdealMin->donneValeur() ;
    pObjectif->dDelaiDebutIdeal = pPeriodIdealMin->dValeur ;
    pObjectif->sUniteDebutIdeal = sPeriodUnitCode ;
  }
  else if ((pObjectif->dDelaiDebutIdeal > 0) || (pObjectif->sUniteDebutIdeal != ""))
  {
    pObjectif->dDelaiDebutIdeal = 0 ;
    pObjectif->sUniteDebutIdeal = "" ;
  }

  if (hasControlValue(pPeriodIdealMax))
  {
    pPeriodIdealMax->donneValeur() ;
    pObjectif->dDelaiDebutIdealMax = pPeriodIdealMax->dValeur ;
    pObjectif->sUniteDebutIdealMax = sPeriodUnitCode ;
  }
  else if ((pObjectif->dDelaiDebutIdealMax > 0) || (pObjectif->sUniteDebutIdealMax != ""))
  {
    pObjectif->dDelaiDebutIdealMax = 0 ;
    pObjectif->sUniteDebutIdealMax = "" ;
  }

  if (hasControlValue(pPeriodRecommendMin))
  {
    pPeriodRecommendMin->donneValeur() ;
    pObjectif->dDelaiDebutConseille = pPeriodRecommendMin->dValeur ;
    pObjectif->sUniteDebutConseille = sPeriodUnitCode ;
  }
  else if ((pObjectif->dDelaiDebutConseille > 0) || (pObjectif->sUniteDebutConseille != ""))
  {
    pObjectif->dDelaiDebutConseille = 0 ;
    pObjectif->sUniteDebutConseille = "" ;
  }

  if (hasControlValue(pPeriodRecommendMax))
  {
    pPeriodRecommendMax->donneValeur() ;
    pObjectif->dDelaiDebutConseilMax = pPeriodRecommendMax->dValeur ;
    pObjectif->sUniteDebutConseilMax = sPeriodUnitCode ;
  }
  else if ((pObjectif->dDelaiDebutConseilMax > 0) || (pObjectif->sUniteDebutConseilMax != ""))
  {
    pObjectif->dDelaiDebutConseilMax = 0 ;
    pObjectif->sUniteDebutConseilMax = "" ;
  }

  if (hasControlValue(pPeriodAuthorizeMin))
  {
    pPeriodAuthorizeMin->donneValeur() ;
    pObjectif->dDelaiDebutAutorise = pPeriodAuthorizeMin->dValeur ;
    pObjectif->sUniteDebutAutorise = sPeriodUnitCode ;
  }
  else if((pObjectif->dDelaiDebutAutorise > 0) || (pObjectif->sUniteDebutAutorise != ""))
  {
    pObjectif->dDelaiDebutAutorise = 0 ;
    pObjectif->sUniteDebutAutorise = "" ;
  }

  if (hasControlValue(pPeriodAuthorizeMax))
  {
    pPeriodAuthorizeMax->donneValeur() ;
    pObjectif->dDelaiDebutCritique = pPeriodAuthorizeMax->dValeur ;
    pObjectif->sUniteDebutCritique = sPeriodUnitCode ;
  }
  else if((pObjectif->dDelaiDebutCritique > 0) || (pObjectif->sUniteDebutCritique != ""))
  {
    pObjectif->dDelaiDebutCritique = 0 ;
    pObjectif->sUniteDebutCritique = "" ;
  }

  return true ;
}

bool
ObjectifViewerDlg::getValueData()
{
  string sValueUnitCode = pUnitValue->getCode() ;

  if ((sValueUnitCode == "") &&
      ((hasControlValue(pValueIdealMin))     || (hasControlValue(pValueIdealMax)) ||
       (hasControlValue(pValueRecommendMin)) || (hasControlValue(pValueRecommendMax)) ||
       (hasControlValue(pValueAuthorizeMin)) || (hasControlValue(pValueAuthorizeMax)) ))
  {
    string sErrorText = pContexte->getSuperviseur()->getText("goalsManagement", "mustUnitValue") ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
  }

  if (hasControlValue(pValueIdealMin))
  {
    pValueIdealMin->donneValeur() ;
    pObjectif->dValMinIdeal      = pValueIdealMin->dValeur ;
    pObjectif->sUniteValMinIdeal = sValueUnitCode ;
    pObjectif->bValMinIdeal      = true ;
  }
  else if (pObjectif->bValMinIdeal)
  {
    pObjectif->dValMinIdeal      = 0 ;
    pObjectif->sUniteValMinIdeal = "" ;
    pObjectif->bValMinIdeal      = false ;
  }

  if (hasControlValue(pValueIdealMax))
  {
    pValueIdealMax->donneValeur();
    pObjectif->dValMaxIdeal      = pValueIdealMax->dValeur ;
    pObjectif->sUniteValMaxIdeal = sValueUnitCode ;
    pObjectif->bValMaxIdeal      = true ;
  }
  else if(pObjectif->bValMaxIdeal)
  {
    pObjectif->dValMaxIdeal      = 0 ;
    pObjectif->sUniteValMaxIdeal = "" ;
    pObjectif->bValMaxIdeal      = false ;
  }

  if (hasControlValue(pValueRecommendMin))
  {
    pValueRecommendMin->donneValeur();
    pObjectif->dValMinConseille      = pValueRecommendMin->dValeur ;
    pObjectif->sUniteValMinConseille = sValueUnitCode ;
    pObjectif->bValMinConseille      = true ;
  }
  else if (pObjectif->bValMinConseille)
  {
    pObjectif->dValMinConseille      = 0 ;
    pObjectif->sUniteValMinConseille = "" ;
    pObjectif->bValMinConseille      = false ;
  }

  if (hasControlValue(pValueRecommendMax))
  {
    pValueRecommendMin->donneValeur();
    pObjectif->dValMaxConseille      = pValueRecommendMax->dValeur ;
    pObjectif->sUniteValMaxConseille = sValueUnitCode ;
    pObjectif->bValMaxConseille      = true ;
  }
  else if (pObjectif->bValMaxConseille)
  {
    pObjectif->dValMaxConseille      = 0 ;
    pObjectif->sUniteValMaxConseille = "" ;
    pObjectif->bValMaxConseille      = false ;
  }

  if (hasControlValue(pValueAuthorizeMin))
  {
    pValueAuthorizeMin->donneValeur() ;
    pObjectif->dValMinAutorise      = pValueAuthorizeMin->dValeur ;
    pObjectif->sUniteValMinAutorise = sValueUnitCode ;
    pObjectif->bValMinAutorise      = true ;
  }
  else if (pObjectif->bValMinAutorise)
  {
    pObjectif->dValMinAutorise      = 0 ;
    pObjectif->sUniteValMinAutorise = "" ;
    pObjectif->bValMinAutorise      = false ;
  }

  if (hasControlValue(pValueAuthorizeMax))
  {
    pValueAuthorizeMax->donneValeur() ;
    pObjectif->dValMaxAutorise      = pValueAuthorizeMax->dValeur ;
    pObjectif->sUniteValMaxAutorise = sValueUnitCode ;
    pObjectif->bValMaxAutorise      = true ;
  }
  else if (pObjectif->bValMaxAutorise)
  {
    pObjectif->dValMaxAutorise      = 0 ;
    pObjectif->sUniteValMaxAutorise = "" ;
    pObjectif->bValMaxAutorise      = false ;
  }

  return true ;
}


void
ObjectifViewerDlg::getDateData()
{
    string sDate;
    if(hasControlValue(pDateIdealMin))
    {
        pDateIdealMin->getDate(&sDate);
        pObjectif->sDateDebutIdeal = sDate ;//completeData(sDate, pDateIdealMin);
    }
    else if(pObjectif->sDateDebutIdeal != "")
        pObjectif->sDateDebutIdeal = "";

    if(hasControlValue(pDateIdealMax))
    {
        pDateIdealMax->getDate(&sDate);
        pObjectif->sDateDebutIdealMax  = sDate ; //completeData(sDate, pDateIdealMax);
    }
    else if(pObjectif->sDateDebutIdealMax != "")
        pObjectif->sDateDebutIdealMax = "";
    if(hasControlValue(pDateRecommendMin))
    {
        pDateRecommendMin->getDate(&sDate);
        pObjectif->sDateDebutConseille = sDate ;//completeData(sDate, pDateRecommendMin);
    }
    else if(pObjectif->sDateDebutConseille != "")
        pObjectif->sDateDebutConseille = "";
    if(hasControlValue(pDateRecommendMax))
    {
        pDateRecommendMax->getDate(&sDate);
        pObjectif->sDateDebutConseilMax = sDate ; //completeData(sDate, pDateRecommendMax);
    }
    else if(pObjectif->sDateDebutConseilMax != "")
        pObjectif->sDateDebutConseilMax = "";
    if(hasControlValue(pDateAuthorizeMin))
    {
        pDateAuthorizeMin->getDate(&sDate);
        pObjectif->sDateDebutAutorise = sDate ; //completeData(sDate, pDateAuthorizeMin);
    }
    else if(pObjectif->sDateDebutAutorise != "")
        pObjectif->sDateDebutAutorise = "";
    if(hasControlValue(pDateAuthorizeMax))
    {
        pDateAuthorizeMax->getDate(&sDate);
        pObjectif->sDateDebutCritique = sDate ; //completeData(sDate, pDateAuthorizeMax);
    }
    else if(pObjectif->sDateDebutCritique != "")
        pObjectif->sDateDebutCritique = "";
}

void
ObjectifViewerDlg::getDataOpenMoment()
{
    if(hasControlValue(pStartDate))
    {
        string sVal;
        pStartDate->getDate(&sVal);
        pObjectif->tDateOuverture.initFromDate(sVal) ;
    }
    else
        if(!pObjectif->tDateOuverture.estVide())
            pObjectif->tDateOuverture.init();
    else
        //apres un eveniment
        if(hasControlValue(pStartEveniment))
        {
             pObjectif->sOpenEventNode = pStartEveniment->getCode() ;
        }
        else
            if( pObjectif->sOpenEventNode != "")
                pObjectif->sOpenEventNode = "";
}

void
ObjectifViewerDlg::getDataCloseMoment()
{
  if (hasControlValue(pEndDate))
  {
    string sVal ;
    pEndDate->getDate(&sVal) ;
    pObjectif->tDateFermeture.initFromDate(sVal) ;
  }
  else
    //apres un eveniment
    if (hasControlValue(pEndEveniment))
    {
      pObjectif->sCloseEventNode = pEndEveniment->getCode() ;
    }
    else
      pObjectif->tDateFermeture.setNoLimit() ;
}

/*void
ObjectifViewerDlg::getValueTree (NSPatPathoArray* pPatho, int iChildCol)
{
    string sValueUnitCode   = pUnitValue->getCode();
    if(hasControlValue(pValueIdealMin))
        getEditNumControlTree(pValueIdealMin, "VMIN01", pPatho, iChildCol, sValueUnitCode) ;
    if(hasControlValue(pValueIdealMax))
        getEditNumControlTree(pValueIdealMin, "VMAX01", pPatho, iChildCol, sValueUnitCode) ;
    if(hasControlValue(pValueRecommendMin))
        getEditNumControlTree(pValueRecommendMin, "VMIN11", pPatho, iChildCol, sValueUnitCode) ;
    if(hasControlValue(pValueRecommendMax))
        getEditNumControlTree(pValueRecommendMax, "VMAX11", pPatho, iChildCol, sValueUnitCode) ;
    if(hasControlValue(pValueAuthorizeMin))
        getEditNumControlTree(pValueAuthorizeMin, "VMIN21", pPatho, iChildCol, sValueUnitCode) ;
    if(hasControlValue(pValueAuthorizeMax))
        getEditNumControlTree(pValueAuthorizeMax, "VMAX21", pPatho, iChildCol, sValueUnitCode) ;
} */


/*void
ObjectifViewerDlg::getDateTree(NSPatPathoArray* pPatho, int colonne)
{
    int iChildCol = colonne + 1;

    if(hasControlValue(pDateIdealMin))
        getEditDateControlTree(pDateIdealMin, "KMOD11", pPatho, iChildCol) ;
    if(hasControlValue(pDateIdealMax))
        getEditDateControlTree(pDateIdealMin, "KMOD21", pPatho, iChildCol) ;
    if(hasControlValue(pDateRecommendMin))
        getEditDateControlTree(pDateRecommendMin, "KMOD31", pPatho, iChildCol) ;
    if(hasControlValue(pDateRecommendMax))
        getEditDateControlTree(pDateRecommendMax, "KMOD41", pPatho, iChildCol) ;
    if(hasControlValue(pDateAuthorizeMin))
        getEditDateControlTree(pDateAuthorizeMin, "KMOD51", pPatho, iChildCol) ;
    if(hasControlValue(pDateAuthorizeMax))
        getEditDateControlTree(pDateAuthorizeMax, "KMOD61", pPatho, iChildCol) ;
}  */


/*void
ObjectifViewerDlg::getTreeOpenMoment(NSPatPathoArray* pPatho, int colonne)
{
    pPatho->ajoutePatho("KOUVR1", colonne, 0) ;
    //date de debut
    if(hasControlValue(pStartDate))
    {
        string sVal;
        pStartDate->getDate(&sVal);
        Message *pCodeMsg = new Message("", "", "", "A", "", "", "") ;
        pCodeMsg->SetUnit("2DA021") ;
        pCodeMsg->SetComplement(sVal) ;
        pPatho->ajoutePatho("�D0;10", pCodeMsg, colonne++, 1) ;
        delete  pCodeMsg;
    }
    else
        //apres un eveniment
        if(hasControlValue(pStartEveniment))
        {
             pPatho->ajoutePatho("KEVOU1", colonne++, 1) ;
             pPatho->ajoutePatho(pStartEveniment->getCode(), colonne++, 1) ;
        }
} */

/*void
ObjectifViewerDlg::getTreeCloseMoment(NSPatPathoArray* pPatho, int colonne)
{

    //date de debut
    if(hasControlValue(pEndDate))
    {
        pPatho->ajoutePatho("KFERM1", colonne, 0) ;
        string sVal;
        pEndDate->getDate(&sVal);
        Message *pCodeMsg = new Message("", "", "", "A", "", "", "") ;
        pCodeMsg->SetUnit("2DA021") ;
        pCodeMsg->SetComplement(sVal) ;
        pPatho->ajoutePatho("�D0;10", pCodeMsg, colonne++, 1) ;
        delete  pCodeMsg;
    }
    else
        //apres un eveniment
        if(hasControlValue(pStartEveniment))
        {
             pPatho->ajoutePatho("KFERM1", colonne, 0) ;
             pPatho->ajoutePatho("KEVFE1", colonne++, 1) ;
             pPatho->ajoutePatho(pStartEveniment->getCode(), colonne++, 1) ;
        }
}   */

void
ObjectifViewerDlg::CmOk()
{
  pObjectif->sLexique = pObjectifLexicon->getCode() ;

  if (pPresence->GetCheck() == BF_CHECKED)
    pObjectif->sCertitude = "" ;
  else if (pAbsence->GetCheck() == BF_CHECKED)
    pObjectif->sCertitude = "WCE001" ;

  char far val[200] ;
	pComplement->GetText(val, 200) ;
  if(val && (string(val) != ""))
  {
    pObjectif->sComplementText = string(val) ;
  }

  getDataOpenMoment() ;
  switch (objectifType)
  {
    case ONE_OBJECTIF :
      //traitment one obj
      if (!getValueData())
        return ;
      getDateData() ;
      pObjectif->iRythme = NSLdvGoal::ponctuel ;
      break ;

    case CYCLE_OBJECTIF :      if (!getPeriodData())        return ;      if (!getValueData())        return ;      pObjectif->iRythme = NSLdvGoal::cyclic ;      break ;
    case PERMANENT_OBJECTIF :
      if (!getValueData())
        return ;
      pObjectif->iRythme = NSLdvGoal::permanent ;
      break ;
  }

  getDataCloseMoment() ;
  TDialog::CmOk() ;
}

void
ObjectifViewerDlg::CmCancel()
{
  TDialog::CmCancel() ;
}

void
ObjectifViewerDlg::EvClose()
{
  TDialog::EvClose() ;
}

void
ObjectifViewerDlg::EvPaint()
{
  TPaintDC Dc(*this) ;
  NS_CLASSLIB::TRect& rect = *(NS_CLASSLIB::TRect*)&Dc.Ps.rcPaint ;
  TDialog::Paint(Dc, false, rect) ;
  Paint(Dc, false, rect) ;
}

void
ObjectifViewerDlg::Paint(TDC& pDc, bool /* erase */, NS_CLASSLIB::TRect& /* RectAPeindre */)
{
  int iAncDC = pDc.SaveDC() ;
  // bool paintLeft = false ;
  // bool paintRight = false ;

  NS_CLASSLIB::TPoint ptTopLeft, ptBottomRight ;
  //centre
  ptTopLeft.x = 229 ;
  ptTopLeft.y = 232 ;
  ptBottomRight.x = 251 ;
  ptBottomRight.y = 256 ;
  initColorControlRect(&pDc, ptTopLeft, ptBottomRight ) ;
  //color utils
  // TColor*  pCurrentColor   = &NS_CLASSLIB::TColor::LtRed ;
  // TColor*  pCentreColor ;

  switch (objectifType)
  {
        case ONE_OBJECTIF :      //date + value
            ptTopLeft.x = 40 ;
            ptTopLeft.y = 400 ;
            ptBottomRight.x = 60 ;
            ptBottomRight.y = 400 ;
            repaintColorBar(&pDc, arrayLeftDateControls, ptTopLeft, ptBottomRight);

            ptTopLeft.x = 420;
            ptTopLeft.y = 400;
            ptBottomRight.x = 440 ;
            ptBottomRight.y = 400 ;
            repaintColorBar(&pDc, arrayRightNumControls, ptTopLeft, ptBottomRight) ;
            break;

        case CYCLE_OBJECTIF :      //period + value            ptTopLeft.x = 40 ;            ptTopLeft.y = 400 ;
            ptBottomRight.x = 60 ;
            ptBottomRight.y = 400 ;
            repaintColorBar(&pDc, arrayLeftNumControls, ptTopLeft, ptBottomRight) ;            ptTopLeft.x = 420 ;            ptTopLeft.y = 400 ;
            ptBottomRight.x = 440 ;
            ptBottomRight.y = 400 ;
            repaintColorBar(&pDc, arrayRightNumControls, ptTopLeft, ptBottomRight) ;            break;
        case PERMANENT_OBJECTIF :   //only value
            ptTopLeft.x = 420 ;
            ptTopLeft.y = 400 ;
            ptBottomRight.x = 440 ;
            ptBottomRight.y = 400 ;
            repaintColorBar(&pDc, arrayRightNumControls, ptTopLeft, ptBottomRight) ;
            break;
	}
	pDc.RestoreDC(iAncDC) ;
}

void
ObjectifViewerDlg::repaintColorBar(TDC* pDc, NSObjectifEditNum** arrayControls, NS_CLASSLIB::TPoint ptInitTopLeft, NS_CLASSLIB::TPoint ptInitBottomRight)
{
	if (!arrayControls || !pDc)
		return ;

	TColor*  pCurrentColor   = &NS_CLASSLIB::TColor::LtRed ;
	TColor*  pCentreColor ;
	NS_CLASSLIB::TPoint ptTopLeft, ptBottomRight ;
	ptTopLeft.x = ptInitTopLeft.x ;
	ptBottomRight.x = ptInitBottomRight.x ;

  // The only possible algoritm is to define the center color (hearth)
	// then move up from there, using existing values as color transitions
  // then start again from the center and go down (in the same way we went up)

  //
  // looking for center color
	// il faut trouver la couleur du coeur
  //
	if ((hasControlValue(arrayControls[2])) || (hasControlValue(arrayControls[3])))
		pCentreColor = &NS_CLASSLIB::TColor::LtBlue ;
	else
		if ((hasControlValue(arrayControls[1])) || (hasControlValue(arrayControls[4])))
			pCentreColor = &NS_CLASSLIB::TColor::LtGreen ;
		else
		{
			if ((hasControlValue(arrayControls[0])) || (hasControlValue(arrayControls[5])))
				pCentreColor   = &NS_CLASSLIB::TColor::LtYellow ;
			else
				return ;
		}

	ColorRect *allRect[7] ;
	for (int i = 0 ; i < 7 ; i++)
		allRect[i] = NULL ;

	// set heart's color
	//
	ptTopLeft.y = ptInitTopLeft.y - 4*24;
	ptBottomRight.y = ptInitBottomRight.y - 24*3;
	allRect[3] = new ColorRect(ptTopLeft, ptBottomRight, pCentreColor);
  //
	// all rects towards top
  //
	pCurrentColor = pCentreColor;
	for (int i = 3 ; i < 6 ; i++)
	{
		ptTopLeft.y = ptInitTopLeft.y - 24*(i+2);
		ptBottomRight.y = ptInitBottomRight.y - 24*(i+1);
		if (hasControlValue(arrayControls[i]))
			pCurrentColor = arrayControls[i]->brushColorForward;
		allRect[i+1] = new ColorRect(ptTopLeft, ptBottomRight, pCurrentColor) ;
	}
	//
	// all rects towards bottom
	//
	pCurrentColor = pCentreColor;
	for (int i = 2 ; i > -1 ; i--)
	{
		ptTopLeft.y = ptInitTopLeft.y - 24*(i+1) ;
		ptBottomRight.y = ptInitBottomRight.y - 24*i;
		if (hasControlValue(arrayControls[i]))
			pCurrentColor = arrayControls[i]->brushColorBack;
		allRect[i] = new ColorRect(ptTopLeft, ptBottomRight, pCurrentColor);
	}

	for (int i = 0; i < 7 ; i++)
	{
		allRect[i]->RectFillWithDefaultColor(pDc) ;
    delete allRect[i] ;
	}
}


void
ObjectifViewerDlg::repaintColorBar(TDC* pDc, NSObjectifEditDateHeure** arrayControls,
                    NS_CLASSLIB::TPoint ptInitTopLeft, NS_CLASSLIB::TPoint ptInitBottomRight)
{
    if(!arrayControls)
        return;
    NS_CLASSLIB::TPoint ptTopLeft, ptBottomRight ;
    ptTopLeft.x = ptInitTopLeft.x ;
    ptBottomRight.x = ptInitBottomRight.x ;

    TColor*  pCurrentColor   = &NS_CLASSLIB::TColor::LtRed ;
    TColor*  pCentreColor ;


    //il faut trouver la couleur du coeur
    if( (hasControlValue(arrayControls[2])) || (hasControlValue(arrayControls[3])) )
    {
        pCentreColor   = &NS_CLASSLIB::TColor::LtBlue ;
    }
    else
        if( (hasControlValue(arrayControls[1])) || (hasControlValue(arrayControls[4])) )
        {
            pCentreColor   = &NS_CLASSLIB::TColor::LtGreen ;
        }
        else
        {
            if( (hasControlValue(arrayControls[0])) || (hasControlValue(arrayControls[5])) )
                pCentreColor   = &NS_CLASSLIB::TColor::LtYellow ;
            else
                return;
        }
    //set the centre
    ColorRect *allRect[7];
    ptTopLeft.y = ptInitTopLeft.y - 4*24;
    ptBottomRight.y = ptInitBottomRight.y - 24*3;
    allRect[3] = new ColorRect(ptTopLeft, ptBottomRight, pCentreColor);
    //all rect towards top
    pCurrentColor = pCentreColor;
    for(int i=3; i<6;i++)
    {
        ptTopLeft.y = ptInitTopLeft.y - 24*(i+2);
        ptBottomRight.y = ptInitBottomRight.y - 24*(i+1);
        if(hasControlValue(arrayControls[i]))
        {
            pCurrentColor = arrayControls[i]->brushColorForward;
        }
        allRect[i+1] = new ColorRect(ptTopLeft, ptBottomRight, pCurrentColor);
    }
    //all rect towards bottom
    pCurrentColor = pCentreColor;
    for(int i=2; i>-1;i--)
    {
        ptTopLeft.y = ptInitTopLeft.y - 24*(i+1);
        ptBottomRight.y = ptInitBottomRight.y - 24*i;
        if(hasControlValue(arrayControls[i]))
        {
            pCurrentColor = arrayControls[i]->brushColorBack;
        }
        allRect[i] = new ColorRect(ptTopLeft, ptBottomRight, pCurrentColor);
    }
    for(int i=0; i<7; i++)
    {
        allRect[i]->RectFillWithDefaultColor(pDc );
        delete allRect[i] ;
    }

}

/*bool
ObjectifViewerDlg::testDraw(NSObjectifEditNum*  arrayControls[6])
{
    bool  blueHeartMin      = false;
    bool  blueHeartMax      = false;
    bool  greenHeartMin     = false;
    bool  greenHeartMax     = false;
    bool  yellowHeartMin    = false;
    bool  yellowHeartMax    = false;

    for(int i=0; i<6; i++)
    {
        char far val[40] ;
	    arrayControls[i]->GetText(val, 40) ;
        if(string(val) != "")
        {
            switch(i)
            {
                case 0  :
                    yellowHeartMin = true ;
                    break;
                case 1  :
                    greenHeartMin = true ;
                    break;
                case 2  :
                    blueHeartMin = true ;
                    break;
                case 3  :
                    blueHeartMax = true ;
                    break;
                case 4  :
                    greenHeartMax = true ;
                    break;
                case 5  :
                    yellowHeartMax = true ;
                    break;
            }
        }
    }
    bool res =((yellowHeartMin && yellowHeartMax) || (greenHeartMax && greenHeartMin) ||
                    (blueHeartMax && blueHeartMin)) ;
    return  res;
}

bool
ObjectifViewerDlg::testDraw(NSObjectifEditDateHeure**  arrayControls)
{
    bool  blueHeartMin      = false;
    bool  blueHeartMax      = false;
    bool  greenHeartMin     = false;
    bool  greenHeartMax     = false;
    bool  yellowHeartMin    = false;
    bool  yellowHeartMax    = false;

    for(int i=0; i<6; i++)
    {
        string sVal = "";
        arrayControls[i]->getDate(&sVal) ;
        if(sVal != "00/00/0000 00:00:00")
        {
            switch(i)
            {
                case 0  :
                    yellowHeartMin = true ;
                    break;
                case 1  :
                    greenHeartMin = true ;
                    break;
                case 2  :
                    blueHeartMin = true ;
                    break;
                case 3  :
                    blueHeartMax = true ;
                    break;
                case 4  :
                    greenHeartMax = true ;
                    break;
                case 5  :
                    yellowHeartMax = true ;
                    break;
            }
        }
    }
    return  ((yellowHeartMin && yellowHeartMax) || (greenHeartMax && greenHeartMin) ||
                    (blueHeartMax && blueHeartMin)) ;
}  */

void
ObjectifViewerDlg::initColorControlRect( TDC *pDc, NS_CLASSLIB::TPoint ptTopLeft, NS_CLASSLIB::TPoint ptBottomRight )
{
    ColorRect* pColorRect = new ColorRect(ptTopLeft, ptBottomRight);
    for(int i=1; i<=7; i++)
    {
        if((i==1)||(i==7))
            pColorRect->RectFill(pDc, NS_CLASSLIB::TColor::LtRed) ;
        else
            if((i==2)||(i==6))
                pColorRect->RectFill(pDc, NS_CLASSLIB::TColor::LtYellow) ;
            else
                if((i==3)||(i==5))
                    pColorRect->RectFill(pDc, NS_CLASSLIB::TColor::LtGreen) ;
                else
                    pColorRect->RectFill(pDc, NS_CLASSLIB::TColor::LtBlue) ;

        ptTopLeft.y = ptBottomRight.y ;
        ptBottomRight.y =  ptBottomRight.y + 24;
        pColorRect->SetRect( ptTopLeft, ptBottomRight);
    }
    delete  pColorRect;
}

//on paint in pCurrentColor tous les rectangles depuis lastPaintedRect
//jusqu'a current rectangle
//rect = 0(centre), 1(gauche), 2(droit)
void
ObjectifViewerDlg::ColorControlRect(int rect, NSObjectifEditNum *lastActivEdit,
                                TColor* pCurrentColor, int lastPaintedRect)
{
    NS_CLASSLIB::TPoint ptTopLeft, ptBottomRight ;

    ptTopLeft.y = 343 ;
    ptBottomRight.y = 343 - 24 ;
    switch( rect )
    {
        case 1 :
                ptTopLeft.x = 20;
                ptBottomRight.x = 38 ;
                break;
        case 2 :
                ptTopLeft.x = 360;
                ptBottomRight.x = 378 ;
                break;

    }
    TWindowDC* pWinDC = new TWindowDC(HWindow); // HWnd

    int listPos = lastActivEdit->posInObjectControlList ;
    for(int i = lastPaintedRect ; i<=listPos; i++)
    {
        ptBottomRight.y = 343 - 24*i ;
        TBrush* pBrush = new TBrush(*pCurrentColor) ;
        pWinDC->FillRect(NS_CLASSLIB::TRect(ptTopLeft, ptBottomRight), *pBrush) ;
        delete pBrush;
    }

    delete pWinDC;
    
}


ColorRect::ColorRect( NS_CLASSLIB::TPoint topLeft, NS_CLASSLIB::TPoint bottomRight,  NS_CLASSLIB::TColor* color )
{
    ptTopLeft = topLeft;
    ptBottomRight = bottomRight;
    defaultColor = color;
}

ColorRect::ColorRect( NS_CLASSLIB::TPoint topLeft, NS_CLASSLIB::TPoint bottomRight )
{
    ptTopLeft = topLeft;
    ptBottomRight = bottomRight;
}

void
ColorRect::SetRect( NS_CLASSLIB::TPoint topLeft, NS_CLASSLIB::TPoint bottomRight )
{
    ptTopLeft = topLeft;
    ptBottomRight = bottomRight;
}

void
ColorRect::RectFill(TDC *pDc, const  NS_CLASSLIB::TColor& color)
{
     TBrush* pBrush = new TBrush(color) ;
     pDc->FillRect(ptTopLeft.x, ptTopLeft.y, ptBottomRight.x, ptBottomRight.y, *pBrush);
     delete pBrush;
}

void
ColorRect::RectFillWithDefaultColor(TDC *pDc)
{
    TBrush* pBrush = new TBrush(*defaultColor) ;
    pDc->FillRect(ptTopLeft.x, ptTopLeft.y, ptBottomRight.x, ptBottomRight.y, *pBrush);
    delete pBrush;
}

//------------------------------------------------------------------------------
//                          NSObjectifEditNum
//------------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSObjectifEditNum, NSEditNum)
	EV_WM_KILLFOCUS,
END_RESPONSE_TABLE;

NSObjectifEditNum::NSObjectifEditNum(NSContexte *pCtx, ObjectifViewerDlg* pUtilDialog, int resId, int listPos,
                 NS_CLASSLIB::TColor* forwardColor,  NS_CLASSLIB::TColor* backColor, int iTextLen, int iDecimales, string sValidator)
                  :NSEditNum(pCtx, pUtilDialog, resId, iTextLen, iDecimales, sValidator)
{
    pParent = pUtilDialog ;
    iValue = 0 ;
    brushColorForward = forwardColor ;
    brushColorBack = backColor ;
    posInObjectControlList = listPos ;
}


NSObjectifEditNum::~NSObjectifEditNum()
{

}

void
NSObjectifEditNum::EvKillFocus(HWND hWndGetFocus)
{
	NSEditNum::EvKillFocus(hWndGetFocus);
    pParent->TWindow::Invalidate();
}

void
NSObjectifEditNum::SetIntIntoEditNum(int iVal)
{
	char sVal[10] ;
	itoa(iVal, sVal, 10) ;
	sContenuTransfert = string (sVal) ;
	donneBrut() ;
	SetText(sContenuBrut.c_str()) ;
}

void
NSObjectifEditNum::SetDoubleIntoEditNum(double dVal)
{
	sContenuTransfert = DoubleToString(&dVal, -1, -1) ;
	donneBrut() ;
	SetText(sContenuBrut.c_str()) ;
}

//------------------------------------------------------------------------------
//                          NSObjectifEditDateHeure
//------------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSObjectifEditDateHeure, NSUtilEditDateHeure)
	EV_WM_KILLFOCUS,
END_RESPONSE_TABLE;

NSObjectifEditDateHeure::NSObjectifEditDateHeure(NSContexte *pCtx, ObjectifViewerDlg* pNSUtilDialog, int resId,
                 NS_CLASSLIB::TColor* forwardColor,  NS_CLASSLIB::TColor* backColor, UINT iTextLen, bool b2000)
                        :NSUtilEditDateHeure(pCtx, pNSUtilDialog, resId, iTextLen, b2000)
{
  pParent = pNSUtilDialog ;
  brushColorForward = forwardColor ;
  brushColorBack    = backColor ;
}


NSObjectifEditDateHeure::~NSObjectifEditDateHeure()
{
}

void
NSObjectifEditDateHeure::EvKillFocus(HWND hWndGetFocus)
{
	TEdit::EvKillFocus(hWndGetFocus) ;
  pParent->TWindow::Invalidate() ;
}

