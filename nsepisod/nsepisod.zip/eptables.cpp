// -----------------------------------------------------------------------------//    EPTABLES.CPP
//    NAUTILUS juillet 2001
//
//    Impl�mentation des objets de base de donn�e
// -----------------------------------------------------------------------------

#include <cstring.h>

//#include "nautilus\nssuper.h"
#include <fstream.h>
#include "nsepisod\eptables.h"
#include "nssavoir\nspatbas.h"

#include "nautilus\nssuper.h"

// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes NSEpiContact
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiContactData::NSEpiContactData()
{
	// Met les champs de donn�es � z�ro
	metAZero() ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiContactData::NSEpiContactData(NSEpiContactData& rv)
{
	strcpy(patient, 		  rv.patient) ;
	strcpy(code,  		    rv.code) ;
	strcpy(dateHeureDeb, 	rv.dateHeureDeb) ;
	strcpy(dateHeureFin,  rv.dateHeureFin) ;
	strcpy(session,  		  rv.session) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiContactData::~NSEpiContactData()
{
}


// -----------------------------------------------------------------------------
// Op�rateur =
// -----------------------------------------------------------------------------
NSEpiContactData&
NSEpiContactData::operator=(NSEpiContactData src)
{
  if (this == &src)
    return *this ;

	strcpy(patient, 		  src.patient) ;
	strcpy(code,  		    src.code) ;
	strcpy(dateHeureDeb, 	src.dateHeureDeb) ;
	strcpy(dateHeureFin,  src.dateHeureFin) ;
	strcpy(session,  		  src.session) ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiContactData::operator==(const NSEpiContactData& o)
{
	if ((strcmp(patient, o.patient) == 0) &&
      (strcmp(code,    o.code)    == 0))
		return 1 ;
	else
		return 0 ;
}

// -----------------------------------------------------------------------------
// Met � z�ro les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiContactData::metAZero()
{
	// Met les champs de donn�es � z�ro
	memset(patient, 	  	0, CONTACT_PATIENT_LEN + 1) ;
	memset(code,   		    0, CONTACT_CODE_LEN + 1) ;
	memset(dateHeureDeb, 	0, CONTACT_DATEHEURE_DEB_LEN + 1) ;
	memset(dateHeureFin,  0, CONTACT_DATEHEURE_FIN_LEN + 1) ;
	memset(session,  		  0, CONTACT_SESSION_LEN + 1) ;
}

// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiContact::NSEpiContact(NSContexte *pCtx)
  : NSEpiContactInfo(),
    NSFiche(pCtx)
{
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiContact::NSEpiContact(NSEpiContact& rv)
  : NSEpiContactInfo(rv),
    NSFiche(rv.pContexte)
{
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiContact::~NSEpiContact()
{
}


// -----------------------------------------------------------------------------
// Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiContact::alimenteFiche()
{
  alimenteChamp(pDonnees->patient, 	    CONTACT_PATIENT_FIELD,  	    CONTACT_PATIENT_LEN) ;
  alimenteChamp(pDonnees->code, 		    CONTACT_CODE_FIELD, 	        CONTACT_CODE_LEN) ;
  alimenteChamp(pDonnees->dateHeureDeb, CONTACT_DATEHEURE_DEB_FIELD,  CONTACT_DATEHEURE_DEB_LEN) ;
  alimenteChamp(pDonnees->dateHeureFin, CONTACT_DATEHEURE_FIN_FIELD,  CONTACT_DATEHEURE_FIN_LEN) ;
  alimenteChamp(pDonnees->session,  	  CONTACT_SESSION_FIELD, 	      CONTACT_SESSION_LEN) ;
}


// -----------------------------------------------------------------------------
// Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSEpiContact::videFiche()
{
	videChamp(pDonnees->patient, 	    CONTACT_PATIENT_FIELD,  	    CONTACT_PATIENT_LEN) ;
  videChamp(pDonnees->code, 		    CONTACT_CODE_FIELD, 	        CONTACT_CODE_LEN) ;
  videChamp(pDonnees->dateHeureDeb, CONTACT_DATEHEURE_DEB_FIELD,  CONTACT_DATEHEURE_DEB_LEN) ;
  videChamp(pDonnees->dateHeureFin, CONTACT_DATEHEURE_FIN_FIELD,  CONTACT_DATEHEURE_FIN_LEN) ;
  videChamp(pDonnees->session,  	  CONTACT_SESSION_FIELD, 	      CONTACT_SESSION_LEN) ;
}


// -----------------------------------------------------------------------------
// Ouvre la table primaire et les index secondaires
// -----------------------------------------------------------------------------
DBIResult
NSEpiContact::open()
{
	char tableName[] = "CONTACT.DB" ;

	// Appelle la fonction open() de la classe de base pour ouvrir l'index primaire
  lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL) ;
	return(lastError) ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiContact::Create()
{
	return true ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiContact::Modify()
{
	return true ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiContact&
NSEpiContact::operator=(NSEpiContact src)
{
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiContact::operator==(const NSEpiContact& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
// Constructeur par d�faut
// -----------------------------------------------------------------------------
NSEpiContactInfo::NSEpiContactInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiContactData() ;
}


// -----------------------------------------------------------------------------
// Constructeur � partir d'un NSEpiContact
// -----------------------------------------------------------------------------
NSEpiContactInfo::NSEpiContactInfo(NSEpiContact *pContact)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiContactData() ;

	// Copie les valeurs du NSEpiContact
	*pDonnees = *(pContact->pDonnees) ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiContactInfo::NSEpiContactInfo(NSEpiContactInfo& rv)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiContactData() ;

	// Copie les valeurs du NSEpiContactInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiContactInfo::~NSEpiContactInfo()
{
	delete pDonnees ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiContactInfo&
NSEpiContactInfo::operator=(NSEpiContactInfo src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiContactInfo::operator==(const NSEpiContactInfo& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes NSEpiContElmt
//
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiContElmtData::NSEpiContElmtData()
{
	// Met les champs de donn�es � z�ro
	metAZero() ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiContElmtData::NSEpiContElmtData(NSEpiContElmtData& rv)
{
	strcpy(contact, 	rv.contact) ;
	strcpy(code,  		rv.code) ;
	strcpy(preoccup,  rv.preoccup) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiContElmtData::~NSEpiContElmtData()
{
}


// -----------------------------------------------------------------------------
// Op�rateur =
// -----------------------------------------------------------------------------
NSEpiContElmtData&
NSEpiContElmtData::operator=(NSEpiContElmtData src)
{
  if (this == &src)
    return *this ;

	strcpy(contact, 	src.contact) ;
	strcpy(code,  		src.code) ;
	strcpy(preoccup,  src.preoccup) ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiContElmtData::operator==(const NSEpiContElmtData& o)
{
	if ((strcmp(contact, o.contact) == 0) &&
      (strcmp(code,    o.code)    == 0))
		return 1 ;
	else
		return 0 ;
}

// -----------------------------------------------------------------------------
// Met � z�ro les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiContElmtData::metAZero()
{
	// Met les champs de donn�es � z�ro
	memset(contact, 	0, CONTELMT_CONTACT_LEN + 1) ;
	memset(code,   		0, CONTELMT_CODE_LEN + 1) ;
	memset(preoccup, 	0, CONTELMT_PREOCCUP_LEN + 1) ;
}


// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiContElmt::NSEpiContElmt(NSContexte *pCtx)
  : NSEpiContElmtInfo(),
    NSFiche(pCtx)
{
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiContElmt::NSEpiContElmt(NSEpiContElmt& rv)
  : NSEpiContElmtInfo(rv),
    NSFiche(rv.pContexte)
{
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiContElmt::~NSEpiContElmt()
{
}


// -----------------------------------------------------------------------------
// Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiContElmt::alimenteFiche()
{
  alimenteChamp(pDonnees->contact,  CONTELMT_CONTACT_FIELD,   CONTELMT_CONTACT_LEN) ;
  alimenteChamp(pDonnees->code, 	  CONTELMT_CODE_FIELD, 	    CONTELMT_CODE_LEN) ;
  alimenteChamp(pDonnees->preoccup, CONTELMT_PREOCCUP_FIELD,  CONTELMT_PREOCCUP_LEN) ;
}


// -----------------------------------------------------------------------------
// Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSEpiContElmt::videFiche()
{
	videChamp(pDonnees->contact,  CONTELMT_CONTACT_FIELD,   CONTELMT_CONTACT_LEN) ;
  videChamp(pDonnees->code, 	  CONTELMT_CODE_FIELD, 	    CONTELMT_CODE_LEN) ;
  videChamp(pDonnees->preoccup, CONTELMT_PREOCCUP_FIELD,  CONTELMT_PREOCCUP_LEN) ;
}


// -----------------------------------------------------------------------------
// Ouvre la table primaire et les index secondaires
// -----------------------------------------------------------------------------
DBIResult
NSEpiContElmt::open()
{
	char tableName[] = "CON_ELMT.DB" ;

	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL) ;
  return (lastError) ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiContElmt::Create()
{
	return true ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiContElmt::Modify()
{
	return true ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiContElmt&
NSEpiContElmt::operator=(NSEpiContElmt src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiContElmt::operator==(const NSEpiContElmt& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
// Constructeur par d�faut
// -----------------------------------------------------------------------------
NSEpiContElmtInfo::NSEpiContElmtInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiContElmtData() ;
}


// -----------------------------------------------------------------------------
// Constructeur � partir d'un NSEpiContElmt
// -----------------------------------------------------------------------------
NSEpiContElmtInfo::NSEpiContElmtInfo(NSEpiContElmt *pContact)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiContElmtData() ;

	// Copie les valeurs du NSEpiContElmt
	*pDonnees = *(pContact->pDonnees) ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiContElmtInfo::NSEpiContElmtInfo(NSEpiContElmtInfo& rv)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiContElmtData() ;

	// Copie les valeurs du NSEpiContElmtInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiContElmtInfo::~NSEpiContElmtInfo()
{
	delete pDonnees ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiContElmtInfo&
NSEpiContElmtInfo::operator=(NSEpiContElmtInfo src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiContElmtInfo::operator==(const NSEpiContElmtInfo& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes NSEpiContClass
//
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiContClasData::NSEpiContClasData()
{
	// Met les champs de donn�es � z�ro
	metAZero() ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiContClasData::NSEpiContClasData(NSEpiContClasData& rv)
{
	strcpy(contElement, rv.contElement) ;
	strcpy(numero,      rv.numero) ;
	strcpy(position,    rv.position) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiContClasData::~NSEpiContClasData()
{
}


// -----------------------------------------------------------------------------
// Op�rateur =
// -----------------------------------------------------------------------------
NSEpiContClasData&
NSEpiContClasData::operator=(NSEpiContClasData src)
{
  if (this == &src)
    return *this ;

	strcpy(contElement, src.contElement) ;
	strcpy(numero,      src.numero) ;
	strcpy(position,    src.position) ;

	return *this ;
}


// -----------------------------------------------------------------------------
//  Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiContClasData::operator==(const NSEpiContClasData& o)
{
	if ((strcmp(contElement, o.contElement) == 0) &&
      (strcmp(numero,      o.numero)      == 0))
		return 1 ;
	else
		return 0 ;
}

// -----------------------------------------------------------------------------
// Met � z�ro les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiContClasData::metAZero()
{
	// Met les champs de donn�es � z�ro
	memset(contElement, 0, CONTCLAS_CONTELMT_LEN + 1) ;
	memset(numero,   	  0, CONTCLAS_NUMERO_LEN + 1) ;
	memset(position, 	  0, CONTCLAS_POSITION_LEN + 1) ;
}

// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiContClass::NSEpiContClass(NSContexte *pCtx)
  : NSEpiContClasInfo(),
    NSFiche(pCtx)
{
}

// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiContClass::NSEpiContClass(NSEpiContClass& rv)
  : NSEpiContClasInfo(rv),
    NSFiche(rv.pContexte)
{
}

// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiContClass::~NSEpiContClass()
{
}

// -----------------------------------------------------------------------------
// Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiContClass::alimenteFiche()
{
  alimenteChamp(pDonnees->contElement,  CONTCLAS_CONTELMT_FIELD,  CONTCLAS_CONTELMT_LEN) ;
  alimenteChamp(pDonnees->numero, 		  CONTCLAS_NUMERO_FIELD, 	  CONTCLAS_NUMERO_LEN) ;
  alimenteChamp(pDonnees->position,     CONTCLAS_POSITION_FIELD,  CONTCLAS_POSITION_LEN) ;
}

// -----------------------------------------------------------------------------
// Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSEpiContClass::videFiche()
{
	videChamp(pDonnees->contElement,  CONTCLAS_CONTELMT_FIELD,  CONTCLAS_CONTELMT_LEN) ;
  videChamp(pDonnees->numero, 		  CONTCLAS_NUMERO_FIELD,    CONTCLAS_NUMERO_LEN) ;
  videChamp(pDonnees->position,     CONTCLAS_POSITION_FIELD,  CONTCLAS_POSITION_LEN) ;
}


// -----------------------------------------------------------------------------
// Ouvre la table primaire et les index secondaires
// -----------------------------------------------------------------------------
DBIResult
NSEpiContClass::open()
{
	char tableName[] = "CON_CLAS.DB" ;

	// Appelle la fonction open() de la classe de base pour ouvrir l'index primaire
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL) ;
	return (lastError) ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiContClass::Create()
{
  return true ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiContClass::Modify()
{
	return true ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiContClass&
NSEpiContClass::operator=(NSEpiContClass src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiContClass::operator==(const NSEpiContClass& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
// Constructeur par d�faut
// -----------------------------------------------------------------------------
NSEpiContClasInfo::NSEpiContClasInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiContClasData() ;
}


// -----------------------------------------------------------------------------
// Constructeur � partir d'un NSEpiContClass
// -----------------------------------------------------------------------------
NSEpiContClasInfo::NSEpiContClasInfo(NSEpiContClass *pContact)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiContClasData() ;

	// Copie les valeurs du NSEpiContClass
	*pDonnees = *(pContact->pDonnees) ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiContClasInfo::NSEpiContClasInfo(NSEpiContClasInfo& rv)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiContClasData() ;

	// Copie les valeurs du NSEpiContClasInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiContClasInfo::~NSEpiContClasInfo()
{
	delete pDonnees ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiContClasInfo&
NSEpiContClasInfo::operator=(NSEpiContClasInfo src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int

NSEpiContClasInfo::operator==(const NSEpiContClasInfo& o){
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
// Impl�mentation des m�thodes NSEpiContCode
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiContCodeData::NSEpiContCodeData()
{
	// Met les champs de donn�es � z�ro
	metAZero() ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiContCodeData::NSEpiContCodeData(NSEpiContCodeData& rv)
{
	strcpy(contElement,     rv.contElement) ;
	strcpy(numero,          rv.numero) ;
	strcpy(classification,  rv.classification) ;
	strcpy(code,            rv.code) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiContCodeData::~NSEpiContCodeData()
{
}


// -----------------------------------------------------------------------------
// Op�rateur =
// -----------------------------------------------------------------------------
NSEpiContCodeData&
NSEpiContCodeData::operator=(NSEpiContCodeData src)
{
  if (this == &src)
    return *this ;

	strcpy(contElement,     src.contElement) ;
	strcpy(numero,          src.numero) ;
	strcpy(classification,  src.classification) ;
	strcpy(code,            src.code) ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiContCodeData::operator==(const NSEpiContCodeData& o)
{
	if ((strcmp(contElement, o.contElement) == 0) &&
      (strcmp(numero,      o.numero)      == 0))
		return 1 ;
	else
		return 0 ;
}

// -----------------------------------------------------------------------------
// Met � z�ro les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiContCodeData::metAZero()
{
	// Met les champs de donn�es � z�ro
	memset(contElement, 	  0, CONTCODE_CONTELMT_LEN + 1) ;
	memset(numero,   		    0, CONTCODE_NUMERO_LEN + 1) ;
	memset(classification,  0, CONTCODE_CLASSIF_LEN + 1) ;
	memset(code,  		      0, CONTCODE_CODE_LEN + 1) ;
}

// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiContCode::NSEpiContCode(NSContexte *pCtx)
              : NSEpiContCodeInfo(), NSFiche(pCtx)
{
}

// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiContCode::NSEpiContCode(NSEpiContCode& rv)
              : NSEpiContCodeInfo(rv), NSFiche(rv.pContexte)
{
}

// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiContCode::~NSEpiContCode()
{
}

// -----------------------------------------------------------------------------
// Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiContCode::alimenteFiche()
{
  alimenteChamp(pDonnees->contElement, 	  CONTCODE_CONTELMT_FIELD,  CONTCODE_CONTELMT_LEN) ;
  alimenteChamp(pDonnees->numero, 		    CONTCODE_NUMERO_FIELD, 	  CONTCODE_NUMERO_LEN) ;
  alimenteChamp(pDonnees->classification, CONTCODE_CLASSIF_FIELD,   CONTCODE_CLASSIF_LEN) ;
  alimenteChamp(pDonnees->code,  	        CONTCODE_CODE_FIELD, 	    CONTCODE_CODE_LEN) ;
}

// -----------------------------------------------------------------------------
// Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSEpiContCode::videFiche()
{
	videChamp(pDonnees->contElement, 	  CONTCODE_CONTELMT_FIELD,  CONTCODE_CONTELMT_LEN) ;
  videChamp(pDonnees->numero, 		    CONTCODE_NUMERO_FIELD,    CONTCODE_NUMERO_LEN) ;
  videChamp(pDonnees->classification, CONTCODE_CLASSIF_FIELD,   CONTCODE_CLASSIF_LEN) ;
  videChamp(pDonnees->code,  	        CONTCODE_CODE_FIELD,      CONTCODE_CODE_LEN) ;
}

// -----------------------------------------------------------------------------
// Ouvre la table primaire et les index secondaires
// -----------------------------------------------------------------------------
DBIResult
NSEpiContCode::open()
{
	char tableName[] = "CON_CODE.DB" ;

	// Appelle la fonction open() de la classe de base pour ouvrir l'index primaire
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL) ;
	return (lastError) ;
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiContCode::Create()
{
	return true ;
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiContCode::Modify()
{
	return true ;
}

// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiContCode&
NSEpiContCode::operator=(NSEpiContCode src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiContCode::operator==(const NSEpiContCode& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
// Constructeur par d�faut
// -----------------------------------------------------------------------------
NSEpiContCodeInfo::NSEpiContCodeInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiContCodeData() ;
}


// -----------------------------------------------------------------------------
// Constructeur � partir d'un NSEpiContCode
// -----------------------------------------------------------------------------
NSEpiContCodeInfo::NSEpiContCodeInfo(NSEpiContCode *pContact)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiContCodeData() ;

	// Copie les valeurs du NSEpiContCode
	*pDonnees = *(pContact->pDonnees) ;
}

// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiContCodeInfo::NSEpiContCodeInfo(NSEpiContCodeInfo& rv)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiContCodeData() ;

	// Copie les valeurs du NSEpiContCodeInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}

// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiContCodeInfo::~NSEpiContCodeInfo()
{
	delete pDonnees ;
}

// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiContCodeInfo&
NSEpiContCodeInfo::operator=(NSEpiContCodeInfo src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}

// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiContCodeInfo::operator==(const NSEpiContCodeInfo& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes NSEpiPreoccup
//
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiPreoccupData::NSEpiPreoccupData()
{
	// Met les champs de donn�es � z�ro
	metAZero() ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiPreoccupData::NSEpiPreoccupData(NSEpiPreoccupData& rv)
{
	strcpy(patient,     rv.patient) ;
	strcpy(code,        rv.code) ;
	strcpy(revision,    rv.revision) ;
	strcpy(session,     rv.session) ;
	strcpy(lexique,  	  rv.lexique) ;
	strcpy(complement,  rv.complement) ;
	strcpy(dateCree,    rv.dateCree) ;
	strcpy(dateFerme,  	rv.dateFerme) ;
	strcpy(actif,  		  rv.actif) ;
	strcpy(recurrent,   rv.recurrent) ;
	strcpy(mere,  		  rv.mere) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiPreoccupData::~NSEpiPreoccupData()
{
}


// -----------------------------------------------------------------------------
// Op�rateur =
// -----------------------------------------------------------------------------
NSEpiPreoccupData&
NSEpiPreoccupData::operator=(NSEpiPreoccupData src)
{
  if (this == &src)
    return *this ;

	strcpy(patient,     src.patient) ;
	strcpy(code,        src.code) ;
	strcpy(revision,    src.revision) ;
	strcpy(session,     src.session) ;
	strcpy(lexique,  	  src.lexique) ;
	strcpy(complement,  src.complement) ;
	strcpy(dateCree,    src.dateCree) ;
	strcpy(dateFerme,  	src.dateFerme) ;
	strcpy(actif,  		  src.actif) ;
	strcpy(recurrent,  	src.recurrent) ;
	strcpy(mere,  		  src.mere) ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiPreoccupData::operator==(const NSEpiPreoccupData& o)
{
	if ((strcmp(patient,  o.patient)  == 0) &&
      (strcmp(code,     o.code)     == 0) &&
      (strcmp(revision, o.revision) == 0))
		return 1 ;
	else
		return 0 ;
}

// -----------------------------------------------------------------------------
// Met � z�ro les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiPreoccupData::metAZero()
{
	// Met les champs de donn�es � z�ro
	memset(patient,     0, PREOCCUP_PATIENT_LEN + 1) ;
	memset(code,   		  0, PREOCCUP_CODE_LEN + 1) ;
	memset(revision, 	  0, PREOCCUP_REVISION_LEN + 1) ;
	memset(session,     0, PREOCCUP_SESSION_LEN + 1) ;
	memset(lexique,  	  0, PREOCCUP_LEXIQUE_LEN + 1) ;
	memset(complement,  0, PREOCCUP_COMPLEMENT_LEN + 1) ;
	memset(dateCree,    0, PREOCCUP_DATE_CREE_LEN + 1) ;
	memset(dateFerme,  	0, PREOCCUP_DATE_FERME_LEN + 1) ;
	memset(actif,  		  0, PREOCCUP_ACTIF_LEN + 1) ;
	memset(recurrent,  	0, PREOCCUP_RECURRENT_LEN + 1) ;
	memset(mere,  		  0, PREOCCUP_MERE_LEN + 1) ;
}

// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiPreoccup::NSEpiPreoccup(NSContexte *pCtx)
  : NSEpiPreoccupInfo(),
    NSFiche(pCtx)
{
}

// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiPreoccup::NSEpiPreoccup(NSEpiPreoccup& rv)
  : NSEpiPreoccupInfo(rv),
    NSFiche(rv.pContexte)
{
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiPreoccup::~NSEpiPreoccup()
{
}


// -----------------------------------------------------------------------------
// Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiPreoccup::alimenteFiche()
{
  alimenteChamp(pDonnees->patient,    PREOCCUP_PATIENT_FIELD,     PREOCCUP_PATIENT_LEN) ;
  alimenteChamp(pDonnees->code, 		  PREOCCUP_CODE_FIELD, 	      PREOCCUP_CODE_LEN) ;
  alimenteChamp(pDonnees->revision,   PREOCCUP_REVISION_FIELD,    PREOCCUP_REVISION_LEN) ;
  alimenteChamp(pDonnees->session,    PREOCCUP_SESSION_FIELD,     PREOCCUP_SESSION_LEN) ;
  alimenteChamp(pDonnees->lexique,  	PREOCCUP_LEXIQUE_FIELD, 	  PREOCCUP_LEXIQUE_LEN) ;
  alimenteChamp(pDonnees->complement, PREOCCUP_COMPLEMENT_FIELD,  PREOCCUP_COMPLEMENT_LEN) ;
  alimenteChamp(pDonnees->dateCree,   PREOCCUP_DATE_CREE_FIELD,   PREOCCUP_DATE_CREE_LEN) ;
  alimenteChamp(pDonnees->dateFerme,  PREOCCUP_DATE_FERME_FIELD,  PREOCCUP_DATE_FERME_LEN) ;
  alimenteChamp(pDonnees->actif,  	  PREOCCUP_ACTIF_FIELD,       PREOCCUP_ACTIF_LEN) ;
  alimenteChamp(pDonnees->recurrent,  PREOCCUP_RECURRENT_FIELD,   PREOCCUP_RECURRENT_LEN) ;
  alimenteChamp(pDonnees->mere,  	    PREOCCUP_MERE_FIELD,        PREOCCUP_MERE_LEN) ;
}


// -----------------------------------------------------------------------------
// Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSEpiPreoccup::videFiche()
{
  videChamp(pDonnees->patient,    PREOCCUP_PATIENT_FIELD,     PREOCCUP_PATIENT_LEN) ;
  videChamp(pDonnees->code, 		  PREOCCUP_CODE_FIELD, 	      PREOCCUP_CODE_LEN) ;
  videChamp(pDonnees->revision,   PREOCCUP_REVISION_FIELD,    PREOCCUP_REVISION_LEN) ;
  videChamp(pDonnees->session,    PREOCCUP_SESSION_FIELD,     PREOCCUP_SESSION_LEN) ;
  videChamp(pDonnees->lexique,  	PREOCCUP_LEXIQUE_FIELD, 	  PREOCCUP_LEXIQUE_LEN) ;
  videChamp(pDonnees->complement, PREOCCUP_COMPLEMENT_FIELD,  PREOCCUP_COMPLEMENT_LEN) ;
  videChamp(pDonnees->dateCree,   PREOCCUP_DATE_CREE_FIELD,   PREOCCUP_DATE_CREE_LEN) ;
  videChamp(pDonnees->dateFerme,  PREOCCUP_DATE_FERME_FIELD,  PREOCCUP_DATE_FERME_LEN) ;
  videChamp(pDonnees->actif,  	  PREOCCUP_ACTIF_FIELD,       PREOCCUP_ACTIF_LEN) ;
  videChamp(pDonnees->recurrent,  PREOCCUP_RECURRENT_FIELD,   PREOCCUP_RECURRENT_LEN) ;
  videChamp(pDonnees->mere,  	    PREOCCUP_MERE_FIELD,        PREOCCUP_MERE_LEN) ;
}


// -----------------------------------------------------------------------------
// Ouvre la table primaire et les index secondaires
// -----------------------------------------------------------------------------
DBIResult
NSEpiPreoccup::open()
{
	char tableName[] = "PREOCCUP.DB";

	// Appelle la fonction open() de la classe de base pour ouvrir l'index primaire
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL) ;
	return (lastError) ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiPreoccup::Create()
{
	return true ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiPreoccup::Modify()
{
	return true ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiPreoccup&
NSEpiPreoccup::operator=(NSEpiPreoccup src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiPreoccup::operator==(const NSEpiPreoccup& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
// Constructeur par d�faut
// -----------------------------------------------------------------------------
NSEpiPreoccupInfo::NSEpiPreoccupInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiPreoccupData() ;
}


// -----------------------------------------------------------------------------
// Constructeur � partir d'un NSEpiPreoccup
// -----------------------------------------------------------------------------
NSEpiPreoccupInfo::NSEpiPreoccupInfo(NSEpiPreoccup *pContact)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiPreoccupData() ;

	// Copie les valeurs du NSEpiPreoccup
	*pDonnees = *(pContact->pDonnees) ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiPreoccupInfo::NSEpiPreoccupInfo(NSEpiPreoccupInfo& rv)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiPreoccupData() ;

	// Copie les valeurs du NSEpiPreoccupInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiPreoccupInfo::~NSEpiPreoccupInfo()
{
	delete pDonnees ;
}


void
NSEpiPreoccupInfo::initActif(bool bActif)
{
  if (bActif)
    pDonnees->actif[0] = '1' ;
  else
    pDonnees->actif[0] = '0' ;
}


void
NSEpiPreoccupInfo::initRecurrent(bool bRecurrent)
{
  if (bRecurrent)
    pDonnees->recurrent[0] = '1' ;
  else
    pDonnees->recurrent[0] = '0' ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiPreoccupInfo&
NSEpiPreoccupInfo::operator=(NSEpiPreoccupInfo src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiPreoccupInfo::operator==(const NSEpiPreoccupInfo& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes NSEpiProbleme
//
// -----------------------------------------------------------------------------// -----------------------------------------------------------------------------// Constructeur// -----------------------------------------------------------------------------
NSEpiProblemeData::NSEpiProblemeData()
{
	// Met les champs de donn�es � z�ro
	metAZero() ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiProblemeData::NSEpiProblemeData(NSEpiProblemeData& rv)
{
	strcpy(preoccupation, rv.preoccupation) ;
	strcpy(code,          rv.code) ;
	strcpy(revision,      rv.revision) ;
	strcpy(session,       rv.session) ;
	strcpy(signifiant,    rv.signifiant) ;
	strcpy(severite,      rv.severite) ;
	strcpy(lexique,  		  rv.lexique) ;
	strcpy(complement,    rv.complement) ;
	strcpy(certitude,     rv.certitude) ;
	strcpy(origine,       rv.origine) ;
	strcpy(fin,           rv.fin) ;
	strcpy(dateDebut,     rv.dateDebut) ;
	strcpy(dateCree,      rv.dateCree) ;
	strcpy(dateFerme,  		rv.dateFerme) ;
	strcpy(dateObso,  		rv.dateObso) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiProblemeData::~NSEpiProblemeData()
{
}


// -----------------------------------------------------------------------------
// Op�rateur =
// -----------------------------------------------------------------------------
NSEpiProblemeData&
NSEpiProblemeData::operator=(NSEpiProblemeData src)
{
  if (this == &src)
    return *this ;

	strcpy(preoccupation, src.preoccupation) ;
	strcpy(code,          src.code) ;
	strcpy(revision,      src.revision) ;
	strcpy(session,       src.session) ;
	strcpy(signifiant,    src.signifiant) ;
	strcpy(severite,      src.severite) ;
	strcpy(lexique,  		  src.lexique) ;
	strcpy(complement,    src.complement) ;
	strcpy(certitude,     src.certitude) ;
	strcpy(origine,       src.origine) ;
	strcpy(fin,           src.fin) ;
	strcpy(dateDebut,     src.dateDebut) ;
	strcpy(dateCree,      src.dateCree) ;
	strcpy(dateFerme,  		src.dateFerme) ;
	strcpy(dateObso,  		src.dateObso) ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiProblemeData::operator==(const NSEpiProblemeData& o)
{
	if ((strcmp(preoccupation, o.preoccupation) == 0) &&
      (strcmp(code,          o.code)          == 0) &&
      (strcmp(revision,      o.revision)      == 0))
		return 1 ;
	else
		return 0 ;
}

// -----------------------------------------------------------------------------
// Met � z�ro les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiProblemeData::metAZero()
{
	// Met les champs de donn�es � z�ro
	memset(preoccupation, 0, PROBLEME_PREOCCUP_LEN + 1) ;
	memset(code,   		    0, PROBLEME_CODE_LEN + 1) ;
	memset(revision, 	    0, PROBLEME_REVISION_LEN + 1) ;
	memset(session,       0, PROBLEME_SESSION_LEN + 1) ;
	memset(signifiant,  	0, PROBLEME_SIGNIFIANT_LEN + 1) ;
	memset(severite,      0, PROBLEME_SEVERITE_LEN + 1) ;
	memset(lexique,  		  0, PROBLEME_LEXIQUE_LEN + 1) ;
	memset(complement, 	  0, PROBLEME_COMPLEMENT_LEN + 1) ;
	memset(certitude,   	0, PROBLEME_CERTITUDE_LEN + 1) ;
	memset(origine, 	    0, PROBLEME_ORIGINE_LEN + 1) ;
	memset(fin,           0, PROBLEME_FIN_LEN + 1) ;
	memset(dateDebut,  		0, PROBLEME_DATE_DEBUT_LEN + 1) ;
	memset(dateCree,      0, PROBLEME_DATE_CREE_LEN + 1) ;
	memset(dateFerme,  		0, PROBLEME_DATE_FERME_LEN + 1) ;
	memset(dateObso,  		0, PROBLEME_DATE_OBSO_LEN + 1) ;
}


// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiProbleme::NSEpiProbleme(NSContexte *pCtx)
  : NSEpiProblemeInfo(),
    NSFiche(pCtx)
{
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiProbleme::NSEpiProbleme(NSEpiProbleme& rv)
  : NSEpiProblemeInfo(rv),
    NSFiche(rv.pContexte)
{
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiProbleme::~NSEpiProbleme()
{
}


// -----------------------------------------------------------------------------
// Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiProbleme::alimenteFiche()
{
  alimenteChamp(pDonnees->preoccupation,  PROBLEME_PREOCCUP_FIELD,    PROBLEME_PREOCCUP_LEN) ;
  alimenteChamp(pDonnees->code, 		      PROBLEME_CODE_FIELD, 	      PROBLEME_CODE_LEN) ;
  alimenteChamp(pDonnees->revision,       PROBLEME_REVISION_FIELD,    PROBLEME_REVISION_LEN) ;
  alimenteChamp(pDonnees->session,        PROBLEME_SESSION_FIELD,     PROBLEME_SESSION_LEN) ;
  alimenteChamp(pDonnees->signifiant,     PROBLEME_SIGNIFIANT_FIELD,  PROBLEME_SIGNIFIANT_LEN) ;
  alimenteChamp(pDonnees->severite,       PROBLEME_SEVERITE_FIELD,    PROBLEME_SEVERITE_LEN) ;
  alimenteChamp(pDonnees->lexique,  	    PROBLEME_LEXIQUE_FIELD,     PROBLEME_LEXIQUE_LEN) ;
  alimenteChamp(pDonnees->complement,     PROBLEME_COMPLEMENT_FIELD,  PROBLEME_COMPLEMENT_LEN) ;
  alimenteChamp(pDonnees->certitude, 	    PROBLEME_CERTITUDE_FIELD,   PROBLEME_CERTITUDE_LEN) ;
  alimenteChamp(pDonnees->origine,        PROBLEME_ORIGINE_FIELD,     PROBLEME_ORIGINE_LEN) ;
  alimenteChamp(pDonnees->fin,            PROBLEME_FIN_FIELD,         PROBLEME_FIN_LEN) ;
  alimenteChamp(pDonnees->dateDebut,      PROBLEME_DATE_DEBUT_FIELD,  PROBLEME_DATE_DEBUT_LEN) ;
  alimenteChamp(pDonnees->dateCree,       PROBLEME_DATE_CREE_FIELD,   PROBLEME_DATE_CREE_LEN) ;
  alimenteChamp(pDonnees->dateFerme,      PROBLEME_DATE_FERME_FIELD,  PROBLEME_DATE_FERME_LEN) ;
  alimenteChamp(pDonnees->dateObso,  	    PROBLEME_DATE_OBSO_FIELD,   PROBLEME_DATE_OBSO_LEN) ;
}


// -----------------------------------------------------------------------------
// Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSEpiProbleme::videFiche()
{
  videChamp(pDonnees->preoccupation,  PROBLEME_PREOCCUP_FIELD,    PROBLEME_PREOCCUP_LEN) ;
  videChamp(pDonnees->code, 		      PROBLEME_CODE_FIELD, 	      PROBLEME_CODE_LEN) ;
  videChamp(pDonnees->revision,       PROBLEME_REVISION_FIELD,    PROBLEME_REVISION_LEN) ;
  videChamp(pDonnees->session,        PROBLEME_SESSION_FIELD,     PROBLEME_SESSION_LEN) ;
  videChamp(pDonnees->signifiant,     PROBLEME_SIGNIFIANT_FIELD,  PROBLEME_SIGNIFIANT_LEN) ;
  videChamp(pDonnees->severite,       PROBLEME_SEVERITE_FIELD,    PROBLEME_SEVERITE_LEN) ;
  videChamp(pDonnees->lexique,  	    PROBLEME_LEXIQUE_FIELD, 	  PROBLEME_LEXIQUE_LEN) ;
  videChamp(pDonnees->complement,     PROBLEME_COMPLEMENT_FIELD,  PROBLEME_COMPLEMENT_LEN) ;
  videChamp(pDonnees->certitude, 	    PROBLEME_CERTITUDE_FIELD,   PROBLEME_CERTITUDE_LEN) ;
  videChamp(pDonnees->origine,        PROBLEME_ORIGINE_FIELD,     PROBLEME_ORIGINE_LEN) ;
  videChamp(pDonnees->fin,            PROBLEME_FIN_FIELD,         PROBLEME_FIN_LEN) ;
  videChamp(pDonnees->dateDebut,      PROBLEME_DATE_DEBUT_FIELD,  PROBLEME_DATE_DEBUT_LEN) ;
  videChamp(pDonnees->dateCree,       PROBLEME_DATE_CREE_FIELD,   PROBLEME_DATE_CREE_LEN) ;
  videChamp(pDonnees->dateFerme,      PROBLEME_DATE_FERME_FIELD,  PROBLEME_DATE_FERME_LEN) ;
  videChamp(pDonnees->dateObso,  	    PROBLEME_DATE_OBSO_FIELD,   PROBLEME_DATE_OBSO_LEN) ;
}


// -----------------------------------------------------------------------------
// Ouvre la table primaire et les index secondaires
// -----------------------------------------------------------------------------
DBIResult
NSEpiProbleme::open()
{
	char tableName[] = "PROBLEME.DB" ;

	// Appelle la fonction open() de la classe de base pour ouvrir l'index primaire
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL) ;
	return (lastError) ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiProbleme::Create()
{
	return true ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiProbleme::Modify()
{
	return true ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiProbleme&
NSEpiProbleme::operator=(NSEpiProbleme src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiProbleme::operator==(const NSEpiProbleme& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
// Constructeur par d�faut
// -----------------------------------------------------------------------------
NSEpiProblemeInfo::NSEpiProblemeInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiProblemeData() ;
}


// -----------------------------------------------------------------------------
// Constructeur � partir d'un NSEpiProbleme
// -----------------------------------------------------------------------------
NSEpiProblemeInfo::NSEpiProblemeInfo(NSEpiProbleme *pContact)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiProblemeData() ;

	// Copie les valeurs du NSEpiProbleme
	*pDonnees = *(pContact->pDonnees) ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiProblemeInfo::NSEpiProblemeInfo(NSEpiProblemeInfo& rv)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiProblemeData() ;

	// Copie les valeurs du NSEpiProblemeInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiProblemeInfo::~NSEpiProblemeInfo()
{
	delete pDonnees ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiProblemeInfo&
NSEpiProblemeInfo::operator=(NSEpiProblemeInfo src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiProblemeInfo::operator==(const NSEpiProblemeInfo& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes NSEpiProbEven
//
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiProbEvenData::NSEpiProbEvenData()
{
	// Met les champs de donn�es � z�ro
	metAZero() ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiProbEvenData::NSEpiProbEvenData(NSEpiProbEvenData& rv)
{
	strcpy(probleme,    rv.probleme) ;
	strcpy(code,        rv.code) ;
	strcpy(revision,    rv.revision) ;
	strcpy(session,     rv.session) ;
	strcpy(lexique,  	  rv.lexique) ;
	strcpy(complement,  rv.complement) ;
	strcpy(certitude,   rv.certitude) ;
	strcpy(severite,    rv.severite) ;
	strcpy(dateHeure,   rv.dateHeure) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiProbEvenData::~NSEpiProbEvenData()
{
}


// -----------------------------------------------------------------------------
// Op�rateur =
// -----------------------------------------------------------------------------
NSEpiProbEvenData&
NSEpiProbEvenData::operator=(NSEpiProbEvenData src)
{
  if (this == &src)
    return *this ;

	strcpy(probleme,    src.probleme) ;
	strcpy(code,        src.code) ;
	strcpy(revision,    src.revision) ;
	strcpy(session,     src.session) ;
	strcpy(lexique,  	  src.lexique) ;
	strcpy(complement,  src.complement) ;
	strcpy(certitude,   src.certitude) ;
	strcpy(severite,    src.severite) ;
	strcpy(dateHeure,   src.dateHeure) ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiProbEvenData::operator == ( const NSEpiProbEvenData& o )
{
	if ((strcmp(probleme, o.probleme) == 0) &&
      (strcmp(code,     o.code)     == 0) &&
      (strcmp(revision, o.revision) == 0))
		return 1 ;
	else
		return 0 ;
}

// -----------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiProbEvenData::metAZero()
{
	// Met les champs de donn�es � z�ro
	memset(probleme,    0, PROBEVEN_PROBLEME_LEN + 1) ;
	memset(code,   		  0, PROBEVEN_CODE_LEN + 1) ;
	memset(revision, 	  0, PROBEVEN_REVISION_LEN + 1) ;
	memset(session,     0, PROBEVEN_SESSION_LEN + 1) ;
	memset(lexique,  	  0, PROBEVEN_LEXIQUE_LEN + 1) ;
	memset(complement,  0, PROBEVEN_COMPLEMENT_LEN + 1) ;
  memset(certitude,   0, PROBEVEN_CERTITUDE_LEN + 1) ;
	memset(severite, 	  0, PROBEVEN_SEVERITE_LEN + 1) ;
	memset(dateHeure,   0, PROBEVEN_DATE_HEURE_LEN + 1) ;
}

// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiProbEven::NSEpiProbEven(NSContexte *pCtx)
  : NSEpiProbEvenInfo(),
    NSFiche(pCtx)
{
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiProbEven::NSEpiProbEven(NSEpiProbEven& rv)
  : NSEpiProbEvenInfo(rv),
    NSFiche(rv.pContexte)
{
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiProbEven::~NSEpiProbEven()
{
}


// -----------------------------------------------------------------------------
// Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiProbEven::alimenteFiche()
{
  alimenteChamp(pDonnees->probleme,   PROBEVEN_PROBLEME_FIELD,    PROBEVEN_PROBLEME_LEN) ;
  alimenteChamp(pDonnees->code, 		  PROBEVEN_CODE_FIELD, 	      PROBEVEN_CODE_LEN) ;
  alimenteChamp(pDonnees->revision,   PROBEVEN_REVISION_FIELD,    PROBEVEN_REVISION_LEN) ;
  alimenteChamp(pDonnees->session,    PROBEVEN_SESSION_FIELD,     PROBEVEN_SESSION_LEN) ;
  alimenteChamp(pDonnees->lexique,  	PROBEVEN_LEXIQUE_FIELD,     PROBEVEN_LEXIQUE_LEN) ;
  alimenteChamp(pDonnees->complement, PROBEVEN_COMPLEMENT_FIELD,  PROBEVEN_COMPLEMENT_LEN) ;
  alimenteChamp(pDonnees->certitude, 	PROBEVEN_CERTITUDE_FIELD,   PROBEVEN_CERTITUDE_LEN) ;
  alimenteChamp(pDonnees->severite,   PROBEVEN_SEVERITE_FIELD,    PROBEVEN_SEVERITE_LEN) ;
  alimenteChamp(pDonnees->dateHeure,  PROBEVEN_DATE_HEURE_FIELD,  PROBEVEN_DATE_HEURE_LEN) ;
}


// -----------------------------------------------------------------------------
// Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSEpiProbEven::videFiche()
{
  videChamp(pDonnees->probleme,   PROBEVEN_PROBLEME_FIELD,    PROBEVEN_PROBLEME_LEN) ;
  videChamp(pDonnees->code, 		  PROBEVEN_CODE_FIELD, 	      PROBEVEN_CODE_LEN) ;
  videChamp(pDonnees->revision,   PROBEVEN_REVISION_FIELD,    PROBEVEN_REVISION_LEN) ;
  videChamp(pDonnees->session,    PROBEVEN_SESSION_FIELD,     PROBEVEN_SESSION_LEN) ;
  videChamp(pDonnees->lexique,  	PROBEVEN_LEXIQUE_FIELD,     PROBEVEN_LEXIQUE_LEN) ;
  videChamp(pDonnees->complement, PROBEVEN_COMPLEMENT_FIELD,  PROBEVEN_COMPLEMENT_LEN) ;
  videChamp(pDonnees->certitude, 	PROBEVEN_CERTITUDE_FIELD,   PROBEVEN_CERTITUDE_LEN) ;
  videChamp(pDonnees->severite,   PROBEVEN_SEVERITE_FIELD,    PROBEVEN_SEVERITE_LEN) ;
  videChamp(pDonnees->dateHeure,  PROBEVEN_DATE_HEURE_FIELD,  PROBEVEN_DATE_HEURE_LEN) ;
}


// -----------------------------------------------------------------------------
// Ouvre la table primaire et les index secondaires
// -----------------------------------------------------------------------------
DBIResult
NSEpiProbEven::open()
{
	char tableName[] = "PROBEVENT.DB" ;

	// Appelle la fonction open() de la classe de base pour ouvrir l'index primaire
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL) ;
	return (lastError) ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiProbEven::Create()
{
	return true ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiProbEven::Modify()
{
	return true ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiProbEven&
NSEpiProbEven::operator=(NSEpiProbEven src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiProbEven::operator==(const NSEpiProbEven& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
// Constructeur par d�faut
// -----------------------------------------------------------------------------
NSEpiProbEvenInfo::NSEpiProbEvenInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiProbEvenData() ;
}


// -----------------------------------------------------------------------------
// Constructeur � partir d'un NSEpiProbEven
// -----------------------------------------------------------------------------
NSEpiProbEvenInfo::NSEpiProbEvenInfo(NSEpiProbEven *pContact)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiProbEvenData() ;

	// Copie les valeurs du NSEpiProbEven
	*pDonnees = *(pContact->pDonnees) ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiProbEvenInfo::NSEpiProbEvenInfo(NSEpiProbEvenInfo& rv)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiProbEvenData() ;

	// Copie les valeurs du NSEpiProbEvenInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiProbEvenInfo::~NSEpiProbEvenInfo()
{
	delete pDonnees ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiProbEvenInfo&
NSEpiProbEvenInfo::operator=(NSEpiProbEvenInfo src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiProbEvenInfo::operator==(const NSEpiProbEvenInfo& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes NSEpiClasser
//
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiClasserData::NSEpiClasserData()
{
	// Met les champs de donn�es � z�ro
	metAZero() ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiClasserData::NSEpiClasserData(NSEpiClasserData& rv)
{
	strcpy(code,            rv.code) ;
	strcpy(classification,  rv.classification) ;
	strcpy(critere,         rv.critere) ;
	strcpy(relation,  	    rv.relation) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiClasserData::~NSEpiClasserData()
{
}


// -----------------------------------------------------------------------------
// Op�rateur =
// -----------------------------------------------------------------------------
NSEpiClasserData&
NSEpiClasserData::operator=(NSEpiClasserData src)
{
  if (this == &src)
    return *this ;

	strcpy(code,            src.code) ;
	strcpy(classification,  src.classification) ;
	strcpy(critere,         src.critere) ;
	strcpy(relation,  	    src.relation) ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiClasserData::operator==(const NSEpiClasserData& o)
{
	if ((strcmp(code,           o.code)           == 0) &&
      (strcmp(classification, o.classification) == 0) &&
      (strcmp(critere,        o.critere)        == 0) &&
      (strcmp(relation,       o.relation)       == 0))
		return 1 ;
	else
		return 0 ;
}

// -----------------------------------------------------------------------------
// Met � z�ro les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiClasserData::metAZero()
{
	// Met les champs de donn�es � z�ro
	memset(code,   		      0, CLASSER_CODE_LEN + 1) ;
	memset(classification,  0, CLASSER_CLASSIF_LEN + 1) ;
	memset(critere,         0, CLASSER_CRITERE_LEN + 1) ;
	memset(relation,  	    0, CLASSER_RELATION_LEN + 1) ;
}


// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiClasser::NSEpiClasser(NSContexte *pCtx)
  : NSEpiClasserInfo(),
    NSFiche(pCtx)
{
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiClasser::NSEpiClasser(NSEpiClasser& rv)
  : NSEpiClasserInfo(rv),
    NSFiche(rv.pContexte)
{
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiClasser::~NSEpiClasser()
{
}


// -----------------------------------------------------------------------------
// Donne l'ensemble des relations pour un code, une relation, un crit�re
// -----------------------------------------------------------------------------
DBIResult
NSEpiClasser::donneRelations(string *pResult, string sCode, string sClassification, string sCritere)
{
  *pResult = "" ;

  bool bOpenClose = false ;
  if (isOpen != true)
    bOpenClose = true ;

  // Ouverture de la table - Open the table
  if (bOpenClose)
  {
    lastError = open() ;
    if (lastError != DBIERR_NONE)
      return lastError ;
  }

  // Recherche de la premi�re relation - Looking for the first proper relation
  string cle = sCode + sClassification ;

  CURProps  curProps ;
  DBIResult lastError   = DbiGetCursorProps(PrendCurseur(), curProps) ;
  Byte      *pIndexRec  = new Byte[curProps.iRecBufSize] ;
  memset(pIndexRec, 0, curProps.iRecBufSize) ;
  DbiPutField(PrendCurseur(), CLASSER_CODE_FIELD,    pIndexRec, (Byte *)sCode.c_str()) ;
  DbiPutField(PrendCurseur(), CLASSER_CLASSIF_FIELD, pIndexRec, (Byte *)sClassification.c_str()) ;

  lastError = chercheClefComposite("CODAGE", NODEFAULTINDEX, keySEARCHGEQ, dbiWRITELOCK, pIndexRec) ;
  delete[] pIndexRec ;

  if ((lastError != DBIERR_NONE) && (lastError != DBIERR_EOF))
	{
    if (bOpenClose)
      close() ;
		return lastError ;
  }

  if (lastError == DBIERR_EOF)
	{
    if (bOpenClose)
      close() ;
		return DBIERR_NONE ;
  }

  lastError = getRecord() ;
  if (lastError != DBIERR_NONE)
	{
    if (bOpenClose)
      close() ;
		return lastError ;
  }

  // On v�rifie que la fiche trouv�e appartient bien au document
  if ((string(pDonnees->code)           != sCode)           ||
      (string(pDonnees->classification) != sClassification))
  {
    if (bOpenClose)
      close() ;
		return DBIERR_NONE ;
	}

  // On avance dans le fichier tant que les fiches trouv�es sont OK
  while ( (lastError                        != DBIERR_EOF)  &&
          (string(pDonnees->code)           == sCode)       &&
          (string(pDonnees->classification) == sClassification))
  {
    if ((string(pDonnees->critere) == sCritere) && (string(pDonnees->relation) != string("")))
    {
      if (*pResult != string(""))
        *pResult += string(";") ;
      *pResult += string(pDonnees->relation) ;
    }

    lastError = suivant(dbiWRITELOCK) ;
    if ((lastError != DBIERR_NONE) && (lastError != DBIERR_EOF))
		{
      if (bOpenClose)
        close() ;
      return lastError ;
		}

    if (lastError != DBIERR_EOF)
    {
      lastError = getRecord() ;
      if (lastError != DBIERR_NONE)
			{
        if (bOpenClose)
          close() ;
        return lastError ;
			}
    }
  }

  // Fermeture du fichier
  if (bOpenClose)
    return close() ;
  return DBIERR_NONE ;
}


// -----------------------------------------------------------------------------
// Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiClasser::alimenteFiche()
{
  alimenteChamp(pDonnees->code, 		      CLASSER_CODE_FIELD,     CLASSER_CODE_LEN) ;
  alimenteChamp(pDonnees->classification, CLASSER_CLASSIF_FIELD,  CLASSER_CLASSIF_LEN) ;
  alimenteChamp(pDonnees->critere,        CLASSER_CRITERE_FIELD,  CLASSER_CRITERE_LEN) ;
  alimenteChamp(pDonnees->relation,  	    CLASSER_RELATION_FIELD, CLASSER_RELATION_LEN) ;
}


// -----------------------------------------------------------------------------
// Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSEpiClasser::videFiche()
{
  videChamp(pDonnees->code, 		      CLASSER_CODE_FIELD,     CLASSER_CODE_LEN) ;
  videChamp(pDonnees->classification, CLASSER_CLASSIF_FIELD,  CLASSER_CLASSIF_LEN) ;
  videChamp(pDonnees->critere,        CLASSER_CRITERE_FIELD,  CLASSER_CRITERE_LEN) ;
  videChamp(pDonnees->relation,  	    CLASSER_RELATION_FIELD, CLASSER_RELATION_LEN) ;
}


// -----------------------------------------------------------------------------
// Ouvre la table primaire et les index secondaires
// -----------------------------------------------------------------------------
DBIResult
NSEpiClasser::open()
{
	char tableName[] = "CLASSER.DB" ;

	// Appelle la fonction open() de la classe de base pour ouvrir l'index primaire
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL) ;
	return (lastError) ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiClasser::Create()
{
	return true ;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiClasser::Modify()
{
	return true ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiClasser&
NSEpiClasser::operator=(NSEpiClasser src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiClasser::operator==(const NSEpiClasser& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
// Constructeur par d�faut
// -----------------------------------------------------------------------------
NSEpiClasserInfo::NSEpiClasserInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiClasserData() ;
}


// -----------------------------------------------------------------------------
// Constructeur � partir d'un NSEpiClasser
// -----------------------------------------------------------------------------
NSEpiClasserInfo::NSEpiClasserInfo(NSEpiClasser *pContact)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiClasserData() ;

	// Copie les valeurs du NSEpiProbEven
	*pDonnees = *(pContact->pDonnees) ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiClasserInfo::NSEpiClasserInfo(NSEpiClasserInfo& rv)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiClasserData() ;

	// Copie les valeurs du NSEpiProbEvenInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiClasserInfo::~NSEpiClasserInfo()
{
	delete pDonnees ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiClasserInfo&
NSEpiClasserInfo::operator=(NSEpiClasserInfo src)
{
  if (this == &src)
    return *this ;
	*pDonnees = *(src.pDonnees) ;
  return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiClasserInfo::operator==(const NSEpiClasserInfo& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


//******************** THESAURUS ********************

// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes NSThesaurus
//
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSThesaurusData::NSThesaurusData()
{
	// Met les champs de donn�es � z�ro
	metAZero() ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSThesaurusData::NSThesaurusData(NSThesaurusData& rv)
{
  strcpy(ibui,     rv.ibui) ;
  strcpy(labelFr,  rv.labelFr) ;
  strcpy(labelNl,  rv.labelNl) ;
  strcpy(icpc2,    rv.icpc2) ;
  strcpy(icd10,    rv.icd10) ;
  strcpy(icpc2_2,  rv.icpc2_2) ;
  strcpy(icd10_2,  rv.icd10_2) ;
  strcpy(icpc2_1X, rv.icpc2_1X) ;
  strcpy(icd10_1X, rv.icd10_1X) ;
  strcpy(icpc2_2X, rv.icpc2_2X) ;
  strcpy(icd10_2X, rv.icd10_2X) ;
  strcpy(icpc2_1Y, rv.icpc2_1Y) ;
  strcpy(icd10_1Y, rv.icd10_1Y) ;
  strcpy(icpc2_2Y, rv.icpc2_2Y) ;
  strcpy(icd10_2Y, rv.icd10_2Y) ;
}

// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSThesaurusData::~NSThesaurusData()
{
}


// -----------------------------------------------------------------------------
// Op�rateur =
// -----------------------------------------------------------------------------
NSThesaurusData&
NSThesaurusData::operator=(NSThesaurusData src)
{
  if (this == &src)
    return *this ;

	strcpy(ibui,     src.ibui) ;
  strcpy(labelFr,  src.labelFr) ;
  strcpy(labelNl,  src.labelNl) ;
  strcpy(icpc2,    src.icpc2) ;
  strcpy(icd10,    src.icd10) ;
  strcpy(icpc2_2,  src.icpc2_2) ;
  strcpy(icd10_2,  src.icd10_2) ;
  strcpy(icpc2_1X, src.icpc2_1X) ;
  strcpy(icd10_1X, src.icd10_1X) ;
  strcpy(icpc2_2X, src.icpc2_2X) ;
  strcpy(icd10_2X, src.icd10_2X) ;
  strcpy(icpc2_1Y, src.icpc2_1Y) ;
  strcpy(icd10_1Y, src.icd10_1Y) ;
  strcpy(icpc2_2Y, src.icpc2_2Y) ;
  strcpy(icd10_2Y, src.icd10_2Y) ;

	return *this ;
}

// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSThesaurusData::operator==(const NSThesaurusData& o)
{
	if (strcmp(ibui, o.ibui) == 0)
		return 1 ;
	else
		return 0 ;
}


// -----------------------------------------------------------------------------
// Met � z�ro les variables de la fiche
// -----------------------------------------------------------------------------
void
NSThesaurusData::metAZero()
{
	// Met les champs de donn�es � z�ro
  memset(ibui,     0, THESAURUS_IBUI_LEN + 1) ;
  memset(labelFr,  0, THESAURUS_LABEL_LEN + 1) ;
  memset(labelNl,  0, THESAURUS_LABEL_LEN + 1) ;
  memset(icpc2,    0, THESAURUS_ICPC2_LEN + 1) ;
  memset(icd10,    0, THESAURUS_ICD10_LEN + 1) ;
  memset(icpc2_2,  0, THESAURUS_ICPC2_LEN + 1) ;
  memset(icd10_2,  0, THESAURUS_ICD10_LEN + 1) ;
  memset(icpc2_1X, 0, THESAURUS_ICPC2_LEN + 1) ;
  memset(icd10_1X, 0, THESAURUS_ICD10_LEN + 1) ;
  memset(icpc2_2X, 0, THESAURUS_ICPC2_LEN + 1) ;
  memset(icd10_2X, 0, THESAURUS_ICD10_LEN + 1) ;
  memset(icpc2_1Y, 0, THESAURUS_ICPC2_LEN + 1) ;
  memset(icd10_1Y, 0, THESAURUS_ICD10_LEN + 1) ;
  memset(icpc2_2Y, 0, THESAURUS_ICPC2_LEN + 1) ;
  memset(icd10_2Y, 0, THESAURUS_ICD10_LEN + 1) ;
}

// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSThesaurus::NSThesaurus(NSContexte *pCtx)
            :NSThesaurusInfo(), NSFiche(pCtx)
{
}

// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSThesaurus::NSThesaurus(NSThesaurus& rv)
            :NSThesaurusInfo(rv), NSFiche(rv.pContexte)
{
}

// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSThesaurus::~NSThesaurus()
{
}

// -----------------------------------------------------------------------------
// Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSThesaurus::alimenteFiche()
{
  alimenteChamp(pDonnees->ibui,			THESAURUS_IBUI_FIELD,     THESAURUS_IBUI_LEN) ;
  alimenteChamp(pDonnees->labelFr,	THESAURUS_FR_LABEL_FIELD,	THESAURUS_LABEL_LEN) ;
  alimenteChamp(pDonnees->labelNl,	THESAURUS_NL_LABEL_FIELD,	THESAURUS_LABEL_LEN) ;
  alimenteChamp(pDonnees->icpc2,		THESAURUS_ICPC2_FIELD,		THESAURUS_ICPC2_LEN) ;
  alimenteChamp(pDonnees->icd10,		THESAURUS_ICD10_FIELD,		THESAURUS_ICD10_LEN) ;
  alimenteChamp(pDonnees->icpc2_2,  THESAURUS_ICPC2_2_FIELD,  THESAURUS_ICPC2_LEN) ;
  alimenteChamp(pDonnees->icd10_2,  THESAURUS_ICD10_2_FIELD,  THESAURUS_ICD10_LEN) ;
  alimenteChamp(pDonnees->icpc2_1X, THESAURUS_ICPC2_1X_FIELD, THESAURUS_ICPC2_LEN) ;
  alimenteChamp(pDonnees->icd10_1X, THESAURUS_ICD10_1X_FIELD, THESAURUS_ICD10_LEN) ;
  alimenteChamp(pDonnees->icpc2_2X, THESAURUS_ICPC2_2X_FIELD, THESAURUS_ICPC2_LEN) ;
  alimenteChamp(pDonnees->icd10_2X, THESAURUS_ICD10_2X_FIELD, THESAURUS_ICD10_LEN) ;
  alimenteChamp(pDonnees->icpc2_1Y, THESAURUS_ICPC2_1Y_FIELD, THESAURUS_ICPC2_LEN) ;
  alimenteChamp(pDonnees->icd10_1Y, THESAURUS_ICD10_1Y_FIELD, THESAURUS_ICD10_LEN) ;
  alimenteChamp(pDonnees->icpc2_2Y, THESAURUS_ICPC2_2Y_FIELD, THESAURUS_ICPC2_LEN) ;
  alimenteChamp(pDonnees->icd10_2Y, THESAURUS_ICD10_2Y_FIELD, THESAURUS_ICD10_LEN) ;
}

// -----------------------------------------------------------------------------
// Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSThesaurus::videFiche()
{
  videChamp(pDonnees->ibui,			THESAURUS_IBUI_FIELD,     THESAURUS_IBUI_LEN) ;
  videChamp(pDonnees->labelFr,	THESAURUS_FR_LABEL_FIELD,	THESAURUS_LABEL_LEN) ;
  videChamp(pDonnees->labelNl,	THESAURUS_NL_LABEL_FIELD,	THESAURUS_LABEL_LEN) ;
  videChamp(pDonnees->icpc2,		THESAURUS_ICPC2_FIELD,		THESAURUS_ICPC2_LEN) ;
  videChamp(pDonnees->icd10,		THESAURUS_ICD10_FIELD,		THESAURUS_ICD10_LEN) ;
  videChamp(pDonnees->icpc2_2,  THESAURUS_ICPC2_2_FIELD,  THESAURUS_ICPC2_LEN) ;
  videChamp(pDonnees->icd10_2,  THESAURUS_ICD10_2_FIELD,  THESAURUS_ICD10_LEN) ;
  videChamp(pDonnees->icpc2_1X, THESAURUS_ICPC2_1X_FIELD, THESAURUS_ICPC2_LEN) ;
  videChamp(pDonnees->icd10_1X, THESAURUS_ICD10_1X_FIELD, THESAURUS_ICD10_LEN) ;
  videChamp(pDonnees->icpc2_2X, THESAURUS_ICPC2_2X_FIELD, THESAURUS_ICPC2_LEN) ;
  videChamp(pDonnees->icd10_2X, THESAURUS_ICD10_2X_FIELD, THESAURUS_ICD10_LEN) ;
  videChamp(pDonnees->icpc2_1Y, THESAURUS_ICPC2_1Y_FIELD, THESAURUS_ICPC2_LEN) ;
  videChamp(pDonnees->icd10_1Y, THESAURUS_ICD10_1Y_FIELD, THESAURUS_ICD10_LEN) ;
  videChamp(pDonnees->icpc2_2Y, THESAURUS_ICPC2_2Y_FIELD, THESAURUS_ICPC2_LEN) ;
  videChamp(pDonnees->icd10_2Y, THESAURUS_ICD10_2Y_FIELD, THESAURUS_ICD10_LEN) ;
}

// -----------------------------------------------------------------------------
// Ouvre la table primaire et les index secondaires
// -----------------------------------------------------------------------------
DBIResult
NSThesaurus::open()
{
	char tableName[] = "Clinical_Labels.DB" ;

	// Appelle la fonction open() de la classe de base pour ouvrir l'index primaire
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL) ;
	return (lastError) ;
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSThesaurus::Create()
{
	return true ;
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSThesaurus::Modify()
{
	return true ;
}

// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSThesaurus&
NSThesaurus::operator=(NSThesaurus src)
{
  if (this == &src)
    return *this ;

	*pDonnees = *(src.pDonnees) ;
  
	return *this ;
}

// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSThesaurus::operator==(const NSThesaurus& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}

// -----------------------------------------------------------------------------
// Constructeur par d�faut
// -----------------------------------------------------------------------------
NSThesaurusInfo::NSThesaurusInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSThesaurusData() ;
}

// -----------------------------------------------------------------------------
// Constructeur � partir d'un NSEpiClasser
// -----------------------------------------------------------------------------
NSThesaurusInfo::NSThesaurusInfo(NSThesaurus *pContact)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSThesaurusData() ;

	// Copie les valeurs du NSEpiProbEven
	*pDonnees = *(pContact->pDonnees) ;
}

// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSThesaurusInfo::NSThesaurusInfo(NSThesaurusInfo& rv)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSThesaurusData() ;

	// Copie les valeurs du NSEpiProbEvenInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}

// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSThesaurusInfo::~NSThesaurusInfo()
{
	delete pDonnees ;
}

// -----------------------------------------------------------------------------
// arrange the result "as a" Classer record for a given classification
// -----------------------------------------------------------------------------
string
NSThesaurusInfo::getClasserString(string sClassif)
{
  if (string("") == sClassif)
    sClassif = string("6CISP") ;

  string sReturn = string("") ;

  if (strlen(sClassif.c_str()) < BASE_SENS_LEN)
    return sReturn ;

  if (string("6CISP") == string(sClassif, 0, BASE_SENS_LEN))
  {
    sReturn = string(pDonnees->icpc2) ;
    addALaClasser(&sReturn, string(pDonnees->icpc2_2)) ;
    addALaClasser(&sReturn, string(pDonnees->icpc2_1X)) ;
    addALaClasser(&sReturn, string(pDonnees->icpc2_2X)) ;
    addALaClasser(&sReturn, string(pDonnees->icpc2_1Y)) ;
    addALaClasser(&sReturn, string(pDonnees->icpc2_2Y)) ;
  }
  else if (string("6CIMA") == string(sClassif, 0, BASE_SENS_LEN))
  {
    sReturn = string(pDonnees->icd10) ;
    addALaClasser(&sReturn, string(pDonnees->icd10_2)) ;
    addALaClasser(&sReturn, string(pDonnees->icd10_1X)) ;
    addALaClasser(&sReturn, string(pDonnees->icd10_2X)) ;
    addALaClasser(&sReturn, string(pDonnees->icd10_1Y)) ;
    addALaClasser(&sReturn, string(pDonnees->icd10_2Y)) ;
  }
  return sReturn ;
}

void
NSThesaurusInfo::addALaClasser(string* pResult, string sCode)
{
  if ((NULL == pResult) || (string("") == sCode))
    return ;

  if (string("") != *pResult)
    *pResult += string(";") ;

  *pResult += sCode ;
}

// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSThesaurusInfo&
NSThesaurusInfo::operator=(NSThesaurusInfo src)
{
  if (this == &src)
    return *this ;

	*pDonnees = *(src.pDonnees) ;
  
  return *this ;
}

// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSThesaurusInfo::operator==(const NSThesaurusInfo& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}

// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes NSEpiClassif
//
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSEpiClassifData::NSEpiClassifData()
{
	// Met les champs de donn�es � z�ro
	metAZero() ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiClassifData::NSEpiClassifData(NSEpiClassifData& rv)
{
  strcpy(classification,  rv.classification) ;
	strcpy(code,            rv.code) ;
	strcpy(libelle,         rv.libelle) ;
	strcpy(chapitre,  	    rv.chapitre) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiClassifData::~NSEpiClassifData()
{
}


// -----------------------------------------------------------------------------
// Op�rateur =
// -----------------------------------------------------------------------------
NSEpiClassifData&
NSEpiClassifData::operator=(NSEpiClassifData src)
{
  if (this == &src)
    return *this ;

	strcpy(classification,  src.classification) ;
	strcpy(code,            src.code) ;
	strcpy(libelle,         src.libelle) ;
	strcpy(chapitre,  	    src.chapitre) ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiClassifData::operator==(const NSEpiClassifData& o)
{
	if ((strcmp(code,           o.code)           == 0) &&
      (strcmp(classification, o.classification) == 0) &&
      (strcmp(libelle,        o.libelle)        == 0) &&
      (strcmp(chapitre,       o.chapitre)       == 0))
		return 1 ;
	else
		return 0 ;
}

// -----------------------------------------------------------------------------
// Met � z�ro les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiClassifData::metAZero()
{
	// Met les champs de donn�es � z�ro
	memset(classification,  0, CLASSIF_CLASSIF_LEN + 1) ;
	memset(code,   		      0, CLASSIF_CODE_LEN + 1) ;
	memset(libelle,         0, CLASSIF_LIBELLE_LEN + 1) ;
	memset(chapitre,  	    0, CLASSIF_CHAPITRE_LEN + 1) ;
}

// -----------------------------------------------------------------------------
//  Constructeur
// -----------------------------------------------------------------------------
NSEpiClassif::NSEpiClassif(NSContexte *pCtx)
             :NSEpiClassifInfo(), NSFiche(pCtx)
{
}

// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiClassif::NSEpiClassif(NSEpiClassif& rv)
             :NSEpiClassifInfo(rv), NSFiche(rv.pContexte)
{
}

// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiClassif::~NSEpiClassif()
{
}

// -----------------------------------------------------------------------------
// Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSEpiClassif::alimenteFiche()
{
  alimenteChamp(pDonnees->classification, CLASSIF_CLASSIF_FIELD,  CLASSIF_CLASSIF_LEN) ;
  alimenteChamp(pDonnees->code, 		      CLASSIF_CODE_FIELD,     CLASSIF_CODE_LEN) ;
  alimenteChamp(pDonnees->libelle,        CLASSIF_LIBELLE_FIELD,  CLASSIF_LIBELLE_LEN) ;
  alimenteChamp(pDonnees->chapitre,  	    CLASSIF_CHAPITRE_FIELD, CLASSIF_CHAPITRE_LEN) ;
}


// -----------------------------------------------------------------------------
// Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSEpiClassif::videFiche()
{
  videChamp(pDonnees->classification, CLASSIF_CLASSIF_FIELD,  CLASSIF_CLASSIF_LEN) ;
  videChamp(pDonnees->code, 		      CLASSIF_CODE_FIELD,     CLASSIF_CODE_LEN) ;
  videChamp(pDonnees->libelle,        CLASSIF_LIBELLE_FIELD,  CLASSIF_LIBELLE_LEN) ;
  videChamp(pDonnees->chapitre,  	    CLASSIF_CHAPITRE_FIELD, CLASSIF_CHAPITRE_LEN) ;
}


// -----------------------------------------------------------------------------
// Ouvre la table primaire et les index secondaires
// -----------------------------------------------------------------------------
DBIResult
NSEpiClassif::open()
{
	char tableName[] = "CLASSIF.DB" ;

	// Appelle la fonction open() de la classe de base pour ouvrir l'index primaire
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL) ;
	return(lastError) ;
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiClassif::Create()
{
	return true ;
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
bool
NSEpiClassif::Modify()
{
	return true ;
}

// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiClassif&
NSEpiClassif::operator=(NSEpiClassif src)
{
  if (&src == this)
    return *this ;

	*pDonnees = *(src.pDonnees) ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiClassif::operator==(const NSEpiClassif& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


bool
NSEpiClassif::initArrayFromCodeList(string sClassification, ClasseStringVector* pVectCodes, NSEpiClassifArray* pResultArray)
{
  if ((NULL == pVectCodes) || (NULL == pResultArray))
    return false ;

  pResultArray->vider() ;

  if (pVectCodes->empty())
    return true ;

  for (iterString itCodes = pVectCodes->begin() ; pVectCodes->end() != itCodes ; itCodes++)
  {
    bool bSuccess = false ;

    if (strlen((*itCodes)->sItem.c_str()) <= CLASSIF_CODE_LEN)
    {
      CURProps curProps ;
      /* DBIResult lastError = */ DbiGetCursorProps(PrendCurseur(), curProps) ;
      Byte* pIndexRec = new Byte[curProps.iRecBufSize] ;
      memset(pIndexRec, 0, curProps.iRecBufSize) ;
      DbiPutField(PrendCurseur(), CLASSIF_CLASSIF_FIELD, pIndexRec, (Byte*) sClassification.c_str()) ;
      DbiPutField(PrendCurseur(), CLASSIF_CODE_FIELD,    pIndexRec, (Byte*) (*itCodes)->sItem.c_str()) ;

      lastError = chercheClefComposite("",
                                       0,
                                       keySEARCHEQ,
                                       dbiWRITELOCK,
                                       pIndexRec) ;
      delete[] pIndexRec ;

      if (lastError != DBIERR_NONE)
      {
        string sErrorText = string("Cannot find ") + (*itCodes)->sItem + string(" in Classif.db") ;
        pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      }
      else
      {
        lastError = getRecord() ;
        if (lastError != DBIERR_NONE)
        {
          string sErrorText = string("Problem reading ") + (*itCodes)->sItem + string(" in Classif.db") ;
          pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
        }
        else
          bSuccess = true ;
      }
    }

    if (bSuccess)
      pResultArray->push_back(new NSEpiClassifInfo(this)) ;
    else
      pResultArray->push_back(new NSEpiClassifInfo()) ;
  }

  return true ;
}

// -----------------------------------------------------------------------------
// Constructeur par d�faut
// -----------------------------------------------------------------------------
NSEpiClassifInfo::NSEpiClassifInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiClassifData() ;
}


// -----------------------------------------------------------------------------
// Constructeur � partir d'un NSEpiClasser
// -----------------------------------------------------------------------------
NSEpiClassifInfo::NSEpiClassifInfo(NSEpiClassif *pContact)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiClassifData() ;

	// Copie les valeurs du NSEpiProbEven
	*pDonnees = *(pContact->pDonnees) ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSEpiClassifInfo::NSEpiClassifInfo(NSEpiClassifInfo& rv)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSEpiClassifData() ;

	// Copie les valeurs du NSEpiProbEvenInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSEpiClassifInfo::~NSEpiClassifInfo()
{
	delete pDonnees ;
}

// -----------------------------------------------------------------------------
// Get ICPC category
// Based ICPC's design : symptoms < 30, pathologies >= 70, procedures in-between
// -----------------------------------------------------------------------------
ICPC_CATEGORY
NSEpiClassifInfo::getIcpcCategory()
{
  // Valid ICPC codes must be in the form Char Digit Digit (ex : R05)
  //
  if (strlen(pDonnees->code) < 3)
    return IcpcUndefined ;

  if (!isdigit(pDonnees->code[1]) || !isdigit(pDonnees->code[2]))
    return IcpcUndefined ;

  if (pDonnees->code[1] < '3')
    return IcpcSymptom ;

  if (pDonnees->code[1] >= '7')
    return IcpcPathology ;

  return IcpcProcedure ;
}

ICPC_PATHOLOGY
NSEpiClassifInfo::getIcpcPathology()
{
  return IcpcUndefinedPatho ;
}

// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSEpiClassifInfo&
NSEpiClassifInfo::operator=(NSEpiClassifInfo src)
{
  if (&src == this)
    return *this ;

	*pDonnees = *(src.pDonnees) ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSEpiClassifInfo::operator==(const NSEpiClassifInfo& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


NSEpiClassifInfoArray::~NSEpiClassifInfoArray()
{
  vider() ;
}

bool
NSEpiClassifInfoArray::ajouteElement(NSEpiClassifInfo *pElement)
{
  // Si l'�l�ment existe d�j�, on ne fait rien
  if (!(empty()))
    for (NSEpiClassifInfoIter i = begin() ; i != end() ; i++)
      if (*(*i) == *pElement)
        return false ;

  push_back(pElement) ;
  return true ;
}


void
NSEpiClassifInfoArray::vider()
{
  if (empty())
    return ;

  for (NSEpiClassifInfoIter i = begin() ; i != end() ; )
  {
    delete (*i) ;
    erase(i) ;
  }
}


// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes de NSEpiClassifArray
//
// -----------------------------------------------------------------------------


NSEpiClassifArray::NSEpiClassifArray()
  : NSEpiClassifInfoVector()
{
  sFileName = "" ;
  pDonnees  = NULL ;
}


NSEpiClassifArray::NSEpiClassifArray(string sFile)
  : NSEpiClassifInfoVector()
{
  sFileName = sFile ;
  pDonnees  = NULL ;
}


NSEpiClassifArray::~NSEpiClassifArray()
{
  vider() ;
}


bool
NSEpiClassifArray::fillArray()
{
  ifstream  inFile ;
  string    line ;

  inFile.open(sFileName.c_str()) ;
  if (!inFile)
    return false ;

  while (!inFile.eof())
  {
    getline(inFile, line) ;
    if (line != "")
    {
      // on ajoute dans l'EpiClassifArray ce qu'on vient de lire dans le fichier
      string  sClassif  = "" ;
      string  sCode     = "" ;
      string  sLibelle  = "" ;
      string  sChapitre = "" ;

      // recherche de la classif
      // le premier param�tre est l'ID dans la table, c'est pour cela qu'on
      // commence � partir de la premi�re tabulation
      size_t  posBeg = line.find("\t") ;
      size_t  posEnd = line.find("\t", posBeg + 1) ;
      if ((posEnd != string::npos) && (posBeg != string::npos) && (posBeg < posEnd))
        sClassif = string(line, posBeg + 1, posEnd - (posBeg + 1)) ;
      else
        return false ;

      // recherche du code
      posBeg  = posEnd ;
      posEnd  = line.find("\t", posBeg + 1) ;
      if ((posEnd != string::npos) && (posBeg != string::npos) && (posBeg < posEnd))
        sCode = string(line, posBeg + 1, posEnd - (posBeg + 1)) ;
      else
        return false ;

      // recherche du libelle
      posBeg  = posEnd ;
      posEnd  = line.find("\t", posBeg + 1) ;
      if ((posEnd != string::npos) && (posBeg != string::npos) && (posBeg < posEnd))
        sLibelle = string(line, posBeg + 1, posEnd - (posBeg + 1)) ;
      else
        return false ;

      // recherche du chapitre
      posBeg  = posEnd ;
      posEnd  = strlen(line.c_str()) ;
      if ((posEnd != string::npos) && (posBeg != string::npos) && (posBeg < posEnd))
        sChapitre = string(line, posBeg + 1, posEnd - (posBeg + 1)) ;
      else
        return false ;

      if ((sClassif != "") && (sCode != "") && (sLibelle != ""))
      {
        NSEpiClassifInfo *pEpiClassifInfoTemp = new NSEpiClassifInfo() ;
        strcpy(pEpiClassifInfoTemp->pDonnees->classification, sClassif.c_str()) ;
        strcpy(pEpiClassifInfoTemp->pDonnees->code,           sCode.c_str()) ;
        strcpy(pEpiClassifInfoTemp->pDonnees->libelle,        sLibelle.c_str()) ;
        strcpy(pEpiClassifInfoTemp->pDonnees->chapitre,       sChapitre.c_str()) ;

        push_back(new NSEpiClassifInfo(*pEpiClassifInfoTemp)) ;
        delete pEpiClassifInfoTemp ;
      }
      else
        return false ;
    }
  }
  inFile.close() ;
  return true ;
}


bool
NSEpiClassifArray::searchKey(string sClassif, string sCode)
{
  for (NSEpiClassifInfoIter iter = begin() ; iter != end() ; iter++)
  {
    if ((strcmp((*iter)->pDonnees->classification,  sClassif.c_str()) == 0)  &&
        (strcmp((*iter)->pDonnees->code,            sCode.c_str())    == 0))
    {
      pDonnees  = (*iter)->pDonnees ;
      return true ;
    }
  }
  return false ;
}


bool
NSEpiClassifArray::vider()
{
  if (empty())
    return true ;

  for (NSEpiClassifInfoIter iter = begin() ; iter != end() ; )
  {
    delete (*iter) ;
    erase(iter) ;
  }
  return true ;
}


// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes NSCodPrestArray
//
// -----------------------------------------------------------------------------


/*
// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSCodPrestArray::NSCodPrestArray(NSCodPrestArray& rv)
  : NSFicheCodPrestArray()
{
  for (NSCodPrestIter i = rv.begin() ; i != rv.end() ; i++)
    push_back(new NSCodPrestInfo(*(*i))) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
void
NSCodPrestArray::vider()
{
  for (NSCodPrestIter i = begin() ; i != end() ; )
  {
    delete (*i) ;
    erase(i) ;
  }
}


NSCodPrestArray::~NSCodPrestArray()
{
	vider() ;
}
*/

//////////////////////////// fin du fichier EpTables.cpp

