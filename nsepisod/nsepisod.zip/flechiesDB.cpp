// -----------------------------------------------------------------------------//    flechiesDB.CPP//    NAUTILUS janvier 2002////    Impl�mentation des objets de base de donn�e pour "flechies.db"// -----------------------------------------------------------------------------#include <cstring.h>#include "nsepisod\flechiesDB.h"// -----------------------------------------------------------------------------// Impl�mentation des m�thodes NSFlechies// -----------------------------------------------------------------------------// -----------------------------------------------------------------------------//  Constructeur// -----------------------------------------------------------------------------NSFlechiesData::NSFlechiesData(){	//	// Met les champs de donn�es � z�ro	//	metAZero() ;}

// -----------------------------------------------------------------------------
//  Constructeur copie
// -----------------------------------------------------------------------------
NSFlechiesData::NSFlechiesData(NSFlechiesData& rv)
{	strcpy(id,					rv.id) ;	strcpy(libelle, 		rv.libelle) ;	strcpy(code,  		  rv.code) ;}
// -----------------------------------------------------------------------------
//  Destructeur
// -----------------------------------------------------------------------------
NSFlechiesData::~NSFlechiesData()
{
}

// -----------------------------------------------------------------------------
//  Op�rateur =
// -----------------------------------------------------------------------------
NSFlechiesData&
NSFlechiesData::operator=(NSFlechiesData src)
{
	strcpy(id,					src.id) ;
	strcpy(libelle, 		src.libelle) ;
	strcpy(code,  		  src.code) ;

	return (*this) ;
}

// -----------------------------------------------------------------------------
//  Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSFlechiesData::operator==(const NSFlechiesData& o)
{
	if ((strcmp(id,			 o.id) == 0) &&
			(strcmp(libelle, o.libelle) == 0) &&
			(strcmp(code,    o.code)    == 0))
		return 1 ;
	else
		return 0 ;
}

// -----------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
// -----------------------------------------------------------------------------
void
NSFlechiesData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(id,						0, FLECHIES_ID_LEN + 1) ;
	memset(libelle, 	  	0, FLECHIES_LIBELLE_LEN + 1) ;
	memset(code,   		    0, FLECHIES_CODE_LEN + 1) ;
}

// -----------------------------------------------------------------------------
//  Constructeur
// -----------------------------------------------------------------------------
NSFlechies::NSFlechies(NSContexte* pCtx, int iBase)
	:	NSFlechiesInfo(),
		NSFiche(pCtx),
		iTypeBase(iBase)
{
	switch (iTypeBase)
	{
		case flechies	:	sFileName   = string("flechies.db") ;
										sFileLib    = string("formes fl�chies") ;
										break ;

		case ortho		:	sFileName   = string("flxortho.db") ;
										sFileLib    = string("fautes d'orthographes classiques") ;
										break ;

		case local		:	sFileName   = string("flxlocal.db") ;
										sFileLib    = string("termes locaux") ;
										break ;

		case express	: sFileName   = string("flxexpre.db") ;
										sFileLib    = string("expressions classiques") ;
										break ;

		default				: sFileName   = string("flechies.db") ;
										sFileLib    = string("formes fl�chies") ;
										break ;
		}
}

// -----------------------------------------------------------------------------
//  Constructeur copie
// -----------------------------------------------------------------------------
NSFlechies::NSFlechies(NSFlechies& rv)
	:	NSFlechiesInfo(rv),
		NSFiche(rv.pContexte)
{
		iTypeBase   = rv.iTypeBase;
		sFileName   = rv.sFileName;
}

// -----------------------------------------------------------------------------
//  Destructeur
// -----------------------------------------------------------------------------
NSFlechies::~NSFlechies()
{
}

// -----------------------------------------------------------------------------
//  Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSFlechies::alimenteFiche()
{
	alimenteChamp(pDonnees->id,				FLECHIES_ID_FIELD,			FLECHIES_ID_LEN) ;
	alimenteChamp(pDonnees->libelle,	FLECHIES_LIBELLE_FIELD,	FLECHIES_LIBELLE_LEN) ;
	alimenteChamp(pDonnees->code,			FLECHIES_CODE_FIELD, 	  FLECHIES_CODE_LEN) ;
}
// -----------------------------------------------------------------------------
//  Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSFlechies::videFiche()
{
	videChamp(pDonnees->id,						FLECHIES_ID_FIELD,			FLECHIES_ID_LEN) ;
	videChamp(pDonnees->libelle, 	  	FLECHIES_LIBELLE_FIELD, FLECHIES_LIBELLE_LEN) ;
	videChamp(pDonnees->code, 		  	FLECHIES_CODE_FIELD, 	  FLECHIES_CODE_LEN) ;
}

// -----------------------------------------------------------------------------
//  Ouvre la table primaire et les index secondaires
// -----------------------------------------------------------------------------
DBIResult
NSFlechies::open(bool bOpenShared)
{
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(sFileName.c_str(), NSF_GUIDES, bOpenShared) ;
	return (lastError) ;

}// -----------------------------------------------------------------------------
//---------------------------------------------------------------------------
bool
NSFlechies::Create()
{
	return true ;
}

// -----------------------------------------------------------------------------
//---------------------------------------------------------------------------
bool
NSFlechies::Modify()
{
	return true ;
}

// -----------------------------------------------------------------------------
//  Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSFlechies&
NSFlechies::operator=(NSFlechies src)
{
	*pDonnees = *(src.pDonnees) ;
	iTypeBase = src.iTypeBase ;
	return *this ;
}

// -----------------------------------------------------------------------------
//  Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSFlechies::operator==(const NSFlechies& o)
{
	 return (*pDonnees == *(o.pDonnees));
}

// -----------------------------------------------------------------------------
//  Constructeur par d�faut
// -----------------------------------------------------------------------------
NSFlechiesInfo::NSFlechiesInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSFlechiesData();
}

// -----------------------------------------------------------------------------
//  Constructeur � partir d'un NSFlechies
// -----------------------------------------------------------------------------
NSFlechiesInfo::NSFlechiesInfo(NSFlechies *pFlechies)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSFlechiesData() ;
	//
	// Copie les valeurs du NSEpiContact
	//
	*pDonnees = *(pFlechies->pDonnees) ;
}

// -----------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSFlechiesInfo::NSFlechiesInfo(NSFlechiesInfo& rv)
{	// Cr�e l'objet de donn�es
	pDonnees = new NSFlechiesData() ;

	// Copie les valeurs du NSFlechiesInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}

// -----------------------------------------------------------------------------
//  Destructeur
// -----------------------------------------------------------------------------
NSFlechiesInfo::~NSFlechiesInfo()
{
	delete pDonnees ;
}

// -----------------------------------------------------------------------------
//  Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSFlechiesInfo&
NSFlechiesInfo::operator=(NSFlechiesInfo src)
{
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}

// -----------------------------------------------------------------------------
//  Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSFlechiesInfo::operator==(const NSFlechiesInfo& o)
{
	 return (*pDonnees == *(o.pDonnees)) ;
}

//////////////////////////// fin du fichier flechiesDB.cpp