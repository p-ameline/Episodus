// -----------------------------------------------------------------------------// nsvueref.cpp
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// $Revision: 1.7 $
// $Author: philippe $
// $Date: 2005/06/09 12:59:23 $
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Copyright Nautilus, 2004
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � g�rer et traiter les
// informations de sant� d'une personne.
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to manage and process
// a person's health data.
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------
#include <owl\owlpch.h>#include <owl\dc.h>
#include <owl\inputdia.h>
#include <owl\chooseco.h>
#include <owl\gdiobjec.h>
#include <owl\docmanag.h>
#include <owl\filedoc.h>
#include <owl\printer.h>
#include <classlib\arrays.h>
#include <iostream.h>
#include <cstring.h>
#include <owl/controlb.h>
#include <owl/buttonga.h>
#include <owl/oleview.h>

#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"

#include "nautilus\nsvueref.h"
#include "nautilus\nscrdoc.h"		// pour r�cup�rer sFichDecod

#include "nsbb\nsattvaltools.h"

// -----------------------------------------------------------------------------
//
// class NSRefVue
//
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSRefVue, TWindowView)
  // EV_WM_SYSCOMMAND,
  // EV_WM_SYSKEYDOWN,
  EV_WM_KEYDOWN,
  EV_WM_VSCROLL,
  EV_WM_HSCROLL,
  EV_MESSAGE(WM_MOUSEWHEEL, EvMouseWheel),
  EV_COMMAND(CM_IMPRIME, CmPublier),
  EV_COMMAND(CM_COMPOSE, CmComposer),  EV_COMMAND(CM_VISUAL, CmVisualiser),
END_RESPONSE_TABLE ;

// -----------------------------------------------------------------------------
// Function    : NSRefVue::NSRefVue(NSRefDocument& doc, TWindow* parent)
// Arguments   : doc 	: NSRefDocument � afficher
// Description : Constructeur
// Retour      : Rien
// -----------------------------------------------------------------------------
NSRefVue::NSRefVue(NSRefDocument& doc, NSContexte* pCtx, TWindow* parent)         :TWindowView(doc, parent), NSRoot(pCtx)
{
  Attr.AccelTable = REFVIEW_ACCEL ;

	pDoc = &doc ;
	HautGcheFenetre.x = HautGcheFenetre.y = 0 ;
	ToolBar 	 = 0 ;
	pBigBoss  = 0 ;
	ImpDriver = "" ;
	ImpDevice = "" ;
	ImpOutput = "" ;
	LargeurPolice = 0 ;

  iLigneEnCours = 0 ;
  iLignePrec = 0 ;
  iLigneSelect = 0 ;

  pMUEViewMenu = 0 ;

	pTIC = new TIC("DISPLAY", NULL, NULL) ;
	pTIC->SetMapMode(MM_LOMETRIC) ;
}

// -----------------------------------------------------------------------------
// Function    : NSRefVue::~NSRefVue()
// Description : Destructeur
// -----------------------------------------------------------------------------
NSRefVue::~NSRefVue()
{
	delete pTIC ;
  pTIC = 0 ;

  if (pMUEViewMenu)
  	delete pMUEViewMenu ;

  if(pBigBoss)
  {
    delete pBigBoss ;
    pBigBoss = 0 ;
  }

  if (0 != hAccelerator)
  {
    DestroyAcceleratorTable(hAccelerator) ;
    hAccelerator = 0 ;
  }
}

// -----------------------------------------------------------------------------// Fonction    : NSRefVue::SetupWindow()// Arguments   : Aucun
// Description : Initialise la fen�tre
// Retour      : Rien
// -----------------------------------------------------------------------------
void NSRefVue::SetupWindow()
{
	// Pr�paration des �l�ments de mise en page du document
	InitAspect('N') ;
}

bool
NSRefVue::PreProcessMsg(MSG &msg)
{
  PRECONDITION(GetHandle()) ;
  return hAccelerator ? ::TranslateAccelerator(GetHandle(), hAccelerator, &msg) : false ;
}

// -----------------------------------------------------------------------------
// Function    : NSRefVue::InitAspect(char type)
// Arguments   : Aucun
// Description : Initialise les para�tres de mise en page du document
// Returns     : true/false
// -----------------------------------------------------------------------------
bool
NSRefVue::InitAspect(char type)
{
	// R�cup�re les donn�es concernant l'imprimante
	if (!InitialiseImpData())
  	return false ;

	// Initialise les styles de paragraphes et les polices � partir de N.MOD
	if (!InitialiseMode(type))
  	return false ;

	if (!InitialisePolicesImp())
  	return false ;

	return true ;
}


// -----------------------------------------------------------------------------// Function    : NSRefVue::Paint(TDC& dc, bool, TRect& RectAPeindre)// Arguments   :	dc 						: device contexte de la fen�tre
//					  		RectAPeindre	: Rectangle � repeindre
// Description : Peint/repeint tout/une partie de la fen�tre
// Returns     : Rien
// -----------------------------------------------------------------------------
void
NSRefVue::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectAPeindre)
{
	// Iterates through the array of line objects.
	const   NSLigne Ligne ;
  int     minLigne, maxLigne ;
	NS_CLASSLIB::TRect*  pRectDocument ;
	NS_CLASSLIB::TRect	  BoiteNormale ;
	NS_CLASSLIB::TPoint  Points[2] ;
	int	  iAncDC ;
	iAncDC = dc.SaveDC() ;

	// Fixe la m�trique et l'origine
	dc.SetMapMode(MM_LOMETRIC) ;

	// Stockage des points sup�rieurs gauches et inf�rieurs droits du rectangle
	Points[0] = RectAPeindre.TopLeft() ;
	Points[1] = RectAPeindre.BottomRight() ;

	// Transformation de ces points en coordonn�es logiques
	dc.DPtoLP(Points, 2) ;

	// Calcul du rectangle du document qui correspond au RectAPeindre de
	// l'�cran
	// ATTENTION : dans le mode MM_LOMETRIC les coordonn�es en ordonn�es
	//				  sont n�gatives
	pRectDocument = new NS_CLASSLIB::TRect(Points[0], Points[1]) ;
	*pRectDocument = pRectDocument->Offset(HautGcheFenetre.x, HautGcheFenetre.y) ;
	pRectDocument->Normalized() ;

	// On demande � toutes les lignes concern�es de se repeindre
  NSLignesArrayIter iter ;
  int ligneEnCours = 1 ;
	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;

  // calcul des lignes min et max de s�lection
  if ((iLigneEnCours + iLigneSelect) < iLigneEnCours)
  {
  	minLigne = iLigneEnCours + iLigneSelect;
    maxLigne = iLigneEnCours;
  }
  else
  {
  	minLigne = iLigneEnCours;
    maxLigne = iLigneEnCours + iLigneSelect;
  }

  // repeinte de la zone d'affichage
  for (iter = Lignes.begin() ; iter != Lignes.end() ; iter++, ligneEnCours++)
	{
		BoiteNormale = (*iter)->Boite ;
		BoiteNormale.Normalized() ;
		if ((BoiteNormale.right  >= pRectDocument->left)  &&
			 	(BoiteNormale.left   <= pRectDocument->right) &&
			 	(BoiteNormale.bottom <= pRectDocument->top)   &&
			 	(BoiteNormale.top 	 >= pRectDocument->bottom))
		//  ATTENTION : la m�thode Touches de TRect ne fonctionne pas
		//	if (pRectDocument->Touches(BoiteNormale))
    {
    	UINT iPhrase = (*iter)->iNumPhrase;
      NSCRPhrArrayIter it;
      for (it = CRDoc->aCRPhrases.begin(); (it != CRDoc->aCRPhrases.end()) && ((*it)->iNumero != iPhrase); it++)
      	;
      if (it != CRDoc->aCRPhrases.end())
      {
      	if ((*it)->aLesions.empty())
        	(*iter)->PeindreCurseur(dc, &HautGcheFenetre, this, NSLIGNEPNT_ECRAN, false) ;
        else
        	(*iter)->PeindreCurseur(dc, &HautGcheFenetre, this, NSLIGNEPNT_ECRAN) ;
      }

      // Affichage du bloc s�lectionn� en inverse vid�o
      if ((ligneEnCours >= minLigne) && (ligneEnCours <= maxLigne))
      	(*iter)->Peindre(dc, &HautGcheFenetre, this, NSLIGNEPNT_ECRAN, true);
      else
      	(*iter)->Peindre(dc, &HautGcheFenetre, this, NSLIGNEPNT_ECRAN);
    }
	}
	delete pRectDocument ;
  pRectDocument = 0 ;
	dc.RestoreDC(iAncDC) ;
}


// -----------------------------------------------------------------------------
// Function    : NSRefVue::PaintPrnt(TDC& dc, bool, TRect& RectAPeindre)
// Arguments   : dc 				: device contexte de la fen�tre
//					  	 RectAPeindre : Rectangle � repeindre
// Description : Peint/repeint sur imprimante
// Returns     : Rien
// -----------------------------------------------------------------------------
void
NSRefVue::PaintPrnt(TDC& dc, bool, int page, NS_CLASSLIB::TRect& RectAPeindre)
{
	// Iterates through the array of line objects.
	const   NSLigne Ligne ;
	NS_CLASSLIB::TRect*  pRectDocument ;
	NS_CLASSLIB::TRect	  BoiteNormale ;
	NS_CLASSLIB::TPoint  Points[2] ;
	int	  iAncDC ;
	iAncDC = dc.SaveDC() ;

	// Fixe la m�trique ; par d�faut c'est le pixel, mais le mode MM_LOMETRIC
	// est beaucoup plus commode
	dc.SetMapMode(MM_LOMETRIC) ;

	// Stockage des points sup�rieurs gauches et inf�rieurs droits du rectangle
	Points[0] = RectAPeindre.TopLeft() ;
	Points[1] = RectAPeindre.BottomRight() ;

	// Transformation de ces points en coordonn�es logiques
	dc.DPtoLP(Points, 2) ;

	// Calcul du rectangle du document qui correspond au RectAPeindre de
	// l'imprimante
	// ATTENTION : dans le mode MM_LOMETRIC les coordonn�es en ordonn�es
	//				  sont n�gatives
	pRectDocument = new NS_CLASSLIB::TRect(Points[0], Points[1]) ;
	*pRectDocument = pRectDocument->Offset(HautGcheFenetre.x, HautGcheFenetre.y) ;
	pRectDocument->Normalized() ;

	// On demande � toutes les lignes concern�es de se repeindre
  //	UINT taille = LignesPrnt.ArraySize();
  NSLignesArrayIter iter ;
  //	for (UINT i = 0; i < taille; i++)
  for (iter = LignesPrnt.begin() ; iter != LignesPrnt.end() ; iter++)
	{
		//Ligne = LignesPrnt[i] ;
		BoiteNormale = (*iter)->Boite ;
		BoiteNormale.Normalized() ;
		if ((Ligne.numPage == page) &&
			 	(BoiteNormale.right  >= pRectDocument->left)  &&
			 	(BoiteNormale.left   <= pRectDocument->right) &&
			 	(BoiteNormale.bottom <= pRectDocument->top)   &&
			 	(BoiteNormale.top 	 >= pRectDocument->bottom))
    	//  ATTENTION : la m�thode Touches de TRect ne fonctionne pas
    	//	if (pRectDocument->Touches(BoiteNormale))
			(*iter)->Peindre(dc, &HautGcheFenetre, this, NSLIGNEPNT_PRNT) ;
	}

	delete pRectDocument ;
  pRectDocument = 0 ;
	dc.RestoreDC(iAncDC) ;
}

#ifdef UNICODE
  #define GETDEFAULTPRINTER "GetDefaultPrinterW"
#else
  #define GETDEFAULTPRINTER "GetDefaultPrinterA"
#endif

// Size of internal buffer used to hold "printername,drivername,portname"
// string. You may have to increase this for huge strings.
#define MAXBUFFERSIZE 250

// -----------------------------------------------------------------------------
// Fonction    : NSRefVue::InitialiseImpData(void)
// Arguments   : Aucun
// Description : Initialise les variables concernant l'imprimante
// Retourne    : true/false
// -----------------------------------------------------------------------------
bool
NSRefVue::InitialiseImpData()
{
	string ps = string("Entering InitialiseImpData") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubSteps) ;

  OSVERSIONINFO osv ;

  // What version of Windows are you running?
  osv.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
  GetVersionEx(&osv);

  char cBuffer[MAXBUFFERSIZE] ;

  char szDevice[MAXBUFFERSIZE] ;
  char szDriver[MAXBUFFERSIZE] ;
  char szOutput[MAXBUFFERSIZE] ;

  // If Windows NT, use the GetDefaultPrinter API for Windows 2000,
  // or GetProfileString for version 4.0 and earlier.
  if (osv.dwPlatformId == VER_PLATFORM_WIN32_NT)
  {
    ps = string("Detected platform Win 32 NT4 or later") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

    if (osv.dwMajorVersion >= 5) // Windows 2000 or later (use explicit call)
    {
      ps = string("Detected platform Windows 2000 or later") ;
      pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

      TModule* pWinspoolModule = new TModule("winspool.drv", TRUE) ;
      if (!pWinspoolModule)
      {
        ps = string("Can't load winspool.drv") ;
        pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;
        ps = string("InitialiseImpData returns false") ;
        pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubSteps) ;
        return false ;
      }

      BOOL (FAR* fnGetDefaultPrinter)( LPTSTR pszBuffer, LPDWORD pcchBuffer ) ;
      (FARPROC) fnGetDefaultPrinter = pWinspoolModule->GetProcAddress(GETDEFAULTPRINTER) ;
      if (!fnGetDefaultPrinter)
      {
        delete pWinspoolModule ;

        ps = string("Can't get default printer function from winspool.drv") ;
        pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;
        ps = string("InitialiseImpData returns false") ;
        pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubSteps) ;
        return false ;
      }

      char  cBuffer[MAXBUFFERSIZE] ;
      DWORD wSize = MAXBUFFERSIZE ;

      bool bFlag = (*fnGetDefaultPrinter)(cBuffer, &wSize) ;
      if (!bFlag)
      {
        delete pWinspoolModule ;

        ps = string("Default printer function failed") ;
        pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;
        ps = string("InitialiseImpData returns false") ;
        pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubSteps) ;
        return false ;
      }

      delete pWinspoolModule ;

      ps = string("Detected default printer: ") + string(cBuffer) ;
      pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

      strcpy(szDevice, cBuffer) ;
      strcpy(szDriver, "winspool") ;
      strcpy(szOutput, "unknown") ;
    }

    else // NT4.0 or earlier
    {
      char cBuffer[MAXBUFFERSIZE] ;

      ps = string("Detected platform NT4 or earlier") ;
      pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

      // Retrieve the default string from Win.ini (the registry).
      // String will be in form "printername,drivername,portname".
      if (GetProfileString("windows", "device", ",,,", cBuffer, MAXBUFFERSIZE) <= 0)
        return false ;

      char *szPtrDevice, *szPtrDriver, *szPtrOutput ;

      if (!(szPtrDevice = strtok(cBuffer, ",")) ||
          !(szPtrDriver = strtok(NULL, ", "))		 ||
          !(szPtrOutput = strtok(NULL, ", ")))
        return false ;

      strcpy(szDevice, szPtrDevice) ;
      strcpy(szDriver, szPtrDriver) ;
      strcpy(szOutput, szPtrOutput) ;
    }
  }
  // If Windows 95 or 98, use EnumPrinters.
  else
  {
	  char 	 szPrinter[64] ;
	  // R�cup�ration de l'imprimante par d�faut dans WIN.INI
	  GetProfileString("windows", "device", "", szPrinter, 64) ;

    char *szPtrDevice, *szPtrDriver, *szPtrOutput ;

    if (!(szPtrDevice = strtok(szPrinter, ",")) ||
      !(szPtrDriver = strtok(NULL, ", "))		 ||
      !(szPtrOutput = strtok(NULL, ", ")))
      return false ;

    strcpy(szDevice, szPtrDevice) ;
    strcpy(szDriver, szPtrDriver) ;
    strcpy(szOutput, szPtrOutput) ;
  }

	// Stockage des r�f�rences de l'imprimante utilis�e
	ImpDriver = string(szDriver) ;
	ImpDevice = string(szDevice) ;
	ImpOutput = string(szOutput) ;
	//ptrInit(&ImpDriver, szDriver) ;
	//ptrInit(&ImpDevice, szDevice) ;
	//ptrInit(&ImpOutput, szOutput) ;

	// Prise d'un DC d'information
	TIC* pDICImprimante = new TIC(szDriver, szDevice, szOutput) ;

	// Initialisation du rectangle de d�limitation d'une page � partir de
	// la taille de la feuille de papier
	pDICImprimante->SetMapMode(MM_LOMETRIC) ;
	RectangleGlobal.left 	 = 0 ;
	RectangleGlobal.top  	 = 0 ;

	// ATTENTION : GetDeviceCaps donne une taille en millim�tres.
	//             Dans le mode MM_LOMETRIC, les y sont en n�gatif.
	RectangleGlobal.right  = pDICImprimante->GetDeviceCaps(HORZSIZE) * 10 ;
	RectangleGlobal.bottom = - pDICImprimante->GetDeviceCaps(VERTSIZE) * 10 ;
	delete pDICImprimante ;
  pDICImprimante = 0 ;
	return true ;
}


// -----------------------------------------------------------------------------
// Fonction    : NSRefVue::InitialisePolicesImp(void)
// Arguments   : Aucun
// Description : Initialise les variables concernant l'imprimante
// Retourne    : true/false
// -----------------------------------------------------------------------------
bool
NSRefVue::InitialisePolicesImp()
{
  // si on a pas d'imprimante s�lectionn�e on sort
  if ((ImpDriver == "") || (ImpDevice == "") || (ImpOutput == ""))
  	return false ;

	NSFont* 	        pPoliceImprimante ;
	NSFont	            PoliceSouhaitee ;
	TFont*	            pPolice, pPoliceEcran ;
	TEXTMETRIC          tm ;
	char		        szNomPolice[LF_FACESIZE] ;
	NS_CLASSLIB::TPoint	PointTransfert ;

	// Cr�ation d'un objet de contexte d'information pour l'imprimante
	TIC* pDICImprimante = new TIC(ImpDriver.c_str(), ImpDevice.c_str(), ImpOutput.c_str()) ;
	if (pDICImprimante == 0)
		return false ;
	TIC* pDICEcran = new TIC("DISPLAY", NULL, NULL) ;
	if (pDICEcran == 0)
	{
		delete pDICImprimante ;
    pDICImprimante = 0 ;
		return false ;
	}

	// Pour le DIC d'imprimante, Twips et Twips Logiques sont identiques
	pDICImprimante->SetMapMode(MM_TWIPS) ;

	// On passe le DIC d'�cran en mode topographique "Twips Logiques"
	pDICEcran->SetMapMode(MM_ANISOTROPIC) ;
	NS_CLASSLIB::TSize* pTaille = new NS_CLASSLIB::TSize(1440, 1440) ;
	pDICEcran->SetWindowExt(*pTaille) ;
	pTaille->cx = pDICEcran->GetDeviceCaps(LOGPIXELSX) ;
	pTaille->cy = pDICEcran->GetDeviceCaps(LOGPIXELSY) ;
	pDICEcran->SetViewportExt(*pTaille) ;
	delete pTaille ;
  pTaille = 0 ;

	// Pour chaque police demand�e,
	// on r�cup�re la police imprimante qui correspond
	for (FontIter i = StylesPolice.begin() ; i != StylesPolice.end() ; i++)
	{
		PoliceSouhaitee = *(*i) ;

		// La taille de la police, exprim�e en points doit �tre convertie
		// en unit� physiques (elle est d'abord * 20 pour avoir des twips)
		PoliceSouhaitee.logFont.lfHeight = PoliceSouhaitee.logFont.lfHeight * 20 ;
		PoliceSouhaitee.logFont.lfWidth 	= PoliceSouhaitee.logFont.lfWidth  * 20 ;

		// Cr�ation d'une TFont � partir de la NSFont contenue dans l'Array
		pPolice = new TFont(&(PoliceSouhaitee.logFont)) ;

		// S�lection de la Police pour le DC imprimante
		pDICImprimante->SelectObject(*pPolice) ;
		delete pPolice ;
    pPolice = 0 ;

		// R�cup�ration de ses param�tres r�els
		// la taille est r�cup�r�e par GetTextMetrics : donc en unit� logique
		pPoliceImprimante = new NSFont(pDICImprimante) ;
		PointTransfert.x = pPoliceImprimante->logFont.lfHeight ;
		PointTransfert.y = pPoliceImprimante->logFont.lfWidth ;

		// Comme on veut des unit�s physiques d'�cran, on convertit ces TWIPS
		// avec le DIC d'�cran
		pDICEcran->LPtoDP(&PointTransfert) ;
		pPoliceImprimante->logFont.lfHeight = PointTransfert.x ;
		pPoliceImprimante->logFont.lfWidth  = PointTransfert.y ;

		// Ajout de l'objet � l'Array
		StylesPolImp.push_back(new NSFont(*pPoliceImprimante)) ;
		delete pPoliceImprimante ;
    pPoliceImprimante = 0 ;
	}
  
	delete pDICImprimante ;
  pDICImprimante = 0 ;
	delete pDICEcran ;
  pDICEcran = 0 ;
	return true ;
}

// -----------------------------------------------------------------------------// Fonction	   : NSRefVue::InitialiseMode(char type)// Arguments 	 : type : cat�gorie de mod�le (N pour CR, M pour Magic)
// Description : Initialise le style du document � partir du fichier N.MOD
// Retourne	   : true/false
// -----------------------------------------------------------------------------
bool
NSRefVue::InitialiseMode(char type)
{
	string  		   Chaine, ChaineNom, ChaineContenu ;
	char	 		   nomFichier[20], buffer[201] ;
	short	 		   etatEnCours ;
	size_t	 		   recherche ;
	NSFont*	 		   pPolice ;
	NSStyleParagraphe* pParagraphe ;
	NSCadreDecor* 	   pCadre ;
  NSPage*			   pPage ;
  string			   sPathMod = pContexte->PathName("FPER") ;
  string             sFichierMod ;

	ifstream inFile ;
	//
	// Tentative d'ouverture du fichier sp�cifique � l'utilisateur
	/******
	strcpy(nomFichier, "N") ;
	nomFichier[0] = type ;
	strcat(nomFichier, pDoc->pSuper->pUtilisateur->pDonnees->indice) ;
	strcat(nomFichier, ".MOD") ;
  sFichierMod = sPathMod + string(nomFichier) ;
	inFile.open(sFichierMod.c_str()) ;
	//
	// Si la tentative a �chou�, ouverture du fichier standard
	//
	if (!inFile)
	{
    *****/

    strcpy(nomFichier, "N.MOD") ;
    nomFichier[0] = type ;
    sFichierMod = sPathMod + string(nomFichier) ;
    inFile.open(sFichierMod.c_str()) ;
    if (!inFile)
    {
      erreur("Impossible d'ouvrir le fichier N.MOD", standardError, 0, GetHandle()) ;
      return false ;
    }
		/* if (!inFile)
			return InitialiseModeDefaut(); */
	// }

	// etatEnCours : 1 = Cadre, 2 = Police, 3 = Paragraphe, 4 = Page
	etatEnCours = 0;

	// Lecture du fichier	inFile.unsetf(ios::skipws) ;
	//while (inFile >> Chaine)
	while (inFile.getline(buffer, 200))
	{
		Chaine = buffer ;

		// Enl�ve les blancs au d�but et � la fin de la Chaine
    strip(Chaine) ;

		// Commentaire ou ligne vierge : on ne fait rien
		if ((strlen(Chaine.c_str()) == 0) ||
			 ((Chaine[0] == '/') && (Chaine[1] == '/')))
		{
		}

		// Si on rencontre un d�limiteur de Section
		else if ((Chaine[0] == '[') && (Chaine[strlen(Chaine.c_str())-1] == ']'))
		{
			// On en termine avec l'�l�ment pr�c�dent
			// (les polices sont mises en place par la fct de traitement)
			switch (etatEnCours)
			{
      	case 1 :	Cadres.push_back(new NSCadreDecor(*pCadre)) ;
                  delete pCadre ;
                  pCadre = 0 ;
                  break ;
        case 3 :	StylesParagraphe.push_back(new NSStyleParagraphe(*pParagraphe)) ;
                  delete pParagraphe ;
                  pParagraphe = 0 ;
                  break ;
        case 4 :	Pages.push_back(new NSPage(*pPage)) ;
                  delete pPage ;
                  pPage = 0 ;
                  break ;
      }

			// On analyse le type de section
			if (Chaine.find("Cadre") != NPOS)
			{
				pCadre = new NSCadreDecor ;
				etatEnCours = 1 ;
        pCadre->InitTitre(&Chaine) ;
			}
			else if (Chaine.find("Polices") != NPOS)
			{
				/* pPolice = new NSFont(); */
				if 	  (Chaine.find("par d�faut") != NPOS)
					etatEnCours = 2 ;
				else if (Chaine.find(ImpDevice) != NPOS)
				{
					StylesPolice.vider() ;
					etatEnCours = 2 ;
				}
				else
					etatEnCours = 0 ;
			}
			else if (Chaine.find("Paragraphe") != NPOS)
			{
				pParagraphe = new NSStyleParagraphe ;
				etatEnCours = 3 ;
			}
      else if (Chaine.find("Mise en page") != NPOS)
			{
				pPage = new NSPage ;
				etatEnCours = 4 ;
        pPage->InitNumPage(&Chaine) ;
			}
			else
				etatEnCours = 0 ;
		}

		// Sinon traitement de la ligne
		else if (etatEnCours > 0)
		{
			recherche = Chaine.find('=') ;
			if ((recherche != NPOS) && (recherche < strlen(Chaine.c_str())-1))
			{
				// On s�pare la chaine en Nom et Contenu
				//	Ex : "Font1=Times New Roman,120"
				// -> Nom : "Font1" et Contenu = "Times New Roman,120"
				ChaineNom 	  = string(Chaine, 0, recherche) ;
				ChaineContenu = string(Chaine, recherche+1, strlen(Chaine.c_str())-(recherche+1)) ;
      }
      else
      {
      	ChaineNom 	  = Chaine ;
        ChaineContenu = "" ;
      }

			// On traite suivant la section
			switch (etatEnCours)
			{
      	case 1 :	if (ChaineNom.find("Taille") != NPOS)
        						pCadre->InitTaille(&ChaineContenu) ;
        					else if (ChaineNom.find("DebutTexte") != NPOS)
                  {
                  	pCadre->finTexte() ;
                    pCadre->debutTexte() ;
                  }
                  else if (ChaineNom.find("FinTexte") != NPOS)
                  	pCadre->finTexte() ;
                  else if (ChaineNom.find("Texte") != NPOS)
                  	pCadre->InitTexte(&ChaineContenu) ;
                  else if (ChaineNom.find("Police") != NPOS)
                  	pCadre->InitPolice(&ChaineContenu) ;
                  else if (ChaineNom.find("Retrait") != NPOS)
                  	pCadre->InitRetrait(&ChaineContenu) ;
                  else if (ChaineNom.find("Espacement") != NPOS)
                  	pCadre->InitEspacement(&ChaineContenu) ;
                  else if (ChaineNom.find("Alignement") != NPOS)
                  	pCadre->InitAlignement(&ChaineContenu) ;
                  else if (ChaineNom.find("Tabulations") != NPOS)                  	pCadre->InitTabulations(&ChaineContenu) ;
                  break ;
        case 2 :	InitModePolice(&ChaineNom, &ChaineContenu) ;
        					break ;
        case 3 :	if (ChaineNom.find("Police") != NPOS)
        						pParagraphe->InitPolice(&ChaineContenu) ;
        					else if (ChaineNom.find("Retrait") != NPOS)
                  	pParagraphe->InitRetrait(&ChaineContenu) ;
                  else if (ChaineNom.find("Espacement") != NPOS)
                  	pParagraphe->InitEspacement(&ChaineContenu) ;
                  else if (ChaineNom.find("Alignement") != NPOS)
                  	pParagraphe->InitAlignement(&ChaineContenu) ;
                  else if (ChaineNom.find("Tabulations") != NPOS)
                  	pParagraphe->InitTabulations(&ChaineContenu) ;
                  break ;
        case 4 :	if (ChaineNom.find("MargesTexte") != NPOS)
        						pPage->InitMargesTxt(&ChaineContenu) ;
                  else if (ChaineNom.find("Marges") != NPOS)
                  	pPage->InitMarges(&ChaineContenu) ;
                  else if (ChaineNom.find("Decor") != NPOS)
                  	pPage->InitDecor(&ChaineNom, &ChaineContenu) ;
                  break ;
      }
		}
    ChaineContenu = "" ;
		ChaineNom = "" ;
		Chaine = "" ;
  }

	// On en termine avec l'�l�ment pr�c�dent
	switch (etatEnCours)
	{
  	case 1 :	Cadres.push_back(new NSCadreDecor(*pCadre)) ;
            	delete pCadre ;
            	pCadre = 0 ;
            	break ;
    case 3 :	StylesParagraphe.push_back(new NSStyleParagraphe(*pParagraphe)) ;
            	delete pParagraphe ;
            	pParagraphe = 0 ;
            	break ;
    case 4 :	Pages.push_back(new NSPage(*pPage)) ;
            	delete pPage ;
            	pPage = 0 ;
            	break ;
  }
	inFile.close() ;
	return true ;
}


// -----------------------------------------------------------------------------// Function    : NSRefVue::InitModePolice(pPolice, ChaineNom, ChaineContenu)// Arguments   :	pPolice 		 : pointeur sur la NSFont � initialiser
//				  			ChaineNom 	 : Nom de la Font (forme "Font4" pour la 4�me)
//				  			ChaineContenu : Descriptif de la Font
// Description : Initialise le style du document � partir du fichier N.MOD
// Returns     : true/false
// -----------------------------------------------------------------------------
//?????????????????????? a revoir
bool
NSRefVue::InitModePolice(string* pChaineNom, string* pChaineContenu)
{
try
{
	UINT    indice, place ;
	size_t  i, j, k ;
	size_t  positionDeb, positionFin, positionNew ;
	NSFont* pPolice ;
	char    facename[LF_FACESIZE] ;
	int	    height = 0, width = 0, escapement = 0, orientation = 0, weight = FW_NORMAL ;
	BYTE    pitchAndFamily = DEFAULT_PITCH|FF_DONTCARE ;
	BYTE    italic = false, underline = false, strikeout = false, charSet = 1 ;
	BYTE    outputPrecision = OUT_DEFAULT_PRECIS ;
	BYTE    clipPrecision	= CLIP_DEFAULT_PRECIS ;
	BYTE    quality			= DEFAULT_QUALITY ;

	// Si le nom n'est pas bon, on sort
	if (string(*pChaineNom, 0, 4) != "Font")
  	return false ;

	// Les caract�res situ�s juste apr�s "Font" donnent l'indice de la police
	if ((strlen(pChaineNom->c_str()) > 4) && (isdigit((*pChaineNom)[4])))
	{
		indice = UINT((*pChaineNom)[4]) - UINT('0') ;
		if ((strlen(pChaineNom->c_str()) > 5) && (isdigit((*pChaineNom)[5])))
		{
			indice = 10 * indice ;
			indice += UINT((*pChaineNom)[5]) - UINT('0') ;
		}
	}

	// S'il n'y a pas de caract�res, la police se place en queue de tableau
	else
		//indice = StylesPolice.ArraySize();
    indice = StylesPolice.size() ;

	// Analyse du descriptif de police
	place = 1 ;
	positionDeb = 0 ;
	positionFin = 0 ;
	positionNew = 0 ;
	while (positionNew != NPOS)
	{
		// Plante quand positionDeb = 10
		//positionNew = ChaineContenu.find((const string) ",", positionDeb);
		for (positionNew = positionDeb ;
				(positionNew < strlen(pChaineContenu->c_str())) &&
				((*pChaineContenu)[positionNew] != ',') ; positionNew++)
    	;
		if (positionNew == strlen(pChaineContenu->c_str()))
			positionNew = NPOS ;

		if (positionNew == NPOS)
			positionFin = strlen(pChaineContenu->c_str()) ;
		else
			positionFin = positionNew ;

		// Traitement du nom de police
		if (place == 1)
		{
			i = min(UINT(LF_FACESIZE-1), positionFin - positionDeb) ;
			for (j = positionDeb ; j < i ; j++)
      	facename[j-positionDeb] = (*pChaineContenu)[j] ;
			facename[j-positionDeb] = '\0' ;
		}

		// Traitement des �l�ments num�riques
		else if ((place > 1) && (positionFin - positionDeb + 1 < 5))
		{
			i = 0 ;
			for (j = positionDeb ; j < positionFin ; j++)
				i = (10 * i) + donneDigit((*pChaineContenu)[j]) ;

			switch (place)
			{
        case 2 	:	height 	    = i ; break ;
        case 3 	:	width  	    = i ; break ;
        case 4 	:	escapement  = i ; break ;
        case 5 	:	orientation = i ; break ;
        case 6 	:	weight 	    = i ; break ;
        default	:	if ((i >= 0) && (i < 256))
            			{
                		switch (place)
                		{
                      case  7 : pitchAndFamily  = (BYTE)i ; break ;
                      case  8 : italic 	        = (BYTE)i ; break ;
                      case  9 : underline 	    = (BYTE)i ; break ;
                      case 10 : strikeout 	    = (BYTE)i ; break ;
                      case 11 : charSet 		    = (BYTE)i ; break ;
                      case 12 : outputPrecision = (BYTE)i ; break ;
                      case 13 : clipPrecision   = (BYTE)i ; break ;
                      case 14 : quality		    	= (BYTE)i ; break ;
                		}
            			}
			}
		}
		if (positionNew != NPOS)
			positionDeb = positionFin + 1 ;
		place++ ;
	}

	// Appel du constructeur de NSFont
	pPolice = new NSFont(facename, height, width, escapement, orientation,
							  weight, pitchAndFamily, italic, underline, strikeout,
							  charSet, outputPrecision, clipPrecision, quality) ;

	// Mise de la police � sa place dans le tableau
  FontIter iter;
  for(iter = StylesPolice.begin(), k=0 ; (iter != StylesPolice.end()) && (k < indice-1) ; iter++, k++)
		;

	StylesPolice.insert(iter, new NSFont(*pPolice)) ;
	delete pPolice ;

	return true ;
}
catch (...)
{
  erreur("Exception NSRefVue::InitModePolice.", standardError, 0) ;
  return false ;
}
}


// -----------------------------------------------------------------------------
// Description : Renvoie un pointeur sur la page de num�ro numPage
// Arguments   : numPage : num�ro de la page � chercher
// Retour      : Pointeur ou 0 si la page n'existe pas
// -----------------------------------------------------------------------------
NSPage *
NSRefVue::donnePage(unsigned int numPage)
{
	if (Pages.empty())
		return 0 ;

  NSStylPageArrayIter i ;
	for (i = Pages.begin() ; (i != Pages.end()) && ((*i)->numeroPage != numPage) ; i++)
  	;
	if (i != Pages.end())
		return *i ;
	else
		return 0 ;
}


// -----------------------------------------------------------------------------
// Description : Renvoie un pointeur sur le d�cor de titre titreDecor
// Arguments   : titreDecor : titre du d�cor � chercher
// Retour      : Pointeur ou 0 si la page n'existe pas
// -----------------------------------------------------------------------------
NSCadreDecor*
NSRefVue::donneDecor(string* titreDecor)
{
	if (Cadres.empty())
		return 0 ;

  CadreDecoIter i;
  for (i = Cadres.begin(); (i != Cadres.end()) && (strcmp((*i)->Titre.c_str(), titreDecor->c_str()) != 0); i++)
  	;

	if (i != Cadres.end())
		return *i ;
	else
		return 0 ;
}


//---------------------------------------------------------------------------
//  Function: 		NSRefVue::metDecor(TRect* rectPage, int ecranImpri)
//
//  Arguments : 	rectPage   : Cadre de la page
//						indicePage : indice de la page
//						ecranImpri : 1 = ecran ; 2 = imprimante
//
//  Description : Affiche les d�cors de la page
//
//  Retour :		Rien
//---------------------------------------------------------------------------
void
NSRefVue::metDecor(NS_CLASSLIB::TRect* rectPage, TDC* pDC, unsigned numPage, int ecranImpri)
{
    int			       indiceCadre;
    NSCadreDecor*      pCadreDecor;
    NS_CLASSLIB::TRect Cadrage;
    long			   lGche, lDrte, lHaut, lBas;
    long			   TraiteLigne, LargeurPossible, LargeurGauche, LargeurChaine;
	NSLigne*		   pLigne;
    unsigned		   iNumPhrase = 0;
    unsigned		   NumeroPara, NumeroPolice;
	size_t		       Curseur, NouBlanc, PreBlanc, NbrBlancs;
    NS_CLASSLIB::TSize TailleChaine;
    //
    // Recherche de la page de num�ro numPage
    //
	NSPage* pStylePage = donnePage(numPage);
    if ((pStylePage == 0) || (pStylePage->Decors.empty()))
		return;
    //
    // Passage en revue de tous ses d�cors
    //
    NSDecoArrayIter iter;

	for (iter = pStylePage->Decors.begin(); iter != pStylePage->Decors.end(); iter++)
    {
        //
        // Recherche du d�cor correspondant
        //
   	    pCadreDecor = donneDecor(&((*iter)->titreCadre));
        if ((pCadreDecor != 0) && !(pCadreDecor->DecorArray.empty()))
        {
      	    //
            // D�termination du cadre dans lequel s'inscrit le d�cor
            //
            if ((*iter)->coinHautGcheX > 0)
            {
         	    lGche = rectPage->Left() + (*iter)->coinHautGcheX;
                lDrte = lGche + pCadreDecor->tailleHorizontale;
            }
            else if ((*iter)->AlignementX == TA_LEFT)
            {
         	    lGche = rectPage->Left();
                lDrte = lGche + pCadreDecor->tailleHorizontale;
            }
            else if ((*iter)->AlignementX == TA_RIGHT)
            {
         	    lDrte = rectPage->Right();
                lGche = lDrte - pCadreDecor->tailleHorizontale;
            }
            else if ((*iter)->AlignementX == TA_CENTER)
            {
         	    lGche = rectPage->Left() + (rectPage->Width() - pCadreDecor->tailleHorizontale) / 2;
                lDrte = lGche + pCadreDecor->tailleHorizontale;
            }
            else if ((*iter)->AlignementX == TA_JUSTIFIED)
            {
         	    lGche = rectPage->Left();
                lDrte = rectPage->Right();
            }

            if ((*iter)->coinHautGcheY > 0)
            {
         	    lHaut = rectPage->Top() - (*iter)->coinHautGcheY;
                lBas  = lHaut - pCadreDecor->tailleVerticale;
            }
            else if ((*iter)->AlignementY == TA_LEFT)
            {
         	    lHaut = rectPage->Top();
                lBas  = lHaut - pCadreDecor->tailleVerticale;
            }
            else if ((*iter)->AlignementY == TA_RIGHT)
            {
         	    lBas  = rectPage->Bottom();
                lHaut = lBas + pCadreDecor->tailleVerticale;
            }
            else if ((*iter)->AlignementY == TA_CENTER)
            {
         	    lHaut = rectPage->Top() + (rectPage->Height() - pCadreDecor->tailleVerticale) / 2;
                lBas  = lHaut - pCadreDecor->tailleVerticale;
            }
            else if ((*iter)->AlignementY == TA_JUSTIFIED)
            {
         	    lHaut = rectPage->Top();
                lBas  = rectPage->Bottom();
            }
            Cadrage.Set(lGche, lHaut, lDrte, lBas);
            //
            // Trac� ligne par ligne
            //
            string 				sTexte;
            NSStyleParagraphe StylePara;

            NS_CLASSLIB::TPoint PointRef;
            PointRef.x = Cadrage.Left();
            PointRef.y = Cadrage.Top();

            NSStylDecoArrayIter decoIter;

            for (decoIter = pCadreDecor->DecorArray.begin(); decoIter != pCadreDecor->DecorArray.end(); decoIter++)
            {
         	    sTexte 	 = (*decoIter)->Texte;
                StylePara = (*decoIter)->styleParagraphe;
				// On pr�voit l'espace au dessus du paragraphe
				PointRef.Offset(0, -StylePara.EspaceDessus);
				// Calcul de la largeur utilisable sans le retrait gauche
                LargeurGauche = Cadrage.Width() - StylePara.RetraitDroit;
                TraiteLigne = 1;
                Curseur = 0; PreBlanc = 0;
				while (TraiteLigne > 0)
				{
					// Cr�ation d'une ligne vierge
					pLigne = new NSLigne();
					// Initialisation de tous les param�tres d�j� connus
					pLigne->iNumPhrase = iNumPhrase;
					pLigne->numPage = numPage;
					if (TraiteLigne == 1)
						pLigne->Boite.left = Cadrage.Left()+StylePara.RetraitPremLigne;
					else
						pLigne->Boite.left = Cadrage.Left()+StylePara.RetraitGauche;
					pLigne->Boite.right   = LargeurGauche;
					pLigne->Boite.top	  	 = PointRef.y;
					pLigne->Boite.bottom  = PointRef.y;
					// pLigne->CouleurTexte  = *(StylePara.pCouleurTexte);
					pLigne->numParagraphe 	= 0;
                    pLigne->StyleParagraphe = StylePara;

					pLigne->numLigne		 = TraiteLigne;
					// Traitement des chaines de taille non nulle
					if (strlen(sTexte.c_str()) > 0)
                    {
						// D�termination de la largeur utilisable
						LargeurPossible = UINT(pLigne->Boite.Width());
						// Recherche du segment de cha�ne qui "tient"
						NouBlanc = Curseur;
						do
						{
							PreBlanc = NouBlanc;
							NouBlanc = sTexte.find(' ', PreBlanc+1);
							if (NouBlanc == NPOS)
								break;
							TailleChaine = pDC->GetTextExtent(string(sTexte, Curseur, NouBlanc-Curseur).c_str(),
														 int(NouBlanc-Curseur));
						}
						while (TailleChaine.cx < LargeurPossible);
						// Si on est en fin de cha�ne,
                        // on regarde si le dernier mot "tient"
						if (NouBlanc == NPOS)
						{
							TailleChaine = pDC->GetTextExtent(string(sTexte, Curseur, strlen(sTexte.c_str())-Curseur).c_str(),
														 int(strlen(sTexte.c_str())-Curseur));
							if (TailleChaine.cx < LargeurPossible)
								PreBlanc = strlen(sTexte.c_str());
						}
						// On met le segment de chaine "qui tient"
                  // dans la chaine Texte de la ligne en cours
						pLigne->Texte = string(sTexte, Curseur, PreBlanc-Curseur);
						// On calcule la vraie taille de cette chaine
                        strip(pLigne->Texte);
						TailleChaine = pDC->GetTextExtent(pLigne->Texte.c_str(),
													 int(strlen(pLigne->Texte.c_str())));
						// On initialise Boite : rectangle exinscrit � la ligne
						if (TailleChaine.cy < StylePara.HauteurLigne)
							TailleChaine.cy = StylePara.HauteurLigne;
						pLigne->Boite.bottom -= TailleChaine.cy;
						PointRef.Offset(0, -TailleChaine.cy);
						if (PreBlanc < strlen(sTexte.c_str()))
						{
							Curseur = PreBlanc + 1;
							TraiteLigne++;
							pLigne->DerniereLigne = false;
						}
						else
						{
							TraiteLigne = 0;
							pLigne->DerniereLigne = true;
						}
					}
					// Traitement des chaines vides
					else
					{
						pLigne->Texte = "";
						// On initialise Boite : rectangle exinscrit � la ligne
						TailleChaine = pDC->GetTextExtent(" ", 1);
						if (TailleChaine.cy < StylePara.HauteurLigne)
							TailleChaine.cy = StylePara.HauteurLigne;
						pLigne->Boite.bottom -= TailleChaine.cy;
						PointRef.Offset(0, -TailleChaine.cy);
						// On pr�cise que le traitement est termin�
						TraiteLigne = 0;
						pLigne->DerniereLigne = true;
					}
					// On ajoute la ligne � Lignes
					Lignes.push_back(new NSLigne(*pLigne));
					delete pLigne;
               pLigne = 0;
            }
            // On pr�voit l'espace au dessous du paragraphe
            PointRef.Offset(0, -StylePara.EspaceDessous);
         }
      }
   }
}

/*
// Let container know about the server view size in pixels
//
bool
NSOleView::EvOcViewPartSize(TOcPartSize far& ps)
{
	TClientDC dc(*this);

	TRect rect(0, 0, 0, 0);
	// a 2" x 2" extent for server
	//
	rect.right  = dc.GetDeviceCaps(LOGPIXELSX) * 2;
	rect.bottom = dc.GetDeviceCaps(LOGPIXELSY) * 2;

	ps.PartRect = rect;
	return true;
}

bool
NSOleView::EvOcViewShowTools(TOcToolBarInfo far& tbi)
{
	// Construct & create a control bar for show, destroy our bar for hide
	//
	if (tbi.Show)
	{
		if (!ToolBar)
		{
			ToolBar = new TControlBar(this);
			//ToolBar->Insert(*new TButtonGadget(CM_PENSIZE, CM_PENSIZE, TButtonGadget::Command));
			//ToolBar->Insert(*new TButtonGadget(CM_PENCOLOR, CM_PENCOLOR, TButtonGadget::Command));
			//ToolBar->Insert(*new TSeparatorGadget);
			//ToolBar->Insert(*new TButtonGadget(CM_ABOUT, CM_ABOUT, TButtonGadget::Command));
			ToolBar->SetHintMode(TGadgetWindow::EnterHints);
		}
		ToolBar->Create();
		tbi.HTopTB = (HWND)*ToolBar;
	}
	else
	{
		if (ToolBar)
		{
			ToolBar->Destroy();
			delete ToolBar;
			ToolBar = 0;
		}
	}
	return true;
}
*/

void
NSRefVue::SelectAll()
{
    // on s�lectionne toutes les lignes du CR
    iLignePrec = iLigneEnCours;
    iLigneEnCours = 1;
    iLigneSelect = Lignes.size() - 1;
    Invalidate();
}

void
NSRefVue::CopyToClipboard()
{
    LPSTR   lpCopy;
    HGLOBAL hgCopy;
    string  sTextSelect = "";
    int     numLigne = 1;
    int     minLigne, maxLigne;
    char*   cData;
    int     len;

    if ((!::OpenClipboard(NULL)) || (iLigneEnCours == 0))
        return;

    // calcul des lignes min et max du bloc s�lectionn�
    if ((iLigneEnCours + iLigneSelect) < iLigneEnCours)
    {
        minLigne = iLigneEnCours + iLigneSelect;
        maxLigne = iLigneEnCours;
    }
    else
    {
        minLigne = iLigneEnCours;
        maxLigne = iLigneEnCours + iLigneSelect;
    }

    // On copie le texte s�lectionn� dans une string
    for (NSLignesArrayIter iter = Lignes.begin(); iter != Lignes.end(); iter++)
    {
        if ((numLigne >= minLigne) && (numLigne <= maxLigne))
            sTextSelect += (*iter)->Texte + string("\r\n");
        numLigne++;
    }

    len = strlen(sTextSelect.c_str());
    cData = new char[len + 1];
    strcpy(cData, sTextSelect.c_str());

    // on vide le clipboard
    ::EmptyClipboard();

    // Allocate a global memory object for the text.
    hgCopy = GlobalAlloc(GMEM_DDESHARE, (len + 1) * sizeof(char));
    if (hgCopy == NULL)
    {
        ::CloseClipboard();
        delete[] cData;
        return;
    }

    // Lock the handle and copy the text to the buffer.
    lpCopy = (LPSTR) GlobalLock(hgCopy);
    memcpy(lpCopy, cData, len * sizeof(char));
    lpCopy[len] = '\0';
    GlobalUnlock(hgCopy);

    // on copie dans le clipboard
    ::SetClipboardData(CF_TEXT, hgCopy);
    ::CloseClipboard();
    delete[] cData;
}
voidNSRefVue::EvKeyDown(uint key, uint repeatCount, uint flags)
{
	WORD wScrollNotify = 0xFFFF;
	bool bVScroll = true;

	switch (key)	{
		case 'a':
			break ;
		case 'A':
			// Control-A : Tout s�lectionner
			if (GetKeyState(VK_CONTROL) < 0)
				SelectAll() ;
			break ;

		case 'c':			break ;
		case 'C':
			// Control-C : copier vers le presse-papier
			if (GetKeyState(VK_CONTROL) < 0)
				CopyToClipboard() ;
			break ;

		case VK_UP:            if (GetKeyState(VK_SHIFT) < 0)
            {
                // s�lectionner vers le haut
                if ((iLigneEnCours) && ((iLigneEnCours + iLigneSelect) > 1))
                {
                    iLigneSelect--;
                    Invalidate();
                }
            }
            else
      	        wScrollNotify = SB_LINEUP;
            break;

        case VK_PRIOR:      	    wScrollNotify = SB_PAGEUP;
            break;

        case VK_NEXT:      	    wScrollNotify = SB_PAGEDOWN;
            break;

        case VK_DOWN:            if (GetKeyState(VK_SHIFT) < 0)
            {
                // s�lectionner vers le bas
                if ((iLigneEnCours) && ((iLigneEnCours + iLigneSelect) < Lignes.size()))
                {
                    iLigneSelect++;
                    Invalidate();
                }
            }
            else
      	        wScrollNotify = SB_LINEDOWN;
            break;

        case VK_HOME:      	    wScrollNotify = SB_TOP;
            break;

        case VK_END:
      	    wScrollNotify = SB_BOTTOM;
            break;

        case VK_RIGHT:
            wScrollNotify = SB_LINERIGHT;
            bVScroll = false;
            break;

        case VK_LEFT:
            wScrollNotify = SB_LINELEFT;
            bVScroll = false;
            break;
    }

	if (wScrollNotify != -1)
	{
		if (bVScroll)
			SendMessage(WM_VSCROLL, MAKELONG(wScrollNotify, 0), 0L);
		else
			SendMessage(WM_HSCROLL, MAKELONG(wScrollNotify, 0), 0L);
	}

	TWindowView::EvKeyDown(key, repeatCount, flags);

}

void
NSRefVue::EvSysCommand(uint cmdType, NS_CLASSLIB::TPoint& point)
{
    // MessageBox("EvSysCommand");
}

void
NSRefVue::EvSysKeyDown(uint key, uint repeatCount, uint flags)
{
    // MessageBox("EvSysKeyDown");
}

//---------------------------------------------------------------------------//  Function: NSRefVue::EvVScroll(UINT scrollCode, UINT thumbPos, HWND hWndCtl)
//
//  Arguments:   dc 				: device contexte de la fen�tre
//					  RectAPeindre : Rectangle � repeindre
//
//  Description: Peint/repeint tout/une partie de la fen�tre
//
//  Returns:	  Rien
//---------------------------------------------------------------------------
void
NSRefVue::EvVScroll(UINT scrollCode, UINT thumbPos, HWND hWndCtl)
{
	if (Lignes.empty())
		return ;

	const NSLigne* pLigne ;
	int		         iTailleScroll ;
	NS_CLASSLIB::TPoint* pPointRef ;
	//
	// On sort tout de suite si on est sur les lignes extr�mes
	//
	if (((scrollCode == SB_LINEDOWN) && (PremLigne == Lignes.size())) ||
        ((scrollCode == SB_PAGEDOWN) && (PremLigne == Lignes.size())) ||
        ((scrollCode == SB_LINEUP) && (PremLigne == 1)) ||
        ((scrollCode == SB_PAGEUP) && (PremLigne == 1)))
		return ;
	//
	// On r�cup�re un "contexte d'information" concernant l'�cran
	//
	TIC* pDC = new TIC("DISPLAY", NULL, NULL) ;
	pDC->SetMapMode(MM_LOMETRIC) ;
	//
	// Scroll vers le haut (fl�che basse)
	//
	if (scrollCode == SB_LINEDOWN)
	{
		//
		// Calcul de la quantit� � scroller (hauteur de la premi�re ligne)
		//
		pLigne = Lignes[PremLigne-1] ;
		iTailleScroll = pLigne->Boite.Height() ;
		//
		// Conversion en pixels
		//
		pPointRef = new NS_CLASSLIB::TPoint(0, iTailleScroll) ;
		pDC->LPtoDP(pPointRef) ;
		//
		// Demande de scroll
		//
		ScrollWindow(0, -pPointRef->y) ;
		delete pPointRef ;
		pPointRef = 0 ;
		//
		// Ajustement des variables PremLigne et HautGcheFenetre
		//
		PremLigne++ ;
		HautGcheFenetre.y += iTailleScroll ;
		//UpdateWindow();
	}
	//
	// Scroll vers le haut (page basse)	//
	else if (scrollCode == SB_PAGEDOWN)
	{
        NS_CLASSLIB::TRect rectClient = GetClientRect();
        int cyScroll = ::GetSystemMetrics(SM_CYHSCROLL);
        int hauteurLignes = 0;
        int numLigne = PremLigne; // num�ro de la premi�re ligne visible
        int hauteurFen = rectClient.bottom - rectClient.top - cyScroll; // hauteur fenetre en pixels
        int hBoite = 0, hLigne = 0;
        int tailleScroll = 0;

        while ((numLigne < Lignes.size()) && (hauteurLignes < hauteurFen))
        {
            pLigne = Lignes[numLigne - 1];
            hBoite = pLigne->Boite.Height();
            NS_CLASSLIB::TPoint py(0, hBoite);
            pDC->LPtoDP(&py);
            hLigne = py.y;

            tailleScroll += hBoite;
            hauteurLignes += hLigne;
            numLigne++;
        }

        PremLigne = numLigne;
        ScrollWindow(0, -hauteurLignes);
        HautGcheFenetre.y += tailleScroll;
    }
	//
	// Scroll vers le bas (fl�che haute)
	//
	else if (scrollCode == SB_LINEUP)
	{
		//
		// Calcul de la quantit� � scroller (hauteur de l'avant-premi�re ligne)
		//
		pLigne = Lignes[PremLigne-2];
		iTailleScroll = pLigne->Boite.Height();
		//
		// Conversion en pixels
		//
		pPointRef = new NS_CLASSLIB::TPoint(0, iTailleScroll);
		pDC->LPtoDP(pPointRef);
		//
		// Demande de scroll
		//
		ScrollWindow(0, pPointRef->y);
		delete pPointRef;
        pPointRef = 0;
		//
		// Ajustement des variables PremLigne et HautGcheFenetre
		//
		PremLigne--;
		HautGcheFenetre.y -= iTailleScroll;
		//UpdateWindow();
	}
	//
	// Scroll vers le bas (page haute)
	//
	else if (scrollCode == SB_PAGEUP)
    {
        NS_CLASSLIB::TRect rectClient = GetClientRect();
        int cyScroll = ::GetSystemMetrics(SM_CYHSCROLL);
        int hauteurLignes = 0;
        int numLigne = PremLigne; // num�ro de la premi�re ligne visible
        int hauteurFen = rectClient.bottom - rectClient.top - cyScroll; // hauteur fenetre en pixels
        int hBoite = 0, hLigne = 0;
        int tailleScroll = 0;

        while ((numLigne > 1) && (hauteurLignes < hauteurFen))
        {
            pLigne = Lignes[numLigne - 2];  // Ligne pr�c�dente
            hBoite = pLigne->Boite.Height();
            NS_CLASSLIB::TPoint py(0, hBoite);
            pDC->LPtoDP(&py);
            hLigne = py.y;

            tailleScroll += hBoite;
            hauteurLignes += hLigne;
            numLigne--;
        }

        PremLigne = numLigne;
        ScrollWindow(0, hauteurLignes);
        HautGcheFenetre.y -= tailleScroll;
	}

	delete pDC ;
	pDC = 0 ;
	SetScrollPos(SB_VERT, PremLigne) ;
}

//---------------------------------------------------------------------------
//  Function: NSRefVue::EvHScroll(UINT scrollCode, UINT thumbPos, HWND hWndCtl)
//
//  Arguments:   dc 				: device contexte de la fen�tre
//					  RectAPeindre : Rectangle � repeindre
//
//  Description: Peint/repeint tout/une partie de la fen�tre
//
//  Returns:	  Rien
//---------------------------------------------------------------------------
void
NSRefVue::EvHScroll(UINT scrollCode, UINT thumbPos, HWND hWndCtl)
{
	NS_CLASSLIB::TPoint* pPointRef;
	//
	// On sort tout de suite si on est sur les lignes extr�mes
	//
	if (((scrollCode == SB_LINERIGHT) && (HautGcheFenetre.x == RectangleGlobal.Width())) ||
        ((scrollCode == SB_PAGERIGHT) && (HautGcheFenetre.x == RectangleGlobal.Width())) ||
		((scrollCode == SB_LINELEFT) && (HautGcheFenetre.x == 0)) ||
        ((scrollCode == SB_PAGELEFT) && (HautGcheFenetre.x == 0)))
		return;
	//
	// On r�cup�re un "contexte d'information" concernant l'�cran
	//
	TIC* pDC = new TIC("DISPLAY", NULL, NULL);
	pDC->SetMapMode(MM_LOMETRIC);
	//
	// Scroll vers la gauche (fl�che droite)
	//
	if (scrollCode == SB_LINERIGHT)
	{
		//
		// Conversion en pixels
		//
		pPointRef = new NS_CLASSLIB::TPoint(LargeurPolice, 0);
		pDC->LPtoDP(pPointRef);
		//
		// Demande de scroll
		//
		ScrollWindow(-pPointRef->x, 0);
		delete pPointRef;
        pPointRef = 0;
		//
		// Ajustement de HautGcheFenetre
		//
		HautGcheFenetre.x += LargeurPolice;
	}
    //
	// Scroll vers la gauche (page droite)
	//
	if (scrollCode == SB_PAGERIGHT)
	{
		//
		// Conversion en pixels
		//
        int k = 1;
        pPointRef = new NS_CLASSLIB::TPoint(LargeurPolice, 0);
        pDC->LPtoDP(pPointRef);

        while ((k <= 10) && ((HautGcheFenetre.x + LargeurPolice) <= RectangleGlobal.Width()))
        {
		    //
		    // Demande de scroll
		    //
		    ScrollWindow(-pPointRef->x, 0);
            //
		    // Ajustement de HautGcheFenetre
		    //
            HautGcheFenetre.x += LargeurPolice;
            k++;
        }

		delete pPointRef;
        pPointRef = 0;
	}
	//
	// Scroll vers la droite (fl�che gauche)
	//
	else if (scrollCode == SB_LINELEFT)
	{
		//
		// Conversion en pixels
		//
		pPointRef = new NS_CLASSLIB::TPoint(LargeurPolice, 0);
		pDC->LPtoDP(pPointRef);
		//
		// Demande de scroll
		//
		ScrollWindow(pPointRef->x, 0);
		delete pPointRef;
        pPointRef = 0;
		//
		// Ajustement de HautGcheFenetre
		//
		HautGcheFenetre.x -= LargeurPolice;
	}
    //
	// Scroll vers la droite (page gauche)
	//
	if (scrollCode == SB_PAGELEFT)
	{
		//
		// Conversion en pixels
		//
        int k = 1;
        pPointRef = new NS_CLASSLIB::TPoint(LargeurPolice, 0);
        pDC->LPtoDP(pPointRef);

        while ((k <= 10) && ((HautGcheFenetre.x - LargeurPolice) >= 0))
        {
		    //
		    // Demande de scroll
		    //
		    ScrollWindow(pPointRef->x, 0);
            //
		    // Ajustement de HautGcheFenetre
		    //
            HautGcheFenetre.x -= LargeurPolice;
            k++;
        }

		delete pPointRef;
        pPointRef = 0;
	}

	delete pDC;
    pDC = 0;
    if (LargeurPolice > 0)
		SetScrollPos(SB_HORZ, HautGcheFenetre.x / LargeurPolice);
}

LRESULT
NSRefVue::EvMouseWheel(WPARAM wParam, LPARAM lParam)
{
    WORD    fwKeys  = LOWORD(wParam) ;           // key flags
    short   zDelta  = (short) HIWORD(wParam) ;   // wheel rotation
    short   xPos    = (short) LOWORD(lParam) ;   // horizontal position of pointer
    short   yPos    = (short) HIWORD(lParam) ;   // vertical position of pointer

    UINT    scrollCode;

    // A positive value indicates that the wheel was rotated forward,
    // away from the user
    //
    if (zDelta > 0)
        scrollCode = SB_LINEUP ;

    // a negative value indicates that the wheel was rotated backward,
    // toward the user.
    //
    else if (zDelta < 0)
        scrollCode = SB_LINEDOWN ;

    for (int i = 0; i < 4; i++)
        EvVScroll(scrollCode, 0, 0) ;

    return 0 ;
}

boolNSRefVue::EvLButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;

	NS_CLASSLIB::TPoint ptClick = point ;
	//
	// On r�cup�re un "contexte d'information" concernant l'�cran
	//
	TIC* pDC = new TIC("DISPLAY", NULL, NULL) ;
	pDC->SetMapMode(MM_LOMETRIC) ;
	//
	// On transforme les unit�s physiques d'�cran en unit�s logiques
	//
	pDC->DPtoLP(&ptClick) ;
	delete pDC ;
	//
	// On positionne le point dans la page
	//
	ptClick.x += HautGcheFenetre.x ;
	ptClick.y += HautGcheFenetre.y ;
	//
	// On cherche si ce point se situe sur une ligne
	// Attention, les ordonn�es sont < 0
	//
  NSLignesArrayIter iter ;
  int ligneEnCours = 1 ;
  bool tourner = true ;
  if (false == Lignes.empty())
  	for (iter = Lignes.begin(); (iter != Lignes.end()) && (tourner); )
  	{
  		if ((ptClick.x >= (*iter)->Boite.left) && (ptClick.x <= (*iter)->Boite.right) &&
			    (ptClick.y <= (*iter)->Boite.top)  && (ptClick.y >= (*iter)->Boite.bottom) )
    		tourner = false ;
    	else
    	{
    		iter++ ;
      	ligneEnCours++ ;
    	}
		}
	//
	// Si ce point se situe sur une ligne, on cherche la phrase correspondante
	//
	if (!tourner)
	{
  	// cas du Shift-click : on s�lectionne un bloc
    if (GetKeyState(VK_SHIFT) < 0)
    {
    	if (iLigneEnCours)
      {
      	iLigneSelect = ligneEnCours - iLigneEnCours ;
        Invalidate() ;
      }
      return true ;
    }
    // on d�s�lectionne le bloc ou la ligne, et on change �ventuellement de ligne
    iLignePrec = iLigneEnCours ;

    if (iLigneSelect != 0) // (s'il y a un bloc)
    {
    	// on remplace le bloc par la nouvelle ligne
      iLigneEnCours = ligneEnCours ;
    }
    else
    {
    	if (iLigneEnCours != ligneEnCours)
      	iLigneEnCours = ligneEnCours ;
      else // pour pouvoir d�s�lectionner une ligne
      	iLigneEnCours = 0 ;
    }

    // on efface le bloc, et on repeind
    iLigneSelect = 0 ;
    Invalidate() ;
    return true ;
	}

	return false ;
}

// Fonction de r�ponse � la commande Composer////////////////////////////////////////////////////////////////void
NSRefVue::CmComposer()
{
	pDoc->Composer();
}

// Fonction de r�ponse � la commande Publier////////////////////////////////////////////////////////////////
void
NSRefVue::CmPublier()
{
	pDoc->Publier();
}

// Fonction de r�ponse � la commande Visualiser////////////////////////////////////////////////////////////////
void
NSRefVue::CmVisualiser()
{
	pDoc->Visualiser();
}

// Fonction CmImprime (non implementee)////////////////////////////////////////////////////////////////
void
NSRefVue::CmImprime()
{
	NSPrinter* pPrinter = pDoc->pContexte->getSuperviseur()->getApplication()->frame->Printer ;
	if (pPrinter)
	{
		NSCRPrintout printout("Echocardiographie", this) ;
		//printout.SetBanding(true);
		//pPrinter->Print(this, printout, false);
		pPrinter->Print(pDoc->pContexte->GetMainWindow(), printout, false) ;
	}
}

//---------------------------------------------------------------------------//  Fonction : 	EcranToLignes(TPoint* pPoint)
//
//  Description : Convertion d'un point de l'�cran en point de l'espace des
//						Lignes.
//
//  Returns:	  	Num�ro de page dans l'espace des Lignes
//---------------------------------------------------------------------------
UINT
NSRefVue::EcranToLignes(NS_CLASSLIB::TPoint* pPoint)
{
	//
	// On transforme les unit�s physiques d'�cran en unit�s logiques
	//
	pTIC->DPtoLP(pPoint);
	//
	// On positionne le point dans la page
	//
	pPoint->x += HautGcheFenetre.x;
	pPoint->y += HautGcheFenetre.y;
	//
	// On calcule la page en cours
	//
    UINT i;
    if (RectangleGlobal.Height() != 0)
		i = pPoint->x / RectangleGlobal.Height();
    else
    	i = 0;
	return i;
}

//---------------------------------------------------------------------------//  Fonction : 	LignesToEcran(TPoint* pPoint)
//
//  Description : Convertion d'un point de l'espace des Lignes en point �cran
//
//  Returns:	  	True si le point est � l'�cran, False sinon
//---------------------------------------------------------------------------
bool
NSRefVue::LignesToEcran(NS_CLASSLIB::TPoint* pPoint)
{
	//
	// On recale le point en coordonn�es de l'�cran
	//
	pPoint->x -= HautGcheFenetre.x;
	pPoint->y -= HautGcheFenetre.y;
	//
	// On transforme les unit�s logiques en unit�s physiques d'�cran
	//
	return pTIC->LPtoDP(pPoint);
}

voidNSRefVue::initMUEViewMenu(string sMenuName){#ifdef N_TIERS	if (pMUEViewMenu)
  	delete pMUEViewMenu ;

	nsMenuIniter menuIter(pDoc->pContexte) ;
	pMUEViewMenu = new OWL::TMenuDescr ;
  menuIter.initMenuDescr(pMUEViewMenu, sMenuName) ;
#endif

	return ;}voidNSRefVue::activateMUEViewMenu(){#ifdef N_TIERS	if (!pMUEViewMenu)
		return ;

	TMyApp* pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;
  pMyApp->GetMainWindow()->SetMenuDescr(*pMUEViewMenu) ;
#endif
	return ;}
//---------------------------------------------------------------------------
//  Fonction : 	NSRefVue::InitialiseLignes()
//
//  Description : Devrait etre virtuelle pure, mais cel� pose des probl�mes
//						aux Templates ; alors elle est d�clar�e mais ne fait rien.
//
//  Returns:	  	Rien
//---------------------------------------------------------------------------
bool
NSRefVue::InitialiseLignes()
{
	return true;
}

///////////////////////////////////////////////////////////////////////////////
//
// M�thodes de NSCRPrintout
//
NSCRPrintout::NSCRPrintout(const char* title, NSRefVue* pCRVue)
  : TPrintout(title)
{
  pCRView = pCRVue;
}

void
NSCRPrintout::BeginDocument(int startPage, int endPage, unsigned flags)
{
	TPrintout::BeginDocument(startPage, endPage, flags);
}

void
NSCRPrintout::BeginPrinting()
{
	TPrintout::BeginPrinting();
}

void
NSCRPrintout::EndDocument()
{
	TPrintout::EndDocument();
}

void
NSCRPrintout::EndPrinting()
{
	TPrintout::EndPrinting();
}

void
NSCRPrintout::SetPrintParams(TPrintDC* pDC, NS_CLASSLIB::TSize pageSize)
{
    NSLigne*			pLigne;
	string 			    Chaine, ChaineLigne;
	NSStyleParagraphe   StylePara;
	TFont*				pPolice;
	UINT				NumeroPara, NumeroPolice, NumeroPage;
	size_t				Curseur, NouBlanc, PreBlanc, NbrBlancs;
	NS_CLASSLIB::TPoint PointRef, PointTransfert, PageLogique;
	ifstream 			inFile;
	UINT				TraiteLigne, LargeurPossible, LargeurGauche, LargeurChaine;
	NS_CLASSLIB::TSize	TailleChaine;
	char*				buffer;
	NSFont		 		PoliceVoulue;
    NSPage*				pStylePage, stylePage;
    string				sFichierCR;

	TPrintout::SetPrintParams(pDC, pageSize);
	//
	// Remise � z�ro des LignesPrnt
	//
	pCRView->LignesPrnt.vider();
	//
	// Tentative d'ouverture du fichier qui contient le compte rendu
	//
    NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pCRView->GetDoc());

    sFichierCR = CRDoc->sFichDecod;

	inFile.open(sFichierCR.c_str());
	if (!inFile)
		return;
	int iAncDC = pDC->SaveDC();
	//
	// Fixe la m�trique ; par d�faut c'est le pixel, mais le mode MM_LOMETRIC
	// est beaucoup plus commode
	//
	pDC->SetMapMode(MM_LOMETRIC);
	//
	// On convertit la taille de la page des unit�s physiques (pixel) aux unit�s
	// logiques (0,1 mm)
	//
	PageLogique.x = pageSize.cx;
	PageLogique.y = pageSize.cy;
	pDC->DPtoLP(&PageLogique);
	//
	// On initialise le style du paragraphe et la police qui correspond
	//
	NumeroPara 	= 1;
	StylePara 	= *(pCRView->StylesParagraphe[NumeroPara-1]);
	NumeroPolice = StylePara.NumPolice;
	//
	// La taille de la police est stock�e en points, on la ram�ne en multiple
	// de 0,1 mm
	//
	PoliceVoulue = *(pCRView->StylesPolice[NumeroPolice-1]);
	PoliceVoulue.logFont.lfHeight = PoliceVoulue.logFont.lfHeight * 254 / 72;
	PoliceVoulue.logFont.lfWidth  = PoliceVoulue.logFont.lfWidth  * 254 / 72;
	//
	// On s�lectionne la police dans le DC
	//
	pPolice = new TFont(&(PoliceVoulue.logFont));
	pDC->SelectObject(*pPolice);
	//
	// On initialise le point de r�f�rence en haut et � gauche
	//
	NumeroPage = 1;
    pStylePage = pCRView->donnePage(NumeroPage);
    if (pStylePage == 0)
   	    pStylePage = pCRView->donnePage(0);

    if (pStylePage != 0)
   	    stylePage = *pStylePage;
    else
   	    stylePage.loadDefault();

    NS_CLASSLIB::TRect	RectanglePage, RectangleTexte;
    RectanglePage.Set(stylePage.MargeGauche,
                      -stylePage.MargeHaute,
                      PageLogique.x-stylePage.MargeDroite,
                      PageLogique.y+stylePage.MargeBasse);

    RectangleTexte.Set(RectanglePage.Left() + stylePage.MargeTxtGch,
                      RectanglePage.Top() - stylePage.MargeTxtHaut,
                      RectanglePage.Right() - stylePage.MargeTxtDte,
                      RectanglePage.Bottom() + stylePage.MargeTxtBas);
    //
	// On initialise le point de r�f�rence en haut et � gauche
	//
	PointRef.x = RectangleTexte.Left();
    PointRef.y = RectangleTexte.Top();
	//
	// Lecture du fichier paragraphe par paragraphe
	//
	while (getline(inFile, Chaine, '\n'))
	{
		if (strlen(Chaine.c_str()) > 0)
		{
			//
			// Si le paragraphe commence par un indicateur de l�sions, on saute
			//
			if (Chaine[0] == '<')
			{
				UINT k = 1;
				while (Chaine[k] != '>')
					k++;
				k++;
				Chaine = string(Chaine, k, strlen(Chaine.c_str()) - k);
			}
        }
        if (strlen(Chaine.c_str()) > 0)
		{
			//
			// Si le paragraphe commence par un changement de style
			//
			if (Chaine[0] == char(27))
			{
				NumeroPara 	 = UINT(Chaine[1]) - UINT('0');
				StylePara 	 = *(pCRView->StylesParagraphe[NumeroPara-1]);
				NumeroPolice = StylePara.NumPolice;
				delete pPolice;
                pPolice = 0;
				PoliceVoulue = *(pCRView->StylesPolice[NumeroPolice-1]);
                PoliceVoulue.logFont.lfHeight = PoliceVoulue.logFont.lfHeight * 254 / 72;
				PoliceVoulue.logFont.lfWidth  = PoliceVoulue.logFont.lfWidth  * 254 / 72;
				pPolice = new TFont(&(PoliceVoulue.logFont));
				Chaine = string(Chaine, 2, strlen(Chaine.c_str()) - 2);
				pDC->SelectObject(*pPolice);
			}
			//
			// On ote les �ventuels d�but/fin de paragraphe
			//
			size_t i = Chaine.find(char(27));
			while (i != NPOS)
			{
					if (i == 0)
						Chaine = string(Chaine, 2, strlen(Chaine.c_str()) - 2);
					else if (i >= strlen(Chaine.c_str()) - 2)
						Chaine = string(Chaine, 0, i);
					else
						Chaine = string(Chaine, 0, i) +
                                string(Chaine, i+2, strlen(Chaine.c_str())-i-2);
					i = Chaine.find(char(27));
			}
			i = Chaine.find(char(28));
			while (i != NPOS)
			{
					if (i == 0)
						Chaine = string(Chaine, 2, strlen(Chaine.c_str()) - 2);
					else if (i >= strlen(Chaine.c_str()) - 2)
						Chaine = string(Chaine, 0, i);
					else
						Chaine = string(Chaine, 0, i) +
                                string(Chaine, i+2, strlen(Chaine.c_str())-i-2);
					i = Chaine.find(char(28));
			}
		}
		//
		// On pr�voit l'espace au dessus du paragraphe
		//
		PointRef.Offset(0, -StylePara.EspaceDessus);
		//
		// Calcul de la largeur utilisable sans le retrait gauche
		//
		LargeurGauche = RectangleTexte.Width() - StylePara.RetraitDroit;
		//
		// On traite le paragraphe, ligne par ligne
		//
		Curseur = 0; PreBlanc = 0;
		TraiteLigne = 1;
		while (TraiteLigne > 0)
		{
				//
				// Cr�ation d'une ligne vierge
				//
				pLigne = new NSLigne();
				//
				// Initialisation de tous les param�tres d�j� connus
				//
				pLigne->numPage = NumeroPage;
				if (TraiteLigne == 1)
					pLigne->Boite.left = StylePara.RetraitPremLigne;
				else
					pLigne->Boite.left = StylePara.RetraitGauche;
				pLigne->Boite.right   = LargeurGauche;
				pLigne->Boite.top	  	 = PointRef.y;
				pLigne->Boite.bottom  = PointRef.y;
				// pLigne->CouleurTexte  = *(StylePara.pCouleurTexte);
				pLigne->numParagraphe = NumeroPara;
				pLigne->numLigne		 = TraiteLigne;
				//
				// Traitement des chaines de taille non nulle
				//
				if (strlen(Chaine.c_str()) > 0)
				{
					//
					// D�termination de la largeur utilisable
					//
					LargeurPossible = UINT(pLigne->Boite.Width());
					//
					// Recherche du segment de cha�ne qui "tient" dans cette largeur
					//
					NouBlanc = Curseur;
					do
					{
						PreBlanc = NouBlanc;
						NouBlanc = Chaine.find(' ', PreBlanc+1);
						if (NouBlanc == NPOS)
							break;
						TailleChaine = pDC->GetTextExtent(string(Chaine, Curseur, NouBlanc-Curseur).c_str(),
																 int(NouBlanc-Curseur));
					}
					while (TailleChaine.cx < LargeurPossible);
					//
					// Si on est en fin de cha�ne, on regarde si le dernier mot "tient"
					//
					if (NouBlanc == NPOS)
					{
						TailleChaine = pDC->GetTextExtent(string(Chaine, Curseur, strlen(Chaine.c_str())-Curseur).c_str(),
																 int(strlen(Chaine.c_str())-Curseur));
						if (TailleChaine.cx < LargeurPossible)
							PreBlanc = strlen(Chaine.c_str());
					}
					//
					// On met le segment de chaine "qui tient" dans la chaine Texte
					// de la ligne en cours
					//
					pLigne->Texte = string(Chaine, Curseur, PreBlanc-Curseur);
					//
					// On calcule la vraie taille de cette chaine
					//
                    strip(pLigne->Texte);
					TailleChaine = pDC->GetTextExtent(pLigne->Texte.c_str(),
                                        int(strlen(pLigne->Texte.c_str())));
					//
					// On initialise Boite : rectangle exinscrit � la ligne
					//
					if (TailleChaine.cy < StylePara.HauteurLigne)
						TailleChaine.cy = StylePara.HauteurLigne;
					pLigne->Boite.bottom -= TailleChaine.cy;
					PointRef.Offset(0, -TailleChaine.cy);

					//
					//
					//
					if (PreBlanc < strlen(Chaine.c_str()))
					{
						Curseur = PreBlanc + 1;
						TraiteLigne++;
						pLigne->DerniereLigne = false;
					}
					else
					{
						TraiteLigne = 0;
						pLigne->DerniereLigne = true;
					}
				}
				//
				// Traitement des chaines vides
				//
				else
				{
					pLigne->Texte = "";
					//
					// On initialise Boite : rectangle exinscrit � la ligne
					//
					TailleChaine = pDC->GetTextExtent(" ", 1);
					if (TailleChaine.cy < StylePara.HauteurLigne)
						TailleChaine.cy = StylePara.HauteurLigne;
					pLigne->Boite.bottom -= TailleChaine.cy;
					PointRef.Offset(0, -TailleChaine.cy);
					//
					// On pr�cise que le traitement est termin�
					//
					TraiteLigne = 0;
					pLigne->DerniereLigne = true;
				}
            //
				// Si la ligne d�borde de la page, elle passe en page suivante
				//
				if (abs(PointRef.y) > abs(RectangleTexte.Height()))
				{
					NumeroPage++;
					PointRef.y = 0;
					pLigne->numPage = NumeroPage;
					pLigne->Boite.top	= PointRef.y;
					pLigne->Boite.bottom = -TailleChaine.cy;
				}
				//
				// On ajoute la ligne � Lignes
				//
				pCRView->LignesPrnt.push_back(new NSLigne(*pLigne));
				delete pLigne;
            pLigne = 0;
		}
		//
		// On pr�voit l'espace au dessous du paragraphe
		//
		PointRef.Offset(0, -StylePara.EspaceDessous);
		Chaine = "";
	}
	delete pPolice;
   pPolice =0;
	inFile.close();
	pDC->RestoreDC(iAncDC);
	return;
}

void
NSCRPrintout::PrintPage(int page, NS_CLASSLIB::TRect& rect, unsigned)
{
  // Conditionally scale the DC to the window so the printout will
  // resemble the window
  //
  int    prevMode;
  NS_CLASSLIB::TSize  oldVExt, oldWExt;
  //
  // Demande � ce rectangle, dans cette page, de se peindre
  //
  pCRView->PaintPrnt(*DC, false, page, rect);
}

// Do not enable page range in the print dialog since only one page is
// available to be printed
//
void
NSCRPrintout::GetDialogInfo(int& minPage, int& maxPage,
										 int& selFromPage, int& selToPage)
{
  minPage = 1;
  maxPage = 1;
  selFromPage = selToPage = 1;
}

bool
NSCRPrintout::HasPage(int pageNumber)
{
	return pageNumber == 1;
}
