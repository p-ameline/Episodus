//---------------------------------------------------------------------------// #include "stdafx.h"

#include <vcl.h>
#pragma hdrstop

#include <dstring.h>
#include "AcroReader.h"
#include "ActiveX.h"

#include "nautilus\nsAcroRead.h"
#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "nautilus\nautilus.rh" 	// pour l'id de commande CM_IMPRIME (et CM_EDITER)
#include "nautilus\nshistdo.h"
#include "nautilus\nsdocview.h"
#include "nsbb\nsattvaltools.h"

typedef enum BrowserNavConstants {
    navOpenInNewWindow = 1,
    navNoHistory = 2,
    navNoReadFromCache = 4,
    navNoWriteToCache = 8
} BrowserNavConstants;

// Table de r�ponses de la classe NSVisualView////////////////////////////////////////////////////////////////
DEFINE_RESPONSE_TABLE1(NSAcrobatView, TWindowView)
  EV_WM_CLOSE,
  EV_WM_SETFOCUS,
  EV_WM_KILLFOCUS,
  EV_WM_KEYDOWN,
  EV_WM_RBUTTONDOWN,
  EV_WM_SIZE,
  EV_COMMAND(CM_ENREGISTRE,	CmFileSave),
  EV_COMMAND(CM_IMPRIME,		CmPublier),
END_RESPONSE_TABLE;

// Constructeur NSAcrobatView
////////////////////////////////////////////////////////////////

NSAcrobatView::NSAcrobatView(NSAcrobatDocument& doc, TWindow *parent)							:TWindowView(doc, parent), pDoc(&doc), Form(0){
	pMUEViewMenu = 0 ;

	nsMenuIniter menuIter(pDoc->pContexte) ;
  pMUEViewMenu = new OWL::TMenuDescr ;
  menuIter.initMenuDescr(pMUEViewMenu, "menubar") ;
  TMyApp* pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;
  pMyApp->GetMainWindow()->SetMenuDescr(*pMUEViewMenu) ;

	bSetupToolBar = true;
}

// Destructeur NSVisualView////////////////////////////////////////////////////////////////

NSAcrobatView::~NSAcrobatView(){
	if (pMUEViewMenu)
  	delete pMUEViewMenu ;

	// Delete de la Form
	delete Form ;
	//CoUninitialize();
	OleUninitialize() ;
}

// GetWindow renvoie this////////////////////////////////////////////////////////////////

TWindow*NSAcrobatView::GetWindow()
{
	return (TWindow*) this;
}

// Fonction CanClose pour d�truire la barre d'outils
////////////////////////////////////////////////////////////////

boolNSAcrobatView::CanClose()
{
	TMyApp* pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;
	pMyApp->FlushControlBar() ;

	bSetupToolBar = false ;

	return TWindow::CanClose() ;}

//
// Override a TWindow virtual to create the HWND directly.
// NSVisualView and the VCL TForm1 class both end up
// wrapping the same HWND.
//

voidNSAcrobatView::PerformCreate(int /*menuOrId*/)
{
try
{
  /********************************************************************
  PRECONDITION(!Form);

  // create the actual VCL form object
  //
  CoInitialize(NULL);
  Form = new TWebProxy(Parent->GetHandle(), this);
  if (Form) {
      CHECK(Form->Handle);

      // Give the OWL TWindow object the handle of the Windows
      // object it aliases
      //
      SetHandle(Form->Handle);
  }
*****************************************************************************/

/******************** USING ACROBAT DLL

  // CoInitialize(NULL) ;  OleInitialize(NULL);    // Use OleInitialize to get clipboard functionality
  // on cr�e la Form pour servir de zone client (on lui passe le handle parent)
  // The Form is created as the client (it receaves the Parent handle)
  //
  Form = new TAcrobatProxy(Parent->GetHandle(), this) ;
  Form->Visible = false ;
  Form->ParentWindow = Parent->HWindow ;

  SetHandle(Form->Handle) ;  ::SetParent(Forms::Application->Handle, pDoc->pContexte->GetMainWindow()->HWindow) ;
  string sFileToOpen ;  if (pDoc->nomFichier[0] == '\0')  	sFileToOpen = pDoc->szFichierExterne ;  else  	sFileToOpen = pDoc->nomFichier ;  if (sFileToOpen != string(""))  	displayFile(sFileToOpen) ;*/// ****************** USING IE	CoInitialize(NULL) ;	Form = new TWebProxy(Parent->GetHandle(), 0) ;
	Form->Visible = false ;
	Form->ParentWindow = Parent->HWindow ;
	SetHandle(Form->Handle) ;
	::SetParent(Forms::Application->Handle, pDoc->pContexte->GetMainWindow()->HWindow) ;

	// on navigue vers le fichier
  //
  string sFileToOpen ;
  if (pDoc->nomFichier[0] == '\0')  	sFileToOpen = pDoc->szFichierExterne ;  else  	sFileToOpen = pDoc->nomFichier ;  if (sFileToOpen != string(""))
    displayFile(sFileToOpen) ;}catch (...)
{
	erreur("Exception NSAcrobatView::PerformCreate.", standardError, 0) ;
}}

void
NSAcrobatView::displayFile(string sFileName)
{
try
{
	wchar_t buff[1024] ;
  MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, sFileName.c_str(), -1, buff, sizeof(buff)) ;

/******************** USING ACROBAT DLL
  TOLEBOOL bResult = Form->Control->LoadFile(buff) ;
*/

// ****************** USING IE

	Variant  Flags(navNoReadFromCache) ;
	TVariant VFlags = Flags.operator TVariant() ;
	Form->Control->Navigate(buff, &VFlags) ;
}
catch (...)
{
	erreur("Exception NSComposView::Navigate.", standardError, 0) ;
}
}

// Fonction SetupWindow////////////////////////////////////////////////////////////////

voidNSAcrobatView::SetupWindow()
{
	TWindowView::SetupWindow() ;

  int X = 0 ;
  int Y = 0 ;
	int W = Form->Width ;
  int H = Form->Height ;

  Parent->SetWindowPos(0, X, Y, W, H, SWP_NOZORDER) ;
	ModifyStyle(WS_BORDER, WS_CHILD) ;
  NS_CLASSLIB::TRect r = GetClientRect() ;  Form->Control->Left   = 0 ;  Form->Control->Top    = 0 ;
  Form->Control->Width  = r.Width() - 5 ;
  Form->Control->Height = r.Height() - 5 ;

  // Form->Control->setViewRect(0, 0, r.Width() - 10, r.Height() - 10) ;
  Form->Show() ;
  MakeVisible() ;
}

void
NSAcrobatView::CmPublier()
{
	// Form->Control->printWithDialog() ;
}

void
NSAcrobatView::CmFileSave()
{
	Enregistrer() ;
}

voidNSAcrobatView::SetupNavBar()
{
	TMyApp* pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;

  if (pMUEViewMenu)
  	pMyApp->GetMainWindow()->SetMenuDescr(*pMUEViewMenu) ;

	pMyApp->FlushControlBar();

/*
	pMyApp->cb2->Insert(*new TButtonGadget(IDC_EDITION_HTM, IDC_EDITION_HTM, TButtonGadget::Command));
  pMyApp->cb2->Insert(*new TButtonGadget(IDC_RAFRAICHIR_HTM, IDC_RAFRAICHIR_HTM, TButtonGadget::Command));
  pMyApp->cb2->Insert(*new TButtonGadget(CM_PRECEDENT, CM_PRECEDENT, TButtonGadget::Command));
  pMyApp->cb2->Insert(*new TSeparatorGadget);
  pMyApp->cb2->Insert(*new TSeparatorGadget);
  pMyApp->cb2->Insert(*new TButtonGadget(CM_SUIVANT, CM_SUIVANT, TButtonGadget::Command));
*/

  pMyApp->cb2->LayoutSession();}

voidNSAcrobatView::EvClose()
{
	TWindow::EvClose();
}

// Fonctions EvSetFocus et EvKillFocus pour la control Bar
////////////////////////////////////////////////////////////////
void
NSAcrobatView::EvSetFocus(THandle hWndLostFocus /* may be 0 */)
{
	TMyApp* pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;

  TWindow::EvSetFocus(hWndLostFocus) ;

	if (bSetupToolBar && (GetWindow() != pMyApp->GetToolBarWindow()))
  {
  	SetupNavBar() ;
    pMyApp->SetToolBarWindow(GetWindow()) ;
  }
}

voidNSAcrobatView::EvKillFocus(THandle hWndGetFocus /* may be 0 */)
{
	TWindow::EvKillFocus(hWndGetFocus);
}

voidNSAcrobatView::EvKeyDown(uint key, uint repeatCount, uint flags)
{
/*
    WORD wScrollNotify = 0xFFFF;
    bool bVScroll = true;
    int  dx, dy;

    // Touches Ctrl - Quelque chose
    //
    if (GetKeyState(VK_CONTROL) < 0)
    {
    	switch (key)
		{
        	// Ctrl C : Copier
            //
        	case 'C':
            	if (GetKeyState(VK_CONTROL) < 0)
            	{
                	// copie du texte s�lectionn� dans le presse-papier
                	IDispatch* pdisp = Form->Control->Document;
                	IOleCommandTarget* command;
                	pdisp->QueryInterface(IID_IOleCommandTarget, (void**)&command);
                	if(command)
                	{
      	            	command->Exec(NULL, Shdocvw_tlb::OLECMDID_COPY, Shdocvw_tlb::OLECMDEXECOPT_DODEFAULT, NULL, NULL);
                    	command->Release();
                	}
                	pdisp->Release();
                	// Form->Control->ExecWB(Shdocvw_tlb::OLECMDID_COPY, Shdocvw_tlb::OLECMDEXECOPT_DODEFAULT, NULL, NULL);
            	}
            	break;
			// Ctrl A : Tout s�lectionner
            //
        	case 'A':            	if (GetKeyState(VK_CONTROL) < 0)
            	{
                	// copie du texte s�lectionn� dans le presse-papier
                	IDispatch* pdisp = Form->Control->Document;
                	IOleCommandTarget* command;
                	pdisp->QueryInterface(IID_IOleCommandTarget, (void**)&command);
                	if(command)
                	{
      	            	command->Exec(NULL, Shdocvw_tlb::OLECMDID_SELECTALL, Shdocvw_tlb::OLECMDEXECOPT_DODEFAULT, NULL, NULL);
                    	command->Release();
                	}
                	pdisp->Release();
                	// Form->Control->ExecWB(Shdocvw_tlb::OLECMDID_SELECTALL, Shdocvw_tlb::OLECMDEXECOPT_DODEFAULT, NULL, NULL);
            	}
            	break;
		}
	}
    else
    {
    	switch (key)
		{
   	    	case VK_UP:
      	    	wScrollNotify = SB_LINEUP;
            	dx = 0; dy = -10;
            	break;

        	case VK_PRIOR:
      	    	wScrollNotify = SB_PAGEUP;
            	dx = 0; dy = -100;
            	break;

        	case VK_NEXT:
      	    	wScrollNotify = SB_PAGEDOWN;
            	dx = 0; dy = 100;
            	break;

        	case VK_DOWN:
      	    	wScrollNotify = SB_LINEDOWN;
            	dx = 0; dy = 10;
            	break;

        	case VK_HOME:
      	    	wScrollNotify = SB_TOP;
            	break;

        	case VK_END:
      	    	wScrollNotify = SB_BOTTOM;
            	break;

        	case VK_RIGHT:
            	wScrollNotify = SB_LINERIGHT;
            	dx = 10; dy = 0;
            	bVScroll = false;
            	break;

        	case VK_LEFT:
            	wScrollNotify = SB_LINELEFT;
            	dx = -10; dy = 0;
            	bVScroll = false;
            	break;
        }
    }

    if (wScrollNotify != 0xFFFF)
    {
        // tentatives de scroll...
        if (bVScroll)
            SendMessage(WM_VSCROLL, MAKELONG(wScrollNotify, 0), 0L);
        else
            SendMessage(WM_HSCROLL, MAKELONG(wScrollNotify, 0), 0L);

        // Form->Control->ScrollBy(dx, dy);
    }
*/
	TWindowView::EvKeyDown(key, repeatCount, flags);
}
voidNSAcrobatView::EvRButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
/*
	OWL::TPopupMenu *menu = new OWL::TPopupMenu();

#ifndef N_TIERS
	if (!strcmp(pDocRef->pDocInfo->pDonnees->type, "TWHTM"))
#else
	if (!strcmp(pDocRef->pDocInfo->pDonnees->type, "ZTHTM"))
#endif
	{
		menu->AppendMenu(MF_STRING, CM_EDITER, "Editer");
    menu->AppendMenu(MF_SEPARATOR, 0, 0);
    menu->AppendMenu(MF_STRING, CM_IMPRIME, "Publier");
    menu->AppendMenu(MF_STRING, CM_COMPOSE, "Composer");
	}
  else
	{
		menu->AppendMenu(MF_GRAYED, 0,         "Editer");
    menu->AppendMenu(MF_SEPARATOR, 0, 0);
    menu->AppendMenu(MF_STRING, CM_IMPRIME, "Imprimer");
    menu->AppendMenu(MF_STRING, CM_COMPOSE, "Composer");
	}

	ClientToScreen(point) ;
	menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point, 0, HWindow) ;
	delete menu ;
*/
}

// Fonction Enregistrer
////////////////////////////////////////////////////////////////
bool NSAcrobatView::Enregistrer(){	string sFichier = pDoc->nomFichier ;

  if (sFichier != string(""))
  {
  	erreur("Erreur lors de la sauvegarde.", warningError, 0, pDoc->pContexte->GetMainWindow()->GetHandle()) ;
		return true ;
  }

  sFichier = pDoc->szFichierExterne ;
  if (sFichier == string(""))
  	return false ;

  pDoc->SetNomFichier(sFichier) ;

  string sNomFichier ;
  string sLocalis ;

  bool bRenommerOk = pDoc->Renommer(sNomFichier, sLocalis, "ZTPDF") ;  if (!bRenommerOk)  	return false ;
  // Copying the temporary file, with the new name
  //
  if (!CopyFile(sFichier.c_str(), pDoc->nomFichier, true))
  {  	string sErrorText = pDoc->pContexte->getSuperviseur()->getText("fileErrors", "errorCopyingFile") ;    sErrorText += string(" ") + sFichier + string(" -> ") + pDoc->nomFichier ;
    erreur(sErrorText.c_str(), standardError, 0, pDoc->pContexte->GetMainWindow()->GetHandle()) ;  	pDoc->SetNomFichier("") ;    return false ;  }

	if (pDoc->Referencer("ZTPDF", "", sNomFichier, sLocalis))
  {    pDoc->SetDirty(false) ;    // Displaying the new file instead of the temporary one    //    displayFile(pDoc->nomFichier) ;
    // on remet le titre � jour    TWindow::SetDocTitle(pDoc->GetTitle(), 0) ;

    // Now, we can delete the temporary file
    if (::DeleteFile(sFichier.c_str()))
    	pDoc->SetFichierExterne(string("")) ;
  }
  else
  {
  	pDoc->SetDirty(true) ;

    // on remet le document dans l'�tat initial    pDoc->SetNomFichier("") ;
  }

  return true ;}

bool
NSAcrobatView::IsTabKeyMessage(MSG &msg)
{
	if (GetCapture() == NULL)
  {
  	if (msg.message == WM_KEYDOWN || msg.message == WM_KEYUP)
    {
    	if (msg.wParam == VK_TAB)
      {
      	SendMessage(CN_BASE + msg.message, msg.wParam, msg.lParam) ;
        return true ;
      }
    }
  }

	return false ;
}

// keep the control at full window size

voidNSAcrobatView::EvSize(uint sizeType, NS_CLASSLIB::TSize& size){
	TWindowView::EvSize(sizeType, size) ;

  NS_CLASSLIB::TRect r = GetClientRect() ;
  Form->Left   = 0 ;
  Form->Top    = 0 ;
  Form->Width  = r.Width() ;
  Form->Height = r.Height() ;
  Form->Invalidate() ;
}


//// Let the form process keystrokes in its own way.  Without
// this method, you can't tab between control on the form.
//
bool
NSAcrobatView::PreProcessMsg(MSG &msg)
{
	bool result = IsTabKeyMessage(msg) ;

  if (!result)
  	result = TWindow::PreProcessMsg(msg) ;

  return result ;
}

////
//
void
NSAcrobatView::MakeVisible()
{
	Form->Visible = true;
}

/******************************************************************************/
//					METHODES DE Document / Vue pour Acrobat
/******************************************************************************/

// Constructeur NSAcrobatDocument////////////////////////////////////////////////////////////////

NSAcrobatDocument::NSAcrobatDocument(TDocument* parent, bool bROnly, NSDocumentInfo* pDocumentInfo,                             NSDocumentInfo* pDocHtmlInfo, NSContexte* pCtx)
                  :NSRefDocument(parent, pDocumentInfo, pDocHtmlInfo, pCtx, bROnly)
{
	// Mise � vide du nom de fichier
  SetNomFichier("") ;
  SetFichierExterne("") ;
	Open(0, "") ;
}

NSAcrobatDocument::NSAcrobatDocument(TDocument *parent, NSContexte *pCtx)                  :NSRefDocument(parent, pCtx)
{
	// Mise � vide du nom de fichier
  SetNomFichier("") ;
  SetFichierExterne("") ;
	Open(0, "") ;
}

NSAcrobatDocument::~NSAcrobatDocument()
{
	if (szFichierExterne[0] != '\0')
		::DeleteFile(szFichierExterne) ;
}

void
NSAcrobatDocument::Visualiser()
{
	NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(this, "Pdf Format") ;
}

voidNSAcrobatDocument::SetNomFichier(string sFich){
	strcpy(nomFichier, sFich.c_str()) ;
}

void
NSAcrobatDocument::SetFichierExterne(string sFich)
{
	strcpy(szFichierExterne, sFich.c_str()) ;

  if (nomFichier[0] == '\0')
  	replaceTagsByValues() ;
}

stringNSAcrobatDocument::GetDocExt(){
	size_t i ;
	string sExt = "";

	for (i = 0; (i < strlen(nomFichier)) && (nomFichier[i] != '.'); i++) ;

  if (i < strlen(nomFichier))
  {
  	// nomDoc[i] == '.'
    i++ ;
    while (i < strlen(nomFichier))
    	sExt += nomFichier[i++] ;
  }

  return sExt ;
}

void
NSAcrobatDocument::replaceTagsByValues()
{
	ifstream inFile ;
  string line ;
  string sData = "" ;

	inFile.open(szFichierExterne, ios::binary) ;
  if (!inFile)
    return ;

  ofstream outFile ;

  string sPathTxt = pContexte->PathName("NTTX") ;
  // on trouve le nom du fichier temporaire � visualiser

  string sFileBase = string("tmp") ;
	sFileBase += pContexte->getPatient()->getNss() ;
  string sFileName = sPathTxt + ::nomSansDoublons(sPathTxt, sFileBase, "pdf") ;

  outFile.open(sFileName.c_str(), ios::binary) ;
	if (!outFile)
  {
  	inFile.close() ;
    return ;
  }

  // If a Tag is similar to the previous one, and the PatPatho is made of
  // more than one element, we answer with next element
  //
  string          sLastTag = "" ;
  string          sLastResult = "" ;
	NSPatPathoArray lastPatPathoArray(pContexte) ;
  PatPathoIter    iterPremier ;

  char iChar = inFile.get() ;

  while (!inFile.eof())
  {
    if ((iChar == '[') && (!inFile.eof()))
    {
    	iChar = inFile.get() ;
      if (iChar == '$')
      {
      	string sBalise = string("") ;
        bool bTourner = true ;
        while (!inFile.eof() && bTourner)
        {
        	iChar = inFile.get() ;
          if (iChar == '$')
          {
          	if (!inFile.eof())
            {
            	iChar = inFile.get() ;
              if (iChar == ']')
              	bTourner = false ;
              else
              	sBalise += string("$") + string(1, iChar) ;
            }
          }
          else
          	sBalise += string(1, iChar) ;
        }
        //
        // Traiter la balise
        //
        string sResult = pdfStringToWindowString(&sBalise) ;

        if (sResult != string(""))
        {
          NSPatPathoArray* pPatPathoArray = NULL ;
        	pContexte->getPatient()->remplaceTagsChemin(sResult, pPatPathoArray) ;
          if (pPatPathoArray)
          	delete pPatPathoArray ;
        }

        if (sResult != string(""))
        	for (size_t i = 0 ; i < strlen(sResult.c_str()) ; i++)
          	outFile.put(sResult[i]) ;
      }
      else
      {
      	outFile.put('[') ;
      	outFile.put(iChar) ;
      }
    }
    else
    	outFile.put(iChar) ;

    iChar = inFile.get() ;
  }
  inFile.close() ;
  outFile.close() ;

  strcpy(szFichierExterne, sFileName.c_str()) ;

  return ;

/*
  size_t pos = sData.find("[$") ;
  while (pos != NPOS)
  {
  	size_t pos2 = sData.find("$]", pos + 1) ;
    if (pos2 != NPOS)
    {
  		// abcd[$123$]efg
  		// 01234567890123
      //     4    9
    	sData = string(sData, 0, pos) + string("balise") + string(sData, pos2+2, strlen(sData.c_str()) - pos2 - 2) ;
      pos = sData.find("[$", pos) ;
    }
    else
			pos = sData.find("[$", pos + 1) ;
  }

	ofstream ostr ;
  string fileN = "tmp.pdf" ;
  ostr.open(fileN.c_str()) ;
  ostr << sData ;
  ostr.close() ;

  strcpy(szFichierExterne, fileN.c_str()) ;

*/
}

string
NSAcrobatDocument::pdfStringToWindowString(string *pPdfString)
{
	if (!pPdfString)
		return string("") ;

  size_t iPdfLen = strlen(pPdfString->c_str()) ;

  string sWindowString = string("") ;

  size_t lastpos = 0 ;
  size_t pos = pPdfString->find('\\') ;
  while (pos != NPOS)
  {
    if (pos > lastpos)
  		sWindowString += string(*pPdfString, lastpos, pos - lastpos) ;

  	// abcd\040efg
		// 01234567890
    //     4
    if (pos <= iPdfLen - 4)
    {
    	string sOctalValue = string(*pPdfString, pos + 1, 3) ;
      int iPdfValue = atoi(sOctalValue.c_str()) ;
      if (iPdfValue > 0)
      {
      	string sWinChars = pdfCharToWindowString(iPdfValue) ;
        sWindowString += sWinChars ;
      }
      lastpos = pos + 4 ;
    }
    else
    	lastpos = pos ;

    pos = pPdfString->find('\\', lastpos) ;
  }
  if (lastpos <= iPdfLen)
  	sWindowString += string(*pPdfString, lastpos, iPdfLen - lastpos) ;

  return sWindowString ;
}

string
NSAcrobatDocument::pdfCharToWindowString(int iPdfValue)
{
	//
  // PDF value differs from Windows value
  //
	switch(iPdfValue)
  {
  	case  32 : return string(1, char(210)) ;
    case  37 : return string(1, char(230)) ;
    case  40 : return string(" ") ; // Space
  	case 200 : return string(1, char(225)) ;
    case 201 : return string(1, char(206)) ;
    case 202 : return string(1, char(207)) ;
    case 203 : return string(1, char(205)) ;
    case 204 : return string(1, char(227)) ;
    case 205 : return string(1, char(226)) ;
    case 210 : return string(1, char(213)) ;
    case 211 : return string(1, char(233)) ;
    case 213 : return string(1, char(211)) ;
    case 214 : return string(1, char(204)) ;
    case 215 : return string(1, char(223)) ;
    case 216 : return string(1, char(224)) ;
    case 217 : return string(1, char(221)) ;
    case 220 : return string(1, char(222)) ;
    case 221 : return string(1, char(202)) ;
    case 222 : return string(1, char(231)) ;
  	case 226 : return string(1, char(214)) ;
  	case 227 : return string(1, char(212)) ;
  	case 230 : return string(1, char(237)) ;
  	case 231 : return string(1, char(216)) ;
    case 235 : return string(1, char(232)) ;
    case 240 : return string(1, char(200)) ;
  }
  //
  // PDF value differs does not exist in Windows
  //
  switch(iPdfValue)
  {
  	case  30 :
    case  31 :
    case  33 :
    case  34 :
    case  35 :
    case  36 :
    case 207 :
    case 212 :
    case 223 :
    case 224 :
  	case 225 :
    case 232 :
    case 233 :
    	return string("") ;
  }
  //
  // PDF and Windows values are equal
  //
  char cWinVal = char(iPdfValue) ;
  return string(1, cWinVal) ;
}

// Ouverture du document////////////////////////////////////////////////////////////////

boolNSAcrobatDocument::Open(int /*mode*/, LPCSTR path){
	string sNomFichier = "" ;

	// Si il existe, prise du nom de fichier de la fiche document  ValideFichier(&sNomFichier) ;

	// Sinon, on sort	if (!bDocumentValide)
		return false ;

	//	// Rangement du nom de fichier dans le document
	//
	SetNomFichier(sNomFichier) ;
  SetDirty(false) ;
  return true ;
}

// Fermeture du document////////////////////////////////////////////////////////////////
bool NSAcrobatDocument::Close()
{
  // if (TDocument::Close())
  // 	 return false;

  SetNomFichier("") ;
  return true ;
}

// G�n�ration du html correspondant au document
////////////////////////////////////////////////////////////////
bool
NSAcrobatDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	return true ;
}

// Indique si document ouvert (il existe un fichier associ�)////////////////////////////////////////////////////////////////
bool NSAcrobatDocument::IsOpen()
{
	if (_fstricmp(nomFichier,""))
    return true ;
 	else
    return false ;
}

// Trouve un nom de fichier nautilus au document
////////////////////////////////////////////////////////////////
bool
NSAcrobatDocument::Renommer(string& sNomFichier, string& sLocalis, string sType, string* psNomBrut)
{
  string sPath = "" ;
  string sExt  = GetDocExt() ;

  if (!TrouveNomFichier(sType, sExt, sNomFichier, sLocalis))
  {
    erreur("Pb � l'attribution d'un nouveau nom pour ce fichier",standardError,0,pContexte->GetMainWindow()->GetHandle()) ;
    return false ;
  }

  if (psNomBrut)
  {
  	// Dans ce cas on renvoie aussi le nom brut (sans extension)
    size_t pos = sNomFichier.find('.') ;
    if (pos != NPOS)
    	*psNomBrut = string(sNomFichier, 0, pos) ;
    else
    	*psNomBrut = sNomFichier ;
  }

  sPath = pContexte->PathName(sLocalis) ;

  // on construit le nom complet pour la sauvegarde
  SetNomFichier(sPath + sNomFichier) ;

  SetDirty(true) ;

  return true ;
}

// fin de nsvisual.cpp/////////////////////////////////////////////////////////////////

