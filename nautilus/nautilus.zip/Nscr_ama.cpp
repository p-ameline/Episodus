//----------------------------------------------------------------------------// ObjectWindows - (C) Copyright 1991, 1993 by Borland International
//   Tutorial application -- step12dv.cpp
//----------------------------------------------------------------------------
#include <owl\dc.h>
#include <owl\gdiobjec.h>
#include <classlib\arrays.h>

#include "partage\nsdivfct.h"#include "nautilus\nscr_ama.h"

// -------------------------------------------------------------------------// -------------------- METHODES DE NSCRPhraseArray ------------------------
// -------------------------------------------------------------------------

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCRPhraseArray::NSCRPhraseArray(NSCRPhraseArray& rv)
                :NSCRPhrArray()
{
try
{
	if (!(rv.empty()))
		for (NSCRPhrArrayIter i = rv.begin(); i != rv.end(); i++)
    	push_back(new NSCRPhrase(*(*i))) ;
}
catch (...)
{
	erreur("Exception NSCRPhraseArray copy ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Fonction:		~NSCRPhraseArray()
//  Description:	Destructeur
//  Retour:			Rien
//---------------------------------------------------------------------------
void
NSCRPhraseArray::vider()
{
	if (empty())
  	return ;

	for (NSCRPhrArrayIter i = begin(); i != end(); )  {
  	delete *i ;
    erase(i) ;
  }
}

NSCRPhraseArray::~NSCRPhraseArray(){
	vider() ;
}

//---------------------------------------------------------------------------//  Fonction	 : NSCRPhraseArray::operator=(NSCRPhraseArray src)
//
//  Description : Op�rateur d'affectation
//---------------------------------------------------------------------------

NSCRPhraseArray&NSCRPhraseArray::operator=(NSCRPhraseArray src)
{
try
{
	if (this == &src)
		return *this ;

	vider() ;

	if (!(src.empty()))		for (NSCRPhrArrayIter i = src.begin(); i != src.end(); i++)
    	push_back(new NSCRPhrase(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception NSCRPhraseArray = operator.", standardError, 0) ;
	return *this ;
}
}

