//----------------------------------------------------------------------------// ObjectWindows - (C) Copyright 1991, 1993 by Borland International
//   Tutorial application -- step12dv.cpp
//----------------------------------------------------------------------------
#include <owl\owlpch.h>
#include <owl\dc.h>

#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"
#include "nautilus\nsdecode.h"
#include "nsbb\nsbb.h"
#include "nsbb\nsbbsmal.h"
#include "nautilus\nsrechd2.h"

#include "nautilus\nscsdoc.h"
#include "nautilus\nscsvue.h"

#include "nautilus\nshistdo.h"
#include "nautilus\ns_html.h"
#include "nsepisod\nssoapdiv.h"
#include "nautilus\nsldvdoc.h"
#include "nautilus\nschoisi.h"

// --------------------------------------------------------------------------
// ---------------------- METHODES DE NSCSDocument --------------------------
// --------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
//	Constructeur � partir d'un document existant
//
//---------------------------------------------------------------------------
NSCSDocument::NSCSDocument(TDocument* parent, NSDocumentInfo* pDocumentInfo,
                           NSDocumentInfo* pDocHtmlInfo, NSContexte* pCtx,
                           string sTypeDocum, bool bROnly)
			       :NSRefDocument(parent, pDocumentInfo, pDocHtmlInfo, pCtx, bROnly)
{
	sTitre		  = "";
	pBigBoss	  = 0;
	sTypeDocument = sTypeDocum;
	pHtmlCS       = 0;
}

//---------------------------------------------------------------------------
//
//	Constructeur pour un nouveau document
//
//---------------------------------------------------------------------------
NSCSDocument::NSCSDocument(TDocument* parent, NSContexte* pCtx, string sTypeDocum)
             :NSRefDocument(parent, pCtx)
{
	if (pContexte->userHasPrivilege(NSContexte::createDocument, -1, -1, string(""), string(""), NULL, NULL))
		bReadOnly = false ;
  else
		bReadOnly = true ;

	sTypeDocument = sTypeDocum;
	sTitre		= "";
	pBigBoss	= 0;
	pHtmlCS		= 0;
}

//---------------------------------------------------------------------------
//  Description : Constructeur copie
//---------------------------------------------------------------------------
NSCSDocument::NSCSDocument(NSCSDocument& rv)
             :NSRefDocument(rv)
{
try
{
	if (rv.pBigBoss)
		pBigBoss = new NSSmallBrother(*(rv.pBigBoss)) ;
	else
  	pBigBoss = 0 ;

	if (rv.pHtmlCS)
  	pHtmlCS = new NSHtml(*(rv.pHtmlCS)) ;
  else
  	pHtmlCS = 0 ;

	sTitre 	      = rv.sTitre ;
	sTypeDocument = rv.sTypeDocument ;
}
catch (...)
{
  erreur("Exception NSCSDocument ctor.", standardError, 0) ;
  return ;
}
}

//---------------------------------------------------------------------------
//  Description : Destructeur
//---------------------------------------------------------------------------
NSCSDocument::~NSCSDocument()
{
	if ((pContexte) && (pContexte->getPatient()))
		if (pContexte->getPatient()->pConsultEnCours == this)
    	pContexte->getPatient()->pConsultEnCours = 0 ;

	if (pHtmlCS)
		delete pHtmlCS ;
}

//---------------------------------------------------------------------------
//  Description : Operateur =
//---------------------------------------------------------------------------
NSCSDocument&
NSCSDocument::operator=(NSCSDocument& src)
{
try
{
	if (this == &src)
  	return *this ;

  NSRefDocument *dest, *source ;
  // Appel de l'operateur = de NSRefDocument
  // (recopie des arguments de la classe NSRefDocument)
  dest   = this ;
  source = &src ;
  *dest  = *source ;

  if (src.pBigBoss)
  	pBigBoss = new NSSmallBrother(*(src.pBigBoss)) ;
  else
  	pBigBoss = 0 ;

  if (src.pHtmlCS)
  	pHtmlCS = new NSHtml(*(src.pHtmlCS)) ;
  else
  	pHtmlCS = 0 ;

	sTitre 	      = src.sTitre ;
  sTypeDocument = src.sTypeDocument ;

	return *this ;
}
catch (...)
{
  erreur("Exception NSCSDocument = operator.", standardError, 0) ;
  return *this ;
}
}

string
NSCSDocument::InitIntitule()
{
try
{
	NSHtml htmlTitre(tTitre2) ;

  string sLang = "";
  if ((pContexte) && (pContexte->getUtilisateur()))
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  string sLibelleDoc = "" ;

  if (!pPatPathoArray->empty())
  {
  	string sCode = (*(pPatPathoArray->begin()))->getLexique() ;
    if (sCode != "")
    {
    	pContexte->getDico()->donneLibelle(sLang, &sCode, &sLibelleDoc) ;
      if (strlen(sLibelleDoc.c_str()))
      	sLibelleDoc[0] = pseumaj(sLibelleDoc[0]) ;
      else
      	sLibelleDoc = "Document de synth�se" ;
    }
    else
    	sLibelleDoc = "Document de synth�se" ;
	}

  if (!pBigBoss)
  	pBigBoss = new NSSmallBrother(pContexte, pPatPathoArray) ;

  char   datex[15] = "" ;
  string sDateExamen = string("") ;

  // on cherche d'abord dans la patpatho
	if (!pPatPathoArray->empty())
	{
  	// First, check if first element is a KCHIR
    //
  	PatPathoIter iterPpt = pPatPathoArray->begin() ;
    iterPpt++ ;
    if (iterPpt != pPatPathoArray->end())
    	if ((*iterPpt)->getLexiqueSens(pContexte) == "KCHIR")
      	pPatPathoArray->CheminDansPatpatho(pBigBoss, "KCHIR", &sDateExamen) ;

    if (sDateExamen == "")
			pPatPathoArray->CheminDansPatpatho(pBigBoss, "LADMI/KCHIR", &sDateExamen) ;
	}

  if (sDateExamen == "")
  {
    if (NULL != pDocInfo)
    {
    	string sDateCreation = pDocInfo->getCreDate() ;
    	strcpy(datex, sDateCreation.c_str()) ;
    }
    else
    	donne_date_duJour(datex) ;
	}
  else
  	strcpy(datex, sDateExamen.c_str()) ;

  if (pContexte->getPatient()->getNomLong() == "")
  	pContexte->getPatient()->fabriqueNomLong() ;

	string sIntitulePatient = pContexte->getPatient()->getNomLong() ;	string sIntituleDocument = sLibelleDoc + string(" de ") + sIntitulePatient ;

	return sIntituleDocument ;}
catch (...)
{
	erreur("Exception NSCSDocument::InitIntitule.", standardError, 0) ;
	return string("") ;
}
}
void
NSCSDocument::activate()
{
	TView* pView = GetViewList() ;
	do
	{
		NSCsVue* pCsView = TYPESAFE_DOWNCAST(pView, NSCsVue) ;
		if (pCsView)
			//pCsView->SetFocus() ;
    	SetFocus(pCsView->GetWindow()->Parent->GetHandle()) ;

		pView = NextView(pView) ;
	}
  while (pView) ;
}

//---------------------------------------------------------------------------//  Function: NSCSDocument::GenereHtml(string sPathHtml, string& sNomHtml, string sAdresseCorresp)
//
//  Arguments:
//				  sPathHtml : 	r�pertoire destination
//				  sNomHtml :   En entr�e -> nom du fichier � g�n�rer
//									En sortie -> nom sans doublons
//				  sAdresseCorresp : nom + adresse du correspondant
//  Description:
//				  G�n�re un fichier html CR dans le r�pertoire sPathName
//				  Utilise les donn�es sTemplate et sBaseImages
//  Returns:
//            true : OK, false : sinon
//---------------------------------------------------------------------------
bool
NSCSDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	string   		sFichierHtml;
	NSHtmlCS 		hcs(typeOperation, this, pContexte, sAdresseCorresp);
  string 			sBaseImg;

	// on trouve le nom du fichier temporaire � visualiser
  sNomHtml = hcs.nomSansDoublons(sPathHtml,sNomHtml,"htm") ;
  sFichierHtml = sPathHtml + sNomHtml ;

  // on passe aussi le path destination pour les images
  if (!hcs.genereHtml(sFichierHtml,sBaseImg,pHtmlInfo,sPathDest))
  	return false ;

	// Mise � jour de la base d'images
  switch (typeOperation)
  {
  	case toComposer:
    	sBaseCompo = sBaseImg ;
      break ;

    default:
    	sBaseImages = sBaseImg ;
	}
	return true ;}

//----------------------------------------------------------------//------------------------------------------------------------------
bool
afficheCompteRendu(NSDocumentInfo& Document, NSContexte *pCtx)
{
	/*NSCRReadOnlyTemplate* DocVisuTemplate = new NSCRReadOnlyTemplate("Compte rendu","",0,"",dtAutoDelete|dtUpdateDir);
	NSCRDocument*			 DocVisuDoc 	  = new NSCRDocument(0, &Document, pSuper);
	DocVisuDoc->SetTemplate(DocVisuTemplate);
	DocVisuTemplate->CreateView(*DocVisuDoc);*/
	return false ;
}
//---------------------------------------------------------------------------//  Ouvre le document en mettant la fiche dans pPatPathoArray
//---------------------------------------------------------------------------
bool
NSCSDocument::Open(int mode, const char far* path)
{
	if (!pDocInfo)
		return true ;

	sTitre = pDocInfo->getDocName() ;
	strip(sTitre) ;

	return bDocumentValide ;
}

bool
NSCSDocument::Close()
{
	//sCompteRendu = "" ;
	return true ;
}

void
NSCSDocument::SetTitle(LPCSTR title)
{
#ifndef _INCLUS
	TDocument::SetTitle(title);
#endif
}

//---------------------------------------------------------------------------
//  Enregistre le document
//---------------------------------------------------------------------------
bool
NSCSDocument::enregistre(bool bVerbose, bool bSoaping)
{
	bool existeInfo;

	if (bEnregEnCours)
		return false ;

	bEnregEnCours = true ;

	string sLang = "";
	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang();

	pContexte->getSuperviseur()->afficheStatusMessage("D�but d'enregistrement");

	// Si c'est une nouvelle fiche, on la cr�e en tant que document
	bool bNewDoc ;
	if (pDocInfo == 0)
		bNewDoc = true ;
	else
		bNewDoc = false ;

	if (bNewDoc)
	{
		string sLibelleDoc ;
    if (sTypeDocument != string(""))
			pContexte->getDico()->donneLibelle(sLang, &sTypeDocument, &sLibelleDoc) ;
    else if (!pPatPathoArray->empty())
    {
    	string sCode = (*(pPatPathoArray->begin()))->getLexique() ;
      pContexte->getDico()->donneLibelle(sLang, &sCode, &sLibelleDoc) ;
    }

		existeInfo = Referencer("ZCS00", sLibelleDoc, "", "", true, bVerbose);
		if (!existeInfo)
		{
			bEnregEnCours = false ;
			return existeInfo ;
		}
	}

	// On enregistre la patpatho
	existeInfo = enregistrePatPatho() ;
	if (!existeInfo)
	{
		bEnregEnCours = false ;
		return existeInfo ;
	}

	existeInfo = NSNoyauDocument::chargePatPatho() ;
	if (!existeInfo)
	{
		bEnregEnCours = false ;
		return existeInfo ;
	}

  // The new document must be inserted in "history" before checking if it resets
  // any goal, because this document's date will be asked to "history"

  // On pr�vient l'historique (fait � part pour les CS et les CN)
	pContexte->getPatient()->pDocHis->Rafraichir(pDocInfo, pPatPathoArray, this) ;

	// Si c'est un nouveau compte rendu on v�rifie s'il remet � z�ro un objectif
	if ((bNewDoc) && (pContexte->getPatient()->pDocLdv))
		pContexte->getPatient()->pDocLdv->showNewTree(pPatPathoArray, GetDateDoc(false)) ;

	pContexte->getSuperviseur()->afficheStatusMessage("Document enregistr�") ;

	bEnregEnCours = false ;

	if (bSoaping)
		makeSOAP() ;

	return existeInfo ;
}

