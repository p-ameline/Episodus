#include <string.h>#include <cstring.h>
#include <stdio.h>

#include "nautilus\nssuper.h"
#include "nautilus\nschoisi.h"
#include "nautilus\nspatdlg.h"
#include "nautilus\nsrechdl.h"
#include "nautilus\nsresour.h"
#include "partage\nsdivfct.h"
#include "partage\ns_timer.h"
#include "nssavoir\nsbloque.h"
#include "nautilus\nsepicap.h"
#include "nautilus\nscqdoc.h"#include "nsbb\nsarc.h"#include "nsbb\ns_skins.h"#include "nsutil\md5.h"   // Cryptage MD5#include "nssavoir\nsHealthTeamMemberInterface.h"#include "nsbb\logpass.h"#include "nsbb\nsdefArch.h"#include "pilot\NautilusPilot.hpp"#include "nsbb\tagNames.h"
#include "nsutil\md5.h"boolpatSortByNameInf(NSPatInfo *pPat1, NSPatInfo *pPat2)
{
	if (pPat1->getNom() != pPat2->getNom())
		return (pPat1->getNom() < pPat2->getNom()) ;
	return (pPat1->getPrenom() < pPat2->getPrenom()) ;
}

bool
patSortByNameSup(NSPatInfo *pPat1, NSPatInfo *pPat2)
{
	if (pPat1->getNom() != pPat2->getNom())
		return (pPat1->getNom() > pPat2->getNom()) ;
	return (pPat1->getPrenom() > pPat2->getPrenom()) ;
}

bool
patSortByBirthInf(NSPatInfo *pPat1, NSPatInfo *pPat2)
{
	return (pPat1->getNaissance() < pPat2->getNaissance()) ;
}

bool
patSortByBirthSup(NSPatInfo *pPat1, NSPatInfo *pPat2)
{
	return (pPat1->getNaissance() > pPat2->getNaissance()) ;
}

bool
patSortBySexInf(NSPatInfo *pPat1, NSPatInfo *pPat2)
{
	return (pPat1->getSexe() < pPat2->getSexe()) ;
}

bool
patSortBySexSup(NSPatInfo *pPat1, NSPatInfo *pPat2)
{
	return (pPat1->getSexe() > pPat2->getSexe()) ;
}

/******************************************************************************/
//					METHODES DE CREERCORRESPDIALOG
/******************************************************************************/
/*

DEFINE_RESPONSE_TABLE1(CreerCorrespDialog, NSUtilDialog)
    EV_WM_CLOSE,
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_BN_CLICKED(IDC_COR_ADR, CmAdresse),
    EV_BN_CLICKED(IDC_COR_ACTIF, CmActif),
END_RESPONSE_TABLE;
CreerCorrespDialog::CreerCorrespDialog(TWindow* pere, NSContexte* pCtx, TModule* module)				   :NSUtilDialog(pere, pCtx, "IDD_CREAT_COR", module)
{
try
{
    // Initialisation des donnees

    pData 		 = new NSCorrespondantData;
#ifndef N_TIERS
    pAdresseInfo = new NSAdressesInfo;
#endif

	// Cr�ation de tous les "objets de contr�le"

    pSexe		 = new TGroupBox(this, IDC_COR_SEXE);
    pTitre		 = new TGroupBox(this, IDC_COR_TITRE);

	pNom 	     = new NSUtilEdit(this, IDC_COR_NOM, COR_NOM_LEN);
	pPrenom    	 = new NSUtilEdit(this, IDC_COR_PRENOM, COR_PRENOM_LEN);
    pSexeM		 = new TRadioButton(this, IDC_COR_SEXE1, pSexe);
    pSexeF       = new TRadioButton(this, IDC_COR_SEXE2, pSexe);

    pAdresse	 = new TCheckBox(this, IDC_COR_ADR);
    pSansTitre   = new TRadioButton(this, IDC_COR_SANSTITRE, pTitre);
    pTitre1		 = new TRadioButton(this, IDC_COR_TITRE1, pTitre);
    pTitre2		 = new TRadioButton(this, IDC_COR_TITRE2, pTitre);
    pTitre3		 = new TRadioButton(this, IDC_COR_TITRE3, pTitre);
    pTitre4		 = new TRadioButton(this, IDC_COR_TITRE4, pTitre);
    pTitre5		 = new TRadioButton(this, IDC_COR_TITRE5, pTitre);
    pTitre6		 = new TRadioButton(this, IDC_COR_TITRE6, pTitre);

	pTelPor		 = new NSEditNumTel(this, IDC_COR_TELPOR, COR_TELEPOR_LEN);
    pTelBur		 = new NSEditNumTel(this, IDC_COR_TELBUR, COR_TELEBUR_LEN);
    pEMail		 = new NSUtilEdit(this, IDC_COR_EMAIL, COR_MESSAGERIE_LEN);
    pNbExpl		 = new NSEditNum(this, IDC_COR_NBEXPL, COR_NB_EXEMP_LEN, 0);

    //pFonction	 = new NSUtilEdit(this, IDC_COR_FONCTION, COR_FONCTION_LEN);
    pFonction	 = new NSUtilLexique(this, IDC_COR_FONCTION, pContexte->getDico());
    pActif       = new TRadioButton(this, IDC_COR_ACTIF);
    bActif       = false;
}

catch (...)
{
    erreur("Exception CreerCorrespDialog ctor.", standardError, 0) ;
}
}
CreerCorrespDialog::~CreerCorrespDialog(){
	delete pFonction;
  delete pEMail;
  delete pNbExpl;
  delete pTelBur;
  delete pTelPor;
  delete pTitre6;
  delete pTitre5;
  delete pTitre4;
  delete pTitre3;
  delete pTitre2;
  delete pTitre1;
  delete pSansTitre;
  delete pAdresse;
  delete pSexeF;
  delete pSexeM;
  delete pPrenom;
  delete pNom;
  delete pTitre;
  delete pSexe;
#ifndef N_TIERS
  delete pAdresseInfo;#endif
  delete pData;  delete pActif;
}


void
CreerCorrespDialog::SetupWindow()
{
  // fichiers d'aide

    sHindex = "";
    sHcorps = "Creation_Modification_d_un.html";

	TDialog::SetupWindow();

    pNom->SetText(pData->nom);
    pPrenom->SetText(pData->prenom);

    if (pData->estMasculin())
   	    pSexeM->Check();
    if (pData->estFeminin())
   	    pSexeF->Check();

    // titre : voir la fonction StringTitre de nsperson.cpp
    switch (pData->docteur[0])
    {
   	    case 'O':
      	    pTitre1->Check();
        	break;
        case 'P':
      	    pTitre2->Check();
      	    break;
        case '1':
      	    pTitre3->Check();
            break;
        case '2':
        	pTitre4->Check();
            break;
        case 'R':
       	    pTitre5->Check();
            break;
        case 'M':
       	    pTitre6->Check();
            break;
        default :
            pSansTitre->Check();
    }

    pTelPor->SetText(pData->telepor);
    pTelBur->SetText(pData->telebur);
    pNbExpl->SetText(pData->nb_exemp);
    pEMail->SetText(pData->messagerie);

    // impl�menter nouvelle fonction
    // pFonction->SetText(pData->fonction);
    if (strcmp(pData->fonction, "") != 0)
        pFonction->setLabel(pData->fonction);

    if (pData->estActif())
    {
        bActif = true;
        repercuteActif();
    }
#ifndef N_TIERS
    if (strcmp(pAdresseInfo->pDonnees->code, ""))   	    pAdresse->Check();
#endif
}

void

CreerCorrespDialog::CmAdresse(){
#ifndef N_TIERS

	bool existeAdresse = false;
  bool modifOK;
  char nomAdr[COR_NOM_LEN + 1];
  char prenomAdr[COR_PRENOM_LEN + 1];

  if (strcmp(pAdresseInfo->pDonnees->code, ""))      existeAdresse = true;

  // on r�cup�re le nom et le pr�nom en cours (sans mettre � jour les data)
  char far nom[COR_NOM_LEN + 1];
  pNom->GetText(nom, COR_NOM_LEN + 1);
  strcpy(nomAdr, nom);

  char far prenom[COR_PRENOM_LEN + 1];
  pPrenom->GetText(prenom, COR_PRENOM_LEN + 1);
  strcpy(prenomAdr, prenom);

  // on ouvre la base des adresses
  NSAdresses* pAdr = new NSAdresses(pContexte);

  pAdr->lastError = pAdr->open();
  if (pAdr->lastError != DBIERR_NONE)
  {
      erreur("Erreur � l'ouverture du fichier Adresses.db", standardError, pAdr->lastError, GetHandle()) ;
  delete pAdr;
  return;
  }

  if (existeAdresse)
  {
      // On fait le chercheClef et le getRecord pour lancer modifier
      pAdr->lastError = pAdr->chercheClef((unsigned char*)(pAdresseInfo->pDonnees->code),
                                          "",
                                          0,
                                          keySEARCHEQ,
                                          dbiWRITELOCK);
      if (pAdr->lastError != DBIERR_NONE)
      {
        erreur("Erreur � la recherche de l'adresse.", 0, pAdr->lastError, GetHandle());
          pAdr->close();
    delete pAdr;
    return;
      }

      pAdr->lastError = pAdr->getRecord();
      if (pAdr->lastError != DBIERR_NONE)
      {
        erreur("Erreur � lecture du fichier Adresses.db", 0, pAdr->lastError, GetHandle());
          pAdr->close();
    delete pAdr;
    return;
      }

      // Appel du dialogue de cr�ation/modification des patients
      modifOK = pAdr->Modifier(nomAdr, prenomAdr, tAdrCorresp, this);
  }
  else
      modifOK = pAdr->Creer(nomAdr, prenomAdr, tAdrCorresp, this);

  pAdr->lastError = pAdr->close();
  if (pAdr->lastError != DBIERR_NONE)
  {
      erreur("Erreur � la fermeture du fichier Adresses.db", 0, pAdr->lastError, GetHandle());
  delete pAdr;
  return;
  }

  if (modifOK)
  {
      *pAdresseInfo = NSAdressesInfo(pAdr);

      // on remplace le nouveau code adresse du correspondant
      strcpy(pData->adresse, pAdresseInfo->pDonnees->code);
  }

  if (strcmp(pAdresseInfo->pDonnees->code, ""))
      pAdresse->Check();
  // pas d'Uncheck car on ne peut pas pour l'instant supprimer une adresse

  delete pAdr;

#endif
}


void
CreerCorrespDialog::CmActif()
{
    if (pFonction->getCode() == "")
    {
        bActif = false;
        repercuteActif();
        return;
    }
    bActif = !bActif;
    repercuteActif();
}

void
CreerCorrespDialog::repercuteActif()
{
    if (bActif)
        pActif->Check();
    else
        pActif->Uncheck();
}
voidCreerCorrespDialog::CmOk()
{
	// int pos1,pos2;

	bool bNom = false ;

	char far nom[COR_NOM_LEN + 1];
  pNom->GetText(nom, COR_NOM_LEN + 1);
  string sNom = string(nom);
  strip(sNom);
  strcpy(pData->nom, sNom.c_str());
  if (strcmp(pData->nom, ""))
      bNom = true;

  char far prenom[COR_PRENOM_LEN + 1];
  pPrenom->GetText(prenom, COR_PRENOM_LEN + 1);
  string sPrenom = string(prenom);
  strip(sPrenom);
  strcpy(pData->prenom, sPrenom.c_str());

  if (pSexeM->GetCheck() == BF_CHECKED)
      pData->metMasculin();
  if (pSexeF->GetCheck() == BF_CHECKED)
      pData->metFeminin();

  if (pSansTitre->GetCheck() == BF_CHECKED)
      strcpy(pData->docteur, "");
  if (pTitre1->GetCheck() == BF_CHECKED)
      strcpy(pData->docteur, "O");
  if (pTitre2->GetCheck() == BF_CHECKED)
      strcpy(pData->docteur, "P");
  if (pTitre3->GetCheck() == BF_CHECKED)
      strcpy(pData->docteur, "1");
  if (pTitre4->GetCheck() == BF_CHECKED)
      strcpy(pData->docteur, "2");
  if (pTitre5->GetCheck() == BF_CHECKED)
      strcpy(pData->docteur, "R");
  if (pTitre6->GetCheck() == BF_CHECKED)
      strcpy(pData->docteur, "M");

  char far telepor[COR_TELEPOR_LEN + 1];
  pTelPor->GetText(telepor, COR_TELEPOR_LEN + 1);
  if (!pTelPor->pFilterValidator->IsValid(telepor))
  {
    erreur("Le champ [T�l�phone portable] contient des caract�res incorrects", standardError, 0, GetHandle());
      return;
  }
  strcpy(pData->telepor, telepor);

  char far telebur[COR_TELEBUR_LEN + 1];
  pTelBur->GetText(telebur, COR_TELEBUR_LEN + 1);
  if (!pTelBur->pFilterValidator->IsValid(telebur))
  {
    erreur("Le champ [T�l�phone bureau] contient des caract�res incorrects", standardError, 0, GetHandle()) ;
      return;
  }
  strcpy(pData->telebur, telebur);

  char far nb_exemp[COR_NB_EXEMP_LEN + 1];
  pNbExpl->GetText(nb_exemp, COR_NB_EXEMP_LEN + 1);
  strcpy(pData->nb_exemp, nb_exemp);

  char far messagerie[COR_MESSAGERIE_LEN + 1];
  pEMail->GetText(messagerie, COR_MESSAGERIE_LEN + 1);
  strcpy(pData->messagerie, messagerie);

  //char far fonction[COR_FONCTION_LEN + 1];
  //pFonction->GetText(fonction, COR_FONCTION_LEN + 1);
  //strcpy(pData->fonction, fonction);
  string code;
  code = pFonction->getCode();
  strcpy(pData->fonction, code.c_str());

  if (pActif->GetCheck() == BF_CHECKED)
      pData->metActif();
  else
      pData->metInactif();

  if (!bNom)
  erreur("Le champ Nom est obligatoire.", standardError, 0, GetHandle()) ;
	else
		TDialog::CmOk();
}


void
CreerCorrespDialog::CmCancel()
{
    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
    int retVal = MessageBox("Voulez-vous vraiment annuler la cr�ation/modification de ce correspondant ?", sCaption.c_str(), MB_YESNO);

    if (retVal == IDYES)
        TDialog::CmCancel();
}

void
CreerCorrespDialog::EvClose()
{
    CmCancel();
}
*/

// -----------------------------------------------------------------------------
//
// m�thodes de CodeUtilisateurDialog
//
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(CodeUtilisateurDialog, NSUtilDialog)
  EV_COMMAND(IDOK,      CmOk),
  EV_COMMAND(IDCANCEL,  CmCancel),
END_RESPONSE_TABLE ;


CodeUtilisateurDialog::CodeUtilisateurDialog(TWindow *pere, string sCode, NSContexte *pCtx)
                      :NSUtilDialog(pere, pCtx, "IDD_CODE_UTIL")
{
  sCodeUtil = sCode ;

  pCode 	  = new NSUtilEdit(pContexte, this, IDC_CODE_UTIL_CODE,    UTI_CODE_LEN) ;
  pConfirm  = new NSUtilEdit(pContexte, this, IDC_CODE_UTIL_CONFIRM, UTI_CODE_LEN) ;
}


CodeUtilisateurDialog::~CodeUtilisateurDialog()
{
  delete pCode ;
  delete pConfirm ;
}


void
CodeUtilisateurDialog::SetupWindow()
{
  TDialog::SetupWindow() ;

  pCode->SetText(sCodeUtil.c_str()) ;
  pConfirm->SetText(sCodeUtil.c_str()) ;
}


void
CodeUtilisateurDialog::CmOk()
{
  bool      bCode     = false ;
  bool      bConfirm  = false ;
  string    sCodeConfirm ;

	char far  code[UTI_CODE_LEN + 1] ;
  pCode->GetText(code, UTI_CODE_LEN + 1) ;

  // contr�le pr�alable : la longueur du code (mot de passe) doit �tre >= 8 caract�res
  if (strlen(code) < 8)
  {
    erreur("La longueur du mot de passe doit �tre sup�rieure ou �gale � 8 caract�res.", warningError, 0, GetHandle());
    pCode->SetText(sCodeUtil.c_str()) ;
    pConfirm->SetText(sCodeUtil.c_str()) ;
    return;
  }

  // Le code ne doit pas contenir d'espace
  string sCode = string(code);
  size_t pos = sCode.find(' ');
  if (pos != NPOS)
  {
    erreur("Votre mot de passe ne doit pas contenir d'espaces.", warningError, 0, GetHandle());
    pCode->SetText(sCodeUtil.c_str()) ;
    pConfirm->SetText(sCodeUtil.c_str()) ;
    return;
  }

  // chiffrage du mot de passe � l'aide de l'algo MD5
  string  sPass         = string(code) ;
  string  sPassEncrypt  = MD5_encrypt(sPass) ;

  sCodeUtil             = sPassEncrypt ;
  size_t  iCodeUtilLen  = strlen(sCodeUtil.c_str()) ;
  if ((iCodeUtilLen > 0) && (iCodeUtilLen <= UTI_CODE_LEN))
    bCode = true ;

  char far  confirm[UTI_CODE_LEN + 1] ;
  pConfirm->GetText(confirm, UTI_CODE_LEN + 1) ;

  // chiffrage du mot de passe confirm� � l'aide de l'algo MD5
  string  sPassConfirm          = string(confirm) ;
  string  sPassConfirmEncrypt   = MD5_encrypt(sPassConfirm) ;

  sCodeConfirm                  = sPassConfirmEncrypt ;
  size_t  iCodeUtilConfirmLen   = strlen(sCodeConfirm.c_str()) ;
  if ((iCodeUtilConfirmLen > 0) && (iCodeUtilConfirmLen <= UTI_CODE_LEN))
    bConfirm = true ;

  if (!bCode)
  {
    erreur("Vous n'avez pas saisi le mot de passe.", warningError, 0, GetHandle()) ;
    return ;
  }

  if (!bConfirm)
  {
    erreur("Vous n'avez pas confirm� le mot de passe.", warningError, 0, GetHandle()) ;
    return ;
  }

  if (sCodeUtil != sCodeConfirm)
  {
    erreur("Le code et la confirmation ne sont pas identiques.", warningError, 0, GetHandle()) ;
    return ;
  }

  TDialog::CmOk() ;
}


void
CodeUtilisateurDialog::CmCancel()
{
	sCodeUtil = "" ;

	TDialog::CmCancel() ;
}

// -----------------------------------------------------------------------------
//
// m�thodes de ModifCodeUtilisateurDialog
//
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(ModifCodeUtilisateurDialog, NSUtilDialog)
  EV_COMMAND(IDOK,      CmOk),
  EV_COMMAND(IDCANCEL,  CmCancel),
END_RESPONSE_TABLE ;


ModifCodeUtilisateurDialog::ModifCodeUtilisateurDialog(TWindow *pere, NSContexte *pCtx)
                           :NSUtilDialog(pere, pCtx, "IDD_OLDCODE_UTIL")
{
  sCodeUtil = "" ;

  pCode = new NSUtilEdit(pContexte, this, IDC_CODE_UTIL_CODE, UTI_CODE_LEN) ;
}


ModifCodeUtilisateurDialog::~ModifCodeUtilisateurDialog()
{
  delete pCode ;
}


void
ModifCodeUtilisateurDialog::SetupWindow()
{
  TDialog::SetupWindow() ;

  pCode->SetText(sCodeUtil.c_str()) ;
}


void
ModifCodeUtilisateurDialog::CmOk()
{
  bool      bCode     = false ;

  char far  code[UTI_CODE_LEN + 1] ;
  pCode->GetText(code, UTI_CODE_LEN + 1) ;

  // chiffrage du mot de passe � l'aide de l'algo MD5
  string  sPass         = string(code) ;
  string  sPassEncrypt  = MD5_encrypt(sPass) ;

  sCodeUtil             = sPassEncrypt ;
  size_t  iCodeUtilLen  = strlen(sCodeUtil.c_str()) ;
  if ((iCodeUtilLen > 0) && (iCodeUtilLen <= UTI_CODE_LEN))
    bCode = true ;

  if (!bCode)
  {
    erreur("Vous n'avez pas saisi le mot de passe.", warningError, 0, GetHandle()) ;
    return ;
  }

  TDialog::CmOk() ;
}


void
ModifCodeUtilisateurDialog::CmCancel()
{
	sCodeUtil = "" ;
	TDialog::CmCancel() ;
}

// -----------------------------------------------------------------------------
//
//  M�thodes de CreerUtilisateurDialog en mode N_TIERS
//
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(CreerUtilisateurDialog, NSUtilDialog)
  EV_WM_CLOSE,
  EV_COMMAND(IDOK,                      CmOk),
  EV_COMMAND(IDCANCEL,                  CmCancel),
  EV_BN_CLICKED(IDC_UTIL_TITRE1,        CmTitre),
  EV_BN_CLICKED(IDC_UTIL_TITRE2,        CmTitre),
  EV_BN_CLICKED(IDC_UTIL_TITRE3,        CmCivilProf),
  EV_BN_CLICKED(IDC_UTIL_TITRE4,        CmCivilProf),
  EV_BN_CLICKED(IDC_UTIL_TITRE5,        CmCivilProf),
  EV_BN_CLICKED(IDC_UTIL_TITRE6,        CmCivilProf),
  EV_BN_CLICKED(IDC_UTIL_TITRE7,        CmCivil),
  EV_BN_CLICKED(IDC_UTIL_TITRE8,        CmCivil),
  EV_BN_CLICKED(IDC_UTIL_TITRE9,        CmCivil),
  EV_BN_CLICKED(IDC_UTIL_PWD_MODIFY,    CmCode),
  EV_BN_CLICKED(IDC_UTIL_ROLE_USER,     CmRole),
  EV_BN_CLICKED(IDC_UTIL_ROLE_ADMIN,    CmRole),
  EV_BN_CLICKED(IDC_UTIL_PWD_TEMP,      CmAccount),
  EV_BN_CLICKED(IDC_UTIL_PWD_CHANGE,    CmAccount),
  EV_BN_CLICKED(IDC_UTIL_PWD_FIXE,      CmAccount),
  EV_BN_CLICKED(IDC_UTIL_PWD_NOCHANGE,  CmAccount),
  EV_BN_CLICKED(IDC_UTIL_PWD_CANCEL,    CmAccount),
  EV_BN_CLICKED(IDC_UTIL_PWD_LOCK,      CmAccount),
END_RESPONSE_TABLE ;

CreerUtilisateurDialog::CreerUtilisateurDialog(TWindow *pere, NSContexte *pCtx, TModule *module)
                       :NSUtilDialog(pere, pCtx, "IDD_CREAT_UTIL1_NTIERS", module)
{
  // fichiers d'aide
  sHindex                 = "" ;
  sHcorps                 = "Creation_Modification.html" ;

  // Initialisation des donnees
  pData 	                = new NSUtilisateurData ;
  sLogin                  = "" ;
  sPasswd                 = "" ;
  sUserType               = "" ;
  sPasswordType           = "" ;
  sDatePasswordCreation   = "" ;
  sValidityDuration       = "" ;

  // Cr�ation de tous les "objets de contr�le"
  pTitre                  = new TGroupBox(this, IDC_UTIL_TITRE) ;
  pCivilProf              = new TGroupBox(this, IDC_UTIL_CIVILPROF) ;
  pCivil                  = new TGroupBox(this, IDC_UTIL_CIVIL) ;
  iTitre                  = 0 ;
  sTitre                  = "" ;
  sCivilProf              = "" ;
  sCivil                  = "" ;

  pNom                    = new NSUtilEdit(pContexte, this, IDC_UTIL_NOM, UTI_NOM_LEN) ;
  pPrenom                 = new NSUtilEdit(pContexte, this, IDC_UTIL_PRENOM, UTI_PRENOM_LEN) ;

  pLogin                  = new NSUtilEdit(pContexte, this, IDC_UTIL_LOGIN, UTI_LOGIN_LEN) ;
  pMetier                 = new NSUtilLexique(pContexte, this, IDC_UTIL_METIER, pContexte->getDico()) ;
  pSpec                   = new NSUtilLexique(pContexte, this, IDC_UTIL_SPEC, pContexte->getDico()) ;
  pCode                   = new TButton(this, IDC_UTIL_PWD_MODIFY) ;

  pRole                   = new TGroupBox(this, IDC_UTIL_ROLE) ;
  pUserRole               = new TRadioButton(this, IDC_UTIL_ROLE_USER, pRole) ;
  pAdminRole              = new TRadioButton(this, IDC_UTIL_ROLE_ADMIN, pRole) ;

  pAccount                = new TGroupBox(this, IDC_UTIL_ACCOUNT) ;
  pPwdTemp                = new TRadioButton(this, IDC_UTIL_PWD_TEMP, pAccount) ;
  pPwdChange              = new TRadioButton(this, IDC_UTIL_PWD_CHANGE, pAccount) ;
  pPwdChangeUpDown        = new NSUtilUpDownEdit(this, pContexte, IDC_UTIL_PWD_DUREE, IDC_UTIL_PWD_UPDOWN) ;
  pPwdFix                 = new TRadioButton(this, IDC_UTIL_PWD_FIXE, pAccount) ;
  pPwdNoChange            = new TRadioButton(this, IDC_UTIL_PWD_NOCHANGE, pAccount) ;
  pPwdCancel              = new TRadioButton(this, IDC_UTIL_PWD_CANCEL, pAccount) ;
  pPwdLock                = new TRadioButton(this, IDC_UTIL_PWD_LOCK, pAccount) ;

  pTitre1                 = new TRadioButton(this, IDC_UTIL_TITRE1, pTitre) ;
  pTitre2                 = new TRadioButton(this, IDC_UTIL_TITRE2, pTitre) ;
  pTitre3                 = new TRadioButton(this, IDC_UTIL_TITRE3, pCivilProf) ;
  pTitre4                 = new TRadioButton(this, IDC_UTIL_TITRE4, pCivilProf) ;
  pTitre5                 = new TRadioButton(this, IDC_UTIL_TITRE5, pCivilProf) ;
  pTitre6                 = new TRadioButton(this, IDC_UTIL_TITRE6, pCivilProf) ;
  pTitre7                 = new TRadioButton(this, IDC_UTIL_TITRE7, pCivil) ;
  pTitre8                 = new TRadioButton(this, IDC_UTIL_TITRE8, pCivil) ;
  pTitre9                 = new TRadioButton(this, IDC_UTIL_TITRE9, pCivil) ;

  pSexe                   = new TGroupBox(this, IDC_UTIL_SEXE) ;
  pSexe1                  = new TRadioButton(this, IDC_UTIL_SEXE1, pSexe) ;
  pSexe2                  = new TRadioButton(this, IDC_UTIL_SEXE2, pSexe) ;

  pEMail                  = new NSUtilEdit(pContexte, this, IDC_UTIL_EMAIL, UTI_MESSAGERIE_LEN) ;

  pLangues                = new NSComboBoxClassif(this, IDC_UTIL_COMBO_LANG, pContexte, "66391")  ;
}

CreerUtilisateurDialog::~CreerUtilisateurDialog()
{
  delete pEMail ;
  delete pLogin ;
  delete pMetier ;  delete pSpec ;  delete pSexe1;  delete pSexe2;  delete pSexe;  delete pTitre9;  delete pTitre8;  delete pTitre7;  delete pTitre6 ;  delete pTitre5 ;
  delete pTitre4 ;
  delete pTitre3 ;
  delete pTitre2 ;
  delete pTitre1 ;
  delete pPwdTemp ;
  delete pPwdChange ;
  delete pPwdChangeUpDown ;
  delete pPwdFix ;
  delete pPwdNoChange ;
  delete pPwdCancel ;
  delete pPwdLock ;
  delete pAccount ;
  delete pUserRole ;
  delete pAdminRole ;
  delete pRole ;
  delete pCode ;
  delete pPrenom ;
  delete pNom ;
  delete pTitre ;
  delete pCivilProf ;
  delete pCivil ;
  delete pData ;
  delete pLangues ;
}


void
CreerUtilisateurDialog::SetupWindow()
{
  TDialog::SetupWindow() ;

  pNom->SetText(pData->_sNom.c_str()) ;
  pPrenom->SetText(pData->_sPrenom.c_str()) ;

  if (sPasswd != "")
  	pCode->SetCaption("Changer mot de passe") ;
  else
  	pCode->SetCaption("Cr�er mot de passe") ;

  // titre : voir la fonction StringTitre de nsperson.cpp
  /******************************************************
  switch (pData->type[0])
  {
    case 'O'  : pTitre1->Check() ; iTitre = 1 ; break ;
    case 'P'  : pTitre2->Check() ; iTitre = 2 ; break ;
    case '1'  : pTitre3->Check() ; iTitre = 3 ; break ;
    case '2'  : pTitre4->Check() ; iTitre = 4 ; break ;
    case 'R'  : pTitre5->Check() ; iTitre = 5 ; break ;
    case 'M'  : pTitre6->Check() ; iTitre = 6 ; break ;
    case 'A'  : pTitre7->Check() ; iTitre = 7 ; break ;
    case 'B'  : pTitre8->Check() ; iTitre = 8 ; break ;
    case 'C'  : pTitre9->Check() ; iTitre = 9 ; break;
  }
  ********************************************************/

  if (string("") != sTitre)
  {
    if      (string("HDOCT1") == sTitre)
    	pTitre1->Check() ;
    else if (string("HPROF1") == sTitre)
    	pTitre2->Check() ;
  }

  if (string("") != sCivilProf)
  {
    if      (string("HMOND1") == sCivilProf)
    	pTitre3->Check() ;
    else if (string("HMADD1") == sCivilProf)
    	pTitre4->Check() ;
    else if (string("HMONF1") == sCivilProf)
    	pTitre5->Check() ;
    else if (string("HMADP1") == sCivilProf)
    	pTitre6->Check() ;
  }

  if (string("") != sCivil)
  {
    if      (string("HMONP1") == sCivil)
    	pTitre7->Check() ;
    else if (string("HMADR1") == sCivil)
    	pTitre8->Check() ;
    else if (string("HMADE1") == sCivil)
    	pTitre9->Check() ;
  }

  // le champ login existe que dans la version MUE
  pLogin->SetText(sLogin.c_str()) ;
  if (strlen((pData->_sMetier).c_str()) > 0)
  	pMetier->setLabel((pData->_sMetier).c_str()) ;
  if (strlen((pData->_sSpecialite).c_str()) > 0)
  	pSpec->setLabel((pData->_sSpecialite).c_str()) ;

	if (string("") != pData->_sSexe)
  {
    if      (pData->estMasculin())
    	pSexe1->Check() ;
    else if (pData->estFeminin())
    	pSexe2->Check() ;
  }

  pEMail->SetText(pData->_sMessagerie.c_str()) ;

  // langue
  pLangues->setCode(pData->_sLang) ;

  initRole() ;
  initAccount() ;
}


void
CreerUtilisateurDialog::CmTitre()
{
  // docteur
  if (pTitre1->GetCheck() == BF_CHECKED)
  {
    if (sTitre == "HDOCT1")
    {
      pTitre1->Uncheck() ;
      sTitre = "" ;
    }
    else
      sTitre = "HDOCT1" ;
  }

  // professeur
  if (pTitre2->GetCheck() == BF_CHECKED)
  {
    if (sTitre == "HPROF1")
    {
      pTitre2->Uncheck() ;
      sTitre = "" ;
    }
    else
      sTitre = "HPROF1" ;
  }
}

void
CreerUtilisateurDialog::CmCivilProf()
{
    // M. le Docteur
    if (pTitre3->GetCheck() == BF_CHECKED)
  {
    if (sCivilProf == "HMOND1")
    {
      pTitre3->Uncheck() ;
      sCivilProf = "" ;
    }
    else
      sCivilProf = "HMOND1" ;
  }

  // Mme le Docteur
  if (pTitre4->GetCheck() == BF_CHECKED)
  {
    if (sCivilProf == "HMADD1")
    {
      pTitre4->Uncheck() ;
      sCivilProf = "" ;
    }
    else
      sCivilProf = "HMADD1" ;
  }

  // M. le Professeur
  if (pTitre5->GetCheck() == BF_CHECKED)
  {
    if (sCivilProf == "HMONF1")
    {
      pTitre5->Uncheck() ;
      sCivilProf = "" ;
    }
    else
     sCivilProf = "HMONF1" ;
  }

  // Mme le professeur
  if (pTitre6->GetCheck() == BF_CHECKED)
  {
    if (sCivilProf == "HMADP1")
    {
      pTitre6->Uncheck() ;
      sCivilProf = "" ;
    }
    else
      sCivilProf = "HMADP1" ;
  }
}

void
CreerUtilisateurDialog::CmCivil()
{
    // Monsieur
    if (pTitre7->GetCheck() == BF_CHECKED)
  {
    if (sCivil == "HMONP1")
    {
      pTitre7->Uncheck() ;
      sCivil = "" ;
    }
    else
      sCivil = "HMONP1" ;
  }

  // Madame
  if (pTitre8->GetCheck() == BF_CHECKED)
  {
    if (sCivil == "HMADR1")
    {
      pTitre8->Uncheck() ;
      sCivil = "" ;
    }
    else
      sCivil = "HMADR1" ;
  }

  // Mademoiselle
  if (pTitre9->GetCheck() == BF_CHECKED)
  {
    if (sCivil == "HMADE1")
    {
      pTitre9->Uncheck() ;
      sCivil = "" ;
    }
    else
      sCivil = "HMADE1" ;
  }
}

void
CreerUtilisateurDialog::CmRole()
{
  if (pUserRole->GetCheck() == BF_CHECKED)
  {
    if (sUserType.find("U") != string::npos)
    {
      pUserRole->Uncheck() ;
      enleveDroit(sUserType, 'U') ;
    }
    else
      ajouteDroit(sUserType, 'U') ;
  }

  if (pAdminRole->GetCheck() == BF_CHECKED)
  {
    if (sUserType.find("A") != string::npos)
    {
      pAdminRole->Uncheck() ;
      enleveDroit(sUserType, 'A') ;
    }
    else
      ajouteDroit(sUserType, 'A') ;
  }

  initRole() ;
}


void
CreerUtilisateurDialog::CmAccount()
{
  if (pPwdTemp->GetCheck() == BF_CHECKED)
  {
    if (sPasswordType.find("T") != string::npos)
    {
      pPwdTemp->Uncheck() ;
      enleveDroit(sPasswordType, 'T') ;
    }
    else
    {
      if (sPasswordType.find("G") != string::npos)
      {
        pPwdNoChange->Uncheck() ;
        enleveDroit(sPasswordType, 'G') ;
      }
      ajouteDroit(sPasswordType, 'T') ;
    }
  }

  if (pPwdChange->GetCheck() == BF_CHECKED)
  {
    if (sPasswordType.find("J") != string::npos)
    {
      pPwdChange->Uncheck() ;
      enleveDroit(sPasswordType, 'J') ;
    }
    else
    {
      if (sPasswordType.find("F") != string::npos)
      {
        pPwdFix->Uncheck() ;
        enleveDroit(sPasswordType, 'F') ;
      }
      ajouteDroit(sPasswordType, 'J') ;
    }
  }

  if (pPwdFix->GetCheck() == BF_CHECKED)
  {
    if (sPasswordType.find("F") != string::npos)
    {
      pPwdFix->Uncheck() ;
      enleveDroit(sPasswordType, 'F') ;
    }
    else
    {
      if (sPasswordType.find("J") != string::npos)
      {
        pPwdChange->Uncheck() ;
        enleveDroit(sPasswordType, 'J') ;
      }
      ajouteDroit(sPasswordType, 'F') ;
    }
  }

  if (pPwdNoChange->GetCheck() == BF_CHECKED)
  {
    if (sPasswordType.find("G") != string::npos)
    {
      pPwdNoChange->Uncheck() ;
      enleveDroit(sPasswordType, 'G') ;
    }
    else
    {
      if (sPasswordType.find("T") != string::npos)
      {
        pPwdTemp->Uncheck() ;
        enleveDroit(sPasswordType, 'T') ;
      }
      ajouteDroit(sPasswordType, 'G') ;
    }
  }

  if (pPwdCancel->GetCheck() == BF_CHECKED)
  {
    if (sPasswordType.find("D") != string::npos)
    {
      pPwdCancel->Uncheck() ;
      enleveDroit(sPasswordType, 'D') ;
    }
    else
    {
      if (sPasswordType.find("V") != string::npos)
      {
        pPwdLock->Uncheck() ;
        enleveDroit(sPasswordType, 'V') ;
      }
      ajouteDroit(sPasswordType, 'D') ;
    }
  }

  if (pPwdLock->GetCheck() == BF_CHECKED)
  {
    if (sPasswordType.find("V") != string::npos)
    {
      pPwdLock->Uncheck() ;
      enleveDroit(sPasswordType, 'V') ;
    }
    else
    {
      if (sPasswordType.find("D") != string::npos)
      {
        pPwdCancel->Uncheck() ;
        enleveDroit(sPasswordType, 'D') ;
      }
      ajouteDroit(sPasswordType, 'V') ;
    }
  }

  initAccount() ;
}


void
CreerUtilisateurDialog::CmCode()
{
  char   szDateJour[10] ;
  donne_date_duJour(szDateJour) ;

  // modification d'un code utilisateur
  // on ne contr�le pas l'ancien mot de passe pour l'administrateur
  // Saisie du nouveau mot de passe
  CodeUtilisateurDialog *pCodeDlg = new CodeUtilisateurDialog(this, "", pContexte) ;

  if (pCodeDlg->Execute() == IDCANCEL)
  {
    delete pCodeDlg ;
    return ;
  }

  sPasswd = pCodeDlg->sCodeUtil ;
  sDatePasswordCreation = string(szDateJour) ;
  delete pCodeDlg ;

  if (sPasswd != "")
    pCode->SetCaption("Changer mot de passe") ;
  else
    pCode->SetCaption("Cr�er mot de passe") ;

  return ;
}


void
CreerUtilisateurDialog::CmOk()
{
  bool bNom   = false ;
  bool bCode  = false ;
  bool bLogin = false ;

  char far nom[UTI_NOM_LEN + 1] ;
  pNom->GetText(nom, UTI_NOM_LEN + 1) ;
  string sNom = string(nom) ;
  strip(sNom) ;
  pData->_sNom = sNom ;
  if (string("") != pData->_sNom)
    bNom = true ;

  char far prenom[COR_PRENOM_LEN + 1] ;
  pPrenom->GetText(prenom, COR_PRENOM_LEN + 1) ;
  string sPrenom = string(prenom) ;
  strip(sPrenom) ;
  pData->_sPrenom = sPrenom ;

  if (sPasswd != "")
    bCode = true ;

  if (pTitre1->GetCheck() == BF_CHECKED)
  	pData->_sType = string("HDOCT1") ;
  if (pTitre2->GetCheck() == BF_CHECKED)
    pData->_sType = string("HPROF1") ;
  if (pTitre3->GetCheck() == BF_CHECKED)
    pData->_sType = string("HMOND1") ;
  if (pTitre4->GetCheck() == BF_CHECKED)
    pData->_sType = string("HMADD1") ;
  if (pTitre5->GetCheck() == BF_CHECKED)
    pData->_sType = string("HMONF1") ;
  if (pTitre6->GetCheck() == BF_CHECKED)
    pData->_sType = string("HMADP1") ;
  if (pTitre7->GetCheck() == BF_CHECKED)
    pData->_sType = string("HMONP1") ;
  if (pTitre8->GetCheck() == BF_CHECKED)
    pData->_sType = string("HMADR1") ;
  if (pTitre9->GetCheck() == BF_CHECKED)
    pData->_sType = string("HMADE1") ;

  // sexe
  if      (pSexe1->GetCheck() == BF_CHECKED)
  	pData->metMasculin() ;
  else if (pSexe2->GetCheck() == BF_CHECKED)
    pData->metFeminin() ;

  char far messagerie[UTI_MESSAGERIE_LEN + 1] ;
  pEMail->GetText(messagerie, UTI_MESSAGERIE_LEN + 1) ;
  pData->_sMessagerie = messagerie ;

  if (sPasswordType.find("J") != NPOS)
  {
    char szDuration[80];

    int iDuration = pPwdChangeUpDown->getValue();
    itoa(iDuration, szDuration, 10);
    sValidityDuration = string(szDuration);
  }
  else
    sValidityDuration = "";

  // on met en dur la langue par d�faut � fr
  // � changer "in the future"
  string sLangCode = pLangues->getSelCode() ;
  if (sLangCode == string(""))
  	pData->_sLang = string("fr") ;
  else
  	pData->_sLang = sLangCode ;

  char far login[UTI_LOGIN_LEN + 1] ;
  pLogin->GetText(login, UTI_LOGIN_LEN + 1) ;
  sLogin = string(login) ;
  if (sLogin != "")
    bLogin = true ;

  pData->_sMetier = pMetier->getCode() ;
  pData->_sSpecialite = pSpec->getCode() ;

  if (!bNom)
  {
    erreur("Le champ Nom est obligatoire.", warningError, 0, GetHandle()) ;
    return ;
  }

  if (!bCode)
  {
    erreur("Le mot de passe est obligatoire.", warningError, 0, GetHandle()) ;
    return ;  }

  // en version MUE le login est obligatoire
  if (!bLogin)
  {
    erreur("Le champ Identifiant utilisateur est obligatoire.", warningError, 0, GetHandle()) ;
    return ;
  }

  TDialog::CmOk() ;
}

void
CreerUtilisateurDialog::CmCancel()
{
  string  sCaption  = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
  int     retVal    = MessageBox("Voulez-vous vraiment annuler la cr�ation/modification de cet utilisateur ?", sCaption.c_str(), MB_YESNO) ;

  if (retVal == IDYES)
    TDialog::CmCancel() ;
}

void
CreerUtilisateurDialog::EvClose()
{
  CmCancel() ;
}

void
CreerUtilisateurDialog::ajouteDroit(string& sTypeDroit, char droit)
{
	sTypeDroit += droit ;
}

void
CreerUtilisateurDialog::enleveDroit(string& sTypeDroit, char droit)
{
  size_t pos = sTypeDroit.find(droit) ;
  string debut = "", fin = "" ;

  if (pos != string::npos)
  {
    debut = string(sTypeDroit, 0, pos) ;
    if (pos < (strlen(sTypeDroit.c_str()) - 1))
    	fin = string(sTypeDroit, pos + 1, strlen(sTypeDroit.c_str()) - pos - 1) ;
    sTypeDroit = debut + fin ;
  }
}

void
CreerUtilisateurDialog::initRole()
{
	bool	bUserTypeDefine	= false ;

	if (sUserType.find("U") != string::npos)
  {
  	pUserRole->Check() ;
    bUserTypeDefine = true ;
  }
  if (sUserType.find("A") != string::npos)
  {
  	pAdminRole->Check() ;
    bUserTypeDefine = true ;
  }

  // traitement par d�faut
  if (!bUserTypeDefine)
  {
  	pUserRole->Check() ;
    ajouteDroit(sUserType, 'U');
  }
}

void
CreerUtilisateurDialog::initAccount()
{
  // Compte et mot de passe :
  // PASSWORD_MUST_CHANGE     T
  // PASSWORD_VALID_DURING    J
  // PASSWORD_FIXE            F
  // USER_PRIVILEGE           G
  // LOCKED_USER              V
  // DESEABLED_USER           D

  if (sPasswordType.find("T") != string::npos)
    pPwdTemp->Check() ;

  if (sPasswordType.find("J") != string::npos)
  {
    pPwdChange->Check() ;
    pPwdChangeUpDown->setValue(atoi(sValidityDuration.c_str())) ;
  }

  if (sPasswordType.find("F") != string::npos)
    pPwdFix->Check() ;

  if (sPasswordType.find("G") != string::npos)
    pPwdNoChange->Check() ;

  if (sPasswordType.find("D") != string::npos)
    pPwdCancel->Check() ;

  if (sPasswordType.find("V") != string::npos)
    pPwdLock->Check() ;
}

/*
// -----------------------------------------------------------------------------
//
//  M�thodes de CreerUtilSimpleDialog en mode N_TIERS (pour l'utilisateur)
//
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(CreerUtilSimpleDialog, NSUtilDialog)
  EV_WM_CLOSE,
  EV_COMMAND(IDOK,                      CmOk),
  EV_COMMAND(IDCANCEL,                  CmCancel),
  EV_BN_CLICKED(IDC_UTIL_TITRE1,        CmTitre),
  EV_BN_CLICKED(IDC_UTIL_TITRE2,        CmTitre),
  EV_BN_CLICKED(IDC_UTIL_TITRE3,        CmCivilProf),
  EV_BN_CLICKED(IDC_UTIL_TITRE4,        CmCivilProf),
  EV_BN_CLICKED(IDC_UTIL_TITRE5,        CmCivilProf),
  EV_BN_CLICKED(IDC_UTIL_TITRE6,        CmCivilProf),
  EV_BN_CLICKED(IDC_UTIL_TITRE7,        CmCivil),
  EV_BN_CLICKED(IDC_UTIL_TITRE8,        CmCivil),
  EV_BN_CLICKED(IDC_UTIL_TITRE9,        CmCivil),
  EV_BN_CLICKED(IDC_UTIL_PWD_MODIFY,    CmCode),
END_RESPONSE_TABLE ;


CreerUtilSimpleDialog::CreerUtilSimpleDialog(TWindow *pere, NSContexte *pCtx, TModule *module)
  : NSUtilDialog(pere, pCtx, "IDD_CREAT_UTIL2_NTIERS", module)
{
    // fichiers d'aide
    sHindex     = "" ;
    sHcorps     = "Creation_Modification.html" ;

    // Initialisation des donnees
    pData 	    = new NSUtilisateurData ;
    sLogin                  = "";
    sPasswd                 = "";
    sRole                   = "";
    sPasswordType           = "";
    sDatePasswordCreation   = "";
    sValidityDuration       = "";

    // Cr�ation de tous les "objets de contr�le"
    pTitre		= new TGroupBox(this,       IDC_UTIL_TITRE) ;
    pCivilProf  = new TGroupBox(this,       IDC_UTIL_CIVILPROF) ;
    pCivil      = new TGroupBox(this,       IDC_UTIL_CIVIL) ;
    iTitre      = 0 ;

	pNom 	    = new NSUtilEdit(this,      IDC_UTIL_NOM,     UTI_NOM_LEN) ;
	pPrenom    	= new NSUtilEdit(this,      IDC_UTIL_PRENOM,  UTI_PRENOM_LEN) ;

    pMetier     = new NSUtilLexique(this,   IDC_UTIL_METIER,  pContexte->getDico()) ;
    pSpec       = new NSUtilLexique(this,   IDC_UTIL_SPEC,    pContexte->getDico()) ;
    pCode		= new TButton(this,         IDC_UTIL_PWD_MODIFY) ;

    pTitre1		= new TRadioButton(this,    IDC_UTIL_TITRE1,  pTitre) ;
    pTitre2		= new TRadioButton(this,    IDC_UTIL_TITRE2,  pTitre) ;
    pTitre3		= new TRadioButton(this,    IDC_UTIL_TITRE3,  pCivilProf) ;
    pTitre4		= new TRadioButton(this,    IDC_UTIL_TITRE4,  pCivilProf) ;
    pTitre5		= new TRadioButton(this,    IDC_UTIL_TITRE5,  pCivilProf) ;
    pTitre6		= new TRadioButton(this,    IDC_UTIL_TITRE6,  pCivilProf) ;
    pTitre7		= new TRadioButton(this,    IDC_UTIL_TITRE7,  pCivil) ;
    pTitre8		= new TRadioButton(this,    IDC_UTIL_TITRE8,  pCivil) ;
    pTitre9		= new TRadioButton(this,    IDC_UTIL_TITRE9,  pCivil) ;

    pSexe		= new TGroupBox(this,       IDC_UTIL_SEXE) ;
    pSexe1		= new TRadioButton(this,    IDC_UTIL_SEXE1,  pSexe) ;
    pSexe2		= new TRadioButton(this,    IDC_UTIL_SEXE2,  pSexe) ;

    pEMail		= new NSUtilEdit(this,      IDC_UTIL_EMAIL,   UTI_MESSAGERIE_LEN) ;
}


CreerUtilSimpleDialog::~CreerUtilSimpleDialog()
{
  delete pEMail ;
  delete pMetier ;
  delete pSpec ;  delete pSexe1;  delete pSexe2;  delete pSexe;  delete pTitre9;  delete pTitre8;  delete pTitre7;  delete pTitre6 ;  delete pTitre5 ;
  delete pTitre4 ;
  delete pTitre3 ;
  delete pTitre2 ;
  delete pTitre1 ;
  delete pCode ;
  delete pPrenom ;
  delete pNom ;
  delete pTitre ;
  delete pCivilProf ;
  delete pCivil ;
  delete pData ;
}

void
CreerUtilSimpleDialog::SetupWindow()
{
    TDialog::SetupWindow() ;

    pNom->SetText(pData->nom) ;
    pPrenom->SetText(pData->prenom) ;

    if (sPasswd != "")
    {
        if (sPasswordType.find("P") != NPOS)
        {
            uint32 uiStyle = pCode->TWindow::GetStyle() ;
            pCode->TWindow::SetStyle(uiStyle | WS_DISABLED) ;
        }
        else
            pCode->SetCaption("Changer mot de passe") ;
    }
    else
    {
        uint32 uiStyle = pCode->TWindow::GetStyle() ;
        pCode->TWindow::SetStyle(uiStyle | WS_DISABLED) ;
        erreur("Aucun mot de passe n'est d�fini pour cet utilisateur. Contactez votre administrateur.", standardError, 0) ;
    }

*/

    /*******************************************************
    // titre : voir la fonction StringTitre de nsperson.cpp
    switch (pData->type[0])
    {
        case 'O'  : pTitre1->Check() ;
                    iTitre = 1 ;
                    break ;
        case 'P'  : pTitre2->Check() ;
                    iTitre = 2 ;
      	            break ;
        case '1'  : pTitre3->Check() ;
                    iTitre = 3 ;
                    break ;
        case '2'  : pTitre4->Check() ;
                    iTitre = 4 ;
                    break ;
        case 'R'  : pTitre5->Check() ;
                    iTitre = 5 ;
                    break ;
        case 'M'  : pTitre6->Check() ;
                    iTitre = 6 ;
                    break ;
        case 'A'  : pTitre7->Check() ;
                    iTitre = 7 ;
                    break ;
        case 'B'  : pTitre8->Check() ;
                    iTitre = 8 ;
                    break ;
        case 'C'  : pTitre9->Check() ;
                    iTitre = 9 ;
                    break;
    }
    ******************************************************/

/*
    if (sTitre != "")
    {
      if (sTitre == "HDOCT1")
          pTitre1->Check();
      else if (sTitre == "HPROF1")
          pTitre2->Check();
    }

    if (sCivilProf != "")
    {
      if (sCivilProf == "HMOND1")
          pTitre3->Check();
      else if (sCivilProf == "HMADD1")
          pTitre4->Check();
      else if (sCivilProf == "HMONF1")
          pTitre5->Check();
      else if (sCivilProf == "HMADP1")
          pTitre6->Check();
    }

    if (sCivil != "")
    {
      if (sCivil == "HMONP1")
          pTitre7->Check();
      else if (sCivil == "HMADR1")
          pTitre8->Check();
      else if (sCivil == "HMADE1")
          pTitre9->Check();
    }

    if (strlen((pData->sMetier).c_str()) > 0)
        pMetier->setLabel((pData->sMetier).c_str());
    if (strlen((pData->sSpecialite).c_str()) > 0)
        pSpec->setLabel((pData->sSpecialite).c_str());

    // sexe (M/F)
    switch (pData->sexe[0])
    {
        case '1' :  pSexe1->Check();
                    break;

        case '2' :  pSexe2->Check();
                    break;
    }

    pEMail->SetText(pData->messagerie) ;
}

void
CreerUtilSimpleDialog::CmTitre()
{
  // docteur
  if (pTitre1->GetCheck() == BF_CHECKED)
  {
    if (sTitre == "HDOCT1")
    {
      pTitre1->Uncheck() ;
      sTitre = "" ;
    }
    else
      sTitre = "HDOCT1" ;
  }

  // professeur
  if (pTitre2->GetCheck() == BF_CHECKED)
  {
    if (sTitre == "HPROF1")
    {
      pTitre2->Uncheck() ;
      sTitre = "" ;
    }
    else
      sTitre = "HPROF1" ;
  }
}

void
CreerUtilSimpleDialog::CmCivilProf()
{
    // M. le Docteur
    if (pTitre3->GetCheck() == BF_CHECKED)
  {
    if (sCivilProf == "HMOND1")
    {
      pTitre3->Uncheck() ;
      sCivilProf = "" ;
    }
    else
      sCivilProf = "HMOND1" ;
  }

  // Mme le Docteur
  if (pTitre4->GetCheck() == BF_CHECKED)
  {
    if (sCivilProf == "HMADD1")
    {
      pTitre4->Uncheck() ;
      sCivilProf = "" ;
    }
    else
      sCivilProf = "HMADD1" ;
  }

  // M. le Professeur
  if (pTitre5->GetCheck() == BF_CHECKED)
  {
    if (sCivilProf == "HMONF1")
    {
      pTitre5->Uncheck() ;
      sCivilProf = "" ;
    }
    else
     sCivilProf = "HMONF1" ;
  }

  // Mme le professeur
  if (pTitre6->GetCheck() == BF_CHECKED)
  {
    if (sCivilProf == "HMADP1")
    {
      pTitre6->Uncheck() ;
      sCivilProf = "" ;
    }
    else
      sCivilProf = "HMADP1" ;
  }
}

void
CreerUtilSimpleDialog::CmCivil()
{
    // Monsieur
    if (pTitre7->GetCheck() == BF_CHECKED)
  {
    if (sCivil == "HMONP1")
    {
      pTitre7->Uncheck() ;
      sCivil = "" ;
    }
    else
      sCivil = "HMONP1" ;
  }

  // Madame
  if (pTitre8->GetCheck() == BF_CHECKED)
  {
    if (sCivil == "HMADR1")
    {
      pTitre8->Uncheck() ;
      sCivil = "" ;
    }
    else
      sCivil = "HMADR1" ;
  }

  // Mademoiselle
  if (pTitre9->GetCheck() == BF_CHECKED)
  {
    if (sCivil == "HMADE1")
    {
      pTitre9->Uncheck() ;
      sCivil = "" ;
    }
    else
      sCivil = "HMADE1" ;
  }
}

void
CreerUtilSimpleDialog::CmCode()
{
    char   szDateJour[10];
    donne_date_duJour(szDateJour);

    // cas l'utilisateur n'a pas le droit de modifier le mot de passe
    if (sPasswordType.find("P") != NPOS)
        return;

    if (sPasswd != "")
    {
        // modification d'un code utilisateur
        // 1. contr�le de l'ancien mot de passe
        string sCodeUtil = sPasswd;

        ModifCodeUtilisateurDialog *pOldCodeDlg = new ModifCodeUtilisateurDialog(this, pContexte) ;

        if (pOldCodeDlg->Execute() == IDCANCEL)
        {
            delete pOldCodeDlg ;
            return ;
        }

        if (sCodeUtil != pOldCodeDlg->sCodeUtil)
        {
            erreur("Le mot de passe saisi ne correspond pas � l'ancien mot de passe.", standardError, 0) ;
            delete pOldCodeDlg ;
            return;
        }

        // 2. Saisie du nouveau mot de passe
        CodeUtilisateurDialog *pCodeDlg = new CodeUtilisateurDialog(this, "", pContexte) ;

        if (pCodeDlg->Execute() == IDCANCEL)
        {
            delete pCodeDlg ;
            return ;
        }

        sPasswd = pCodeDlg->sCodeUtil ;
        sDatePasswordCreation = string(szDateJour);
        delete pOldCodeDlg;
        delete pCodeDlg ;
    }
    else
    {
        erreur("Aucun mot de passe n'est d�fini pour cet utilisateur. Contactez votre administrateur.", standardError, 0) ;
        return;
    }

    if (sPasswd != "")
        pCode->SetCaption("Changer mot de passe") ;

    return ;
}

void
CreerUtilSimpleDialog::CmOk()
{
  bool bNom   = false ;
  bool bCode  = false ;

  char far nom[UTI_NOM_LEN + 1] ;
  pNom->GetText(nom, UTI_NOM_LEN + 1) ;
  string sNom = string(nom) ;
  strip(sNom) ;
  strcpy(pData->nom, sNom.c_str()) ;
  if (strcmp(pData->nom, ""))
    bNom = true ;

  char far prenom[COR_PRENOM_LEN + 1] ;
  pPrenom->GetText(prenom, COR_PRENOM_LEN + 1) ;
  string sPrenom = string(prenom) ;
  strip(sPrenom) ;
  strcpy(pData->prenom, sPrenom.c_str()) ;

  if (sPasswd != "")
    bCode = true ;

  if (pTitre1->GetCheck() == BF_CHECKED)
    strcpy(pData->type, "O") ;
  if (pTitre2->GetCheck() == BF_CHECKED)
    strcpy(pData->type, "P") ;
  if (pTitre3->GetCheck() == BF_CHECKED)
    strcpy(pData->type, "1") ;
  if (pTitre4->GetCheck() == BF_CHECKED)
    strcpy(pData->type, "2") ;
  if (pTitre5->GetCheck() == BF_CHECKED)
    strcpy(pData->type, "R") ;
  if (pTitre6->GetCheck() == BF_CHECKED)
    strcpy(pData->type, "M") ;
  if (pTitre7->GetCheck() == BF_CHECKED)
    strcpy(pData->type, "A") ;
  if (pTitre8->GetCheck() == BF_CHECKED)
    strcpy(pData->type, "B") ;
  if (pTitre9->GetCheck() == BF_CHECKED)
    strcpy(pData->type, "C") ;

  // sexe
  if (pSexe1->GetCheck() == BF_CHECKED)
    strcpy(pData->sexe, "1");
  else if (pSexe2->GetCheck() == BF_CHECKED)
    strcpy(pData->sexe, "2");

  char far messagerie[UTI_MESSAGERIE_LEN + 1] ;
  pEMail->GetText(messagerie, UTI_MESSAGERIE_LEN + 1) ;
  strcpy(pData->messagerie, messagerie) ;

  // on met en dur la langue � fr
  // � changer "in the future"
  strcpy(pData->lang, "fr") ;

  pData->sMetier = pMetier->getCode() ;
  pData->sSpecialite = pSpec->getCode() ;

  if (!bNom)
  {
    erreur("Le champ Nom est obligatoire.", warningError, 0, GetHandle()) ;
    return ;
  }

  if (!bCode)
  {
    erreur("Le mot de passe est obligatoire.", warningError, 0, GetHandle()) ;
    return ;  }

  TDialog::CmOk() ;
}


void
CreerUtilSimpleDialog::CmCancel()
{
  string  sCaption  = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
  int     retVal    = MessageBox("Voulez-vous vraiment annuler la cr�ation/modification de cet utilisateur ?", sCaption.c_str(), MB_YESNO) ;

  if (retVal == IDYES)
    TDialog::CmCancel() ;
}


void
CreerUtilSimpleDialog::EvClose()
{
  CmCancel() ;
}

*/

// -----------------------------------------------------------------------------
//
//  M�thodes de NSPersonImportDialog en mode N_TIERS
//
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSUserImportDialog, NSUtilDialog)
  EV_COMMAND(IDOK,                      CmOk),
  EV_COMMAND(IDCANCEL,                  CmCancel),
  EV_EN_CHANGE(IDC_IMPORTUSER_PWDUSER,   PasswordChange),
END_RESPONSE_TABLE ;

NSUserImportDialog::NSUserImportDialog(TWindow * pere, NSContexte *pCtx, TModule *module)
                   :NSUtilDialog(pere, pCtx, "IDD_IMPORTUSERLDV", module)
{
	pLogin  = new NSUtilEdit(pContexte, this, IDC_IMPORTUSER_IDENTUSER, 80) ;
	pPasswd = new NSUtilEdit(pContexte, this, IDC_IMPORTUSER_PWDUSER, 80) ;
	// pNumLdv = new NSUtilEdit(this, IDC_IMPORTLDV_ADELI, 80);
	// pAdeli  = new NSUtilEdit(this, IDC_IMPORTLDV_NUMLDV, 80);

	// pRole    = new TGroupBox(this, IDC_IMPORTLDV_ROLE) ;
	// pRoleUti = new TRadioButton(this, IDC_IMPORTLDV_USER, pRole) ;
	// pRoleCor = new TRadioButton(this, IDC_IMPORTLDV_CORRESP, pRole) ;
}

NSUserImportDialog::~NSUserImportDialog()
{
	delete pLogin ;
	delete pPasswd ;
	// delete pAdeli ;
	// delete pNumLdv ;
	// delete pRoleUti ;
	// delete pRoleCor ;
	// delete pRole ;
}

void
NSUserImportDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	if (pContexte->getUtilisateur()->haveGlobalSessionPassword())
	{
		pLogin->Insert(pContexte->getUtilisateur()->getGlobalLoginSession().c_str()) ;
		pPasswd->Insert(pContexte->getUtilisateur()->getGlobalPasswordSession().c_str()) ;
		isHached = true ;
	}
	else
		isHached = false ;
}

void
NSUserImportDialog::PasswordChange()
{
	isHached = false;
}

void
NSUserImportDialog::CmOk()
{
	char far login[80];
	char far passwd[80];
    // char far adeli[80];
    // char far numldv[80];

	pLogin->GetText(login, 80);
	sLogin = string(login);

	pPasswd->GetText(passwd, 80);
	sPasswd = string(passwd);
	if (isHached  == false)
		sPasswd = MD5_encrypt(sPasswd) ;

    // pAdeli->GetText(adeli, 80);
    // sAdeli = string(adeli);

    // pNumLdv->GetText(numldv, 80);
    // sNumLdv = string(numldv);

	if ((sLogin == "") || (sPasswd == ""))
	{
		erreur("Vous devez d�finir un login et un mot de passe pour la personne � importer.", warningError, 0) ;
		return ;
	}

    /******************************************
    if ((sAdeli == "") && (sNumLdv == ""))
    {
        erreur("Vous devez d�finir un num�ro ADELI ou Ligne de Vie pour la personne � importer.", 0, 0);
        return;
    }
    ********************************************/

    NSUtilDialog::CmOk();
}

void
NSUserImportDialog::CmCancel()
{
    NSUtilDialog::CmCancel();
}

// -----------------------------------------------------------------------------
//
//  M�thodes de NSPersonImportDialog en mode N_TIERS
//
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSCorrespImportDialog, NSUtilDialog)
  EV_COMMAND(IDOK,                      CmOk),
  EV_COMMAND(IDCANCEL,                  CmCancel),
  EV_EN_CHANGE(IDC_IMPORTCOR_PWDUSER,   PasswordChange),
END_RESPONSE_TABLE ;

NSCorrespImportDialog::NSCorrespImportDialog(TWindow * pere, NSContexte *pCtx, TModule *module)
                      :NSUtilDialog(pere, pCtx, "IDD_IMPORTCORRESPLDV", module)
{
	pLogin  = new NSUtilEdit(pContexte, this, IDC_IMPORTCOR_IDENTUSER, 80);
	pPasswd = new NSUtilEdit(pContexte, this, IDC_IMPORTCOR_PWDUSER, 80);
	pAdeli  = new NSUtilEdit(pContexte, this, IDC_IMPORTCOR_ADELI, 80);
	pNumLdv = new NSUtilEdit(pContexte, this, IDC_IMPORTCOR_NUMLDV, 80);

}

NSCorrespImportDialog::~NSCorrespImportDialog()
{
	delete pLogin ;
	delete pPasswd ;
	delete pAdeli ;
	delete pNumLdv ;
}

void
NSCorrespImportDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	if (pContexte->getUtilisateur()->haveGlobalSessionPassword())
	{
		pLogin->Insert(pContexte->getUtilisateur()->getGlobalLoginSession().c_str()) ;
		pPasswd->Insert(pContexte->getUtilisateur()->getGlobalPasswordSession().c_str()) ;
		isHached = true ;
	}
	else
		isHached = false ;
}

void
NSCorrespImportDialog::PasswordChange()
{
	isHached = false;
}

void
NSCorrespImportDialog::CmOk()
{
	char far login[80] ;
	char far passwd[80] ;
	char far adeli[80] ;
	char far numldv[80] ;

	pLogin->GetText(login, 80) ;
	sLogin = string(login) ;

	pPasswd->GetText(passwd, 80) ;
	sPasswd = string(passwd) ;
	if (isHached  == false)
		sPasswd = MD5_encrypt(sPasswd) ;

	pAdeli->GetText(adeli, 80) ;
	sAdeli = string(adeli) ;

	pNumLdv->GetText(numldv, 80) ;
	sNumLdv = string(numldv) ;

	if ((sLogin == "") || (sPasswd == ""))
	{
		erreur("Vous devez d�finir un login et un mot de passe pour l'utilisateur en cours.", warningError, 0) ;
		return;
	}

	if ((sAdeli == "") && (sNumLdv == ""))
	{
		erreur("Vous devez d�finir un num�ro ADELI ou Ligne de Vie pour la personne � importer.", warningError, 0) ;
		return ;
	}

	NSUtilDialog::CmOk() ;
}

void
NSCorrespImportDialog::CmCancel()
{
	NSUtilDialog::CmCancel() ;
}


// -----------------------------------------------------------------------------
//
//  M�thodes de NSPatientImportDialog en mode N_TIERS
//
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSPatientImportDialog, NSUtilDialog)
  EV_COMMAND(IDOK,                      CmOk),
  EV_COMMAND(IDCANCEL,                  CmCancel),
  EV_EN_CHANGE(IDC_IMPORTPAT_PWDPAT,    PasswordChange),
END_RESPONSE_TABLE ;

NSPatientImportDialog::NSPatientImportDialog(TWindow * pere, NSContexte *pCtx, TModule *module)
  : NSUtilDialog(pere, pCtx, "IDD_IMPORT_PATLDV", module)
{
  pLogin  = new NSUtilEdit(pContexte, this, IDC_IMPORTPAT_LOGINPAT, 80) ;
  pPasswd = new NSUtilEdit(pContexte, this, IDC_IMPORTPAT_PWDPAT, 80) ;
  pNumLdv = new NSUtilEdit(pContexte, this, IDC_IMPORTPAT_NUMLDVPAT, 80) ;
}

NSPatientImportDialog::~NSPatientImportDialog()
{
  delete pLogin ;
  delete pPasswd ;
  delete pNumLdv ; 
}

void
NSPatientImportDialog::SetupWindow()
{
    NSUtilDialog::SetupWindow();
    if (pContexte->getUtilisateur()->haveGlobalSessionPassword())
    {
        pLogin->Insert(pContexte->getUtilisateur()->getGlobalLoginSession().c_str());
        pPasswd->Insert(pContexte->getUtilisateur()->getGlobalPasswordSession().c_str());
        isHached = true;
    }
    else
        isHached = false;
}

/*********************************************
void  NSPatientImportDialog::CmCreateMandat()
{
		GetData(false);
    CreateMandatInterface* create_mandat;
    if ((sLogin != "") && (sPasswd != ""))
   		create_mandat = new CreateMandatInterface(this, pContexte,sLogin, sPasswd );
    else
       create_mandat = new CreateMandatInterface(this, pContexte);
    if (create_mandat != NULL)
    	create_mandat->Execute();
    delete create_mandat;

}
**********************************************/

void NSPatientImportDialog::GetData(bool check)
{
    char far login[80];
    char far passwd[200];
    char far numldv[80];

    pLogin->GetText(login, 80);
    sLogin = string(login);

    pPasswd->GetText(passwd, 200);
    sPasswd = string(passwd);
    if (isHached == false)
    	sPasswd = MD5_encrypt(sPasswd);

    pNumLdv->GetText(numldv, 80);
    sNumLdv = string(numldv);

    if (check)
    	if ((sLogin == "") || (sPasswd == ""))
    	{
        erreur("Vous devez d�finir un login et un mot de passe pour le patient � importer.", warningError, 0);
        return;
    	}
}

void
NSPatientImportDialog::CmOk()
{
		GetData(true);

  /*  if (pMandat->GetCheck() == BF_CHECKED)
        bMandat = true;
    else
        bMandat = false;      */

    NSUtilDialog::CmOk();
}

void
NSPatientImportDialog::PasswordChange()
{
    isHached = false;
}

void
NSPatientImportDialog::CmCancel()
{
    NSUtilDialog::CmCancel();
}

/*

// -----------------------------------------------------------------
//
//  M�thodes de ChercheListeUtilDialog
//
// -----------------------------------------------------------------

// ---------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(ChercheListeUtilDialog, NSUtilDialog)
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_LVN_GETDISPINFO(IDC_LISTUTI_LW, LvnGetDispInfo),
END_RESPONSE_TABLE;


ChercheListeUtilDialog::ChercheListeUtilDialog(TWindow* pere, NSContexte* pCtx, TModule* mod)
                         :NSUtilDialog(pere, pCtx, "IDD_LISTUTI", mod)
{
    pListeUtil = new NSListUtilWindow(this, IDC_LISTUTI_LW, mod);
    pUtilArray = new NSUtiliArray;
    pUtilSelect = new NSUtiliInfo(pContexte);
}

ChercheListeUtilDialog::~ChercheListeUtilDialog()
{
	delete pUtilSelect;
    delete pUtilArray;
    delete pListeUtil;
}

void
ChercheListeUtilDialog::SetupWindow(){
	NSUtilDialog::SetupWindow();

    InitUtilArray();
    InitListe();
    AfficheListe();
}

bool
ChercheListeUtilDialog::InitUtilArray()
{
	pUtilArray->vider();
    nbUtil = 0;

#ifndef N_TIERS
    NSUtilisateur* pUtil = new NSUtilisateur(pContexte);	//
	// Ouverture du fichier
	//
	pUtil->lastError = pUtil->open();
	if (pUtil->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture de la base des utilisateurs.", 0, pUtil->lastError, GetHandle());
		delete pUtil;
		return false;
	}

   	pUtil->lastError = pUtil->debut(dbiWRITELOCK);
   	if (pUtil->lastError != DBIERR_NONE)
	{
		erreur("Erreur de positionnement dans la base des utilisateurs.", 0, pUtil->lastError, GetHandle());
		pUtil->close();
		delete pUtil;
		return false;
	}

   	do
   	{
   		pUtil->lastError = pUtil->getRecord();
		if (pUtil->lastError != DBIERR_NONE)
		{
			erreur("Erreur de lecture dans la base des utilisateurs.", 0, pUtil->lastError, GetHandle());
			pUtil->close();
			delete pUtil;
			return false;
		}

        // on stocke la fiche utilisateur dans pUtilArray
        pUtilArray->push_back(new NSUtiliInfo(pUtil));
        nbUtil++;

      	// on se positionne sur la template suivante

      	pUtil->lastError = pUtil->suivant(dbiWRITELOCK);
		if ((pUtil->lastError != DBIERR_NONE) && (pUtil->lastError != DBIERR_EOF))
      	{
			erreur("Erreur d'acc�s � l'utilisateur suivant.", 0, pUtil->lastError, GetHandle());
         	pUtil->close();
			delete pUtil;
			return false;
      	}
    }
   	while (pUtil->lastError != DBIERR_EOF);

	pUtil->lastError = pUtil->close();   	if (pUtil->lastError != DBIERR_NONE)		erreur("Erreur de fermeture de la base des utilisateurs.", 0, pUtil->lastError, GetHandle());

	delete pUtil;

#endif

    return true;
}

void
ChercheListeUtilDialog::InitListe()
{
	TListWindColumn colNom("Nom", 100, TListWindColumn::Left, 0);
  	pListeUtil->InsertColumn(0, colNom);
    TListWindColumn colPrenom("Prenom", 100, TListWindColumn::Left, 1);
  	pListeUtil->InsertColumn(1, colPrenom);
}

void
ChercheListeUtilDialog::AfficheListe()
{
    char nom[255];

	pListeUtil->DeleteAllItems();

	for (int i = nbUtil - 1; i >= 0; i--)
    {
   	    sprintf(nom, "%s", ((*pUtilArray)[i])->pDonnees->nom);
   	    TListWindItem Item(nom, 0);
        pListeUtil->InsertItem(Item);
    }
}

void
ChercheListeUtilDialog::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
    const int BufLen = 255;
    static char buffer[BufLen];
    TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item;
    int index;

    index = dispInfoItem.GetIndex();

    // Affiche les informations en fonction de la colonne

    switch (dispInfoItem.GetSubItem())
    {
        case 1: 	// pr�nom
            sprintf(buffer, "%s", ((*pUtilArray)[index])->pDonnees->prenom);
            dispInfoItem.SetText(buffer);
            break;
    }
}

void
ChercheListeUtilDialog::CmOk()
{
	UtilChoisi = pListeUtil->IndexItemSelect();
    if (UtilChoisi >= 0)
   	    *pUtilSelect = *((*pUtilArray)[UtilChoisi]);
    else
    {
        erreur("Vous devez choisir un utilisateur.", warningError, 0, GetHandle());
        return;
    }

    NSUtilDialog::CmOk();
}

void
ChercheListeUtilDialog::CmCancel()
{
	UtilChoisi = -1;
    NSUtilDialog::CmCancel();
}
*/
// -----------------------------------------------------------------
//
//  M�thodes de NSListUtilWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSListUtilWindow, TListWindow)
    EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

NSListUtilWindow::NSListUtilWindow(ChercheListeUtilDialog* pere, int resId, TModule* module) : TListWindow(pere, resId, module)
{
    pDlg = pere;
}

NSListUtilWindow::~NSListUtilWindow()
{
}

//---------------------------------------------------------------------------
//  Function: NSListUtilWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListUtilWindow::EvLButtonDblClk(uint /* modKeys */, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point);

    HitTest(info);

    if (info.GetFlags() & LVHT_ONITEM)
        pDlg->CmOk();
}

//---------------------------------------------------------------------------
//  Function: NSListUtilWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListUtilWindow::IndexItemSelect()
{
    int count = GetItemCount();
    int index = -1;

    for (int i = 0; i < count; i++)
   	    if (GetItemState(i, LVIS_SELECTED))
        {
      	    index = i;
            break;
        }

    return index;
}

/******************************************************************************/
//					METHODES DE PATCORDIALOG
/******************************************************************************/
/*
DEFINE_RESPONSE_TABLE1(PatCorDialog, NSUtilDialog)
	EV_WM_PAINT,
	EV_COMMAND(IDC_PATCOR_AJOUTER, CmAjouter),
    EV_COMMAND(IDC_PATCOR_SUPPR, CmSupprimer),
    EV_COMMAND(IDC_PATCOR_CREER, CmCreer),
    EV_COMMAND(IDC_PATCOR_MODIF, CmModifier),
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_LBN_SELCHANGE(IDC_PATCOR_CORRESP, CmSelectCorresp),
	EV_LBN_DBLCLK(IDC_PATCOR_CORRESP, CmCorrespDblClk),
END_RESPONSE_TABLE;

PatCorDialog::PatCorDialog(TWindow* pere, NSContexte* pCtx, string sNomLong, TModule* module)
							:NSUtilDialog(pere, pCtx, "IDD_PATCOR", module)
{
    pNomPatient = new NSUtilEdit(this, IDC_PATCOR_PATIENT, PAT_NOM_LONG_LEN);
	pListeCorresp 	= new TListBox(this, IDC_PATCOR_CORRESP, module);
    pCorrespBaseArray = new NSCorrespArray;
	pCorrespArray = new NSCorrespArray;
    sNomPatient = sNomLong;
    CorrespChoisi = -1;
    bAjouter = false;
}

PatCorDialog::~PatCorDialog()
{
	delete pListeCorresp;
	delete pCorrespArray;
    delete pCorrespBaseArray;
    delete pNomPatient;
}

void
PatCorDialog::SetupWindow()
{
	TDialog::SetupWindow();

    pNomPatient->SetText(sNomPatient.c_str());
    InitCorrespArray();
    if (pCorrespArray->empty())
   	    bAjouter = true;

    AfficheCorresp();
}

void
PatCorDialog::InitCorrespArray()
{
    pCorrespArray->vider();

	for (CorrespInfoIter i = pCorrespBaseArray->begin(); i != pCorrespBaseArray->end(); i++)
   	    pCorrespArray->push_back(new NSCorrespondantInfo(*(*i)));
}

void
PatCorDialog::AfficheCorresp()
{
	string sCorresp;

    // on vide la liste si elle contient des items
    if (pListeCorresp->GetCount())
   	    pListeCorresp->ClearList();

    for (CorrespInfoIter i = pCorrespArray->begin(); i != pCorrespArray->end(); i++)
    {
   	    // on remplit la liste
        sCorresp = (*i)->pDonnees->donneTitre();
        pListeCorresp->AddString(sCorresp.c_str());
    }
}

bool
PatCorDialog::ExisteCode(char* code)
{
	bool existeCode = false;

    for (CorrespInfoIter i = pCorrespArray->begin(); i != pCorrespArray->end(); i++)
    {
   	    if (!strcmp((*i)->pDonnees->code, code))
        {
      	    existeCode = true;
            break;
        }
    }

    return existeCode;
}

void
PatCorDialog::EvPaint()
{
	NSUtilDialog::EvPaint();

    if (bAjouter)
    {
        bAjouter = false;
        CmAjouter();
    }
}

void
PatCorDialog::CmSelectCorresp()
{
    CorrespChoisi = (int) pListeCorresp->GetSelIndex();
}

void
PatCorDialog::CmCorrespDblClk()
{
	CorrespChoisi = (int) pListeCorresp->GetSelIndex();
    CmModifier();
}

void
PatCorDialog::CmOk()
{
	// met � jour le tableau initial des correspondants
	pCorrespBaseArray->vider();

	for (CorrespInfoIter i = pCorrespArray->begin(); i != pCorrespArray->end(); i++)
   	    pCorrespBaseArray->push_back(new NSCorrespondantInfo(*(*i)));

    TDialog::CmOk();
}

void
PatCorDialog::CmCancel()
{
    TDialog::CmCancel();
}

void
PatCorDialog::CmAjouter()
{
    ChercheListeCorDialog* pListeCorDlg = new ChercheListeCorDialog(this, pContexte, GetModule());

    if ((pListeCorDlg->Execute() == IDOK) && (pListeCorDlg->CorrespChoisi >= 0))
    {
   	    // on v�rifie que le correspondant n'existe pas d�j�
        if (!ExisteCode(pListeCorDlg->pCorrespSelect->pDonnees->code))
   		    pCorrespArray->push_back(new NSCorrespondantInfo(*(pListeCorDlg->pCorrespSelect)));
    }

	delete pListeCorDlg;

    AfficheCorresp();
}

void
PatCorDialog::CmSupprimer()
{
	CorrespInfoIter i;
	int j;

    if (CorrespChoisi == -1)
    {
   	    erreur("Vous n'avez pas s�lectionn� de correspondant.", warningError, 0, GetHandle());
		return;
    }

	for (i = pCorrespArray->begin(), j = 0; i != pCorrespArray->end(); i++, j++)
    {
   	    if (j == CorrespChoisi)
        {
      	    delete (*i);
            pCorrespArray->erase(i);
            break;
        }
    }

    AfficheCorresp();
}
voidPatCorDialog::CmCreer()
{
#ifndef N_TIERS

	bool creatOK;
	NSCorrespondant* pCorresp = new NSCorrespondant(pContexte);

	pCorresp->lastError = pCorresp->open();
	if (pCorresp->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier Corresp.db", 0, pCorresp->lastError, GetHandle());
		delete pCorresp;
		return;
	}

    creatOK = pCorresp->Creer(this);

    pCorresp->lastError = pCorresp->close();
	if (pCorresp->lastError != DBIERR_NONE)
	{
		erreur("Erreur � la fermeture du fichier Corresp.db", 0, pCorresp->lastError, GetHandle());
		delete pCorresp;
		return;
	}

    if (creatOK)
    {
   	    // On ajoute les infos du nouveau correspondant
        pCorrespArray->push_back(new NSCorrespondantInfo(pCorresp));
        AfficheCorresp();
    }

    delete pCorresp;
#endif
}

voidPatCorDialog::CmModifier()
{
	string sCodeCorresp ;

  if (CorrespChoisi == -1)
  {
  	erreur("Vous n'avez pas s�lectionn� de correspondant.", warningError, 0, GetHandle()) ;
		return ;
  }

#ifndef N_TIERS

	bool modifOK ;

  NSCorrespondant* pCorresp = new NSCorrespondant(pContexte);

	pCorresp->lastError = pCorresp->open();
	if (pCorresp->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier Corresp.db", 0, pCorresp->lastError, GetHandle());
		delete pCorresp;
		return;
	}

    // on r�cup�re le code du correspondant s�lectionn�
    sCodeCorresp = string(((*pCorrespArray)[CorrespChoisi])->pDonnees->code);

    pCorresp->lastError = pCorresp->chercheClef(&sCodeCorresp,
                                                "",
                                                0,
                                                keySEARCHEQ,
                                                dbiWRITELOCK);
    if (pCorresp->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur � la recherche du correspondant.", 0, pCorresp->lastError, GetHandle());
        pCorresp->close();
		delete pCorresp;
		return;
    }

    pCorresp->lastError = pCorresp->getRecord();
    if (pCorresp->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur � lecture du fichier Corresp.db", 0, pCorresp->lastError, GetHandle());
        pCorresp->close();
		delete pCorresp;
		return;
    }

    // on retrouve l'adresse du correspondant
    pCorresp->initAdresseInfo();

    // on modifie les donn�es
    modifOK = pCorresp->Modifier(this);

    pCorresp->lastError = pCorresp->close();
	if (pCorresp->lastError != DBIERR_NONE)
	{
		erreur("Erreur � la fermeture du fichier Corresp.db", 0, pCorresp->lastError, GetHandle());
		delete pCorresp;
		return;
    }

    if (modifOK)
    {
   	    *((*pCorrespArray)[CorrespChoisi]) = NSCorrespondantInfo(pCorresp);
        AfficheCorresp();
    }
    delete pCorresp;

#endif
}

*/

// -----------------------------------------------------------------//
//  M�thodes de ChercheListePatCorDialog
//
// -----------------------------------------------------------------

// ---------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(ChercheListePatCorDialog, NSUtilDialog)
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_COMMAND(IDC_LISTCOR_AUTRE, CmAutreCorresp),
    EV_LVN_GETDISPINFO(IDC_LISTCOR_LW, LvnGetDispInfo),
END_RESPONSE_TABLE;

ChercheListePatCorDialog::ChercheListePatCorDialog(TWindow* pere, NSContexte* pCtx, TModule* mod)                         :NSUtilDialog(pere, pCtx, "IDD_LISTCOR", mod)
{
	pListeCorresp  = new NSListPatCorWindow(this, IDC_LISTCOR_LW, mod) ;
	pCorrespArray  = new NSPersonArray(pContexte) ;
	pCorrespSelect = new NSPersonInfo(pContexte) ;
}

ChercheListePatCorDialog::~ChercheListePatCorDialog(){
	delete pCorrespSelect ;
	delete pCorrespArray ;
	delete pListeCorresp ;
}

voidChercheListePatCorDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	InitPatCorArray() ;
  InitListe() ;
  AfficheListe() ;
}

// m�thode pour un patient d�j� initialis�
bool
ChercheListePatCorDialog::InitPatCorArray()
{
	pCorrespArray->vider() ;
	nbCorresp = 0 ;

	NSPatientChoisi* pPatChoisi = pContexte->getPatient() ;

	// Si on ne passe pas de patient, prend un array vide
	if ((NULL != pPatChoisi) && (NULL != pPatChoisi->pHealthTeam))
	{
  	VecteurString* pMembersList = pPatChoisi->pHealthTeam->getPIDS() ;
		for (EquiItemIter i = pMembersList->begin(); i != pMembersList->end(); i++)
    {
      if (pPatChoisi->getNss() != **i)
      {
    	  NSPersonInfo* pPersonInfo = pContexte->getPersonArray()->getPerson(*(*i), pidsCorresp) ;
        if (pPersonInfo->sPersonID != pPatChoisi->getNss())
        {
      	  pCorrespArray->push_back(new NSPersonInfo(*pPersonInfo)) ;
      	  nbCorresp++ ;
        }
      }
    }
	}

	if (nbCorresp == 0)
		return false ;	return true ;}

voidChercheListePatCorDialog::InitListe()
{
	TListWindColumn colNom("Nom", 100, TListWindColumn::Left, 0) ;
	pListeCorresp->InsertColumn(0, colNom) ;
	TListWindColumn colPrenom("Prenom", 100, TListWindColumn::Left, 1) ;
	pListeCorresp->InsertColumn(1, colPrenom) ;
	TListWindColumn colVille("Ville", 90, TListWindColumn::Left, 2) ;
	pListeCorresp->InsertColumn(2, colVille) ;
}

voidChercheListePatCorDialog::AfficheListe()
{
	char nom[255] ;

	pListeCorresp->DeleteAllItems() ;

	if (0 == nbCorresp)
		return ;

	for (int i = nbCorresp - 1; i >= 0; i--)
	{
		sprintf(nom, "%s", ((*pCorrespArray)[i])->sNom.c_str()) ;
    TListWindItem Item(nom, 0) ;
    pListeCorresp->InsertItem(Item) ;
	}
}

void
ChercheListePatCorDialog::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
	const int BufLen = 255 ;
	static char buffer[BufLen] ;
	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item;

	int index = dispInfoItem.GetIndex() ;

	// Affiche les informations en fonction de la colonne

	switch (dispInfoItem.GetSubItem())
	{
  	case 1: 	// pr�nom
    	sprintf(buffer, "%s", ((*pCorrespArray)[index])->sPrenom.c_str()) ;
      dispInfoItem.SetText(buffer) ;
      break ;
#ifndef N_TIERS
		case 2: 	// ville
    	sprintf(buffer, "%s", ((*pCorrespArray)[index])->pAdresseInfo->pDonnees->ville) ;
      dispInfoItem.SetText(buffer) ;
      break ;
#endif	}}

voidChercheListePatCorDialog::CmAutreCorresp()
{
  NSTPersonListDialog *pListeCorDlg = new NSTPersonListDialog((TWindow *)this, pidsCorresp, false, pContexte, 0, true) ;
	if ((pListeCorDlg->Execute() == IDOK) && (NULL != pListeCorDlg->pPersonSelect))
	{
		*pCorrespSelect = *(pListeCorDlg->pPersonSelect) ;
    CorrespChoisi = nbCorresp ;
	}
	delete pListeCorDlg ;
	NSUtilDialog::CmOk() ;
}

voidChercheListePatCorDialog::CmOk()
{
	CorrespChoisi = pListeCorresp->IndexItemSelect() ;

	if (CorrespChoisi >= 0)
		*pCorrespSelect = *((*pCorrespArray)[CorrespChoisi]) ;
	else
	{
  	erreur("Vous devez choisir un correspondant.", warningError, 0, GetHandle()) ;
    return ;
	}

	NSUtilDialog::CmOk() ;
}

voidChercheListePatCorDialog::CmCancel()
{
	CorrespChoisi = -1 ;
	NSUtilDialog::CmCancel() ;
}

// -----------------------------------------------------------------

//
//  M�thodes de NSListPatCorWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSListPatCorWindow, TListWindow)
    EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

NSListPatCorWindow::NSListPatCorWindow(ChercheListePatCorDialog* pere, int resId, TModule* module) : TListWindow(pere, resId, module)
{
    pDlg = pere;
}

NSListPatCorWindow::~NSListPatCorWindow()
{
}

//---------------------------------------------------------------------------
//  Function: NSListPatCorWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListPatCorWindow::EvLButtonDblClk(uint /* modKeys */, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point);

    HitTest(info);

    if (info.GetFlags() & LVHT_ONITEM)
        pDlg->CmOk();
}

//---------------------------------------------------------------------------
//  Function: NSListPatCorWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListPatCorWindow::IndexItemSelect()
{
    int count = GetItemCount();
    int index = -1;

    for (int i = 0; i < count; i++)
   	    if (GetItemState(i, LVIS_SELECTED))
        {
      	    index = i;
            break;
        }

    return index;
}// -----------------------------------------------------------------//
//  M�thodes de NSListeClientGroupDialog
//
// -----------------------------------------------------------------

// ---------------------------------------------------------------------------
#ifdef N_TIERS

DEFINE_RESPONSE_TABLE1(NSListeClientGroupDialog, NSUtilDialog)	EV_COMMAND(IDOK, CmOk),
	EV_COMMAND(IDCANCEL, CmCancel),
	EV_COMMAND(IDC_LISTGROUP_RECHNOM,  RechercheParNomPrenom),
	EV_COMMAND(IDC_LISTGROUP_RECHIEP,  RechercheParIEP),
  EV_COMMAND(IDC_LISTGROUP_OUVRIR,   CmOk),
  EV_COMMAND(IDC_LISTGROUP_MERGE,    CmOk),
	EV_COMMAND(IDC_LISTGROUP_IMPORTER, Importer),
	EV_COMMAND(IDC_LISTGROUP_GROOP,    Importation),
	EV_COMMAND(IDC_LISTGROUP_BACK,     CmBack),
	EV_LVN_GETDISPINFO(IDC_LISTGROUP_LW, LvnGetDispInfo),
	EV_LVN_COLUMNCLICK(IDC_LISTGROUP_LW, LVNColumnclick),
END_RESPONSE_TABLE;NSListeClientGroupDialog::NSListeClientGroupDialog(TWindow* parent, NSContexte* pCtx, NSPatInfo* pPat)                         :NSUtilDialog(parent, pCtx, "IDD_LISTGROUP")
{
	// Cr�ation de tous les "objets de contr�le"
	pNom           = new NSUtilEdit(pContexte, this, IDC_LISTGROUP_NOM, PAT_NOM_LEN) ;
	pPrenom        = new NSUtilEdit(pContexte, this, IDC_LISTGROUP_PRENOM, PAT_PRENOM_LEN) ;
	pIEP           = new NSUtilEdit(pContexte, this, IDC_LISTGROUP_IEP, 30) ;
	pTexte		     = new TStatic(this, IDC_LISTGROUP_TEXT) ;

	pCancel		     = new TStatic(this, IDCANCEL) ;

	pButtonNom     = new TStatic(this, IDC_LISTGROUP_RECHNOM) ;
	pButtonIep     = new TStatic(this, IDC_LISTGROUP_RECHIEP) ;

	pButtonImport  = new TStatic(this, IDC_LISTGROUP_IMPORTER) ;
	pButtonBack    = new TStatic(this, IDC_LISTGROUP_BACK) ;
	pButtonGrpSrch = new TStatic(this, IDC_LISTGROUP_GROOP) ;
	pButtonOpen    = new TStatic(this, IDC_LISTGROUP_OUVRIR) ;
	pButtonMerge   = new TStatic(this, IDC_LISTGROUP_MERGE) ;

	pExactButton   = new TRadioButton(this, IDC_RECH_EXACT) ;
	pStartByButton = new TRadioButton(this, IDC_RECH_APPROCHE) ;

	pListe 	       = new NSListGroupWindow(this, pContexte, IDC_LISTGROUP_LW) ;

	pLastList      = new NSPersonsAttributesArray() ;

    // on recup�re le patient en cours
	pPatEnCours = pPat;

	//il faut reinitialiser la liste des patients
	bMustInit = true;

	// Cr�ation du tableau de Patients
	pPatientsArray = new NSPatientArray;

	iSortedColumn    = 1 ;
	bNaturallySorted = true ; // in order to have it naturally sorted

	// nom et pr�nom initiaux
	strcpy(nomPat, "");
	strcpy(prenomPat, "");

	// Existe-t-il des donn�es de capture Episodus ?
	if (pContexte->getSuperviseur()->getEpisodus())
	{
		NSCaptureArray* pCapt = &(pContexte->getSuperviseur()->getEpisodus()->newCaptureArray);

        string sNom     = string("") ;
        string sPrenom  = string("") ;
        string sCode    = string("") ;

        pCapt->trouveChemin(string("LNOM01"), &sNom) ;
        pCapt->trouveChemin(string("LNOM21"), &sPrenom) ;
        pCapt->trouveChemin(string("LIDEN1"), &sCode) ;

        string sPatronyme = string("") ;
        pCapt->trouveChemin(string("LPATR1"), &sPatronyme) ;
        if (sPatronyme != "")
        {
            size_t i ;
            //
            // Recherche de la premi�re lettre non majuscule
            //
            for (i = 0; (i < strlen(sPatronyme.c_str())) &&
                    (sPatronyme[i] == pseumaj(sPatronyme[i])); i++) ;

            if (i < strlen(sPatronyme.c_str()))
            {
                if (i > 0)
                {
                    for (; (i > 0) && (sPatronyme[i] != ' '); i--) ;
                    if (i > 0)
                    {
                        sNom    = string(sPatronyme, 0, i) ;
                        sPrenom = string(sPatronyme, i+1, strlen(sPatronyme.c_str()) - i - 1) ;
                    }
                    else
                        sPrenom = sPatronyme ;
                }
                else
                    sPrenom = sPatronyme ;
            }
            else
                sNom = sPatronyme ;
        }

        if (strlen(sNom.c_str()) > PAT_NOM_LEN)
            sNom = string(sNom, 0, PAT_NOM_LEN) ;
        strcpy(nomPat, sNom.c_str()) ;

        if (strlen(sPrenom.c_str()) > PAT_PRENOM_LEN)
            sPrenom = string(sPrenom, 0, PAT_PRENOM_LEN) ;
        strcpy(prenomPat, sPrenom.c_str()) ;
    }

	sNssSelect = "" ;	etat = todoNothing ;    mode = todoNothing ; 	bTrouveLocal = false ;	bTrouveGlobal = false ;	bListeLocal = true ;	sIdLocal = "" ;	sIdGlobal = "" ;
	// Gestion du blocage patient	verifBloque  = false ;
	donneMessage = true ;

	// fichiers d'aide
	pContexte->getSuperviseur()->setAideIndex("h_index.htm") ;
	pContexte->getSuperviseur()->setAideCorps("h_rchpat.htm") ;
}

NSListeClientGroupDialog::~NSListeClientGroupDialog()
{
	delete pNom ;
	delete pPrenom ;
  delete pIEP ;
	delete pTexte	;
	delete pCancel ;
	delete pButtonNom ;
	delete pButtonIep ;
	delete pButtonImport ;
	delete pButtonBack ;
	delete pButtonGrpSrch ;
	delete pButtonOpen ;
  delete pButtonMerge ;
  delete pExactButton ;
	delete pStartByButton ;

  delete pLastList ;
	delete pListe ;
	delete pPatientsArray ;
}

void
NSListeClientGroupDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow();

	setResearchOn() ;

	pNom->SetText(nomPat);
	pPrenom->SetText(prenomPat);

	InitListe();

	pStartByButton->SetCheck(BF_CHECKED) ;
}

void
NSListeClientGroupDialog::RechercheParIEP()
{
	char Code[PAT_CODE_LEN + 1] = "" ;

	pIEP->GetText(Code, PAT_CODE_LEN + 1) ;

	if (!strcmp(Code, ""))
		return ;

	RechercheIEP(Code) ;
}

void prepareString(char *str)
{
	if (strstr(str, "*") == NULL)
		return ;
	for (size_t i = 0; i < strlen(str); i++)
		if (str[i] == '*')
			str[i] = '%' ;
}

void
NSListeClientGroupDialog::PrepareNomPrenom(string& sNomToCall, string& sPrenomToCall)
{
	// on r�cup�re le nom et le pr�nom pour les passer comme traits au service
	pNom->GetText(nomPat, PAT_NOM_LEN + 1);
	pPrenom->GetText(prenomPat, PAT_PRENOM_LEN + 1);

	if (prenomPat)
	{
    	if (string(prenomPat) != "")
			prepareString(prenomPat) ;

    	sPrenomToCall = string(prenomPat) ;

    	if (pStartByButton->GetCheck() == BF_CHECKED)
    	{
    		if ((sPrenomToCall == "") || (sPrenomToCall[strlen(sPrenomToCall.c_str())-1] != '%'))
      			sPrenomToCall += string("%") ;
    	}
	}

	if (nomPat)
	{
  		if (string(nomPat) != "")
			prepareString(nomPat) ;

    	sNomToCall = string(nomPat) ;

        // Recherche exacte ou recherche approch�e
        //
        if (pStartByButton->GetCheck() == BF_CHECKED)
        {
            if ((sNomToCall == "") || (sNomToCall[strlen(sNomToCall.c_str())-1] != '%'))
            	sNomToCall += string("%") ;
        }
	}
}

void
NSListeClientGroupDialog::RechercheParNomPrenom()
{
try
{
	// on r�cup�re le nom et le pr�nom pour les passer comme traits au service
	string sNomToCall = "" ;
	string sPrenomToCall = "" ;

	pContexte->GetMainWindow()->SetCursor(0, IDC_WAIT) ;

	PrepareNomPrenom(sNomToCall, sPrenomToCall) ;

  if (sNomToCall == string("%"))
  {
  	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName() ;
    MessageBox("Attention vous devez taper comme crit�re au moins une lettre du nom.", sCaption.c_str(), MB_OK) ;
    return ;
  }

	//on a une liste des patients
	NSPersonsAttributesArray PatiensList ;
	NSBasicAttributeArray    AttrArray ;

	AttrArray.push_back(new NSBasicAttribute(ROLE, PATIENT_ROLE)) ;
	if (sPrenomToCall != string("%"))
		AttrArray.push_back(new NSBasicAttribute(FIRST_NAME, sPrenomToCall)) ;
	AttrArray.push_back(new NSBasicAttribute(LAST_NAME, sNomToCall)) ;

	if ((sNomToCall == string("")) && (sPrenomToCall == string("")))
		return ;

	AttrArray.push_back(new NSBasicAttribute(TRAIT, FIRST_NAME));
	AttrArray.push_back(new NSBasicAttribute(TRAIT, LAST_NAME));
	AttrArray.push_back(new NSBasicAttribute(TRAIT, SEX));
	AttrArray.push_back(new NSBasicAttribute(TRAIT, BIRTHDATE));
	AttrArray.push_back(new NSBasicAttribute(TRAIT, IPP)) ;
	// pAttrArray->push_back(new NSBasicAttribute(OPERATOR, user)) ;
	// pAttrArray->push_back(new NSBasicAttribute(CONSOLE, console)) ;
	// pAttrArray->push_back(new NSBasicAttribute(INSTANCE, string(szInstance))) ;

  if (bListeLocal)
  {
  	bool res = pContexte->pPilot->personList(NautilusPilot::SERV_PERSON_LIST_FROM_TRAITS.c_str(), &PatiensList, &AttrArray) ;
    //if ((!res) || (pPatiensList->empty()))
    if (!res)
    {
    	std::string tempMessage = pContexte->pPilot->getWarningMessage() ;
      std::string tempError = pContexte->pPilot->getErrorMessage() ;
      if( tempMessage != "")
      	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
      if( tempError != "")
      	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
      return ;
    }

    etat = todoSearch ;

    // Initialisation du tableau des patients et des bookmarks
    InitPatArray(&PatiensList) ;

    // on conserve l'�tat de la liste pour le retour �ventuel � la recherche
    *pLastList = PatiensList ;

    // Initialisation de la liste
    AfficheListe(true) ;

    pTexte->SetText("Etat de la recherche nom-pr�nom sur serveur local.") ;
  }
  else
  {
  	// on est ici dans le cas o� on r�it�re la recherche sur le serveur SIH
    bool res = pContexte->pPilot->personList((NautilusPilot::SERV_GROUP_PATIENT_LIST).c_str(), &PatiensList, &AttrArray);

    if (!res)
    {
    	std::string tempMessage = pContexte->pPilot->getWarningMessage();
      std::string tempError = pContexte->pPilot->getErrorMessage();
      if( tempMessage != "")
      	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK);
      if( tempError != "")
      	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK);
      return ;
    }

    // Dans ce contexte, on laisse l'etat inchang�
    // Initialisation du tableau des patients et des bookmarks
    InitPatArray(&PatiensList) ;

    // Initialisation de la liste
    AfficheListe(false) ;
  }

  pContexte->GetMainWindow()->SetCursor(0, IDC_ARROW) ;
}
catch (...)
{
  erreur("Exception NSListeClientGroupDialog::RechercheParNomPrenom", standardError, 0) ;
}
}

//
// Liste des patients sur le serveur SIH
// Patients list on the HIS server
//
void
NSListeClientGroupDialog::Importation()
{
try
{
	string sNomToCall, sPrenomToCall ;
	// on r�cup�re le nom et le pr�nom pour les passer comme traits au service
	PrepareNomPrenom(sNomToCall, sPrenomToCall) ;

  if (sNomToCall == string("%"))
  {
  	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName() ;
    MessageBox("Attention vous devez taper comme crit�re au moins une lettre du nom.", sCaption.c_str(), MB_OK) ;
    return ;
  }

	bool listOk = false;
	// le serviceName est d�fini dans le constructeur
	//on a une liste des patients
	NSPersonsAttributesArray PatiensList ;
	NSBasicAttributeArray    AttrArray ;

  pContexte->GetMainWindow()->SetCursor(0, IDC_WAIT) ;

  // sur le serveur de groupe
  serviceName = (NautilusPilot::SERV_GROUP_PATIENT_LIST).c_str() ;

  AttrArray.push_back(new NSBasicAttribute(ROLE, PATIENT_ROLE));
  if (sPrenomToCall != string("%"))
  	AttrArray.push_back(new NSBasicAttribute(FIRST_NAME, sPrenomToCall));
  AttrArray.push_back(new NSBasicAttribute(LAST_NAME, sNomToCall));

  AttrArray.push_back(new NSBasicAttribute(TRAIT, IPP));
  AttrArray.push_back(new NSBasicAttribute(TRAIT, FIRST_NAME));
  AttrArray.push_back(new NSBasicAttribute(TRAIT, LAST_NAME));
  AttrArray.push_back(new NSBasicAttribute(TRAIT, SEX));
  AttrArray.push_back(new NSBasicAttribute(TRAIT, BIRTHDATE));

  listOk = pContexte->pPilot->personList(serviceName, &PatiensList, &AttrArray) ;

  // we switch to "group mode" even with an empty list
  if ((!listOk) /*|| (pPatiensList->empty())*/)
  {
  	std::string tempMessage = pContexte->pPilot->getWarningMessage();
    std::string tempError = pContexte->pPilot->getErrorMessage();
    if( tempMessage != "")
    	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK);
    if( tempError != "")
    	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK);
    return ;
  }

  etat = todoImport ;

  pButtonImport->Show(SW_SHOW) ;
  pButtonBack->Show(SW_SHOW) ;
  pButtonMerge->Show(SW_HIDE) ;
  pButtonGrpSrch->Show(SW_HIDE) ;
  pButtonOpen->Show(SW_HIDE) ;

  Invalidate() ;

  // ::ShowWindow(GetDlgItem(IDC_LISTGROUP_IMPORTER),   SW_HIDE);
  // ::EnableWindow(GetDlgItem(IDC_LISTGROUP_IMPORTER), FALSE );
  // pButtonImport->ShowWindow(SW_HIDE);

  // Initialisation du tableau des patients et des bookmarks
  InitPatArray(&PatiensList) ;

  pContexte->GetMainWindow()->SetCursor(0, IDC_ARROW) ;

  // Initialisation de la liste
  AfficheListe(false) ;

  pTexte->SetText("Etat de la recherche nom-pr�nom sur serveur SIH. S�lectionnez ci-dessous le patient � importer ou Retour pour revenir � la liste locale.") ;
}
catch (...)
{
  erreur("Exception NSListeClientGroupDialog::Importation", standardError, 0) ;
}
}

void
NSListeClientGroupDialog::Importer()
{
	if (!bTrouveGlobal)
		CmOk();
	else
	{
		if (!importPatientGroup(sIPPTrouve))
			return ;

		SetCursor(0, IDC_ARROW) ;
		CloseWindow(IDOK) ;
	}
}

void
NSListeClientGroupDialog::InitListe()
{
	TListWindColumn colIpp("", 15, TListWindColumn::Left, 0);
    pListe->InsertColumn(0, colIpp) ;

	TListWindColumn colPatient("Patient", 200, TListWindColumn::Left, 1) ;
	pListe->InsertColumn(1, colPatient) ;

	TListWindColumn colDateN("Date Naiss", 80, TListWindColumn::Left, 2) ;	pListe->InsertColumn(2, colDateN) ;

	TListWindColumn colSexe("Sexe", 40, TListWindColumn::Left, 3) ;
	pListe->InsertColumn(3, colSexe) ;

	TListWindColumn colStatut("Statut", 40, TListWindColumn::Left, 4) ;
	pListe->InsertColumn(4, colStatut) ;

	TListWindColumn colBloque("Bloqu�", 50, TListWindColumn::Left, 5) ;	pListe->InsertColumn(5, colBloque) ;
}

void
NSListeClientGroupDialog::AfficheListe(bool bLocal)
{
	// char flagIpp[5];

	bListeLocal = bLocal ;

	// On vide la liste
	//
	pListe->DeleteAllItems();

	if (bListeLocal)
	{
		SetCaption("PATIENTS DU SERVICE");
        pButtonNom->SetCaption("Rechercher par Nom/Pr�nom");
		// setResearchOn();
	}
	else
	{
		SetCaption("PATIENTS DU SIH");
        pButtonNom->SetCaption("Rechercher sur SIH");
		// setResearchOff();
	}

	PatientReverseIter iterReverse = pPatientsArray->rbegin() ;

	while(iterReverse != pPatientsArray->rend())
	{
		TListWindItem Item("", 0) ;

        if ((*iterReverse)->haveIpp())
        	Item.SetStateImage(2) ;

		pListe->InsertItem(Item) ;
		iterReverse++ ;
	}
}

void
NSListeClientGroupDialog::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
	const int   BufLen = 255 ;
	static char buffer[BufLen] ;
	int         index ;
	static char libelBloqu[3] ;
	static char	libelStatut[5] ;
	static char sexe[2] ;
	string      clef ;

	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;
	index = dispInfoItem.GetIndex() ;

	// Affiche les informations en fonction de la colonne

	switch (dispInfoItem.GetSubItem())
	{
  	case 1 :
    	sprintf(buffer, "%s %s", ((*pPatientsArray)[index])->getszNom(), ((*pPatientsArray)[index])->getszPrenom()) ;
      dispInfoItem.SetText(buffer) ;
      break ;

    case 2 : // date de naissance
    	if (((*pPatientsArray)[index])->donneDateNaiss() != "")
      {
      	sprintf(buffer, "%s", (((*pPatientsArray)[index])->donneDateNaiss()).c_str()) ;
        dispInfoItem.SetText(buffer) ;
      }
      break ;

    case 3 : // sexe
    	if (((*pPatientsArray)[index])->estMasculin())
      	strcpy(sexe, "M") ;
      else
      	strcpy(sexe, "F") ;
      dispInfoItem.SetText(sexe) ;

      break ;

    case 4 : // Statut
    	strcpy(libelStatut, "  ") ;
      dispInfoItem.SetText(libelStatut) ;
      break ;

    case 5 : // blocage
    	strcpy(libelBloqu, "  ") ;
      dispInfoItem.SetText(libelBloqu) ;
      break ;
	}
}

void
NSListeClientGroupDialog::InitPatArray(NSPersonsAttributesArray *pList)
{
	pPatientsArray->vider();

	if (!(pList->empty()))
		for (NSPersonsAttributeIter iterPatient = pList->begin(); iterPatient != pList->end(); iterPatient++)
		{
			NSPatInfo *pPatientEnCours = new NSPatInfo(*iterPatient, pContexte);
			pPatientsArray->push_back(pPatientEnCours) ;
		}

  iSortedColumn    = 1 ;
  bNaturallySorted = true ;
	sort(pPatientsArray->begin(), pPatientsArray->end(), patSortByNameInf) ;
}

void
NSListeClientGroupDialog::RechercheIEP(string sIEP)
{
try
{
	bool listOk = false;
  // le serviceName est d�fini dans le constructeur
  //on a une liste des patients
  NSPersonsAttributesArray PatiensList ;
  NSBasicAttributeArray    AttrArray ;

  // sur le serveur de groupe
  serviceName= (NautilusPilot::SERV_GROUP_PATIENT_LIST).c_str() ;

  AttrArray.push_back(new NSBasicAttribute(ROLE,  PATIENT_ROLE)) ;
  AttrArray.push_back(new NSBasicAttribute(IEP,   sIEP)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, IPP)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, FIRST_NAME)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, LAST_NAME)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, SEX)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, BIRTHDATE)) ;

  listOk = pContexte->pPilot->personList(serviceName, &PatiensList, &AttrArray) ;

  if ((!listOk) || (PatiensList.empty()))
  {
    std::string tempMessage = pContexte->pPilot->getWarningMessage() ;
    std::string tempError = pContexte->pPilot->getErrorMessage() ;
    if( tempMessage != "")
    	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK);
    if( tempError != "")
    	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK);
    return ;
	}

  // on prend le premier de la liste (en principe l'IEP est unique)
  NSPatInfo *pPatientEnCours = new NSPatInfo(*(PatiensList.begin()), pContexte) ;

  if (!pPatientEnCours->haveIpp())
  {
  	// cas d'erreur
    erreur("Le patient recherch� ne d�tient pas d'IPP.", standardError, 0) ;
    return ;
	}

  bTrouveGlobal = true ;
  sIPPTrouve    = pPatientEnCours->getIpp() ;
  sIdGlobal     = pPatientEnCours->getNss() ;
  sPatientGlobal = pPatientEnCours->getNom() + string(" ") + pPatientEnCours->getPrenom() ;

  // NSDataGraph* pDataGraph = pPatientEnCours->pGraphPerson->pDataGraph ;
  AttrArray.vider() ;
  PatiensList.vider() ;
  bool bTrouve = false ;

  // on recherche son IPP en local
  //////////////////////////////////////////////////////////////////////////////////////////
	char szInstance[3] ;
  int iInstance = pContexte->getSuperviseur()->getInstance() ;
  itoa(iInstance, szInstance, 10) ;

  string user = pContexte->getUtilisateurID();
  string console = pContexte->getSuperviseur()->getConsole() ;

  AttrArray.push_back(new NSBasicAttribute(ROLE, PATIENT_ROLE)) ;
  AttrArray.push_back(new NSBasicAttribute(IPP, pPatientEnCours->getIpp())) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, FIRST_NAME)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, LAST_NAME)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, SEX)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, BIRTHDATE)) ;
  // pAttrArray->push_back(new NSBasicAttribute(OPERATOR, user)) ;
  // pAttrArray->push_back(new NSBasicAttribute(CONSOLE, console)) ;
  // pAttrArray->push_back(new NSBasicAttribute(INSTANCE, string(szInstance))) ;

  bool res = pContexte->pPilot->personList(NautilusPilot::SERV_PERSON_LIST_FROM_TRAITS.c_str(), &PatiensList, &AttrArray) ;
  if (!res)
  {
  	std::string tempMessage = pContexte->pPilot->getWarningMessage() ;
    std::string tempError = pContexte->pPilot->getErrorMessage();
    if( tempMessage != "")
    	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK);
    if( tempError != "")
    	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK);
    return ;
  }

  if (false == PatiensList.empty())
  	bTrouve = true ;

  pNom->SetText(pPatientEnCours->getszNom()) ;
  pPrenom->SetText(pPatientEnCours->getszPrenom()) ;

  if (bTrouve)
  {
  	bTrouveLocal = true ;

    etat = todoSynchro;

    pButtonImport->Show(SW_HIDE) ;
    pButtonBack->Show(SW_SHOW) ;
    pButtonMerge->Show(SW_HIDE) ;
    pButtonGrpSrch->Show(SW_HIDE) ;
    pButtonOpen->Show(SW_SHOW) ;

    Invalidate() ;

    InitPatArray(&PatiensList) ;
    AfficheListe(true) ;

    pTexte->SetText("Patient trouv� en local. S�lectionnez-le et appuyez sur Ouvrir pour l'ouvrir.");
  }
  else
  {
  	AttrArray.vider() ;
    PatiensList.vider() ;

    AttrArray.push_back(new NSBasicAttribute(ROLE, PATIENT_ROLE)) ;
    AttrArray.push_back(new NSBasicAttribute(FIRST_NAME, pPatientEnCours->getPrenom())) ;
    AttrArray.push_back(new NSBasicAttribute(LAST_NAME, pPatientEnCours->getNom())) ;
    // pAttrArray->push_back(new NSBasicAttribute(SEX, pPatientEnCours->getSexe())) ;
    // pAttrArray->push_back(new NSBasicAttribute(BIRTHDATE, pPatientEnCours->getNaissance())) ;

    AttrArray.push_back(new NSBasicAttribute(TRAIT, FIRST_NAME));
    AttrArray.push_back(new NSBasicAttribute(TRAIT, LAST_NAME));
    AttrArray.push_back(new NSBasicAttribute(TRAIT, SEX));
    AttrArray.push_back(new NSBasicAttribute(TRAIT, BIRTHDATE));
    AttrArray.push_back(new NSBasicAttribute(TRAIT, IPP)) ;

    bool res = pContexte->pPilot->personList(NautilusPilot::SERV_PERSON_LIST_FROM_TRAITS.c_str(), &PatiensList, &AttrArray) ;
    if (!res)
    {
      std::string tempMessage = pContexte->pPilot->getWarningMessage();
      std::string tempError = pContexte->pPilot->getErrorMessage();
      if( tempMessage != "")
          ::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK);
      if( tempError != "")
          ::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK);
      return;
    }

    etat = todoMerge;

    pButtonImport->Show(SW_SHOW) ;
    pButtonBack->Show(SW_SHOW) ;
    pButtonMerge->Show(SW_SHOW) ;
    pButtonGrpSrch->Show(SW_HIDE) ;
    pButtonOpen->Show(SW_HIDE) ;

    Invalidate() ;

    InitPatArray(&PatiensList) ;
    AfficheListe(true) ;

    char msg[255] ;
    char dateNaiss[255] ;

    if (pPatientEnCours->donneDateNaiss() != "")
      sprintf(dateNaiss, " n�(e) le %s", (pPatientEnCours->donneDateNaiss()).c_str()) ;
    else
      strcpy(dateNaiss, "") ;

    sprintf(msg, "Patient recherch� : %s %s%s. IPP non trouv� sur la base locale. S�lectionnez ci-dessous, sur la base locale, un patient de m�me nom � fusionner ou importez le patient en cliquant sur Importer.",
        pPatientEnCours->getszNom(), pPatientEnCours->getszPrenom(), dateNaiss) ;
    pTexte->SetText(msg) ;
	}
  SetCursor(0, IDC_ARROW) ;
}
catch (...)
{
  erreur("Exception NSListeClientGroupDialog::RechercheIEP", standardError, 0) ;
}
}

bool
NSListeClientGroupDialog::importPatientGroup(string sIPP)
{
try
{
	NSDataGraph* pGraph = pPatEnCours->pGraphPerson->pDataGraph;
	NSBasicAttributeArray *pAttrArray =  new NSBasicAttributeArray();

	/*pAttrArray->push_back(new NSBasicAttribute(LOGIN, pContexte->getUtilisateur()->getGlobalLoginSession()));
	pAttrArray->push_back(new NSBasicAttribute(PASSWORD, pContexte->getUtilisateur()->getGlobalPasswordSession()));*/
	pAttrArray->push_back(new NSBasicAttribute(OPERATOR, pContexte->getUtilisateurID()));
	pAttrArray->push_back(new NSBasicAttribute(IPP, sIPP));

	// lancement du service d'importation
	bool res = pContexte->pPilot->importPerson(NautilusPilot::SERV_GROUP_PATIENT_IMPORT.c_str(),
                                pAttrArray, pPatEnCours->pGraphPerson->pDataGraph);

	if (!res)
	{
		std::string tempMessage = pContexte->pPilot->getWarningMessage();
		std::string tempError = pContexte->pPilot->getErrorMessage();
		if( tempMessage != "")
			::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK);
		if( tempError != "")
			::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK);
		//CloseWindow(IDCANCEL);
		delete pAttrArray ;
		return false ;
	}

   //	pPatEnCours->pGraphPerson->setInfoPids(pAttrArray);
	pPatEnCours->pGraphPerson->pDataGraph->setLastTree();

	pPatEnCours->pGraphPerson->parseMainAttributes();

	string user = pContexte->getUtilisateurID();
	char szInstance[3];
	int iInstance = pContexte->getSuperviseur()->getInstance() ;
	itoa(iInstance, szInstance, 10) ;
	serviceName = (NautilusPilot::SERV_CREATE_IMPORTED_GROUP_PATIENT).c_str();
	NSPersonsAttributesArray *pPersonsList = new NSPersonsAttributesArray();
	NSBasicAttributeArray *pAttrList = new NSBasicAttributeArray();

	pAttrArray->vider();
	*pAttrArray = *(pPatEnCours->pGraphPerson->pAttrArray) ;

	pAttrList->push_back(new NSBasicAttribute(LAST_NAME, pAttrArray->getAttributeValue(LAST_NAME))) ;
	pAttrList->push_back(new NSBasicAttribute(FIRST_NAME, pAttrArray->getAttributeValue(FIRST_NAME))) ;
	pAttrList->push_back(new NSBasicAttribute(SEX, pAttrArray->getAttributeValue(SEX))) ;
	pAttrList->push_back(new NSBasicAttribute(BIRTHDATE, pAttrArray->getAttributeValue(BIRTHDATE))) ;
	pAttrList->push_back(new NSBasicAttribute(OPERATOR, user)) ;
	pAttrList->push_back(new NSBasicAttribute(CONSOLE, string(pContexte->getSuperviseur()->getConsole()))) ;
	pAttrList->push_back(new NSBasicAttribute(INSTANCE, string(szInstance))) ;
	pAttrList->push_back(new NSBasicAttribute(PERSON, pPatEnCours->pGraphPerson->getPersonID())) ;
	pAttrList->push_back(new NSBasicAttribute(IPP, sIPP));
	string sRootDoc = string(pPatEnCours->pGraphPerson->getRootTree(), PAT_NSS_LEN, DOC_CODE_DOCUM_LEN);
	pAttrList->push_back(new NSBasicAttribute(ROOTDOC, sRootDoc)) ;
	bool bRes = pContexte->pPilot->createImportedPerson(serviceName, pGraph, pPersonsList, pAttrList) ;

	if (!bRes)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("patientManagement", "importedPatientCreationError") ;
		erreur(sErrorText.c_str(), standardError, 0) ;
    delete pPersonsList ;
		delete pAttrList ;
		return false ;
	}

	// import all objects for this patient
	NSBasicAttributeArray *pAttrObjectsArray = new NSBasicAttributeArray() ;
	pAttrObjectsArray->push_back(new NSBasicAttribute(OPERATOR, user)) ;
	pAttrObjectsArray->push_back(new NSBasicAttribute(PERSON, pPatEnCours->pGraphPerson->getPersonID())) ;
	bRes = pContexte->pPilot->updateObjectList(NautilusPilot::SERV_UPDATE_ALL_LDV_OBJECTS.c_str(), pGraph, pAttrObjectsArray) ;
	if (!bRes)
	{
		erreur(pContexte->pPilot->getWarningMessage().c_str(), standardError, 0) ;
		string sErrorText = pContexte->getSuperviseur()->getText("patientManagement", "errorImportObjects") ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		delete pPersonsList ;
		delete pAttrList ;
		delete pAttrObjectsArray ;
		delete pAttrArray ;
		return false ;
	}

	delete pAttrObjectsArray ;

	pAttrArray->push_back(new NSBasicAttribute(OPERATOR, user)) ;
	pAttrArray->push_back(new NSBasicAttribute(PERSON, pPatEnCours->pGraphPerson->getPersonID())) ;

	if ((!pPatEnCours->pGraphPerson->pDataGraph) ||
    	(!pPatEnCours->pGraphPerson->graphPrepare()))
	{
		delete pPersonsList ;
		delete pAttrList ;
		delete pAttrArray ;
		return false ;
	}

	pPatEnCours->pGraphPerson->bNeedUnlock	= true ;
	pPatEnCours->pGraphPerson->bReadOnly 	= false ;

	pPatEnCours->pGraphPerson->setInfoPids(pAttrArray) ;
	pPatEnCours->pGraphPerson->pDataGraph->setLastTree() ;
    //debug line
	string sRootTree = pPatEnCours->pGraphPerson->getRootTree() ;

    mode = todoImport;

	delete pAttrArray ;
	delete pPersonsList ;
	delete pAttrList ;

	return true ;
}
catch (...)
{
  erreur("Exception NSListeClientGroupDialog::importPatientGroup", standardError, 0) ;
	return false ;
}
}

void
NSListeClientGroupDialog::GardeNss(int index)
{
	sNssSelect = ((*pPatientsArray)[index])->getNss();
}

void
NSListeClientGroupDialog::RetrouvePatSelect()
{
	for (int i = 0; i < nbNom; i++)
    {
        if (sNssSelect == ((*pPatientsArray)[i])->getNss())
        {      	    pListe->SetSel(i, true);
            break;
        }
    }
}

void
NSListeClientGroupDialog::setResearchOn()
{
	/******************************************** on ne gere plus que les boutons ici
	uint32 uiStyle = pNom->TWindow::GetStyle() ;
	uiStyle &= ~WS_DISABLED ;
	//pNom->TWindow::SetStyle(uiStyle ^ WS_DISABLED) ;
	pNom->TWindow::SetStyle(uiStyle);

	uiStyle = pPrenom->TWindow::GetStyle();
	uiStyle &= ~WS_DISABLED ;
	//pPrenom->TWindow::SetStyle(uiStyle ^ WS_DISABLED) ;
	pPrenom->TWindow::SetStyle(uiStyle);

	uiStyle = pIEP->TWindow::GetStyle();
	//pIEP->TWindow::SetStyle(uiStyle ^ WS_DISABLED) ;
	uiStyle &= ~WS_DISABLED ;
	pIEP->TWindow::SetStyle(uiStyle) ;

	uiStyle = pButtonNom->TWindow::GetStyle();
	// pButtonNom->TWindow::SetStyle(uiStyle ^ WS_DISABLED) ;
	uiStyle &= ~WS_DISABLED ;
	pButtonNom->TWindow::SetStyle(uiStyle);

	uiStyle = pButtonIep->TWindow::GetStyle();
	uiStyle &= ~WS_DISABLED ;
	pButtonIep->TWindow::SetStyle(uiStyle) ;
    **********************************************************************************/

    pButtonImport->Show(SW_HIDE) ;
    pButtonBack->Show(SW_HIDE) ;
    pButtonMerge->Show(SW_HIDE) ;
    pButtonGrpSrch->Show(SW_SHOW) ;
    pButtonOpen->Show(SW_SHOW) ;

	Invalidate() ;
}

void
NSListeClientGroupDialog::setResearchOff()
{
	uint32 uiStyle = pNom->TWindow::GetStyle() ;
	pNom->TWindow::SetStyle(uiStyle | WS_DISABLED) ;

	uiStyle = pPrenom->TWindow::GetStyle();
	pPrenom->TWindow::SetStyle(uiStyle | WS_DISABLED) ;

	uiStyle = pIEP->TWindow::GetStyle();
	pIEP->TWindow::SetStyle(uiStyle | WS_DISABLED) ;

	uiStyle = pButtonNom->TWindow::GetStyle();
	pButtonNom->TWindow::SetStyle(uiStyle | WS_DISABLED) ;

	uiStyle = pButtonIep->TWindow::GetStyle();
	pButtonIep->TWindow::SetStyle(uiStyle | WS_DISABLED) ;

	// pButtonImport->Show(SW_SHOW) ;
	// pButtonBack->Show(SW_SHOW) ;
	// pButtonGrpSrch->Show(SW_HIDE) ;
	// pButtonOpen->Show(SW_HIDE) ;

	Invalidate() ;
}

bool
NSListeClientGroupDialog::CanClose()
{
	return NSUtilDialog::CanClose();
}


voidNSListeClientGroupDialog::CmOk(){	int index = pListe->IndexItemSelect();	if (index == -1)
	{
		// erreur("Vous devez s�lectionner un patient dans la liste.",0,0,GetHandle());
		string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "PatientNotSelected") ;
		erreur(sErrorText.c_str(), warningError, standardError, 0) ;
		return ;
	}

	*pPatEnCours = *((*pPatientsArray)[index]);

	char szPerson[PAT_NSS_LEN + 1] ;
	strcpy(szPerson, ((*pPatientsArray)[index])->getszNss()) ;

  /*
  if ((szPerson[0] != LocalPatient) && (pContexte->getUtilisateur()->haveGlobalSessionPassword() == false))
  {
    LogPassInterface* getGlobPassword = new LogPassInterface(this,pContexte);
    getGlobPassword->Execute();
    delete  getGlobPassword;
  }
  */

	if (bListeLocal)
	{
		bTrouveLocal = true ;
		sIdLocal = ((*pPatientsArray)[index])->getNss() ;
    sPatientLocal = ((*pPatientsArray)[index])->getNom() + string(" ") + ((*pPatientsArray)[index])->getPrenom() ;
	}
	else
	{
		bTrouveGlobal = true ;
		sIdGlobal = ((*pPatientsArray)[index])->getNss() ;
		sIPPTrouve = ((*pPatientsArray)[index])->getIpp() ;
    sPatientGlobal = ((*pPatientsArray)[index])->getNom() + string(" ") + ((*pPatientsArray)[index])->getPrenom() ;
	}

	char szInstance[3] ;
	int iInstance = pContexte->getSuperviseur()->getInstance() ;
	itoa(iInstance, szInstance, 10) ;

	SetCursor(0, IDC_WAIT) ;
	// pContexte->setPatient(new NSPatientChoisi(pContexte));
	string user = pContexte->getUtilisateurID() ;

	NSBasicAttributeArray    AttrArray ;
	NSPersonsAttributesArray List ;

	if (etat == todoSearch)
	{
		// ouverture en mode Client Group :
		// on v�rifie si le patient a un ipp
		if (((*pPatientsArray)[index])->haveIpp())
		{
      AttrArray.push_back(new NSBasicAttribute(IPP, ((*pPatientsArray)[index])->getIpp())) ;
      AttrArray.push_back(new NSBasicAttribute(OPERATOR, pContexte->getUtilisateurID())) ;
      AttrArray.push_back(new NSBasicAttribute(CONSOLE, string(pContexte->getSuperviseur()->getConsole()))) ;
      AttrArray.push_back(new NSBasicAttribute(INSTANCE, string(szInstance))) ;

      // lancement du service de synchronisation
      bool res = pContexte->pPilot->searchPatient(NautilusPilot::SERV_OPEN_PATIENT_DATA_FROM_TRAITS.c_str(), pPatEnCours->pGraphPerson->pDataGraph, &List, &AttrArray) ;
			if (!res)
			{
				string tempMessage = pContexte->pPilot->getWarningMessage() ;
				string tempError = pContexte->pPilot->getErrorMessage() ;
				if( tempMessage != "")
					::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
				if( tempError != "")
					::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
				//CloseWindow(IDCANCEL) ;
        SetCursor(0, IDC_ARROW) ;
				return ;
			}

      // Mode NeedUnlock et Read-only
      pPatEnCours->pGraphPerson->bNeedUnlock	= false ;
      pPatEnCours->pGraphPerson->bReadOnly 	= true ;

      if (!(List.empty()))
      {
        string sIsLocked = List.getAttributeValue("locked") ;
        if (sIsLocked == "ok")
          pPatEnCours->pGraphPerson->bNeedUnlock = true ;
        string sOperationType	= List.getAttributeValue("operationType") ;
        if (sOperationType == "readWrite")
          pPatEnCours->pGraphPerson->bReadOnly = false ;
      }
		}
		else
		{
      // on affiche les nom et prenom avant la recherche en groupe
      pNom->SetText(pPatEnCours->getszNom()) ;
      pPrenom->SetText(pPatEnCours->getszPrenom()) ;

      // Lancement des services r�alisant la proc�dure de merge
      // sur le serveur de groupe
      string sNomToCall, sPrenomToCall ;
      // on r�cup�re le nom et le pr�nom pour les passer comme traits au service
      PrepareNomPrenom(sNomToCall, sPrenomToCall) ;

      if (sNomToCall == string("%"))
      {
        string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName() ;
        MessageBox("Attention vous devez taper comme crit�re au moins une lettre du nom.", sCaption.c_str(), MB_OK) ;
        return ;
      }

			bool listOk = false ;
			// le serviceName est d�fini dans le constructeur
			//on a une liste des patients
			serviceName = (NautilusPilot::SERV_GROUP_PATIENT_LIST).c_str() ;

			AttrArray.push_back(new NSBasicAttribute(ROLE, PATIENT_ROLE)) ;
      if (sPrenomToCall != string("%"))
				AttrArray.push_back(new NSBasicAttribute(FIRST_NAME, sPrenomToCall)) ;
			AttrArray.push_back(new NSBasicAttribute(LAST_NAME, sNomToCall)) ;
			AttrArray.push_back(new NSBasicAttribute(TRAIT, IPP)) ;
			AttrArray.push_back(new NSBasicAttribute(TRAIT, FIRST_NAME)) ;
			AttrArray.push_back(new NSBasicAttribute(TRAIT, LAST_NAME)) ;
			AttrArray.push_back(new NSBasicAttribute(TRAIT, SEX)) ;
			AttrArray.push_back(new NSBasicAttribute(TRAIT, BIRTHDATE)) ;

			listOk = pContexte->pPilot->personList(serviceName, &List, &AttrArray) ;
			if (!listOk)
			{
        SetCursor(0, IDC_ARROW) ;
				string tempMessage = pContexte->pPilot->getWarningMessage() ;
				string tempError = pContexte->pPilot->getErrorMessage() ;
				if (tempMessage != "")
					::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
				if (tempError != "")
					::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
				return ;
			}

			etat = todoMerge ;

      pButtonImport->Show(SW_HIDE) ;
      pButtonBack->Show(SW_SHOW) ;
      pButtonMerge->Show(SW_SHOW) ;
      pButtonGrpSrch->Show(SW_HIDE) ;
      pButtonOpen->Show(SW_HIDE) ;

      Invalidate() ;

			//::ShowWindow(GetDlgItem(IDC_LISTGROUP_IMPORTER),   SW_HIDE) ;
			//::EnableWindow(GetDlgItem(IDC_LISTGROUP_IMPORTER), FALSE ) ;

			// Initialisation du tableau des patients et des bookmarks
			InitPatArray(&List) ;

			// Initialisation de la liste
			AfficheListe(false) ;

      char msg[255] ;
      char dateNaiss[255] ;

      if (pPatEnCours->donneDateNaiss() != "")
          sprintf(dateNaiss, " n�(e) le %s", (pPatEnCours->donneDateNaiss()).c_str()) ;
      else
          strcpy(dateNaiss, "") ;

      sprintf(msg, "IPP non trouv� en local. Vous pouvez maintenant fusionner %s %s%s avec une personne ci-dessous (liste du serveur SIH) ou Retour pour revenir � la liste locale.", pPatEnCours->getszNom(), pPatEnCours->getszPrenom(), dateNaiss) ;

			pTexte->SetText(msg) ;

      SetCursor(0, IDC_ARROW) ;
			return ;
		}
	}
	else if (etat == todoSynchro)
	{
		AttrArray.push_back(new NSBasicAttribute(IPP, sIPPTrouve)) ;
    AttrArray.push_back(new NSBasicAttribute(OPERATOR, pContexte->getUtilisateurID())) ;
    AttrArray.push_back(new NSBasicAttribute(CONSOLE, string(pContexte->getSuperviseur()->getConsole()))) ;
    AttrArray.push_back(new NSBasicAttribute(INSTANCE, string(szInstance))) ;

		// lancement du service de synchronisation
		bool res = pContexte->pPilot->searchPatient(NautilusPilot::SERV_OPEN_PATIENT_DATA_FROM_TRAITS.c_str(), pPatEnCours->pGraphPerson->pDataGraph, &List, &AttrArray) ;
		if (!res)
		{
      SetCursor(0, IDC_ARROW) ;
			string tempMessage = pContexte->pPilot->getWarningMessage() ;
			string tempError = pContexte->pPilot->getErrorMessage() ;
			if( tempMessage != "")
				::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
			if( tempError != "")
				::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
			//CloseWindow(IDCANCEL) ;
			return ;
		}

    mode = todoSynchro ;

    // Mode NeedUnlock et Read-only
    pPatEnCours->pGraphPerson->bNeedUnlock	= false ;
    pPatEnCours->pGraphPerson->bReadOnly 	= true ;

    if (!(List.empty()))
    {
      string sIsLocked = List.getAttributeValue("locked") ;
      if (sIsLocked == "ok")
        pPatEnCours->pGraphPerson->bNeedUnlock = true ;
      string sOperationType	= List.getAttributeValue("operationType") ;
      if (sOperationType == "readWrite")
        pPatEnCours->pGraphPerson->bReadOnly = false ;
    }
	}
	else if (etat == todoMerge)
	{
		char msg[255] ;

    sprintf(msg, "ATTENTION : Vous allez fusionner %s (base SIH) avec %s (base locale). Voulez-vous continuer ?", sPatientGlobal.c_str(), sPatientLocal.c_str()) ;
    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName() ;
    int retVal = MessageBox(msg, sCaption.c_str(), MB_YESNO) ;
    if (retVal == IDNO)
			return ;

    // Dans ce cas on doit v�rifier que l'IPP trouv� sur le serveur de groupe
    // n'existe pas d�j� en local, auquel cas l'importation plante...
    AttrArray.push_back(new NSBasicAttribute(ROLE, PATIENT_ROLE)) ;
    AttrArray.push_back(new NSBasicAttribute(IPP, sIPPTrouve)) ;
    AttrArray.push_back(new NSBasicAttribute(TRAIT, FIRST_NAME)) ;
    AttrArray.push_back(new NSBasicAttribute(TRAIT, LAST_NAME)) ;
    AttrArray.push_back(new NSBasicAttribute(TRAIT, SEX)) ;
    AttrArray.push_back(new NSBasicAttribute(TRAIT, BIRTHDATE)) ;

    bool res = pContexte->pPilot->personList(NautilusPilot::SERV_PERSON_LIST_FROM_TRAITS.c_str(), &List, &AttrArray) ;
    if (!res)
    {
    	string tempMessage = pContexte->pPilot->getWarningMessage() ;
      string tempError = pContexte->pPilot->getErrorMessage() ;
      if (tempMessage != "")
      	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
      if (tempError != "")
      	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
      return ;
    }

    if (!List.empty())
    {
    	// cas d'erreur : le patient que l'on veut importer a d�j� le m�me IPP en local
      erreur("Fusion impossible : un patient d�tenant le m�me IPP que le patient s�lectionn� sur le SIH existe d�j� en local.", standardError, 0) ;
      return ;
    }

    AttrArray.vider() ;

		if (importPatientGroup(sIPPTrouve))
		{
			char szInstance[3] ;
			int iInstance = pContexte->getSuperviseur()->getInstance() ;
			itoa(iInstance, szInstance, 10) ;
      // NSDataGraph* pGraph = pPatEnCours->pGraphPerson->pDataGraph ;

			// pContexte->setPatient(new NSPatientChoisi(pContexte));
			string user = pContexte->getUtilisateurID() ;

			NSBasicAttributeArray LocalAttrArray ;

			LocalAttrArray.push_back(new NSBasicAttribute(COLLECTIVE, sIdGlobal)) ;
			LocalAttrArray.push_back(new NSBasicAttribute(LOCAL, sIdLocal)) ;
			LocalAttrArray.push_back(new NSBasicAttribute(OPERATOR, user)) ;
			LocalAttrArray.push_back(new NSBasicAttribute(CONSOLE, string(pContexte->getSuperviseur()->getConsole()))) ;
			LocalAttrArray.push_back(new NSBasicAttribute(INSTANCE, string(szInstance))) ;

			bool res = pContexte->pPilot->mergePatient(NautilusPilot::SERV_MERGE_PATIENT.c_str(), pPatEnCours->pGraphPerson->pDataGraph, &LocalAttrArray) ;
			if (!res)
			{
      	SetCursor(0, IDC_ARROW) ;
				string tempMessage = pContexte->pPilot->getWarningMessage() ;
				string tempError = pContexte->pPilot->getErrorMessage() ;
				if (tempMessage != "")
        	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
				if (tempError != "")
        	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
				return ;
			}

      LocalAttrArray.vider() ;
      LocalAttrArray.push_back(new NSBasicAttribute(PERSON, sIdGlobal)) ;
      LocalAttrArray.push_back(new NSBasicAttribute(OPERATOR, user)) ;

      res = pContexte->pPilot->modifyPersonOrObject(NautilusPilot::SERV_MODIFY_GRAPH_PERSON.c_str(), pPatEnCours->pGraphPerson->pDataGraph, &List, &LocalAttrArray) ;
      if (!res)
			{
      	SetCursor(0, IDC_ARROW) ;
				string tempMessage = pContexte->pPilot->getWarningMessage() ;
				string tempError = pContexte->pPilot->getErrorMessage() ;
				if (tempMessage != "")
        	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
				if (tempError != "")
        	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
				return ;
			}

      mode = todoMerge ;

			// string sIdCollectif = pPatEnCours->getNss() ;
		}
    else
			return ;
	}
	else if (etat == todoImport)
	{
    // Dans ce cas on doit v�rifier que l'IPP trouv� sur le serveur de groupe
    // n'existe pas d�j� en local, auquel cas l'importation plante...
    AttrArray.push_back(new NSBasicAttribute(ROLE, PATIENT_ROLE)) ;
    AttrArray.push_back(new NSBasicAttribute(IPP, sIPPTrouve)) ;
    AttrArray.push_back(new NSBasicAttribute(TRAIT, FIRST_NAME)) ;
    AttrArray.push_back(new NSBasicAttribute(TRAIT, LAST_NAME)) ;
    AttrArray.push_back(new NSBasicAttribute(TRAIT, SEX)) ;
    AttrArray.push_back(new NSBasicAttribute(TRAIT, BIRTHDATE)) ;
    // pAttrArray->push_back(new NSBasicAttribute(OPERATOR, user)) ;
    // pAttrArray->push_back(new NSBasicAttribute(CONSOLE, console)) ;
    // pAttrArray->push_back(new NSBasicAttribute(INSTANCE, string(szInstance))) ;

    bool res = pContexte->pPilot->personList(NautilusPilot::SERV_PERSON_LIST_FROM_TRAITS.c_str(), &List, &AttrArray) ;
    if (!res)
    {
      string tempMessage = pContexte->pPilot->getWarningMessage() ;
      string tempError = pContexte->pPilot->getErrorMessage() ;
      if (tempMessage != "")
        ::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
      if (tempError != "")
        ::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
      return ;
    }

    if (!List.empty())
    {
      // cas d'erreur : le patient que l'on veut importer a d�j� le m�me IPP en local
      erreur("Importation impossible : un patient d�tenant le m�me IPP que le patient s�lectionn� sur le SIH existe d�j� en local.", standardError, 0) ;
      return ;
    }

		if (!importPatientGroup(sIPPTrouve))
    {
      SetCursor(0, IDC_ARROW) ;
      return ;
		}
	}

	if ((!pPatEnCours->pGraphPerson->pDataGraph) || (!pPatEnCours->pGraphPerson->graphPrepare()))
	{
    SetCursor(0, IDC_ARROW) ;
		return ;
	}

  if ((etat != todoImport) && (etat != todoMerge))
  {
    AttrArray.push_back(new NSBasicAttribute(PERSON, string(szPerson))) ;
    AttrArray.push_back(new NSBasicAttribute(OPERATOR, user)) ;
    AttrArray.push_back(new NSBasicAttribute(CONSOLE, string(pContexte->getSuperviseur()->getConsole()))) ;
    AttrArray.push_back(new NSBasicAttribute(INSTANCE, string(szInstance))) ;

    pPatEnCours->pGraphPerson->setInfoPids(&AttrArray) ;
    pPatEnCours->pGraphPerson->pDataGraph->setLastTree() ;
  }

    //debug lines
	string sCodePat = pPatEnCours->pGraphPerson->getRootTree() ;
	// NSDataGraph* pGraph = pPatEnCours->pGraphPerson->pDataGraph ;

	SetCursor(0, IDC_ARROW) ;
	CloseWindow(IDOK) ;
}voidNSListeClientGroupDialog::CmCancel(){	CloseWindow(IDCANCEL) ;}voidNSListeClientGroupDialog::CmBack(){	// if (bListeLocal)	//  	return ;	bTrouveGlobal = false ;    pTexte->SetText("");    if (!pLastList->empty())    	etat = todoSearch ;    else    	etat = todoNothing ;	InitPatArray(pLastList) ;    AfficheListe(true);	setResearchOn() ;}voidNSListeClientGroupDialog::LVNColumnclick(TLwNotify& lwn)
{
  switch ( lwn.iSubItem )
  {
    case 0  : sortByName() ;      break ;
    case 1  : sortByBirthday() ;  break ;
    case 2  : sortBySex() ;       break ;
  }
}
voidNSListeClientGroupDialog::sortByName()
{
  if (iSortedColumn == 0)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = 0 ;
    bNaturallySorted = true ;
  }

  if (pPatientsArray->empty())
    return ;

  if (bNaturallySorted)
    sort(pPatientsArray->begin(), pPatientsArray->end(), patSortByNameInf) ;
  else
    sort(pPatientsArray->begin(), pPatientsArray->end(), patSortByNameSup) ;

  AfficheListe(bListeLocal) ;
}

void
NSListeClientGroupDialog::sortByBirthday()
{
  if (iSortedColumn == 0)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = 0 ;
    bNaturallySorted = true ;
  }

  if (pPatientsArray->empty())
    return ;

  if (bNaturallySorted)
    sort(pPatientsArray->begin(), pPatientsArray->end(), patSortByBirthInf) ;
  else
    sort(pPatientsArray->begin(), pPatientsArray->end(), patSortByBirthSup) ;

  AfficheListe(bListeLocal) ;
}

void
NSListeClientGroupDialog::sortBySex()
{
  if (iSortedColumn == 0)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = 0 ;
    bNaturallySorted = true ;
  }

  if (pPatientsArray->empty())
    return ;

  if (bNaturallySorted)
    sort(pPatientsArray->begin(), pPatientsArray->end(), patSortBySexInf) ;
  else
    sort(pPatientsArray->begin(), pPatientsArray->end(), patSortBySexSup) ;

  AfficheListe(bListeLocal) ;
}
// -----------------------------------------------------------------//
//  M�thodes de NSNTiersListePatDialog
//
// -----------------------------------------------------------------

// ---------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSNTiersListePatDialog, NSUtilDialog)	EV_COMMAND(IDOK, CmOk),
	EV_COMMAND(IDC_LISTPA_OUVRIR, CmOk),
	EV_COMMAND(IDCANCEL, CmCancel),
	EV_COMMAND(IDC_NTLISTPA_RECHPAT, Rechercher),
	EV_COMMAND(IDC_NTLISTPA_CREER, Creer),
	EV_LVN_GETDISPINFO(IDC_NTLISTPA_LW, LvnGetDispInfo),
	EV_LVN_COLUMNCLICK(IDC_NTLISTPA_LW, LVNColumnclick),
  EV_WM_TIMER,
  EV_COMMAND_AND_ID(IDC_USENOM,    nameActiver),
  EV_COMMAND_AND_ID(IDC_USEPRENOM, nameActiver),
END_RESPONSE_TABLE;NSNTiersListePatDialog::NSNTiersListePatDialog(TWindow* parent, NSContexte* pCtx, NSPatInfo* pPat,                         char* cResId)
                         :NSUtilDialog(parent, pCtx, cResId)
{
try
{
  _bDontEvenTryToOpen = false ;

	// Cr�ation de tous les "objets de contr�le"
	pNom 	      = new NSNTiersRechNomEdit(pContexte, this, IDC_NTLISTPA_NOM, PAT_NOM_LEN) ;
	pPrenom     = new NSNTiersRechNomEdit(pContexte, this, IDC_NTLISTPA_PRENOM, PAT_PRENOM_LEN) ;
	pNumero     = new NSUtilEdit(pContexte, this, IDC_NTLISTPA_NUMERO, PAT_NSS_LEN) ;
	pCode       = new NSNTiersRechNomEdit(pContexte, this, IDC_NTLISTPA_CODE, PAT_CODE_LEN) ;

  pLibName         = new TStatic(this, IDS_NTLISTPA_NOM) ;
  pLibGivenName    = new TStatic(this, IDS_NTLISTPA_PRENOM) ;
	pLibID           = new TStatic(this, IDS_NTLISTPA_NUMERO) ;
	pLibCode         = new TStatic(this, IDS_NTLISTPA_CODE) ;

  pUseNom          = new TCheckBox(this, IDC_USENOM) ;
  pUsePrenom       = new TCheckBox(this, IDC_USEPRENOM) ;

	pExactButton     = new TRadioButton(this, IDC_RECH_EXACT) ;
	pStartByButton   = new TRadioButton(this, IDC_RECH_APPROCHE) ;

	pListe 	         = new NSNTiersListPatWindow(this, pContexte, IDC_NTLISTPA_LW) ;
	iSortedColumn    = 1 ;
  bNaturallySorted = true ; // in order to have it naturally sorted

	// on recup�re le patient en cours
	pPatEnCours = pPat ;

	//il faut reinitialiser la liste des patients
	bMustInit = true ;

	// Cr�ation du tableau de Patients
	pPatientsArray = new NSPatientArray ;

	// nom et pr�nom initiaux
	strcpy(nomPat,    "") ;
	strcpy(prenomPat, "") ;
	strcpy(numPat,    "") ;
	strcpy(codePat,   "") ;

	// Existe-t-il des donn�es de capture Episodus ?
	if (NULL != pContexte->getSuperviseur()->getEpisodus())
	{
		NSCaptureArray* pCapt = &(pContexte->getSuperviseur()->getEpisodus()->newCaptureArray) ;

    bool bIPPMode = false ;
    if (string("") != pContexte->getSuperviseur()->getIppSite())
    	bIPPMode = true ;

    string sNom     = string("") ;
    string sPrenom  = string("") ;
    string sCode    = string("") ;

    pCapt->trouveChemin(string("LNOM01"), &sNom) ;
    pCapt->trouveChemin(string("LNOM21"), &sPrenom) ;

    if (false == bIPPMode)
    	pCapt->trouveChemin(string("LIDEN1"), &sCode) ;
    else
    	pCapt->trouveChemin(string("LIPP01"), &sCode) ;

    string sPatronyme = string("") ;
    pCapt->trouveChemin(string("LPATR1"), &sPatronyme) ;
    if (sPatronyme != "")
    {
    	size_t i ;
      //
      // Recherche de la premi�re lettre non majuscule
      //
      for (i = 0; (i < strlen(sPatronyme.c_str())) &&
                    (sPatronyme[i] == pseumaj(sPatronyme[i])); i++) ;

      if (i < strlen(sPatronyme.c_str()))
      {
      	if (i > 0)
        {
        	for (; (i > 0) && (sPatronyme[i] != ' '); i--) ;
          if (i > 0)
          {
          	sNom    = string(sPatronyme, 0, i) ;
            sPrenom = string(sPatronyme, i+1, strlen(sPatronyme.c_str()) - i - 1) ;
          }
          else
          	sPrenom = sPatronyme ;
        }
        else
        	sPrenom = sPatronyme ;
      }
      else
      	sNom = sPatronyme ;
    }

    if (strlen(sNom.c_str()) > PAT_NOM_LEN)
    	sNom = string(sNom, 0, PAT_NOM_LEN) ;
    strcpy(nomPat, sNom.c_str()) ;

    if (strlen(sPrenom.c_str()) > PAT_PRENOM_LEN)
    	sPrenom = string(sPrenom, 0, PAT_PRENOM_LEN) ;
    strcpy(prenomPat, sPrenom.c_str()) ;

        /*******************************
        string sCode    = string("") ;
        pCapt->trouveChemin(string("LIDEN1"), &sCode) ;

        if (strlen(sCode.c_str()) > PAT_CODE_LEN)
            sCode = string(sCode, 0, PAT_CODE_LEN);
        strcpy(codePat, sCode.c_str()) ;
        *************************************/
  }

  sNssSelect = "" ;
  // fichiers d'aide  // pContexte->getSuperviseur()->setAideIndex("h_index.htm") ;
  // pContexte->getSuperviseur()->setAideCorps("h_rchpat.htm") ;
}
catch (...)
{
	erreur("Exception NSNTiersListePatDialog ctor.", standardError, 0) ;
}
}

NSNTiersListePatDialog::~NSNTiersListePatDialog()
{
	delete pNom ;
	delete pPrenom ;
	delete pNumero ;
	delete pCode ;
  delete pExactButton ;
  delete pStartByButton ;
	delete pListe ;
	delete pPatientsArray ;
  delete pLibName ;
  delete pLibGivenName ;
	delete pLibID ;
	delete pLibCode ;
  delete pUseNom ;
  delete pUsePrenom ;
}

void
NSNTiersListePatDialog::SetupWindow()
{
	string ps = string("Entering SetupWindow for patient selection") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

	TDialog::SetupWindow();

	pNom->SetText(nomPat);
	pPrenom->SetText(prenomPat);

  pUseNom->Check() ;
  if (prenomPat[0] == '\0')
  	pUsePrenom->Check() ;
  else
  	pUsePrenom->Uncheck() ;

  string sLocalText = pContexte->getSuperviseur()->getText("dialog_patientList", "famillyName") ;
  if (sLocalText != "")
  	pLibName->SetText(sLocalText.c_str()) ;
  sLocalText = pContexte->getSuperviseur()->getText("dialog_patientList", "givenName") ;
  if (sLocalText != "")
  	pLibGivenName->SetText(sLocalText.c_str()) ;
  sLocalText = pContexte->getSuperviseur()->getText("dialog_patientList", "patientId") ;
  if (sLocalText != "")
		pLibID->SetText(sLocalText.c_str()) ;
  sLocalText = pContexte->getSuperviseur()->getText("dialog_patientList", "code") ;
  if (sLocalText != "")
		pLibCode->SetText(sLocalText.c_str()) ;

  sLocalText = pContexte->getSuperviseur()->getText("dialog_patientList", "fuzzySearch") ;
  if (sLocalText != "")
  	pExactButton->SetCaption(sLocalText.c_str()) ;
  sLocalText = pContexte->getSuperviseur()->getText("dialog_patientList", "exactSearch") ;
  if (sLocalText != "")
		pStartByButton->SetCaption(sLocalText.c_str()) ;

	ps = string("Initializing patients list") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

	// Initialisation de la liste
	InitListe();
	// AfficheListe();

  pStartByButton->SetCheck(BF_CHECKED) ;

	if (nomPat[0] != '\0')
  	Rechercher() ;

	ps = string("Leaving SetupWindow for patient selection") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;
}

void
NSNTiersListePatDialog::InitListe()
{
	string sLocalText = pContexte->getSuperviseur()->getText("dialog_patientList", "patient") ;
  if (sLocalText == "")
  	sLocalText = "Patient" ;
	TListWindColumn colPatient((char*) sLocalText.c_str(), 200, TListWindColumn::Left, 0) ;
	pListe->InsertColumn(0, colPatient) ;

  sLocalText = pContexte->getSuperviseur()->getText("dialog_patientList", "birthDate") ;
  if (sLocalText == "")
  	sLocalText = "Date Naiss" ;
	TListWindColumn colDateN((char*) sLocalText.c_str(), 80, TListWindColumn::Left, 1) ;	pListe->InsertColumn(1, colDateN) ;

  sLocalText = pContexte->getSuperviseur()->getText("dialog_patientList", "sex") ;
  if (sLocalText == "")
  	sLocalText = "Sexe" ;
	TListWindColumn colSexe((char*) sLocalText.c_str(), 40, TListWindColumn::Left, 2) ;
	pListe->InsertColumn(2, colSexe) ;

  sLocalText = pContexte->getSuperviseur()->getText("dialog_patientList", "locked") ;
  if (sLocalText == "")
  	sLocalText = "Bloqu�" ;
	TListWindColumn colBloque((char*) sLocalText.c_str(), 50, TListWindColumn::Left, 3) ;	pListe->InsertColumn(3, colBloque) ;
}

void
NSNTiersListePatDialog::AfficheListe()
{
	// On vide la liste
	//
	pListe->DeleteAllItems() ;

	PatientReverseIter iterReverse = pPatientsArray->rbegin() ;

	while(iterReverse != pPatientsArray->rend())
	{
		string sNomLong  = string((*iterReverse)->getszNom()) + string(" ") + string((*iterReverse)->getszPrenom()) ;
		// sprintf(buffer, "%s %s", ((*iterReverse)->getszNom(), (*iterReverse)->getszPrenom()));
		TListWindItem Item(sNomLong.c_str(), 0) ;

		pListe->InsertItem(Item) ;
		iterReverse++ ;
	}
}

void
NSNTiersListePatDialog::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
	const int 	BufLen = 255 ;
	static char buffer[BufLen] ;
	int 		    index ;
	static char libelBloqu[3] ;
	static char sexe[2] ;
	string 		  clef ;

	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;
	index = dispInfoItem.GetIndex() ;

	// Affiche les informations en fonction de la colonne

	switch (dispInfoItem.GetSubItem())
	{
  	case 1 : // date de naissance
    	if (((*pPatientsArray)[index])->donneDateNaiss() != "")
      {
      	sprintf(buffer, "%s", (((*pPatientsArray)[index])->donneDateNaiss()).c_str()) ;
        dispInfoItem.SetText(buffer) ;
      }
      break ;

    case 2 : // sexe
    	if (((*pPatientsArray)[index])->estMasculin())
      	strcpy(sexe, "M") ;
      else
      	strcpy(sexe, "F") ;
      dispInfoItem.SetText(sexe) ;

      break ;

    case 3 : // blocage : � faire
    	strcpy(libelBloqu, "  ") ;
      dispInfoItem.SetText(libelBloqu) ;
      break ;
	}
}

void
NSNTiersListePatDialog::InitPatArray()
{
	pPatientsArray->vider() ;

	bool listOk = false ;

	// le serviceName est d�fini dans le constructeur
	//on a une liste des patients
	serviceName = (NautilusPilot::SERV_PERSON_LIST_FROM_TRAITS).c_str() ;

	// on r�cup�re le nom et le pr�nom pour les passer comme traits au service
  //
  nomPat[0] = '\0' ;
  if (pUseNom->GetCheck() == BF_CHECKED)
		pNom->GetText(nomPat, PAT_NOM_LEN + 1) ;

  prenomPat[0] = '\0' ;
  if (pUsePrenom->GetCheck() == BF_CHECKED)
		pPrenom->GetText(prenomPat, PAT_PRENOM_LEN + 1) ;

  pCode->GetText(codePat, PAT_CODE_LEN + 1) ;

	if ((strcmp(nomPat, "") == 0) && (strcmp(prenomPat, "") == 0) && (strcmp(codePat, "") == 0))
		serviceName = (NautilusPilot::SERV_PATIENT_LIST).c_str() ;
	//else if ((strcmp(nomPat, "") != 0) && (IsCharAlpha(nomPat[strlen(nomPat) - 1])))
	//	strcat(nomPat, "*");
	//else if ((strcmp(prenomPat, "") != 0) && (IsCharAlpha(prenomPat[strlen(prenomPat) - 1])))
	//	strcat(prenomPat, "*");

  string sNomToCall    = string("") ;
  string sPrenomToCall = string("") ;
  string sCodeToCall   = string("") ;

	//on a une liste des patients
	NSPersonsAttributesArray PatiensList ;
	NSBasicAttributeArray    AttrArray ;

	AttrArray.push_back(new NSBasicAttribute(ROLE, PATIENT_ROLE)) ;
	if ((prenomPat) && (string(prenomPat) != ""))
	{
		prepareString(prenomPat) ;
    sPrenomToCall = string(prenomPat) ;

    if ((pStartByButton->GetCheck() == BF_CHECKED) && (sPrenomToCall != ""))
    {
    	if ((sPrenomToCall == "") || (sPrenomToCall[strlen(sPrenomToCall.c_str())-1] != '%'))
      	sPrenomToCall += string("%") ;
    }

		AttrArray.push_back(new NSBasicAttribute(FIRST_NAME, sPrenomToCall)) ;
	}
	if (nomPat)
	{
    if (string(nomPat) != "")
			prepareString(nomPat) ;
    sNomToCall = string(nomPat) ;

    // Recherche exacte ou recherche approch�e
  	//
  	if (pStartByButton->GetCheck() == BF_CHECKED)
    {
    	if ((sNomToCall == "") || (sNomToCall[strlen(sNomToCall.c_str())-1] != '%'))
      	sNomToCall += string("%") ;
    }
		AttrArray.push_back(new NSBasicAttribute(LAST_NAME, sNomToCall)) ;
	}

  if ('\0' != codePat[0])
  {
  	prepareString(codePat) ;
    sCodeToCall = string(codePat) ;

    if (string("") != pContexte->getSuperviseur()->getIppSite())
    	AttrArray.push_back(new NSBasicAttribute(IPP, sCodeToCall)) ;
    else
    	AttrArray.push_back(new NSBasicAttribute(LIDEN, sCodeToCall)) ;
  }

  if ((sNomToCall == string("")) && (sPrenomToCall == string("")) && (sCodeToCall == string("")))
		return ;

	AttrArray.push_back(new NSBasicAttribute(TRAIT, FIRST_NAME)) ;
	AttrArray.push_back(new NSBasicAttribute(TRAIT, LAST_NAME)) ;
	AttrArray.push_back(new NSBasicAttribute(TRAIT, SEX)) ;
	AttrArray.push_back(new NSBasicAttribute(TRAIT, BIRTHDATE)) ;

	listOk = pContexte->pPilot->personList(serviceName, &PatiensList, &AttrArray) ;
	//if ((!res) || (pPatiensList->empty()))
	if (!listOk)
	{
		std::string tempMessage = pContexte->pPilot->getWarningMessage() ;
		std::string tempError = pContexte->pPilot->getErrorMessage() ;
		if( tempMessage != "")
			::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
		if( tempError != "")
			::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
		return ;
	}

  if (!(PatiensList.empty()))
		for (NSPersonsAttributeIter iterPatient = PatiensList.begin(); iterPatient != PatiensList.end(); iterPatient++)
		{
			NSPatInfo *pPatientEnCours = new NSPatInfo(*iterPatient, pContexte) ;
			pPatientsArray->push_back(pPatientEnCours) ;
		}

  sortByName() ;
}

void
NSNTiersListePatDialog::Rechercher()
{
	KillTimer(ID_PAT_TIMER) ;
	pContexte->GetMainWindow()->SetCursor(0, IDC_WAIT) ;

	// Initialisation du tableau des patients
	InitPatArray() ;

	pContexte->GetMainWindow()->SetCursor(0, IDC_ARROW) ;

	// Affichage de la liste
	AfficheListe() ;

  // Select first patient in the list, so that <Enter> can have her get open
  int iCount = pListe->GetItemCount() ;
  if (iCount > 0)
  	pListe->SetSel(0, true) ;

//	TWindow* pWnd = ChildWithId(IDC_LISTPA_OUVRIR) ;
//  if (NULL != pWnd)
//		SetControlFocus(pWnd->HWindow) ;
}

void
NSNTiersListePatDialog::Creer()
{
try
{
	string sNomPat, sPrenomPat, sCodePat ;
	// int idRet ;

  bool bAPatientAlreadyThere = true ;
  if (!(pContexte->getPatient()))
  	bAPatientAlreadyThere = false ;

  pNom->GetText(nomPat,       PAT_NOM_LEN + 1) ;
  sNomPat     = string(nomPat) ;
  pPrenom->GetText(prenomPat, PAT_PRENOM_LEN + 1) ;
  sPrenomPat  = string(prenomPat) ;
  pCode->GetText(codePat,     PAT_CODE_LEN + 1) ;
  sCodePat    = string(codePat) ;

  // on enl�ve les blancs terminaux des nom et pr�nom
  strip(sNomPat,    stripRight) ;
  strip(sPrenomPat, stripRight) ;
  strip(sCodePat,   stripRight) ;
  strcpy(nomPat,    sNomPat.c_str()) ;
  strcpy(prenomPat, sPrenomPat.c_str()) ;
  strcpy(codePat,   sCodePat.c_str()) ;

/*
  // First, we check if this patient doesn't already exist
  //
  NSPersonsAttributesArray PatiensList ;
	NSBasicAttributeArray    AttrArray ;

  AttrArray.push_back(new NSBasicAttribute(ROLE, PATIENT_ROLE)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, FIRST_NAME)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, LAST_NAME)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, SEX)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, BIRTHDATE)) ;
    // pAttrArray->push_back(new NSBasicAttribute(OPERATOR, user)) ;
    // pAttrArray->push_back(new NSBasicAttribute(CONSOLE, console)) ;
    // pAttrArray->push_back(new NSBasicAttribute(INSTANCE, string(szInstance))) ;

    bool res = pContexte->pPilot->personList(NautilusPilot::SERV_PERSON_LIST_FROM_TRAITS.c_str(), &PatiensList, &AttrArray) ;
    if (!res)
    {
      string tempMessage = pContexte->pPilot->getWarningMessage() ;
      string tempError = pContexte->pPilot->getErrorMessage() ;
      if (tempMessage != "")
        ::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
      if (tempError != "")
        ::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
      return ;
    }

    if (!PatiensList.empty())
    {
      // cas d'erreur : le patient que l'on veut importer a d�j� le m�me IPP en local
      erreur("Importation impossible : un patient d�tenant le m�me IPP que le patient s�lectionn� sur le SIH existe d�j� en local.", standardError, 0) ;
      return ;
    }
*/

  // on enregistre les donn�es pr�sentes � l'�cran dans les variables li�es � la capture

  NSSuper *pSuper = pContexte->getSuperviseur() ;
  // 1. cas o� il y a d�j� des donn�es dans les variables de capture
  //    on v�rifie que ce ne sont pas les m�mes
  //    si c'est les m�mes, on laisse tel quel
  if      ((pSuper->getEpisodus() != NULL) && (!(pSuper->getEpisodus()->newCaptureArray.empty())))
  {
    NSCaptureArray* pNewCaptureArray = &(pSuper->getEpisodus()->newCaptureArray) ;

    bool  bAlreadyNameCaptured      = false ;
    bool  bAlreadyFirstNameCaptured = false ;

    // on regarde si on est dans le cas d'une capture : on v�rifie que le nom
    for (CaptureIter captIter = pNewCaptureArray->begin() ; captIter != pNewCaptureArray->end() ; captIter++)
    {
    	if (((*captIter)->sChemin == "ZADMI1/LIDET1/LNOM01") && ((*captIter)->sLibelle == sNomPat))
      	bAlreadyNameCaptured      = true ;
      if (((*captIter)->sChemin == "ZADMI1/LIDET1/LNOM21") && ((*captIter)->sLibelle == sPrenomPat))
      	bAlreadyFirstNameCaptured = true ;
    }

    if (!bAlreadyNameCaptured || !bAlreadyFirstNameCaptured)
    {
    	// pSuper->pEpisodus->CaptureArray.vider() ;

#ifndef _EXT_CAPTURE
			pNewCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM01", sNomPat)) ;
      pNewCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM21", sPrenomPat)) ;
      pNewCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LCODO1", sCodePat)) ;
#else
			pNewCaptureArray->ajouter(new NSCapture("ZADMI1/LIDET1/LNOM01", sNomPat)) ;
      pNewCaptureArray->ajouter(new NSCapture("ZADMI1/LIDET1/LNOM21", sPrenomPat)) ;
      pNewCaptureArray->ajouter(new NSCapture("ZADMI1/LIDET1/LCODO1", sCodePat)) ;
#endif

			//pSuper->pEpisodus->CaptureArray.push_back(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM01", sNomPat)) ;
      //pSuper->pEpisodus->CaptureArray.push_back(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM21", sPrenomPat)) ;
      //pSuper->pEpisodus->CaptureArray.push_back(new NSCapture(pContexte, "ZADMI1/LIDET1/LCODO1", sCodePat)) ;
		}
  }

  // 2. il n'y a pas de donn�es dans les variables de capture, on met les donn�es actuelles
  else if (pSuper->getEpisodus() != NULL)
  {
    NSCaptureArray* pNewCaptureArray = &(pSuper->getEpisodus()->newCaptureArray) ;

#ifndef _EXT_CAPTURE
		pNewCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM01", sNomPat)) ;
    pNewCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM21", sPrenomPat)) ;
    pNewCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LCODO1", sCodePat)) ;
#else
		pNewCaptureArray->ajouter(new NSCapture("ZADMI1/LIDET1/LNOM01", sNomPat)) ;
    pNewCaptureArray->ajouter(new NSCapture("ZADMI1/LIDET1/LNOM21", sPrenomPat)) ;
    pNewCaptureArray->ajouter(new NSCapture("ZADMI1/LIDET1/LCODO1", sCodePat)) ;
#endif

		//pSuper->pEpisodus->CaptureArray.push_back(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM01", sNomPat)) ;
    //pSuper->pEpisodus->CaptureArray.push_back(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM21", sPrenomPat)) ;
    //pSuper->pEpisodus->CaptureArray.push_back(new NSCapture(pContexte, "ZADMI1/LIDET1/LCODO1", sCodePat)) ;
  }

  // S'il n'y a pas de patient en cours, on swappe newCaptureArray et
  // CaptureArray (s'il y a un patient en cours, c'est fait dans
  // NSEpisodus::PatChanged()
  //
  if (!bAPatientAlreadyThere)
  {
  	// pSuper->getEpisodus()->CaptureArray.vider() ;
    // pSuper->getEpisodus()->CaptureArray.append(&(pSuper->getEpisodus()->newCaptureArray)) ;
    // pSuper->getEpisodus()->newCaptureArray.vider() ;
#ifdef _IN_EXE
		pSuper->getEpisodus()->PutNewCaptureInTank(true /*bEmptyTankFirst*/, true /*bool bResetNew*/) ;
#endif
  }

  // on lance l'archetype de cr�ation de patient (voir nom dans nsarc.h)
  pContexte->getSuperviseur()->BbkAskUser(pSuper->getDemographicArchetypeId(), pContexte, NSCQDocument::creatpat) ;
  CloseWindow(IDCANCEL) ;
}
catch (...)
{
	erreur("Exception NSNTiersListePatDialog::Creer", standardError, 0) ;
}
}

void
NSNTiersListePatDialog::GardeNss(int index)
{
	sNssSelect = ((*pPatientsArray)[index])->getNss();
}

void
NSNTiersListePatDialog::RetrouvePatSelect()
{
	for (int i = 0; i < nbNom; i++)
		if (sNssSelect == ((*pPatientsArray)[i])->getNss())
    {    	pListe->SetSel(i, false) ;
      break;
    }
}

void
NSNTiersListePatDialog::nameActiver(WPARAM wParam)
{
	switch (wParam)
	{
		case (IDC_USENOM) :
    	if (pUseNom->GetCheck() == BF_CHECKED)
      	pUseNom->Uncheck() ;
      else
      	pUseNom->Check() ;
      break ;
    case (IDC_USEPRENOM) :
    	if (pUsePrenom->GetCheck() == BF_CHECKED)
      	pUsePrenom->Uncheck() ;
      else
      	pUsePrenom->Check() ;
      break ;
	}

	char szNomPat[PAT_NOM_LEN + 1] ;
	pNom->GetText(szNomPat, PAT_NOM_LEN + 1) ;
  
  if (szNomPat[0] != '\0')
  	Rechercher() ;
}

bool
NSNTiersListePatDialog::CanClose()
{
	return TDialog::CanClose() ;
}

voidNSNTiersListePatDialog::CmOk(){try{
	int index = pListe->IndexItemSelect() ;
  if (index == -1)
  {
  	// erreur("Vous devez s�lectionner un patient dans la liste.",0,0,GetHandle());
    string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "PatientNotSelected") ;
    erreur(sErrorText.c_str(), warningError, standardError, 0) ;
    return ;
  }

  *pPatEnCours = *((*pPatientsArray)[index]) ;

  // In order to select a patient without trying to load her data
  // (by example in order to repair the record)
  //
  if (true == _bDontEvenTryToOpen)
  {
    CloseWindow(IDOK) ;
    return ;
  }

  char szPerson[PAT_NSS_LEN + 1] ;
  strcpy(szPerson, ((*pPatientsArray)[index])->getszNss()) ;

  string ps = string("Opening a new patient: Id ") + string(szPerson) ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSteps) ;

  if ((szPerson[0] != LocalPatient) && (pContexte->getUtilisateur()->haveGlobalSessionPassword() == false))
  {
  	LogPassInterface* getGlobPassword = new LogPassInterface(this, pContexte) ;
    getGlobPassword->Execute() ;
    delete getGlobPassword ;
  }

  char szInstance[3] ;
  int iInstance = pContexte->getSuperviseur()->getInstance() ;
  itoa(iInstance, szInstance, 10) ;

  SetCursor(0, IDC_WAIT) ;
  // pContexte->setPatient(new NSPatientChoisi(pContexte));
  string user = pContexte->getUtilisateurID() ;

  NSBasicAttributeArray    AttrArray ;
  NSPersonsAttributesArray List ;

  // ouverture standard
  AttrArray.push_back(new NSBasicAttribute(PERSON , string(szPerson))) ;
  AttrArray.push_back(new NSBasicAttribute(OPERATOR , user)) ;
  AttrArray.push_back(new NSBasicAttribute(CONSOLE , string(pContexte->getSuperviseur()->getConsole()))) ;
  AttrArray.push_back(new NSBasicAttribute(INSTANCE , string(szInstance))) ;

  ps = string("Calling Pilot service \"searchPatient\"") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

  bool res = pContexte->pPilot->searchPatient(NautilusPilot::SERV_SEARCH_PATIENT.c_str(),
                                    pPatEnCours->pGraphPerson->pDataGraph, &List, &AttrArray) ;
  if (false == res)
  {
  	std::string tempMessage = pContexte->pPilot->getWarningMessage() ;
    std::string tempError   = pContexte->pPilot->getErrorMessage() ;
    if (string("") != tempMessage)
    {
      pContexte->getSuperviseur()->trace(&tempMessage, 1, NSSuper::trWarning) ;
    	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
    }
    if (string("") != tempError)
    {
      pContexte->getSuperviseur()->trace(&tempError, 1, NSSuper::trError) ;
    	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
    }
    return ;
  }

	if ((NULL == pPatEnCours->pGraphPerson->pDataGraph) ||
    	(false == pPatEnCours->pGraphPerson->graphPrepare()))
  {
    if (NULL == pPatEnCours->pGraphPerson->pDataGraph)
      ps = string("Empty graph.") ;
    else
      ps = string("Failure of the graphPrepare function.") ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trWarning) ;
		return ;
  }

	pPatEnCours->pGraphPerson->bNeedUnlock = false ;
	pPatEnCours->pGraphPerson->bReadOnly 	 = true ;

	if (false == List.empty())
	{
		string sIsLocked = List.getAttributeValue("locked") ;
		if (sIsLocked == "ok")
			pPatEnCours->pGraphPerson->bNeedUnlock = true ;
		string sOperationType	= List.getAttributeValue("operationType") ;
		if (sOperationType == "readWrite")
			pPatEnCours->pGraphPerson->bReadOnly = false ;
	}

  if (true == pPatEnCours->pGraphPerson->bReadOnly)
  {
    string sCaption = pContexte->getSuperviseur()->getAppName() ;
    string sWarnText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    MessageBox(sWarnText.c_str(), sCaption.c_str(), MB_OK) ;
  }

	pPatEnCours->pGraphPerson->setInfoPids(&AttrArray) ;
	pPatEnCours->pGraphPerson->pDataGraph->setLastTree() ;

	string sCodePat = pPatEnCours->pGraphPerson->getRootTree() ;
	// NSDataGraph* pGraph = pPatEnCours->pGraphPerson->pDataGraph;

	SetCursor(0, IDC_ARROW) ;

  ps = string("Closing the patient selection dialog.") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

	CloseWindow(IDOK) ;
}
catch (...)
{
	erreur("Exception NSNTiersListePatDialog::CmOk", standardError, 0) ;
}}voidNSNTiersListePatDialog::LVNColumnclick(TLwNotify& lwn)
{
  switch ( lwn.iSubItem )
  {
    case 0  : sortByName() ;      break ;
    case 1  : sortByBirthday() ;  break ;
    case 2  : sortBySex() ;       break ;
  }
}
voidNSNTiersListePatDialog::sortByName(bool bChangeOrder)
{
	if (iSortedColumn == 0)
	{
    if (bChangeOrder)
  	{
    	if (bNaturallySorted)
      	bNaturallySorted = false ;
    	else
      	bNaturallySorted = true ;
    }
	}
  else
  {
    iSortedColumn = 0 ;
    bNaturallySorted = true ;
  }

  if (pPatientsArray->empty())
    return ;

  if (bNaturallySorted)
    sort(pPatientsArray->begin(), pPatientsArray->end(), patSortByNameInf) ;
  else
    sort(pPatientsArray->begin(), pPatientsArray->end(), patSortByNameSup) ;

  AfficheListe() ;
}

void
NSNTiersListePatDialog::sortByBirthday()
{
  if (iSortedColumn == 0)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = 0 ;
    bNaturallySorted = true ;
  }

  if (pPatientsArray->empty())
    return ;

  if (bNaturallySorted)
    sort(pPatientsArray->begin(), pPatientsArray->end(), patSortByBirthInf) ;
  else
    sort(pPatientsArray->begin(), pPatientsArray->end(), patSortByBirthSup) ;

  AfficheListe() ;
}

void
NSNTiersListePatDialog::sortBySex()
{
  if (iSortedColumn == 0)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = 0 ;
    bNaturallySorted = true ;
  }

  if (pPatientsArray->empty())
    return ;

  if (bNaturallySorted)
    sort(pPatientsArray->begin(), pPatientsArray->end(), patSortBySexInf) ;
  else
    sort(pPatientsArray->begin(), pPatientsArray->end(), patSortBySexSup) ;

  AfficheListe() ;
}

void
NSNTiersListePatDialog::EvTimer(uint id)
{
	if (id != ID_PAT_TIMER)
		return ;

	// Searching patients from an empty string can be very time consuming, prevent it
  //
  char szNomPat[PAT_NOM_LEN + 1] ;
	pNom->GetText(szNomPat, PAT_NOM_LEN + 1) ;
  if (szNomPat[0] == '\0')
  {
  	char szCodePat[PAT_CODE_LEN + 1] ;
  	pCode->GetText(szCodePat, PAT_CODE_LEN + 1) ;
    if (szCodePat[0] == '\0')
  	{
  		pListe->DeleteAllItems() ;
			return ;
    }
	}

	Rechercher() ;
}

void
NSNTiersListePatDialog::resetTimer()
{
	KillTimer(ID_PAT_TIMER) ;
	SetTimer(ID_PAT_TIMER, 1000) ;
}

#endif // N_TIERS

// -----------------------------------------------------------------//
//  M�thodes de NSListePatDialog
//
// -----------------------------------------------------------------

// ---------------------------------------------------------------------------
/*

DEFINE_RESPONSE_TABLE1(NSListePatDialog, NSUtilDialog)    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_LVN_GETDISPINFO(IDC_LISTPA_LW, LvnGetDispInfo),
END_RESPONSE_TABLE;

NSListePatDialog::NSListePatDialog(TWindow* pere, NSContexte* pCtx, NSPids* pPat, char* cResId)
                 :NSUtilDialog(pere, pCtx, cResId)
{
try
{
	// Cr�ation de tous les "objets de contr�le"
	pNom 	    = new NSRechNomEdit(this, IDC_LISTPA_NOM, PAT_NOM_LEN);
	pPrenom     = new NSRechPreEdit(this, IDC_LISTPA_PRENOM, PAT_PRENOM_LEN);

    pListe 	    = new NSListPatWindow(this, pCtx, IDC_LISTPA_LW);
	pVScroll    = new NSLVScrollBar(this, IDC_LISTPA_VSCROLL);

    // on recup�re le patient en cours
	pPatEnCours = pPat;

    // on stocke le r�sultat de la recherche
    ErrDBI      = pPat->lastError;

    // Cr�ation du tableau de Patients
	pPatientsArray = new NSPatientArray;

    // nom et pr�nom initiaux
    strcpy(nomPat, "");
    strcpy(prenomPat, "");

	// Existe-t-il des donn�es de capture Episodus ?
	if (pContexte->getSuperviseur()->getEpisodus())
	{
		NSCaptureArray* pCapt = &(pContexte->getSuperviseur()->getEpisodus()->newCaptureArray) ;

        string sNom     = string("") ;
        string sPrenom  = string("") ;
        string sCode    = string("") ;

        pCapt->trouveChemin(string("LNOM01"), &sNom) ;
        pCapt->trouveChemin(string("LNOM21"), &sPrenom) ;
        pCapt->trouveChemin(string("LIDEN1"), &sCode) ;

        string sPatronyme = string("") ;
        pCapt->trouveChemin(string("LPATR1"), &sPatronyme) ;
        if (sPatronyme != "")
        {
            size_t i ;
            //
            // Recherche de la premi�re lettre non majuscule
            //
            for (i = 0; (i < strlen(sPatronyme.c_str())) &&
                    (sPatronyme[i] == pseumaj(sPatronyme[i])); i++) ;

            if (i < strlen(sPatronyme.c_str()))
            {
                if (i > 0)
                {
                    for (; (i > 0) && (sPatronyme[i] != ' '); i--) ;
                    if (i > 0)
                    {
                        sNom    = string(sPatronyme, 0, i) ;
                        sPrenom = string(sPatronyme, i+1, strlen(sPatronyme.c_str()) - i - 1) ;
                    }
                    else
                        sPrenom = sPatronyme ;
                }
                else
                    sPrenom = sPatronyme ;
            }
            else
                sNom = sPatronyme ;
        }

        if (strlen(sNom.c_str()) > PAT_NOM_LEN)
            sNom = string(sNom, 0, PAT_NOM_LEN) ;
        strcpy(nomPat, sNom.c_str()) ;

        if (strlen(sPrenom.c_str()) > PAT_PRENOM_LEN)
            sPrenom = string(sPrenom, 0, PAT_PRENOM_LEN) ;
        strcpy(prenomPat, sPrenom.c_str()) ;
    }

    sNssSelect = "" ;
    // Gestion du blocage patient    verifBloque  = false ;
    donneMessage = true ;
    pBloques = new NSBloques(pContexte) ;

    // fichiers d'aide
    pContexte->getSuperviseur()->setAideIndex("h_index.htm") ;
    pContexte->getSuperviseur()->setAideCorps("h_rchpat.htm") ;
}
catch (...)
{
    erreur("Exception NSListePatDialog ctor.", standardError, 0) ;
}
}

NSListePatDialog::~NSListePatDialog(){
	delete pNom;
	delete pPrenom;
	delete pVScroll;
    delete pListe;
    delete pPatientsArray;
    delete pBloques;

    pPatEnCours->detruireBookMarks(2);
}

//---------------------------------------------------------------------------
//  Function: NSListePatDialog::SetupWindow()
//
//  Arguments:	  Aucun
//
//  Description: Initialise la boite de dialogue
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListePatDialog::SetupWindow()
{
	TDialog::SetupWindow();

    pNom->SetText(nomPat);
    pPrenom->SetText(prenomPat);

    // Cr�ation de 2 BookMarks
	pPatEnCours->creerBookMarks(2);

    // Positionnement du patient en fin de fichier
    PosLastPatient();

    // Initialisation du tableau des patients et des bookmarks
    InitPatArray();

    // Initialisation de la liste
    InitListe();
    AfficheListe();

    // Ouverture du fichier des blocages
    pBloques->lastError = pBloques->open();
    if (pBloques->lastError == DBIERR_NONE)
   	    verifBloque = true;
}

//---------------------------------------------------------------------------//  Function: NSListePatDialog::InitListe()
//
//  Arguments:	  Aucun
//
//  Description: Initialise la ListWindow avec ses colonnes
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListePatDialog::InitListe()
{
    TListWindColumn colPatient("Patient", 200, TListWindColumn::Left, 0);
  	pListe->InsertColumn(0, colPatient);

  	TListWindColumn colDateN("Date Naiss", 80, TListWindColumn::Left, 1);  	pListe->InsertColumn(1, colDateN);

    TListWindColumn colSexe("Sexe", 40, TListWindColumn::Left, 2);
  	pListe->InsertColumn(2, colSexe);

    TListWindColumn colBloque("Bloqu�", 50, TListWindColumn::Left, 3);  	pListe->InsertColumn(3, colBloque);
}
//---------------------------------------------------------------------------//  Function: NSListePatDialog::AfficheListe(int decal)
//
//  Arguments:	  Aucun
//
//  Description: Affiche le tableau de patients dans la liste
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListePatDialog::AfficheListe()
{
    // On vide la liste
    //
#ifndef _MUE
    const int BufLen = 255;
    static char buffer[BufLen];
#endif
	pListe->DeleteAllItems();

    PatientReverseIter iterReverse = pPatientsArray->rbegin() ;
  	//  for(iterReverse; iterReverse != pPatientsArray->rend(); iterReverse++)
    while(iterReverse != pPatientsArray->rend())
    {
#ifndef _MUE
        sprintf(buffer, "%s %s", (*iterReverse)->pDonnees->nom, (*iterReverse)->pDonnees->prenom);
        TListWindItem Item(buffer, 0);
#else
        string sNomLong  = string((*iterReverse)->getszNom()) + string(" ") + string((*iterReverse)->getszPrenom()) ;
       // sprintf(buffer, "%s %s", ((*iterReverse)->getszNom(), (*iterReverse)->getszPrenom()));
        TListWindItem Item(sNomLong.c_str(), 0);
#endif

        pListe->InsertItem(Item);
        iterReverse++;
    }

    pListe->ShowScrollBar(SB_VERT, FALSE);
}

//// Callback notification to handle additional column information
// for each item.
// Dans ce cas, ajoute le pr�nom et la date de naissance
//
void
NSListePatDialog::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
    const int 	   BufLen = 255;
    static char    buffer[BufLen];
    int 		   index;
    static char    libelBloqu[3];
    static char    sexe[2];
    string 		   clef;

    TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item;
    index = dispInfoItem.GetIndex();

    // Affiche les informations en fonction de la colonne

	switch (dispInfoItem.GetSubItem())
  	{
   	    case 1 : // date de naissance
            if (((*pPatientsArray)[index])->donneDateNaiss() != "")
            {
      	        sprintf(buffer, "%s", (((*pPatientsArray)[index])->donneDateNaiss()).c_str());
        	    dispInfoItem.SetText(buffer);
            }
        	break;

        case 2 : // sexe
            if (((*pPatientsArray)[index])->estMasculin())
                strcpy(sexe, "M");
            else
                strcpy(sexe, "F");
            dispInfoItem.SetText(sexe);

            break;

   	    case 3 : // blocage
      	    strcpy(libelBloqu, "  ");

      	    if (verifBloque)
      	    {
#ifndef _MUE
         	    clef = string(((*pPatientsArray)[index])->pDonnees->nss);#else                clef = ((*pPatientsArray)[index])->getNss();#endif      		    pBloques->lastError = pBloques->chercheClef(&clef,
                                                            "",
                                                            0,
                                                            keySEARCHEQ,
                                                            dbiWRITELOCK);
   			    if (pBloques->lastError == DBIERR_NONE)
   			    {
   				    pBloques->lastError = pBloques->getRecord();
   				    if ((pBloques->lastError != DBIERR_NONE) && donneMessage)
            	    {
   					    erreur("Le fichier des blocages est d�fectueux.", standardError, pBloques->lastError, GetHandle());
               	        donneMessage = false;
            	    }
            	    else
            		    strcpy(libelBloqu, pBloques->pDonnees->console);
                }
      	    }
      	    //sprintf(buffer, "%s", ((*pPatientsArray)[index])->pDonnees->nom_long);
      	    dispInfoItem.SetText(libelBloqu);
      	    break;
    }
}

//---------------------------------------------------------------------------//  Function: NSListePatDialog::InitPatArray()
//
//  Arguments:	  Aucun
//
//  Description: Initialise le tableau de patients et les bookmarks
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListePatDialog::InitPatArray()
{
	pPatientsArray->vider();

	// Mise en place du 1er BookMark sur la premi�re fiche
	pPatEnCours->placeBookMark(1);
	pVScroll->PositionneCurseur();

	// Initialisation du tableau de patients


	for (int i = 0; i < nbNom; i++)
	{
		pPatEnCours->alimenteFiche();
		pPatientsArray->push_back(new NSPatInfo(pPatEnCours));
		if (i < nbNom - 1)
			pPatEnCours->suivant(dbiWRITELOCK);
	}

	// Mise en place du 2nd BookMark sur la derni�re fiche
	pPatEnCours->placeBookMark(2);
}

//---------------------------------------------------------------------------
//  Function: NSListePatDialog::PosLastPatient()
//
//  Arguments:	  Aucun
//
//  Description: Positionne le pPatEnCours en fonction de la fin de la table
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListePatDialog::PosLastPatient()
{
    int    		nbPrec = 0, limiteSup, totalRec, currentRec;
    int 		NombreTotal, NumEnCours;
    int	 		nbAffListe = 13;	// Nombre de patients affich�s dans la liste
    								// Note : on a 14 - 1 patients affich�s � cause
                                    // de la scroll bar horizontale (due au champ Bloqu�)

    // Calcul du nombre de noms affich�s
    pPatEnCours->donneNbTotalRec(&NombreTotal);
    totalRec = NombreTotal;
    if (totalRec < nbAffListe)
    {
   	    nbNom = NombreTotal;
        bVScroll = false;
    }
    else
    {
   	    nbNom = nbAffListe;
        bVScroll = true;
    }

    // dimensionnement de la scroll bar
    pVScroll->FixeRange(NombreTotal,nbNom);

    // Calcul du nombre de pr�c�dents
    /////////////////////////////////////////////////////////////
    limiteSup = totalRec - nbNom + 1;

    // on teste le r�sultat de la recherche pr�c�dente
    if (ErrDBI == DBIERR_EOF)
    {
   	    nbPrec = nbNom;
        ErrDBI = DBIERR_NONE;
    }
    else // cas DBIERR_NONE
    {
        pPatEnCours->donneNumRecEnCours(&NumEnCours);
        currentRec = NumEnCours;
        if (currentRec > limiteSup)
      	    nbPrec = currentRec - limiteSup;
    }

    for (int i = 0; (i < nbPrec) && (ErrDBI == DBIERR_NONE); i++)
   	    ErrDBI = pPatEnCours->precedent(dbiWRITELOCK);

    if ((ErrDBI != DBIERR_NONE) && (ErrDBI != DBIERR_BOF))
		erreur("Erreur de positionnement dans la base des patients.", standardError, ErrDBI, GetHandle());
}

//---------------------------------------------------------------------------//  Function: NSListePatDialog::ScrollPatient()
//
//  Arguments:	  Aucun
//
//  Description: Scrolle la liste en fonction du nom et du prenom
//
//  Returns:     Rien
//---------------------------------------------------------------------------

void
NSListePatDialog::ScrollPatient()
{
	DBIResult ErrDBI;
    CURProps curProps;
    Byte* pIndexRec;

    pNom->GetText(nomPat, PAT_NOM_LEN + 1);
    pPrenom->GetText(prenomPat, PAT_PRENOM_LEN + 1);

    ErrDBI = DbiGetCursorProps(pPatEnCours->PrendCurseur(), curProps);    pIndexRec = new Byte[curProps.iRecBufSize];
    memset(pIndexRec, 0, curProps.iRecBufSize);

#ifndef _MUE
    DbiPutField(pPatEnCours->PrendCurseur(), PAT_NOM_FIELD, 	  pIndexRec, (Byte*)nomPat);    DbiPutField(pPatEnCours->PrendCurseur(), PAT_PRENOM_FIELD, pIndexRec, (Byte*)prenomPat);
#else
    DbiPutField(pPatEnCours->PrendCurseur(), PIDS_NOM_FIELD, 	  pIndexRec, (Byte*)nomPat);
    DbiPutField(pPatEnCours->PrendCurseur(), PIDS_PRENOM_FIELD, pIndexRec, (Byte*)prenomPat);
#endif
    ErrDBI = pPatEnCours->chercheClefComposite("NOM_PRENOM",
  												NODEFAULTINDEX,
 												keySEARCHGEQ,
												dbiWRITELOCK,
                              	                pIndexRec);
    delete[] pIndexRec;

    if ((ErrDBI != DBIERR_NONE) && (ErrDBI != DBIERR_EOF))
		erreur("Erreur de positionnement dans la base des patients.", standardError, ErrDBI, GetHandle());

    // On replace les BookMarks et on re-remplit le tableau des patients
    PosLastPatient();
    InitPatArray();
    AfficheListe();
    RetrouvePatSelect();

    // **************** en mode N_TIERS
    int index = 0;
    string sNom, sPrenom;

    pNom->GetText(nomPat, PAT_NOM_LEN + 1);
    pPrenom->GetText(prenomPat, PAT_PRENOM_LEN + 1);
    pseumaj(nomPat);
    pseumaj(prenomPat);

    if ((strlen(nomPat) == 0) && (strlen(prenomPat) == 0))
        return;

    for (PatientIter i = pPatientsArray->begin(); i != pPatientsArray->end(); i++)
    {
        sNom = (*i)->getNom();
        sPrenom = (*i)->getPrenom();
        pseumaj(&sNom);
        pseumaj(&sPrenom);

        if ((strncmp(nomPat, sNom.c_str(), strlen(nomPat)) <= 0) &&
            (strncmp(prenomPat, sPrenom.c_str(), strlen(prenomPat)) <= 0))
        {
            pListe->SetSel(index, true);
            pListe->EnsureVisible(index, true);
            break;
        }

        index++;
    }
	// ***************************************************************************
}

//---------------------------------------------------------------------------
//  Function: NSListePatDialog::GardeNss(int index)
//
//  Arguments:	  Index du patient s�lectionn�
//
//  Description: Conserve le nss du patient s�lectionn�
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListePatDialog::GardeNss(int index)
{
#ifndef _MUE
	sNssSelect = string(((*pPatientsArray)[index])->pDonnees->nss);#else    sNssSelect = ((*pPatientsArray)[index])->getNss();#endif
}
//---------------------------------------------------------------------------//  Function: NSListePatDialog::RetrouvePatSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retrouve le patient s�lectionn�
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListePatDialog::RetrouvePatSelect()
{
	for (int i = 0; i < nbNom; i++)
    {
#ifndef _MUE
   	    if (sNssSelect == string(((*pPatientsArray)[i])->pDonnees->nss))#else        if (sNssSelect == ((*pPatientsArray)[i])->getNss())#endif        {
      	    pListe->SetSel(i, true);
            break;
        }
    }
}

//---------------------------------------------------------------------------
//  Function: NSListePatDialog::LineDown()
//
//  Arguments:	  Aucun
//
//  Description: G�re le d�filement de la liste d'une ligne vers le bas
//
//  Returns:     True->Ok False->Echec
//---------------------------------------------------------------------------
bool
NSListePatDialog::LineDown()
{
#ifndef N_TIERS
	DBIResult ErrDBI;

    if (!bVScroll)        return false;

	// Replacement sur le 2nd BookMark
	pPatEnCours->retrouveBookMark(2);

	// Positionnement sur la fiche suivante
	// et sortie imm�diate si la fiche suivante n'existe pas
    ErrDBI = pPatEnCours->suivant(dbiWRITELOCK);
	if (ErrDBI != DBIERR_NONE)
    {
   	    if (ErrDBI != DBIERR_EOF)
      	    erreur("Erreur d'acc�s au patient suivant.", 0, ErrDBI, GetHandle());
		return false;
    }

	pPatEnCours->placeBookMark(2);

	// Mise � jour de pPatientsArray
	pPatEnCours->alimenteFiche();
#ifndef _MUE
	pPatEnCours->pDonnees->fabriqueNomLong();#endif
    pPatientsArray->erase(pPatientsArray->begin());	pPatientsArray->push_back(new NSPatInfo(pPatEnCours) );
	AfficheListe();
    RetrouvePatSelect();

	// Repositionnement du 1er BookMark
	pPatEnCours->retrouveBookMark(1);
	pPatEnCours->suivant(dbiWRITELOCK);
	pPatEnCours->placeBookMark(1);

	// pVScroll->PositionneCurseur();
#else
    // bool listOk = false;

    // **********************************************
    //on a une liste des patients
    NSPersonsAttributesArray *pPatiensList = new NSPersonsAttributesArray();
    NSBasicAttributeArray *pAttrArray =  new NSBasicAttributeArray();
    pAttrArray->push_back(new NSBasicAttribute(STEP , string("1000")));
    listOk = pContexte->pPilot->personList(serviceName, pPatiensList,pAttrArray);
    delete pAttrArray;
    if (listOk)
        for (NSPersonsAttributeIter iterPatient = pPatiensList->begin(); iterPatient != pPatiensList->end(); iterPatient++)
        {
            NSPatInfo *pPatEnCours = new NSPatInfo(*iterPatient, pContexte);
            pPatientsArray->push_back(new NSPatInfo(*pPatEnCours));
        }
    AfficheListe();
    delete pPatiensList ;
    // *************************************************
#endif

    return true;
}

//---------------------------------------------------------------------------
//  Function: NSListePatDialog::LineUp()
//
//  Arguments:	  Aucun
//
//  Description: G�re le d�filement de la liste d'une ligne vers le haut
//
//  Returns:     Rien
//---------------------------------------------------------------------------
bool
NSListePatDialog::LineUp()
{
#ifndef N_TIERS
    DBIResult ErrDBI;

    if (!bVScroll) return false;

	// Replacement sur le 1er BookMark
	pPatEnCours->retrouveBookMark(1);

	// Positionnement sur la fiche pr�c�dente
	// et sortie imm�diate si la fiche pr�c�dente n'existe pas
    ErrDBI = pPatEnCours->precedent(dbiWRITELOCK);
	if (ErrDBI != DBIERR_NONE)
	{
   	    if (ErrDBI != DBIERR_BOF)
      	    erreur("Erreur d'acc�s au patient pr�c�dent.", 0, ErrDBI, GetHandle());
		return false;
    }

	pPatEnCours->placeBookMark(1);

	// pVScroll->PositionneCurseur();

	// Mise � jour de pPatientsArray
	pPatEnCours->alimenteFiche();
#ifndef _MUE
	pPatEnCours->pDonnees->fabriqueNomLong();#endif    // insertion au debut du vecteur
	pPatientsArray->insert(pPatientsArray->begin(),new NSPatInfo(pPatEnCours));
    pPatientsArray->pop_back();
	AfficheListe();
    RetrouvePatSelect();

	// Repositionnement du 2nd BookMark
	pPatEnCours->retrouveBookMark(2);
	pPatEnCours->precedent(dbiWRITELOCK);
	pPatEnCours->placeBookMark(2);
#else
     //ici il faut introduire le code pour avance vers le debut
#endif
    return true;
}

//-------------------------------------------------------------------------
//  CanClose()
//  R�pond � OK. Positionne le patient sur le patient s�lectionn�.
//---------------------------------------------------------------------------
bool
NSListePatDialog::CanClose()
{
    // Fermeture du fichier de blocage
    //
	pBloques->close();

    return TDialog::CanClose();
}

//-------------------------------------------------------------------------
//  CmOk()
//  R�pond � OK. Positionne le patient sur le patient s�lectionn�.
//---------------------------------------------------------------------------
void
NSListePatDialog::CmOk()
{
try
{
	DBIResult ErrDBI;
    int 	  index;

    index = pListe->IndexItemSelect();

    if (index == -1)
    {
        erreur("Vous devez s�lectionner un patient dans la liste.", warningError, 0, GetHandle());
        return;
    }

	//
	// Positionnement sur la fiche active
	//
    char szClef[PAT_NSS_LEN + 1];
#ifndef _MUE
    strcpy(szClef, ((*pPatientsArray)[index])->pDonnees->nss);
#else
    strcpy(szClef, ((*pPatientsArray)[index])->getszNss());
#endif

	ErrDBI = pPatEnCours->chercheClef((unsigned char*) szClef,
												 "",
												 0,
												 keySEARCHEQ,
												 dbiWRITELOCK);
    if (ErrDBI == DBIERR_NONE)
		CloseWindow(IDOK);
    else
    {
   	    erreur("Erreur � la recherche du patient s�lectionn�.", standardError, ErrDBI, GetHandle());
        CloseWindow(IDCANCEL);
    }
}
catch (...)
{
	erreur("Exception NSListePatDialog::CmOk", standardError, 0) ;
}
}

*/

// -----------------------------------------------------------------//
//  M�thodes de ChercheListePatDialog
//
// -----------------------------------------------------------------

/*

// ---------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(ChercheListePatDialog, NSListePatDialog)
	EV_COMMAND(IDC_LISTPA_CREER, CmCreer),
END_RESPONSE_TABLE;

ChercheListePatDialog::ChercheListePatDialog(TWindow* pere, NSContexte* pCtx, NSPids* pPat)
                      :NSListePatDialog(pere, pCtx, pPat, "IDD_LISTPA")
{
	// Cr�ation de tous les "objets de contr�le" (suppl�mentaires)
	pNum        = new NSRechNumEdit(this, IDC_LISTPA_NUMERO, PAT_NSS_LEN);
	pCode       = new NSRechCodeEdit(this, IDC_LISTPA_CODE, PAT_CODE_LEN);
	pCreer      = new TStatic(this, IDC_LISTPA_CREER);

	bPatientCree = false;

	// Existe-t-il des donn�es de capture Episodus ?
	if (pContexte->getSuperviseur()->getEpisodus())
	{
		NSCaptureArray* pCapt = &(pContexte->getSuperviseur()->getEpisodus()->newCaptureArray);

		string sCode    = string("") ;
		pCapt->trouveChemin(string("LIDEN1"), &sCode) ;

		if (strlen(sCode.c_str()) > PAT_CODE_LEN)
			sCode = string(sCode, 0, PAT_CODE_LEN);
		strcpy(codePat, sCode.c_str()) ;
	}
}

ChercheListePatDialog::~ChercheListePatDialog(){
	delete pNum ;
	delete pCode ;
	delete pCreer ;
}

//---------------------------------------------------------------------------//  Function: ChercheListePatDialog::SetupWindow()
//
//  Arguments:	  Aucun
//
//  Description: Initialise la boite de dialogue
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
ChercheListePatDialog::SetupWindow()
{
  // fichiers d'aide
	sHindex = "";
	sHcorps = "Patient.htm";
	NSListePatDialog::SetupWindow();
	pCode->SetText(codePat) ;

	::ShowWindow(GetDlgItem(IDC_LISTPA_CREER),      SW_SHOW) ;
	::EnableWindow(GetDlgItem(IDC_LISTPA_CREER),    TRUE) ;
	::ShowWindow(GetDlgItem(IDC_LISTPA_IMPORTER),   SW_HIDE) ;
	::EnableWindow(GetDlgItem(IDC_LISTPA_IMPORTER), FALSE) ;
}

// -----------------------------------------------------------------------------
// CmCreer()
// Pour cr�er un nouveau patient en tenant compte des nom et pr�nom saisis
// -----------------------------------------------------------------------------
void
ChercheListePatDialog::CmCreer()
{
try
{
  DBIResult   ErrDBI ;
  CURProps    curProps ;
  Byte        *pIndexRec ;
  string      sNomPat, sPrenomPat, sCodePat ;
  int         idRet ;

  bool        bAPatientAlreadyThere = true ;
  if (!(pContexte->getPatient()))
      bAPatientAlreadyThere = false ;

  pNom->GetText(nomPat,       PAT_NOM_LEN + 1) ;
  sNomPat     = string(nomPat) ;
  pPrenom->GetText(prenomPat, PAT_PRENOM_LEN + 1) ;
  sPrenomPat  = string(prenomPat) ;
  pCode->GetText(codePat,     PAT_CODE_LEN + 1) ;
  sCodePat    = string(codePat) ;

  // on enl�ve les blancs terminaux des nom et pr�nom
  strip(sNomPat,    stripRight) ;
  strip(sPrenomPat, stripRight) ;
  strip(sCodePat,   stripRight) ;
  strcpy(nomPat,    sNomPat.c_str()) ;
  strcpy(prenomPat, sPrenomPat.c_str()) ;
  strcpy(codePat,   sCodePat.c_str()) ;

  // on recherche ce patient dans la base pour v�rifier qu'il n'existe pas d�j�
  ErrDBI = DbiGetCursorProps(pPatEnCours->PrendCurseur(), curProps) ;
  pIndexRec = new Byte[curProps.iRecBufSize] ;
  memset(pIndexRec, 0, curProps.iRecBufSize) ;

	DbiPutField(pPatEnCours->PrendCurseur(), PIDS_NOM_FIELD,    pIndexRec, (Byte *)nomPat) ;
  DbiPutField(pPatEnCours->PrendCurseur(), PIDS_PRENOM_FIELD, pIndexRec, (Byte *)prenomPat) ;

    // on lance cette fois une recherche exacte
    ErrDBI = pPatEnCours->chercheClefComposite( "NOM_PRENOM",
                                              NODEFAULTINDEX,
                                              keySEARCHEQ,
                                              dbiWRITELOCK,
                                              pIndexRec) ;
    delete[] pIndexRec ;

    if (ErrDBI == DBIERR_NONE)
    {
        string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName() ;
        idRet = MessageBox("Attention ce patient existe d�j�. Voulez-vous tout de m�me cr�er ce patient ?", sCaption.c_str(), MB_YESNO) ;
        if (idRet == IDNO)
            return ;
    }
    else if (ErrDBI != DBIERR_RECNOTFOUND)
    {
        erreur("Erreur � la recherche dans la base patient.db", standardError, ErrDBI, GetHandle()) ;
        return ;
    }

#ifndef _MUE
    if (pPatEnCours->Creer(nomPat, prenomPat, codePat, this))    {
        // on positionne le booleen pour l'utilisateur choisi et on ferme la liste
        bPatientCree = true ;
        CloseWindow(IDOK) ;
    }
#else
    // on enregistre les donn�es pr�sentes � l'�cran dans les variables li�es � la capture

    NSSuper *pSuper = pContexte->getSuperviseur() ;
    // 1. cas o� il y a d�j� des donn�es dans les variables de capture
    //    on v�rifie que ce ne sont pas les m�mes
    //    si c'est les m�mes, on laisse tel quel
    if      ((pSuper->getEpisodus() != NULL) && (!(pSuper->getEpisodus()->newCaptureArray.empty())))
    {
			NSCaptureArray* pCapt = &(pContexte->getSuperviseur()->getEpisodus()->newCaptureArray) ;
        bool  bAlreadyNameCaptured      = false ;
        bool  bAlreadyFirstNameCaptured = false ;

        // on regarde si on est dans le cas d'une capture : on v�rifie que le nom
        for (CaptureIter captIter = pCapt->begin() ; captIter != pCapt->end() ; captIter++)
        {
            if (((*captIter)->sChemin == "ZADMI1/LIDET1/LNOM01") && ((*captIter)->sLibelle == sNomPat))
                bAlreadyNameCaptured      = true ;
            if (((*captIter)->sChemin == "ZADMI1/LIDET1/LNOM21") && ((*captIter)->sLibelle == sPrenomPat))
                bAlreadyFirstNameCaptured = true ;
        }

        if (!bAlreadyNameCaptured || !bAlreadyFirstNameCaptured)
        {
            // pSuper->pEpisodus->CaptureArray.vider() ;
#ifndef _EXT_CAPTURE
            pCapt->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM01", sNomPat)) ;
            pCapt->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM21", sPrenomPat)) ;
            pCapt->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LCODO1", sCodePat)) ;
#else
            pCapt->ajouter(new NSCapture("ZADMI1/LIDET1/LNOM01", sNomPat)) ;
            pCapt->ajouter(new NSCapture("ZADMI1/LIDET1/LNOM21", sPrenomPat)) ;
            pCapt->ajouter(new NSCapture("ZADMI1/LIDET1/LCODO1", sCodePat)) ;
#endif

            //pSuper->pEpisodus->CaptureArray.push_back(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM01", sNomPat)) ;
            //pSuper->pEpisodus->CaptureArray.push_back(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM21", sPrenomPat)) ;
            //pSuper->pEpisodus->CaptureArray.push_back(new NSCapture(pContexte, "ZADMI1/LIDET1/LCODO1", sCodePat)) ;
        }
    }

    // 2. il n'y a pas de donn�es dans les variables de capture, on met les donn�es actuelles
    else if (pSuper->getEpisodus() != NULL)
    {
			NSCaptureArray* pCapt = &(pContexte->getSuperviseur()->getEpisodus()->newCaptureArray) ;

#ifndef _EXT_CAPTURE
        pCapt->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM01", sNomPat)) ;
        pCapt->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM21", sPrenomPat)) ;
        pCapt->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LCODO1", sCodePat)) ;
#else
        pCapt->ajouter(new NSCapture("ZADMI1/LIDET1/LNOM01", sNomPat)) ;
        pCapt->ajouter(new NSCapture("ZADMI1/LIDET1/LNOM21", sPrenomPat)) ;
        pCapt->ajouter(new NSCapture("ZADMI1/LIDET1/LCODO1", sCodePat)) ;
#endif

        //pSuper->pEpisodus->CaptureArray.push_back(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM01", sNomPat)) ;
        //pSuper->pEpisodus->CaptureArray.push_back(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM21", sPrenomPat)) ;
        //pSuper->pEpisodus->CaptureArray.push_back(new NSCapture(pContexte, "ZADMI1/LIDET1/LCODO1", sCodePat)) ;
    }

    // S'il n'y a pas de patient en cours, on swappe newCaptureArray et
    // CaptureArray (s'il y a un patient en cours, c'est fait dans
    // NSEpisodus::PatChanged()
    //
    if (!bAPatientAlreadyThere)
    {
        // pSuper->getEpisodus()->CaptureArray.vider() ;
        // pSuper->getEpisodus()->CaptureArray.append(&(pSuper->getEpisodus()->newCaptureArray)) ;
        // pSuper->getEpisodus()->newCaptureArray.vider() ;
#ifdef _IN_EXE
        pSuper->getEpisodus()->PutNewCaptureInTank(true, true) ;
#endif
    }

    // on lance l'archetype de cr�ation de patient (voir nom dans nsarc.h)
    pSuper->BbkAskUser(pSuper->getDemographicArchetypeId(), pContexte, NSCQDocument::creatpat) ;
    CloseWindow(IDCANCEL) ;
#endif
}
catch (...)
{
	erreur("Exception ChercheListePatDialog::CmCreer", standardError, 0) ;
}
}

*/

// -----------------------------------------------------------------
//
//  M�thodes de NSListPatWindow
//
// -----------------------------------------------------------------

/*

DEFINE_RESPONSE_TABLE1(NSListPatWindow, NSSkinableListWindow)
   EV_WM_KEYDOWN,
   EV_WM_LBUTTONDBLCLK,
   EV_WM_LBUTTONDOWN,
   EV_WM_KILLFOCUS,
   EV_WM_SETFOCUS,
END_RESPONSE_TABLE ;

NSListPatWindow::NSListPatWindow(NSListePatDialog* pere, NSContexte* pCtx, int resId)
                :NSSkinableListWindow(pere, pCtx, resId)
{
	pDlg = pere ;
    // Attr.Style |= LVS_REPORT | LVS_SHOWSELALWAYS ;    Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;}

void
NSListPatWindow::SetupWindow()
{
    ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;

    NSSkinableListWindow::SetupWindow() ;

    skinSwitchOff("patientListOff") ;
}
// on red�finit EvKeyDown pour pouvoir scroller avec les fl�chesvoid
NSListPatWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
    int count, itemSel;

    switch (key)
    {
        case VK_DOWN :

            count = GetItemCount() ;
            itemSel = IndexItemSelect() ;
            if (itemSel == (count - 1))
            {
                pDlg->pVScroll->SBLineDown() ;
                SetSel(itemSel, true) ;
            }
            else if (itemSel != -1)
                SetSel(itemSel + 1, true) ;
            break ;

        case VK_UP :

            itemSel = IndexItemSelect() ;
            if (itemSel == 0)
            {
                pDlg->pVScroll->SBLineUp() ;
                SetSel(itemSel, true) ;
            }
            else if (itemSel != -1)
                SetSel(itemSel - 1, true) ;
            break ;

        case VK_NEXT :
            itemSel = IndexItemSelect() ;            if (itemSel != -1)
            {
                pDlg->pVScroll->SBPageDown() ;
                SetSel(itemSel, true) ;
            }
            break ;

        case VK_PRIOR :
            itemSel = IndexItemSelect() ;            if (itemSel != -1)
            {
                pDlg->pVScroll->SBPageUp() ;
                SetSel(itemSel, true) ;
            }
            break ;

        default :

            TListWindow::EvKeyDown(key, repeatCount, flags) ;    }
}

//---------------------------------------------------------------------------//  Function: NSListPatWindow::EvLButtonDown(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point click�
//
//  Description: Fonction de r�ponse au click (d�sactive la multi-s�lection)
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListPatWindow::EvLButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
    // int count = GetItemCount();
	TLwHitTestInfo info(point);

    int index = HitTest(info);

    if (info.GetFlags() & LVHT_ONITEM)
   	    pDlg->GardeNss(index);

    // On appelle le Button Down de la classe m�re
    TListWindow::EvLButtonDown(modKeys, point);
}

//---------------------------------------------------------------------------
//  Function: NSListPatWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListPatWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point);

    HitTest(info);

    if (info.GetFlags() & LVHT_ONITEM)
        pDlg->CmOk();
}

//---------------------------------------------------------------------------//  Function: NSListPatWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListPatWindow::IndexItemSelect()
{
	int count = GetItemCount();
    int index = -1;

    for (int i = 0; i < count; i++)
   	    if (GetItemState(i, LVIS_SELECTED))
        {
      	    index = i;
            break;
        }

    return index;
}

// Gain du focus
//
void
NSListPatWindow::EvSetFocus(HWND hWndLostFocus)
{
    skinSwitchOn("patientListOn") ;

    TListWindow::EvSetFocus(hWndLostFocus) ;

    int count = GetItemCount() ;
    if (count > 0)
    {
        for (int i = 0 ; i < count ; i++)
            if (GetItemState(i, LVIS_SELECTED))
                return ;

        SetItemState(0, select ? LVIS_FOCUSED | LVIS_SELECTED : 0, LVIS_SELECTED);
        //SetItemState(0 , LVIS_FOCUSED | LVIS_SELECTED, LVIF_STATE) ;
        //SetSel(0, true) ;
    }
}

//
// Perte du focus.
//
void
NSListPatWindow::EvKillFocus(HWND hWndGetFocus)
{
    skinSwitchOff("patientListOff") ;

    TListWindow::EvKillFocus(hWndGetFocus) ;
}

*/

// -----------------------------------------------------------------
//
//  M�thodes de NSListGroupWindow
//
// -----------------------------------------------------------------

#ifdef N_TIERS

DEFINE_RESPONSE_TABLE1(NSListGroupWindow, NSSkinableListWindow)
   EV_WM_KEYDOWN,
   EV_WM_LBUTTONDBLCLK,
   EV_WM_LBUTTONDOWN,
   EV_WM_KILLFOCUS,
   EV_WM_SETFOCUS,
END_RESPONSE_TABLE ;

NSListGroupWindow::NSListGroupWindow(NSListeClientGroupDialog* pere, NSContexte* pCtx, int resId)
                :NSSkinableListWindow(pere, pCtx, resId)
{
	pDlg = pere ;
    // Attr.Style |= LVS_REPORT | LVS_SHOWSELALWAYS ;    Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;    Images  = 0 ;}

NSListGroupWindow::~NSListGroupWindow()
{
	if (Images)
        delete Images ;
}

void
NSListGroupWindow::SetupWindow()
{
    ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;

    NSSkinableListWindow::SetupWindow() ;

    skinSwitchOff("patientListOff") ;

    HINSTANCE hInstModule = *GetApplication() ;

    Images = new TImageList(NS_CLASSLIB::TSize(16, 16), ILC_COLOR4, 15, 5) ;
  	Images->Add(OWL::TBitmap(hInstModule, PAT_EARLY_RED)) ;
  	Images->Add(OWL::TBitmap(hInstModule, PAT_EARLY_YELLOW)) ;
  	Images->Add(OWL::TBitmap(hInstModule, PAT_EARLY_GREEN)) ;
  	Images->Add(OWL::TBitmap(hInstModule, PAT_BLUE)) ;
  	Images->Add(OWL::TBitmap(hInstModule, PAT_GREEN)) ;
  	Images->Add(OWL::TBitmap(hInstModule, PAT_YELLOW)) ;
    Images->Add(OWL::TBitmap(hInstModule, PAT_RED)) ;
  	SetImageList(*Images, TListWindow::State) ;
}
// on red�finit EvKeyDown pour pouvoir scroller avec les fl�chesvoid
NSListGroupWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
    int count, itemSel;

    switch (key)
    {
        case VK_DOWN :

            count = GetItemCount() ;
            itemSel = IndexItemSelect() ;
            if (itemSel == (count - 1))
            {
                pDlg->pVScroll->SBLineDown() ;
                SetSel(itemSel, true) ;
            }
            else if (itemSel != -1)
                SetSel(itemSel + 1, true) ;
            break ;

        case VK_UP :

            itemSel = IndexItemSelect() ;
            if (itemSel == 0)
            {
                pDlg->pVScroll->SBLineUp() ;
                SetSel(itemSel, true) ;
            }
            else if (itemSel != -1)
                SetSel(itemSel - 1, true) ;
            break ;

        case VK_NEXT :
            itemSel = IndexItemSelect() ;            if (itemSel != -1)
            {
                pDlg->pVScroll->SBPageDown() ;
                SetSel(itemSel, true) ;
            }
            break ;

        case VK_PRIOR :
            itemSel = IndexItemSelect() ;            if (itemSel != -1)
            {
                pDlg->pVScroll->SBPageUp() ;
                SetSel(itemSel, true) ;
            }
            break ;

        default :

            TListWindow::EvKeyDown(key, repeatCount, flags) ;    }
}

//---------------------------------------------------------------------------//  Function: NSListGroupWindow::EvLButtonDown(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point click�
//
//  Description: Fonction de r�ponse au click (d�sactive la multi-s�lection)
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListGroupWindow::EvLButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
    // int count = GetItemCount();
	TLwHitTestInfo info(point);

    int index = HitTest(info);

    if (info.GetFlags() & LVHT_ONITEM)
   	    pDlg->GardeNss(index);

    // On appelle le Button Down de la classe m�re
    TListWindow::EvLButtonDown(modKeys, point);
}

//---------------------------------------------------------------------------
//  Function: NSListGroupWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListGroupWindow::EvLButtonDblClk(uint /* modKeys */, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point);

    HitTest(info);

    if (info.GetFlags() & LVHT_ONITEM)
        pDlg->CmOk();
}

//---------------------------------------------------------------------------//  Function: NSListGroupWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListGroupWindow::IndexItemSelect()
{
	int count = GetItemCount();
    int index = -1;

    for (int i = 0; i < count; i++)
   	    if (GetItemState(i, LVIS_SELECTED))
        {
      	    index = i;
            break;
        }

    return index;
}

// Gain du focus
//
void
NSListGroupWindow::EvSetFocus(HWND hWndLostFocus)
{
    skinSwitchOn("patientListOn") ;

    TListWindow::EvSetFocus(hWndLostFocus) ;

    int count = GetItemCount() ;
    if (count > 0)
    {
        for (int i = 0 ; i < count ; i++)
            if (GetItemState(i, LVIS_SELECTED))
                return ;

        SetItemState(0, select ? LVIS_FOCUSED | LVIS_SELECTED : 0, LVIS_SELECTED);
        //SetItemState(0 , LVIS_FOCUSED | LVIS_SELECTED, LVIF_STATE) ;
        //SetSel(0, true) ;
    }
}

//
// Perte du focus.
//
void
NSListGroupWindow::EvKillFocus(HWND hWndGetFocus)
{
	skinSwitchOff("patientListOff") ;

	TListWindow::EvKillFocus(hWndGetFocus) ;
}

/***************************************************/
/* CLASSE NSNTiersListPatWindow                    */
/***************************************************/

DEFINE_RESPONSE_TABLE1(NSNTiersListPatWindow, NSSkinableListWindow)
   EV_WM_KEYDOWN,
   EV_WM_LBUTTONDBLCLK,
   EV_WM_LBUTTONDOWN,
   EV_WM_KILLFOCUS,
   EV_WM_SETFOCUS,
END_RESPONSE_TABLE ;

NSNTiersListPatWindow::NSNTiersListPatWindow(NSNTiersListePatDialog* pere, NSContexte* pCtx, int resId)
                :NSSkinableListWindow(pere, pCtx, resId)
{
	pDlg = pere ;
  // Attr.Style |= LVS_REPORT | LVS_SHOWSELALWAYS ;	Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;}

void
NSNTiersListPatWindow::SetupWindow()
{
  ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;

  NSSkinableListWindow::SetupWindow() ;

  skinSwitchOff("patientListOff") ;
}
// on red�finit EvKeyDown pour pouvoir scroller avec les fl�chesvoid
NSNTiersListPatWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
	int count, itemSel ;

	switch (key)
	{
  	case VK_DOWN :

      count = GetItemCount() ;
      itemSel = IndexItemSelect() ;
      if (itemSel == (count - 1))
      {
      	// pDlg->pVScroll->SBLineDown() ;
        SetSel(itemSel, true) ;
      }
      else if (itemSel != -1)
          SetSel(itemSel + 1, true) ;
      break ;

    case VK_UP :

      itemSel = IndexItemSelect() ;
      if (itemSel == 0)
      {
      	// pDlg->pVScroll->SBLineUp() ;
        SetSel(itemSel, true) ;
      }
      else if (itemSel != -1)
          SetSel(itemSel - 1, true) ;
      break ;

    case VK_NEXT :
      itemSel = IndexItemSelect() ;      if (itemSel != -1)
      {
      	// pDlg->pVScroll->SBPageDown() ;
        SetSel(itemSel, true) ;
      }
      break ;

    case VK_PRIOR :
      itemSel = IndexItemSelect() ;      if (itemSel != -1)
      {
      	// pDlg->pVScroll->SBPageUp() ;
        SetSel(itemSel, true) ;
      }
      break ;

    default :

  		TListWindow::EvKeyDown(key, repeatCount, flags) ;	}
}

//---------------------------------------------------------------------------//  Function: NSNTiersListePatWindow::EvLButtonDown(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point click�
//
//  Description: Fonction de r�ponse au click (d�sactive la multi-s�lection)
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSNTiersListPatWindow::EvLButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	// int count = GetItemCount();
	TLwHitTestInfo info(point);

	int index = HitTest(info);

	if (info.GetFlags() & LVHT_ONITEM)
  	pDlg->GardeNss(index) ;

	// On appelle le Button Down de la classe m�re
	TListWindow::EvLButtonDown(modKeys, point) ;
}

//---------------------------------------------------------------------------
//  Function: NSNTiersListePatWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSNTiersListPatWindow::EvLButtonDblClk(uint /* modKeys */, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point) ;

	HitTest(info) ;

	if (info.GetFlags() & LVHT_ONITEM)
  	pDlg->CmOk() ;
}

//---------------------------------------------------------------------------//  Function: NSNTiersListePatWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSNTiersListPatWindow::IndexItemSelect()
{
	int count = GetItemCount() ;
	int index = -1 ;

	for (int i = 0; i < count; i++)
  	if (GetItemState(i, LVIS_SELECTED))
    {
    	index = i ;
      break ;
    }

	return index ;
}

// Gain du focus
//
void
NSNTiersListPatWindow::EvSetFocus(HWND hWndLostFocus)
{
	skinSwitchOn("patientListOn") ;

	TListWindow::EvSetFocus(hWndLostFocus) ;

	int count = GetItemCount() ;
	if (count > 0)
	{
  	for (int i = 0 ; i < count ; i++)
    	if (GetItemState(i, LVIS_SELECTED))
      	return ;

    SetItemState(0, select ? LVIS_FOCUSED | LVIS_SELECTED : 0, LVIS_SELECTED);
        //SetItemState(0 , LVIS_FOCUSED | LVIS_SELECTED, LVIF_STATE) ;
        //SetSel(0, true) ;
	}
}

//
// Perte du focus.
//
void
NSNTiersListPatWindow::EvKillFocus(HWND hWndGetFocus)
{
	skinSwitchOff("patientListOff") ;

	TListWindow::EvKillFocus(hWndGetFocus) ;
}

// -----------------------------------------------------------------
//
//  M�thodes de NSRechNomEdit
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSNTiersRechNomEdit, NSUtilEdit)
	EV_WM_CHAR,
	EV_WM_KEYUP,
END_RESPONSE_TABLE;

//// On doit intercepter EvChar pour interdire l'espace et le double-espace
//
void
NSNTiersRechNomEdit::EvChar(uint key, uint repeatCount, uint flags)
{
	char Nom[PAT_NOM_LEN + 1] = "" ;

	/* pDlg->pNom-> */ GetText(Nom, PAT_NOM_LEN + 1) ;

	// on interdit l'espace comme premier caractere
	if ((!strcmp(Nom, "")) && (key == VK_SPACE))
		return ;
	// on interdit le double espace
	if ((strlen(Nom) > 0) && (Nom[strlen(Nom)-1] == ' ') && (key == VK_SPACE))
		return ;

	NSUtilEdit::EvChar(key, repeatCount, flags) ;
}

//
// On doit intercepter EvKeyUp pour tenir compte de VK_DELETE
// qui n'est pas intercept� par EvChar
//
void
NSNTiersRechNomEdit::EvKeyUp(uint key, uint repeatCount, uint flags)
{
	NSUtilEdit::EvKeyUp(key, repeatCount, flags) ;

	if ((key != VK_RETURN) && (key != VK_TAB))
  	pDlg->resetTimer() ;
}


#endif

// -----------------------------------------------------------------
//
//  M�thodes de NSRechNomEdit
//
// -----------------------------------------------------------------

/*

DEFINE_RESPONSE_TABLE1(NSRechNomEdit, NSUtilEdit)
   EV_WM_CHAR,
   EV_WM_KEYUP,
END_RESPONSE_TABLE;

//// On doit intercepter EvChar pour interdire l'espace et le double-espace
//
void
NSRechNomEdit::EvChar(uint key, uint repeatCount, uint flags)
{
    char Nom[PAT_NOM_LEN + 1] = "";

    pDlg->pNom->GetText(Nom, PAT_NOM_LEN + 1);

    // on interdit l'espace comme premier caractere
    if ((!strcmp(Nom, "")) && (key == VK_SPACE))
        return;
    // on interdit le double espace
    if ((strlen(Nom) > 0) && (Nom[strlen(Nom)-1] == ' ') && (key == VK_SPACE))
        return;

	NSUtilEdit::EvChar(key, repeatCount, flags);
}

//
// On doit intercepter EvKeyUp pour tenir compte de VK_DELETE
// qui n'est pas intercept� par EvChar
//
void
NSRechNomEdit::EvKeyUp(uint key, uint repeatCount, uint flags)
{
    NSUtilEdit::EvKeyUp(key, repeatCount, flags);

    if ((key != VK_RETURN) && (key != VK_TAB))
   	    pDlg->ScrollPatient();

}

// -----------------------------------------------------------------
//
//  M�thodes de NSRechPreEdit
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSRechPreEdit, NSUtilEdit)
   EV_WM_CHAR,
   EV_WM_KEYUP,
END_RESPONSE_TABLE;

//
// On doit intercepter EvChar pour interdire l'espace et le double-espace
//
void
NSRechPreEdit::EvChar(uint key, uint repeatCount, uint flags)
{
    char Prenom[PAT_PRENOM_LEN + 1] = "";

    pDlg->pPrenom->GetText(Prenom, PAT_PRENOM_LEN + 1);

    // on interdit l'espace comme premier caractere
    if ((!strcmp(Prenom, "")) && (key == VK_SPACE))
        return;
    // on interdit le double espace
    if ((Prenom[strlen(Prenom)-1] == ' ') && (key == VK_SPACE))
        return;

	NSUtilEdit::EvChar(key, repeatCount, flags);
}

//
// On doit intercepter EvKeyUp pour tenir compte de VK_DELETE
// qui n'est pas intercept� par EvChar
//
void
NSRechPreEdit::EvKeyUp(uint key, uint repeatCount, uint flags)
{
    NSUtilEdit::EvKeyUp(key, repeatCount, flags);

    if ((key != VK_RETURN) && (key != VK_TAB))
   	    pDlg->ScrollPatient();
}

*/

// -----------------------------------------------------------------
//
//  M�thodes de NSRechNumEdit
//
// -----------------------------------------------------------------

/*

DEFINE_RESPONSE_TABLE1(NSRechNumEdit, NSUtilEdit)
   EV_WM_CHAR,
END_RESPONSE_TABLE;


#ifdef N_TIERS

void
NSRechNumEdit::EvChar(uint key, uint repeatCount, uint flags)
{
}

#else

void
NSRechNumEdit::EvChar(uint key, uint repeatCount, uint flags)
{
	DBIResult ErrDBI;
    char      NSS[PAT_NSS_LEN + 1] = "";
    char      Nom[PAT_NOM_LEN + 1] = "";
	char      Prenom[PAT_PRENOM_LEN + 1] = "";
    char      Code[PAT_CODE_LEN + 1] = "";

	NSUtilEdit::EvChar(key, repeatCount, flags);

    if (key == VK_RETURN)
    {
        pDlg->pNum->GetText(NSS, PAT_NSS_LEN + 1);

        if (!strcmp(NSS, ""))
            return;

        ErrDBI = pDlg->pPatEnCours->chercheClef((unsigned char*)NSS,
													   "",
													   0,
													   keySEARCHEQ,
                                                       dbiWRITELOCK);

        if (ErrDBI == DBIERR_RECNOTFOUND)
        {
            erreur("Aucun patient ne poss�de ce num�ro.", standardError, 0) ;
            return;
        }

        ErrDBI = pDlg->pPatEnCours->getRecord();
   	    if (ErrDBI != DBIERR_NONE)
   	    {
   		    erreur("Erreur � lecture du fichier Adresses.db", 0, ErrDBI);
			return;
   	    }

        // on met � jour les champs li�s
        strcpy(Nom, pDlg->pPatEnCours->pDonnees->nom);
        strcpy(Prenom, pDlg->pPatEnCours->pDonnees->prenom);
        strcpy(Code, pDlg->pPatEnCours->pDonnees->code);

        pDlg->pNom->SetText(Nom);
        pDlg->pPrenom->SetText(Prenom);
        pDlg->pCode->SetText(Code);

   	    pDlg->ScrollPatient();
    }
}
#endif

// -----------------------------------------------------------------
//
//  M�thodes de NSRechCodeEdit
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSRechCodeEdit, NSUtilEdit)
   EV_WM_KEYUP,
   EV_WM_CHAR,
END_RESPONSE_TABLE;

void
NSRechCodeEdit::EvKeyUp(uint key, uint repeatcount, uint flags)
{
    // on bloque cette fonction pour Return, Down ou Tab
    // pour empecher le NSUtilEdit de lancer CmOk
    // directement apres la recherche par code
    if (!((key == VK_RETURN) || (key == VK_DOWN) || (key == VK_TAB)))
        NSUtilEdit::EvKeyUp(key, repeatcount, flags);
}

void
NSRechCodeEdit::EvChar(uint key, uint repeatCount, uint flags)
{
}

*/

// -----------------------------------------------------------------
//
//  M�thodes de NSLVScrollBar
//
// -----------------------------------------------------------------

NSLVScrollBar::NSLVScrollBar(NSListePatDialog* parent, int resourceId, TModule* module)
				  :TScrollBar(parent, resourceId, module)
{
	pListeDlg = parent;
}

void
NSLVScrollBar::FixeRange(int max, int taille)
{
   // SetRange(1, max);

   // HWND hWnd = HWND();

   SCROLLINFO scInfo;
   scInfo.cbSize = (UINT) sizeof(scInfo);
   scInfo.fMask = SIF_ALL;
   scInfo.nMin = 1;
   scInfo.nMax = max;
   scInfo.nPage = (UINT) (taille);
   scInfo.nPos = 1;

   SetScrollInfo(&scInfo, TRUE);
}

void
NSLVScrollBar::SBLineDown()
{
	// Transmet � la boite de Dialogue
	TScrollBar::SBLineDown();
	pListeDlg->LineDown();
}

void
NSLVScrollBar::SBLineUp()
{
	// Transmet � la boite de Dialogue
	TScrollBar::SBLineUp();
	pListeDlg->LineUp();
}

void
NSLVScrollBar::SBPageDown()
{
	TScrollBar::SBPageDown();
   for (int i = 0; i < PageMagnitude; i++)
   	if (!pListeDlg->LineDown())
      	break;
}

void
NSLVScrollBar::SBPageUp()
{
	TScrollBar::SBPageUp();
   for (int i = 0; i < PageMagnitude; i++)
   	if (!pListeDlg->LineUp())
      	break;
}

void
NSLVScrollBar::PositionneCurseur()
{
#ifndef N_TIERS
	//
	// Prise du nombre total de d'enregistrement et de la position actuelle
	//
	int NumEnCours;

	//
	// Positionnement du curseur
	//
    pListeDlg->pPatEnCours->donneNumRecEnCours(&NumEnCours);
	SetPosition(NumEnCours);
#endif
}

// -----------------------------------------------------------------
//
//  M�thodes de ChercheListeCorDialog
//
// -----------------------------------------------------------------

/*

// ---------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(ChercheListeCorDialog, NSUtilDialog)
   EV_COMMAND(IDOK, CmOk),
   EV_COMMAND(IDCANCEL, CmCancel),
   EV_LVN_GETDISPINFO(IDC_LC2_LW, LvnGetDispInfo),
END_RESPONSE_TABLE;

ChercheListeCorDialog::ChercheListeCorDialog(TWindow* pere, NSContexte* pCtx, TModule* module)
                      :NSUtilDialog(pere, pCtx, "IDD_LISTCOR2", module)
{
	// Cr�ation de tous les "objets de contr�le"
    pNom 	 = new NSRechCorEdit(this, IDC_LC2_NOM, COR_NOM_LEN);
	pPrenom  = new NSRechCorEdit(this, IDC_LC2_PRENOM, COR_PRENOM_LEN);

    pListe 	 = new NSListCorWindow(this, IDC_LC2_LW, module);
	pVScroll = new NSLCScrollBar(this, IDC_LC2_VSCROLL);

	// Cr�ation du tableau de Patients
#ifndef N_TIERS
	pCorEnCours = 0;
#endif
    // on stocke le r�sultat de la recherche
    ErrDBI = DBIERR_NONE;

    pCorrespSelect = new NSCorrespondantInfo(pContexte);
	pCorrespArray  = new NSCorrespArray;

    sNumSelect = "";
}

ChercheListeCorDialog::~ChercheListeCorDialog()
{
	delete pNom;
	delete pPrenom;
	delete pVScroll;
	delete pListe;
   	delete pCorrespSelect;
   	delete pCorrespArray;

#ifndef N_TIERS
   pCorEnCours->detruireBookMarks(2);

   delete pCorEnCours;
#endif
}

//---------------------------------------------------------------------------
//  Function: ChercheListeCorDialog::SetupWindow()
//
//  Arguments:	  Aucun
//
//  Description: Initialise la boite de dialogue
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
ChercheListeCorDialog::SetupWindow()
{
	TDialog::SetupWindow();

   pNom->SetText("");
   pPrenom->SetText("");

   if (!InitRecherche())
   	return;

#ifndef N_TIERS
   // Cr�ation de 2 BookMarks
	pCorEnCours->creerBookMarks(2);
#endif

   // Positionnement du corresp en fin de fichier
   PosLastCorresp();

   // Initialisation du tableau des patients et des bookmarks
   InitCorArray();

   // Initialisation de la liste
   InitListe();
   AfficheListe();
}

//---------------------------------------------------------------------------
//  Function: ChercheListeCorDialog::InitRecherche()
//
//  Arguments:	  Aucun
//
//  Description: Initialise la recherche des corresp par nom, prenom
//
//  Returns:     true->OK, false sinon
//---------------------------------------------------------------------------
bool
ChercheListeCorDialog::InitRecherche()
{
#ifndef N_TIERS

	pCorEnCours = new NSCorrespondant(pContexte);

	ErrDBI = pCorEnCours->open();
	if (ErrDBI != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier Corresp.db", 0, ErrDBI, GetHandle());
		return false;
	}

    // Pour avoir une liste tri�e ...
    string sNomBlanc    = string(COR_NOM_LEN, ' ');
    string sPrenomBlanc = string(COR_PRENOM_LEN, ' ');
    CURProps curProps;
    DbiGetCursorProps(pCorEnCours->PrendCurseur(), curProps);
    Byte* pIndexRec = new Byte[curProps.iRecBufSize];
    memset(pIndexRec, 0, curProps.iRecBufSize);
    DbiPutField(pCorEnCours->PrendCurseur(), COR_NOM_FIELD,    pIndexRec, (Byte*)sNomBlanc.c_str());
    DbiPutField(pCorEnCours->PrendCurseur(), COR_PRENOM_FIELD, pIndexRec, (Byte*)sPrenomBlanc.c_str());

    ErrDBI = pCorEnCours->chercheClefComposite("NOM_PRENOM",
   												 NODEFAULTINDEX,
												 keySEARCHGEQ,
												 dbiWRITELOCK,
												 pIndexRec);
    delete[] pIndexRec;

    if (ErrDBI != DBIERR_NONE)
    {
        erreur("Erreur � la recherche dans le fichier Corresp.db", 0, ErrDBI, GetHandle());
        return false;
    }

#endif

    return true;
}

//---------------------------------------------------------------------------
//  Function: ChercheListeCorDialog::InitListe()
//
//  Arguments:	  Aucun
//
//  Description: Initialise la ListWindow avec ses colonnes
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
ChercheListeCorDialog::InitListe()
{
	TListWindColumn colNom("Nom", 100, TListWindColumn::Left, 0);
  	pListe->InsertColumn(0, colNom);
    TListWindColumn colPrenom("Pr�nom", 100, TListWindColumn::Left, 1);
  	pListe->InsertColumn(1, colPrenom);
  	TListWindColumn colVille("Ville", 90, TListWindColumn::Left, 2);
  	pListe->InsertColumn(2, colVille);
}

//---------------------------------------------------------------------------
//  Function: ChercheListeCorDialog::AfficheListe(int decal)
//
//  Arguments:	  Aucun
//
//  Description: Affiche le tableau de patients dans la liste
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
ChercheListeCorDialog::AfficheListe()
{
	char nom[255];

   //
   // On vide la liste
   //
	pListe->DeleteAllItems();

	for (int i = nbNom - 1; i >= 0; i--)
   {
   	sprintf(nom, "%s", ((*pCorrespArray)[i])->pDonnees->nom);
   	TListWindItem Item(nom, 0);
      pListe->InsertItem(Item);
   }

   pListe->ShowScrollBar(SB_VERT, FALSE);
}


//
// Callback notification to handle additional column information
// for each item.
//
void
ChercheListeCorDialog::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
  const int BufLen = 255;
   static char buffer[BufLen];
   TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item;
   int index;

   index = dispInfoItem.GetIndex();

   // Affiche les informations en fonction de la colonne

   switch (dispInfoItem.GetSubItem())
   {
       case 1: 	// pr�nom
         sprintf(buffer, "%s", ((*pCorrespArray)[index])->pDonnees->prenom);
         dispInfoItem.SetText(buffer);
         break;
#ifndef N_TIERS
       case 2: 	// ville         sprintf(buffer, "%s", ((*pCorrespArray)[index])->pAdresseInfo->pDonnees->ville);
         dispInfoItem.SetText(buffer);
         break;
#endif
   }
}

//---------------------------------------------------------------------------//  Function: ChercheListeCorDialog::InitCorArray()//
//  Arguments:	  Aucun
//
//  Description: Initialise le tableau de corresps et les bookmarks
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
ChercheListeCorDialog::InitCorArray()
{
  #ifndef N_TIERS
	// Mise en place du 1er BookMark sur la premi�re fiche
	pCorEnCours->placeBookMark(1);
	pVScroll->PositionneCurseur();

	// Initialisation du tableau de patients
    pCorrespArray->vider();

	for (int i = 0; i < nbNom; i++)
	{
		pCorEnCours->alimenteFiche();
        pCorEnCours->initAdresseInfo();
		pCorrespArray->push_back(new NSCorrespondantInfo(pCorEnCours));
		if (i < nbNom - 1)
			pCorEnCours->suivant(dbiWRITELOCK);
	}

	// Mise en place du 2nd BookMark sur la derni�re fiche
	pCorEnCours->placeBookMark(2);
  #endif
}

//---------------------------------------------------------------------------//  Function: ChercheListeCorDialog::PosLastCorresp()
//
//  Arguments:	  Aucun
//
//  Description: Positionne le pCorEnCours en fonction de la fin de la table
//
//  Returns:     Rien
//---------------------------------------------------------------------------
voidChercheListeCorDialog::PosLastCorresp()
{
#ifndef N_TIERS

	int    		nbPrec = 0, limiteSup, totalRec, currentRec;
    int 		NombreTotal, NumEnCours;
    int	 		nbAffListe = 14;	// Nombre de corresps affich�s dans la liste

   // Calcul du nombre de noms affich�s
   pCorEnCours->donneNbTotalRec(&NombreTotal);

   totalRec = NombreTotal;

   if (totalRec < nbAffListe)
   {
   	  nbNom = NombreTotal;
      bVScroll = false;
   }
   else
   {
   	  nbNom = nbAffListe;
      bVScroll = true;
   }

   // dimensionnement de la scroll bar
   pVScroll->FixeRange(NombreTotal, nbNom);

   // Calcul du nombre de pr�c�dents
   /////////////////////////////////////////////////////////////
   limiteSup = totalRec - nbNom + 1;

   // on teste le r�sultat de la recherche pr�c�dente
   if (ErrDBI == DBIERR_EOF)
   {
	  nbPrec = nbNom;
	  ErrDBI = DBIERR_NONE;
   }
   else // cas DBIERR_NONE
   {
	  pCorEnCours->donneNumRecEnCours(&NumEnCours);
	  currentRec = NumEnCours;
	  if (currentRec > limiteSup)
		nbPrec = currentRec - limiteSup;
   }

   for (int i = 0; (i < nbPrec) && (ErrDBI == DBIERR_NONE); i++)
	ErrDBI = pCorEnCours->precedent(dbiWRITELOCK);

   if ((ErrDBI != DBIERR_NONE) && (ErrDBI != DBIERR_BOF))
		erreur("Erreur de positionnement dans la base des correspondants.", 0, ErrDBI, GetHandle());

#endif // ifndef N_TIERS
}

//---------------------------------------------------------------------------//  Function: ChercheListeCorDialog::ScrollCorresp()
//
//  Arguments:	  Aucun
//
//  Description: Scrolle la liste en fonction du nom et du prenom
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
ChercheListeCorDialog::ScrollCorresp()
{
#ifndef N_TIERS

	DBIResult ErrDBI;
    CURProps curProps;
    Byte* pIndexRec;

	char far nom[PAT_NOM_LEN + 1];
   	pNom->GetText(nom, PAT_NOM_LEN + 1);

   	char far prenom[PAT_PRENOM_LEN + 1];
   	pPrenom->GetText(prenom, PAT_PRENOM_LEN + 1);

   	ErrDBI = DbiGetCursorProps(pCorEnCours->PrendCurseur(), curProps);
   	pIndexRec = new Byte[curProps.iRecBufSize];
   	memset(pIndexRec, 0, curProps.iRecBufSize);
   	DbiPutField(pCorEnCours->PrendCurseur(), COR_NOM_FIELD, 	  pIndexRec, (Byte*)nom);
   	DbiPutField(pCorEnCours->PrendCurseur(), COR_PRENOM_FIELD, pIndexRec, (Byte*)prenom);

   	ErrDBI = pCorEnCours->chercheClefComposite("NOM_PRENOM",
												NODEFAULTINDEX,
												keySEARCHGEQ,
												dbiWRITELOCK,
												pIndexRec);
   	delete[] pIndexRec;

   	if ((ErrDBI != DBIERR_NONE) && (ErrDBI != DBIERR_EOF))
		erreur("Erreur de positionnement dans la base des patients.", 0, ErrDBI, GetHandle());

   	// On replace les BookMarks et on re-remplit le tableau des correspondants
   	PosLastCorresp();
   	InitCorArray();
   	AfficheListe();
   	RetrouveCorSelect();

#endif
}

//---------------------------------------------------------------------------

//  Function: ChercheListeCorDialog::GardeNss(int index)
//
//  Arguments:	  Index du patient s�lectionn�
//
//  Description: Conserve le nss du patient s�lectionn�
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
ChercheListeCorDialog::GardeNum(int index)
{
	sNumSelect = string(((*pCorrespArray)[index])->pDonnees->code);
}

//---------------------------------------------------------------------------
//  Function: ChercheListeCorDialog::RetrouveCorSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retrouve le patient s�lectionn�
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
ChercheListeCorDialog::RetrouveCorSelect()
{
	for (int i = 0; i < nbNom; i++)
   {
   	if (sNumSelect == string(((*pCorrespArray)[i])->pDonnees->code))
      {
      	pListe->SetSel(i, true);
         break;
      }
   }
}
//---------------------------------------------------------------------------//  Function: ChercheListeCorDialog::LineDown()
//
//  Arguments:	  Aucun
//
//  Description: G�re le d�filement de la liste d'une ligne vers le bas
//
//  Returns:     True->Ok False->Echec
//---------------------------------------------------------------------------
bool
ChercheListeCorDialog::LineDown()
{
	if (!bVScroll)
    	return false;

#ifndef N_TIERS

	DBIResult ErrDBI ;

	// Replacement sur le 2nd BookMark
	pCorEnCours->retrouveBookMark(2);

	// Positionnement sur la fiche suivante
	// et sortie imm�diate si la fiche suivante n'existe pas
  ErrDBI = pCorEnCours->suivant(dbiWRITELOCK);
	if (ErrDBI != DBIERR_NONE)
  {
		if (ErrDBI != DBIERR_EOF)
			erreur("Erreur d'acc�s au patient suivant.", 0, ErrDBI, GetHandle());
		return false;
  }

	pCorEnCours->placeBookMark(2);

	// Mise � jour de pPatientsArray
	pCorEnCours->alimenteFiche();
	pCorEnCours->initAdresseInfo();

   	pCorrespArray->erase(pCorrespArray->begin());
	pCorrespArray->push_back(new NSCorrespondantInfo(pCorEnCours));
	AfficheListe();
   	RetrouveCorSelect();

	// Repositionnement du 1er BookMark
	pCorEnCours->retrouveBookMark(1);
	pCorEnCours->suivant(dbiWRITELOCK);
	pCorEnCours->placeBookMark(1);

	// pVScroll->PositionneCurseur();
#endif

   return true;}

//---------------------------------------------------------------------------//  Function: ChercheListeCorDialog::LineUp()
//
//  Arguments:	  Aucun
//
//  Description: G�re le d�filement de la liste d'une ligne vers le haut
//
//  Returns:     Rien
//---------------------------------------------------------------------------
bool
ChercheListeCorDialog::LineUp()
{
	if (!bVScroll)
    	return false;

#ifndef N_TIERS

	DBIResult ErrDBI;

	// Replacement sur le 1er BookMark
	pCorEnCours->retrouveBookMark(1);

	// Positionnement sur la fiche pr�c�dente
	// et sortie imm�diate si la fiche pr�c�dente n'existe pas
   	ErrDBI = pCorEnCours->precedent(dbiWRITELOCK);
	if (ErrDBI != DBIERR_NONE)
	{
   		if (ErrDBI != DBIERR_BOF)
      		erreur("Erreur d'acc�s au patient pr�c�dent.", 0, ErrDBI, GetHandle());
		return false;
   	}

	pCorEnCours->placeBookMark(1);

	// pVScroll->PositionneCurseur();

	// Mise � jour de pPatientsArray
	pCorEnCours->alimenteFiche();
	pCorEnCours->initAdresseInfo();

   	// insertion au debut du vecteur
	pCorrespArray->insert(pCorrespArray->begin(),new NSCorrespondantInfo(pCorEnCours));
   	pCorrespArray->pop_back();
	AfficheListe();
   	RetrouveCorSelect();

	// Repositionnement du 2nd BookMark
	pCorEnCours->retrouveBookMark(2);
	pCorEnCours->precedent(dbiWRITELOCK);
	pCorEnCours->placeBookMark(2);

#endif

   	return true;
}


//-------------------------------------------------------------------------
//  CanClose()
//  R�pond � OK. Positionne le patient sur le patient s�lectionn�.
//---------------------------------------------------------------------------
bool
ChercheListeCorDialog::CanClose()
{
   return TDialog::CanClose();
}
//-------------------------------------------------------------------------
//  CmOk()
//  R�pond � OK. Positionne le patient sur le patient s�lectionn�.
//---------------------------------------------------------------------------
void
ChercheListeCorDialog::CmOk()
{
	int index = pListe->IndexItemSelect() ;

	CorrespChoisi = index ;
  if (CorrespChoisi >= 0)
  	*pCorrespSelect = *((*pCorrespArray)[CorrespChoisi]) ;
  else
  {
  	erreur("Vous devez choisir un correspondant.", warningError, 0, GetHandle()) ;
    return ;
  }

  CloseWindow(IDOK) ;
}

*/
// -----------------------------------------------------------------
//
//  M�thodes de NSListCorWindow
//
// -----------------------------------------------------------------
/*
DEFINE_RESPONSE_TABLE1(NSListCorWindow, TListWindow)
   EV_WM_KEYDOWN,
   EV_WM_LBUTTONDBLCLK,
   EV_WM_LBUTTONDOWN,
END_RESPONSE_TABLE;

NSListCorWindow::NSListCorWindow(ChercheListeCorDialog* pere, int resId, TModule* module) : TListWindow(pere, resId, module)
{
	pDlg = pere;
}

// on met en place EvKeyDown pour scroller avec les touches ->, <-, etc.
void
NSListCorWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
    int count, itemSel;

    switch (key)
    {
        case VK_DOWN :
            count = GetItemCount();
            itemSel = IndexItemSelect();
            if (itemSel == (count - 1))
            {
                pDlg->pVScroll->SBLineDown();
                SetSel(itemSel, true);
            }
            else if (itemSel != -1)
                SetSel(itemSel + 1, true);
            break;

        case VK_UP :
            itemSel = IndexItemSelect();
            if (itemSel == 0)
            {
                pDlg->pVScroll->SBLineUp();
                SetSel(itemSel, true);
            }
            else if (itemSel != -1)
                SetSel(itemSel - 1, true);
            break;

        case VK_NEXT :
            itemSel = IndexItemSelect();
            if (itemSel != -1)
            {
                pDlg->pVScroll->SBPageDown();
                SetSel(itemSel, true);
            }
            break;

        case VK_PRIOR :
            itemSel = IndexItemSelect();
            if (itemSel != -1)
            {
                pDlg->pVScroll->SBPageUp();
                SetSel(itemSel, true);
            }
            break;

        default :
            TListWindow::EvKeyDown(key, repeatCount, flags);
    }
}
//---------------------------------------------------------------------------//  Function: NSListCorWindow::EvLButtonDown(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point click�
//
//  Description: Fonction de r�ponse au click (d�sactive la multi-s�lection)
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListCorWindow::EvLButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
    // int count = GetItemCount();
	TLwHitTestInfo info(point);

    int index = HitTest(info);

    if (info.GetFlags() & LVHT_ONITEM)
   	    pDlg->GardeNum(index);

    // On appelle le Button Down de la classe m�re
    TListWindow::EvLButtonDown(modKeys,point);
}


//---------------------------------------------------------------------------
//  Function: NSListCorWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListCorWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point);

   HitTest(info);

   if (info.GetFlags() & LVHT_ONITEM)
      pDlg->CmOk();
}

//---------------------------------------------------------------------------
//  Function: NSListCorWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListCorWindow::IndexItemSelect()
{
	int count = GetItemCount();
   int index = -1;

   for (int i = 0; i < count; i++)
   	if (GetItemState(i, LVIS_SELECTED))
      {
      	index = i;
         break;
      }

   return index;
}
*/
// -----------------------------------------------------------------
//
//  M�thodes de NSRechCorEdit
//
// -----------------------------------------------------------------
/*
DEFINE_RESPONSE_TABLE1(NSRechCorEdit, NSUtilEdit)
   EV_WM_CHAR,
END_RESPONSE_TABLE;

void
NSRechCorEdit::EvChar(uint key, uint repeatCount, uint flags)
{
	NSUtilEdit::EvChar(key, repeatCount, flags);

   if ((key != VK_RETURN) && (key != VK_TAB))
   	pDlg->ScrollCorresp();
}
*/
// -----------------------------------------------------------------
//
//  M�thodes de NSLCScrollBar
//
// -----------------------------------------------------------------
/*
NSLCScrollBar::NSLCScrollBar(ChercheListeCorDialog* parent, int resourceId, TModule* module)
				  :TScrollBar(parent, resourceId, module)
{
	pListeDlg = parent;
}

void
NSLCScrollBar::FixeRange(int max, int taille)
{
   // SetRange(1, max);

   // HWND hWnd = HWND();

   SCROLLINFO scInfo;
   scInfo.cbSize = (UINT) sizeof(scInfo);
   scInfo.fMask = SIF_ALL;
   scInfo.nMin = 1;
   scInfo.nMax = max;
   scInfo.nPage = (UINT) (taille);
   scInfo.nPos = 1;

   SetScrollInfo(&scInfo, TRUE);
}

void
NSLCScrollBar::SBLineDown()
{
	// Transmet � la boite de Dialogue
	TScrollBar::SBLineDown();
	pListeDlg->LineDown();
}

void
NSLCScrollBar::SBLineUp()
{
	// Transmet � la boite de Dialogue
	TScrollBar::SBLineUp();
	pListeDlg->LineUp();
}

void
NSLCScrollBar::SBPageDown()
{
	TScrollBar::SBPageDown();
   for (int i = 0; i < PageMagnitude; i++)
   	if (!pListeDlg->LineDown())
      	break;
}

void
NSLCScrollBar::SBPageUp()
{
	TScrollBar::SBPageUp();
   for (int i = 0; i < PageMagnitude; i++)
   	if (!pListeDlg->LineUp())
      	break;
}
voidNSLCScrollBar::PositionneCurseur()
{
#ifndef N_TIERS
	//
	// Prise du nombre total de d'enregistrement et de la position actuelle
	//
	int NumEnCours ;

	//
	// Positionnement du curseur
	//
	pListeDlg->pCorEnCours->donneNumRecEnCours(&NumEnCours) ;
	SetPosition(NumEnCours) ;
#endif
}
*///***********************************************************************////							Classe NSEnregDocPatientDlg
//***********************************************************************//

DEFINE_RESPONSE_TABLE1(NSEnregDocPatientDlg, NSUtilDialog)END_RESPONSE_TABLE;

NSEnregDocPatientDlg::NSEnregDocPatientDlg(TWindow* parent, NSContexte* pCtx,															TModule* module)
#ifndef _MUE
				   :NSUtilDialog(parent, pCtx, "IDD_ENREG_DOC_PATIENT", module)
#else
                   :NSUtilDialog(parent, pCtx, "IDD_ENREG_DOC_PATIENT", module) // � faire en mode MUE
#endif
{
    pChemBox = new TCheckBox(this, IDC_ENREG_DOC_CHEM);
    pIndexBox = new TCheckBox(this, IDC_ENREG_DOC_INDEX);
    pSynthBox = new TCheckBox(this, IDC_ENREG_DOC_SYNTH);
}

NSEnregDocPatientDlg::~NSEnregDocPatientDlg(){
    delete pChemBox;
    delete pIndexBox;
    delete pSynthBox;
}

void
NSEnregDocPatientDlg::SetupWindow()
{
    NSUtilDialog::SetupWindow();
}

voidNSEnregDocPatientDlg::CheckChem(){    pChemBox->Check();}voidNSEnregDocPatientDlg::CheckIndex(){    pIndexBox->Check();}voidNSEnregDocPatientDlg::CheckSynth(){    pSynthBox->Check();}//***********************************************************************//
//							Classe NSEnregPatientDlg
//***********************************************************************//

DEFINE_RESPONSE_TABLE1(NSEnregPatientDlg, NSUtilDialog)END_RESPONSE_TABLE;

NSEnregPatientDlg::NSEnregPatientDlg(TWindow* parent, NSContexte* pCtx,															TModule* module)
                   :NSUtilDialog(parent, pCtx, "IDD_ENREG_PATIENT_MUE", module)
{
  pAdminBox = new TCheckBox(this, IDC_ENREG_ADMIN) ;
  pHistoBox = new TCheckBox(this, IDC_ENREG_HISTO) ;
  pSynthBox = 0 ; // new TCheckBox(this, IDC_ENREG_SYNTH) ;
  pCorrsBox = new TCheckBox(this, IDC_ENREG_CORRS) ;
  pLDVBox   = new TCheckBox(this, IDC_ENREG_LDV) ;
}

NSEnregPatientDlg::~NSEnregPatientDlg(){
  delete pAdminBox ;
  delete pHistoBox ;
  if (NULL != pSynthBox)
    delete pSynthBox ;
  delete pCorrsBox ;
  delete pLDVBox ;
}

void
NSEnregPatientDlg::SetupWindow()
{
  NSUtilDialog::SetupWindow() ;
}

voidNSEnregPatientDlg::CheckAdmin(){  pAdminBox->Check() ;}voidNSEnregPatientDlg::CheckHisto(){  pHistoBox->Check() ;}voidNSEnregPatientDlg::CheckSynth(){  if (NULL != pSynthBox)    pSynthBox->Check() ;}voidNSEnregPatientDlg::CheckCorrs()
{
  pCorrsBox->Check() ;
}void
NSEnregPatientDlg::CheckLDV()
{
  pLDVBox->Check() ;
}
// fin de nspatdlg.cpp

