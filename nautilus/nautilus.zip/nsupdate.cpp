// -----------------------------------------------------------------------------
// nsupdate.cpp
// -----------------------------------------------------------------------------
// $Revision: 1.2 $
// $Author: PA $
// $Date: 2007/08/27 06:50:15 $
// -----------------------------------------------------------------------------
// PA - aout 2007
// -----------------------------------------------------------------------------

#include <stdio.h>
#include <fstream.h>
#include <process.h>

#include "curl\curl.h"
#include "curl\easy.h"
#include "curl\nscurl.h"

#include "nautilus\nsupdate.h"
#include "partage\nsdivfct.h"    // fonction erreur
#include "nsepisod\nsldvuti.h"

NSUpdate::NSUpdate(NSContexte * pCtx)
         :NSRoot(pCtx)
{
	sSettingsFile = string("update.dat") ;

	sURL        = "" ;
	sLogin      = "" ;
	sPassword   = "" ;
	sProtocol   = "" ;
	sUpdateDir  = "" ;

  bLastUpdate      = false ;
	tLastUpdate.init() ;

  iInterval   = 0 ;
	bLastUpdateCheck = true ;
	bInterval        = true ;
  tLastUpdateCheck.init() ;
	tNextUpdateCheck.init() ;

  string ps = string("Init of update params") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

  curl.init() ;

	if (true == curl.aCurlOptParams.empty())
	{
  	ps = string("No specific curlopt params") ;
		pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
  }
  else
  {
  	ps = string("Specific curlopt params:") ;
		pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

		map<string, string>::iterator iter ;

		for (iter = curl.aCurlOptParams.begin() ; iter != curl.aCurlOptParams.end() ; iter++)
  	{
  		string sOption = (*iter).first ;
    	string sParam  = (*iter).second ;
      ps = string("- ") + sOption + sParam ;
			pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
    }
  }
}

NSUpdate::~NSUpdate()
{
}

bool
NSUpdate::init()
{
  ifstream inFile ;
	// on ouvre le fichier de configuration
  inFile.open(sSettingsFile.c_str()) ;
  if (!inFile)
  {
  	string sErrorMsg = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    sErrorMsg += string(" ") + sSettingsFile ;
    pContexte->getSuperviseur()->trace(&sErrorMsg, 1, NSSuper::trWarning) ;

    //
    // Make certain that warning messages won't be hidden by splash screen
    //
    HWND hWnd = 0 ;
    if (NULL != pContexte->getSuperviseur()->getApplication())
    {
  	  TSplashWindow* pSplashWin = pContexte->getSuperviseur()->getApplication()->getSplashWindow() ;
      if (NULL != pSplashWin)
    	  hWnd = pSplashWin->GetHandle() ;
    }
    erreur(sErrorMsg.c_str(), warningError, 0, hWnd) ;
    return false ;
  }

	string sLine ;
  string sData = string("") ;
  // on lit les param�tres de backup
	while (!inFile.eof())
	{
		getline(inFile, sLine) ;
    sData += sLine + "\n" ;
	}

  inFile.close() ;

  size_t i = 0 ;

  string sNomAttrib ;
  string sValAttrib ;

	while (i < strlen(sData.c_str()))
	{
		sNomAttrib = "" ;
		sValAttrib = "" ;

		while ((i < strlen(sData.c_str())) && (sData[i] != ' ') && (sData[i] != '\t'))
			sNomAttrib += pseumaj(sData[i++]) ;
		while ((i < strlen(sData.c_str())) && ((sData[i] == ' ') || (sData[i] == '\t')))
			i++ ;

		while ((i < strlen(sData.c_str())) && (sData[i] != '\n'))
			sValAttrib += sData[i++] ;

		i++ ;

		if 		((sNomAttrib == "URL") && (sValAttrib != ""))
      sURL = sValAttrib ;
    else if ((sNomAttrib == "LOGIN") && (sValAttrib != ""))
      sLogin = sValAttrib ;
    else if ((sNomAttrib == "PASSWORD") && (sValAttrib != ""))
      sPassword = sValAttrib ;
    else if ((sNomAttrib == "PROTOCOL") && (sValAttrib != ""))
		{
			for (size_t j = 0 ; j < strlen(sValAttrib.c_str()) ; j++)
				sValAttrib[j] = pseumaj(sValAttrib[j]) ;
      sProtocol = sValAttrib ;
    }
    else if ((sNomAttrib == "UPDATE_DIR") && (sValAttrib != ""))
      sUpdateDir = sValAttrib ;
		else if ((sNomAttrib == "LAST_UPDATE") && (sValAttrib != ""))
		{
			for (size_t j = 0 ; j < strlen(sValAttrib.c_str()) ; j++)
				sValAttrib[j] = pseumaj(sValAttrib[j]) ;

			if ((sValAttrib == string("NEVER")) || (sValAttrib == string("JAMAIS")))
				bLastUpdate = false ;
      else
        tLastUpdate.initFromDateHeure(sValAttrib) ;
		}
    else if ((sNomAttrib == "LAST_CHECK") && (sValAttrib != ""))
		{
			for (size_t j = 0 ; j < strlen(sValAttrib.c_str()) ; j++)
				sValAttrib[j] = pseumaj(sValAttrib[j]) ;

			if ((sValAttrib == string("NEVER")) || (sValAttrib == string("JAMAIS")))
				bLastUpdateCheck = false ;
      else
        tLastUpdateCheck.initFromDateHeure(sValAttrib) ;
		}
		else if ((sNomAttrib == "INTERVAL_DAYS") && (sValAttrib != ""))
		{
			for (size_t j = 0 ; j < strlen(sValAttrib.c_str()) ; j++)
				sValAttrib[j] = pseumaj(sValAttrib[j]) ;

			if ((sValAttrib == string("NEVER")) || (sValAttrib == string("JAMAIS")))
				bInterval = false ;
      else
      {
      	iInterval = atoi(sValAttrib.c_str()) ;
      	if (true == bLastUpdate)
        {
        	tNextUpdateCheck = tLastUpdate ;
        	tNextUpdateCheck.ajouteJours(iInterval) ;
        }
      }
		}
	}
  return true ;
}

bool
NSUpdate::mustCheckForUpdateAvailability()
{
  NVLdVTemps  tNow ;
  tNow.takeTime() ;

	if ((false == bInterval) || ((true == bLastUpdateCheck) && (tNextUpdateCheck > tNow)))
		return false ;

	return true ;
}

bool
NSUpdate::isUpdateAvailable()
{
	string sReleaseFile = string("releases.txt") ;
	if (string("") != sUpdateDir)
		sReleaseFile = sUpdateDir + sReleaseFile ;

	// don't download if sURL is the same as sUpdateDir
  //
  if (sURL != sUpdateDir)
	{
		if (string("") == sURL)
			return false ;

  	if (false == curl.bIsReady())
			return false ;

		curl.setURL(sURL) ;
		curl.setLogin(sLogin) ;
		curl.setPassword(sPassword) ;

  	bool bDownloadSuccess = curl.fileDownload(string("releases.txt"), sReleaseFile) ;

  	if (false == bDownloadSuccess)
    {
    	string ps = string("Curl download error: ") + curl.sLastCurlError ;
			pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;
			return false ;
    }
	}

  // Record that we checked
  updateLastCheckDate() ;

  ifstream inFile ;
	// opening releases history file
  //
  inFile.open(sReleaseFile.c_str()) ;
  if (!inFile)
  {
  	string sErrorMsg = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    sErrorMsg += string(" ") + sReleaseFile ;
    erreur(sErrorMsg.c_str(), warningError, 0) ;
    return false ;
  }

  string sLine = string("") ;
  // just reading the first non empty line
	while (!inFile.eof() && (string("") == sLine))
		getline(inFile, sLine) ;

  inFile.close() ;

	if (string("") == sLine)
		return false ;

  // Line is of the kind "----> 5.03.0034 28/08/2007"
  //
	size_t pos = sLine.find(' ') ;
	if (NPOS == pos)
		return false ;

	size_t pos2 = sLine.find(' ', pos + 1) ;
  if (NPOS == pos2)
		return false ;

	string sReleaseVersion = string(sLine, pos + 1, pos2 - pos - 1) ;

  if (sReleaseVersion > pContexte->getSuperviseur()->sNumVersion)
		return true ;

	return false ;
}

bool
NSUpdate::startUpdate()
{
	string sRemoteFile = string("Epi5_maj.exe") ;

	string sReleaseFile = sRemoteFile ;
	if (string("") != sUpdateDir)
  	sReleaseFile = sUpdateDir + sReleaseFile ;

	// don't download if sURL is the same as sUpdateDir
  //
  if (sURL != sUpdateDir)
	{
		bool bProgressBar = false ;
  	MemUnaFunctor<TMyApp, int>* pProgressBarFunctor = 0 ;

  	// Attach the progress bar to the splash screen's
  	//
 		TMyApp* pApplication = pContexte->getSuperviseur()->getApplication() ;
  	if (NULL != pApplication)
  	{
			pProgressBarFunctor = new MemUnaFunctor<TMyApp, int>(pApplication, &TMyApp::setSplashPercentDone) ;
    	bProgressBar = true ;
  	}

  	bool bDownloadSuccess = curl.fileDownload(sRemoteFile, sReleaseFile, bProgressBar, pProgressBarFunctor) ;

  	if (NULL != pProgressBarFunctor)
			delete pProgressBarFunctor ;

  	if (false == bDownloadSuccess)
			return false ;
	}

	// execution
	int iExecError = WinExec(sReleaseFile.c_str(), SW_SHOWNORMAL) ;
	if (iExecError > 31)
	{
  	// on doit remplacer la date de la derni�re sauvegarde dans le fichier backup.dat
    updateLastUpdateDate() ;
    return true ;
  }

  string sErrMsg ;
	switch (iExecError)
  {
		case 0                    :
    	erreur("The system is out of memory or resources.", standardError, 0) ;
      break ;
    case ERROR_BAD_FORMAT     :
    	sErrMsg = string("The .EXE file ( ") + sReleaseFile + string(" ) is invalid (non-Win32 .EXE or error in .EXE image)") ;
    	erreur(sErrMsg.c_str(), standardError, 0) ;
      break ;
    case ERROR_FILE_NOT_FOUND :
    	sErrMsg = string("The specified file was not found ( ") + sReleaseFile + string(" )") ;
    	erreur(sErrMsg.c_str(), standardError, 0) ;
      break ;
    case ERROR_PATH_NOT_FOUND :
      sErrMsg = string("The specified path was not found ( ") + sReleaseFile + string(" )") ;
    	erreur(sErrMsg.c_str(), standardError, 0) ;
    	break ;
    default                   :
    	sErrMsg = string("Unknown error when starting update ( ") + sReleaseFile + string(" )") ;
    	erreur(sErrMsg.c_str(), standardError, 0) ;
  }
  return false ;
}

bool
NSUpdate::updateLastCheckDate()
{
	ofstream  outFile ;
	outFile.open(sSettingsFile.c_str(), ios::out) ;
	if (!outFile)
		return false ;

	NVLdVTemps  tNow ;
	tNow.takeTime() ;

  string sLastUpdateDate ;
	if (true == tLastUpdate.estVide())
		sLastUpdateDate = string("never") ;
	else
  	sLastUpdateDate = tLastUpdate.donneDateHeure() ;

	char outLine[2048] ;
	sprintf(outLine, "URL %s\nLOGIN %s\nPASSWORD %s\nPROTOCOL %s\nUPDATE_DIR %s\nLAST_UPDATE %s\nLAST_CHECK %s\nINTERVAL_DAYS %d\n", sURL.c_str(), sLogin.c_str(), sPassword.c_str(), sProtocol.c_str(), sUpdateDir.c_str(), sLastUpdateDate.c_str(), tNow.donneDateHeure().c_str(), iInterval) ;
	outFile.write(outLine, strlen(outLine)) ;
	outFile.close() ;

	return true ;
}

bool
NSUpdate::updateLastUpdateDate()
{
	ofstream  outFile ;
	outFile.open(sSettingsFile.c_str(), ios::out) ;
	if (!outFile)
		return false ;

	NVLdVTemps  tNow ;
	tNow.takeTime() ;

  string sLastCheckDate ;
	if (true == tLastUpdateCheck.estVide())
		sLastCheckDate = string("never") ;
	else
  	sLastCheckDate = tLastUpdateCheck.donneDateHeure() ;

	char outLine[2048] ;
	sprintf(outLine, "URL %s\nLOGIN %s\nPASSWORD %s\nPROTOCOL %s\nUPDATE_DIR %s\nLAST_UPDATE %s\nLAST_CHECK %s\nINTERVAL_DAYS %d\n", sURL.c_str(), sLogin.c_str(), sPassword.c_str(), sProtocol.c_str(), sUpdateDir.c_str(), tNow.donneDateHeure().c_str(), sLastCheckDate.c_str(), iInterval) ;
	outFile.write(outLine, strlen(outLine)) ;
	outFile.close() ;

	return true ;
}

