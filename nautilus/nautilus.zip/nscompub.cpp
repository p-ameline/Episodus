// NSCOMPUB.CPP : M�thodes d�di�es � la composition et � la publication// RS Septembre 1997
//////////////////////////////////////////////////////////////////////////

#include "nautilus\Lettre.h"#include "nautilus\nssmtp.h"

#include <owl\applicat.h>#include <owl\olemdifr.h>
#include <owl\dialog.h>
#include <owl\edit.h>
#include <owl\color.h>
#include <owl\module.h>
#include <bde.hpp>
#include <stdio.h>
#include <string.h>
#include <winuser.h>
#include <classlib\date.h>
#include <classlib\time.h>

#include "nautilus\nssuper.h"#include "nautilus\nsanxary.h"
#include "partage\nsdivfct.h"
#include "partage\nsperson.h"
#include "nautilus\nsdochis.h"
#include "nautilus\nshistdo.h"
#include "nautilus\nsresour.h"
#include "nautilus\nsvisual.h"
#include "nautilus\nsbasimg.h"
#include "nautilus\nsbrowse.h"
#include "nautilus\nautilus.rh"
#include "nautilus\ns_html.h"
#include "nautilus\nscompub.h"
#include "nsbb\nsmanager.h"
#include "nautilus\nsdocview.h"
#include "nssavoir\nsgraphe.h"
#include "nssavoir\nsHealthTeam.h"
#include "nsdn\nsintrad.h"

#include "pilot\NautilusPilot.hpp"
#include "nsbb\tagNames.h"


TModule* pCryptoModule = 0;
bool bEnvoyerReturn = true ;

// handle de hook
HHOOK hhook ; 

// -----------------------------------------------------------------//
//  M�thodes de ChoixTemplateDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(ChoixTemplateDialog, NSUtilDialog)	EV_CHILD_NOTIFY_AND_CODE(IDC_TEMPLATEBOX, LBN_SELCHANGE, CmSelectTemplate),
	EV_CHILD_NOTIFY_AND_CODE(IDC_TEMPLATEBOX, LBN_DBLCLK, CmTemplateDblClk),
END_RESPONSE_TABLE;

ChoixTemplateDialog::ChoixTemplateDialog(TWindow* pere, NSContexte* pCtx, string typeDoc, string codeSensRoot)                    :NSUtilDialog(pere, pCtx, "IDD_TEMPLATE")
{
try
{
	pTemplateBox   = new OWL::TListBox(this, IDC_TEMPLATEBOX) ;
	pTemplateArray = new NSTemplateArray ;
	sTypeDoc       = typeDoc ;
	sCodeSensRoot  = codeSensRoot ;

	// on cherche les �quivalents s�mantiques du code Root	if (sCodeSensRoot != "")
		pContexte->getSuperviseur()->getFilGuide()->chercheEquivalent(sCodeSensRoot, &VectTermeEquivalentRoot, "ES") ;

	TemplateChoisi = 0 ;
	// fichiers d'aide	sHindex = "hi_doc.htm" ;
	sHcorps = "h_compos.htm" ;
}
catch (...)
{
	erreur("Exception ChoixTemplateDialog ctor", standardError, 0) ;
}
}

ChoixTemplateDialog::~ChoixTemplateDialog(){
	delete pTemplateBox ;
	delete pTemplateArray ;
}

voidChoixTemplateDialog::SetupWindow()
{
try
{
	string sCodeRootTmpl, sCodeSensTmpl ;
	string sTypeTmpl, sCompoTmpl, sUtilTmpl, sLibTmpl ;
	bool   bTypeTmplOK ;

	NSUtilDialog::SetupWindow() ;
	//	// Remplissage de TemplateBox avec les libelles des fichiers modele
	//
	// ------------ Appel du pilote
	NSObjectGraphManager ObjectManager(pContexte) ;	NSDataGraph* pGraph = ObjectManager.pDataGraph ;	string sTraitType = string("_0OTPL") + string("_0TYPE");  string sTraitOper = string("_0OTPL") + string("_DOPER");
  string sTraitCons = string("_0OTPL") + string("_LNUCO");
  string sTraitRoot = string("_0OTPL") + string("_0TYPC");
  string sTraitComp = string("_0OTPL") + string("_0COMD");
  string sTraitDefa = string("_0OTPL") + string("_0DEFA");  string sTraitLibelle = string("_0OTPL") + string("_0INTI");	NSPersonsAttributesArray ObjList ;	NSBasicAttributeArray AttrArray ;	string sTypeDocComplet = sTypeDoc ;  pContexte->getSuperviseur()->getDico()->donneCodeComplet(sTypeDocComplet) ;	AttrArray.push_back(new NSBasicAttribute(sTraitType, sTypeDocComplet)) ;
	bool res = pContexte->pPilot->objectList(NautilusPilot::SERV_OBJECT_LIST_WITH_TRAITS.c_str(),
                                    &ObjList, &AttrArray) ;
	if (!res)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "templateNotFound") ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return ;
	}	NSPatPathoArray PatPathoArray(pContexte, graphObject) ;	if (!ObjList.empty())  {  	for (NSPersonsAttributeIter i = ObjList.begin(); i != ObjList.end(); i++)    {    	string sOIDS = (*i)->getAttributeValue(OIDS) ;      AttrArray.vider() ;      pGraph->graphReset() ;      if (sOIDS != "")      {
      	//pList->push_back(new NSBasicAttribute("graphID", sOIDS)) ;
        AttrArray.push_back(new NSBasicAttribute(OBJECT, sOIDS)) ;
        res = pContexte->pPilot->invokeService(NautilusPilot::SERV_SEARCH_OBJECT_FROM_ID.c_str(), pGraph, &AttrArray) ;
        if (!res)
        {
        	string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "objectNotFound") ;
          if (sErrorText == "")
          	sErrorText = string("Echec service : Impossible de r�cup�rer un objet dans la base") ;
          sErrorText = string(" ") + sOIDS ;
          pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
          erreur(sErrorText.c_str(), standardError, 0) ;
          return ;
        }

        NSDataTreeIter iterTree ;
        PatPathoArray.vider() ;

        if (pGraph->aTrees.ExisteTree("0OTPL1", pContexte, &iterTree))
        	(*iterTree)->getPatPatho(&PatPathoArray) ;
        else
        {
        	erreur("Probl�me � la r�cup�ration du graphe d'un objet template.", standardError, 0);
          continue ;
        }

        ObjectManager.ParseTemplate(&PatPathoArray, &AttrArray) ;

        sCodeRootTmpl = AttrArray.getAttributeValue(sTraitRoot) ;
        sTypeTmpl     = AttrArray.getAttributeValue(sTraitType) ;
        sCompoTmpl    = AttrArray.getAttributeValue(sTraitComp) ;
        sUtilTmpl     = AttrArray.getAttributeValue(sTraitOper) ;
        sLibTmpl      = AttrArray.getAttributeValue(sTraitLibelle) ;

        bTypeTmplOK = false ;

        if (sCodeRootTmpl != "")        {
        	// le code root de la base template est-il un �quivalent du code root doc ?
          pContexte->getSuperviseur()->getDico()->donneCodeSens(&sCodeRootTmpl, &sCodeSensTmpl) ;

          for (EquiItemIter i = VectTermeEquivalentRoot.begin(); i != VectTermeEquivalentRoot.end(); i++)          {
          	if (sCodeSensTmpl == (*(*i)))
            {
            	bTypeTmplOK = true ;
              break ;
            }
          }
        }
        else // cas codeRoot == "", on regarde le type
        	if (sTypeDocComplet == sTypeTmpl)
          	bTypeTmplOK = true ;

        // On remplit la TemplateBox et le TemplateArray si le type correspond au type Document        // On regarde si compo == 1 (car utilis� en composition)
        // On regarde si on a le bon utilisateur ou aucun

        if ((bTypeTmplOK)                      &&
            (sCompoTmpl == "1")
                      &&
            ((sUtilTmpl == pContexte->getUtilisateur()->getNss()) ||
                     (sUtilTmpl == "")
              )
            )
        {
        	pTemplateBox->AddString(sLibTmpl.c_str()) ;
          pTemplateArray->push_back(new NSTemplateInfo(&AttrArray)) ;
        }
      }    }  }}catch (...)
{
	erreur("Exception ChoixTemplateDialog::SetupWindow.", standardError, 0) ;
}
}

void ChoixTemplateDialog::CmTemplateDblClk(WPARAM Cmd)
{
	TemplateChoisi = pTemplateBox->GetSelIndex() + 1;
	TDialog::CmOk();
}

void ChoixTemplateDialog::CmSelectTemplate(WPARAM Cmd){
	//
	// R�cup�ration de l'indice du template s�lectionn�
	//

	TemplateChoisi = pTemplateBox->GetSelIndex() + 1;}

void ChoixTemplateDialog::CmCancel(){
	TemplateChoisi = 0;

	TDialog::CmCancel();}

// -----------------------------------------------------------------//
//  M�thodes de NomCompoDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NomCompoDialog, NSUtilDialog)   EV_BN_CLICKED(IDC_NEWCOMPO, CmClickNewCompo),
   EV_BN_CLICKED(IDC_OLDCOMPO, CmClickOldCompo),
   EV_COMMAND(IDOK, CmOk),
   EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

NomCompoDialog::NomCompoDialog(TWindow* pere, NSContexte* pCtx)               :NSUtilDialog(pere, pCtx, "IDD_NOMCOMPO")
{
try
{
    pNomDocHtml = new OWL::TEdit(this, IDC_EDITNOMCOMPO, DOC_NOM_LEN);
    pNewCompo 	= new OWL::TRadioButton(this,IDC_NEWCOMPO,0);
    pOldCompo 	= new OWL::TRadioButton(this,IDC_OLDCOMPO,0);

    sNomDocHtml = "";}
catch (...)
{
	erreur("Exception NomCompoDialog ctor.", standardError, 0) ;
}
}

NomCompoDialog::~NomCompoDialog(){
    delete pNomDocHtml;
    delete pNewCompo;
    delete pOldCompo;
}

voidNomCompoDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow();

    pOldCompo->Check();    pNewCompo->Uncheck();
}

voidNomCompoDialog::CmClickNewCompo()
{
	pOldCompo->Uncheck();
}

voidNomCompoDialog::CmClickOldCompo()
{
	pNewCompo->Uncheck();
}

voidNomCompoDialog::CmOk()
{
	char far cfNomDocHtml[DOC_NOM_LEN + 1];

    pNomDocHtml->GetText(cfNomDocHtml,DOC_NOM_LEN);	sNomDocHtml = string(cfNomDocHtml);

	if ((pNewCompo->GetCheck()) == BF_CHECKED)    {
   	    if (sNomDocHtml == "")
        {
      	    MessageBox("Erreur : Vous n'avez pas saisi de nom pour le nouveau fichier");
            return;
        }
    }

    TDialog::CmOk();}

voidNomCompoDialog::CmCancel()
{
	TDialog::CmCancel();
}

// -----------------------------------------------------------------//
//  M�thodes de LettreTypeEditDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(LettreTypeEditDialog, NSUtilDialog)   EV_BN_CLICKED(IDC_LTYPEDIT_NEW, CmNouveau),
   EV_BN_CLICKED(IDC_LTYPEDIT_DEL, CmDetruire),
   EV_COMMAND(IDOK, CmOk),
   EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

LettreTypeEditDialog::LettreTypeEditDialog(TWindow* pere, NSContexte* pCtx)                     :NSUtilDialog(pere, pCtx, "IDD_LTYPEDIT")
{
try
{
	pData = new NSFormuleData() ;
	pEdit = new NSMultiEdit(pContexte, this, IDC_LTYPEDIT_EDIT, FORM_TEXTE1_LEN +
                                                     FORM_TEXTE2_LEN +
                                                     FORM_TEXTE3_LEN +
                                                     FORM_TEXTE4_LEN) ;
  bNew = false ;
  bDel = false ;
}
catch (...)
{
	erreur("Exception LettreTypeEditDialog ctor.", standardError, 0) ;
}
}

LettreTypeEditDialog::~LettreTypeEditDialog(){
	delete pEdit ;
}

voidLettreTypeEditDialog::SetupWindow()
{
    NSUtilDialog::SetupWindow();

    sTexte = "";
    if (strcmp(pData->code, ""))    {
        sTexte += pData->texte1;
        sTexte += pData->texte2;
        sTexte += pData->texte3;
        sTexte += pData->texte4;
    }
    else
        bNew = true;

    pEdit->FormatLines(true);    pEdit->SetText(sTexte.c_str());
}

voidLettreTypeEditDialog::CmNouveau()
{
    sTexte = "";

    pEdit->SetText("");
    bNew = true;}

voidLettreTypeEditDialog::CmDetruire()
{
    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();

    int idRet = MessageBox("Etes vous s�r de vouloir d�truire cette formule?", sCaption.c_str(), MB_YESNO);

    if (idRet == IDYES)    {
        bDel = true;

        if (bNew)            TDialog::CmCancel();
        else
            TDialog::CmOk();
    }
}

voidLettreTypeEditDialog::CmOk()
{
    pEdit->GetText(sTexte);

    // test pr�alable    if (strlen(sTexte.c_str()) > (FORM_TEXTE1_LEN + FORM_TEXTE2_LEN + FORM_TEXTE3_LEN + FORM_TEXTE4_LEN))
    {
        string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();

        int idRet = MessageBox("Attention le texte est trop long et va �tre tronqu�. Voulez-vous continuer ?", sCaption.c_str(), MB_YESNO);
        if (idRet == IDNO)            return;
    }

    strcpy(pData->texte1, "");    strcpy(pData->texte2, "");
    strcpy(pData->texte3, "");
    strcpy(pData->texte4, "");

    if (strlen(sTexte.c_str()) > FORM_TEXTE1_LEN)    {
        strcpy(pData->texte1, string(sTexte, 0, FORM_TEXTE1_LEN).c_str());
        sTexte = string(sTexte, FORM_TEXTE1_LEN, strlen(sTexte.c_str()) - FORM_TEXTE1_LEN + 1);
    }
    else
    {
        strcpy(pData->texte1, sTexte.c_str());
        TDialog::CmOk();
        return;
    }

    if (strlen(sTexte.c_str()) > FORM_TEXTE2_LEN)    {
        strcpy(pData->texte2, string(sTexte, 0, FORM_TEXTE2_LEN).c_str());
        sTexte = string(sTexte, FORM_TEXTE2_LEN, strlen(sTexte.c_str()) - FORM_TEXTE2_LEN + 1);
    }
    else
    {
        strcpy(pData->texte2, sTexte.c_str());
        TDialog::CmOk();
        return;
    }

    if (strlen(sTexte.c_str()) > FORM_TEXTE3_LEN)    {
        strcpy(pData->texte3, string(sTexte, 0, FORM_TEXTE3_LEN).c_str());
        sTexte = string(sTexte, FORM_TEXTE3_LEN, strlen(sTexte.c_str()) - FORM_TEXTE3_LEN + 1);
    }
    else
    {
        strcpy(pData->texte3, sTexte.c_str());
        TDialog::CmOk();
        return;
    }

    if (strlen(sTexte.c_str()) > FORM_TEXTE4_LEN)    {
        strcpy(pData->texte1, string(sTexte, 0, FORM_TEXTE4_LEN).c_str());
    }
    else
    {
        strcpy(pData->texte1, sTexte.c_str());
    }

    TDialog::CmOk();}

voidLettreTypeEditDialog::CmCancel()
{
    TDialog::CmCancel();
}

// -----------------------------------------------------------------
//
//  M�thodes de LettreTypeDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(LettreTypeDialog, NSUtilDialog)   EV_BN_CLICKED(IDC_LTYP_INTRO_SANS, CmClickSansIntro),
   EV_BN_CLICKED(IDC_LTYP_CORPS_SANS, CmClickSansCorps),
   EV_BN_CLICKED(IDC_LTYP_POLIT_SANS, CmClickSansPolit),
   EV_COMMAND(IDC_LTYP_INTRO_PREC, CmIntroPrec),
   EV_COMMAND(IDC_LTYP_INTRO_SUIV, CmIntroSuiv),
   EV_COMMAND(IDC_LTYP_INTRO_EDIT, CmEditIntro),
   EV_COMMAND(IDC_LTYP_CORPS_PREC, CmCorpsPrec),
   EV_COMMAND(IDC_LTYP_CORPS_SUIV, CmCorpsSuiv),
   EV_COMMAND(IDC_LTYP_CORPS_EDIT, CmEditCorps),
   EV_COMMAND(IDC_LTYP_POLIT_PREC, CmPolitPrec),
   EV_COMMAND(IDC_LTYP_POLIT_SUIV, CmPolitSuiv),
   EV_COMMAND(IDC_LTYP_POLIT_EDIT, CmEditPolit),
   EV_COMMAND(IDOK, CmOk),
   EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

LettreTypeDialog::LettreTypeDialog(TWindow* pere, NSContexte* pCtx)                 :NSUtilDialog(pere, pCtx, "IDD_LTYP")
{
try
{
  pIntro      = new NSUtilEdit(pContexte, this, IDC_LTYP_INTRO) ;
  pCorps      = new NSUtilEdit(pContexte, this, IDC_LTYP_CORPS) ;
  pPolit      = new NSUtilEdit(pContexte, this, IDC_LTYP_POLIT) ;
  pSansIntro  = new OWL::TRadioButton(this, IDC_LTYP_INTRO_SANS, 0) ;
  pSansCorps  = new OWL::TRadioButton(this, IDC_LTYP_CORPS_SANS, 0) ;
  pSansPolit  = new OWL::TRadioButton(this, IDC_LTYP_POLIT_SANS, 0) ;
  pIntroArray = new NSFormuleArray ;
  pCorpsArray = new NSFormuleArray ;
  pPolitArray = new NSFormuleArray ;

  nbIntro = 0 ;
  nbCorps = 0 ;
  nbPolit = 0 ;

  choixIntro = 0 ;
  choixCorps = 0 ;
  choixPolit = 0 ;

  sIntro = "" ;  sCorps = "" ;
  sPolit = "" ;
}
catch (...)
{
  erreur("Exception LettreTypeDialog ctor.", standardError, 0) ;
}
}

LettreTypeDialog::~LettreTypeDialog(){
	delete pIntro ;
  delete pCorps ;
  delete pPolit ;
  delete pSansIntro ;
  delete pSansCorps ;
  delete pSansPolit ;
  delete pIntroArray ;
  delete pCorpsArray ;
  delete pPolitArray ;
}

voidLettreTypeDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow();

    pSansIntro->Uncheck();    pSansCorps->Uncheck();
    pSansPolit->Uncheck();

	if (InitFormulesArray())    {
        pIntro->FormatLines(true);
        AfficheIntro();

        pCorps->FormatLines(true);        AfficheCorps();

        pPolit->FormatLines(true);        AffichePolit();
    }
    else
    	erreur("La base des formules est inaccessible.", standardError, 0, GetHandle()) ;
}

boolLettreTypeDialog::InitFormulesArray()
{
try
{
    // pour le cas base vide
    sLastCode = "000";

	NSFormule* pFormule = new NSFormule(pContexte);
	pFormule->lastError = pFormule->open();
	if (pFormule->lastError != DBIERR_NONE)	{
		erreur("Impossible d'ouvrir le fichier Formule.", standardError, pFormule->lastError, GetHandle());
		delete pFormule;
		return false;
	}

    pFormule->lastError = pFormule->debut(dbiWRITELOCK);
    if (pFormule->lastError == DBIERR_BOF)    {
     	pFormule->close();
		delete pFormule;
		return true;
	}

    while (pFormule->lastError != DBIERR_EOF)    {
   	    pFormule->lastError = pFormule->getRecord();

   	    if (pFormule->lastError != DBIERR_NONE)   	    {
			erreur("Erreur � la lecture d'une formule.", standardError, pFormule->lastError, GetHandle());
      	    pFormule->close();
			delete pFormule;
			return false;
		}

        sLastCode = pFormule->pDonnees->code;
        switch (pFormule->pDonnees->type[0])        {
        	case 'A':
            	pIntroArray->push_back(new NSFormuleInfo(pFormule));
                nbIntro++;
                break;

            case 'B':            	pCorpsArray->push_back(new NSFormuleInfo(pFormule));
                nbCorps++;
                break;

            case 'C':                pPolitArray->push_back(new NSFormuleInfo(pFormule));
                nbPolit++;
                break;

            default:            	erreur("Type de formule non pr�vu dans la base", standardError, 0, GetHandle()) ;
        }

        // on passe � la formule suivante        pFormule->lastError = pFormule->suivant(dbiWRITELOCK);

   	    if ((pFormule->lastError != DBIERR_NONE) && (pFormule->lastError != DBIERR_EOF))   	    {
			erreur("Erreur d'acc�s � la formule suivante.", standardError, pFormule->lastError, GetHandle());
      	    pFormule->close();
			delete pFormule;
			return false;
		}
    } // fin du while

    // on ferme la base Formule
    pFormule->lastError = pFormule->close();

	if (pFormule->lastError != DBIERR_NONE)	{
		erreur("Impossible de fermer le fichier Formule.", standardError, pFormule->lastError, GetHandle()) ;
		delete pFormule;
		return false;
	}

    delete pFormule;    return true;
}
catch (...)
{
	erreur("Exception LettreTypeDialog::InitFormulesArray.", standardError, 0) ;
	return false ;
}
}

voidLettreTypeDialog::RemplaceTags(string& sTexte)
{
  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	// remplacement du tag [nomPatient]
	//
	string sNomLong    = string("") ;
  string sEpisodusId = string("") ;
  if (NULL != pContexte->getPatient())
  {
  	pContexte->getPatient()->fabriqueNomLong() ;
    sNomLong = pContexte->getPatient()->getNomLong() ;
  }
	size_t pos = sTexte.find("[nomPatient]") ;
	while (pos != NPOS)
	{
    sTexte.replace(pos, strlen("[nomPatient]"), sNomLong) ;
		pos = sTexte.find("[nomPatient]", pos + 1) ;
  }
	// remplacement du tag [dateJour]	char dateJ[9], message[11] ;
  pos = sTexte.find("[dateJour]") ;
	while (pos != NPOS)
	{
  	donne_date_duJour(dateJ) ;
		donne_date(dateJ, message, sLang) ;
		sTexte.replace(pos, strlen("[dateJour]"), message) ;
		pos = sTexte.find("[dateJour]", pos + strlen(message)) ;
	}
}

voidLettreTypeDialog::AfficheIntro()
{
	string sTexte = "";

    if (nbIntro)    {
        sTexte += ((*pIntroArray)[choixIntro])->pDonnees->texte1;
        sTexte += ((*pIntroArray)[choixIntro])->pDonnees->texte2;
        sTexte += ((*pIntroArray)[choixIntro])->pDonnees->texte3;
        sTexte += ((*pIntroArray)[choixIntro])->pDonnees->texte4;

        RemplaceTags(sTexte);        sIntro = sTexte;
        pIntro->SetText(sTexte.c_str());
    }
    else
        pIntro->SetText("<vide>");
}

voidLettreTypeDialog::AfficheCorps()
{
	string sTexte = "";

    if (nbCorps)    {
        sTexte += ((*pCorpsArray)[choixCorps])->pDonnees->texte1;
        sTexte += ((*pCorpsArray)[choixCorps])->pDonnees->texte2;
        sTexte += ((*pCorpsArray)[choixCorps])->pDonnees->texte3;
        sTexte += ((*pCorpsArray)[choixCorps])->pDonnees->texte4;

        RemplaceTags(sTexte);
        sCorps = sTexte;        pCorps->SetText(sTexte.c_str());
    }
    else
        pCorps->SetText("<vide>");
}

voidLettreTypeDialog::AffichePolit()
{
	string sTexte = "";

    if (nbPolit)    {
        sTexte += ((*pPolitArray)[choixPolit])->pDonnees->texte1;
        sTexte += ((*pPolitArray)[choixPolit])->pDonnees->texte2;
        sTexte += ((*pPolitArray)[choixPolit])->pDonnees->texte3;
        sTexte += ((*pPolitArray)[choixPolit])->pDonnees->texte4;

        RemplaceTags(sTexte);
        sPolit = sTexte;        pPolit->SetText(sTexte.c_str());
    }
    else
        pPolit->SetText("<vide>");
}

voidLettreTypeDialog::CmIntroPrec()
{
	if (nbIntro && (choixIntro >= 0))
    {
    	choixIntro--;

        if (choixIntro < 0)        	choixIntro = nbIntro - 1;

        AfficheIntro();    }
}

voidLettreTypeDialog::CmIntroSuiv()
{
	if (nbIntro && (choixIntro >= 0))
    {
    	choixIntro++;

        if (choixIntro == nbIntro)        	choixIntro = 0;

        AfficheIntro();    }
}

voidLettreTypeDialog::CmCorpsPrec()
{
	if (nbCorps && (choixCorps >= 0))
    {
    	choixCorps--;

        if (choixCorps < 0)        	choixCorps = nbCorps - 1;

        AfficheCorps();    }
}

voidLettreTypeDialog::CmCorpsSuiv()
{
	if (nbCorps && (choixCorps >= 0))
    {
    	choixCorps++;

        if (choixCorps == nbCorps)        	choixCorps = 0;

        AfficheCorps();    }
}

voidLettreTypeDialog::CmPolitPrec()
{
	if (nbPolit && (choixPolit >= 0))
    {
    	choixPolit--;

        if (choixPolit < 0)        	choixPolit = nbPolit - 1;

        AffichePolit();    }
}

voidLettreTypeDialog::CmPolitSuiv()
{
	if (nbPolit && (choixPolit >= 0))
    {
    	choixPolit++;

        if (choixPolit == nbPolit)        	choixPolit = 0;

        AffichePolit();    }
}

voidLettreTypeDialog::CmClickSansIntro()
{
	if (choixIntro >= 0)
    {
    	sIntro = "";
        pIntro->SetText("");
        pSansIntro->Check();
        choixIntro = -1;
    }
    else
    {
    	choixIntro = 0;
        pSansIntro->Uncheck();
        AfficheIntro();
    }
}

voidLettreTypeDialog::CmClickSansCorps()
{
	if (choixCorps >= 0)
    {
    	sCorps = "";
        pCorps->SetText("");
        pSansCorps->Check();
        choixCorps = -1;
    }
    else
    {
    	choixCorps = 0;
        pSansCorps->Uncheck();
        AfficheCorps();
    }
}

voidLettreTypeDialog::CmClickSansPolit()
{
	if (choixPolit >= 0)
    {
    	sPolit = "";
        pPolit->SetText("");
        pSansPolit->Check();
        choixPolit = -1;
    }
    else
    {
    	choixPolit = 0;
        pSansPolit->Uncheck();
        AffichePolit();
    }
}

voidLettreTypeDialog::CmEditIntro()
{
try
{
    string mode;

    NSFormuleInfo* pForm = new NSFormuleInfo();
    if ((pSansIntro->GetCheck()) == BF_CHECKED)        return;

    if (nbIntro)        *(pForm->pDonnees) = *(((*pIntroArray)[choixIntro])->pDonnees);

    CmEditFormule(pForm->pDonnees, mode);
    if (mode == "new")    {
        pIntroArray->push_back(new NSFormuleInfo(*pForm));
        nbIntro++;
        choixIntro = nbIntro - 1;
        AfficheIntro();
    }
    else if (mode == "mod")
    {
        *(((*pIntroArray)[choixIntro])->pDonnees) = *(pForm->pDonnees);
        AfficheIntro();
    }
    else if (mode == "del")
    {
        NSFormuleIter i;
        int j;

        for (i = pIntroArray->begin(), j = 0; i != pIntroArray->end(); j++)        {
            if (j == choixIntro)
            {
   	            delete *i;
                pIntroArray->erase(i);
                break;
            }
        }

        nbIntro--;        choixIntro = 0;
        AfficheIntro();
    }
}
catch (...)
{
	erreur("Exception LettreTypeDialog::CmEditIntro.", standardError, 0) ;
}
}

voidLettreTypeDialog::CmEditCorps()
{
try
{
    string mode;

    NSFormuleInfo* pForm = new NSFormuleInfo();
    if ((pSansCorps->GetCheck()) == BF_CHECKED)        return;

    if (nbCorps)        *(pForm->pDonnees) = *(((*pCorpsArray)[choixCorps])->pDonnees);

    CmEditFormule(pForm->pDonnees, mode);
    if (mode == "new")    {
        pCorpsArray->push_back(new NSFormuleInfo(*pForm));
        nbCorps++;
        choixCorps = nbCorps - 1;
        AfficheCorps();
    }
    else if (mode == "mod")
    {
        *(((*pCorpsArray)[choixCorps])->pDonnees) = *(pForm->pDonnees);
        AfficheCorps();
    }
    else if (mode == "del")
    {
        NSFormuleIter i;
        int j;

        for (i = pCorpsArray->begin(), j = 0; i != pCorpsArray->end(); j++)        {
            if (j == choixCorps)
            {
   	            delete *i;
                pCorpsArray->erase(i);
                break;
            }
        }

        nbCorps--;        choixCorps = 0;
        AfficheCorps();
    }
}
catch (...)
{
	erreur("Exception LettreTypeDialog::CmEditCorps.", standardError, 0) ;
}
}

voidLettreTypeDialog::CmEditPolit()
{
try
{
	if ((pSansPolit->GetCheck()) == BF_CHECKED)		return ;

	string mode ;
	NSFormuleInfo FormInfo ;

	if (nbPolit)  	*(FormInfo.pDonnees) = *(((*pPolitArray)[choixPolit])->pDonnees);

	CmEditFormule(FormInfo.pDonnees, mode) ;
	if (mode == "new")	{
  	pPolitArray->push_back(new NSFormuleInfo(FormInfo)) ;
    nbPolit++ ;
    choixPolit = nbPolit - 1 ;
    AffichePolit() ;
	}
  else if (mode == "mod")
  {
  	*(((*pPolitArray)[choixPolit])->pDonnees) = *(FormInfo.pDonnees) ;
    AffichePolit() ;
  }
  else if (mode == "del")
  {
  	NSFormuleIter i ;
    int j ;

    if (!(pPolitArray->empty()))
    	for (i = pPolitArray->begin(), j = 0; i != pPolitArray->end(); j++)    	{
    		if (j == choixPolit)
      	{
      		delete *i ;
        	pPolitArray->erase(i) ;
        	break ;
      	}
    	}

    nbPolit-- ;    choixPolit = 0 ;
    AffichePolit() ;
  }
}
catch (...)
{
	erreur("Exception LettreTypeDialog::CmEditPolit.", standardError, 0) ;
}
}

voidLettreTypeDialog::CmEditFormule(NSFormuleData* pFormData, string& sMode)
{
try
{
    LettreTypeEditDialog* pEditDlg = new LettreTypeEditDialog(this, pContexte);
    *(pEditDlg->pData) = *pFormData;

    sMode = "annul";
    if (pEditDlg->Execute() == IDOK)    {
        NSFormule* pFormule = new NSFormule(pContexte);
	    pFormule->lastError = pFormule->open();
	    if (pFormule->lastError != DBIERR_NONE)
	    {
		    erreur("Impossible d'ouvrir le fichier Formule.", standardError, pFormule->lastError, GetHandle()) ;
		    delete pFormule;
		    return;
	    }

        if (pEditDlg->bNew)        {
            if (!pFormule->IncrementeCode(&sLastCode))
            {
                erreur("Erreur � l'attribution d'un code formule.", standardError, pFormule->lastError, GetHandle());
     	        pFormule->close();
		        delete pFormule;
		        return;
            }

            *(pFormule->pDonnees) = *(pEditDlg->pData);            strcpy(pFormule->pDonnees->code, sLastCode.c_str());

            pFormule->lastError = pFormule->appendRecord();
            if (pFormule->lastError != DBIERR_NONE)            {
                erreur("Erreur � l'ajout de la nouvelle formule.", standardError, pFormule->lastError, GetHandle()) ;
     	        pFormule->close();
		        delete pFormule;
		        return;
            }

            *pFormData = *(pEditDlg->pData);            sMode = "new";
        }
        else
        {
            // Attention la base est index�e sur code + type
            string sCode = string(pEditDlg->pData->code) + string(pEditDlg->pData->type);

            // on recherche la fiche dans la base            pFormule->lastError = pFormule->chercheClef(&sCode,
                                                       "",
													   0,
													   keySEARCHEQ,
													   dbiWRITELOCK);

            if (pFormule->lastError != DBIERR_NONE)            {
		        erreur("Erreur � la recherche de la formule.", standardError, pFormule->lastError, GetHandle()) ;
     	        pFormule->close();
		        delete pFormule;
		        return;
            }

            if (pEditDlg->bDel)            {
                pFormule->lastError = pFormule->deleteRecord();

                if (pFormule->lastError != DBIERR_NONE)                {
                    erreur("Erreur � la destruction de la formule.", standardError, pFormule->lastError, GetHandle()) ;
     	            pFormule->close();
		            delete pFormule;
		            return;
                }

                sMode = "del";            }
            else
            {
                *(pFormule->pDonnees) = *(pEditDlg->pData);

                pFormule->lastError = pFormule->modifyRecord(TRUE);
                if (pFormule->lastError != DBIERR_NONE)                {
                    erreur("Erreur � la modification de la formule.", standardError, pFormule->lastError, GetHandle()) ;
     	            pFormule->close();
		            delete pFormule;
		            return;
                }

                *pFormData = *(pEditDlg->pData);                sMode = "mod";
            }
        }

        pFormule->lastError = pFormule->close();
	    if (pFormule->lastError != DBIERR_NONE)		    erreur("Impossible de fermer le fichier Formule.", standardError, pFormule->lastError, GetHandle()) ;

        delete pFormule;    }
}
catch (...)
{
	erreur("Exception LettreTypeDialog::CmEditFormule.", standardError, 0) ;
}
}

voidLettreTypeDialog::CmOk()
{
	TDialog::CmOk();
}

voidLettreTypeDialog::CmCancel()
{
	TDialog::CmCancel();
}

// -----------------------------------------------------------------
//
//  M�thodes de NSPubliEdit
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSPubliEdit, NSUtilEdit)	EV_WM_CHAR,
END_RESPONSE_TABLE;

NSPubliEdit::NSPubliEdit(NSContexte *pCtx, NSUtilDialog* pUtilDialog, int resId, int iTextLen, bool bReturn)            :NSUtilEdit(pCtx, pUtilDialog, resId, iTextLen, bReturn){
  iResId = resId ;
}

NSPubliEdit::~NSPubliEdit(){
}

void
NSPubliEdit::EvChar(uint key, uint repeatCount, uint flags)
{
	// char far sNbExpl[WF_NB_PUBLI_LEN + 1] ;
  char far sNbExpl[3] ;
	char far sUrl[COR_MESSAGERIE_LEN + 1] ;

	UINT 		correspSelect ;
	PubliCorrespDialog* pPCDialog = dynamic_cast<PubliCorrespDialog*>(pNSUtilDialog) ;	NSPersonInfo* pCorrespSelect ;
	correspSelect  = pPCDialog->pCorrespBox->GetSelIndex() ;	pCorrespSelect = pPCDialog->aCorrespArray[correspSelect] ;

	NSUtilEdit::EvChar(key,repeatCount,flags) ;
	if (iResId == IDC_PUBLIER_NBEXPL)	{
  	// GetText(sNbExpl, WF_NB_PUBLI_LEN + 1) ;
    GetText(sNbExpl, 3) ;
    pPCDialog->SetNbExpl(pCorrespSelect, sNbExpl) ;
  }
  else if (iResId == IDC_PUBLIER_URL)
  {
  	GetText(sUrl, COR_MESSAGERIE_LEN + 1) ;
    pPCDialog->SetUrl(pCorrespSelect, sUrl) ;
	}
}

// -----------------------------------------------------------------//
//  M�thodes de PubliCorrespDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(PubliCorrespDialog, NSUtilDialog)	EV_CHILD_NOTIFY_AND_CODE(IDC_PUBLIER_CORRESPBOX, LBN_SELCHANGE, CmSelectCorresp),
	EV_CHILD_NOTIFY_AND_CODE(IDC_PUBLIER_CORRESPBOX, LBN_DBLCLK, CmCorrespDblClk),
	EV_COMMAND(IDC_PUBLIER_SELECT,        LanceChoixCorrespDialog),
  EV_BN_CLICKED(IDC_PUBLIER_IMPRIMANTE, CmClickImprimante),
  EV_BN_CLICKED(IDC_PUBLIER_EMAIL,      CmClickEmail),
  EV_BN_CLICKED(IDC_PUBLIER_INTRANET,   CmClickIntranet),
  EV_BN_CLICKED(IDC_PUBLIER_HTML,       CmClickHtml),
  EV_BN_CLICKED(IDC_PUBLIER_JOINDRE,    CmClickJoindre),
  EV_BN_CLICKED(IDC_PUBLIER_LETTRE,     CmLettreType),
  EV_BN_CLICKED(IDC_PUBLIER_PATIENT,    CmAjouterPatient),
  EV_BN_CLICKED(IDC_PUBLIER_BLANK,      CmAjouterBlank),
  EV_COMMAND(IDOK, CmOk),
  EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

PubliCorrespDialog::PubliCorrespDialog(TWindow* pere, NSContexte* pCtx, NSPublication* pPublication)
                   :NSUtilDialog(pere, pCtx, "IDD_PUBLIER"), aCorrespArray(pCtx)
{
try
{
	pCorrespBox   = new OWL::TListBox(this, IDC_PUBLIER_CORRESPBOX) ;
	pAdresse      = new NSUtilEdit(pContexte, this, IDC_PUBLIER_ADRESSE) ;
	// pNbExpl       = new NSPubliEdit(this, IDC_PUBLIER_NBEXPL, WF_NB_PUBLI_LEN) ;
  pNbExpl       = new NSPubliEdit(pContexte, this, IDC_PUBLIER_NBEXPL, 2) ;
	pUrl          = new NSPubliEdit(pContexte, this, IDC_PUBLIER_URL, COR_MESSAGERIE_LEN) ;
	pImprimante   = new OWL::TRadioButton(this, IDC_PUBLIER_IMPRIMANTE, 0) ;
	pEmail        = new OWL::TRadioButton(this, IDC_PUBLIER_EMAIL, 0) ;
	pIntranet     = new OWL::TRadioButton(this, IDC_PUBLIER_INTRANET, 0) ;
	pHtml         = new OWL::TRadioButton(this, IDC_PUBLIER_HTML, 0) ;
	pLettre       = new OWL::TCheckBox(this, IDC_PUBLIER_LETTRE) ;
	pJoindre      = new OWL::TRadioButton(this, IDC_PUBLIER_JOINDRE, 0) ;
	pPubliPatient = new OWL::TRadioButton(this, IDC_PUBLIER_PATIENT, 0) ;
	pPubliBlank   = new OWL::TRadioButton(this, IDC_PUBLIER_BLANK, 0) ;

	pLettreType   = 0 ;	pPubli = pPublication ;
	pCorrespBaseArray = &(pPubli->aCorrespBaseArray) ;
	pContexte->setAideIndex("hi_doc.htm") ;	pContexte->setAideCorps("h_publi.htm#Phase2") ;
}
catch (...)
{
	erreur("Exception PubliCorrespDialog ctor.", standardError, 0) ;
}
}

PubliCorrespDialog::~PubliCorrespDialog(){
	delete pPubliPatient ;
  delete pPubliBlank ;
	delete pJoindre ;
	delete pLettre ;
	delete pHtml ;
	delete pIntranet ;
	delete pEmail ;
	delete pImprimante ;
	delete pAdresse ;
	delete pUrl ;
	delete pNbExpl ;
	delete pCorrespBox ;

	// le delete de pLettreType est pris en charge par CmOk et CmCancel	pPubli = 0 ;					  // ne pas deleter
	pCorrespBaseArray = 0 ;    // ne pas deleter
}

voidPubliCorrespDialog::InitCorrespArray()
{
try
{
	aCorrespArray.vider() ;
	pPubliPatient->Uncheck() ;
	if (pCorrespBaseArray->empty())
		return ;

	for (NSPersonIter i = pCorrespBaseArray->begin(); i != pCorrespBaseArray->end(); i++)
	{  	// Checking if this person is selected    //  	int j = 0 ;  	for ( ; (j < MAXSELECT) && (string(pPubli->aChoixPubli[j].corresp) != (*i)->sPersonID) ; j++) ;    if ((j < MAXSELECT) && (true == pPubli->aChoixPubli[j].select))    {  		// on v�rifie s'il existe d�j� un patient dans les correspondants    	if ((NULL != pContexte->getPatient()) && (!strcmp((*i)->getszPersonID(), pContexte->getPatient()->getszNss())))    		pPubliPatient->Check() ;    	// on ajoute les corresps s�lectionn�s � l'array courant
    	aCorrespArray.push_back(new NSPersonInfo(*(*i))) ;
    }
	}

/* Previous code
	int j = 0 ;
	for (NSPersonIter i = pCorrespBaseArray->begin(); i != pCorrespBaseArray->end(); i++,j++)	{		if (pPubli->aChoixPubli[j].select)		{    	// on v�rifie s'il existe d�j� un patient dans les correspondants      if (!strcmp((*i)->getszPersonID(), pContexte->getPatient()->getszNss()))      	pPubliPatient->Check() ;    	// on ajoute les corresps s�lectionn�s � l'array courant
			aCorrespArray.push_back(new NSPersonInfo(*(*i)));
		}
	}
*/
}catch (...)
{
	erreur("Exception PubliCorrespDialog::InitCorrespArray", standardError, 0) ;
}
}

voidPubliCorrespDialog::AfficheCorresp()
{
	string sCorresp ;

	// on reprend le tableau � chaque coup � cause des changements de s�lection	InitCorrespArray() ;

	// on vide la liste si elle contient des items	if (pCorrespBox->GetCount())
		pCorrespBox->ClearList() ;

	if (!(aCorrespArray.empty()))	{
  	for (NSPersonIter i = aCorrespArray.begin(); i != aCorrespArray.end(); i++)
    {
    	// on remplit la CorrespBox
      if (string("") == (*i)->sPersonID)
      {
      	string sBlankAddressText = pContexte->getSuperviseur()->getText("publishingManagement", "blankAddress") ;
        pCorrespBox->AddString(sBlankAddressText.c_str()) ;
      }
      else
      {
      	sCorresp = (*i)->sNom + string(" ") + (*i)->sPrenom ;
      	pCorrespBox->AddString(sCorresp.c_str()) ;
      }
    }
  }

	pAdresse->SetText("") ;	pNbExpl->SetText("") ;

	if (!aCorrespArray.empty())	{
  	pCorrespBox->SetSelIndex(0) ;
    AfficheAdresse(aCorrespArray[0]) ;
    AfficheChoixPubli(aCorrespArray[0]) ;
	}
	else
	{
		pImprimante->Uncheck() ;
		pEmail->Uncheck() ;
		pIntranet->Uncheck() ;
		pHtml->Uncheck() ;
		pLettre->Uncheck() ;
		pJoindre->Uncheck() ;
	}
}

voidPubliCorrespDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;
	pAdresse->FormatLines(true) ;

	//	// Remplissage de CorrespBox avec le NSCorrespArray
	//
	AfficheCorresp() ;
}

voidPubliCorrespDialog::LanceChoixCorrespDialog()
{
	ChoixCorrespDialog(pContexte->GetMainWindow(), pContexte, pPubli).Execute() ;

	AfficheCorresp() ;}

voidPubliCorrespDialog::SetNbExpl(NSPersonInfo *pCorrespSelect, char* sNbExpl){
	for (int index = 0; index < MAXSELECT; index ++)
	{
  	if (!strcmp(pCorrespSelect->getszPersonID(), pPubli->aChoixPubli[index].corresp))
    {
    	if (pPubli->aChoixPubli[index].imprimante)
      {
      	strcpy(pPubli->aChoixPubli[index].nb_expl, sNbExpl) ;
        pPubli->aChoixPubli[index].cpt = atoi(pPubli->aChoixPubli[index].nb_expl) ;
        break ;
      }
    }
  }
}

voidPubliCorrespDialog::SetUrl(NSPersonInfo *pCorrespSelect, char* sUrl){
	for (int index = 0; index < MAXSELECT; index ++)
	{
		if (!strcmp(pCorrespSelect->getszPersonID(), pPubli->aChoixPubli[index].corresp))
		{
    	if (pPubli->aChoixPubli[index].email)
      {
      	strcpy(pPubli->aChoixPubli[index].url, sUrl) ;
        break ;
      }
    }
	}
}

boolPubliCorrespDialog::ExisteLettre(NSPersonInfo *pCorrespSelect){
try
{
	if (NULL == pCorrespSelect)
		return false ;

	string sDocId = pPubli->getCodeLettre(pCorrespSelect->sPersonID) ;

  return !(string("") == sDocId) ;
}
catch (...)
{
	erreur("Exception PubliCorrespDialog::ExisteLettre.", standardError, 0) ;
	return false ;
}
}

voidPubliCorrespDialog::AfficheChoixPubli(NSPersonInfo *pCorrespSelect){
	for (int index = 0; index < MAXSELECT; index ++)
	{
		if (!strcmp(pCorrespSelect->getszPersonID(), pPubli->aChoixPubli[index].corresp))
		{
    	if (pPubli->aChoixPubli[index].imprimante)
      {
      	pImprimante->Check() ;
        pNbExpl->SetText(pPubli->aChoixPubli[index].nb_expl) ;
      }
      else
      {
      	pImprimante->Uncheck() ;
        pNbExpl->SetText("") ;
      }

      if (pPubli->aChoixPubli[index].email)      {
      	pEmail->Check() ;
        string sEmail ;
        PIDSTYPE iTypePids ;
        if ((NULL != pContexte->getPatient()) && (!strcmp(pCorrespSelect->getszPersonID(), pContexte->getPatient()->getszNss())))
        	iTypePids = pidsPatient ;
        else
        	iTypePids = pidsCorresp ;

        pCorrespSelect->getPersonGraph()->trouveEMail(iTypePids, sEmail) ;
        strcpy(pPubli->aChoixPubli[index].url, sEmail.c_str()) ;
        pUrl->SetText(pPubli->aChoixPubli[index].url) ;
      }
      else
      {
      	pEmail->Uncheck() ;
        pUrl->SetText("") ;
      }

      if (pPubli->aChoixPubli[index].intranet)      	pIntranet->Check() ;
      else
      	pIntranet->Uncheck() ;

      if (pPubli->aChoixPubli[index].html)      	pHtml->Check() ;
      else
      	pHtml->Uncheck() ;

      if (ExisteLettre(pCorrespSelect))      {
      	pLettre->Check() ;

        if (pPubli->aChoixPubli[index].lettre)        	pJoindre->Check() ;
        else
        	pJoindre->Uncheck() ;
      }
      else
      {
      	pLettre->Uncheck() ;
        pJoindre->Uncheck() ;
        pPubli->aChoixPubli[index].lettre = false ;
      }

      break ;    }
  }
}

voidPubliCorrespDialog::AfficheAdresse(NSPersonInfo *pCorrespSelect){
	string sAdresse = "" ;

	// on charge ici en m�moire le graphe de personne et le graphe d'adresse
	string sNss = string(pCorrespSelect->sPersonID) ;

	if (string("") != sNss)
	{
		if ((NULL != pContexte->getPatient()) && (!strcmp(sNss.c_str(), pContexte->getPatient()->getszNss())))
  		sAdresse = pCorrespSelect->getMainAdr(pidsPatient) ;
		else
			sAdresse = pCorrespSelect->getMainAdr(pidsCorresp) ;
	}

	pAdresse->SetText(sAdresse.c_str()) ;
}

stringPubliCorrespDialog::CodeCorrespSelect()
{
  int iSelIndx = pCorrespBox->GetSelIndex() ;
  if (iSelIndx < 0)
    return string("") ;

  CorrespChoisi = iSelIndx ;
	NSPersonInfo *pCorrespSelect = aCorrespArray[CorrespChoisi] ;

	return string(pCorrespSelect->getszPersonID()) ;
}
// Fonction r�cup�rant le code document de la lettre d'accompagnement// selon le code du correspondant s�lectionn�
/////////////////////////////////////////////////////////////////////

boolPubliCorrespDialog::CodeDocLettreSelect(string& sCode)
{
try
{
	NSPersonInfo *pCorrespSelect ;
	string				sCodeCourrier ;

	CorrespChoisi = pCorrespBox->GetSelIndex() ;	pCorrespSelect = aCorrespArray[CorrespChoisi] ;

	sCode = pPubli->getCodeLettre(pCorrespSelect->sPersonID) ;

  return !(string("") == sCode) ;
}
catch (...)
{
	erreur("Exception PubliCorrespDialog::CodeDocLettreSelect.", standardError, 0) ;
	return false ;
}
}

voidPubliCorrespDialog::CheckLettre()
{
	NSPersonInfo *pCorrespSelect ;

	CorrespChoisi = pCorrespBox->GetSelIndex() ;
	pCorrespSelect = aCorrespArray[CorrespChoisi] ;
	if (ExisteLettre(pCorrespSelect))	{
		pLettre->Check() ;

		for (int index = 0; index < MAXSELECT; index ++)		{
    	if (!strcmp(pCorrespSelect->getszPersonID(), pPubli->aChoixPubli[index].corresp))
      {
      	pJoindre->Check() ;
        pPubli->aChoixPubli[index].lettre = true ;
        break ;
      }
    }
  }
  else
  {
  	pLettre->Uncheck() ;
    pJoindre->Uncheck() ;
  }
}

voidPubliCorrespDialog::CmAjouterPatient()
{
try
{
	NSPatientChoisi* pPatChoisi = pContexte->getPatient() ;
  if (NULL == pPatChoisi)
		return ;

	int i ;
	bool bIsCheck = false ;

	// on v�rifie s'il existe d�j� un patient dans les correspondants  if (!(pCorrespBaseArray->empty()))		for (NSPersonIter j = pCorrespBaseArray->begin(); j != pCorrespBaseArray->end(); j++)		{
  		if (!strcmp((*j)->getszPersonID(), pPatChoisi->getszNss()))
    	{
    		bIsCheck = true ;
      	break ;
    	}
  	}

	if (!bIsCheck)	{
		// on rajoute le patient au tableau des correspondants
    NSPersonInfo PatInfo(pContexte, pPatChoisi->getNss(), pidsPatient) ;
		// on cherche l'indice du dernier corresp dans pPubli->aChoixPubli
    for (i = 0; i < MAXSELECT; i++)
    	if (false == pPubli->aChoixPubli[i].select)
    	// if (!strcmp(pPubli->aChoixPubli[i].corresp, ""))
      	break ;

    if (i == MAXSELECT)		{
    	erreur("Vous avez d�pass� la limite des s�lections possibles. Vous ne pourrez pas publier vers le patient.", standardError, 0, GetHandle()) ;
      return ;
    }

    // on DOIT ajouter le patient directement dans NSPubli    // � cause du fonctionnement de ChoixCorrespDialog
    pCorrespBaseArray->push_back(new NSPersonInfo(PatInfo)) ;

    // Charge les valeurs par d�faut des choix publication    strcpy(pPubli->aChoixPubli[i].corresp, pPatChoisi->getszNss()) ;    pPubli->aChoixPubli[i].select     = true ;
    pPubli->aChoixPubli[i].imprimante = true ;
    strcpy(pPubli->aChoixPubli[i].nb_expl, "1") ;
    pPubli->aChoixPubli[i].cpt      = 1 ;
    pPubli->aChoixPubli[i].email    = false ;
    pPubli->aChoixPubli[i].intranet = false ;
    pPubli->aChoixPubli[i].html     = false ;
    pPubli->aChoixPubli[i].lettre   = false ;

    pPubliPatient->Check();	}
	else
	{
		// on enl�ve le patient du tableau des correspondants
    i = 0 ;

		if (!(pCorrespBaseArray->empty()))
			for (NSPersonIter j = pCorrespBaseArray->begin(); j != pCorrespBaseArray->end(); i++,j++)
			{      	if (!strcmp((*j)->getszPersonID(), pPatChoisi->getszNss()))
        {
        	delete (*j) ;
          pCorrespBaseArray->erase(j) ;

          strcpy(pPubli->aChoixPubli[i].corresp, "") ;          pPubli->aChoixPubli[i].select = false ;
          pPubli->aChoixPubli[i].imprimante = false ;
          strcpy(pPubli->aChoixPubli[i].nb_expl, "") ;
          pPubli->aChoixPubli[i].cpt = 0 ;
          strcpy(pPubli->aChoixPubli[i].url, "") ;
          pPubli->aChoixPubli[i].email    = false ;
          pPubli->aChoixPubli[i].intranet = false ;
          pPubli->aChoixPubli[i].html     = false ;
          pPubli->aChoixPubli[i].lettre   = false ;
          break;
        }
      }

    pPubliPatient->Uncheck() ;	}

	// on remet la liste � jour	AfficheCorresp() ;
}
catch (...)
{
	erreur("Exception PubliCorrespDialog::CmAjouterPatient.", standardError, 0) ;
}
}

void
PubliCorrespDialog::CmAjouterBlank()
{
try
{
	int i ;
	bool bIsCheck = false ;

	// on v�rifie s'il existe d�j� un "blanc" dans les correspondants  if (!(pCorrespBaseArray->empty()))		for (NSPersonIter j = pCorrespBaseArray->begin(); j != pCorrespBaseArray->end(); j++)		{
  		if ('\0' == (*j)->getszPersonID()[0])
    	{
    		bIsCheck = true ;
      	break ;
    	}
  	}

	if (!bIsCheck)	{
		// on cherche l'indice du dernier corresp dans pPubli->aChoixPubli
    for (i = 0; i < MAXSELECT; i++)
    	if (false == pPubli->aChoixPubli[i].select)
      	break ;

    if (i == MAXSELECT)		{
    	erreur("Vous avez d�pass� la limite des s�lections possibles.", standardError, 0, GetHandle()) ;
      return ;
    }

    // on DOIT ajouter le "blanc" directement dans NSPubli    // � cause du fonctionnement de ChoixCorrespDialog
    pCorrespBaseArray->push_back(new NSPersonInfo(pContexte)) ;

    // Charge les valeurs par d�faut des choix publication    strcpy(pPubli->aChoixPubli[i].corresp, "") ;    pPubli->aChoixPubli[i].select     = true ;
    pPubli->aChoixPubli[i].imprimante = true ;
    strcpy(pPubli->aChoixPubli[i].nb_expl, "1") ;
    pPubli->aChoixPubli[i].cpt      = 1 ;
    pPubli->aChoixPubli[i].email    = false ;
    pPubli->aChoixPubli[i].intranet = false ;
    pPubli->aChoixPubli[i].html     = false ;
    pPubli->aChoixPubli[i].lettre   = false ;

    pPubliBlank->Check() ;	}
	else
	{
		// on enl�ve le "blanc" du tableau des correspondants
    i = 0 ;

		if (!(pCorrespBaseArray->empty()))
			for (NSPersonIter j = pCorrespBaseArray->begin(); j != pCorrespBaseArray->end(); i++, j++)
			{      	if ('\0' == (*j)->getszPersonID()[0])
        {
        	delete (*j) ;
          pCorrespBaseArray->erase(j) ;

          strcpy(pPubli->aChoixPubli[i].corresp, "") ;          pPubli->aChoixPubli[i].select = false ;
          pPubli->aChoixPubli[i].imprimante = false ;
          strcpy(pPubli->aChoixPubli[i].nb_expl, "") ;
          pPubli->aChoixPubli[i].cpt = 0 ;
          strcpy(pPubli->aChoixPubli[i].url, "") ;
          pPubli->aChoixPubli[i].email    = false ;
          pPubli->aChoixPubli[i].intranet = false ;
          pPubli->aChoixPubli[i].html     = false ;
          pPubli->aChoixPubli[i].lettre   = false ;
          break;
        }
      }

    pPubliBlank->Uncheck() ;	}

	// on remet la liste � jour	AfficheCorresp() ;
}
catch (...)
{
	erreur("Exception PubliCorrespDialog::CmAjouterBlank.", standardError, 0) ;
}
}

voidPubliCorrespDialog::CmSelectCorresp(WPARAM Cmd)
{
	NSPersonInfo *pCorrespSelect ;

  CorrespChoisi = pCorrespBox->GetSelIndex() ;
  pCorrespSelect = aCorrespArray[CorrespChoisi] ;
  pContexte->GetMainWindow()->SetCursor(0, IDC_WAIT) ;

  AfficheAdresse(pCorrespSelect) ;  AfficheChoixPubli(pCorrespSelect) ;

  pContexte->GetMainWindow()->SetCursor(0, IDC_ARROW) ;
}

voidPubliCorrespDialog::CmCorrespDblClk(WPARAM Cmd)
{
}

voidPubliCorrespDialog::CmClickImprimante()
{
	if (aCorrespArray.empty())
		return ;

	CorrespChoisi = pCorrespBox->GetSelIndex() ;
	NSPersonInfo *pCorrespSelect = aCorrespArray[CorrespChoisi] ;

	for (int index = 0; index < MAXSELECT ; index ++)	{
		if (!strcmp(pCorrespSelect->getszPersonID(), pPubli->aChoixPubli[index].corresp))
		{
    	if (pPubli->aChoixPubli[index].imprimante)
      {
      	pPubli->aChoixPubli[index].imprimante = false ;
        strcpy(pPubli->aChoixPubli[index].nb_expl, "") ;
        pPubli->aChoixPubli[index].cpt = 0 ;
      }
      else
      {
      	pPubli->aChoixPubli[index].imprimante = true ;
        strcpy(pPubli->aChoixPubli[index].nb_expl, "1") ;
        pPubli->aChoixPubli[index].cpt = 1 ;
      }

      break ;    }
	}

	AfficheChoixPubli(pCorrespSelect) ;}

voidPubliCorrespDialog::CmClickEmail()
{
	if (aCorrespArray.empty())
		return ;

	CorrespChoisi = pCorrespBox->GetSelIndex() ;
	NSPersonInfo *pCorrespSelect = aCorrespArray[CorrespChoisi] ;

	for (int index = 0; index < MAXSELECT; index ++)	{
  	if (!strcmp(pCorrespSelect->getszPersonID(), pPubli->aChoixPubli[index].corresp))
    {
    	if (pPubli->aChoixPubli[index].email)
      	pPubli->aChoixPubli[index].email = false ;
      else
      	pPubli->aChoixPubli[index].email = true ;

      break ;    }
	}

	AfficheChoixPubli(pCorrespSelect) ;}

voidPubliCorrespDialog::CmClickIntranet()
{
	if (aCorrespArray.empty())
		return ;

	CorrespChoisi = pCorrespBox->GetSelIndex() ;
	NSPersonInfo *pCorrespSelect = aCorrespArray[CorrespChoisi] ;

	for (int index = 0; index < MAXSELECT; index ++)	{
  	if (!strcmp(pCorrespSelect->getszPersonID(), pPubli->aChoixPubli[index].corresp))
    {
    	if (pPubli->aChoixPubli[index].intranet)
      	pPubli->aChoixPubli[index].intranet = false ;
      else
      	pPubli->aChoixPubli[index].intranet = true ;

      break ;    }
	}

	AfficheChoixPubli(pCorrespSelect) ;}

voidPubliCorrespDialog::CmClickHtml()
{
	if (aCorrespArray.empty())
		return ;

	CorrespChoisi = pCorrespBox->GetSelIndex();
	NSPersonInfo *pCorrespSelect = aCorrespArray[CorrespChoisi] ;

	for (int index = 0; index < MAXSELECT; index ++)	{
  	if (!strcmp(pCorrespSelect->getszPersonID(), pPubli->aChoixPubli[index].corresp))
    {
    	if (pPubli->aChoixPubli[index].html)
      	pPubli->aChoixPubli[index].html = false ;
      else
      	pPubli->aChoixPubli[index].html = true ;

      break ;    }
	}

	AfficheChoixPubli(pCorrespSelect) ;}

voidPubliCorrespDialog::CmClickJoindre()
{
	if (aCorrespArray.empty())
		return ;

	CorrespChoisi = pCorrespBox->GetSelIndex() ;
	NSPersonInfo *pCorrespSelect = aCorrespArray[CorrespChoisi] ;

	if (pLettre->GetCheck() == BF_CHECKED)	{
  	for (int index = 0; index < MAXSELECT; index ++)
    {
    	if (!strcmp(pCorrespSelect->getszPersonID(), pPubli->aChoixPubli[index].corresp))
      {
      	if (pPubli->aChoixPubli[index].lettre)
        	pPubli->aChoixPubli[index].lettre = false ;
        else
        	pPubli->aChoixPubli[index].lettre = true ;

        break ;      }
    }
  }

	AfficheChoixPubli(pCorrespSelect) ;}

voidPubliCorrespDialog::CmLettreType()
{
try
{
	if (aCorrespArray.empty())
		return ;

	LettreTypeDialog *pLTDlg ;
	string			     sTexte = "" ;
	NSPersonInfo     *pCorrespSelect ;

	CorrespChoisi  = pCorrespBox->GetSelIndex() ;
	pCorrespSelect = aCorrespArray[CorrespChoisi] ;

	if (!ExisteLettre(pCorrespSelect))
	{
		if ((NULL != pContexte->getPatient()) && (pContexte->getPatient()->pGraphPerson->bReadOnly))
		{
			pLettre->Uncheck() ;
			string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
			erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      return ;
		}

		pLTDlg = new LettreTypeDialog(this, pContexte) ;

		if (pLTDlg->Execute() == IDOK)
		{
			if (pLTDlg->choixIntro >= 0)
				sTexte += pLTDlg->sIntro + string("\n\n") ;

			if (pLTDlg->choixCorps >= 0)
				sTexte += pLTDlg->sCorps + string("\n\n") ;

			if (pLTDlg->choixPolit >= 0)
				sTexte += pLTDlg->sPolit + string("\n\n") ;

			// on cr�e la forme lettre type
			if (pLettreType)
				delete pLettreType ;
			pLettreType = new TLettreType(NULL, this, pPubli->pDocMaitre) ;
			pLettreType->Show() ;
			pLettreType->SetText(sTexte) ;
		}
		else
			pLettre->Uncheck() ;

		delete pLTDlg ;
	}
	else
	{
		// si le patient est en lecture seule, on autorise la visualisation de la lettre
		if (pLettreType)
			delete pLettreType ;
		pLettreType = new TLettreType(NULL, this, pPubli->pDocMaitre) ;
		pLettreType->Show() ;
    if (NULL != pContexte->getPatient())
			pLettreType->OuvreLettre(pContexte->getPatient()->getReadOnly()) ;
	}
}
catch (...)
{
	erreur("Exception PubliCorrespDialog::CmLettreType().", standardError, 0) ;
}
}

voidPubliCorrespDialog::CmOk()
{
	if (pLettreType)
	{
		pLettreType->Close() ;
		delete pLettreType ;
	}

	TDialog::CmOk() ;}

voidPubliCorrespDialog::CmCancel()
{
	if (pLettreType)
	{
		pLettreType->Close() ;
		delete pLettreType ;
	}

	TDialog::CmCancel() ;}

// -----------------------------------------------------------------//
//  M�thodes de PubliSansCorrespDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(PubliSansCorrespDialog, NSUtilDialog)	EV_BN_CLICKED(IDC_PSC_IMPRIMANTE, CmClickImprimante),
	EV_BN_CLICKED(IDC_PSC_EMAIL,      CmClickEmail),
	EV_BN_CLICKED(IDC_PSC_INTRANET,   CmClickIntranet),
	EV_BN_CLICKED(IDC_PSC_HTML,       CmClickHtml),
	EV_BN_CLICKED(IDC_PSC_PATIENT,    CmPublierVersPatient),
	// EV_BN_CLICKED(IDC_PSC_LETTRE, CmClickLettre),
	EV_COMMAND(IDOK, CmOk),
	EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

PubliSansCorrespDialog::PubliSansCorrespDialog(TWindow* pere, NSContexte* pCtx, NSPublication* pPublication)                       :NSUtilDialog(pere, pCtx, "IDD_PUBLISANSCORRESP")
{
try
{
	// pNbExpl       = new NSUtilEdit(this,        IDC_PSC_NBEXPL, WF_NB_PUBLI_LEN);
  pNbExpl       = new NSUtilEdit(pContexte, this, IDC_PSC_NBEXPL, 2) ;
	pUrl          = new NSUtilEdit(pContexte, this, IDC_PSC_URL,    COR_MESSAGERIE_LEN) ;
	pGroupe       = new OWL::TGroupBox(this,    IDC_PSC_GROUPE) ;
	pImprimante   = new OWL::TRadioButton(this, IDC_PSC_IMPRIMANTE, pGroupe) ;
	pEmail        = new OWL::TRadioButton(this, IDC_PSC_EMAIL,      pGroupe) ;
	pIntranet     = new OWL::TRadioButton(this, IDC_PSC_INTRANET,   pGroupe) ;
	pHtml         = new OWL::TRadioButton(this, IDC_PSC_HTML,       pGroupe) ;
	pGroupePat    = new OWL::TGroupBox(this,    IDC_PSC_GROUPEPAT) ;
	pPubliPatient = new OWL::TRadioButton(this, IDC_PSC_PATIENT,    pGroupePat) ;
	// pLettre = 		new TCheckBox(this,IDC_PSC_LETTRE);
	pPubli = pPublication ;

	pContexte->setAideIndex("hi_doc.htm") ;	pContexte->setAideCorps("h_publi.htm#Phase2b") ;
}
catch (...)
{
	erreur("Exception PubliSansCorrespDialog ctor.", standardError, 0) ;
}
}

PubliSansCorrespDialog::~PubliSansCorrespDialog(){
	// delete pLettre;
    delete pPubliPatient;
    delete pHtml;
    delete pIntranet;
    delete pEmail;
    delete pImprimante;
    delete pUrl;
    delete pNbExpl;

    pPubli = 0;					  // ne pas deleter}

voidPubliSansCorrespDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow();

    AfficheChoixPubli();}

voidPubliSansCorrespDialog::AfficheChoixPubli()
{
	if (pPubli->choixPubli.imprimante)
    {
   	    pImprimante->Check();
        pNbExpl->SetText(pPubli->choixPubli.nb_expl);
    }
    else
    {
   	    pImprimante->Uncheck();
        pNbExpl->SetText("");
    }

    if (pPubli->choixPubli.email)    {
   	    pEmail->Check();
        pUrl->SetText(pPubli->choixPubli.url);
    }
    else
    {
   	    pEmail->Uncheck();
        pUrl->SetText("");
    }

    if (pPubli->choixPubli.intranet)   	    pIntranet->Check();
    else
   	    pIntranet->Uncheck();

    if (pPubli->choixPubli.html)   	    pHtml->Check();
    else
   	    pHtml->Uncheck();
}

voidPubliSansCorrespDialog::CmPublierVersPatient()
{
	// on met un corresp fictif pour Imprimer()
	if ((NULL != pContexte->getPatient()) && (!strcmp(pPubli->choixPubli.corresp, "")))
	{
  	pPubliPatient->Check() ;
    strcpy(pPubli->choixPubli.corresp, pContexte->getPatient()->getszNss());

    if (pEmail->GetCheck() == BF_CHECKED)    {
    	char far url[COR_MESSAGERIE_LEN + 1] ;
      pUrl->GetText(url, COR_MESSAGERIE_LEN + 1) ;

      // si dans ce cas il n'y a pas d'url, on propose celle du patient      //      if (!strcmp(url, ""))
      	pUrl->SetText(pPubli->choixPubli.url) ;
    }
	}
	else
	{
  	strcpy(pPubli->choixPubli.corresp, "") ;
    pPubliPatient->Uncheck() ;
	}
}

voidPubliSansCorrespDialog::CmClickImprimante()
{
    if (pPubli->choixPubli.imprimante)
    {
   	    pPubli->choixPubli.imprimante = false;
        strcpy(pPubli->choixPubli.nb_expl, "");
        pPubli->choixPubli.cpt = 0;
    }
    else
    {
   	    pPubli->choixPubli.imprimante = true;
        strcpy(pPubli->choixPubli.nb_expl, "1");
        pPubli->choixPubli.cpt = 1;
    }

    AfficheChoixPubli();}

voidPubliSansCorrespDialog::CmClickEmail()
{
	if (pPubli->choixPubli.email)
    {
   	    pPubli->choixPubli.email = false;
        strcpy(pPubli->choixPubli.url, "");
    }
    else
    {
   	    pPubli->choixPubli.email = true;
    }

    AfficheChoixPubli();}

voidPubliSansCorrespDialog::CmClickIntranet()
{
	if (pPubli->choixPubli.intranet)
   	    pPubli->choixPubli.intranet = false;
    else
   	    pPubli->choixPubli.intranet = true;

    AfficheChoixPubli();}

voidPubliSansCorrespDialog::CmClickHtml()
{
	if (pPubli->choixPubli.html)
   	    pPubli->choixPubli.html = false;
    else
   	    pPubli->choixPubli.html = true;

    AfficheChoixPubli();}

voidPubliSansCorrespDialog::CmClickLettre()
{
	if (pPubli->choixPubli.lettre)
   	    pPubli->choixPubli.lettre = false;
    else
   	    pPubli->choixPubli.lettre = true;

    AfficheChoixPubli();}

voidPubliSansCorrespDialog::CmOk()
{
	// char far nb_expl[WF_NB_PUBLI_LEN + 1];
  char far nb_expl[3] ;
	char far url[COR_MESSAGERIE_LEN + 1] ;

	// pNbExpl->GetText(nb_expl, WF_NB_PUBLI_LEN + 1) ;  pNbExpl->GetText(nb_expl, 3) ;	pUrl->GetText(url, COR_MESSAGERIE_LEN + 1) ;

	strcpy(pPubli->choixPubli.nb_expl, nb_expl) ;	pPubli->choixPubli.cpt = atoi(pPubli->choixPubli.nb_expl) ;
	strcpy(pPubli->choixPubli.url, url) ;

	TDialog::CmOk() ;}

voidPubliSansCorrespDialog::CmCancel()
{
	TDialog::CmCancel();
}

// -----------------------------------------------------------------//
//  M�thodes de ChoixCorrespDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(ChoixCorrespDialog, NSUtilDialog)	EV_CHILD_NOTIFY_AND_CODE(IDC_BASEBOX, LBN_SELCHANGE, CmSelectCorrespBase),
	EV_CHILD_NOTIFY_AND_CODE(IDC_BASEBOX, LBN_DBLCLK, CmCorrespBaseDblClk),
    EV_BN_CLICKED(IDC_AJOUTER_PATIENT, CmAjouterPatient),
    EV_COMMAND(IDC_SELECTALL, CmSelectAll),
   	EV_COMMAND(IDOK,CmOk),
   	EV_COMMAND(IDCANCEL,CmCancel),
END_RESPONSE_TABLE;

ChoixCorrespDialog::ChoixCorrespDialog(TWindow* pere, NSContexte* pCtx, NSPublication* pPublication)							:NSUtilDialog(pere, pCtx, "IDD_SELECTCORR")
{
try
{
	pPubli = pPublication ;

	pCorrespBaseBox 	= new OWL::TListBox(this,     IDC_BASEBOX) ;	pCorrespSelectBox = new OWL::TListBox(this,     IDC_SELECTBOX) ;
	pAjouterPatient   = new OWL::TRadioButton(this, IDC_AJOUTER_PATIENT, 0) ;

	pCorrespBaseArray = &(pPubli->aCorrespBaseArray) ;
	pContexte->getSuperviseur()->setAideIndex("hi_doc.htm") ;	pContexte->getSuperviseur()->setAideCorps("h_publi.htm#Phase1") ;
}
catch (...)
{
	erreur("Exception ChoixCorrespDialog ctor.", standardError, 0) ;
}
}

ChoixCorrespDialog::~ChoixCorrespDialog(){
	delete pCorrespBaseBox ;
	delete pCorrespSelectBox ;
	delete pAjouterPatient ;

	pCorrespBaseArray = 0 ;}

voidChoixCorrespDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	pAjouterPatient->Uncheck() ;
	if ((NULL != pContexte->getPatient()) && (!(pCorrespBaseArray->empty())))	{
		for (NSPersonIter j = pCorrespBaseArray->begin(); j != pCorrespBaseArray->end(); j++)
		{
    	if (pContexte->getPatient()->getNss() == (*j)->sPersonID)      {
      	// Il existe d�j� un patient
        pAjouterPatient->Check() ;
        break;
      }
    }
  }

	SetSelectBase() ;	AfficheSelect() ;
}

voidChoixCorrespDialog::SetSelectBase()
{
	// on vide la liste si elle contient des items
	if (pCorrespBaseBox->GetCount())
		pCorrespBaseBox->ClearList() ;

	//	// Mise � jour des s�lections de CorrespBaseBox
	//
	if (pCorrespBaseArray->empty())
		return ;
	int CorrespBaseIndex[MAXSELECT] ;
	int numSelect = 0 ;

	for (NSPersonIter it = pCorrespBaseArray->begin(); it != pCorrespBaseArray->end(); it++)
	{
		// on remplit la CorrespBox
    string sCorresp = (*it)->sNom + string(" ") + (*it)->sPrenom ;
    pCorrespBaseBox->AddString(sCorresp.c_str()) ;

    int iPubliIndex = getPubliIndexFromPersonID((*it)->sPersonID) ;
		if ((iPubliIndex >= 0) && pPubli->aChoixPubli[iPubliIndex].select)
  	{
    	CorrespBaseIndex[numSelect] = iPubliIndex ;
      numSelect++ ;
    }
  }

	pCorrespBaseBox->SetSelIndexes(CorrespBaseIndex, numSelect, true) ;}

voidChoixCorrespDialog::AfficheSelect()
{
	// on vide la liste si elle contient des items
  // if the list isn't empty, we empty it
  //
	if (pCorrespSelectBox->GetCount())
		pCorrespSelectBox->ClearList() ;

	// R�cup�ration des indices des correspondants s�lectionn�s  // Getting indexes of selected persons	//
  int CorrespBaseIndex[MAXSELECT] ;
	int numSelect = pCorrespBaseBox->GetSelIndexes(CorrespBaseIndex, MAXSELECT) ;

	for (int i = 0; i < numSelect; i++)	{
  	int index = CorrespBaseIndex[i] ;
    NSPersonInfo* pCorrespInfoChoisi = (*(pCorrespBaseArray))[index] ;    string sCorresp = pCorrespInfoChoisi->sNom + string(" ") + pCorrespInfoChoisi->sPrenom ;
    pCorrespSelectBox->AddString(sCorresp.c_str()) ;

    int iPubliIndex = getPubliIndexFromPersonID(pCorrespInfoChoisi->sPersonID) ;
    if (iPubliIndex >= 0)
    	pPubli->aChoixPubli[iPubliIndex].select = true ;
	}
}

voidChoixCorrespDialog::CmSelectCorrespBase(WPARAM Cmd)
{
	AfficheSelect() ;
}

voidChoixCorrespDialog::CmCorrespBaseDblClk(WPARAM Cmd)
{
}

voidChoixCorrespDialog::CmAjouterPatient()
{
try
{
	int i ;
	NSPatientChoisi* pPatChoisi = pContexte->getPatient() ;
  if (NULL == pPatChoisi)
		return ;

	bool bIsCheck = false ;

	// on v�rifie s'il existe d�j� un patient dans les correspondants	if (!(pCorrespBaseArray->empty()))
	{
		for (NSPersonIter j = pCorrespBaseArray->begin(); j != pCorrespBaseArray->end(); j++)
		{			if (pPatChoisi->getNss() == (*j)->sPersonID)
      {      	bIsCheck = true ;
        break ;
      }
    }
	}

	if (!bIsCheck)	{
		// on rajoute le patient au tableau des correspondants
		NSPersonInfo PatInfo(pContexte, pPatChoisi->getNss(), pidsPatient) ;
		// on cherche l'indice du dernier corresp dans pPubli->aChoixPubli
    for (i = 0; i < MAXSELECT; i++)
    	if (!strcmp(pPubli->aChoixPubli[i].corresp, ""))
      	break ;

    if (i == MAXSELECT)    {
    	erreur("Vous avez d�pass� la limite des s�lections possibles. Vous ne pourrez pas publier vers le patient.", standardError, 0, GetHandle());
      return ;
    }

    // on DOIT ajouter le patient directement dans NSPubli    // � cause du fonctionnement de ChoixCorrespDialog

    pCorrespBaseArray->push_back(new NSPersonInfo(PatInfo)) ;

		// Charge les valeurs par d�faut des choix publication		strcpy(pPubli->aChoixPubli[i].corresp, pPatChoisi->getszNss()) ;
    pPubli->aChoixPubli[i].select   = true;    pPubli->aChoixPubli[i].imprimante = true;
    strcpy(pPubli->aChoixPubli[i].nb_expl, "1");
    pPubli->aChoixPubli[i].cpt      = 1;
    strcpy(pPubli->aChoixPubli[i].url, "");
    pPubli->aChoixPubli[i].email    = false;
    pPubli->aChoixPubli[i].intranet = false;
    pPubli->aChoixPubli[i].html     = false;
    pPubli->aChoixPubli[i].lettre   = false;

    pAjouterPatient->Check() ;	}
  else
	{
  	// on enl�ve le patient du tableau des correspondants
		for (NSPersonIter j = pCorrespBaseArray->begin(); j != pCorrespBaseArray->end(); j++)
		{			if (pPatChoisi->getNss() == (*j)->sPersonID)
      {
        delete (*j) ;
        pCorrespBaseArray->erase(j) ;

        int iPubliIndex = getPubliIndexFromPersonID(pPatChoisi->getNss()) ;
    		if (iPubliIndex >= 0)
				{
        	strcpy(pPubli->aChoixPubli[iPubliIndex].corresp, "") ;        	pPubli->aChoixPubli[iPubliIndex].select = false ;
        	pPubli->aChoixPubli[iPubliIndex].imprimante = false ;
        	strcpy(pPubli->aChoixPubli[iPubliIndex].nb_expl, "") ;
        	pPubli->aChoixPubli[iPubliIndex].cpt = 0 ;
        	strcpy(pPubli->aChoixPubli[iPubliIndex].url, "");
        	pPubli->aChoixPubli[iPubliIndex].email    = false ;
        	pPubli->aChoixPubli[iPubliIndex].intranet = false ;
        	pPubli->aChoixPubli[iPubliIndex].html     = false ;
        	pPubli->aChoixPubli[iPubliIndex].lettre   = false ;
        }
        break ;
      }
    }

    pAjouterPatient->Uncheck() ;  }

	// on remet la liste � jour	SetSelectBase() ;
	AfficheSelect() ;
}
catch (...)
{
	erreur("Exception ChoixCorrespDialog::CmAjouterPatient", standardError, 0) ;
}
}

voidChoixCorrespDialog::CmSelectAll()
{
	int CorrespBaseIndex[MAXSELECT] ;
	int numSelect = 0 ;

	// on vide la liste si elle contient des items	if (pCorrespSelectBox->GetCount())
		pCorrespSelectBox->ClearList() ;

	if (!(pCorrespBaseArray->empty()))	{
		for (NSPersonIter i = pCorrespBaseArray->begin(); i != pCorrespBaseArray->end(); i++)
		{    	NSPersonInfo* pCorrespInfoChoisi = (*i) ;
      string sCorresp = pCorrespInfoChoisi->sNom + string(" ") + pCorrespInfoChoisi->sPrenom ;
      pCorrespSelectBox->AddString(sCorresp.c_str()) ;
      CorrespBaseIndex[numSelect] = numSelect ;
      numSelect++ ;
    }
  }

	pCorrespBaseBox->SetSelIndexes(CorrespBaseIndex, numSelect, true) ;
	CmOk() ;}

voidChoixCorrespDialog::CmOk()
{
	int index, numSelect, i ;
	int CorrespBaseIndex[MAXSELECT] ;

	// on efface l'ancienne s�lection	for (i = 0; i < MAXSELECT; i++)
		pPubli->aChoixPubli[i].select = false ;

	// R�cup�ration des indices des correspondants s�lectionn�s	//
	numSelect = pCorrespBaseBox->GetSelIndexes(CorrespBaseIndex, MAXSELECT) ;

	if (numSelect == 0)	{
		erreur("Vous devez s�lectionner au moins un correspondant.", warningError, 0, GetHandle()) ;
		return ;
	}

	// mise a jour du tableau de NSPublication	for (i = 0; i < numSelect; i++)
	{
		index = CorrespBaseIndex[i] ;

    NSPersonInfo* pCorrespInfoChoisi = (*(pCorrespBaseArray))[index] ;

    int iPubliIndex = getPubliIndexFromPersonID(pCorrespInfoChoisi->sPersonID) ;
    if (iPubliIndex >= 0)
			pPubli->aChoixPubli[iPubliIndex].select = true ;
	}

	TDialog::CmOk() ;}

voidChoixCorrespDialog::CmCancel()
{
	TDialog::CmCancel() ;
}

int
ChoixCorrespDialog::getPubliIndexFromPersonID(string sPersonID)
{
  for (int i = 0; i < MAXSELECT; i++)
		if (string(pPubli->aChoixPubli[i].corresp) == sPersonID)
    	return i ;

	return -1 ;
}

/****************** Hook Procedure ********************************//* Appel�e apr�s SendMessage sur le message WH_CALLWNDPROCRET     */
/******************************************************************/

LRESULT WINAPI CallWndRetProc(int nCode, WPARAM wParam, LPARAM lParam)
{
  char cName[30] ;
  string sName ;
  LPCWPRETSTRUCT pMsg ;

  if (nCode < 0) // do not process msg
    return CallNextHookEx(hhook, nCode, wParam, lParam) ;

  switch (nCode)  {
    case HC_ACTION:
    {
      pMsg = (LPCWPRETSTRUCT) lParam ;

      switch (pMsg->message)
      {
        // Attention le seul evenement utilisable est WM_PAINT
        // WM_CREATE arrive trop tot et fait planter le serveur

        case WM_PAINT:

          // On r�cup�re le nom de la classe de fenetre
          if (GetClassName(pMsg->hwnd, cName, 30))
            sName = string(cName) ;
          else
            sName = "" ;

          // La fenetre d'impression et la fenetre d'annulation
          // qui est cr�ee quand on envoie un Return ont toutes
          // les deux le meme nom de classe #32770.
          // On est donc oblig� d'envoyer les Return un coup sur
          // deux pour ne pas annuler l'impression.

          if (sName == string("#32770"))
          {
            if (bEnvoyerReturn)
            {
              keybd_event(VK_RETURN, 0, standardError, 0) ;
              keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0) ;
              bEnvoyerReturn = false ;
            }
            else
              bEnvoyerReturn = true ;
          }
          break ;
      }
    }
    break ;

    default:
      break ;
  }
  return CallNextHookEx(hhook, nCode, wParam, lParam) ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSPublication
//
// -----------------------------------------------------------------

NSPublication::NSPublication(NSPatientChoisi* pPatientChoisi,
                             NSRefDocument* pDocEnCours,
                             NSContexte* pCtx)
              :NSRoot(pCtx), aCorrespBaseArray(pContexte)
{
	// Patient en cours
	pPatChoisi          = pPatientChoisi ;
	pDocMaitre          = pDocEnCours ;
	bImpressionEnCours  = false ;

	// Param�tres de tempo.dat	bUseHook            = false ;
	bWaitImp            = false ;
	iTempImp            = 0 ;
  // NSChoixPubli has no constructor... so let's make sure there is some initialization
	for (int i = 0; i < MAXSELECT; i++)
	{
  	aChoixPubli[i].corresp[0] = '\0' ;
    aChoixPubli[i].select = false ;
  }

	initParams() ;
	if ((NULL != pDocMaitre) && (NULL != pDocMaitre->pDocInfo))	{
  	codeDoc = pDocMaitre->pDocInfo->getID() ;

    if (codeDoc == "")    	codeDoc = string("temp") ;

    if (pDocMaitre->pHtmlInfo) // cas composition deja effectuee    {
    	fichTmpl = pDocMaitre->TemplateInfoBrut() ;
      enteteTmpl = pDocMaitre->EnTeteInfoBrut() ;
    }
    else // on est en presence d'un document brut
    {    // on r�cup�re la template de composition par d�faut du type document
    	string sTypeDoc = string(pDocMaitre->pDocInfo->getType()) ;

      if (pContexte->typeDocument(sTypeDoc, NSSuper::isTree))
      {
      	// s'il existe une template et un en-tete non vides
        // on les r�cup�re, sinon on prend les fichiers par d�faut

        fichTmpl = pDocMaitre->TemplateInfoBrut(false) ;
        enteteTmpl = pDocMaitre->EnTeteInfoBrut(false) ;

        if ((fichTmpl == "") || (enteteTmpl == ""))
        {        	string sType = pDocMaitre->pDocInfo->getType() ;          pDocMaitre->TemplateCompo(sType, fichTmpl, enteteTmpl) ;
        }
      }
      else
      	pDocMaitre->TemplateCompo(pDocMaitre->pDocInfo->getType(), fichTmpl, enteteTmpl) ;
    }
  }
  else
	{
  	codeDoc    = "temp" ;
    fichTmpl   = "" ;
    enteteTmpl = "" ;
	}

	pCrypteMsg = 0 ;	pCrypteFic = 0 ;
}

NSPublication::~NSPublication()
{
	// !!! Ne pas deleter ces deux pointeurs
	// (ce qui tuerait le patient et le document)

	pPatChoisi = 0 ;	pDocMaitre = 0 ;

	// On ne delete plus les fichiers de publication	// Ce travail est fait directement dans ~NSVisualView
	// DeleteFichPubli();
}

stringNSPublication::tempPubli(char *typePub)
{
	// par defaut pour l'instant :
	// retourne la template de composition
	return fichTmpl ;
}

stringNSPublication::entetePubli(char *typePub)
{
	// par defaut pour l'instant :
	// retourne l'en-tete de composition
	return enteteTmpl ;
}

stringNSPublication::dateSysteme()
{
	char cDate[9] ;
	struct date dateSys ;

	getdate(&dateSys) ;	sprintf(cDate, "%4d%02d%02d", dateSys.da_year, dateSys.da_mon, dateSys.da_day) ;
	return string(cDate) ;
}

stringNSPublication::heureSysteme()
{
	char cHeure[7] ;
	struct time heureSys ;

	gettime(&heureSys) ;	sprintf(cHeure, "%02d%02d%02d", heureSys.ti_hour, heureSys.ti_min, heureSys.ti_sec) ;
	return string(cHeure) ;
}

boolNSPublication::ChargeCorrespBase()
{
try
{
	int j = 0 ;
	aCorrespBaseArray.vider() ;

	// Si on ne passe pas de patient, prend un array vide	if (pPatChoisi && pPatChoisi->pHealthTeam)
	{
  	VecteurString* pMembersList = pPatChoisi->pHealthTeam->getPIDS() ;
		for (EquiItemIter i = pMembersList->begin(); i != pMembersList->end(); i++)
    {
      PIDSTYPE iTypePids ;
      if ((NULL != pContexte->getPatient()) && (!strcmp((*i)->c_str(), pContexte->getPatient()->getszNss())))
        iTypePids = pidsPatient ;
      else
        iTypePids = pidsCorresp ;

    	NSPersonInfo* pPersonInfo = pContexte->getPersonArray()->getPerson(*(*i), iTypePids) ;
      aCorrespBaseArray.push_back(new NSPersonInfo(*pPersonInfo)) ;
    	// aCorrespBaseArray.push_back(new NSPersonInfo(pContexte, *(*i), pidsCorresp)) ;
    }
	}

	for (int k = 0; k < MAXSELECT; k++)
	{
		sFichHtml[k]   = "" ;
		sLettreHtml[k] = "" ;
	}

	if (!(aCorrespBaseArray.empty()))	{
		for (NSPersonIter i = aCorrespBaseArray.begin(); i != aCorrespBaseArray.end(); i++,j++)
		{    	if (j < MAXSELECT)
			{
      	// Charge les valeurs par d�faut des choix publication
        strcpy(aChoixPubli[j].corresp, (*i)->getszPersonID()) ;
				aChoixPubli[j].select = false ;        aChoixPubli[j].imprimante = true ;

        // initialisation du nombre d'exemplaires        strcpy(aChoixPubli[j].nb_expl, "1") ;
        aChoixPubli[j].cpt = 1 ;
        strcpy(aChoixPubli[j].url, "") ;

        aChoixPubli[j].email = false ;
        aChoixPubli[j].intranet = false ;
        aChoixPubli[j].html = false ;
        aChoixPubli[j].lettre = false ;
      }
      else
    	{
      	erreur("Le nombre des correspondants d�passe le maximum des s�lectionn�s", standardError, 0, pContexte->GetMainWindow()->GetHandle());
        return false ;
      }
    }
  }

	for (int i = j; i < MAXSELECT; i++)	{
    strcpy(aChoixPubli[i].corresp, "") ;
    aChoixPubli[i].select     = false ;
    aChoixPubli[i].imprimante = false ;
    strcpy(aChoixPubli[i].nb_expl, "") ;
    aChoixPubli[i].cpt = 0 ;
    // l'url est ici � vide par d�faut
    // car le patient en cours n'est pas le cas par d�faut
    strcpy(aChoixPubli[i].url, "") ;
    aChoixPubli[i].email    = false ;
    aChoixPubli[i].intranet = false ;
    aChoixPubli[i].html     = false ;
    aChoixPubli[i].lettre   = false ;
	}

  strcpy(choixPubli.corresp, "") ;  choixPubli.select     = true ;
  choixPubli.imprimante = true ;
  strcpy(choixPubli.nb_expl, "1") ;
  choixPubli.cpt      = 1 ;
  strcpy(choixPubli.url, "") ;
  choixPubli.email    = false ;
  choixPubli.intranet = false ;
  choixPubli.html     = false ;
  choixPubli.lettre   = false ;

	return true ;
}
catch (...)
{
	erreur("Exception NSPublication::ChargeCorrespBase", standardError, 0) ;
	return false;
}
}

boolNSPublication::ExisteCorrespSelect()
{
	for (int i = 0; i < MAXSELECT; i++)
		if (true == aChoixPubli[i].select)
			return true ;

	return false ;
}

#ifndef N_TIERSboolNSPublication::AppendWorkflow(char *dest, char *type, char *nb_expl, string entete, string tmpl)
{
try
{
    NSWorkflow* pWorkflow = new NSWorkflow(pContexte);
	pWorkflow->lastError = pWorkflow->open();
	if (pWorkflow->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier Workflow.db", 0, pWorkflow->lastError, pContexte->GetMainWindow()->GetHandle());
		delete pWorkflow;
		return false;
	}

    strcpy(pWorkflow->pDonnees->code_docu,   codeDoc.c_str());
    strcpy(pWorkflow->pDonnees->code_dest,   dest);
    strcpy(pWorkflow->pDonnees->type_publi,  type);
    strcpy(pWorkflow->pDonnees->date_publi,  dateSysteme().c_str());
    strcpy(pWorkflow->pDonnees->heure_publi, heureSysteme().c_str());
    strcpy(pWorkflow->pDonnees->nb_publi,    nb_expl);
    strcpy(pWorkflow->pDonnees->entet_publi, entete.c_str());
    strcpy(pWorkflow->pDonnees->tmpl_publi,  tmpl.c_str());
    strcpy(pWorkflow->pDonnees->ar_publi,    "0");
    strcpy(pWorkflow->pDonnees->valide,      "1");

    pWorkflow->lastError = pWorkflow->appendRecord();

	if (pWorkflow->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ajout d'une fiche Workflow.", 0, pWorkflow->lastError, pContexte->GetMainWindow()->GetHandle());
		pWorkflow->close();
		delete pWorkflow;
		return false;
	}

    pWorkflow->lastError = pWorkflow->close();
    if (pWorkflow->lastError != DBIERR_NONE)
		erreur("Erreur de fermeture du fichier Workflow.", 0, pWorkflow->lastError, pContexte->GetMainWindow()->GetHandle());

    delete pWorkflow;

    return true;
}
catch (...)
{
    erreur("Exception.", standardError, 0) ;
    return false;
}
}
#endif
#ifndef N_TIERS
boolNSPublication::RemplitWorkflow()
{
    for (int i = 0; i < MAXSELECT; i++)
    {
   	    if (aChoixPubli[i].select)
        {
            if (aChoixPubli[i].imprimante)
         	    AppendWorkflow(aChoixPubli[i].corresp, "I", aChoixPubli[i].nb_expl,
            				                entetePubli("I"), tempPubli("I"));

            if (aChoixPubli[i].email)
         	    AppendWorkflow(aChoixPubli[i].corresp, "E", "1",
            				                entetePubli("E"), tempPubli("E"));

            if (aChoixPubli[i].intranet)
         	    AppendWorkflow(aChoixPubli[i].corresp, "R", "1",
            				                entetePubli("R"), tempPubli("R"));

            if (aChoixPubli[i].html)
         	    AppendWorkflow(aChoixPubli[i].corresp, "H", "1",
            				                entetePubli("H"), tempPubli("H"));
        }
    }

    return true;
}
#endif

boolNSPublication::CodeDocLettre(int index, string& sCode)
{
try
{
	sCode = getCodeLettre(aChoixPubli[index].corresp) ;

  if (string("") == sCode)
		return false ;

	return true ;
}
catch (...)
{
	erreur("Exception NSPublication::CodeDocLettre.", standardError, 0) ;
	return false ;
}
}

string
NSPublication::getCodeLettre(string sPersonID)
{
try
{
	if (string("") == sPersonID)
		return string("") ;

	if (NULL == pContexte->getPatient())
  	return string("") ;
  NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	VecteurString aVecteurString ;
	pGraphe->TousLesVraisDocument(pDocMaitre->pDocInfo->getID(), NSRootLink::letterOfDocument, &aVecteurString, "ENVERS") ;
	if (true == aVecteurString.empty())
		return string("") ;

	NSHISTODocument* pDocHisPat = pContexte->getPatient()->pDocHis ;
  if (NULL == pDocHisPat)
		return string("") ;

	for (EquiItemIter i = aVecteurString.begin(); aVecteurString.end() != i ; i++)
  {
    // Check that it is valid and not "in-memory"
    //
    if ((strlen((*i)->c_str()) == PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) &&
        (INMEMORY_CHAR != (**i)[PAT_NSS_LEN]))
    {
  	  // First attempt, look for the document in history
      //
		  DocumentIter itCurrentDoc = pDocHisPat->VectDocument.TrouveDocHisto(**i) ;
		  if ((itCurrentDoc != NULL) &&
          (pDocHisPat->VectDocument.end() != itCurrentDoc))
      {
    	  if ((*itCurrentDoc)->getDestinat() == sPersonID)
    		  return (*itCurrentDoc)->getID() ;
      }
      // Second attempt, parse it from graph
      //
      else
      {
    	  NSDocumentInfo docInfo(**i, pContexte) ;
        if ((true == docInfo.ParseMetaDonnees()) &&
            (docInfo.getDestinat() == sPersonID))
    		  return **i ;
      }
    }
  }

	return string("") ;
}
catch (...)
{
	erreur("Exception NSPublication::getCodeLettre.", standardError, 0) ;
	return string("") ;
}
}

stringNSPublication::StringAdresse(char *codeCorresp)
{
	string sAdresse = "" ;

	if ((NULL == codeCorresp) || ('\0' == codeCorresp[0]))
		return sAdresse ;

	NSPersonInfo *pCorrespSelect = 0 ;
	if (!(aCorrespBaseArray.empty()))	{
		for (NSPersonIter k = aCorrespBaseArray.begin(); k != aCorrespBaseArray.end(); k++)
		{			if (!strcmp((*k)->getszPersonID(), codeCorresp))
			{				pCorrespSelect = *k ;
        break ;
      }
    }
	}

  if (NULL == pCorrespSelect)
  	return sAdresse ;

	if (string("") != pCorrespSelect->sMainAdr)
  	return pCorrespSelect->sMainAdr ;

	// on charge ici en m�moire le graphe de personne et le graphe d'adresse
	string sNss = string(pCorrespSelect->sPersonID) ;

	if ((NULL != pContexte->getPatient()) &&
        (!strcmp(sNss.c_str(), pContexte->getPatient()->getszNss())))
		sAdresse = pCorrespSelect->getMainAdr(pidsPatient) ;
	else
		sAdresse = pCorrespSelect->getMainAdr(pidsCorresp) ;

	return sAdresse ;}

stringNSPublication::NomCorresp(char *codeCorresp)
{
	string sNom = "";

	if ((NULL == codeCorresp) || ('\0' == codeCorresp[0]))
		return sNom ;

	NSPersonInfo *pCorrespSelect = 0 ;
	if (!(aCorrespBaseArray.empty()))
	{
		for (NSPersonIter k = aCorrespBaseArray.begin(); k != aCorrespBaseArray.end(); k++)
		{			if (!strcmp((*k)->getszPersonID(), codeCorresp))
      {      	pCorrespSelect = *k ;
        break ;
      }
    }
	}

	if (NULL != pCorrespSelect)
	{
		sNom = pCorrespSelect->sPrenom ;
		if (sNom != "")    	sNom += string(" ") ;		sNom += pCorrespSelect->sNom ;	}	else // cas, par exemple, de l'impression sans correspondant
		sNom = "XXX" ;

	return sNom ;}

voidNSPublication::Publication()
{
	bool bImpress   = false ;
    bool bEMail     = false ;
    bool bExport    = false ;
    //
   	// recuperation de la template et de l'en-tete de publication
    //

    // Modif RS du 04-05-04 :
    // on prend dor�navant la template et l'en-tete bruts r�cup�r�s dans le constructeur
    // et quel que soit le cas de figure, on reprend le PathName("NTPL") pour tenir compte
    // des diff�rents acc�s au r�pertoire NTPL (cas supports <> sur serveur et sur client)
    if (fichTmpl != "")
        pDocMaitre->sTemplate = pContexte->PathName("NTPL") + fichTmpl;
    else
        pDocMaitre->sTemplate = "";

    if (enteteTmpl != "")
        pDocMaitre->sEnTete = pContexte->PathName("NTPL") + enteteTmpl;
    else
        pDocMaitre->sEnTete = "";

    //
    // La publication se fait par paquets homog�nes : e-mails, puis exportation
    // HTML puis impression ; on regarde d'abord pour quels modes il existe
    // au moins un document � publier
    //
   	if (aCorrespBaseArray.empty())
   	{
   		// publication sans correspondant
      	if (choixPubli.imprimante)
      		bImpress = true;

      	if (choixPubli.email)
      		bEMail = true;

      	if (choixPubli.html)
        	bExport = true;
   	}
   	else
   	{
    	for (int i = 0; i < MAXSELECT; i++)
   		{
   			if (aChoixPubli[i].select)
      		{
         		if (!bImpress && (aChoixPubli[i].imprimante))
            		bImpress = true;

            	if (!bEMail && (aChoixPubli[i].email))
            		bEMail = true;

            	if (!bExport && (aChoixPubli[i].html))
                	bExport = true;
      		}
   		}
   	}

   	numImpress = 0;
    //
    // On envoie d'abord les e-mail
    //
   	if (bEMail)
   	{
        // connexion au serveur SMTP
    	ConnectHost();
        if (pXSMTP)
        {
    	    if (aCorrespBaseArray.empty())
   		    {
   			    // publication sans correspondant
      		    if ((pXSMTP->Continuer()) && (choixPubli.email))
      		    {
      			    if (!SendMail(pContexte->PathName("EHTM")))
         		        erreur("Impossible d'envoyer le document par e-mail.",standardError,0,pContexte->GetMainWindow()->GetHandle());      		    }
   		    }
   		    else
   		    {
    		    for (int i = 0; i < MAXSELECT; i++)
   			    {
                    if (!pXSMTP->Continuer())
                        break;

   				    if ((aChoixPubli[i].select) && (aChoixPubli[i].email))
      			    {
                        // boucle d'attente entre chaque SendMail
                        while (pXSMTP->Attendre());

            		    if (!SendMail(pContexte->PathName("EHTM"), i))
            		    {
               	  		    char msg[100];
                  		    string sDest = NomCorresp(aChoixPubli[i].corresp);
                  		    sprintf(msg,"Impossible d'envoyer le document destin� � %s.",sDest.c_str());
               	  		    erreur(msg,standardError,0,pContexte->GetMainWindow()->GetHandle());
               		    }
            	    }
      		    }
   		    }

            // boucle d'attente du dernier SendMail
            while (pXSMTP->Attendre());

            string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
            if (pXSMTP->Continuer())
                ::MessageBox(pContexte->GetMainWindow()->GetHandle(), "Envoi d'E-Mail termin�.", sCaption.c_str(), MB_OK);
            else
                ::MessageBox(pContexte->GetMainWindow()->GetHandle(), "Envoi d'E-Mail interrompu.", sCaption.c_str(), MB_OK);

    	    DisconnectHost();
        }
   	}
    //
    // Lancement des exportations
    //
    if (bExport)
    {
    	if (aCorrespBaseArray.empty())
   		{
      		if (choixPubli.html)
      		{
      			if (!Exporter(pContexte->PathName("EHTM")))
         			erreur("Impossible d'exporter le document.",standardError,0,pContexte->GetMainWindow()->GetHandle());
      		}
   		}
   		else
   		{
    		for (int i = 0; i < MAXSELECT; i++)
   			{
   				if ((aChoixPubli[i].select) && (aChoixPubli[i].html))
      			{
            		if (!Exporter(pContexte->PathName("EHTM"), i))
            		{
               	  		char msg[100];
                  		string sDest = NomCorresp(aChoixPubli[i].corresp);
                  		sprintf(msg,"Impossible d'envoyer le document destin� � %s.",sDest.c_str());
               	  		erreur(msg,standardError,0,pContexte->GetMainWindow()->GetHandle());
               		}
            	}
      		}
   		}
        string sMessage = string("T�che d'exportation termin�e (dans le r�pertoire ") + pContexte->PathName("EHTM") + string(")") ;
        string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
        ::MessageBox(pContexte->GetMainWindow()->GetHandle(), sMessage.c_str(), sCaption.c_str(), MB_OK);
    }
    //
   	// Lancement de l'impression : g�r�e par le browser
    //
   	if (bImpress)
   	{
      	indexSelect = 0;
        DebutImpression();  // fonction de synchronisation
      	ImprimerSuivant();  // processus d'impression
   	}
}

// fonction appel�e par le browser en fin d'impression
// Retourne false si on relance une impression
// Retourne true si la tache d'impression est termin�e
bool
NSPublication::ImprimerSuivant()
{
	int i ;
	bool bFinish = false ;

	if (aCorrespBaseArray.empty())
  {
  	if ((choixPubli.select) && (choixPubli.imprimante))
    {
    	if (!Imprimer())
      {
      	erreur("Impossible d'imprimer le document.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      }

      choixPubli.select = false ;    }
    bFinish = true ;  }
  else
  {
  	for (i = indexSelect; i < MAXSELECT; i++)
    {
    	if ((aChoixPubli[i].select) && (aChoixPubli[i].imprimante))
      {
      	indexSelect = i + 1 ;
      	if (!Imprimer(i))
        {
        	// dans ce cas on essaie directement d'imprimer le suivant (pas de break)
          char msg[100] ;
          string sDest = NomCorresp(aChoixPubli[i].corresp) ;
          sprintf(msg,"Impossible d'imprimer le document destin� � %s.",sDest.c_str()) ;
          erreur(msg, standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
        }
        else
        	break ;

/*
         	    if (!Imprimer(i))
                {
            	    // dans ce cas on essaie directement d'imprimer le suivant (pas de break)
                    char msg[100];
                    string sDest = NomCorresp(aChoixPubli[i].corresp);
                    sprintf(msg,"Impossible d'imprimer le document destin� � %s.",sDest.c_str());
                    erreur(msg,0,0,pContexte->GetMainWindow()->GetHandle());
                }
                else
                {
            	    indexSelect = i + 1;
                    break;
                }
*/
			}
		}

		if (i == MAXSELECT) // plus de corresp => on ferme le browser
    	bFinish = true;
	}

	return bFinish ;
}

// Fonction appel�e par CmOk et CmCancel de TDIEPubli :
// Destruction des fichiers temporaires d'impression
///////////////////////////////////////////////////////
void
NSPublication::DeleteFichPubli()
{
	string pathHtml = pContexte->PathName("SHTM") ;

	for (int j = 0; j < numImpress; j++)
	{
  	sFichHtml[j] = pathHtml + sFichHtml[j] ;
    if (!DeleteFile(sFichHtml[j].c_str()))
    	erreur("Pb de destruction d'un fichier de publication.",standardError,0,pContexte->GetMainWindow()->GetHandle()) ;

    if (sLettreHtml[j] != "")
    {
    	sLettreHtml[j] = pathHtml + sLettreHtml[j] ;
      if (!DeleteFile(sLettreHtml[j].c_str()))
      	erreur("Pb de destruction d'une lettre jointe.",standardError,0,pContexte->GetMainWindow()->GetHandle()) ;
    }
	}
	numImpress = 0 ;
}

void
NSPublication::InstalleHook()
{
	if (bUseHook)
		hhook = SetWindowsHookEx(WH_CALLWNDPROCRET, CallWndRetProc, (HINSTANCE) NULL, GetCurrentThreadId()) ;
}

void
NSPublication::LibereHook()
{
    if (bUseHook)
	    UnhookWindowsHookEx(hhook);
}

void
NSPublication::ConnectHost()
{
try
{
	// r�cup�ration des param�tres de emailXXX.dat
	if (!pContexte->getUtilisateur()->initMail())
  {
  	erreur("Envoi des e-mails impossible.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    pXSMTP = 0 ;
    return ;
	}

  // nom du fichier � exporter : nom document + nom patient + prenom patient
  if (pDocMaitre->pDocInfo)
  {
  	sObjet = pDocMaitre->pDocInfo->getDocName() ;
    if (sObjet == "")
    	sObjet = string("fichier") ;

    sObjet += string(" ") ;
  }
  else
  	sObjet = string("fichier ") ;

	if (NULL != pContexte->getPatient())
  {
		sObjet += pContexte->getPatient()->getNom() + string(" ") ;
  	sObjet += pContexte->getPatient()->getPrenom() ;
  }
  string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
  string sMessage = string("Vous devez �tre connect�s � internet pour que ") + pContexte->getSuperviseur()->getAppName().c_str() + string(" envoie vos e-mails automatiquement. Etes-vous connect�s en ce moment ?") ;
  int idRet = ::MessageBox(pContexte->GetMainWindow()->GetHandle(), sMessage.c_str(), sCaption.c_str(), MB_YESNO) ;

	if (idRet == IDYES)
	{
    pXSMTP = new TControlSMTP(NULL, pContexte, pDocMaitre, pContexte->getUtilisateur()->pMail) ;
    pXSMTP->Show() ;
    pXSMTP->Connect() ;
    if (!(pXSMTP->bConnected))
    {
    	pXSMTP->Close() ;
      delete pXSMTP ;
      pXSMTP = 0 ;
    }
	}
  else
  {
  	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    ::MessageBox(pContexte->GetMainWindow()->GetHandle(), "Impossible d'envoyer les e-mails.", sCaption.c_str(), MB_OK) ;
    pXSMTP = 0 ;
	}
}
catch (...)
{
	erreur("Exception NSPublication::ConnectHost", standardError, 0) ;
}
}

void
NSPublication::DisconnectHost()
{
	if (!pXSMTP)
		return ;

	pXSMTP->Disconnect() ;
	pXSMTP->Close() ;
	delete pXSMTP ;
}

bool
NSPublication::Imprimer(int index)
{
try
{
	string sDest;
	string sAdrCorresp;
	string sPathHtml;
	char   nomFichHtml[255];
	char   msg[255];
	string ps;

	sPathHtml = pContexte->PathName("SHTM");

	//
	// generation du compte-rendu � la bonne adresse
	//
	if (index >= 0)
	{
		// on est certain ici que le corresp existe
		//
		sDest = NomCorresp(aChoixPubli[index].corresp) ;
		sAdrCorresp = StringAdresse(aChoixPubli[index].corresp) ;
		sprintf(nomFichHtml,"%s-%s",codeDoc.c_str(), aChoixPubli[index].corresp) ;

		pDocMaitre->nbImpress       = aChoixPubli[index].cpt ;
		pDocMaitre->indexCorresp    = index ;

		//
		// Impression avec lettre
		//
		if (aChoixPubli[index].lettre)
		{
			if (CodeDocLettre(index, pDocMaitre->sCodeLettre))
			{
				pDocMaitre->bImprimerLettre = true ;
				indexLettre = index ;
				// sAdresseCorresp sert pour NSVisualView::ImprimerLettre()
				sAdresseCorresp = sAdrCorresp ;
			}
			else
			{
				pDocMaitre->bImprimerLettre = false ;
				char msgerr[100] ;
				sprintf(msgerr,"Impossible d'imprimer la lettre destin�e � %s.",sDest.c_str()) ;
				erreur(msgerr, standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
			}
		}
		else			pDocMaitre->bImprimerLettre = false ;	}
	else
	{
		if ((NULL != pContexte->getPatient()) && (!strcmp(choixPubli.corresp, pContexte->getPatient()->getszNss())))   // cas du patient
		{			sDest = pContexte->getPatient()->getPrenom() ;			if (sDest != "")
				sDest += string(" ") ;
			sDest += pContexte->getPatient()->getNom() ;

			sAdrCorresp = StringAdresse(aChoixPubli[index].corresp) ;
		}
		else
		{
			// en g�n�ral ici corresp == "" (sDest <= "XXX")
			sDest = NomCorresp(choixPubli.corresp) ;
			sAdrCorresp = "" ;
		}

		sprintf(nomFichHtml,"%s-000",codeDoc.c_str()) ;
		pDocMaitre->nbImpress = choixPubli.cpt ;
		pDocMaitre->indexCorresp = -1 ;
	}

	sFichHtml[numImpress] = string(nomFichHtml) ;

  sprintf(msg, "Impression n�%d - %s", numImpress+1, sDest.c_str()) ;
  ps = string(msg) ;
  pContexte->getSuperviseur()->trace(&ps, 1) ;

  ps = string("G�n�ration du fichier : ") +  sFichHtml[numImpress] ;
  pContexte->getSuperviseur()->trace(&ps, 1) ;

  if (!pDocMaitre->GenereHtml(sPathHtml, sFichHtml[numImpress], toImprimer, sAdrCorresp))
  {
    erreur("Impossible de cr�er le fichier html � imprimer", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
  	return false ;
  }

  pDocMaitre->sNomDocHtml = sFichHtml[numImpress] ;

	if (iTempImp)
		Tempo(iTempImp) ;
	else if (bWaitImp)
	{
		string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
		::MessageBox(pContexte->GetMainWindow()->GetHandle(), msg, sCaption.c_str(), MB_OK) ;	}	ps = "Lancement de la VisualView..." ;
	pContexte->getSuperviseur()->trace(&ps, 1) ;

  numImpress++ ;

  NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pDocMaitre, "Visual Format") ;

  // For synch reasons, it is better to do it earlier
	// numImpress++ ;

	// Ancienne m�thode de publication :
	// on lance le navigate qui est ensuite intercept� par l'objet browser	// pDocMaitre->pWebBrowserPubli->Navigate(sFichHtml[numImpress++]);
	return true ;
}
catch (...)
{
	erreur("Exception NSPublication::Imprimer", standardError, 0) ;
	return false ;
}
}

boolNSPublication::SendMail(string sPathHtml, int index)
{
try
{
	string sAdrCorresp ;
  string sNomHtml ;
  string sNomDoc ;
  string sFichierHtml ;
  string sFichierImage ;
  string sEMail ;
  string sCodeLettre = "" ;
  char   nomFichHtml[100] ;
  NSBaseImages* pBase ;

  // generation du compte-rendu � la bonne adresse  if (index >= 0)
  {
    sAdrCorresp = StringAdresse(aChoixPubli[index].corresp) ;
    sprintf(nomFichHtml, "%s-%s", codeDoc.c_str(), aChoixPubli[index].corresp) ;
    sEMail = string(aChoixPubli[index].url) ;

    if (sEMail == "")    {
      char msg[100] ;
      string sDest = NomCorresp(aChoixPubli[index].corresp) ;
      sprintf(msg, "Le correspondant %s n'a pas d'adresse e-mail.", sDest.c_str()) ;
      erreur(msg, standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      return false ;
    }

#ifndef _MUE
		if (aChoixPubli[index].lettre)    {
      	    if (!CodeDocLettre(index, sCodeLettre))
            {
                char msg[100];

                string sDest = NomCorresp(aChoixPubli[index].corresp);
                sprintf(msg,"Impossible d'envoyer le corps du message pour %s.",sDest.c_str());
                erreur(msg, 0, 0, pContexte->GetMainWindow()->GetHandle());
            }
        }#endif
    }    else
    {
    	if ((NULL != pContexte->getPatient()) && (!strcmp(choixPubli.corresp, pContexte->getPatient()->getszNss())))
      {
        sAdrCorresp = StringAdresse(aChoixPubli[index].corresp) ;
        sprintf(nomFichHtml, "%s-%s", codeDoc.c_str(), choixPubli.corresp) ;
        sEMail = string(choixPubli.url) ;

        if (sEMail == "")        {
          char msg[100] ;
          string sDest = NomCorresp(choixPubli.corresp) ;
          sprintf(msg, "Le correspondant %s n'a pas d'adresse e-mail.", sDest.c_str()) ;
          erreur(msg, standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
          return false ;
        }
      }
      else
      {
        sAdrCorresp = "" ;        sprintf(nomFichHtml,"%s",codeDoc.c_str()) ;
        sEMail = string(choixPubli.url) ;
        if (sEMail == "")        {
          erreur("Vous n'avez pas mentionn� d'adresse e-mail.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
          return false ;
        }
      }
    }

    sNomHtml = string(nomFichHtml) ;
    if (!pDocMaitre->GenereHtml(sPathHtml, sNomHtml, toExporter, sAdrCorresp, sPathHtml))
    {
      erreur("Impossible de cr�er le fichier html � exp�dier",standardError,0,pContexte->GetMainWindow()->GetHandle()) ;
      return false ;
    }

    sFichierHtml = sPathHtml + sNomHtml ;

    //
    if (!InitCrypteurs(sEMail))
    {
      erreur("Impossible d'initialiser le module de cryptage", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      return false ;
    }
    if (pCrypteMsg != NULL)
    {
    	long lErr = ((*pCrypteMsg)
                     ((NSContexte far *) pContexte, (string far *) &sCodeLettre,
                      (string far *) &sEMail, NULL)) ;
      if (lErr != 0)
      {
        erreur("Impossible de crypter le message",standardError,0,pContexte->GetMainWindow()->GetHandle()) ;
        return false ;
      }
    }
    if (pCrypteMsg != NULL)
    {
    	long lErr = ((*pCrypteMsg)
                     ((NSContexte far *) pContexte, (string far *) &sCodeLettre,
                      (string far *) &sEMail, NULL));
      if (lErr != 0)
      {
        erreur("Impossible de crypter le message",standardError,0,pContexte->GetMainWindow()->GetHandle()) ;
        return false ;
      }
    }

    // corps du message    pXSMTP->ComposeMessage(pContexte->getUtilisateur()->pMail->sMailExp,                            sEMail, sObjet, sCodeLettre) ;

    // Attachement du document Html
    if (sFichierHtml != "")
    {
    	if (pCrypteFic != NULL)
    	{
      	string sFichierInitial = sFichierHtml ;
    		long lErr = ((*pCrypteFic)
                     	 ((NSContexte far *) pContexte, (string far *) &sFichierHtml,
                      	  (string far *) &sEMail, NULL)) ;
        if (lErr != 0)
        {
        	erreur("Impossible de crypter le document HTML",standardError,0,pContexte->GetMainWindow()->GetHandle()) ;
          return false ;
        }
        pXSMTP->AttacheMessage(sFichierHtml) ;
        if (sFichierHtml != sFichierInitial)
        {
        	DeleteFile(sFichierHtml.c_str()) ;
          sFichierHtml = sFichierInitial ;
        }
    	}
      else
    		pXSMTP->AttacheMessage(sFichierHtml) ;
    }

    // Attachement des images
    if (pDocMaitre->sBaseImages != "")
    {
        pBase = new NSBaseImages(pDocMaitre->sBaseImages);
   		pBase->lire();

   		for (int i = 0; i < pBase->nbImages; i++)
   		{
      	sFichierImage = pBase->tableDesImg[i] + pBase->tableImages[i] ;
        if (pCrypteFic != NULL)
    		{
        	string sFichierImageInitial = sFichierImage ;
    			long lErr = ((*pCrypteFic)
                     	 	 ((NSContexte far *) pContexte, (string far *) &sFichierImage,
                      	  	 (string far *) &sEMail, NULL));
          if (lErr != 0)
          {
            erreur("Impossible de crypter une image",standardError,0,pContexte->GetMainWindow()->GetHandle());
            return false;
          }
          pXSMTP->AttacheMessage(sFichierImage) ;
          if (sFichierImage != sFichierImageInitial)
          {
          	DeleteFile(sFichierImage.c_str()) ;
            sFichierImage = sFichierImageInitial ;
          }
    		}
        else
        	pXSMTP->AttacheMessage(sFichierImage) ;
		}
	}
	pXSMTP->SendMail() ;

  if (pDocMaitre->sBaseImages != "")
  {
  	pBase->detruire() ;
    pDocMaitre->sBaseImages = "" ;
    delete pBase ;
  }
	if (!DeleteFile(sFichierHtml.c_str()))
  	erreur("Pb de destruction du fichier de publication",standardError,0,pContexte->GetMainWindow()->GetHandle()) ;

	return true ;
}catch (...)
{
    erreur("Exception NSPublication::SendMail.", standardError, 0) ;
    return false;
}
}

boolNSPublication::Exporter(string sPathHtml, int index)
{
	string sAdrCorresp ;
	string sNomHtml ;
	char   nomFichHtml[1024] ;

	// generation du compte-rendu � la bonne adresse
	if (index >= 0)
	{
  	sAdrCorresp = StringAdresse(aChoixPubli[index].corresp) ;
    sprintf(nomFichHtml,"%s-%s",codeDoc.c_str(),aChoixPubli[index].corresp) ;
	}
	else
	{
		if ((NULL != pContexte->getPatient()) && (!strcmp(choixPubli.corresp, pContexte->getPatient()->getszNss())))
    {
    	sAdrCorresp = StringAdresse(aChoixPubli[index].corresp) ;
      sprintf(nomFichHtml,"%s-%s",codeDoc.c_str(),aChoixPubli[index].corresp) ;
    }
    else
    {
    	sAdrCorresp = "" ;
      sprintf(nomFichHtml,"%s",codeDoc.c_str()) ;
    }
	}

	sNomHtml = string(nomFichHtml) ;

	// exportation du fichier html
	if (!pDocMaitre->GenereHtml(sPathHtml,sNomHtml,toExporter,sAdrCorresp,sPathHtml))
	{
  	erreur("Impossible de cr�er le fichier html � exporter", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return false ;
	}

	// exportation des images : fait par GenereHtml
	/*************************************************
	if (pDocMaitre->sBaseImages != "")
    {
   		NSBaseImages* pBase = new NSBaseImages(pDocMaitre->sBaseImages);
   		pBase->lire();
		if (!pBase->copier(sPathHtml))
        	erreur("Erreur � la copie des images dans le r�pertoire d'exportation.",0,0);
        pBase->detruire();
        delete pBase;
    }
    **************************************************/

	return true ;
}

voidNSPublication::DeleteVisualViews()
{
	for (TView* pView = pDocMaitre->GetViewList(); pView != 0; pView = pView->GetNextView())
	{
		if (!strcmp(pView->GetViewName(), "NSVisualView"))
		{
			NSVisualView* pVisualView = dynamic_cast<NSVisualView*>(pView) ;
      if (pVisualView)
				pVisualView->CloseWindow() ;
		}
	}
}

voidNSPublication::initParams()
{
    ifstream inFile;
    string line;
    string sData = "";
    string sNomAttrib = "";
   	string sValAttrib = "";

    size_t i = 0, j = 0;
    string sFichierTempo = pContexte->PathName("FPER") + string("tempo.dat");
    inFile.open(sFichierTempo.c_str());    if (!inFile)
    {
   	    erreur("Erreur d'ouverture du fichier tempo.dat.", standardError, 0, pContexte->GetMainWindow()->GetHandle());
        return;
    }

    while (!inFile.eof())    {
        getline(inFile,line);
        if (line != "")
            sData += line + "\n";
    }

    inFile.close();
    // boucle de chargement des attributs de tempo.dat   	while (i < strlen(sData.c_str()))
   	{
        sNomAttrib = "";

   		while ((i < strlen(sData.c_str())) && (sData[i] != ' ') && (sData[i] != '\t'))      		sNomAttrib += pseumaj(sData[i++]);

      	while ((i < strlen(sData.c_str())) && ((sData[i] == ' ') || (sData[i] == '\t')))      		i++;

        sValAttrib = "";
      	while ((i < strlen(sData.c_str())) && (sData[i] != '\n'))      		sValAttrib += sData[i++];

        if (sNomAttrib == "HOOK")
        {

            for (j = 0; j < strlen(sValAttrib.c_str()); j++)                sValAttrib[j] = pseumaj(sValAttrib[j]);

            if ((sValAttrib == "NON") || (sValAttrib == "NO"))                bUseHook = false;
            else
                bUseHook = true;
        }
        else if (sNomAttrib == "WAITIMP")
        {
            for (j = 0; j < strlen(sValAttrib.c_str()); j++)
                sValAttrib[j] = pseumaj(sValAttrib[j]);

            if ((sValAttrib == "NON") || (sValAttrib == "NO"))                bWaitImp = false;
            else
                bWaitImp = true;
        }
        else if (sNomAttrib == "TEMPIMP")
        {
            iTempImp = atoi(sValAttrib.c_str());
        }

      	i++;   	}}

voidNSPublication::Tempo(int iDelay)
{
	// application du d�lai (unit� : centi�me de seconde)
	if ((pContexte->getSuperviseur() == NULL) || (iDelay == 0))
		return ;

	pContexte->getSuperviseur()->Delay(iDelay) ;}

voidNSPublication::Publier()
{
	string ps ;

	pContexte->GetMainWindow()->SetCursor(0, IDC_WAIT) ;

	bool bCorrespLoaded = ChargeCorrespBase() ;	pContexte->GetMainWindow()->SetCursor(0, IDC_ARROW) ;
	if (false == bCorrespLoaded)
		return ;

	if (aCorrespBaseArray.empty())	{
  	ps = "Lancement de PubliSansCorrespDialog..." ;
		pContexte->getSuperviseur()->trace(&ps, 1) ;

		if (PubliSansCorrespDialog(pContexte->GetMainWindow(),pContexte, this).Execute() == IDCANCEL)			return ;

      	// voir workflow...	}
	else
	{
  	if (aCorrespBaseArray.size() > 1)
    {
    	if (ChoixCorrespDialog(pContexte->GetMainWindow(),pContexte, this).Execute() == IDCANCEL)
      	return ;
    }
    else
    {
    	aChoixPubli[0].select = true ;
    }

    ps = "Lancement de PubliCorrespDialog...";    pContexte->getSuperviseur()->trace(&ps, 1);

    if (PubliCorrespDialog(pContexte->GetMainWindow(),pContexte, this).Execute() == IDCANCEL)    	return ;

#ifndef _MUE		RemplitWorkflow();#endif
	}

	if ((aCorrespBaseArray.empty()) || (ExisteCorrespSelect()))	{
  	// On regarde si on a un document "publiable"
    if ((pDocMaitre->pDocInfo->getType() != string("ZCN00")) &&
        (pDocMaitre->pDocInfo->getType() != string("ZCS00")) &&
        (pDocMaitre->pDocInfo->getType() != string("ZCQ00")) &&        (string(pDocMaitre->pDocInfo->getType(), 0, 2) != string("ZC")) &&
        (string(pDocMaitre->pDocInfo->getType(), 0, 2) != string("ZP")) &&
        (pDocMaitre->pDocInfo->getType() != string("ZHIST")) &&
        (pDocMaitre->pDocInfo->getType() != string("ZTRTF")) &&
        (pDocMaitre->pDocInfo->getType() != string("ZTHTM")))
    {
    	erreur("Ce type de document n'est pas g�r� par la publication", warningError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      return ;
    }

		// sinon :    ps = "Lancement de la Publication..." ;
    pContexte->getSuperviseur()->trace(&ps, 1) ;

		Publication() ;	}
}

bool
NSPublication::InitCrypteurs(string sURL){
try
{
    pCrypteMsg = 0;
    pCrypteFic = 0;

    string sFAI;
    size_t iPosAt = sURL.find('@');
    if ((iPosAt == NPOS) || (iPosAt == strlen(sURL.c_str()) - 1))
        sFAI = "";
    else
        sFAI = string(sURL, iPosAt + 1, strlen(sURL.c_str()) - iPosAt -1);

    //
    // Est-ce une adresse Apicrypt ?
    //
    if ((string(sFAI, 0, 7) == "medical") && (sFAI.find("netinfo.fr") != NPOS))
    {
        // On ferme la dll de cryptage d�j� ouverte, sauf si c'est d�j�
        // la dll Apicrypt
        //
        if (pCryptoModule)
        {
            const char* nomModule = pCryptoModule->GetName();
            if ((string(nomModule).find(string("ns_apicr")) == NPOS) &&
                (string(nomModule).find(string("NS_APICR")) == NPOS))
            {
      		    delete pCryptoModule;
         	    pCryptoModule = 0;
            }
        }
        // Si aucune dll de cryptage n'est ouverte, on ouvre la dll Apicrypt
        //
        if (!pCryptoModule)
        {
        	pCryptoModule = new TModule("ns_apicr.dll", TRUE);
            if (!pCryptoModule)
           	{
      	        erreur("La DLL de cryptage Apicrypt (ns_apicr.dll) est introuvable.", standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
                return false;
            }
        }
        // On initialise les pointeurs de cryptage (cha�nes et fichiers)
        //
        (FARPROC) pCrypteMsg = pCryptoModule->GetProcAddress(MAKEINTRESOURCE(1));
        if (pCrypteMsg == NULL)
            return false;
        (FARPROC) pCrypteFic = pCryptoModule->GetProcAddress(MAKEINTRESOURCE(2));
        if (pCrypteFic == NULL)
            return false;
        return true;
    }

    return true;
}
catch (...)
{
    erreur("Exception � l'ouverture du module de cryptage.", standardError, 0) ;
    return false;
}
}

////////////////////////////// Messagerie via MAPI ////////////////////////

NSMapiCtrl::NSMapiCtrl(NSContexte* ctx, NSRefDocument* doc, NSMailParams* mail)
{
	// on ne fait pas de copie : tous les pointeurs sont r�sidents
    pContexte = ctx;
    pDoc = doc;
    pMail = mail;
    encours = "(vide)";
    bInterrupt = false;
    bAttendre = false;

    memset(&msg, 0, sizeof(msg));
    memset(&destinataire, 0, sizeof(destinataire));
    memset(&emetteur, 0, sizeof(emetteur));
    emetteur.ulRecipClass = MAPI_ORIG;
}

NSMapiCtrl::~NSMapiCtrl(){
}

void
NSMapiCtrl::Connect()
{
try
{
    // Ouverture de la DLL
    GetProfileInt("Mail", "MAPI", 0 );
    MapiInst = LoadLibrary("MAPI32.DLL");

  	LPMAPILOGON MapiLogon = (LPMAPILOGON) GetProcAddress(MapiInst, "MAPILogon");
    MapiLogon(0, NULL, NULL, MAPI_LOGON_UI, 0, &session);
}
catch (...)
{
    erreur("Exception � l'ouverture de MAPI.", standardError, 0) ;
}
}

void
NSMapiCtrl::Disconnect()
{
try
{
	LPMAPILOGOFF MapiLogoff = (LPMAPILOGOFF) GetProcAddress(MapiInst, "MAPILogoff");
    MapiLogoff(session, 0, standardError, 0) ;
    FreeLibrary(MapiInst);
}
catch (...)
{
    erreur("Exception lors de la d�connexion MAPI.", standardError, 0) ;
}
}

bool
NSMapiCtrl::Verify()
{
	if (session)
    	return true;
    return false;
}

void
NSMapiCtrl::ComposeMessage(string sFromAdr, string sToAdr, string sObjet, string sCodeLettre)
{
try
{
    // Raz des param�tres
    memset(&msg, 0, sizeof(msg));
    if (destinataire.lpszAddress)
    	delete[] destinataire.lpszAddress;
    memset(&destinataire, 0, sizeof(destinataire));

    destinataire.ulRecipClass = MAPI_TO;
  	destinataire.lpszAddress = new char[strlen(sToAdr.c_str())+1];
    strcpy(destinataire.lpszAddress, sToAdr.c_str());

    if (emetteur.lpszAddress)
    	delete[] emetteur.lpszAddress;
    emetteur.lpszAddress = new char[strlen(sFromAdr.c_str())+1];
    strcpy(emetteur.lpszAddress, sFromAdr.c_str());

    msg.lpszSubject  = new char[strlen(sObjet.c_str())+1];
    strcpy(msg.lpszSubject, sObjet.c_str());

  	msg.lpszNoteText = new char[strlen(sCodeLettre.c_str())+1];
    strcpy(msg.lpszNoteText, sCodeLettre.c_str());

    msg.lpOriginator = &emetteur;
  	msg.nRecipCount  = 1;
  	msg.lpRecips     = &destinataire;
}
catch (...)
{
    erreur("Exception lors du ComposeMessage MAPI.", standardError, 0) ;
}
}

ULONGNSMapiCtrl::SendMail()
{
try
{
    LPMAPISENDMAIL MapiSendMail = (LPMAPISENDMAIL) GetProcAddress(MapiInst, "MAPISendMail");
    if (MapiSendMail == NULL)
        return 0;

    ULONG lResult = MapiSendMail(0 /*Session*/, 0 /*ulUIParam*/, &msg, MAPI_LOGON_UI, 0);

    string sErreur = "";

    if      (lResult == MAPI_E_AMBIGUOUS_RECIPIENT)
        sErreur = "destinataire ambigu - message non exp�di�";
    else if (lResult == MAPI_E_ATTACHMENT_NOT_FOUND)
        sErreur = "pi�ce jointe non trouv�e - message non exp�di�";
    else if (lResult == MAPI_E_ATTACHMENT_OPEN_FAILURE)
        sErreur = "impossible d'ouvrir une pi�ce jointe - message non exp�di�";
    else if (lResult == MAPI_E_BAD_RECIPTYPE)
        sErreur = "un destinataire n'a pas un type correct (CC, CCI...) - message non exp�di�";
    else if (lResult == MAPI_E_FAILURE)
        sErreur = "erreur(s) MAPI non pr�cis�e(s) - message non exp�di�";
    else if (lResult == MAPI_E_INSUFFICIENT_MEMORY)
        sErreur = "m�moire insuffisante - message non exp�di�";
    else if (lResult == MAPI_E_LOGIN_FAILURE)
        sErreur = "�chec du login - message non exp�di�";
    else if (lResult == MAPI_E_TEXT_TOO_LARGE)
        sErreur = "message trop grand - message non exp�di�";
    else if (lResult == MAPI_E_TOO_MANY_FILES)
        sErreur = "trop de fichiers joints - message non exp�di�";
    else if (lResult == MAPI_E_TOO_MANY_RECIPIENTS)
        sErreur = "trop de correspondants - message non exp�di�";
    else if (lResult == MAPI_E_UNKNOWN_RECIPIENT)
        sErreur = "correspondant inconnu - message non exp�di�";
    else if (lResult == MAPI_E_USER_ABORT)
        sErreur = "envoi annul� - message non exp�di�";

    if (lResult != SUCCESS_SUCCESS)
    {
        sErreur = "Erreur � l'envoi du message par MAPI : " + sErreur;
        erreur(sErreur.c_str(), standardError, 0) ;
    }

    return lResult;
}
catch (...)
{
    erreur("Exception lors du SendMail MAPI.", standardError, 0) ;
    return 0 ;
}
}

// fin de nscompub.cpp
