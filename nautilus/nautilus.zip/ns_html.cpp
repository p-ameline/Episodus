// -----------------------------------------------------------------------------// NS_HTML.CPP
// RS Juin 97
// G�n�ration de fichiers HTML � partir d'un compte-rendu
// -----------------------------------------------------------------------------
#define __NS_HTML_CPP

#include <stdio.h>
#include <classlib\filename.h>

#include "nautilus\ns_html.h"
#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "nautilus\nsresour.h"

#include "partage\nsperson.h"     // pour l'utilisateur  (NSHtmlCR)
#include "nautilus\nscrdoc.h"		  // pour r�cup�rer sFichDecod  (NSHtmlCR)
#include "nautilus\nscsdoc.h"		  // pour r�cup�rer le html de consultation (NSHtmlCS)
#include "nautilus\nsttx.h"		    // pour la constante MAXCARS (taille max RTF)
#include "nautilus\nsdocaga.h"
#include "nautilus\nsperary.h"
#include "nautilus\nsrechdl.h"
#include "nautilus\nscqdoc.h"
#include "nsbb\nsmanager.h"

// -----------------------------------------------------------------------------
// Classe NSHtmlCS
//
// On r�cup�re le html correspondant � l'�tat en cours de la TreeView (pHtmlCS)
// -----------------------------------------------------------------------------

NSHtmlCS::NSHtmlCS(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)
         :NSModHtml(typeOp, pDocNoy, pCtx)
{
	string sIntitule  = string("") ;
  string sTitre     = string("") ;
	string sCreateur  = string("") ;
	string sDate      = string("") ;
	string sSignature = string("") ;

	NSCSDocument *pCSDoc = dynamic_cast<NSCSDocument *>(pDocNoy) ;
	// on r�cup�re le titre du document
	sTitre = string(pCSDoc->GetTitle()) ;

	string sNss = pCSDoc->pDocInfo->getAuthor() ;
  if (string("") == sNss)
  	sNss = pCSDoc->pDocInfo->getCreator() ;

  if (string("") != sNss)
  {
		NSPersonInfo* pUtil = pContexte->getPersonArray()->getPerson(sNss, pidsUtilisat) ;
  	if (NULL != pUtil)
			sSignature = pUtil->sCivilite ;
	}

  // on prend la date du document et l'intitule
  sDate     = pCSDoc->GetDateDoc() ;
  sIntitule = pCSDoc->InitIntitule() ;

  ajoute(new NSHtml(tTitle,     sTitre)) ;
  ajoute(new NSHtml(tOperateur, sCreateur)) ;
  ajoute(new NSHtml(tDate,      sDate)) ;
  ajoute(new NSHtml(tDest,      sDest)) ;
  ajoute(new NSHtml(tIntitule,  sIntitule)) ;
  ajoute(pCSDoc->pHtmlCS) ;
  ajoute(new NSHtml(tSignature, sSignature)) ;
}

NSHtmlCS::~NSHtmlCS()
{
}

// -----------------------------------------------------------------------------
// Classe NSHtmlCQ
//
// On r�cup�re le html inclus dans l'archetype associ�
// -----------------------------------------------------------------------------

NSHtmlCQ::NSHtmlCQ(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)
         :NSModHtml(typeOp, pDocNoy, pCtx)
{
	string sTitre     = string("") ;
	string sCreateur  = string("") ;
	string sDate      = string("") ;
	string sSignature = string("") ;
	string sIntitule  = string("") ;

  if (NULL != pDocNoy)
  {
		NSCQDocument *pCQDoc = dynamic_cast<NSCQDocument *>(pDocNoy) ;
    if (NULL != pCQDoc)
    {
			// on g�n�re le html � visualiser
			pCQDoc->genereHtmlView() ;

			// on r�cup�re le titre du document
			sTitre = string(pCQDoc->GetTitle()) ;

			string sNss = pCQDoc->pDocInfo->getAuthor() ;
			if (string("") == sNss)
				pCQDoc->pDocInfo->getCreator() ;
  		if (string("") != sNss)
  		{
				NSPersonInfo* pUtil = pContexte->getPersonArray()->getPerson(sNss, pidsUtilisat) ;
    		if (NULL != pUtil)
					sSignature = pUtil->sCivilite ;
  		}

  		// on prend la date du document et l'intitule
			sDate     = pCQDoc->GetDateDoc() ;
  		sIntitule = pCQDoc->InitIntitule() ;

    	ajoute(new NSHtml(tCQ, pCQDoc->sHtmlView)) ;
    }
	}

  ajoute(new NSHtml(tTitle,     sTitre)) ;
  ajoute(new NSHtml(tOperateur, sCreateur)) ;
  ajoute(new NSHtml(tDate,      sDate)) ;
  ajoute(new NSHtml(tDest,      sDest)) ;
  ajoute(new NSHtml(tIntitule,  sIntitule)) ;
  ajoute(new NSHtml(tSignature, sSignature)) ;
}


NSHtmlCQ::~NSHtmlCQ()
{
}

// -----------------------------------------------------------------------------
// Classe NSHtmlHisto
//
// On r�cup�re le html correspondant � l'�tat en cours de la TreeView (pHtmlCS)
// -----------------------------------------------------------------------------


NSHtmlHisto::NSHtmlHisto(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)
            :NSModHtml(typeOp, pDocNoy, pCtx)
{
  string 	            sTitre ;
  string 	            sDate ;
  string              sIntro, sMessage ;
  char 	              cDate[9] ;
  TDate 	            dateSys ;
  NSHistoRefDocument  *pHistoDoc = dynamic_cast<NSHistoRefDocument *>(pDocNoy) ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  sTitre = string("Historique") ;

  sprintf(cDate,"%4d%02d%02d", (int) dateSys.Year(), (int) dateSys.Month(), (int) dateSys.DayOfMonth()) ;
  sDate = string(cDate) ;
  donne_date_claire(sDate, &sMessage, &sIntro, sLang) ;

  if (sIntro != "")
    sDate = sIntro + " " + sMessage ;
  else
    sDate = sMessage ;

  if      (pHistoDoc->sImportance == "A")
    sDate += " (global)" ;
  else if (pHistoDoc->sImportance == "B")
    sDate += " (partiel : �l�ments d'importance 1+)" ;
  else if (pHistoDoc->sImportance == "C")
    sDate += " (partiel : �l�ments d'importance 2+)" ;
  else if (pHistoDoc->sImportance == "D")
    sDate += " (partiel : �l�ments d'importance 3+)" ;
  else if (pHistoDoc->sImportance == "E")
    sDate += " (partiel : �l�ments d'importance 4+)" ;

  ajoute(new NSHtml(tTitle, sTitre)) ;
  ajoute(new NSHtml("nomPatient", pContexte->getPatient()->getNomLong())) ;
  ajoute(new NSHtml(tDate, sDate)) ;  ajoute(new NSHtml(tDest, sDest)) ;
  ajoute(pHistoDoc->pHtmlCS) ;
}


NSHtmlHisto::~NSHtmlHisto()
{
}

// -----------------------------------------------------------------------------
//		Classe NSHtmlSecu//
// Pour l'impression des feuilles de soins � partir des donn�es patient
// -----------------------------------------------------------------------------


NSHtmlSecu::NSHtmlSecu(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx)
           :NSModHtml(typeOp, pDocNoy, pCtx)
{
  NSSecuRefDocument *pSecuDoc = dynamic_cast<NSSecuRefDocument *>(pDocNoy) ;

  // Compatibilit� CERFA 10441*2

  // on instancie d'abord les tags li�s au malade
  ajoute(new NSHtml("nomMalade",    pSecuDoc->pCarteMalade->pDonnees->nomPatro)) ;
  ajoute(new NSHtml("prenomMalade", pSecuDoc->pCarteMalade->pDonnees->prenom)) ;
  if (pSecuDoc->bNonAssure)
  {
    ajoute(new NSHtml("numMalade",  "")) ;
    ajoute(new NSHtml("numAssu",    pSecuDoc->pCarteMalade->pDonnees->immatricul)) ;
  }
  else
  {
    ajoute(new NSHtml("numMalade",  pSecuDoc->pCarteMalade->pDonnees->immatricul)) ;
    ajoute(new NSHtml("numAssu",    "")) ;
  }

  char cDateNaiss[9], message[11];
  if (strcmp(pSecuDoc->pCarteMalade->pDonnees->dateNais, ""))
  {
  	string sLang = "" ;
		if (pContexte->getUtilisateur())
			sLang = pContexte->getUtilisateur()->donneLang() ;

    // on convertit la date de naissance au format jj/mm/aaaa
    strcpy(cDateNaiss, (string(pSecuDoc->pCarteMalade->pDonnees->dateNais, 0, 8)).c_str()) ;
    donne_date(cDateNaiss, message, sLang) ;
    ajoute(new NSHtml("dateNaissMalade", message)) ;
  }
  else
    ajoute(new NSHtml("dateNaissMalade", "")) ;

  ajoute(new NSHtml("codeRegime",   pSecuDoc->pCarte->pDonnees->regime)) ;
  ajoute(new NSHtml("codeCaisse",   pSecuDoc->pCarte->pDonnees->caisse)) ;
  ajoute(new NSHtml("codeCentre",   pSecuDoc->pCarte->pDonnees->centre)) ;
  ajoute(new NSHtml("codeGestion",  pSecuDoc->pCarte->pDonnees->codeGest)) ;

  // on instancie ensuite les tags li�s � l'assur�
  if (pSecuDoc->bNonAssure)
  {
    ajoute(new NSHtml("nomAssu",    pSecuDoc->pAssuInfo->getNom())) ;
    ajoute(new NSHtml("prenomAssu", pSecuDoc->pAssuInfo->getPrenom())) ;
  }
  else    // on remplace les tags par des blancs
  {
    ajoute(new NSHtml("nomAssu",    "")) ;
    ajoute(new NSHtml("prenomAssu", "")) ;
  }
}

NSHtmlSecu::~NSHtmlSecu()
{
}

// -----------------------------------------------------------------------------
// Classe NSHtmlConvoc//
// On instancie le html pour �diter la lettre de reconvocation
// -----------------------------------------------------------------------------

NSHtmlConvoc::NSHtmlConvoc(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)
             :NSModHtml(typeOp, pDocNoy, pCtx)
{
  NSConvocRefDocument *pConvocDoc = dynamic_cast<NSConvocRefDocument *>(pDocNoy) ;

  string sTitre  = string("Lettre de reconvocation") ;
  int index   = (pConvocDoc->pTabSelect)[pConvocDoc->indexCorresp] ;

  string  sM_Mme ;
  if (((pConvocDoc->pVarConvoc->aPatientArray)[index])->estMasculin())
    sM_Mme = string("Monsieur") ;  else
    sM_Mme = string("Madame") ;

  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  string sDate = ((pConvocDoc->pVarConvoc->aPatientArray)[index])->getConvoc() ;
  string sIntro, sMessage ;
  donne_date_claire(sDate, &sMessage, &sIntro, sLang) ;
  string sDateConvoc ;
  if (sIntro != "")
    sDateConvoc = sIntro + " " + sMessage ;
  else
    sDateConvoc = sMessage ;

  ajoute(new NSHtml(tTitle,       sTitre)) ;
  ajoute(new NSHtml(tDest,        sDest)) ;
  ajoute(new NSHtml("M_Mme",      sM_Mme),      2) ;
  ajoute(new NSHtml("dateConvoc", sDateConvoc)) ;
}


NSHtmlConvoc::~NSHtmlConvoc()
{
}

// -----------------------------------------------------------------------------
// Classe NSHtmlAga
//
// On instancie le html correspondant � l'�tat des AGA en cours
// -----------------------------------------------------------------------------

NSHtmlAga::NSHtmlAga(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)          :NSModHtml(typeOp, pDocNoy, pCtx)
{
	string sTitre ;
	string sOperateur   = "" ;
  char   cDateAga[9]  = "" ;
  char   dateAga1[11] = "" ;
  char   dateAga2[11] = "" ;

  NSAgaRefDocument  *pAgaDoc = dynamic_cast<NSAgaRefDocument *>(pDocNoy) ;
	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  strcpy(cDateAga, (pAgaDoc->pCriteres->sDateAga1).c_str()) ;  donne_date(cDateAga, dateAga1, sLang) ;
  strcpy(cDateAga, (pAgaDoc->pCriteres->sDateAga2).c_str()) ;
  donne_date(cDateAga, dateAga2, sLang) ;

  if (!pAgaDoc->bAgaCumules)  {    // on r�cup�re le titre du document
    sTitre = string("Liste des AGA du ") + string(dateAga1) ;
  }
  else
  {
    sTitre = string("Liste des recettes du ") + string(dateAga1) + string(" au ") + string(dateAga2) ;
  }

  if (pAgaDoc->pCriteres->bActesPerso)  {
    sOperateur = string(" pour ") + pContexte->getUtilisateur()->donneTitre(pContexte) ;
    sTitre += sOperateur ;
  }

  ajoute(new NSHtml("titre", sTitre)) ;

  if (!pAgaDoc->bAgaCumules)
    ajoute(new NSHtml("date", string(dateAga1))) ;  else    ajoute(new NSHtml("date", (string(dateAga1) + string(" au ") + string(dateAga2)))) ;
  ajoute(new NSHtml("beneficiaire", sOperateur)) ;}


NSHtmlAga::~NSHtmlAga()
{
}


void
NSHtmlAga::initTotaux()
{
  int 		montant ;
  char 		cData[100] ;
  string 	sData ;

  NSAgaRefDocument *pAgaDoc = dynamic_cast<NSAgaRefDocument *>(pDocBrut) ;

  montant = pAgaDoc->pTotaux->paieLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pAgaDoc->pVar->sigle ;
  ajoute(new NSHtml("totPaieLoc", sData)) ;

  montant = pAgaDoc->pTotaux->paieEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totPaieEuro", sData)) ;

  montant = pAgaDoc->pTotaux->espLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pAgaDoc->pVar->sigle ;
  ajoute(new NSHtml("totEspLoc", sData)) ;

  montant = pAgaDoc->pTotaux->espEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totEspEuro", sData)) ;

	montant = pAgaDoc->pTotaux->chqLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pAgaDoc->pVar->sigle ;
  ajoute(new NSHtml("totChqLoc", sData)) ;

  montant = pAgaDoc->pTotaux->chqEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totChqEuro", sData)) ;

  montant = pAgaDoc->pTotaux->virLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pAgaDoc->pVar->sigle ;
  ajoute(new NSHtml("totVirLoc", sData)) ;

  montant = pAgaDoc->pTotaux->virEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totVirEuro", sData)) ;

  montant = pAgaDoc->pTotaux->cbLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pAgaDoc->pVar->sigle ;
  ajoute(new NSHtml("totCbLoc", sData)) ;

  montant = pAgaDoc->pTotaux->cbEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totCbEuro", sData)) ;

  montant = pAgaDoc->pPartiels->paieLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pAgaDoc->pVar->sigle ;
  ajoute(new NSHtml("parPaieLoc", sData)) ;

  montant = pAgaDoc->pPartiels->paieEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("parPaieEuro", sData)) ;

  montant = pAgaDoc->pPartiels->espLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pAgaDoc->pVar->sigle ;
  ajoute(new NSHtml("parEspLoc", sData)) ;

  montant = pAgaDoc->pPartiels->espEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("parEspEuro", sData)) ;

  montant = pAgaDoc->pPartiels->chqLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pAgaDoc->pVar->sigle ;
  ajoute(new NSHtml("parChqLoc", sData)) ;

  montant = pAgaDoc->pPartiels->chqEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("parChqEuro", sData)) ;

  montant = pAgaDoc->pPartiels->virLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pAgaDoc->pVar->sigle ;
  ajoute(new NSHtml("parVirLoc", sData)) ;

  montant = pAgaDoc->pPartiels->virEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("parVirEuro", sData)) ;

  montant = pAgaDoc->pPartiels->cbLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pAgaDoc->pVar->sigle ;
  ajoute(new NSHtml("parCbLoc", sData)) ;

  montant = pAgaDoc->pPartiels->cbEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("parCbEuro", sData)) ;
}


void
NSHtmlAga::ajouteBloc(NSHtml *ph)
{
  ligneBlocHtml.push_back(new NSBlocHtml(ph, 1)) ;
}


void
NSHtmlAga::ajouteLignes(){
	int     iMontant ;
	char    cMontant[10]  = "" ;
	string  sData ;
	char    cDateAga[9]   = "" ;
	char    dateAga[11]   = "" ;

	NSAgaRefDocument *pAgaDoc = dynamic_cast<NSAgaRefDocument *>(pDocBrut) ;
	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	strcpy(cDateAga, (pAgaDoc->pCriteres->sDateAga1).c_str()) ;	donne_date(cDateAga, dateAga, sLang) ;
	for (NSAgaIter i = pAgaDoc->pAgaArray->begin() ; i != pAgaDoc->pAgaArray->end() ; i++)	{
  	ligneBlocHtml.vider() ;

        if (!pAgaDoc->bAgaCumules)
        {
            sData = ((*i)->patInfo).sNom ;
            ajouteBloc(new NSHtml("TBLNom", sData)) ;

            sData = ((*i)->patInfo).sPrenom ;            ajouteBloc(new NSHtml("TBLPrenom", sData)) ;

            sData = string((*i)->nomPatient) ;
            ajouteBloc(new NSHtml("TBLNomLong", sData)) ;

            sData = string((*i)->actes) ;            ajouteBloc(new NSHtml("TBLExamen", sData)) ;

            sData = string(dateAga) ;
            ajouteBloc(new NSHtml("TBLDate", sData)) ;
        }
        else
        {
            ajouteBloc(new NSHtml("TBLNom",     "&nbsp;")) ;
            ajouteBloc(new NSHtml("TBLPrenom",  "&nbsp;")) ;

            if (strcmp((*i)->actes, "") != 0)
                sData = string((*i)->actes) ;
            else
                sData = string("&nbsp;") ;
            ajouteBloc(new NSHtml("TBLExamen", sData)) ;

            if (strcmp((*i)->nomPatient, "") != 0)
                sData = string((*i)->nomPatient) ;
            else
                sData = string((*i)->libelle) ;
            ajouteBloc(new NSHtml("TBLNomLong", sData)) ;

            sData = string((*i)->datePaie) ;
            ajouteBloc(new NSHtml("TBLDate", sData)) ;

            sData = string((*i)->ecriture.compte) ;
            ajouteBloc(new NSHtml("TBLCompte", sData)) ;

            sData = string((*i)->cpt_lib.libelle) ;
            ajouteBloc(new NSHtml("TBLCompteLib", sData)) ;
        }

        iMontant = atoi((*i)->montant) ;        sprintf(cMontant, "%d,%02d", iMontant / 100, iMontant % 100) ;
		sData = string(cMontant) ;
        ajouteBloc(new NSHtml("TBLMontant", sData)) ;

        if (!strcmp((*i)->unite, "LOC"))            sData = pAgaDoc->pVar->sigle ;
        else
            sData = string("Euro") ;

        ajouteBloc(new NSHtml("TBLUnite", sData)) ;
        sData = string((*i)->modePaie) ;        ajouteBloc(new NSHtml("TBLModePaie", sData)) ;

        table.push_back(new NSBlocHtmlArray(ligneBlocHtml)) ;    }
	bExisteTable = true ;
}

// -----------------------------------------------------------------------------
// Classe NSHtmlReq
//
// On instancie le html correspondant � l'�tat de la recherche
// -----------------------------------------------------------------------------

NSHtmlReq::NSHtmlReq(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)          :NSModHtml(typeOp, pDocNoy, pCtx)
{
	string sTitre ;
	string sOperateur   = "" ;
  char szDateJour[15] ;
  donne_date_duJour(szDateJour) ;

    // on r�cup�re le titre du document    sTitre = string("R�sultats de la recherche du ") + string(szDateJour) ;
    sOperateur = string(" pour ") + pContexte->getUtilisateur()->donneTitre(pContexte) ;
    sTitre += sOperateur ;

  ajoute(new NSHtml("titre", sTitre)) ;  ajoute(new NSHtml("date", string(szDateJour))) ;
  // ajoute(new NSHtml("beneficiaire", sOperateur)) ;}


NSHtmlReq::~NSHtmlReq()
{
}


void
NSHtmlReq::initTotaux()
{
  int 		total ;
  char 		cData[100] ;
  string 	sData ;

  NSReqRefDocument *pReqDoc = dynamic_cast<NSReqRefDocument *>(pDocBrut) ;

  total = pReqDoc->nbPatTotal ;
  sprintf(cData, "%d", total) ;
  sData = string(cData) ;
  ajoute(new NSHtml("nbPatTotal", sData)) ;

  total = pReqDoc->nbPatResult ;
  sprintf(cData, "%d", total) ;
  sData = string(cData) ;
  ajoute(new NSHtml("nbPatResult", sData)) ;

  total = pReqDoc->nbDocResult ;
  sprintf(cData, "%d", total) ;
  sData = string(cData) ;
  ajoute(new NSHtml("nbDocResult", sData)) ;

  total = pReqDoc->nbPatCritPat ;
  sprintf(cData, "%d", total) ;
  sData = string(cData) ;
  ajoute(new NSHtml("nbPatCritPat", sData)) ;

  total = pReqDoc->nbDocCritPat ;
  sprintf(cData, "%d", total) ;
  sData = string(cData) ;
  ajoute(new NSHtml("nbDocCritPat", sData)) ;

  total = pReqDoc->nbPatCritDoc ;
  sprintf(cData, "%d", total) ;
  sData = string(cData) ;
  ajoute(new NSHtml("nbPatCritDoc", sData)) ;

  total = pReqDoc->nbDocCritDoc ;
  sprintf(cData, "%d", total) ;
  sData = string(cData) ;
  ajoute(new NSHtml("nbDocCritDoc", sData)) ;
}


void
NSHtmlReq::ajouteBloc(NSHtml *ph)
{
  ligneBlocHtml.push_back(new NSBlocHtml(ph, 1)) ;
}

void
NSHtmlReq::ajouteLignes(){
	const int BufLen = 255 ;

	char buffer[BufLen] ;  int  nbTrouves ;
	char dateAffiche[20] ;
	string  sData ;

	NSReqRefDocument *pReqDoc = dynamic_cast<NSReqRefDocument *>(pDocBrut) ;
	if (pReqDoc->bReqModeDoc)  	nbTrouves = pReqDoc->nbDocResult ;
	else
		nbTrouves = pReqDoc->nbPatResult ;
	string sLang = "" ;  if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;	for (int i = 0 ; i < nbTrouves ; i++)	{
  	ligneBlocHtml.vider() ;

		if (pReqDoc->bReqModeDoc)
    {
    	strcpy(buffer, ((pReqDoc->VectDocResultat)[i])->getPatient().c_str()) ;
      ajouteBloc(new NSHtml("TBLNss", string(buffer))) ;

      strcpy(buffer, ((pReqDoc->VectDocResultat)[i])->getDocument().c_str()) ;
      ajouteBloc(new NSHtml("TBLDoc", string(buffer))) ;
      strcpy(buffer, ((pReqDoc->VectPatResultat)[i])->getszNom()) ;
      ajouteBloc(new NSHtml("TBLNom", string(buffer))) ;
      strcpy(buffer, ((pReqDoc->VectPatResultat)[i])->getszPrenom()) ;      ajouteBloc(new NSHtml("TBLPrenom", string(buffer))) ;

      donne_date((pReqDoc->VectDocResultat[i])->GetDateDoc(), dateAffiche, sLang) ;
      sprintf(buffer, "%s du %s", (pReqDoc->VectDocResultat[i])->getDocName().c_str(),
                                            dateAffiche) ;
      ajouteBloc(new NSHtml("TBLExamen", string(buffer))) ;
    }
    else
    {
    	strcpy(buffer, ((pReqDoc->VectPatResultat)[i])->getszNss()) ;
      ajouteBloc(new NSHtml("TBLNss", string(buffer))) ;

      strcpy(buffer, "&nbsp;");
      ajouteBloc(new NSHtml("TBLDoc", string(buffer))) ;
      strcpy(buffer, ((pReqDoc->VectPatResultat)[i])->getszNom()) ;
      ajouteBloc(new NSHtml("TBLNom", string(buffer))) ;
      strcpy(buffer, ((pReqDoc->VectPatResultat)[i])->getszPrenom()) ;      ajouteBloc(new NSHtml("TBLPrenom", string(buffer))) ;

      strcpy(buffer, "&nbsp;");
      ajouteBloc(new NSHtml("TBLExamen", string(buffer))) ;
    }

    table.push_back(new NSBlocHtmlArray(ligneBlocHtml)) ;	}

	bExisteTable = true ;
}

// -----------------------------------------------------------------------------
// Classe NSHtmlDep
//
// On instancie le html correspondant � l'�tat des Dep en cours
// -----------------------------------------------------------------------------

NSHtmlDep::NSHtmlDep(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)          :NSModHtml(typeOp, pDocNoy, pCtx)
{
  string sTitre ;
  string sOperateur   = "" ;
  char   cDateDep[9]  = "" ;
  char   dateDep1[11] = "" ;
  char   dateDep2[11] = "" ;

  NSDepRefDocument *pDepDoc = dynamic_cast<NSDepRefDocument *>(pDocNoy) ;
	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  strcpy(cDateDep, (pDepDoc->pCriteres->sDateAga1).c_str()) ;  donne_date(cDateDep, dateDep1, sLang) ;
  strcpy(cDateDep, (pDepDoc->pCriteres->sDateAga2).c_str()) ;
  donne_date(cDateDep, dateDep2, sLang) ;

  sTitre = string("Liste des d�penses du ") + string(dateDep1) + string(" au ") + string(dateDep2) ;
  if (pDepDoc->pCriteres->bActesPerso)  {
    sOperateur = string(" pour ") + pContexte->getUtilisateur()->donneTitre(pContexte) ;
    sTitre += sOperateur ;
  }

  ajoute(new NSHtml("titre",        sTitre)) ;
  ajoute(new NSHtml("date",         (string(dateDep1) + string(" au ") + string(dateDep2)))) ;
  ajoute(new NSHtml("beneficiaire", sOperateur)) ;
}


NSHtmlDep::~NSHtmlDep(){
}


voidNSHtmlDep::initTotaux()
{
  int 		montant ;
  char 		cData[100] ;
  string 	sData ;

  NSDepRefDocument *pDepDoc = dynamic_cast<NSDepRefDocument *>(pDocBrut) ;
  montant = pDepDoc->pTotaux->paieLoc ;  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pDepDoc->pVar->sigle ;
  ajoute(new NSHtml("totPaieLoc", sData)) ;

  montant = pDepDoc->pTotaux->paieEuro ;  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totPaieEuro", sData)) ;

  montant = pDepDoc->pTotaux->espLoc ;  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pDepDoc->pVar->sigle ;
  ajoute(new NSHtml("totEspLoc", sData)) ;

  montant = pDepDoc->pTotaux->espEuro ;  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totEspEuro", sData)) ;

  montant = pDepDoc->pTotaux->chqLoc ;  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pDepDoc->pVar->sigle ;
  ajoute(new NSHtml("totChqLoc", sData)) ;

  montant = pDepDoc->pTotaux->chqEuro ;  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totChqEuro", sData)) ;

  montant = pDepDoc->pTotaux->virLoc ;  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pDepDoc->pVar->sigle ;
  ajoute(new NSHtml("totVirLoc", sData)) ;

  montant = pDepDoc->pTotaux->virEuro;  sprintf(cData, "%d,%02d ", montant/100, montant%100);
  sData = string(cData) + string("EU");
  ajoute(new NSHtml("totVirEuro", sData));

  montant = pDepDoc->pTotaux->cbLoc ;  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pDepDoc->pVar->sigle ;
  ajoute(new NSHtml("totCbLoc", sData)) ;

  montant = pDepDoc->pTotaux->cbEuro ;  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totCbEuro", sData)) ;
}


void
NSHtmlDep::ajouteBloc(NSHtml *ph)
{
  ligneBlocHtml.push_back(new NSBlocHtml(ph, 1)) ;
}

voidNSHtmlDep::ajouteLignes(){
try
{
	NSDepRefDocument *pDepDoc = dynamic_cast<NSDepRefDocument *>(pDocBrut) ;
	if (!pDepDoc || !(pDepDoc->pDepensArray) || pDepDoc->pDepensArray->empty())  	return ;
	bExisteTable = true ;
}catch (...)
{
	erreur("Exception NSHtmlDep::ajouteLignes.", standardError, 0) ;
}
}
// -----------------------------------------------------------------------------// Classe NSHtmlImp//
// On instancie le html correspondant � l'�tat des impay�s en cours
// -----------------------------------------------------------------------------


NSHtmlImp::NSHtmlImp(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)
          :NSModHtml(typeOp, pDocNoy, pCtx)
{
	string sTitre ;
	string sOperateur = "" ;
  char   cDate1[9]  = "" ;
  char   cDate2[9]  = "" ;
  char   date1[11]  = "" ;
  char   date2[11]  = "" ;
  string sDate, sCode, sExamen, sPrescript, sContexte ;
  string sLibCourtOrga, sLibLongOrga ;
  NSImpRefDocument *pImpDoc = dynamic_cast<NSImpRefDocument *>(pDocNoy) ;

  string sLang = "" ;
  if ((pContexte) && (pContexte->getUtilisateur()))
    sLang = pContexte->getUtilisateur()->donneLang() ;

  strcpy(cDate1, (pImpDoc->pCriteres->sDate1).c_str()) ;
  donne_date(cDate1, date1, sLang) ;

  strcpy(cDate2, (pImpDoc->pCriteres->sDate2).c_str()) ;
  donne_date(cDate2, date2, sLang) ;

  if ((pImpDoc->pCriteres->sDate2) > (pImpDoc->pCriteres->sDate1))
  {
    sDate = string(date1) + string(" au ") + string(date2) ;
  }
  else // cas date1 == date2
  {
    sDate = string(date1) ;
  }

  // on r�cup�re le titre du document
  sTitre = string("Liste des impayes du ") + sDate ;

  if (pImpDoc->pCriteres->bActesPerso)
  {
    sOperateur = string(" pour ") + pContexte->getUtilisateur()->donneTitre(pContexte) ;
    sTitre += sOperateur ;
  }

  if (pImpDoc->pCriteres->bInterruptedProcess)
    sTitre += string(" (r�sultats partiels, processus interrompu en cours de recherche)") ;

  sCode = (pImpDoc->pCriteres->sCodeExamen) + (pImpDoc->pCriteres->sSynExamen) ;
  if (sCode == "")
    sExamen = string("Tous") ;
  else
    pContexte->getDico()->donneLibelle(sLang, &sCode, &sExamen) ;

  sPrescript = pImpDoc->pCriteres->sTitrePrescript ;
  if (sPrescript == "")
    sPrescript = string("Tous") ;

  switch (pImpDoc->pCriteres->iContexte)
  {
    case 0  : sContexte = string("Tous") ;
              break ;
    case 1  : sContexte = string("Non pr�cis�") ;
              break ;
    case 2  : sContexte = string("Externe") ;
              break ;
    case 4  : sContexte = string("Hospitalis�") ;
              break ;
    case 8  : sContexte = string("Ambulatoire") ;
              break ;
  }

  if ((pImpDoc->pCriteres->sCodeOrga) == "")
  {
    sLibCourtOrga = string("Tous") ;
    sLibLongOrga  = string("Tous") ;
  }
  else
  {
    sLibCourtOrga = pImpDoc->pCriteres->sLibCourtOrga ;
		sLibLongOrga  = pImpDoc->pCriteres->sLibLongOrga ;
  }

  ajoute(new NSHtml("titre",        sTitre)) ;
  ajoute(new NSHtml("date",         sDate)) ;
  ajoute(new NSHtml("dateDeb",      string(date1))) ;
  ajoute(new NSHtml("dateFin",      string(date2))) ;
  ajoute(new NSHtml("beneficiaire", sOperateur)) ;
  ajoute(new NSHtml("libExam",      sExamen)) ;
  ajoute(new NSHtml("prescripteur", sPrescript)) ;
	ajoute(new NSHtml("contexte",     sContexte)) ;
  ajoute(new NSHtml("libCourtOrga", sLibCourtOrga)) ;
  ajoute(new NSHtml("libLongOrga",  sLibLongOrga)) ;
}


NSHtmlImp::~NSHtmlImp()
{
}


void
NSHtmlImp::ajouteBloc(NSHtml *ph)
{
  ligneBlocHtml.push_back(new NSBlocHtml(ph, 1)) ;
}


void
NSHtmlImp::ajouteLignes()
{
  int    iSommeDue, iImpaye ;
  string sSommeDue, sImpaye ;
	char 	 cSommeDue[10]  = "" ;
  char	 cImpaye[10]    = "" ;
  char	 cDateExam[9]   = "" ;
  char	 dateExam[11]   = "" ;
	string sData ;

  NSImpRefDocument *pImpDoc = dynamic_cast<NSImpRefDocument *>(pDocBrut) ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

	for (NSImpIter i = pImpDoc->pImpArray->begin() ; i != pImpDoc->pImpArray->end() ; i++)
  {
    ligneBlocHtml.vider() ;

    sData = string((*i)->dateCompt) ;
    strcpy(cDateExam, sData.c_str()) ;
    donne_date(cDateExam, dateExam, sLang) ;
    ajouteBloc(new NSHtml("TBLDateExam", string(dateExam))) ;

    sData = ((*i)->patInfo).sNom ;
    ajouteBloc(new NSHtml("TBLNom", sData)) ;

    sData = ((*i)->patInfo).sPrenom ;    ajouteBloc(new NSHtml("TBLPrenom", sData)) ;

    sData = ((*i)->patInfo).sPersonID ;    ajouteBloc(new NSHtml("TBLCodePat", sData)) ;

    sData = (*i)->sNomPatient ;    ajouteBloc(new NSHtml("TBLNomLong", sData)) ;

    sData = (*i)->sLibExam ;
    ajouteBloc(new NSHtml("TBLLibExam", sData)) ;

    if (!pImpDoc->bEuro)
    {
      iSommeDue = atoi((*i)->sommeDueLoc) ;
      sprintf(cSommeDue, "%d,%02d ", iSommeDue / 100, iSommeDue % 100) ;
      sSommeDue = string(cSommeDue) + pImpDoc->pVar->sigle ;

      iImpaye = atoi((*i)->impayeLoc) ;
      sprintf(cImpaye, "%d,%02d ", iImpaye / 100, iImpaye % 100) ;
      sImpaye = string(cImpaye) + pImpDoc->pVar->sigle ;
    }
    else // on affiche les sommes en Euro
    {
      iSommeDue = atoi((*i)->sommeDueEuro) ;
      sprintf(cSommeDue, "%d,%02d ", iSommeDue / 100, iSommeDue % 100) ;
      sSommeDue = string(cSommeDue) + string("EU") ;

      iImpaye = atoi((*i)->impayeEuro) ;
      sprintf(cImpaye, "%d,%02d ", iImpaye / 100, iImpaye % 100) ;
      sImpaye = string(cImpaye) + string("EU") ;
    }

    ajouteBloc(new NSHtml("TBLSommeDue", sSommeDue)) ;
    ajouteBloc(new NSHtml("TBLImpaye", sImpaye)) ;

		sData = string((*i)->libOrga) ;
    if (sData == "") sData = "&nbsp;" ;
      ajouteBloc(new NSHtml("TBLLibOrga", sData)) ;

    table.push_back(new NSBlocHtmlArray(ligneBlocHtml)) ;
  }

	bExisteTable = true ;
}


// -----------------------------------------------------------------------------
// Classe NSHtmlLac
//
// On instancie le html correspondant � la liste des actes
// -----------------------------------------------------------------------------


NSHtmlLac::NSHtmlLac(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)
          :NSModHtml(typeOp, pDocNoy, pCtx)
{
	string sTitre ;
	string sOperateur = "" ;
  char   cDate1[9]  = "" ;
  char   cDate2[9]  = "" ;
  char   date1[11]  = "" ;
  char	 date2[11]  = "" ;
  string sDate, sCode, sExamen, sPrescript, sImpayes, sContexte ;
  NSListActRefDocument *pActDoc = dynamic_cast<NSListActRefDocument *>(pDocNoy) ;

  string sLang = "" ;
  if ((pContexte) && (pContexte->getUtilisateur()))
    sLang = pContexte->getUtilisateur()->donneLang() ;

  strcpy(cDate1, (pActDoc->pCriteres->sDate1).c_str()) ;
  donne_date(cDate1, date1, sLang) ;

  strcpy(cDate2, (pActDoc->pCriteres->sDate2).c_str()) ;
  donne_date(cDate2, date2, sLang) ;

  if ((pActDoc->pCriteres->sDate2) > (pActDoc->pCriteres->sDate1))
  {
    sDate = string(date1) + string(" au ") + string(date2) ;
  }
  else // cas date1 == date2
  {
    sDate = string(date1) ;
  }

  // on r�cup�re le titre du document
  sTitre = string("Liste des actes du ") + sDate ;

  if (pActDoc->pCriteres->bActesPerso)
  {
    sOperateur = string(" pour ") + pContexte->getUtilisateur()->donneTitre(pContexte) ;
    sTitre += sOperateur ;
  }

  if (pActDoc->pCriteres->bInterruptedProcess)
    sTitre += string(" (r�sultats partiels, processus interrompu en cours de recherche)") ;

  sCode = (pActDoc->pCriteres->sCodeExamen) + (pActDoc->pCriteres->sSynExamen) ;
  if (sCode == "")
    sExamen = string("Tous") ;
  else
    pContexte->getDico()->donneLibelle(sLang, &sCode, &sExamen) ;

  sPrescript = pActDoc->pCriteres->sTitrePrescript ;
  if (sPrescript == "")
    sPrescript = string("Tous") ;

  switch (pActDoc->pCriteres->iImpayes)
  {
    case 0  : sImpayes = string("Tous") ;
              break ;

    case 1  : sImpayes = string("Impayes") ;
              break ;

    case 2  : sImpayes = string("Payes") ;
  }

  switch (pActDoc->pCriteres->iContexte)
  {
    case 0  : sContexte = string("Tous") ;
              break ;
    case 1  : sContexte = string("Non pr�cis�") ;
              break ;
    case 2  : sContexte = string("Externe") ;
              break ;
    case 4  : sContexte = string("Hospitalis�") ;
              break ;
    case 8  : sContexte = string("Ambulatoire") ;
              break ;
  }

  ajoute(new NSHtml("titre",        sTitre)) ;
  ajoute(new NSHtml("date",         sDate)) ;
  ajoute(new NSHtml("dateDeb",      string(date1))) ;
  ajoute(new NSHtml("dateFin",      string(date2))) ;
  ajoute(new NSHtml("beneficiaire", sOperateur)) ;
  ajoute(new NSHtml("libExam",      sExamen)) ;
  ajoute(new NSHtml("prescripteur", sPrescript)) ;
  ajoute(new NSHtml("impayes",      sImpayes)) ;
	ajoute(new NSHtml("contexte",     sContexte)) ;
}


NSHtmlLac::~NSHtmlLac()
{
}


void
NSHtmlLac::ajouteBloc(NSHtml *ph)
{
  ligneBlocHtml.push_back(new NSBlocHtml(ph, 1)) ;
}


void
NSHtmlLac::ajouteLignes()
{
  string sSommeDue, sImpaye ;
  char	 cDateExam[9]   = "" ;
  char	 dateExam[11]   = "" ;
	string sData ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  NSListActRefDocument *pActDoc = dynamic_cast<NSListActRefDocument *>(pDocBrut) ;

  for (NSListActIter i = pActDoc->pActArray->begin() ; i != pActDoc->pActArray->end() ; i++)
  {
    ligneBlocHtml.vider() ;

    sData = string((*i)->dateCompt) ;
    strcpy(cDateExam, sData.c_str()) ;
    donne_date(cDateExam, dateExam, sLang) ;
    ajouteBloc(new NSHtml("TBLDateExam", string(dateExam))) ;

    sData = ((*i)->patInfo).sNom ;
    ajouteBloc(new NSHtml("TBLNom", sData)) ;

    sData = ((*i)->patInfo).sPrenom ;    ajouteBloc(new NSHtml("TBLPrenom", sData)) ;

    sData = ((*i)->patInfo).sPersonID ;    ajouteBloc(new NSHtml("TBLCodePat", sData)) ;

    sData = string((*i)->nomPatient) ;    ajouteBloc(new NSHtml("TBLNomLong", sData)) ;

    sData = string((*i)->libExam) ;
    if (sData == "")
      sData = "&nbsp;" ;
    ajouteBloc(new NSHtml("TBLLibExam", sData)) ;

		sData = string((*i)->actes) ;
    if (sData == "")
      sData = "&nbsp;" ;
    ajouteBloc(new NSHtml("TBLActes", sData)) ;

    table.push_back(new NSBlocHtmlArray(ligneBlocHtml)) ;
  }

	bExisteTable = true ;
}


// -----------------------------------------------------------------------------
// Classe NSHtmlSac
//
// On instancie le html correspondant � la somme des actes
// -----------------------------------------------------------------------------


NSHtmlSac::NSHtmlSac(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)
          :NSModHtml(typeOp, pDocNoy, pCtx)
{
	string sTitre ;
	string sOperateur = "" ;
  char   cDate1[9]  = "" ;
  char   cDate2[9]  = "" ;
  char   date1[11]  = "" ;
  char   date2[11]  = "" ;
  string sDate, sCode, sExamen, sPrescript, sImpayes, sContexte ;
  NSSomActRefDocument *pActDoc = dynamic_cast<NSSomActRefDocument *>(pDocNoy) ;

  string sLang = "" ;
  if ((pContexte) && (pContexte->getUtilisateur()))
    sLang = pContexte->getUtilisateur()->donneLang() ;

  strcpy(cDate1, (pActDoc->pCriteres->sDate1).c_str()) ;
  donne_date(cDate1, date1, sLang) ;

  strcpy(cDate2, (pActDoc->pCriteres->sDate2).c_str()) ;
  donne_date(cDate2, date2, sLang) ;

  if ((pActDoc->pCriteres->sDate2) > (pActDoc->pCriteres->sDate1))
  {
    sDate = string(date1) + string(" au ") + string(date2) ;
  }
  else // cas date1 == date2
  {
    sDate = string(date1) ;
  }

  // on r�cup�re le titre du document
  sTitre = string("Somme des actes du ") + sDate ;

  if (pActDoc->pCriteres->bActesPerso)
  {
    sOperateur = string(" pour ") + pContexte->getUtilisateur()->donneTitre(pContexte) ;
    sTitre += sOperateur ;
  }

  if (pActDoc->pCriteres->bInterruptedProcess)
    sTitre += string(" (r�sultats partiels, processus interrompu en cours de recherche)") ;

  sCode = (pActDoc->pCriteres->sCodeExamen) + (pActDoc->pCriteres->sSynExamen) ;
  if (sCode == "")
    sExamen = string("Tous") ;
  else
    pContexte->getDico()->donneLibelle(sLang, &sCode, &sExamen) ;

  sPrescript = pActDoc->pCriteres->sTitrePrescript ;
  if (sPrescript == "")
    sPrescript = string("Tous") ;

  switch (pActDoc->pCriteres->iImpayes)
  {
    case 0  : sImpayes = string("Tous") ;
              break ;

    case 1  : sImpayes = string("Impayes") ;
              break ;

    case 2  : sImpayes = string("Payes") ;
  }

  switch (pActDoc->pCriteres->iContexte)
  {
    case 0  : sContexte = string("Tous") ;
              break ;
    case 1  : sContexte = string("Non pr�cis�") ;
              break ;
    case 2  : sContexte = string("Externe") ;
              break ;
    case 4  : sContexte = string("Hospitalis�") ;
              break ;
    case 8  : sContexte = string("Ambulatoire") ;
              break ;
  }

  ajoute(new NSHtml("titre",        sTitre)) ;
  ajoute(new NSHtml("date",         sDate)) ;
  ajoute(new NSHtml("dateDeb",      string(date1))) ;
  ajoute(new NSHtml("dateFin",      string(date2))) ;
  ajoute(new NSHtml("beneficiaire", sOperateur)) ;
  ajoute(new NSHtml("libExam",      sExamen)) ;
  ajoute(new NSHtml("prescripteur", sPrescript)) ;
  ajoute(new NSHtml("impayes",      sImpayes)) ;
	ajoute(new NSHtml("contexte",     sContexte)) ;
}


NSHtmlSac::~NSHtmlSac()
{
}


void
NSHtmlSac::initTotaux()
{
  int 		montant ;
  char 		cData[100] ;
  string 	sData ;

  NSSomActRefDocument *pActDoc = dynamic_cast<NSSomActRefDocument *>(pDocBrut) ;

  montant = pActDoc->totaux.totalLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pActDoc->pVar->sigle ;
  ajoute(new NSHtml("totalLoc", sData)) ;

  montant = pActDoc->totaux.totalEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totalEuro", sData)) ;

  montant = pActDoc->totaux.depassLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pActDoc->pVar->sigle ;
  ajoute(new NSHtml("depassLoc", sData)) ;

  montant = pActDoc->totaux.depassEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("depassEuro", sData)) ;

  montant = pActDoc->totaux.paieLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pActDoc->pVar->sigle ;
  ajoute(new NSHtml("paieLoc", sData)) ;

  montant = pActDoc->totaux.paieEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("paieEuro", sData)) ;

  montant = pActDoc->totaux.espLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pActDoc->pVar->sigle ;
  ajoute(new NSHtml("espLoc", sData)) ;

  montant = pActDoc->totaux.espEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("espEuro", sData)) ;

  montant = pActDoc->totaux.chqLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pActDoc->pVar->sigle ;
  ajoute(new NSHtml("chqLoc", sData)) ;

  montant = pActDoc->totaux.chqEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("chqEuro", sData)) ;

  montant = pActDoc->totaux.virLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pActDoc->pVar->sigle ;
  ajoute(new NSHtml("virLoc", sData)) ;

  montant = pActDoc->totaux.virEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("virEuro", sData)) ;

  montant = pActDoc->totaux.cbLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pActDoc->pVar->sigle ;
  ajoute(new NSHtml("cbLoc", sData)) ;

  montant = pActDoc->totaux.cbEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("cbEuro", sData)) ;

  montant = pActDoc->totaux.impayeLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pActDoc->pVar->sigle ;
  ajoute(new NSHtml("impayeLoc", sData)) ;

  montant = pActDoc->totaux.impayeEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("impayeEuro", sData)) ;

  montant = pActDoc->totaux.impTPLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pActDoc->pVar->sigle ;
  ajoute(new NSHtml("impTPLoc", sData)) ;

  montant = pActDoc->totaux.impTPEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("impTPEuro", sData)) ;

  montant = pActDoc->totaux.impAutreLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pActDoc->pVar->sigle ;
  ajoute(new NSHtml("impAutreLoc", sData)) ;

  montant = pActDoc->totaux.impAutreEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("impAutreEuro", sData)) ;
}


void
NSHtmlSac::ajouteBloc(NSHtml *ph)
{
  ligneBlocHtml.push_back(new NSBlocHtml(ph, 1)) ;
}


void
NSHtmlSac::ajouteLignes()
{
  string sData ;
  string sCodeExam ;
  char   cNbExam[10] ;
  char   buffer[255] ;
  char   cCodeExam[80] ;
  int    occur ;

  NSSomActRefDocument *pActDoc = dynamic_cast<NSSomActRefDocument *>(pDocBrut) ;

  string sLang = "" ;
  if ((pContexte) && (pContexte->getUtilisateur()))
    sLang = pContexte->getUtilisateur()->donneLang() ;

  for (NSExamIter i = pActDoc->pExamArray->begin() ; i != pActDoc->pExamArray->end() ; i++)
  {
    ligneBlocHtml.vider() ;

    sCodeExam = string((*i)->sCodeExam) ;
    pContexte->getDico()->donneLibelle(sLang, &sCodeExam, &sData) ;
    if (sData == "")
      sData = "&nbsp;" ;
    ajouteBloc(new NSHtml("TBLLibExam", sData)) ;

    itoa((*i)->nbExam, cNbExam, 10) ;
		sData = string(cNbExam) ;
    ajouteBloc(new NSHtml("TBLNbExam", sData)) ;

    strcpy(buffer, "") ;

    for (NSKCodeIter j = (*i)->aKCodeArray.begin() ; j != (*i)->aKCodeArray.end() ; j++)
    {
      occur = (*j)->occur * 100 ;
      if ((occur % 100) == 0)
        sprintf(cCodeExam, " %s(%d)", ((*j)->sKCode).c_str(), occur / 100) ;
      else
        sprintf(cCodeExam, " %s(%d,%02d)", ((*j)->sKCode).c_str(), occur / 100, occur % 100) ;

      strcat(buffer, cCodeExam) ;
    }
    sData = string(buffer) ;
    ajouteBloc(new NSHtml("TBLKCodes", sData)) ;

    table.push_back(new NSBlocHtmlArray(ligneBlocHtml)) ;
  }

  bExisteTable = true ;
}


// -----------------------------------------------------------------------------
// Classe NSHtmlSen
//
// On instancie le html correspondant � la somme des encaissements
// -----------------------------------------------------------------------------
NSHtmlSen::NSHtmlSen(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)          :NSModHtml(typeOp, pDocNoy, pCtx)
{
  string sTitre ;
  string sOperateur = "" ;
  char   cDate1[9]  = "" ;
  char   cDate2[9]  = "" ;
  char   date1[11]  = "" ;
  char	 date2[11]  = "" ;
  string sDate ;
  string sLibCourtOrga, sLibLongOrga ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  NSSomEncaissRefDocument *pEncaissDoc = dynamic_cast<NSSomEncaissRefDocument *>(pDocNoy) ;

  strcpy(cDate1, (pEncaissDoc->pCriteres->sDate1).c_str()) ;
  donne_date(cDate1, date1, sLang) ;

  strcpy(cDate2, (pEncaissDoc->pCriteres->sDate2).c_str()) ;
  donne_date(cDate2, date2, sLang) ;

  if ((pEncaissDoc->pCriteres->sDate2) > (pEncaissDoc->pCriteres->sDate1))
  {
    sDate = string(date1) + string(" au ") + string(date2) ;
  }
  else // cas date1 == date2
  {
    sDate = string(date1) ;
  }

  // on r�cup�re le titre du document
  sTitre = string("Somme des encaissements du ") + sDate ;

  if (pEncaissDoc->pCriteres->bActesPerso)
  {
    sOperateur = string(" pour ") + pContexte->getUtilisateur()->donneTitre(pContexte) ;
   	sTitre += sOperateur ;
  }

  if (pEncaissDoc->pCriteres->bInterruptedProcess)
    sTitre += string(" (r�sultats partiels, processus interrompu en cours de recherche)") ;

  sLibCourtOrga = pEncaissDoc->pCriteres->sLibCourtOrga ;
  sLibLongOrga  = pEncaissDoc->pCriteres->sLibLongOrga ;

  ajoute(new NSHtml("titre",        sTitre)) ;
  ajoute(new NSHtml("date",         sDate)) ;
  ajoute(new NSHtml("dateDeb",      string(date1))) ;
  ajoute(new NSHtml("dateFin",      string(date2))) ;
  ajoute(new NSHtml("beneficiaire", sOperateur)) ;
  ajoute(new NSHtml("libCourtOrga", sLibCourtOrga)) ;
  ajoute(new NSHtml("libLongOrga",  sLibLongOrga)) ;
}


NSHtmlSen::~NSHtmlSen()
{
}


void
NSHtmlSen::initTotaux()
{
  int 		montant ;
  char 		cData[100] ;
  string 	sData ;

  NSSomEncaissRefDocument *pEncaissDoc = dynamic_cast<NSSomEncaissRefDocument *>(pDocBrut) ;

  montant = pEncaissDoc->pTotaux->paieLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pEncaissDoc->pVar->sigle ;
  ajoute(new NSHtml("totPaieLoc", sData)) ;

  montant = pEncaissDoc->pTotaux->paieEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totPaieEuro", sData)) ;

  montant = pEncaissDoc->pTotaux->espLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pEncaissDoc->pVar->sigle ;
  ajoute(new NSHtml("totEspLoc", sData)) ;

  montant = pEncaissDoc->pTotaux->espEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totEspEuro", sData)) ;

	montant = pEncaissDoc->pTotaux->chqLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pEncaissDoc->pVar->sigle ;
  ajoute(new NSHtml("totChqLoc", sData)) ;

  montant = pEncaissDoc->pTotaux->chqEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totChqEuro", sData)) ;

  montant = pEncaissDoc->pTotaux->virLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pEncaissDoc->pVar->sigle ;
  ajoute(new NSHtml("totVirLoc", sData)) ;

  montant = pEncaissDoc->pTotaux->virEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totVirEuro", sData)) ;

  montant = pEncaissDoc->pTotaux->cbLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pEncaissDoc->pVar->sigle ;
  ajoute(new NSHtml("totCbLoc", sData)) ;

  montant = pEncaissDoc->pTotaux->cbEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("totCbEuro", sData)) ;

  montant = pEncaissDoc->pPartiels->paieLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pEncaissDoc->pVar->sigle ;
  ajoute(new NSHtml("parPaieLoc", sData)) ;

  montant = pEncaissDoc->pPartiels->paieEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("parPaieEuro", sData)) ;

  montant = pEncaissDoc->pPartiels->espLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pEncaissDoc->pVar->sigle ;
  ajoute(new NSHtml("parEspLoc", sData)) ;

  montant = pEncaissDoc->pPartiels->espEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("parEspEuro", sData)) ;

	montant = pEncaissDoc->pPartiels->chqLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pEncaissDoc->pVar->sigle ;
  ajoute(new NSHtml("parChqLoc", sData)) ;

  montant = pEncaissDoc->pPartiels->chqEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("parChqEuro", sData)) ;

  montant = pEncaissDoc->pPartiels->virLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pEncaissDoc->pVar->sigle ;
  ajoute(new NSHtml("parVirLoc", sData)) ;

  montant = pEncaissDoc->pPartiels->virEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("parVirEuro", sData)) ;

  montant = pEncaissDoc->pPartiels->cbLoc ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + pEncaissDoc->pVar->sigle ;
  ajoute(new NSHtml("parCbLoc", sData)) ;

  montant = pEncaissDoc->pPartiels->cbEuro ;
  sprintf(cData, "%d,%02d ", montant / 100, montant % 100) ;
  sData = string(cData) + string("EU") ;
  ajoute(new NSHtml("parCbEuro", sData)) ;
}


// -----------------------------------------------------------------------------
//
// Classe NSHtmlPubli//
// -----------------------------------------------------------------------------NSHtmlPubli::NSHtmlPubli(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)            :NSModHtml(typeOp, pDocNoy, pCtx)
{
  char cDate1[9]   = "" ;
  char cDate2[9]   = "" ;
  char date1[11]   = "" ;
  char date2[11]   = "" ;
  char cTitre[255] = "" ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  NSPubliRefDocument *pPBDoc = dynamic_cast<NSPubliRefDocument *>(pDocBrut) ;

  // Initialisation des donn�es statiques
  if (string("ZPCVC") == pPBDoc->pDocInfo->getType())
  {
    string *psDate1 = static_cast<string *>((*(pPBDoc->pVoidArray))[0]) ;
    string *psDate2 = static_cast<string *>((*(pPBDoc->pVoidArray))[1]) ;

    strcpy(cDate1, (*psDate1).c_str()) ;
    strcpy(cDate2, (*psDate2).c_str()) ;
    donne_date(cDate1, date1, sLang) ;
    donne_date(cDate2, date2, sLang) ;
    sprintf(cTitre, "Liste des patients � reconvoquer entre le %s et le %s.", date1, date2) ;

    ajoute(new NSHtml("titre", string(cTitre))) ;
    ajoute(new NSHtml("date1", string(date1))) ;
    ajoute(new NSHtml("date2", string(date2))) ;
  }
}


NSHtmlPubli::~NSHtmlPubli()
{
}


void
NSHtmlPubli::ajouteBloc(NSHtml *ph)
{
  ligneBlocHtml.push_back(new NSBlocHtml(ph, 1)) ;
}


void
NSHtmlPubli::ajouteLignes()
{
  string sAdr = "";
  char   cDateConvoc[11]  = "" ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  NSPubliRefDocument *pPBDoc = dynamic_cast<NSPubliRefDocument *>(pDocBrut) ;

  if (string("ZPCVC") == pPBDoc->pDocInfo->getType())
  {
    NSPersonArray *pPatArray = static_cast<NSPersonArray *>((*(pPBDoc->pVoidArray))[2]) ;
    if (NULL == pPatArray)
    	return ;

    for (NSPersonIter i = pPatArray->begin() ; pPatArray->end() != i ; i++)
    {
      ligneBlocHtml.vider() ;

      ajouteBloc(new NSHtml("TBLNomLong", (*i)->getNomLong())) ;

/*
      if ((*i)->initGraphs())
      {
        if ((*i)->sChez != "")
            sAdr = (*i)->sChez + string("\r\n");

        sAdr += (*i)->pGraphAdr->trouveLibLongAdr();
      }
*/

      ajouteBloc(new NSHtml("TBLAdresse", (*i)->sMainAdr)) ;

      string sDateNau = (*i)->getConvoc() ;
      donne_date((char*) sDateNau.c_str(), cDateConvoc, sLang) ;
      ajouteBloc(new NSHtml("TBLDateConvoc", string(cDateConvoc))) ;

      table.push_back(new NSBlocHtmlArray(ligneBlocHtml)) ;
    }
  }

  bExisteTable = true ;
}


// -----------------------------------------------------------------------------
//
// Classe NSHtmlCR
//
// -----------------------------------------------------------------------------

NSHtmlCR::NSHtmlCR(OperationType typeOp, NSNoyauDocument *pDocNoy, NSContexte *pCtx, string sDest)
         :NSModHtml(typeOp, pDocNoy, pCtx)
{
	string sTitre     = string("") ;
	string sCreateur  = string("") ;
	string sDate      = string("") ;
	string sSignature = string("") ;

  NSHtml       *pHtmlCR = new NSHtml(tCR) ;
  NSCRDocument *pCRDoc  = dynamic_cast<NSCRDocument *>(pDocNoy) ;

  source = string("") ;
  cc = 0 ;

  // On r�cup�re le nom de fichier associ� et on le transforme en html
  if (!lireCR(pHtmlCR, pCRDoc->sFichDecod))
    MessageBox(0, "Pb lecture du compte-rendu", 0, MB_OK) ;

  // on r�cup�re le titre du document
  sTitre = string(pCRDoc->GetTitle()) ;

  // recherche de l'operateur
	string sNss = pCRDoc->pDocInfo->getAuthor() ;
  if (string("") == sNss)
		sNss = pCRDoc->pDocInfo->getCreator() ;
  if (string("") != sNss)
  {
		NSPersonInfo* pUtil = pContexte->getPersonArray()->getPerson(sNss, pidsUtilisat) ;
  	if (NULL != pUtil)
			sSignature = pUtil->sCivilite ;
	}

  // on prend la date du document
  sDate = pCRDoc->GetDateDoc() ;

  ajoute(new NSHtml(tTitle, sTitre)) ;
  ajoute(new NSHtml(tOperateur, sCreateur)) ;
  ajoute(new NSHtml(tDate, sDate)) ;
  ajoute(new NSHtml(tDest, sDest)) ;
  ajoute(pHtmlCR) ;
  ajoute(new NSHtml(tSignature, sSignature)) ;

	if (pHtmlCR)
    delete pHtmlCR ;
}

NSHtmlCR::~NSHtmlCR()
{
}

HtmlTypes
NSHtmlCR::typeHtml(char cc)
{
  HtmlTypes typeRetour ;

  switch (cc)
  {
    case 'B'  : typeRetour = tIndent ;
                break ;

    case 'C'  : typeRetour = tCR ;
                break ;

    case '1'  : typeRetour = tTitre1 ;
                break ;

    case '2'  : typeRetour = tTitre2 ;
                break ;

    case '3'  : typeRetour = tTitre3 ;
                break ;

    case '4'  : typeRetour = tTitre4 ;
                break ;

    case '5'  : typeRetour = tTitre5 ;
                break ;

    case '6'  : typeRetour = tTitre6 ;
                break ;

    case '7'  : typeRetour = tTitre7 ;                break ;

    case '8'  : typeRetour = tTitre8 ;
                break ;

    case '9'  : typeRetour = tTitre9 ;
                break ;

    case 'T'  : typeRetour = tTexte ;
                break ;

    case 'P'  : typeRetour = tPara ;
                break ;

    case 'G'  : typeRetour = tGras ;
                break ;

    case 'S'  : typeRetour = tSouligne ;
                break ;

    case 'I'  : typeRetour = tItalic ;
                break ;

    default   : typeRetour = tUndefined ;
  }
  return typeRetour ;
}

string
NSHtmlCR::lireTexte()
{
  string texte("") ;

  while ((cc < strlen(source.c_str())) && (source[cc] != 27) && (source[cc] != 28))
  {
    texte += source[cc] ;
    cc++ ;
  }
  return texte ;
}

bool
NSHtmlCR::lireFils(NSHtml *pere, HtmlTypes typeDebut, string sChemin)
{
  NSHtml    *fils, *petitFils ;
  string    texte ;
  bool      bOk       = true ;
  bool      bEstPere  = false ;
  HtmlTypes typeNouv, typeFin = tHtml ;

  fils = new NSHtml(typeDebut) ;
  fils->sPath  = sChemin ;

  while ((bOk) && (typeFin != typeDebut))
  {
        if (cc < strlen(source.c_str()))
        {
            switch(source[cc])
            {
                case 27 :
                    cc++ ;
                    if (cc >= strlen(source.c_str())) // on ne peut pas lire le type
                    {
                        bOk = false ;
                        delete fils ;
                        break ;
                    }
                    typeNouv = typeHtml(source[cc++]) ;
                    bOk = lireFils(fils, typeNouv, sChemin) ;
                    bEstPere = true ;
                    break ;

                case 28 :
                    cc++ ;
                    if (cc >= strlen(source.c_str()))
                    {
                        bOk = false ;
                        delete fils ;
                        break ;
                    }
                    typeFin = typeHtml(source[cc++]) ;
                    if (typeFin == typeDebut)
                        pere->filsArray.push_back(new NSHtml(*fils)) ;
                    else
                        bOk = false ;
                    delete fils ;
                    break ;

                default :
                    texte = string("") ;
                    texte = lireTexte() ;

                    if (typeDebut != tIndent)
                    {
                        if (bEstPere)
                        {
                            petitFils         = new NSHtml(typeDebut) ;
                            petitFils->sTexte = texteHtml(texte) ;
                            petitFils->sPath  = sChemin ;
                            fils->filsArray.push_back(petitFils) ;
                        }
                        else
                            fils->sTexte = texteHtml(texte) ;
                    }
            }	// fin du switch(source[cc])
        }
        else // on ne peut pas lire le fils
        {
            bOk = false ;
            delete fils ;
        }
    }
    return (bOk) ;
}


bool
NSHtmlCR::lireCR(NSHtml *pCR, string sFichier)
{
  ifstream  inFile ;
  inFile.open(sFichier.c_str()) ;
  if (!inFile)
    return false ;

  string line ;
  while (!inFile.eof())
  {
    getline(inFile,line) ;
    if (line != "")
      source += line + "\n" ;
  }
  inFile.close() ;

  HtmlTypes typeFils ;
  bool bOk = true ;
  while ((cc < strlen(source.c_str())) && (bOk))
  {
    string sChemin = "" ;

    // lecture jusqu'au prochain marqueur ou fin de fichier
    while ((cc < strlen(source.c_str())) && (source[cc] != 27) && (source[cc] != '|'))
      cc++ ;

    if (source[cc] == '|')
    {
      cc++ ;
      size_t iDeb = cc ;
      while ((cc < strlen(source.c_str())) && (source[cc] != 27) && (source[cc] != '|'))
        cc++ ;

      if (source[cc] == '|')
      {
        sChemin = string(source, iDeb, cc - iDeb) ;
        size_t iCrochet1 = sChemin.find('[') ;
        if (iCrochet1 == NPOS)
          sChemin = "" ;
        else
        {
          size_t iCrochet2 = sChemin.find(']') ;
          if (iCrochet2 == NPOS)
            sChemin = "" ;
          else
          {
            sChemin = string(sChemin, iCrochet1 + 1, iCrochet2 - iCrochet1 - 1) ;
            // modif RS du 05/04/04 : on enl�ve la racine pour plus de g�n�ricit� dans les templates
            size_t iFirst = sChemin.find('/');
            if (iFirst == NPOS)
              sChemin = "/";
            else
              sChemin = string(sChemin, iFirst+1, strlen(sChemin.c_str())-iFirst-1);
          }
        }
      }
    }

    // lecture jusqu'au prochain marqueur ou fin de fichier
    while ((cc < strlen(source.c_str())) && (source[cc] != 27))
      cc++ ;

    if (cc < strlen(source.c_str()))
      cc++ ;						// lecture du char 27
    else
      break ;

    // recuperation du type (debut)
    if (cc < strlen(source.c_str()))
    {
      typeFils  = typeHtml(source[cc++]) ;
      bOk       = lireFils(pCR, typeFils, sChemin) ;
    }
  }
  return (bOk) ;
}

// -----------------------------------------------------------------------------
//
// Classe NSHtmlTXT
//
// -----------------------------------------------------------------------------

NSHtmlTXT::NSHtmlTXT(OperationType typeOp, NSNoyauDocument *pDocNoy, const char *fichier, NSContexte *pCtx, string sDest)
          :NSModHtml(typeOp, pDocNoy, pCtx)
{
try
{
	string sTitre     = string("") ;
	string sCreateur  = string("") ;
	string sDate      = string("") ;
	string sSignature = string("") ;

	if (pDocNoy)
	{
		NSSimpleTxtDocument* pTxtDoc = dynamic_cast<NSSimpleTxtDocument *>(pDocNoy) ;
    if (!pTxtDoc)
    	return ;

		// on r�cup�re le titre du document
		sTitre = string(pDocNoy->GetTitle()) ;

		// recherche de l'operateur
		string sNss = pTxtDoc->pDocInfo->getAuthor() ;
		if (string("") == sNss)
    	sNss = pTxtDoc->pDocInfo->getCreator() ;
    if (string("") != sNss)
    {
			NSPersonInfo* pUtil = pContexte->getPersonArray()->getPerson(sNss, pidsUtilisat) ;
    	if (NULL != pUtil)
				sSignature = pUtil->sCivilite ;
		}

		// on prend la date du document
		sDate = pTxtDoc->GetDateDoc() ;

		ajoute(new NSHtml(tTitle,       sTitre)) ;
		ajoute(new NSHtml(tDate,        sDate)) ;
		ajoute(new NSHtml(tDest,        sDest)) ;
		ajoute(new NSHtml(tSignature,   sSignature)) ;
		ajoute(new NSHtml(tTXT,         StringTexteHtml(fichier, false))) ;
	}
	// En cas d'importation, il est normal de ne pas avoir de pDocNoy
	else if (typeOp == toImporter)
	{
		ajoute(new NSHtml(tTXT,         StringTexteHtml(fichier, true))) ;
	}
}
catch (...)
{
	erreur("Exception NSHtmlTXT ctor", standardError, 0) ;
}
}

NSHtmlTXT::~NSHtmlTXT()
{
}

string
NSHtmlTXT::StringTexteHtml(const char* fichier, bool bImport)
{
  ifstream inFile ;
  string   line;
  string   sText = "" ;

  inFile.open(fichier) ;  if (!inFile)
  {
  	char msg[255] ;
    sprintf(msg, "Erreur d'ouverture du fichier %s", fichier) ;
    erreur(msg, standardError, 0) ;
    return "" ;
  }

  while (!inFile.eof())  {
  	getline(inFile,line) ;
    if (line != "")
    	sText += line + "\n" ;
  }

  inFile.close() ;

  RemplaceDynamicTags(sText);

  return texteHtml(sText) ;
}

void
NSHtmlTXT::RemplaceTag(string& sTexte, string sTag, string sValeur)
{
	size_t pos = sTexte.find(sTag) ;

	while (pos != string::npos)
	{
		// on remplace le texte dans la string et on r�it�re
		sTexte.replace(pos, strlen(sTag.c_str()), sValeur.c_str()) ;
		pos = sTexte.find(sTag, pos + strlen(sValeur.c_str())) ;
	}
}

void
NSHtmlTXT::RemplaceDynamicTags(string& sTexte)
{
	char dateJ[9], message[11] ;

	string sLang = "" ;
  if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

	// on convertit les tags internes et on remplace le texte
	pContexte->getPatient()->fabriqueNomLong() ;
	RemplaceTag(sTexte, "[nomPatient]", pContexte->getPatient()->getNomLong()) ;
	donne_date_duJour(dateJ) ;	donne_date(dateJ, message, sLang) ;
	RemplaceTag(sTexte, "[dateJour]", message) ;
}

// -----------------------------------------------------------------------------
//
// M�thodes de ConvertRTFDialog
//
// -----------------------------------------------------------------------------


// DEFINE_RESPONSE_TABLE1(ConvertRTFDialog, TDialog)
// 	 EV_COMMAND(IDOK,	CmOk),
// END_RESPONSE_TABLE ;


ConvertRTFDialog::ConvertRTFDialog(TWindow *pere, const char *fichier)
                 :TDialog(pere, "IDD_CONVRTF")
{
try
{
  pRichEdit = new TRichEdit(this, IDC_RICHECVT, "", 12, 12, 450, 220) ;
  strcpy(fichierRTF,fichier) ;
}
catch (...)
{
	erreur("Exception ConvertRTFDialog ctor", standardError, 0) ;
}
}

ConvertRTFDialog::~ConvertRTFDialog()
{
  delete pRichEdit ;
}

void
ConvertRTFDialog::SetupWindow()
{
  TDialog::SetupWindow() ;
  pRichEdit->ReplaceWith(fichierRTF) ;
}

// -----------------------------------------------------------------------------
//
// Classe NSHtmlRTF
//
// -----------------------------------------------------------------------------

NSHtmlRTF::NSHtmlRTF(OperationType typeOp, NSNoyauDocument *pDocNoy, const char *fichier, NSContexte *pCtx, string sDest)
          :NSModHtml(typeOp, pDocNoy, pCtx), pDialog(0)
{
try
{
  NSTtxDocument *pTtxDoc ;

  string sTitre     = string("") ;
	string sCreateur  = string("") ;
	string sDate      = string("") ;
	string sSignature = string("") ;

  if (pDocNoy)
  {
    pTtxDoc = dynamic_cast<NSTtxDocument *>(pDocNoy) ;
		if (!pTtxDoc)
			return ;

    // on r�cup�re le titre du document
    sTitre = string(pDocNoy->GetTitle()) ;

    // recherche de l'operateur
    string sNss = pTtxDoc->pDocInfo->getAuthor() ;
		if (string("") == sNss)
			sNss = pTtxDoc->pDocInfo->getCreator() ;

    if (string("") != sNss)
    {
			NSPersonInfo* pUtil = pContexte->getPersonArray()->getPerson(sNss, pidsUtilisat) ;
    	if (NULL != pUtil)
				sSignature = pUtil->sCivilite ;
		}

    // on prend la date du document
    sDate = pTtxDoc->GetDateDoc() ;

    ajoute(new NSHtml(tTitle,     sTitre)) ;
    ajoute(new NSHtml(tDate,      sDate)) ;
    ajoute(new NSHtml(tDest,      sDest)) ;
    ajoute(new NSHtml(tSignature, sSignature)) ;
  }

  // En cas d'importation, il est normal de ne pas avoir de pDocNoy
  else if (typeOp == toImporter)
  {
    pDialog = new ConvertRTFDialog(pContexte->GetMainWindow(), fichier) ;
    alignPrec = -1 ;
    return ;
  }
  else
  {
    erreur("Le document texte ne peut pas �tre converti en html", warningError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    // on initialise le dialogue de conversion pour �viter les bugs
    pDialog = new ConvertRTFDialog(pContexte->GetMainWindow(), fichier) ;
    alignPrec = -1 ;
    return ;
  }

	if (string("ZTRTF") == pTtxDoc->pDocInfo->getType())
  {
    // on initialise le dialogue de conversion et l'alignement des paragraphes
    pDialog = new ConvertRTFDialog(pContexte->GetMainWindow(), fichier) ;
    alignPrec = -1 ;
  }
	else if (string("ZTHTM") == pTtxDoc->pDocInfo->getType())
  {
    // on met � jour une variable de NSDocNoy
    // pour pouvoir cr�er le fichier dans NSModHtml::genereModele
    pTtxDoc->sNomFichierHtml = string(fichier) ;
    if (!AnalyseXML(fichier))
    {
      erreur("Le document Word ne peut �tre converti en html.", warningError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      return ;
    }
  }
}
catch (...)
{
	erreur("Exception NSHtmlRTF ctor", standardError, 0) ;
}
}

NSHtmlRTF::~NSHtmlRTF()
{
  if (pDialog)
    delete pDialog ;
}

bool
NSHtmlRTF::AnalyseXML(string sNomFichierXML)
{
try
{
	if (sNomFichierXML == "")
  	return false ;

  ifstream 	inFile ;
  inFile.open(sNomFichierXML.c_str()) ;
	if (!inFile)
  {
    char msg[255] ;
    sprintf(msg, "Impossible d'ouvrir le fichier : %s", sNomFichierXML.c_str()) ;
    erreur(msg, standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return false ;
  }

  string   	line ;
  string    sFichierXML = "" ;
  string    sxHtmlXML, sxHeadXML, sxBodyXML ;
  string    sHeadXML, sBodyXML ;
  size_t    pos1, pos2 ;

  while (!inFile.eof())
  {
    getline(inFile, line) ;
    if (line != "")
      sFichierXML += line + "\n" ;
  }
  inFile.close() ;

  // recherche du param html (xhtmlXML)
  pos1 = sFichierXML.find("<html") ;
  if (pos1 == string::npos)
    pos1 = sFichierXML.find("<HTML") ;

  if (pos1 != string::npos)
  {
    pos2 = sFichierXML.find(">", pos1) ;
    if (pos2 != string::npos)
    {
      sxHtmlXML = string(sFichierXML, pos1 + 5, pos2 - (pos1 + 5)) ;
    }
    else
      return false ;
  }
  else
    return false ;

  ajoute(new NSHtml("xhtmlXML", sxHtmlXML)) ;

  // recherche du param head (xheadXML)
  pos1 = sFichierXML.find("<head") ;
  if (pos1 == string::npos)
    pos1 = sFichierXML.find("<HEAD") ;

  if (pos1 != string::npos)
  {
    pos2 = sFichierXML.find(">", pos1) ;
    if (pos2 != string::npos)
    {
      sxHeadXML = string(sFichierXML, pos1 + 5, pos2 - (pos1 + 5)) ;
      // recherche du head html (headXML)
      pos1 = pos2 + 1 ;
      pos2 = sFichierXML.find("</head>", pos1) ;
      if (pos2 == string::npos)
        pos2 = sFichierXML.find("</HEAD>", pos1) ;

      if (pos2 != string::npos)
        sHeadXML = string(sFichierXML, pos1, pos2 - pos1) ;
      else
        return false ;
    }
    else
      return false ;
  }
  else
  {
    sxHeadXML = "" ;
    sHeadXML  = "" ;
  }

  ajoute(new NSHtml("xheadXML", sxHeadXML)) ;
  ajoute(new NSHtml("headXML", sHeadXML)) ;

  // recherche du param body (xbodyXML)
  pos1 = sFichierXML.find("<body") ;
  if (pos1 == string::npos)
    pos1 = sFichierXML.find("<BODY") ;

  if (pos1 != string::npos)
  {
    pos2 = sFichierXML.find(">", pos1) ;
    if (pos2 != string::npos)
    {
      sxBodyXML = string(sFichierXML, pos1 + 5, pos2 - (pos1 + 5)) ;
      // recherche du head html (headXML)
      pos1 = pos2 + 1 ;
      pos2 = sFichierXML.find("</body>", pos1) ;
      if (pos2 == string::npos)
        pos2 = sFichierXML.find("</BODY>", pos1) ;

      if (pos2 != string::npos)
        sBodyXML = string(sFichierXML, pos1, pos2 - pos1) ;
      else
        return false ;
    }
    else
      return false ;
  }
  else
  {
    sxBodyXML = "" ;
    sBodyXML  = "" ;
  }

  ajoute(new NSHtml("xbodyXML", sxBodyXML)) ;
  ajoute(new NSHtml("bodyXML", sBodyXML)) ;
  return true ;
}
catch (...)
{
	erreur("Exception NSHtmlRTF::AnalyseXML", standardError, 0) ;
  return false ;
}
}

void
NSHtmlRTF::RemplaceTagRTF(char far *texte, string sTag, string sValeur)
{
  string 	sTexte = string(texte) ;
  size_t  pos ;

  pos = sTexte.find(sTag) ;

  while (pos != string::npos)
  {
    // on remplace le texte directement dans le controle
    pDialog->pRichEdit->DeleteSubText(pos, pos + strlen(sTag.c_str())) ;
    pDialog->pRichEdit->Insert(sValeur.c_str()) ;
    // on effectue la meme modif dans la string pour le calcul des positions
    sTexte.replace(pos, strlen(sTag.c_str()), sValeur.c_str()) ;
    pos = sTexte.find(sTag, pos + strlen(sValeur.c_str())) ;
  }
  strcpy(texte, sTexte.c_str()) ;
}

voidNSHtmlRTF::Convertir()
{
try
{
  NSHtml  *pHtmlRTF = new NSHtml(tRTF) ;

  pDialog->Create() ;
  ConvertRTF(pHtmlRTF) ;
  pDialog->CmOk() ;

  ajoute(pHtmlRTF) ;
}
catch (...)
{
	erreur("Exception NSHtmlRTF::Convertir", standardError, 0) ;
}
}

void
NSHtmlRTF::ConvertRTF(NSHtml *pTexte)
{
  // constante MAXCARS dans nsttx.h
  char far        str[MAXCARS + 255] ; // on rajoute 255 pour pouvoir faire les replace des tags
  TCharFormat far cf, cfPrec ;
  TParaFormat far pf, pfPrec ;
  TextStyle       styleDebut, styleCourant ;
  PoliceParam     policeDebut, policeCourant ;
  string          texteCourant ;
  size_t          i ;
  bool            newPara = false ;
  NSHtml          *pPara ;
  char            dateJ[9], message[11] ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  // on r�cup�re le texte
  pDialog->pRichEdit->GetSubText(str, 0, MAXCARS) ;

  // on convertit les tags internes et on remplace le texte
  pContexte->getPatient()->fabriqueNomLong() ;
  RemplaceTagRTF(str, "[nomPatient]", pContexte->getPatient()->getNomLong()) ;
  donne_date_duJour(dateJ) ;  donne_date(dateJ, message, sLang) ;
  RemplaceTagRTF(str, "[dateJour]", message) ;
  pDialog->pRichEdit->ClearModify() ;

  // on r�alise la conversion en HTML
  pDialog->pRichEdit->SetSelection(0, 1) ;
  pDialog->pRichEdit->GetCharFormat(cfPrec, true) ;
  styleDebut = TypeStyle(cfPrec) ;
  TypePolice(cfPrec, policeDebut) ;
  pDialog->pRichEdit->GetParaFormat(pfPrec) ;
  pPara = CreerNewPara(pTexte, pfPrec) ;
  texteCourant = str[0] ;

  for (i = 1 ; i < strlen(str) ; i++)
  {
    pDialog->pRichEdit->SetSelection(i, i + 1) ;
    pDialog->pRichEdit->GetCharFormat(cf, true) ;
    styleCourant = TypeStyle(cf) ;
    TypePolice(cf, policeCourant) ;

    if (str[i - 1] == '\n')
    {
      pDialog->pRichEdit->GetParaFormat(pf) ;
      if ((pfPrec.wAlignment    != pf.wAlignment)     ||
          (pfPrec.dxStartIndent != pf.dxStartIndent)  ||
          (pfPrec.dxOffset      != pf.dxOffset))
      {
        newPara = true ;
        pfPrec  = pf ;
      }
    }

    if (newPara)
    {
      CreerFils(pPara, policeDebut, styleDebut, texteHtml(texteCourant)) ;
      styleDebut    = styleCourant ;
      policeDebut   = policeCourant ;
      texteCourant  = string("") ;
      pPara         = CreerNewPara(pTexte, pf) ;
      newPara       = false ;
    }

    if ((styleCourant == styleDebut) && (policeCourant == policeDebut))
    {
      if (str[i] != '\r')
        texteCourant += str[i] ;
    }
    else
    {
      CreerFils(pPara, policeDebut, styleDebut, texteHtml(texteCourant)) ;
      styleDebut      = styleCourant ;
      policeDebut     = policeCourant ;
      if (str[i] != '\r')
        texteCourant  = str[i] ;      else        texteCourant  = string("") ;    }
  }

  CreerFils(pPara, policeDebut, styleDebut, texteHtml(texteCourant)) ;
}

NSHtml*NSHtmlRTF::CreerNewPara(NSHtml *pere, TParaFormat far pf){
  int alignPara ;
  int indentPara = 0 ;

  if (pf.wAlignment == PFA_LEFT)
    alignPara = 0 ;
  if (pf.wAlignment == PFA_CENTER)
    alignPara = 1 ;
  if (pf.wAlignment == PFA_RIGHT)
    alignPara = 2 ;
  if (pf.wAlignment == PFA_JUSTIFY)    alignPara = 3 ;
  if ((!alignPara) && (pf.dwMask & PFM_STARTINDENT) && (pf.dwMask & PFM_OFFSET))
  {
    indentPara = (int)((pf.dxStartIndent + pf.dxOffset) / DIVTAB) ;
  }

  return CreerPara(pere, indentPara, alignPara) ;
}

NSHtml*
NSHtmlRTF::CreerPara(NSHtml *pere, int indent, int align)
{
try
{
  NSHtml  *pCourant ;
  int     i ;

  pCourant = pere ;

  // Construction de l'indentation du paragraphe (si align� � gauche)
  if (align == 0)
  {
    for (i = 0 ; i < indent ; i++)
    {
      pCourant->filsArray.push_back(new NSHtml(tIndent)) ;
      pCourant = pCourant->filsArray.back() ;
    }
  }

  // Construction du paragraphe
  switch (align)
  {
    case 0  : pCourant->filsArray.push_back(new NSHtml(tPara)) ;
         	    break ;
    case 1  : pCourant->filsArray.push_back(new NSHtml(tParaCentre)) ;
         	    break ;
    case 2  : pCourant->filsArray.push_back(new NSHtml(tParaDroite)) ;
         	    break ;
    // case 3 : justify
    default : pCourant->filsArray.push_back(new NSHtml(tPara)) ;
  }

  pCourant = pCourant->filsArray.back() ;

  return pCourant ;
}
catch (...)
{
	erreur("Exception NSHtmlRTF::CreerPara", standardError, 0) ;
  return NULL ;
}
}


void
NSHtmlRTF::CreerFils(NSHtml *pere, PoliceParam pp, TextStyle style, string text)
{
try
{
  NSHtml *fils, *pfils ;

  pere->filsArray.push_back(new NSHtml(tPolice, pp.face, pp.size)) ;
  fils = pere->filsArray.back() ;

  switch (style)
  {
    case B    : pfils = new NSHtml(tGras) ;
                pfils->sTexte = text ;
                break ;

    case I    : pfils = new NSHtml(tItalic) ;
                pfils->sTexte = text ;
                break ;

    case U    : pfils = new NSHtml(tSouligne) ;
                pfils->sTexte = text ;
                break ;

    case BI   : pfils = new NSHtml(tGras) ;
                pfils->filsArray.push_back(new NSHtml(tItalic)) ;
                (pfils->filsArray[0])->sTexte = text ;
                break ;

    case BU   : pfils = new NSHtml(tGras) ;
                pfils->filsArray.push_back(new NSHtml(tSouligne)) ;
                (pfils->filsArray[0])->sTexte = text ;
                break ;

    case IU   : pfils = new NSHtml(tItalic) ;
                pfils->filsArray.push_back(new NSHtml(tSouligne)) ;
                (pfils->filsArray[0])->sTexte = text ;
                break ;

    case BIU  : pfils = new NSHtml(tGras) ;
                pfils->filsArray.push_back(new NSHtml(tItalic)) ;
                (pfils->filsArray[0])->filsArray.push_back(new NSHtml(tSouligne)) ;
                ((pfils->filsArray[0])->filsArray[0])->sTexte = text ;
                break ;

    default   : pfils = new NSHtml(tTexte) ;
                pfils->sTexte = text ;
  }
  fils->filsArray.push_back(new NSHtml(*pfils)) ;
  delete pfils ;
}
catch (...)
{
	erreur("Exception NSHtmlRTF::CreerFils", standardError, 0) ;
}
}


TextStyle
NSHtmlRTF::TypeStyle(TCharFormat far cf)
{
  DWORD     effects ;
  TextStyle style ;
  bool      IsBold      = false ;
  bool      IsItalic    = false ;
  bool      IsUnderline = false ;

  effects = cf.dwEffects ;
  if (effects & CFE_BOLD)
    IsBold = true ;
  if (effects & CFE_ITALIC)
    IsItalic = true ;
  if (effects & CFE_UNDERLINE)
    IsUnderline = true ;

  if (IsBold)
  {
    if (IsItalic)
    {
      if (IsUnderline)
        style = BIU ;
      else
        style = BI ;
    }
    else
    {
      if (IsUnderline)
        style = BU ;
      else
        style = B ;
    }
  }
  else
  {
    if (IsItalic)
    {
      if (IsUnderline)
        style = IU ;
      else
        style = I ;
    }
    else
    {
      if (IsUnderline)
        style = U ;
      else
        style = N ;
    }
  }

  return style ;
}


void
NSHtmlRTF::TypePolice(TCharFormat far cf, PoliceParam& pp)
{
  int taillePoints, tailleHtml ;

  taillePoints = (int) (cf.yHeight / 20) ;
  tailleHtml = (taillePoints / 2) - 3 ;
  if (tailleHtml < 1)
    tailleHtml = 1 ;
  if (tailleHtml > 7)
    tailleHtml = 7 ;

  pp.size = tailleHtml ;
  pp.face = string(cf.szFaceName) ;
}

// fin du fichier ns_html.cpp

