//---------------------------------------------------------------------------//    NSANNEXE.CPP
//    PA   juillet 94
//  Impl�mentation des objets annexes de NAUTILUS
//---------------------------------------------------------------------------
#include <cstring.h>
#include <windows.h>
#include <mem.h>

#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "nautilus\nspatdlg.h"
#include "nautilus\nsannexe.h"
#include "nautilus\nsresour.h"

#ifndef N_TIERS
//***************************************************************************
// Impl�mentation des m�thodes NSPatCor
//***************************************************************************

//---------------------------------------------------------------------------
//  Function:		NSPatCorData::NSPatCorData()
//  Description:	Constructeur.
//  Retour:			Aucun
//---------------------------------------------------------------------------
NSPatCorData::NSPatCorData()
{
    // Met les champs de donn�es � z�ro
    memset(patient,       0, PCO_PATIENT_LEN + 1);
    memset(correspondant, 0, PCO_CORRESPONDANT_LEN + 1);
    memset(fonction,      0, PCO_FONCTION_LEN + 1);
}

//---------------------------------------------------------------------------

//  Function:		NSPatCor::NSPatCor()
//  Description:	Constructeur.
//  Retour:			Aucun
//---------------------------------------------------------------------------
NSPatCor::NSPatCor(NSContexte* pCtx) : NSFiche(pCtx)
{
    // Cr�e un objet Donn�es
    pDonnees = new NSPatCorData();
}

//---------------------------------------------------------------------------
//  Function:		NSPatCor::~NSPatCor()
//  Description:	Destructeur.
//  Retour:			Aucun
//---------------------------------------------------------------------------
NSPatCor::~NSPatCor()
{
    // D�truit l'objet Donn�es
    delete pDonnees;
}

//---------------------------------------------------------------------------
//  Function:		NSPatCor::alimenteFiche()
//  Description:	Transf�re le contenu de pRecBuff dans les variables de
//						la fiche
//  Retour:			Rien
//---------------------------------------------------------------------------
void NSPatCor::alimenteFiche()
{

	alimenteChamp(pDonnees->patient, 	   PCO_PATIENT_FIELD, 		PCO_PATIENT_LEN);
    alimenteChamp(pDonnees->correspondant, PCO_CORRESPONDANT_FIELD, PCO_CORRESPONDANT_LEN);
	alimenteChamp(pDonnees->fonction, 	   PCO_FONCTION_FIELD, 		PCO_FONCTION_LEN);
}

//---------------------------------------------------------------------------
//  Function:		NSPatCor::videFiche()
//  Description:	Transf�re le contenu des valeurs de la fiche dans pRecBuff
//  Returns:		Rien
//---------------------------------------------------------------------------
void NSPatCor::videFiche()
{
	videChamp(pDonnees->patient, 	   PCO_PATIENT_FIELD, 		PCO_PATIENT_LEN);
    videChamp(pDonnees->correspondant, PCO_CORRESPONDANT_FIELD, PCO_CORRESPONDANT_LEN);
	videChamp(pDonnees->fonction, 	   PCO_FONCTION_FIELD, 		PCO_FONCTION_LEN);
}

//---------------------------------------------------------------------------
//  Fonction:		NSPatCor::open()
//  Description:	Ouvre la table
//  Retour:			DBIResult
//---------------------------------------------------------------------------
DBIResult NSPatCor::open()
{
#ifdef _INCLUS
	return 0;
#else
	char tableName[] = "PATCOR.DB";

	// Appelle la fonction open() de la classe de base
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL);
	return(lastError);
#endif
}

//---------------------------------------------------------------------------
//  Fonction:		NSPatCor::Creer(char* codePatient, char* codeCorresp, char* codeFonction)
//  Description:	Cr�e un lien PatCor (v�rifie que la base est ouverte)
//  Retour:			True->Succ�s False->Echec
//---------------------------------------------------------------------------
bool
NSPatCor::Creer(char* codePatient, char* codeCorresp, char* codeFonction)
{
#ifdef _INCLUS
	int nID;
	PatCorresp_Create(&nID);

	strcpy(pDonnees->patient, codePatient);
	strcpy(pDonnees->correspondant, codeCorresp);
	strcpy(pDonnees->fonction, codeFonction);

	bool bRes = PatCorresp_AddRecord(nID, codePatient, codeCorresp, codeFonction);
	if (!bRes)
	{
		erreur("Erreur � l'ajout de la fiche PatCor", 0, 0);
		PatCorresp_Destroy(nID);
		return false;
	}

	PatCorresp_Destroy(nID);

#else
	// Ouverture de PatCor.db
	if (!isOpen)
	{
		lastError = open();
		if (lastError != DBIERR_NONE)
		{
			erreur("Erreur � l'ouverture de la base PatCor.db", 0, lastError, pContexte->GetMainWindow()->GetHandle());
			return false;
		}
	}

	strcpy(pDonnees->patient, codePatient);
	strcpy(pDonnees->correspondant, codeCorresp);
	strcpy(pDonnees->fonction, codeFonction);

	lastError = appendRecord();
	if (lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ajout de la fiche PatCor", 0, lastError, pContexte->GetMainWindow()->GetHandle());
		if (!isOpen) close();
			return false;
	}

	if (!isOpen)
	{
		lastError = close();
		if (lastError != DBIERR_NONE)
			erreur("Erreur de fermeture de la base PatCor.db.", 0, lastError, pContexte->GetMainWindow()->GetHandle());
	}
#endif

	return true;
}

//---------------------------------------------------------------------------
//  Fonction:		NSPatCor::Modifier(char* codePatient, char* codeCorresp, char* codeFonction)
//  Description:	Modifie un lien PatCor (v�rifie que la base est ouverte)
//  Retour:			True->Succ�s False->Echec
//---------------------------------------------------------------------------
bool
NSPatCor::Modifier(char* codePatient, char* codeCorresp, char* codeFonction)
{
#ifdef _INCLUS
	// On modifie les donnees
	strcpy(pDonnees->patient, codePatient);
	strcpy(pDonnees->correspondant, codeCorresp);
	strcpy(pDonnees->fonction, codeFonction);

	int nID;
	PatCorresp_Create(&nID);	//??? on peut modifier seulement la fonction avec ce code ???

	bool bRes = PatCorresp_ModifyRecord(nID, codePatient, codeCorresp, codeFonction);
	if (!bRes)
	{
		erreur("Erreur � la modification de la fiche PatCor", 0, lastError);
		PatCorresp_Destroy(nID);
		return false;
	}

	PatCorresp_Destroy(nID);

#else
	string sClePatCor = string(codePatient) + string(codeCorresp);

	if (!isOpen)
	{
		lastError = open();
		if (lastError != DBIERR_NONE)
		{
			erreur("Erreur � l'ouverture de la base PatCor.db", 0, lastError, pContexte->GetMainWindow()->GetHandle());
			return false;
		}
	}

	// Recherche du correspondant choisi
	//
	lastError = chercheClef(&sClePatCor,
							"",
							0,
							keySEARCHEQ,
							dbiWRITELOCK);

	if (lastError != DBIERR_NONE)
	{
		erreur("Erreur � la recherche du lien PatCor.", 0, lastError, pContexte->GetMainWindow()->GetHandle());
		if (!isOpen) close();
			return false;
	}

	// On modifie les donnees
	strcpy(pDonnees->patient, codePatient);
	strcpy(pDonnees->correspondant, codeCorresp);
	strcpy(pDonnees->fonction, codeFonction);

	lastError = modifyRecord(TRUE);
	if (lastError != DBIERR_NONE)
	{
		erreur("Erreur � la modification de la fiche PatCor", 0, lastError, pContexte->GetMainWindow()->GetHandle());
		if (!isOpen) close();
			return false;
	}

	if (!isOpen)
	{
		lastError = close();
		if (lastError != DBIERR_NONE)
			erreur("Erreur de fermeture de la base PatCor.db.", 0, lastError, pContexte->GetMainWindow()->GetHandle());
	}
#endif

	return true;
}

//---------------------------------------------------------------------------
//  Fonction:		NSPatCor::Supprimer(char* codePatient, char* codeCorresp)
//  Description:	Supprime un lien PatCor (v�rifie que la base est ouverte)
//  Retour:			True->Succ�s False->Echec
//---------------------------------------------------------------------------
bool
NSPatCor::Supprimer(char* codePatient, char* codeCorresp)
{
#ifdef _INCLUS
	int nID;
	PatCorresp_Create(&nID);

	bool bRes = PatCorresp_DeleteRecord(nID, codePatient, codeCorresp);
	if (!bRes)
	{
		erreur("Erreur � la suppression de la fiche PatCor", 0, lastError);
		PatCorresp_Destroy(nID);
		return false;
	}

	PatCorresp_Destroy(nID);

#else
	string sClePatCor = string(codePatient) + string(codeCorresp);

	if (!isOpen)
	{
		lastError = open();
		if (lastError != DBIERR_NONE)
		{
			erreur("Erreur � l'ouverture de la base PatCor.db", 0, lastError, pContexte->GetMainWindow()->GetHandle());
			return false;
		}
	}

	// Recherche du correspondant choisi
	//
	lastError = chercheClef(&sClePatCor,
							"",
							0,
							keySEARCHEQ,
							dbiWRITELOCK);

	if (lastError != DBIERR_NONE)
	{
		erreur("Erreur � la recherche du lien PatCor.", 0, lastError, pContexte->GetMainWindow()->GetHandle());
		if (!isOpen) close();
			return false;
	}

	// On supprime l'enregistrement

	lastError = deleteRecord();
	if (lastError != DBIERR_NONE)
	{
		erreur("Erreur � la suppression de la fiche PatCor", 0, lastError, pContexte->GetMainWindow()->GetHandle());
		if (!isOpen) close();
			return false;
	}

	if (!isOpen)
	{
		lastError = close();
		if (lastError != DBIERR_NONE)
			erreur("Erreur de fermeture de la base PatCor.db.", 0, lastError, pContexte->GetMainWindow()->GetHandle());
	}
#endif

	return true;
}
#endif // ifndef N_TIERS
//***************************************************************************
//
// Impl�mentation des m�thodes NSAdresses
//
//***************************************************************************
#ifndef N_TIERS
//---------------------------------------------------------------------------
//  Function:  NSAdressesData::NSAdressesData()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSAdressesData::NSAdressesData()
{
    //
    // Met les champs de donn�es � z�ro
    //
    metAZero();
}

//---------------------------------------------------------------------------
//  Fonction:		NSAdressesData::NSAdressesData(NSAdressesData& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSAdressesData::NSAdressesData(NSAdressesData& rv)
{
    strcpy(code,   	   rv.code);
	strcpy(adresse1,   rv.adresse1);
	strcpy(adresse2,   rv.adresse2);
	strcpy(adresse3,   rv.adresse3);
	strcpy(code_post,  rv.code_post);
	strcpy(ville, 	   rv.ville);
	strcpy(telephone,  rv.telephone);
	strcpy(fax, 	   rv.fax);
    strcpy(messagerie, rv.messagerie);
}

//---------------------------------------------------------------------------
//  Fonction:		NSAdressesData::operator=(NSAdressesData src)
//  Description:	Op�rateur =
//  Retour:			R�f�rence sur l'objet cible
//---------------------------------------------------------------------------
NSAdressesData&
NSAdressesData::operator=(NSAdressesData src)
{
    strcpy(code,   	   src.code);
	strcpy(adresse1,   src.adresse1);
	strcpy(adresse2,   src.adresse2);
	strcpy(adresse3,   src.adresse3);
	strcpy(code_post,  src.code_post);
	strcpy(ville, 	   src.ville);
	strcpy(telephone,  src.telephone);
	strcpy(fax,		   src.fax);
    strcpy(messagerie, src.messagerie);

	return *this;
}

//---------------------------------------------------------------------------
//  Fonction:		NSAdressesData::operator==(NSAdressesData& o)
//  Description:	Op�rateur de comparaison
//  Retour:			0 ou 1
//---------------------------------------------------------------------------
int
NSAdressesData::operator == ( NSAdressesData& o )
{

	if ((strcmp(code,   	  o.code) 		== 0) &&
		 (strcmp(adresse1,  o.adresse1) 	== 0) &&
		 (strcmp(adresse2,  o.adresse2) 	== 0) &&
		 (strcmp(adresse3,  o.adresse3) 	== 0) &&
		 (strcmp(code_post, o.code_post) == 0) &&
		 (strcmp(ville,     o.ville) 		== 0) &&
		 (strcmp(telephone, o.telephone) == 0) &&
		 (strcmp(fax,  	  o.fax) 		== 0) &&
       (strcmp(messagerie,o.messagerie)== 0))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Function:  NSAdressesData::metABlanc()
//
//  Description:	Met � blanc les variables de la fiche
//  Retour:			Rien
//---------------------------------------------------------------------------
void NSAdressesData::metABlanc()
{
  //
  // Met les champs de donn�es � blanc
  //
  memset(code,       ' ', ADR_CODE_LEN);
  memset(adresse1,   ' ', ADR_ADRESSE1_LEN);
  memset(adresse2,   ' ', ADR_ADRESSE2_LEN);
  memset(adresse3,   ' ', ADR_ADRESSE3_LEN);
  memset(code_post,	' ', ADR_CODE_POST_LEN);
  memset(ville,      ' ', ADR_VILLE_LEN);
  memset(telephone,  ' ', ADR_TELEPHONE_LEN);
  memset(fax,			' ', ADR_FAX_LEN);
  memset(messagerie, ' ', ADR_MESSAGERIE_LEN);
}

//---------------------------------------------------------------------------
//  Function:		NSAdressesData::metAZero()
//  Description:	Initialise les champs de donn�es � z�ro.
//  Retour:			Aucun
//---------------------------------------------------------------------------
void NSAdressesData::metAZero()
{
  // Met les champs de donn�es � z�ro
  memset(code,       0, ADR_CODE_LEN + 1);
  memset(adresse1,   0, ADR_ADRESSE1_LEN + 1);
  memset(adresse2,   0, ADR_ADRESSE2_LEN + 1);
  memset(adresse3,   0, ADR_ADRESSE3_LEN + 1);
  memset(code_post,	0, ADR_CODE_POST_LEN + 1);
  memset(ville,      0, ADR_VILLE_LEN + 1);
  memset(telephone,  0, ADR_TELEPHONE_LEN + 1);
  memset(fax,			0, ADR_FAX_LEN + 1);
  memset(messagerie, 0, ADR_MESSAGERIE_LEN + 1);
}

//---------------------------------------------------------------------------
//  Function:  NSAdresses::NSAdresses()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSAdresses::NSAdresses(NSContexte* pCtx) : NSFiche(pCtx)
{
    //
    // Cr�ation d'un objet de donn�es
    //
    pDonnees = new NSAdressesData();
}

//---------------------------------------------------------------------------
//  Function:  NSAdresses::~NSAdresses()
//
//  Description: Destructeur.
//---------------------------------------------------------------------------
NSAdresses::~NSAdresses()
{
	//
	// D�truit l'objet de donn�es
	//
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Function:  NSAdresses::alimenteFiche()
//
//  Arguments:
//
//  Description:
//             Transf�re le contenu de pRecBuff dans les variables de
//             la fiche
//  Returns:
//             Rien
//---------------------------------------------------------------------------
void NSAdresses::alimenteFiche()
{
	alimenteChamp(pDonnees->code, 			ADR_CODE_FIELD,			ADR_CODE_LEN);
   alimenteChamp(pDonnees->adresse1, 		ADR_ADRESSE1_FIELD,		ADR_ADRESSE1_LEN);
   alimenteChamp(pDonnees->adresse2, 		ADR_ADRESSE2_FIELD,		ADR_ADRESSE2_LEN);
   alimenteChamp(pDonnees->adresse3, 		ADR_ADRESSE3_FIELD,		ADR_ADRESSE3_LEN);
   alimenteChamp(pDonnees->code_post, 		ADR_CODE_POST_FIELD,		ADR_CODE_POST_LEN);
   alimenteChamp(pDonnees->ville, 			ADR_VILLE_FIELD,			ADR_VILLE_LEN);
   alimenteChamp(pDonnees->telephone, 		ADR_TELEPHONE_FIELD,		ADR_TELEPHONE_LEN);
   alimenteChamp(pDonnees->fax, 				ADR_FAX_FIELD,				ADR_FAX_LEN);
   alimenteChamp(pDonnees->messagerie, 	ADR_MESSAGERIE_FIELD,	ADR_MESSAGERIE_LEN);
}

//---------------------------------------------------------------------------
//  Function:  NSAdresses::videFiche()
//
//  Arguments:
//
//  Description:
//             Transf�re le contenu des valeurs de la fiche dans pRecBuff
//
//  Returns:
//             Rien
//---------------------------------------------------------------------------
void NSAdresses::videFiche()
{
   videChamp(pDonnees->code, 			ADR_CODE_FIELD,			ADR_CODE_LEN);
   videChamp(pDonnees->adresse1, 	ADR_ADRESSE1_FIELD,		ADR_ADRESSE1_LEN);
   videChamp(pDonnees->adresse2, 	ADR_ADRESSE2_FIELD,		ADR_ADRESSE2_LEN);
   videChamp(pDonnees->adresse3, 	ADR_ADRESSE3_FIELD,		ADR_ADRESSE3_LEN);
   videChamp(pDonnees->code_post, 	ADR_CODE_POST_FIELD,		ADR_CODE_POST_LEN);
   videChamp(pDonnees->ville, 		ADR_VILLE_FIELD,			ADR_VILLE_LEN);
   videChamp(pDonnees->telephone, 	ADR_TELEPHONE_FIELD,		ADR_TELEPHONE_LEN);
   videChamp(pDonnees->fax, 			ADR_FAX_FIELD,				ADR_FAX_LEN);
   videChamp(pDonnees->messagerie, 	ADR_MESSAGERIE_FIELD,	ADR_MESSAGERIE_LEN);
}

//---------------------------------------------------------------------------
//  Function:  NSAdresses::open()
//
//  Arguments:
//
//  Description: Ouvre la table
//
//  Returns:
//             PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult NSAdresses::open()
{
#ifdef _INCLUS
  return 0;
#else
  char tableName[] = "ADRESSES.DB";
  //
  // Appelle la fonction open() de la classe de base pour ouvrir
  // l'index primaire
  //
  lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL);
  return(lastError);
#endif
}

//---------------------------------------------------------------------------
//  Function:  NSAdresses::InitNewData(bool bCreer, char* nom, char* prenom, int type)
//
//  Arguments:
//
//  Description: Appel du dialogue de cr�ation/modification d'une adresse
//
//  Returns: true->Les Data sont modifi�es false->Sinon
//
//---------------------------------------------------------------------------
bool NSAdresses::InitNewData(bool bCreer, char* nom, char* prenom, int type, TWindow* parent)
{
    CreerAdresseDialog* pNewAdresseDlg;
    TModule* module = 0;

    if (parent)
        module = parent->GetModule();

    // on utilise le pSuperviseur de NSFiche
	pNewAdresseDlg = new CreerAdresseDialog(parent, pContexte, nom, prenom, type, module);

    if (!bCreer)	// on est en modification
   	    *(pNewAdresseDlg->pData) = *pDonnees;

    if ((pNewAdresseDlg->Execute()) == IDCANCEL)
    {
   	    delete pNewAdresseDlg;
   	    return false;
    }

    // on stocke les donnees du dialogue dans les Data
    *pDonnees = *(pNewAdresseDlg->pData);

    delete pNewAdresseDlg;

    return true;
}

//---------------------------------------------------------------------------
//  Function:  NSAdresses::Creer(char* nom, char* prenom, int type)
//
//  Arguments:
//
//  Description: Cr�ation d'une nouvelle adresse
//
//  Returns: true->Succ�s false->Echec
//
//---------------------------------------------------------------------------
bool NSAdresses::Creer(char* nom, char* prenom, int type, TWindow* parent)
{
   string sCode = "";

   // On met � jour les nouvelles Data (sauf code)
   if (!InitNewData(true,nom,prenom,type,parent))
   	return false;

#ifdef _INCLUS
   int nRSID;
   Address_Create(&nRSID);
   char szCode[ADR_CODE_LEN+1];

   if (!strcmp(pDonnees->code, ""))
   {
	// On calcule et on instancie le nouveau code du correspondant

		memset(szCode, '0', ADR_CODE_LEN);
		szCode[ADR_CODE_LEN] = '\0';
		if (!Address_LastCode(nRSID, szCode))
		{
		  Address_Destroy(nRSID);
			return false;
		}
		else
		{
		  string sCode = szCode;
//          IncrementeCode(&sCode);
			strcpy(pDonnees->code, sCode.c_str());
		}

		  // on ajoute les Data � la base des correspondants
		bool bRes = Address_AddRecord(nRSID, pDonnees->code,
					   pDonnees->adresse1, pDonnees->adresse2, pDonnees->adresse3,
					   pDonnees->code_post, pDonnees->ville, pDonnees->telephone,
			 pDonnees->fax, pDonnees->messagerie);
		if(!bRes)
		{
			erreur("Erreur � l'ajout de la fiche adresse", 0, 0);
		  Address_Destroy(nRSID);
		  return false;
		}
   }
   else	// on reprend un code existant => on remet � jour
   {
		  // on modifie les Data dans la base des adresses
		bool bRes = Address_ModifyRecord(nRSID, pDonnees->code,
				   pDonnees->adresse1, pDonnees->adresse2, pDonnees->adresse3,
					   pDonnees->code_post, pDonnees->ville, pDonnees->telephone,
			 pDonnees->fax, pDonnees->messagerie);
		if(!bRes)
		{
			erreur("Erreur � la modification de la fiche adresse", 0, 0);
		  Address_Destroy(nRSID);
		  return false;
		}
   }
   Address_Destroy(nRSID);

#else
   if (!strcmp(pDonnees->code, ""))
   {
	// On calcule et on instancie le nouveau code du correspondant
	if (!LastCode(&sCode,tCodeAdresse))
		return false;
	else
		strcpy(pDonnees->code, sCode.c_str());

		// on ajoute les Data � la base des correspondants
   	lastError = appendRecord();
   	if(lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � l'ajout de la fiche adresse", 0, lastError, pContexte->GetMainWindow()->GetHandle());
      	// le close doit etre fait par la fonction d'appel
      	return false;
   	}
   }
   else	// on reprend un code existant => on remet � jour
   {
   	lastError = chercheClef((unsigned char*)(pDonnees->code),
													 			 "",
																 0,
													 			 keySEARCHEQ,
                                                 dbiWRITELOCK);
   	if (lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � la recherche de l'adresse.", 0, lastError, pContexte->GetMainWindow()->GetHandle());
      	// le close doit etre fait par la fonction d'appel
			return false;
   	}

   	lastError = modifyRecord(TRUE);
   	if(lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � la modification de la fiche adresse", 0, lastError, pContexte->GetMainWindow()->GetHandle());
      	// le close doit etre fait par la fonction d'appel
      	return false;
   	}
   }
#endif

   return true;
}

//---------------------------------------------------------------------------
//  Function:  NSAdresses::Modifier(char* nom, char* prenom, int type)
//
//  Arguments:
//
//  Description: Remplace les valeurs de la fiche adresse
//
//  Returns: true->Succ�s false->Echec
//
//---------------------------------------------------------------------------
bool NSAdresses::Modifier(char* nom, char* prenom, int type, TWindow* parent)
{
	string sCode = "";
	char codeAdresse[ADR_CODE_LEN + 1];

   strcpy(codeAdresse, pDonnees->code);

	// On met � jour les nouvelles Data
   if (!InitNewData(false,nom,prenom,type,parent))
   	return false;

#ifdef _INCLUS
   int nRSID;
   Address_Create(&nRSID);
   char szCode[ADR_CODE_LEN+1];

   // cas remise � z�ro du code => Cr�ation d'une nouvelle adresse
   if (!strcmp(pDonnees->code, ""))
   {
	  // On calcule et on instancie le nouveau code du correspondant
		memset(szCode, '0', ADR_CODE_LEN);
		szCode[ADR_CODE_LEN] = '\0';
		if (!Address_LastCode(nRSID, szCode))
		{
		  Address_Destroy(nRSID);
			return false;
		}
		else
		{
		  string sCode = szCode;
//          IncrementeCode(&sCode);
			strcpy(pDonnees->code, sCode.c_str());
		}

		  // on ajoute les Data � la base des correspondants
		bool bRes = Address_AddRecord(nRSID, pDonnees->code,
					   pDonnees->adresse1, pDonnees->adresse2, pDonnees->adresse3,
					   pDonnees->code_post, pDonnees->ville, pDonnees->telephone,
			 pDonnees->fax, pDonnees->messagerie);
		if(!bRes)
		{
			erreur("Erreur � l'ajout de la fiche adresse", 0, 0);
		  Address_Destroy(nRSID);
		  return false;
		}
   }
   else // autres cas : modification
   {
		  // on modifie les Data dans la base des adresses
		bool bRes = Address_ModifyRecord(nRSID, pDonnees->code,
				   pDonnees->adresse1, pDonnees->adresse2, pDonnees->adresse3,
					   pDonnees->code_post, pDonnees->ville, pDonnees->telephone,
			 pDonnees->fax, pDonnees->messagerie);
		if(!bRes)
		{
			erreur("Erreur � la modification de la fiche adresse", 0, 0);
		  Address_Destroy(nRSID);
		  return false;
		}
   }
   Address_Destroy(nRSID);

#else
   // cas remise � z�ro du code => Cr�ation d'une nouvelle adresse
   if (!strcmp(pDonnees->code, ""))
   {
	// On calcule et on instancie le nouveau code du correspondant
	if (!LastCode(&sCode,tCodeAdresse))
		return false;
   	else
   		strcpy(pDonnees->code, sCode.c_str());

		// on ajoute les Data � la base des correspondants
	lastError = appendRecord();
   	if(lastError != DBIERR_NONE)
   	{
		erreur("Erreur � l'ajout de la fiche adresse", 0, lastError, pContexte->GetMainWindow()->GetHandle());
      	// le close doit etre fait par la fonction d'appel
      	return false;
   	}
   }
   else // autres cas : modification
   {
   	// si on a chang� de code => ChercheClef
   	if (strcmp(codeAdresse, pDonnees->code))
   	{
   		lastError = chercheClef((unsigned char*)(pDonnees->code),
													 			 "",
													 			 0,
													 			 keySEARCHEQ,
                                                 dbiWRITELOCK);
   		if (lastError != DBIERR_NONE)
   		{
   			erreur("Erreur � la recherche de l'adresse.", 0, lastError, pContexte->GetMainWindow()->GetHandle());
      		// le close doit etre fait par la fonction d'appel
				return false;
   		}
   	}

		// on modifie les Data dans la base des adresses

   	lastError = modifyRecord(TRUE);
   	if(lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � la modification de la fiche adresse", 0, lastError, pContexte->GetMainWindow()->GetHandle());
      	// le close doit etre fait par la fonction d'appel
      	return false;
	}
   }
#endif

   return true;
}

//---------------------------------------------------------------------------
//  Function:  NSAdresses::chercheAdressesInfo(char* cleAdresse, NSAdressesInfo* pAdressesInfo)
//
//  Arguments: Une cl� adresse et un pointeur sur la structure � remplir
//
//  Description: Remplit le NSAdressesInfo correspondant � la cl� adresse
//						Si la base est d�j� ouverte, ne l'ouvre pas.
//
//  Returns: true->OK	false->Echec
//
//---------------------------------------------------------------------------
bool
NSAdresses::chercheAdressesInfo(char* cleAdresse, NSAdressesInfo* pAdresseInfo)
{
#ifdef _INCLUS		//�a va marcher seulement si cleAdresse contient le code de l'adresse recherch�e
	int nID;
	Address_Create(&nID);

	char szCode[ADR_CODE_LEN+1];
	char szAdresse1[ADR_ADRESSE1_LEN+1], szAdresse2[ADR_ADRESSE2_LEN+1];
	char szAdresse3[ADR_ADRESSE3_LEN+1];
	char szCode_Post[ADR_CODE_POST_LEN+1], szVille[ADR_VILLE_LEN];
	char szPhone[ADR_TELEPHONE_LEN+1], szFax[ADR_FAX_LEN+1];
	char szMessagerie[ADR_MESSAGERIE_LEN+1];

	strcpy(szCode, cleAdresse);
	bool bRes = Address_GetDataByCode(nID, szCode, szAdresse1, szAdresse2, szAdresse3,
					 szCode_Post, szVille, szPhone, szFax, szMessagerie);

	if (!bRes)
	{
		erreur("Erreur � la recherche de l'adresse.", 0, 0);
		Address_Destroy(nID);
		return false;
	}

	strcpy(pDonnees->code, szCode);
	strcpy(pDonnees->adresse1, szAdresse1);
	strcpy(pDonnees->adresse2, szAdresse2);
	strcpy(pDonnees->adresse3, szAdresse3);
	strcpy(pDonnees->code_post, szCode_Post);
	strcpy(pDonnees->ville, szVille);
	strcpy(pDonnees->telephone, szPhone);
	strcpy(pDonnees->fax, szFax);
	strcpy(pDonnees->messagerie, szMessagerie);

	*pAdresseInfo = NSAdressesInfo(this);

	Address_Destroy(nID);

#else

	bool bOpenInside = false;
	//
	// Ouverture de Adresses.db
	//

   if (!isOpen)
   {
		lastError = open();
		if (lastError != DBIERR_NONE)
		{
			erreur("Erreur � l'ouverture de la base Adresses.db", 0, lastError, pContexte->GetMainWindow()->GetHandle());
			return false;
		}
	  bOpenInside = true;
   }

	// Recherche de l'adresse choisie
	//
	lastError = chercheClef((unsigned char*)cleAdresse,
														"",
															0,
															keySEARCHEQ,
															dbiWRITELOCK);
	if (lastError == DBIERR_NONE)
		lastError = getRecord();

	if (lastError != DBIERR_NONE)
	{
		erreur("Erreur � la recherche de l'adresse.", 0, lastError, pContexte->GetMainWindow()->GetHandle());
	  if (bOpenInside) close();
		return false;
	}
	else
	{
		*pAdresseInfo = NSAdressesInfo(this);
	}

	if (bOpenInside)
	{
		lastError = close();
		if (lastError != DBIERR_NONE)
		{
			erreur("Erreur de fermeture de la base des adresses.", 0, lastError, pContexte->GetMainWindow()->GetHandle());
			return false;
		}
   }
#endif

	return true;
}

//***************************************************************************
//
// Impl�mentation des m�thodes NSAdressesInfo
//
//***************************************************************************

//---------------------------------------------------------------------------
//  Fonction:		NSAdressesInfo::NSAdressesInfo()
//  Description:	Constructeur par d�faut
//  Retour:			Rien
//---------------------------------------------------------------------------
NSAdressesInfo::NSAdressesInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSAdressesData();
}

//---------------------------------------------------------------------------
//  Fonction:		NSAdressesInfo::NSAdressesInfo(NSAdresses*)
//  Description:	Constructeur � partir d'un NSAdresses
//  Retour:			Rien
//---------------------------------------------------------------------------
NSAdressesInfo::NSAdressesInfo(NSAdresses* pAdresses)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSAdressesData();
	//
	// Copie les valeurs du NSCorrespondant
	//
	*pDonnees = *(pAdresses->pDonnees);
}

//---------------------------------------------------------------------------
//  Fonction:		NSAdressesInfo::~NSAdressesInfo()
//  Description:	Destructeur
//  Retour:			Rien
//---------------------------------------------------------------------------
NSAdressesInfo::~NSAdressesInfo()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Fonction:		NSAdressesInfo::NSAdressesInfo(NSAdressesInfo& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSAdressesInfo::NSAdressesInfo(NSAdressesInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSAdressesData();
	//
	// Copie les valeurs du NSAdressesInfo d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Fonction:		NSAdressesInfo::StringAdresse()
//  Description:	Construit une string adresse pour les controles Edit
//  Retour:			la string adresse
//---------------------------------------------------------------------------
string
NSAdressesInfo::StringAdresse(bool bEdit)
{
	string sAdresse = "";
   string sRC;

   if (bEdit)
   	sRC = string("\r\n");
   else
   	sRC = string("\n");

   if (strlen(pDonnees->adresse1))
   	sAdresse += string(pDonnees->adresse1) + sRC;
   if (strlen(pDonnees->adresse2))
   	sAdresse += string(pDonnees->adresse2) + sRC;
   if (strlen(pDonnees->adresse3))
   	sAdresse += string(pDonnees->adresse3) + sRC;

   sAdresse += string(pDonnees->code_post) + string(" ");
   sAdresse += string(pDonnees->ville);

   return sAdresse;
}

//---------------------------------------------------------------------------
//  Fonction:		NSAdressesInfo::operator=(NSAdressesInfo src)
//  Description:	Op�rateur d'affectation
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
NSAdressesInfo&
NSAdressesInfo::operator=(NSAdressesInfo src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Fonction:		NSAdressesInfo::operator==(NSAdressesInfo src)
//  Description:	Op�rateur de comparaison
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
int NSAdressesInfo::operator == ( NSAdressesInfo& o )
{
	 return (*pDonnees == *(o.pDonnees));
}
#endif // ifndef N_TIERS

//***************************************************************************
//
// Impl�mentation des m�thodes NSTypeMime
//
//***************************************************************************

//---------------------------------------------------------------------------
//  Function:  NSTypeMimeData::NSTypeMimeData()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSTypeMimeData::NSTypeMimeData()
{
  //
  // Met les champs de donn�es � z�ro
  //
  metAZero();
}

//---------------------------------------------------------------------------
//  Fonction:		NSTypeMimeData::NSTypeMimeData(NSTypeMimeData& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSTypeMimeData::NSTypeMimeData(NSTypeMimeData& rv)
{
   strcpy(extension,   	rv.extension);
	strcpy(libelle, 		rv.libelle);
	strcpy(mime, 			rv.mime);
	strcpy(type,  			rv.type);
}

//---------------------------------------------------------------------------
//  Fonction:		NSTypeMimeData::operator=(NSTypeMimeData src)
//  Description:	Op�rateur =
//  Retour:			R�f�rence sur l'objet cible
//---------------------------------------------------------------------------
NSTypeMimeData&
NSTypeMimeData::operator=(NSTypeMimeData src)
{
   strcpy(extension,   	src.extension);
	strcpy(libelle, 		src.libelle);
	strcpy(mime, 			src.mime);
	strcpy(type,  			src.type);

	return *this;
}

//---------------------------------------------------------------------------
//  Fonction:		NSTypeMimeData::operator==(NSTypeMimeData& o)
//  Description:	Op�rateur de comparaison
//  Retour:			0 ou 1
//---------------------------------------------------------------------------
int
NSTypeMimeData::operator == ( NSTypeMimeData& o )
{

	if ((strcmp(extension, 	o.extension) 	== 0) &&
		 (strcmp(libelle,   	o.libelle) 		== 0) &&
		 (strcmp(mime,  		o.mime) 			== 0) &&
       (strcmp(type,			o.type)			== 0))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Function:  NSTypeMimeData::metABlanc()
//
//  Description:	Met � blanc les variables de la fiche
//  Retour:			Rien
//---------------------------------------------------------------------------
void
NSTypeMimeData::metABlanc()
{
  //
  // Met les champs de donn�es � blanc
  //
  memset(extension,	' ', MIM_EXTENSION_LEN);
  memset(libelle,   	' ', MIM_LIBELLE_LEN);
  memset(mime,   		' ', MIM_MIME_LEN);
  memset(type,   		' ', MIM_TYPE_LEN);
}

//---------------------------------------------------------------------------
//  Function:		NSTypeMimeData::metAZero()
//  Description:	Initialise les champs de donn�es � z�ro.
//  Retour:			Aucun
//---------------------------------------------------------------------------
void
NSTypeMimeData::metAZero()
{
  // Met les champs de donn�es � z�ro
  memset(extension,	0, MIM_EXTENSION_LEN + 1);
  memset(libelle,   	0, MIM_LIBELLE_LEN + 1);
  memset(mime,   		0, MIM_MIME_LEN + 1);
  memset(type,   		0, MIM_TYPE_LEN + 1);
}

//---------------------------------------------------------------------------
//  Function:  NSTypeMime::NSTypeMime()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSTypeMime::NSTypeMime(NSContexte* pCtx) : NSFiche(pCtx)
{
    //
    // Cr�ation d'un objet de donn�es
    //
    pDonnees = new NSTypeMimeData();
}

//---------------------------------------------------------------------------
//  Function:  NSTypeMime::~NSTypeMime()
//
//  Description: Destructeur.
//---------------------------------------------------------------------------
NSTypeMime::~NSTypeMime()
{
	//
	// D�truit l'objet de donn�es
	//
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Function:  NSTypeMime::alimenteFiche()
//
//  Arguments:
//
//  Description:
//             Transf�re le contenu de pRecBuff dans les variables de
//             la fiche
//  Returns:
//             Rien
//---------------------------------------------------------------------------
void NSTypeMime::alimenteFiche()
{
	alimenteChamp(pDonnees->extension, 		MIM_EXTENSION_FIELD,		MIM_EXTENSION_LEN);
   alimenteChamp(pDonnees->libelle, 		MIM_LIBELLE_FIELD,		MIM_LIBELLE_LEN);
   alimenteChamp(pDonnees->mime, 			MIM_MIME_FIELD,			MIM_MIME_LEN);
   alimenteChamp(pDonnees->type, 			MIM_TYPE_FIELD,			MIM_TYPE_LEN);
}

//---------------------------------------------------------------------------
//  Function:  NSTypeMime::videFiche()
//
//  Arguments:
//
//  Description:
//             Transf�re le contenu des valeurs de la fiche dans pRecBuff
//
//  Returns:
//             Rien
//---------------------------------------------------------------------------
void NSTypeMime::videFiche()
{
   videChamp(pDonnees->extension, 	MIM_EXTENSION_FIELD,		MIM_EXTENSION_LEN);
   videChamp(pDonnees->libelle, 		MIM_LIBELLE_FIELD,		MIM_LIBELLE_LEN);
   videChamp(pDonnees->mime, 			MIM_MIME_FIELD,			MIM_MIME_LEN);
   videChamp(pDonnees->type, 			MIM_TYPE_FIELD,			MIM_TYPE_LEN);
}

//---------------------------------------------------------------------------
//  Function:  NSTypeMime::open()
//
//  Arguments:
//
//  Description: Ouvre la table
//
//  Returns:
//             PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult NSTypeMime::open()
{
  char tableName[] = "TYPEMIME.DB";
  //
  // Appelle la fonction open() de la classe de base pour ouvrir
  // l'index primaire
  //
  lastError = NSFiche::open(tableName, NSF_PERSONNEL);
  return(lastError);
}

//---------------------------------------------------------------------------
//  Function:  NSTypeMime::chercheTypeMimeInfo(char* fichExt, NSTypeMimeInfo* pTypeMimeInfo)
//
//  Arguments: Une cl� extension et un pointeur sur la structure � remplir
//
//  Description: Remplit le NSTypeMimeInfo correspondant � la cl� extension
//						Si la base est d�j� ouverte, ne l'ouvre pas.
//
//  Returns: true->OK	false->Echec
//
//---------------------------------------------------------------------------
bool
NSTypeMime::chercheTypeMimeInfo(string sFichExt, NSTypeMimeInfo* pTypeMimeInfo)
{
	bool bOpenInside = false;
    char cFichExt[100];

	//
	// Ouverture de TypeMime.db
	//

   if (!isOpen)
   {
		lastError = open();
		if (lastError != DBIERR_NONE)
		{
			erreur("Erreur � l'ouverture de la base TypeMime.db", standardError, lastError, pContexte->GetMainWindow()->GetHandle());
			return false;
		}
      bOpenInside = true;
   }

   // La recherche n'est pas case-sensitive
   strcpy(cFichExt, sFichExt.c_str());
   CharLower(cFichExt);
   sFichExt = string(cFichExt);

	// Recherche de l'extension choisie
	//
	lastError = chercheClef(&sFichExt,
   									"",
										0,
										keySEARCHEQ,
										dbiWRITELOCK);

	if (lastError == DBIERR_NONE)
		lastError = getRecord();

	if (lastError != DBIERR_NONE)
	{
        // Note : on ne signale plus cette erreur � cause de son apparition
        // fr�quente dans la proc�dure d'importation des images
   	    // if (lastError != DBIERR_EOF)
		//  	erreur("Erreur � la recherche de l'extension dans TypeMime.db.", 0, lastError);
        if (bOpenInside) close();
		return false;
	}
   else
   {
   	*pTypeMimeInfo = NSTypeMimeInfo(this);
   }

   if (bOpenInside)
   {
		lastError = close();
   	if (lastError != DBIERR_NONE)
      {
			erreur("Erreur de fermeture de la base TypeMime.db.", standardError, lastError, pContexte->GetMainWindow()->GetHandle());
         return false;
      }
   }

	return true;
}

//***************************************************************************
//
// Impl�mentation des m�thodes NSTypeMimeInfo
//
//***************************************************************************

//---------------------------------------------------------------------------
//  Fonction:		NSTypeMimeInfo::NSTypeMimeInfo()
//  Description:	Constructeur par d�faut
//  Retour:			Rien
//---------------------------------------------------------------------------
NSTypeMimeInfo::NSTypeMimeInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSTypeMimeData();
}

//---------------------------------------------------------------------------
//  Fonction:		NSTypeMimeInfo::NSTypeMimeInfo(NSTypeMime*)
//  Description:	Constructeur � partir d'un NSTypeMime
//  Retour:			Rien
//---------------------------------------------------------------------------
NSTypeMimeInfo::NSTypeMimeInfo(NSTypeMime* pTypeMime)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSTypeMimeData();
	//
	// Copie les valeurs du NSTypeMime
	//
	*pDonnees = *(pTypeMime->pDonnees);
}

//---------------------------------------------------------------------------
//  Fonction:		NSTypeMimeInfo::~NSTypeMimeInfo()
//  Description:	Destructeur
//  Retour:			Rien
//---------------------------------------------------------------------------
NSTypeMimeInfo::~NSTypeMimeInfo()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Fonction:		NSTypeMimeInfo::NSTypeMimeInfo(NSTypeMimeInfo& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSTypeMimeInfo::NSTypeMimeInfo(NSTypeMimeInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSTypeMimeData();
	//
	// Copie les valeurs du NSTypeMimeInfo d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Fonction:		NSTypeMimeInfo::operator=(NSTypeMimeInfo src)
//  Description:	Op�rateur d'affectation
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
NSTypeMimeInfo&
NSTypeMimeInfo::operator=(NSTypeMimeInfo src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Fonction:		NSTypeMimeInfo::operator==(NSTypeMimeInfo src)
//  Description:	Op�rateur de comparaison
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
int NSTypeMimeInfo::operator == ( NSTypeMimeInfo& o )
{
	 return (*pDonnees == *(o.pDonnees));
}
#ifndef N_TIERS
//***************************************************************************
//
// Impl�mentation des m�thodes NSCritical
//
//***************************************************************************

//---------------------------------------------------------------------------
//  Function:  NSCriticalData::NSCriticalData()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSCriticalData::NSCriticalData()
{
  	//
  	// Met les champs de donn�es � z�ro
  	//
  	metAZero();
}

//---------------------------------------------------------------------------
//  Fonction:		NSCriticalData::NSCriticalData(NSCriticalData& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCriticalData::NSCriticalData(NSCriticalData& rv)
{
   	strcpy(base,   	rv.base);
	strcpy(occupe, 	rv.occupe);
	strcpy(date, 	rv.date);
	strcpy(heure,  	rv.heure);
}

//---------------------------------------------------------------------------
//  Fonction:		NSCriticalData::operator=(NSCriticalData src)
//  Description:	Op�rateur =
//  Retour:			R�f�rence sur l'objet cible
//---------------------------------------------------------------------------
NSCriticalData&
NSCriticalData::operator=(NSCriticalData src)
{
   	strcpy(base,   	src.base);
	strcpy(occupe, 	src.occupe);
	strcpy(date, 	src.date);
	strcpy(heure,  	src.heure);

	return *this;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCriticalData::operator==(NSCriticalData& o)
//  Description:	Op�rateur de comparaison
//  Retour:			0 ou 1
//---------------------------------------------------------------------------
int
NSCriticalData::operator == ( NSCriticalData& o )
{

	if 	((strcmp(base, 		o.base) 	== 0) &&
		 (strcmp(occupe,   	o.occupe) 	== 0) &&
		 (strcmp(date,  	o.date) 	== 0) &&
       	 (strcmp(heure,		o.heure)	== 0))
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Function:  NSCriticalData::metABlanc()
//
//  Description:	Met � blanc les variables de la fiche
//  Retour:			Rien
//---------------------------------------------------------------------------
void
NSCriticalData::metABlanc()
{
  	//
  	// Met les champs de donn�es � blanc
  	//
  	memset(base,		' ', CRITIC_BASE_LEN);
  	memset(occupe,   	' ', CRITIC_OCCUPE_LEN);
  	memset(date,   		' ', CRITIC_DATE_LEN);
  	memset(heure,   	' ', CRITIC_HEURE_LEN);
}

//---------------------------------------------------------------------------
//  Function:		NSCriticalData::metAZero()
//  Description:	Initialise les champs de donn�es � z�ro.
//  Retour:			Aucun
//---------------------------------------------------------------------------
void
NSCriticalData::metAZero()
{
  	// Met les champs de donn�es � z�ro
  	memset(base,		0, CRITIC_BASE_LEN + 1);
  	memset(occupe,   	0, CRITIC_OCCUPE_LEN + 1);
  	memset(date,   		0, CRITIC_DATE_LEN + 1);
  	memset(heure,   	0, CRITIC_HEURE_LEN + 1);
}

//---------------------------------------------------------------------------
//  Function:  NSCritical::NSCritical()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSCritical::NSCritical(NSContexte* pCtx) : NSFiche(pCtx)
{
    //
  	// Cr�ation d'un objet de donn�es
  	//
  	pDonnees = new NSCriticalData();
}

//---------------------------------------------------------------------------
//  Function:  NSCritical::~NSCritical()
//
//  Description: Destructeur.
//---------------------------------------------------------------------------
NSCritical::~NSCritical()
{
	//
	// D�truit l'objet de donn�es
	//
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Function:  NSCritical::alimenteFiche()
//
//  Arguments:
//
//  Description:
//             Transf�re le contenu de pRecBuff dans les variables de
//             la fiche
//  Returns:
//             Rien
//---------------------------------------------------------------------------
void NSCritical::alimenteFiche()
{
	alimenteChamp(pDonnees->base, 		CRITIC_BASE_FIELD,		CRITIC_BASE_LEN);
   	alimenteChamp(pDonnees->occupe, 	CRITIC_OCCUPE_FIELD,	CRITIC_OCCUPE_LEN);
   	alimenteChamp(pDonnees->date, 		CRITIC_DATE_FIELD,		CRITIC_DATE_LEN);
   	alimenteChamp(pDonnees->heure, 		CRITIC_HEURE_FIELD,		CRITIC_HEURE_LEN);
}

//---------------------------------------------------------------------------
//  Function:  NSCritical::videFiche()
//
//  Arguments:
//
//  Description:
//             Transf�re le contenu des valeurs de la fiche dans pRecBuff
//
//  Returns:
//             Rien
//---------------------------------------------------------------------------
void NSCritical::videFiche()
{
   	videChamp(pDonnees->base, 		CRITIC_BASE_FIELD,		CRITIC_BASE_LEN);
   	videChamp(pDonnees->occupe, 	CRITIC_OCCUPE_FIELD,	CRITIC_OCCUPE_LEN);
   	videChamp(pDonnees->date, 		CRITIC_DATE_FIELD,		CRITIC_DATE_LEN);
   	videChamp(pDonnees->heure, 		CRITIC_HEURE_FIELD,		CRITIC_HEURE_LEN);
}

//---------------------------------------------------------------------------
//  Function:  NSCritical::open()
//
//  Arguments:
//
//  Description: Ouvre la table
//
//  Returns:
//             PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult NSCritical::open()
{
  char tableName[] = "CRITICAL.DB";
  //
  // Appelle la fonction open() de la classe de base pour ouvrir
  // l'index primaire
  // Note : on passe false pour ouvrir cette table en mode exclusif
  //
  lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL, false);
  return(lastError);
}

//***************************************************************************
//
// Impl�mentation des m�thodes NSCriticalInfo
//
//***************************************************************************

//---------------------------------------------------------------------------
//  Fonction:		NSCriticalInfo::NSCriticalInfo()
//  Description:	Constructeur par d�faut
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCriticalInfo::NSCriticalInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSCriticalData();
}

//---------------------------------------------------------------------------
//  Fonction:		NSCriticalInfo::NSCriticalInfo(NSCritical*)
//  Description:	Constructeur � partir d'un NSCritical
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCriticalInfo::NSCriticalInfo(NSCritical* pCritical)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCriticalData();
	//
	// Copie les valeurs du NSCritical
	//
	*pDonnees = *(pCritical->pDonnees);
}

//---------------------------------------------------------------------------
//  Fonction:		NSCriticalInfo::~NSCriticalInfo()
//  Description:	Destructeur
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCriticalInfo::~NSCriticalInfo()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCriticalInfo::NSCriticalInfo(NSCriticalInfo& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCriticalInfo::NSCriticalInfo(NSCriticalInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCriticalData();
	//
	// Copie les valeurs du NSCriticalInfo d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Fonction:		NSCriticalInfo::operator=(NSCriticalInfo src)
//  Description:	Op�rateur d'affectation
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
NSCriticalInfo&
NSCriticalInfo::operator=(NSCriticalInfo src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCriticalInfo::operator==(NSCriticalInfo src)
//  Description:	Op�rateur de comparaison
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
int NSCriticalInfo::operator == ( NSCriticalInfo& o )
{
	 return (*pDonnees == *(o.pDonnees));
}
//***************************************************************************//
// 	M�thodes de NSCriticalDialog
//
//***************************************************************************

DEFINE_RESPONSE_TABLE1(NSCriticalDialog, TDialog)
	EV_COMMAND(IDC_CRITIC_REESSAYER, CmReessayer),
	EV_COMMAND(IDC_CRITIC_FORCER, CmForcerBlocage),
	EV_COMMAND(IDC_CRITIC_ANNULER, CmAnnuler),
END_RESPONSE_TABLE ;

NSCriticalDialog::NSCriticalDialog(TWindow* parent, NSCriticalInfo* pCritInfo)                 :TDialog(parent, "IDD_CRITICAL"){
	pTextBase    = new TStatic(this, IDC_CRITIC_BASE) ;
	pTextConsole = new TStatic(this, IDC_CRITIC_CONSOLE) ;
	pTextDate    = new TStatic(this, IDC_CRITIC_DATE) ;
	pInfo        = new NSCriticalInfo(*pCritInfo) ;
}

NSCriticalDialog::~NSCriticalDialog(){
	delete pTextBase ;
	delete pTextConsole ;
	delete pTextDate ;
	delete pInfo ;
}

voidNSCriticalDialog::SetupWindow()
{
	char   msg[255] ;
  string sHeure ;
	char   cDate[15] ;

	TDialog::SetupWindow() ;

  sprintf(msg, "La base %s est bloqu�e", pInfo->pDonnees->base) ;
  pTextBase->SetCaption(msg) ;

  sprintf(msg, "par la console n�%s", pInfo->pDonnees->occupe) ;
  pTextConsole->SetCaption(msg) ;

  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  donne_date(pInfo->pDonnees->date, cDate, sLang) ;
  donne_heure(pInfo->pDonnees->heure, sHeure) ;

  sprintf(msg, "depuis le %s � %s", cDate, sHeure.c_str()) ;  pTextDate->SetCaption(msg) ;
}


void
NSCriticalDialog::CmReessayer()
{
	reponse = RP_REESSAYER;

    TDialog::CmOk();
}

void
NSCriticalDialog::CmForcerBlocage()
{
	reponse = RP_FORCER;

    TDialog::CmOk();
}

void
NSCriticalDialog::CmAnnuler()
{
	reponse = RP_ANNULER;

    TDialog::CmCancel();
}
#endif // ifndef N_TIERS

// fin de NSAnnexe.cpp
///////////////////////////////////////////////////////////////////////////////

