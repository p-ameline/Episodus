#include <owl\applicat.h>#include <owl\olemdifr.h>
#include <owl\dialog.h>
#include <owl\edit.h>
#include <owl\color.h>
#include <bde.hpp>
#include <stdio.h>
#include <string.h>

#include "nautilus\nssuper.h"#include "nautilus\nsanxary.h"
#include "nautilus\nsresour.h"
#include "nautilus\nsrechd2.h"
#include "partage\nsdivfct.h"
#include "nautilus\cr.rh"
#include "nautilus\nstypdoc.rh"
#include "nssavoir\nspathor.h"
#include "nsbb\nsednum.h"


//***********************************************************************//
//							Classe NSTypeDocument
//***********************************************************************//

/**********************************************************************///  permettre l'�dition de champ num�rique pour un NSTreeNode
/**********************************************************************/

DEFINE_RESPONSE_TABLE1(NSTypeDocument, NSUtilDialog)  EV_COMMAND(IDOK, CmOk),
  EV_COMMAND(IDCANCEL, CmCancel),
  EV_COMMAND(CONSULTATION_BOUTON, ChoixConsultation),
END_RESPONSE_TABLE;

NSTypeDocument::NSTypeDocument(TWindow* parent, NSContexte* pCtx,                               string* pTypeDocument, TModule* module)
               :NSUtilDialog(parent, pCtx, "TYPE_DOCUMENT", module)
{
  pConsultation = new TButton(this, CONSULTATION_BOUTON) ;
	pType         = new NSUtilLexique(pContexte, this, DOCUMENT_EDIT, pContexte->getDico()) ;
  pTypeDocum    = pTypeDocument ;
}

NSTypeDocument::~NSTypeDocument(){
  delete pConsultation ;
  delete pType ;
}

//----------------------------------------------------------------------------//----------------------------------------------------------------------------
void
NSTypeDocument::CmOk()
{
    // on r�cup�re d'abord un �ventuel �l�ment lexique s�lectionn� par les fl�ches
    // Le Return n'envoie pas d'EvKeyDown et appelle directement CmOk
    if (pType->pDico->pDicoDialog->EstOuvert())
    {
        pType->pDico->pDicoDialog->InsererElementLexique();
        return;
    }
    //
    // Ne pas accepter les textes libres
    //
    if (pType->sCode == string("�?????"))
    {
        erreur("Il faut choisir un code lexique et non pas du texte libre ", standardError, 0, GetHandle());
        pType->SetFocus();
        return;
    }
    *pTypeDocum = pType->sCode;

    if (*pTypeDocum == "")
        *pTypeDocum = "GCONS1";

	CloseWindow(IDOK);
}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
void
NSTypeDocument::CmCancel()
{
    *pTypeDocum = "";
    Destroy(IDCANCEL);
}

void
NSTypeDocument::SetupWindow()
{    // fichiers d'aide

    sHindex = "";
    sHcorps = "Les_Fiches_de.html";

    TDialog::SetupWindow();
}
//---------------------------------------------------------------------
//on a choisi la consultation
//---------------------------------------------------------------------
void
NSTypeDocument::ChoixConsultation()
{
    *pTypeDocum = "GCONS1";
    CloseWindow(IDOK);
}

// -----------------------------------------------------------------//
//  M�thodes de ChoixCRDialog
//
// -----------------------------------------------------------------

#ifdef _INCLUSDEFINE_RESPONSE_TABLE1(ChoixCRDialog, NSDialogWrapper)
#else
DEFINE_RESPONSE_TABLE1(ChoixCRDialog, TDialog)
#endif
	EV_COMMAND(IDOK,		CmOk),
	EV_COMMAND(IDCANCEL,	CmCancel),
	EV_CHILD_NOTIFY_AND_CODE(IDC_MODU_LISTE, LBN_SELCHANGE, CmSelectModule),
	EV_CHILD_NOTIFY_AND_CODE(IDC_MODU_LISTE, LBN_DBLCLK, CmModuleDblClk),
END_RESPONSE_TABLE;

//--------------------------------------------------------------------------//      Constructeur
//---------------------------------------------------------------------------

#ifdef _INCLUSChoixCRDialog::ChoixCRDialog(TWindow* pere, string* pChoix, NSContexte* pCtx, TModule* module)
              :NSDialogWrapper(pCtx, pere, "IDD_MODULES", module)
#else
ChoixCRDialog::ChoixCRDialog(TWindow* pere, string* pChoix, string* pImport, NSContexte* pCtx)
              :NSUtilDialog(pere, pCtx, "IDD_MODULES")
#endif
{
try
{
    pContexte       = pCtx ;
	//
	// Cr�ation des objets dialogues
	//
	pModulesBox     = new TListBox(this, IDC_MODU_LISTE) ;
	//
	// Initialisation des variables g�n�rales
	//
	pModulesArray   = new NSModuleArray ;

	lexiqueCR[0]    = '\0' ;
	Contexte 	    = '0' ;
	iModuleChoisi   = -1 ;

    pChoisi         = pChoix ;
    pImportDll      = pImport ;
}
catch (const exception& e)
{
    string sExept = "ChoixCRDialog ctor " + string(e.what()) ;
    erreur(sExept.c_str(), standardError, 0) ;
}
catch (...)
{
    erreur("ChoixCRDialog ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//      Destructeur
//---------------------------------------------------------------------------
ChoixCRDialog::~ChoixCRDialog()
{
	//
	// D�truit les objets de pilotage des dialogues
	//
	delete pModulesBox;
	delete pModulesArray;
}

//---------------------------------------------------------------------------
//  Description: Initialise la boite de liste des modules
//
//  Returns:	  Rien
//---------------------------------------------------------------------------
void
ChoixCRDialog::SetupWindow()
{
  // fichiers d'aide

    sHindex = "";
    sHcorps = "Compte_Rendus.html";

	char    buffer[501];
	string  Chaine, sCode;
    string  sFichierModules;
	int	    i, j;

	TDialog::SetupWindow();

	sFichierModules = pContexte->PathName("FPER") + string("MODULES.LUS");
	//
	// Ouverture du fichier des modules
	//
	ifstream inFile;
	inFile.open(sFichierModules.c_str());
	if (!inFile)
	{
		erreur("Erreur � l'ouverture du fichier des modules.", standardError, 0, GetHandle());
		return;
	}
	//
	// Lecture du fichier
	//
    string sLang = "";
    if ((pContexte) && (pContexte->getUtilisateur()))
        sLang = pContexte->getUtilisateur()->donneLang();

    int iNbModules = 0 ;

    string sString1;
    string sString2;

	NSModuleInfo* pModule = new NSModuleInfo;
	inFile.unsetf(ios::skipws);
    while (inFile.getline(buffer, 500))
	{
        sString1 = "";
        sString2 = "";

        int iTailleBuf = strlen(buffer);
		if (iTailleBuf >= 8)
		{
			i = 0;
			//
			// Prise du nom du module
			//
			for (j = 0; (j < MODU_LEXIQUE_LEN) && (i < iTailleBuf); j++, i++)
				pModule->pDonnees->lexique[j] = buffer[i];
			pModule->pDonnees->lexique[j] = '\0';
            //
			for (; (i < iTailleBuf) && ((buffer[i] == ' ') || (buffer[i] == '\t')); i++);
			//
			// Prise du code du module
			//
			for (j = 0; (j < MODU_CODE_LEN) && (i < iTailleBuf); j++, i++)
				pModule->pDonnees->code[j] = buffer[i];
			pModule->pDonnees->code[j] = '\0';
            //
			for (; (i < iTailleBuf) && ((buffer[i] == ' ') || (buffer[i] == '\t')); i++);

            if (i < iTailleBuf)
            {
                for (; (i < iTailleBuf) && (buffer[i] != ' ') && (buffer[i] != '\t'); i++)
				    sString1 += buffer[i];
                for (; (i < iTailleBuf) && ((buffer[i] == ' ') || (buffer[i] == '\t')); i++);
                for (; (i < iTailleBuf) && (buffer[i] != ' ') && (buffer[i] != '\t'); i++)
				    sString2 += buffer[i];
            }

            if (sString1 != "")
            {
                if (strlen(sString1.c_str()) == MODU_COMPTE_LEN)
                {
                    strcpy(pModule->pDonnees->compte, sString1.c_str());
                    pModule->pDonnees->sImportDll = sString2;
                }
                else
                {
                    pModule->pDonnees->sImportDll = sString1;
                    if (strlen(sString2.c_str()) == MODU_COMPTE_LEN)
                        strcpy(pModule->pDonnees->compte, sString2.c_str());
                }
            }
			//
			// Recherche du libell�
			//
            sCode = string(pModule->pDonnees->lexique);
			pContexte->getDico()->donneLibelle(sLang, &sCode, &pModule->pDonnees->libelle);
			//
			// Ajout du module � la liste
			//
			pModulesBox->AddString(pModule->pDonnees->libelle.c_str());
			pModulesArray->push_back(new NSModuleInfo(*pModule));

            iNbModules++ ;
		}
		pModule->pDonnees->metAZero();
	}
	delete pModule;
	inFile.close();

    if (iNbModules == 1)
    {
        pModulesBox->SetSelIndex(0) ;
        iModuleChoisi = 1 ;
    }

	return;
}

//---------------------------------------------------------------------------
//  Arguments :	    Cmd : WPARAM retourn� par Windows
//  Description :	S�lectionne un module et sort
//  Retour	: 		Rien
//---------------------------------------------------------------------------
void
ChoixCRDialog::CmModuleDblClk(WPARAM Cmd)
{
	iModuleChoisi = pModulesBox->GetSelIndex() + 1;
	CmOk();
}

//---------------------------------------------------------------------------
//  Arguments :	    Cmd : WPARAM retourn� par Windows
//  Description :	S�lectionne un module
//  Retour	: 		Rien
//---------------------------------------------------------------------------
void
ChoixCRDialog::CmSelectModule(WPARAM Cmd)
{
	//
	// R�cup�ration de l'indice de la chemise s�lectionn�e
	//
	iModuleChoisi = pModulesBox->GetSelIndex() + 1;
}

//---------------------------------------------------------------------------
//  Description :	Appelle CmOk si un module a �t� choisi
//  Retour	: 		Rien
//---------------------------------------------------------------------------
void ChoixCRDialog::CmOk()
{
	if (iModuleChoisi <= 0)
	{
		erreur("Vous devez s�lectionner un module.", standardError, 0, GetHandle()) ;
		return ;
	}

	int indice = iModuleChoisi - 1 ;

	// pour les versions d�mo
	int lenKey = strlen((*pModulesArray)[indice]->pDonnees->compte) ;

	if (lenKey)
	{
		string sKey = string((*pModulesArray)[indice]->pDonnees->compte) ;
		// la longueur est fix�e � deux caract�res
		if ((lenKey != 2) || (sKey == "AA"))
		{
    	erreur("Cette version de d�monstration a expir�", standardError, 0) ;
      return ;
    }
    else
    {
    	if ((sKey[0] < 'A') || (sKey[0] > 'Z') || (sKey[1] < 'A') || (sKey[1] > 'Z'))
      {
      	erreur("Cette version de d�monstration a expir�", standardError, 0) ;
        return ;
      }
      if (sKey[1] == 'A')
      {
      	sKey[0] -= 1 ;
        sKey[1] = 'Z' ;
      }
      else
      	sKey[1] -= 1;

      strcpy((*pModulesArray)[indice]->pDonnees->compte, sKey.c_str()) ;

            string sOut = "";
            NSModuInfoArrayIter i = pModulesArray->begin();
            for (; i != pModulesArray->end(); i++)
            {
            	sOut += string((*i)->pDonnees->lexique);
                sOut += string(" ");
                sOut += string((*i)->pDonnees->code);
                if ((*i)->pDonnees->compte[0] != '\0')
                {
                	sOut += string(" ");
                    sOut += string((*i)->pDonnees->compte);
                }
                sOut += string("\n");
            }

            string sFichierModules = pContexte->PathName("FPER") +
                										string("MODULES.LUS");
            ofstream outFile;
            outFile.open(sFichierModules.c_str());
            if (!outFile)
            {
            	erreur("Erreur d'ouverture en �criture du fichier des modules", standardError, 0);
                return;
            }

            for (size_t j = 0; j < strlen(sOut.c_str()); j++)
            	outFile.put(sOut[j]);

            outFile.close();
        }
    }

    //
    // On fixe les donn�es propres au module
    //
    strcpy(lexiqueCR, (*pModulesArray)[indice]->pDonnees->lexique);

    *pChoisi    = string(lexiqueCR);
    *pImportDll = (*pModulesArray)[indice]->pDonnees->sImportDll;

    //
    // On sort
    //
    TDialog::CmOk();
    return;
}

//---------------------------------------------------------------------------
//  Function :		ChoixCRDialog::CmCancel()
//
//  Arguments :	Aucun
//
//  Description :	Annule ModuleChoisie et appelle Cancel()
//
//  Retour	: 		Rien
//---------------------------------------------------------------------------
void ChoixCRDialog::CmCancel()
{
	iModuleChoisi   = -1 ;
    *pChoisi        = "";

	TDialog::CmCancel();
}

// -----------------------------------------------------------------//
//  M�thodes de ChoixArchetypeDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(ChoixArchetypeDialog, NSUtilDialog)	EV_COMMAND(IDOK,		CmOk),
	EV_COMMAND(IDCANCEL,	CmCancel),
	EV_CHILD_NOTIFY_AND_CODE(IDC_MODU_LISTE, LBN_SELCHANGE, CmSelectModule),
	EV_CHILD_NOTIFY_AND_CODE(IDC_MODU_LISTE, LBN_DBLCLK, CmModuleDblClk),
END_RESPONSE_TABLE;

//--------------------------------------------------------------------------//      Constructeur
//---------------------------------------------------------------------------

ChoixArchetypeDialog::ChoixArchetypeDialog(TWindow* pere, string* pChoix, NSContexte* pCtx)
                     :NSUtilDialog(pere, pCtx, "IDD_MODULES")
{
try
{
	//
	// Cr�ation des objets dialogues
	//
	pModulesBox     = new TListBox(this, IDC_MODU_LISTE);
	//
	// Initialisation des variables g�n�rales
	//
	pModulesArray   = new NSArchetypeArray;

	sArchetype      = "";
	pChoisi         = pChoix;
	iModuleChoisi   = -1 ;

  sHcorps					= "dpio_selecteur_exam.htm" ;
}
catch (...)
{
	erreur("ChoixCRDialog ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//      Destructeur
//---------------------------------------------------------------------------
ChoixArchetypeDialog::~ChoixArchetypeDialog()
{
	//
	// D�truit les objets de pilotage des dialogues
	//
	delete pModulesBox;
	delete pModulesArray;
}

//---------------------------------------------------------------------------
//  Description: Initialise la boite de liste des modules
//
//  Returns:	  Rien
//---------------------------------------------------------------------------
void
ChoixArchetypeDialog::SetupWindow()
{
	char    buffer[501] ;
	string  Chaine, sCode ;
    string  sFichierModules ;
	int     i, j ;

	TDialog::SetupWindow() ;

	sFichierModules = pContexte->PathName("FPER") + string("MODULEA.LUS") ;
	//
	// Ouverture du fichier des modules
	//
	ifstream inFile ;
	inFile.open(sFichierModules.c_str()) ;
	if (!inFile)
	{
		erreur("Erreur � l'ouverture du fichier des modules.", standardError, 0, GetHandle()) ;
		return ;
	}
	//
	// Lecture du fichier
	//
    string  sLang = "" ;
    if ((pContexte) && (pContexte->getUtilisateur()))
        sLang = pContexte->getUtilisateur()->donneLang() ;

    string  sString1 ;
    string  sString2 ;

    int     iNbArchetypes = 0 ;

	NSArchtypeInfo* pModule = new NSArchtypeInfo ;
	inFile.unsetf(ios::skipws) ;
    while (inFile.getline(buffer, 500))
	{
        pModule->sArchetype = "" ;
        pModule->sLibelle   = "" ;

        int iTailleBuf = strlen(buffer) ;
        //
        // Prise de l'Archetype
        //
        for (j = 0; (j < iTailleBuf) && (buffer[j] != ' ') && (buffer[j] != '\t'); j++)
            pModule->sArchetype += buffer[j] ;
        //
        for (; (j < iTailleBuf) && ((buffer[j] == ' ') || (buffer[j] == '\t')); j++);
        //
        // Prise du code du module
        //
        for (; (j < iTailleBuf); j++)
            pModule->sLibelle += buffer[j] ;
        //
        // Ajout du module � la liste
        //
        pModulesBox->AddString(pModule->sLibelle.c_str()) ;
        pModulesArray->push_back(new NSArchtypeInfo(*pModule)) ;

        iNbArchetypes++ ;
	}
	delete pModule ;
	inFile.close() ;

    if (iNbArchetypes == 1)
    {
        pModulesBox->SetSelIndex(0) ;
        iModuleChoisi = 1 ;
    }

	return ;
}

//---------------------------------------------------------------------------
//  Arguments :	    Cmd : WPARAM retourn� par Windows
//  Description :	S�lectionne un module et sort
//  Retour	: 		Rien
//---------------------------------------------------------------------------
void
ChoixArchetypeDialog::CmModuleDblClk(WPARAM Cmd)
{
	iModuleChoisi = pModulesBox->GetSelIndex() + 1 ;
	CmOk() ;
}

//---------------------------------------------------------------------------
//  Arguments :	    Cmd : WPARAM retourn� par Windows
//  Description :	S�lectionne un module
//  Retour	: 		Rien
//---------------------------------------------------------------------------
void
ChoixArchetypeDialog::CmSelectModule(WPARAM Cmd)
{
	//
	// R�cup�ration de l'indice de la chemise s�lectionn�e
	//
	iModuleChoisi = pModulesBox->GetSelIndex() + 1 ;
}

//---------------------------------------------------------------------------
//  Description :	Appelle CmOk si un module a �t� choisi
//  Retour	: 		Rien
//---------------------------------------------------------------------------
void ChoixArchetypeDialog::CmOk()
{
  if (iModuleChoisi <= 0)
  {
    erreur("Vous devez s�lectionner un Archetype.", warningError, 0, GetHandle()) ;
    return ;
  }

  int indice = iModuleChoisi - 1 ;

  //
  // On fixe les donn�es propres au module
  //
  sArchetype = (*pModulesArray)[indice]->sArchetype ;
  *pChoisi   = sArchetype ;

  //
  // On sort
  //
  TDialog::CmOk() ;
  return ;
}

//---------------------------------------------------------------------------
//  Function :		ChoixCRDialog::CmCancel()
//
//  Arguments :	Aucun
//
//  Description :	Annule ModuleChoisie et appelle Cancel()
//
//  Retour	: 		Rien
//---------------------------------------------------------------------------
void ChoixArchetypeDialog::CmCancel()
{
	iModuleChoisi   = -1 ;
    *pChoisi        = "" ;

	TDialog::CmCancel() ;
}
//***************************************************************************
//
// Impl�mentation des m�thodes NSModule
//
//***************************************************************************
//---------------------------------------------------------------------------//  Function:    NSModuleData::metAZero()
//
//  Description: Met � 0 les variables.
//---------------------------------------------------------------------------
void
NSModuleData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(code, 	0, MODU_CODE_LEN + 1);
	memset(lexique, 0, MODU_LEXIQUE_LEN + 1);
    memset(compte, 	0, MODU_COMPTE_LEN + 1);

   	libelle     = "";    sImportDll  = "";
}

//---------------------------------------------------------------------------
//  Function:    NSModuleData::metABlanc()
//
//  Description: Met � blanc les variables.
//---------------------------------------------------------------------------
void
NSModuleData::metABlanc()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(code, 	' ', MODU_CODE_LEN);
	memset(lexique, ' ', MODU_LEXIQUE_LEN);
    memset(compte, 	' ', MODU_COMPTE_LEN);

    libelle     = "";
    sImportDll  = "";
}

//---------------------------------------------------------------------------
//  Function:    NSModuleData::initialiseLibelle()
//
//  Description: Va chercher le libelle dans le lexique.
//---------------------------------------------------------------------------
void
NSModuleData::initialiseLibelle()
{
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSModuleData::NSModuleData(NSModuleData& rv)
{
	strcpy(code,	rv.code);
	strcpy(lexique, rv.lexique);
    strcpy(compte,  rv.compte);

    libelle     = rv.libelle;
    sImportDll  = rv.sImportDll;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSModuleData&
NSModuleData::operator=(NSModuleData src)
{
	strcpy(code,	src.code);
	strcpy(lexique, src.lexique);
    strcpy(compte,  src.compte);

    libelle     = src.libelle;
    sImportDll  = src.sImportDll;

	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSModuleData::operator==(const NSModuleData& o)
{
	 if ((strcmp(code,	  o.code)	 == 0) &&
         (strcmp(lexique, o.lexique) == 0))
		  return 1;
	 else
		  return 0;
}

//---------------------------------------------------------------------------
//  Constructeur par d�faut
//---------------------------------------------------------------------------
NSModuleInfo::NSModuleInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSModuleData();
}

//---------------------------------------------------------------------------
//  Destructeur.
//---------------------------------------------------------------------------
NSModuleInfo::~NSModuleInfo()
{
    // D�truit l'objet de donn�es
    delete pDonnees;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSModuleInfo::NSModuleInfo(NSModuleInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSModuleData();
	//
	// Initialise les donn�es � partir de celles de la source
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSModuleInfo& NSModuleInfo::operator=(NSModuleInfo src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

int NSModuleInfo::operator == ( const NSModuleInfo& o )
{
	 return (*pDonnees == *(o.pDonnees));
}

//***************************************************************************
// Impl�mentation des m�thodes NSModuleArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSModuleArray::NSModuleArray(NSModuleArray& rv)
              :NSModuInfoArray()
{
try
{
	if (rv.empty())
		return ;

	for (NSModuInfoArrayIter i = rv.begin(); i != rv.end(); i++)
  	push_back(new NSModuleInfo(*(*i))) ;
}
catch (...)
{
    erreur("Exception NSModuleArray copy ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  Vidange
//---------------------------------------------------------------------------
void
NSModuleArray::vider()
{
    if (empty())
        return;

	for (NSModuInfoArrayIter i = begin(); i != end(); )
    {
  		delete *i;
        erase(i);
    }
}

NSModuleArray::~NSModuleArray()
{
	vider();
}

//////////////////////////////////////////////////////////////////////////////

//---------------------------------------------------------------------------
//  Constructeur par d�faut
//---------------------------------------------------------------------------
NSArchtypeInfo::NSArchtypeInfo()
{
	sArchetype  = "";
    sLibelle    = "";
}

//---------------------------------------------------------------------------
//  Destructeur.
//---------------------------------------------------------------------------
NSArchtypeInfo::~NSArchtypeInfo()
{
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSArchtypeInfo::NSArchtypeInfo(NSArchtypeInfo& rv)
{
	sArchetype  = rv.sArchetype;
    sLibelle    = rv.sLibelle;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSArchtypeInfo& NSArchtypeInfo::operator=(NSArchtypeInfo src)
{
	sArchetype  = src.sArchetype;
    sLibelle    = src.sLibelle;

	return *this;
}

int NSArchtypeInfo::operator == ( const NSArchtypeInfo& o )
{
	 return ((sArchetype    == o.sArchetype) &&
             (sLibelle      == o.sLibelle));
}

//***************************************************************************
// Impl�mentation des m�thodes NSArchetypeArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSArchetypeArray::NSArchetypeArray(NSArchetypeArray& rv)
                 :NSArcheInfoArray()
{
try
{
	if (rv.empty())
  	return ;

	for (NSArchInfoArrayIter i = rv.begin(); i != rv.end(); i++)
  	push_back(new NSArchtypeInfo(*(*i))) ;
}
catch (...)
{
	erreur("Exception NSArchetypeArray copy ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  Vidange
//---------------------------------------------------------------------------
void
NSArchetypeArray::vider()
{
    if (empty())
        return;

	for (NSArchInfoArrayIter i = begin(); i != end(); )
    {
  		delete *i;
        erase(i);
    }
}

NSArchetypeArray::~NSArchetypeArray()
{
	vider();
}

