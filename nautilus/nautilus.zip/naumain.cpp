// -----------------------------------------------------------------------------
// naumain.cpp
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// $Revision: 1.164 $
// $Author: pameline $
// $Date: 2005/07/08 07:23:37 $
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Copyright Nautilus, 2001-2005
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � g�rer et traiter les
// informations de sant� d'une personne.
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to manage and process
// a person's health data.
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------

#include <ostream.h>
#include <checks.h>

#include "nautilus\EMail.h"
#include <owl\pch.h>
#include <owl\applicat.h>
#include <owl\decmdifr.h>

#include <owl\gdiobjec.h>
#include <owl\dialog.h>
#include <owl\controlb.h>
#include <owl\buttonga.h>
#include <owl\statusba.h>
#include <owl\docmanag.h>
#include <owl\docview.h>
#include <owl\olemdifr.h>
#include <owl\oleview.h>
#include <owl\oledoc.h>
#include <stdlib.h>
#include <string.h>
#include <bde.hpp>
#include <time.h>
#include <owl\printer.h>
#include <winuser.h>

#define __NAUTILUS_CPP

#include "nautilus\nautilus.h"
#include "nautilus\nssuper.h"
#include "nautilus\nsepicap.h"
#include "partage\nsglobal.h"
#include <owl\docview.rc>
#include <owl\mdi.rh>
#include "nautilus\nautilus.rh"
#include "nautilus\nsresour.h"
#include "nautilus\nsrechdl.h"
#include "nautilus\nsrechd2.h"
#include "partage\nsmatfic.h"

#include "nautilus\nsvisual.h"
#include "nautilus\nsttx.h"
#include "nautilus\nscsdoc.h"
#include "nautilus\nscsvue.h"
#include "nautilus\nscrvue.h"
#include "nautilus\nshistor.h"
#include "nautilus\nsadmiwd.h"
#include "nautilus\nsSOAPview.h"
#include "nscompta\nsagadlg.h"
#include "nscompta\nsnoemie.h"
#include "nscompta\nsdepens.h"
#include "nscompta\nsgendlg.h"
#include "nautilus\nsdocaga.h"
#include "nautilus\nsaddfunctions.h"
#include "nautilus\nscompub.h"
#include "nautilus\nspatdlg.h"
#include "nautilus\nsldvdoc.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsmanager.h"
#include "nsbb\nsdlg.h"
#include "nsbb\nsbbtran.h"
#include "nssavoir\nsgraphe.h"
#include "nsbb\nslistwind.h"
#include "nautilus\nsbrowseSvce.h"

//#include "nsoutil/nssmedit.h"
#include "nsoutil/nsoutdlg.h"
#include "nsoutil/nsepiout.h"
#include "nsoutil/nsfilgui.h"
#include "nsoutil/nsrechcr.h"
#include "nautilus/nsepisodview.h"
#include "nautilus/nscqvue.h"
#include "nautilus/nsldvvue.h"
#include "nautilus/nsldvvar.h"
#include "adopt.h"
#include "nsbb\nsdefArch.h"

#include "ns_ob1\nautilus-bbk.h"
#include "ns_ob1\BB1Task.h"
#include "ns_ob1\BB1Types.h"
#include "ns_ob1\InterfaceForKs.h"

#include "nautilus\EnumProc.h"
#include "nautilus\nsdocview.h"
#include "nautilus\nsdrugview.h"
#include "nautilus\nsgoalview.h"
#include "nautilus\nsprocessview.h"
#include "nautilus\nsFollowUpView.h"
#include "nautilus\nsrcview.h"
#include "nautilus\nsMailSvce.h"
#include "nautilus\nsTeamDocView.h"
#include "nautilus\nscqdoc.h"
#include "nsbb\nsPaneSplitter.h"
#include "nssavoir\nsHealthTeamInterface.h"
#include "nssavoir\GraphicHealthTeam.h"
#include "nsbb\logpass.h"
#include "nsbb\nsattvaltools.h"
#include "pilot\NautilusPilot.hpp"
#include "pilot\NSAgentTools.h"
#include "nsbb\tagNames.h"
#include "nsoutil\ns_arche.h"

#include <tlhelp32.h>
#include <vdmdbg.h>

#include <windows.h>

#define ID_CB2 750
#define ID_CB3 751

DEFINE_RESPONSE_TABLE1(TMyApp, OWL::TApplication)
  EV_OWLVIEW(dnCreate,                          EvNewView),
  EV_OWLVIEW(dnClose,                           EvCloseView),
  EV_WM_DROPFILES,
  EV_WM_HOTKEY,
  EV_COMMAND(CM_CREATDOC,                       CmCreatDoc),
  EV_COMMAND(CM_MODIFDOC,                       CmModifDoc),
  EV_COMMAND(CM_NEW_ENTETE,                     CmNewEnTete),
  EV_COMMAND(CM_MOD_ENTETE,                     CmModEnTete),
  EV_COMMAND(CM_MODIFCOR,                       CmModifCor),
  EV_COMMAND(CM_CREATCOR,                       CmCreatCor),
  EV_COMMAND(CM_HEALTHTEAM_ROSE,                CmHealthTeam),
  EV_COMMAND(CM_HEALTHTEAM_LIST,                CmHealthTeamList),
  EV_COMMAND(CM_IMPORT_PATIENT,                 CmImportPatientLdv),
  EV_COMMAND(CM_IMPORT_CORRESP,                 CmImportCorrespLdv),
	EV_COMMAND(CM_IMPORT_USER,                    CmImportUserLdv),
  EV_COMMAND(CM_NEWDOC,                         CmNewDoc),
  EV_COMMAND(CM_NEWPAT,                         CmNewPat),
  EV_COMMAND(CM_BUREAU,                         CmBureau),
  EV_COMMAND(CM_MAILBOX,                        CmMailBox),
  EV_COMMAND(CM_OUTILS,                         CmOutils),
  EV_COMMAND(CM_BBK,                            CmBBK),
  EV_COMMAND(CM_GROUPGD,                        CmGroupGd),
  EV_COMMAND(CM_REQUETE,                        CmRequete),
  EV_COMMAND(CM_RESULT,                         CmResult),
  EV_COMMAND(CM_SAUVEGARDE,                     CmSauvegarde),
  EV_COMMAND(CM_REFARCH,                        CmRefArchetype),
  EV_COMMAND(CM_REFEDIT,                        CmEditRef),
  EV_COMMAND(CM_ARCHEDIT,                       CmEditArchetype),
  EV_COMMAND(CM_TPLEDIT,                        CmEditTemplate),
  EV_COMMAND(CM_MATERIELS,                      CmMateriels),
  EV_COMMAND(CM_RECONVOC,                       CmReconvoquer),
  EV_COMMAND(CM_SET_RECONVOC,                   CmSetReconvocDate),
  EV_COMMAND(CM_ABOUT,                          CmAbout),
  EV_COMMAND(CM_CHEMISE,                        CmChemise),
  EV_COMMAND(CM_NEWTTXT,                        CmNewTtext),
  EV_COMMAND(CM_NEWTMPL,                        CmNewTmpl),
  EV_COMMAND(CM_OPENTTXT,                       CmOpenTtext),
  EV_COMMAND(CM_OPENTMPL,                       CmOpenTmpl),
  EV_COMMAND(CM_ENREG_WIN,                      CmEnregWin),
  EV_COMMAND(CM_NEWCR,                          CmNewCr),
  EV_COMMAND(CM_NEWCS,                          CmNewConsult),
  EV_COMMAND(CM_NEWCONSULT,                     CmNewTypedDoc),
  EV_COMMAND(CM_IMPORTE,                        CmImporter),
  EV_COMMAND(CM_IMPORTIMG,                      CmImportImg),
  EV_COMMAND(CM_IMPORT_HTML,                    CmImportHtml),
  EV_COMMAND(CM_IMPORT_PDF,                     CmImportPdf),
  EV_COMMAND(CM_CAPTUREIMG,                     CmCaptureImg),
  EV_COMMAND(CM_CAPTURETWAIN,                   CmCaptureTwain),
  EV_COMMAND(CM_PANNEL,                         CmGenerePannel),
  EV_COMMAND(CM_CVITALE,                        CmCarteVitale),
  EV_COMMAND(CM_CREATCOMPTA,                    CmFicheCompt),
  EV_COMMAND(CM_MODIFCOMPTA,                    CmSituation),
  EV_COMMAND(CM_AGA,                            CmAga),
  EV_COMMAND(CM_IMPAYES,                        CmImpayes),
  EV_COMMAND(CM_LISTACTES,                      CmListeActes),
  EV_COMMAND(CM_SOMACTES,                       CmSommeActes),
  EV_COMMAND(CM_SOMENCAISS,                     CmSommeEncaiss),
  EV_COMMAND(CM_SAISIETP,                       CmSaisieTP),
  EV_COMMAND(CM_FEUILLESOINS,                   CmFeuilleSecu),
  EV_COMMAND(CM_IMPORTNOEMIE,                   CmImportNoemie),
  EV_COMMAND(CM_RECETTE,                        CmRecettes),
  EV_COMMAND(CM_DEPENSE,                        CmDepenses),
  EV_COMMAND(CM_LISTRECETTES,                   CmListeRecettes),
  EV_COMMAND(CM_LISTDEPENSES,                   CmListeDepenses),
  EV_COMMAND(CM_2035,                           Cm2035),
  EV_COMMAND(CM_EXIT,                           CmExit),
  EV_COMMAND(CM_HELP,                           CmHelp),
  EV_COMMAND(CM_EPISO_START,                    CmEpisoStart),
  EV_COMMAND(CM_EPISO_STOP,                     CmEpisoStop),
  EV_COMMAND(CM_EPISO_LEARN,                    CmEpisoLearn),
  EV_COMMAND(CM_EPISO_MODELS,                   CmEpisoModels),
  EV_COMMAND(IDC_EPISOD_PHARE_ON,               IdcEpisodPhare),
  EV_COMMAND(IDC_EPISOD_PHARE_OFF,              IdcEpisodPhare),
  EV_COMMAND(CM_LDV,                            CmOpenLdV),
  EV_COMMAND(CM_LDV_DRUGS,                      CmOpenDrugs),
  EV_COMMAND(CM_PROCESS,                        CmOpenProcess),
  EV_COMMAND(CM_LDV_GOALS,                      CmOpenGoals),
  EV_COMMAND(CM_PROMET_MESSAGE,                 CmEpisodusBuildMessage),
  EV_COMMAND(CM_PROMET_SEND,                    CmEpisodusSendMessage),
  EV_COMMAND(CM_PROMET_SURF,                    CmEpisodusSurf),
  EV_COMMAND(CM_PROMET_SURF_PERS,               CmEpisodusSurfPerso),
  EV_COMMAND(CM_PREDI,                          CmPREDI),
  EV_COMMAND(CM_QUESTIONNAIRE,                  CmNewQuestionnaire),
  EV_COMMAND(CM_DIOGENE,                        CmDiogene),
  EV_COMMAND(CM_FUNCTION,                       CmFunctions),
  EV_COMMAND(CM_ADMIN,                          CmOpenAdmin),
  EV_COMMAND(CM_PARAM_PRINT,                    CmParamPrint),
  EV_COMMAND(CM_SYNCHRO_IMP_THIS_PAT,           CmSynchroImportThisPat),
  EV_COMMAND(CM_SYNCHRO_EXP_THIS_PAT,           CmSynchroExportThisPat),
	EV_COMMAND(CM_PILOT_AGENTS,                   CmPilotAgentsManagement),
  EV_COMMAND(CM_PARAM_UPDATE,                   CmParamUpdate),
//  EV_REGISTERED("Episodus Mouse Hook Message",  CmMouseHook),
END_RESPONSE_TABLE ;

// -----------------------------------------------------------------------------
// definition pour OB1
const string		 NULLSTRING	        = string("") ;
int							 NULLINT		        = 0 ;
Voidptr					 NULLPTR		        = NULL ;
NSPatPathoArray  *NULLPATHO         = (NSPatPathoArray *) NULL ;
PatPathoIter     *NULLPATPATHOITER  = (PatPathoIter *) NULL;
NautilusQuestion *NULLLNAUTQUEST    = (NautilusQuestion *) NULL ;
AnswerStatus     *NULLLANSWERSTATUS = (AnswerStatus *) NULL ;
PathsList		     *NULLPATHS         = (PathsList *) NULL ;
BB1Object				 *NULLOBJECT	      = (BB1Object *) NULL ;
NautilusEvent		 *NULLNAUTILUSEVENT	= (NautilusEvent *) NULL ;
// -----------------------------------------------------------------------------

TMyApp::TMyApp(NSContexte *pCtx)
       :OWL::TApplication("Episodus")
{
	// Object initialisation

	appContext = pCtx ;
  Client     = NULL ;

  frame      = 0 ;
  sb         = 0 ;
  cb         = 0 ;

  Harbor     = 0 ;
  cb1        = 0 ;
  cb2        = 0 ;
  cb3        = 0 ;

  hAccelerator = 0 ;

	// Get current directory as soon as possible
  initCurrentDir() ;

	// Splash window

	int SplashStyle = TSplashWindow::MakeStatic | TSplashWindow::MakeGauge |
                                                 TSplashWindow::CaptureMouse ;
	int timeOut = 0 ;

  pSplashDib    = new TDib("splash.bmp") ;
	pSplashWindow = new TSplashWindow(*pSplashDib, pSplashDib->Width(),
                                  pSplashDib->Height() + 100, SplashStyle, timeOut) ;

	pSplashWindow->Create() ;       // create the splash window
	pSplashWindow->UpdateWindow() ; // update the display to show the splash screen

	// Object initialisation

  sCurrentMenuName = string("") ;

  iCaptureHotKey = 0 ;
  iBabylonHotKey = 0 ;

	appContext->getSuperviseur()->setApplication(this) ;

  SetCmdShow(SW_MAXIMIZE) ;
  SetToolBarWindow(0) ;

  // register hotkey shortcut
  Word        Key ;
  TShiftState Shift ;

  // create the shortcut for the capture (shortcut : [CTRL] + <Espace>
  TShortCut myShortCut = ShortCut(Word(' '), TShiftState() << ssCtrl) ;
  ShortCutToKey(myShortCut, Key, Shift) ;
  Word Mods = 0 ;
  Mods = Mods | MOD_CONTROL ;
  RegisterHotKey(NULL, myShortCut, Mods, Key) ;
  iCaptureHotKey = myShortCut ;

  // create the shortcut for the capture (shortcut : [SHIFT] + <Espace>
  Mods = 0 ;
  TShortCut myShortCut2 = ShortCut(Word(' '), TShiftState() << ssShift) ;
  ShortCutToKey(myShortCut, Key, Shift) ;
  Mods = Mods | MOD_SHIFT ;
  RegisterHotKey(NULL, myShortCut2, Mods, Key) ;
  iBabylonHotKey = myShortCut2 ;
}


// -----------------------------------------------------------------------------
// destructeur
// -----------------------------------------------------------------------------
TMyApp::~TMyApp()
{
/*
  // --------
  // does anyone have a reason to not do it ?
  // if it is not used, it will not be in the code. .fab
  // --------
  NSSuper* pSuper = appContext->getSuperviseur() ;

	if (pSuper)
  {
		delete pSuper ;
    pSuper = 0 ;
  }

  if (appContext)
  {
		delete appContext ;
    appContext = 0 ;
  }
  // --------
*/

  // unregister hotkey shortcut
  Word        Key ;
  TShiftState Shift ;

  Word Mods = 0 ;
  ShortCutToKey(iCaptureHotKey, Key, Shift) ;
  Mods = Mods | MOD_CONTROL ;
  UnregisterHotKey(NULL, iCaptureHotKey) ;

  Mods = 0 ;
  ShortCutToKey(iBabylonHotKey, Key, Shift) ;
  Mods = Mods | MOD_SHIFT ;
  UnregisterHotKey(NULL, iBabylonHotKey) ;

  if (0 != hAccelerator)
  {
    DestroyAcceleratorTable(hAccelerator) ;
    hAccelerator = 0 ;
  }
}


void
TMyApp::InitMainWindow()
{
	sendMessageToSplash("Init main window") ;
  setSplashPercentDone(95) ;

  NSSuper* pSuper = appContext->getSuperviseur() ;

  string ps = string("TMyapp Init main window: Entering.") ;
  pSuper->trace(&ps, 1, NSSuper::trDetails) ;

  // HKEY hKeyResult;
  // cl� du programme Word.Basic dans HKEY_LOCAL_MACHINE
  // LPCTSTR lpszKey = _T("SOFTWARE\\CLASSES\\Word.Basic");

	// Si on est appel� en temps que serveur OLE, on ne cr�e pas la
	// fen�tre principale
	// if (GetRegistrar().IsOptionSet(TOcCmdLine::Embedding))

	// if (GetRegistrar().IsOptionSet(amEmbedding))
	// 	nCmdShow = SW_HIDE;

  // if (nCmdShow != SW_HIDE)
  //  nCmdShow = (nCmdShow != SW_SHOWMINNOACTIVE) ? SW_SHOWNORMAL : nCmdShow;

  string sNomModule = string("NAUTILUS") ;
  if (pSuper && (pSuper->getDPIO()) && (pSuper->getDPIO()->sNomModule != ""))
  {
    sNomModule = pSuper->getDPIO()->sNomModule ;
    if (pSuper->getDPIO()->sOEMModule != "")
      sNomModule += string("/") + pSuper->getDPIO()->sOEMModule ;
  }

	frame = new NSMDIFrame(appContext, sNomModule.c_str(), 0, *(Client = new NSMDIClient(this)), true, this) ;
	// frame->SetOcApp(OcApp) ;

  // frame->Attr.AccelTable = IDA_MDICMNDS ;

  frame->SetIcon(this, EPI_ICON1) ;
  frame->SetIconSm(this, EPI_ICON1) ;

  // pour les barres dockables
  Harbor = new THarborEx(*frame) ;

	// Construction de la barre de statut
	sb = new OWL::TStatusBar(frame, TGadget::Recessed) ;

	// Construction de la barre de contr�le
	cb1 = new TDockableControlBarEx(frame) ;

  /*
  cb1->Insert(*new TButtonGadget(CM_NEWDOC, 		CM_NEWDOC, 	 	TButtonGadget::Command)) ;
  cb1->Insert(*new TButtonGadget(CM_NEWPAT, 		CM_NEWPAT, 	 	TButtonGadget::Command)) ;
  cb1->Insert(*new TButtonGadget(CM_BUREAU, 		CM_BUREAU, 	 	TButtonGadget::Command)) ;
  cb1->Insert(*new TSeparatorGadget);
  cb1->Insert(*new TButtonGadget(CM_IMPORTE, 		CM_IMPORTE, 	TButtonGadget::Command)) ;
  cb1->Insert(*new TButtonGadget(CM_CHEMISE, 		CM_CHEMISE,  	TButtonGadget::Command)) ;
  cb1->Insert(*new TButtonGadget(CM_IMPORTIMG, 	CM_IMPORTIMG, TButtonGadget::Command)) ;

  DWORD   nBufferLength = 254 ; // size, in characters, of buffer
  char    szResult[255] ;	      // address of buffer for found filename
  LPTSTR  lpFilePart ;          // address of pointer to file component
  if (::SearchPath(NULL, "ns_grab", ".dll", nBufferLength, szResult, &lpFilePart))
    cb1->Insert(*new TButtonGadget(CM_CAPTUREIMG,   CM_CAPTUREIMG, 	TButtonGadget::Command)) ;

  cb1->Insert(*new TSeparatorGadget);
  cb1->Insert(*new TButtonGadget(CM_LDV, 		    CM_LDV,  	    TButtonGadget::Command)) ;
  cb1->Insert(*new TSeparatorGadget);
  cb1->Insert(*new TButtonGadget(CM_NEWTTXT, 		CM_NEWTTXT,  	TButtonGadget::Command)) ;

  // Insertion du bouton Word si Word.Basic existe dans la base de registre
  if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, lpszKey, (DWORD)0, KEY_READ, &hKeyResult) == ERROR_SUCCESS)
  	cb1->Insert(*new TButtonGadget(CM_NEWTMPL, 		CM_NEWTMPL, TButtonGadget::Command)) ;

  // Fonction d'appel des comptes-rendus pour le modele serveur OLE
  cb1->Insert(*new TButtonGadget(CM_NEWCR, 		  CM_NEWCR, 	 	TButtonGadget::Command)) ;
  cb1->Insert(*new TButtonGadget(CM_NEWCONSULT, CM_NEWCONSULT,TButtonGadget::Command)) ;
  cb1->Insert(*new TSeparatorGadget);
  cb1->Insert(*new TButtonGadget(CM_ENREGISTRE, CM_ENREGISTRE,TButtonGadget::Command)) ;
  cb1->Insert(*new TButtonGadget(CM_COMPOSE, 		CM_COMPOSE,  	TButtonGadget::Command)) ;
  cb1->Insert(*new TButtonGadget(CM_IMPRIME, 		CM_IMPRIME,  	TButtonGadget::Command)) ;
  cb1->Insert(*new TButtonGadget(CM_VISUAL, 		CM_VISUAL,  	TButtonGadget::Command)) ;
  cb1->Insert(*new TSeparatorGadget);
  cb1->Insert(*new TButtonGadget(CM_MAILBOX, 		CM_MAILBOX, 	TButtonGadget::Command)) ;
  cb1->Insert(*new TButtonGadget(CM_OUTILS, 		CM_OUTILS, 	 	TButtonGadget::Command)) ;
  cb1->Insert(*new TButtonGadget(CM_ABOUT, 		  CM_ABOUT, 	 	TButtonGadget::Command)) ;
  */
	cb1->SetHintMode(TGadgetWindow::EnterHints) ;

  cb2 = new TDockableControlBarEx(ID_CB2, "Secondaire", false, frame) ;

  // cb3 = new TDockableControlBarEx(ID_CB3, "Episodus", false, frame) ;
  // cb3->Insert(*new TButtonGadget(CM_EPISO_START, CM_EPISO_START, TButtonGadget::Command)) ;

  Harbor->Insert(*cb1, OWL::alTop) ;
  Harbor->Insert(*cb2, OWL::alTop) ;
  //Harbor->Insert(*cb3, OWL::alTop) ;

  // Insertion des barres (statut et contr�le)
  frame->Insert(*sb, TDecoratedFrame::Bottom) ;

	// D�finition de la fen�tre principale et de son menu
	SetMainWindow(frame) ;
  appContext->getSuperviseur()->pExeModule = GetMainWindow()->GetModule() ;

  // Initialization of all menus
  //
  initMenus() ;

  GetMainWindow()->Attr.Style |= WS_MAXIMIZE ;

	// Mise en place du gestionnaire de documents
	// SetDocManager(new TDocManager(dmMDI | dmMenu | dmNoRevert, this));
  SetDocManager(new TDocManager(dmMDI)) ;

	appContext->getSuperviseur()->setMainWindow(GetMainWindow()) ;

  sendMessageToSplash("Go") ;
  setSplashPercentDone(100) ;

  delete pSplashWindow ;
  pSplashWindow = 0 ;

  delete pSplashDib ;
  pSplashDib = 0 ;

  char szMain[20] ;
  sprintf(szMain, "%p", GetMainWindow()->HWindow) ;
  ps = string("TMyapp Init main window: Leaving (Main Window: ") + string(szMain) + string(")") ;
  pSuper->trace(&ps, 1, NSSuper::trDetails) ;
}

voidTMyApp::setMenu(string sMenuName, HACCEL far *hAccelerator){	string sNewMenuName = string("") ;	if (string("") == sMenuName)		sNewMenuName = sCurrentMenuName ;  else  	sNewMenuName = sMenuName ;  if (string("") == sNewMenuName)		return ;	nsMenuIniter menuIter(appContext) ;	OWL::TMenuDescr menuBar ;
  menuIter.initMenuDescr(&menuBar, sNewMenuName) ;
  GetMainWindow()->SetMenuDescr(menuBar) ;

  *hAccelerator = menuIter.getAccelerator() ;

  sCurrentMenuName = sNewMenuName ;
}// -----------------------------------------------------------------------------
// Met � 1 le fichier instance.dat (1�re instance du pgm)
// -----------------------------------------------------------------------------
bool
TMyApp::SetFirstInstance()
{
  ofstream    outFile ;
  string      sOut ;

  sOut = "1\n" ;

  // On �crit 1 dans le fichier instance.dat
  outFile.open("instance.dat") ;
  if (!outFile)
  {
  	// Make certain that error message won't be hidden by the splash screen
		//
  	HWND hWnd = 0 ;
    if (NULL != pSplashWindow)
    	hWnd = pSplashWindow->GetHandle() ;

    erreur("Erreur d'ouverture en �criture du fichier instance.dat.", standardError, 0, hWnd) ;
    return false ;
  }

  for (size_t i = 0 ; i < strlen(sOut.c_str()) ; i++)
    outFile.put(sOut[i]) ;

  outFile.close() ;
  return true ;
}

bool
TMyApp::GetNumInstance(int& numInst)
{
  ifstream inFile ;
  ofstream outFile ;
  string line ;
  string sFichierDat = "" ;
  string sInstance = "" ;
  char   cInstance[5] ;

  inFile.open("instance.dat") ;
  if (!inFile)
  {
    erreur("Erreur d'ouverture du fichier instance.dat.", standardError, 0) ;
    return false ;
  }

  while (!inFile.eof())
  {
    getline(inFile,line) ;
    if (line != "")
      sFichierDat += line + "\n" ;
  }
  inFile.close() ;

  // on r�cup�re le num�ro d'instance contenu dans le fichier
  for (size_t i = 0 ; (i < strlen(sFichierDat.c_str())) && (sFichierDat[i] != '\n') ; i++)
    sInstance += sFichierDat[i] ;

  numInst = atoi(sInstance.c_str()) + 1 ;

  sprintf(cInstance, "%d\n", numInst) ;
  sInstance = string(cInstance) ;

  // On �crit le nouveau num�ro d'instance dans le fichier instance.dat
  outFile.open("instance.dat") ;
  if (!outFile)
  {
    erreur("Erreur d'ouverture en �criture du fichier instance.dat.", standardError, 0) ;
    return false ;
  }

  for (size_t i = 0 ; i < strlen(sInstance.c_str()) ; i++)
    outFile.put(sInstance[i]) ;

  outFile.close() ;
  return true ;
}

void
TMyApp::InitInstance()
{
	bool bExit = false ;
	int  retVal ;

  // appel de InitMainWindow
	OWL::TApplication::InitInstance() ;

	// Cr�ation d'un mutex pour g�rer numInstance
	if (CreateMutex(NULL, TRUE, "NautilusMutex") == NULL)
	{
  	// Make certain that error message won't be hidden by the splash screen
		//
  	HWND hWnd = 0 ;
    if (NULL != pSplashWindow)
    	hWnd = pSplashWindow->GetHandle() ;
		erreur("Echec de la fonction CreateMutex.", standardError, 0, hWnd) ;
		appContext->getSuperviseur()->setInstance(0) ;
		bExit = true ;
	}
	else
	{
		if (GetLastError() != ERROR_ALREADY_EXISTS)
		{
			// on est dans la premi�re instance
			if (SetFirstInstance())
				appContext->getSuperviseur()->setInstance(1) ;
			else
			{
				appContext->getSuperviseur()->setInstance(0) ;
				bExit = true ;
			}
		}
		else
		{
    	int iInstance ;
      bool bGetInstance = GetNumInstance(iInstance) ;
			// instance n (n>1) on r�cup�re le num�ro et on l'incr�mente
			if (bGetInstance)
			{
      	appContext->getSuperviseur()->setInstance(iInstance) ;
				retVal = ::MessageBox(0, "Une session ant�rieure de Nautilus existe d�j�. Voulez-vous continuer ?", "Message Nautilus", MB_YESNO) ;
				if (retVal == IDNO)
					bExit = true ;
			}
			else
			{
				appContext->getSuperviseur()->setInstance(0) ;
				bExit = true ;
			}
		}
	}

	if (bExit) // pour sortir dans MessageLoop
		appContext->setUtilisateur(0) ;
	else
	{
		// Ctl3d DLL
		EnableCtl3d(true) ;
		// BWCC DLL
		EnableBWCC(true, 0xc) ;

		GetMainWindow()->DragAcceptFiles(true) ;

		if (appContext->getUtilisateur() == 0)
		{
			appContext->getSuperviseur()->setInitInstance(true) ;
			appContext->getSuperviseur()->ReferenceTousArchetypes() ;
      appContext->getSuperviseur()->ReferenceNewFilsGuides() ;
			appContext->getSuperviseur()->AppelUtilisateur() ;
		}

		NS_CLASSLIB::TRect rect ;
		cb1->GetRect(rect) ;
		Harbor->Move(*cb2, OWL::alTop, &NS_CLASSLIB::TPoint(rect.left + rect.Width(), rect.top)) ;
		cb2->GetRect(rect) ;
		// Harbor->Move(*cb3, OWL::alTop, &NS_CLASSLIB::TPoint(rect.left + rect.Width(), rect.top));

		// Initialisation du lexique et du r�seau s�mantique
		appContext->getDico()->Prend() ;
		appContext->getFilGuide()->Prend() ;
		appContext->getFilDecode()->Prend() ;
	}
}


bool
TMyApp::CanClose()
{
	if (GetMainWindow())
	{
		// on doit positionner bCanCloseHisto si un patient est ouvert
		// sinon l'historique emp�che le CloseChildren et CanClose renvoie false
		if (appContext->getPatient())
			if (!(appContext->getUtilisateur()->fermePatEnCours()))
				return false ;
		//pContexte->getPatient()->bCanCloseHisto = true;
		prendClient()->CloseChildren() ;
	}
	return OWL::TApplication::CanClose() ;
}


// -----------------------------------------------------------------------------
// MessageLoop : appel�e par Run apr�s InitInstance
// -----------------------------------------------------------------------------
int
TMyApp::MessageLoop()
{
	// test : si pas d'utilisateur => sort du programme
	if (appContext->getUtilisateur() == 0)
	{
		GetMainWindow()->CloseWindow() ;
		return 0 ;
	}

	// on d�truit les fichier tmp de perso (fichiers CR)
	if (appContext->getSuperviseur()->getInstance() == 1)
		DetruireFichiersTmp() ;

	return (OWL::TApplication::MessageLoop()) ;
}


void
TMyApp::DetruireFichiersTmp()
{
  WIN32_FIND_DATA FileData ;
  HANDLE          hSearch ;
  char            szMask[255] ;
  bool            bFinish = false ;
  size_t          pos ;
  string          sFileName, sExtension ;
  string          sPathName, sFile ;
  char            extension[255] ;
  DWORD           dwAttr ;

  sPathName = appContext->PathName("FPER") ;
  strcpy(szMask, sPathName.c_str()) ;
  strcat(szMask, "*.*") ;

  hSearch = FindFirstFile(szMask, &FileData) ;
  if (hSearch == INVALID_HANDLE_VALUE)
    return ;

  while (!bFinish)
  {
    dwAttr = FileData.dwFileAttributes ;

    if (!(dwAttr & FILE_ATTRIBUTE_DIRECTORY))
    {
      sFileName = string(FileData.cFileName) ;
      // R�cup�ration de l'extension
      pos = sFileName.find(".") ;
    }

    if ((!(dwAttr & FILE_ATTRIBUTE_DIRECTORY)) && (pos != string::npos))
    {
      sExtension = string(sFileName, pos + 1, strlen(sFileName.c_str()) - pos - 1) ;
      strcpy(extension, sExtension.c_str()) ;
      sExtension = string(strlwr(extension)) ;

      if (sExtension == "tmp")
      {
        sFile = sPathName + sFileName ;
        if (!DeleteFile(sFile.c_str()))
        {
          string sMsg = "Pb � la destruction du fichier temporaire " + sFileName ;
          erreur(sMsg.c_str(), standardError, 0) ;
        }
      }
    }

    if (!FindNextFile(hSearch, &FileData))
    {
      if (GetLastError() == ERROR_NO_MORE_FILES)
        bFinish = true ;
      else // impossible de trouver le fichier suivant : on sort quand m�me
        return ;
    }
  }
}


/*
void
TMyApp::RemoveNavBar()
{
	// on enl�ve les boutons de la control bar
  TGadget* pGadget = cbNav->FirstGadget() ;
  while (pGadget)
  {
   	cbNav->Remove(*pGadget) ;
    cbNav->LayoutSession() ;
    pGadget = cbNav->FirstGadget() ;
  }
}
*/


/*
void
TMyApp::InsertControlBar(TButtonGadget* pGadget)
{
	GadgetArray[nbGadget++] = pGadget ;
	cb->Insert(*pGadget) ;
  cb->LayoutSession() ;
}
*/


/*
void
TMyApp::InsertControlBar(TControlGadget* pGadget)
{
	GadgetArray[nbGadget++] = pGadget ;
	cb->Insert(*pGadget) ;
  cb->LayoutSession() ;
}
*/


/*
void
TMyApp::InsertControlBar(TSeparatorGadget* pGadget)
{
	GadgetArray[nbGadget++] = pGadget ;
	cb->Insert(*pGadget) ;
  cb->LayoutSession() ;
}
*/


// -----------------------------------------------------------------------------
// capture by hotkey
// -----------------------------------------------------------------------------
void
TMyApp::EvHotKey(int idHotKey)
{
  if (idHotKey == iCaptureHotKey)
  {
    NSEpisodus* pEpisod = appContext->getSuperviseur()->getEpisodus() ;
    // update mouse cursor position
    GetCursorPos(pEpisod->getPMousePoint()) ;
    // update information

    HWND hMainWnd = (HWND) GetMainWindow() ;

    OSVERSIONINFO osVer ;
    osVer.dwOSVersionInfoSize = sizeof(OSVERSIONINFO) ;
    GetVersionEx(&osVer) ;

    // Mise d'Episodus au premier plan
    // ::SystemParametersInfo(SPI_SETFOREGROUNDLOCKTIMEOUT, 0, (LPVOID)0, SPIF_SENDWININICHANGE | SPIF_UPDATEINIFILE) ;

    if (osVer.dwMajorVersion < 5)
      ::SetForegroundWindow(hMainWnd) ;
    else
      GetMainWindow()->FlashWindow(TRUE) ;

    pEpisod->Capture(hMainWnd) ;
  }
  else if (idHotKey == iBabylonHotKey)
  {
    NSEpisodus* pEpisod = appContext->getSuperviseur()->getEpisodus() ;
    // update mouse cursor position
    GetCursorPos(pEpisod->getPMousePoint()) ;
    // update information
    pEpisod->CaptureBabylon((HWND) GetMainWindow()) ;
  }
}


void
TMyApp::EvDropFiles(TDropInfo dropInfo)
{
	// si pas d'utilisateur ou pas de patient en cours : on sort
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;

	int fileCount = dropInfo.DragQueryFileCount() ;
	for (int index = 0 ; index < fileCount ; index++)
	{
		int fileLength = dropInfo.DragQueryFileNameLen(index) + 1 ;
		char* filePath = new char [fileLength] ;
		dropInfo.DragQueryFile(index, filePath, fileLength) ;

		appContext->getPatient()->Importer(filePath) ;

		// TDocTemplate* tpl = GetDocManager()->MatchTemplate(filePath);
		// if (tpl)
		// 	tpl->CreateDoc(filePath);

		delete[] filePath ;
		filePath = 0 ;
	}
	dropInfo.DragFinish() ;
}


bool
MyConditionChild(TWindow* pWind, void* pCreate)
{
  //NSMUEView* pCr = TYPESAFE_DOWNCAST(&pCreate, NSMUEView) ;
  NSMDIChild* pChild = TYPESAFE_DOWNCAST(pWind, NSMDIChild) ;
  if (pChild)
    if (pChild->getCreateWindow()== pCreate)
      return true ;
  return false ;
}


void
TMyApp::EvNewView(TView& view)
{
try
{
	char nomVue[80] ;
	NS_CLASSLIB::TRect zone ;

	// Dans la version serveur OLE, il faut d�terminer quelle est la
	// fen�tre parent (diff�rent lorsqu'il est utilis� in situ - serveur
	// dans son conteneur - ou appel� d'une autre application)
	/********************************************************
	TOleView* ov = TYPESAFE_DOWNCAST(&view, TOleView);
	if (view.GetDocument().IsEmbedded() && ov && !ov->IsOpenEditing())
	{
		TWindow* vw = view.GetWindow() ;
		vw->SetParent(TYPESAFE_DOWNCAST(GetMainWindow(), TOleFrame)->GetRemViewBucket()) ;
		vw->Create() ;
	}
	else
	{
    TMDIChild* child = new TMDIChild(*Client, 0) ;
    if (view.GetViewMenu())
    {
      child->SetMenuDescr(*view.GetViewMenu()) ;
    }

    // on r�cup�re le nom de la vue � cr�er
    strcpy(nomVue, view.GetViewName()) ;

    child->Create() ;
    child->SetClientWindow(view.GetWindow()) ;
    child->GetClientRect(zone) ;
	}
  if (!ov || !ov->GetOcRemView())
    OcApp->SetOption(amEmbedding, false) ;
  **********************************************************/

	bool bSplitted  = false ;

	NSMDIChild*      child  = 0 ;
  NSCQWindowsView* pCQVue = 0 ;

	// NSMUEVIEW : fen�tre contenue dans un NSPaneSplitter
	// NSMUEVIEW : windows made to be part of a NSPaneSplitter
	NSMUEView* pMUEView = TYPESAFE_DOWNCAST(&view, NSMUEView) ;
	if (pMUEView)
	{
    // Premi�re fen�tre � s'ouvrir : il faut cr�er le NSPaneSplitter
    // First window of a group : it means we have to create the NSPaneSplitter
    if (pMUEView->getCreateWindow() == NULL)
    {
      NSMDIChildContent* pChildContent = new NSMDIChildContent(appContext, Client) ;

      NSPaneSplitter* pPanelSplitter = new NSPaneSplitter(appContext, pChildContent) ;
      // si le style de la fenetre ne contient pas les butoons OK, Cancel
      // on n'affiche pas la fenetre gadget avec les buttons
    	NSGadgetWindow*  pGadgetWnd = new NSGadgetWindow (pChildContent, pMUEView->uButtonsStyle) ;
    	pGadgetWnd->setPaneSplitter(pPanelSplitter) ;
/*
      if (pMUEView->uButtonsStyle != 0x00000000L)
        pGadgetWnd = new NSGadgetWindow (pPanelSplitter, true) ;
      else
        pGadgetWnd = new NSGadgetWindow (pPanelSplitter, false) ;
*/
			pPanelSplitter->pGadgetPanelWindow = pGadgetWnd ;

      pChildContent->setSplitter(pPanelSplitter) ;
			pChildContent->setToolBar(pGadgetWnd) ;

      // child = new NSMDIChild(appContext, *Client, 0, pPanelSplitter) ;
      child = new NSMDIChild(appContext, *Client, 0, pChildContent) ;
      pPanelSplitter->pMDIChild = (TMDIChild*)child ;
      // child->split((TWindow*)pGadgetWnd, 0, psNone, 0.50) ;

      // TGadgetControl* pControl = new TGadgetControl(pGadgetWnd) ;
      pMUEView->setPaneSplitter(pPanelSplitter) ;

      pCQVue = TYPESAFE_DOWNCAST(&view, NSCQWindowsView) ;
      if (pCQVue)
        child->setCreateWindow(pCQVue) ;
      else
        child->setCreateWindow(pMUEView) ;
    }

    // Fen�tre qui vient compl�ter un groupe
    // Window that comes as a complementary window of a group
    else
    {
      TWindow *winClient = Client->FirstThat(MyConditionChild,(void *)pMUEView->getCreateWindow()) ;
      if (winClient)
      {
        NSMDIChild* child = TYPESAFE_DOWNCAST(winClient, NSMDIChild) ;
        if (child)
        {
          NSMUEView* wndMother = TYPESAFE_DOWNCAST(pMUEView->getSplittedWindow(), NSMUEView) ;
          if (wndMother)
          {
            //pContexte->getSuperviseur()->pNSApplication->prendClient()
            NSSplittingWindowProperty *pSplitProp = appContext->getUtilisateur()->aWinProp.searchProperty(wndMother->getFunction(), pMUEView->getFunction()) ;
            if (pSplitProp)
            {
              pMUEView->setPercent(pSplitProp->getPercent()) ;
              pMUEView->setSplitDirection(pSplitProp->getSplitDirection()) ;
            }

            child->split(pMUEView->getSplittedWindow(),pMUEView, pMUEView->getSplitDirection(),pMUEView->getPercent()) ;
            pMUEView->setPaneSplitter(wndMother->getPaneSplitter()) ;
            bSplitted = true ;
          }
        }
      }
    }
  }

  // En cas de fen�tre compl�mentaire d'un NSPaneSplitter, le travail est fini
  // In case of a NSPaneSplitter complementary window, work is done
  if (bSplitted)
    return ;

  if (!child)
    child = new NSMDIChild(appContext, *Client, 0, view.GetWindow(), false) ;

  // Mise en place des icones
  NSCsVue* pview = TYPESAFE_DOWNCAST(&view, NSCsVue) ;
  if (pview)
  {
    child->SetIconSm(this, CS_ICON_CS) ;
  }
  else
	{
    NSCRReadOnlyView* pview = TYPESAFE_DOWNCAST(&view, NSCRReadOnlyView) ;
    if (pview)
    {
      child->SetIconSm(this, CR_ICON_CS) ;
    }
    else
    {
      NSTtxView* pview = TYPESAFE_DOWNCAST(&view, NSTtxView) ;
      if (pview)
      {
        child->SetIcon(this, TTX_ICON) ;
        child->SetIconSm(this, TTX_ICON_CS) ;
      }
      else
      {
        NsHistorique* pview = TYPESAFE_DOWNCAST(&view, NsHistorique) ;
        if (pview)
        {
          child->SetIconSm(this, HIST_ICON_CS) ;
        }
        else
        {
          NSVisualView* pview = TYPESAFE_DOWNCAST(&view, NSVisualView) ;
          if (pview)
          {
            child->SetIconSm(this, HTM_ICON_CS) ;
          }
          else
          {
            NSAutoWordView* pView = TYPESAFE_DOWNCAST(&view, NSAutoWordView) ;
            if (pView)
            {
              child->SetIconSm(this, WRD_ICON_CS) ;
            }
            else
            {
              NSEpisodView* pView = TYPESAFE_DOWNCAST(&view, NSEpisodView) ;
              if (pView)
              {
                child->SetIconSm(this, WRD_ICON_CS) ;
              }
              else
              {
                NSCQWindowsView* pView = TYPESAFE_DOWNCAST(&view, NSCQWindowsView) ;
                if (pView)
                {
                  child->SetIconSm(this, CQ_ICON_CS) ;
                }
              }
            }
          }
        }
      }
    }
  }

  if (view.GetViewMenu())
    child->SetMenuDescr(*view.GetViewMenu()) ;

  // on r�cup�re le nom de la vue � cr�er
  strcpy(nomVue, view.GetViewName()) ;

  string ps = string("EvNewView, avant child->create") ;
  appContext->getSuperviseur()->trace(&ps, 1) ;

/*
  if (pCQVue)
  {
    if (!pCQVue->clientWin)
    {
      delete child ;
      return ;
    }

    char far szTitle[256] ;
    int res = pCQVue->clientWin->GetWindowText(szTitle, 255) ;
    if (!res)
      strcpy(szTitle, "Archetype") ;
    //pCQVue->pDoc->SetTitle(szTitle);
  }

  if (pCQVue)
    child->initClient(pCQVue->clientWin) ;
*/

  // if (pCQVue)
  //  child->initClientArchetype(pCQVue) ;

  child->Create() ;

  char szChild[20] ;
  sprintf(szChild, "%p", child->HWindow) ;
  ps = string("EvNewView: NSMDIChild created (") + string(szChild) + string(").") ;
  appContext->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

  // Si la NSMDIChild n'a pas de NSPaneSplitter, on a fini
  // Si the NSMDIChild has no NSPaneSplitter, we are done
  if (!child->getCreateWindow())
    return ;
  if(!pMUEView->getPaneSplitter())
    return ;

  NSGadgetWindow* pGadgetWind = pMUEView->getPaneSplitter()->pGadgetPanelWindow ;
  if(!pGadgetWind)
    return ;

	// start modif 21/03/07
	pMUEView->setGadgetPanelWindow(pGadgetWind) ;
/*
  child->split(pGadgetWind, 0, psNone, 0.50) ;
  if (pMUEView->uButtonsStyle == 0)
    child->split(pGadgetWind, child->getCreateWindow(), psHorizontal, 0.001) ;
  else
    child->split(pGadgetWind, child->getCreateWindow(), psHorizontal, 0.08) ;
*/
	child->split(child->getCreateWindow(), 0, psNone, 0.50) ;
	// end modif 21/03/07

  child->getCreateWindow()->SetFocus() ;

  ps = string("EvNewView, apr�s child->create") ;
  appContext->getSuperviseur()->trace(&ps, 1) ;

  if ((NULL == pCQVue) && (pMUEView))
  {
    TWindow *wndCr = child->getCreateWindow() ;
    NSMUEView* wndCreate = TYPESAFE_DOWNCAST(wndCr, NSMUEView) ;
    NSWindowProperty *pWinProp = appContext->getUtilisateur()->aWinProp.getProperty(wndCreate->getFunction()) ;
    if (pWinProp)
    {
    	// Warning : if application is iconic, then GetWindowRect returns
      //           fake informations (-3000, -3500...)
    	if (!(appContext->GetMainWindow()->IsZoomed()))
    		child->MoveWindow(pWinProp->X(), pWinProp->Y(), pWinProp->W(), pWinProp->H(), true) ;
      else
      {
      	NS_CLASSLIB::TRect  clientRect, rectWnd ;
      	Client->GetWindowRect(clientRect) ;
      	rectWnd.left = pWinProp->X() - clientRect.left ;
      	rectWnd.top = pWinProp->Y() - clientRect.top ;
      	child->MoveWindow(rectWnd.left , rectWnd.top, pWinProp->W(), pWinProp->H(), true) ;
      	// string sFunction = pWinProp->sFunction ;
      }
    }
  }

  // cas des vues formulaire : on redimentionne la fenetre
  if (pCQVue)
  {
    ps = string("EvNewView de NSCQVue, d�but du traitement sp�cifique") ;
    appContext->getSuperviseur()->trace(&ps, 1) ;

    // ?? pCQVue->SetParent((TWindow *)child) ;
    bool bMovingCQVue = false ;

    if (pCQVue->getFunction() != "")
    {
      // copier/coller nscsvue pour "Synthesis"
      // fixer la nouvelle position
      // (on ne tient pas compte de la taille, vu le probleme pour restaurer
      // une fenetre TView, TWindow mise en icone)
      NSWindowProperty *pWinProp = appContext->getUtilisateur()->aWinProp.getProperty(pCQVue->getFunction()) ;
      if (pWinProp)
      {
      	/*
        NS_CLASSLIB::TRect  clientRect, rectWnd ;
        Client->GetWindowRect(clientRect) ;
        rectWnd.top = pWinProp->iX - clientRect.left ;
        rectWnd.left = pWinProp->iY - clientRect.top ;
        child->MoveWindow(rectWnd.top , rectWnd.left, pWinProp->iW, pWinProp->iH, true) ;
        */
        child->MoveWindow(pWinProp->X(), pWinProp->Y(), pWinProp->W(), pWinProp->H(), true) ;
        bMovingCQVue = true ;
      }
    }

    if (!bMovingCQVue)
    {
      NS_CLASSLIB::TRect winRect, cliRect ;
      child->GetWindowRect(winRect) ;
      child->GetClientRect(cliRect) ;

      // ATTENTION : contrairement � ce que dit l'aide en ligne, les coordonn�es X, Y
      // dans MoveWindow sont relatives � la zone client de la fenetre Parent (ici la MainWindow)
      // On positionne donc ici les formulaires, au d�part, dans le coin sup�rieur gauche
      // (� cause de la taille des dialogues � afficher)

      int newWidth  = (pCQVue->dlgRect).Width() + (winRect.Width() - cliRect.Width()) ;
      int newHeight = (pCQVue->dlgRect).Height() + (winRect.Height() - cliRect.Height()) ;

      ps = string("EvNewView de NSCQVue, MoveWindow") ;
      appContext->getSuperviseur()->trace(&ps, 1) ;

      child->MoveWindow(0, 0, newWidth, newHeight, true) ;
    }

    if (pCQVue->pDoc->iTypeDoc == NSCQDocument::dpio)
    {
      NSDPIO* pDPIO = appContext->getSuperviseur()->getDPIO() ;
      if (pDPIO)
      {
        char far szTitle[256];
        // pCQVue->clientWin->GetWindowText(szTitle, 255) ;
        pCQVue->GetWindow()->GetWindowText(szTitle, 255) ;

        ps = string("EvNewView de NSCQVue, r�f�rencement du formulaire ") + string(szTitle) ;
        appContext->getSuperviseur()->trace(&ps, 1) ;

        pDPIO->referenceFormulaire((TWindow*)child, szTitle) ;
      }
    }

    ps = string("EvNewView de NSCQVue, fin du traitement sp�cifique") ;
    appContext->getSuperviseur()->trace(&ps, 1) ;
  }

  // on cr�e les fen�tres compl�mentaires cette fen�tre
  // we now create the complementary windows for this window
  if ((pMUEView))
  {
    NSMUEView* pMotherWind ;
    NSPaneSplitter* pPanelSplitter = pMUEView->getPaneSplitter() ;
    if (pPanelSplitter && (pMUEView->getFunction() != ""))
    {
      VecteurString VectChildFct ;
      pPanelSplitter->researchChildWindFonction(pMUEView->getFunction(), &VectChildFct) ;
      if (VectChildFct.empty())
        return ;

      for (EquiItemIter iterChilds = VectChildFct.begin() ; iterChilds != VectChildFct.end() ; iterChilds++)
      {
        pMotherWind = pPanelSplitter->researchMotherWindow((**iterChilds), pMUEView->getFunction()) ;
        if (pMotherWind)
          pMotherWind->newWindow((**iterChilds)) ;
      }

      if (pPanelSplitter->pCurrentFocusedView)
        pPanelSplitter->pCurrentFocusedView->focusView() ;
    }
  }
}
catch (...)
{
  erreur("Exception TMyApp::EvNewView.", standardError, 0) ;
}
}


void
TMyApp::EvCloseView(TView& /*view*/)
{
	// Rien � faire ici en MDI
}


void
TMyApp::Tempo(double s)
{
  time_t time1, time2 ;

  time(&time1) ;
  do
    time(&time2) ;
  while (difftime(time2, time1) < s) ;
}


void
TMyApp::CmMailBox()
{
	if (appContext->pMailBoxChild != NULL)
	{
  	SetFocus(appContext->pMailBoxChild->GetHandle()) ;
		return ;
	}

	appContext->pMailBoxWindow = new NSMailServiceWindow(appContext, GetMainWindow()) ;
	appContext->pMailBoxChild  = new NSMailServiceChild(appContext, *(prendClient()), "", appContext->pMailBoxWindow) ;
	appContext->pMailBoxChild->Create() ;

/*
	TMailBox*	    pMailBox ;
	NSMailParams* pm ;

	if (!appContext->getUtilisateur()->initMail())
	{
		erreur("Impossible d'ouvrir la boite aux lettres Nautilus.", standardError, 0) ;
		return ;
	}

	pm = appContext->getUtilisateur()->pMail ;
	pMailBox = new TMailBox(NULL, pm->sUrlPOP3, pm->iPortPOP3, pm->sUserPOP3, pm->sPassPOP3, appContext) ;
	pMailBox->Show() ;
*/
}


void
TMyApp::CmOutils()
{
try
{
	string sModuleName = string("") ;

	NsOutilDialog* pNsOutilDialog = new NsOutilDialog(appContext->GetMainWindow(), appContext, &sModuleName) ;
	int idRet = pNsOutilDialog->Execute() ;
  delete pNsOutilDialog ;

  if ((idRet != IDOK) || (sModuleName == string("")))
		return ;

  TModule* pDCModule = new TModule(sModuleName.c_str(), TRUE) ;

  if (!pDCModule)
  {
  	string sErrorMsg = string("Impossible to open DLL ") +  sModuleName ;
    erreur(sErrorMsg.c_str(), standardError, 0) ;
    return ;
  }

  void (FAR *pAdresseFct) (TWindow far *, NSContexte far *) ;

  // R�cup�ration du pointeur sur la fonction // Getting function's pointer
  // (FARPROC) pAdresseFct = pDCModule->GetProcAddress(MAKEINTRESOURCE(2)) ;
  (FARPROC) pAdresseFct = pDCModule->GetProcAddress("@nsmToolsAction$qp11OWL@TWindowp10NSContexte") ;
  if (pAdresseFct == NULL)
  {
  	delete pDCModule ;
    return ;
  }

  ((*pAdresseFct)((TWindow far *) appContext->GetMainWindow(), (NSContexte far *) appContext)) ;

  // delete pDCModule ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception TMyApp::CmOutils : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
	erreur("Exception TMyApp::CmOutils.", standardError, 0) ;
}
}


void
TMyApp::CmBBK()
{
  BB1BBInterface* pOB1 = appContext->getSuperviseur()->getBBinterface() ;
  if (NULL != pOB1)
    pOB1->MaskBB(false) ;

 //	NSBBKDlg *pBBKDialog = new NSBBKDlg(pContexte->GetMainWindow(), pContexte) ;
 //	pBBKDialog->Execute() ;
}


void
TMyApp::CmGroupGd()
{
try
{
	NSGroupGdDialog* pGroupGdDialog = new NSGroupGdDialog(appContext->GetMainWindow(), appContext) ;
	pGroupGdDialog->Execute() ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception TMyApp::CmGroupGd : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
	erreur("Exception TMyApp::CmGroupGd.", standardError, 0) ;
}
}


void
TMyApp::CmRequete()
{
	if (appContext->getUtilisateur() != 0)
		appContext->getUtilisateur()->CmRequete() ;
}


void
TMyApp::CmResult()
{
	if (appContext->getUtilisateur() != 0)
		appContext->getUtilisateur()->CmResult() ;
}


void
TMyApp::CmSauvegarde()
{
/************************************************
  // cr�ation de l'�quipe m�dicale locale
  NSMoralPerson *pMPTeam = new NSMoralPerson(appContext, "", "Equipe m�dicale locale", "") ;
  pMPTeam->createTree() ;
  NSMoralPersonManager *pMPManager = new NSMoralPersonManager(pMPTeam) ;
  delete pMPTeam ;

  NSPersonsAttributesArray *pAttsList = new NSPersonsAttributesArray() ;

  const char *serviceName = (NautilusPilot::SERV_SEARCH_PERSON).c_str() ;
  NSBasicAttributeArray *pAttrArray = new NSBasicAttributeArray() ;
  pAttrArray->push_back(new NSBasicAttribute(ROLE, USER_ROLE)) ;
  bool bListOk = appContext->pPilot->personList(serviceName, pAttsList, pAttrArray) ;
  delete pAttrArray ;

  if ((bListOk) && (!(pAttsList->empty())))
  {
    for (NSPersonsAttributeIter iterPerson = pAttsList->begin() ; iterPerson != pAttsList->end() ; iterPerson++)
    {
      string sUserID = (*iterPerson)->getAttributeValue(PIDS) ;
      NVLdVTemps	ldvCurDate ;	ldvCurDate.takeTime() ;
      NVLdVTemps	ldvNoLimit ;  ldvNoLimit.setNoLimit() ;

      NSHTMMandateArray *pMandatesArray = new NSHTMMandateArray() ;
      pMandatesArray->push_back(new NSHealthTeamMandate(nearDist, 3, "", "", ldvCurDate.donneDateHeure(), ldvNoLimit.donneDateHeure(), "", "", NSHealthTeamMandate::user)) ;
      pMPManager->addMember(new NSHealthTeamMember(sUserID, NSHealthTeamMember::person, pMandatesArray), NSHealthTeamMember::person) ;
      delete pMandatesArray ;
    }
  }
  delete pAttsList ;

  NSTeamGraphManager* pTeamManager = new NSTeamGraphManager(appContext) ;
  if (pTeamManager->setTeamGraph(pMPManager->getPatho(), appContext->getUtilisateurID(), true))
  {
    MessageBox(NULL, "La cr�ation de l'�quipe m�dicale a r�ussi", "Cr�ation de l'Equipe M�dicale locale", MB_OK) ;
  }

***********************************************/


/*
 CSVParser *csvParser = new CSVParser("c:\\stucture12_2004.csv", ';', '\0') ;
 bool bReturn = csvParser->run(pContexte) ;
 delete csvParser ;
*/
}


void
TMyApp::CmEditRef()
{
try
{
	ArchetypesListDialog* pListArchDlg = new ArchetypesListDialog(appContext->GetMainWindow(), appContext, NSArcManager::referentiel) ;
	pListArchDlg->Execute() ;
  delete pListArchDlg ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmEditRef : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmEditRef.", standardError, 0) ;
}
}

void
TMyApp::CmEditArchetype()
{
try
{
	ArchetypesListDialog* pListArchDlg = new ArchetypesListDialog(appContext->GetMainWindow(), appContext, NSArcManager::archetype) ;
	pListArchDlg->Execute() ;
  delete pListArchDlg ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmEditArchetype : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmEditArchetype.", standardError, 0) ;
}
}


void
TMyApp::CmEditTemplate()
{
	// if (appContext->getUtilisateur() != 0)
	//	appContext->getUtilisateur()->CmEditTemplate() ;

  NSTemplateWindow* pTplWindow = new NSTemplateWindow(appContext, GetMainWindow()) ;
  TMDIChild*        pMdiChild  = new TMDIChild(*(OWL::TMDIClient*)prendClient(), "", pTplWindow) ;
	pMdiChild->Create() ;
}


void
TMyApp::CmRefArchetype()
{
	if (appContext->getUtilisateur() != 0)
		appContext->getUtilisateur()->CmRefArchetype() ;
}


void
TMyApp::CmPREDI()
{
/*
  BB1Order* temp = new BB1Order(NOBEEP,std::string("") ,std::string("")) ;
  appContext->getSuperviseur()->bbkToDo(appContext, 0, "BB1Order", "", "", temp, true, NULL, false) ;
  TypedVal& typ("Init") ;
  AskDeterministicQuestion *DPIOMessage = new AskDeterministicQuestion("Lance la boite de dialogue", &typ, 10) ;
  appContext->getSuperviseur()->bbkToDo(appContext, 0, "AskDeterministicQuestion", "", "", DPIOMessage, true, NULL, false) ;
*/

	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;

	appContext->getSuperviseur()->getBBinterface()->addNautilusEvent(std::string("GPRED")) ;
}


void
TMyApp::CmNewQuestionnaire()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmNewArchetype() ;
}


void
TMyApp::CmMateriels()
{
try
{
	ListeMaterielDialog* pListeMatDlg = new ListeMaterielDialog(appContext->GetMainWindow(), appContext) ;
	pListeMatDlg->Execute() ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmMateriels : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmMateriels.", standardError, 0) ;
}
}


void
TMyApp::CmReconvoquer()
{
  NSDateConvocDialog* pDateDlg = new NSDateConvocDialog(appContext->GetMainWindow(), appContext) ;
  int idRet = pDateDlg->Execute() ;
  if (idRet == IDOK)
  {
    NSVarConvoc* pVarConvoc = new NSVarConvoc(appContext, pDateDlg->sDate1, pDateDlg->sDate2) ;
    NSListeConvocDialog* pListeDlg = new NSListeConvocDialog(appContext->GetMainWindow(), appContext, pVarConvoc) ;
    pListeDlg->Execute() ;
    if (pListeDlg->bImprimerListe)
    {
      NSVoidArray* pVarArray = new NSVoidArray ;
      pVarArray->push_back((void*)(&(pVarConvoc->sDate1))) ;
      pVarArray->push_back((void*)(&(pVarConvoc->sDate2))) ;
      pVarArray->push_back((void*)(&(pVarConvoc->aPatientArray))) ;
      NSPubliRefDocument* pDocPubli = new NSPubliRefDocument(pVarArray, "ZPCVC", appContext) ;
      pDocPubli->Publier(false) ;
    }
    else if (pListeDlg->bImprimerLettre)
    {
      int index ;

      // on instancie le document convoc (lettre de reconvocation)
      NSConvocRefDocument* pDocConvoc = new NSConvocRefDocument(pVarConvoc, pListeDlg->pTabSelect, pListeDlg->nbConvoc, appContext) ;

      // on pr�pare l'objet de publication du document
      pDocConvoc->pPubli = new NSPublication(0, pDocConvoc, appContext) ;

      // on instancie � la main un tableau de correspondants fictifs
      // qui correspondent � la liste des patients � reconvoquer
      for (int i = 0 ; i < pListeDlg->nbConvoc ; i++)
      {
        if (i < MAXSELECT)
        {
        	NSPersonInfo PatInfo(appContext) ;

          // on r�cup�re l'indice du patient � reconvoquer
          index = pListeDlg->pTabSelect[i] ;
          PatInfo = *(pVarConvoc->aPatientArray[index]) ;

          pDocConvoc->pPubli->aCorrespBaseArray.push_back(new NSPersonInfo(PatInfo)) ;

          // on remplit �galement la structure de s�lection aChoixPubli
          // sprintf(pDocConvoc->pPubli->aChoixPubli[i].corresp, "%03d", i) ;
          strcpy(pDocConvoc->pPubli->aChoixPubli[i].corresp, PatInfo.getNss().c_str()) ;
          pDocConvoc->pPubli->aChoixPubli[i].select = true ;
          pDocConvoc->pPubli->aChoixPubli[i].imprimante = true ;
          strcpy(pDocConvoc->pPubli->aChoixPubli[i].nb_expl, "1") ;
          pDocConvoc->pPubli->aChoixPubli[i].cpt = 1 ;
          strcpy(pDocConvoc->pPubli->aChoixPubli[i].url, "") ;
          pDocConvoc->pPubli->aChoixPubli[i].email = false ;
          pDocConvoc->pPubli->aChoixPubli[i].intranet = false ;
          pDocConvoc->pPubli->aChoixPubli[i].html = false ;
          pDocConvoc->pPubli->aChoixPubli[i].lettre = false ;
        }
        else
        {
          erreur("Le nombre de patients � reconvoquer d�passe le maximum des publications.", standardError, 0) ;
          break ;
        }
      }

      // on lance la publication proprement dite
      pDocConvoc->pPubli->Publication() ;
    }
    delete pListeDlg ;
    delete pVarConvoc ;
  }

  delete pDateDlg;
}

void
TMyApp::CmSetReconvocDate()
{
	if (NULL == appContext->getPatient())
		return ;

	NSLdvDocument *pDocLdv = appContext->getPatient()->pDocLdv ;
  if (NULL == pDocLdv)
		return ;

	NSLdvDocument::LDVSERVICESERROR result = pDocLdv->NewAppointmentService(0) ;
}

void
TMyApp::CmAbout()
{
try
{
	AboutDialog(&TWindow(GetMainWindow()->GetCommandTarget()), appContext).Execute() ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmAbout : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmAbout.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Cr�ation d'un utilisateur
// -----------------------------------------------------------------------------
void
TMyApp::CmCreatDoc()
{
  if (appContext->getUtilisateur() != 0)
  {
    if (!appContext->getUtilisateur()->isAdmin())
    {
      erreur("Cette fonction est accessible uniquement � l'administrateur.", standardError, 0) ;
      return ;
    }
	 	if (!appContext->getUtilisateur()->Creer(appContext->GetMainWindow()))
      erreur("Erreur � la cr�ation d'un nouvel utilisateur", standardError, 0) ;
  }
}


// -----------------------------------------------------------------------------
// Modification d'un utilisateur
// -----------------------------------------------------------------------------
void
TMyApp::CmModifDoc()
{
  if (appContext->getUtilisateur() != 0)
  {
    if (appContext->getUtilisateur()->isAdmin())
    {
      if (!appContext->getUtilisateur()->ModifierAutreUtilisateur(appContext->GetMainWindow()))
        erreur("Erreur � la modification d'un nouvel utilisateur", standardError, 0) ;
      return;
    }
    if (!appContext->getUtilisateur()->Modifier(appContext->GetMainWindow()))
      erreur("Erreur � la modification d'un nouvel utilisateur", standardError, 0) ;
  }
}


void
TMyApp::CmNewEnTete()
{
	if (appContext->getUtilisateur() != 0)
		appContext->getUtilisateur()->CmNewEnTete() ;
}


void
TMyApp::CmModEnTete()
{
	if (appContext->getUtilisateur() != 0)
		appContext->getUtilisateur()->CmModEnTete() ;
}


void
TMyApp::CmCreatCor()
{
#ifndef N_TIERS
  NSCorrespondant* pCorresp = new NSCorrespondant(appContext) ;
  pCorresp->lastError = pCorresp->open() ;
  if (pCorresp->lastError != DBIERR_NONE)
  {
    erreur("Erreur � l'ouverture du fichier Corresp.db", 0, pCorresp->lastError) ;
    delete pCorresp ;
    return ;
  }

  bool creatOK = pCorresp->Creer(appContext->GetMainWindow()) ;
  pCorresp->lastError = pCorresp->close() ;
  if (pCorresp->lastError != DBIERR_NONE)
  {
    erreur("Erreur � la fermeture du fichier Corresp.db", 0, pCorresp->lastError) ;
    delete pCorresp ;
    return ;
  }

  delete pCorresp ;
#else
  /* NSPersonInfo *pPersonInfo = */ appContext->getPersonArray()->createPerson(pidsCorresp) ;
#endif // N_TIERS
}


void
TMyApp::CmModifCor()
{
  NSTPersonListDialog indep(GetMainWindow(), pidsCorresp, false, appContext) ;
  if (indep.Execute() == IDOK)
  {
    if (indep.bCreer)
    {
      /* NSPersonInfo	*pPersonInfo = */ appContext->getPersonArray()->createPerson(pidsCorresp) ;
    }
    else
    {
      NSPersonInfo *temp = indep.pPersonSelect ;
      string sPids  = temp->sPersonID ;
      string sRoles = temp->sRoles ;
      appContext->getPersonArray()->modifyPerson(sPids, sRoles, pidsCorresp) ;
    }
  }
}

void
TMyApp::CmHealthTeam()
{
	if (appContext->getPatient() == 0)
  	return ;

	appContext->getPatient()->heathTeamRosaceShow() ;

/*
 GraphicHealthTeam* health = new GraphicHealthTeam(GetMainWindow(), appContext, appContext->getPatient()->pHealthTeam) ;
 health->Execute() ;
 delete health ;
*/
}

void
TMyApp::CmHealthTeamList()
{
	if (appContext->getPatient() == 0)
  	return ;

  appContext->getPatient()->heathTeamListShow() ;
}

void
TMyApp::CmImportPatientLdv()
{
	// si pas d'utilisateur en cours : on sort
	if (appContext->getUtilisateur() == 0)
		return ;
  //if(!pContexte->pPilot->testServiceStatus(NautilusPilot::SERV_PATIENT_IMPORT))
	if(!appContext->pPilot->isOperationalLdVAgent())
  {
   //	appContext->pPilot->detailError(NautilusPilot::SERV_PATIENT_IMPORT) ;
   	if(!appContext->pPilot->traitError(NSAgentStatus::LdV))
    		return ;
  }
	appContext->getUtilisateur()->importPatientLdv() ;
}

void
TMyApp::CmImportUserLdv()
{
  // only on administrator can create a user
	if ((appContext->getUtilisateur() == 0) || (!(appContext->getUtilisateur()->isAdmin())))
  {
		string sErrMsg = appContext->getSuperviseur()->getText("globalMessages", "administratorRightsNeeded") ;
    erreur(sErrMsg.c_str(), warningError, 0) ;
	}

  if(!appContext->pPilot->isOperationalLdVAgent())
  {
   	if(!appContext->pPilot->traitError(NSAgentStatus::LdV))
    		return ;
  }
	appContext->getUtilisateur()->importUserLdv() ;
}


void
TMyApp::CmImportCorrespLdv()
{
	// si pas d'utilisateur en cours : on sort
	if (appContext->getUtilisateur() == 0)
		return ;

  if(!appContext->pPilot->isOperationalLdVAgent())
  {
   	if(!appContext->pPilot->traitError(NSAgentStatus::LdV))
    		return ;
  }
	appContext->getUtilisateur()->importCorrespLdv() ;
}

void
TMyApp::CmNewDoc()
{
  if ((appContext->getSuperviseur()) && (appContext->getSuperviseur()->getEpisodus()))
    appContext->getSuperviseur()->getEpisodus()->resetCaptureArray() ;

	appContext->getSuperviseur()->AppelUtilisateur() ;
	if (appContext->getUtilisateur() == 0)
    GetMainWindow()->CloseWindow() ;
}


void TMyApp::CmNewPat()
{
  if ((appContext->getSuperviseur()) && (appContext->getSuperviseur()->getEpisodus()))
    appContext->getSuperviseur()->getEpisodus()->resetCaptureArray() ;

  if (appContext->getUtilisateur() != 0)
  {
    if (!appContext->getUtilisateur()->isUser())
    {
    	string sErrMsg = appContext->getSuperviseur()->getText("globalMessages", "userOnlyFunction") ;
      erreur(sErrMsg.c_str(), standardError, 0) ;
      return ;
    }
		appContext->getUtilisateur()->AppelPatient() ;
  }
}


void
TMyApp::CmBureau()
{
  if (appContext->getUtilisateur() != 0)
  {
    int retVal = ::MessageBox(appContext->GetMainWindow()->GetHandle(), "Voulez-vous vraiment fermer le patient en cours ?", "Message Nautilus", MB_YESNO) ;
    if (retVal == IDYES)
    {
      if ((appContext->getSuperviseur()) && (appContext->getSuperviseur()->getEpisodus()))
        appContext->getSuperviseur()->getEpisodus()->resetCaptureArray() ;
      appContext->getUtilisateur()->fermePatEnCours();
    }
  }
}


void
TMyApp::CmOpenLdV()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->LdV_show() ;
}


void
TMyApp::CmOpenDrugs()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->drugs_show() ;
}


void
TMyApp::CmOpenProcess()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->process_show() ;
}


void
TMyApp::CmOpenGoals()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->goals_show() ;
}


void
TMyApp::CmEpisodusBuildMessage()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;

	NSEpisodus* pEpisodus = appContext->getSuperviseur()->getEpisodus() ;
  if (pEpisodus)
    pEpisodus->appendPrometheFile() ;
}


void
TMyApp::CmEpisodusSendMessage()
{
	if (appContext->getUtilisateur() == 0)
		return ;

	NSEpisodus* pEpisodus = appContext->getSuperviseur()->getEpisodus() ;
  if (pEpisodus)
    pEpisodus->sendPrometheMessage() ;
}


void
TMyApp::CmDiogene()
{
  NSDPIO* pDPIO = appContext->getSuperviseur()->getDPIO() ;
  if (pDPIO)
    pDPIO->sendMessage() ;
}


void
TMyApp::CmEpisodusSurf()
{
	if (appContext->getUtilisateur() == 0)
		return ;

	NSEpisodus* pEpisodus = appContext->getSuperviseur()->getEpisodus() ;
  if ((pEpisodus) && (pEpisodus->sPrometheURL != ""))
    appContext->getSuperviseur()->NavigationEncyclopedie(pEpisodus->sPrometheURL, appContext) ;
}


void
TMyApp::CmEpisodusSurfPerso()
{
	if (appContext->getUtilisateur() == 0)
		return ;

	NSEpisodus* pEpisodus = appContext->getSuperviseur()->getEpisodus() ;
  if ((pEpisodus) && (pEpisodus->sPrometheURL != ""))
    appContext->getSuperviseur()->NavigationEncyclopedie(pEpisodus->sPrometheURL, appContext) ;
}


void
TMyApp::CmChemise()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmChemise() ;
}


// -----------------------------------------------------------------------------
// lancement RichEdit Nautilus
// -----------------------------------------------------------------------------
void
TMyApp::CmNewTtext()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmNewTTxt() ;
}


// -----------------------------------------------------------------------------
// lancement Word
// -----------------------------------------------------------------------------
void
TMyApp::CmNewTmpl()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmNewTmpl() ;
}


// -----------------------------------------------------------------------------
// ouverture fichier RichEdit Nautilus
// -----------------------------------------------------------------------------
void
TMyApp::CmOpenTtext()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmOpenTTxt() ;
}


// -----------------------------------------------------------------------------
// ouverture fichier Word
// -----------------------------------------------------------------------------
void
TMyApp::CmOpenTmpl()
{
  if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
    return ;
	appContext->getPatient()->CmOpenTmpl() ;
}


// -----------------------------------------------------------------------------
// pour enregistrer la position des fenetres
// -----------------------------------------------------------------------------
void
TMyApp::CmEnregWin()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;

  appContext->getUtilisateur()->bEnregWin = true ;
	::MessageBox(appContext->GetMainWindow()->GetHandle(), "La position actuelle des fen�tres sera enregistr�e � la fermeture du patient.", "Message Nautilus", MB_OK) ;
}


void
TMyApp::CmImporter()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmImporter() ;
}


void
TMyApp::CmImportImg()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmImportImg() ;
}

void
TMyApp::CmCaptureImg()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmAssistCapture() ;
}

void
TMyApp::CmCaptureTwain()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmTwainCapture() ;
}

void
TMyApp::CmImportPdf()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmOpenPdf() ;
}

void
TMyApp::CmImportHtml()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmOpenHtml() ;
}

void
TMyApp::CmGenerePannel()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmGenerePannel() ;
}


void
TMyApp::CmNewCr()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmNewCr() ;
}


void
TMyApp::CmNewConsult()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmNewConsult() ;
}


void
TMyApp::CmNewTypedDoc()
{
	if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
		return ;
	appContext->getPatient()->CmNewConsult(false) ;
}


void
TMyApp::CmNewMagic()
{
  // fonction libre pour l'instant
}


void
TMyApp::CmCarteVitale()
{
	if (appContext->getUtilisateur() == 0)
    return ;

	if (appContext->getPatient() == 0)
  {
    erreur("Vous devez choisir un patient", standardError, 0) ;
    return ;
  }

  // NSComptaPatient* pCompta = new NSComptaPatient(appContext, (NSPatInfo *)appContext->getPatient()) ;
  NSPersonInfo personInfo(appContext, appContext->getPatient()->getNss()) ;
  NSComptaPatient* pCompta = new NSComptaPatient(appContext, &personInfo) ;

  pCompta->CmCarteVitale() ;
  delete pCompta ;
}


void
TMyApp::CmOpenAdmin()
{
	if (appContext->getPatient() == 0)
  {
    erreur("Vous devez choisir un patient", standardError, 0) ;
    return ;
  }
  appContext->getPatient()->admin_show() ;
}


void
TMyApp::CmFicheCompt()
{
	if (appContext->getUtilisateur() == 0)
    return ;

	if (appContext->getPatient() == 0)
  {
    erreur("Vous devez choisir un patient", standardError, 0) ;
    return ;
  }

  // NSComptaPatient* pCompta = new NSComptaPatient(appContext, (NSPatInfo *)appContext->getPatient()) ;
  NSPersonInfo personInfo(appContext, appContext->getPatient()->getNss()) ;
  NSComptaPatient* pCompta = new NSComptaPatient(appContext, &personInfo) ;

  pCompta->CmFicheCompt() ;
  delete pCompta ;
}


void
TMyApp::CmSituation()
{
  if (appContext->getUtilisateur() == 0)
    return ;

  if (appContext->getPatient() == 0)
  {
    erreur("Vous devez choisir un patient", standardError, 0) ;
    return ;
  }

  // NSComptaPatient* pCompta = new NSComptaPatient(appContext, (NSPatInfo *)appContext->getPatient()) ;
  NSPersonInfo personInfo(appContext, appContext->getPatient()->getNss()) ;
  NSComptaPatient* pCompta = new NSComptaPatient(appContext, &personInfo) ;

  pCompta->CmSituation() ;
  delete pCompta ;
}


void
TMyApp::CmAga()
{
try
{
  NSCriteres*	pCriteres = new NSCriteres() ;

	if (appContext->getUtilisateur() == 0)
  {
    delete pCriteres ;
    return ;
  }

  // on lance d'abord le dialogue des crit�res
  NSCritAgaDialog* pCritAgaDlg = new NSCritAgaDialog(appContext->GetMainWindow(), appContext) ;
  if (pCritAgaDlg->Execute() != IDOK)
  {
    delete pCritAgaDlg ;
    delete pCriteres ;
    return ;
  }

  *pCriteres = *(pCritAgaDlg->pCriteres) ;
  delete pCritAgaDlg ;

  while (pCriteres->sDateAga1 <= pCriteres->sDateAga2)
  {
    // on doit instancier et ouvrir un NSAgaDocument...
    NSAgaDocument* pAgaDoc = new NSAgaDocument(0, appContext) ;

    if (!pAgaDoc->Open(pCriteres))
    {
      erreur("Impossible d'ouvrir le document AGA", standardError, 0, appContext->GetMainWindow()->GetHandle()) ;
      delete pAgaDoc ;
      break ;
    }

    // Note : on n'affiche plus la MessageBox dans le cas nbAga == 0
    if (pAgaDoc->nbAga > 0)
    {
      NSListAgaDialog* pListAgaDlg = new NSListAgaDialog(appContext->GetMainWindow(), appContext, pAgaDoc) ;
      if (pListAgaDlg->Execute() == IDCANCEL)
      {
        pAgaDoc->Close() ;
        delete pAgaDoc ;
        break ;
      }

      if (pAgaDoc->bImprimer)
      {
        // On ne fait pas de delete du document compta car NSVisualView le fait en fin d'impression
        appContext->getUtilisateur()->pDocCompta->pAgaRefDoc = new NSAgaRefDocument(pAgaDoc) ;
        appContext->getUtilisateur()->pDocCompta->pAgaRefDoc->Publier(false) ;
      }
      delete pListAgaDlg ;
    }
    pAgaDoc->Close() ;
    delete pAgaDoc ;
    incremente_date(pCriteres->sDateAga1) ;
  }

  ::MessageBox(appContext->GetMainWindow()->GetHandle(), "Liste des AGA termin�e.", "Message Nautilus", MB_OK) ;
  delete pCriteres ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmAga : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmAga.", standardError, 0) ;
}
}


void
TMyApp::CmImpayes()
{
try
{
	if (appContext->getUtilisateur() == 0)
   		return ;

	// on doit instancier et ouvrir un NSImpDocument...
  NSImpDocument ImpDoc(0, appContext) ;
  if (!ImpDoc.Open())
    return ;

  NSListImpDialog* pListImpDlg = new NSListImpDialog(appContext->GetMainWindow(), appContext, &ImpDoc) ;
  pListImpDlg->Execute() ;

  if (ImpDoc.bImprimer)
  {
    // On ne fait pas de delete du document compta car NSVisualView le fait en fin d'impression
    appContext->getUtilisateur()->pDocCompta->pImpRefDoc = new NSImpRefDocument(&ImpDoc);
    appContext->getUtilisateur()->pDocCompta->pImpRefDoc->Publier(false);
  }

  ImpDoc.Close() ;
  delete pListImpDlg;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmImpayes : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmImpayes.", standardError, 0) ;
}
}


void
TMyApp::CmListeActes()
{
try
{
	if (appContext->getUtilisateur() == 0)
    return ;

	// on doit instancier et ouvrir un NSActDocument...
  NSActDocument ActDoc(0, appContext) ;
  if (!ActDoc.Open())
    return ;

  NSListActDialog* pListActDlg = new NSListActDialog(appContext->GetMainWindow(), appContext, &ActDoc) ;
  pListActDlg->Execute() ;
  if (ActDoc.bImprimer)
  {
    // On ne fait pas de delete du document compta car NSVisualView le fait en fin d'impression
    appContext->getUtilisateur()->pDocCompta->pListActRefDoc = new NSListActRefDocument(&ActDoc) ;
    appContext->getUtilisateur()->pDocCompta->pListActRefDoc->Publier(false) ;
  }

  ActDoc.Close() ;
  delete pListActDlg ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmListeActes : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmListeActes.", standardError, 0) ;
}
}


void
TMyApp::CmSommeActes()
{
try
{
	if (appContext->getUtilisateur() == 0)
    return ;

	// on doit instancier et ouvrir un NSActDocument...
  NSActDocument ActDoc(0, appContext) ;
  if (!ActDoc.Open(1))
    return ;

  NSSomActDialog* pSomActDlg = new NSSomActDialog(appContext->GetMainWindow(), appContext, &ActDoc) ;
  pSomActDlg->Execute() ;
  if (ActDoc.bImprimer)
  {
    // On ne fait pas de delete du document compta car NSVisualView le fait en fin d'impression
    appContext->getUtilisateur()->pDocCompta->pSomActRefDoc = new NSSomActRefDocument(&ActDoc) ;
    appContext->getUtilisateur()->pDocCompta->pSomActRefDoc->Publier(false) ;
  }
  ActDoc.Close() ;
  delete pSomActDlg ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmSommeActes() : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmSommeActes().", standardError, 0) ;
}
}


void
TMyApp::CmSommeEncaiss()
{
try
{
	if (appContext->getUtilisateur() == 0)
    return ;

	// on doit instancier et ouvrir un NSEncaissDocument...
  NSEncaissDocument EncaissDoc(0, appContext) ;
  if (!EncaissDoc.Open())
    return ;

  NSSomEncaissDialog* pSomEncaissDlg = new NSSomEncaissDialog(appContext->GetMainWindow(), appContext, &EncaissDoc) ;
  pSomEncaissDlg->Execute() ;
  if (EncaissDoc.bImprimer)
  {
    // On ne fait pas de delete du document compta car NSVisualView le fait en fin d'impression
    appContext->getUtilisateur()->pDocCompta->pSomEncaissRefDoc = new NSSomEncaissRefDocument(&EncaissDoc) ;
    appContext->getUtilisateur()->pDocCompta->pSomEncaissRefDoc->Publier(false) ;
  }
  EncaissDoc.Close() ;
  delete pSomEncaissDlg ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmSommeEncaiss() : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmSommeEncaiss().", standardError, 0) ;
}
}


void
TMyApp::CmSaisieTP()
{
try
{
	if (appContext->getUtilisateur() == 0)
    return ;

  NSSaisieTPDialog* pSaisieTPDlg = new NSSaisieTPDialog(appContext->GetMainWindow(), appContext) ;
  pSaisieTPDlg->Execute() ;
  delete pSaisieTPDlg ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmSaisieTP() : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmSaisieTP().", standardError, 0) ;
}
}


void
TMyApp::CmFeuilleSecu()
{
  if ((appContext->getUtilisateur() == 0) || (appContext->getPatient() == 0))
    return ;
	appContext->getPatient()->CmFeuilleSecu() ;
}


void
TMyApp::CmImportNoemie()
{
try
{
  NSNoemie* pImportNoemieDlg = new NSNoemie(appContext->GetMainWindow(), appContext) ;
  pImportNoemieDlg->Execute() ;
  delete pImportNoemieDlg ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmImportNoemie : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmImportNoemie.", standardError, 0) ;
}
}


void
TMyApp::CmRecettes()
{
try
{
  NSRecettesDlg* pRecettesDlg = new NSRecettesDlg(appContext->GetMainWindow(), appContext) ;
  pRecettesDlg->Execute() ;
  delete pRecettesDlg ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmRecettes : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmRecettes.", standardError, 0) ;
}
}


void
TMyApp::CmDepenses()
{
try
{
  NSDepensDlg* pDepensesDlg = new NSDepensDlg(appContext->GetMainWindow(), appContext) ;
  pDepensesDlg->Execute() ;
  delete pDepensesDlg ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmDepenses : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmDepenses.", standardError, 0) ;
}
}


void
TMyApp::CmListeRecettes()
{
try
{
	if (appContext->getUtilisateur() == 0)
    return ;

  // on lance d'abord le dialogue des crit�res
  NSCritAgaDialog* pCritAgaDlg = new NSCritAgaDialog(appContext->GetMainWindow(), appContext) ;
  if (pCritAgaDlg->Execute() != IDOK)
  {
    delete pCritAgaDlg ;
    return ;
  }

  NSCriteres Criteres = *(pCritAgaDlg->pCriteres) ;
  delete pCritAgaDlg;

  // on doit instancier et ouvrir un NSAgaDocument...
  NSAgaDocument AgaDoc(0, appContext) ;
  if (!AgaDoc.Open(&Criteres, true))
  {
    erreur("Impossible d'ouvrir le document AGA", standardError, 0, appContext->GetMainWindow()->GetHandle()) ;
    return ;
  }

  if (AgaDoc.nbAga > 0)
  {
    NSListAgaDialog* pListAgaDlg = new NSListAgaDialog(appContext->GetMainWindow(), appContext, &AgaDoc) ;
    if (pListAgaDlg->Execute() == IDCANCEL)
    {
      AgaDoc.Close() ;
      delete pListAgaDlg ;
      return ;
    }

    if (AgaDoc.bImprimer)
    {
      // On ne fait pas de delete du document compta car NSVisualView le fait en fin d'impression
      appContext->getUtilisateur()->pDocCompta->pAgaRefDoc = new NSAgaRefDocument(&AgaDoc) ;
      appContext->getUtilisateur()->pDocCompta->pAgaRefDoc->Publier(false) ;
    }
    delete pListAgaDlg ;
  }
  else
    ::MessageBox(appContext->GetMainWindow()->GetHandle(), "Aucune recette ne correspond � la p�riode choisie.", "Message Nautilus", MB_OK) ;

  AgaDoc.Close() ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmListeRecettes : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmListeRecettes.", standardError, 0) ;
}
}


void
TMyApp::CmListeDepenses()
{
try
{
	if (appContext->getUtilisateur() == 0)
    return ;

  // on lance d'abord le dialogue des crit�res
  NSCritAgaDialog* pCritAgaDlg = new NSCritAgaDialog(appContext->GetMainWindow(), appContext) ;
  if (pCritAgaDlg->Execute() != IDOK)
  {
    delete pCritAgaDlg ;
    return ;
  }

  NSCriteres Criteres = *(pCritAgaDlg->pCriteres) ;
  delete pCritAgaDlg ;

  // on doit instancier et ouvrir un NSDepensDocument...
  NSDepensDocument DepDoc(0, appContext) ;
  if (!DepDoc.Open(&Criteres))
  {
    erreur("Impossible d'ouvrir le document des d�penses", standardError, 0, appContext->GetMainWindow()->GetHandle()) ;
    return ;
  }

  if (DepDoc.nbDepens > 0)
  {
    NSListDepensDialog* pListDepDlg = new NSListDepensDialog(appContext->GetMainWindow(), appContext, &DepDoc) ;
    if (pListDepDlg->Execute() == IDCANCEL)
    {
      DepDoc.Close() ;
      delete pListDepDlg ;
      return ;
    }

    if (DepDoc.bImprimer)
    {
      // On ne fait pas de delete du document compta car NSVisualView le fait en fin d'impression
      appContext->getUtilisateur()->pDocCompta->pDepRefDoc = new NSDepRefDocument(&DepDoc) ;
      appContext->getUtilisateur()->pDocCompta->pDepRefDoc->Publier(false) ;
    }
    delete pListDepDlg ;
  }
  else
    ::MessageBox(appContext->GetMainWindow()->GetHandle(), "Aucune d�pense ne correspond � la p�riode choisie.", "Message Nautilus", MB_OK) ;

  DepDoc.Close() ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmListeDepenses : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmListeDepenses.", standardError, 0) ;
}
}


void
TMyApp::Cm2035()
{
try
{
  if (appContext->getUtilisateur() == 0)
    return ;

  NSAnnee2035Dialog* pAnneeDlg = new NSAnnee2035Dialog(appContext->GetMainWindow(), appContext) ;
  if (pAnneeDlg->Execute() == IDOK)
  {
    string sAnnee2035 = pAnneeDlg->sAnnee ;
    if ((sAnnee2035 != "") && (strlen(sAnnee2035.c_str()) == 4))
    {
      NS2035Dialog* pDlg = new NS2035Dialog(appContext->GetMainWindow(), appContext, sAnnee2035) ;
      pDlg->Execute() ;
      delete pDlg ;
    }
    else
    {
      erreur("La date saisie n'est pas correcte.", standardError, 0) ;
    }
  }
  delete pAnneeDlg ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::Cm2035 : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::Cm2035.", standardError, 0) ;
}
}

void
TMyApp::CmExit()
{
  // cas de fermeture historique (autre cas : fermePatEnCours dans nschoisi.cpp)
  // on v�rifie que le patient existe si on l'a d�j� ferm� ...
  if (appContext->getPatient())
    appContext->getPatient()->bCanCloseHisto = true ;
  if (prendClient()->CloseChildren())
    GetMainWindow()->CloseWindow() ;
}

void
TMyApp::CmHelp()
{
  if (appContext->getSuperviseur())
  {
    appContext->getSuperviseur()->setAideIndex("") ;
    appContext->getSuperviseur()->setAideCorps("home.htm") ;
    appContext->NavigationAideEnLigne() ;
  }
}

// -----------------------------------------------------------------------------
//
// Episodus
//
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// lance Episodus
// -----------------------------------------------------------------------------
void
TMyApp::CmEpisoStart()
{
try
{
  NSEmailFile* pMailCfg = new NSEmailFile(appContext) ;
  pMailCfg->Lancer() ;
  delete pMailCfg ;
  return ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmEpisoStart : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmEpisoStart.", standardError, 0) ;
}
/*
  // v�rifier �tat de Episodus
  // appContext->getSuperviseur()->pEpisodus->SetStateOn(true) ;

  appContext->getSuperviseur()->pEpisodus->ImportModels() ;
  appContext->getSuperviseur()->pEpisodus->SetMouseHookState(true) ;

  appContext->getSuperviseur()->pEpisodus->lanceHook() ;

  FlushEpisodusControlBar() ;
  cb3->Insert(*new TButtonGadget(CM_EPISO_STOP, CM_EPISO_STOP, TButtonGadget::Command)) ;
  cb3->Insert(*new TButtonGadget(CM_EPISO_LEARN, CM_EPISO_LEARN, TButtonGadget::Command)) ;
  cb3->Insert(*new TButtonGadget(IDC_EPISOD_PHARE_OFF, IDC_EPISOD_PHARE_OFF, TButtonGadget::Command)) ;
  cb3->LayoutSession() ;
*/
}


// -----------------------------------------------------------------------------
// Arr�te Episodus
// -----------------------------------------------------------------------------
void
TMyApp::CmEpisoStop()
{
try
{
  NsEpisodusOutilDialog* pDlg = new NsEpisodusOutilDialog(appContext->GetMainWindow(), appContext) ;
  pDlg->Execute() ;
  return ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmEpisoStop : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmEpisoStop.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Param�tres d'impression
// -----------------------------------------------------------------------------
void
TMyApp::CmParamPrint()
{
try
{
  NSPrintParamsDlg* pDlg = new NSPrintParamsDlg(appContext->GetMainWindow(), appContext) ;
  pDlg->Execute() ;
  return ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmParamPrint : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmParamPrint", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Auto-Update parameters
// -----------------------------------------------------------------------------
void
TMyApp::CmParamUpdate()
{
try
{
  NSUpdateParamsDlg* pDlg = new NSUpdateParamsDlg(appContext->GetMainWindow(), appContext) ;
  pDlg->Execute() ;
  return ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmParamUpdate : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmParamUpdate", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Lance la phase d'apprentissage
// -----------------------------------------------------------------------------
void
TMyApp::CmEpisoLearn()
{
try
{
	NSPrometheFile* pPrometCfg = new NSPrometheFile(appContext) ;
	pPrometCfg->Lancer() ;
	delete pPrometCfg ;
	return ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception TMyApp::CmEpisoLearn : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
	erreur("Exception TMyApp::CmEpisoLearn.", standardError, 0) ;
}
/*
  appContext->getSuperviseur()->pEpisodus->SetLearning(true) ;
  //appContext->getSuperviseur()->pEpisodus->createViewData() ;

  if (appContext->getSuperviseur()->pEpisodus->pCurrentModel)
    appContext->getSuperviseur()->pEpisodus->ExportModels() ;
*/
}


void
TMyApp::CmEpisoModels()
{
try
{
#ifdef _EXT_CAPTURE
	ArrayEpisodusModelData* pM    = appContext->getSuperviseur()->getEpisodus()->pCaptureEngine->pModels ;
	ArrayEpisodusModelData* pSubM = appContext->getSuperviseur()->getEpisodus()->pCaptureEngine->pSubModels ;
#endif

#ifndef _EXT_CAPTURE
	NSModelDlg* pRefDlg = new NSModelDlg(appContext->GetMainWindow(), appContext, NULL) ;
#else
	NSModelDlg* pRefDlg = new NSModelDlg(appContext->GetMainWindow(), NULL, pM, pSubM, appContext->PathName("FGLO")) ;
#endif
	pRefDlg->Execute() ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception TMyApp::CmEpisoModels : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
	erreur("Exception TMyApp::CmEpisoModels.", standardError, 0) ;
}
}

void
TMyApp::IdcEpisodPhare()
{
  char    buffer[1024] ;
  sprintf(buffer, "toto") ;
}

void
TMyApp::logMessage(string sSpyMessage)
{
  ifstream    inFile ;
  string      sLastSpyMessage ;

  inFile.open("spy.log") ;
  if (inFile)
  {
    while (!inFile.eof())
    {
      string line ;
      getline(inFile, line) ;
      if (line != "")
        sLastSpyMessage += line + "\n" ;
    }
    inFile.close() ;
  }
  else // cas fichier vide
    sLastSpyMessage = "Nautilus log : " ;

  // on ajoute la nouvelle erreur
  sLastSpyMessage += sSpyMessage + "\n" ;

  // On �crit le nouveau fichier reqerror.log
  ofstream    outFile ;
  outFile.open("spy.log") ;
  if (!outFile)
  {
    // cas d'erreur bloquant...
    MessageBox(NULL, "Erreur d'ouverture en �criture du fichier spy.log.", "Erreur NAUTILUS", MB_ICONEXCLAMATION) ;
    return ;
  }

  for (size_t i = 0 ; i < strlen(sLastSpyMessage.c_str()) ; i++)
    outFile.put(sLastSpyMessage[i]) ;
  outFile.close() ;
}


void
TMyApp::CmFunctions()
{
try
{
#ifdef _MUE
  NSAddFunctions* pDlg = new NSAddFunctions(appContext->GetMainWindow(), appContext) ;
  pDlg->Execute() ;
#endif
  return ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmFunctions : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmFunctions.", standardError, 0) ;
}
}

void
TMyApp::CmSynchroImportThisPat()
{
	if (appContext->getUtilisateur() == 0)
		return ;

	if (appContext->getPatient() == 0)
	{
		string sErrMsg = appContext->getSuperviseur()->getText("globalMessages", "patientNeeded") ;
    erreur(sErrMsg.c_str(), warningError, 0) ;
	}

	string sMsg = appContext->getSuperviseur()->getText("patientSynchronization", "patientSynchronizationWarning") ;
	string sTxt = appContext->getSuperviseur()->getText("patientSynchronization", "patientImportAction") ;
	int retVal = ::MessageBox(0, sMsg.c_str(), sTxt.c_str(), MB_YESNO) ;
	if (retVal == IDNO)
		return ;

	string sGlobalLogin, sGlobalPasswd ;
	if (!appContext->getUtilisateur()->haveGlobalSessionPassword())
	{
		LogPassInterface* pDlgLogPass = new LogPassInterface(appContext->GetMainWindow(), appContext) ;
		if (pDlgLogPass->Execute() == IDCANCEL)
			return ;

		sGlobalLogin = pDlgLogPass->getLogin() ;
		sGlobalPasswd = pDlgLogPass->getPassword() ;
		delete pDlgLogPass ;
	}
	else
	{
		sGlobalLogin = appContext->getUtilisateur()->getGlobalLoginSession() ;
		sGlobalPasswd = appContext->getUtilisateur()->getGlobalPasswordSession() ;
	}

	appContext->GetMainWindow()->SetCursor(0, IDC_WAIT) ;
	appContext->getUtilisateur()->fermePatEnCours(true) ;
	appContext->getUtilisateur()->synchroImportThisPat(sGlobalLogin, sGlobalPasswd) ;

	// On lance le patient :
	// R�cup�ration des donn�es rattach�es au patient : adresse et correspondants
	appContext->getPatient()->Initialisation() ;
	appContext->GetMainWindow()->SetCursor(0, IDC_ARROW) ;
}


void
TMyApp::CmSynchroExportThisPat()
{
	if (appContext->getUtilisateur() == 0)
		return ;

	if (appContext->getPatient() == 0)
	{
		string sErrMsg = appContext->getSuperviseur()->getText("globalMessages", "patientNeeded") ;
    erreur(sErrMsg.c_str(), warningError, 0) ;
	}

	string sMsg = appContext->getSuperviseur()->getText("patientSynchronization", "patientSynchronizationWarning") ;
	string sTxt = appContext->getSuperviseur()->getText("patientSynchronization", "patientExportAction") ;
	int retVal = ::MessageBox(0, sMsg.c_str(), sTxt.c_str(), MB_YESNO) ;
	if (retVal == IDNO)
		return ;

	string sGlobalLogin, sGlobalPasswd ;
	if (!appContext->getUtilisateur()->haveGlobalSessionPassword())
	{
		LogPassInterface* pDlgLogPass = new LogPassInterface(appContext->GetMainWindow(), appContext) ;
		if (pDlgLogPass->Execute() == IDCANCEL)
			return ;
		sGlobalLogin = pDlgLogPass->getLogin() ;
		sGlobalPasswd = pDlgLogPass->getPassword() ;
		delete pDlgLogPass ;
	}
	else
	{
		sGlobalLogin = appContext->getUtilisateur()->getGlobalLoginSession() ;
		sGlobalPasswd = appContext->getUtilisateur()->getGlobalPasswordSession() ;
	}

	appContext->GetMainWindow()->SetCursor(0, IDC_WAIT) ;
	appContext->getUtilisateur()->fermePatEnCours(true) ;
	appContext->getUtilisateur()->synchroExportThisPat(sGlobalLogin, sGlobalPasswd) ;

	// on termine la fermeture du patient
	delete appContext->getPatient() ;
	appContext->setPatient(0) ;

	// on r�tablit le titre de l'application sans les infos patient
	appContext->setMainCaption() ;
	appContext->GetMainWindow()->SetCursor(0, IDC_ARROW) ;
}


void
TMyApp::CmPilotAgentsManagement()
{
try
{
	NSAgentsList *pAgWin = new NSAgentsList(appContext->GetMainWindow(), appContext) ;
	pAgWin->Execute() ;
	delete pAgWin ;
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception TMyApp::CmPilotAgentsManagement : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch(...)
{
  erreur("Exception TMyApp::CmPilotAgentsManagement", standardError, 0) ;
}
}

void
TMyApp::Condemn(TWindow* win)
{
	// OWL::TApplication::Condemn(win) ;

  // TRACEX(OwlApp, 1, "Condemning window @" << (void*)win << *win);
  win->SetParent(0);

// #if 0

  // The following logic is from previous versions of ObjectWindows.
  // It results in LIFO destructions which is somewhat unfair.
  // However, we'll keep this code around in case previous applications
  // relied on this destruction order
  //
//  win->SetNext(CondemnedWindows);
//  CondemnedWindows = win;

// #else

  // Insert the new window to be deleted at the end of the list
  //
  win->SetNext(0) ;
  if (pNSCondemnedWindows)
	{
    TWindow* eol = pNSCondemnedWindows ;
    while (eol->Next())
      eol = eol->Next() ;
    eol->SetNext(win) ;
  }
  else
  {
    pNSCondemnedWindows = win ;
  }

// #endif
}

//
// Remove a condemned window from the list.
//
void
TMyApp::Uncondemn(TWindow* win)
{
	// OWL::TApplication::Uncondemn(win) ;

  if (win && pNSCondemnedWindows)
	{
    TWindow* w = 0 ;
    if (pNSCondemnedWindows != win)
      for (w = pNSCondemnedWindows; w->Next() != win; w = w->Next())
        if (!w->Next())
          return ;

    // TRACEX(OwlApp, 1, "Uncondemning window @" << (void*)win << *win);
    if (w)
      w->SetNext(win->Next()) ;
    else
      pNSCondemnedWindows = win->Next() ;
  }
}

//
// Walk the condemned window list & delete each window. Assumes that the
// windows were constructed using 'new'
//
void
TMyApp::DeleteCondemned()
{
	// OWL::TApplication::DeleteCondemned() ;

  while (pNSCondemnedWindows)
  {
    // TRACEX(OwlApp, 1, "Deleting condemned window @" << CondemnedWindows << *CondemnedWindows);
    TWindow* next = pNSCondemnedWindows->Next() ;
    delete pNSCondemnedWindows ;
    pNSCondemnedWindows = next ;
  }
}

void
TMyApp::initCurrentDir()
{
	const  initbuf = 256 ;
	size_t buflen  = initbuf ;
	char *buf = reinterpret_cast<char *>(malloc(buflen)) ;

	if (buf)
	{
		buflen = GetCurrentDirectory(buflen, buf) ;
		if (buflen > initbuf)
		{
			char *p = reinterpret_cast<char *>(realloc(buf, buflen)) ;
			if (p)
      {
				buf = p ;
        buflen = GetCurrentDirectory(buflen, buf) ;
      }
  	}
	}

	if ((buflen > 0) && (NULL != buf) && (NULL != appContext))
		appContext->setBaseDirectory(string(buf)) ;

	free(buf) ;
}

DEFINE_RESPONSE_TABLE1(NSMDIFrame, TDecoratedMDIFrame)
  EV_WM_QUERYENDSESSION,
  EV_WM_ENDSESSION,
  EV_COMMAND(IDM_TODO, CmToDo),
END_RESPONSE_TABLE;

NSMDIFrame::NSMDIFrame(NSContexte* pCtx, const char far *title, TResId menuResId, TMDIClient &clientWnd, bool trackMenuSelection, TModule* module)
  : TDecoratedMDIFrame(title, menuResId, clientWnd, trackMenuSelection, module),
    NSRoot(pCtx)
{
	// Printer = new NSPrinter ;
}


NSMDIFrame::~NSMDIFrame()
{
	// delete Printer;
  // Printer = 0;
}


void
NSMDIFrame::SetupWindow()
{
  char szThis[20] ;
  sprintf(szThis, "%p", HWindow) ;
  string sMsg = string("SetupWindow for NSMDIFrame ") + string(szThis) ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trDetails) ;

  TFrameWindow::SetupWindow() ;

  TMyApp* pApp = pContexte->getSuperviseur()->getApplication() ;
  char szApp[20] ;
  sprintf(szApp, "%p", pContexte->GetMainWindow()->HWindow) ;
  sMsg = string("- Main Window ") + string(szApp) ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trDetails) ;

  char szStatusBar[20] ;
  if (NULL != pApp->sb)
    sprintf(szStatusBar, "%p", pApp->sb->HWindow) ;
  else
    strcpy(szStatusBar, "not created") ;
  sMsg = string("- Status bar ") + string(szStatusBar) ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trDetails) ;

  char szControlBar[20] ;
  if (NULL != pApp->cb)
    sprintf(szControlBar, "%p", pApp->cb->HWindow) ;
  else
    strcpy(szControlBar, "not created") ;
  sMsg = string("- Control bar ") + string(szControlBar) ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trDetails) ;

  char szHarbor[20] ;
  if (NULL != pApp->Harbor)
    sprintf(szHarbor, "%p", pApp->Harbor->HWindow) ;
  else
    strcpy(szHarbor, "not created") ;
  sMsg = string("- Harbor ") + string(szHarbor) ;
  pContexte->getSuperviseur()->trace(&sMsg, 1, NSSuper::trDetails) ;

  // On reroute le parent de l'appli VCL vers la frame OWL
  AdoptVCLAppWindow(GetHandle()) ;
}


bool
NSMDIFrame::EvQueryEndSession()
{
	if (pContexte->getSuperviseur()->getApplication()->prendClient()->CloseChildren())
	{
		bEndSession = true ;
		return true ;
	}
	else
	{
		bEndSession = false ;
		return false ;
	}
}

void
NSMDIFrame::EvEndSession(bool endSession, bool logOff)
{
  NSSuper* pSuper = pContexte->getSuperviseur() ;

  // Si fin de session :
  // on detruit le superviseur, ce qui permet de d�bloquer le patient en cours
  if (bEndSession && pSuper)
  {
    delete pSuper ;
    pSuper = 0 ;
  }
}

void
NSMDIFrame::CmToDo()
{
try
{
	if (!pContexte)
		return ;

	NSSuper *pSuper = pContexte->getSuperviseur() ;
	if (!pSuper)
		return ;

	string ps ;

	if (pSuper->aToDo.empty())
	{
		ps = string("CmToDo with an empty ToDo array") ;
		pSuper->trace(&ps, 1, NSSuper::trSubDetails) ;
		return ;
	}

	// Pour �viter les probl�mes de synchronisation (un todo est ajout�
	// � l'array au milieu du traitement des todo pr�c�dents, on fait
	// une copie locale et on vide le r�servoir global
  while (pSuper->bToDoLocked)
		pSuper->getApplication()->PumpWaitingMessages() ;

	pSuper->bToDoLocked = true ;
  for (TaskIter iTD = pSuper->aToDo.begin() ; iTD != pSuper->aToDo.end() ; iTD++)
	{
		ps = string("globalToDo ") + (*iTD)->sWhatToDo + string(" sP1=") + (*iTD)->sParam1 + string(" sP2=") + (*iTD)->sParam2 ;
		pSuper->trace(&ps, 1, NSSuper::trSubDetails) ;
	}
	NSTaskArray aLocalToDo = pSuper->aToDo ;
	pSuper->aToDo.vider() ;
	pSuper->bToDoLocked = false ;
	for (TaskIter iTD = aLocalToDo.begin() ; iTD != aLocalToDo.end() ; iTD++)
	{
		ps = string("localToDo ") + (*iTD)->sWhatToDo + string(" sP1=") + (*iTD)->sParam1 + string(" sP2=") + (*iTD)->sParam2 ;
		pSuper->trace(&ps, 1, NSSuper::trSubDetails) ;
	}

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  if (aLocalToDo.empty() == false)
	for (TaskIter iTD = aLocalToDo.begin() ; iTD != aLocalToDo.end() ; )
	{
		ps = string("d�but Todo : ") + (*iTD)->sWhatToDo ;
		pSuper->trace(&ps, 1) ;

		if      ((*iTD)->sWhatToDo == "Archetype")
    	ToDo_Archetype(*iTD) ;

    else if ((*iTD)->sWhatToDo == "KS_Archetype")
			ToDo_KS_Archetype(*iTD) ;

    else if ((*iTD)->sWhatToDo == "FermeArchetype")
    	ToDo_FermeArchetype(*iTD) ;

    else if ((*iTD)->sWhatToDo == "Referential")
    {
      if ((pContexte->getUtilisateur() == 0) || (pContexte->getPatient() == 0))
        return ;

      pContexte->getPatient()->CmReferentiel((*iTD)->sParam1, "") ;
    }
    else if ((*iTD)->sWhatToDo == "CreerBibArch")
    	ToDo_CreerBibArch(*iTD) ;

    else if ((*iTD)->sWhatToDo == "CreerBibChem")
    	ToDo_CreerBibChem(*iTD) ;

    else if ((*iTD)->sWhatToDo == "FermeDPIO")
    	ToDo_FermeDPIO(*iTD) ;

    else if ((*iTD)->sWhatToDo == "ActivateMUEView")
    	ToDo_ActivateMUEView(*iTD) ;

    else if ((*iTD)->sWhatToDo == "NewPreoccup")
    	ToDo_NewPreoccup(*iTD) ;

    else if ((*iTD)->sWhatToDo == "NewPreoccupFromNode")
    	ToDo_NewPreoccupFromNode(*iTD) ;

    else if ((*iTD)->sWhatToDo == "NewDrugFromNode")
    	ToDo_NewDrugFromNode(*iTD) ;

    else if ((*iTD)->sWhatToDo == "ChangePreoccupFromNode")
    	ToDo_ChangePreoccupFromNode(*iTD) ;

		// Ouverture d'une Fonction - Function opening
		else if ((*iTD)->sWhatToDo == "OpenNewWindow")
			ToDo_OpenNewWindow(*iTD) ;

    else if ((*iTD)->sWhatToDo == "FocusWindow")
    {
    	NSMUEView* pView = (static_cast<NSMUEView *>((*iTD)->pPointer1)) ;
      if (pView)
        pView->SetFocus() ;
    }
    else if ((*iTD)->sWhatToDo == "NavigateComplete")
    {
      NSVisualView* pView = (static_cast<NSVisualView *>((*iTD)->pPointer1)) ;

      if (pView)
      {
      	// temporisation avant de lancer la publication
      	if (pView && pView->iTempPostNav > 0)
        	pContexte->getSuperviseur()->Delay(pView->iTempPostNav) ;      	// publication [impression] du document (ExecWB)      	pView->CmPublier() ;
      }
    }
    else if ((*iTD)->sWhatToDo == "AddDatasOnBBK")
    {
      NSPatPathoArray *pPt  = (NSPatPathoArray *)((*iTD)->pPointer1) ;
      if (pPt)
        addDatasFromNautilusOnBlackboard(pContexte, pPt) ;
    }
    else if ((*iTD)->sWhatToDo == "AddToSOAP")
    {
    	NSEpisodus* pEpisod = pContexte->getSuperviseur()->getEpisodus() ;
      if (pEpisod)
      {
      	NSCapture *pPt = (NSCapture *)((*iTD)->pPointer1) ;
      	if (pPt)
        	pEpisod->addToSOAP(pPt) ;
        else
        {
        	SOAPObject *pPt2 = (SOAPObject *)((*iTD)->pPointer1) ;
      		if (pPt2)
        		pEpisod->addToSOAP(pPt2) ;
        }
      }
    }
		else if ((*iTD)->sWhatToDo == "RefreshHealthTeamInformation")
    {
    	NSPatientChoisi* pPatient = pContexte->getPatient() ;
      if ((NULL != pPatient) && (NULL != pPatient->pHealthDoc))
      	pPatient->pHealthDoc->invalidateViews((*iTD)->sParam1, (*iTD)->sParam2) ;
		}

    ps = string("fin Todo : ") + (*iTD)->sWhatToDo ;
    pContexte->getSuperviseur()->trace(&ps, 1) ;

    delete (*iTD) ;
    aLocalToDo.erase(iTD) ;
  }
}
catch(TWindow::TXWindow& e)
{
  string sErr = string("Exception NSMDIFrame::CmToDo : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
}
catch (...)
{
  erreur("Exception NSMDIFrame::CmToDo.", standardError, 0) ;
}
}

void
NSMDIFrame::ToDo_Archetype(NSToDoTask* pToDo)
{
  if (NULL == pToDo)
    return ;

	NSSuper *pSuper = pContexte->getSuperviseur() ;
	string ps = string("Todo Archetype : ") + pToDo->sParam1 ;
  pSuper->trace(&ps, 1) ;

  string sArchetype = pToDo->sParam1 ;
  string sTypeArc   = pToDo->sParam2 ;
  int iTypeArc      = atoi(sTypeArc.c_str()) ;

  if (iTypeArc == NSCQDocument::creatpat)
  {
  	// En cas de cr�ation d'un nouveau patient
    // on ferme l'eventuel patient en cours
    if (pContexte->getPatient())
    	pContexte->getUtilisateur()->fermePatEnCours() ;
  }

  ps = string("Todo Archetype : ") + sArchetype + string(" cr�ation du document") ;
  pSuper->trace(&ps, 1) ;

  // cr�ation d'un document vierge (on transmet l'archetype)
  // on lance le mod�le document/vues formulaire
  NSCQDocument* pCQDoc = new NSCQDocument(0, pContexte, sArchetype, iTypeArc) ;
  if (pCQDoc->bParsingOk)
  {
  	ps = string("Todo Archetype : ") + sArchetype + string(" cr�ation de la vue") ;
    pSuper->trace(&ps, 1) ;

    NSDocViewManager dvManager(pContexte) ;
    dvManager.createView(pCQDoc, "CQ Format") ;
  }
  else
  {
  	delete pCQDoc ;
    ps = string("Todo Archetype : ") + sArchetype + string(" abort (mauvais Archetype)") ;
    pSuper->trace(&ps, 1) ;
  }
}

voidNSMDIFrame::ToDo_KS_Archetype(NSToDoTask* pToDo){#ifdef __OB1__  if (NULL == pToDo)    return ;	NSSuper *pSuper = pContexte->getSuperviseur() ;	BB1BBInterfaceForKs* pKSinterface = (static_cast<BB1BBInterfaceForKs *>(pToDo->pPointer1)) ;
  string ps ;

  if (!pKSinterface)
  {
  	ps = string("Todo KS_Archetype with wrong BB1BBInterfaceForKs pointer") ;
    pSuper->trace(&ps, 1) ;
    return ;
  }

  BB1BBInterfaceForKs ksInterface = *pKSinterface ;

  string sArchetype = ksInterface.getArchetypeID() ;
  string sKSname    = ksInterface.getKsName() ;

  ps = string("Todo KS_Archetype : ") + sArchetype + string(" for KS : ") + sKSname ;
  pSuper->trace(&ps, 1) ;

  ps = string("Todo Archetype : ") + sArchetype + string(" cr�ation du document") ;
  pSuper->trace(&ps, 1) ;

  // cr�ation d'un document vierge (on transmet l'archetype)
  // on lance le mod�le document/vues formulaire
  NSCQDocument* pCQDoc = new NSCQDocument(0, pContexte, &ksInterface) ;
  if (pCQDoc->bParsingOk)
  {
  	ps = string("Todo Archetype : ") + sArchetype + string(" cr�ation de la vue") ;
    pSuper->trace(&ps, 1) ;

    NSDocViewManager dvManager(pContexte) ;
    dvManager.createView(pCQDoc, "CQ Format") ;
  }
  else
  {
  	delete pCQDoc ;
    ps = string("Todo Archetype : ") + sArchetype + string(" abort (mauvais Archetype)") ;
    pSuper->trace(&ps, 1) ;
  }

  if (!(pToDo->deleteP1))
  {
  	delete pKSinterface ;
    pToDo->pPointer1 = NULL ;
  }
#endif
}
voidNSMDIFrame::ToDo_FermeArchetype(NSToDoTask* pToDo){  if (NULL == pToDo)    return ;	NSSuper *pSuper = pContexte->getSuperviseur() ;  if (NULL == pSuper)  	return ;	string ps = string("D�but Todo : FermeArchetype") ;  pSuper->trace(&ps, 1) ;

  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  NSSmallBrother  *pBB    = (static_cast<NSSmallBrother *>(pToDo->pPointer1)) ;
  NSCQWindowsView *pView  = (static_cast<NSCQWindowsView *>(pToDo->pPointer2)) ;
  //NSCQVue         *pView = TYPESAFE_DOWNCAST((*iTD)->pPointer2, NSCQVue) ;

  if (pBB)
  {
  	if (!(pBB->getPatPatho()->empty()))
    {
    	bool existeInfo ;
      NSCQDocument  *pDocum = pView->pDoc ;
      *(pDocum->pPatPathoArray) = *(pBB->getPatPatho()) ;

      if (pDocum->iTypeDoc == NSCQDocument::creatpat)
      {
      	NSPatPathoArray aPPt(pContexte) ;
        aPPt = *(pDocum->pPatPathoArray) ;
				pContexte->GetMainWindow()->SetCursor(0, IDC_WAIT) ;

        if (pContexte->getUtilisateur()->createPatient(&aPPt))
        	pContexte->getPatient()->Initialisation() ;
        else
        	pContexte->setPatient(NULL) ;

        pContexte->GetMainWindow()->SetCursor(0, IDC_ARROW) ;

        if (NULL != pView)
          pView->setWaitingForSystem(false) ;

				pBB->canCloseArchetype(true, false) ;
			}
			else if (pDocum->iTypeDoc == NSCQDocument::creatadr)
      {
      	NSAddressGraphManager  *pGraphManager = new NSAddressGraphManager(pContexte) ;
        pGraphManager->setGraphAdr(pDocum->pPatPathoArray) ;
        delete pGraphManager ;

        if (NULL != pView)
          pView->setWaitingForSystem(false) ;

        pBB->canCloseArchetype(true) ;
      }
			else if (pDocum->pDocInfo != 0)
      {
        bool bIsDemographicArchetype = false ;
        if (pContexte->getSuperviseur()->getDemographicArchetypeId() == pDocum->_sDefaultArchetype)
          bIsDemographicArchetype = true ;

      	// string sArchetype = string("") ;
        // if ((NULL != pDocum->pPatPathoArray) && (false == pDocum->pPatPathoArray->empty()))
        // 	sArchetype = (*(pDocum->pPatPathoArray->begin()))->getArchetype() ;

      	if (true == bIsDemographicArchetype)
        {
        	// Manage IPP
          //
  				string sIPP = string("") ;
          NSPatPathoArray* pPatPathoAdmin = pDocum->pPatPathoArray ;

					pContexte->getUtilisateur()->getAndRemoveIppFromPatpatho(pPatPathoAdmin, &sIPP) ;

          if ((string("") != sIPP) && (string("") != pContexte->getSuperviseur()->getIppSite()))
          	pContexte->getPatient()->updateIPPEnCours(pContexte->getSuperviseur()->getIppSite(), sIPP) ;
        }

      	pDocum->enregistrePatPatho() ;
        // on recharge la patpatho pour r�cup�rer les nouveaux nodes
        // Reloading the patpatho in order to freshen nodes
        pDocum->NSNoyauDocument::chargePatPatho() ;
        // string sArchetype = (*(pDocum->pPatPathoArray->begin()))->pDonnees->getArchetype() ;

        pContexte->getPatient()->pDocHis->Rafraichir(pDocum->pDocInfo, pDocum->pPatPathoArray) ;

        if (NULL != pView)
          pView->setWaitingForSystem(false) ;

        if (false == bIsDemographicArchetype)
        {
        	ps = string("Fermeture effective du document ") + pDocum->sArchetype ;
          pContexte->getSuperviseur()->trace(&ps, 1) ;
          pBB->canCloseArchetype(true) ;
        }
        else
          pContexte->getPatient()->PatientDataChanged(pDocum->pPatPathoArray) ;
			}
      else
      {
      	// cas des nouveaux documents formulaire
        string sLibelleDoc = "" ;
        string sCode = (*(pBB->getPatPatho()->begin()))->pDonnees->lexique ;
        if (sCode != "")
        	pContexte->getDico()->donneLibelle(sLang, &sCode, &sLibelleDoc) ;

        string ps = string("Fermeture formulaire ") + sLibelleDoc ;
        pContexte->getSuperviseur()->trace(&ps, 1) ;

        ps = string("Referencement formulaire ") + sLibelleDoc ;
        pContexte->getSuperviseur()->trace(&ps, 1) ;

        // R�f�rencement sans boite de dialogue
				existeInfo = pDocum->Referencer("ZCQ00", sLibelleDoc, "", "", true, false) ;

				if (existeInfo)
        {
        	ps = string("Enregistrement de l'arbre du formulaire ") + sLibelleDoc ;
          pContexte->getSuperviseur()->trace(&ps, 1) ;
          existeInfo = pDocum->enregistrePatPatho() ;
        }

        // on recharge la patpatho pour r�cup�rer les nouveaux nodes
        if (existeInfo)
        {
        	existeInfo = pDocum->NSNoyauDocument::chargePatPatho() ;
          pContexte->getPatient()->pDocHis->Rafraichir(pDocum->pDocInfo, pDocum->pPatPathoArray) ;
        }

        if (existeInfo)
        {
        	pContexte->getPatient()->pDocLdv->showNewTree(pDocum->pPatPathoArray, pDocum->GetDateDoc(false)) ;
          pDocum->makeSOAP() ;
        }

        NSDPIO  *pDPIO = pContexte->getSuperviseur()->getDPIO() ;

        if (existeInfo)
        {
        	string sRacineDoc = pDocum->DonneDocInfo()->getID() ;
          string sDateDoc   = pDocum->GetDateDoc(false) ;
          string sDateDPIO  = string(sDateDoc, 6, 2) + string("/") + string(sDateDoc, 4, 2) + string("/") + string(sDateDoc, 0, 4) ;

          pDPIO->sSendPage += string("<document code=\"") + sRacineDoc + string("\" date=\"") + sDateDPIO + string("\">\r\n") + pDocum->pPatPathoArray->genereXML() + string("</document>\r\n") ;

          // Rafraichir l'historique
          pContexte->getPatient()->pDocHis->Rafraichir(pDocum->pDocInfo, pDocum->pPatPathoArray/*, NSNoyauDocument* pNouveauDocument*/) ;

          // Archetype ?
          string      sNomRef = "" ;

          if (pBB && pBB->pBBItem && pBB->pBBItem->pParseur && pBB->pBBItem->pParseur->pArchetype)
          {
          	Carchetype  *pArchetype = pBB->pBBItem->pParseur->pArchetype ;

            if (pArchetype->getDialog())
            	sNomRef = pArchetype->getDialog()->getStringAttribute(ATTRIBUT_DIALOGUE_REF) ;

            // Connexion � (ouverture de) la pr�occupation
            string  sConcernCode    = "" ;
            // bool    bConnected      = false ;

            Creferences *pRef     = pArchetype->getReference() ;
            if (pRef)
            {
            	Cconcern  *pConcern = pRef->getFirstCconcern() ;
              if (pConcern)
              {
              	sConcernCode    = pConcern->getCode() ;
                bool    bCreate = pConcern->getAutoCreate() ;
                int     iSevere = pConcern->getSeverity() ;

                if ((sConcernCode != "") && (pContexte->getPatient()) && (pContexte->getPatient()->pDocLdv))
                {
                	ps = string("Connection � sa preoccupation du formulaire ") + sLibelleDoc ;
                  pContexte->getSuperviseur()->trace(&ps, 1) ;
                  NSLdvDocument *pDocLdv = pContexte->getPatient()->pDocLdv ;

                  if ((sConcernCode[0] == 'I') || (sConcernCode[0] == '_'))
                  	pDocLdv->connectObjectToDrug(sConcernCode, iSevere, sRacineDoc, NSRootLink::problemRelatedTo, bCreate) ;

                  else if (sConcernCode[0] != '#')
                  	/*bConnected =*/ pDocLdv->connectObjectToConcern(sConcernCode, iSevere, sRacineDoc, NSRootLink::problemRelatedTo, bCreate) ;

                  // Si sConcernCode[0] == '#', c'est qu'on se connecte �
                  // la pr�occupation lanceuse du formulaire
                  else
                  {
                  	string sPreoType = string(sConcernCode, 1, strlen(sConcernCode.c_str()) - 1) ;
                    string sQuestion = string("0PRO1/IsA/") + sPreoType ;
                    NSPatPathoArray *pAnswer = NULL ;
#ifdef __OB1__
										string sAnswerDate ;
										if (pSuper->getBBinterface()->getAnswer2Question(sQuestion, "", &pAnswer, sAnswerDate, false))
#else
										if (pSuper->getBlackboard()->getAnswer2Question(sQuestion, "", &pAnswer, false))
#endif // !__OB1__
										{
                    	if (pAnswer && !pAnswer->empty())
                      {
                      	PatPathoIter iter = pAnswer->begin() ;
                        string sLaunchingPreoc = (*iter)->getLexique() ;
                        pDocLdv->connectObjectToConcern(sLaunchingPreoc, iSevere, sRacineDoc, NSRootLink::problemRelatedTo, bCreate) ;
                      }
                    }
                    if (pAnswer)
                    	delete pAnswer ;
									}
								}
							}
						}

            // Lancement du r�f�rentiel
            if (sNomRef != "")
            {
            	ps = string("Lancement du referentiel pour le formulaire ") + sLibelleDoc ;
              pContexte->getSuperviseur()->trace(&ps, 1) ;
              pContexte->getPatient()->CmReferentiel(sNomRef, sRacineDoc) ;
            }

            if ((pDocum->iTypeDoc == NSCQDocument::dpio) && pDPIO && pDPIO->bLogPage)
            {
            	ps = string("Log DPIO du formulaire ") + sLibelleDoc ;
              pContexte->getSuperviseur()->trace(&ps, 1) ;
              // pDPIO->sLogPage += pDocum->donneTexte() ;
              pDPIO->AppendLogFile() ;
            }

            // Fermeture du questionnaire
            // A faire en dernier car pDocum disparait � la fermeture de la vue
            ps = string("Fermeture effective du formulaire ") + sLibelleDoc ;
            pContexte->getSuperviseur()->trace(&ps, 1) ;
            pBB->canCloseArchetype(true) ;
            // Fait par la vue
            //delete pBB ;
					}
          else if (pBB)
          {
          	pBB->canCloseArchetype(true) ;
            // Fait par la vue
            //delete pBB ;
          }
				}
			}
		}
	}}voidNSMDIFrame::ToDo_CreerBibArch(NSToDoTask* pToDo){  if (NULL == pToDo)    return ;  NSDocumentInfo DocInfo(pContexte) ;
  // Patient : Patient en cours
  DocInfo.setPatient("_------") ;

  // Code : par d�finition "_00000"
  string sCodeDocum = string("_") + string(DOC_CODE_DOCUM_LEN - 1, '0') ;
  DocInfo.setDocument(sCodeDocum) ;

  // Ne pas passer pDocInfo dans le cteur pour �viter qu'il essaie de
  // charger la patpatho
  NSRefDocument DocLibArch(0, 0, 0, pContexte, false) ;
  DocLibArch.pDocInfo = new NSDocumentInfo(DocInfo) ;
  DocLibArch.pPatPathoArray->ajoutePatho("0LIBA1", 0) ;

	DocLibArch.enregistrePatPatho() ;

  // IMPORTANT : on doit remettre pDocInfo et pHtmlInfo � 0
  // pour �viter que ~NSRefDocument ne remette � jour l'historique
  DocLibArch.pDocInfo = 0 ;

  string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName() ;
  MessageBox("La biblioth�que d'Archetypes a �t� cr��e avec succ�s.", sCaption.c_str(), MB_OK) ;}voidNSMDIFrame::ToDo_CreerBibChem(NSToDoTask* pToDo){  if (NULL == pToDo)    return ;	// Cr�ation de l'arbre-biblioth�que de chemises  if (pContexte->getPatient() == 0)
  {
    erreur("Vous devez ouvrir un patient avant de lancer cette option.", standardError, 0) ;
    return ;
  }

  char szDateJour[10] ;
  donne_date_duJour(szDateJour) ;

  NSRefDocument LibChem(0, 0, 0, pContexte, false) ;
  LibChem.pPatPathoArray->ajoutePatho("0LIBC1", 0) ;

  // ajout de la chemise corbeille
  // Note : cette chemise doit �tre cr��e en premier afin que la chemise par d�faut
  // soit s�lectionn�e plus tard dans EnregDocDialog (on s�lectionne la derni�re chemise)
  LibChem.pPatPathoArray->ajoutePatho("0CHEM1", 1) ;

  // Intitul� : nom de la chemise
  LibChem.pPatPathoArray->ajoutePatho("0INTI1", 2) ;
  Message *pMessage = new Message ;
  pMessage->SetTexteLibre("corbeille") ;
  LibChem.pPatPathoArray->ajoutePatho("�?????", pMessage, 3) ;
  delete pMessage ;

  // Date d'ouverture
  LibChem.pPatPathoArray->ajoutePatho("KOUVR1", 2) ;
  string sDateCreation = string(szDateJour) + string("000000") ;
  pMessage = new Message ;
  pMessage->SetUnit("2DA021") ;
  pMessage->SetComplement(sDateCreation.c_str()) ;
  LibChem.pPatPathoArray->ajoutePatho("�T0;19", pMessage, 3) ;
  delete pMessage ;

  // ajout de la chemise par d�faut
  LibChem.pPatPathoArray->ajoutePatho("0CHEM1", 1) ;

  // Intitul� : nom de la chemise
  LibChem.pPatPathoArray->ajoutePatho("0INTI1", 2) ;
  pMessage = new Message ;
  pMessage->SetTexteLibre("d�faut") ;
  LibChem.pPatPathoArray->ajoutePatho("�?????", pMessage, 3) ;
  delete pMessage ;

  // Date d'ouverture
  LibChem.pPatPathoArray->ajoutePatho("KOUVR1", 2) ;
  pMessage = new Message ;
  pMessage->SetUnit("2DA021") ;
  pMessage->SetComplement(sDateCreation.c_str()) ;
  LibChem.pPatPathoArray->ajoutePatho("�T0;19", pMessage, 3) ;
  delete pMessage ;

  if (false == LibChem.Referencer("ZCS00", "Biblioth�que de chemises", "", "", true, false, "", NSRootLink::personFolderLibrary))
  {
    erreur("Impossible de referencer la biblioth�que de chemises du patient.", standardError, 0) ;
    return ;
  }

  if (false == LibChem.enregistrePatPatho())
  {
    erreur("Impossible d'enregistrer la biblioth�que de chemises du patient.", standardError, 0) ;
    return ;
  }
  LibChem.NSNoyauDocument::chargePatPatho() ;

  string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName() ;
  MessageBox("La biblioth�que de chemises a �t� cr��e avec succ�s.", sCaption.c_str(), MB_OK) ;}voidNSMDIFrame::ToDo_FermeDPIO(NSToDoTask* pToDo){try{  if ((NULL == pToDo) || (NULL == pToDo->pPointer1))    return ;  NSDPIO *pDPIO = pContexte->getSuperviseur()->getDPIO() ;  if (NULL == pDPIO)    return ;      pDPIO->fermeFormulaire(pToDo->pPointer1) ;
/*  TMDIChild *pView = (static_cast<TMDIChild *>(pToDo->pPointer1)) ;  if (NULL == pView)
  	return ;

  //if (pView->pDoc->iTypeDoc == NSCQDocument::dpio)
  //{
  NSDPIO  *pDPIO = pContexte->getSuperviseur()->getDPIO() ;
  //TMDIChild* pChild = pView->Parent ;
  pDPIO->fermeFormulaire((TWindow*)pView) ;
  //}

  // PA 29/05/09
  // if (pView->IsWindow())
  //   delete pView ;
*/
}
catch (...)
{
  erreur("Exception ToDo_FermeDPIO.", standardError, 0) ;
}
}voidNSMDIFrame::ToDo_ActivateMUEView(NSToDoTask* pToDo){  if (NULL == pToDo)    return ;	// NSMUEView* pMueView = NULL ;  // if (pToDo->pPointer1)
  //  pMueView = (static_cast<NSMUEView *>(pToDo->pPointer1)) ;

  NSDialog* pDialog = NULL ;
  if (pToDo->pPointer2)
    pDialog = (static_cast<NSDialog *>(pToDo->pPointer2)) ;

  ::SetForegroundWindow(pContexte->GetMainWindow()->GetHandle());
  if (pDialog)
  {
    pDialog->bActivateMUEView = false;
    ::SetActiveWindow(pDialog->GetHandle());
  }
  if (pContexte->GetMainWindow()->IsIconic())
    ::SetForegroundWindow(pContexte->GetMainWindow()->GetHandle());}voidNSMDIFrame::ToDo_NewPreoccup(NSToDoTask* pToDo){  if (NULL == pToDo)    return ;	// TWindow *pView  = (static_cast<TWindow *>(pToDo->pPointer1)) ;  string sLexique = pToDo->sParam1 ;
  string sDate    = pToDo->sParam2 ;

  NSLdvDocument *pLdvDoc = pContexte->getPatient()->pDocLdv ;
  if (NULL == pLdvDoc)
    return ;

  // On v�rifie que la pr�occupation n'existe pas d�j�
  //
  string sCodeSensConcern ;
  pContexte->getDico()->donneCodeSens(&sLexique, &sCodeSensConcern) ;

  NSConcern* pConcern = pLdvDoc->donneOpenConcern(sCodeSensConcern) ;
  if (NULL == pConcern)
  {
    string sNewNode = string("") ;
    string sCocCode = string("") ;
    NSPatPathoArray *pDetails = NULL ;

    string* psDate = NULL ;
    if (sDate != "")
      psDate = &sDate ;

    TWindow* pView = 0 ;
    NSLdvView *pLdvView = pLdvDoc->getLdvView() ;
    if (NULL != pLdvView)
      pView = pLdvView ;
    else
      pView = this ;

    NSNewConcernDlg *pNPDialog = new NSNewConcernDlg(pView, &sNewNode, pLdvDoc, pContexte, pDetails, &sCocCode, &sLexique, psDate) ;
    /* int iExecReturn = */ pNPDialog->Execute() ;
  }}voidNSMDIFrame::ToDo_NewPreoccupFromNode(NSToDoTask* pToDo){try{  if (NULL == pToDo)    return ;	NSTreeWindow *pView = (static_cast<NSTreeWindow *>(pToDo->pPointer1)) ;  NSTreeNode   *pNode = (static_cast<NSTreeNode *>(pToDo->pPointer2)) ;
  if ((NULL == pView) || (NULL == pNode))
  	return ;

  NSLdvDocument *pLdvDoc = pContexte->getPatient()->pDocLdv ;

  string sNewNode = string("") ;
  string sLexique = pNode->getEtiquette() ;
  NSPatPathoArray Details(pContexte) ;

  // Todo : get possible CISP code
  string sCocCode = string("") ;

	NSNewConcernDlg *pNPDialog = 0 ;
  TDialog *pDlg = 0 ;

  TWindow* pControlParent = pView->Parent ;
  if (NULL != pControlParent)
	{
  	pDlg = TYPESAFE_DOWNCAST(pControlParent, TDialog) ;
    if (NULL != pDlg)
    	pNPDialog = new NSNewConcernDlg(pDlg, &sNewNode, pLdvDoc, pContexte, &Details, &sCocCode, &sLexique) ;
  }

	if (NULL == pNPDialog)
		pNPDialog = new NSNewConcernDlg(pView, &sNewNode, pLdvDoc, pContexte, &Details, &sCocCode, &sLexique) ;
  int iExecReturn = pNPDialog->Execute() ;
  delete pNPDialog ;

  if (IDOK == iExecReturn)
  {
    if (sNewNode != "")
      pNode->addTemporaryLink(sNewNode, NSRootLink::problemContactElement, dirFleche) ;
    pLdvDoc->getConcerns()->reinit() ;
  }
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception ToDo_NewPreoccupFromNode : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
}
catch (...)
{
  erreur("Exception ToDo_NewPreoccupFromNode.", standardError, 0) ;
}
}voidNSMDIFrame::ToDo_NewDrugFromNode(NSToDoTask* pToDo){  if (NULL == pToDo)    return ;	NSTreeWindow *pView = (static_cast<NSTreeWindow *>(pToDo->pPointer1)) ;  NSTreeNode   *pNode = (static_cast<NSTreeNode *>(pToDo->pPointer2)) ;
  if ((!pView) || (!pNode))
  	return ;

  string sLexique = pNode->getEtiquette() ;

  NSLdvDocument   *pLdvDoc = pContexte->getPatient()->pDocLdv ;
  NSDrugView      *pDrugView = pLdvDoc->getDrugView("") ;
  if (!pDrugView)
  {
    pContexte->getPatient()->drugs_show() ;
    for (int i = 0 ; (i < 50) && !pDrugView ; i++)
      pDrugView = pLdvDoc->getDrugView("") ;
  }

  if (pDrugView)
    pDrugView->CmAddWithCode(sLexique) ;
}voidNSMDIFrame::ToDo_ChangePreoccupFromNode(NSToDoTask* pToDo){  if (NULL == pToDo)    return ;	NSTreeWindow *pView = (static_cast<NSTreeWindow *>(pToDo->pPointer1)) ;  NSTreeNode   *pNode = (static_cast<NSTreeNode *>(pToDo->pPointer2)) ;
  string       sCcrn  = pToDo->sParam1 ;
  if ((!pView) || (!pNode))
  	return ;

  NSLdvDocument *pLdvDoc     = pContexte->getPatient()->pDocLdv ;
  NSConcern     *pOldConcern = pLdvDoc->getConcerns()->getConcern(sCcrn) ;

  string sNewNode = string("") ;
  string sCocCode = string("") ;
  string sLexique = pNode->getEtiquette() ;
  NSPatPathoArray Details(pContexte) ;

  NSNewConcernDlg *pNPDialog = new NSNewConcernDlg(pView, &sNewNode, pLdvDoc, pContexte, &Details, &sCocCode, &sLexique) ;
  int iExecReturn = pNPDialog->Execute() ;
  delete pNPDialog  ;

  if (IDOK == iExecReturn)
  {
    pNode->addTemporaryLink(sNewNode, NSRootLink::problemContactElement, dirFleche) ;
    pLdvDoc->getConcerns()->reinit() ;

    // On part du principe que la nouvelle pr�occupation est en fin d'array

    ArrayConcern  *pConcernArray  = pLdvDoc->getConcerns() ;
    NSConcern     *pNewConcern    = pConcernArray->back() ;

    /* bool bSuccess = */ pLdvDoc->creeConcernSuite(pOldConcern, pNewConcern) ;
  }
}voidNSMDIFrame::ToDo_OpenNewWindow(NSToDoTask* pToDo){  if (NULL == pToDo)    return ;	// sParam1 = fonction - function  // sParam2 = pr�occupation - concern
  // pPointer1 = fen�tre splitt�e - splitted window
  string sDocumentType = "" ;

  // Reservoir SOAP - SOAP tank
  if      (pToDo->sParam1 == "Tanking")
  {
    NSSOAPDocument  *pNewDocSOAP ;
    sDocumentType = "SoapDoc" ;
    NSMUEView       *pSplittedView = (NSMUEView *)(pToDo->pPointer1) ;
    if (!pSplittedView)
      return ;

    NSPaneSplitter  *pPaneSpl = pSplittedView->getPaneSplitter() ;
    NSMUEView       *pWindWithDocType = pPaneSpl->researchDocument("SoapDoc") ;
    if (!pWindWithDocType)
      pNewDocSOAP = new NSSOAPDocument(0, pContexte) ;
    else
      pNewDocSOAP = TYPESAFE_DOWNCAST(pWindWithDocType->pDoc, NSSOAPDocument) ;
    if (!pNewDocSOAP)
      return ;

    NSSOAPTankView      *pNSSOAPTankView = new NSSOAPTankView(*pNewDocSOAP, 0) ;

    if (pSplittedView->getCreateWindow())
      pNSSOAPTankView->setCreateWindow(pSplittedView->getCreateWindow()) ;
    else
      pNSSOAPTankView->setCreateWindow(pSplittedView) ;

    pNSSOAPTankView->setSplittedWindow(pSplittedView) ;

    NSDocViewManager dvManager(pContexte) ;
    dvManager.createView(pNewDocSOAP, "SOAP tank", pNSSOAPTankView) ;
  }
  // Paniers SOAP - SOAP baskets
  else if (pToDo->sParam1 == "Soaping")
  {
    NSMUEView *pSplittedView = (NSMUEView *)(pToDo->pPointer1) ;
    if (!pSplittedView)
    {
      // createSOAPView();
      NSSOAPDocument  *pNewDocSOAP    = new NSSOAPDocument(0, pContexte) ;
      NSSOAPView      *pNSSOAPView    = new NSSOAPView(*pNewDocSOAP, 0, "Soaping") ;

      pNSSOAPView->setCreateWindow(NULL) ;
      pNSSOAPView->setSplittedWindow(NULL) ;

      NSDocViewManager dvManager(pContexte) ;
      dvManager.createView(pNewDocSOAP, "SOAP baskets", pNSSOAPView) ;
    }
  }
  // M�dicaments - Drugs
  else if (pToDo->sParam1 == "DrugManagement")
  {
    NSLdvDocument *pLdvDoc ;
    sDocumentType = "LdvDoc" ;
    NSMUEView     *pSplittedView = (NSMUEView *)(pToDo->pPointer1) ;
    if (!pSplittedView)
    {
      NSPatientChoisi *pPatEnCours = pContexte->getPatient() ;
      if (!pPatEnCours)
      {
        erreur("Il n'y a pas de patient actif!", standardError, 0) ;
        return ;
      }
      pPatEnCours->drugs_show(pToDo->sParam2) ;
    }
    else
    {
      NSPatientChoisi *pPatEnCours = pContexte->getPatient() ;
      if (!pPatEnCours)
      {
        erreur("Imposible d'ouvrir la fenetre demand�e ! \nIl n'y a pas de dossier patient actif.\nVeuillez ouvrir un patient.", standardError, 0) ;
        return ;
      }

      // NSPaneSplitter  *pPaneSpl = pSplittedView->getPaneSplitter() ;
      pLdvDoc = pContexte->getPatient()->pDocLdv ;
      if (!pLdvDoc)
        return ;

      NSDrugView    *pDrugView = new NSDrugView(*pLdvDoc, pSplittedView->getConcern()) ;

      if (pSplittedView->getCreateWindow())
        pDrugView->setCreateWindow(pSplittedView->getCreateWindow()) ;
      else
        pDrugView->setCreateWindow(pSplittedView) ;

      pDrugView->setSplittedWindow(pSplittedView) ;

      NSDocViewManager dvManager(pContexte) ;
      dvManager.createView(pLdvDoc, "Drug Management", pDrugView) ;
    }
  }
  // Objectifs de sant� - Health goals
  else if (pToDo->sParam1 == "GoalManagement")
  {
    NSPatientChoisi *pPatEnCours = pContexte->getPatient() ;
    if (!pPatEnCours)
    {
      erreur("Imposible d'ouvrir la fenetre demand�e ! \nIl n'y a pas de dossier patient actif.\nVeuillez ouvrir un patient.", standardError, 0) ;
      return ;
    }
    NSLdvDocument *pLdvDoc ;
    sDocumentType = "LdvDoc" ;
    NSMUEView     *pSplittedView = (NSMUEView *)(pToDo->pPointer1) ;
    if (!pSplittedView)
    {
      NSPatientChoisi *pPatEnCours = pContexte->getPatient() ;
      if (!pPatEnCours)
      {
        erreur("Il n'y a pas de patient actif!", standardError, 0) ;
        return ;
      }
      pPatEnCours->goals_show(pToDo->sParam2) ;
    }
    else
    {
      pLdvDoc = pContexte->getPatient()->pDocLdv ;
      if (!pLdvDoc)
        return ;

      NSGoalView      *pGoalView = new NSGoalView(*pLdvDoc, pSplittedView->getConcern()) ;

      if (pSplittedView->getCreateWindow())
        pGoalView->setCreateWindow(pSplittedView->getCreateWindow()) ;
      else
        pGoalView->setCreateWindow(pSplittedView) ;

      pGoalView->setSplittedWindow(pSplittedView) ;

      NSDocViewManager dvManager(pContexte) ;
      dvManager.createView(pLdvDoc, "Goal Management", pGoalView) ;
    }
  }
  // Follow Up
  else if (pToDo->sParam1 == "FollowUpManagement")
  {
    NSLdvDocument *pLdvDoc ;
    sDocumentType = "LdvDoc" ;
    NSMUEView     *pSplittedView = (NSMUEView *)(pToDo->pPointer1) ;
    if (NULL == pSplittedView)
    {
      NSPatientChoisi *pPatEnCours = pContexte->getPatient() ;
      if (!pPatEnCours)
      {
        erreur("Il n'y a pas de patient actif!", standardError, 0) ;
        return ;
      }
      pPatEnCours->drugs_show(pToDo->sParam2) ;
    }
    else
    {
      NSPatientChoisi *pPatEnCours = pContexte->getPatient() ;
      if (!pPatEnCours)
      {
        erreur("Imposible d'ouvrir la fenetre demand�e ! \nIl n'y a pas de dossier patient actif.\nVeuillez ouvrir un patient.", standardError, 0) ;
        return ;
      }

      // NSPaneSplitter  *pPaneSpl = pSplittedView->getPaneSplitter() ;
      pLdvDoc = pContexte->getPatient()->pDocLdv ;
      if (!pLdvDoc)
        return ;

      NSFollowUpView *pFUView = new NSFollowUpView(*pLdvDoc, pSplittedView->getConcern()) ;

      if (pSplittedView->getCreateWindow())
        pFUView->setCreateWindow(pSplittedView->getCreateWindow()) ;
      else
        pFUView->setCreateWindow(pSplittedView) ;

      pFUView->setSplittedWindow(pSplittedView) ;

      NSDocViewManager dvManager(pContexte) ;
      dvManager.createView(pLdvDoc, "FollowUp Management", pFUView) ;
    }
  }
  // Proc�dures - Processes
  else if (pToDo->sParam1 == "ProcessManagement")
  {
    NSPatientChoisi *pPatEnCours = pContexte->getPatient() ;
    if (!pPatEnCours)
    {
      erreur("Imposible d'ouvrir la fenetre demand�e ! \nIl n'y a pas de dossier patient actif.\nVeuillez ouvrir un patient.  ", standardError, 0) ;
      return ;
    }

    NSLdvDocument *pLdvDoc ;
    sDocumentType = "LdvDoc" ;
    NSMUEView     *pSplittedView = (NSMUEView *)(pToDo->pPointer1) ;
    if (!pSplittedView)
    {
      NSPatientChoisi *pPatEnCours = pContexte->getPatient() ;
      if (!pPatEnCours)
      {
        erreur("Il n'y a pas de patient actif!", standardError, 0) ;
        return ;
      }
      pPatEnCours->process_show(pToDo->sParam2) ;
    }
    else
    {
      pLdvDoc = pContexte->getPatient()->pDocLdv ;
      if (!pLdvDoc)
        return ;

      NSProcessView   *pProcessView         = new NSProcessView(*pLdvDoc, pSplittedView->getConcern()) ;

      if (pSplittedView->getCreateWindow())
        pProcessView->setCreateWindow(pSplittedView->getCreateWindow()) ;
      else
        pProcessView->setCreateWindow(pSplittedView) ;

      pProcessView->setSplittedWindow(pSplittedView) ;

      NSDocViewManager dvManager(pContexte) ;
      dvManager.createView(pLdvDoc, "Process Management", pProcessView) ;
    }
  }
  // Liste des r�sultats de consultation
  else if (pToDo->sParam1 == "EpiRCManagement")
  {
    NSLdvDocument *pLdvDoc ;
    sDocumentType = "LdvDoc" ;
    NSMUEView     *pSplittedView = (NSMUEView *)(pToDo->pPointer1) ;

    pLdvDoc = pContexte->getPatient()->pDocLdv ;
    if (!pLdvDoc)
      return ;

    NSDocViewManager dvManager(pContexte) ;

    if (!pSplittedView)
      dvManager.createView(pLdvDoc, "RC view Format") ;
    else
    {
      NSEpisodRCView   *pRCView = new NSEpisodRCView(*pLdvDoc, pSplittedView->getConcern()) ;

      if (pSplittedView->getCreateWindow())
        pRCView->setCreateWindow(pSplittedView->getCreateWindow()) ;
      else
        pRCView->setCreateWindow(pSplittedView) ;
      pRCView->setSplittedWindow(pSplittedView) ;

      dvManager.createView(pLdvDoc, "RC view Format", pRCView) ;
    }
  }
  // Historique des r�sultats de consultation
  else if (pToDo->sParam1 == "RcItemHistory")
  {
    NSLdvDocument *pLdvDoc ;
    sDocumentType = "LdvDoc" ;
    NSMUEView     *pSplittedView = (NSMUEView *)(pToDo->pPointer1) ;

    pLdvDoc = pContexte->getPatient()->pDocLdv ;
    if (!pLdvDoc)
      return ;

    NSDocViewManager dvManager(pContexte) ;

    if (!pSplittedView)
      dvManager.createView(pLdvDoc, "RC histo Format") ;
    else
    {
      NSRCHistoryView   *pHistoryView = new NSRCHistoryView(*pLdvDoc, pSplittedView->getConcern()) ;

      if (pSplittedView->getCreateWindow())
        pHistoryView->setCreateWindow(pSplittedView->getCreateWindow()) ;
      else
        pHistoryView->setCreateWindow(pSplittedView) ;

      pHistoryView->setSplittedWindow(pSplittedView) ;
      dvManager.createView(pLdvDoc, "RC histo Format", pHistoryView) ;
    }
  }
  // Fiche administrative -
  else if (pToDo->sParam1 == "AdminData")
  {
    NSMUEView *pSplittedView = (NSMUEView *)(pToDo->pPointer1) ;

    if (!pSplittedView)
    {
      bool bOK = true ;

      NSPatientChoisi *pPat = pContexte->getPatient() ;

      NSDocumentInfo  DocumentInfo(pContexte) ;
      string sCodeDocRoot = pContexte->getPatient()->getszNss() + string("_00000") ;
      string sCodeDocAdmin, sCodeDocAdminData ;

      NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
      VecteurString aVecteurString ;
      pGraphe->TousLesVrais(sCodeDocRoot, NSRootLink::personAdminData, &aVecteurString) ;

      if (!aVecteurString.empty())
      {
        sCodeDocAdmin = *(*(aVecteurString.begin())) ;
        aVecteurString.vider() ;
        pGraphe->TousLesVrais(sCodeDocAdmin, NSRootLink::docData, &aVecteurString) ;

        if (!aVecteurString.empty())
        {
          sCodeDocAdminData = *(*(aVecteurString.begin())) ;
          string sCodePat = string(sCodeDocAdminData, 0,            PAT_NSS_LEN) ;
          string sCodeDoc = string(sCodeDocAdminData, PAT_NSS_LEN,  DOC_CODE_DOCUM_LEN) ;

          DocumentInfo.setPatient(sCodePat) ;
          DocumentInfo.setDocument(sCodeDoc) ;
          DocumentInfo.setType("CQ030") ;
        }
        else
        {
          erreur("Impossible de retrouver les donn�es de la fiche administrative.", standardError, 0) ;
          bOK = false ;
        }
      }
      else
      {
        erreur("Impossible de retrouver le document fiche administrative du patient.", standardError, 0) ;
        bOK = false ;
      }

      if (bOK)
      {
        NSPatPathoArray PatPathoAdmin(pContexte) ;
        pPat->pDocHis->DonnePatPathoDocument("ZADMI1", &PatPathoAdmin) ;
        pPat->ChargeDonneesPatient(&PatPathoAdmin) ;
        pPat->initCorrespArray(&PatPathoAdmin) ;
        // pPat->PostInitialisation() ;
      }
      // On doit lancer postinitialisation AVANT d'ouvrir la fiche administrative
      // (fabrication du nom long, calcul de l'age du patient, etc.)
      pPat->pDocHis->AutoriserEdition(&DocumentInfo) ;
    }
  }
  // Document treeWindow - treeWindow document
  else if ((strlen(pToDo->sParam1.c_str()) == BASE_LEXI_LEN + 3) && (string(pToDo->sParam1, 0, 3) == "Cs:"))
  {
    string sRootLexique = string(pToDo->sParam1, 3, BASE_LEXI_LEN) ;

    sDocumentType = "LdvDoc" ;
    NSMUEView     *pSplittedView = (NSMUEView *)(pToDo->pPointer1) ;

    if (!pSplittedView)
    {
      NSCSDocument  *pNewDocCS = new NSCSDocument(0, pContexte, sRootLexique) ;

      NSDocViewManager dvManager(pContexte) ;
      dvManager.createView(pNewDocCS, "CS Format") ;
    }
    else
    {
      /*
      NSPaneSplitter  *pPaneSpl = pSplittedView->getPaneSplitter() ;

      NSCSTemplate    *pCSTemplate = new NSCSTemplate("CS", "", 0, "CS", dtAutoDelete) ;
      NSCSDocument    *pNewDocCS = new NSCSDocument(0, appContext, sRootLexique) ;
      pNewDocCS->SetTemplate(pCSTemplate) ;
      NSCsVue         *pCsVue = new NSCsVue(*pNewDocCS, 0) ;

      if (pSplittedView->getCreateWindow())
        pCsVue->setCreateWindow(pSplittedView->getCreateWindow()) ;
      else
        pCsVue->setCreateWindow(pSplittedView) ;

      pCsVue->setSplittedWindow(pSplittedView) ;

      pCSTemplate->InitView(pCsVue) ;
      */
    }
  }}void
TMyApp::initMenus()
{
	setMenu("menubar", &hAccelerator) ;
}

void
TMyApp::initMainMenu()
{
	// TMenu* menu = new TMenu(*GetApplication()->GetMainWindow()) ;
  // pMainMenu = new TMenu(menu->GetSubMenu(1));

	pMainMenu = new OWL::TMenu ;
  pMainMenu->InsertMenu(0, MF_BYPOSITION, CM_NEWCR, "Nouveau compte-&rendu") ;
}

DEFINE_RESPONSE_TABLE1(NSMDIClient, TMDIClient)
END_RESPONSE_TABLE;


NSMDIClient::NSMDIClient(TModule* module)
            :OWL::TMDIClient(module)
{
}

NSMDIClient::~NSMDIClient()
{
}

static bool
sCannotCloseButServices(TWindow* win, void*)
{
	NSWebServiceChild *wsChild = TYPESAFE_DOWNCAST(win, NSWebServiceChild);
  if (wsChild)
  	return false ;

	return !win->CanClose() ;
}

static void
sCloseChildButServices(TWindow* win, void*)
{
	NSWebServiceChild *wsChild = TYPESAFE_DOWNCAST(win, NSWebServiceChild);
  if (wsChild)
  	return ;

	NSMailServiceChild *mailChild = TYPESAFE_DOWNCAST(win, NSMailServiceChild);
  if (mailChild)
  	return ;

	win->Destroy() ;
  delete win ;
}

bool
NSMDIClient::CloseChildrenButServicesWindows()
{
	if (!FirstThat(sCannotCloseButServices))
  {
    ForEach(sCloseChildButServices) ;
    return true ;
  }
  return false ;
}

/*
NSPrinter::NSPrinter(OWL::TApplication* app)
{
  Data = new OWL::TPrintDialog::TData ;
  Error = 0 ;
  Application = app ? app : ::GetApplicationObject() ;
  CHECK(Application) ;
  GetDefaultPrinter() ;
}


NSPrinter::~NSPrinter()
{
  delete Data ;
  Data = 0 ;
}


#define SETCLEAR(flag, set, clear)((flag) = ((flag)&~(clear))|(set))
#define WM_SETNUMBER    WM_USER+100

// -----------------------------------------------------------------------------
// Abort procedure used during printing, called by windows. Returns true to
// continue the print job, false to cancel.
// -----------------------------------------------------------------------------
int CALLBACK __export
TPrinterAbortProc(HDC hDC, int code)
{
  GetApplicationObject()->PumpWaitingMessages() ;

  // UserAbortDC will have been set by the AbortDialog
  if (OWL::TPrinter::GetUserAbort() == hDC || OWL::TPrinter::GetUserAbort() == HDC(-1))
  {
    OWL::TPrinter::SetUserAbort(0) ;
    return false ;
  }
  return (code == 0 || code == SP_OUTOFDISK) ;
}


bool
NSPrinter::Print(TWindow* parent, TPrintout& printout, bool prompt)
{
  PRECONDITION(parent) ;

  // Start from scratch
  Error = 1 ;           // Positive 'Error' means print job is OK
  TPrintDC*   prnDC ;
  HCURSOR hOrigCursor = ::SetCursor(::LoadCursor(0, IDC_WAIT)) ;

  // Get page range & selection range (if any) from document
  int selFromPage ;
  int selToPage ;
  printout.GetDialogInfo(Data->MinPage, Data->MaxPage, selFromPage, selToPage) ;
  if (selFromPage)
    Data->Flags &= ~PD_NOSELECTION ;
  else
    Data->Flags |= PD_NOSELECTION ;
  if (Data->MinPage)
  {
    Data->Flags &= ~PD_NOPAGENUMS ;
    if (Data->FromPage < Data->MinPage)
      Data->FromPage = Data->MinPage ;
    else if (Data->FromPage > Data->MaxPage)
		  Data->FromPage = Data->MaxPage ;
    if (Data->ToPage < Data->MinPage)
      Data->ToPage = Data->MinPage ;
    else if (Data->ToPage > Data->MaxPage)
      Data->ToPage = Data->MaxPage ;
  }
  else
    Data->Flags |= PD_NOPAGENUMS ;

  // Create & execute a TPrintDialog (or derived) and have it return a usable
  // DC if prompt is enabled. If the dialog fails because the default printer
  // changed, clear our device information & try again.
  if (prompt)
  {
    SETCLEAR(Data->Flags, PD_RETURNDC, PD_RETURNDEFAULT|PD_PRINTSETUP) ;
    bool ok = ExecPrintDialog(parent) ;
    if (!ok && Data->Error == PDERR_DEFAULTDIFFERENT)
    {
		  ClearDevice() ;
      ok = ExecPrintDialog(parent) ;
	 }
    if (!ok)
      return false ;

    prnDC = Data->TransferDC() ;   // We now own the DC, let prnDC manage it
  }
  // Construct the DC directly if prompting was not enabled.
  //
  else
  {
    prnDC = new TPrintDC(Data->GetDriverName(), Data->GetDeviceName(), Data->GetOutputName(), Data->GetDevMode()) ;
  }
  if (!prnDC)
    throw(TXPrinter()) ;

  // Get the page size
  PageSize.cx = prnDC->GetDeviceCaps(HORZRES) ;
  PageSize.cy = prnDC->GetDeviceCaps(VERTRES) ;
  printout.SetPrintParams(prnDC, PageSize) ;

  // Create modeless abort dialog using strings
  TWindow* abortWin ;
  try
  {
    abortWin = CreateAbortWindow(parent, printout) ;
  }
  catch (...)
  {
    delete prnDC ;
    prnDC = 0 ;
    // RETHROW ;
  }

  ::SetCursor(hOrigCursor) ;
  parent->EnableWindow(false) ;

  prnDC->SetAbortProc(TPrinterAbortProc) ;

  // Only band if the user requests banding and the printer supports banding
  bool banding = printout.WantBanding() && (prnDC->GetDeviceCaps(RASTERCAPS) & RC_BANDING) ;
  if (banding)
  {
    // Only use BANDINFO if supported.
    UseBandInfo = ToBool(prnDC->QueryEscSupport(BANDINFO)) ;
  }
  else
  {
    // Set the banding rectangle to full page
    BandRect.Set(0, 0, PageSize.cx, PageSize.cy) ;
  }

  // If more than one (uncollated) copy was requested, see if printer can
  // handle it for performance and user convenience.
  int copiesPerPass = 1 ;
  if (!(Data->Flags & PD_COLLATE))
    prnDC->SetCopyCount(Data->Copies, copiesPerPass) ;

  // Figure out which page range to use: Selection, Dialog's from/to,
  // whole doc range or all possible pages.
  int fromPage ;
  int toPage ;
  if (prompt && (Data->Flags & PD_SELECTION) || selFromPage)
  {
    fromPage = selFromPage ;
    toPage = selToPage ;
  }
  else if (prompt && (Data->Flags & PD_PAGENUMS))
  {
    fromPage = Data->FromPage ;
    toPage = Data->ToPage ;
  }
  else if (Data->MinPage)
  {
    fromPage = Data->MinPage ;
    toPage = Data->MaxPage ;
  }
  else
  {
    fromPage = 1 ;
	  toPage = INT_MAX ;
  }

  // Copies loop, one pass per block of document copies.
  printout.BeginPrinting() ;
  for (int copies = Data->Copies ; copies > 0 && Error > 0 ; copies -= copiesPerPass)
  {
    // On last multi-copy pass, may need to adjust copy count
    if (copiesPerPass > 1 && copies < copiesPerPass)
      prnDC->SetCopyCount(copies, copiesPerPass) ;

    // Whole document loop, one pass per page
    Flags = pfBoth ;
    Error = prnDC->StartDoc(printout.GetTitle(), 0) ;  // get PD_PRINTTOFILE ?
	  printout.BeginDocument(fromPage, toPage, Flags) ;

    for (int pageNum = fromPage ; Error > 0 && pageNum <= toPage && printout.HasPage(pageNum) ; pageNum++)
    {
		  abortWin->SendDlgItemMessage(ID_PAGE, WM_SETNUMBER, pageNum) ;

      // Begin the page by getting the first band or calling StartPage()
      if (banding)
      {
        FirstBand = true ;
        Error = prnDC->NextBand(BandRect) ;
      }
      else
        Error = prnDC->StartPage() ;

      // Whole page loop, one pass per band (once when not banding)
      while (Error > 0 && !BandRect.IsEmpty())
      {
        // [Manually call the abort proc between bands or pages]
#if defined(MANUAL_ABORT_CALL)
        prnDC->QueryAbort() ;
#endif // MANUAL_ABORT_CALL
        if (banding)
        {
          CalcBandingFlags(*prnDC) ;
          if (printout.WantForceAllBands() && (Flags & pfBoth) == pfGraphics)
            prnDC->SetPixel(NS_CLASSLIB::TPoint(0, 0), 0) ;  // Some old drivers need this
          prnDC->DPtoLP(BandRect, 2) ;
        }

		    printout.PrintPage(pageNum, BandRect, Flags) ;
        if (banding)
          Error = prnDC->NextBand(BandRect) ;
        else
          break ;
      }

      // EndPage (NEWFRAME) need only called if not banding
      if (Error > 0 && !banding)
      {
        Error = prnDC->EndPage() ;
        if (Error == 0)    // a zero return here is OK for this call
          Error = 1 ;
      }

    }  // End of Whole Document-loop

    // Tell GDI the document is finished
    if (Error > 0)
#if defined(MANUAL_ABORT_CALL)
      if (banding && (UserAbortDC == *prnDC || UserAbortDC == HDC(-1))
        prnDC->AbortDoc() ;
      else
        prnDC->EndDoc() ;
#else
      prnDC->EndDoc() ;
#endif // !MANUAL_ABORT_CALL

    printout.EndDocument() ;
  } // End of Copy-loop
  printout.EndPrinting() ;

  // Set the printer back to 1 copy
  if (copiesPerPass > 1)
    prnDC->SetCopyCount(1, copiesPerPass) ;

  // Re-enable parent and free allocated resources
  parent->EnableWindow(true) ;
  abortWin->Destroy() ;
  delete abortWin ;
  abortWin =0 ;
  //if (UserAbortDC == *prnDC)  // User tried to abort, but it was too late
  //  UserAbortDC = 0 ;
  delete prnDC ;
  prnDC = 0 ;

  // Report error if not already done so by printmgr
  if (Error & SP_NOTREPORTED)
    ReportError(parent, printout) ;

  return (Error > 0) ;
}
*/



