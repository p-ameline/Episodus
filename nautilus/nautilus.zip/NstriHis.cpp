//**************************************************************************//  Traitement de la fiche historique
//**************************************************************************

#include <owl\listwind.h>
#include <owl\treewind.h>
#include <owl\window.h>

#include "nsbb\nspatpat.h"
#include "nautilus\nshisto.rh"
#include "nautilus\nstrihis.h"
#include "partage\nsdivfct.h"
#include "nsbb\nsTlibre.h"
#include "nautilus\nsrechdl.h"  // pour le dialogue des propri�t�s
#include "nautilus\nscrvue.h"    // Document / Vues CN (Compte-Rendu Nautilus)
#include "nautilus\nsttx.h" 	 // Document / Vues TTX
#include "nautilus\nscsdoc.h"    // Document / Vues CS Consultation
#include "nautilus\nscsvue.h"    // Document / Vues CS Consultation
#include "nautilus\nscqvue.h"   // Document / Vues CQ Formulaires#include "nautilus\nscqdoc.h"#include "nautilus\nsdocview.h"#include "nsbb\nsbb.rh"
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//									 Classe NSTreeHistorique
//----------------------------------------------------------------------
//----------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSTreeHistorique, NSTreeWindow)
	EV_NOTIFY_AT_CHILD(TVN_SELCHANGED, SelChanged),
  EV_WM_LBUTTONDBLCLK,  //double click
  EV_WM_CLOSE,
  EV_WM_KEYDOWN,
	EV_WM_SETFOCUS,
  EV_WM_VSCROLL,
  EV_WM_HSCROLL,
  NS_TV_KEYDOWN(EvTvKeyDown),
  EV_WM_RBUTTONDOWN,
  EV_COMMAND(IDC_OUVRIR, Ouvrir),
  EV_COMMAND(CM_EDITER, Editer),
  EV_COMMAND(IDC_TOUTOUVRIR, ToutOuvrir),
  EV_COMMAND(IDC_OTER, Oter),
  EV_COMMAND(IDC_PROPRIETE, Proprietes),
  EV_COMMAND(IDC_PARAMETRES, Parametres),
  EV_COMMAND(IDC_DETRUIRE, Detruire),
  EV_COMMAND(IDC_XML_EXPORT, XmlExport),
END_RESPONSE_TABLE;

//----------------------------------------------------------------------
//----------------------------------------------------------------------
NSTreeHistorique::NSTreeHistorique(TWindow* parent, NSContexte* pCtx,
                                    int id, int x, int y, int w, int h,
                                    NSHISTODocument* pDocu,
                                    TModule* module, TStyle style)
                 :NSTreeWindow(parent, pCtx, id, x, y, w, h, style, module)
{
try
{
    pDoc        = pDocu;
    sImportance = "";
    pBigBoss 	= 0;
    NSTreeWindow* pNSTreeWindow = this;
    pNSPatPathoArray = new NSPatPathoArray(pContexte); //patpatho globale de l'historique
                                                    //form�e par les titres des documents

    skinName    = string("historyWindow");              // nom de la fenetre de skin
    pNSTreeWindow->ReadOnly = true;
}
catch (...)
{
    erreur("Exception NSTreeHistorique ctor.", standardError, 0) ;
}
}

//----------------------------------------------------------------------//			Destructeur
//----------------------------------------------------------------------
NSTreeHistorique::~NSTreeHistorique()
{
    delete pBigBoss;
    delete pNSPatPathoArray;
    delete ImagesHisto;
}

//---------------------------------------------------------------------------//  Description:	Surcharge de l'op�rateur d'affectation
//---------------------------------------------------------------------------
NSTreeHistorique&
NSTreeHistorique::operator = (NSTreeHistorique src)
{
    pDoc  		= src.pDoc;
    sImportance = src.sImportance ;
    return *this;
}

//---------------------------------------------------------------------------// SetupWindow
//---------------------------------------------------------------------------
void
NSTreeHistorique::SetupWindow()
{
try
{
	HINSTANCE hInstModule ;

  TTreeWindow::SetupWindow();

  skinSwitchOn(skinName) ;

  ImagesHisto = new TImageList(NS_CLASSLIB::TSize(16, 16), ILC_COLOR4, 15, 5) ;

  hInstModule = *GetApplication() ;

  //Int�ret sur les pathos
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_0PLUS)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_1PLUS)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_2PLUS)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_3PLUS)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_4PLUS)) ;

  //CR ferm� et ouvert
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_OUVERT)) ;
  //CS ferm� et ouvert
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CONSULTATION)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CS_OUVERT)) ;
//document sans bitmap
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_VIDE)) ;
  //HD CR et CS ouverts
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_HD)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CS_HD)) ;
  //image
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_IMAGE)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_IMAGE_FERME)) ;
  //texte
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_TLIB)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_INCLUS)) ;
  //CQ ferm� et ouvert  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CQ)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CQ_OUVERT)) ;
  //Acrobat ferm� et ouvert
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_AR)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_AR_OUVERT)) ;

  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_1)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_OUVERT_1)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CONSULTATION_1)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CS_OUVERT_1)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_VIDE_1)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_HD_1)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CS_HD_1)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_IMAGE_1)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_IMAGE_FERME_1)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_TLIB_1)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_INCLUS)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CQ_1)) ;  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CQ_OUVERT_1)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_AR_1)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_AR_OUVERT_1)) ;

  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_2)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_OUVERT_2)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CONSULTATION_2)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CS_OUVERT_2)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_VIDE_2)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_HD_2)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CS_HD_2)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_IMAGE_2)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_IMAGE_FERME_2)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_TLIB_2)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_INCLUS)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CQ_2)) ;  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CQ_OUVERT_2)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_AR_2)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_AR_OUVERT_2)) ;

  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_3)) ;  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_OUVERT_3)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CONSULTATION_3)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CS_OUVERT_3)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_VIDE_3)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_HD_3)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CS_HD_3)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_IMAGE_3)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_IMAGE_FERME_3)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_TLIB_3)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_INCLUS)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CQ_3)) ;  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CQ_OUVERT_3)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_AR_3)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_AR_OUVERT_3)) ;

  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_4)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_OUVERT_4)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CONSULTATION_4)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CS_OUVERT_4)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_VIDE_4)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CR_HD_4)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CS_HD_4)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_IMAGE_4)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_IMAGE_FERME_4)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_TLIB_4)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_INCLUS)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CQ_4)) ;  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_CQ_OUVERT_4)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_AR_4)) ;
  ImagesHisto->Add(OWL::TBitmap(hInstModule, IDB_AR_OUVERT_4)) ;

  SetImageList(TTreeWindow::Normal, *ImagesHisto) ;

  #define IndexIcone_0plus     0
  #define IndexIcone_1plus     1
  #define IndexIcone_2plus     2
  #define IndexIcone_3plus     3
  #define IndexIcone_4plus     4

  #define IndexIcone_CR 		   5
  #define IndexIcone_CRouvert  6
  #define IndexIcone_CS 		   7
  #define IndexIcone_CSouvert  8

  #define IndexIcone_vide 	   9

  #define IndexIcone_CRcompo 	10
  #define IndexIcone_CScompo 	11

  #define IndexIcone_Image 	  12  #define IndexIcone_ImageFer 13

  #define IndexIcone_tlib 	  14
  #define IndexIcone_inclus 	15

  #define IndexIcone_CQ       16  #define IndexIcone_CQouvert 17  #define IndexIcone_AR       18  #define IndexIcone_ARouvert 19  #define IndexDecalage		    15
  AfficheDocument() ;
}
catch (...)
{
	erreur("Exception NSTreeHistorique::SetupWindow.", standardError, 0) ;
}
}

//------------------------------------------------------------------------//date de cr�ation d'un document (CR ou CS), pPat est sa patpatho
//------------------------------------------------------------------------
void
NSTreeHistorique::DateCreation(NSDocumentHisto* pNSDocumentHisto)
{
	if (NULL == pNSDocumentHisto)
		return ;

	if (string("ZCN00") == pNSDocumentHisto->getType())
	{		NSPatPathoArray Pat(pContexte) ;
		string sDate = string("") ;
		pNSDocumentHisto->DonnePatPatho(&Pat) ;

    // on cherche d'abord dans la patpatho
		if (!Pat.empty())
		{
  		// First, check if first element is a KCHIR
    	//
  		PatPathoIter iterPpt = Pat.begin() ;
    	iterPpt++ ;
    	if (iterPpt != Pat.end())
    		if ((*iterPpt)->getLexiqueSens(pContexte) == "KCHIR")
      		Pat.CheminDansPatpatho(pBigBoss, "KCHIR", &sDate) ;

    	if (sDate == string(""))
				Pat.CheminDansPatpatho(pBigBoss, "LADMI/KCHIR", &sDate) ;
		}

    if (sDate != string(""))
    	pNSDocumentHisto->setCreDate(sDate) ;
	}
}

//-----------------------------------------------------------------------// Afficher l'ensemble des documents visibles.
// Principe 	 :	1. trier les documents dans l'ordre de leurs cr�ations
//					2. extraire la patpatho de chacun d'entre eux
//					3. former pNSPatPathoArray (patpatho de l'historique):
//					   contient les t�tes des patpathos
//					4. dispatcher pNSPatPathoArray par NSTreeWindow
//-----------------------------------------------------------------------
void
NSTreeHistorique::AfficheDocument()
{
try
{
	pNodeArray->vider();
	//ensemble des documents � afficher
	NSPatPathoArray* pPatAffiche = new NSPatPathoArray(pContexte);

	if (pDoc->VectDocument.empty())
	{
  	NSPatPathoArray PAT = *pPatAffiche ;
    pBigBoss  = new NSSmallBrother(pContexte, pPatAffiche) ;
    //le patient lance l'historique
		pBigBoss->lanceConsult("HPATI1", this) ;
    *pNSPatPathoArray = PAT ;
    DispatcherPatPatho(pNSPatPathoArray, 0, 0, "") ;

    if (!pBigBoss->getPatPatho()->empty())
			pBigBoss->MetTitre() ;
		delete pPatAffiche ;
    return ;
	}

	// on stocke l'�l�ment 0 de chaque patpatho dans pPatAffiche
	DocumentIter iterDoc = pDoc->VectDocument.begin() ;
	for (; iterDoc != pDoc->VectDocument.end(); iterDoc++)
	{
		if (!((*iterDoc)->pPatPathoArray->empty()))
		{
			PatPathoIter iter = (*iterDoc)->pPatPathoArray->begin() ;
			pPatAffiche->push_back(new NSPatPathoInfo(*(*iter))) ;
		}
		else
		{
    	NSPatPathoInfo* pPpt = new NSPatPathoInfo() ;
      pPpt->setLexique((*iterDoc)->getContent()) ;
    	pPatAffiche->push_back(pPpt) ;
		}
	}

	//adapter les lignes et colonnes des pathos de pPatAffiche
	PatPathoIter Iter = pPatAffiche->begin();
	int ligne = 0;
	for (; Iter != pPatAffiche->end(); Iter++)
	{
		(*Iter)->setLigne(ligne) ;
    (*Iter)->setColonne(0) ;
		ligne++ ;
	}

	//sauvegarder provisoirement
	NSPatPathoArray PAT = *pPatAffiche ;
	pBigBoss  = new NSSmallBrother(pContexte, pPatAffiche) ;
	//le patient lance l'historique
	pBigBoss->lanceConsult("HPATI1", this) ;

	*pNSPatPathoArray = PAT ;
	DispatcherPatPatho(pNSPatPathoArray, 0, 0, "") ;

	if (!pBigBoss->getPatPatho()->empty())
		pBigBoss->MetTitre() ;
	delete pPatAffiche ;

	//
	// Pour chaque noeud supportant un document changer
	// son label (label + date de cr�ation)
	//
	iterDoc = pDoc->VectDocument.begin() ;
	iterNSTreeNode iterNode = pNodeArray->begin() ;

	for (; (iterDoc != pDoc->VectDocument.end()) && (iterNode != pNodeArray->end())
         				    ; iterDoc++, iterNode++)
	{
		(*iterNode)->pDocument = static_cast<void*>((*iterDoc));
		//
		// Ouvrir automatiquement la fiche de synth�se : changer la bitmap
		//
		// if (strcmp((*iterDoc)->pDonnees->nom, "Synth�se") == 0)
    if (string("ZSYNT") == (*iterDoc)->getSemCont())
			AfficheIcone(IndexIcone_CSouvert, (*iterNode)) ;
		else
		{
/*
			if (string("HD") == string((*iterDoc)->getType(), 0, 2))
			{
				// AfficheIcone(IndexIcone_CRcompo, (*iterNode));

				NSDocumentInfo* pDocHtml = 0 ;
				NSDocumentInfo* pDocument = new NSDocumentInfo(*(*iterDoc)) ;
				// on retrouve le document brut
				if (!pContexte->ChercheComposition(&pDocument, &pDocHtml))
				{
          string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "theReferenceDocumentCannotBeFound") ;
    			sErrorText += string(" (") + pDocument->getPatient() + string(" ") + pDocument->getDocument() + string(")") ;
    			pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
    			erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;

					delete pDocument ;
					return ;
				}

				if      (string("ZCN00") == pDocument->getType())
        	AfficheIcone(IndexIcone_CRcompo, (*iterNode)) ;
        else if (string("ZCS00") == pDocument->getType())
        	AfficheIcone(IndexIcone_CScompo, (*iterNode)) ;
        else if (string("ZCQ00") == pDocument->getType())
        	AfficheIcone(IndexIcone_CQ, (*iterNode)) ;
        else if (string("ZTPDF") == pDocument->getType())
        	AfficheIcone(IndexIcone_AR, (*iterNode)) ;
        else if (pContexte->typeDocument(pDocument->getType(), NSSuper::isImage))
        	AfficheIcone(IndexIcone_Image, (*iterNode)) ;
        else if (pContexte->typeDocument(pDocument->getType(), NSSuper::isText))
        	AfficheIcone(IndexIcone_tlib, (*iterNode)) ;
        else
        	AfficheIcone(IndexIcone_vide, (*iterNode)) ;

				delete pDocument;
        delete pDocHtml;
			}
      else
      {
*/
      	if      (string("ZCN00") == (*iterDoc)->getType())
        	AfficheIcone(IndexIcone_CR, (*iterNode)) ;
        else if (string("ZCS00") == (*iterDoc)->getType())
        	AfficheIcone(IndexIcone_CS, (*iterNode)) ;
        else if (string("ZCQ00") == (*iterDoc)->getType())
        	AfficheIcone(IndexIcone_CQ, (*iterNode)) ;
        else if (string("ZTPDF") == (*iterDoc)->getType())
        	AfficheIcone(IndexIcone_AR, (*iterNode)) ;
        else if (pContexte->typeDocument((*iterDoc)->getType(), NSSuper::isImage))
        	AfficheIcone(IndexIcone_Image, (*iterNode)) ;
        else if (pContexte->typeDocument((*iterDoc)->getType(), NSSuper::isText))
        	AfficheIcone(IndexIcone_tlib, (*iterNode)) ;
        else
        	AfficheIcone(IndexIcone_vide, (*iterNode)) ;
//			}
		}
		SetLabelNode(*iterNode, *iterDoc) ;
	}
}
catch (...)
{
	erreur("Exception NSTreeHistorique::AfficheDocument.", standardError, 0) ;
}
}

//--------------------------------------------------------------------------// Ajoute un document � l'historique, deux cas :
//	1:	il sera plac� selon sa date de cr�ation.
//		S'il est le plus r�cent , c'est le Root qui le cr�e en tant que fils
//		sinon c'est son fr�re dont la date de cr�ation est la plus proche qui le cr�e
//		en tant que fr�re.
//	2: s'il est compos�, il remplace son document brut.
//
//  Note : Dans cette fonction, le document est d�j� ouvert, donc
//		   on met � jour l'historique
//--------------------------------------------------------------------------
void
NSTreeHistorique::AjouteDocument(NSDocumentInfo* pNSDocumentInfo, NSPatPathoArray* pNSPatPath,
                                 NSNoyauDocument* pNouveauDocument)
{
try
{
	if (NULL == pNSDocumentInfo)
		return ;

	// V�rifier que ce document n'existe pas dans l'historique
  //
  iterNSTreeNode iterNode = pNodeArray->begin() ;
  string codeDocBrut = pNSDocumentInfo->getID() ;
  string typeDocBrut ;

  iterNode = TrouveNoeud(codeDocBrut) ;
  if (iterNode != pNodeArray->end())
  {
  	NSDocumentHisto* pDocHisto = static_cast<NSDocumentHisto*>((*iterNode)->pDocument) ;
    if (NULL == pDocHisto)
    	return ;

    *(pDocHisto->getData()) = *(pNSDocumentInfo->getData()) ;

    return ;
	}

	// on cr�e un nouveau DocumentHisto avec sa patpatho
  NSDocumentHisto* pNSDocumentHisto = new NSDocumentHisto(pNSDocumentInfo) ;
  if (NULL != pNSPatPath)
  	*(pNSDocumentHisto->pPatPathoArray) = *pNSPatPath ;
  else //document type image, HTML qui n'ont pas de patpatho
  	pNSDocumentHisto->DonnePatPatho(pNSDocumentHisto->pPatPathoArray) ;

  //
  // Cas o� pNSDocumentHisto est compos�, il remplace son document brut
  //
/*
  if (string("HD") == string(pNSDocumentInfo->getType(), 0, 2))
  {
  	NSDocumentInfo* pDocHtml = 0 ;
    NSDocumentInfo* pDocument = new NSDocumentInfo(*pNSDocumentInfo) ;

    // on retrouve le document brut
    if (!pContexte->ChercheComposition(&pDocument, &pDocHtml))
    {
      string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "theReferenceDocumentCannotBeFound") ;
      sErrorText += string(" (") + pDocument->getPatient() + string(" ") + pDocument->getDocument() + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
      erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;

      delete pDocument ;
      return ;
    }

    codeDocBrut = pDocument->getID() ;
    typeDocBrut = pDocument->getType() ;

    if (NULL != pNouveauDocument)
    {
    	// Trouver le noeud correspondant au document brut
      //
      iterNSTreeNode iterNode = pNodeArray->begin() ;
      iterNode = TrouveNoeud(codeDocBrut) ;
      if (iterNode != pNodeArray->end())
      {
      	(*iterNode)->pDocument = static_cast<void*>(pNSDocumentHisto) ;
        if      (string("ZCN00") == pDocument->getType())
        	AfficheIcone(IndexIcone_CRouvert, (*iterNode));
        else if (string("ZCS00") == pDocument->getType())
        	AfficheIcone(IndexIcone_CSouvert, (*iterNode));
        else if (string("ZCQ00") == pDocument->getType())        	AfficheIcone(IndexIcone_CQouvert, (*iterNode));
        else if (string("ZTPDF") == pDocument->getType())
        	AfficheIcone(IndexIcone_ARouvert, (*iterNode));

        // on d�clare ouvert le nouveau document HDHTM
        // qui a remplac� le document brut dans pNodeArray
        // (on ferme le document brut devenu invisible)
        pDoc->FermeDocumentOuvert(pDocument) ;
        pDoc->RangeDocumentOuvert(pDocHtml, pNouveauDocument) ;
      }
      else
      {   // Attention ne pas faire le delete pNSDocumentHisto dans l'autre cas
      	string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "theReferenceDocumentCannotBeFound") ;
        sErrorText += string(" (") + pNSDocumentHisto->getPatient() + string(" ") + pNSDocumentHisto->getDocument() + string(")") ;
        pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
        erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
        delete pNSDocumentHisto ;
      }

      delete pDocument ;
      delete pDocHtml ;
      return ;
    }
  }
*/

	// Ancienne m�thode d'Hafedh qui �crase la date de creation des CN
	// DateCreation(pNSDocumentHisto);

	char dateAffiche[20] ;
  string sAffiche = pNSDocumentHisto->getDocName() ;
  strip(sAffiche, stripBoth) ;
  if (strcmp(pNSDocumentHisto->GetDateDoc(), "") != 0)
  {
  	string sLang = "" ;
		if (pContexte->getUtilisateur())
			sLang = pContexte->getUtilisateur()->donneLang() ;

    sAffiche += string(" - ") ;
  	// strcat(chAffiche, " du ") ;
    donne_date(pNSDocumentHisto->GetDateDoc(), dateAffiche, sLang) ;
    sAffiche += dateAffiche ;
  }
  //
  // insertion de ce nouveau document: pNSDocumentHisto sera plac� juste apr�s
  // le premier document (s'il existe) le plus recent par rapport � lui , sinon
  // il sera cre� par le Root � la t�te de l'historique
  //
  iterNSTreeNode iterGrandFrere = pNodeArray->begin() ;
  int ligne   = -1 ;
  char dateAfficheNoeud[20] ;
  iterNode = pNodeArray->begin() ;
  bool bOk = false ;

  string sDateInfo = string(pNSDocumentHisto->GetDateDoc());
  for (; iterNode != pNodeArray->end(); iterNode++)
  {
		NSDocumentHisto* pDocument = static_cast<NSDocumentHisto*>((*iterNode)->pDocument) ;
    int Ligne = (*iterNode)->getLigne() ;
    if (pDocument)
    {
    	string sDateNode = string(pDocument->GetDateDoc()) ;
      if ((sDateNode > sDateInfo) && (Ligne > ligne))
      {
      	iterGrandFrere = iterNode ;
        ligne = (*iterGrandFrere)->getLigne() ;
        bOk = true ;
      }
    }
  }
  TTreeNode root = GetRoot() ;
  NSTreeNode* pNewNSTreeNode = 0 ;
  //
  // Il existe un document plus r�cent, c'est lui qui cr�e le nouveau
  //
  if (bOk)
  {
  	int colonne = 0 ;
    // Coordonn�es du dernier petit fils(s'il existe) de iterGrandFrere
    GetMaxCoordonnees(*iterGrandFrere, &ligne, &colonne) ;

    // D�caler les lignes des autres noeuds d'une unit�
    iterNSTreeNode iterN = pNodeArray->begin() ;
    for(; iterN != pNodeArray->end(); iterN++)
    	if ((*iterN)->getLigne() > ligne)
      	(*iterN)->setLigne((*iterN)->getLigne() + 1) ;

    pNewNSTreeNode = new NSTreeNode((*iterGrandFrere)->InsertItem(TTreeNode(*this, "")), pContexte) ;
    ligne++ ;
  }
  //
  // Il n'existe pas de document plus r�cent, c'est le Root qui cr�e
  //
  else
  {
  	// D�caler les lignes des autres noeuds d'une unit�
    iterNSTreeNode iterN = pNodeArray->begin() ;
    for (; iterN != pNodeArray->end(); iterN++)
    	(*iterN)->setLigne((*iterN)->getLigne() + 1) ;

    ligne = 1 ;
    TTreeNode* pAmorce = new TTreeNode(*this, TVI_FIRST) ;
    *pAmorce = root.InsertChild(*pAmorce, TTreeNode::First) ;
    pNewNSTreeNode = new NSTreeNode(*pAmorce, pContexte) ;
    delete pAmorce ;
  }
  //
  // Initialisation du nouveau noeud
  //
  pNewNSTreeNode->pere = 0 ;
  pNewNSTreeNode->FrerePilote = 0 ;

  // Declaration d'ouverture du document
  // (dans le cas d'un nouveau document, celui-ci est forc�ment ouvert � l'�cran,
  //  et on doit le signaler � l'historique en appelant RangeDocumentOuvert
  //  sinon on ne doit pas le d�clarer ouvert ici - c'est g�r� ailleurs -)
  if (pNouveauDocument)
  	pDoc->RangeDocumentOuvert(pNSDocumentInfo, pNouveauDocument) ;

  NSTlibre* pNSTlibre = 0 ;
  bool texteRecupere ;
  int tailleVecteur = 0 ;
  if ((pNSDocumentHisto->pPatPathoArray) && (!(pNSDocumentHisto->pPatPathoArray->empty())))
  {
  	string  sTexteLibre = (*(pNSDocumentHisto->pPatPathoArray->begin()))->getTexteLibre() ;
    string  sIdentite   = (*(pNSDocumentHisto->pPatPathoArray->begin()))->getLexique() ;
    /* bool bTexte = */ pNewNSTreeNode->MettreAjourLabel(pNSTlibre, &texteRecupere, &tailleVecteur,
                                ligne, 0, sTexteLibre, "", sIdentite, this, sLang) ;
	}

  pNewNSTreeNode->pDocument = static_cast<void*>(pNSDocumentHisto) ;

  pNewNSTreeNode->sLabel = sAffiche ;
  pNewNSTreeNode->SetText(sAffiche.c_str(), true) ;

  // Mise en place des icones
  //
  string sTypeDoc = pNSDocumentInfo->getType() ;

  if (sTypeDoc == "ZCN00")
  {
  	if (pDoc->EstUnDocumentOuvert(pNSDocumentInfo))
    	AfficheIcone(IndexIcone_CRouvert, pNewNSTreeNode) ;
    else
    	AfficheIcone(IndexIcone_CR, pNewNSTreeNode) ;
	}
  else if (sTypeDoc == "ZCS00")
  {
    if (pDoc->EstUnDocumentOuvert(pNSDocumentInfo))
    	AfficheIcone(IndexIcone_CSouvert, pNewNSTreeNode) ;
    else
    	AfficheIcone(IndexIcone_CS, pNewNSTreeNode) ;
	}
  else if (sTypeDoc == "ZCQ00")
  {
    if (pDoc->EstUnDocumentOuvert(pNSDocumentInfo))
      AfficheIcone(IndexIcone_CQouvert, pNewNSTreeNode) ;
    else
      AfficheIcone(IndexIcone_CQ, pNewNSTreeNode) ;
	}
  else if (sTypeDoc == "ZTPDF")
  {
    if (pDoc->EstUnDocumentOuvert(pNSDocumentInfo))
      AfficheIcone(IndexIcone_ARouvert, pNewNSTreeNode) ;
    else
      AfficheIcone(IndexIcone_AR, pNewNSTreeNode) ;
	}
  else if (sTypeDoc == "ZDHTM")
  {
  	if (typeDocBrut == string("ZCN00"))
    {
    	if (pDoc->EstUnDocumentOuvert(pNSDocumentInfo))
      	AfficheIcone(IndexIcone_CRouvert, pNewNSTreeNode) ;
      else
      	AfficheIcone(IndexIcone_CRcompo, pNewNSTreeNode) ;
    }
    else if (typeDocBrut == string("ZCS00"))
    {
    	if (pDoc->EstUnDocumentOuvert(pNSDocumentInfo))
      	AfficheIcone(IndexIcone_CSouvert, pNewNSTreeNode) ;
      else
      	AfficheIcone(IndexIcone_CScompo, pNewNSTreeNode) ;
    }
  }
	else if (pContexte->typeDocument(sTypeDoc, NSSuper::isImage))
	{
  	if (pDoc->EstUnDocumentOuvert(pNSDocumentInfo))
    	AfficheIcone(IndexIcone_ImageFer, pNewNSTreeNode) ;
    else
    	AfficheIcone(IndexIcone_Image, pNewNSTreeNode) ;
	}
	else if (pContexte->typeDocument(sTypeDoc, NSSuper::isText))
	{
  	AfficheIcone(IndexIcone_tlib, pNewNSTreeNode) ;
	}
	else
  	AfficheIcone(IndexIcone_vide, pNewNSTreeNode) ;

	//delete pNSTlibre;
	pDoc->VectDocument.push_back(pNSDocumentHisto) ;
}
catch (...)
{
	erreur("Exception NSTreeHistorique::AjouteDocument.", standardError, 0) ;
}
}

//--------------------------------------------------------------------------// Enlever le document pNSDocumentHisto de l'historique
//--------------------------------------------------------------------------
void
NSTreeHistorique::EnleverDocument(NSDocumentInfo* pNSDocumentHisto)
{
	if ((pNodeArray) && (!(pNodeArray->empty())))
	{
    iterNSTreeNode iterNode = pNodeArray->begin() ;
    string codeDocBrut = pNSDocumentHisto->getID() ;
    iterNode = TrouveNoeud(codeDocBrut) ;
    if (iterNode != pNodeArray->end())
    {
      int ligne  	 = (*iterNode)->getLigne() ;
      int cardinal = 1 ; //nb fils et petits fils

      // on remove le node de la TreeView
      (*iterNode)->Delete() ;
      // on d�truit ses fils
      DetruitFils(&cardinal, *iterNode) ;

      // on enleve le node de l'Array de son p�re
      if ((*iterNode)->pere)
        (*iterNode)->pere->VectFils.erase(iterNode) ;

      delete (*iterNode) ;
      // enlever le node (et ses fr�res li�s ) de pNodeArray
      pNodeArray->erase(iterNode) ;

      //mettre � jour les coordonn�es des autres NSTreeNodes
      for (iterNSTreeNode iter = pNodeArray->begin(); iter != pNodeArray->end(); iter++)
        if ((*iter)->getLigne() > ligne)
            (*iter)->setLigne((*iter)->getLigne() - cardinal ) ;
    }
	}

	// on enleve le document de l'array des documents ouverts
	if (pDoc->EstUnDocumentOuvert(pNSDocumentHisto))
		pDoc->FermeDocumentOuvert(pNSDocumentHisto) ;
}

//-------------------------------------------------------------------------//changer la BITmap d'un document qui vient d'�tre ferm�
//-------------------------------------------------------------------------
void
NSTreeHistorique::FermetureDocument(NSDocumentInfo* pDocumentInfo)
{
  if ((pNodeArray) && (!(pNodeArray->empty())))
  {
  	string codeDocBrut = pDocumentInfo->getID() ;
    iterNSTreeNode iterNode = pNodeArray->begin() ;
    iterNode = TrouveNoeud(codeDocBrut) ;
    if (iterNode != pNodeArray->end())
    {
    	NSDocumentHisto* pDocument = static_cast<NSDocumentHisto*>((*iterNode)->pDocument) ;
/*
      if (string("ZDHTM") == pDocumentInfo->getType())
      {
      	NSDocumentInfo* pDocHtml = 0 ;
        NSDocumentInfo* pDocum = new NSDocumentInfo(*pDocumentInfo) ;
        // on retrouve le document brut
        if (!pContexte->ChercheComposition(&pDocum, &pDocHtml))
        {
        	string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "theReferenceDocumentCannotBeFound") ;
    			sErrorText += string(" (") + pDocument->getPatient() + string(" ") + pDocument->getDocument() + string(")") ;
    			pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
    			erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
          delete pDocum ;
          return ;
        }

        if      (string("ZCN00") == pDocum->getType())
        	AfficheIcone(IndexIcone_CRcompo, *iterNode);
        else if (string("ZCS00") == pDocum->getType())
        	AfficheIcone(IndexIcone_CScompo, *iterNode);
        delete pDocum;
      	delete pDocHtml;
      }
      else
      {
*/
      	if      (string("ZCN00") == pDocument->getType())
        	AfficheIcone(IndexIcone_CR, *iterNode) ;
        else if (string("ZCS00") == pDocument->getType())
        	AfficheIcone(IndexIcone_CS, *iterNode) ;
        else if (string("ZCQ00") == pDocument->getType())        	AfficheIcone(IndexIcone_CQ, *iterNode) ;
        else if (string("ZTPDF") == pDocument->getType())
        	AfficheIcone(IndexIcone_AR, *iterNode) ;
        else if (pContexte->typeDocument(pDocument->getType(), NSSuper::isImage))
        	AfficheIcone(IndexIcone_Image, *iterNode) ;
        else if (pContexte->typeDocument(pDocument->getType(), NSSuper::isText))
        	AfficheIcone(IndexIcone_tlib, *iterNode) ;
        else
        	AfficheIcone(IndexIcone_vide, *iterNode) ;
//      }
    }
  }
  pDoc->FermeDocumentOuvert(pDocumentInfo) ;
}

//-------------------------------------------------------------------------//  Visualisation d'un document : mise en avant s'il est d�j� ouvert,
//                                ouverture sinon//-------------------------------------------------------------------------
void
NSTreeHistorique::VisualiserDocument(NSTreeNode* pNSDocNode)
{
	if (NULL == pNSDocNode)
		return ;

	NSDocumentHisto* pDocument = getDocumentForNode(pNSDocNode) ;
  if (NULL == pDocument)
		return ;

	//
	// Si le document est d�j� ouvert, on le met en premier plan
	//
	if (pDoc->EstUnDocumentOuvert(pDocument))
	{
  	pDoc->ActiveFenetre(pDocument) ;
    return ;
	}

	if (!(pContexte->userHasPrivilege(NSContexte::openDocument, -1, -1, pDocument->getAuthor(), string(""), NULL, NULL)))
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
    erreur(sErrorText.c_str(), warningError, 0) ;
    return ;
	}

	//
	// S'il n'�tait pas d�j� ouvert, on l'ouvre
	//
	HCursor = ::SetCursor(::LoadCursor(0, IDC_WAIT)) ;

	/******************* Affichage de l'ic�ne correspondant au document ouvert ***********/

	//	// 1. Cas des documents compos�s (HTML dynamique)
	//
/*
	if (string("ZDHTM") == pDocument->getType())
	{
  	NSDocumentInfo* pDocHtml = 0 ;
    NSDocumentInfo* pDocum = new NSDocumentInfo(pContexte) ;
    *(pDocum->getData()) = *(pDocument->getData()) ;

    //    // On retrouve le document brut
    //
    if (!pContexte->ChercheComposition(&pDocum, &pDocHtml))
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "theReferenceDocumentCannotBeFound") ;
      sErrorText += string(" (") + pDocument->getPatient() + string(" ") + pDocument->getDocument() + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
      erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;

      delete pDocum ;
      return ;
    }

    //    // S�lection de l'icone
    //
    if      (string("ZCN00") == pDocum->getType())
    	AfficheIcone(IndexIcone_CRouvert, pNSDocNode);
    else if (string("ZCS00") == pDocum->getType())
    	AfficheIcone(IndexIcone_CSouvert, pNSDocNode);

    delete pDocum ;    delete pDocHtml ;
	}
  //
  // 2. cas des documents non compos�s (bruts)
  //
  else
  {
*/
  	//
    // S�lection de l'icone
    //
    if      (string("ZCN00") == pDocument->getType())
    	AfficheIcone(IndexIcone_CRouvert, pNSDocNode) ;
    else if (string("ZCS00") == pDocument->getType())
    	AfficheIcone(IndexIcone_CSouvert, pNSDocNode) ;
    else if (string("ZCQ00") == pDocument->getType())    	AfficheIcone(IndexIcone_CQouvert, pNSDocNode) ;
    else if (string("ZTPDF") == pDocument->getType())
    	AfficheIcone(IndexIcone_ARouvert, pNSDocNode) ;
    else if (pContexte->typeDocument(pDocument->getType(), NSSuper::isImage))
    	AfficheIcone(IndexIcone_ImageFer, pNSDocNode) ;
    else if (pContexte->typeDocument(pDocument->getType(), NSSuper::isText))
    	AfficheIcone(IndexIcone_tlib, pNSDocNode) ;
    else
    	AfficheIcone(IndexIcone_vide, pNSDocNode) ;
//  }

  /************************* Ouverture effective du document (par NSSuper) ************/
  //
  // Double affectation utile dans le cas d'un document Hd
  // sinon pDocum sera transform� en document brut
  //
  NSDocumentInfo* pDocum = new NSDocumentInfo(pContexte) ;
  *(pDocum->getData()) = *(pDocument->getData()) ;
  NSNoyauDocument* pDocNoy ;   // pointeur sur le document cr�� par OuvreDocument
  // Ouverture en lecture seule
  pDocNoy = pContexte->getSuperviseur()->OuvreDocument(*pDocum, pContexte, true) ;
  if (pDocNoy)
  {
  	// on reprend les donnees pour �viter l'effet de bord de OuvreDocument
    // (switch entre document HD et document brut CN)
    *(pDocum->getData()) = *(pDocument->getData()) ;

    // on range le pHtmlInfo dans le cas d'un HD
    // (permet de savoir que le document est compos�)
    pDoc->RangeDocumentOuvert(pDocum, pDocNoy) ;
  }
  delete pDocum ;
  HCursor = ::SetCursor(::LoadCursor(0, IDC_ARROW)) ;
}

//-------------------------------------------------------------------------
// Rafra�chir l'historique en tenant compte des changements (exemple patpatho)
// de pNSDocumentHisto
//-------------------------------------------------------------------------
void
NSTreeHistorique::VisualiserPatho(NSDocumentInfo* pDocumentInfo, NSPatPathoArray* pNSPatPathoArray)
{
	if (NULL == pDocumentInfo)
		return ;

	NSDocumentHisto* pDocumentHisto ;

	string codeDocBrut = pDocumentInfo->getID() ;
	iterNSTreeNode pNSTreeNodeSelection = TrouveNoeud(codeDocBrut) ;

	if ((pNodeArray->end() == pNSTreeNodeSelection) || (NULL == pNSTreeNodeSelection))
		return ;

	pDocumentHisto = static_cast<NSDocumentHisto*>((*pNSTreeNodeSelection)->pDocument) ;

  // Updating NSDocumentInfo
  if (pDocumentInfo)
  {
  	*(pDocumentHisto->getData()) = *(pDocumentInfo->getData()) ;

    // Updating presentation information
    if (pDocumentInfo->pPres && (false == pDocumentInfo->pPres->empty()))
  	  *(pDocumentHisto->pPres) = *(pDocumentInfo->pPres) ;

    // Updating meta data
    if (pDocumentInfo->pMeta && (false == pDocumentInfo->pMeta->empty()))
  	  *(pDocumentHisto->pMeta) = *(pDocumentInfo->pMeta) ;
  }

  // mise � jour de la patpatho
  if (NULL != pNSPatPathoArray)
  {
  	pDocumentHisto->pPatPathoArray->vider() ;
    *(pDocumentHisto->pPatPathoArray) = *pNSPatPathoArray ;
  }
  pDocumentHisto->TrouveDateDoc() ;
  // on remet � jour le titre et la bitmap d'int�r�t
  SetLabelNode(*pNSTreeNodeSelection, pDocumentHisto) ;
  //Interet(*pNSTreeNodeSelection);

	//provisoirement pour CS
  if (string("ZCS00") == pDocumentInfo->getType())
	{
  	if (pNSPatPathoArray)
		{
    	NSPatPathoArray* pPatPatho = new NSPatPathoArray(pContexte) ;
      int DecalageLigneFils = 0 ;
      int ligne  	 = (*pNSTreeNodeSelection)->getLigne() ;
      int cardinal = 0 ; //nb fils et petits fils
      //supprimer l'ancienne patpatho si elle existe
      bool PatpthoNonVide = true ;

      SupprimerFils((*pNSTreeNodeSelection), &cardinal, &PatpthoNonVide) ;
      //mettre � jour les coordonn�es des autres NSTreeNodes
      iterNSTreeNode iter = pNodeArray->begin() ;
      if (cardinal)
      {
      	for (; iter != pNodeArray->end(); iter++)
        	if( (*iter)->getLigne() > ligne )
          	(*iter)->setLigne((*iter)->getLigne() - cardinal ) ;
      }

      pDocumentHisto->pPatPathoArray->donnePatpatho(pPatPatho, sImportance) ;
      if (!pPatPatho->empty())
      {
      	DispatcherPatPatho(pPatPatho, (*pNSTreeNodeSelection), &DecalageLigneFils, "") ;

        // Mettre � jour les coordonn�es des autres NSTreeNodes
        for (; iter != pNodeArray->end(); iter++)
        	if( ((*iter)->getLigne() > ligne) && ((!(*iter)->Descendant((*pNSTreeNodeSelection)))) )
          	(*iter)->setLigne((*iter)->getLigne() + DecalageLigneFils ) ;
        //
        // Affiche les bitmaps correspondant aux diff�rents int�rets
        // des fils de pNSTreeNodeSelection
        //
        AfficheInteret(*pNSTreeNodeSelection) ;
        (*pNSTreeNodeSelection)->ExpandItem(TVE_EXPAND) ;
      }
      delete pPatPatho ;
    }
  }
}

//--------------------------------------------------------------------------//affiche le bitmaps correspondant � l'int�rets de pNSTreeNodeSelection
//--------------------------------------------------------------------------
void
NSTreeHistorique::Interet(NSTreeNode* pNSTreeNode)
{
	if (NULL == pNSTreeNode)
		return ;

	//ne pas changer la bitmap du noeud sur le document lui m�me
  if (pNSTreeNode->getColonne() == 1)
  	return;

	string sInteret = pNSTreeNode->getInteret() ;
	if      (sInteret == string("A"))
	{
  	pNSTreeNode->SetImageIndex(0) ;
    pNSTreeNode->SetSelectedImageIndex(0, true) ;
	}
  else if (sInteret == string("B"))
  {
  	pNSTreeNode->SetImageIndex(1) ;
    pNSTreeNode->SetSelectedImageIndex(1, true) ;
  }
  else if (sInteret == string("C"))
  {
  	pNSTreeNode->SetImageIndex(2) ;
    pNSTreeNode->SetSelectedImageIndex(2, true) ;
  }
  else if (sInteret == string("D"))
  {
  	pNSTreeNode->SetImageIndex(3) ;
    pNSTreeNode->SetSelectedImageIndex(3, true) ;
	}
  else if (sInteret == string("E"))
  {
  	pNSTreeNode->SetImageIndex(4) ;
    pNSTreeNode->SetSelectedImageIndex(4, true) ;
	}
}

//--------------------------------------------------------------------------//affiche les bitmaps correspondant aux diff�rents int�rets des fils
//de pNSTreeNodeSelection
//--------------------------------------------------------------------------
void
NSTreeHistorique::AfficheInteret(NSTreeNode* pNSTreeNodePere)
{
	if (NULL == pNSTreeNodePere)
		return ;

	if (false == pNSTreeNodePere->VectFils.empty())
  {
		iterNSTreeNode fils = pNSTreeNodePere->VectFils.begin() ;
		for ( ; fils != pNSTreeNodePere->VectFils.end(); fils++)
			AfficheInteret(*fils) ;
	}

	Interet(pNSTreeNodePere) ;
}

//--------------------------------------------------------------------------// Fonction de NSTreeWindow surcharg�e
// pour �viter que les documents de l'historique (colonne == 1)
// affichent l'int�r�t max � la place de leur type
//--------------------------------------------------------------------------
void
NSTreeHistorique::AfficheInteretMaximum(NSTreeNode* pNSTreeNode)
{
	if (NULL == pNSTreeNode)
		return ;

	if (pNSTreeNode->getColonne() == 1)
  	return ;
	else
		NSTreeWindow::AfficheInteretMaximum(pNSTreeNode) ;
}

//--------------------------------------------------------------------------// Fonction de NSTreeWindow surcharg�e
// pour �viter que les documents de l'historique (colonne == 1)
// affichent l'int�r�t r�el � la place de leur type
//--------------------------------------------------------------------------
void
NSTreeHistorique::AfficheInteretReel(NSTreeNode* pNSTreeNode)
{
	if (NULL == pNSTreeNode)
		return ;

	if (pNSTreeNode->getColonne() > 1)
		NSTreeWindow::AfficheInteretReel(pNSTreeNode) ;
}

NSTreeNode*
NSTreeHistorique::getNodeForPoint(NS_CLASSLIB::TPoint point)
{
	pHitTestInfo->pt = point ;
	return GetNSTreeNode(HitTest(pHitTestInfo)) ;
}

NSTreeNode*
NSTreeHistorique::getSelectedNode()
{
	TTreeNode node = GetSelection() ;
  return GetNSTreeNode(&node) ;
}

NSDocumentHisto*
NSTreeHistorique::getDocumentForNode(NSTreeNode* pNSTreeNode)
{
	if ((NULL == pNSTreeNode) || (false == pNSTreeNode->estUnDocument()))
		return NULL ;

	NSDocumentHisto* pDocument = static_cast<NSDocumentHisto*>(pNSTreeNode->pDocument) ;

	return pDocument ;
}

NSDocumentHisto*
NSTreeHistorique::getSelectedDocument()
{
	NSTreeNode* pNSTreeNodeSelection = GetNSTreeNode(HitTest(pHitTestInfo)) ;

	return getDocumentForNode(pNSTreeNodeSelection) ;
}

//-------------------------------------------------------------------------// Remet � jour le titre du node en fonction des DocumentHisto associ�es
//-------------------------------------------------------------------------
void
NSTreeHistorique::SetLabelNode(NSTreeNode* pNSTreeNode, NSDocumentHisto* pDocHisto)
{
	char   dateAffiche[20] ;
  string sAffiche = pDocHisto->getDocName() ;

	strip(sAffiche, stripBoth) ;

	// if (strcmp(chAffiche, "Synth�se"))
  if (string("ZSYNT") != pDocHisto->getSemCont())
	{
		if (strcmp(pDocHisto->GetDateDoc(), "") != 0)
    {
    	string sLang = "" ;
			if (pContexte->getUtilisateur())
				sLang = pContexte->getUtilisateur()->donneLang() ;

    	// strcat(chAffiche, " du ") ;
      sAffiche += string(" - ") ;
      donne_date(pDocHisto->GetDateDoc(), dateAffiche, sLang) ;
      sAffiche += string(dateAffiche) ;
    }
	}

	pNSTreeNode->sLabel = sAffiche ;
	pNSTreeNode->SetText(sAffiche.c_str(), true) ;
}

//-------------------------------------------------------------------------// Affiche les patpathos des documents selon leurs importances :
// ON SE LIMITE POUR L'INSTANT AUX DOCUMENTS TYPE CONSULTATION OU CR
//-------------------------------------------------------------------------
void
NSTreeHistorique::AffichePatho()
{
	if (pNodeArray->empty())
  	return ;

	NSPatPathoArray* pPatPatho ;	iterNSTreeNode 	 iter, itersuite, itertransit ;

	int	 iDocEnCours = 1 ;
	bool bTourner = true ;

	iterNSTreeNode 	 iterNode = pNodeArray->begin() ;

	while (bTourner)
	{
  	int  iNDoc 	 = 0 ;
    bool bTraite = false ;
    for (iterNode = pNodeArray->begin();
        			(iterNode != pNodeArray->end()) && !bTraite; iterNode++)
    {
    	if (((*iterNode)->getColonne()) == 0)
      	iNDoc++ ;
      if (iNDoc == iDocEnCours)
      {
      	NSDocumentHisto* pDocumentHisto = static_cast<NSDocumentHisto*>((*iterNode)->pDocument) ;
        // CR ou CS
				// if( (sType[0] == 'C') || (!(strncmp(pDocumentInfo->pDonnees->type, "HD", 2))))
        // provisoirement pour CS
				if (pDocumentHisto && (string("ZCS00") == pDocumentHisto->getType()))
        {
        	int DecalageLigneFils = 0 ;
          pPatPatho = new NSPatPathoArray(pContexte) ;
          int ligne  	 = (*iterNode)->getLigne() ;
          int cardinal = 0 ; //nb fils et petits fils
          //
          // Supprimer l'ancienne patpatho si elle existe
          //
          bool PatpthoNonVide = true ;
          SupprimerFils((*iterNode), &cardinal, &PatpthoNonVide) ;
          //
          // Mettre � jour les coordonn�es des autres NSTreeNodes
          //
          iter = pNodeArray->begin() ;
          if (cardinal)
          {
          	for (; iter != pNodeArray->end(); iter++)
            	if ((*iter)->getLigne() > ligne)
              	(*iter)->setLigne((*iter)->getLigne() - cardinal) ;
          }

          pDocumentHisto->pPatPathoArray->donnePatpatho(pPatPatho, sImportance) ;
          if (!pPatPatho->empty())
          {
          	itertransit = iterNode ;
            DispatcherPatPatho(pPatPatho, (*iterNode), &DecalageLigneFils, "") ;
            iterNode = itertransit ;

            //
            // Mettre � jour les coordonn�es des autres NSTreeNodes
            //
            if (cardinal)
            	itersuite = iter ;
            else
            	itersuite = pNodeArray->begin() ;

            for (; itersuite != pNodeArray->end(); itersuite++)
            	if (((*itersuite)->getLigne() > ligne) &&
                        		((!(*itersuite)->Descendant((*iterNode)))))
              	(*itersuite)->setLigne((*itersuite)->getLigne() + DecalageLigneFils) ;
            //
            // Affiche les bitmaps correspondant aux diff�rents int�rets
            // des fils de pNSTreeNodeSelection
            //
            AfficheInteret(*iterNode) ;
            (*iterNode)->ExpandItem(TVE_EXPAND) ;

            // On r�tablit l'ic�ne du node p�re (CS)
            if (pDoc->EstUnDocumentOuvert(*iterNode))
            	AfficheIcone(IndexIcone_CSouvert, *iterNode) ;
            else
            	AfficheIcone(IndexIcone_CS, *iterNode) ;
          }
          delete pPatPatho ;
        }
        if (pDocumentHisto &&
            		((string("ZCN00") == pDocumentHisto->getType()) ||
                     (string("ZDHTM") == pDocumentHisto->getType()))
                	)
        {        	int DecalageLigneFils = 0 ;
          pPatPatho = new NSPatPathoArray(pContexte) ;
          int ligne  	 = (*iterNode)->getLigne() ;
          int cardinal = 0 ; //nb fils et petits fils
          //
          // Supprimer l'ancienne patpatho si elle existe
          //
          bool PatpthoNonVide = true ;
          SupprimerFils((*iterNode), &cardinal, &PatpthoNonVide) ;
        	//
          // Mettre � jour les coordonn�es des autres NSTreeNodes
          //
          iter = pNodeArray->begin();
          if (cardinal)
          {
            for (; iter != pNodeArray->end(); iter++)
              if ((*iter)->getLigne() > ligne)
                (*iter)->setLigne((*iter)->getLigne() - cardinal) ;
          }

          pDocumentHisto->pPatPathoArray->donnePatpatho(pPatPatho, sImportance);

          //
          // Cas particulier pour les comptes rendus : on donne � la
          // conclusion une valeur Importance document + 2
          //
          string sDocInteret = pDocumentHisto->getInteret() ;
          char importDoc  = sDocInteret[0] ;
          char importConc = char(importDoc + 2) ;

          if (pPatPatho->empty())
          {
            PatPathoIter iterPpt = (pDocumentHisto->pPatPathoArray)->begin() ;
            for ( ; (iterPpt != (pDocumentHisto->pPatPathoArray)->end()) &&
                ((*iterPpt)->getLexique() != "0CONC1");
                                        iterPpt++) ;
            // Il y a une conclusion
            if ((iterPpt != (pDocumentHisto->pPatPathoArray)->end()) &&
                    (importConc >= sImportance[0]))
            {
              NSPatPathoArray SousPatho(pContexte) ;
              (pDocumentHisto->pPatPathoArray)->ExtrairePatPatho(iterPpt, &SousPatho) ;
              // et elle n'est pas vide
              if (false == SousPatho.empty())
              {
                NSPatPathoInfo racine = *(*iterPpt) ;
                racine.setLigne(0) ;
                racine.setColonne(0) ;
                pPatPatho->push_back(new NSPatPathoInfo(racine)) ;
                PatPathoIter ssiter ;
                for (ssiter = SousPatho.begin(); ssiter != SousPatho.end(); ssiter++)
                {
                  (*ssiter)->setLigne((*ssiter)->getLigne() + 1) ;
                  (*ssiter)->setColonne((*ssiter)->getColonne() + 1) ;
                  pPatPatho->push_back(new NSPatPathoInfo(*(*ssiter))) ;
                }
              }
            }
          }

          if (false == pPatPatho->empty())
          {
            itertransit = iterNode ;
            DispatcherPatPatho(pPatPatho, (*iterNode), &DecalageLigneFils, "") ;
            iterNode = itertransit ;

            //
            // Mettre � jour les coordonn�es des autres NSTreeNodes
            //
            if (cardinal)
              itersuite = iter ;
            else
              itersuite = pNodeArray->begin() ;

            for (; itersuite != pNodeArray->end(); itersuite++)
              if (((*itersuite)->getLigne() > ligne) &&
                      ((!(*itersuite)->Descendant((*iterNode)))))
                (*itersuite)->setLigne((*itersuite)->getLigne() + DecalageLigneFils ) ;
            //
            // Affiche les bitmaps correspondant aux diff�rents int�rets
            // des fils de pNSTreeNodeSelection
            //
            AfficheInteret(*iterNode) ;
            (*iterNode)->ExpandItem(TVE_EXPAND) ;

            // On r�tablit l'ic�ne du node p�re (CS)
            if (pDoc->EstUnDocumentOuvert(*iterNode))
              AfficheIcone(IndexIcone_CRouvert, *iterNode) ;
            else
              AfficheIcone(IndexIcone_CR, *iterNode) ;
          }
          delete pPatPatho ;
        }
        iDocEnCours++ ;
        bTraite = true ;
      }
    }
    if (iterNode == pNodeArray->end())
    	bTourner = false ;
  }
}

//-------------------------------------------------------------------------// Enlever les patpathos affich�es des documents
//-------------------------------------------------------------------------
void
NSTreeHistorique::EnlevePatho()
{
	if (pNodeArray->empty())
		return ;

	iterNSTreeNode iterNode = pNodeArray->begin() ;
	for (; iterNode != pNodeArray->end(); iterNode++)
	{
    int ligne  	 = (*iterNode)->getLigne() ;
    int cardinal = 0 ; //nb fils et petits fils
    //
    // Supprimer l'ancienne patpatho si elle existe
    //
    bool PatpthoNonVide = true ;
    SupprimerFils((*iterNode), &cardinal, &PatpthoNonVide) ;
    //
    // Mettre � jour les coordonn�es des autres NSTreeNodes
    //
    iterNSTreeNode iter = pNodeArray->begin() ;
    if (cardinal > 0)
    	for (; iter != pNodeArray->end(); iter++)
      	if ((*iter)->getLigne() > ligne)
        	(*iter)->setLigne((*iter)->getLigne() - cardinal) ;
	}
}

voidNSTreeHistorique::AfficheIcone(int iCategorie, NSTreeNode* pNSDocNode)
{
	if (NULL == pNSDocNode)
		return ;

	NSDocumentHisto* pDocument = getDocumentForNode(pNSDocNode) ;
  if (NULL == pDocument)
		return ;

	string sDocInteret = pDocument->getInteret() ;
	char interet = sDocInteret[0] ;
	int  nbIcone = iCategorie ;
	switch (interet)
	{
  	case 'A' :
    	nbIcone = iCategorie ;
      break ;
    case 'B' :
    	nbIcone = iCategorie + IndexDecalage ;
      break ;
    case 'C' :
    	nbIcone = iCategorie + 2*IndexDecalage ;
      break ;
    case 'D' :
    	nbIcone = iCategorie + 3*IndexDecalage ;
      break ;
		case 'E' :
    	nbIcone = iCategorie + 4*IndexDecalage ;
      break ;
	}

	pNSDocNode->SetImageIndex(nbIcone) ;
	pNSDocNode->SetSelectedImageIndex(nbIcone, true) ;
}

//-------------------------------------------------------------------------// Demander l'autorisation de l'ouverture de ce document, s'il est d�j� ouvert,
// il suffit de l'activer
//-------------------------------------------------------------------------
void
NSTreeHistorique::AutoriserOuverture(NSDocumentInfo* pNSDocumentInfo)
{
	if (NULL == pNSDocumentInfo)
		return ;

	string codeDocBrut = pNSDocumentInfo->getID() ;
	iterNSTreeNode iterNode = TrouveNoeud(codeDocBrut) ;

  // cas des documents visibles dans l'historique
  //
	if ((NULL != iterNode) && (pNodeArray->end() != iterNode))
	{
		OuvertureDocument(*iterNode) ;
    return ;
	}

  // on regarde d'abord le cas des documents visibles
  // qui ne figurent pas dans l'historique
  if (true == pNSDocumentInfo->estVisible())
  {
    string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "theDocumentDoesNotBelongToHistory") ;
    sErrorText += string(" (") + pNSDocumentInfo->getDocName() + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
    erreur(sErrorText.c_str(), warningError, 0) ;
    return ;
  }

  // cas des documents invisibles
  if (!pDoc->EstUnDocumentOuvert(pNSDocumentInfo))
  {
    if (!(pContexte->userHasPrivilege(NSContexte::openDocument, -1, -1, pNSDocumentInfo->getAuthor(), string(""), NULL, NULL)))
    {
      string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
      erreur(sErrorText.c_str(), warningError, 0) ;
      return ;
    }
    // on fait une copie sinon les HD sont transform�s en documents bruts
    NSDocumentInfo* pDocum = new NSDocumentInfo(*pNSDocumentInfo) ;
    NSNoyauDocument* pDocNoy ; // pointeur sur le document cr�� par OuvreDocument

    bool bReadOnlyOpening = true ;
    if (pContexte->userHasPrivilege(NSContexte::modifyDocument, -1, -1, pNSDocumentInfo->getAuthor(), string(""), NULL, NULL))
      bReadOnlyOpening = false ;

    pDocNoy = pContexte->getSuperviseur()->OuvreDocument(*pNSDocumentInfo, pContexte, bReadOnlyOpening) ;

    if (pDocNoy)      pDoc->RangeDocumentOuvert(pDocum, pDocNoy) ;
    delete pDocum ;  }
}

//----------------------------------------------------------------------------// Demander l'autorisation de l'�dition de ce document (cas des fichiers Word)
// En principe, dans cette fonction, on peut changer le fichier word mais
// pas les param�tres du document (nom de fichier, nom de document, etc.)
// on ne v�rifie pas l'appartenance � l'historique car on peut tr�s bien
// �diter un document invisible dans l'historique.
//----------------------------------------------------------------------------
void
NSTreeHistorique::AutoriserEdition(NSDocumentInfo* pNSDocumentInfo)
{
try
{
	if (NULL == pNSDocumentInfo)
		return ;

	NSNoyauDocument* pDocNoy ;
	bool bDocInHisto ;
  bool bReadOnlyOpening = true ;

	if (pNSDocumentInfo->getSemCont() != "ZSYNT")
  {
  	if (!(pContexte->userHasPrivilege(NSContexte::openDocument, -1, -1, pNSDocumentInfo->getAuthor(), string(""), NULL, NULL)))
		{
			string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
			erreur(sErrorText.c_str(), warningError, 0) ;
			return ;
		}
    if (pContexte->userHasPrivilege(NSContexte::modifyDocument, -1, -1, pNSDocumentInfo->getAuthor(), string(""), NULL, NULL))
    	bReadOnlyOpening = false ;
  }
	else
	{
  	if (!(pContexte->userHasPrivilege(NSContexte::viewSynthesis, -1, -1, string(""), string(""), NULL, NULL)))
		{
			string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
			erreur(sErrorText.c_str(), warningError, 0) ;
			return ;
		}
    if (pContexte->userHasPrivilege(NSContexte::modifySynthesis, -1, -1, string(""), string(""), NULL, NULL))
    	bReadOnlyOpening = false ;
	}

	// on r�cup�re le iterNode pour l'affichage des ic�nes	iterNSTreeNode iterNode = pNodeArray->begin() ;
	string codeDocBrut = pNSDocumentInfo->getID() ;
	iterNode = TrouveNoeud(codeDocBrut) ;

	if (iterNode == pNodeArray->end())
		bDocInHisto = false ;
	else
		bDocInHisto = true ;

	// on charge � cet endroit la pNSDocumentInfo si elle n'est pas complete	// (cas par exple de la synth�se � l'initialisation). Pour �viter de la charger	// deux fois (si elle provient de l'historique, comme dans EditionDocument),	// on consid�re qu'elle est charg�e si sCodeDocMeta != ""	if ((pNSDocumentInfo->sCodeDocMeta == "") && (!pDoc->ChargeDocInfo(pNSDocumentInfo)))	{    string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "theDocumentCannotBeEdited") ;    sErrorText += string(" (") + pNSDocumentInfo->getPatient() + string(" ") + pNSDocumentInfo->getDocument() + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
	}	NSDocViewManager dvManager(pContexte) ;

	if (string("ZCN00") == pNSDocumentInfo->getType())
	{
		NSCRDocument* pCRDoc ;

		// donne le focus � la vue d'�dition si elle existe
		TView* pView = pDoc->ActiveFenetre(pNSDocumentInfo, "NSCRReadOnlyView") ;
		if (pView == 0)
		{
			// si le document est ouvert, on le r�cup�re pour l'�diter
			pDocNoy = pDoc->EstUnDocumentOuvert(pNSDocumentInfo) ;
			if (pDocNoy)
				pCRDoc = dynamic_cast<NSCRDocument*>(pDocNoy) ;
			else // on cr�e ici un nouveau pointeur, qu'on doit d�clarer ouvert
			{
				if (bDocInHisto)
					AfficheIcone(IndexIcone_CRouvert, *iterNode) ;
				pCRDoc = new NSCRDocument(0, pNSDocumentInfo, 0, pContexte, "", bReadOnlyOpening) ;
			}

      dvManager.createView(pCRDoc, "CN Format") ;

			// on d�clare �ventuellement ouvert le nouveau compte-rendu
			if (NULL == pDocNoy)
				pDoc->RangeDocumentOuvert(pNSDocumentInfo, pCRDoc) ;
		}
	}
	else if (string("ZCS00") == pNSDocumentInfo->getType())
	{
		NSCSDocument* pCSDoc ;

		// donne le focus � la vue d'�dition si elle existe
		TView* pView = pDoc->ActiveFenetre(pNSDocumentInfo, "NSCsVue") ;
		if (pView == 0)
		{
			// si le document est ouvert, on le r�cup�re pour l'�diter
			pDocNoy = pDoc->EstUnDocumentOuvert(pNSDocumentInfo) ;
			if (pDocNoy)
				pCSDoc = dynamic_cast<NSCSDocument*>(pDocNoy) ;
			else // on cr�e ici un nouveau pointeur, qu'on doit d�clarer ouvert
			{
				if (bDocInHisto)
					AfficheIcone(IndexIcone_CSouvert, *iterNode) ;
				pCSDoc = new NSCSDocument(0, pNSDocumentInfo, 0, pContexte, "", bReadOnlyOpening) ;
			}

      dvManager.createView(pCSDoc, "CS Format") ;

			// on d�clare �ventuellement ouvert la nouvelle consultation
			if (!pDocNoy)
				pDoc->RangeDocumentOuvert(pNSDocumentInfo, pCSDoc) ;
		}
	}
	else if (string("ZCQ00") == pNSDocumentInfo->getType())	{
		// cas des formulaires
		NSCQDocument* pCQDoc ;
		// donne le focus � la vue d'�dition si elle existe		TView* pView = pDoc->ActiveFenetre(pNSDocumentInfo, "NSCQVue") ;
		if (pView == 0)
		{
			// si le document est ouvert, on le r�cup�re pour l'�diter
			pDocNoy = pDoc->EstUnDocumentOuvert(pNSDocumentInfo) ;
			if (pDocNoy)
			{				pCQDoc = dynamic_cast<NSCQDocument*>(pDocNoy) ;
        if (!pCQDoc)
        	return ;
				pCQDoc->bCreate = false ;			}			else // on cr�e ici un nouveau pointeur, qu'on doit d�clarer ouvert			{
				if (bDocInHisto)
					AfficheIcone(IndexIcone_CQouvert, *iterNode) ;

        //
        // Declaring default Archetypes
        //
        string sDefaultArchetype = string("") ;
        if (string("ZADMI") == pNSDocumentInfo->getSemCont())
        	sDefaultArchetype = pContexte->getSuperviseur()->getDemographicArchetypeId() ;

				pCQDoc = new NSCQDocument(0, pNSDocumentInfo, 0, pContexte, bReadOnlyOpening, sDefaultArchetype) ;				if (!pCQDoc->bParsingOk)				{        	delete pCQDoc ;					return ;				}
			}

      dvManager.createView(pCQDoc, "CQ Format") ;

			// on d�clare �ventuellement ouvert le nouveau formulaire			if (!pDocNoy)
				pDoc->RangeDocumentOuvert(pNSDocumentInfo, pCQDoc) ;
		}
	}
	else if (string("ZTRTF") == pNSDocumentInfo->getType())
	{
		NSTtxDocument* pDocTtx = 0 ;

		// donne le focus � la vue d'�dition si elle existe
		TView* pView = pDoc->ActiveFenetre(pNSDocumentInfo, "NSTtxView") ;
		if (pView == 0)
		{
			// si le document est ouvert, on le r�cup�re pour l'�diter
			pDocNoy = pDoc->EstUnDocumentOuvert(pNSDocumentInfo) ;
			if (pDocNoy)
				pDocTtx = dynamic_cast<NSTtxDocument*>(pDocNoy) ;
			if (!pDocTtx) // on cr�e ici un nouveau pointeur, qu'on doit d�clarer ouvert
			{
				if (bDocInHisto)
					AfficheIcone(IndexIcone_tlib, *iterNode) ;
				pDocTtx = new NSTtxDocument(0, bReadOnlyOpening, pNSDocumentInfo, 0, pContexte) ;
			}

      dvManager.createView(pDocTtx, "Rtf Format") ;

			// on d�clare �ventuellement ouvert le nouveau document texte
			if (!pDocNoy)
				pDoc->RangeDocumentOuvert(pNSDocumentInfo, pDocTtx) ;
		}
	}
	else if (string("ZTTXT") == pNSDocumentInfo->getType())	{
		NSSimpleTxtDocument* pDocTxt = 0 ;

		// donne le focus � la vue d'�dition si elle existe
		TView* pView = pDoc->ActiveFenetre(pNSDocumentInfo, "NSSimpleTxtView") ;
		if (pView == 0)
		{
			// si le document est ouvert, on le r�cup�re pour l'�diter
			pDocNoy = pDoc->EstUnDocumentOuvert(pNSDocumentInfo) ;
			if (pDocNoy)
				pDocTxt = dynamic_cast<NSSimpleTxtDocument*>(pDocNoy) ;
			if (!pDocTxt) // on cr�e ici un nouveau pointeur, qu'on doit d�clarer ouvert
			{
				if (bDocInHisto)
					AfficheIcone(IndexIcone_tlib, *iterNode) ;
				pDocTxt = new NSSimpleTxtDocument(0, bReadOnlyOpening, pNSDocumentInfo, 0, pContexte) ;
      }

      dvManager.createView(pDocTxt, "Txt Format") ;

			// on d�clare �ventuellement ouvert le nouveau document texte
			if (!pDocNoy)
				pDoc->RangeDocumentOuvert(pNSDocumentInfo, pDocTxt) ;
		}
	}
	else if (string("ZTHTM") == pNSDocumentInfo->getType())
	{
		NSTtxDocument* pDocTtx = 0 ;

		// donne le focus � la vue d'�dition si elle existe
		TView* pView = pDoc->ActiveFenetre(pNSDocumentInfo, "NSAutoWordView") ;
		if (pView == 0)
		{
			// si le document est ouvert, on le r�cup�re pour l'�diter
			pDocNoy = pDoc->EstUnDocumentOuvert(pNSDocumentInfo) ;
			if (pDocNoy)
				pDocTtx = dynamic_cast<NSTtxDocument*>(pDocNoy) ;
			if (!pDocTtx) // on cr�e ici un nouveau pointeur, qu'on doit d�clarer ouvert
			{
				if (bDocInHisto)
					AfficheIcone(IndexIcone_tlib, *iterNode) ;
				pDocTtx = new NSTtxDocument(0, bReadOnlyOpening, pNSDocumentInfo, 0, pContexte) ;
			}

      		dvManager.createView(pDocTtx, "Word Format") ;

			// on d�clare �ventuellement ouvert le nouveau document texte
			if (!pDocNoy)
				pDoc->RangeDocumentOuvert(pNSDocumentInfo, pDocTtx) ;
		}
	}
	else
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "noEditFunctionExistsForTheDocument") ;
    sErrorText += string(" (") + pNSDocumentInfo->getDocName() + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
    erreur(sErrorText.c_str(), warningError, 0) ;
	}
}
catch (...)
{
	erreur("Exception NSTreeHistorique::AutoriserEdition", standardError, 0) ;
}
}

//----------------------------------------------------------------------// un noeud a �t� s�lectionn� : ouverture d'un document
//----------------------------------------------------------------------
void
NSTreeHistorique::EvLButtonDblClk(uint /* a */, NS_CLASSLIB::TPoint& point)
{
	NSTreeNode* pNSTreeNodeSelection = getNodeForPoint(point) ;
	if (NULL == pNSTreeNodeSelection)
		return ;

	::SetCursor(::LoadCursor(0, IDC_WAIT)) ;

	OuvertureDocument(pNSTreeNodeSelection);
	::SetCursor(::LoadCursor(0, IDC_ARROW)) ;}

//---------------------------------------------------------------------//ouverture ou activation d'un document
//---------------------------------------------------------------------
void
NSTreeHistorique::OuvertureDocument(NSTreeNode* pNSDocNode)
{
	if (NULL == pNSDocNode)
		return ;
	NSDocumentHisto* pDocument = getDocumentForNode(pNSDocNode) ;
	if (NULL == pDocument)
		return ;

  // Already open ; put it up
  //
	if (pDoc->EstUnDocumentOuvert(pDocument))
  {
  	pDoc->ActiveFenetre(pDocument) ;
    return ;
  }

/*
	if (string("ZDHTM") == pDocument->getType())
	{
		NSDocumentInfo* pDocHtml = 0 ;
		NSDocumentInfo* pNSDocumentHisto = new NSDocumentInfo(*pDocument) ;
		// on retrouve le document brut
		if (!pContexte->ChercheComposition(&pNSDocumentHisto,&pDocHtml))
		{
    	string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "theReferenceDocumentCannotBeFound") ;
      sErrorText += string(" (") + pNSDocumentHisto->getPatient() + string(" ") + pNSDocumentHisto->getDocument() + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
      erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;

			delete pNSDocumentHisto ;
			return ;
		}
		if      (string("ZCN00") == pNSDocumentHisto->getType())
			AfficheIcone(IndexIcone_CRouvert, pNSDocNode) ;
		else if (string("ZCS00") == pNSDocumentHisto->getType())
			AfficheIcone(IndexIcone_CSouvert, pNSDocNode);

		delete pNSDocumentHisto ;
		delete pDocHtml ;
	}
	else
	{
*/
		// cas de la synth�se : on lance l'�dition et on sort (� revoir)
		if ((string("ZCS00") == pDocument->getType()) &&
                (string("00000") == pDocument->getDocument()))
		{
			// AutoriserEdition va d�clarer ouverte la synth�se
			AutoriserEdition(pDocument) ;
			return ;
		}

		if (!(pContexte->userHasPrivilege(NSContexte::openDocument, -1, -1, pDocument->getAuthor(), string(""), NULL, NULL)))
		{
			string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
			erreur(sErrorText.c_str(), warningError, 0) ;
			return ;
		}

		// Affichage des icones "document ouvert"
		if      (string("ZCN00") == pDocument->getType())
    	AfficheIcone(IndexIcone_CRouvert, pNSDocNode) ;
    else if (string("ZCS00") == pDocument->getType())
    	AfficheIcone(IndexIcone_CSouvert, pNSDocNode) ;
    else if (string("ZCQ00") == pDocument->getType())    	AfficheIcone(IndexIcone_CQouvert, pNSDocNode) ;
    else if (string("ZTPDF") == pDocument->getType())
    	AfficheIcone(IndexIcone_ARouvert, pNSDocNode) ;
    else if (pContexte->typeDocument(pDocument->getType(), NSSuper::isImage))
    	AfficheIcone(IndexIcone_ImageFer, pNSDocNode) ;
    else if (pContexte->typeDocument(pDocument->getType(), NSSuper::isText))
    	AfficheIcone(IndexIcone_tlib, pNSDocNode) ;
		else
			//bitmap vide
			AfficheIcone(IndexIcone_vide, pNSDocNode) ;
//	}
	//
	// Ouverture effective du document : appel de pSuper
	//
	NSDocumentInfo* pDocum = new NSDocumentInfo(pContexte) ;
	*(pDocum->getData()) = *(pDocument->getData()) ;
  *(pDocum->pMeta) = *(pDocument->pMeta) ;
  *(pDocum->pPres) = *(pDocument->pPres) ;
  pDocum->sCodeDocMeta = pDocument->sCodeDocMeta ;
  pDocum->sCodeDocPres = pDocument->sCodeDocPres ;

	bool bReadOnlyOpening = true ;
	if (pContexte->userHasPrivilege(NSContexte::modifyDocument, -1, -1, pDocument->getAuthor(), string(""), NULL, NULL))
		bReadOnlyOpening = false ;

	NSNoyauDocument* pDocNoy ;   // pointeur sur le document cr�� par OuvreDocument
	pDocNoy = pContexte->getSuperviseur()->OuvreDocument(*pDocum, pContexte, bReadOnlyOpening) ;
	if (pDocNoy)
	{
		// on reprend les donnees pour �viter l'effet de bord de OuvreDocument
  	// (switch entre document HD et document brut CN)
		*(pDocum->getData()) = *(pDocument->getData());

		// on range le pHtmlInfo dans le cas d'un HD
		// (permet de savoir que le document est compos�)
		pDoc->RangeDocumentOuvert(pDocum, pDocNoy);
	}
	delete pDocum ;
}

//---------------------------------------------------------------------// Edition d'un document
//---------------------------------------------------------------------
void
NSTreeHistorique::EditionDocument(NSTreeNode* pNSDocNode)
{
	if (NULL == pNSDocNode)
		return ;

	pContexte->GetMainWindow()->SetCursor(0, IDC_WAIT) ;

	NSDocumentHisto* pDocument = static_cast<NSDocumentHisto*>(pNSDocNode->pDocument);
	if (NULL == pDocument)
		return ;

	// Cas particulier des documents compos�s
	//
/*
	if (string("HD") == string(pDocument->getType(), 0, 2))
	{
		NSDocumentInfo* pDocHtml = 0;
		NSDocumentInfo* pDocBrut = new NSDocumentInfo(*pDocument);
		// on retrouve le document brut
		if (!pContexte->ChercheComposition(&pDocBrut, &pDocHtml))
		{
    	string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "theReferenceDocumentCannotBeFound") ;
    	sErrorText += string(" (") + pDocBrut->getPatient() + string(" ") + pDocBrut->getDocument() + string(")") ;
    	pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
    	erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;

			delete pDocBrut;
			return ;
		}
		pDocument = static_cast<NSDocumentHisto*>(pDocBrut);
	}
*/

	AutoriserEdition(pDocument) ;

	pContexte->GetMainWindow()->SetCursor(0, IDC_ARROW) ;
}

//----------------------------------------------------------------------// R�ponse � une touche du clavier
//----------------------------------------------------------------------
void
NSTreeHistorique::EvTvKeyDown(TTwKeyDownNotify& nhmr)
{
	//ouverture du document
	if (VK_RETURN == nhmr.wVKey)
	{
    NSTreeNode* pNode = getSelectedNode() ;
		if (NULL == pNode)
			return ;

    VisualiserDocument(pNode) ;
	}
	else
		DefaultProcessing() ;
}

//--------------------------------------------------------------------// Trouver un noeud � partir d'un document
//--------------------------------------------------------------------
iterNSTreeNode
NSTreeHistorique::TrouveNoeud(string sCodeDocBrut)
{
	if (pNodeArray->empty())
  	return NULL ;

	iterNSTreeNode iterNode = pNodeArray->begin() ;
	for (; iterNode != pNodeArray->end(); iterNode++)
	{
  	NSDocumentHisto* pDocument = static_cast<NSDocumentHisto*>((*iterNode)->pDocument) ;
    if ((pDocument) && (sCodeDocBrut == pDocument->getID()))
    	return iterNode ;
	}

	return pNodeArray->end() ;
}

//-------------------------------------------------------------------------//click droit sur un document
//-------------------------------------------------------------------------
void
NSTreeHistorique::EvRButtonDown(uint , NS_CLASSLIB::TPoint& point)
{
	NSTreeNode* pNSTreeNodeSelection = getNodeForPoint(point) ;
  if (NULL == pNSTreeNodeSelection)
		return ;

	NSDocumentInfo* pDocument = getDocumentForNode(pNSTreeNodeSelection) ;
	if (NULL == pDocument)
		return ;

	TPopupMenu *menu = new TPopupMenu() ;

	pNSTreeNodeSelection->SelectItem(TVGN_CARET) ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;
	string sOpen = pSuper->getText("documentManagement", "open") ;
  sOpen[0] = pseumaj(sOpen[0]) ;
  string sOpeA = pSuper->getText("documentManagement", "openEveryDocument") ;
  sOpeA[0] = pseumaj(sOpeA[0]) ;
	string sEdit = pSuper->getText("documentManagement", "edit") ;
  sEdit[0] = pseumaj(sEdit[0]) ;
	string sPara = pSuper->getText("documentManagement", "parameters") ;
  sPara[0] = pseumaj(sPara[0]) ;
	string sProp = pSuper->getText("documentManagement", "properties") ;
  sProp[0] = pseumaj(sProp[0]) ;
	string sRemo = pSuper->getText("documentManagement", "removeFromHistory") ;
  sRemo[0] = pseumaj(sRemo[0]) ;
	string sDele = pSuper->getText("documentManagement", "destroy") ;
  sDele[0] = pseumaj(sDele[0]) ;
  string sExpo = pSuper->getText("documentManagement", "exportAsXmlFile") ;
  sExpo[0] = pseumaj(sExpo[0]) ;
	//
	// This is not the synthesis
	//
	if (pDocument->getSemCont() != "ZSYNT")
	{
  	menu->AppendMenu(MF_STRING, IDC_OUVRIR, sOpen.c_str()) ;
    //
		// Does the author have privileges to modify this document
    //
		if ((pContexte->typeDocument(pDocument->getType(), NSSuper::isTree)) ||
				(pContexte->typeDocument(pDocument->getType(), NSSuper::isText)) ||
            (string("ZDHTM") == pDocument->getType()))
		{
			if (pContexte->userHasPrivilege(NSContexte::modifyDocument, -1, -1, pDocument->getAuthor(), string(""), NULL, NULL))
				menu->AppendMenu(MF_STRING, CM_EDITER, sEdit.c_str()) ;
			else
				menu->AppendMenu(MF_GRAYED, 0, sEdit.c_str()) ;
    }
		menu->AppendMenu(MF_STRING, IDC_PARAMETRES, sPara.c_str()) ; 
		menu->AppendMenu(MF_STRING, IDC_PROPRIETE,  sProp.c_str()) ;
    menu->AppendMenu(MF_STRING, IDC_XML_EXPORT, sExpo.c_str()) ;
		menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
		menu->AppendMenu(MF_STRING, IDC_OTER,       sRemo.c_str()) ;
		menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
		// Does the author have privileges to suppres this document
		//
		if (pContexte->userHasPrivilege(NSContexte::suppresDocument, -1, -1, pDocument->getAuthor(), string(""), NULL, NULL))
			menu->AppendMenu(MF_STRING, IDC_DETRUIRE,	sDele.c_str()) ;
    else
    	menu->AppendMenu(MF_GRAYED, 0,           	sDele.c_str()) ;
		menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
		menu->AppendMenu(MF_STRING, IDC_TOUTOUVRIR, sOpeA.c_str()) ;
	}
  //
	// This is the synthesis
	//
	else
	{
  	menu->AppendMenu(MF_STRING, IDC_OUVRIR, sOpen.c_str()) ;
    //
		// Does the author have privileges to modify this document
    //
		if (pContexte->userHasPrivilege(NSContexte::modifySynthesis, -1, -1, string(""), string(""), NULL, NULL))
			menu->AppendMenu(MF_STRING, CM_EDITER, sEdit.c_str()) ;
		else
			menu->AppendMenu(MF_GRAYED, 0, sEdit.c_str()) ;
		menu->AppendMenu(MF_STRING, IDC_PARAMETRES, sPara.c_str()) ;
		menu->AppendMenu(MF_STRING, IDC_PROPRIETE,  sProp.c_str()) ;
    menu->AppendMenu(MF_STRING, IDC_XML_EXPORT, sExpo.c_str()) ;
		menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
		menu->AppendMenu(MF_STRING, IDC_OTER,       sRemo.c_str()) ;
		menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
		menu->AppendMenu(MF_STRING, IDC_TOUTOUVRIR, sOpeA.c_str()) ;
	}

  NS_CLASSLIB::TPoint lp = point ;
	ClientToScreen(lp) ;
	menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow) ;
	delete menu ;

	return ;
}

voidNSTreeHistorique::EvHScroll(uint scrollCode, uint thumbPos, HWND hWndCtl)
{
	TWindow::EvHScroll(scrollCode, thumbPos, hWndCtl) ;
}

voidNSTreeHistorique::EvVScroll(uint scrollCode, uint thumbPos, HWND hWndCtl)
{
	TWindow::EvVScroll(scrollCode, thumbPos, hWndCtl) ;
}

void
NSTreeHistorique::EvSetFocus(HWND hWndLostFocus)
{
	TWindow::EvSetFocus(hWndLostFocus) ;
}

void
NSTreeHistorique::EvClose()
{
}

void
NSTreeHistorique::SelChanged()
{
	TWindow::Invalidate() ;
}

int
NSTreeHistorique::donneIndexInteret(char cInteret)
{
	if      (cInteret == 'A')
		return 9 ;
	else if (cInteret == 'B')
		return 10 ;
	else if (cInteret == 'C')
  	return 11 ;
	else if (cInteret == 'D')
  	return 12 ;
	else if (cInteret == 'E')
  	return 13 ;

	return 0 ;
}
voidNSTreeHistorique::Ouvrir()
{
	NSTreeNode* pNSTreeNodeEdit = getSelectedNode() ;
	if (NULL == pNSTreeNodeEdit)
		return ;

	OuvertureDocument(pNSTreeNodeEdit) ;}

voidNSTreeHistorique::Editer()
{
	NSTreeNode* pNSTreeNodeEdit = getSelectedNode() ;
	if (NULL == pNSTreeNodeEdit)
		return ;

	EditionDocument(pNSTreeNodeEdit) ;
}

voidNSTreeHistorique::ToutOuvrir()
{
	if (pNodeArray->empty())
		return ;

	iterNSTreeNode iter = pNodeArray->end() ;
	while (iter != pNodeArray->begin())
	{
  	iter-- ;
    if ((*iter)->getColonne() == 0)
    	OuvertureDocument(*iter) ;
	}
}

voidNSTreeHistorique::Oter()
{
	NSDocumentHisto* pDocument = getSelectedDocument() ;
  if (NULL == pDocument)
  	return ;

	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *(pDocument->getData()) ;

	//
  // On rend le document invisible
  //
  NSDocumentInfo DocInfoMeta(pContexte) ;
  // remise � jour du pDocInfoMeta pour charger le document Meta
  // on pr�cise ici uniquement codePatient et codeDocument sans pr�ciser le type
  // on doit ensuite charger la patpatho � la main (cf NSDocumentInfo::ChargeDocMeta())
  DocInfoMeta.setPatient(pDocument->getPatient()) ;
  string sNewCodeDoc = string(pDocument->sCodeDocMeta, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;
  DocInfoMeta.setDocument(sNewCodeDoc) ;

  NSNoyauDocument NoyDoc(0, &DocInfoMeta, 0, pContexte, false) ;
  bool resultat = NoyDoc.chargePatPatho() ;
  if (false == resultat)
    return ;

  if (NoyDoc.DocumentInvisible(pDocument->sCodeDocMeta))
  	// on reporte la modif en m�moire
    pDocument->rendInvisible() ;

	//
	// On supprime le document de l'historique
	//
  EnleverDocument(&Docum) ;

	//
	// Chercher pDocum dans VectDocument
	//
	DocumentIter iterDoc = pDoc->VectDocument.TrouveDocHisto(Docum.getID()) ;

	// on l'enl�ve de VectDocument
	if ((iterDoc != NULL) && (iterDoc != pDoc->VectDocument.end()))
  {
  	delete *iterDoc ;
    pDoc->VectDocument.erase(iterDoc) ;
	}
}

// m�thode appel�e depuis ChoixChemiseDialog (nsrechdl) par pDocHis// Ajoute un document invisible (on le rend visible) � l'historique (inverse de Oter)
void
NSTreeHistorique::Ajouter(NSDocumentInfo* pDocumentInfo)
{
  //
  // On rend le document visible
  //
  NSDocumentInfo DocInfoMeta(pContexte) ;
  // remise � jour du pDocInfoMeta pour charger le document Meta
  // on pr�cise ici uniquement codePatient et codeDocument sans pr�ciser le type
  // on doit ensuite charger la patpatho � la main (cf NSDocumentInfo::ChargeDocMeta())
  DocInfoMeta.setPatient(pDocumentInfo->getPatient()) ;
  string sNewCodeDoc = string(pDocumentInfo->sCodeDocMeta, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;
  DocInfoMeta.setDocument(sNewCodeDoc) ;

  NSNoyauDocument NoyDoc(0, &DocInfoMeta, 0, pContexte, false) ;
  bool resultat = NoyDoc.chargePatPatho() ;
  if (false == resultat)
    return ;

  if (NoyDoc.DocumentVisible(pDocumentInfo->sCodeDocMeta))
  	// on reporte la modif en m�moire
    pDocumentInfo->rendVisible() ;

	//
	// On ajoute le document � l'historique
	// mais il ne s'agit pas d'un nouveau document
	// (on n'ajoute pas le document � l'array des documents ouvert)
	//
	AjouteDocument(pDocumentInfo, 0) ;
}

void
NSTreeHistorique::Proprietes()
{
	NSTreeNode* pNSDocNode = getSelectedNode() ;
	if (NULL == pNSDocNode)
  	return ;

	string sTitre = pNSDocNode->sLabel ;

	NSDocumentHisto* pDocument = getDocumentForNode(pNSDocNode) ;
  if (NULL == pDocument)
  	return ;

	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *(pDocument->getData()) ;

	NSPropDocDialog* pPropDlg = new NSPropDocDialog(pContexte->GetMainWindow(),
                                                    sTitre, &Docum, pContexte) ;
	pPropDlg->Execute() ;
	delete pPropDlg ;
}

voidNSTreeHistorique::Parametres()
{
	NSDocumentHisto* pDocument = getSelectedDocument() ;
  if (NULL == pDocument)
		return ;

	NSDocumentInfo* pDocInfo = new NSDocumentInfo(pContexte) ;
	NSDocumentInfo* pHtmlInfo = 0 ;
	*(pDocInfo->getData()) = *(pDocument->getData()) ;
	*(pDocInfo->pMeta) = *(pDocument->pMeta) ;
	pDocInfo->sCodeDocMeta = pDocument->sCodeDocMeta ;

/*
	// cas des html dynamiques : on instancie le pHtmlInfo du document
  if (string("HD") == string(pDocument->getType(), 0, 2))
  {
  	// on retrouve le document brut
    if (!pContexte->ChercheComposition(&pDocInfo, &pHtmlInfo))
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "theReferenceDocumentCannotBeFound") ;
    	sErrorText += string(" (") + pDocInfo->getPatient() + string(" ") + pDocInfo->getDocument() + string(")") ;
    	pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
    	erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;

      delete pDocInfo ;
      return ;
    }
	}
*/

	// on cr�e un docref virtuel pour pouvoir lancer le dialogue des param�tres
	// ce document est donc une copie d'un document qui est dans l'historique
	// on ne lance pas validefichier comme dans NSSuper car on n'ouvre pas le document
	NSRefDocument* pDocRef = new NSRefDocument(0, pDocInfo, pHtmlInfo, pContexte, false) ;
	if (pDocRef->ParamDoc())
	{
  	// on doit prendre le pDocInfo du pDocRef pour tenir compte des modifs
    if (pDocRef->pHtmlInfo)
    	pDoc->Rafraichir(pDocRef->pHtmlInfo, 0) ;
    else
    	pDoc->Rafraichir(pDocRef->pDocInfo, 0) ;
	}

	// IMPORTANT : on doit remettre pDocInfo et pHtmlInfo � 0
	// pour �viter que ~NSRefDocument ne remette � jour l'historique
	pDocRef->pDocInfo = 0 ;
	pDocRef->pHtmlInfo = 0 ;
	delete pDocRef ;
}

voidNSTreeHistorique::Detruire()
{
	NSTreeNode* pNSDocNode = getSelectedNode() ;
	if (NULL == pNSDocNode)
  	return ;

	string sTitre = pNSDocNode->sLabel ;

	NSDocumentHisto* pDocument = getDocumentForNode(pNSDocNode) ;
  if (NULL == pDocument)
  	return ;

	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *(pDocument->getData()) ;
	*(Docum.pMeta) = *(pDocument->pMeta) ;
	Docum.sCodeDocMeta = pDocument->sCodeDocMeta ;

	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;	string sMessage = pContexte->getSuperviseur()->getText("documentHistoryManagement", "doYouReallyWantToSuppressTheDocument") + string(" ") + sTitre ;

	int retVal = ::MessageBox(pContexte->GetMainWindow()->GetHandle(), sMessage.c_str(), sCaption.c_str(), MB_YESNO);
	if (retVal != IDYES)
  	return ;

	// Destruction du document
	// Cette m�thode rend le document invisible et remplit
	// le champ pDonnees->tranDel pour le signaler d�truit
	pContexte->getPatient()->DetruireDocument(&Docum) ;
	// on appelle rafraichir pour enlever le document de l'historique
	pDoc->Rafraichir(&Docum, 0) ;
}

void
NSTreeHistorique::XmlExport()
{
  NSDocumentHisto* pDocument = getSelectedDocument() ;
  if (NULL == pDocument)
		return ;

  string sXmlContent = string("<Document>\r\n") ;

  if (NULL != pDocument->pMeta)
  {
    sXmlContent += string("  <LabelTree>\r\n") ;
    sXmlContent += pDocument->pMeta->genereXML() ;
    sXmlContent += string("  </LabelTree>\r\n") ;
  }

  if (NULL != pDocument->pPatPathoArray)
  {
    sXmlContent += string("  <DataTree>\r\n") ;
    sXmlContent += pDocument->pPatPathoArray->genereXML() ;
    sXmlContent += string("  </DataTree>\r\n") ;
  }

  sXmlContent += string("</Document>\r\n") ;

  string sExportPath = pContexte->PathName("EHTM") ;
  string sDocId      = pDocument->getID() ;
  string sFileName   = sExportPath + nomSansDoublons(sExportPath, sDocId, string("xml")) ;

  ofstream outFile ;
  outFile.open(sFileName.c_str()) ;
	if (!outFile)
	{
    string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningOutputFile") + string(" ") + sFileName ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
    return ;
	}

  outFile << sXmlContent ;

  outFile.close() ;

  string sMessage = pContexte->getSuperviseur()->getText("exportManagement", "ExportSucceededInFile") + string(" ") + sFileName ;
  string sCaption = pContexte->getSuperviseur()->getAppName().c_str();
  ::MessageBox(pContexte->GetMainWindow()->GetHandle(), sMessage.c_str(), sCaption.c_str(), MB_OK);
}

/**************************************************************************/
//						bo�te de dialogue pour le changement de titre
/*************************************************************************/

/**********************************************************************/
//  permettre l'�dition de champ num�rique pour un NSTreeNode
/**********************************************************************/
DEFINE_RESPONSE_TABLE1(NSTitre, TDialog)
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

NSTitre::NSTitre(TWindow* parent, TResId ressource, NSContexte* pCtx, string Titre )
        :TDialog(parent, ressource), NSRoot(pCtx)
{
	sTitre = Titre ;
	//
	// Cr�ation de tous les "objets de contr�le"
	//
	pTitre = new TEdit(this, IDC_TITRE) ;
}

NSTitre::~NSTitre()
{
	delete pTitre ;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSTitre::CmOk()
{
  char far* titre = new char[100] ;
  pTitre->GetText(titre, 100) ;
  sTitre = string(titre) ;
  delete[] titre ;

  if (titre == "")
  {
  	erreur("votre titre n'est pas valide", standardError, 0, GetHandle()) ;
    pTitre->SetFocus() ;
    return ;
	}
	CloseWindow(IDOK) ;
}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
void
NSTitre::CmCancel()
{
	Destroy(IDCANCEL) ;
}

voidNSTitre::SetupWindow()
{
	TDialog::SetupWindow() ;
	pTitre->SetText(sTitre.c_str()) ;
}

