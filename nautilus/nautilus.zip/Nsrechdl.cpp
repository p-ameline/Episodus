#include <owl\applicat.h>#include <owl\olemdifr.h>
#include <owl\dialog.h>
#include <owl\static.h>
#include <owl\edit.h>
#include <owl\color.h>
#include <stdio.h>
#include <string.h>
#include <owl\module.h>
#include <bde.hpp>

#include "nautilus\nsrechdl.h"
#include "nautilus\nssuper.h"
#include "nautilus\nsresour.h"
#include "nautilus\nspatdlg.h"
#include "nautilus\nsdocref.h"
#include "nautilus\nsdocaga.h"
#include "partage\nsdivfct.h"
#include "nautilus\nshistdo.h"
#include "nsoutil\mexcel.h"
#include "nsoutil\nsfilgui.h"
#include "nsepisod\nsldvuti.h"
#include "nssavoir\nsgraphe.h"
#include "nautilus\nshisto.rh"
#include "nautilus\nautilus.rh"
#include "nsbb\nsbb.rh"

#include "nsutil\md5.h"

#include "pilot\Pilot.hpp"
#include "pilot\NautilusPilot.hpp"
#include "pilot\JavaSystem.hpp"#include "nsbb\tagNames.h"using namespace miniexcel ;
//----------------------- class NSUserWithRoleArray ---------------------
//utiliser pour garder le login + role d'utilisateur
NSUserWithRoleArray::NSUserWithRoleArray(NSUserWithRoleArray& rv):NSUserWithRoleVector(){    if (!(rv.empty()))        for (NSUserWithRoleIter i = rv.begin(); i != rv.end(); i++)            push_back(new NSUserWithRole(*(*i)));}voidNSUserWithRoleArray::vider(){    if (empty())        return;    for (NSUserWithRoleIter i = begin(); i != end(); )    {        delete *i;
        erase(i);
    }
}
NSUserWithRoleArray::~NSUserWithRoleArray(){	vider();}
NSUserWithRoleArray&NSUserWithRoleArray::operator=(NSUserWithRoleArray src){	vider();    if (!(src.empty()))        for (NSUserWithRoleIter i = src.begin(); i != src.end(); i++)            push_back(new NSUserWithRole(*(*i)));
	return *this;}//----------------------- class UserLoginNTiersDialog --------------------------
DEFINE_RESPONSE_TABLE1(UserLoginNTiersDialog, NSUtilDialog)
	EV_COMMAND(IDOK,	CmOk),
	EV_CHILD_NOTIFY_AND_CODE(NSE_LOGIN_UTILISATEUR, LBN_DBLCLK, CmLoginDblClk),
END_RESPONSE_TABLE ;

// -----------------------------------------------------------------------------
UserLoginNTiersDialog::UserLoginNTiersDialog(TWindow *pere, NSContexte *pCtx,
                                             NSUtilisateurChoisi* pUtil)
                      :NSUtilDialog(pere, pCtx, "USER_LOGIN")
{
try
{
  pUtilChoisi = pUtil;
  pLogs  = new OWL::TListBox(this, NSE_LOGIN_UTILISATEUR) ;
  pPass  = new NSUtilEdit(pContexte, this, NSE_CODE_UTILISATEUR,  UTI_CODE_LEN) ;
  pUsers = new NSUserWithRoleArray() ;

  pPassL = new OWL::TStatic(this, NSE_CODE_LIB) ;
  pId    = new OWL::TStatic(this, NSE_CODE_ID) ;
}
catch (...)
{
	erreur("Exception UserLoginDialog ctor.", standardError, 0) ;
}
}

UserLoginNTiersDialog::~UserLoginNTiersDialog()
{
  delete pLogs ;
  delete pPass ;
  delete pUsers ;
  delete pPassL ;
  delete pId ;
}

void
UserLoginNTiersDialog::SetupWindow()
{
	string ps = string("Entering SetupWindow for user login") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

	TDialog::SetupWindow() ;

  string titleText = pContexte->getSuperviseur()->getText("loginDialog", "userIdentification") ;
  string loginText = pContexte->getSuperviseur()->getText("loginDialog", "userLogin") ;
  string passwText = pContexte->getSuperviseur()->getText("loginDialog", "userPassword") ;

  pPassL->SetText(passwText.c_str()) ;
  pId->SetText(loginText.c_str()) ;
  SetCaption(titleText.c_str()) ;

/*
	VecteurString result ;

	pContexte->pPilot->invokeService(NautilusPilot::SERV_USER_LIST.c_str(), LOGIN, result);
	int iNbUtils = 0 ;
  if (!(result.empty()))
  {
		EquiItemIter iter = result.begin() ;
		while( iter != result.end() )  //loop on the nodes
		{
			const char* aLogin = (*iter)->c_str() ;

      NSBasicAttributeArray AttrArray ;
			AttrArray.push_back(new NSBasicAttribute(LOGIN, *(*iter))) ;
			NSPersonsAttributesArray AttrUserList ;
			bool res = pContexte->pPilot->invokeService2ReturnElements(NautilusPilot::SERV_LOGIN.c_str(),
            pUtilChoisi->pGraphPerson->pDataGraph, &AttrUserList, &AttrArray) ;
           // "login", szLogin, "password", sPassEncrypt.c_str(), NULL);

			if ((res) && (!AttrUserList.empty()))
			{
				NSBasicAttributeArray ResultArray(*(*(AttrUserList.begin()))) ;
				// on remet login et password car ils ne sont pas retourn�s
				string sPasswordType = ResultArray.getAttributeValue(PASSWDTYPE) ;

        if (sPasswordType.find("D") == string::npos)
      	{
					pLogs->AddString(aLogin) ;
					iNbUtils++ ;
        }
      }
			iter++ ;
    }
	}
*/

	NSPersonsAttributesArray ListArray ;

  ps = string("Calling Pilot for users list") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

	pContexte->pPilot->personsList(NautilusPilot::SERV_USER_LIST_WITH_ROLES.c_str(), "user", &ListArray, NULL) ;
	int iNbUtils = 0 ;
  if (!(ListArray.empty()))
  {
		for (NSPersonsAttributeIter iterUser = ListArray.begin(); iterUser != ListArray.end(); iterUser++)
		{
    	string sPassType = (*iterUser)->getAttributeValue(PASSWDTYPE) ;

      if ((string("") == sPassType) || (string::npos == sPassType.find("D")))
      {
      	string sLogin = (*iterUser)->getAttributeValue(LOGIN) ;
        const char* aLogin = sLogin.c_str() ;

      	pLogs->AddString(aLogin) ;
        iNbUtils++ ;
    	}
		}
	}

  pLogs->SetSelIndex(0) ;

  // iNbUtils == 1 : administrator only : put focus on pswd
  // iNbUtils == 2 : administrator + user : select user and put focus on pswd
	//
  if (iNbUtils == 1)
		PostMessage(WM_NEXTDLGCTL, (WPARAM)pPass->HWindow, TRUE) ;
  else if (iNbUtils == 2)
	{
		int iLen = pLogs->GetStringLen(0) ;
    char* pcString = new char[iLen + 1] ;
		int iResult = pLogs->GetString(pcString, 0) ;

    if ((iResult > 0) && (string(pcString) == string("Administrateur")))
			pLogs->SetSelIndex(1) ;

    delete[] pcString ;

    // pPass->SetFocus() ;
    PostMessage(WM_NEXTDLGCTL, (WPARAM)pPass->HWindow, TRUE) ;
  }

  ps = string("Leaving SetupWindow for user login") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;
}

// -----------------------------------------------------------------------------
void
UserLoginNTiersDialog::CmOk()
{
try
{
	string ps = string("Entering Ok response function for user login") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

	char far szLogin[UTI_LOGIN_LEN + 1] ;
  memset(szLogin, 0, CHE_CODE_LEN + 1) ;
	pLogs->GetSelString(szLogin, UTI_LOGIN_LEN + 1) ;

	if (szLogin[0] == '\0')
	{
		string sErrorText = pContexte->getSuperviseur()->getText("userManagement", "loginNeeded") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), warningError, 0, 0) ;
		return ;
	}

	char far szPass[UTI_CODE_LEN + 1] ;
  memset(szPass, 0, UTI_CODE_LEN + 1) ;
	pPass->GetText(szPass, UTI_CODE_LEN + 1) ;
	if (szPass[0] == '\0')
	{
		string sErrorText = pContexte->getSuperviseur()->getText("userManagement", "passwordNeeded") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), warningError, 0, 0) ;
		return ;
	}

	// chiffrage du mot de passe � l'aide de l'algo MD5
	string  sPass         = string(szPass) ;
	string  sPassEncrypt  = "" ;
	sPassEncrypt = MD5_encrypt(sPass) ;

  ps = string("Checking user login + password validity") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

	//char far szPassEncrypt[UTI_CODE_LEN + 1] ;
	//sprintf(szPassEncrypt, "%s", sPassEncrypt.c_str()) ;
	NSBasicAttributeArray AttrArray ;
	AttrArray.push_back(new NSBasicAttribute(LOGIN , string(szLogin))) ;
	AttrArray.push_back(new NSBasicAttribute(PASSWORD , sPassEncrypt)) ;
	NSPersonsAttributesArray AttrUserList ;

  bool res = pContexte->pPilot->personList(NautilusPilot::SERV_LOGIN.c_str(),
                                                  &AttrUserList, &AttrArray) ;

	// bool res = pContexte->pPilot->invokeService2ReturnElements(NautilusPilot::SERV_LOGIN.c_str(),
  //          pUtilChoisi->pGraphPerson->pDataGraph, &AttrUserList, &AttrArray) ;
           // "login", szLogin, "password", sPassEncrypt.c_str(), NULL);

	if ((!res) || (AttrUserList.empty()))
	{
		string sErrorText = pContexte->pPilot->getErrorMessage() + pContexte->pPilot->getWarningMessage() ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return ;
	}

	NSBasicAttributeArray ResultArray(*(*(AttrUserList.begin()))) ;
	// on remet login et password car ils ne sont pas retourn�s
	ResultArray.setAttributeValue(LOGIN, string(szLogin)) ;
	ResultArray.setAttributeValue(PASSWORD, sPassEncrypt) ;

	// pResultArray->setAttributeValue(USERTYPE, "UA");

	// Note : � laisser ici pour pouvoir inspecter
	string sLogin                = ResultArray.getAttributeValue(LOGIN);
	string sPasswd               = ResultArray.getAttributeValue(PASSWORD);
	string sUserType             = ResultArray.getAttributeValue(USERTYPE);
	string sPasswordType         = ResultArray.getAttributeValue(PASSWDTYPE);
	string sDatePasswordCreation = ResultArray.getAttributeValue(STARTDATE);
	string sValidityDuration     = ResultArray.getAttributeValue(DAYSNB);

	pUtilChoisi->SetUtilisateurChoisi(&ResultArray) ;

	string sCaption = pContexte->getSuperviseur()->getAppName().c_str() +
                    string(" : ") +
                    pUtilChoisi->donneSignature(pContexte) ;

	pContexte->GetMainWindow()->SetCaption(sCaption.c_str()) ;
	TDialog::CmOk() ;

  ps = string("Leaving Ok response function for user login") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;
}catch (...){
	erreur("Exception UserLoginNTiersDialog::CmOk", standardError, 0) ;
}
}
void
UserLoginNTiersDialog::CmLoginDblClk(WPARAM Cmd)
{
	pPass->SetFocus() ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSPropDocDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSPropDocDialog, NSUtilDialog)
    EV_COMMAND(IDOK, CmOk),
END_RESPONSE_TABLE;

NSPropDocDialog::NSPropDocDialog(TWindow* parent, string titre, NSDocumentInfo* pDocumInfo, NSContexte* pCtx)
                :NSUtilDialog(parent, pCtx, "IDD_PROPRIETES")
{
	sTitre = titre ;
	pInfos = pDocumInfo ;
	pProp = new NSUtilEdit(pContexte, this, IDC_PROP_EDIT) ;  // textLimit = 0
}

NSPropDocDialog::~NSPropDocDialog(){
	delete pProp ;
}

void
NSPropDocDialog::SetupWindow()
{
	string sText ;
	string sCreateur ;
	char   dateAffiche[20] ;

	NSUtilDialog::SetupWindow() ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	if (NULL == pInfos)
		return ;

	sText = "Titre : " + sTitre + "\r\n" ;
	sText += "Type document : " + pInfos->getType() + "\r\n" ;
	sText += string("Code document : ") + pInfos->getID() + string("\r\n") ;

	donne_date((char*) pInfos->getCreDate().c_str(), dateAffiche, sLang) ;
	sText += string("Date de cr�ation : ") + string(dateAffiche) + "\r\n" ;
	sText += "Auteur : " + sCreateur + "\r\n" ;

	if (string("") != pInfos->getLocalis())		sText += "Localisation : " + pInfos->getLocalis() + "\r\n" ;

	if (string("") != pInfos->getFichier())
  	sText += "Fichier : " + pInfos->getFichier() + "\r\n" ;

  if (string("") != pInfos->getTemplate())
  	sText += "Fichier template : " + pInfos->getTemplate() + "\r\n" ;

  if (string("") != pInfos->getEntete())  	sText += "Fichier en-t�te : " + pInfos->getEntete() + "\r\n" ;

  sText += "Int�r�t : " + pInfos->getInteret() + "\r\n" ;
  if (pInfos->estVisible())  	sText += "Visible : Oui" ;
  else
  	sText += "Visible : Non" ;

	pProp->FormatLines(true) ;
	pProp->SetText(sText.c_str()) ;
}

voidNSPropDocDialog::CmOk()
{
	NSUtilDialog::CmOk() ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSDocuBox
//
// -----------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSDocuBox, OWL::TListBox)
	EV_WM_RBUTTONDOWN,
  EV_COMMAND(IDC_OUVRIR, Ouvrir),
  EV_COMMAND(CM_EDITER, Editer),
  EV_COMMAND(IDC_AJOUTER, Ajouter),
  EV_COMMAND(IDC_PARAMETRES, Parametres),
  EV_COMMAND(IDC_PROPRIETE, Proprietes),
  EV_COMMAND(IDC_DETRUIRE, Detruire),
END_RESPONSE_TABLE;

NSDocuBox::NSDocuBox(NSContexte* pCtx, ChoixChemiseDialog* pere)          :OWL::TListBox(pere, IDC_DOCUBOX), NSRoot(pCtx){
	pDlg = pere ;
}

NSDocuBox::~NSDocuBox(){
}

void
NSDocuBox::EvRButtonDown(uint /*modkeys*/, NS_CLASSLIB::TPoint& point)
{
	int hindex, count ;
	bool trouve = false ;
	NS_CLASSLIB::TRect itemRect ;

	// on doit selectionner l'item qui encadre le point click�
  hindex = GetTopIndex() ;
  count = GetCount() ;

	while ((!trouve) && (hindex < count))
	{
  	GetItemRect(hindex, itemRect) ;

    if ((point.y >= itemRect.Top()) && (point.y < itemRect.Bottom()))
    {
    	trouve = true ;
      break ;
    }

    hindex++ ;
	}

	if (trouve)
  	SetSelIndex(hindex) ;
	else
  {
  	// on enleve la selection
    SetSelIndex(-1) ;
    return ;
	}

	TPopupMenu *menu = new TPopupMenu() ;
	NSDocumentInfo* pDocument = (*(pDlg->pDocusArray))[GetSelIndex()] ;

  menu->AppendMenu(MF_STRING, IDC_OUVRIR,    "Ouvrir") ;
  // if (!strcmp(pDocument->pDonnees->type, "TWHTM"))
  menu->AppendMenu(MF_STRING, CM_EDITER, "Editer") ;
  menu->AppendMenu(MF_STRING, IDC_PARAMETRES,"Param�tres") ;
  menu->AppendMenu(MF_STRING, IDC_PROPRIETE, "Propri�t�s") ;
  menu->AppendMenu(MF_SEPARATOR, 0, 0) ;

  if (false == pDocument->estVisible())
      menu->AppendMenu(MF_STRING, IDC_AJOUTER, "Ajouter � l'historique") ;
  else
      menu->AppendMenu(MF_GRAYED, 0,           "Ajouter � l'historique") ;
  menu->AppendMenu(MF_SEPARATOR, 0, 0);

  menu->AppendMenu(MF_STRING, IDC_DETRUIRE,  "D�truire") ;

  ClientToScreen(point) ;
  menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point, 0, HWindow) ;
  delete menu ;
}

voidNSDocuBox::Ouvrir()
{
	// on est sur qu'il s'agit d'un index valide
	pDlg->DocumentChoisi = GetSelIndex() + 1 ;
	pDlg->CmOk() ;
}

voidNSDocuBox::Editer()
{
	// on est sur qu'il s'agit d'un index valide
	pDlg->DocumentChoisi = GetSelIndex() + 1 ;
	pDlg->bEditer = true ;
	pDlg->CmOk() ;
}
voidNSDocuBox::Ajouter()
{
	// on est sur qu'il s'agit d'un index valide
	int docChoisi = GetSelIndex() + 1 ;
	pDlg->AjouteDocument(docChoisi) ;
	// on rafraichit la listbox
	pDlg->CmSelectChemise(0) ;
}

voidNSDocuBox::Detruire()
{
	// on est sur qu'il s'agit d'un index valide
	NSDocumentInfo* pDocument = (*(pDlg->pDocusArray))[GetSelIndex()] ;
	char far        titre[1024] ;

	GetString(titre, GetSelIndex()) ;
	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
	string sMessage = pContexte->getSuperviseur()->getText("documentHistoryManagement", "doYouReallyWantToSuppressTheDocument") + string(" ") + string(titre) ; 

	int retVal = ::MessageBox(pContexte->GetMainWindow()->GetHandle(), sMessage.c_str(), sCaption.c_str(), MB_YESNO) ;

	if (retVal != IDYES)		return ;  // Destruction du document
  //
  pContexte->getPatient()->DetruireDocument(pDocument);
  pContexte->getPatient()->pDocHis->Rafraichir(pDocument, 0);

  //  // Mise � jour de l'array  //
  SetSelIndex(-1);
  pDlg->CmSelectChemise(0);
}

voidNSDocuBox::Parametres()
{
	NSDocumentInfo* pDocInfo = (*(pDlg->pDocusArray))[GetSelIndex()] ;
	NSDocumentInfo* pHtmlInfo = 0 ;

	// cas des html dynamiques : on instancie le pHtmlInfo du document
/*
  if (string("HD") == string(pDocInfo->getType(), 0, 2))
  {
  	// on retrouve le document brut
    if (!pContexte->ChercheComposition(&pDocInfo, &pHtmlInfo))
    {      string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "theReferenceDocumentCannotBeFound") ;
      sErrorText += string(" (") + pDocInfo->getPatient() + string(" ") + pDocInfo->getDocument() + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
      erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
      return ;
    }
	}
*/

  // on cr�e un docref virtuel pour pouvoir lancer le dialogue des param�tres  // on ne lance pas validefichier comme dans NSSuper car on n'ouvre pas le document
  NSRefDocument* pDocRef = new NSRefDocument(0, pDocInfo, pHtmlInfo, pContexte, true) ;

	if (pDocRef->ParamDoc())	{
		// on doit prendre le pDocInfo du pDocRef pour tenir compte des modifs
    if (pDocRef->pHtmlInfo)
    	pContexte->getPatient()->pDocHis->Rafraichir(pDocRef->pHtmlInfo, 0) ;
    else
    	pContexte->getPatient()->pDocHis->Rafraichir(pDocRef->pDocInfo, 0) ;
    //
    // Mise � jour de l'array
    //
    SetSelIndex(-1) ;
    pDlg->CmSelectChemise(0) ;
	}

  // IMPORTANT : on doit remettre pDocInfo et pHtmlInfo � 0
  // pour �viter que ~NSRefDocument ne remette � jour l'historique
  pDocRef->pDocInfo = 0 ;
  pDocRef->pHtmlInfo = 0 ;
  delete pDocRef ;
}

voidNSDocuBox::Proprietes()
{
	char far titre[255] ;
	NSDocumentInfo* pDocument = (*(pDlg->pDocusArray))[GetSelIndex()] ;

	GetString(titre, GetSelIndex());

	NSPropDocDialog* pPropDlg = new NSPropDocDialog(pContexte->GetMainWindow(),
                                                    string(titre), pDocument, pContexte) ;
	pPropDlg->Execute() ;
	delete pPropDlg ;
}


// -----------------------------------------------------------------//
//  M�thodes de ChoixChemiseDialog
//
// -----------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(ChoixChemiseDialog, NSUtilDialog)
	EV_CHILD_NOTIFY_AND_CODE(IDC_CHEMISEBOX, LBN_SELCHANGE, CmSelectChemise),
	EV_CHILD_NOTIFY_AND_CODE(IDC_DOCUBOX, 	  LBN_SELCHANGE, CmSelectDocument),
	EV_CHILD_NOTIFY_AND_CODE(IDC_CHEMISEBOX, LBN_DBLCLK, CmChemiseDblClk),
	EV_CHILD_NOTIFY_AND_CODE(IDC_DOCUBOX, 	  LBN_DBLCLK, CmDocumentDblClk),
	EV_COMMAND(IDCANCEL,	CmCancel),
END_RESPONSE_TABLE;

ChoixChemiseDialog::ChoixChemiseDialog(TWindow* pere, NSContexte* pCtx)                   :NSUtilDialog(pere, pCtx, "IDD_CHEMISE")
{
	pChemiseBox    = new TListBox(this, IDC_CHEMISEBOX);
	pDocuBox       = new NSDocuBox(pCtx, this) ;
	pChemisesArray = new NSChemiseArray;
	pDocusArray    = new NSDocHistoArray;

	// Edition : remplace ouvrir pour les fichiers word
	bEditer = false ;

	// fichiers d'aide	sHindex = "" ;
	sHcorps = "Dossier_patient.html" ;
}

//---------------------------------------------------------------------------//  Function: ChoixChemiseDialog::~ChoixChemiseDialog()
//
//  Arguments:	  Aucun
//
//  Description: Destructeur, ouvre la chemise ou le document s�lectionn�
//
//  Returns:     Rien
//---------------------------------------------------------------------------
ChoixChemiseDialog::~ChoixChemiseDialog()
{
	//
	// Si un document a �t� choisi
	//
	if (DocumentChoisi)
		OuvreDocument(DocumentChoisi);
	// else if (ChemiseChoisie)
	//  	for (int i = 0; i < pDocusArray->size(); i++)
	//  		OuvreDocument(i + 1);

	delete pChemiseBox;
	delete pDocuBox;
	delete pChemisesArray;
	delete pDocusArray;
}

//---------------------------------------------------------------------------
//  Function: ChoixChemiseDialog::OuvreDocument(int NumDoc)
//
//  Arguments:	  Num�ro du document � ouvrir
//
//  Description: Attache le document au mod�le Document/Visualisation
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
ChoixChemiseDialog::OuvreDocument(int NumDoc)
{
	NSDocumentInfo* pDocument = (*pDocusArray)[NumDoc-1];
    if (bEditer)
    {
        // cas des fichiers word...
        pContexte->getPatient()->pDocHis->AutoriserEdition(pDocument);
    }
    else
    {
        //demander l'autorisation de l'ouverture de ce document, s'il est d�j� ouvert,
        //il suffit de l'activer
        pContexte->getPatient()->pDocHis->AutoriserOuverture(pDocument);
    }
}

//---------------------------------------------------------------------------//  Function: ChoixChemiseDialog::AjouteDocument(int NumDoc)
//
//  Arguments:	  Num�ro du document � ajouter
//
//  Description: Ajoute le document � l'historique en le rendant visible
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
ChoixChemiseDialog::AjouteDocument(int NumDoc)
{
	NSDocumentInfo* pDocument = (*pDocusArray)[NumDoc-1] ;

	// On regarde d'abord si le document n'appartient pas d�j� � l'historique
	if (pDocument->estVisible())
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("documentHistoryManagementErrors", "thisDocumentIsAlreadyPartOfTheHistoryView") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), warningError, 0, GetHandle()) ;
    return ;
	}

	// demander l'autorisation de l'ouverture de ce document, s'il est d�j� ouvert,
	// il suffit de l'activer
	pContexte->getPatient()->pDocHis->AjouteDocument(pDocument) ;
}

//---------------------------------------------------------------------------//  Function: ChoixChemiseDialog::SetupWindow()
//  Etat initial : le patient a au moins une chemise
//  Arguments:	Aucun
//
//  Description:
//            Initialise la boite de liste des chemises
//  Returns:
//            Rien
//---------------------------------------------------------------------------
void ChoixChemiseDialog::SetupWindow()
{
	char chAffiche[200], dateAffiche[20];

	NSUtilDialog::SetupWindow();
  PatPathoIter iter;  int iColBase;
  string sElemLex, sSens, sType;
  string sNodeChem = "";
  string sNom = "", sDate = "";

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  NSDocumentHisto* pLibChem = pContexte->getPatient()->pDocHis->pLibChem ;

  // on doit parcourir la librairie pour charger l'array des chemises
  iter = pLibChem->pPatPathoArray->begin();
  iColBase = (*iter)->pDonnees->getColonne();
  iter++;

  while ((iter != pLibChem->pPatPathoArray->end()) && ((*iter)->pDonnees->getColonne() > iColBase))
  {
      sElemLex = string((*iter)->pDonnees->lexique);
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

      if (sSens == string("0CHEM"))
      {
          sNodeChem = (*iter)->pDonnees->getNode();
          sNom = "";
          sDate = "";
          iter++;

          // on charge les donn�es de la chemise
          while ((iter != pLibChem->pPatPathoArray->end()) && ((*iter)->pDonnees->getColonne() > iColBase+1))
          {
              sElemLex = string((*iter)->pDonnees->lexique);
              pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

              // nom de la chemise
              if (sSens == string("0INTI"))
              {
                  iter++;

                  while ((iter != pLibChem->pPatPathoArray->end()) && ((*iter)->pDonnees->getColonne() > iColBase+2))
                  {
                      // on cherche ici un texte libre
                      sElemLex = string((*iter)->pDonnees->lexique);

                      if (sElemLex == string("�?????"))
                      {
                          sNom = (*iter)->pDonnees->getTexteLibre();
                      }

                      iter++;
                  }
              }
              // Dates
              else if (sSens == "KOUVR")
              {
                  iter++;
                  int iLigneBase = (*iter)->pDonnees->getLigne();
                  // gereDate* pDate = new gereDate(pContexte);
                  string sUnite  = "";
                  string sFormat = "";
                  string sValeur = "";
                  string sTemp   = "";

                  while ((iter != pLibChem->pPatPathoArray->end()) &&
                         ((*iter)->pDonnees->getLigne() == iLigneBase))
                  {
                      if (((*iter)->pDonnees->lexique)[0] == '�')
                      {
                          sTemp   = (*iter)->getLexique() ;
                          pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
                          sValeur = (*iter)->getComplement() ;
                          sTemp   = (*iter)->getUnit() ;
                          pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
                          iter++;
                          break ;
                      }

                      iter++;
                  }

                  // sFormat est du type �D0;03
                  if ((sFormat != "") && (sFormat[1] == 'T') &&
                      (sValeur != ""))
                  {
                      if (sUnite == "2DA02")
                      {
                          sDate = string(sValeur, 0, 8);
                      }
                  }
              }
              else
                  iter++;
          }

          if (sNom != "")
          {
              NSChemiseInfo* pChemInfo = new NSChemiseInfo();
              pChemInfo->sNodeChemise = sNodeChem;
              strcpy(pChemInfo->pDonnees->nom, sNom.c_str());
              strcpy(pChemInfo->pDonnees->creation, sDate.c_str());

          // Pr�paration de l'intitul� de la chemise
          pChemInfo->donneIntitule(chAffiche, sLang);

              pChemiseBox->AddString(chAffiche);              pChemisesArray->push_back(new NSChemiseInfo(*pChemInfo)) ;

              delete pChemInfo;
          }
      }
      else
          iter++;
  }}


//---------------------------------------------------------------------------//  Function :		ChoixChemiseDialog::CmSelectChemise(WPARAM Cmd)
//
//  Arguments :	Cmd : WPARAM retourn� par Windows
//
//  Description :	Initialise la boite de liste des documents pour la chemise
//						s�lectionn�e
//
//  Retour	: 		Rien
//---------------------------------------------------------------------------

void ChoixChemiseDialog::CmSelectChemise(WPARAM Cmd){
	//
	// Effacement de la boite de liste des documents
	//
	pDocuBox->ClearList();

	//	// R�cup�ration de l'indice de la chemise s�lectionn�e
	//
	ChemiseChoisie = pChemiseBox->GetSelIndex() + 1 ;
	DocumentChoisi = 0 ;

	//	// R�cup�ration de la NSChemiseInfo correspondante
	//
	NSChemiseInfo* ChemiseEnCours = (*pChemisesArray)[ChemiseChoisie - 1] ;

	// vidange de pDocusArray
  //
  if (false == pDocusArray->empty())
	{
		DocumentIter iter ;
		for (iter = pDocusArray->begin() ; pDocusArray->end() != iter ; )
		{
  		delete *iter ;
    	pDocusArray->erase(iter) ;
		}
  }

	if (NULL == ChemiseEnCours)
		return ;

	//	// Remplissage de DocuBox avec les documents du patient
	//

	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
  VecteurString VectString ;
	string sNodeChemise = ChemiseEnCours->sNodeChemise ;

	// chargement de tous les documents de la chemise
	VectString.vider() ;
	pGraphe->TousLesVrais(sNodeChemise, NSRootLink::docFolder, &VectString) ;

	if (VectString.empty())
		return ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  for (EquiItemIter i = VectString.begin(); i != VectString.end(); i++)
  {
    NSDocumentHisto* pNSDocumentHisto = new NSDocumentHisto(new NSDocumentInfo(*(*i), pContexte)) ;
    pDocusArray->push_back(pNSDocumentHisto) ;
  }

  // R�cup�ration des informations des documents
  DocumentIter iterDoc = pDocusArray->begin() ;
  bool bOk ;

  while (iterDoc != pDocusArray->end())  {
    (*iterDoc)->pPatPathoArray->vider() ;
    VectString.vider() ;
    bOk = false ;

    // On remonte le lien data du m�ta-document
    pGraphe->TousLesVrais((*iterDoc)->sCodeDocMeta, NSRootLink::docData, &VectString) ;
    if (!VectString.empty())
    {
      string sCodeDocData = *(*(VectString.begin())) ;
      string sCodePat = string(sCodeDocData, 0, PAT_NSS_LEN) ;
      string sCodeDoc = string(sCodeDocData, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;

      (*iterDoc)->setPatient(sCodePat) ;
      (*iterDoc)->setDocument(sCodeDoc) ;

      if (((*iterDoc)->ParseMetaDonnees()) &&
                  ((*iterDoc)->DonnePatPatho((*iterDoc)->pPatPathoArray)))
        bOk = true ;
    }
    else
    {
      // m�ta-document sans lien data
      // NOTE : pour ce type de documents on met dans pDonnees le code document du Meta
      // cela permet de les retrouver dans l'historique

      string sCodePat = string((*iterDoc)->sCodeDocMeta, 0, PAT_NSS_LEN) ;
      string sCodeDoc = string((*iterDoc)->sCodeDocMeta, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;

      (*iterDoc)->setPatient(sCodePat) ;
      (*iterDoc)->setDocument(sCodeDoc) ;

      if ((*iterDoc)->ParseMetaDonnees())
      {
        (*iterDoc)->pPatPathoArray->ajoutePatho("ZDOCU1", 0) ;
        bOk = true ;
      }
    }

    //probl�me de r�cup�ration de la patpatho (ou de parsing) : le document
    //ne figure pas dans la liste

    if (!bOk)    {
    	string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "cannotFindDocumentInformation") ;
      sErrorText += string(" (") + (*iterDoc)->getPatient() + string(" ") + (*iterDoc)->getDocument() + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
      erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;

      delete *iterDoc ;
      pDocusArray->erase(iterDoc) ;
    }
    else
    {
      //
      // Pr�paration de l'intitul� du document
      //
      char 		 	chAffiche[1024], dateAffiche[20] ;
      string sAffiche = (*iterDoc)->getDocName() ;
      strip(sAffiche, stripBoth) ;

      if (strcmp((*iterDoc)->GetDateDoc(), ""))      {
        // strcat(chAffiche, " du ") ;
        donne_date((*iterDoc)->GetDateDoc(), dateAffiche, sLang) ;
        // strcat(chAffiche, dateAffiche) ;
        sAffiche += string(" - ") + string(dateAffiche) ;
      }

      //      // Ajout du document � la DocuBox s'il n'est pas d�truit
      //

      // Note : on doit rajouter encore la gestion des suppressions de document en MUE
      // if (pDocument->pDonnees->tranDel[0] == '\0')      // {
      pDocuBox->AddString(sAffiche.c_str()) ;
      // }

      iterDoc++ ;
    }
  }
}

//---------------------------------------------------------------------------//  Function :		ChoixChemiseDialog::CmChemiseDblClk(WPARAM Cmd)
//
//  Arguments :	Cmd : WPARAM retourn� par Windows
//
//  Description :	S�lectionne une chemise enti�re
//
//  Retour	: 		Rien
//---------------------------------------------------------------------------
void ChoixChemiseDialog::CmChemiseDblClk(WPARAM Cmd)
{
}

//---------------------------------------------------------------------------
//  Function :		ChoixChemiseDialog::CmSelectDocument(WPARAM Cmd)
//
//  Arguments :	Cmd : WPARAM retourn� par Windows
//
//  Description :	S�lectionne un document de la chemise en cours
//
//  Retour	: 		Rien
//---------------------------------------------------------------------------
void ChoixChemiseDialog::CmSelectDocument(WPARAM Cmd)
{
	//
	// R�cup�ration de l'indice du document s�lectionn�
	//
	DocumentChoisi = pDocuBox->GetSelIndex() + 1;
}

//---------------------------------------------------------------------------
//  Function :		ChoixChemiseDialog::CmDocumentDblClk(WPARAM Cmd)
//
//  Arguments :	Cmd : WPARAM retourn� par Windows
//
//  Description :	S�lectionne une chemise enti�re
//
//  Retour	: 		Rien
//---------------------------------------------------------------------------
void ChoixChemiseDialog::CmDocumentDblClk(WPARAM Cmd)
{
	NSUtilDialog::CmOk();
}

//---------------------------------------------------------------------------
//  Function :		ChoixChemiseDialog::CmCancel()
//
//  Arguments :	Aucun
//
//  Description :	Annule ChemiseChoisie et DocumentChoisi et appelle Cancel()
//
//  Retour	: 		Rien
//---------------------------------------------------------------------------
void ChoixChemiseDialog::CmCancel()
{
	DocumentChoisi = 0;
	ChemiseChoisie = 0;
	NSUtilDialog::CmCancel();
}

/****************************************************************/
/**      Classes pour la liste des patients � reconvoquer      **/
/****************************************************************/
DEFINE_RESPONSE_TABLE1(NSDateConvocDialog, NSUtilDialog)
	EV_COMMAND(IDOK, CmOk),
	EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

NSDateConvocDialog::NSDateConvocDialog(TWindow* parent, NSContexte* pCtx)
                   :NSUtilDialog(parent, pCtx, "IDD_DATECONVOC")
{
	sDate1 = "" ;
	sDate2 = "" ;
	pDate1 = new NSUtilEditDate(pContexte, this, IDC_DATECONVOC_DATE1) ;
	pDate2 = new NSUtilEditDate(pContexte, this, IDC_DATECONVOC_DATE2) ;
}

NSDateConvocDialog::~NSDateConvocDialog()
{
	delete pDate1 ;
	delete pDate2 ;
}

void
NSDateConvocDialog::SetupWindow()
{
	struct date	dateSys ;
	char	dateJour[9] = "" ;

	NSUtilDialog::SetupWindow() ;

	getdate(&dateSys) ;
	sprintf(dateJour, "%4d%02d%02d", dateSys.da_year, dateSys.da_mon, dateSys.da_day) ;

	pDate1->setDate(dateJour) ;
	pDate2->setDate(dateJour) ;
}

void
NSDateConvocDialog::CmOk()
{
	pDate1->getDate(&sDate1) ;
	pDate2->getDate(&sDate2) ;

	NSUtilDialog::CmOk() ;
}

void
NSDateConvocDialog::CmCancel()
{
	NSUtilDialog::CmCancel() ;
}

//-----------------------------------------------------------------------
// fonction globale de tri :
//			afficher les patients dans ordre de date de reconvocation
//-----------------------------------------------------------------------
bool
triParDates(NSPersonInfo* a, NSPersonInfo* b)
{
	if (a->getConvoc() < b->getConvoc())
		return true ;
	return false ;
}

/******************************************************************/

DEFINE_RESPONSE_TABLE1(NSListeConvocDialog, NSUtilDialog)
	EV_LV_DISPINFO_NOTIFY(IDC_LISTECONVOC_LW, LVN_GETDISPINFO, DispInfoListe),
	EV_COMMAND(IDC_LISTECONVOC_IMP, CmImprimerListe),
	EV_COMMAND(IDC_LISTECONVOC_LETTRE, CmImprimerLettre),
	EV_COMMAND(IDOK, CmOk),
	EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

NSListeConvocDialog::NSListeConvocDialog(TWindow* parent, NSContexte* pCtx, NSVarConvoc* pVarConvoc)
                    :NSUtilDialog(parent, pCtx, "IDD_LISTECONVOC")
{
try
{
	pDate1 = new NSUtilEditDate(pContexte, this, IDC_LISTECONVOC_DATE1) ;
	pDate2 = new NSUtilEditDate(pContexte, this, IDC_LISTECONVOC_DATE2) ;
	pListe = new NSListeConvocWindow(this, IDC_LISTECONVOC_LW) ;
	pTabSelect = 0 ;
	nbConvoc = 0 ;

	pVar = pVarConvoc ;
	bImprimerListe = false ;
	bImprimerLettre = false ;

  string _sLang = "" ;
	if (pContexte->getUtilisateur())
		_sLang = pContexte->getUtilisateur()->donneLang() ;
}catch (...)
{
	erreur("Exception NSListeConvocDialog ctor.", standardError, 0) ;
}
}

NSListeConvocDialog::~NSListeConvocDialog()
{
	// Attention on ne delete pas l'objet point� par pVar
	// car cet objet doit rester r�sidant
	delete pDate1 ;
	delete pDate2 ;
	delete pListe ;
	if (NULL != pTabSelect)
		delete[] pTabSelect ;
}

void
NSListeConvocDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	pDate1->setDate(pVar->sDate1) ;
	pDate2->setDate(pVar->sDate2) ;

	if (InitPatientArray())
	{
  	InitListe() ;
    AfficheListe() ;
	}
}

bool
NSListeConvocDialog::InitPatientArray()
{
try
{
	if (NULL == pVar)
		return false ;

	SetCursor(0, IDC_WAIT) ;

	(pVar->aPatientArray).vider() ;
	pVar->nbPatient = 0 ;

  NSBasicAttributeArray AttrArray  ;

	// We could do this, but the comparison would not be made on the same node
  //
	// AttrArray.push_back(new NSBasicAttribute(APPOINTMENT_DATE, string("${>=}$") + pVar->sDate1)) ;
  // AttrArray.push_back(new NSBasicAttribute(APPOINTMENT_DATE, string("${<=}$") + pVar->sDate2)) ;

  string sRequest = string(" $[]$ >= '") + pVar->sDate1 + string("' AND $[]$ <= '") + pVar->sDate2 + string("'") ;
  AttrArray.push_back(new NSBasicAttribute(APPOINTMENT_DATE, sRequest)) ;
  AttrArray.push_back(new NSBasicAttribute(TRAIT, APPOINTMENT_DATE));

  NSPersonsAttributesArray PatiensList ;

  bool bListOk = pContexte->pPilot->personList((NautilusPilot::SERV_PERSON_LIST_FROM_TRAITS).c_str(), &PatiensList, &AttrArray) ;

	if (false == bListOk)
	{
  	std::string tempMessage = pContexte->pPilot->getWarningMessage() ;
    std::string tempError   = pContexte->pPilot->getErrorMessage() ;
    if( tempMessage != "")
    	::MessageBox(GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
    if( tempError != "")
    	::MessageBox(GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
    SetCursor(0, IDC_ARROW) ;
    return false ;
	}

	// Nobody found
	//
	if (true == PatiensList.empty())
  {
		erreur("Aucune date de reconvocation dans l'intervalle.", warningError, 0, GetHandle()) ;
    SetCursor(0, IDC_ARROW) ;
    return true ;
	}

  for (NSPersonsAttributeIter iterPatient = PatiensList.begin(); iterPatient != PatiensList.end(); iterPatient++)
	{
  	NSPersonInfo bufferInfo(pContexte, *iterPatient) ;
    NSPersonInfo* pNewPerson = new NSPersonInfo(pContexte, bufferInfo.getNss(), pidsPatient) ;
    pNewPerson->setConvoc(bufferInfo.getConvoc()) ;
  	(pVar->aPatientArray).push_back(pNewPerson) ;
    pVar->nbPatient++ ;
	}

	if (true == pVar->aPatientArray.empty())
  {
  	SetCursor(0, IDC_ARROW) ;
		return true ;
  }

  SetCursor(0, IDC_ARROW) ;

	sort((pVar->aPatientArray).begin(), (pVar->aPatientArray).end(), triParDates) ;

	return true ;
}
catch (...)
{
	erreur("Exception NSListeConvocDialog::InitPatientArray.", standardError, 0, GetHandle()) ;
  return false ;
}
}

void
NSListeConvocDialog::InitListe()
{
	TListWindColumn colPat("Patient", 200, TListWindColumn::Left, 0) ;
	pListe->InsertColumn(0, colPat) ;
	TListWindColumn colDate("Date", 200, TListWindColumn::Left, 1) ;
	pListe->InsertColumn(1, colDate) ;
}

voidNSListeConvocDialog::AfficheListe()
{
	pListe->DeleteAllItems() ;

  static char buffer[1024] ;

	for (int i = pVar->nbPatient - 1; i >= 0; i--)
	{
  	strcpy(buffer, (pVar->aPatientArray)[i]->getNomLong().c_str()) ;
  	TListWindItem Item(buffer, 0) ;
    pListe->InsertItem(Item) ;
	}
}

voidNSListeConvocDialog::DispInfoListe(TLwDispInfoNotify& dispInfo)
{
	const int BufLen = 255 ;
	static char buffer[BufLen] ;
	char cDate[10] ;
	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;

  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	int index = dispInfoItem.GetIndex() ;

	// Affiche les informations en fonction de la colonne

	switch (dispInfoItem.GetSubItem())	{
  	case 1: 	// date de reconvocation
    	{
      	string sTimeFormat = pContexte->getSuperviseur()->getText("0localInformation", "timeFormat") ;
        string sFormatedTime = getFormatedTime(((pVar->aPatientArray)[index])->getConvoc(), sLang, sTimeFormat, "") ;
    		strcpy(buffer, sFormatedTime.c_str()) ;
      	dispInfoItem.SetText(buffer) ;
    	}
    	break ;
	}
}

voidNSListeConvocDialog::CmFichePatient(int itemSel)
{
	NSFichePatientDialog* pFPDlg = new NSFichePatientDialog(this, pContexte,
	                                            (pVar->aPatientArray)[itemSel]) ;
	pFPDlg->Execute() ;
	delete pFPDlg ;
}

voidNSListeConvocDialog::CmImprimerListe()
{
	bImprimerListe = true;
	CmOk() ;
}

voidNSListeConvocDialog::CmImprimerLettre()
{
	pTabSelect = new int[pVar->nbPatient] ;
	nbConvoc = pListe->GetSelIndexes(pTabSelect, pVar->nbPatient) ;
	bImprimerLettre = true ;
	CmOk() ;
}

voidNSListeConvocDialog::CmOk()
{
	NSUtilDialog::CmOk() ;
}

voidNSListeConvocDialog::CmCancel()
{
	NSUtilDialog::CmCancel() ;
}

// -----------------------------------------------------------------
//
//  M�thodes de NSListPatWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSListeConvocWindow, TListWindow)
	EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

NSListeConvocWindow::NSListeConvocWindow(NSListeConvocDialog* pere, int resId)                    :TListWindow(pere, resId){
	pDlg = pere ;
}

//---------------------------------------------------------------------------//  Function: NSListeConvocWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListeConvocWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point) ;

	HitTest(info) ;

	if (info.GetFlags() & LVHT_ONITEM)
		pDlg->CmFichePatient(IndexItemSelect()) ;
}

//---------------------------------------------------------------------------
//  Function: NSListeConvocWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListeConvocWindow::IndexItemSelect()
{
	int count = GetItemCount() ;
	int index = -1 ;

	for (int i = 0; i < count; i++)
  	if (GetItemState(i, LVIS_SELECTED))
    {
    	index = i ;
      break ;
    }

	return index ;
}

// Retourne le tableau des items s�lectionn�s avec leurs indexs// Valeur de retour : Nombre d'items s�lectionn�s
int
NSListeConvocWindow::GetSelIndexes(int* pTabIndex, int tailleTab)
{
	int count = GetItemCount() ;
	int numSelect = 0 ;

	for (int i = 0; i < count; i++)
  	if (GetItemState(i, LVIS_SELECTED))
    {
    	if (numSelect < tailleTab)
      {
      	pTabIndex[numSelect] = i ;
        numSelect++ ;
      }
    }

	return numSelect ;
}

//// Classe NSFichePatientDialog
//
DEFINE_RESPONSE_TABLE1(NSFichePatientDialog, NSUtilDialog)
	EV_COMMAND(IDC_ADMIN_MODIFDC, CmModifDateConvoc),
	EV_COMMAND(IDOK, CmOk),
	EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

NSFichePatientDialog::NSFichePatientDialog(TWindow* parent, NSContexte* pCtx, NSPersonInfo* ppi)
                     :NSUtilDialog(parent, pCtx, "IDD_FICHEPATIENT")
{
	pSitFam  = new NSUtilEdit(pContexte, this, IDC_ADMIN_SITFAM, 15) ;
	pNbEnf 	 = new NSUtilEdit(pContexte, this, IDC_ADMIN_NBENF, 2) ;
	pSexe 	 = new NSUtilEdit(pContexte, this, IDC_ADMIN_SEXE, 8) ;
	pDateN 	 = new NSUtilEditDate(pContexte, this, IDC_ADMIN_DATEN) ;

	pNss 		 = new NSUtilEdit(pContexte, this, IDC_ADMIN_NSS, PAT_NSS_LEN) ;	pCode 	 = new NSUtilEdit(pContexte, this, IDC_ADMIN_CODE, PAT_CODE_LEN) ;
  pTelPor  = new NSUtilEdit(pContexte, this, IDC_ADMIN_TELPOR, PAT_TELEPOR_LEN) ;
  pTelBur  = new NSUtilEdit(pContexte, this, IDC_ADMIN_TELBUR, PAT_TELEBUR_LEN) ;

  pDateC 	 = new NSUtilEditDate(pContexte, this, IDC_ADMIN_DATEC) ;

  pAdresse = new NSUtilEdit(pContexte, this, IDC_ADMIN_ADR) ;  // textLimit = 0
  pTelDom  = new NSUtilEdit(pContexte, this, IDC_ADMIN_TELDOM, ADR_TELEPHONE_LEN) ;
  pEMail   = new NSUtilEdit(pContexte, this, IDC_ADMIN_EMAIL, ADR_MESSAGERIE_LEN) ;
  pFax     = new NSUtilEdit(pContexte, this, IDC_ADMIN_FAX, ADR_FAX_LEN) ;

  pListeCorresp = new TListBox(this, IDC_ADMIN_COR) ;

  pPatInfo = ppi ;
}

NSFichePatientDialog::~NSFichePatientDialog()
{
	delete pListeCorresp ;
  delete pFax ;
  delete pEMail ;
  delete pTelDom ;
  delete pAdresse ;
  delete pDateC ;
  delete pTelBur ;
  delete pTelPor ;
  delete pCode ;
  delete pNss ;
  delete pDateN ;
  delete pSexe ;
  delete pNbEnf ;
  delete pSitFam ;
}

void
NSFichePatientDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	AfficheDonneesPatient() ;
  AfficheDonneesAdresse() ;
  AfficheDonneesCorresp() ;
}

void
NSFichePatientDialog::AfficheDonneesPatient()
{
	SetCaption(pPatInfo->getNomLong().c_str()) ;

	if (pPatInfo->estMasculin())
  	pSexe->SetText("Masculin") ;
	else
  	pSexe->SetText("F�minin") ;

  // pSitFam->SetText((pPatInfo->donneSitFam()).c_str()) ;
  // pNbEnf->SetText((pPatInfo->donneNbEnfants()).c_str()) ;

  pDateN->setDate(pPatInfo->getNaissance()) ;

	pNss->SetText(pPatInfo->getNss().c_str()) ;
  // pCode->SetText(pPatInfo->getCode().c_str()) ;
  // pTelPor->SetText(pPatInfo->getTelepor().c_str()) ;
  // pTelBur->SetText(pPatInfo->getTelebur().c_str()) ;

	pDateC->setDate(pPatInfo->getConvoc()) ;
}

voidNSFichePatientDialog::AfficheDonneesAdresse()
{
/*
	string sAdresse ;

	pAdresse->FormatLines(true);
	pAdresse->SetText("");

	pTelDom->SetText(pPatInfo->pAdresseInfo->pDonnees->telephone);
	pFax->SetText(pPatInfo->pAdresseInfo->pDonnees->fax);
	pEMail->SetText(pPatInfo->pAdresseInfo->pDonnees->messagerie);

	sAdresse = pPatInfo->pAdresseInfo->StringAdresse();
	pAdresse->SetText(sAdresse.c_str());
*/
}

void
NSFichePatientDialog::AfficheDonneesCorresp()
{
/*
	string sCorresp;

	// on vide la liste si elle contient des items
    if (pListeCorresp->GetCount())
   	    pListeCorresp->ClearList();

    for (CorrespInfoIter i = pPatInfo->pCorrespArray->begin();
   							i != pPatInfo->pCorrespArray->end(); i++)
    {
        // on remplit la CorrespBox
        sCorresp = string((*i)->pDonnees->nom) + string(" ") + string((*i)->pDonnees->prenom);
        pListeCorresp->AddString(sCorresp.c_str());
    }
*/
}

void
NSFichePatientDialog::CmModifDateConvoc()
{
/*
	string sDateC;

    pDateC->getDate(&sDateC);
    strcpy(pPatInfo->pDonnees->convoc, sDateC.c_str());

    NSPatient* pPatient = new NSPatient(pContexte);

    pPatient->lastError = pPatient->open();
    if (pPatient->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur � l'ouverture du fichier Patient.db", 0, pPatient->lastError, GetHandle());
		delete pPatient;
		return;
    }

    pPatient->lastError = pPatient->chercheClef((unsigned char*)(pPatInfo->pDonnees->nss),
													 					"",
													 					0,
													 					keySEARCHEQ,
                                                                        dbiWRITELOCK);
    if (pPatient->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur � la recherche du Patient.", 0, pPatient->lastError, GetHandle());
        pPatient->close();
		delete pPatient;
		return;
    }

    pPatient->lastError = pPatient->getRecord();
    if (pPatient->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur � lecture du fichier Patient.db", 0, pPatient->lastError, GetHandle());
        pPatient->close();
		delete pPatient;
		return;
    }

    // On remet � jour la date de reconvocation
    strcpy(pPatient->pDonnees->convoc, sDateC.c_str());

    pPatient->lastError = pPatient->modifyRecord(TRUE);
    if (pPatient->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur � modification du fichier Patient.db", 0, pPatient->lastError, GetHandle());
        pPatient->close();
		delete pPatient;
		return;
    }

    pPatient->lastError = pPatient->close();
    if (pPatient->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur � la fermeture du fichier Patient.db", 0, pPatient->lastError, GetHandle());
		delete pPatient;
		return;
    }

    MessageBox("Date de reconvocation enregistr�e");*/
}
voidNSFichePatientDialog::CmOk()
{
	NSUtilDialog::CmOk() ;
}

/*************************************************************
    AFFICHAGE DES RESULTATS DE REQUETE (cf nsrechcr.cpp)
**************************************************************/
// -----------------------------------------------------------------//
//  M�thodes de NSResultReqWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSResultReqWindow, TListWindow)
	EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

//---------------------------------------------------------------------------
//  Function: NSResultReqWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
//
//  Arguments:	  les modKeys et le point click�
//
//  Description: Fonction de r�ponse au click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSResultReqWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TListWindow::EvLButtonDown(modKeys, point) ;

	TLwHitTestInfo info(point) ;
	HitTest(info) ;

	if (info.GetFlags() & LVHT_ONITEM)
		pDlg->AfficheItem() ;
}

//---------------------------------------------------------------------------//  Function: NSResultReqWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSResultReqWindow::IndexItemSelect()
{
	int count = GetItemCount();
	int index = -1;

	for (int i = 0; i < count; i++)
  	if (GetItemState(i, LVIS_SELECTED))
    {
    	index = i ;
      break ;
    }

	return index ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSResultReqDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSResultReqDialog, NSUtilDialog)
	EV_BN_CLICKED(IDC_RESULTREQ_FERMER,   CmFermer),
  EV_LVN_GETDISPINFO(IDC_RESULTREQ_LW,  LvnGetDispInfo),
  EV_BN_CLICKED(IDC_RESULTREQ_MASQUER,  CmMasquer),
  EV_BN_CLICKED(IDC_RESULTREQ_OUVRIR,   CmOuvrir),
  EV_BN_CLICKED(IDC_RESULTREQ_ENREG,    CmEnregistrer),
  EV_BN_CLICKED(IDC_RESULTREQ_EXCEL,    CmExcelExport),
  EV_BN_CLICKED(IDC_RESULTREQ_IMPRIMER, CmImprimer),  EV_TCN_KEYDOWN(IDC_RESULTREQ_TABS,    RequestTabKeyDown),	EV_TCN_SELCHANGE(IDC_RESULTREQ_TABS,  RequestTabSelChange), 
END_RESPONSE_TABLE;

NSResultReqDialog::NSResultReqDialog(TWindow* pere, NSContexte* pCtx, NSRequeteDialog* pRequete)
                  :NSUtilDialog(pere, pCtx, "IDD_RESULTREQ")
{
  pReqDlg      = pRequete ;
  pNomRes      = new NSUtilEdit2(pContexte, this, IDC_RESULTREQ_NOM, 80) ;
  pRequests    = new OWL::TTabControl(this, IDC_RESULTREQ_TABS) ;
  pListeRes    = new NSResultReqWindow(this, IDC_RESULTREQ_LW) ;
  pPatTotal    = new TStatic(this, IDC_RESULTREQ_TOTALPAT1) ;
  pPatCritPat  = new TStatic(this, IDC_RESULTREQ_TOTALPAT2) ;
  pPatCritDoc  = new TStatic(this, IDC_RESULTREQ_TOTALPAT3) ;
  pPatResult   = new TStatic(this, IDC_RESULTREQ_RESULTPAT) ;
  pDocCritPat  = new TStatic(this, IDC_RESULTREQ_TOTALDOC2) ;
  pDocCritDoc  = new TStatic(this, IDC_RESULTREQ_TOTALDOC3) ;
  pDocResult   = new TStatic(this, IDC_RESULTREQ_RESULTDOC) ;

  pRequestPatResult = new TStatic(this, IDC_RESULTREQ_PAT_TABS) ;
	pRequestDocResult = new TStatic(this, IDC_RESULTREQ_DOC_TABS) ;

	sFileNameRes =  "" ;

  if (pReqDlg)  {    // chargement des compteurs et des donn�es
    bReqModeDoc  = pReqDlg->bReqModeDoc ;
    nbPatTotal   = pReqDlg->nbPatTotal ;
    nbPatCritPat = pReqDlg->nbPatCritPat ;
    nbPatCritDoc = pReqDlg->nbPatCritDoc ;
    nbPatResult  = pReqDlg->nbPatResult ;
    nbDocCritPat = pReqDlg->nbDocCritPat ;
    nbDocCritDoc = pReqDlg->nbDocCritDoc ;
    nbDocResult  = pReqDlg->nbDocResult ;

    if (false == pReqDlg->VectDocResultat.empty())
    	for (DocumentIter i = pReqDlg->VectDocResultat.begin(); i != pReqDlg->VectDocResultat.end(); i++)
    		VectDocResultat.push_back(new NSDocumentHisto(*(*i))) ;
    if (false == pReqDlg->VectPatResultat.empty())
    	for (PatientIter i = pReqDlg->VectPatResultat.begin(); i != pReqDlg->VectPatResultat.end(); i++)
    		VectPatResultat.push_back(new NSPatInfo(*(*i))) ;

    if (false == pReqDlg->_aRequestResults.empty())
    	for (NSRequestResultIter i = pReqDlg->_aRequestResults.begin(); i != pReqDlg->_aRequestResults.end(); i++)
    		VectRequestResults.push_back(new NSRequestResult(*(*i))) ;
  }
}

NSResultReqDialog::~NSResultReqDialog(){
  delete pListeRes ;
  delete pRequests ;
  delete pPatTotal ;
  delete pPatCritPat ;
  delete pPatCritDoc ;
  delete pPatResult ;
  delete pDocCritPat ;
  delete pDocCritDoc ;
  delete pDocResult ;
  delete pRequestPatResult ;
  delete pRequestDocResult ;
}

voidNSResultReqDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;
	InitListeRes() ;
	itemChoisi = -1 ;

  if (false == VectRequestResults.empty())
  {
  	if (VectRequestResults.size() > 1)
    {
    	string sTabText = pContexte->getSuperviseur()->getText("searchingResultDisplay", "allResults") ;
  		TTabItem tab(sTabText.c_str()) ;
			pRequests->Add(tab) ;
    }

		for (NSRequestResultIter it = VectRequestResults.begin(); VectRequestResults.end() != it; it++)
    {
    	string sReqName = (*it)->getRequestName() ;
    	pRequests->Add(TTabItem(sReqName.c_str())) ;
    }

    pRequests->SetSel(0) ;
  }

	if (pReqDlg)
	{
  	if (sFileNameRes != "")
    	pNomRes->SetText(sFileNameRes.c_str()) ;
    AfficheCompteurs() ;
    AfficheListeRes() ;
	}
	else
	{
		// chargement � partir d'un fichier .nrs
		CmOuvrir() ;
	}
}

voidNSResultReqDialog::AfficheCompteurs()
{
  char cText[255] = "" ;
  char cLib[255] = "" ;

  pPatTotal->GetText(cLib, 200) ;
  sprintf(cText, "%s : %d", cLib, nbPatTotal) ;
  pPatTotal->SetText(cText) ;

  pPatCritPat->GetText(cLib, 200) ;
  sprintf(cText, "%s : %d", cLib, nbPatCritPat) ;
  pPatCritPat->SetText(cText) ;

  pPatCritDoc->GetText(cLib, 200) ;
  sprintf(cText, "%s : %d", cLib, nbPatCritDoc) ;
  pPatCritDoc->SetText(cText) ;

  pPatResult->GetText(cLib, 200) ;
  sprintf(cText, "%s : %d", cLib, nbPatResult) ;
  pPatResult->SetText(cText) ;

  if (bReqModeDoc)
  {
    pDocCritPat->GetText(cLib, 200) ;
    sprintf(cText, "%s : %d", cLib, nbDocCritPat) ;
    pDocCritPat->SetText(cText) ;

    pDocCritDoc->GetText(cLib, 200) ;
    sprintf(cText, "%s : %d", cLib, nbDocCritDoc) ;
    pDocCritDoc->SetText(cText) ;

    pDocResult->GetText(cLib, 200) ;
    sprintf(cText, "%s : %d", cLib, nbDocResult) ;
    pDocResult->SetText(cText) ;
  }
  else
  {
    // compteurs non valides en mode Patient
    pDocCritPat->SetText("") ;
    pDocCritDoc->SetText("") ;
    pDocResult->SetText("") ;
  }
}
void
NSResultReqDialog::InitListeRes()
{
	string sLocalText = pContexte->getSuperviseur()->getText("searchingResultDisplay", "patient") ;
  TListWindColumn colPat((char*) sLocalText.c_str(), 50, TListWindColumn::Left, 0);
  pListeRes->InsertColumn(0, colPat);

	sLocalText = pContexte->getSuperviseur()->getText("searchingResultDisplay", "document") ;
  TListWindColumn colDoc((char*) sLocalText.c_str(), 50, TListWindColumn::Left, 1);
  pListeRes->InsertColumn(1, colDoc);

  sLocalText = pContexte->getSuperviseur()->getText("searchingResultDisplay", "name") ;
  TListWindColumn colNom((char*) sLocalText.c_str(), 200, TListWindColumn::Left, 2);
  pListeRes->InsertColumn(2, colNom);

  sLocalText = pContexte->getSuperviseur()->getText("searchingResultDisplay", "title") ;
  TListWindColumn colTitre((char*) sLocalText.c_str(), 200, TListWindColumn::Left, 3);
  pListeRes->InsertColumn(3, colTitre);
}

voidNSResultReqDialog::AfficheListeRes()
{
	pListeRes->DeleteAllItems() ;
  int index = pRequests->GetSel() ;

  int iNbPatResult = nbPatResult ;
	int iNbDocResult = nbDocResult ;

  if (bReqModeDoc)
  {
  	NSDocHistoArray* pCurrentArray ;

    if ((true == VectRequestResults.empty()) || (1 == VectRequestResults.size()))
    	pCurrentArray = &VectDocResultat ;
    else if (0 == index)
    	pCurrentArray = &VectDocResultat ;
    else
    {
    	pCurrentArray = &(VectRequestResults[index-1]->_aVectDocumentResults) ;
      iNbPatResult = VectRequestResults[index-1]->_nbPatResult ;
			iNbDocResult = VectRequestResults[index-1]->_nbDocResult ;
    }

  	for (DocumentIter it = pCurrentArray->end(); pCurrentArray->begin() != it; )
    {
    	it-- ;
    	TListWindItem Item((*it)->getPatient().c_str(), 0, strlen((*it)->getPatient().c_str())) ;
      pListeRes->InsertItem(Item) ;
    }
  }
  else
  {
  	NSPatientArray* pCurrentArray ;

    if ((true == VectRequestResults.empty()) || (1 == VectRequestResults.size()))
    	pCurrentArray = &VectPatResultat ;
    else if (0 == index)
    	pCurrentArray = &VectPatResultat ;
    else
    {
    	pCurrentArray = &(VectRequestResults[index-1]->_aVectPatientResults) ;
      iNbPatResult = VectRequestResults[index-1]->_nbPatResult ;
			iNbDocResult = VectRequestResults[index-1]->_nbDocResult ;
    }

  	for (PatientIter it = pCurrentArray->end(); pCurrentArray->begin() != it; )
    {
    	it-- ;
    	TListWindItem Item((*it)->getszNss(), 0) ;
      pListeRes->InsertItem(Item) ;
    }
  }

  string sPatText = pContexte->getSuperviseur()->getText("searchingResultDisplay", "patientsFound") ;
  string sDocText = pContexte->getSuperviseur()->getText("searchingResultDisplay", "documentsFound") ;

	char cText[255] = "" ;
  sprintf(cText, "%s : %d", sPatText.c_str(), iNbPatResult) ;
  pRequestPatResult->SetText(cText) ;
  sprintf(cText, "%s : %d", sDocText.c_str(), iNbDocResult) ;
  pRequestDocResult->SetText(cText) ;

/*
	char nss[PAT_NSS_LEN + 1] ;
	int  nbTrouves ;
	if (bReqModeDoc)
		nbTrouves = nbDocResult ;
	else
		nbTrouves = nbPatResult ;

	for (int i = nbTrouves - 1; i >= 0; i--)
	{
		if (bReqModeDoc)
			strcpy(nss, ((VectDocResultat)[i])->pDonnees->codePatient) ;
		else
			strcpy(nss, ((VectPatResultat)[i])->getszNss()) ;
		TListWindItem Item(nss, 0) ;		pListeRes->InsertItem(Item) ;
	}
*/
}

voidNSResultReqDialog::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
	const int BufLen = 255 ;
	static char buffer[BufLen] ;
	char nom[BufLen] ;	char prenom[BufLen] ;	char dateAffiche[20] ;

	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;
	int index = dispInfoItem.GetIndex() ;
	string sLang = "" ;	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;
  NSDocHistoArray* pCurrentDocArray ;
  NSPatientArray*  pCurrentPatArray ;

  int iTabIndex = pRequests->GetSel() ;
  if ((true == VectRequestResults.empty()) || (1 == VectRequestResults.size()))
  {
  	pCurrentDocArray = &VectDocResultat ;
  	pCurrentPatArray = &VectPatResultat ;
  }
  else if (0 == iTabIndex)
  {
  	pCurrentDocArray = &VectDocResultat ;
  	pCurrentPatArray = &VectPatResultat ;
  }
  else
  {
  	pCurrentDocArray = &(VectRequestResults[iTabIndex-1]->_aVectDocumentResults) ;
  	pCurrentPatArray = &(VectRequestResults[iTabIndex-1]->_aVectPatientResults) ;
  }

	// Affiche les informations en fonction de la colonne
	switch (dispInfoItem.GetSubItem())	{

		case 1: 	// code document

			if (bReqModeDoc)      	sprintf(buffer, "%s", ((*pCurrentDocArray)[index])->getDocument().c_str()) ;
      else
      	strcpy(buffer, "") ;
      dispInfoItem.SetText(buffer) ;
      break ;

		case 2: 	// nom patient
    	if (pReqDlg->bReqModeDoc)
      {
      	// Chercher le patient
        string sPatId = ((*pCurrentDocArray)[index])->getPatient() ;

        PatientIter it = pCurrentPatArray->begin() ;
        for ( ; (pCurrentPatArray->end() != it) && ((*it)->getNss() != sPatId); it++) ;
        if (pCurrentPatArray->end() != it)
        {
        	strcpy(nom, (*it)->getszNom()) ;
      		strcpy(prenom, (*it)->getszPrenom()) ;
        }
        else
        {
        	strcpy(nom, "") ;
      		strcpy(prenom, "") ;
        }
      }
      else
      {
				strcpy(nom, (VectPatResultat[index])->getszNom()) ;
      	strcpy(prenom, (VectPatResultat[index])->getszPrenom()) ;
      }

			sprintf(buffer, "%s %s", nom, prenom) ;
			dispInfoItem.SetText(buffer) ;
			break ;

		case 3:     // titre document
			if (pReqDlg->bReqModeDoc)      {
      	donne_date(((*pCurrentDocArray)[index])->GetDateDoc(), dateAffiche, sLang) ;
        sprintf(buffer, "%s du %s", ((*pCurrentDocArray)[index])->getDocName().c_str(),
                                            dateAffiche) ;
      }
      else
      	strcpy(buffer, "") ;
      dispInfoItem.SetText(buffer) ;
      break ;
  }
}

voidNSResultReqDialog::AfficheItem()
{
	itemChoisi = pListeRes->IndexItemSelect() ;

	if (itemChoisi == -1)		return ;

	NSUtilDialog::CmOk() ;}

voidNSResultReqDialog::EcrireResultats(string &sOut)
{
	char cCpt[20] ;

	sOut += string("cpt") + "\"" ;

	if (bReqModeDoc)
		sOut += string("1") + "\"" ;
	else
		sOut += string("0") + "\"" ;

  // on �crit tous les compteurs
  itoa(nbPatTotal, cCpt, 10) ;
  sOut += string(cCpt) + "\"" ;
  itoa(nbPatCritPat, cCpt, 10) ;
  sOut += string(cCpt) + "\"" ;
  itoa(nbPatCritDoc, cCpt, 10) ;
  sOut += string(cCpt) + "\"" ;
  itoa(nbPatResult, cCpt, 10) ;
  sOut += string(cCpt) + "\"" ;
  itoa(nbDocCritPat, cCpt, 10) ;
  sOut += string(cCpt) + "\"" ;
  itoa(nbDocCritDoc, cCpt, 10) ;
  sOut += string(cCpt) + "\"" ;
  itoa(nbDocResult, cCpt, 10) ;
  sOut += string(cCpt) + "\"" ;
  sOut += "$\n" ;       // le '$' en fin de chaine sert � simplifier la lecture

	// Vecteur des patients
	sOut += string("vpa") + "\"" ;
	for (PatientIter i = VectPatResultat.begin(); i != VectPatResultat.end(); i++)
		sOut += (*i)->getNss() + "\"" ;

	sOut += "$\n" ;
	// Vecteur des documents	if ((bReqModeDoc) && (false == VectDocResultat.empty()))
	{
		sOut += string("vdo") + "\"" ;
    for (DocumentIter i = VectDocResultat.begin(); i != VectDocResultat.end(); i++)
    {
    	sOut += (*i)->getPatient() + "|" ;
      sOut += (*i)->getDocument() + "\"" ;
    }
    sOut += "$\n" ;
	}

  if (true == VectRequestResults.empty())
		return ;

	for (NSRequestResultIter it = VectRequestResults.begin(); VectRequestResults.end() != it; it++)
	{
  	// Vecteur des patients
		sOut += string("vp2") + "\"" ;
    sOut += (*it)->getRequestName() + "\"" ;
    sOut += (*it)->getRequestLabel() + "\"" ;
    itoa((*it)->_nbPatResult, cCpt, 10) ;
  	sOut += string(cCpt) + "\"" ;
  	itoa((*it)->_nbDocResult, cCpt, 10) ;
  	sOut += string(cCpt) + "\"" ;
    if (false == (*it)->_aVectPatientResults.empty())
			for (PatientIter i = (*it)->_aVectPatientResults.begin(); (*it)->_aVectPatientResults.end() != i; i++)
				sOut += (*i)->getNss() + "\"" ;

		sOut += "$\n" ;
		// Vecteur des documents		if ((bReqModeDoc) && (false == (*it)->_aVectDocumentResults.empty()))
		{
			sOut += string("vd2") + "\"" ;
    	for (DocumentIter i = (*it)->_aVectDocumentResults.begin(); i != (*it)->_aVectDocumentResults.end(); i++)
    	{
    		sOut += (*i)->getPatient() + "|" ;
      	sOut += (*i)->getDocument() + "\"" ;
    	}
    	sOut += "$\n" ;
		}
  }
}

boolNSResultReqDialog::ChargerResultats(string sFichier)
{
	ifstream inFile ;
	string   line ;

	inFile.open(sFichier.c_str());
	if (!inFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    sErrorText += string(" (") + sFichier + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
		return false ;
	}

	while (!inFile.eof())
	{
		getline(inFile,line) ;

		if (strlen(line.c_str()) >= 3)
		{
    	string sType = string(line, 0, 3) ;
      string sData ;
      size_t pos1, pos2 ;

    	pos2 = line.find('\"');
      if (pos2 == NPOS)
      	continue ;

      if (sType == "cpt")
      {
        // compteurs
        nbPatTotal = 0; nbPatCritPat = 0; nbPatCritDoc = 0; nbPatResult = 0;
        nbDocCritPat = 0; nbDocCritDoc = 0; nbDocResult = 0;

        pos1 = pos2+1;
        pos2 = line.find('\"', pos1);
        if (pos2 == NPOS)
            continue;
        sData = string(line, pos1, pos2-pos1);
        if (sData == "1")
            bReqModeDoc = true;
        else
            bReqModeDoc = false;

        pos1 = pos2+1;
        pos2 = line.find('\"', pos1);
        if (pos2 == NPOS)
            continue;
        sData = string(line, pos1, pos2-pos1);
        nbPatTotal = atoi(sData.c_str());

        pos1 = pos2+1;
        pos2 = line.find('\"', pos1);
        if (pos2 == NPOS)            continue;
        sData = string(line, pos1, pos2-pos1);        nbPatCritPat = atoi(sData.c_str());

        pos1 = pos2+1;
        pos2 = line.find('\"', pos1);
        if (pos2 == NPOS)
            continue;
        sData = string(line, pos1, pos2-pos1);
        nbPatCritDoc = atoi(sData.c_str());

        pos1 = pos2+1;
        pos2 = line.find('\"', pos1);
        if (pos2 == NPOS)
            continue;
        sData = string(line, pos1, pos2-pos1);
        nbPatResult = atoi(sData.c_str());

        pos1 = pos2+1 ;
        pos2 = line.find('\"', pos1) ;
        if (pos2 == NPOS)
        	continue ;
        sData = string(line, pos1, pos2-pos1) ;
        nbDocCritPat = atoi(sData.c_str()) ;

        pos1 = pos2+1 ;
        pos2 = line.find('\"', pos1) ;
        if (pos2 == NPOS)
        	continue ;
        sData = string(line, pos1, pos2-pos1) ;
        nbDocCritDoc = atoi(sData.c_str()) ;

        pos1 = pos2+1 ;
        pos2 = line.find('\"', pos1) ;
        if (pos2 == NPOS)
        	continue ;
        sData = string(line, pos1, pos2-pos1) ;
        nbDocResult = atoi(sData.c_str()) ;
      }
      else if (sType == "vpa")
      {
        // vecteur des patients r�sultat
        VectPatResultat.vider() ;
        NSPatInfo patinfo(pContexte) ;

        // on charge juste les nss pour l'instant
        // on a forc�ment un '$' en fin de chaine,
        // cela �vite un plantage �ventuel sur find
        pos1 = pos2+1 ;
        pos2 = line.find('\"', pos1) ;
        while (pos2 != NPOS)
        {
          sData = string(line, pos1, pos2-pos1) ;
          patinfo.setNss(sData) ;
          VectPatResultat.push_back(new NSPatInfo(patinfo)) ;          pos1 = pos2+1 ;
          pos2 = line.find('\"', pos1) ;
      	}
      }
      else if (sType == "vdo")
      {
        // vecteur des documents r�sultat
        VectDocResultat.vider() ;
        NSDocumentHisto dochisto(pContexte) ;
        string sCodePat, sCodeDoc ;
        size_t pos ;

        // on charge juste les codes pour l'instant
        // on a forc�ment un '$' en fin de chaine,
        // cela �vite un plantage �ventuel sur find
        pos1 = pos2+1 ;
        pos2 = line.find('\"', pos1) ;
        while (pos2 != NPOS)
        {
          sData = string(line, pos1, pos2-pos1) ;
          pos = sData.find('|') ;
          if (pos != NPOS)
          {
            sCodePat = string(sData, 0, pos) ;
            sCodeDoc = string(sData, pos+1, strlen(sData.c_str())-pos-1) ;
            dochisto.setPatient(sCodePat) ;
            dochisto.setDocument(sCodeDoc) ;
            VectDocResultat.push_back(new NSDocumentHisto(dochisto)) ;
          }
          pos1 = pos2+1 ;
          pos2 = line.find('\"', pos1) ;        }
      }
    	else if (sType == "vp2")
      {
        // vecteur des patients r�sultat
        NSRequestResult reqResult ;

        // on charge juste les nss pour l'instant
        // on a forc�ment un '$' en fin de chaine,
        // cela �vite un plantage �ventuel sur find
        pos1 = pos2+1 ;
        pos2 = line.find('\"', pos1) ;
        if (pos2 == NPOS)
        	continue ;
        reqResult.setRequestName(string(line, pos1, pos2-pos1)) ;

        pos1 = pos2+1 ;
        pos2 = line.find('\"', pos1) ;
        if (pos2 == NPOS)
        	continue ;
        reqResult.setRequestLabel(string(line, pos1, pos2-pos1)) ;

        pos1 = pos2+1 ;
        pos2 = line.find('\"', pos1) ;
        if (pos2 == NPOS)
        	continue ;
        sData = string(line, pos1, pos2-pos1) ;
        reqResult._nbPatResult = atoi(sData.c_str()) ;

        pos1 = pos2+1 ;
        pos2 = line.find('\"', pos1) ;
        if (pos2 == NPOS)        	continue ;
        sData = string(line, pos1, pos2-pos1) ;        reqResult._nbDocResult = atoi(sData.c_str()) ;

        while (pos2 != NPOS)
        {
          sData = string(line, pos1, pos2-pos1) ;
          NSPatInfo patinfo(pContexte) ;
          patinfo.setNss(sData) ;
          reqResult._aVectPatientResults.push_back(new NSPatInfo(patinfo)) ;          pos1 = pos2+1 ;
          pos2 = line.find('\"', pos1) ;
      	}

				VectRequestResults.push_back(new NSRequestResult(reqResult)) ;
      }
      else if (sType == "vd2")
      {
        // vecteur des documents r�sultat
        NSRequestResult* pReqResult = VectRequestResults.back() ;

        // on charge juste les codes pour l'instant
        // on a forc�ment un '$' en fin de chaine,
        // cela �vite un plantage �ventuel sur find
        pos1 = pos2+1 ;
        pos2 = line.find('\"', pos1) ;
        while (pos2 != NPOS)
        {
          sData = string(line, pos1, pos2-pos1) ;
          size_t pos = sData.find('|') ;
          if (pos != NPOS)
          {
            string sCodePat = string(sData, 0, pos) ;
            string sCodeDoc = string(sData, pos+1, strlen(sData.c_str())-pos-1) ;
            NSDocumentHisto dochisto(pContexte) ;
            dochisto.setPatient(sCodePat) ;
            dochisto.setDocument(sCodeDoc) ;
            pReqResult->_aVectDocumentResults.push_back(new NSDocumentHisto(dochisto)) ;
          }
          pos1 = pos2+1 ;
          pos2 = line.find('\"', pos1) ;        }
      }
    }
  } // fin du while

	inFile.close() ;
	return true ;
}

//// On charge les donn�es des patients dont les codes (nss)
// sont contenus dans VectPatResultat
//
bool
NSResultReqDialog::ChargerPatResultat()
{
	if (true == VectPatResultat.empty())
		return true ;

	char szInstance[3] ;
	int iInstance = pContexte->getSuperviseur()->getInstance() ;
	itoa(iInstance, szInstance, 10) ;

	SetCursor(0, IDC_WAIT) ;
	string user = pContexte->getUtilisateurID() ;

	for (PatientIter it = VectPatResultat.begin(); VectPatResultat.end() != it; it++)
	{
  	string sNss = (*it)->getNss() ;

		NSBasicAttributeArray    AttrArray ;
		NSPersonsAttributesArray List ;

		// ouverture standard
		AttrArray.push_back(new NSBasicAttribute(PERSON,   sNss)) ;
		AttrArray.push_back(new NSBasicAttribute(OPERATOR, user)) ;
		AttrArray.push_back(new NSBasicAttribute(CONSOLE,  string(pContexte->getSuperviseur()->getConsole()))) ;
		AttrArray.push_back(new NSBasicAttribute(INSTANCE, string(szInstance))) ;

		bool res = pContexte->pPilot->searchPatient(NautilusPilot::SERV_SEARCH_PATIENT.c_str(),
                                    (*it)->pGraphPerson->pDataGraph, &List, &AttrArray) ;

		if ((true == res) && (NULL != (*it)->pGraphPerson->pDataGraph) &&
    	  (NULL != (*it)->pGraphPerson->graphPrepare()))
		{
			(*it)->pGraphPerson->bNeedUnlock	= false ;
			(*it)->pGraphPerson->bReadOnly 	= true ;

			if (false == List.empty())
			{
				string sIsLocked = List.getAttributeValue("locked") ;
				if (sIsLocked == "ok")
					(*it)->pGraphPerson->bNeedUnlock = true ;
				string sOperationType	= List.getAttributeValue("operationType") ;
				if (sOperationType == "readWrite")
					(*it)->pGraphPerson->bReadOnly = false ;
			}

			(*it)->pGraphPerson->setInfoPids(&AttrArray) ;
			(*it)->pGraphPerson->pDataGraph->setLastTree() ;

			string sRootTree = (*it)->pGraphPerson->getRootTree() ;
			// NSDataGraph* pGraph = Patient.pGraphPerson->pDataGraph;

      if (false == VectDocResultat.empty())
      {
      	DocumentIter itDoc = VectDocResultat.begin() ;
				for (; VectDocResultat.end() != itDoc; itDoc++)
        {
        	if ((*itDoc)->getPatient() == sNss)
          {
            string sDocRosace ;
      			if ((*it)->pGraphPerson->getTree((*itDoc)->getID(), (*itDoc)->pPatPathoArray, &sDocRosace))
            	(*itDoc)->TrouveDateDoc() ;
          }
        }
      }
    }
  }
  SetCursor(0, IDC_ARROW) ;

  return true ;
}
boolNSResultReqDialog::ChargerDocResultat()
{
	return true ;
}

voidNSResultReqDialog::CmFermer()
{
	NSUtilDialog::CmOk() ;
}

voidNSResultReqDialog::CmMasquer()
{
	NSUtilDialog::CmCancel() ;
}

voidNSResultReqDialog::CmOuvrir()
{
	// on regarde d'abord si une requete est d�j� ouverte
	if (NULL != pReqDlg)
	{
		string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
		int idRet = MessageBox("Attention une requ�te est d�j� charg�e. Etes-vous certain de vouloir en ouvrir une autre ?", sCaption.c_str(), MB_YESNO);
		if (idRet == IDNO)
			return ;
	}

	// on delete �ventuellement l'ancienne requete en passant par l'utilisateur
	if (pContexte->getUtilisateur()->pRequete)
	{
		delete (pContexte->getUtilisateur()->pRequete) ;
    pContexte->getUtilisateur()->pRequete = 0 ;
	}

	pContexte->getUtilisateur()->pRequete = new NSRequeteDialog(pContexte->GetMainWindow(), pContexte) ;
	pReqDlg = pContexte->getUtilisateur()->pRequete ;

	char path[1024] ;
	// on choisi d'abord le r�pertoire par d�faut des requetes (NREQ)
	strcpy(path, (pContexte->PathName("NREQ")).c_str()) ;

	TFileOpenDialog::TData initData(OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
   											"Tous fichiers (*.NRS)|*.nrs|",
                                            0, path, "NRS");

	int iUserChoice = TFileOpenDialog(pContexte->GetMainWindow(), initData).Execute() ;

	pContexte->reallocateBaseDirectory() ;

	if (IDOK != iUserChoice)
	{
		if (NULL != pReqDlg)
		{
			delete pContexte->getUtilisateur()->pRequete ;
			pContexte->getUtilisateur()->pRequete = 0 ;
      pReqDlg = 0 ;
    }
    return ;
	}

	string sFileName = string(initData.FileName) ;
	SetCursor(0, IDC_WAIT) ;

	if (!pReqDlg->ChargerRequete(sFileName))
	{
		SetCursor(0, IDC_ARROW) ;
		erreur("Impossible de charger le fichier requete associ�.", standardError, 0, GetHandle()) ;
		return ;
	}

	if (!ChargerResultats(sFileName))
	{
		SetCursor(0, IDC_ARROW) ;
		erreur("Impossible de charger le fichier r�sultat sp�cifi�.", standardError, 0, GetHandle()) ;
    return ;
	}

	size_t pos = sFileName.find_last_of('\\') ;
	if (NPOS != pos)
		sFileName = string(sFileName, pos+1, strlen(sFileName.c_str())-pos-1) ;

	pReqDlg->sFileName = sFileName ;
	// pReqDlg->pNomReq->SetText(sFileName.c_str());

	if (!ChargerPatResultat())
	{
		erreur("Impossible de charger les patients r�sultat.", standardError, 0, GetHandle()) ;
	}

	if (!ChargerDocResultat())
	{
		erreur("Impossible de charger les documents r�sultat.", standardError, 0, GetHandle()) ;
	}

	sFileNameRes = sFileName ;
	pNomRes->SetText(sFileNameRes.c_str()) ;

	// on affiche les r�sultats
	AfficheCompteurs() ;
	AfficheListeRes() ;

	SetCursor(0, IDC_ARROW) ;
}

voidNSResultReqDialog::CmEnregistrer()
{
	if (NULL == pReqDlg)
	{
		erreur("Le fichier r�sultat est vide, ou n'est associ� � aucune requete.", standardError, 0, GetHandle()) ;
    return ;
	}

	string sFichierResult = "" ;
	ofstream outFile ;

	pReqDlg->EcrireRequete(sFichierResult) ;
	EcrireResultats(sFichierResult) ;

	NSNomGdDialog* pNomGdDlg =
        new NSNomGdDialog(this, pContexte->PathName("NREQ"), sFileNameRes, "nrs", pContexte);

	if (pNomGdDlg->Execute() != IDOK)
  {
  	delete pNomGdDlg ;
    return ;
  }

	// on peut enregistrer sous le nom de fichier propos�
  string sNomFichier = pNomGdDlg->sFichier ;

  outFile.open(sNomFichier.c_str());
  if (outFile)
  {
  	for (size_t i = 0; i < strlen(sFichierResult.c_str()); i++)
    	outFile.put(sFichierResult[i]) ;

    outFile.close() ;
  }
  else
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningOutputFile") + string("") + sNomFichier ;
    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
  	// erreur("Impossible d'enregistrer le fichier de resultats.", standardError, 0, GetHandle()) ;
    return ;
	}

	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
	MessageBox("Fichier de resultats enregistr�.", sCaption.c_str(), MB_OK) ;
	size_t pos = sNomFichier.find_last_of('\\');	if (pos != NPOS)
		sFileNameRes = string(sNomFichier, pos+1, strlen(sNomFichier.c_str())-pos-1) ;
	else
		sFileNameRes = sNomFichier ;

	pNomRes->SetText(sFileNameRes.c_str()) ;

	delete pNomGdDlg ;
}

void
NSResultReqDialog::CmExcelExport()
{
	NSNomGdDialog* pNomGdDlg =
        new NSNomGdDialog(this, pContexte->PathName("NREQ"), sFileNameRes, "xls", pContexte) ;

	if (pNomGdDlg->Execute() != IDOK)
  {
  	delete pNomGdDlg ;
    return ;
  }

	// on peut enregistrer sous le nom de fichier propos�
  string sNomFichier = pNomGdDlg->sFichier ;
  delete pNomGdDlg ;

  CMiniExcel miniExcel ;

  unsigned iCriteres = 0 ;

  // Header
	//
  miniExcel(iCriteres, 0) = "Utilisateur" ;
  if (pContexte->getUtilisateur())
  	miniExcel(iCriteres, 1) = pContexte->getUtilisateur()->donneSignature(pContexte).c_str() ;

  miniExcel(iCriteres, 2) = "Date" ;
  NVLdVTemps tNow ;
  tNow.takeTime() ;
  miniExcel(iCriteres, 2) = tNow.donneDateHeure().c_str() ;

  iCriteres++ ;

	// Research criteria
  //
	if (NULL != pReqDlg)
  {
  	if (pReqDlg->bCritPat)
		{
    	miniExcel(++iCriteres, 0) = "Crit�res patients" ;

      if ('\0' != pReqDlg->pCritPat->nom[0])
      {
      	miniExcel(++iCriteres, 1) = "Nom" ;
        miniExcel(iCriteres, 2) = pReqDlg->pCritPat->nom ;
      }
      if ('\0' != pReqDlg->pCritPat->prenom[0])
      {
      	miniExcel(++iCriteres, 1) = "Pr�nom" ;
        miniExcel(iCriteres, 2) = pReqDlg->pCritPat->prenom ;
      }
      if ('\0' != pReqDlg->pCritPat->sexe[0])
      {
      	miniExcel(++iCriteres, 1) = "Sexe" ;
        miniExcel(iCriteres, 2) = pReqDlg->pCritPat->sexe ;
      }
      if ('\0' != pReqDlg->pCritPat->dateN1[0])
      {
      	miniExcel(++iCriteres, 1) = "Date de naissance mini" ;
        miniExcel(iCriteres, 2) = pReqDlg->pCritPat->dateN1 ;
      }
      if ('\0' != pReqDlg->pCritPat->dateN2[0])
      {
      	miniExcel(++iCriteres, 1) = "Date de naissance maxi" ;
        miniExcel(iCriteres, 2) = pReqDlg->pCritPat->dateN2 ;
      }
      if ('\0' != pReqDlg->pCritPat->sitfam[0])
      {
      	miniExcel(++iCriteres, 1) = "Situation familiale" ;
        miniExcel(iCriteres, 2) = pReqDlg->pCritPat->sitfam ;
      }
      if ('\0' != pReqDlg->pCritPat->code_post[0])
      {
      	miniExcel(++iCriteres, 1) = "Code postal" ;
        miniExcel(iCriteres, 2) = pReqDlg->pCritPat->code_post ;
      }
      if ('\0' != pReqDlg->pCritPat->ville[0])
      {
      	miniExcel(++iCriteres, 1) = "Ville" ;
        miniExcel(iCriteres, 2) = pReqDlg->pCritPat->ville ;
      }
		}

		// on �crit les crit�res document
		if (pReqDlg->bCritDoc)
		{
    	miniExcel(++iCriteres, 0) = "Crit�res documents" ;
      if (string("") != pReqDlg->pCritDoc->sTitreAuteur)
      {
      	miniExcel(++iCriteres, 1) = "Auteur" ;
        miniExcel(iCriteres, 2) = pReqDlg->pCritDoc->sTitreAuteur.c_str() ;
      }
      if (string("") != pReqDlg->pCritDoc->sCodeRoot)
      {
      	miniExcel(++iCriteres, 1) = "Type" ;
        miniExcel(iCriteres, 2) = pReqDlg->pCritDoc->sCodeRoot.c_str() ;
      }
      if (string("") != pReqDlg->pCritDoc->sDate1)
      {
      	miniExcel(++iCriteres, 1) = "Date mini" ;
        miniExcel(iCriteres, 2) = pReqDlg->pCritDoc->sDate1.c_str() ;
      }
      if (string("") != pReqDlg->pCritDoc->sDate2)
      {
      	miniExcel(++iCriteres, 1) = "Date maxi" ;
        miniExcel(iCriteres, 2) = pReqDlg->pCritDoc->sDate2.c_str() ;
      }
		}
  }

  iCriteres++ ;

  unsigned iCounters = ++iCriteres ;

  miniExcel(iCounters, 1) = "Patients" ;

  miniExcel(iCounters+1, 0) = "Total" ;
	miniExcel(iCounters+1, 1) = nbPatTotal ;

	miniExcel(iCounters+2, 0) = "+ crit�res patient" ;
	miniExcel(iCounters+2, 1) = nbPatCritPat ;

  miniExcel(iCounters+3, 0) = "+ crit�res document" ;
	miniExcel(iCounters+3, 1) = nbPatCritDoc ;

  miniExcel(iCounters+4, 0) = "R�sultat" ;
	miniExcel(iCounters+4, 1) = nbPatResult ;

	if (bReqModeDoc)
  {
		miniExcel(iCounters, 2) = "Documents" ;
    miniExcel(iCounters+2, 2) = nbDocCritPat ;
    miniExcel(iCounters+3, 2) = nbDocCritDoc ;
    miniExcel(iCounters+4, 2) = nbDocResult ;
	}

	unsigned iCurrentRow = iCounters + 6 ;

  if (false == VectRequestResults.empty())
  {
  	NSRequestResultIter resIter = VectRequestResults.begin() ;
    for (; VectRequestResults.end() != resIter; resIter++)
    {
    	string sReqName = (*resIter)->getRequestName() ;
      miniExcel(iCurrentRow, 0) = sReqName.c_str() ;
      miniExcel(iCurrentRow, 1) = (*resIter)->_nbPatResult ;
      if (bReqModeDoc)
      	miniExcel(iCurrentRow, 2) = (*resIter)->_nbDocResult ;

      iCurrentRow++ ;
    }
  }

	FILE *f = fopen(sNomFichier.c_str(), "wb") ;
  miniExcel.Write(f) ;
}

void
NSResultReqDialog::CmImprimer()
{
	// On ne fait pas de delete du document
	// car NSVisualView le fait en fin d'impression
	pContexte->getUtilisateur()->pReqRefDoc = new NSReqRefDocument(this) ;
	pContexte->getUtilisateur()->pReqRefDoc->Publier(false) ;
}

void
NSResultReqDialog::RequestTabKeyDown(TTabKeyDown& nmHdr)
{
	int index = pRequests->GetSel() ;
  AfficheListeRes() ;
}

void
NSResultReqDialog::RequestTabSelChange(TNotify far& nm)
{
	int index = pRequests->GetSel() ;
  AfficheListeRes() ;
}

// ---------------------------------------------------------------------------DEFINE_RESPONSE_TABLE1(AboutDialog, TDialog)
	EV_COMMAND(IDOK,	CmOk),
END_RESPONSE_TABLE;

// -----------------------------------------------------------------
AboutDialog::AboutDialog(TWindow* pere, NSContexte* pCtx)
            :NSUtilDialog(pere, pCtx, "IDD_NS_ABOUT_MUE")
{
	pAppName = new TStatic(this, IDC_APPNAME);
}

void AboutDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	string sCaption = pContexte->getSuperviseur()->getAppName() + string(" : A propos de...");
  SetCaption(sCaption.c_str());

  char cText[255] = "";
  strcpy(cText, pContexte->getSuperviseur()->getAppName().c_str());
  strcat(cText, " ") ;
  strcat(cText, pContexte->getSuperviseur()->sNumVersion.c_str());

	pAppName->SetText(cText);
}

void AboutDialog::CmOk()
{
	TDialog::CmOk();
}

/****************************************************************************

	ancienne version// -----------------------------------------------------------------
//
//  M�thodes de NSTableauNoir
//

// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSTableauNoir, TControl)
	EV_WM_PAINT,
	EV_WM_ERASEBKGND,
	EV_WM_LBUTTONDOWN,
	EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

NSTableauNoir::NSTableauNoir(ChercheListePatDialog* parent,
									  const char far* title,
									  int             id,
									  int x, int y, int w, int h,
									  TModule*        module)
					:TControl(parent, id, title, x, y, w, h, module)
{
	pListeDlg = parent;
	Attr.Style = WS_CHILD | WS_VISIBLE;
	Attr.Style &= ~WS_TABSTOP;     // no input for us
}

// NSTableauNoir::NSTableauNoir(ChercheListePatDialog* parent, int resourceId, TModule* module)
//				  :TGroupBox(parent, resourceId, module)
// {
// 	pListeDlg = parent;
// }

//---------------------------------------------------------------------------
//  Function: ChercheListePatDialog::SetupWindow()
//
//  Arguments:	  Aucun
//
//  Description: Initialise la boite de dialogue
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSTableauNoir::SetupWindow()
{
	HWND         hCtrl;
	HDC          hDC;
	HFONT        hFont;
	LOGFONT 		 logfont;
	TEXTMETRIC	 textMetric;
	long			 iHauteur;

	TWindowAttr WAttr = pListeDlg->pGrpFond->Attr;
	Attr.X = WAttr.X+3;
	Attr.Y = WAttr.Y+3;
	Attr.W = WAttr.W-6;
	Attr.H = WAttr.H-6;
	//
	//
	// R�cup�ration des coordonn�es de l'Edit
	//
	GetClientRect(rectFond);
	iHauteur = rectFond.Height();
	//
	// Prise d'un DC
	//
	TDC* pDC;
	// hCtrl = pListeDlg->GetDlgItem(ID_LISTPA_LISTE);
	pDC = new TDC(GetDC(hCtrl));
	pDC->SetMapMode(MM_TEXT);
	//
	// Etablissement des caract�ristiques de la police
	//
	logfont.lfHeight 	    	  = -10;
	logfont.lfWidth  	    	  = 0;
	logfont.lfEscapement	     = 0;
	logfont.lfOrientation     = 0;
	logfont.lfWeight          = FW_NORMAL;
	logfont.lfItalic          = 0;
	logfont.lfUnderline       = 0;
	logfont.lfStrikeOut       = 0;
	logfont.lfCharSet         = ANSI_CHARSET;
	logfont.lfOutPrecision    = OUT_TT_PRECIS;
	logfont.lfClipPrecision   = CLIP_DEFAULT_PRECIS;
	logfont.lfQuality         = PROOF_QUALITY;
	logfont.lfPitchAndFamily  = VARIABLE_PITCH | FF_ROMAN;
	strcpy(logfont.lfFaceName, "");
	//
	// Mise en place de la police
	//
	pDC->SelectObject(TFont(&logfont));
	//
	// Prise des caract�ristiques de la police EN UNITES LOGIQUES
	//
	pDC->GetTextMetrics(textMetric);
	//
	// Calcul de la hauteur de ligne du texte � afficher
	//
	HauteurLigne = textMetric.tmHeight + textMetric.tmExternalLeading;
	//
	// Calcul du nombre de lignes affichables
	//
	if (HauteurLigne > 0)
   	nbNom = int(long(iHauteur) / HauteurLigne);

	delete pDC;
	iActif = 0;
}

void
NSTableauNoir::EvPaint()
{
	//TGroupBox::EvPaint();
	TPaintDC  dc(*this);
	Paint(dc, dc.Ps.fErase, TRect(dc.Ps.rcPaint));
//	HWND        hCtrl;
//	PAINTSTRUCT ps;
//	hCtrl = pListeDlg->GetDlgItem(ID_LISTPA_LISTE);
//	BeginPaint(hCtrl, &ps);
//	Paint(TDC(ps.hdc), ps.fErase, TRect(ps.rcPaint));
//	EndPaint(hCtrl, &ps);
}

//---------------------------------------------------------------------------
//  Function: 	  NSTableauNoir::EvLButtonDown(UINT modKeys, TPoint& point)
//
//  Arguments:	  point -> Lieu du click souris
//
//  Description: S�lectionne une ligne comme ligne en cours
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSTableauNoir::EvLButtonDown(UINT modKeys, TPoint& point)
{
	int iLigne = point.y / HauteurLigne;
	if (iLigne < nbNom)
	{
		iActif = iLigne;
		Invalidate(true);
	}
}

//---------------------------------------------------------------------------
//  Function: 	  NSTableauNoir::EvLButtonDblClk(UINT modKeys, TPoint& point)
//
//  Arguments:	  point -> Lieu du double click souris
//
//  Description: S�lectionne une ligne comme ligne en cours
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSTableauNoir::EvLButtonDblClk(UINT modKeys, TPoint& point)
{
	int iLigne = point.y / HauteurLigne;
	if (iLigne < nbNom)
		iActif = iLigne;
	pListeDlg->CmOk();
}

void
NSTableauNoir::Paint(TDC& dc, bool erase, TRect& rect)
{
	int  		  iPosition;
	char 		  dateNaiss[15];
	TEXTMETRIC textMetric;

	NSPatientArray*  pPatArray = pListeDlg->pPatientsArray;

	dc.SetMapMode(MM_TEXT);
	dc.GetTextMetrics(textMetric);
	//
	// Calcul de la hauteur de ligne du texte � afficher
	//
	HauteurLigne = textMetric.tmHeight + textMetric.tmExternalLeading;
	//
	// Calcul du nombre de lignes affichables
	//
	int iHauteur = rectFond.Height() - 6;
	if (HauteurLigne > 0)
   	nbNom = int(long(iHauteur) / HauteurLigne);

	TColor CouleurFond;
	dc.SetBkColor(CouleurFond.LtGray);
	dc.SetTextColor(CouleurFond.Black);
	dc.SelectObject(TBrush(CouleurFond.LtGray));
	dc.FillRect(rectFond.left+3, rectFond.top+3, rectFond.left+rectFond.Width()-6, rectFond.top+iHauteur, TBrush(CouleurFond.LtGray));

	for (int i = 0; i < nbNom; i++)
	{
		if (i == iActif)
		{
			dc.SetBkColor(CouleurFond.Gray);
			dc.SetTextColor(CouleurFond.White);
		}
      iPosition = rectFond.top + (i * int(HauteurLigne));

		dc.TextOut(rectFond.left+3, iPosition+1, ((*pPatArray)[i])->pDonnees->nom_long);
		donne_date(((*pPatArray)[i])->pDonnees->naissance, dateNaiss, sLang);
		dc.TextOut(rectFond.left+170, iPosition+1, dateNaiss);
		if (i == iActif)
		{
			dc.SetBkColor(CouleurFond.LtGray);
			dc.SetTextColor(CouleurFond.Black);
		}
	}
	pListeDlg->pGrpSepare->Invalidate(true);
}

//
// We'll always erase as we paint to avoid flicker
//
bool
NSTableauNoir::EvEraseBkgnd(HDC)
{
  return true;
}

void
NSTableauNoir::DrawItem(DRAWITEMSTRUCT far &drawInfo)
{
	Paint(drawInfo.hDC, true, TRect(drawInfo.rcItem));
}

//--------------------------------------------------------------------------
// Impl�mentation de l'enregistrement d'une classe
//--------------------------------------------------------------------------

//---------------------------------------------------------------------------
//  Function: bool NSBitmapRegister()
//
//  Arguments:
//          AUCUN
//  Description:
//            V�rifie si la classe NSBitmap n'est pas d�j� enregistr�e.
//            Si elle ne l'est pas l'enregistre. ???
//  Returns:
//          true   si la classe n'�tait pas enregistr�e
//          false  sinon
//---------------------------------------------------------------------------
bool NSTableauNoirRegister()
{
	WNDCLASS  windowClass;
	BOOL gc;   // NE PAS CHANGER CE GRAND BOOL !!!!!!!!!!
	static char className[] = "NSTableauNoir";
	// Only check for globally registered classes if not in an NT WoW box,
	// since WoW plays nasty games with class registration.
#if defined(__WIN32__)
	gc = ::GetClassInfo(NULL, "NSTableauNoir", &windowClass);
#else
	static bool isWoW = bool(::GetWinFlags()&0x4000);
	if (!isWoW)
	 	gc = ::GetClassInfo(NULL,"NSTableauNoir", &windowClass);
  	else
	 	gc = 0;
#endif
  	//if (!gc && !::GetClassInfo(0, "NSTableauNoir", &windowClass)) {
  if ( gc == 0)
  	{
	 	memset(&windowClass, 0, sizeof windowClass);
	 	windowClass.cbClsExtra 	  = 0;
	 	windowClass.cbWndExtra 	  = 0;
	 	windowClass.hInstance 	  = *::Module;
	 	windowClass.hIcon 		  = 0;
	 	windowClass.hCursor 		  = ::LoadCursor(0, IDC_CROSS);
	 	windowClass.hbrBackground = HBRUSH(COLOR_WINDOW + 1);
	 	windowClass.lpszMenuName  = 0;
	 	windowClass.lpszClassName = className;
	 	windowClass.style 		  = CS_HREDRAW|CS_VREDRAW;
	 	windowClass.lpfnWndProc   =::DefWindowProc;  //InitWndProc;
	 	return ::RegisterClass(&windowClass);
  	}
  	return true;
}
*****************************************************************************/

/////////////////////////// fin de nsrechdl.cpp /////////////////////////////////

