// -----------------------------------------------------------------------------
// nschoisi.cpp
// -----------------------------------------------------------------------------
// $Revision: 1.321 $
// $Author: remi $
// $Date: 2005/07/12 15:46:32 $
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Copyright Nautilus, 2001-2005
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � [rappeler les
// caract�ristiques techniques de votre logiciel].
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to [describe
// functionalities and technical features of your software].
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------

#include <mem.h>
#include <owl\olemdifr.h>

#include <owl\opensave.h>

#include "nautilus\nssuper.h"
#include "nautilus\nsrechdl.h"
#include "nautilus\nsrechd2.h"
#include "partage\nsdivfct.h"
#include "nautilus\nsadmiwd.h"
#include "nsbb\nsbb.h"
#include "nsdn\nsintrad.h"
#include "nautilus\nsttx.h"
#include "nautilus\nsacroread.h"
#include "nautilus\nscrvue.h"
#include "nautilus\nscsdoc.h"
#include "nautilus\nscsvue.h"
#include "nautilus\nshistor.h"
#include "nautilus\nsresour.h"  // pour le dialogue de la fiche admin
#include "nssavoir\nstransa.h"
#include "nautilus\nscompub.h"

#include "nssavoir\nsbloque.h"
#include "nautilus\nspatdlg.h"
#include "nautilus\nsmodhtm.h"
#include "nautilus\nsbrowse.h"
#include "nautilus\nsGrabObjects.h"
#include "nautilus\nsdocaga.h"	// pour les documents de compta et pDocRefHisto
#include "nautilus\nschoisi.h"
#include "nautilus\nsepicap.h"
#include "nautilus\nsdocview.h"
#include "nautilus\nsldvvue.h"
#include "nautilus\nsdrugview.h"
#include "nautilus\nsprocessview.h"
#include "nautilus\nsFollowUpView.h"
#include "nautilus\nsgoalview.h"
#include "nautilus\nsrcview.h"
#include "nautilus\nscqdoc.h"
#include "nautilus\nsMailSvce.h"
#include "ns_grab\nsgrabfc.h"
#include "nsbb\nsarc.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbbtran.h"
//#include "nsoutil\nssmedit.h"
#include "nsoutil\nsarcedit.h"
#include "nsepisod\nsldvuti.h"
#include "nssavoir\nsgraphe.h"
#include "dcodeur\decoder.h"
#include "nsbb\nsdefArch.h"
#include "nautilus\nsTeamDocView.h"
#include "nautilus\nsVisual.h"

# include "ns_ob1\nautilus-bbk.h"

#include "nsbb\nsmpids.h"
#include "nsbb\nsmanager.h"
#include "nsbb\logpass.h"

# include "pilot\NautilusPilot.hpp"

# include "nsbb\tagNames.h"
# include "nsbb\nsattvaltools.h"

//***************************************************************************
// Impl�mentation des m�thodes NSPatientChoisi
//***************************************************************************

//---------------------------------------------------------------------------
//  Function :  	NSPatientChoisi::~NSPatientChoisi()
//
//  Arguments :
//
//  Description :	Destructeur
//
//  Returns :		Rien
//---------------------------------------------------------------------------
NSPatientChoisi::~NSPatientChoisi()
{
	if (getADebloquer())
		debloquer();

  // Fermeture des objets de la Ligne de vie
#ifndef __EPIPUMP__
#ifndef __EPIBRAIN__

  // Should be done in ~NSPatInfo() but not possible yet due to linking dependencies
  //
  if (NULL != pDocHis)
    delete pDocHis ;

	if (pDocLdv)
	{
/*
		NSLdvTemplate* pLdvTempl = TYPESAFE_DOWNCAST(pDocLdv->GetTemplate(), NSLdvTemplate) ;
    if (pLdvTempl)
    	delete pLdvTempl ;
*/
		delete pDocLdv ;
	}

  if (NULL != pHealthDoc)
    delete pHealthDoc ;

	if (pSynthese)
		delete pSynthese ;

#endif // !__EPIBRAIN__
#endif // !__EPIPUMP__
}

//---------------------------------------------------------------------------
//  Function :  	NSPatientChoisi::ChercheChemise()
//
//  Arguments :
//
//  Description :	Choix des documents � visualiser
//
//  Returns :		Rien
//---------------------------------------------------------------------------

void NSPatientChoisi::CmChemise()
{
try
{
	ChoixChemiseDialog* ChoixChemiseDl = new ChoixChemiseDialog(pContexte->GetMainWindow(), pContexte);
	ChoixChemiseDl->Execute();
	delete ChoixChemiseDl;
}
catch (...)
{
	erreur("Exception NSPatientChoisi::CmChemise.", standardError, 0) ;
}
}

/**
* New text
*/
void NSPatientChoisi::CmNewTTxt()
{
try
{
#ifndef __EPIPUMP__

	if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	NSTtxDocument* pNewDocTtx = new NSTtxDocument(0, pContexte) ;
	NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pNewDocTtx, "Rtf Format") ;

#endif // !__EPIPUMP__
}
catch (...)
{
  erreur("Exception NSPatientChoisi::CmNewTTxt.", standardError, 0) ;
}
}

/**
*	Cr�e un document de type Word
* Create a Word document
*/
void NSPatientChoisi::CmNewTmpl()
{
try
{
#ifndef __EPIPUMP__

	if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	NSTtxDocument*   pNewDocTtx = new NSTtxDocument(0, pContexte) ;
  NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pNewDocTtx, "Word Format") ;

#endif // !__EPIPUMP__
}
catch (...)
{
	erreur("Exception NSPatientChoisi::CmNewTmpl().", standardError, 0) ;
}
}

void NSPatientChoisi::CmOpenTTxt()
{
try
{
#ifndef __EPIPUMP__

	if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	// on installe ici le point d'entr�e de la routine d'importation (temporaire)

	char 	 path[1024];
	string sFileName;

	// on choisi d'abord le r�pertoire par d�faut d'importation (IHTM)
	strcpy(path, (pContexte->PathName("NLTR")).c_str()) ;

	TFileOpenDialog::TData initData(OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
																	"Fichiers texte (*.rtf)|*.rtf;|",
																	0,
																	path,
																	"*.rtf");

	int iUserChoice = TFileOpenDialog(pContexte->GetMainWindow(), initData).Execute() ;

	pContexte->reallocateBaseDirectory() ;

	if (IDOK != iUserChoice)
		return ;

	sFileName = string(initData.FileName);

	NSTtxDocument* pNewDocTtx = new NSTtxDocument(0, pContexte) ;
	pNewDocTtx->SetFichierExterne(sFileName) ;
	NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pNewDocTtx, "Rtf Format") ;

#endif // !__EPIPUMP__
}
catch (...)
{
  erreur("Exception NSPatientChoisi::CmOpenTTxt.", standardError, 0) ;
}
}

void NSPatientChoisi::CmOpenPdf()
{
try
{
#ifndef __EPIPUMP__

	if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	// on installe ici le point d'entr�e de la routine d'importation (temporaire)
	char 	 path[1024] ;
	// on choisi d'abord le r�pertoire par d�faut d'importation (NLTR)
	strcpy(path, (pContexte->PathName("NLTR")).c_str()) ;

	TFileOpenDialog::TData initData(OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
																	"Adobe acrobat (*.pdf)|*.pdf;|",
																	0,
																	path,
																	"*.pdf") ;

	int iResult = TFileOpenDialog(pContexte->GetMainWindow(), initData).Execute() ;

	pContexte->reallocateBaseDirectory() ;

	if (iResult != IDOK)
		return ;

	string sFileName = string(initData.FileName) ;

	NSAcrobatDocument* pNewDocPdf = new NSAcrobatDocument(0, pContexte) ;
	pNewDocPdf->SetFichierExterne(sFileName) ;
	NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pNewDocPdf, "Pdf Format") ;

#endif // !__EPIPUMP__
}
catch (...)
{
  erreur("Exception NSPatientChoisi::CmOpenPdf.", standardError, 0) ;
}
}

void NSPatientChoisi::CmOpenHtml()
{
try
{
#ifndef __EPIPUMP__

	if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	// on installe ici le point d'entr�e de la routine d'importation (temporaire)
	char 	 path[1024] ;
	// on choisi d'abord le r�pertoire par d�faut d'importation (NLTR)
	strcpy(path, (pContexte->PathName("NLTR")).c_str()) ;

	TFileOpenDialog::TData initData(OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
																	"HTML (*.htm)|*.htm;|",
																	0,
																	path,
																	"*.htm") ;

	int iResult = TFileOpenDialog(pContexte->GetMainWindow(), initData).Execute() ;

	pContexte->reallocateBaseDirectory() ;

	if (iResult != IDOK)
		return ;

	string sFileName = string(initData.FileName) ;

	NSHtmlModelDocument* pNewDocHtml = new NSHtmlModelDocument(0, pContexte) ;
  pNewDocHtml->SetModelFile(sFileName) ;
	NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pNewDocHtml, "Html Format") ;

#endif // !__EPIPUMP__
}
catch (...)
{
  erreur("Exception NSPatientChoisi::CmOpenHtml.", standardError, 0) ;
}
}

void NSPatientChoisi::CmOpenTmpl()
{
try
{
#ifndef __EPIPUMP__

	if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	// on installe ici le point d'entr�e de la routine d'importation (temporaire)
	char path[1024] ;
	// on choisi d'abord le r�pertoire par d�faut d'importation (IHTM)
	strcpy(path,(pContexte->PathName("NLTR")).c_str()) ;

	TFileOpenDialog::TData initData(OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
																	"Fichiers Word (*.doc)|*.doc|",
																	0,
																	path,
																	"*.doc") ;

	int iUserChoice = TFileOpenDialog(pContexte->GetMainWindow(), initData).Execute() ;

  pContexte->reallocateBaseDirectory() ;

	if (IDOK != iUserChoice)
		return ;

	string sFileName = string(initData.FileName) ;

	NSTtxDocument* pNewDocTtx = new NSTtxDocument(0, pContexte) ;
  pNewDocTtx->SetFichierExterne(sFileName) ;
  NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pNewDocTtx, "Word Format") ;

#endif // !__EPIPUMP__
}
catch (...)
{
  erreur("Exception NSPatientChoisi::CmOpenTmpl.", standardError, 0) ;
}
}

void
NSPatientChoisi::CmAssistCapture()
{
#ifndef __EPIPUMP__
try
{
	string sRes ;
	bool bOk = lireParam(pContexte->getUtilisateur()->getNss(), "matrox.dat", "Assist", sRes) ;
	if (bOk)
	{
		if (sRes == string("oui"))
		{
			AssistCaptureDialog* pAssist = new AssistCaptureDialog(pContexte->GetMainWindow(), pContexte) ;
			pAssist->Create() ;
			// delete pAssist;
		}
    else if (sRes == string("bmp"))
    {
    	string sFileName = string("Image51.bmp") ;

      pContexte->getSuperviseur()->initGrabModule("ns_grab.dll") ;

      if (!pContexte->getSuperviseur()->getGrabModule())
      {
        erreur("Impossible d'ouvrir la DLL ns_grab.dll.", standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
        pContexte->getSuperviseur()->afficheStatusMessage("") ;
        return ;
      }

      // Initialisation du contexte Matrox
      bool (FAR *pAdrConvert) (string far *, NSContexte far *) ;
      // R�cup�ration du pointeur sur la fonction ConvertBmpToJpg
      (FARPROC) pAdrConvert = pContexte->getSuperviseur()->getGrabModule()->GetProcAddress(MAKEINTRESOURCE(M_CONVERTBMP)) ;

      if (pAdrConvert == NULL)
      {
        erreur("Impossible de r�cup�rer la fonction ConvertBmpToJpg()", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
        TModule* pGrabMod = pContexte->getSuperviseur()->getGrabModule() ;
        delete pGrabMod ;
        pContexte->getSuperviseur()->setGrabModule(0) ;
        return ;
      }

      bool bOk = ((*pAdrConvert)((string far *)(&sFileName), (NSContexte far *)pContexte)) ;
      if (!bOk)
      {
        erreur("Erreur � la conversion d'une image bmp.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
        TModule* pGrabMod = pContexte->getSuperviseur()->getGrabModule() ;
        delete pGrabMod ;
        pContexte->getSuperviseur()->setGrabModule(0) ;
        return ;
      }

      ::MessageBox(0, "Conversion termin�e...", "Message Nautilus", MB_OK) ;
    }
		else
		{
			CmCapture() ;
		}
	}
}
catch (...)
{
	erreur("Exception NSPatientChoisi::CmAssistCapture.", standardError, 0) ;
}
#endif // #ifndef __EPIPUMP__
}

void
NSPatientChoisi::CmTwainCapture()
{
#ifndef __EPIPUMP__
try
{
	NSTwainWindow*    pTwainWindow = new NSTwainWindow(pContexte->GetMainWindow(), pContexte) ;
	NSTwainGrabChild* pTwainChild  = new NSTwainGrabChild(pContexte, *(pContexte->getSuperviseur()->getApplication()->prendClient()), "Scan", pTwainWindow) ;
	pTwainChild->Create() ;
}
catch (...)
{
	erreur("Exception NSPatientChoisi::CmTwainCapture.", standardError, 0) ;
}
#endif // #ifndef __EPIPUMP__
}

void
NSPatientChoisi::CmCapture(AssistCaptureDialog* pAssist)
{
#ifndef __EPIPUMP__
try
{
	// on regarde si la capture est d�j� lanc�e
	if (pContexte->getSuperviseur()->getMatrox())
	{
		erreur("La capture d'images est en cours...", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		pContexte->getSuperviseur()->afficheStatusMessage("") ;
    return ;
	}

	char title[255] ;
	// Pour emp�cher la TMDIChild de red�finir le titre de la MainWindow
	pContexte->GetMainWindow()->GetWindowText(title, 254) ;

	TModule* pGrabMod = pContexte->getSuperviseur()->getGrabModule() ;

	if (pGrabMod)
		delete pGrabMod ;

	// Initialisation du module de la dll de capture
	pGrabMod = new TModule("ns_grab.dll", TRUE);

	if (!pGrabMod)
	{
  	erreur("Impossible d'ouvrir la DLL ns_grab.dll.", standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
    pContexte->getSuperviseur()->afficheStatusMessage("") ;
    pContexte->getSuperviseur()->setGrabModule(NULL) ;
    return ;
	}
	pContexte->getSuperviseur()->setGrabModule(pGrabMod) ;

	// Initialisation du contexte Matrox
	bool (FAR *pAdrGrabInit) (NSMatrox far **, NSContexte far *) ;
	// R�cup�ration du pointeur sur la fonction GrabInit
	(FARPROC) pAdrGrabInit = pContexte->getSuperviseur()->getGrabModule()->GetProcAddress(MAKEINTRESOURCE(M_GRABINIT)) ;

	if (pAdrGrabInit == NULL)
	{
		erreur("Impossible de r�cup�rer la fonction GrabInit()", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		delete pGrabMod ;
    pContexte->getSuperviseur()->setGrabModule(NULL) ;
    return ;
	}

	NSMatrox* pMatroxPtr = NULL ;
	bool bOk = ((*pAdrGrabInit)((NSMatrox far **) &pMatroxPtr, (NSContexte far *) pContexte)) ;
	if (!bOk)
	{
		erreur("Erreur � l'initialisation du contexte Matrox", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		delete pGrabMod ;
		pContexte->getSuperviseur()->setGrabModule(NULL) ;
    pContexte->getSuperviseur()->initMatrox(NULL) ;
    return ;
	}
	pContexte->getSuperviseur()->initMatrox(pMatroxPtr) ;

	// on cr�e maintenant la fenetre de capture, qui r�cup�re le contexte
	NSMilGrabWindow* pGrabWindow = new NSMilGrabWindow(pContexte->GetMainWindow(), pContexte, pAssist) ;
	NSMilGrabChild*  pGrabChild  = new NSMilGrabChild(pContexte, *(pContexte->getSuperviseur()->getApplication()->prendClient()), "Capture", pGrabWindow) ;
	pContexte->GetMainWindow()->SetCaption(title);

	// nsMenuIniter menuIter(pContexte) ;
	// OWL::TMenuDescr menuBar ;
	// menuIter.initMenuDescr(&menuBar, "menubar") ;
	// TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;
	// pMyApp->GetMainWindow()->SetMenuDescr(menuBar) ;
	// pMyApp->setMenu(string("menubar")) ;
	pGrabChild->Create() ;
}
catch (...)
{
	erreur("Exception NSPatientChoisi::CmCapture.", standardError, 0) ;
}
#endif // #ifndef __EPIPUMP__
}

/**
* Importation
*/
void NSPatientChoisi::CmImporter()
{
try
{
#ifndef __EPIPUMP__
	if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	// on installe ici le point d'entr�e de la routine d'importation (temporaire)
	char path[1024] ;
	// on choisi d'abord le r�pertoire par d�faut d'importation (IHTM)
	strcpy(path,(pContexte->PathName("IHTM")).c_str()) ;

	TFileOpenDialog::TData initData(OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
																	"Tous fichiers (*.*)|*.*|",
																	0,
																	path,
																	"*") ;

	int iUserChoice = TFileOpenDialog(pContexte->GetMainWindow(), initData).Execute() ;

	pContexte->reallocateBaseDirectory() ;

	if (IDOK != iUserChoice)
		return ;

	string sFileName = string(initData.FileName) ;

	// Recherche pr�alable de l'extension pour
	// traiter le cas des documents Word
	string sExtension = "" ;

	// R�cup�ration du path
	size_t pos1 = sFileName.find_last_of("\\") ;

	if (pos1 == NPOS)
	{
		/* on doit normalement r�cup�rer au moins C:\
		// => on g�n�re une erreur s'il n'y a pas de '\\'  */
		erreur("Aucun PathName ne peut etre associ� � ce fichier.", standardError, 0) ;
		return ;
	}

	// sPathName = string(sFileName, 0, pos1+1);
	// R�cup�ration de l'extension
	size_t pos2 = sFileName.find(".") ;

	if (pos2 == NPOS)
	{
		//
		// On v�rifie d'abord si ce n'est pas un fichier texte de l'ancien
		// Nautilus : gastroda
		//
		string sNomSeul = string(sFileName, pos1+1, strlen(sFileName.c_str())-pos1-1) ;
		//sNomSeul = pseumaj(sNomSeul.c_str());
		if (sNomSeul == "GASTRODA")
		{
			// cas de l'ancien Nautilus (trait� plus tard dans l'importation)
			// pour le moment, on se contente de mettre l'extension � vide
			sExtension = "" ;
		}
		else
		{
			erreur("Ce fichier n'a pas d'extension.", standardError, 0) ;
			return ;
		}
	}
	else
	{
		char szExt[10] ;

		sExtension = string(sFileName, pos2+1, strlen(sFileName.c_str())-pos2-1) ;
		strcpy(szExt, sExtension.c_str()) ;
		pseumaj(szExt) ;
		sExtension = string(szExt) ;
	}

	if ((string("DOC") == sExtension) || (string("DOCX") == sExtension)) // cas des documents Word
	{
		::MessageBox(0, "Votre document est de type Word. Pour ce type de fichier, Nautilus va ouvrir votre document dans une session Word. Pour l'importer, vous devez alors revenir sur la session Nautilus (par la barre des t�ches) et cliquer sur <Archiver> dans la fen�tre <Document Word> de Nautilus.", "Message Nautilus", MB_OK);

		// on ouvre ici le document Word en automation OLE
		// cf code identique � la fonction CmOpenTpml()

    NSTtxDocument* pNewDocTtx = new NSTtxDocument(0, pContexte) ;
    pNewDocTtx->SetFichierExterne(sFileName) ;
		NSDocViewManager dvManager(pContexte) ;
		dvManager.createView(pNewDocTtx, "Word Format") ;
	}
	else
		Importer(sFileName) ;

#endif // !__EPIPUMP__
}
catch (...)
{
  erreur("Exception NSPatientChoisi::CmImporter.", standardError, 0) ;
}
}

void
NSPatientChoisi::CmGenericReferentiel(string sRefId, string sDocument, string sConcern)
{
try
{
#ifndef __EPIPUMP__
  ValIter ival, ivalp ;

  if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

  NSSuper* pSuper = pContexte->getSuperviseur() ;

  string ps = string("Entering CmGenericReferentiel, ID=") + sRefId ;
  pSuper->trace(&ps, 1) ;

  string sRefFile = pSuper->getArcManager()->DonneFichierArchetypeParNom(NSArcManager::referentiel, sRefId) ;
  if (string("") == sRefFile)
    return ;

  ps = string("Parsing file ") + sRefFile ;
  pSuper->trace(&ps, 1) ;

  nsrefParseur Parseur(pContexte) ;
  if (!(Parseur.open(sRefFile)))
    return ;

  if ((!(Parseur.pReferentiel)) || (!(Parseur.pReferentiel->getValArray())))
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("referentialManagement", "invalidReferential") + string(" ") + sRefId ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return ;
  }

  Valeur_array* pRefArray = Parseur.pReferentiel->getValArray() ;
  if (pRefArray->empty())
  {
    string sErrorText = pContexte->getSuperviseur()->getText("referentialManagement", "emptyReferential") + string(" ") + sRefId ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return ;
  }

  bool	bSimple = true ;
  nsrefDialog* pDial = new nsrefDialog(pContexte->GetMainWindow(), pContexte, &Parseur, bSimple) ;
  int idRet = pDial->Execute() ;
  delete pDial ;

  ps = string("R�ferentiel, lancement dialogue") ;
  pSuper->trace(&ps, 1);

  while ((IDOK != idRet) && (IDCANCEL != idRet))
  {
/*
    if (bSimple == true)
      bSimple = false ;
    else
      bSimple = true ;
*/

    if      (IDC_OTHER == idRet)
      bSimple = false ;
    else if (IDC_BBK_EVENT == idRet)
    {
      if (NULL != Parseur.pReferentiel)
      {
        Cglobalvars *pGVars = Parseur.pReferentiel->getGVars() ;
        if (NULL != pGVars)
          pGVars->resetProcessState() ;
      }
    }

    pDial = new nsrefDialog(pContexte->GetMainWindow(), pContexte, &Parseur, bSimple) ;
    idRet = pDial->Execute() ;
    delete pDial ;
  }
  if (idRet != IDOK)
    return ;

	bool bDrugsAdded = false ;
	bool bGoalsAdded = false ;

	// Browsing all the proposals
  // on parcourt l'ensemble des propositions
  //
  for (ival = pRefArray->begin(); ival != pRefArray->end(); ival++)
  {    if ((*ival)->sLabel == LABEL_PROPOSITION)    {      // si la proposition a �t� retenue (check == true)      Cproposition* pCprop = dynamic_cast<Cproposition*>((*ival)->pObject) ;
      if (pCprop->getCheck())
      {
        //
        string sPropName = pCprop->getStringAttribute(ATTRIBUT_CONTR_NOM) ;
        if (sPropName != "")
        {
          ps = string("R�ferentiel, traitement proposition ") + sPropName ;
          pSuper->trace(&ps, 1) ;
        }
        else
        {
          ps = string("R�ferentiel, proposition sans nom") ;
          pSuper->trace(&ps, 1) ;
        }

        ps = string("R�ferentiel, proposition, cr�ation d'objectifs") ;
        pSuper->trace(&ps, 1) ;

        // Browsing every proposal's trees
        //
        for (ivalp = pCprop->getValArray()->begin() ; ivalp != pCprop->getValArray()->end() ; ivalp++)
        {
          if ((*ivalp)->sLabel == LABEL_TREE)
          {
            // Creating the tree - On cr�e l'arbre
            //
            Ctree* pCtree = dynamic_cast<Ctree *>((*ivalp)->pObject) ;
            string sDestinationPath = pCtree->getLocalisation() ;

            if      (string("ZPOMR/N0000") == sDestinationPath)
            	bDrugsAdded = true ;
            else if (string("ZPOMR/0OBJE") == sDestinationPath)
            	bGoalsAdded = true ;

            ps = string("R�ferentiel, proposition, cr�ation d'un objet") ;
            pSuper->trace(&ps, 1) ;
            if (!CreeElementFromRef(sDestinationPath, pCtree->pPatPathoArray, sDocument, sRefId, pCprop->getLocalPropIDFromPropID(), pCprop->pReasonTree, sConcern))
            	// cas d'erreur : on interrompt le processus
              return ;
          }
        }
      }
    }
  }

	if (NULL != pDocLdv)
	{
		if (true == bDrugsAdded)
    {
    	ArrayLdvDrugs* pDrugs = pDocLdv->getDrugs() ;
      if (NULL != pDrugs)
      	pDrugs->reinit() ;
    }
    if (true == bGoalsAdded)
    	pDocLdv->reinitAllGoals() ;

  	pDocLdv->invalidateViews(string("MISCELLANOUS")) ;
	}

  ps = string("Leaving CmGenericReferentiel") ;
  pSuper->trace(&ps, 1) ;

#endif // !__EPIPUMP__
}
catch (...)
{
  erreur("Exception NSPatientChoisi::CmGenericReferentiel.", standardError, 0) ;
}
}

void
NSPatientChoisi::CmReferentiel(string sRefId, string sDocument)
{
try
{
#ifndef __EPIPUMP__
  ValIter ival, ivalp ;

  if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

  NSSuper* pSuper = pContexte->getSuperviseur() ;

  string ps = string("D�but r�ferentiel, ID=") + sRefId ;
  pSuper->trace(&ps, 1) ;

  string sRefFile = pSuper->getArcManager()->DonneFichierArchetypeParNom(NSArcManager::referentiel, sRefId) ;
  if (sRefFile == "")
    return ;

  ps = string("R�ferentiel, parsing du fichier ") + sRefFile ;
  pSuper->trace(&ps, 1) ;

  nsrefParseur Parseur(pContexte) ;
  if (!(Parseur.open(sRefFile)))
    return ;

  if ((!(Parseur.pReferentiel)) || (!(Parseur.pReferentiel->getValArray())))
  {
    string sError = string("Le r�ferentiel ") + sRefId + string(" est incorrect.") ;
    pContexte->getSuperviseur()->trace(&sError, 1, NSSuper::trError) ;
    erreur(sError.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return ;
  }

  Valeur_array* pRefArray = Parseur.pReferentiel->getValArray() ;
  if (pRefArray->empty())
  {
    string sError = string("Le r�ferentiel ") + sRefId + string(" est vide.") ;
    pContexte->getSuperviseur()->trace(&sError, 1, NSSuper::trError) ;
    erreur(sError.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return ;
  }

  bool	bSimple = true ;
  nsrefDialog* pDial = new nsrefDialog(pContexte->GetMainWindow(), pContexte, &Parseur, bSimple) ;
  int idRet = pDial->Execute() ;
  delete pDial ;

  ps = string("R�ferentiel, lancement dialogue") ;
  pSuper->trace(&ps, 1);

  while ((idRet != IDOK) && (idRet != IDCANCEL))
  {
/*
    if (bSimple == true)
      bSimple = false ;
    else
      bSimple = true ;
*/

    if      (IDC_OTHER == idRet)
      bSimple = false ;
    else if (IDC_BBK_EVENT == idRet)
    {
      if (NULL != Parseur.pReferentiel)
      {
        Cglobalvars *pGVars = Parseur.pReferentiel->getGVars() ;
        if (NULL != pGVars)
          pGVars->resetProcessState() ;
      }
    }

    pDial = new nsrefDialog(pContexte->GetMainWindow(), pContexte, &Parseur, bSimple) ;
    idRet = pDial->Execute() ;
    delete pDial ;
  }
  if (idRet != IDOK)
    return ;

  string sLogString = "" ;

#ifndef __EPIBRAIN__
	// Publication des contraintes du r�f�rentiel
  // We publish referential's constraints
	//
  Cglobalvars* pGlobVars = Parseur.pReferentiel->getGVars() ;
	if (pGlobVars && pSuper->getDPIO() && pSuper->getDPIO()->bLogPage && pGlobVars->existPublishingString())
	{
		pSuper->getDPIO()->addToLogPage(string(""), string("<br>\r\n")) ;
		pSuper->getDPIO()->addToLogPage(string("Facteurs de risque retenus :"), string("<b>"), string("</b><br>\r\n")) ;

		sLogString = pGlobVars->getPublishingString() ;

    //if (sLogString != "")
    //	pSuper->getDPIO()->addToLogPage(sLogString) ;
	}
#endif // !__EPIBRAIN__

  ArrayGoals PreviousGoals(pDocLdv) ;
  ValArray   OldTrees ;
  ValArray   ClosedTrees ;

  // R�cup�ration de la liste des objectifs issus d'un document de m�me type
  // Getting the list of goals created from a document of the same kind
  if (!(pDocHis->VectDocument.empty()))
  {
    // R�cup�ration du pr�c�dent document du m�me type
    // Getting the previous doc of the same kind
    DocumentIter itCurrentDoc = pDocHis->VectDocument.TrouveDocHisto(sDocument) ;
    if ((itCurrentDoc != NULL) && (itCurrentDoc != pDocHis->VectDocument.end()))
    {
      PatPathoIter iterRootPat = (*itCurrentDoc)->pPatPathoArray->begin() ;
      string sTypeDoc = (*iterRootPat)->getLexique() ;
      NSPatPathoArray PreviousPatPatho(pContexte) ;
      DocumentIter itPreviousDoc = pDocHis->DonnePrevPatPathoDocument(sTypeDoc, &PreviousPatPatho, itCurrentDoc) ;

      // Il existe un document plus ancien : on stocke dans pPreviousGoals
      // des pointeurs sur ses objectifs
      if ((itPreviousDoc != NULL) && (itPreviousDoc != pDocHis->VectDocument.end()))
      {
        string sCodePrevDoc = (*itPreviousDoc)->getID() ;
        NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
        VecteurString GoalsID ;
        pGraphe->TousLesVrais(sCodePrevDoc, NSRootLink::refCreator, &GoalsID) ;

        if (!(GoalsID.empty()))
        {
          ArrayGoals* pLDVgoals = pDocLdv->getGoals() ;
          if ((pLDVgoals) && (!(pLDVgoals->empty())))
          {
            EquiItemIter iGoals = GoalsID.begin() ;
            for ( ; iGoals != GoalsID.end() ; iGoals++)
            {
              NSLdvGoal* pGoal = pLDVgoals->getGoal(**iGoals) ;
              if (pGoal != NULL)
                PreviousGoals.push_back(pGoal) ;
            }
          }
        }
      }
    }
  }

#ifndef __EPIBRAIN__
  if (pSuper->getDPIO() && pSuper->getDPIO()->bLogPage)
  {
		pSuper->getDPIO()->addToLogPage(string(""), string("<br>\r\n")) ;
		pSuper->getDPIO()->addToLogPage(string("Objectifs de suivi :"), string("<b>"), string("</b><br>\r\n")) ;
  }
#endif // !__EPIBRAIN__

  // Fermeture des objectifs qui n'ont pas �t� � nouveau choisis et prolongation
  // des objectifs prorog�s
  // Il est important d'effectuer cette �tape avant l'insertion des nouveaux objectifs
  // --
  // Closing all the goals that were not selected again, and continuatins already
  // existing ones
  // This step must be achieved before we insert new goals
  if (!(PreviousGoals.empty()))
  {
		// On marque tous les anciens objectifs comme "� d�truire" ; seuls ceux
    // qui sont retrouv�s dans la nouvelle liste seront sortis de cette liste
    //
		// Each and every new goal is flaged "to delete"; only those who are
    // found in the new selection are moved away from this list
    ArrayGoals ToDelete(PreviousGoals) ;

    // On ne garde au sein de pPreviousGoals que ceux qui n'ont pas � nouveau �t� choisis
    // on parcourt l'ensemble des propositions
    for (ival = pRefArray->begin(); ival != pRefArray->end(); ival++)
    {
      if (LABEL_PROPOSITION == (*ival)->sLabel)
      {        // si la proposition a �t� retenue (check == true)        Cproposition* pCprop = dynamic_cast<Cproposition*>((*ival)->pObject);
        if (pCprop->getCheck())
        {
          for (ivalp = pCprop->getValArray()->begin(); ivalp != pCprop->getValArray()->end(); ivalp++)
          {
            if (LABEL_TREE == (*ivalp)->sLabel)
            {
              // on cr�e l'objectif de sant� pour chaque arbre
              Ctree* pCtree = dynamic_cast<Ctree*>((*ivalp)->pObject);
              NSPatPathoArray PptObjectif(pContexte) ;
              if (LocalPatho(pCtree->pPatPathoArray, &PptObjectif))
              {
                NSLdvGoal Goal(pContexte) ;
                PatPathoIter itPpt = PptObjectif.begin() ;
                Goal.initFromPatho(&PptObjectif, &itPpt) ;

                for (ArrayGoalIter itGoals = ToDelete.begin(); itGoals != ToDelete.end(); )
                {
                  if (Goal.estIdentique(*itGoals))
                  {
										NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
                    pGraphe->etablirLien(sDocument, NSRootLink::refCreator, (*itGoals)->getNoeud()) ;

                    OldTrees.push_back(*ivalp) ;
                    ToDelete.erase(itGoals) ;
                  }
                  else
                    itGoals++ ;
                }
              }
            }
          }
        }

        // Proposition refus�e avec motif : ouverture et fermeture instantan�e
        else if (pCprop->bInitialyChecked && pCprop->pReasonTree && !(pCprop->pReasonTree->empty()))
        {
          // on parcours l'ensemble des arbres d'objectif de la proposition
          for (ivalp = pCprop->getValArray()->begin(); ivalp != pCprop->getValArray()->end(); ivalp++)
          {
            if (LABEL_TREE == (*ivalp)->sLabel)
            {
              // on cr�e l'objectif de sant� pour chaque arbre
              Ctree* pCtree = dynamic_cast<Ctree*>((*ivalp)->pObject) ;
              NSPatPathoArray PptObjectif(pContexte) ;
              if (LocalPatho(pCtree->pPatPathoArray, &PptObjectif))
              {
                NSLdvGoal Goal(pContexte) ;
                PatPathoIter itPpt = PptObjectif.begin() ;
                Goal.initFromPatho(&PptObjectif, &itPpt) ;

                for (ArrayGoalIter itGoals = ToDelete.begin() ; itGoals != ToDelete.end() ; )
                {
                  if (Goal.estIdentique(*itGoals))
                  {
                    pDocLdv->closeGoal(*itGoals, pCprop->pReasonTree) ;
										NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

                    pGraphe->etablirLien(sDocument, NSRootLink::goalCloser, (*itGoals)->getNoeud()) ;

                    ClosedTrees.push_back(*ivalp) ;
                    ToDelete.erase(itGoals) ;
                  }
                  else
                    itGoals++ ;
                }
              }
            }
          }
        }
      }
    }
    if (!(ToDelete.empty()))
    {
      for (ArrayGoalIter itGoals = ToDelete.begin(); itGoals != ToDelete.end(); )
      {
        pDocLdv->closeGoal(*itGoals, NULL) ;
        ToDelete.erase(itGoals) ;
      }
    }

    for (ArrayGoalIter itGoals = PreviousGoals.begin() ; itGoals != PreviousGoals.end() ; )
      PreviousGoals.erase(itGoals) ;
  }

  // on parcourt l'ensemble des propositions
  for (ival = pRefArray->begin(); ival != pRefArray->end(); ival++)
  {    if (LABEL_PROPOSITION == (*ival)->sLabel)    {      // si la proposition a �t� retenue (check == true)      Cproposition* pCprop = dynamic_cast<Cproposition*>((*ival)->pObject);
      if (pCprop->getCheck())
      {
        //
        string sPropName = pCprop->getStringAttribute(ATTRIBUT_CONTR_NOM) ;
        if (sPropName != "")
        {
          ps = string("R�ferentiel, traitement proposition ") + sPropName ;
          pSuper->trace(&ps, 1) ;
#ifndef __EPIBRAIN__
          pSuper->getDPIO()->addToLogPage(sPropName, string("<li>"), string("</li>\r\n")) ;
#endif // !__EPIBRAIN__
        }
        else
        {
          ps = string("R�ferentiel, proposition sans nom") ;
          pSuper->trace(&ps, 1) ;
        }

        ps = string("R�ferentiel, proposition, cr�ation d'objectifs") ;
        pSuper->trace(&ps, 1) ;
        // on parcours l'ensemble des arbres d'objectif de la proposition
        for (ivalp = pCprop->getValArray()->begin() ; ivalp != pCprop->getValArray()->end() ; ivalp++)
        {
          if (LABEL_TREE == (*ivalp)->sLabel)
          {
            // on cr�e l'objectif de sant� pour chaque arbre
            Ctree* pCtree = dynamic_cast<Ctree *>((*ivalp)->pObject) ;

            // Cet objectif existait-il d�j� ?
            // Was this goal already there ?
            bool bAlreadyThere = false ;
            if (!(OldTrees.empty()))
            {
              ValIter iOltTrees = OldTrees.begin() ;
              for ( ; (iOltTrees != OldTrees.end()) && ((*iOltTrees)->pObject != (*ivalp)->pObject) ; iOltTrees++)
                ;
              if (iOltTrees != OldTrees.end())
                bAlreadyThere = true ;
            }
            if (!bAlreadyThere)
            {
              ps = string("R�ferentiel, proposition, cr�ation d'un objectif") ;
              pSuper->trace(&ps, 1) ;
              if (!CreeObjectif(pCtree->pPatPathoArray, sDocument, sRefId, pCprop->getLocalPropIDFromPropID(), pCprop->pReasonTree))
                // cas d'erreur : on interrompt le processus
                return ;
            }
          }
        }
      }
      // Proposition refus�e avec motif : ouverture et fermeture instantan�e
      else if (pCprop->bInitialyChecked && pCprop->pReasonTree && !(pCprop->pReasonTree->empty()))
      {
        string sPropName = pCprop->getStringAttribute(ATTRIBUT_CONTR_NOM) ;
#ifndef __EPIBRAIN__
        if (sPropName != "")
        	pSuper->getDPIO()->addToLogPage(string("Refus de ") + sPropName, string("<li>"), string("</li>\r\n")) ;
#endif // !__EPIBRAIN__

        // on parcours l'ensemble des arbres d'objectif de la proposition
        for (ivalp = pCprop->getValArray()->begin(); ivalp != pCprop->getValArray()->end(); ivalp++)
        {
          if (LABEL_TREE == (*ivalp)->sLabel)
          {
            // on cr�e l'objectif de sant� pour chaque arbre
            Ctree* pCtree = dynamic_cast<Ctree *>((*ivalp)->pObject) ;

            // Cet objectif a-t-il d�j� �t� ferm� ?
            // Has this goal already been closed ?
            bool bAlreadyClosed = false ;
            if (!(ClosedTrees.empty()))
            {
              ValIter iOltTrees = ClosedTrees.begin() ;
              for ( ; (iOltTrees != ClosedTrees.end()) && ((*iOltTrees)->pObject != (*ivalp)->pObject) ; iOltTrees++)
                ;
              if (iOltTrees != ClosedTrees.end())
                bAlreadyClosed = true ;
            }
            if (!bAlreadyClosed)
            {
              if (!RefuseObjectif(pCtree->pPatPathoArray, sDocument, sRefId, pCprop->pReasonTree))
                // cas d'erreur : on interrompt le processus
                return ;
            }
          }
        }
      }
    }
  }

  ps = string("R�ferentiel, inscription du log DPIO") ;
  pSuper->trace(&ps, 1) ;

#endif // !__EPIPUMP__
}
catch (...)
{
  erreur("Exception NSPatientChoisi::CmReferentiel.", standardError, 0) ;
}
}

void
NSPatientChoisi::Importer(string sFileName)
{
try
{
	char            title[255] ;

	// Pour emp�cher la TMDIChild de red�finir le titre de la MainWindow
	pContexte->GetMainWindow()->GetWindowText(title, 254) ;

	// on cr�e la fenetre d'importation
	NSImportWindow* pImportWindow = new NSImportWindow(pContexte->GetMainWindow(), sFileName, pContexte) ;

  if (false == pImportWindow->bNavOk)
  {
    // Here is an exception for the fu.... Word files that we treat like if
    // it has been selected by "open / file"
    //
    string sMajExtension = pseumaj(pImportWindow->sExtension) ;
    delete pImportWindow ;

    if ((string("DOC") == sMajExtension) || (string("DOCX") == sMajExtension))
    {
      NSTtxDocument* pNewDocTtx = new NSTtxDocument(0, pContexte) ;
      pNewDocTtx->SetFichierExterne(sFileName) ;
		  NSDocViewManager dvManager(pContexte) ;
		  dvManager.createView(pNewDocTtx, "Word Format") ;
      return ;
    }

    if (string("") == pImportWindow->sTypeNautilus)
    {
      string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "unreferencedExtension") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	  erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      return ;
	  }

    return ;
  }

	NSImportChild* pImportChild = new NSImportChild(pContexte, *(pContexte->getSuperviseur()->getApplication()->prendClient()), "Importation", pImportWindow) ;

	pContexte->GetMainWindow()->SetCaption(title) ;

	pImportChild->Create() ;
}
catch (...)
{
	erreur("Exception NSPatientChoisi::Importer.", standardError, 0) ;
}
}

void
NSPatientChoisi::CmImportImg(AssistCaptureDialog* pAssist)
{
try
{
	if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	// on cr�e la fenetre d'importation des images
  NSImpImgWindow* pImportWindow = new NSImpImgWindow(pContexte->GetMainWindow(), pContexte, pAssist) ;

  if (false == pImportWindow->bNavOk)
	{
    delete pImportWindow ;
    return ;
  }

	NSImpImgChild* pImportChild = new NSImpImgChild(pContexte, *(pContexte->getSuperviseur()->getApplication()->prendClient()), "Importation des images", pImportWindow) ;

	pImportChild->Create() ;
}
catch (...)
{
	erreur("Exception NSPatientChoisi::CmImportImg.", standardError, 0) ;
}
}

void
NSPatientChoisi::CmGenerePannel()
{
try
{
	string sNomFichier, sLocFichier ;
	string sNomSource, sNomDest, sNomTemplate, sNomEnTeteBrut ;

	// char   nomModele[TMPL_FICHIER_LEN + 1];
	// char   nomEnTete[TMPL_EN_TETE_LEN + 1];

  string sNomModele = string("") ;
  string sNomEntete = string("") ;

	bool   bExisteImages = false ;
	// NSBaseImages*  pBaseCompo;

	// Dialogue de choix du template
	// qui sera le fichier source du nouveau HIHTM
	ChoixTemplateDialog* pChoixTemplateDlg =
		new ChoixTemplateDialog(pContexte->GetMainWindow(), pContexte, "ZIHTM", "") ;

	if (pChoixTemplateDlg->Execute() == IDCANCEL)
	{
		delete pChoixTemplateDlg ;
		return ;
	}

	int numModele = pChoixTemplateDlg->TemplateChoisi ;
	if (numModele > 0)
	{
		// strcpy(nomModele, (*(pChoixTemplateDlg->pTemplateArray))[numModele-1]->pDonnees->fichier) ;
		// strcpy(nomEnTete, (*(pChoixTemplateDlg->pTemplateArray))[numModele-1]->pDonnees->en_tete) ;

    sNomModele = (*(pChoixTemplateDlg->pTemplateArray))[numModele-1]->getFichier() ;
  	sNomEntete = (*(pChoixTemplateDlg->pTemplateArray))[numModele-1]->getEnTete() ;
	}
	else
	{
    string sErrorText = pContexte->getSuperviseur()->getText("imagesPannelErrors", "aTemplateMustBeSelected") ;
		erreur(sErrorText.c_str(), warningError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    delete pChoixTemplateDlg ;
		return ;
	}

	delete pChoixTemplateDlg ;

	// on prend comme convention que le fichier template sera copi� dans le fichier html dest
	// => le nom template ne figure pas dans le HDHTM (il y figure par contre l'en-tete)
  // car un fichier HIHTM est lui-m�me sa propre template
	sNomTemplate = pContexte->PathName("NTPL") + sNomModele ;
  sNomEnTeteBrut = sNomEntete ;

  NSRefDocument NewDoc(0, pContexte) ;

	// On trouve un nouveau nom pour le fichier � r�f�rencer
	if (!NewDoc.TrouveNomFichier("ZIHTM", "htm", sNomFichier, sLocFichier))
	{
    string sErrorText = pContexte->getSuperviseur()->getText("imagesPannelErrors", "errorWhenSettingAFileNameForThisPannel") ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return;
	}

	// on le copie depuis le repertoire source sous son nouveau nom
	sNomSource = sNomTemplate ;
	sNomDest = pContexte->PathName(sLocFichier) + sNomFichier ;

	if (!CopyFile(sNomSource.c_str(), sNomDest.c_str(), false))
	{
    string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorCopyingFile") ;
    sErrorText += string(" ") + sNomSource + string(" -> ") + sNomDest ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return;
	}

  string sLangue  = pContexte->getUtilisateur()->donneLang() ;
  string sCodeLex = string("ZIHTM1") ;
  string sLibelle ;
  pContexte->getDico()->donneLibelle(sLangue, &sCodeLex, &sLibelle) ;

	if (!NewDoc.Referencer("ZIHTM", sLibelle, sNomFichier, sLocFichier, true,
                                true, "", NSRootLink::personDocument, 0, "_User_",
                                "", sNomEnTeteBrut))
	{
    string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "failedToSave") ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	// test pr�alable : la chemise contient-elle des images ?
	if (!NewDoc.ChemiseAvecImages(bExisteImages))
	{
    string sErrorText = pContexte->getSuperviseur()->getText("imagesPannelErrors", "itIsNotPossibleToDetermineIfThisPannel'sFolderContainsImages") ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	if (!bExisteImages)
	{
		string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    string sErrorText = pContexte->getSuperviseur()->getText("imagesPannelErrors", "thisPannel'sFolderDoesNotContainAnyImages") ;
    sErrorText += string(" ") + pContexte->getSuperviseur()->getText("imagesPannelErrors", "doYouWantToKeepOn") ;
		int idRet = MessageBox(0, sErrorText.c_str(), sCaption.c_str(), MB_YESNO) ;
		if (idRet == IDNO)
			return ;
	}

	// Le pannel �tant maintenant un nouveau document HIHTM
	// on charge automatiquement sa base de composition pour
	// pouvoir lui donner comme composants les images de la
	// chemise en cours.
	NSModHtml html(toComposer, &NewDoc, pContexte) ;

	if (!html.chargeBaseImages(pContexte->PathName("SHTM"), "", true))
	{
    string sErrorText = pContexte->getSuperviseur()->getText("imagesManagementErrors", "cannotCreateImagesList") ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	if (html.sBaseCompo != "")
		NewDoc.sBaseCompo = html.sBaseCompo ;

	NSPersonGraphManager* pManager = pContexte->getPatient()->pGraphPerson ;
  string sDroits ;
  // �criture des composants image
  NewDoc.EcrireComposants(NewDoc.pDocInfo->pPres) ;
  // enregistrement des composants et mise � jour de pDocInfo
  pManager->setTree(NewDoc.pDocInfo->pPres, "", NewDoc.pDocInfo->sCodeDocPres) ;
  pManager->commitGraphTree(NewDoc.pDocInfo->sCodeDocPres) ;
  pManager->getTree(NewDoc.pDocInfo->sCodeDocPres, NewDoc.pDocInfo->pPres, &sDroits) ;

	//
	// Ouverture effective du document : appel de pSuper
	//

	// NSDocumentInfo Docum(pContexte) ;
	// *(Docum.getData()) = *(NewDoc.pDocInfo->getData()) ;

  NSDocumentInfo Docum(*(NewDoc.pDocInfo)) ;

	NSNoyauDocument* pDocNoy = pContexte->getSuperviseur()->OuvreDocument(Docum, pContexte, false) ;
	if (NULL != pDocNoy)
	{
		// on reprend les donnees pour �viter l'effet de bord de OuvreDocument
		// (switch entre document HD et document brut CN)
		*(Docum.getData()) = *(NewDoc.pDocInfo->getData()) ;

		// on range le pHtmlInfo dans le cas d'un HD
		// (permet de savoir que le document est compos�)
		pDocHis->RangeDocumentOuvert(&Docum, pDocNoy) ;
	}
}
catch (...)
{
	erreur("Exception NSPatientChoisi::CmGenerePannel.", standardError, 0) ;
}
}

void NSPatientChoisi::LdV_init()
{
try
{
#ifndef __EPIPUMP__
	pDocLdv = new NSLdvDocument(0, pContexte);
#endif // !__EPIPUMP__
}
catch (...)
{
	erreur("Exception NSPatientChoisi::LdV_init.", standardError, 0) ;
}
}

void
NSPatientChoisi::LdV_show(string sConcern)
{
try
{
#ifndef __EPIPUMP__

	if (!pDocLdv)
		return ;

	TView* pView = pDocLdv->GetViewList() ;
  if (NULL != pView)
  {
		do
		{
			NSLdvView* pLdVView = TYPESAFE_DOWNCAST(pView, NSLdvView) ;
			if (pLdVView /*&& (pLdVView->getConcern() == sConcern)*/)
			{
        pLdVView->SetFocus() ;
    		// ::SetFocus(pLdVView->GetHandle()) ;
        // TWindow* pWnd = (TWindow*) pLdVView->GetParent() ;
      	// if (pWnd)
        //   ::SetFocus(pWnd->GetHandle()) ;
				return ;
			}

			pView = pDocLdv->NextView(pView) ;
		}
		while (pView) ;
  }

	NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pDocLdv) ;

#endif
}
catch (...)
{
    erreur("Exception NSPatientChoisi::LdV_show.", standardError, 0) ;
}
}

void
NSPatientChoisi::drugs_show(string sConcern)
{
try
{
#ifndef __EPIPUMP__
	if (!pDocLdv)
		return ;

	TView* pView = pDocLdv->GetViewList() ;
  if (NULL != pView)
  {
		do
		{
			NSDrugView* pDrugView = TYPESAFE_DOWNCAST(pView, NSDrugView) ;
			if (pDrugView && (pDrugView->getConcern() == sConcern))
			{
      	pDrugView->activate() ;
				return ;
			}

			pView = pDocLdv->NextView(pView) ;
		}
		while (pView) ;
  }

	if (!(pContexte->userHasPrivilege(NSContexte::viewDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

	NSDocViewManager dvManager(pContexte) ;
	if (sConcern == "")
		dvManager.createView(pDocLdv, "Drug Management") ;
	else
	{
		NSDrugView* pDrugView = new NSDrugView(*pDocLdv, sConcern) ;
		dvManager.createView(pDocLdv, "Drug Management", pDrugView) ;
	}

#endif // !__EPIPUMP__
}
catch (...)
{
	erreur("Exception NSPatientChoisi::drugs_show.", standardError, 0) ;
}
}

void
NSPatientChoisi::goals_show(string sConcern)
{
try
{
#ifndef __EPIPUMP__
	if (!pDocLdv)
		return ;
	//
	// On v�rifie que la fen�tre n'est pas d�j� ouverte
	// Checking if the same window is not already open
	//
	TView* pView = pDocLdv->GetViewList() ;
  if (NULL != pView)
  {
		do
		{
			NSGoalView* pGoalView = TYPESAFE_DOWNCAST(pView, NSGoalView) ;
			if (pGoalView && (pGoalView->getConcern() == sConcern))
			{
				pGoalView->activate() ;
				return ;
			}

			pView = pDocLdv->NextView(pView) ;
		}
		while (pView) ;
  }

	if (!(pContexte->userHasPrivilege(NSContexte::viewGoal, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

	NSDocViewManager dvManager(pContexte) ;
	if (sConcern == "")
		dvManager.createView(pDocLdv, "Goal Management") ;
	else
	{
		NSGoalView* pGoalView = new NSGoalView(*pDocLdv, sConcern) ;
		dvManager.createView(pDocLdv, "Goal Management", pGoalView) ;
	}

#endif // !__EPIPUMP__
}
catch (...)
{
    erreur("Exception NSPatientChoisi::goals_show.", standardError, 0) ;
}
}

void
NSPatientChoisi::process_show(string sConcern)
{
try
{
#ifndef __EPIPUMP__
	if (!pDocLdv)
		return ;
	// On v�rifie que la fen�tre n'est pas d�j� ouverte
	// Checking if the same window is not already open
	TView *pView = pDocLdv->GetViewList() ;
  if (NULL != pView)
  {
		do
		{
			NSProcessView* pProcessView = TYPESAFE_DOWNCAST(pView, NSProcessView) ;
			if (pProcessView && (pProcessView->getConcern() == sConcern))
			{
				pProcessView->activate() ;
				return ;
			}

			pView = pDocLdv->NextView(pView) ;
		}
		while (pView) ;
  }

	if (!(pContexte->userHasPrivilege(NSContexte::viewProcess, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

	NSDocViewManager dvManager(pContexte) ;
	if (sConcern == "")
		dvManager.createView(pDocLdv, "Process Management") ;
	else
	{
		NSProcessView* pProcessView = new NSProcessView(*pDocLdv, sConcern) ;
		dvManager.createView(pDocLdv, "Process Management", pProcessView) ;
	}

#endif // !__EPIPUMP__
}
catch (...)
{
	erreur("Exception NSPatientChoisi::process_show.", standardError, 0) ;
}
}

void
NSPatientChoisi::followUp_show(string sConcern)
{
try
{
#ifndef __EPIPUMP__
	if (!pDocLdv)
		return ;
	// On v�rifie que la fen�tre n'est pas d�j� ouverte
	// Checking if the same window is not already open
	TView *pView = pDocLdv->GetViewList() ;
  if (NULL != pView)
  {
		do
		{
			NSFollowUpView* pFUView = TYPESAFE_DOWNCAST(pView, NSFollowUpView) ;
			if (pFUView && (pFUView->getConcern() == sConcern))
			{
				pFUView->activate() ;
				return ;
			}

			pView = pDocLdv->NextView(pView) ;
		}
		while (pView) ;
  }

	if (!(pContexte->userHasPrivilege(NSContexte::viewProcess, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

	NSDocViewManager dvManager(pContexte) ;
	if (sConcern == "")
		dvManager.createView(pDocLdv, "FollowUp Management") ;
	else
	{
		NSFollowUpView* pFUView = new NSFollowUpView(*pDocLdv, sConcern) ;
		dvManager.createView(pDocLdv, "FollowUp Management", pFUView) ;
	}

#endif // !__EPIPUMP__
}
catch (...)
{
	erreur("Exception NSPatientChoisi::followUp_show.", standardError, 0) ;
}
}

void
NSPatientChoisi::heathTeamRosaceShow()
{
try
{
#ifndef __EPIPUMP__
#ifndef __EPIBRAIN__

	if (!pHealthDoc)
  	pHealthDoc = new NSHealthTeamDocument(0, pContexte, pHealthTeam) ;

	TView* pView = pHealthDoc->GetViewList() ;
  if (NULL != pView)
  {
		do
		{
			NSHealthTeamRosaceView* pRosaceView = TYPESAFE_DOWNCAST(pView, NSHealthTeamRosaceView) ;
			if (pRosaceView)
			{
        pRosaceView->activate() ;
				return ;
			}

			pView = pHealthDoc->NextView(pView) ;
		}
		while (pView) ;
  }

	NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pHealthDoc, "HealthTeam rosace") ;

#endif // !__EPIPUMP__
#endif // !__EPIBRAIN__
}
catch (...)
{
	erreur("Exception NSPatientChoisi::heathTeamRosaceShow.", standardError, 0) ;
}
}

void
NSPatientChoisi::heathTeamListShow()
{
try
{
#ifndef __EPIPUMP__
#ifndef __EPIBRAIN__

	if (!pHealthDoc)
  	pHealthDoc = new NSHealthTeamDocument(0, pContexte, pHealthTeam) ;

	TView* pView = pHealthDoc->GetViewList() ;
  if (NULL != pView)
  {
		do
		{
			NSHealthTeamListView* pListView = TYPESAFE_DOWNCAST(pView, NSHealthTeamListView) ;
			if (pListView)
			{
        pListView->activate() ;
				return ;
			}

			pView = pHealthDoc->NextView(pView) ;
		}
		while (pView) ;
  }

	NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pHealthDoc, "HealthTeam list") ;

#endif
#endif
}
catch (...)
{
	erreur("Exception NSPatientChoisi::heathTeamRosaceShow.", standardError, 0) ;
}
}

void
NSPatientChoisi::admin_show()
{
try
{
	NSLinkManager* pGraphe = pGraphPerson->pLinkManager ;
  string sCodeDocRoot = pGraphPerson->getRootTree() ;
	string sCodeDocAdmin, sCodeDocAdminData ;
  //
  // Meta document
  //
	VecteurString VecteurString ;
	pGraphe->TousLesVrais(sCodeDocRoot, NSRootLink::personAdminData, &VecteurString) ;

	if (VecteurString.empty())
	{
  	string sError = pContexte->getSuperviseur()->getText("patientOpening", "unableToFindAdminDocument") ;
    pContexte->getSuperviseur()->trace(&sError, 1, NSSuper::trError) ;
    erreur(sError.c_str(), standardError, 0) ;
		return ;
	}
  //
  // Data document
  //
	sCodeDocAdmin = *(*(VecteurString.begin())) ;
	VecteurString.vider() ;
	pGraphe->TousLesVrais(sCodeDocAdmin, NSRootLink::docData, &VecteurString) ;
	if (VecteurString.empty())
	{
		erreur("Impossible de retrouver les donn�es de la fiche administrative.", standardError, 0) ;
		return ;
	}
	sCodeDocAdminData = *(*(VecteurString.begin())) ;

	string sCodePat = string(sCodeDocAdminData, 0, PAT_NSS_LEN) ;
	string sCodeDoc = string(sCodeDocAdminData, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;

	NSDocumentInfo NSDocumentInfo(pContexte) ;
	NSDocumentInfo.setPatient(sCodePat) ;
	NSDocumentInfo.setDocument(sCodeDoc) ;
	NSDocumentInfo.setType(string("CQ030")) ;

  // Already open ?
  //
	TView* pView = pDocHis->ActiveFenetre(&NSDocumentInfo, "NSCQVue");
	if (pView != 0)
		return ;

	NSPatPathoArray PatPathoAdmin(pContexte) ;
	pDocHis->DonnePatPathoDocument("ZADMI1", &PatPathoAdmin) ;
	ChargeDonneesPatient(&PatPathoAdmin) ;
	initCorrespArray(&PatPathoAdmin) ;
	PostInitialisation() ;

	// On doit lancer postinitialisation AVANT d'ouvrir la fiche administrative
	// (fabrication du nom long, calcul de l'age du patient, etc.)
	pDocHis->AutoriserEdition(&NSDocumentInfo) ;
}
catch (...)
{
	erreur("Exception NSPatientChoisi::admin_show.", standardError, 0) ;
}
}

void
NSPatientChoisi::histo_show()
{
}

void NSPatientChoisi::CmFeuilleSecu()
{
	// on ne doit pas deleter pDocSecu car cela est fait
	// par la VisualView en fin de visualisation
	pDocSecu = new NSSecuRefDocument(pContexte);

	if (pDocSecu->bInitOk)
		pDocSecu->Visualiser();
	else
		erreur("Impossible d'�diter la feuille de soins.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
}


void NSPatientChoisi::CmNewCr()
{
try
{
#ifndef __EPIPUMP__
#ifndef __EPIBRAIN__
  /***********************
	if (getReadOnly())
	{
		erreur("Le dossier de ce patient est en lecture seule.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}
  ***********************/

	// choix du compte rendu
	string sChoixCR ;
	string sImportDll = "" ;

	ChoixCRDialog* pChoixCRDl = new ChoixCRDialog(pContexte->GetMainWindow(), &sChoixCR, &sImportDll, pContexte) ;
	if (pChoixCRDl->Execute() == IDCANCEL)
		return ;

	// Importation automatique
	if (sImportDll != "")
	{
		// Chargement de la dll d'importation / Loading the import dll
		TModule* pDCModule = new TModule(sImportDll.c_str(), TRUE) ;

		if (!pDCModule)
		{
			string sErrMess = "Impossible d'ouvrir la DLL d'importation : " + sImportDll ;
      pContexte->getSuperviseur()->trace(&sErrMess, 1, NSSuper::trError) ;
			erreur(sErrMess.c_str(), standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
		}
		else
		{
			bool (FAR *pAdresseFct) (NSContexte far *) ;
			// R�cup�ration du pointeur sur la fonction // Getting function's pointer
			(FARPROC) pAdresseFct = pDCModule->GetProcAddress(MAKEINTRESOURCE(1)) ;
			if (pAdresseFct != NULL)
			{
				bool bReussi = ((*pAdresseFct)((NSContexte far *) pContexte)) ;
				if (!bReussi)
					erreur("Echec � l'importation", standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
			}
			delete pDCModule ;
		}
	}

	// Lancement du module
	NSCRDocument* pDocNewCr = new NSCRDocument(0, pContexte, sChoixCR) ;
  NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pDocNewCr, "CN Format") ;

#endif // !__EPIPUMP__
#endif // !__EPIBRAIN__
}
catch (...)
{
	erreur("Exception NSPatientChoisi::CmNewCr.", standardError, 0) ;
}
}

void NSPatientChoisi::CmNewArchetype()
{
try
{
	if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return;
	}

	//
	// choix du compte rendu
	//
	string sChoixCR;

	ChoixArchetypeDialog* pChoixCRDl = new ChoixArchetypeDialog(pContexte->GetMainWindow(),
                                                                &sChoixCR,
                                                                pContexte);
	if (pChoixCRDl->Execute() == IDCANCEL)
		return;
    if (sChoixCR == "")
        return;

	//
	// Lancement de l'achetype
	//
	pContexte->getSuperviseur()->BbkAskUser(sChoixCR, pContexte, NSCQDocument::standard);
}
catch (...)
{
	erreur("Exception NSPatientChoisi::CmNewArchetype.", standardError, 0) ;
}
}


// -----------------------------------------------------------------------------
// Function    : NSPatientChoisi::CmNewMagic()
// Arguments   :
// Description : Cr�e un document de type Magic
// Returns     : Rien
// -----------------------------------------------------------------------------
void NSPatientChoisi::CmNewConsult(bool bIsDocCS)
{
try
{
#ifndef __EPIPUMP__
#ifndef __EPIBRAIN__
	if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

  if (bIsDocCS && pConsultEnCours)
  {
    pConsultEnCours->activate() ;
    return ;
  }

	// choix du type document
	string sTypeDocument ;

  if (!bIsDocCS)
  {
    NSTypeDocument* pNSTypeDocument = new NSTypeDocument(pContexte->GetMainWindow(), pContexte, &sTypeDocument) ;
    if (pNSTypeDocument->Execute() == IDCANCEL)
    {
      delete pNSTypeDocument ;
      return ;
    }
    delete pNSTypeDocument ;
  }
  else
  	sTypeDocument = string("GCONS1") ;

  if ((sTypeDocument == "GCONS1") && pConsultEnCours)
  {
    pConsultEnCours->activate() ;
    return ;
  }

	NSCSDocument* pNewDocCS = new NSCSDocument(0, pContexte, sTypeDocument) ;

	if (sTypeDocument == "GCONS1")
		pConsultEnCours = pNewDocCS ;

  NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pNewDocCS, "CS Format") ;

#endif // !__EPIPUMP__
#endif // !__EPIBRAIN__
}
catch (...)
{
	erreur("Exception NSPatientChoisi::CmNewConsult.", standardError, 0) ;
}
}

void
NSPatientChoisi::Initialisation()
{
	string ps ;

try
{

#ifndef __EPIPUMP__
#ifndef __EPIBRAIN__

	bloquer() ;

	NSSuper *pSuper = pContexte->getSuperviseur() ;

	// NSLinkManager	*pGraphe 	= pGraphPerson->pLinkManager ;

	// on vide le nom et le pr�nom de l'array de capture
  //
	if ((pSuper->getEpisodus() != NULL) && (false == pSuper->getEpisodus()->CaptureArray.empty()))
	{
		NSCaptureArray* pCapt = &(pSuper->getEpisodus()->CaptureArray) ;

		for (CaptureIter captIter = pCapt->begin() ; pCapt->end() != captIter ; )
		{
			if      ((*captIter)->sChemin == "ZADMI1/LIDET1/LNOM01")
			{
				delete (*captIter) ;
				pCapt->erase(captIter) ;
			}
			else if ((*captIter)->sChemin == "ZADMI1/LIDET1/LNOM21")
			{
				delete (*captIter) ;
				pCapt->erase(captIter) ;
			}
			else if ((*captIter)->sChemin == "ZADMI1/LIDET1/LCODO1")
			{
				delete (*captIter) ;
				pCapt->erase(captIter) ;
			}
			else
				captIter++ ;
		}
	}

	NSEnregPatientDlg	*pProgressDlg = new NSEnregPatientDlg(pContexte->GetMainWindow(), pContexte) ;

	pProgressDlg->Create() ;	pProgressDlg->Show(SW_SHOW) ;

  //
  // Documents will be referenced in History inside NSHISTODocument ctor
  // We must create the contribution before, in case some documents need fixing
  //
  if (getContribution() == "")
    CreeContribution() ;

  pDocHis = new NSHISTODocument(0, pContexte) ;

	// ---------------------------------------------------------------------------
	// Initialisation de l'Equipe de Sant� du Patient.
	// Initialization of Patient's HealthTeam.

	NSPatPathoArray HTPatPatho(pContexte) ;
	pDocHis->DonnePatPathoDocument("LEQUI1", &HTPatPatho) ;
	pHealthTeam	= new NSHealthTeam(&HTPatPatho) ;

  pContexte->getRelationship()->init(pContexte) ;

	// ---------------------------------------------------------------------------
	// cr�ation de la fiche historique
  ps = pContexte->getSuperviseur()->getText("patientOpening", "openingHistory") + string("\n") ;
	pSuper->trace(&ps, 1) ;
	pProgressDlg->CheckHisto() ;

  NSDocViewManager dvManager(pContexte) ;
	dvManager.createView(pDocHis, "HS Format") ;

	// fixer la position de la fiche historique selon les valeurs dans la base des registres
	// TView	*pTView = pDocHis->GetViewList() ;
	// NsHistorique *pNsHistorique = static_cast<NsHistorique *>(pTView) ;

  NSDocumentInfo *pNSDocumentInfo = NULL ;

	// ouverture de la fiche de synth�se

	NSWindowProperty *pWinProp = pContexte->getUtilisateur()->aWinProp.getProperty("Synthesis") ;
  if ((NULL != pWinProp) && (pWinProp->getActivity() == NSWindowProperty::openedWithPatient))
	// if ((!(pSuper->getDPIO())) || (!(pSuper->getDPIO()->bMinimalInterface)))
	{
  	ps = pContexte->getSuperviseur()->getText("patientOpening", "openingSynthesis") + string("\n") ;
		pSuper->trace(&ps, 1) ;
		pProgressDlg->CheckSynth() ;

		pNSDocumentInfo = NULL ;

		string sCodeDocRoot = pGraphPerson->getRootTree() ;

		string sCodeDocSynth, sCodeDocSynthData ;

    VecteurString aVecteurString ;
    NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
    pGraphe->TousLesVrais(sCodeDocRoot, NSRootLink::personSynthesis, &aVecteurString) ;

    if (!aVecteurString.empty())
    {
      sCodeDocSynth = *(*(aVecteurString.begin())) ;
      aVecteurString.vider() ;
      pGraphe->TousLesVrais(sCodeDocSynth, NSRootLink::docData, &aVecteurString) ;

      if (!aVecteurString.empty())
      {
        sCodeDocSynthData = *(*(aVecteurString.begin())) ;

        DocumentIter synthIter = pDocHis->VectDocument.TrouveDocHisto(sCodeDocSynthData) ;
        if ((synthIter != NULL) && (synthIter != pDocHis->VectDocument.end()))
        	pNSDocumentInfo = *synthIter ;
      }
      else
      {
      	string sError = pContexte->getSuperviseur()->getText("patientOpening", "unableToFindSynthesisData") ;
        pContexte->getSuperviseur()->trace(&sError, 1, NSSuper::trError) ;
        erreur(sError.c_str(), standardError, 0) ;
        // pProgressDlg->Destroy() ;
        // delete pProgressDlg ;
        // return ;
      }
    }
    else
    {
    	string sError = pContexte->getSuperviseur()->getText("patientOpening", "unableToFindSynthesisDocument") ;
      pContexte->getSuperviseur()->trace(&sError, 1, NSSuper::trError) ;
      erreur(sError.c_str(), standardError, 0) ;
      // pProgressDlg->Destroy() ;
      // delete pProgressDlg ;
      // return ;
    }

		// la synth�se est ouverte par l'historique
    if (pNSDocumentInfo)
    	pDocHis->AutoriserEdition(pNSDocumentInfo) ;
	}

	// ---------------------------------------------------------------------------
  // ouverture de la fiche administrative � partir de l'historique
  pProgressDlg->CheckAdmin() ;
  pNSDocumentInfo = NULL ;

/*
	string sCodeDocRoot = pGraphPerson->getRootTree() ;

	string sCodeDocAdmin, sCodeDocAdminData ;

  VecteurString aVecteurString ;
  pGraphe->TousLesVrais(sCodeDocRoot, NSRootLink::personAdminData, &aVecteurString) ;

  if (!aVecteurString.empty())
  {
    sCodeDocAdmin = *(*(aVecteurString.begin())) ;
    aVecteurString.vider() ;
    pGraphe->TousLesVrais(sCodeDocAdmin, NSRootLink::docData, &aVecteurString) ;

    if (!aVecteurString.empty())
    {
      sCodeDocAdminData = *(*(aVecteurString.begin())) ;

			DocumentIter synthIter = pDocHis->VectDocument.TrouveDocHisto(sCodeDocAdminData) ;
			if ((synthIter != NULL) && (synthIter != pDocHis->VectDocument.end()))
				pNSDocumentInfo = *synthIter ;
    }
    else
    {
    	string sError = pContexte->getSuperviseur()->getText("patientOpening", "unableToFindAdminData") ;
      erreur(sError.c_str(), standardError, 0) ;
      // pProgressDlg->Destroy() ;
      // delete pProgressDlg ;
      // return ;
    }
  }
  else
  {
  	string sError = pContexte->getSuperviseur()->getText("patientOpening", "unableToFindAdminDocument") ;
    erreur(sError.c_str(), standardError, 0) ;
    // pProgressDlg->Destroy() ;
    // delete pProgressDlg ;
    // return ;
  }

*/

	NSPatPathoArray PatPathoAdmin(pContexte) ;
	pDocHis->DonnePatPathoDocument("ZADMI1", &PatPathoAdmin) ;
	ChargeDonneesPatient(&PatPathoAdmin) ;

  string sStatusText = pContexte->getSuperviseur()->getText("HealthTeamManagement", "loadingCorrespondants") ;
  pContexte->getSuperviseur()->afficheStatusMessage((char*) sStatusText.c_str()) ;
  ps = string("Initializing windows position") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

	initCorrespArray(&PatPathoAdmin) ;

  ps = string("Initializing windows position") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;
  sStatusText = pContexte->getSuperviseur()->getText("HealthTeamManagement", "correspondantsLoaded") ;
  pContexte->getSuperviseur()->afficheStatusMessage((char*) sStatusText.c_str()) ;

  pProgressDlg->CheckCorrs() ;

	PostInitialisation() ;

	// On doit lancer postinitialisation AVANT d'ouvrir la fiche administrative
	// (fabrication du nom long, calcul de l'age du patient, etc.)
	if (pNSDocumentInfo)
		pDocHis->AutoriserEdition(pNSDocumentInfo) ;

	// ---------------------------------------------------------------------------
	// Initialisation de la ligne de vie
  ps = pContexte->getSuperviseur()->getText("patientOpening", "openingLigneDeVie") + string("\n") ;
	pSuper->trace(&ps, 1) ;
	pProgressDlg->CheckLDV() ;
	LdV_init() ;

	if (false == pContexte->getUtilisateur()->aWinProp.empty())
	{
		ArrayWPIter iter = pContexte->getUtilisateur()->aWinProp.begin() ;
  	for ( ; pContexte->getUtilisateur()->aWinProp.end() != iter ; iter++)
    {
    	if (NSWindowProperty::openedWithPatient == (*iter)->getActivity())
      {
      	if      (string("HealthTeamList")   == (*iter)->getFunction())
      		heathTeamListShow() ;
        else if (string("HealthTeamRosace") == (*iter)->getFunction())
      		heathTeamRosaceShow() ;
        else if (string("DrugManagement")   == (*iter)->getFunction())
      		drugs_show() ;
        else if (string("GoalManagement")   == (*iter)->getFunction())
      		goals_show() ;
        else if (string("AdminData")        == (*iter)->getFunction())
      		admin_show() ;
        else if (string("GoalsFollowUp")    == (*iter)->getFunction())
      		followUp_show() ;
      }
    }
	}

  // Mode Ouverture automatique de la Ligne de vie
	// if ((pSuper->getEpisodus()) && (pSuper->getEpisodus()->bAutoOpenLdV))
  LdV_show() ;

	// Ouverture du gestionnaire de RC
#ifndef __EPIBRAIN__
	if (pSuper->getDPIO() && (pSuper->getDPIO()->sNomModule.find("SCMG") != string::npos))
  	dvManager.createView(pDocLdv, "RC view Format") ;
#endif // !__EPIBRAIN__

	// Initialisation du blackboard FIXME
	reinitBlackboard(pContexte) ;
	pProgressDlg->Destroy() ;
	delete pProgressDlg ;

	// bool  bDPIO = false ;
	// bool  bRVDB = false ;

	// Lancement de DPIO
#ifndef __EPIBRAIN__
	if ((pSuper->getDPIO()) && (pSuper->getDPIO()->bDPIOactif))
	{
		pSuper->getDPIO()->PatOpening() ;
		//    DPIO(pContexte) ;
		// bDPIO = true ;
	}
#endif // !__EPIBRAIN__

	// lancement de RVDB
	/*
	if ((pSuper->getDPIO()) && (pSuper->getDPIO()->bRVDBactif))
	{
		//    RVDB(pContexte) ;
		bRVDB = true ;
	}
	*/

	if (NULL != pContexte->pMailBoxWindow)
  	pContexte->pMailBoxWindow->SetFocus() ;

	ps = "Initialisation patient choisi termin�e.\n" ;
	pSuper->trace(&ps, 1) ;

#endif // !__EPIBRAIN__
#endif // !__EPIPUMP__
}
catch (...)
{
	erreur("Exception NSPatientChoisi::Initialisation.", standardError, 0) ;
}
}

void
NSPatientChoisi::PostInitialisation()
{
try
{
	string sLang("") ;
  if (NULL != pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  // On fixe les donn�es de la Caption � cet endroit
  // calcul de l'age du patient
  // char    szDateNaiss[9] ;
  // int     age = -1 ;
  // char    szAge[4] ;  // char    szDateJour[10] ;  if (getContribution() == "")    CreeContribution() ;  // on fabrique le nom long  pContexte->getPatient()->fabriqueNomLong() ;

  pContexte->setMainCaption() ;

  // Synchronizing mail box
  //
	if ((NULL != pContexte->pMailBoxWindow) && (NULL != pContexte->pMailBoxWindow->getList()))
  	pContexte->pMailBoxWindow->getList()->selectCurrentPatientFirstMessage() ;
}
catch (...)
{
	erreur("Exception NSPatientChoisi::PostInitialisation.", standardError, 0) ;
}
}

void
NSPatientChoisi::ChargeDonneesPatient(NSPatPathoArray* pPatPathoArray)
{
try
{
  if ((NULL == pPatPathoArray) || (pPatPathoArray->empty()))
    return ;
  //
  // On part du principe que les donn�es qui nous int�ressent sont dans un
  // sous chapitre LIDET (identit�)
  // On pourrait imaginer prendre les premi�res valeurs "nom", "pr�nom"...
  // rencontr�es
  //
  // We suppose that the values we need are in a sub-chapter LIDET (identity)
  // We could imagine we take the first encoutered "1st name", "2nd name"... values
  //
  string          sElemLex, sSens, sType ;

  string sNom    = "" ;
  string sPrenom = "" ;
  string sNomJF  = "" ;
  string sCode   = "" ;

  string sTemp   = "" ;

  PatPathoIter iter = pPatPathoArray->begin() ;
  int iColBase = (*iter)->getColonne() ;
  iter++ ;

  while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColBase))
  {
    sSens = (*iter)->getLexiqueSens(pContexte) ;

    // Chapitre "identit�" / Identity chapter
    //
    if (string("LIDET") == sSens)
    {
      int iColIdentity = (*iter)->getColonne() ;
      iter++ ;

      while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity))
      {
        sSens = (*iter)->getLexiqueSens(pContexte) ;

        // Nom du patient
        // Patient's name
        if ((sSens == string("LNOM0")) && (string("") == sNom))
        {
          iter++ ;
          while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity+1))
          {
            // on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 3) == string("�CL"))
            {
              sNom = (*iter)->getTexteLibre() ;
              pDonnees->sNom = sNom ;
            }
            iter++ ;
          }
        }
        // Pr�nom du patient
        // Patient's second name
        else if ((string("LNOM2") == sSens) && (sPrenom == ""))
        {
          iter++ ;
          while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity+1))
          {
            // on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 3) == string("�CL"))
            {
              sPrenom = (*iter)->getTexteLibre() ;
              pDonnees->sPrenom = sPrenom ;
            }
            iter++ ;
          }
        }
        // Nom de jeune fille du patient
        // Patient's maiden name
        else if ((string("LNOM1") == sSens) && (string("") != sNomJF))
        {
          iter++ ;
          while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity+1))
          {
            // on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 3) == string("�CL"))
            {
              sNomJF = (*iter)->getTexteLibre() ;
              pDonnees->sNomJeuneFille = sNomJF ;
            }
            iter++ ;
          }
        }
        // Code patient
        // Patient's code
        else if ((string("LCOD0") == sSens) && (string("") == sCode))
        {
          iter++ ;
          while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity+1))
          {
            // on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 3) == string("�CL"))
            {
              sCode = (*iter)->getTexteLibre() ;
              pDonnees->sCode = sCode ;
            }
            iter++ ;
          }
        }
        // Sexe du patient
        // Patient's sex
        else if (string("LSEXE") == sSens)
        {
          iter++ ;
          while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity+1))
          {
            // on cherche ici un code lexique
            sElemLex = (*iter)->getLexique() ;
            pContexte->getDico()->donneCodeSens(&sElemLex, &sTemp) ;

            if      (string("HMASC") == sTemp)
              pDonnees->metMasculin();
            else if (string("HFEMI") == sTemp)
              pDonnees->metFeminin();

            iter++ ;

            while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity + 2))
            {
              sElemLex = string((*iter)->getLexique()) ;
              pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

              // Civilit�
              if (string("HCIVO") == sSens)
              {
                iter++ ;
                while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity + 3))
                {
                  // on cherche ici un code lexique pour un libelle
                  string sCodeLex = string((*iter)->getLexique()) ;
                  pDonnees->sCivilite = sCodeLex ;
                  iter++ ;
                }
              }
              else
                iter++ ;
            }
          }
        }
        else if (string("KNAIS") == sSens)
        {
          iter++ ;
          while ((pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColIdentity+1))
          {
            string sUnite  = (*iter)->getUnitSens(pContexte) ;
            string sFormat = (*iter)->getLexiqueSens(pContexte) ;
            string sValeur = (*iter)->getComplement() ;

            if ((string("2DA01") == sUnite) || (string("2DA02") == sUnite))
              pDonnees->sNaissance = sValeur ;

            iter++ ;
          }
        }
        else
          iter++ ;
      }
    }
    else
      iter++ ;
  }
}
catch (...)
{
	erreur("Exception NSPatientChoisi::ChargeDonneesPatient.", standardError, 0) ;
}
}

void
NSPatientChoisi::PatientDataChanged(NSPatPathoArray *pPatPathoArray)
{
  ChargeDonneesPatient(pPatPathoArray) ;
  pContexte->setMainCaption() ;

  //
  //
  NSPersonInfo* pPersonInfo = pContexte->getPersonArray()->lookForPersonInArray(getNss()) ;
  if (NULL != pPersonInfo)
  {
    string sCode ;
    string sSex ;

    pGraphPerson->ChargeDonneesAdmin(pPatPathoArray, pPersonInfo->sNom, pPersonInfo->sPrenom, sCode, sSex, pPersonInfo->sNaissance, pPersonInfo->sCivilite) ;

    if      (string("1") == sSex)
      pPersonInfo->metMasculin() ;
    else if (string("2") == sSex)
      pPersonInfo->metFeminin() ;

    pPersonInfo->updateCalculatedValues(pGraphPerson, pidsPatient) ;
  }

  //
  //
  if (NULL != pDocLdv)
    pDocLdv->invalidateViews("MISCELLANOUS") ;
}

bool
NSPatientChoisi::etablirLiensTree(bool &bCreerMetaLien, string sNodeMeta, string sNodeData)
{
	// if (pDocRoot->NSNoyauDocument::bCreerMetaLien)
  if (bCreerMetaLien)
  {
  	NSLinkManager Link(pContexte, pGraphPerson->pDataGraph) ;
    if (!Link.etablirLien(sNodeMeta, NSRootLink::docData, sNodeData))    {
    	erreur("Impossible de faire le lien vers le document data.", standardError, 0) ;
      return false ;
    }    bCreerMetaLien = false ;
  }
  else if ( sNodeMeta!= "")             // sCodeDocMeta
  {  	// Note : le lien contributionModified ne peut s'�tablir que la deuxi�me fois    // qu'on enregistre les donn�es, car la premi�re fois bCreerMetaLien est true.    string sContribution = pContexte->getPatient()->getContribution() ;    NSLinkManager Link(pContexte, pGraphPerson->pDataGraph) ;    if (!Link.existeLien(sNodeMeta, NSRootLink::contributionModified, sContribution))    {    	// lien du m�ta vers la contribution en cours      if (!Link.etablirLien(sNodeMeta, NSRootLink::docData, sNodeData))      {
      	string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "cannotEstablishALinkWithTheContribution") ;
        pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
        erreur(sErrorText.c_str(), standardError, 0) ;
        return false ;
      }    }  }
  return true ;
}

// Cr�ation du noeud racine patient
////////////////////////////////////
bool
NSPatientChoisi::CreeRootNode()
{
	// ---------------------------------------------------------------------------
  // Cr�ation du noeud personne
	// Person node creation

  NSRefDocument DocRoot(0, 0, 0, pContexte, false) ;
	DocRoot.pPatPathoArray->ajoutePatho("HHUMA3", 0) ;
	string sIdRoot = pGraphPerson->getRootTree() ;
  string sRootDoc = sIdRoot.substr(7, 6) ;

  if (!DocRoot.Referencer("ZCS00", "Noeud racine patient", "", "", false, false, sRootDoc, NSRootLink::personDocument, 0, ""))
  	return false ;

  string sRootDocData = pGraphPerson->pDataGraph->getLastTree() ;
  pGraphPerson->setTree(DocRoot.pPatPathoArray, "", sRootDocData) ;

  // etablir lien ZA
  // bool *pCreerMetaLien = &(DocRoot.NSNoyauDocument::bCreerMetaLien) ;
  // etablirLiensTree(pCreerMetaLien, DocRoot.sCodeDocMeta, sRootDocData) ;

  etablirLiensTree(DocRoot.NSNoyauDocument::bCreerMetaLien, DocRoot.sCodeDocMeta, sRootDocData) ;

	return true ;
}

// Cr�ation de l'index de sant�
//////////////////////////////////
bool
NSPatientChoisi::CreeRootIndex()
{
	// ---------------------------------------------------------------------------
  // Cr�ation de l'index de sant�
	// Health index creation

	// Ne pas passer pDocInfo dans le cteur pour �viter qu'il essaie de charger la
	// patpatho
	NSRefDocument	PbIndex(0, 0, 0, pContexte, false) ;
  bool bIndexCreated = PbIndex.createLdvFrame(pGraphPerson) ;
  if (false == bIndexCreated)
    return false ;

  NSRefDocument	PbRisk(0, 0, 0, pContexte, false) ;
  return PbRisk.createRiskFrame(pGraphPerson) ;

/*
	PbIndex.pPatPathoArray->ajoutePatho("ZPOMR1", 0, 0) ;

	// ajout des pr�occupations de Sant� dans l'index de Sant�
	PbIndex.pPatPathoArray->ajoutePatho("0PRO11", 1, 1) ;

	// ajout des objectifs de Sant� dans l'index de Sant�
	PbIndex.pPatPathoArray->ajoutePatho("0OBJE1", 1, 1) ;

  // ajout des traitements dans l'index de Sant�
	PbIndex.pPatPathoArray->ajoutePatho("N00001", 1, 1) ;

	if (!PbIndex.Referencer("ZCS00", "Index de sant�", "", "", true, false, "", NSRootLink::personHealthIndex, 0, ""))
		return false ;

	// le code est etabli dans la methode referencer
  string sRootDocData = pGraphPerson->pDataGraph->getLastTree() ;
  pGraphPerson->setTree(PbIndex.pPatPathoArray, "", sRootDocData) ;

  // etablir lien ZA entre les metaDonn�es et les donn�es.
  // bool *pCreerMetaLien = &(PbIndex.NSNoyauDocument::bCreerMetaLien) ;
  // etablirLiensTree(pCreerMetaLien, PbIndex.sCodeDocMeta, sRootDocData) ;

  etablirLiensTree(PbIndex.NSNoyauDocument::bCreerMetaLien, PbIndex.sCodeDocMeta, sRootDocData) ;

	return true ;
*/
}

// Cr�ation de la fiche de synth�se
/////////////////////////////////////
bool
NSPatientChoisi::CreeRootSynthese()
{
	// ---------------------------------------------------------------------------
  // Cr�ation de la fiche de synth�se
	// Synthesis creation

  NSRefDocument DocSynth(0, 0, 0, pContexte, false) ;
  return DocSynth.createSynthesisFrame(pGraphPerson) ;

/*
	DocSynth.pPatPathoArray->ajoutePatho("ZSYNT1", 0, 0) ;

	if (!DocSynth.Referencer("ZCS00", "Fiche de synth�se", "", "", true, false, "", NSRootLink::personSynthesis, 0, ""))
		return false ;

  //le code est etabli dans la methode referencer
  string sRootDocData = pGraphPerson->pDataGraph->getLastTree() ;
  pGraphPerson->setTree(DocSynth.pPatPathoArray, "", sRootDocData) ;

  //etablir lien ZA entre les metaDonn�es et les donn�es.
  // bool *pCreerMetaLien = &(DocSynth.NSNoyauDocument::bCreerMetaLien) ;
  // etablirLiensTree(pCreerMetaLien, DocSynth.sCodeDocMeta, sRootDocData) ;

  etablirLiensTree(DocSynth.NSNoyauDocument::bCreerMetaLien, DocSynth.sCodeDocMeta, sRootDocData) ;

	return true ;
*/
}

// Cr�ation de la fiche administrative
////////////////////////////////////////
bool
NSPatientChoisi::CreeRootAdmin(NSPatPathoArray *pPatPathoAdmin)
{
	// ---------------------------------------------------------------------------
  // Cr�ation de l'arbre administratif
  // Administrative Tree creation

  NSRefDocument DocAdmin(0, 0, 0, pContexte, false) ;
	*(DocAdmin.pPatPathoArray) = *pPatPathoAdmin ;

	if (!DocAdmin.Referencer("ZCQ00", "Fiche administrative", "", "", true, false, "", NSRootLink::personAdminData, 0, ""))
  	return false ;

  // le code est etabli dans la methode referencer
  string sRootDocData = pGraphPerson->pDataGraph->getLastTree() ;
  pGraphPerson->setTree(DocAdmin.pPatPathoArray, "", sRootDocData) ;

  // etablir lien ZA entre les metaDonn�es et les donn�es.
  // bool *pCreerMetaLien = &(DocAdmin.NSNoyauDocument::bCreerMetaLien) ;
  // etablirLiensTree(pCreerMetaLien, DocAdmin.sCodeDocMeta, sRootDocData) ;

  etablirLiensTree(DocAdmin.NSNoyauDocument::bCreerMetaLien, DocAdmin.sCodeDocMeta, sRootDocData) ;

	return true ;
}

// Cr�ation de la biblioth�que de chemises (folders)
/////////////////////////////////////////////////////
bool
NSPatientChoisi::CreeRootLibChem()
{
  // ---------------------------------------------------------------------------
  // Cr�ation de l'arbre-biblioth�que de chemises
  // "chemises" library tree creation

  NSRefDocument LibChem(0, 0, 0, pContexte, false) ;
  return LibChem.createFoldersLibrary(pGraphPerson) ;

/*
	char szDateJour[10] ;
  donne_date_duJour(szDateJour) ;

	LibChem.pPatPathoArray->ajoutePatho("0LIBC1", 0, 0) ;

	// ajout de la chemise corbeille
  // Note : cette chemise doit �tre cr��e en premier afin que la chemise par d�faut
  // soit s�lectionn�e plus tard dans EnregDocDialog (on s�lectionne la derni�re chemise)
	LibChem.pPatPathoArray->ajoutePatho("0CHEM1", 1, 1) ;

	// Intitul� : nom de la chemise
  LibChem.pPatPathoArray->ajoutePatho("0INTI1", 2, 1) ;
  Message *pMessage = new Message("", "", "", "A", "", "", "") ;
  pMessage->SetTexteLibre("corbeille") ;
  LibChem.pPatPathoArray->ajoutePatho("�?????", pMessage, 3, 1) ;
  delete pMessage ;

  // Date d'ouverture
  LibChem.pPatPathoArray->ajoutePatho("KOUVR1", 2, 1) ;
  string sDateCreation = string(szDateJour) + string("000000") ;
  pMessage = new Message("", "", "", "A", "", "", "") ;
  pMessage->SetUnit("2DA021") ;
  pMessage->SetComplement(sDateCreation.c_str()) ;
  LibChem.pPatPathoArray->ajoutePatho("�T0;19", pMessage, 3, 1) ;
  delete pMessage ;

  // ajout de la chemise par d�faut
	LibChem.pPatPathoArray->ajoutePatho("0CHEM1", 1, 1) ;

	// Intitul� : nom de la chemise
  LibChem.pPatPathoArray->ajoutePatho("0INTI1", 2, 1) ;
  pMessage = new Message("", "", "", "A", "", "", "") ;
  pMessage->SetTexteLibre("d�faut") ;
  LibChem.pPatPathoArray->ajoutePatho("�?????", pMessage, 3, 1) ;
  delete pMessage ;

  // Date d'ouverture
  LibChem.pPatPathoArray->ajoutePatho("KOUVR1", 2, 1) ;
  pMessage = new Message("", "", "", "A", "", "", "") ;
  pMessage->SetUnit("2DA021") ;
  pMessage->SetComplement(sDateCreation.c_str()) ;
  LibChem.pPatPathoArray->ajoutePatho("�T0;19", pMessage, 3, 1) ;
  delete pMessage ;

	if (!LibChem.Referencer("ZCS00", "Biblioth�que de chemises", "", "", true, false, "", NSRootLink::personFolderLibrary, 0, ""))
  	return false ;

  // le code est etabli dans la methode referencer
  string sRootDocData = pGraphPerson->pDataGraph->getLastTree() ;
  pGraphPerson->setTree(LibChem.pPatPathoArray, "", sRootDocData) ;

  // etablir lien ZA entre les metaDonn�es et les donn�es.
  // bool *pCreerMetaLien = &(LibChem.NSNoyauDocument::bCreerMetaLien) ;
  // etablirLiensTree(pCreerMetaLien, LibChem.sCodeDocMeta, sRootDocData) ;

  etablirLiensTree(LibChem.NSNoyauDocument::bCreerMetaLien, LibChem.sCodeDocMeta, sRootDocData) ;

	return true ;
*/
}

// Creating identifiers library
// Cr�ation de la biblioth�que d'identifiants
/////////////////////////////////////////////////////
bool
NSPatientChoisi::CreeRootLibIDs()
{
  NSRefDocument DocLibId(0, 0, 0, pContexte, false) ;
  return DocLibId.createIdentifiersFrame(pGraphPerson) ;

/*
	DocLibId.pPatPathoArray->ajoutePatho("0LIBI1", 0, 0) ;

	if (false == DocLibId.Referencer("ZCS00", "Identifiants", "", "", true, false, "", NSRootLink::personIdentifiers))
		return false ;

  //le code est etabli dans la methode referencer
  string sRootDocData = pGraphPerson->pDataGraph->getLastTree() ;
  pGraphPerson->setTree(DocLibId.pPatPathoArray, "", sRootDocData) ;

  //etablir lien ZA entre les metaDonn�es et les donn�es.
  // bool *pCreerMetaLien = &(DocLibId.NSNoyauDocument::bCreerMetaLien) ;
  // etablirLiensTree(pCreerMetaLien, DocLibId.sCodeDocMeta, sRootDocData) ;

  etablirLiensTree(DocLibId.NSNoyauDocument::bCreerMetaLien, DocLibId.sCodeDocMeta, sRootDocData) ;

	return true ;
*/
}

// -----------------------------------------------------------------------------
// Description	: Cr�e tous les documents root d'un nouveau patient :
//									* Noeud personne
//									* index de sant�
//									* fiche de synth�se
//									* arbre administratif
//									* arbre Equipe de Sant�
// Initialise le graphe de liaison entre ces documents
// --
// Returns			: True->Succ�s False->Echec
// -----------------------------------------------------------------------------
// Description	: Create root documents for a new petient :
//									* person node
//									* health index
//									* Synthesis
//									* administrative tree
//									* health team tree (with just the patient himself)
// Initialize already the graph of links between documents.
// --
// Returns			: if success true else false
// -----------------------------------------------------------------------------
bool
NSPatientChoisi::CreeRootDocs(NSPatPathoArray *pPatPathoAdmin)
{
try
{
	NSDocumentInfo DocInfo(pContexte) ;
  string sCodeDocum ;
  char szDateJour[10] ;

  donne_date_duJour(szDateJour) ;

	if (!CreeRootNode())
  	return false ;

	CreeContribution(true) ;

  if (!CreeRootLibChem())
  	return false ;

	if (!CreeRootIndex())
  	return false ;

  if (!CreeRootSynthese())
  	return false ;

  if (!CreeRootAdmin(pPatPathoAdmin))
  	return false ;

	return true ;
}
catch (...)
{
	erreur("Exception CreeRootDocs.", standardError, 0) ;
	return false ;
}
}

bool
NSPatientChoisi::IsDocRoot(string sCodeDoc)
{
	string sNss = string(sCodeDoc, 0, PAT_NSS_LEN) ;
  string sNodeRoot = sNss + string("_") + string(DOC_CODE_DOCUM_LEN - 1, '0') ;

	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	bool bResult = false ;
  if ((sCodeDoc == sNodeRoot) ||
        (pGraphe->existeLien(sNodeRoot, NSRootLink::personHealthIndex, sCodeDoc)) ||
        (pGraphe->existeLien(sNodeRoot, NSRootLink::personSynthesis, sCodeDoc)) ||
        (pGraphe->existeLien(sNodeRoot, NSRootLink::personAdminData, sCodeDoc)) ||
        (pGraphe->existeLien(sNodeRoot, NSRootLink::personFolderLibrary, sCodeDoc)) ||
        (pGraphe->existeLien(sNodeRoot, NSRootLink::personHealthTeam, sCodeDoc)))
		bResult = true ;

	return bResult ;
}

bool
NSPatientChoisi::CreeElementFromRef(string sDestinationPath, NSPatPathoArray *pPatPatho, string sDocument, string sRefId, string sProposalId, NSPatPathoArray *pPatPathoMotif, string sConcern)
{
try
{
#ifndef __EPIPUMP__
	if ((NULL == pPatPatho) || (pPatPatho->empty()))
		return true ;

	if (string("") == sDestinationPath)
		return true ;

  ClasseStringVector Vect ;
	DecomposeChaine(&sDestinationPath, &Vect, "/") ;
  if (Vect.empty())
  	return FAILURE ;

	iterString iterpVect = Vect.begin() ;
	string sTargetDoc = (*iterpVect)->sItem ;

	// NSPatPathoArray* pPathoIndex = 0 ;

	// Can we work ?
	if (!pDocHis)
	{
		erreur("Erreur grave (historique introuvable). Vous devriez relancer le logiciel.", standardError, 0) ;
		return false;
	}
	if (pDocHis->VectDocument.empty())
	{
		erreur("Erreur grave (historique vide). Vous devriez relancer le logiciel.", standardError, 0) ;
		return false;
	}

	// Recherche du document
	// Looking for the document
	DocumentIter iterDoc ;

	bool bSearchIndex = true ;
	while (bSearchIndex)
	{
		bool bContinuer = true ;
		iterDoc = pDocHis->VectDocument.begin() ;
		while ((iterDoc != pDocHis->VectDocument.end()) && bContinuer)
		{
    	if (((*iterDoc)->pPatPathoArray) && (!((*iterDoc)->pPatPathoArray->empty())))
      {
      	PatPathoIter iter = (*iterDoc)->pPatPathoArray->begin() ;
        string sRootSens = (*iter)->getLexiqueSens(pContexte) ;
        if (sRootSens == sTargetDoc)
        	bContinuer = false ;
        else
        	iterDoc++ ;
      }
      else
      	iterDoc++ ;
		}

		// Document non trouv� - Document not found
		if (iterDoc == pDocHis->VectDocument.end())
		{
			// En MUE on signale une erreur car l'index de sant� est normalement cr��
      // lors de l'initialisation du patient (m�thode NSPatientChoisi::CreeRootDocs())
      ::MessageBox(pContexte->GetMainWindow()->GetHandle(),
           "Ce patient ne semble pas avoir de document des Index de sant�.",
           "Attention", MB_OK) ;

      return false ;
		}
		else
			bSearchIndex = false;
	}

    // ???????????????????
	if (iterDoc == pDocHis->VectDocument.end())
		return false ;

	// Document found
	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *((*iterDoc)->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;

	NSPatPathoArray* pPt = Noyau.pPatPathoArray ;

	// On cherche le chapitre
  iterpVect++ ;
  string sTargetChapter = (*iterpVect)->sItem ;
	PatPathoIter iter = pPt->ChercherItem(sTargetChapter) ;

	if ((iter == NULL) || (iter == pPt->end()))
	{
		erreur("Erreur grave : le document Index de sant� de ce patient ne poss�de pas de chapitre Objectifs de sant�.", standardError, 0) ;
		return false ;
	}

	// Ajout d'un nouveau segment d'arbre
	// Adding a new tree branch
	// Ajout de la branche � l'arbre Index de sant�
	// Adding the branch to the Health index tree

	// On cherche o� il faut ins�rer la branche
	// Looking for the place to insert the branch
	int colonneMere = (*iter)->getColonne() ;
	iter++ ;
	while ((pPt->end() != iter) && ((*iter)->getColonne() > colonneMere))
  {
  	// on v�rifie si un fils identique existe d�j�
    if ((*iter)->getColonne() == (colonneMere + 1))
    {
    	if (!strcmp((*iter)->pDonnees->lexique, (*(pPatPatho->begin()))->pDonnees->lexique))
      {
        string sLangue = pContexte->getUtilisateur()->donneLang() ;
        string sCodeLex = (*iter)->getLexique() ;
        string sLibelle ;
        pContexte->getDico()->donneLibelle(sLangue, &sCodeLex, &sLibelle) ;
      }
    }

    iter++ ;
  }

  //
  // On cherche un(les) �l�ment calcul�(s)
  //
  NSPatPathoArray pptCopy(pContexte) ;
  LocalPatho(pPatPatho, &pptCopy) ;

  if (pptCopy.empty())
  	return false ;

  //
  // On ins�re l'identifiant d'objectif au sein du r�f�rentiel
  //
  if ((sProposalId != "") && (strlen(sProposalId.c_str()) <= BASE_COMPLEMENT_LEN))
  {
  	PatPathoIter iterRoot = pptCopy.begin() ;

    int iLocalRootCol = (*iterRoot)->getColonne() ;

    iterRoot++ ;

    Message* pCodeMsg = new Message("") ;
    pCodeMsg->SetLexique("�REFC1");
    pCodeMsg->SetComplement(sProposalId);
    int iDecalLigne ;
    if (iterRoot != pptCopy.end())
    	iDecalLigne = 0 ;
    else
    	iDecalLigne = 1 ;
    pptCopy.ajoutePatho(iterRoot, "�REFC1", pCodeMsg, iLocalRootCol+1, iDecalLigne, true);
    delete pCodeMsg;
  }

  // on note ici la position en ligne et colonne de l'�l�ment que l'on va ins�rer
  int ligneIns, colonneIns;

  if (iter != pPt->end())
  {
  	ligneIns = (*iter)->getLigne() ;
    colonneIns = colonneMere + 1 ;
  }
  else
  {
  	PatPathoIter iterEnd = iter ;
    iterEnd-- ;
    ligneIns = (*iterEnd)->getLigne() + 1 ;
    colonneIns = colonneMere + 1 ;
  }

  // Insertion de l'�l�ment
  pPt->InserePatPatho(iter, &pptCopy, colonneIns) ;

	pContexte->getPatient()->pGraphPerson->setTree(pPt, "") ;

	PatPathoIter itRoot = pPt->ChercherItem(ligneIns, colonneIns);

	if ((itRoot == NULL) || (itRoot == pPt->end()))
	{
		erreur("Erreur grave : l'�l�ment n'a pas �t� correctement enregistr�.", standardError, 0) ;
		return false;
	}

	string sNoeud  = (*itRoot)->getNode();

	//
	// Lien entre le noeud et son document cr�ateur
	//
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
  if (sDocument != "")
  	pGraphe->etablirLien(sDocument, NSRootLink::refCreator, sNoeud) ;
	//
	// Lien entre le noeud et le r�f�rentiel
	//
	if (sRefId != "")
	{
		string sRefNode = pContexte->getArcManager()->DonneNoeudArchetype(NSArcManager::referentiel, sRefId) ;
		if (sRefNode != "")
			pGraphe->etablirLien(sRefNode, NSRootLink::referentialOf, sNoeud) ;
	}

	//
	// Lien entre le noeud et la pr�occupation de sant� qu'il concerne (plusieurs ?)
	//
  if (string("") != sConcern)
  {
    if      (string("ZPOMR/N0000") == sDestinationPath)
      pGraphe->etablirLien(sNoeud, NSRootLink::drugOf, sConcern) ;
    else if (string("ZPOMR/0OBJE") == sDestinationPath)
      pGraphe->etablirLien(sNoeud, NSRootLink::problemGoals, sConcern) ;
  }
  else if (string("") != sDocument)
  {
  	VecteurString aVecteurString ;
    pGraphe->TousLesVraisDocument(sDocument, NSRootLink::problemRelatedTo, &aVecteurString) ;
    if (!aVecteurString.empty())
    {
    	string sPrimoPb =  *(*(aVecteurString.begin())) ;

      if      (string("ZPOMR/N0000") == sDestinationPath)
        pGraphe->etablirLien(sNoeud, NSRootLink::drugOf, sPrimoPb) ;
      else if (string("ZPOMR/0OBJE") == sDestinationPath)
        pGraphe->etablirLien(sNoeud, NSRootLink::problemGoals, sPrimoPb) ;
    }
  }

	// Enregistrement du document modifi�
	Noyau.enregistrePatPatho() ;

	// Mise � jour de l'historique
	Noyau.chargePatPatho();
	pPt = Noyau.pPatPathoArray;
	pDocHis->Rafraichir(&Docum, pPt);

	if (pPt->empty())
	{
		erreur("Erreur grave : l'�l�ment n'a pas �t� correctement enregistr�.", standardError, 0) ;
		return false ;
	}

  if (string("ZPOMR/N0000") == sDestinationPath)
  {
    // Prise en compte du  sur la Ligne de vie
    pDocLdv->getDrugs()->loadDrugs(pPt, itRoot, (*itRoot)->getColonne() - 1, true /*bJustOne*/) ;
    pDocLdv->showNewDrug(pPt, itRoot) ;
  }

#endif // !__EPIPUMP__

	return true ;
}
catch (...)
{
	erreur("Exception CreeElementFromRef.", standardError, 0) ;
	return false;
}
}

bool
NSPatientChoisi::CreeObjectif(NSPatPathoArray* pPatPatho, string sDocument, string sRefId, string sGoalId, NSPatPathoArray* pPatPathoMotif, string sGoal)
{
try
{
#ifndef __EPIPUMP__
	if ((!pPatPatho) || (pPatPatho->empty()))
		return true ;

	// NSPatPathoArray* pPathoIndex = 0 ;

	// Can we work ?
	if (!pDocHis)
	{
		erreur("Erreur grave (historique introuvable). Vous devriez relancer le logiciel.", standardError, 0) ;
		return false;
	}
	if (pDocHis->VectDocument.empty())
	{
		erreur("Erreur grave (historique vide). Vous devriez relancer le logiciel.", standardError, 0) ;
		return false;
	}

	// Recherche du document "Index de sant�"
	// Looking for "Health index" document
	DocumentIter iterDoc ;

	bool bSearchIndex = true ;
	while (bSearchIndex)
	{
		bool bContinuer = true ;
		iterDoc = pDocHis->VectDocument.begin() ;
		while ((iterDoc != pDocHis->VectDocument.end()) && bContinuer)
		{
    	if (((*iterDoc)->pPatPathoArray) && (!((*iterDoc)->pPatPathoArray->empty())))
      {
      	PatPathoIter iter = (*iterDoc)->pPatPathoArray->begin() ;
        if (strcmp((*iter)->pDonnees->lexique, "ZPOMR1") == 0)
        	bContinuer = false ;
        else
        	iterDoc++ ;
      }
      else
      	iterDoc++ ;
		}

		// Index de sant� non trouv� - Health index not found
		if (iterDoc == pDocHis->VectDocument.end())
		{
			// En MUE on signale une erreur car l'index de sant� est normalement cr��
      // lors de l'initialisation du patient (m�thode NSPatientChoisi::CreeRootDocs())
      ::MessageBox(pContexte->GetMainWindow()->GetHandle(),
           "Ce patient ne semble pas avoir de document des Index de sant�.",
           "Attention", MB_OK) ;

      return false ;
		}
		else
			bSearchIndex = false;
	}

    // ???????????????????
	if (iterDoc == pDocHis->VectDocument.end())
		return false ;

	// Health index found
	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *((*iterDoc)->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;

	NSPatPathoArray* pPt = Noyau.pPatPathoArray ;

	// On cherche le chapitre "objectifs de sant�"
	PatPathoIter iter = pPt->ChercherItem("0OBJE1") ;

	if ((iter == NULL) || (iter == pPt->end()))
	{
		erreur("Erreur grave : le document Index de sant� de ce patient ne poss�de pas de chapitre Objectifs de sant�.", standardError, 0) ;
		return false ;
	}

	// Ajout d'un nouveau segment d'arbre
	// Adding a new tree branch
	// Ajout de la branche � l'arbre Index de sant�
	// Adding the branch to the Health index tree

	// On cherche o� il faut ins�rer la branche
	// Looking for the place to insert the branch
	int colonneMere = (*iter)->getColonne() ;
	iter++ ;
	while ((iter != pPt->end()) && ((*iter)->getColonne() > colonneMere))
  {
  	// on v�rifie si un fils identique existe d�j�
    if ((*iter)->getColonne() == (colonneMere + 1))
    {
    	if (!strcmp((*iter)->pDonnees->lexique, (*(pPatPatho->begin()))->pDonnees->lexique))
      {
        string sLangue = pContexte->getUtilisateur()->donneLang() ;
        string sCodeLex = (*iter)->getLexique() ;
        string sLibelle ;
        pContexte->getDico()->donneLibelle(sLangue, &sCodeLex, &sLibelle) ;
/*
				char msg[255] ;
        sprintf(msg, "L'objectif \"%s\" existe d�j� pour ce patient. Voulez-vous en ins�rer un autre ?", sLibelle.c_str()) ;
        int iRetVal = ::MessageBox(pContexte->GetMainWindow()->GetHandle(),
                                    msg, "Attention", MB_YESNO) ;

				if (iRetVal != IDYES)
					return true ;
*/
      }
    }

    iter++ ;
  }

  //
  // On cherche un(les) �l�ment calcul�(s)
  //
  NSPatPathoArray pptCopy(pContexte) ;
  LocalPatho(pPatPatho, &pptCopy) ;

  if (pptCopy.empty())
  	return false ;

  //
  // On ins�re l'identifiant d'objectif au sein du r�f�rentiel
  //
  if ((sGoalId != "") && (strlen(sGoalId.c_str()) <= BASE_COMPLEMENT_LEN))
  {
  	PatPathoIter iterRoot = pptCopy.begin() ;

    int colonneMere = (*iterRoot)->getColonne() ;

    iterRoot++ ;

    Message* pCodeMsg = new Message("") ;
    pCodeMsg->SetLexique("�REFC1");
    pCodeMsg->SetComplement(sGoalId);
    int iDecalLigne ;
    if (iterRoot != pptCopy.end())
    	iDecalLigne = 0 ;
    else
    	iDecalLigne = 1 ;
    pptCopy.ajoutePatho(iterRoot, "�REFC1", pCodeMsg, colonneMere+1, iDecalLigne, true);
    delete pCodeMsg;
  }

  // on note ici la position en ligne et colonne de l'�l�ment que l'on va ins�rer
  int ligneIns, colonneIns;

  if (iter != pPt->end())
  {
  	ligneIns = (*iter)->getLigne() ;
    colonneIns = colonneMere + 1 ;
  }
  else
  {
  	PatPathoIter iterEnd = iter ;
    iterEnd-- ;
    ligneIns = (*iterEnd)->getLigne() + 1 ;
    colonneIns = colonneMere + 1 ;
  }

  // Insertion de l'objectif
  pPt->InserePatPatho(iter, &pptCopy/*pPatPatho*/, colonneIns) ;

	pContexte->getPatient()->pGraphPerson->setTree(pPt, "") ;

	PatPathoIter    itRoot  = pPt->ChercherItem(ligneIns, colonneIns);

	if ((itRoot == NULL) || (itRoot == pPt->end()))
	{
		erreur("Erreur grave : l'objectif de sant� n'a pas �t� correctement enregistr�.", standardError, 0) ;
		return false;
	}

	string sNoeud  = (*itRoot)->getNode();

	//
	// Lien entre le noeud et son document cr�ateur
	//
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
  if (sDocument != "")
  	pGraphe->etablirLien(sDocument, NSRootLink::refCreator, sNoeud) ;
	//
	// Lien entre le noeud et le r�f�rentiel
	//
	if (sRefId != "")
	{
		string sRefNode = pContexte->getArcManager()->DonneNoeudArchetype(NSArcManager::referentiel, sRefId) ;
		if (sRefNode != "")
			pGraphe->etablirLien(sRefNode, NSRootLink::referentialOf, sNoeud) ;
	}

	//
	// Lien entre le noeud et la pr�occupation de sant� qu'il concerne (plusieurs ?)
	//
  if (sDocument != "")
  {
  	VecteurString aVecteurString ;
    pGraphe->TousLesVraisDocument(sDocument, NSRootLink::problemRelatedTo, &aVecteurString) ;
    if (!aVecteurString.empty())
    {
    	string sPrimoPb =  *(*(aVecteurString.begin()));
      pGraphe->etablirLien(sNoeud, NSRootLink::problemGoals, sPrimoPb);
    }
  }
  else if (sGoal != "")
  	pGraphe->etablirLien(sNoeud, NSRootLink::problemGoals, sGoal) ;

	// Enregistrement du document modifi�
	Noyau.enregistrePatPatho() ;

	// Mise � jour de l'historique
	/* bool bReload = */ Noyau.chargePatPatho();
	pPt = Noyau.pPatPathoArray;
	pDocHis->Rafraichir(&Docum, pPt);

	if (pPt->empty())
	{
		erreur("Erreur grave : l'objectif de sant� n'a pas �t� correctement enregistr�.", standardError, 0) ;
		return false ;
	}

	//
  // On reconstitue la pptCopy avec les bons num�ros de noeuds (il faut
  // l'extraire de l'index de sant�)
  // We have to rebuild pptCopy in order to get nodes ID (we have to get
  // it from health index)
  //

  NSPatPathoArray pptFille(pContexte);
  pPt->ExtrairePatPatho(itRoot, &pptFille) ;

  pptCopy.vider() ;

  NSPatPathoInfo racine = *(*itRoot) ;
  racine.setLigne(0) ;
  racine.setColonne(0) ;
  pptCopy.push_back(new NSPatPathoInfo(racine)) ;

  if (!(pptFille.empty()))
  {
  	PatPathoIter ssiter;    for (ssiter = pptFille.begin(); ssiter != pptFille.end(); ssiter++)
    {
    	(*ssiter)->setLigne((*ssiter)->getLigne() + 1) ;
      (*ssiter)->setColonne((*ssiter)->getColonne() + 1) ;
      pptCopy.push_back(new NSPatPathoInfo(*(*ssiter))) ;
    }
  }

  NSLdvGoal Goal(pContexte) ;
  PatPathoIter itPpt = itRoot ;
  Goal.initFromPatho(&pptCopy, &itPpt) ;

  // RegleObjectif(&Goal) ;
  pDocLdv->initGoal(&Goal) ;

#ifndef __EPIBRAIN__
  NSDPIO* pDPIO = pContexte->getSuperviseur()->getDPIO() ;
  pDPIO->sSendPage += string("<goal>\r\n") + pptCopy.genereXML() + string("</goal>\r\n") ;
#endif // !__EPIBRAIN__

  //
  // Prise en compte de l'objectif sur la Ligne de vie
  //
  pDocLdv->getGoals()->loadGoals(itRoot, (*itRoot)->getColonne() - 1, true /*bJustOne*/) ;
  pDocLdv->invalidateViews("GOAL_NEW") ;

#endif // !__EPIPUMP__

	return true ;
}
catch (...)
{
	erreur("Exception CreeObjectif.", standardError, 0) ;
	return false;
}
}

//
// Obsolete... use pDocLdv->initGoal(pGoal) instead
//
void
NSPatientChoisi::RegleObjectif(NSLdvGoal* pGoal)
{
#ifndef __EPIPUMP__
    // Objectif qui ne s'ouvre jamais
    if ((pGoal->sOpenEventNode == "") && (pGoal->tDateOuverture.estVide()))
        return ;

    //
    // On regarde si les conditions d'ouverture sont r�alis�es
    //
    NVLdVTemps tNow ;
    tNow.takeTime() ;
    // Date de fermeture d�j� atteinte : on sort
    if ((!(pGoal->tDateFermeture.estVide())) && (pGoal->tDateFermeture < tNow))
        return ;

    //
    // On regarde le document le plus r�cent du m�me type
    //
    string sNewConcept ;
    pContexte->getDico()->donneCodeSens(&(pGoal->sLexique), &sNewConcept) ;

    NVLdVTemps  tDateDoc ;
    tDateDoc.init() ;

    string sDocId = "" ;

    NSPatPathoArray* pPatPathoDoc = new NSPatPathoArray(pContexte) ;
    DocumentIter itDoc = pDocHis->DonnePatPathoDocument(sNewConcept, pPatPathoDoc) ;
    if ((itDoc != NULL) && (itDoc != pDocHis->VectDocument.end()))
    {
        string sDate = (*itDoc)->GetDateDoc() ;
        tDateDoc.initFromDate(sDate) ;

        PatPathoIter iter = pPatPathoDoc->begin() ;
        sDocId = (*iter)->getNode() ;
    }
    delete pPatPathoDoc ;

    //
    // Si l'objectif est ponctuel, on regarde si le document est dans les
    // dates pr�vues
    //
    if (!(pGoal->iRythme == NSLdvGoal::cyclic))
    {
        // Si il existe une date de d�but autoris�
        if (pGoal->sDateDebutAutorise != "")
        {
            NVLdVTemps tDateDebut ;
            tDateDebut.initFromDate(pGoal->sDateDebutAutorise) ;
            // Si le document est ant�rieur � la date de d�but autoris�, on ne
            // doit pas en tenir compte
            if (tDateDoc < tDateDebut)
                return ;
            // Sinon, le document ferme l'objectif
            pDocLdv->closeGoal(pGoal, &tNow, NULL) ;
            return ;
        }
        string sDateMin = "" ;
        if (pGoal->sDateDebutConseille != "")
            sDateMin = pGoal->sDateDebutConseille ;
        else
            if (pGoal->sDateDebutIdeal != "" )
                sDateMin = pGoal->sDateDebutIdeal ;
            else
                if (pGoal->sDateDebutIdealMax != "" )
                    sDateMin = pGoal->sDateDebutIdealMax ;
                else
                    if (pGoal->sDateDebutConseilMax != "" )
                        sDateMin = pGoal->sDateDebutConseilMax ;
                    else
                        if (pGoal->sDateDebutCritique != "" )
                            sDateMin = pGoal->sDateDebutCritique ;
        if (sDateMin == "")
            return ;

        // Sinon, le document ferme l'objectif
        NVLdVTemps tDateDebut ;
        tDateDebut.initFromDate(sDateMin) ;
        if (tDateDoc >= tDateDebut)
            pDocLdv->closeGoal(pGoal, &tNow, NULL) ;
        return ;
    }
    //
    // ------------------------- Objectif cyclique ------------------------
    //

  // On cherche s'il existe un �v�nement d'ouverture
  if (pGoal->sOpenEventNode != "")
  {
    string sEventConcept ;
    pContexte->getDico()->donneCodeSens(&(pGoal->sOpenEventNode), &sEventConcept) ;

    pPatPathoDoc = new NSPatPathoArray(pContexte) ;
    itDoc = pDocHis->DonnePatPathoDocument(sEventConcept, pPatPathoDoc) ;
    if ((itDoc != NULL) && (itDoc != pDocHis->VectDocument.end()))
    {
    	string sDate = (*itDoc)->GetDateDoc() ;
      tDateDoc.initFromDate(sDate) ;
    }
    else
    {
    	delete pPatPathoDoc ;
      return ;
    }
    PatPathoIter iter = pPatPathoDoc->begin() ;
    string sOpener = (*iter)->getNode() ;
    NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
    pGraphe->etablirLien(sOpener, NSRootLink::goalOpener, pGoal->sReference) ;

    NVLdVTemps tDateOpener ;
    tDateOpener.init() ;
    string sDate = (*itDoc)->GetDateDoc() ;
    tDateOpener.initFromDate(sDate) ;

    delete pPatPathoDoc ;

    // Si l'�v�nement d'ouverture est plus r�cent que le document, on sort
    if (tDateOpener > tDateDoc)
    	return ;
  }

	if (sDocId == "")
		return ;

	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	pGraphe->etablirLien(sDocId, NSRootLink::goalReseter, pGoal->sReference) ;

#endif // !__EPIPUMP__
}

bool
NSPatientChoisi::LocalPatho(NSPatPathoArray* pPptModele, NSPatPathoArray* pPptInstance)
{
  if ((NULL == pPptInstance) || (NULL == pPptModele) || (pPptModele->empty()))
    return false ;

  *pPptInstance = *pPptModele ;

  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

  string sTypeDate = "" ;
  PatPathoIter itCpy = pPptInstance->begin() ;
  for ( ; pPptInstance->end() != itCpy ; itCpy++)
  {
    if ((*itCpy)->pDonnees->lexique[0] == 'K')
    {
      string sTypeBase = (*itCpy)->getLexique() ;
      pContexte->getDico()->donneCodeSens(&sTypeBase, &sTypeDate) ;
    }

    // El�ment calcul� : format "$KNAIS+AAMMJJ"
    //                           012345678901234

    if (((*itCpy)->pDonnees->lexique[0] == '�') &&
        (((*itCpy)->pDonnees->lexique[1] == 'D') || ((*itCpy)->pDonnees->lexique[1] == 'T')) &&
        ((*itCpy)->pDonnees->complement[0] == '$'))
    {
      if (strlen((*itCpy)->pDonnees->complement) == 13)
      {
        string sUnitSens = (*itCpy)->getUnitSens(pContexte) ;

        string sDateCalcul = (*itCpy)->getComplement() ;

        string sRefDate = string(sDateCalcul, 1, 5) ;
        string sOperat  = string(sDateCalcul, 6, 1) ;
        string sAjout   = string(sDateCalcul, 7, 6) ;

        string sActualReferenceDate = string("") ;

        if ("KNAIS" == sRefDate)
        {
          char szNaiss[9] ;
          donneNaissance(szNaiss) ;
          if (strcmp(szNaiss, "00000000"))
            sActualReferenceDate = string(szNaiss) ;
        }
        else if ("KAUJO" == sRefDate)
        {
          NVLdVTemps TpsObj ;
          TpsObj.takeTime() ;
          sActualReferenceDate = TpsObj.donneDateHeure() ;
        }
        else
        {
          // pour l'instant le blackboard ne r�pond qu'� une question oui/non
          // L'alias doit etre un chemin de codes sens (s�parateur : '/')
          NSPatPathoArray* pPatPathoLocale = NULL ;

          string sVarAlias = sRefDate ;

          // on pose la question au blackboard
#ifdef __OB1__
          // the referential will ignore it
          string sAnswerDate ;
          int res = pContexte->getSuperviseur()->getBBinterface()->getAnswer2Question(sVarAlias, "", &pPatPathoLocale, sAnswerDate, true, true) ;
#else
          int res = pContexte->getSuperviseur()->getBlackboard()->getAnswer2Question(sVarAlias, "", &pPatPathoLocale, false) ;
#endif
          if (res == 1)
          {
            // on teste d'abord l'existence de la variable
            // (la patpatho r�sultat est non vide ==> la variable existe)
            if ((NULL != pPatPathoLocale) && (!((pPatPathoLocale)->empty())))
            {
              PatPathoIter iter = pPatPathoLocale->begin() ;
			        int iLigneBase = (*iter)->getLigne() ;
			        string sUnit   = "" ;
			        string sFormat = "" ;
              string sValeur = "" ;

			        while ((pPatPathoLocale->end() != iter) && ((*iter)->getLigne() == iLigneBase))
			        {
				        if (((*iter)->pDonnees->lexique)[0] == '�')
				        {
					        sFormat = (*iter)->getLexiqueSens(pContexte) ;
					        sValeur = (*iter)->getComplement() ;
					        sUnit   = (*iter)->getUnitSens(pContexte) ;

                  if ((string("2DA01") == sUnit) || (string("2DA02") == sUnit))
					          break ;
			          }
			          iter++ ;
		          }
              sActualReferenceDate = sValeur ;
            }
          }
          if (NULL != pPatPathoLocale)
            delete pPatPathoLocale ;
        }

        if (string("") != sActualReferenceDate)
        {
          NVLdVTemps TpsObj ;
          TpsObj.initFromDate(sActualReferenceDate) ;

          string sAjoutAns  = string(sAjout, 0, 2) ;
          string sAjoutMois = string(sAjout, 2, 2) ;
          string sAjoutJour = string(sAjout, 4, 2) ;

          int    iAjoutAns  = atoi(sAjoutAns.c_str()) ;
          int    iAjoutMois = atoi(sAjoutMois.c_str()) ;
          int    iAjoutJour = atoi(sAjoutJour.c_str()) ;

          if (string("-") == sOperat)
          {
            iAjoutAns  = - iAjoutAns ;
            iAjoutMois = - iAjoutMois ;
            iAjoutJour = - iAjoutJour ;
          }

          if (0 != iAjoutAns)
            TpsObj.ajouteAns(iAjoutAns, false /* don't normalize */) ;
          if (0 != iAjoutMois)
            TpsObj.ajouteMois(iAjoutMois, false /* don't normalize */) ;
          if (0 != iAjoutJour)
            TpsObj.ajouteJours(iAjoutJour) ;

          // L'ouverture de l'objectif ne peut pas �tre
          // ant�rieure � sa date de cr�ation (aujourd'hui
          if ("KOUVR" == sTypeDate)
          {
            if (tpsNow > TpsObj)
              TpsObj = tpsNow ;
          }

          string sDateObj = string("") ;
          if (string("2DA01") == sUnitSens)
            sDateObj = TpsObj.donneDate() ;
          else
            sDateObj = TpsObj.donneDateHeure() ;

          (*itCpy)->setComplement(sDateObj) ;
        }
        else
          (*itCpy)->setComplement("") ;
      }
      else
        (*itCpy)->setComplement("") ;
    }
  }
  return true ;
}

bool
NSPatientChoisi::RefuseObjectif(NSPatPathoArray* pPatPatho, string sDocument, string sRefId, NSPatPathoArray* pPatPathoMotif)
{
try
{
#ifndef __EPIPUMP__
	if ((!pPatPatho) || (pPatPatho->empty()))
		return true ;

//	NSPatPathoArray* pPathoIndex = 0;

	// Can we work ?
	if (!pDocHis)
	{
		erreur("Erreur grave (historique introuvable). Vous devriez relancer le logiciel.", standardError, 0) ;
		return false ;
	}
	if (pDocHis->VectDocument.empty())
	{
		erreur("Erreur grave (historique vide). Vous devriez relancer le logiciel.", standardError, 0) ;
		return false ;
	}

	// Recherche du document "Index de sant�"
	// Looking for "Health index" document
	DocumentIter iterDoc ;

	bool bSearchIndex = true ;
	while (bSearchIndex)
	{
		bool bContinuer = true ;
		iterDoc = pDocHis->VectDocument.begin() ;
		while ((iterDoc != pDocHis->VectDocument.end()) && bContinuer)
		{
    	if (((*iterDoc)->pPatPathoArray) && (!((*iterDoc)->pPatPathoArray->empty())))
			{
				PatPathoIter iter = (*iterDoc)->pPatPathoArray->begin() ;
				if (strcmp((*iter)->pDonnees->lexique, "ZPOMR1") == 0)
					bContinuer = false ;
				else
					iterDoc++ ;
			}
		}

		// Index de sant� non trouv� - Health index not found
		if (iterDoc == pDocHis->VectDocument.end())
		{
      // En MUE on signale une erreur car l'index de sant� est normalement cr��
      // lors de l'initialisation du patient (m�thode NSPatientChoisi::CreeRootDocs())
      ::MessageBox(pContexte->GetMainWindow()->GetHandle(), "Ce patient ne semble pas avoir de document des Index de sant�.", "Attention", MB_OK) ;
      return false ;
		}
		else
			bSearchIndex = false ;
	}

    // ???????????????????
	if (iterDoc == pDocHis->VectDocument.end())
		return false ;

	// Health index found
	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *((*iterDoc)->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;
	NSPatPathoArray* pPt = Noyau.pPatPathoArray ;

	// On cherche le chapitre "objectifs de sant�"
	PatPathoIter iter = pPt->ChercherItem("0OBJE1") ;

	if ((iter == NULL) || (iter == pPt->end()))
	{
		erreur("Erreur grave : le document Index de sant� de ce patient ne poss�de pas de chapitre Objectifs de sant�.", standardError, 0) ;
		return false ;
	}

	// Ajout d'un nouveau segment d'arbre
	// Adding a new tree branch
	// Ajout de la branche � l'arbre Index de sant�
	// Adding the branch to the Health index tree

	// On cherche o� il faut ins�rer la branche
	// Looking for the place to insert the branch
	int colonneMere = (*iter)->getColonne() ;
	iter++ ;
	while ((iter != pPt->end()) && ((*iter)->getColonne() > colonneMere))
  {
    // on v�rifie si un fils identique existe d�j�
    if ((*iter)->getColonne() == (colonneMere + 1))
    {
      if (!strcmp((*iter)->pDonnees->lexique, (*(pPatPatho->begin()))->pDonnees->lexique))
      {
        string sLangue  = pContexte->getUtilisateur()->donneLang() ;
        string sCodeLex = (*iter)->getLexique() ;
        string sLibelle ;
        pContexte->getDico()->donneLibelle(sLangue, &sCodeLex, &sLibelle) ;

        /*
        char msg[255] ;
        sprintf(msg, "L'objectif \"%s\" existe d�j� pour ce patient. Voulez-vous en ins�rer un autre ?", sLibelle.c_str()) ;
        int iRetVal = ::MessageBox(pContexte->GetMainWindow()->GetHandle(), msg, "Attention", MB_YESNO) ;
        if (iRetVal != IDYES)
          return true ;
        */
      }
    }

		iter++ ;
  }

  // On cherche un(les) �l�ment calcul�(s)
  bool bSeenClosingDate = false ;

  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;
  string sDateObj = tpsNow.donneDateHeure() ;

  NSPatPathoArray pptCopy(pContexte) ;

  // Transformation de la patpatho th�orique en patpatho r�elle
  LocalPatho(pPatPatho, &pptCopy) ;

  PatPathoIter itCpy = pptCopy.begin() ;
  itCpy++ ;
  while ((itCpy != pptCopy.end()) && (((*itCpy)->getColonne() != 1) || ((*itCpy)->getLexique() != "KFERM1")))
    itCpy++ ;

	// On a trouv� une date de fin, on la modifie
	// We have found a previous ending date, we can change it
	if (itCpy != pptCopy.end())
	{
    bSeenClosingDate = true ;
    itCpy++ ;
		strcpy((*itCpy)->pDonnees->complement, sDateObj.c_str()) ;
  }

  if (!bSeenClosingDate)
  {
    itCpy = pptCopy.begin() ;
    itCpy++ ;
    pptCopy.ajoutePatho(itCpy, "KFERM1", 1, 0) ;
    Message theMessage ;
    theMessage.SetComplement(sDateObj) ;
    theMessage.SetUnit(string("2DA021")) ;
    itCpy++ ;
    pptCopy.ajoutePatho(itCpy, "�T0;19", &theMessage, 2, 0) ;
  }

  // Insertion du motif de refus
  pptCopy.InserePatPatho(pptCopy.end(), pPatPathoMotif, 1) ;

#ifndef __EPIBRAIN__
  NSDPIO* pDPIO = pContexte->getSuperviseur()->getDPIO() ;
  pDPIO->sSendPage += string("<goal>\r\n") + pptCopy.genereXML() + string("</goal>\r\n") ;
#endif // !__EPIBRAIN__

  // on note ici la position en ligne et colonne de l'�l�ment que l'on va ins�rer
  int ligneIns, colonneIns ;

  if (iter != pPt->end())
  {
    ligneIns = (*iter)->getLigne() ;
    colonneIns = colonneMere + 1 ;
  }
  else
  {
    PatPathoIter iterEnd = iter ;
    iterEnd-- ;
    ligneIns = (*iterEnd)->getLigne() + 1 ;
    colonneIns = colonneMere + 1 ;
  }

  // Insertion de l'objectif
  pPt->InserePatPatho(iter, &pptCopy/*pPatPatho*/, colonneIns) ;

  // Enregistrement du document modifi�
  Noyau.enregistrePatPatho() ;

  // Mise � jour de l'historique
  /* bool bReload = */ Noyau.chargePatPatho() ;
  pPt = Noyau.pPatPathoArray ;
  pDocHis->Rafraichir(&Docum, pPt) ;

  if (!(pPt->empty()))
  {
    PatPathoIter itRoot  = pPt->ChercherItem(ligneIns, colonneIns) ;
    string       sNoeud  = (*itRoot)->getNode() ;

    // Lien entre le noeud et son document cr�ateur
    NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
    pGraphe->etablirLien(sDocument, NSRootLink::refCreator, sNoeud) ;

    // Lien entre le noeud et le r�f�rentiel
    if (sRefId != "")
    {
      string sRefNode = pContexte->getArcManager()->DonneNoeudArchetype(NSArcManager::referentiel, sRefId) ;
      if (sRefNode != "")
        pGraphe->etablirLien(sRefNode, NSRootLink::referentialOf, sNoeud) ;
    }

    // Lien entre le noeud et la pr�occupation de sant� qu'il concerne (plusieurs ?)
    VecteurString aVecteurString ;
		pGraphe->TousLesVraisDocument(sDocument, NSRootLink::problemRelatedTo, &aVecteurString) ;
    if (!aVecteurString.empty())
    {
      string sPrimoPb = *(*(aVecteurString.begin())) ;
      pGraphe->etablirLien(sNoeud, NSRootLink::problemGoals, sPrimoPb) ;
    }

    // Prise en compte de l'objectif sur la Ligne de vie
    pDocLdv->getGoals()->loadGoals(itRoot, (*itRoot)->getColonne() - 1, true /*bJustOne*/) ;
    pDocLdv->invalidateViews("GOAL_REFUSE") ;
  }

#endif // !__EPIPUMP__
  return true ;
}
catch (...)
{
	erreur("Exception RefuseObjectif.", standardError, 0) ;
	return false ;
}
}


bool
NSPatientChoisi::CreeTraitement(NSPatPathoArray *pPatPatho, VecteurString* pRelatedConcerns)
{
try
{
#ifndef __EPIPUMP__
	if ((!pPatPatho) || (pPatPatho->empty()))
  	return true ;

	// Recherche du document "Index de sant�"
	// Looking for "Health index" document
  //
	DocumentIter iterDoc = trouveIndexSante() ;

	if (iterDoc == NULL)
		return false ;

	// Health index found
	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *((*iterDoc)->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;

	NSPatPathoArray *pPt = Noyau.pPatPathoArray ;

	// On cherche le chapitre "traitement"
	PatPathoIter iter = pPt->ChercherItem("N00001") ;

	if ((iter == NULL) || (iter == pPt->end()))
	{
  	// ajout des traitements dans l'index de Sant�
    pPt->ajoutePatho("N00001", 1) ;

    PatPathoIter iter = pPt->ChercherItem("N00001") ;
    if ((iter == NULL) || (iter == pPt->end()))
    {
    	erreur("Erreur grave : le document Index de sant� de ce patient est endommag�.", standardError, 0) ;
      return false ;
    }
	}

	// Ajout d'un nouveau segment d'arbre
	// Adding a new tree branch
	// Ajout de la branche � l'arbre Index de sant�
	// Adding the branch to the Health index tree

	// On cherche o� il faut ins�rer la branche
	// Looking for the place to insert the branch
  // on se place ici apr�s le chap�tre "traitement"
	int colonneMere = (*iter)->getColonne() ;
	iter++ ;
	while ((iter != pPt->end()) && ((*iter)->getColonne() > colonneMere))
		iter++ ;

  	// on note ici la position en ligne et colonne de l'�l�ment que l'on va ins�rer
	int ligneIns, colonneIns ;

	if (iter != pPt->end())
	{
  	ligneIns = (*iter)->getLigne() ;
    colonneIns = colonneMere + 1 ;
	}
  else
	{
  	PatPathoIter iterEnd = iter ;
    iterEnd-- ;
    ligneIns = (*iterEnd)->getLigne() + 1 ;
    colonneIns = colonneMere + 1 ;
  }

	// Insertion du m�dicament
  pPt->InserePatPatho(iter, pPatPatho, colonneIns) ;

	// Enregistrement du document modifi�
	Noyau.enregistrePatPatho() ;

	// Mise � jour de l'historique
	/* bool bReload = */ Noyau.chargePatPatho() ;
	pPt = Noyau.pPatPathoArray ;
	pDocHis->Rafraichir(&Docum, pPt) ;
	bool bRet = true ;
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	if (!(pPt->empty()))
	{
  	// on retrouve le num�ro du node ins�r�
    PatPathoIter iterIns = pPt->ChercherItem(ligneIns, colonneIns) ;
    if ((iterIns != pPt->end()) && (iterIns != NULL))
    {
    	string sNodeALier = (*iterIns)->getNode() ;

      // on �tablit le lien entre le m�dicament et la pr�occupation
      if ((NULL != pRelatedConcerns) && (!(pRelatedConcerns->empty())))
      	for (EquiItemIter it = pRelatedConcerns->begin() ; it != pRelatedConcerns->end() ; it++)
        	pGraphe->etablirLien(sNodeALier, NSRootLink::drugOf, **it) ;

      // Prise en compte du  sur la Ligne de vie
      pDocLdv->getDrugs()->loadDrugs(pPt, iterIns, (*iterIns)->getColonne() - 1, true /*bJustOne*/) ;

      // fabTODO showNewDrug
      pDocLdv->showNewDrug(pPt, iterIns) ;

      pDocLdv->invalidateViews("DRUG_NEW") ;
    }
    else
    {
    	// fabTODO erreur
    }
	}

	return bRet ;
  
#endif // !__EPIPUMP__
}
catch (...)
{
	erreur("Exception CreeTraitement.", standardError, 0) ;
	return false ;
}
}


bool
NSPatientChoisi::ArreterElement(VecteurString* pNodeArret, string sDateFin, bool bSave)
{
try
{
#ifndef __EPIPUMP__
    // Recherche du document "Index de sant�"
	// Looking for "Health index" document
	DocumentIter iterDoc = trouveIndexSante() ;

	if (iterDoc == NULL)
		return false ;

	if (pNodeArret->empty())
		return false ;

	// Health index found
	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *((*iterDoc)->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;
	NSPatPathoArray* pPpt = Noyau.pPatPathoArray ;

	if (pPpt == NULL)
		return false ;	// temporairement on traite un seul noeud	string sNodeArret = *(*(pNodeArret->begin()));	//	// Recherche du noeud	//  PatPathoIter pptIt = pPpt->ChercherNoeud(sNodeArret) ;  if ((NULL == pptIt) || (pPpt->end() == pptIt))  	return false ;	// Recherche de la date de fermeture en sous-niveau du noeud	//	PatPathoIter pptItValeur ;	bool bDateTrouvee = false;	int iColBase = (*pptIt)->getColonne() ;	pptIt++ ;	while ((pptIt != pPpt->end()) && ((*pptIt)->getColonne() > iColBase))	{
		string sElemLex = (*pptIt)->getLexique() ;
		string sSens ;
		pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

		if ((*pptIt)->getColonne() == iColBase+1)
		{
    	// Dates
      if (sSens == "KFERM")
      {
      	pptIt++ ;
        int iLigneBase = (*pptIt)->getLigne() ;
        string sUnite  = "" ;
        string sFormat = "" ;
        string sValeur = "" ;
        string sTemp   = "" ;

        while ((pptIt != pPpt->end()) &&
                            ((*pptIt)->getLigne() == iLigneBase))
        {
					if (((*pptIt)->pDonnees->lexique)[0] == '�')
					{
						sTemp   = (*pptIt)->getLexique() ;
            pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
            sValeur = (*pptIt)->getComplement() ;
            sTemp   = (*pptIt)->getUnit() ;
            pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
            pptItValeur = pptIt;
            break ;
					}
					pptIt++;
				}

				// sFormat est du type �D0;03 ou �T0
				if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) && (sValeur != ""))
				{
					if ((sUnite == "2DA01") || (sUnite == "2DA02"))
					{
						if (sValeur > sDateFin)
							strcpy((*pptItValeur)->pDonnees->complement, sDateFin.c_str());

						bDateTrouvee = true;
					}
        }
			}
			else
				pptIt++ ;
		}
		else
    	pptIt++ ;
	}

	if (!bDateTrouvee)
	{
		NSPatPathoArray PatPatho(pContexte) ;

		// Date de fin - Date of ending
		if ((sDateFin != "") &&
				(sDateFin != string("19000000")) && (sDateFin != string("00000000")) && (sDateFin != string("00000000000000")))
		{
			PatPatho.ajoutePatho("KFERM1", 0) ;
			Message	CodeMsg ;
      CodeMsg.SetUnit("2DA021") ;
      CodeMsg.SetComplement(sDateFin) ;
      PatPatho.ajoutePatho("�T0;19", &CodeMsg, 1) ;

			pPpt->InserePatPatho(pptIt, &PatPatho, iColBase + 1) ;
		}
	}

	if (false == bSave)
		return true ;

	// Enregistrement du document modifi�
	Noyau.enregistrePatPatho() ;

	// Mise � jour de l'historique
	/* bool bReload = */ Noyau.chargePatPatho() ;
	pPpt = Noyau.pPatPathoArray ;
	pDocHis->Rafraichir(&Docum, pPpt) ;

	if (!(pPpt->empty()))
	{
    // on se repositionne sur le noeud � cause de la pr�c�dente insertion
    //
    pptIt = pPpt->ChercherNoeud(sNodeArret) ;
    //
    // Prise en compte du  sur la Ligne de vie
    //
    pDocLdv->getDrugs()->reloadDrugs(pPpt, pptIt, (*pptIt)->getColonne() - 1, true /*bJustOne*/) ;
    pDocLdv->invalidateViews("CONCERN_STOP") ;
	}

#endif // !__EPIPUMP__

	return true ;
}
catch (...)
{
	erreur("Exception ArreterElement.", standardError, 0) ;
	return false ;
}
}

bool
NSPatientChoisi::addSubElement(string motherNode, NSPatPathoArray *pPPT, bool bSave)
{
try
{
#ifndef __EPIPUMP__

	if ((NULL == pPPT) || (string("") == motherNode))
		return false ;

	DocumentIter iterDoc = trouveIndexSante() ;

	if (iterDoc == NULL)
		return false ;

	// Health index found
	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *((*iterDoc)->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;
	NSPatPathoArray* pPptIndex = Noyau.pPatPathoArray ;

  if ((NULL == pPptIndex) || (pPptIndex->empty()))
  	return false ;  //  // Recherche du noeud  //  PatPathoIter pptIt = pPptIndex->ChercherNoeud(motherNode) ;  if ((NULL == pptIt) || (pPptIndex->end() == pptIt))  	return false ;	pPptIndex->InserePatPathoFille(pptIt, pPPT) ;

	if (false == bSave)
		return true ;

	// Enregistrement du document modifi�
	Noyau.enregistrePatPatho() ;

	// Mise � jour de l'historique
	/* bool bReload = */ Noyau.chargePatPatho() ;
	pPptIndex = Noyau.pPatPathoArray ;
	pDocHis->Rafraichir(&Docum, pPptIndex) ;

	if (!(pPptIndex->empty()))
	{
    // on se repositionne sur le noeud � cause de la pr�c�dente insertion
    //
    pptIt = pPptIndex->ChercherNoeud(motherNode) ;
    //
    // Prise en compte du  sur la Ligne de vie
    //
    pDocLdv->getDrugs()->reloadDrugs(pPptIndex, pptIt, (*pptIt)->getColonne() - 1, true /*bJustOne*/) ;
    pDocLdv->invalidateViews("CONCERN_STOP") ;
	}

#endif // !__EPIPUMP__

	return true ;
}
catch (...)
{
	erreur("Exception addSubElement.", standardError, 0) ;
	return false ;
}
}

bool
NSPatientChoisi::RenouvelerTraitement(VecteurString* pNodeMedic, NSPatPathoArray* pPPT)
{
try
{
#ifndef __EPIPUMP__
	// Recherche du document "Index de sant�"
	// Looking for "Health index" document
  //
	DocumentIter iterDoc = trouveIndexSante() ;

	if (iterDoc == NULL)
		return false ;

	if (pNodeMedic->empty())
  	return false ;

	// Health index found
	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *((*iterDoc)->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;
	NSPatPathoArray* pPptIndex = Noyau.pPatPathoArray ;

  if ((pPptIndex == NULL) || (pPptIndex->empty()))
  	return false ;	// temporairement on traite un seul noeud	string sNodeMedic = *(*(pNodeMedic->begin())) ;  //  // Recherche du noeud  //  PatPathoIter pptIt = pPptIndex->ChercherNoeud(sNodeMedic) ;  if ((NULL == pptIt) || (pPptIndex->end() == pptIt))  	return false ;	// Recherche de la derni�re phase en sous-niveau du noeud  //  PatPathoIter pptItValeur ;  bool bEnterPhase = false ;  int iColBase = (*pptIt)->getColonne() ;  int iColPhase ;  pptIt++ ;  while ((pptIt != pPptIndex->end()) && ((*pptIt)->getColonne() > iColBase))  {
  	string sElemLex = (*pptIt)->getLexique() ;
    string sSens ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    if ((*pptIt)->getColonne() == iColBase+1)
    {
    	// Dates
      if (sSens == "KPHAT")
      {
      	if (!bEnterPhase)
        	bEnterPhase = true ;

        iColPhase = (*pptIt)->getColonne() ;
        pptIt++ ;

        // on "skippe" la phase
        while ((pptIt != pPptIndex->end()) && ((*pptIt)->getColonne() > iColPhase))
        	pptIt++ ;
      }
      else if (bEnterPhase)
      {
      	// on suppose que s'il y a plusieurs phases, elles se succ�dent
        // on est donc ici apr�s la derni�re phase.
        break ;
      }
      else
      	pptIt++ ;
    }
    else
    	pptIt++ ;
  }

  pptItValeur = pptIt ;

  if (bEnterPhase)
  	pPptIndex->InserePatPatho(pptItValeur, pPPT, iColPhase + 1) ;
  else
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("drugManagementErrors", "noTreatmentPhaseDefined") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  	erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
  }

	// Enregistrement du document modifi�
	Noyau.enregistrePatPatho() ;

	// Mise � jour de l'historique
	/* bool bReload = */ Noyau.chargePatPatho() ;
	pPptIndex = Noyau.pPatPathoArray ;
	pDocHis->Rafraichir(&Docum, pPptIndex) ;

  if (!(pPptIndex->empty()))
  {
  	// on se repositionne sur le noeud � cause de la pr�c�dente insertion
    //
    pptIt = pPptIndex->ChercherNoeud(sNodeMedic) ;
    //
    // Prise en compte du  sur la Ligne de vie
    //
    pDocLdv->getDrugs()->reloadDrugs(pPptIndex, pptIt, (*pptIt)->getColonne() - 1, true /*bJustOne*/) ;
    pDocLdv->invalidateViews("DRUG_RENEW") ;
  }

#endif // !__EPIPUMP__

	return true ;
}
catch (...)
{
	erreur("Exception RenouvelerTraitement.", standardError, 0) ;
	return false ;
}
}

bool
NSPatientChoisi::SupprimerElement(string sNodeArret, bool bAvecTransa)
{
try
{
	// Recherche du document "Index de sant�"
	// Looking for "Health index" document
  //
	DocumentIter iterDoc = trouveIndexSante() ;

	if (iterDoc == NULL)
		return false ;

	// Health index found
	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *((*iterDoc)->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;
	NSPatPathoArray* pPpt = Noyau.pPatPathoArray ;

  if (pPpt == NULL)
  	return false ;  //  // Recherche du noeud  //  PatPathoIter pptIt = pPpt->ChercherNoeud(sNodeArret) ;  if ((NULL == pptIt) || (pPpt->end() == pptIt))  	return false ;  // Suppression du m�dicament (sous patpatho qui commence � pptIt)  pPpt->SupprimerItem(pptIt) ;  // Enregistrement du document modifi�	Noyau.enregistrePatPatho() ;

	// Mise � jour de l'historique
	/* bool bReload = */ Noyau.chargePatPatho() ;
	pPpt = Noyau.pPatPathoArray ;
	pDocHis->Rafraichir(&Docum, pPpt) ;

	return true ;
}
catch (...)
{
	erreur("Exception SupprimerElement.", standardError, 0) ;
	return false ;
}
}

bool
NSPatientChoisi::CreeOrdonnance(bool bGereALD)
{
try
{
#ifndef __EPIPUMP__

	if (!(pContexte->userHasPrivilege(NSContexte::createDocument, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return false ;
	}

	// Recherche du document "Index de sant�"
	// Looking for "Health index" document
	DocumentIter iterDoc = trouveIndexSante() ;

	if (iterDoc == NULL)
		return false ;

	// Health index found
	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *((*iterDoc)->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;

	NSPatPathoArray* pPpt = Noyau.pPatPathoArray ;
  if ((NULL == pPpt) || (true == pPpt->empty()))
		return false ;

	// On cherche le chapitre "traitement"
	PatPathoIter pptIt = pPpt->ChercherItem("N00001") ;
	if ((NULL == pptIt) || (pPpt->end() == pptIt))
		return false;   // cas aucun traitement d�j� effectu�

	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	VecteurString NewTraitement ;
	VecteurString NewLexique ;
	VecteurString NewTrtALD ;
	VecteurString NewLexALD ;

	if (false == initNewPrescriptionArrays(pPpt, bGereALD, &NewTraitement, &NewLexique, &NewTrtALD, &NewLexALD))
		return false ;

	// cas des renouvelements
  //
	if (false == initRenewPrescriptionArrays(pPpt, bGereALD, &NewTraitement, &NewLexique, &NewTrtALD, &NewLexALD))
		return false ;

	// Le traitement est constitu�
	if ((NewTraitement.empty()) && (NewTrtALD.empty()))
		return false ;

	// constitution de la patpatho correspondant au nouveau traitement
	NSPatPathoArray PatPatho(pContexte) ;

  if (false == buildPrescriptionPatpatho(pPpt, &PatPatho, bGereALD, &NewTraitement, &NewLexique, &NewTrtALD, &NewLexALD))
		return false ;

  if (PatPatho.empty() == true)
		return false ;

	PatPathoIter iter = PatPatho.begin() ;
	while (iter != PatPatho.end())
	{
		(*iter)->setNodeID("") ;
		(*iter)->setTreeID("") ;
    iter++ ;
	}

	// enregistrement du document
	NSCRDocument CRDoc(0, pContexte) ;
	*(CRDoc.pPatPathoArray) = PatPatho ;

	bool existeInfo = CRDoc.Referencer("ZCN00", "Ordonnance", "", "", true, false) ;

	if (existeInfo)
		existeInfo = CRDoc.enregistrePatPatho() ;

	if (existeInfo)
	{
  	//
    // Rafraichir l'historique
    //
    /* bool bReload = */ CRDoc.NSNoyauDocument::chargePatPatho() ;
    pContexte->getPatient()->pDocHis->Rafraichir(CRDoc.pDocInfo, CRDoc.pPatPathoArray) ;
    PatPatho = *(CRDoc.pPatPathoArray) ;
    PatPathoIter iter ;
    string sNodeALier ;

    EquiItemIter i = NewLexique.begin() ;
    EquiItemIter j = NewTraitement.begin() ;
    // on a maintenant les numeros de noeuds, on peut �tablir les liens restants
    while ((i != NewLexique.end()) && (j != NewTraitement.end()))
    {
    	iter = PatPatho.ChercherItem(*(*i)) ;
      if ((iter != NULL) && (iter != PatPatho.end()))
      {
      	sNodeALier = (*iter)->pDonnees->getNode();
        /* bool bRes = */ pGraphe->etablirLien(*(*j), NSRootLink::treatmentOf, sNodeALier);
      }

      i++ ;
      j++ ;
    }
    if (bGereALD)
    {
    	EquiItemIter _iALD = NewLexALD.begin() ;
      EquiItemIter _jALD = NewTrtALD.begin() ;
      // on a maintenant les numeros de noeuds, on peut �tablir les liens restants
      while ((_iALD != NewLexALD.end()) && (_jALD != NewTrtALD.end()))
      {
      	iter = PatPatho.ChercherItem(*(*_iALD)) ;
        if ((iter != NULL) && (iter != PatPatho.end()))
        {
        	sNodeALier = (*iter)->pDonnees->getNode();
          /* bool bRes = */ pGraphe->etablirLien(*(*_jALD), NSRootLink::treatmentOf, sNodeALier);
        }

        _iALD++ ;
        _jALD++ ;
      }
    }
	}

	if (existeInfo)
		existeInfo = CRDoc.enregistrePatPatho() ;

	// on ouvre l'ordonnance en �dition
	pDocHis->AutoriserEdition(CRDoc.pDocInfo) ;

#endif // !__EPIPUMP__
	return true;
}
catch (...)
{
	erreur("Exception CreeOrdonnance.", standardError, 0) ;
	return false ;
}
}

bool
NSPatientChoisi::CreeOrdonnanceFromSelection(bool bGereALD, VecteurString* pDrugsRefs)
{
try
{
#ifndef __EPIPUMP__

	if ((NULL == pDrugsRefs) || (true == pDrugsRefs->empty()))
		return false ;

	if (!(pContexte->userHasPrivilege(NSContexte::createDocument, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return false ;
	}

	// Recherche du document "Index de sant�"
	// Looking for "Health index" document
	DocumentIter iterDoc = trouveIndexSante() ;

	if (iterDoc == NULL)
		return false ;

	// Health index found
	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *((*iterDoc)->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;

	NSPatPathoArray* pPpt = Noyau.pPatPathoArray ;
  if ((NULL == pPpt) || (true == pPpt->empty()))
		return false ;

	VecteurString NewTraitement ;
	VecteurString NewLexique ;

	VecteurString NewTrtALD ;
	VecteurString NewLexALD ;

	EquiItemIter itemsIter = pDrugsRefs->begin() ;
	for ( ; pDrugsRefs->end() != itemsIter ; itemsIter++)
	{
  	string sNodeMedic = **itemsIter ;

		PatPathoIter pptIt = pPpt->ChercherNoeud(sNodeMedic) ;
    if ((NULL != pptIt) && (pPpt->end() != pptIt))
    {
    	string sCodeMedic = (*pptIt)->getLexique() ;

			if (bGereALD)
      {
      	if (pDocLdv && pDocLdv->isALDDrug(sNodeMedic))
        {
        	NewTrtALD.push_back(new string(sNodeMedic)) ;
          NewLexALD.push_back(new string(sCodeMedic)) ;
        }
        else
        {
        	NewTraitement.push_back(new string(sNodeMedic)) ;
          NewLexique.push_back(new string(sCodeMedic)) ;
        }
      }
      else
      {
      	NewTraitement.push_back(new string(sNodeMedic)) ;
        NewLexique.push_back(new string(sCodeMedic)) ;
      }
    }
  }

	// On cherche le chapitre "traitement"
	PatPathoIter pptIt = pPpt->ChercherItem("N00001") ;
	if ((NULL == pptIt) || (pPpt->end() == pptIt))
		return false;   // cas aucun traitement d�j� effectu�

	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	// Le traitement est constitu�
	if ((NewTraitement.empty()) && (NewTrtALD.empty()))
		return false ;

	// constitution de la patpatho correspondant au nouveau traitement
	NSPatPathoArray PatPatho(pContexte) ;

  if (false == buildPrescriptionPatpatho(pPpt, &PatPatho, bGereALD, &NewTraitement, &NewLexique, &NewTrtALD, &NewLexALD))
		return false ;

  if (PatPatho.empty() == true)
		return false ;

	PatPathoIter iter = PatPatho.begin() ;
	while (iter != PatPatho.end())
	{
		(*iter)->setNodeID("") ;
		(*iter)->setTreeID("") ;
    iter++ ;
	}

	// enregistrement du document
	NSCRDocument CRDoc(0, pContexte) ;
	*(CRDoc.pPatPathoArray) = PatPatho ;

	bool existeInfo = CRDoc.Referencer("ZCN00", "Ordonnance", "", "", true, false) ;

	if (existeInfo)
		existeInfo = CRDoc.enregistrePatPatho() ;

	if (existeInfo)
	{
  	//
    // Rafraichir l'historique
    //
    /* bool bReload = */ CRDoc.NSNoyauDocument::chargePatPatho() ;
    pContexte->getPatient()->pDocHis->Rafraichir(CRDoc.pDocInfo, CRDoc.pPatPathoArray) ;
    PatPatho = *(CRDoc.pPatPathoArray) ;
    PatPathoIter iter ;
    string sNodeALier ;

    EquiItemIter i = NewLexique.begin() ;
    EquiItemIter j = NewTraitement.begin() ;
    // on a maintenant les numeros de noeuds, on peut �tablir les liens restants
    while ((i != NewLexique.end()) && (j != NewTraitement.end()))
    {
    	iter = PatPatho.ChercherItem(*(*i)) ;
      if ((iter != NULL) && (iter != PatPatho.end()))
      {
      	sNodeALier = (*iter)->pDonnees->getNode();
        /* bool bRes = */ pGraphe->etablirLien(*(*j), NSRootLink::treatmentOf, sNodeALier);
      }

      i++ ;
      j++ ;
    }
    if (bGereALD)
    {
    	EquiItemIter _iALD = NewLexALD.begin() ;
      EquiItemIter _jALD = NewTrtALD.begin() ;
      // on a maintenant les numeros de noeuds, on peut �tablir les liens restants
      while ((_iALD != NewLexALD.end()) && (_jALD != NewTrtALD.end()))
      {
      	iter = PatPatho.ChercherItem(*(*_iALD)) ;
        if ((iter != NULL) && (iter != PatPatho.end()))
        {
        	sNodeALier = (*iter)->pDonnees->getNode();
          /* bool bRes = */ pGraphe->etablirLien(*(*_jALD), NSRootLink::treatmentOf, sNodeALier);
        }

        _iALD++ ;
        _jALD++ ;
      }
    }
	}

	if (existeInfo)
		existeInfo = CRDoc.enregistrePatPatho() ;

	// on ouvre l'ordonnance en �dition
	pDocHis->AutoriserEdition(CRDoc.pDocInfo) ;

#endif // !__EPIPUMP__
	return true;
}
catch (...)
{
	erreur("Exception CreeOrdonnanceFromSelection.", standardError, 0) ;
	return false ;
}
}

bool
NSPatientChoisi::initNewPrescriptionArrays(NSPatPathoArray* pPpt, bool bGereALD, VecteurString* pNewTraitement, VecteurString* pNewLexique, VecteurString* pNewTrtALD, VecteurString* pNewLexALD)
{
	if ((NULL == pPpt) || (true == pPpt->empty()))
		return false ;

	PatPathoIter pptIt = pPpt->ChercherItem("N00001") ;
	if ((NULL == pptIt) || (pPpt->end() == pptIt))
		return false ;   // cas aucun traitement d�j� effectu�

	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	// r�cup�ration de la date du jour au format AAAAMMJJ
  //
	NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

	VecteurString OldTraitement ;

	int iColBase = (*pptIt)->getColonne() ;
	pptIt++ ;	while ((pPpt->end() != pptIt) && ((*pptIt)->getColonne() > iColBase))	{
		if ((*pptIt)->getColonne() == iColBase+1)
		{
  		// on est sur un noeud m�dicament
      string sNodeMedic = (*pptIt)->pDonnees->getNode() ;
      string sCodeMedic = (*pptIt)->getLexique() ;

      // initialisation des donn�es � r�cup�rer pour ce m�dicament
      string sUnite1  = "" ;
      string sFormat1 = "" ;
      string sValeur1 = "" ;
      string sTemp1   = "" ;
      string sUnite2  = "" ;
      string sFormat2 = "" ;
      string sValeur2 = "" ;
      string sTemp2   = "" ;
      bool   bAvecFermeture = false ;
      bool   bAvecOuverture = false ;

      // On regarde si le m�dicament est d�j� prescrit dans un ancien traitement (ou ordonnance)
      // Si c'est le cas, on ne doit pas le reproposer.
      OldTraitement.vider() ;
      pGraphe->TousLesVrais(sNodeMedic, NSRootLink::treatmentOf, &OldTraitement) ;

      if (OldTraitement.empty())
      {
      	pptIt++ ;
        while ((pptIt != pPpt->end()) && ((*pptIt)->getColonne() > iColBase + 1))        {
        	string sSens = (*pptIt)->getLexiqueSens(pContexte) ;

          if ((*pptIt)->getColonne() == iColBase + 2)
          {
          	// Dates
            if (sSens == "KOUVR")
            {
            	pptIt++;
              int iLigneBase = (*pptIt)->getLigne();
              bAvecOuverture = true;

              while ((pPpt->end() != pptIt) &&
                                ((*pptIt)->getLigne() == iLigneBase))
              {
								if (((*pptIt)->pDonnees->lexique)[0] == '�')
                {
                	sTemp1   = (*pptIt)->getLexique() ;
                  pContexte->getDico()->donneCodeSens(&sTemp1, &sFormat1) ;
                  sValeur1 = (*pptIt)->getComplement() ;
                  sTemp1   = (*pptIt)->getUnit() ;
                  pContexte->getDico()->donneCodeSens(&sTemp1, &sUnite1) ;
                  break ;
                }
								pptIt++;
							}
						}
            else if (sSens == "KFERM")
            {
            	pptIt++ ;
              int iLigneBase = (*pptIt)->getLigne() ;
              bAvecFermeture = true ;

              while ((pptIt != pPpt->end()) &&
                                ((*pptIt)->getLigne() == iLigneBase))
              {
								if (((*pptIt)->pDonnees->lexique)[0] == '�')
                {
                	sTemp2   = (*pptIt)->getLexique() ;
                  pContexte->getDico()->donneCodeSens(&sTemp2, &sFormat2) ;
                  sValeur2 = (*pptIt)->getComplement() ;
                  sTemp2   = (*pptIt)->getUnit() ;
                  pContexte->getDico()->donneCodeSens(&sTemp2, &sUnite2) ;
                  break ;
                }
								pptIt++ ;
							}
						}
            else
            	pptIt++ ;
					}
          else
          	pptIt++ ;
				} // fin du while sur les dates
			}
      else  // if (pOldTraitement->empty())
      	pptIt++;

      // On regarde ici si le m�dicament peut appartenir au nouveau traitement
      // v�rification des dates d'ouverture et de fermeture
      // v�rification des formats (sFormat est du type �D0;03)
      if ((bAvecOuverture) && (sFormat1 != "") && ((sFormat1[1] == 'D') || (sFormat1[1] == 'T')) && (sValeur1 != ""))
      {
      	if ((sUnite1 == "2DA01") || (sUnite1 == "2DA02"))
        {
        	// Si le date d'ouverture est >= dateJour - 1 :
          // on retient le noeud pour ajouter au nouveau traitement
          incremente_date(sValeur1);

          if (sValeur1 >= tpsNow.donneDateHeure())
          {
          	// Si le m�dicament n'a pas de date de fermeture (cas chronique)
            // ou si la date de fermeture est future
            if ((!bAvecFermeture) ||
                        		  ((sFormat2 != "") && ((sFormat2[1] == 'D') || (sFormat2[1] == 'T')) &&
                               (sValeur2 != "") && ((sUnite2 == "2DA01") ||
                               											(sUnite2 == "2DA02")) &&
                               (sValeur2 > tpsNow.donneDateHeure())))
            {
              if (bGereALD)
              {
              	if (pDocLdv && pDocLdv->isALDDrug(sNodeMedic))
                {
                	pNewTrtALD->push_back(new string(sNodeMedic)) ;
                  pNewLexALD->push_back(new string(sCodeMedic)) ;
                }
                else
                {
                	pNewTraitement->push_back(new string(sNodeMedic)) ;
                  pNewLexique->push_back(new string(sCodeMedic)) ;
                }
              }
              else
              {
              	pNewTraitement->push_back(new string(sNodeMedic)) ;
                pNewLexique->push_back(new string(sCodeMedic)) ;
              }
            }
          }
        }
      }
		}
    else
    	pptIt++ ;
	} // fin du while sur les m�dicaments

  return true ;
}

bool
NSPatientChoisi::initRenewPrescriptionArrays(NSPatPathoArray* pPpt, bool bGereALD, VecteurString* pNewTraitement, VecteurString* pNewLexique, VecteurString* pNewTrtALD, VecteurString* pNewLexALD)
{
	if ((NULL == pPpt) || (true == pPpt->empty()))
		return false ;

	PatPathoIter pptIt = pPpt->ChercherItem("N00001") ;

  if ((pptIt == NULL) || (pptIt == pPpt->end()))
  	return false ;   // cas aucun traitement d�j� effectu�

  string sNodeRenouv, sCodeMedic, sNodeMedic ;

  NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	// r�cup�ration de la date du jour au format AAAAMMJJ
  //
	NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

	VecteurString OldTraitement ;

  int iColBase = (*pptIt)->getColonne() ;
  pptIt++ ;

  while (pPpt->end() != pptIt)
  {
  	pptIt = pPpt->ChercherItem("GRENT", true, pptIt) ;

    if ((NULL != pptIt) && (pPpt->end() != pptIt))
    {
    	sNodeRenouv = (*pptIt)->pDonnees->getNode() ;

      // On regarde si le renouvelement est d�j� prescrit dans un ancien traitement (ou ordonnance)
      // Si c'est le cas, on ne doit pas le reproposer.
      OldTraitement.vider() ;
      pGraphe->TousLesVrais(sNodeRenouv, NSRootLink::treatmentOf, &OldTraitement) ;

      if (OldTraitement.empty())
      {
      	// on remonte en arri�re jusqu'au noeud m�dicament
        PatPathoIter pptItMedic = pptIt ;

        while ((*pptItMedic)->getColonne() > iColBase+1)
        	pptItMedic-- ;

        if ((*pptItMedic)->getColonne() == iColBase+1)
        {
        	sCodeMedic = (*pptItMedic)->getLexique() ;
          sNodeMedic = (*pptItMedic)->pDonnees->getNode() ;
        }
        else
        {
        	sCodeMedic = "" ; // cas d'erreur : il n'existe pas de m�dicament
          sNodeMedic = "" ;
        }

        if (sCodeMedic != "")
        {
        	// initialisation des donn�es � r�cup�rer pour ce m�dicament
      		string sUnite1  = "" ;
      		string sFormat1 = "" ;
      		string sValeur1 = "" ;
      		string sTemp1   = "" ;

        	PatPathoIter pptItDate = pptIt ;
          int iColRenouv = (*pptItDate)->getColonne() ;
          pptItDate++ ;
          bool bAvecOuverture = false ;

          while ((pptItDate != pPpt->end()) && ((*pptItDate)->getColonne() > iColRenouv))
          {
          	string sSens = (*pptItDate)->getLexiqueSens(pContexte) ;

            if ((*pptItDate)->getColonne() == iColRenouv + 1)
            {
            	// Dates
              if (sSens == "KOUVR")
              {
              	pptItDate++ ;
                int iLigneBase = (*pptItDate)->getLigne() ;
                bAvecOuverture = true ;

                while ((pptItDate != pPpt->end()) &&
                       ((*pptItDate)->getLigne() == iLigneBase))
                {
                	if (((*pptItDate)->pDonnees->lexique)[0] == '�')
                  {
                  	sTemp1   = (*pptItDate)->getLexique() ;
                    pContexte->getDico()->donneCodeSens(&sTemp1, &sFormat1) ;
                    sValeur1 = (*pptItDate)->getComplement() ;
                    sTemp1   = (*pptItDate)->getUnit() ;
                    pContexte->getDico()->donneCodeSens(&sTemp1, &sUnite1) ;
                    break ;
                  }
                  pptItDate++ ;
                }
              }
              else
              	pptItDate++ ;
            }
            else
            	pptItDate++ ;
          } // fin du while sur les dates

          // On regarde ici si le m�dicament peut appartenir au nouveau traitement
          // v�rification de la date d'ouverture
          // v�rification des formats (sFormat est du type �D0;03)
          if ((bAvecOuverture) && (sFormat1 != "") && ((sFormat1[1] == 'D') || (sFormat1[1] == 'T')) && (sValeur1 != ""))
          {
          	if ((sUnite1 == "2DA01") || (sUnite1 == "2DA02"))
            {
            	if (strlen(sValeur1.c_str()) > 8)
              	sValeur1 = string(sValeur1, 0, 8) ;

              // Si le date d'ouverture est >= dateJour - 1 :
              // on retient le noeud pour ajouter au nouveau traitement
              incremente_date(sValeur1) ;

              if (sValeur1 >= tpsNow.donneDateHeure())
              {
              	if (bGereALD)
                {
                	if (pDocLdv && pDocLdv->isALDDrug(sNodeMedic))
                  {
                  	pNewTrtALD->push_back(new string(sNodeRenouv)) ;
                    pNewLexALD->push_back(new string(sCodeMedic)) ;
                  }
                  else
                  {
                  	pNewTraitement->push_back(new string(sNodeRenouv)) ;
                    pNewLexique->push_back(new string(sCodeMedic)) ;
                  }
                }
                else
                {
                	pNewTraitement->push_back(new string(sNodeRenouv)) ;
                  pNewLexique->push_back(new string(sCodeMedic)) ;
                }
              }
            }
          }
        }
      }
    }
  }
	return true ;
}

bool
NSPatientChoisi::buildPrescriptionPatpatho(NSPatPathoArray* pPpt, NSPatPathoArray* pPrescriPpt, bool bGereALD, VecteurString* pNewTraitement, VecteurString* pNewLexique, VecteurString* pNewTrtALD, VecteurString* pNewLexALD)
{
	if ((NULL == pPpt) || (NULL == pPrescriPpt))
		return false ;

	pPrescriPpt->vider() ;
	pPrescriPpt->ajoutePatho("ZORDO1", 0) ;

	if (false == bGereALD)
		return buildSimplePrescriptionPatpatho(pPpt, pPrescriPpt, pNewTraitement, pNewLexique) ;
	else
  	return buildBizonePrescriptionPatpatho(pPpt, pPrescriPpt, pNewTraitement, pNewLexique, pNewTrtALD, pNewLexALD) ;
}

bool
NSPatientChoisi::buildBizonePrescriptionPatpatho(NSPatPathoArray* pPpt, NSPatPathoArray* pPrescriPpt, VecteurString* pNewTraitement, VecteurString* pNewLexique, VecteurString* pNewTrtALD, VecteurString* pNewLexALD)
{
	if ((NULL == pPpt) || (NULL == pPrescriPpt))
		return false ;

	if ((NULL == pNewLexique) || (NULL == pNewTraitement) ||
      (NULL == pNewLexALD)  || (NULL == pNewTrtALD))
		return false ;

	NSPatPathoArray SousPPT(pContexte) ;

	// ALD
	if (false == pNewTrtALD->empty())
	{
  	if (true == pNewLexALD->empty())
    	return false ;

  	EquiItemIter iALD = pNewLexALD->begin() ;
    EquiItemIter jALD = pNewTrtALD->begin() ;

    pPrescriPpt->ajoutePatho("GPALD1", 1) ;

    while ((pNewLexALD->end() != iALD) && (pNewTrtALD->end() != jALD))
    {
    	// constitution de la sous-patpatho du noeud
      // on cherche d'abord le code lexique correspondant au traitement
      // pour v�rifier s'il s'agit d'un m�dicament ou d'un renouvelement
      PatPathoIter pptItTrait = pPpt->ChercherNoeud(*(*jALD)) ;
      string sElemLex = (*pptItTrait)->getLexique() ;
      string sSens ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;
      SousPPT.vider() ;

      if (string("GRENT") == sSens)
      {
      	if (pDocLdv && pDocLdv->getDrugs())
        	pDocLdv->getDrugs()->getRenewPatPatho(&SousPPT, *(*jALD)) ;
        else
        	return false ;

        // Insertion en queue (iter doit �tre ici egal � end())
        pPrescriPpt->InserePatPatho(pPrescriPpt->end(), &SousPPT, 2) ;
      }
      else
      {
      	pContexte->getPatient()->DonneSousArray(*(*jALD), &SousPPT) ;

        // on reconstitue la patpatho � partir du noeud
        pPrescriPpt->ajoutePatho(*(*iALD), 2) ;
        // Insertion en queue (iter doit �tre ici egal � end())
        pPrescriPpt->InserePatPatho(pPrescriPpt->end(), &SousPPT, 3) ;
      }

      iALD++ ;
      jALD++ ;
    }
  }
  // non ALD
  if (false == pNewTraitement->empty())
  {
  	if (true == pNewLexique->empty())
    	return false ;

  	EquiItemIter iNonALD = pNewLexique->begin() ;
    EquiItemIter jNonALD = pNewTraitement->begin() ;

    pPrescriPpt->ajoutePatho("GPCOD1", 1) ;

    while ((iNonALD != pNewLexique->end()) && (jNonALD != pNewLexALD->end()))
    {
    	// constitution de la sous-patpatho du noeud
      // on cherche d'abord le code lexique correspondant au traitement
      // pour v�rifier s'il s'agit d'un m�dicament ou d'un renouvelement
      PatPathoIter pptItTrait = pPpt->ChercherNoeud(*(*jNonALD)) ;
      string sElemLex = (*pptItTrait)->getLexique() ;
      string sSens ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;
      SousPPT.vider() ;

      if (sSens == "GRENT")
      {
      	if (pDocLdv && pDocLdv->getDrugs())
        	pDocLdv->getDrugs()->getRenewPatPatho(&SousPPT, *(*jNonALD)) ;
        else
        	return false ;

        // Insertion en queue (iter doit �tre ici egal � end())
        pPrescriPpt->InserePatPatho(pPrescriPpt->end(), &SousPPT, 2) ;
      }
      else
      {
      	pContexte->getPatient()->DonneSousArray(*(*jNonALD), &SousPPT) ;

        // on reconstitue la patpatho � partir du noeud
        pPrescriPpt->ajoutePatho(*(*iNonALD), 2) ;
        // Insertion en queue (iter doit �tre ici egal � end())
        pPrescriPpt->InserePatPatho(pPrescriPpt->end(), &SousPPT, 3) ;
      }

      iNonALD++ ;
      jNonALD++ ;
    }
  }
  return true ;
}

bool
NSPatientChoisi::buildSimplePrescriptionPatpatho(NSPatPathoArray* pPpt, NSPatPathoArray* pPrescriPpt, VecteurString* pNewTraitement, VecteurString* pNewLexique)
{
	if ((NULL == pPpt) || (NULL == pPrescriPpt))
		return false ;

	if ((NULL == pNewLexique) || (true == pNewLexique->empty()))
		return false ;
	if ((NULL == pNewTraitement) || (true == pNewTraitement->empty()))
		return false ;

	NSPatPathoArray SousPPT(pContexte) ;

	EquiItemIter i = pNewLexique->begin() ;
	EquiItemIter j = pNewTraitement->begin() ;

	while ((pNewLexique->end() != i) && (pNewTraitement->end() != j))
	{
  	// on cherche d'abord le code lexique correspondant au traitement
    // pour v�rifier s'il s'agit d'un m�dicament ou d'un renouvelement
    PatPathoIter pptItTrait = pPpt->ChercherNoeud(*(*j)) ;
    string sElemLex = (*pptItTrait)->getLexique() ;
    string sSens ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;
    SousPPT.vider() ;

    if (string("GRENT") == sSens)
    {
    	if (pDocLdv && pDocLdv->getDrugs())
      	pDocLdv->getDrugs()->getRenewPatPatho(&SousPPT, *(*j)) ;
      else
      	return false ;

      // Insertion en queue (iter doit �tre ici egal � end())
      pPrescriPpt->InserePatPatho(pPrescriPpt->end(), &SousPPT, 1) ;
    }
    else
    {
    	// prescription d'un nouveau m�dicament
      // constitution de la sous-patpatho du noeud
      pContexte->getPatient()->DonneSousArray(*(*j), &SousPPT) ;

      // on reconstitue la patpatho � partir du noeud
      pPrescriPpt->ajoutePatho(*(*i), 1) ;
      // Insertion en queue (iter doit �tre ici egal � end())
      pPrescriPpt->InserePatPatho(pPrescriPpt->end(), &SousPPT, 2) ;
  	}

    i++ ;
    j++ ;
	}
  return true ;
}

//---------------------------------------------------------------------------
//
// Recherche du document Index de sant�
// Finding the Health index document
//
//---------------------------------------------------------------------------
DocumentIter
NSPatientChoisi::trouveIndexSante()
{
	if (!pDocHis)
	{
		erreur("Erreur grave (historique introuvable). Vous devriez relancer le logiciel.", standardError, 0) ;
		return NULL ;
	}
	if (pDocHis->VectDocument.empty())
	{
		erreur("Erreur grave (historique vide). Vous devriez relancer le logiciel.", standardError, 0) ;
		return NULL ;
	}

	// Recherche du document "Index de sant�"
	// Looking for "Health index" document
	DocumentIter iterDoc ;

	bool bSearchIndex = true ;
	while (bSearchIndex)
	{
		bool bContinuer = true ;
		iterDoc = pDocHis->VectDocument.begin() ;
		while ((iterDoc != pDocHis->VectDocument.end()) && bContinuer )
		{
    	if (((*iterDoc)->pPatPathoArray) && (!((*iterDoc)->pPatPathoArray->empty())))
			{
				PatPathoIter iter = (*iterDoc)->pPatPathoArray->begin() ;
				if (strcmp((*iter)->pDonnees->lexique, "ZPOMR1") == 0)
					bContinuer = false ;
				else
					iterDoc++ ;
			}
      else
				iterDoc++ ;
		}

		// Index de sant� non trouv� - Health index not found
		if (iterDoc == pDocHis->VectDocument.end())
		{
			// En MUE on signale une erreur car l'index de sant� est normalement cr��
            // lors de l'initialisation du patient (m�thode NSPatientChoisi::CreeRootDocs())
            ::MessageBox(pContexte->GetMainWindow()->GetHandle(),
                            "Ce patient ne semble pas avoir de document des Index de sant�.",
                            "Attention", MB_OK);

            return NULL;
		}
		else
			bSearchIndex = false ;
	}

    // ???????????????????
	if (iterDoc == pDocHis->VectDocument.end())
		return NULL ;

    return iterDoc ;
}

void
NSPatientChoisi::remplaceTagsChemin(string& sHtml, NSPatPathoArray* pPatPathoArray)
{
	if (string("") == sHtml)
		return ;

  size_t pos2, pos3;
  string sChemin, sCheminSens, sValeur, sLabel;
  string sCheminNode, sCheminSensNode;
  string sTag, sTypeTag;
  PatPathoIter iterNode;
  bool bAvecPrecoche = false ;
  string answer_date;

  if (NULL == pPatPathoArray)
  	bAvecPrecoche = true ;

  // Etape 1 : on cherche les [[IF
  //
  // Attention : ils pourraient �tre imbriqu�s

  size_t pos1 = sHtml.find("[[IF") ;

  while (pos1 != NPOS)
  {
  	// Etape 1 : On prend le chemin et son contenu (Metatag)
    //
    pos2 = sHtml.find("]", pos1) ;
    if (pos2 == NPOS)
    {
    	erreur("Tag incorrect dans le html de pr�sentation du document.", standardError, 0) ;
      sHtml = "" ;
      return ;
    }
    // If a tag was opened before the closing ']', it means that this ']' didn't
    // close the [IF
    //
    size_t posOpenTag = sHtml.find("[", pos1+2) ;  // +2 because pos1 -> [[IF
    while (posOpenTag < pos2)
    {
      pos2       = sHtml.find("]", pos2+1) ;
      posOpenTag = sHtml.find("[", posOpenTag+1) ;
    }

    sChemin = string(sHtml, pos1+4, pos2-pos1-4) ;
    strip(sChemin, stripBoth) ;

    // On cherche le ] qui clot le IF
    //
    // On en profite pour trouver s'il y a un [ELSE]
    //
    size_t  pos1_else, pos2_else ;
    bool    bElse = false ;

    size_t  iHtmlLen    = strlen(sHtml.c_str()) ;
    size_t  pos3        = pos2 + 1 ;
    bool    bTourner    = true ;
    int     iCompteur   = 1 ;
    while (bTourner && (pos3 < iHtmlLen))
    {
    	if      (sHtml[pos3] == '[')
      {
        if ((iCompteur == 1) && (pos3 <= iHtmlLen - 6) &&
            (sHtml[pos3+1] == 'E') &&
            (sHtml[pos3+2] == 'L') && (sHtml[pos3+3] == 'S') &&
            (sHtml[pos3+4] == 'E') && (sHtml[pos3+5] == ']'))
        {
            bElse = true ;
            pos1_else = pos3 ;
            pos2_else = pos3 + 5 ;
        }
        iCompteur++ ;
      }
      else if (sHtml[pos3] == ']')
      	iCompteur-- ;

      if (iCompteur > 0)
      	pos3++ ;
      else
      	bTourner = false ;
    }
    if (iCompteur > 0)
    {
    	erreur("MetaTag incorrect dans le html de pr�sentation du document.", standardError, 0) ;
      sHtml = "" ;
      return ;
    }
    string sMetaTag = string(sHtml, pos2+1, pos3-pos2-1) ;

    //
    // On regarde si le tag est valide
    //

/*
    // on cr�e le chemin de codes sens

    //pContexte->getDico()->donneCodeSens(&sChemin, &sCheminSens);
    //
    // Trouv�
    //
    size_t pos4 ;

    // Is it just a path, or an expression
    //
    string sExpression = string("") ;

    size_t posBlank = sChemin.find(" ") ;
    if (string::npos != posBlank)
    {
      sExpression = string(sChemin, posBlank + 1, strlen(sChemin.c_str()) - posBlank - 1) ;
      strip(sExpression, stripBoth) ;

      sChemin = string(sChemin, 0, posBlank) ;
    }

    bool bPathFound = false ;
    if (false == bAvecPrecoche)
    {
    	if (pPatPathoArray->CheminDansPatpatho(sChemin, "|", &iterNode))
      {
      	bPathFound = true ;
        if (string("") != sExpression)
        {
          NSPatPathoArray subPatPatho(pContexte) ;
          pPatPathoArray->ExtrairePatPatho(iterNode, &subPatPatho) ;
          bool bExpressionIsValid ;
          bPathFound = subPatPatho.isExpressionTrue(sExpression, &bExpressionIsValid) ;
        }
      }
    }
    else
    {
    	NSPatPathoArray* pSearchPPt = 0 ;

    	int res = pContexte->getSuperviseur()->getBBinterface()->precoche(sChemin, "", &pSearchPPt, &answer_date) ;
			if ((res == 1) && (NULL != pSearchPPt) && (!(pSearchPPt->empty())))
      {
      	bPathFound = true ;
        if (string("") != sExpression)
        {
          bool bExpressionIsValid ;
          bPathFound = pSearchPPt->isExpressionTrue(sExpression, &bExpressionIsValid) ;
        }
      }

      if (NULL != pSearchPPt)
      	delete pSearchPPt ;
    }
*/

    int iBoolValue = getLogicalStringValue(sChemin, pPatPathoArray) ;

    bool bPathFound = (iBoolValue > 0) ;

    size_t pos4 ;

    if (true == bPathFound)
    {
      if (bElse)
      	pos4 = pos1_else ;
      else
      	pos4 = pos3 ;

      if (pos1 != 0)
      {
      	if (pos3 < iHtmlLen - 1)
        	sHtml = string(sHtml, 0, pos1) + string(sHtml, pos2+1, pos4-pos2-1) + string(sHtml, pos3+1, iHtmlLen-pos3-1) ;
      	else
        	sHtml = string(sHtml, 0, pos1) + string(sHtml, pos2+1, pos4-pos2-1) ;
      }
      else
      {
      	if (pos3 < iHtmlLen - 1)
        	sHtml = string(sHtml, pos2+1, pos4-pos2-1) + string(sHtml, pos3+1, iHtmlLen-pos3-1) ;
        else
        	sHtml = string(sHtml, pos2+1, pos4-pos2-1) ;
      }
    }
    //
    // Pas trouv� avec else
    //
    else if (bElse)
    {
      pos2 = pos2_else ;
      pos4 = pos3 ;

      if (pos1 != 0)
      {
        if (pos3 < iHtmlLen - 1)
        	sHtml = string(sHtml, 0, pos1) + string(sHtml, pos2+1, pos4-pos2-1) + string(sHtml, pos3+1, iHtmlLen-pos3-1) ;
        else
        	sHtml = string(sHtml, 0, pos1) + string(sHtml, pos2+1, pos4-pos2-1) ;
      }
      else
      {
        if (pos3 < iHtmlLen - 1)
        	sHtml = string(sHtml, pos2+1, pos4-pos2-1) + string(sHtml, pos3+1, iHtmlLen-pos3-1) ;
        else
        	sHtml = string(sHtml, pos2+1, pos4-pos2-1) ;
      }
    }
    //
    // Pas trouv� sans else
    //
    else
    {
    	if (pos1 != 0)
      {
        if (pos3 < iHtmlLen - 1)
        	sHtml = string(sHtml, 0, pos1) + string(sHtml, pos3+1, iHtmlLen-pos3-1) ;
        else
        	sHtml = string(sHtml, 0, pos1) ;
      }
      else
      {
        if (pos3 < iHtmlLen - 1)
        	sHtml = string(sHtml, pos3+1, iHtmlLen-pos3-1) ;
        else
        	sHtml = "" ;
      }
    }

    // Repartir au d�but pour g�rer les
    pos1 = sHtml.find("[[IF", pos1) ;
  }

  // Etape 2 : on remplace les autres tags

  pos1 = sHtml.find("[") ;

  while (pos1 != NPOS)
  {
    pos2 = sHtml.find("]", pos1);
    if (pos2 == NPOS)
    {
    	erreur("Tag incorrect dans le html de pr�sentation du document.", standardError, 0) ;
      sHtml = "" ;
      return ;
    }

    sTag = string(sHtml, pos1+1, pos2-pos1-1) ;
    pos3 = sTag.find(" ");
    if (pos3 == NPOS)
    {
    	erreur("Tag incorrect (type absent) dans le html de pr�sentation du document.", standardError, 0) ;
      sHtml = "" ;
      return ;
    }

    // Type de tag : LABEL ou VALUE
    sTypeTag = string(sTag, 0, pos3);
    if ((sTypeTag != "LABEL") && (sTypeTag != "VALUE") && (sTypeTag != "TREEVALUE") && (sTypeTag != "FREELABEL"))
    {
    	erreur("Tag de type inconnu dans le html de pr�sentation du document.", standardError, 0) ;
      sHtml = "" ;
      return ;
    }

    // Le chemin r�cup�r� est par convention un chemin de codes lexiques s�par�s par "/"
    //
    sChemin = string(sTag, pos3+1, strlen(sTag.c_str())-pos3-1) ;

    string sModifiers = string("") ;
    size_t posModifs = sChemin.find(":") ;
    if (string::npos != posModifs)
    {
      if (posModifs < strlen(sChemin.c_str()) - 1)
        sModifiers = string(sChemin, posModifs+1, strlen(sChemin.c_str())-posModifs-1) ;
      sChemin = string(sChemin, 0, posModifs) ;
    }

    // Starting by "?/" : if not found in pPatPathoArray, search in whole record
    //
    bool bGlobalSearch = false ;
    if ((string("") != sModifiers) && (string::npos != sModifiers.find("S=G")))
      bGlobalSearch = true ;

    // Le tag FREELABEL est consid�r� comme n'ayant rien � voir avec la patpatho
    // contrairement au tag LABEL qui est trait� comme un tag VALUE sans fils

    if (sTypeTag == "FREELABEL")
    {
    	// D�codage de l'�l�ment lexique
      // on forme une patpatho contenant l'�l�ment
      NSPatPathoArray PT(pContexte) ;

    	if (sChemin != string(""))
      {
      	string sElement = string("") ;
        sCheminNode = string("") ;

        size_t szPosLastSeparator = sChemin.find_last_of(string(1, cheminSeparationMARK)) ;
        if (szPosLastSeparator != string::npos)
        {
        	sCheminNode = string(sChemin, 0, szPosLastSeparator) ;
          sElement    = string(sChemin, szPosLastSeparator+1, strlen(sChemin.c_str())-szPosLastSeparator-1) ;
          pContexte->getDico()->donneCodeSens(&sCheminNode, &sCheminSensNode) ;
        }
        else
        	sElement = sChemin ;

        PT.ajoutePatho(sElement, 0) ;

        GlobalDkd Dcode(pContexte, pContexte->getUtilisateur()->donneLang(), sCheminSensNode, &PT) ;
        Dcode.decodeNoeud(sCheminNode) ;
        sLabel = *(Dcode.sDcodeur()) ;

        // pour un libell�, on met la premi�re lettre en majuscule
        sLabel[0] = pseumaj(sLabel[0]) ;

        sHtml.replace(pos1, pos2-pos1+1, sLabel) ;
        pos2 = pos1 + strlen(sLabel.c_str()) ;
      }
      else
			{
      	// iterNode n'est pas trouv� => on efface le tag
        sHtml.replace(pos1, pos2-pos1+1, "") ;
        pos2 = pos1 ;
      }
    }
    else
    {
      bool bMustDeleteSearchPpt = false ;
      NSPatPathoArray* pSearchPPt = 0 ;

    	// on r�cup�re la valeur du chemin sp�cifi� dans la patpatho du document
      //
    	bool bPathFound = false ;
    	if (false == bAvecPrecoche)
    	{
    		if (pPatPathoArray->CheminDansPatpatho(sChemin, string(1, cheminSeparationMARK), &iterNode))
        {
      		bPathFound = true ;
          pSearchPPt = pPatPathoArray ;
        }
        else if (bGlobalSearch)
        {
          int res = pContexte->getSuperviseur()->getBBinterface()->precoche(sChemin, "", &pSearchPPt, &answer_date) ;
				  if ((res == 1) && (NULL != pSearchPPt) && (false == pSearchPPt->empty()))
      		  bPathFound = true ;
          bMustDeleteSearchPpt = true ;
        }
    	}
    	else
      {
    		int res = pContexte->getSuperviseur()->getBBinterface()->precoche(sChemin, "", &pSearchPPt, &answer_date) ;
				if ((res == 1) && (NULL != pSearchPPt) && (false == pSearchPPt->empty()))
      		bPathFound = true ;
        bMustDeleteSearchPpt = true ;
    	}

    	if (true == bPathFound)
      {
        if (false == bAvecPrecoche)
        {
          // pour une valeur, on doit r�cup�rer le noeud suivant le chemin
          if (string("VALUE") == sTypeTag) 
            iterNode++ ;

          // on r�cup�re le chemin effectif (du pere) du node
          sCheminNode = pSearchPPt->donneCheminItem(iterNode);
        }
        else
        {
          if (pSearchPPt->empty())
          {
            sHtml = "" ;
            if ((true == bMustDeleteSearchPpt) && (NULL != pSearchPPt))
              delete pSearchPPt ;
            return ;
          }

          iterNode = pSearchPPt->begin() ;
          // pour une valeur, on doit r�cup�rer le noeud suivant le chemin
          if (string("VALUE") == sTypeTag)
            iterNode++ ;

          if (pSearchPPt->end() == iterNode)
          {
            sHtml = "" ;
            if ((true == bMustDeleteSearchPpt) && (NULL != pSearchPPt))
              delete pSearchPPt ;
            return ;
          }

          sCheminNode = sChemin ;
        }

        // on cr�e le chemin de codes sens
        pContexte->getDico()->donneCodeSens(&sCheminNode, &sCheminSensNode) ;

        // D�codage de l'�l�ment lexique
        // on forme une patpatho contenant l'�l�ment
        NSPatPathoArray PT(pContexte) ;

        if ((string("VALUE") == sTypeTag) || (string("LABEL") == sTypeTag))
        {
          if (pSearchPPt->end() != iterNode)
            PT.ajoutePatho(iterNode, 0, 0) ;
        }
        else if (string("TREEVALUE") == sTypeTag)
          pSearchPPt->ExtrairePatPatho(iterNode, &PT) ;

        if (false == PT.empty())
        {
          // TreeValue : all the tree must be published
          //
          if (string("TREEVALUE") == sTypeTag)
            sLabel = getTreeAsHtml(sCheminNode, &PT) ;
          else
          {
            GlobalDkd Dcode(pContexte, pContexte->getUtilisateur()->donneLang(), sCheminSensNode, &PT) ;
            Dcode.decodeNoeud(sCheminNode) ;
            sLabel = *(Dcode.sDcodeur()) ;

            // pour un libell�, on met la premi�re lettre en majuscule
            if ((string("LABEL") == sTypeTag) && (string("") != sLabel))
              sLabel[0] = pseumaj(sLabel[0]) ;
          }

          sHtml.replace(pos1, pos2-pos1+1, sLabel) ;
          pos2 = pos1 + strlen(sLabel.c_str()) ;
        }
        else
        {
          // iterNode n'est pas trouv� => on efface le tag
          sHtml.replace(pos1, pos2-pos1+1, "") ;
          pos2 = pos1 ;
        }
      }
      else
      {
        // iterNode n'est pas trouv� => on efface le tag
        sHtml.replace(pos1, pos2-pos1+1, "") ;
        pos2 = pos1 ;
      }

      if ((true == bMustDeleteSearchPpt) && (NULL != pSearchPPt))
        delete pSearchPPt ;
    }

    pos1 = sHtml.find("[", pos2) ;
  }
}

string
NSPatientChoisi::getTreeAsHtml(string sPath, NSPatPathoArray* pPatPathoArray)
{
  if ((NULL == pPatPathoArray) || pPatPathoArray->empty())
    return string("") ;

  string sHtmlValue = string("<ul>") ;

  for (PatPathoIter it = pPatPathoArray->begin(); pPatPathoArray->end() != it; it++)
	{
		if ((*it)->getColonne() == 0)
    {
      // decodeNoeud only treats the first node in the tree, so we have to
      // extract a ppt whose root is current node
      //
      NSPatPathoArray pptDecod(pContexte) ;
      pPatPathoArray->ExtrairePatPathoFreres(it, &pptDecod) ;

      GlobalDkd Dcode(pContexte, pContexte->getUtilisateur()->donneLang(), sPath, &pptDecod) ;
      Dcode.decodeNoeud(sPath) ;
      sHtmlValue += string("<li>") + *(Dcode.sDcodeur()) ;

      NSPatPathoArray pptFils(pContexte) ;
      pPatPathoArray->ExtrairePatPatho(it, &pptFils) ;
      if (false == pptFils.empty())
      {
        string sNewPath = sPath ;
        if (string("") != sNewPath)
          sNewPath += string(1, cheminSeparationMARK) ;
        sNewPath += (*it)->getNodeLabel() ;

        string sSonsHtmlValues = getTreeAsHtml(sNewPath, &pptFils) ;

        sHtmlValue += sSonsHtmlValues ;
      }

      sHtmlValue += string("</li>") ;
    }
  }

  sHtmlValue += string("</ul>") ;

  return sHtmlValue ;
}

//
// return : 0 false, 1 true, -1 invalid entry
//
int
NSPatientChoisi::getLogicalStringValue(string sFormula, NSPatPathoArray* pPatPathoArray)
{
  if (string("") == sFormula)
    return true ;

  VectString aBlocks ;

  // First step: just store distinct blocks
  //
  string sSubBlockSeparators = string("()!&|") ;

  size_t iBlockStart = 0 ;
  size_t iCurseur = 0 ;
  while (iCurseur < strlen(sFormula.c_str()))
  {
    // This char is a reserved char
    //
    if (sSubBlockSeparators.find(sFormula[iCurseur]) != string::npos)
    {
      string sBlockContent = string(sFormula, iBlockStart, iCurseur - iBlockStart) ;
      strip(sBlockContent, stripBoth) ;
      if ((string("") != sBlockContent) && (false == aBlocks.contains(sBlockContent)))
        aBlocks.push_back(new string(sBlockContent)) ;

      iCurseur++ ;

      // Looking for the starting char of next block (not a separator)
      //
      while ((iCurseur < strlen(sFormula.c_str())) &&
             (sSubBlockSeparators.find(sFormula[iCurseur]) != string::npos))
        iCurseur++ ;

      iBlockStart = iCurseur ;
    }
    else
      iCurseur++ ;
  }

  string sBlockContent = string(sFormula, iBlockStart, iCurseur - iBlockStart) ;
  strip(sBlockContent, stripBoth) ;
  if ((string("") != sBlockContent) && (false == aBlocks.contains(sBlockContent)))
    aBlocks.push_back(new string(sBlockContent)) ;

  if (aBlocks.empty())
    return -1 ;

  map<string, bool> mBoolVars ; // large streets :-)

  // Now, let give a boolean value to each block and assign them to a var inside
  // formula
  //
  size_t iBlockNb = 1 ;

  for (IterString it = aBlocks.begin() ; aBlocks.end() != it ; it++)
  {
    // Just check if this path exists, or "left value operator right value"?
    //
    string sPathToFind = **it ;
    string sExpression = string("") ;

    size_t posBlank = sPathToFind.find(" ") ;
    if (string::npos != posBlank)
    {
      sExpression = string(sPathToFind, posBlank + 1, strlen(sPathToFind.c_str()) - posBlank - 1) ;
      strip(sExpression, stripBoth) ;

      sPathToFind = string(sPathToFind, 0, posBlank) ;
    }

    string sModifiers = string("") ;
    size_t posModifs = sPathToFind.find(":") ;
    if (string::npos != posModifs)
    {
      if (posModifs < strlen(sPathToFind.c_str()) - 1)
        sModifiers = string(sPathToFind, posModifs+1, strlen(sPathToFind.c_str())-posModifs-1) ;
      sPathToFind = string(sPathToFind, 0, posModifs) ;
    }

    bool bPathFound = false ;

    if (NULL != pPatPathoArray)
    {
      PatPathoIter iterNode ;
    	if (pPatPathoArray->CheminDansPatpatho(sPathToFind, string(1, cheminSeparationMARK), &iterNode))
      {
      	bPathFound = true ;
        if (string("") != sExpression)
        {
          NSPatPathoArray subPatPatho(pContexte) ;
          pPatPathoArray->ExtrairePatPatho(iterNode, &subPatPatho) ;
          bool bExpressionIsValid ;
          bPathFound = subPatPatho.isExpressionTrue(sExpression, &bExpressionIsValid) ;
        }
      }
      // If not found in Ppt but Scope == Global, then look in patient record
      //
      else if (string::npos != sModifiers.find("S=G"))
      {
        NSPatPathoArray* pSearchPPt = 0 ;

        string answer_date ;
    	  int res = pContexte->getSuperviseur()->getBBinterface()->precoche(sPathToFind, "", &pSearchPPt, &answer_date) ;
			  if ((res == 1) && (NULL != pSearchPPt) && (!(pSearchPPt->empty())))
        {
      	  bPathFound = true ;
          if (string("") != sExpression)
          {
            bool bExpressionIsValid ;
            bPathFound = pSearchPPt->isExpressionTrue(sExpression, &bExpressionIsValid) ;
          }
        }

        if (NULL != pSearchPPt)
      	  delete pSearchPPt ;
      }
    }
    else
    {
    	NSPatPathoArray* pSearchPPt = 0 ;

      string answer_date ;
    	int res = pContexte->getSuperviseur()->getBBinterface()->precoche(sPathToFind, "", &pSearchPPt, &answer_date) ;
			if ((res == 1) && (NULL != pSearchPPt) && (!(pSearchPPt->empty())))
      {
      	bPathFound = true ;
        if (string("") != sExpression)
        {
          bool bExpressionIsValid ;
          bPathFound = pSearchPPt->isExpressionTrue(sExpression, &bExpressionIsValid) ;
        }
      }

      if (NULL != pSearchPPt)
      	delete pSearchPPt ;
    }

    // Now it's time to add this information to mBoolVars and update sFormula
    //
    string sBlockName = string("block") + IntToString(iBlockNb) ;
    iBlockNb++ ;

    size_t iBlockPos = sFormula.find(**it) ;
    while (string::npos != iBlockPos)
    {
      sFormula.replace(iBlockPos, strlen((*it)->c_str()), sBlockName) ;
      iBlockPos = sFormula.find(**it) ;
    }

    mBoolVars[sBlockName] = bPathFound ;
  }

  // Now, we just have to evaluate sFormula
  //
  size_t iFormulaStart = 0 ;
  return evaluate(&mBoolVars, sFormula, iFormulaStart) ;
}

//---------------------------------------------------------------------------
//  bloquer()
//
//  Inscrit le patient comme �tant bloqu� par cette console
//---------------------------------------------------------------------------
void
NSPatientChoisi::bloquer()
{
try
{
}
catch (...)
{
	erreur("Exception bloquer.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  bloquer()
//
//  Efface le patient du fichier de blocage
//---------------------------------------------------------------------------
void
NSPatientChoisi::debloquer()
{
try
{
	if (!getADebloquer())
		return ;

	NSBasicAttributeArray BAttrArray ;
  char szInstance[128] ;
  sprintf(szInstance, "%d", pContexte->getSuperviseur()->getInstance()) ;
  BAttrArray.push_back(new NSBasicAttribute(CONSOLE,	string(pContexte->getSuperviseur()->getConsole()))) ;
  BAttrArray.push_back(new NSBasicAttribute(INSTANCE,	string(szInstance))) ;
  BAttrArray.push_back(new NSBasicAttribute(PERSON,		getNss())) ;
  if (!pContexte->pPilot->unlockPatient(NautilusPilot::SERV_UNLOCK.c_str(), &BAttrArray))
  {
    string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "unlockError") ;
    return ;
  }

	setADebloquer(false) ;
}
catch (...)
{
	erreur("Exception debloquer.", standardError, 0) ;
}
}

void
NSPatientChoisi::DetruireDocument(NSDocumentInfo* pDocInfo)
{
try
{
	if (NULL == pDocInfo)
		return ;

	if (getReadOnly())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "patientFileIsReadOnly") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	string sCodeDoc = pDocInfo->getID() ;

	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

  // on rend d'abord le document invisible
  //
  pDocInfo->rendInvisible() ;

  // on doit r�-enregistrer le document Meta pour mettre visible � 0
  //
  NSDocumentInfo* pDocInfoMeta = new NSDocumentInfo(pContexte) ;
  //
  // remise � jour du pDocInfoMeta pour charger le document Meta
  // on pr�cise ici uniquement codePatient et codeDocument sans pr�ciser le type
  // on doit ensuite charger la patpatho � la main (cf NSDocumentInfo::ChargeDocMeta())
	//
  pDocInfoMeta->setPatient(pDocInfo->getPatient()) ;
  string sNewCodeDoc = string(pDocInfo->sCodeDocMeta, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;
  pDocInfoMeta->setDocument(sNewCodeDoc) ;

  // on recharge la patpatho avec les arrays de donn�es
  //
  NSNoyauDocument DocMeta(0, pDocInfoMeta, 0, pContexte, false) ;
  bool resultat = DocMeta.chargePatPatho() ;
  if ((false == resultat) || (true == DocMeta.pPatPathoArray->empty()))
  	return ;

  // on met � z�ro la donn�e visible du noeud racine
  (*(DocMeta.pPatPathoArray->begin()))->setVisible("0") ;
	if (DocMeta.enregistrePatPatho())
		DocMeta.NSNoyauDocument::chargePatPatho() ;  // on remet � jour le pMeta de la pDocInfo  *(pDocInfo->pMeta) = *(DocMeta.pPatPathoArray) ;

  // on supprime le lien personDocument de la partie Meta du document
  string sCodeDocMeta = pDocInfo->sCodeDocMeta ;

  VecteurString aVecteurString ;
  pGraphe->TousLesVrais(sCodeDocMeta, NSRootLink::personDocument, &aVecteurString, "ENVERS") ;
  if (aVecteurString.empty())
	{
    string sErrorText = pContexte->getSuperviseur()->getText("documentManagement", "thisDocumentHasAlreadyBeenDeleted") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), warningError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return ;
	}

	string sNodeRoot = *(*(aVecteurString.begin())) ;
	pGraphe->detruireLien(sNodeRoot, NSRootLink::personDocument, sCodeDocMeta) ;

	// on d�truit le lien sur l'ancienne chemise et on le relie � la corbeille
  //
	aVecteurString.vider() ;
	pGraphe->TousLesVrais(sCodeDocMeta, NSRootLink::docFolder, &aVecteurString, "ENVERS") ;

	if (!aVecteurString.empty())
	{
		string sNodeChemise = *(*(aVecteurString.begin())) ;
		pGraphe->detruireLien(sNodeChemise, NSRootLink::docFolder, sCodeDocMeta) ;
	}

	if ((NULL == pDocHis) || (NULL == pDocHis->pLibChem) || (NULL == pDocHis->pLibChem->pPatPathoArray))
		return ;
	if (pDocHis->pLibChem->pPatPathoArray->empty())
		return ;

	// On relie � la corbeille
	//
	// Le noeud corbeille est par construction la premi�re chemise
	//
	PatPathoIter iter = pDocHis->pLibChem->pPatPathoArray->begin() ;
	iter++ ;
	if (pDocHis->pLibChem->pPatPathoArray->end() == iter)
		return ;

	string sSens = (*iter)->getLexiqueSens(pContexte) ;
	if (sSens == string("0CHEM"))
	{
		string sNodeCorbeille = (*iter)->pDonnees->getNode() ;
		/* bool bRet = */ pGraphe->etablirLien(sNodeCorbeille, NSRootLink::docFolder, sCodeDocMeta) ;
	}
	else
	{
		string sErrorText = pContexte->getSuperviseur()->getText("documentManagement", "cannotFindTrashToPutTheDocumentIntoIt") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), warningError, 0, pContexte->GetMainWindow()->GetHandle()) ;
	}
}
catch (...)
{
	erreur("Exception NSPatientChoisi::DetruireDocument.", standardError, 0) ;
}
}

bool
NSPatientChoisi::updateIPPEnCours(string sSite, string sNewIpp)
{
	if (string("") == sNewIpp)
		return false ;

	NSPatPathoArray pptIdent(pContexte) ;
	bool bGetPpt = pGraphPerson->getLibIDsPpt(&pptIdent) ;

	// Does the IDs Library exist?
  //
	if (false == bGetPpt)
	{
  	NSDataGraph* pGraph = pGraphPerson->pDataGraph ;
    NSDataTreeIter iterTree ;
    if (false == pGraph->aTrees.ExisteTree("0LIBI1", pContexte, &iterTree))
    {
    	// Create an Identifiers Library
      //
    	bool bSuccess = CreeRootLibIDs() ;
      if (false == bSuccess)
      {
      	string sErrorText = pContexte->getSuperviseur()->getText("identifiersManagement", "cannotCreateIdentifiersLibrary") ;
    		pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
				erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      	return false ;
      }

      bool bGetNewPpt = pGraphPerson->getLibIDsPpt(&pptIdent) ;
      if (false == bGetNewPpt)
      {
      	string sErrorText = pContexte->getSuperviseur()->getText("identifiersManagement", "cannotAccessIdentifiersLibrary") ;
    		pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
				erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      	return false ;
      }
    }
  }

  string sCurrentIpp ;
  bool bExistIPP = pGraphPerson->IPPEnCours(&pptIdent, sSite, &sCurrentIpp) ;
  if ((true == bExistIPP) && (sCurrentIpp == sNewIpp))
		return true ;

	if (true == bExistIPP)
		pGraphPerson->ClotureIPP(&pptIdent, sSite, sCurrentIpp) ;

	// Adding the new identifier for this site
  //
  NSPatPathoArray pptIdLib(pContexte) ;
  pptIdLib.ajoutePatho("LIPP01", 0) ;

  Message Msg ;
  Msg.SetTexteLibre(sNewIpp) ;
  pptIdLib.ajoutePatho("�CL000", &Msg, 1) ;

  pptIdLib.ajoutePatho("KOUVR1", 1) ;

  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

  Msg.Reset() ;
  Msg.SetComplement(tpsNow.donneDateHeure()) ;
  Msg.SetUnit("2DA021") ;
  pptIdLib.ajoutePatho("�T0;19", &Msg, 2) ;

	bool bGraphUpdate = pGraphPerson->InsereIPPFusion(&pptIdent, sSite, &pptIdLib) ;

  if (false == bGraphUpdate)
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("identifiersManagement", "cannotUpdateIdentifiersLibrary") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return false ;
  }

	// Time to save
  //
	NSBasicAttributeArray *pAttrList = pGraphPerson->pAttrArray ;
  pAttrList->changeAttributeValue(IPP, sNewIpp) ;

	NSVectPatPathoArray VectUpdate ;
	string sTreeID      = string("") ;
  string sCodeDocMeta = string("") ;
	VectUpdate.push_back(new NSPatPathoArray(pptIdent)) ;

	pGraphPerson->updateTrees(&VectUpdate, &sTreeID, &sCodeDocMeta, pidsPatient) ;

	if (sTreeID == "")
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "failedToSave") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return false ;
	}

  return true ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSPatientChoisi::operator=(NSPatInfo src)
//  Description:	Op�rateur d'affectation
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
NSPatientChoisi&
NSPatientChoisi::operator=(NSPatInfo src)
{
	if (this == &src)
  	return *this ;

	*pDonnees 	   = *(src.getData()) ;
	*pCorrespArray = *(src.pCorrespArray) ;
	pContexte 	   = src.pContexte ;

  *pGraphPerson  = *(src.pGraphPerson) ;
  *pGraphAdr     = *(src.pGraphAdr) ;
  sChez          = src.sChez ;

  if (NULL != pDocHis)
  {
    delete pDocHis ;
    pDocHis = 0 ;
  }
  if (NULL != src.pDocHis)
    pDocHis = new NSHISTODocument(*(src.pDocHis)) ;

	return *this ;
}


//***************************************************************************
//
// Impl�mentation des m�thodes NSUtilisateurChoisi
//
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur � partir d'un NSSuper*
//---------------------------------------------------------------------------
NSUtilisateurChoisi::NSUtilisateurChoisi(NSContexte* pCtx)
                    :NSUtiliInfo(pCtx), aWinProp(pCtx)
{
	pPatRech     = 0;
	pDocCompta   = new NSDocCompta;
	pDocRefHisto = 0;
	pMail        = new NSMailParams;
	pRequete     = 0;
	pResult      = 0;
  bEnregWin    = false;
  // #ifdef N_TIERS
  //  bCreat       = true;
  // #endif
}

//---------------------------------------------------------------------------
//  Constructeur � partir de dataGraph et login + password
//---------------------------------------------------------------------------
NSUtilisateurChoisi::NSUtilisateurChoisi(NSContexte* pCtx, NSDataGraph *pDataGraph)
                    :NSUtiliInfo(pCtx), aWinProp(pCtx)
{
	pPatRech        = 0;
	pDocCompta      = new NSDocCompta;
	pDocRefHisto    = 0;
	pMail           = new NSMailParams;
	pRequete        = 0;
	pResult         = 0;
  bEnregWin       = false;

	pGraphPerson->pDataGraph = pDataGraph ;
}


//---------------------------------------------------------------------------
//      Destructeur
//---------------------------------------------------------------------------
NSUtilisateurChoisi::~NSUtilisateurChoisi()
{
try
{
	// Ces documents sont d�truits directement par la VisualView
	// en fin d'impression...
	// delete pDocCompta;
	// if (pDocRefHisto)
	//  	delete pDocRefHisto;

	//
	// A faire avant la fermeture de la transaction
	//
	if (NULL != pContexte->getPatient())
  {
    bool bOkToClosePatient = fermePatEnCours() ;
  }

	//
	// Fermeture de la transaction
	//
	// NSTransaction Transa(pContexte) ;
	// Transa.fermeTransaction() ;

	if (NULL != pMail)
		delete pMail ;

	//
	// Destruction du patient en cours
	//

#ifndef __EPIPUMP__
#ifndef __EPIBRAIN__
	if (pContexte->getPatient() == 0)
		if (pContexte->getSuperviseur()->getApplication()->GetMainWindow())
			pContexte->getSuperviseur()->getApplication()->prendClient()->CloseChildrenButServicesWindows() ;
#endif
#endif

	if (pPatRech)
		delete pPatRech ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi destructor", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  Fonction :		NSUtilisateurChoisi::SetUtilisateurChoisi()
//
//  Description :	Met � jour les variables de l'utilisateur.
//---------------------------------------------------------------------------
void
NSUtilisateurChoisi::SetUtilisateurChoisi(NSBasicAttributeArray *pAttrArray)
{
	if (NULL == pAttrArray)
		return ;

  _sLogin                = pAttrArray->getAttributeValue(LOGIN) ;
  _sPasswd               = pAttrArray->getAttributeValue(PASSWORD) ;
  _sUserType             = pAttrArray->getAttributeValue(USERTYPE) ;
  _sPasswordType         = pAttrArray->getAttributeValue(PASSWDTYPE) ;
  _sDatePasswordCreation = pAttrArray->getAttributeValue(STARTDATE) ;
  _sValidityDuration     = pAttrArray->getAttributeValue(DAYSNB) ;

  // string sIdRoot = pGraphPerson->pDataGraph->getGraphID() ;
  // string sPids = sIdRoot.substr(0, PAT_NSS_LEN) ;
  
  string sPids = pAttrArray->getAttributeValue(PIDS) ;
  setNss(sPids) ;
  pGraphPerson->setAttributeValue(PIDS, sPids) ;

  // pGraphPerson->setRootTree(sIdRoot) ; If root tree is set, then GetGraphUtil will not load the graph
  pGraphPerson->setRootTree(string("")) ;

	string ps = string("Initializing windows position") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

  // Initialisation des positions des fenetres
	aWinProp.initWindsChild(getNss(), pContexte->PathName("FGLO")) ;
  //
  // Setting user's Hot Keys
  //
  /*
  if (false == aWinProp.empty())
	{
		ArrayWPIter iter = aWinProp.begin() ;
  	for ( ; aWinProp.end() != iter ; iter++)
    {
    	if (string("") != (*iter)->getModifiers())
      {
      }
    }
	}
  */

  ps = string("Getting user's graph") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

  GetGraphUtil(this) ;
}

//---------------------------------------------------------------------------
//  Fonction :		NSUtilisateurChoisi::AppelPatient()
//
//  Description :	Cr�e le patient principal.
//---------------------------------------------------------------------------
void
NSUtilisateurChoisi::AppelPatient()
{
try
{
#ifndef __EPIPUMP__
	string sNom       = "" ;
	string sPrenom    = "" ;
	string sPatronyme = "" ;

	char Nom[PAT_NOM_LEN + 1] = "" ;
	char Prenom[PAT_PRENOM_LEN + 1] = "" ;
	// char NSS[PAT_NSS_LEN + 1] = "";
	// char Code[PAT_CODE_LEN + 1] = "";
	int  idRetour ;

	// Existe-t-il des donn�es de capture Episodus ?

	if (pContexte->getSuperviseur()->getEpisodus())
	{
		NSCaptureArray* pCapt = &(pContexte->getSuperviseur()->getEpisodus()->newCaptureArray) ;

	   /*	string sNom         = string("");
		string sPrenom      = string("");
		string sPatronyme   = string("");  */

		pCapt->trouveChemin(string("LNOM01"), &sNom) ;
		pCapt->trouveChemin(string("LNOM21"), &sPrenom) ;
		pCapt->trouveChemin(string("LPATR1"), &sPatronyme) ;

		if (sPatronyme != "")
		{
			size_t i ;
			//
			// Recherche de la premi�re lettre non majuscule
			//
			for (i = 0; (i < strlen(sPatronyme.c_str())) && (sPatronyme[i] == pseumaj(sPatronyme[i])); i++)
				;

			if (i < strlen(sPatronyme.c_str()))
			{
				if (i > 0)
				{
					for (; (i > 0) && (sPatronyme[i] != ' '); i--)
						;

          if (i > 0)
          {
						sNom    = string(sPatronyme, 0, i);
						sPrenom = string(sPatronyme, i+1, strlen(sPatronyme.c_str()) - i - 1);
					}
					else
						sPrenom = sPatronyme;
				}
				else
					sPrenom = sPatronyme;
			}
			else
			{
				if (strlen(sPatronyme.c_str()) > PAT_NOM_LEN)
					sPatronyme = string(sPatronyme, 0, PAT_NOM_LEN);
				strcpy(Nom, sPatronyme.c_str());
			}
		}

		if (sNom != "")
		{
			if (strlen(sNom.c_str()) > PAT_NOM_LEN)
				sNom = string(sNom, 0, PAT_NOM_LEN);
			strcpy(Nom, sNom.c_str());
		}

		if (sPrenom != "")
		{
			if (strlen(sPrenom.c_str()) > PAT_PRENOM_LEN)
				sPrenom = string(sPrenom, 0, PAT_PRENOM_LEN);
			strcpy(Prenom, sPrenom.c_str());
		}
	}

	/****************** Ancienne m�thode par CherchePatientDialog *************************
	int idRetour;
	//
	// Lancement de la boite de dialogue de recherche
	//
	idRetour = CherchePatientDialog(pSuper->pNSApplication->GetMainWindow(), pSuper).Execute();

	if (pPatient && (idRetour != IDCANCEL))
	{
		// R�cup�ration des donn�es rattach�es au patient : adresse et correspondants
		pPatient->Initialisation();
	}
	*************************************************************************************/

	//
	// Cr�ation de l'objet patient
	//
  if (!pPatRech)
  	pPatRech = new NSPatInfo(pContexte) ;

	NSNTiersListePatDialog* pPatDlg = 0 ;
	NSListeClientGroupDialog* pPatDlgGroup = 0 ;

	// Note : En principe on execute ici en fonction du r�sultat
	// de la recherche qui sera stock� dans pPatRech (NSPatInfo*)
  //
	if (false == pContexte->isClientGroup())
	{
		pPatDlg = new NSNTiersListePatDialog(pContexte->GetMainWindow(), pContexte, pPatRech) ;
		idRetour = pPatDlg->Execute() ;
	}
	else
	{
		pPatDlgGroup = new NSListeClientGroupDialog(pContexte->GetMainWindow(), pContexte, pPatRech) ;
		idRetour = pPatDlgGroup->Execute() ;
	}

	if (IDOK == idRetour)
	{
		pContexte->GetMainWindow()->SetCursor(0, IDC_WAIT) ;
		bool bCanClosePatient = ChangePatientChoisi() ;

    if (true == bCanClosePatient)
    {
      // A la fin d'une importation, en mode GroupInterfaceOnly,
      // Si on se rend compte que le graphe ne poss�de pas
      // d'index de sant� et/ou de synth�se, on cr�e ces documents.
      if ((pContexte->isClientGroup()) && (pContexte->isGroupInterfaceOnly()) && (pPatDlgGroup->mode == todoImport))
      {
        string sRootTree = pContexte->getPatient()->pGraphPerson->getRootTree() ;
        NSLinkManager* pLink = pContexte->getPatient()->pGraphPerson->pLinkManager ;
        VecteurString VectString ;

        // index de sant�
        pLink->TousLesVrais(sRootTree, NSRootLink::personHealthIndex, &VectString) ;
        if (VectString.empty())
          pContexte->getPatient()->CreeRootIndex() ;

        // synth�se
        VectString.vider() ;
        pLink->TousLesVrais(sRootTree, NSRootLink::personSynthesis, &VectString) ;
        if (VectString.empty())
          pContexte->getPatient()->CreeRootSynthese() ;
      }

      // On lance le patient :
      // R�cup�ration des donn�es rattach�es au patient : adresse et correspondants
      pContexte->getPatient()->Initialisation() ;
    }
		pContexte->GetMainWindow()->SetCursor(0, IDC_ARROW) ;
	}

	if (false == pContexte->isClientGroup())
		delete pPatDlg  ;
	else
		delete pPatDlgGroup ;

#endif // !__EPIPUMP__
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::AppelPatient().", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Function     : NSUtilisateurChoisi::OuvrePatient(string sNss)
// Description  : Ouvre un nouveau patient de code sNss et ferme le patient en
//                cours s'il existe
// -----------------------------------------------------------------------------
bool
NSUtilisateurChoisi::OuvrePatient(string sNss)
{
try
{
	// Cr�ation de l'objet patient

  if (!pPatRech)
    pPatRech = new NSPatInfo(pContexte) ;

	NSBasicAttributeArray LocalAttrArray ;
	LocalAttrArray.push_back(new NSBasicAttribute(PERSON,   sNss)) ;
	LocalAttrArray.push_back(new NSBasicAttribute(OPERATOR, pContexte->getUtilisateurID())) ;

  NSPersonsAttributesArray PatientList ;

  pContexte->GetMainWindow()->SetCursor(0, IDC_WAIT) ;

	bool res = pContexte->pPilot->searchPatient(NautilusPilot::SERV_OPEN_PATIENT_DATA_FROM_TRAITS.c_str(), pPatRech->pGraphPerson->pDataGraph,  &PatientList, &LocalAttrArray) ;

	if (!res)
	{
  	pContexte->GetMainWindow()->SetCursor(0, IDC_ARROW) ;
  	string tempMessage = pContexte->pPilot->getWarningMessage() ;
    string tempError = pContexte->pPilot->getErrorMessage() ;
    if (tempMessage != "")
    	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
    if (tempError != "")
    	::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
    return false ;
	}

	ChangePatientChoisi() ;

	pContexte->GetMainWindow()->SetCursor(0, IDC_ARROW) ;

  return true ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::OuvrePatient.", standardError, 0) ;
	return false ;
}
}

//------------------------------------------------------------------------------
//  Fonction :		NSUtilisateurChoisi::ChangePatientChoisi()
//
//  Description :	Ferme le patient principal et reprend pPatRech comme patient
//------------------------------------------------------------------------------
bool
NSUtilisateurChoisi::ChangePatientChoisi()
{
try
{
	bool bSwitcher = true ;

	// N.B. En mode MUE le fermeTransaction() est fait dans fermePatEnCours()
	// car la transaction d�pend du patient
	if (pContexte->getPatient())
		bSwitcher = fermePatEnCours() ;

	if (bSwitcher)
	{
    //set patient actif
    pContexte->setPatient(new NSPatientChoisi(pPatRech)) ;
    NSDataGraph* pGraph = pPatRech->pGraphPerson->pDataGraph ;
    string sIdRoot = pGraph->getGraphID() ;
    NSPatientChoisi* pPat = pContexte->getPatient() ;
    pPat->setNss(string(sIdRoot, 0, PAT_NSS_LEN)) ;
    pPat->pGraphPerson->setRootTree(sIdRoot) ;
    // Temporaire

    // string sLastTree = pContexte->getPatient()->pGraphPerson->pDataGraph->getLastTree();
	}

  return bSwitcher ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::ChangePatientChoisi().", standardError, 0) ;
  return false ;
}
}


//---------------------------------------------------------------------------
//  Fonction :		NSUtilisateurChoisi::fermePatEnCours()
//
//  Description :	Ferme le patient principal.
//---------------------------------------------------------------------------
bool
NSUtilisateurChoisi::fermePatEnCours(bool bWithSynchro)
{
	pContexte->getSuperviseur()->PurgeImpression() ;

	if (pContexte->getPatient())
	{
#ifndef __EPIPUMP__
		pContexte->getSuperviseur()->getEpisodus()->PatChanged() ;
# ifndef __EPIBRAIN__
		pContexte->getSuperviseur()->getDPIO()->PatChanged() ;
# endif // !__EPIBRAIN__
#endif // !__EPIPUMP__
	}
	if (pContexte->getSuperviseur()->getApplication()->GetMainWindow())
	{
#ifndef __EPIPUMP__
# ifndef __EPIBRAIN__
		// cas de fermeture historique (autre cas CmExit() dans nautilus.cpp)
		pContexte->getPatient()->bCanCloseHisto = true ;
		bool bAllClosed = pContexte->getSuperviseur()->getApplication()->prendClient()->CloseChildrenButServicesWindows() ;

    // If close was cancelled, return false
    if (false == bAllClosed)
      return false ;
# endif // !__EPIBRAIN__
#endif // !__EPIPUMP__
	}

	if (pContexte->getPatient())
	{
		// enregistrement des documents contenant des liens en attente
		NSPersonGraphManager* pGraphManager = pContexte->getPatient()->pGraphPerson ;
		string sNextDoc = pGraphManager->pLinkManager->nextDocToSave() ;
		while (sNextDoc != "")
		{
			pGraphManager->commitGraphTree(sNextDoc) ;
			sNextDoc = pGraphManager->pLinkManager->nextDocToSave() ;
		}

		// pContexte->getSuperviseur()->pEpisodus->PatChanged() ;
		// pContexte->getSuperviseur()->pDPIO->PatChanged() ;
		// on ferme la contribution juste avant de fermer la transaction
		pContexte->getPatient()->FermeContribution() ;

    if (pContexte->isClientGroup() && !pContexte->isGroupInterfaceOnly())
    {
      synchroImportThisPat(_sLogin, _sPasswd) ;
      synchroExportThisPat(_sLogin, _sPasswd) ;
    }

    pContexte->getUtilisateur()->bEnregWin = false ;

    // pour la synchro on ne delete pas le patient en cours
    // pour pouvoir le synchroniser et le r�ouvrir.
    if (false == bWithSynchro)
    {
      delete pContexte->getPatient() ;
      pContexte->setPatient(0) ;

      // on r�tablit le titre de l'application sans les infos patient
      pContexte->setMainCaption() ;
    }
	}

	return true ;
}

bool
NSUtilisateurChoisi::getAndRemoveIppFromPatpatho(NSPatPathoArray* pPpt, string* psIpp)
{
	if ((NULL == pPpt) || (NULL == psIpp))
		return false ;

	*psIpp = string("") ;

	if (true == pPpt->empty())
		return true ;

	// Looking for an Identifier Library root concept
  //
  PatPathoIter It = pPpt->begin() ;
  while ((NULL != It) && (pPpt->end() != It) &&
                      (string("0LIBI") != (*It)->getLexiqueSens(pContexte)))
		It = pPpt->ChercherFrere(It) ;

	// No Identifier in ppt
	//
	if ((NULL == It) || (pPpt->end() == It))
		return true ;

	NSPatPathoArray pptIdsLibrary(pContexte) ;
  pPpt->ExtrairePatPatho(It, &pptIdsLibrary) ;

	// Suppress the identifier tree
  //
  pPpt->SupprimerItem(It) ;

	// Identifier tree contains no identifier
  //
	if (false == pptIdsLibrary.CheminDansPatpatho(string("LSITE1/LIPP01"), string(1, cheminSeparationMARK), &It))
		return true ;

	int Col = (*It)->getColonne() ;
	It++ ;
  if ((pptIdsLibrary.end() != It) && ((*It)->getColonne() == Col+1) &&
         			        (string("�CL") == (*It)->getLexiqueSens(pContexte)))
  	*psIpp = (*It)->getTexteLibre() ;

	return true ;
}

bool
NSUtilisateurChoisi::createPatient(NSPatPathoArray *pPatPathoAdmin)
{
	if ((NULL == pPatPathoAdmin) || (true == pPatPathoAdmin->empty()))
		return false ;

//	int typeCode ;

  pContexte->setPatient(new NSPatientChoisi(pContexte)) ;

  // Remove IPP if exists
  string sIPP = string("") ;
  getAndRemoveIppFromPatpatho(pPatPathoAdmin, &sIPP) ;

  //donn�es patient correspondantes au PIDS
  pContexte->getPatient()->ChargeDonneesPatient(pPatPathoAdmin) ;

  //l'dentifiant PIDS in memoire
  pContexte->getPatient()->setNss(string(1, INMEMORY_CHAR) + string(PIDS_NSS_LEN - 1, '0')) ;

  string sRootDocGraph = string(1, INMEMORY_CHAR) + string(DOC_CODE_DOCUM_LEN - 1, '0') ;
  string sRootGraph = pContexte->getPatient()->getNss() + sRootDocGraph ;

  //on fixe la racine du graphe du patient
  pContexte->getPatient()->pGraphPerson->setRootTree(sRootGraph) ;
  pContexte->getPatient()->pGraphPerson->pDataGraph->setLastTree(sRootGraph) ;

  pContexte->getPatient()->CreeRootDocs(pPatPathoAdmin) ;

  string user = pContexte->getUtilisateurID() ;

  NSDataGraph* pGraph = pContexte->getPatient()->pGraphPerson->pDataGraph ;
  NSPersonsAttributesArray PatiensList ;

  char szInstance[3] ;
  int iInstance = pContexte->getSuperviseur()->getInstance() ;
  itoa(iInstance, szInstance, 10) ;

  // NSBasicAttributeArray *pAttrList = new NSBasicAttributeArray() ;
  NSBasicAttributeArray *pAttrList = pContexte->getPatient()->pGraphPerson->pAttrArray ;
  pAttrList->push_back(new NSBasicAttribute(LAST_NAME,  pContexte->getPatient()->getNom())) ;
  pAttrList->push_back(new NSBasicAttribute(FIRST_NAME, pContexte->getPatient()->getPrenom())) ;
  pAttrList->push_back(new NSBasicAttribute(SEX,        pContexte->getPatient()->getSexe())) ;
  pAttrList->push_back(new NSBasicAttribute(BIRTHDATE,  pContexte->getPatient()->getNaissance())) ;
  pAttrList->push_back(new NSBasicAttribute(OPERATOR,   user)) ;
  pAttrList->push_back(new NSBasicAttribute(CONSOLE,    string(pContexte->getSuperviseur()->getConsole()))) ;
  pAttrList->push_back(new NSBasicAttribute(INSTANCE,   string(szInstance))) ;
  if (string("") != sIPP)
  	pAttrList->push_back(new NSBasicAttribute(IPP, sIPP)) ;

/*
  bool bRes = pContexte->pPilot->createPersonOrObject(NautilusPilot::SERV_CREATE_PATIENT.c_str(), pGraph, &PatiensList, pAttrList) ;
  if ((!bRes) || (!pGraph))
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("patientManagement", "patientCreationError") ;
    erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
  }
*/

	bool bRes = pContexte->getPatient()->pGraphPerson->writeGraph(pidsPatient, 0) ;
  if (bRes == false)
  	return false ;

  // ---------------------------------------------------------------------------
	// Ugly patch : createPersonOrObject should give these status... but doesn't
  pContexte->getPatient()->setADebloquer(true) ;
  pContexte->getPatient()->setReadOnly(false) ;

  pContexte->getPatient()->setContribution(pGraph->getLastContribution()) ;

  string sPersonId = pContexte->getPatient()->pGraphPerson->getPersonID() ;
  if (sPersonId == "")
  {
    string sErrorText = pContexte->getSuperviseur()->getText("patientManagement", "patientIdCreationError") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
  }
  pAttrList->push_back(new NSBasicAttribute(PERSON, sPersonId)) ;

  NSDataTreeIter iterTree ;

  // cr�ation de l'Equipe de Sant�
  // utiliser la classe HT pour cr�er la HealthTeam du patient
  NSPatPathoArray	ppt(pContexte) ;
  ppt.ajoutePatho(HEALTHTEAM, 0) ;
  NSHealthTeam HealthTeam(&ppt) ;
  NSHealthTeamManager	HTManager(&HealthTeam) ;

  NVLdVTemps	ldvCurDate ;	ldvCurDate.takeTime() ;
  NVLdVTemps	ldvNoLimit ;	ldvNoLimit.setNoLimit() ;

  // ajout des mandats du patient -- adding Patient mandates
  NSHTMMandateArray	MandatesArray ;
  MandatesArray.push_back(new NSHealthTeamMandate(patDist, 0, "", "", ldvCurDate.donneDateHeure(), ldvNoLimit.donneDateHeure(), "", "", NSHealthTeamMandate::root)) ;
  MandatesArray.push_back(new NSHealthTeamMandate(patDist, 0, "", "", ldvCurDate.donneDateHeure(), ldvNoLimit.donneDateHeure(), "", "", NSHealthTeamMandate::user)) ;
  HTManager.addMember(new NSHealthTeamMember(sPersonId, NSHealthTeamMember::person, &MandatesArray), NSHealthTeamMember::person) ;

  // ajout de l'Equipe M�dicale du site -- adding Hospital Medical Team mandate
  // il faut d'abord faire un appel au pilot pour trouver l'�quipe m�dicale locale
  // s'il y en a plusieurs, les equipes medicales sont separes par des "|"
  vector<string> vLocalTeams = pContexte->getSuperviseur()->getLocalTeams() ;
  if (!vLocalTeams.empty())
  {
    for (vector<string>::iterator lTeamIter = vLocalTeams.begin() ; lTeamIter != vLocalTeams.end() ; lTeamIter++)
    {
      string sLocalTeam = *lTeamIter ;
      NSHTMMandateArray MandatesArr ;
      MandatesArr.push_back(new NSHealthTeamMandate(nearDist, 3, "", "", ldvCurDate.donneDateHeure(), ldvNoLimit.donneDateHeure(), "", "", NSHealthTeamMandate::user)) ;
      HTManager.addMember(new NSHealthTeamMember(sLocalTeam, NSHealthTeamMember::team, &MandatesArr), NSHealthTeamMember::team) ;
    }
  }
/*
  if (sLocalTeamsID != "")
  {
    size_t firstID  = 0 ;
    size_t nextID   = sLocalTeamsID.find("|") ;
    while (nextID != string::npos)
    {
      string sLocalTeam = string(sLocalTeamsID, firstID, nextID - firstID) ;
      pMandatesArray = new NSHTMMandateArray() ;
      pMandatesArray->push_back(new NSHealthTeamMandate(nearDist, 3, "", "", ldvCurDate.donneDateHeure(), ldvNoLimit.donneDateHeure(), "", "", NSHealthTeamMandate::user)) ;
      pHTManager->addMember(new NSHealthTeamMember(sLocalTeam, NSHealthTeamMember::team, pMandatesArray), NSHealthTeamMember::team) ;
      delete pMandatesArray ;
      firstID = nextID + 1 ;
      nextID  = sLocalTeamsID.find("|", firstID) ;
    }
    string sLocalTeam = string(sLocalTeamsID, firstID, strlen(sLocalTeamsID.c_str()) - firstID) ;
    pMandatesArray = new NSHTMMandateArray() ;
    pMandatesArray->push_back(new NSHealthTeamMandate(nearDist, 3, "", "", ldvCurDate.donneDateHeure(), ldvNoLimit.donneDateHeure(), "", "", NSHealthTeamMandate::user)) ;
    pHTManager->addMember(new NSHealthTeamMember(sLocalTeam, NSHealthTeamMember::team, pMandatesArray), NSHealthTeamMember::team) ;
    delete pMandatesArray ;
  }
*/
  else
  {
    // ajout des mandats de l'utilisateur -- adding user mandate
    NSHTMMandateArray MandatesArr ;
    MandatesArr.push_back(new NSHealthTeamMandate(nearDist, 3, "", "", ldvCurDate.donneDateHeure(), ldvNoLimit.donneDateHeure(), "", "", NSHealthTeamMandate::user)) ;
    HTManager.addMember(new NSHealthTeamMember(user, NSHealthTeamMember::person, &MandatesArr), NSHealthTeamMember::person) ;
  }

  NSRefDocument HTRefDoc(0, 0, 0, pContexte, false) ;
  *(HTRefDoc.pPatPathoArray) = *(HTManager.getPatho()) ;

  if (!HTRefDoc.Referencer("ZCS00", "Equipe de Sant�", "", "", true, false, "", NSRootLink::personHealthTeam))
	  return false ;

	// le code est etabli dans la methode referencer
  string sHealthTeamDocData = pContexte->getPatient()->pGraphPerson->pDataGraph->getLastTree() ;
  pContexte->getPatient()->pGraphPerson->setTree(HTRefDoc.pPatPathoArray, "", sHealthTeamDocData) ;

  // etablir lien ZA entre les metaDonn�es et les donn�es.
  // bool *pCreerMetaLien = &(HTRefDoc.NSNoyauDocument::bCreerMetaLien) ;
  // pContexte->getPatient()->etablirLiensTree(pCreerMetaLien, HTRefDoc.sCodeDocMeta, sHealthTeamDocData) ;

  pContexte->getPatient()->etablirLiensTree(HTRefDoc.NSNoyauDocument::bCreerMetaLien, HTRefDoc.sCodeDocMeta, sHealthTeamDocData) ;

	//
  // Identifiers Library creation
  //
	if (string("") != sIPP)
  {
  	string sSite = pContexte->getSuperviseur()->getIppSite() ;

    NSPatPathoArray	pptIdLib(pContexte) ;

    pptIdLib.ajoutePatho("0LIBI1", 0) ;
    pptIdLib.ajoutePatho("LSITE1", 1) ;

    Message Msg ;

    if (string("") != sSite)
  	{
      Msg.SetComplement(sSite) ;
      pptIdLib.ajoutePatho("�OBJE1", &Msg, 2) ;
    }

    pptIdLib.ajoutePatho("LIPP01", 2) ;

    Msg.Reset() ;
    Msg.SetTexteLibre(sIPP) ;
    pptIdLib.ajoutePatho("�CL000", &Msg, 3) ;

    pptIdLib.ajoutePatho("KOUVR1", 3) ;

    NVLdVTemps tpsNow ;
    tpsNow.takeTime() ;

    Msg.Reset() ;
    Msg.SetComplement(tpsNow.donneDateHeure()) ;
    Msg.SetUnit("2DA021") ;
    pptIdLib.ajoutePatho("�T0;19", &Msg, 4) ;

    NSRefDocument IDRefDoc(0, 0, 0, pContexte, false) ;
    *(IDRefDoc.pPatPathoArray) = pptIdLib ;

    if (true == IDRefDoc.Referencer("ZCS00", "Identifiants", "", "", true, false, "", NSRootLink::personIdentifiers))
    {
      // le code est etabli dans la methode referencer
      string sIdDocData = pContexte->getPatient()->pGraphPerson->pDataGraph->getLastTree() ;
      pContexte->getPatient()->pGraphPerson->setTree(IDRefDoc.pPatPathoArray, "", sIdDocData) ;

      pContexte->getPatient()->etablirLiensTree(IDRefDoc.NSNoyauDocument::bCreerMetaLien, IDRefDoc.sCodeDocMeta, sIdDocData) ;
    }
  }

  bRes = pContexte->pPilot->modifyPersonOrObject(NautilusPilot::SERV_MODIFY_PERSON.c_str(), pGraph, &PatiensList, pAttrList) ;

  if ((!bRes) || (!pGraph))
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("HealthTeamManagement", "patientModifyError") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
  }

  // Update du nss et de la contribution initiale LCTRI1
  pContexte->getPatient()->setNss(pContexte->getPatient()->pGraphPerson->getPersonID()) ;
  if (pGraph->aTrees.ExisteTree("LCTRI1", pContexte, &iterTree))
    pContexte->getPatient()->setContribution((*iterTree)->getTreeID()) ;
  else
    erreur("Erreur � la recherche de la contribution initiale du patient.", standardError, 0) ;

  pContexte->getPatient()->setReadOnly(false) ;

  return true ;
}

bool
NSUtilisateurChoisi::createCorrespondant(NSCorrespondantInfo* pNewCorresp)
{
	if (NULL == pNewCorresp)
		return false ;

try
{
	NSPatPathoArray PatPathoCor(pContexte, graphPerson) ;

	NSSmallBrother BigBoss(pContexte, &PatPathoCor) ;
	BigBoss.pFenetreMere = pContexte->GetMainWindow() ;
	// Ici on lance une boite de dialogue modale
	// BB1BBInterfaceForKs InterfaceForKs(-1, pContexte->getSuperviseur()->getAddressArchetypeId(), "", false) ;
  BB1BBInterfaceForKs InterfaceForKs(-1, pContexte->getSuperviseur()->getReferalProfessionnalArchetypeId(), "", false) ;
	BigBoss.lanceBbkArchetypeInDialog(pContexte->getSuperviseur()->getReferalProfessionnalArchetypeId(), 0, 0, &InterfaceForKs, true) ;

	// on teste le code de retour du dialogue, qui est stock� dans le
	// BBItem root cr�� par le pBigBoss.
	if (BigBoss.pBBItem->iRetourDlg == 0)     // CmOK
	{
		// on enregistre la patpatho du pBigBoss, qui contient les nouvelles donn�es
		// si elle n'est pas vide.
		if (!(BigBoss.getPatPatho()->empty()))
		{
    	PatPathoCor = *(BigBoss.getPatPatho()) ;

			pNewCorresp->GetDataFromGraph(&PatPathoCor) ;

			string sNewPids = string(1, INMEMORY_CHAR) + string(PAT_NSS_LEN - 1, '_') ;
			NSBasicAttributeArray AttrList ;
			AttrList.push_back(new NSBasicAttribute(OPERATOR,   pContexte->getUtilisateurID())) ;
			AttrList.push_back(new NSBasicAttribute(FIRST_NAME, pNewCorresp->getPrenom())) ;
			AttrList.push_back(new NSBasicAttribute(LAST_NAME,  pNewCorresp->getNom())) ;
			AttrList.push_back(new NSBasicAttribute(PIDS,       sNewPids)) ;
			pNewCorresp->pGraphPerson->setInfoPids(&AttrList) ;

			if (pNewCorresp->pGraphPerson->setGraphAdmin(&PatPathoCor, pidsCorresp))
			{
				// on r�cup�re le personID pour le stocker dans nss
				string sPersonID = pGraphPerson->getPersonID() ;  ///
				if (string("") != sPersonID)
        	pNewCorresp->setNss(sPersonID) ;
			}
		}
	}
	return true ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::CreePIDS().", standardError, 0) ;
	return false ;
}
}

bool
NSUtilisateurChoisi::importPatientLdv()
{
try
{
	NSPatientImportDialog* pDialog = new NSPatientImportDialog(pContexte->GetMainWindow(), pContexte);
	if (pDialog->Execute() != IDOK)
  {
		delete pDialog ;
		return true ;
	}

  const char* serviceName = (NautilusPilot::SERV_PATIENT_IMPORT).c_str() ;
  NSPersonGraphManager GraphManager(pContexte) ;
  NSDataGraph *pGraph = GraphManager.pDataGraph ;

  NSBasicAttributeArray AttrList ;
  AttrList.push_back(new NSBasicAttribute(ROLE, PATIENT_ROLE)) ;
  AttrList.push_back(new NSBasicAttribute(LIDEN, pDialog->sNumLdv)) ;
  AttrList.push_back(new NSBasicAttribute(LOGIN, pDialog->sLogin)) ;
  AttrList.push_back(new NSBasicAttribute(PASSWORD, pDialog->sPasswd)) ;
  AttrList.push_back(new NSBasicAttribute(OPERATOR, pContexte->getUtilisateurID())) ;

  bool bRes = pContexte->pPilot->importPerson(serviceName, &AttrList, pGraph) ;

  if ((!bRes)||(!pGraph))
  {
    /*string sErrorText = pContexte->getSuperviseur()->getText("patientManagement", "patientImportError") ;  */
		string sWarningText = pContexte->pPilot->getWarningMessage() ;
		if (sWarningText != "")
    {
    	pContexte->getSuperviseur()->trace(&sWarningText, 1, NSSuper::trWarning) ;
			erreur(sWarningText.c_str(), warningError, 0) ;
    }
		else
		{
			string sErrorText = pContexte->pPilot->getErrorMessage() ;
			if (sErrorText != "")
      {
      	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
				erreur(sErrorText.c_str(), standardError, 0) ;
      }
		}
    return false ;
  }

  // =========== PARSING DU GRAPHE et sauvegarde des traits ==================

	GraphManager.parseMainAttributes() ;

  string user = pContexte->getUtilisateurID() ;
  char szInstance[3] ;
  int iInstance = pContexte->getSuperviseur()->getInstance() ;
  itoa(iInstance, szInstance, 10) ;
  serviceName = (NautilusPilot::SERV_CREATE_IMPORTED_PATIENT).c_str() ;

  NSPersonsAttributesArray PersonsList ;

//  NSBasicAttributeArray *pAttrArray = pGraphManager->pAttrArray ;
	AttrList.vider() ;

  AttrList.push_back(new NSBasicAttribute(LAST_NAME,  GraphManager.getAttributeValue(LAST_NAME))) ;
  AttrList.push_back(new NSBasicAttribute(FIRST_NAME, GraphManager.getAttributeValue(FIRST_NAME))) ;
  AttrList.push_back(new NSBasicAttribute(SEX,        GraphManager.getAttributeValue(SEX))) ;
  AttrList.push_back(new NSBasicAttribute(BIRTHDATE,  GraphManager.getAttributeValue(BIRTHDATE))) ;
  AttrList.push_back(new NSBasicAttribute(OPERATOR,   user)) ;
  AttrList.push_back(new NSBasicAttribute(CONSOLE,    string(pContexte->getSuperviseur()->getConsole()))) ;
  AttrList.push_back(new NSBasicAttribute(INSTANCE,   string(szInstance))) ;
  AttrList.push_back(new NSBasicAttribute(PERSON,     GraphManager.getPersonID())) ;
  string sRootDoc = string(GraphManager.getRootTree(), PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;
  AttrList.push_back(new NSBasicAttribute(ROOTDOC,    sRootDoc)) ;

  bRes = pContexte->pPilot->createImportedPerson(serviceName, pGraph, &PersonsList, &AttrList) ;

  if (!bRes)
  {
    string sErrorText = pContexte->getSuperviseur()->getText("patientManagement", "importedPatientCreationError") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
  }

  // import all objects for this patient
  NSBasicAttributeArray AttrObjectsArray ;
  AttrObjectsArray.push_back(new NSBasicAttribute(OPERATOR, user)) ;
  AttrObjectsArray.push_back(new NSBasicAttribute(PERSON,   GraphManager.getPersonID())) ;

  bRes = pContexte->pPilot->updateObjectList(NautilusPilot::SERV_UPDATE_ALL_LDV_OBJECTS.c_str(), pGraph, &AttrObjectsArray) ;
  if (!bRes)
  {
  	string sErrorText = pContexte->pPilot->getWarningMessage() ;
    if (string("") != sErrorText)
    {
    	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    	erreur(sErrorText.c_str(), standardError, 0) ;
    }

    sErrorText = pContexte->getSuperviseur()->getText("patientManagement", "errorImportObjects") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
    return true ;
  }

  // on ouvre maintenant le patient import�
  // on doit mettre celui-ci dans le patient de recherche (pPatRech)
  // avant de faire le changement de patient et l'appel de la routine d'initialisation
  if (pPatRech)
    delete pPatRech ;

  GraphManager.setAttributeValue(PERSON,   GraphManager.getPersonID()) ;
  // pAttrArray->setAttributeValue(ROOTDOC, sRootDoc);
  GraphManager.setAttributeValue(OPERATOR, user) ;
	GraphManager.setAttributeValue(CONSOLE,  string(pContexte->getSuperviseur()->getConsole())) ;
	GraphManager.setAttributeValue(INSTANCE, string(szInstance)) ;

	if (pPatRech)
		delete pPatRech ;
  pPatRech = new NSPatInfo(&AttrList, pContexte) ;
  *(pPatRech->pGraphPerson) = GraphManager ;

  ChangePatientChoisi() ;
  pContexte->getPatient()->pGraphPerson->bNeedUnlock = true ;
  pContexte->getPatient()->pGraphPerson->bReadOnly = false ;
	pContexte->getPatient()->pGraphPerson->pDataGraph->setLastTree("") ;
  // On lance le patient :
  // R�cup�ration des donn�es rattach�es au patient : adresse et correspondants
  pContexte->getPatient()->Initialisation() ;

	delete pDialog ;
	return true ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::importPatientLdv().", standardError, 0) ;
	return false ;
}
}

bool
NSUtilisateurChoisi::importUserLdv()
{
try
{
  NSUserImportDialog userImportDlg(pContexte->GetMainWindow(), pContexte) ;
	if (userImportDlg.Execute() != IDOK)
	{
		return true ;
	}

	NSBasicAttributeArray AttrList ;
	const char* serviceName ;
	NSPersonGraphManager  gManager(pContexte) ;
	NSDataGraph *pGraph = gManager.pDataGraph ;
	// pAttrList->push_back(new NSBasicAttribute(ROLE, pDialog->sRole));

	serviceName = (NautilusPilot::SERV_USER_IMPORT).c_str() ;
	AttrList.push_back(new NSBasicAttribute(LOGIN, userImportDlg.sLogin)) ;
	AttrList.push_back(new NSBasicAttribute(PASSWORD, userImportDlg.sPasswd)) ;

	bool bRes = pContexte->pPilot->importPerson(serviceName, &AttrList, pGraph) ;
	if ((!bRes) || (!pGraph))
	{
		// string sErrorText = pContexte->getSuperviseur()->getText("patientManagement", "patientCreationError") ;
		/*	string sErrorText = "Echec de la proc�dure d'importation." ;    */
		string sWarningText = pContexte->pPilot->getWarningMessage() ;
		if (sWarningText != "")
    {
    	pContexte->getSuperviseur()->trace(&sWarningText, 1, NSSuper::trWarning) ;
			erreur(sWarningText.c_str(), warningError, 0) ;
    }
		else
		{
			string sErrorText = pContexte->pPilot->getErrorMessage() ;
			if (sErrorText != "")
      {
      	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
				erreur(sErrorText.c_str(), standardError, 0) ;
      }
		}
		//	erreur(sErrorText.c_str(), standardError, 0) ;

		return false ;
	}

	// =========== PARSING DU GRAPHE et sauvegarde des traits ==================

	gManager.parseMainAttributes();

	// Appeler la boite de dialogue de cr�ation / modification
	// pour d�finir login et mot de passe, type, etc...
	// puis appeler createImportedPerson
	TModule                 *module = pContexte->GetMainWindow()->GetModule() ;
	CreerUtilisateurDialog  newUtilDlg(pContexte->GetMainWindow(), pContexte, module) ;
	NSUtiliInfo             newUtilInfo(gManager.pAttrArray, pContexte) ;

	serviceName = (NautilusPilot::SERV_CREATE_IMPORTED_USER).c_str() ;
	AttrList.vider() ;

	// on charge ici les MainAttributes dans le dialogue
	*(newUtilDlg.pData) = *(newUtilInfo.getData()) ;

	while ((newUtilDlg.Execute()) == IDCANCEL)
	{
		int retVal = ::MessageBox(0, "L'annulation entrainera l'�chec de la proc�dure d'importation de cet utilisateur. Voulez-vous continuer ?", "Message Nautilus", MB_YESNO) ;
		if (retVal == IDYES)
			return false ;
	}

	// on stocke les donnees du dialogue dans les Data
	*(newUtilInfo.getData())          = *(newUtilDlg.pData) ;
	newUtilInfo.setLogin(newUtilDlg.getLogin()) ;
	newUtilInfo.setPasswd(newUtilDlg.getPasswd()) ;
	newUtilInfo.setUserType(newUtilDlg.getUserType()) ;
	newUtilInfo.setPassType(newUtilDlg.getPassType()) ;
	newUtilInfo.setPassDate(newUtilDlg.getPassDate()) ;
	newUtilInfo.setValidity(newUtilDlg.getValidity()) ;

	// on construit maintenant les nouvelles valeurs de PIDS pour le pilote
	string sLogin     = newUtilInfo.getLogin() ;
	string sPasswd    = newUtilInfo.getPasswd() ;
	string sNss       = gManager.getPersonID() ;
  string sUserType  = newUtilInfo.getUserType() ;

	// On met � jour le graphe de l'utilisateur de pUtilInfo
	AttrList.push_back(new NSBasicAttribute(LOGIN,      sLogin)) ;
	AttrList.push_back(new NSBasicAttribute(PASSWORD,   sPasswd)) ;
	// pAttrList->push_back(new NSBasicAttribute(PIDS, sNss));
	AttrList.push_back(new NSBasicAttribute(PERSON,     sNss)) ;
	AttrList.push_back(new NSBasicAttribute(OPERATOR,   pContexte->getUtilisateurID())) ;
	AttrList.push_back(new NSBasicAttribute(USERTYPE,   newUtilInfo.getUserType())) ;
	AttrList.push_back(new NSBasicAttribute(PASSWDTYPE, newUtilInfo.getPassType())) ;
	if (string("") != newUtilInfo.getValidity())
  	AttrList.push_back(new NSBasicAttribute(DAYSNB,   newUtilInfo.getValidity())) ;
	AttrList.push_back(new NSBasicAttribute(FIRST_NAME, newUtilInfo.getPrenom())) ;
	AttrList.push_back(new NSBasicAttribute(LAST_NAME,  newUtilInfo.getNom())) ;
	AttrList.push_back(new NSBasicAttribute(ROOTDOC,    string(DOC_CODE_DOCUM_LEN, '0'))) ;
	gManager.setInfoPids(&AttrList);

	NSPersonsAttributesArray PersonsList ;
	bRes = pContexte->pPilot->createImportedPerson(serviceName, pGraph, &PersonsList, &AttrList) ;
	if (!bRes)
	{
		// string sErrorText = pContexte->getSuperviseur()->getText("patientManagement", "patientCreationError") ;
		erreur("Echec de la proc�dure d'importation (phase 2).", standardError, 0) ;
		return false ;
	}

  if (sUserType.find("U") != string::npos)
  {
    // FIXME TODO -- FLP
    // here we have to insert imported user in local medical team
    // il faut r�cup�rer l'ID de la personne cr��e et l'ajouter dans l'Equipe M�dicale locale (ou toutes les equipes medicales locales)
    vector<string> vLocalTeams = pContexte->getSuperviseur()->getLocalTeams() ;
    if (!vLocalTeams.empty())
    {
      for (vector<string>::iterator lTeamIter = vLocalTeams.begin() ; lTeamIter != vLocalTeams.end() ; lTeamIter++)
      {
        NVLdVTemps	ldvCurDate ;	ldvCurDate.takeTime() ;
        NVLdVTemps	ldvNoLimit ;	ldvNoLimit.setNoLimit() ;

        // r�cup�ration de l'objet Team et ajout de la nouvelle personne
        NSTeamGraphManager teamManager(pContexte) ;
        NSPatPathoArray	ppt(pContexte) ;
        teamManager.getTeamGraph(*lTeamIter, &ppt) ;

        NSMoralPerson MoralPerson(&ppt) ;
        NSMoralPersonManager mpManager(&MoralPerson) ;

        NSHTMMandateArray MandatesArray ;
        MandatesArray.push_back(new NSHealthTeamMandate(nearDist, 3, "", "", ldvCurDate.donneDateHeure(), ldvNoLimit.donneDateHeure(), "", "", NSHealthTeamMandate::user)) ;
        mpManager.addMember(new NSHealthTeamMember(sNss, NSHealthTeamMember::person, &MandatesArray), NSHealthTeamMember::person) ;

        // + appel pilot pour modifier la Team
        teamManager.setTeamGraph(mpManager.getPatho(), pContexte->getUtilisateurID()) ;
      }
    }
  }

  // Create user directory and specific files
	//
  CreateUserFiles(sNss) ;

	return true ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::importUserLdv().", standardError, 0) ;
	return false ;
}
}


// -----------------------------------------------------------------------------
// NSUtilisateur::importCorrespLdv
// -----------------------------------------------------------------------------
// function that imports a "correspondant" (a contact) from LdV server.
// -----------------------------------------------------------------------------
bool
NSUtilisateurChoisi::importCorrespLdv()
{
try
{
  NSCorrespImportDialog* pDialog = new NSCorrespImportDialog(pContexte->GetMainWindow(), pContexte) ;
  if (pDialog->Execute() != IDOK)
  {
    delete pDialog ;
    return false ;
  }

  string sLogin   = pDialog->sLogin ;
  string sPasswd  = pDialog->sPasswd ;
  string sAdeliID = pDialog->sAdeli ;
  string sLdVID   = pDialog->sNumLdv ;
  delete pDialog ;

  NSPersonGraphManager GraphManager(pContexte) ;
  NSDataGraph *pGraph = GraphManager.pDataGraph ;
  // pAttrList->push_back(new NSBasicAttribute(ROLE, pDialog->sRole)) ;

  const char* serviceName = (NautilusPilot::SERV_CORRESPONDENT_IMPORT).c_str() ;

  NSBasicAttributeArray AttrList ;
  if (sAdeliID != "")
		AttrList.push_back(new NSBasicAttribute(ADELI_ID, sAdeliID)) ;
  else if (sLdVID != "")
		AttrList.push_back(new NSBasicAttribute(LIDEN, sLdVID)) ;
  else
    return false ;

	AttrList.push_back(new NSBasicAttribute(LOGIN, sLogin)) ;
	AttrList.push_back(new NSBasicAttribute(PASSWORD, sPasswd)) ;
  bool bRes = pContexte->pPilot->importPerson(serviceName, &AttrList, pGraph) ;
  if ((!bRes) || (!pGraph))
  {
    // string sErrorText = pContexte->getSuperviseur()->getText("patientManagement", "patientCreationError") ;
    /*	string sErrorText = "Echec de la proc�dure d'importation." ;    */
    string sWarningText = pContexte->pPilot->getWarningMessage() ;
    if (sWarningText != "")
    {
    	pContexte->getSuperviseur()->trace(&sWarningText, 1, NSSuper::trError) ;
      erreur(sWarningText.c_str(), standardError, 0) ;
    }
    else
    {
      string sErrorText = pContexte->pPilot->getErrorMessage() ;
      if (sErrorText != "")
      {
      	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
        erreur(sErrorText.c_str(), standardError, 0) ;
      }
    }
    //	erreur(sErrorText.c_str(), standardError, 0) ;

    return false ;
  }

  // =========== PARSING DU GRAPHE et sauvegarde des traits ==================

	GraphManager.parseMainAttributes() ;

  string sCorrespId = GraphManager.getPersonID() ;
  serviceName = (NautilusPilot::SERV_CREATE_IMPORTED_CORRESP).c_str() ;
  AttrList.vider() ;
  AttrList.push_back(new NSBasicAttribute(OPERATOR,   pContexte->getUtilisateurID())) ;
  AttrList.push_back(new NSBasicAttribute(LAST_NAME,  GraphManager.getAttributeValue(LAST_NAME))) ;
  AttrList.push_back(new NSBasicAttribute(FIRST_NAME, GraphManager.getAttributeValue(FIRST_NAME))) ;
  AttrList.push_back(new NSBasicAttribute(PERSON,     sCorrespId)) ;
  string sRootDoc = string(GraphManager.getRootTree(), PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;
  AttrList.push_back(new NSBasicAttribute(ROOTDOC,    sRootDoc)) ;

  NSPersonsAttributesArray PersonsList ;
  bRes = pContexte->pPilot->createImportedPerson(serviceName, pGraph, &PersonsList, &AttrList) ;
  if (!bRes)
  {
    // string sErrorText = pContexte->getSuperviseur()->getText("patientManagement", "patientCreationError") ;
    string sErrorText = "Echec de la proc�dure d'importation (phase 2)." ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
  }

  if (sCorrespId != "")
  {
    char  szBuffer[1024] ;
    NSPersonInfo* pPersonInfo = pContexte->getPersonArray()->getPerson(sCorrespId, pidsCorresp) ;
    sprintf(szBuffer, "Le correspondant \"%s\" a bien �t� import�", pPersonInfo->sCivilite.c_str()) ;
    MessageBox(NULL, szBuffer, "Importation d'un correspondant", MB_OK) ;
  }  return true ;
}
catch (...)
{
  erreur("Exception NSUtilisateurChoisi::importCorrespLdv().", standardError, 0) ;
  return false ;
}
}

bool
NSUtilisateurChoisi::synchroImportThisPat(string sGlobalLogin, string sGlobalPasswd)
{
try
{
	const char* serviceName = (NautilusPilot::SERV_IMPORT_DATA).c_str();
	NSPersonGraphManager* pGraphManager = pContexte->getPatient()->pGraphPerson ;
	NSDataGraph*          pGraph = pGraphManager->pDataGraph ;

	NSBasicAttributeArray AttrList ;
	AttrList.push_back(new NSBasicAttribute(LOGIN,    sGlobalLogin)) ;
	AttrList.push_back(new NSBasicAttribute(PASSWORD, sGlobalPasswd)) ;
	AttrList.push_back(new NSBasicAttribute(PERSON,   pGraphManager->getPersonID())) ;

	bool bRes = pContexte->pPilot->importNewDataGraphPerson(serviceName, &AttrList, pGraph) ;

	if ((!bRes)||(!pGraph))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("patientSynchronization", "patientImportError") ;
		if (sErrorText == "")
			sErrorText = "Echec de la proc�dure de mise � jour depuis la Ligne de vie.";
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	// pGraphManager->setInfoPids(pAttrArray);
	pGraphManager->pDataGraph->setLastTree() ;

  return true ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::synchroImportThisPat().", standardError, 0) ;
	return false ;
}
}

bool
NSUtilisateurChoisi::synchroExportThisPat(string sGlobalLogin, string sGlobalPasswd)
{
try
{
	const char* serviceName = (NautilusPilot::SERV_EXPORT_DATA).c_str() ;
	NSPersonGraphManager* pGraphManager = pContexte->getPatient()->pGraphPerson ;
	NSDataGraph *pGraph = pGraphManager->pDataGraph ;

  NSBasicAttributeArray AttrList ;
	string sPID = pGraphManager->getPersonID() ;
	AttrList.push_back(new NSBasicAttribute(LOGIN,    sGlobalLogin)) ;
	AttrList.push_back(new NSBasicAttribute(PASSWORD, sGlobalPasswd)) ;
	AttrList.push_back(new NSBasicAttribute(PERSON,   sPID)) ;

	bool bRes = pContexte->pPilot->exportNewDataGraphPerson(serviceName, &AttrList) ;

	if ((!bRes)||(!pGraph))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("patientManagement", "patientExportError") ;
		if (sErrorText == "")
			sErrorText = "Echec de la proc�dure de synchronisation vers la Ligne de vie.";
		string sExecError =  pContexte->pPilot->getWarningMessage() +  pContexte->pPilot->getErrorMessage() ;
		sErrorText =  sErrorText + "\n" + sExecError;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

  string sText = pContexte->getSuperviseur()->getText("patientSynchronization", "operationOk") ;
  pContexte->getSuperviseur()->trace(&sText, 1, NSSuper::trError) ;
  erreur(sText.c_str(), warningError, 0) ;
  return true ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::synchroExportThisPat().", standardError, 0) ;
	return false ;
}
}

//---------------------------------------------------------------------------
//  Fonction :		NSUtilisateurChoisi::initMail()
//
//  Description :	Charge les param�tres SMTP et POP3 � partir de email.dat.
//---------------------------------------------------------------------------
bool
NSUtilisateurChoisi::initMail()
{
	// une erreur bizzare pousse � d�finir deux ifstreams
	ifstream inFile1, inFile2;
	string  line;
	string  sData = "";
	string  sNomAttrib;
	string  sValAttrib;
	size_t  i = 0, j = 0;

	string sFichier = string("email") + getNss() + string(".dat") ;

	inFile1.open(sFichier.c_str());
	if (!inFile1)
	{
		inFile2.open("email.dat");
		if (!inFile2)
		{
    	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") + string(" email.dat") ;
    	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
			erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
			return false ;
		}

		while (!inFile2.eof())
		{
			getline(inFile2,line) ;
			if (line != "")
				sData += line + "\n" ;
		}

		inFile2.close() ;
	}
	else
	{
		while (!inFile1.eof())
		{
			getline(inFile1,line) ;
			if (line != "")
				sData += line + "\n" ;
		}

		inFile1.close() ;
	}

	// boucle de chargement des attributs
	i = 0 ;
	while (i < strlen(sData.c_str()))
	{
		sNomAttrib = "" ;
		sValAttrib = "" ;

		while ((i < strlen(sData.c_str())) && (sData[i] != ' ') && (sData[i] != '\t'))
			sNomAttrib += pseumaj(sData[i++]) ;

		while ((strlen(sData.c_str())) && ((sData[i] == ' ') || (sData[i] == '\t')))
			i++ ;

		while ((strlen(sData.c_str())) && (sData[i] != '\n'))
			sValAttrib += sData[i++] ;

		i++ ;

		if ((sNomAttrib == "URLSMTP") && (sValAttrib != ""))
			pMail->sUrlSMTP = sValAttrib ;
		else
			if ((sNomAttrib == "PORTSMTP") && (sValAttrib != ""))
				pMail->iPortSMTP = atoi((sValAttrib).c_str()) ;
			else
				if ((sNomAttrib == "USERSMTP") && (sValAttrib != ""))
					pMail->sUserSMTP = sValAttrib ;
				else
					if ((sNomAttrib == "MAILEXP") && (sValAttrib != ""))
						pMail->sMailExp = sValAttrib ;
					else
						if ((sNomAttrib == "URLPOP3") && (sValAttrib != ""))
							pMail->sUrlPOP3 = sValAttrib ;
						else
							if ((sNomAttrib == "PORTPOP3") && (sValAttrib != ""))
								pMail->iPortPOP3 = atoi((sValAttrib).c_str()) ;
							else
								if ((sNomAttrib == "USERPOP3") && (sValAttrib != ""))
									pMail->sUserPOP3 = sValAttrib ;
								else
									if ((sNomAttrib == "PASSPOP3") && (sValAttrib != ""))
										pMail->sPassPOP3 = sValAttrib ;
									else
										if ((sNomAttrib == "METHODE") && (sValAttrib != ""))
										{
											if (sValAttrib == "0")
												pMail->iTypeEnvoi = NSMAIL_NAUTILUS ;
											else
												if (sValAttrib == "1")
													pMail->iTypeEnvoi = NSMAIL_MAPI ;
												else
												{
													for (j = 0; j < strlen(sValAttrib.c_str()); j++)
														sValAttrib[j] = pseumaj(sValAttrib[j]) ;
													if (sValAttrib == "NAUTILUS")
														pMail->iTypeEnvoi = NSMAIL_NAUTILUS ;
													else
														if (sValAttrib == "MAPI")
															pMail->iTypeEnvoi = NSMAIL_MAPI ;
												}
										}
	}

	return true ;
}

void
NSUtilisateurChoisi::CmRequete()
{
try
{
	if (pResult)
	{
		string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
		::MessageBox(0, "Vous devez fermer le dialogue des r�sultats avant de lancer une nouvelle requ�te.", sCaption.c_str(), MB_OK) ;
		return;
	}

	if (!pRequete)
		pRequete = new NSRequeteDialog(pContexte->GetMainWindow(), pContexte) ;

	if (pRequete->Execute() == IDCANCEL)
	{
		delete pRequete ;
		pRequete = 0 ;
		return ;
	}

	CmResult() ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::CmRequete().", standardError, 0) ;
}
}

void
NSUtilisateurChoisi::CmResult()
{
try
{
	if (!pResult)
		pResult = new NSResultReqDialog(pContexte->GetMainWindow(), pContexte, pRequete) ;

	if (pResult->Execute() == IDCANCEL) // cas Masquer : on ne fait rien
		return ;

	if (pResult->itemChoisi > -1)
	{
  	string sNss = (pResult->VectPatResultat[pResult->itemChoisi])->getNss() ;

		if (OuvrePatient(sNss))
		{
			if (pResult->bReqModeDoc)
			{
				// cas du mode document : on ouvre aussi le document
				NSDocumentInfo* pDocumentInfo = new NSDocumentInfo(pContexte) ;
				*(pDocumentInfo->getData()) = *((pResult->VectDocResultat[pResult->itemChoisi])->getData()) ;
				pContexte->getPatient()->pDocHis->AutoriserOuverture(pDocumentInfo) ;
			}
		}
	}
	else
	{
		delete pResult ;
		pResult = 0 ;
		if (pRequete)
			CmRequete() ;
	}
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::CmResult().", standardError, 0) ;
}
}

void NSUtilisateurChoisi::CmEditRef()
{
try
{
/*
	NSRefEditeur* pDlg = new NSRefEditeur(pContexte->GetMainWindow(), pContexte);
	pDlg->Execute();
	delete pDlg;
*/
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::CmEditRef().", standardError, 0) ;
}
}

void NSUtilisateurChoisi::CmEditArchetype()
{
try
{
/*
    NSArcEditeur* pDlg = new NSArcEditeur(pContexte->GetMainWindow(), pContexte);
    pDlg->Execute();
    delete pDlg;
*/
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::CmEditArchetype().", standardError, 0) ;
}
}

void NSUtilisateurChoisi::CmEditTemplate()
{
try
{
	NSEditTemplateDialog* pDlg = new NSEditTemplateDialog(pContexte->GetMainWindow(), pContexte);
	if (pDlg->Execute() == IDOK)
	{
    NSObjectGraphManager GraphObject(pContexte) ;
    string sRootId = GraphObject.setTree(pDlg->pPatPatho, "") ;
    GraphObject.setRootObject(sRootId) ;

    // Appel du pilote
    NSDataGraph* pGraph = GraphObject.pDataGraph ;
    //pObectsList la liste d'objects qui correspondent a ces criteres
    NSPersonsAttributesArray ObjectsList ;

    // Elaboration des traits
    string user = "_000000" ;
    if (pContexte->getUtilisateur()!= NULL)
    	user = pContexte->getUtilisateurID() ;

    string sTraitType = string("_0OTPL") + string("_0TYPE") ;
    string sTraitOper = string("_0OTPL") + string("_DOPER") ;
    string sTraitCons = string("_0OTPL") + string("_LNUCO") ;
    string sTraitRoot = string("_0OTPL") + string("_0TYPC") ;
    string sTraitComp = string("_0OTPL") + string("_0COMD") ;
    string sTraitDefa = string("_0OTPL") + string("_0DEFA") ;

    NSBasicAttributeArray AttrList ;
    AttrList.push_back(new NSBasicAttribute("user",     user)) ;
    AttrList.push_back(new NSBasicAttribute(sTraitType, pDlg->sTypeDoc)) ;
    AttrList.push_back(new NSBasicAttribute(sTraitOper, pDlg->sOper)) ;
    AttrList.push_back(new NSBasicAttribute(sTraitCons, pDlg->sNoConsole)) ;
    AttrList.push_back(new NSBasicAttribute(sTraitRoot, pDlg->sLexiqueRoot)) ;
    AttrList.push_back(new NSBasicAttribute(sTraitComp, pDlg->sCompo)) ;
    AttrList.push_back(new NSBasicAttribute(sTraitDefa, pDlg->sDefaut)) ;

    pContexte->pPilot->createPersonOrObject(NautilusPilot::SERV_CREATE_OBJECT.c_str(),
                        pGraph, &ObjectsList, &AttrList, OBJECT_TYPE, false);

    if (!pGraph)
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("templateManagement", "templateCreationError") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    	erreur(sErrorText.c_str(), standardError, 0) ;
      delete pDlg ;
      return ;
    }

    string sErrorText = pContexte->getSuperviseur()->getText("templateManagement", "templateSuccessfullyCreated") ;
    ::MessageBox(0, sErrorText.c_str(), "", MB_OK) ;
	}
  delete pDlg ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::CmEditTemplate().", standardError, 0) ;
}
}


// -----------------------------------------------------------------------------
// TODO : cette m�thode a semble-t-il �t� d�connect� en grande partie en N_TIERS
//        il reste des balises N_TIERS � l'int�rieur de !N_TIERS
// Refactor programm� pour RS
// TODO FIXME -- RS
// --
// FLP
// -----------------------------------------------------------------------------
void
NSUtilisateurChoisi::CmNewEnTete()
{
try
{
  WIN32_FIND_DATA FileData ;
  HANDLE          hSearch ;  char            szMask[255] ;  bool            bFinish = false ;  bool            bExisteModele = false ;  size_t          pos, pos1, pos2 ;  string          sPathName, sFileName, sExtension ;  string          sHTM ;  DWORD           dwAttr ;  VecteurString*  pFiles = new VecteurString() ;  VecteurString*  pNames = new VecteurString() ;  pContexte->getSuperviseur()->afficheStatusMessage("Recherche de la liste des modeles") ;  sPathName = pContexte->PathName("NTPL") ;  strcpy(szMask, sPathName.c_str()) ;  strcat(szMask, "*.*") ;
  hSearch = FindFirstFile(szMask, &FileData) ;  if (hSearch == INVALID_HANDLE_VALUE)
  {    erreur("Aucun fichier trouv� dans le r�pertoire template.", standardError, 0) ;    pContexte->getSuperviseur()->afficheStatusMessage("") ;    return ;  }
  while (!bFinish)  {    dwAttr = FileData.dwFileAttributes ;
    if (!(dwAttr & FILE_ATTRIBUTE_DIRECTORY))
    {      sFileName = string(FileData.cFileName) ;      // R�cup�ration de l'extension      pos = sFileName.find(".") ;    }
    if ((!(dwAttr & FILE_ATTRIBUTE_DIRECTORY)) && (pos != string::npos))    {      sExtension = string(sFileName, pos + 1, strlen(sFileName.c_str()) - pos - 1) ;      if ((sExtension == "htm") || (sExtension == "HTM") || (sExtension == "html") || (sExtension == "HTML"))
      {        pos1 = sFileName.find("modele") ;        if (pos1 != string::npos)        {          ifstream inFile ;          string   line ;          string   sModele, sTitre ;          string   sTagModele = string("{modele}") ;          // recherche du titre du modele (� afficher dans la liste)          sHTM = sPathName + sFileName ;          if (!bExisteModele)            bExisteModele = true ;          inFile.open(sHTM.c_str()) ;          if (!inFile)
          {
            string sErrorText = "Erreur d'ouverture du fichier mod�le " + sHTM ;
            pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
            erreur(sErrorText.c_str(), standardError, 0) ;
            return ;
          }
          while (!inFile.eof())
          {
            getline(inFile,line) ;
            if (line != "")
              sModele += line + "\n" ;
          }
          inFile.close() ;
          pos1 = sModele.find(sTagModele) ;          if (pos1 != string::npos)          {            pos1 += strlen(sTagModele.c_str()) ;            pos2 = sModele.find("{/modele}") ;            if (pos2 != string::npos)            {              sTitre = string(sModele, pos1, pos2 - pos1) ;            }            else            {              string sErrorText = string("Erreur de syntaxe du titre du fichier mod�le ") + sHTM ;              pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
              erreur(sErrorText.c_str(), standardError, 0) ;              sTitre = string("modele : ") + sFileName ;            }          }          else          {            sTitre = string("modele : ") + sFileName ;          }          pFiles->push_back(new string(sHTM)) ;          pNames->push_back(new string(sTitre)) ;        }      }    }
    if (!FindNextFile(hSearch, &FileData))    {      if (GetLastError() == ERROR_NO_MORE_FILES)        bFinish = true ;      else      {        erreur("Impossible de trouver le fichier suivant dans le r�pertoire des templates.", standardError, 0) ;        pContexte->getSuperviseur()->afficheStatusMessage("") ;        return ;      }    }  }

  pContexte->getSuperviseur()->afficheStatusMessage("") ;

  if (!bExisteModele)
  {
    erreur("Aucun fichier modele trouv� dans le r�pertoire des templates.", standardError, 0) ;
    return ;
  }

  ChoixDansListeDialog listDialog(pContexte->GetMainWindow(), pContexte, pNames) ;
  if ((listDialog.Execute() == IDCANCEL) || (listDialog.itemChoisi == -1))
    return ;

  // pListeDialog->pListBox->GetString(str, pListeDialog->itemChoisi);
  // string modele = pContexte->PathName("NTPL") + string("modele.htm");
  string modele = *((*pFiles)[listDialog.itemChoisi]) ;
//  delete pListeDialog ;
  delete pFiles ;
  delete pNames ;

  NSEnTeteEditDialog enteteDlg(pContexte->GetMainWindow(), pContexte, modele) ;
  if (enteteDlg.Execute() != IDOK)
  {
//    delete pDlg ;
    return ;
  }
//  delete pDlg ;

	string fichier = string("entete_") + pContexte->getUtilisateur()->getNss() + string(".htm") ;

  string sFirstCode, sLastCode, sNewCode, sCode ;
	// int    iNewCode ;
  // char   szNewCode[10] ;
  // bool   bPremier = true ;

	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
	::MessageBox(0, "Nouvel en-t�te cr�� avec succ�s.", sCaption.c_str(), MB_OK) ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::CmNewEnTete().", standardError, 0) ;
}
}

void NSUtilisateurChoisi::CmModEnTete()
{
try
{
	string entete = pContexte->PathName("NTPL") + string("entete_") +
                    pContexte->getUtilisateur()->getNss() + string(".htm") ;

	NSEnTeteEditDialog* pDlg = new NSEnTeteEditDialog(pContexte->GetMainWindow(), pContexte, entete) ;
	if (pDlg->Execute() == IDOK)
	{
  	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    ::MessageBox(0, "En-t�te modifi� avec succ�s.", sCaption.c_str(), MB_OK) ;
  }
  delete pDlg ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::CmModEnTete().", standardError, 0) ;
}
}

void NSUtilisateurChoisi::CmRefArchetype()
{
try
{
	char path[1024] ;

	// on choisi d'abord le r�pertoire par d�faut des archetypes (IXML)
	strcpy(path,(pContexte->PathName("IXML")).c_str());

	TFileOpenDialog::TData initData(OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
																	"Tous fichiers (*.XML)|*.xml|",
																	0,
																	path,
																	"XML");

	int iUserChoice = TFileOpenDialog(pContexte->GetMainWindow(), initData).Execute() ;

	pContexte->reallocateBaseDirectory() ;

	if (IDOK != iUserChoice)
		return ;

	string sFileName = string(initData.FileName);
	string sFichArc, sPathArc ;

	size_t pos = sFileName.find_last_of("\\");
	if (pos != NPOS)
	{
		sPathArc = string(sFileName, 0, pos+1) ;
		sFichArc = string(sFileName, pos+1, strlen(sFileName.c_str())-pos-1) ;
	}
	else
	{
		sPathArc = "" ;
		sFichArc = sFileName ;
	}

	nsarcParseur ArcParseur(pContexte) ;
	nsrefParseur RefParseur(pContexte) ;

	if (ArcParseur.open(sFileName))
	{
		string sRes = pContexte->getArcManager()->AjouteArchetype(NSArcManager::archetype,
                                                    ArcParseur.pArchetype->getName(),
                                                    sFichArc, sPathArc) ;
		if (sRes != "")
    	::MessageBox(0, "L'archetype est r�f�renc� dans la librairie XML.", "Message Nautilus", MB_OK) ;
	}
	else if (RefParseur.open(sFileName))
	{
    string sTypeName   = string("") ;
    string sDomainName = string("") ;
    Creferences* pRefRef = RefParseur.pReferentiel->getReference() ;
    if (NULL != pRefRef)
    {
      Cconcern *pConcern = pRefRef->getFirstCconcern() ;
      if (NULL != pConcern)
      {
        sTypeName   = pConcern->getCode() ;
        sDomainName = pConcern->getCategory() ;
      }
    }

    string sTitle = RefParseur.pReferentiel->getTitle() ;

		string sRes = pContexte->getArcManager()->AjouteArchetype(NSArcManager::referentiel,
                                                    RefParseur.pReferentiel->getName(),
                                                    sFichArc, sPathArc, sTypeName,
                                                    sDomainName, sTitle) ;

		if (sRes != "")
			::MessageBox(0, "Le r�f�rentiel est r�f�renc� dans la librairie XML.", "Message Nautilus", MB_OK) ;
	}
	else
	{
  	erreur("Le fichier XML s�lectionn� n'est ni un arch�type, ni un r�f�rentiel valide.", standardError, 0) ;
	}
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::CmRefArchetype().", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Function    : NSUtilisateurChoisi::debloqueConsole()
// Description : D�bloque tous les patients qui n'ont pas �t� d�bloqu�s par une
//               pr�cedente session de cette console.
// -----------------------------------------------------------------------------
void
NSUtilisateurChoisi::debloqueConsole()
{
	NSBasicAttributeArray AttrList ;

  char szInstance[3] ;
  itoa(pContexte->getSuperviseur()->getInstance(), szInstance, 10) ;
  string szNoConsole = pContexte->getSuperviseur()->getConsole() ;
  AttrList.push_back(new NSBasicAttribute(CONSOLE, string(pContexte->getSuperviseur()->getConsole()))) ;
  AttrList.push_back(new NSBasicAttribute(INSTANCE, string(szInstance))) ;

  bool	bReturn = pContexte->pPilot->unlockPatient(NautilusPilot::SERV_UNLOCK_ALL_PATIENTS.c_str(), &AttrList) ;
  if (!bReturn)
  {
  	string sWarningMsg = pContexte->pPilot->getWarningMessage() ;
    string sErrorMsg = pContexte->pPilot->getErrorMessage() ;
    if (sWarningMsg != "")
    {
    	pContexte->getSuperviseur()->trace(&sWarningMsg, 1, NSSuper::trWarning) ;
    	erreur(sWarningMsg.c_str(), warningError, 0) ;
    }
    if (sErrorMsg != "")
    {
    	pContexte->getSuperviseur()->trace(&sErrorMsg, 1, NSSuper::trError) ;
    	erreur(sErrorMsg.c_str(), standardError, 0) ;
    }
  }
}


//---------------------------------------------------------------------------
//  Function :		NSSuper::nouveauCR(string sCompteRendu)
//
//  Arguments :	sCompteRendu : string qui re�oit le CR
//
//  Description :	G�n�re un nouveau compte rendu.
//
//  Retour :		TRUE si OK, FALSE sinon
//---------------------------------------------------------------------------
bool
NSUtilisateurChoisi::nouveauCR(string* sCompteRendu)
{
	/*
	char codeModule[MODU_CODE_LEN+1], bigModule[MODU_BIG_LEN+1];
	char contexteModule;
	//
	// Lancement de la boite de dialogue de choix de module
	//
	ChoixCRDialog* ChoixCRDl =
		new ChoixCRDialog(pNSSuperviseur->pNSApplication->GetMainWindow());
	ChoixCRDl->Execute();
	//
	// Si un module a �t� choisi, on le lance
	//
	if (ChoixCRDl->EnteteCR[0] != '\0')
	{
		strcpy(codeModule, ChoixCRDl->EnteteCR);
		strcpy(bigModule, ChoixCRDl->NomScript);
		contexteModule = ChoixCRDl->Contexte;
		delete ChoixCRDl;
		return BigBrother('C', bigModule, sCompteRendu, "", pNSSuperviseur, codeModule, contexteModule);
	}
	else
	{
		delete ChoixCRDl;
		return FALSE;
	}
	*/
    return true ;
}

void
NSUtilisateurChoisi::RemplirIndex(NSPatPathoArray* pPPT)
{
}

void
NSUtilisateurChoisi::RemplirSynthese(NSPatPathoArray* pPPT)
{
}

void
NSUtilisateurChoisi::RemplirIdentifiant(NSPatPathoArray* pPPT)
{
}

void
NSUtilisateurChoisi::RemplirLibChem(NSPatPathoArray* pPPT)
{
}


// -----------------------------------------------------------------------------
// Function     : NSUtilisateurChoisi::InitNewData(NSUtiliInfo *pUtilInfo, bool bCreer)
// -----------------------------------------------------------------------------
// Arguments    : Les infos utilisateur � initialiser ou � modifer
// -----------------------------------------------------------------------------
// Description  : Appel du dialogue de cr�ation/modification d'un utilisateur
// -----------------------------------------------------------------------------
// Returns      : true->Les Data sont modifi�es false->Sinon
// -----------------------------------------------------------------------------
bool
NSUtilisateurChoisi::InitNewData(NSUtiliInfo *pUtilInfo, bool bCreer, TWindow* parent)
{
	if (NULL == pUtilInfo)
		return false ;

	CreerUtilisateurDialog  *pNewUtilDlg ;
	TModule                 *module = 0 ;

	if (parent)
		module = parent->GetModule() ;

	pNewUtilDlg = new CreerUtilisateurDialog(parent, pContexte, module) ;

	if (!bCreer)	// on est en modification
	{
  	// on regarde si le graphe n'est pas d�j� charg�
    // sinon, on le charge ici avant le setGraph qui est dans Modifier()
    GetGraphUtil(pUtilInfo) ;
    *(pNewUtilDlg->pData) = *(pUtilInfo->getData()) ;
    
    pNewUtilDlg->setTitre(pUtilInfo->getTitre()) ;
    pNewUtilDlg->setCivilPro(pUtilInfo->getCivilProf()) ;
    pNewUtilDlg->setCivil(pUtilInfo->getCivil()) ;
    pNewUtilDlg->setLogin(pUtilInfo->getLogin()) ;
    pNewUtilDlg->setPasswd(pUtilInfo->getPasswd()) ;
    pNewUtilDlg->setUserType(pUtilInfo->getUserType()) ;
    pNewUtilDlg->setPassType(pUtilInfo->getPassType()) ;
    pNewUtilDlg->setPassDate(pUtilInfo->getPassDate()) ;
    pNewUtilDlg->setValidity(pUtilInfo->getValidity()) ;
	}

	if ((pNewUtilDlg->Execute()) == IDCANCEL)
	{
		delete pNewUtilDlg ;
		return false ;
	}

	// on stocke les donnees du dialogue dans les Data
	*(pUtilInfo->getData()) = *(pNewUtilDlg->pData) ;

	pUtilInfo->setTitre(pNewUtilDlg->getTitre()) ;
	pUtilInfo->setCivilProf(pNewUtilDlg->getCivilPro()) ;
	pUtilInfo->setCivil(pNewUtilDlg->getCivil()) ;
	pUtilInfo->setLogin(pNewUtilDlg->getLogin()) ;
	pUtilInfo->setPasswd(pNewUtilDlg->getPasswd()) ;
	pUtilInfo->setUserType(pNewUtilDlg->getUserType()) ;
	pUtilInfo->setPassType(pNewUtilDlg->getPassType()) ;
	pUtilInfo->setPassDate(pNewUtilDlg->getPassDate()) ;
	pUtilInfo->setValidity(pNewUtilDlg->getValidity()) ;

	delete pNewUtilDlg ;
	return true ;
}

// -----------------------------------------------------------------------------
// Function     : NSUtilisateurChoisi::Creer()
// Arguments    : none
// Description  : Cr�ation d'un nouvel utilisateur
// Returns      : true -> Succ�s ; false -> Echec
// -----------------------------------------------------------------------------
bool
NSUtilisateurChoisi::Creer(TWindow* parent)
{
	NSUtiliInfo NewUtilInfo(pContexte) ;
	string 		 sCode = "" ;

	// On met � jour les nouvelles Data (sauf code)
	if (!InitNewData(&NewUtilInfo, true, parent))
		return true ;

  SetGraphUtil(&NewUtilInfo, true) ;
  // FIXME TODO -- FLP
  // here we have to insert new user in local medical team
  // il faut r�cup�rer l'ID de la personne cr��e et l'ajouter dans l'Equipe M�dicale locale (ou toutes les equipes medicales locales)
  string sNewUserID = NewUtilInfo.pGraphPerson->getPersonID() ; // FIXME TODO

  if (NewUtilInfo.isUser())
  {
    vector<string>  vLocalTeams = pContexte->getSuperviseur()->getLocalTeams() ;
    if (!vLocalTeams.empty())
    {
      NVLdVTemps	ldvCurDate ;	ldvCurDate.takeTime() ;
      NVLdVTemps	ldvNoLimit ;	ldvNoLimit.setNoLimit() ;

      for (vector<string>::iterator lTeamIter = vLocalTeams.begin() ; lTeamIter != vLocalTeams.end() ; lTeamIter++)
      {
        // r�cup�ration de l'objet Team et ajout de la nouvelle personne
        NSTeamGraphManager teamManager(pContexte) ;
        NSPatPathoArray	Ppt(pContexte) ;
        teamManager.getTeamGraph(*lTeamIter, &Ppt) ;

        NSMoralPerson MoralPerson(&Ppt) ;
        NSMoralPersonManager mpManager(&MoralPerson) ;

        NSHTMMandateArray MandatesArray ;
        MandatesArray.push_back(new NSHealthTeamMandate(nearDist, 3, "", "", ldvCurDate.donneDateHeure(), ldvNoLimit.donneDateHeure(), "", "", NSHealthTeamMandate::user)) ;
        mpManager.addMember(new NSHealthTeamMember(sNewUserID, NSHealthTeamMember::person, &MandatesArray), NSHealthTeamMember::person) ;

        // + appel pilot pour modifier la Team
        teamManager.setTeamGraph(mpManager.getPatho(), pContexte->getUtilisateurID()) ;
      }
    }
  }

  // Create User specific directory and files
  //
  CreateUserFiles(sNewUserID) ;

	return true ;
}

// -----------------------------------------------------------------------------
// Function     : NSUtilisateurChoisi::Modifier()
// Arguments    :
// Description  : Remplace les valeurs de la fiche utilisateur
// Returns      : true->Succ�s false->Echec
// -----------------------------------------------------------------------------
bool
NSUtilisateurChoisi::Modifier(TWindow* parent)
{
	NSUtiliInfo NewUtilInfo(this) ;

  string sRootTree = NewUtilInfo.pGraphPerson->getRootTree() ;
//  NSDataGraph* pDataGraph = pNewUtilInfo->pGraphPerson->pDataGraph ;

	// On met � jour les nouvelles Data
  if (!InitNewData(&NewUtilInfo, false, parent))
		return true ;

  SetGraphUtil(&NewUtilInfo, false) ;

	// on rafraichit les donnees en memoire
	*pDonnees = *(NewUtilInfo.getData()) ;

	*pGraphPerson = *(NewUtilInfo.pGraphPerson) ;

  pContexte->setMainCaption() ;
	return true ;
}


bool
NSUtilisateurChoisi::ModifierAutreUtilisateur(TWindow* parent)
{
	// on pr�sente d'abord � l'administrateur une liste des utilisateurs
	// s'il se choisit lui-m�me, on appelle Modifier()
	NSTPersonListDialog Liste(parent, pidsUtilisat, false, pContexte) ;
	if (Liste.Execute() != IDOK)
		return true ;

	string sNssUser = Liste.pPersonSelect->sPersonID ;
	if (sNssUser == "")
		return false ;

	if (pGraphPerson->getPersonID() == sNssUser)
	{
		Modifier(parent) ;
		return true ;
	}

	NSUtiliInfo OtherUtilInfo(pContexte) ;
	OtherUtilInfo.setNss(sNssUser) ;

	// on r�cup�re le login et le password de l'utilisateur � modifier
	const char* serviceName = (NautilusPilot::SERV_USER_PROPERTIES_LIST).c_str() ;
	NSPersonsAttributesArray PatList ;
	NSBasicAttributeArray    AttrList ;
	AttrList.push_back(new NSBasicAttribute(LOGIN,    _sLogin)) ;
	AttrList.push_back(new NSBasicAttribute(PASSWORD, _sPasswd)) ;
	AttrList.push_back(new NSBasicAttribute(PERSON,   sNssUser)) ;

	bool res = pContexte->pPilot->getUserProperties(serviceName, &PatList, &AttrList) ;
	if (!res)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "personNotFound") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	//ajout de la balise PERSON dans pPatList
	OtherUtilInfo.setLogin(PatList.getAttributeValue(LOGIN)) ;
	OtherUtilInfo.setPasswd(PatList.getAttributeValue(PASSWORD)) ;
	OtherUtilInfo.setUserType(PatList.getAttributeValue(USERTYPE)) ;
	OtherUtilInfo.setPassType(PatList.getAttributeValue(PASSWDTYPE)) ;
	OtherUtilInfo.setPassDate(PatList.getAttributeValue(STARTDATE)) ;
	OtherUtilInfo.setValidity(PatList.getAttributeValue(DAYSNB)) ;

	// On met � jour les nouvelles Data
	// Note : dans cette fonction GetGraphUtil charge le graphe et remplit les pDonnees
	if (false == InitNewData(&OtherUtilInfo, false, parent))
		return true ;

	// on met � jour le graphe
	SetGraphUtil(&OtherUtilInfo, false) ;

	return true ;
}

bool
NSUtilisateurChoisi::SetGraphUtil(NSUtiliInfo* pUtilInfo, bool bCreer)
{
	if (NULL == pUtilInfo)
		return false ;

  // on construit d'abord une patpatho admin et pds pour l'utilisateur.
  NSPatPathoArray PPT(pContexte, graphPerson) ;

  bool bRet ;

  if (bCreer)
  {
    PPT.ajoutePatho("ZADMI1", 0) ;
    PPT.ajoutePatho("LIDET1", 1) ;

    // nom de l'utilisateur
    PPT.ajoutePatho("LNOM01", 2) ;
    Message Msg ;
    Msg.SetTexteLibre(pUtilInfo->getNom()) ;
    PPT.ajoutePatho("�CL000", &Msg, 3) ;

    // prenom
    PPT.ajoutePatho("LNOM21", 2) ;
    Msg.Reset() ;
    Msg.SetTexteLibre(pUtilInfo->getPrenom()) ;
    PPT.ajoutePatho("�CL000", &Msg, 3) ;

    // sexe
    PPT.ajoutePatho("LSEXE1", 2) ;
    if (pUtilInfo->estMasculin())
    {
      PPT.ajoutePatho("HMASC2", 3) ;
      if (string("HMONP1") == pUtilInfo->getCivil())
      {
        PPT.ajoutePatho("HCIVO1", 4) ;
        PPT.ajoutePatho("HMONP1", 5) ;
      }
    }
    else if (pUtilInfo->estFeminin())
    {
      PPT.ajoutePatho("HFEMI2", 3) ;
      if (string("HMADR1") == pUtilInfo->getCivil())
      {
        PPT.ajoutePatho("HCIVO1", 4) ;
        PPT.ajoutePatho("HMADR1", 5) ;
      }
      else if (string("HMADE1") == pUtilInfo->getCivil())
      {
        PPT.ajoutePatho("HCIVO1", 4) ;
        PPT.ajoutePatho("HMADE1", 5) ;
      }
    }

    // construction de la patpatho professionnel de sant� (point de vue)
    PPT.ajoutePatho("DPROS1", 0) ;

    // sous-chapitre "Langue"
    if (string("") != pUtilInfo->getLang())
		{
    	PPT.ajoutePatho("LLANG1", 1) ;

      Message localMessage ;
      localMessage.SetComplement(pUtilInfo->getLang()) ;
      PPT.ajoutePatho("663911", &localMessage, 2) ;
    }

    // sous-chapitre "Comp�tences m�dicales"
    PPT.ajoutePatho("LCOMP1", 1) ;

    // M�tier
    if (string("") != pUtilInfo->getJob())
    {
      PPT.ajoutePatho("LMETI1", 2) ;
      PPT.ajoutePatho(pUtilInfo->getJob(), 3) ;
    }

    // Sp�cialit�
    if (string("") != pUtilInfo->getSpecialty())
    {
      PPT.ajoutePatho("LSPEC1", 2) ;
      PPT.ajoutePatho(pUtilInfo->getSpecialty(), 3) ;
    }

    // titre
    if (string("") != pUtilInfo->getTitre())
    {
      PPT.ajoutePatho("LTITR1", 1) ;
      PPT.ajoutePatho(pUtilInfo->getTitre(), 2) ;
    }

    // civilit� professionnelle
    if (string("") != pUtilInfo->getCivilProf())
    {
      PPT.ajoutePatho("HCIVO1", 1) ;
      PPT.ajoutePatho(pUtilInfo->getCivilProf(), 2) ;
    }

    // e-mail
    if (string("") != pUtilInfo->getMail())
    {
      PPT.ajoutePatho("ULIEX1", 1) ;
      PPT.ajoutePatho("LMAIL1", 2) ;
      Message localMessage ;
      localMessage.SetTexteLibre(pUtilInfo->getMail()) ;
      PPT.ajoutePatho("�CL000", &localMessage, 3) ;
    }
  }
  else // cas de la modification
  {
    NSDataTreeIter iterTree ;
    NSDataGraph* pDataGraph = pUtilInfo->pGraphPerson->pDataGraph ;

    if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
      (*iterTree)->getPatPatho(&PPT) ;
    else
    {
      string sErrorText = string("Impossible de trouver l'arbre [ZADMI1] dans le graphe administratif.") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      erreur(sErrorText.c_str(), standardError, 0) ;
      return false ;
    }

    if (pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
    {
      NSPatPathoArray PatPathoPDS(pContexte) ;
      (*iterTree)->getPatPatho(&PatPathoPDS) ;
      PPT.InserePatPatho(PPT.end(), &PatPathoPDS, 0, true) ;
    }

    // on modifie les �l�ments dans la patpatho
    PatPathoIter iter ;
    if (PPT.CheminDansPatpatho("ZADMI1/LIDET1/LNOM01/�CL000", string(1, cheminSeparationMARK), &iter))
      (*iter)->setTexteLibre(pUtilInfo->getNom()) ;
    else
    {
      Message Msg ;
      Msg.SetLexique("�CL000") ;
      Msg.SetTexteLibre(pUtilInfo->getNom()) ;
      PPT.AjouterChemin("ZADMI1/LIDET1/LNOM01", &Msg) ;
    }

    if (PPT.CheminDansPatpatho("ZADMI1/LIDET1/LNOM21/�CL000", string(1, cheminSeparationMARK), &iter))
      (*iter)->setTexteLibre(pUtilInfo->getPrenom()) ;
    else
    {
      Message Msg ;
      Msg.SetLexique("�CL000") ;
      Msg.SetTexteLibre(pUtilInfo->getPrenom()) ;
      PPT.AjouterChemin("ZADMI1/LIDET1/LNOM21", &Msg) ;
    }

    if (pUtilInfo->estMasculin())
    {
      if (!PPT.CheminDansPatpatho("ZADMI1/LIDET1/LSEXE1/HMASC2"))
        PPT.AjouterChemin("ZADMI1/LIDET1/LSEXE1", "HMASC2") ;

      if (string("HMONP1") == pUtilInfo->getCivil())
      {
        if (!PPT.CheminDansPatpatho("ZADMI1/LIDET1/LSEXE1/HMASC2/HCIVO1/HMONP1"))
          PPT.AjouterChemin("ZADMI1/LIDET1/LSEXE1/HMASC2/HCIVO1", "HMONP1") ;
      }
    }
    else if (pUtilInfo->estFeminin())
    {
      if (!PPT.CheminDansPatpatho("ZADMI1/LIDET1/LSEXE1/HFEMI2"))
        PPT.AjouterChemin("ZADMI1/LIDET1/LSEXE1", "HFEMI2") ;

      if (string("HMADR1") == pUtilInfo->getCivil())
      {
        if (!PPT.CheminDansPatpatho("ZADMI1/LIDET1/LSEXE1/HFEMI2/HCIVO1/HMADR1"))
          PPT.AjouterChemin("ZADMI1/LIDET1/LSEXE1/HFEMI2/HCIVO1", "HMADR1") ;
      }
      else if (string("HMADE1") == pUtilInfo->getCivil())
      {
        if (!PPT.CheminDansPatpatho("ZADMI1/LIDET1/LSEXE1/HFEMI2/HCIVO1/HMADE1"))
          PPT.AjouterChemin("ZADMI1/LIDET1/LSEXE1/HFEMI2/HCIVO1", "HMADE1") ;
      }
    }

		// Langue
    if (string("") != pUtilInfo->getLang())
    {
    	if (PPT.CheminDansPatpatho("DPROS1/LLANG1/663911", string(1, cheminSeparationMARK), &iter))
      	(*iter)->setComplement(pUtilInfo->getLang()) ;
    	else
    	{
      	Message Msg ;
      	Msg.SetLexique("663911") ;
      	Msg.SetComplement(pUtilInfo->getLang()) ;
      	PPT.AjouterChemin("DPROS1/LLANG1", &Msg) ;
      }
    }
    else
    {
    	if (PPT.CheminDansPatpatho("DPROS1/LLANG1/663911", string(1, cheminSeparationMARK), &iter))
        PPT.SupprimerItem(iter) ;
    }

    // M�tier
    if (string("") != pUtilInfo->getJob())
    {
      string sCheminMetier = string("DPROS1/LCOMP1/LMETI1/") + pUtilInfo->getJob() ;
      if (!PPT.CheminDansPatpatho(sCheminMetier))
        PPT.AjouterChemin("DPROS1/LCOMP1/LMETI1", pUtilInfo->getJob()) ;
    }
    else
    {
      if (PPT.CheminDansPatpatho("DPROS1/LCOMP1/LMETI1", string(1, cheminSeparationMARK), &iter))
        PPT.SupprimerItem(iter) ;
    }

    // Sp�cialit�
    if (string("") != pUtilInfo->getSpecialty())
    {
      string sCheminSpec = string("DPROS1/LCOMP1/LSPEC1/") + pUtilInfo->getSpecialty() ;
      if (!PPT.CheminDansPatpatho(sCheminSpec))
        PPT.AjouterChemin("DPROS1/LCOMP1/LSPEC1", pUtilInfo->getSpecialty()) ;
    }
    else
    {
      if (PPT.CheminDansPatpatho("DPROS1/LCOMP1/LSPEC1", string(1, cheminSeparationMARK), &iter))
        PPT.SupprimerItem(iter) ;
    }

    // Titre
    if (string("") != pUtilInfo->getTitre())
    {
      string sCheminTitre = string("DPROS1/LTITR1/") + pUtilInfo->getTitre() ;
      if (!PPT.CheminDansPatpatho(sCheminTitre))
        PPT.AjouterChemin("DPROS1/LTITR1", pUtilInfo->getTitre()) ;
    }
    else
    {
      if (PPT.CheminDansPatpatho("DPROS1/LTITR1", string(1, cheminSeparationMARK), &iter))
        PPT.SupprimerItem(iter) ;
    }

    // Civilite professionnelle
    if (string("") != pUtilInfo->getCivilProf())
    {
      string sCheminCivp = string("DPROS1/HCIVO1/") + pUtilInfo->getCivilProf() ;
      if (!PPT.CheminDansPatpatho(sCheminCivp))
        PPT.AjouterChemin("DPROS1/HCIVO1", pUtilInfo->getCivilProf()) ;
    }
    else
    {
      if (PPT.CheminDansPatpatho("DPROS1/HCIVO1", string(1, cheminSeparationMARK), &iter))
        PPT.SupprimerItem(iter) ;
    }

    // messagerie
    if (PPT.CheminDansPatpatho("DPROS1/ULIEX1/LMAIL1/�CL000", string(1, cheminSeparationMARK), &iter))
      (*iter)->setTexteLibre(pUtilInfo->getMail()) ;
    else
    {
      Message Msg ;
      Msg.SetLexique("�CL000") ;
      Msg.SetTexteLibre(pUtilInfo->getMail()) ;
      PPT.AjouterChemin("DPROS1/ULIEX1/LMAIL1", &Msg) ;
    }
  }

  // on construit maintenant le graphe pour le pilote
  string sLogin = pUtilInfo->getLogin() ;
  string sPasswd = pUtilInfo->getPasswd() ;

  string sNss ;

  if (bCreer)
    sNss = string(1, INMEMORY_CHAR) + string(PAT_NSS_LEN - 1, '0') ;
  else
    sNss = pUtilInfo->pGraphPerson->getPersonID() ;

  // On met � jour le graphe de l'utilisateur de pUtilInfo
  NSBasicAttributeArray AttrList ;
  AttrList.push_back(new NSBasicAttribute(LOGIN,      sLogin)) ;
  AttrList.push_back(new NSBasicAttribute(PASSWORD,   sPasswd)) ;
  AttrList.push_back(new NSBasicAttribute(PERSON,     sNss)) ;

  AttrList.push_back(new NSBasicAttribute(OPERATOR,   pContexte->getUtilisateurID())) ;
  AttrList.push_back(new NSBasicAttribute(USERTYPE,   pUtilInfo->getUserType())) ;
  AttrList.push_back(new NSBasicAttribute(PASSWDTYPE, pUtilInfo->getPassType())) ;
  if (string(pUtilInfo->getValidity()) != "")
  	AttrList.push_back(new NSBasicAttribute(DAYSNB,   pUtilInfo->getValidity())) ;

  AttrList.push_back(new NSBasicAttribute(FIRST_NAME, pUtilInfo->getPrenom())) ;
  AttrList.push_back(new NSBasicAttribute(LAST_NAME,  pUtilInfo->getNom())) ;

  pUtilInfo->pGraphPerson->setInfoPids(&AttrList) ;
  bRet = pUtilInfo->pGraphPerson->setGraphAdmin(&PPT, pidsUtilisat) ;

  // TODO FIXME -- FLP
  // en fonction de pUtilInfo->sUserType on doit ajouter ou retirer
  // l'utilisateur de l'Equipe M�dicale Locale

  // il faut r�cup�rer l'ID de la personne cr��e et l'ajouter dans l'Equipe M�dicale locale (ou toutes les equipes medicales locales)
  vector<string> vLocalTeams = pContexte->getSuperviseur()->getLocalTeams() ;
  if (!vLocalTeams.empty())
  {
    if ((pUtilInfo->getUserType().find(ADMIN_ROLE) != string::npos) && (pUtilInfo->getUserType().find(USER_ROLE) == string::npos))
    {
      // si seulement administrateur --> retirer s'il existe de l'Equipe M�dicale Locale
      // ==> retirer de l'Equipe Medicale Locale (s'il y est d�j�)

      for (vector<string>::iterator lTeamIter = vLocalTeams.begin() ; lTeamIter != vLocalTeams.end() ; lTeamIter++)
      {
        // r�cup�ration de l'objet Team et ajout de la nouvelle personne
        NSTeamGraphManager teamManager(pContexte) ;
        NSPatPathoArray	ppt(pContexte) ;
        teamManager.getTeamGraph(*lTeamIter, &ppt) ;

        NSMoralPerson MoralPerson(&ppt) ;
        NSMoralPersonManager mpManager(&MoralPerson) ;

        mpManager.closeAllMandates(pContexte, sNss) ;

        // + appel pilot pour modifier la Team
        teamManager.setTeamGraph(mpManager.getPatho(), pContexte->getUtilisateurID()) ;
      }
    }
    else if (pUtilInfo->getUserType().find(USER_ROLE) != string::npos)
    {
      // si au moins utilisateur --> ajouter (s'il n'y est pas d�j�) de l'Equipe M�dicale Locale
      // ==> ajouter � l'Equipe M�dicale Locale (s'il n'y est pas d�j�)

      for (vector<string>::iterator lTeamIter = vLocalTeams.begin() ; lTeamIter != vLocalTeams.end() ; lTeamIter++)
      {
        // r�cup�ration de l'objet Team et ajout de la nouvelle personne
        NSTeamGraphManager teamManager(pContexte) ;
        NSPatPathoArray	ppt(pContexte) ;
        teamManager.getTeamGraph(*lTeamIter, &ppt) ;

        NSMoralPerson MoralPerson(&ppt) ;
        NSMoralPersonManager mpManager(&MoralPerson) ;

        mpManager.addMember(pContexte, sNss) ;

        // + appel pilot pour modifier la Team
        teamManager.setTeamGraph(mpManager.getPatho(), pContexte->getUtilisateurID()) ;
      }
    }
  }

  return bRet ;
}


bool
NSUtilisateurChoisi::GetGraphUtil(NSUtiliInfo* pUtilInfo)
{
try
{
	NSPatPathoArray PatPathoArray(pContexte, graphPerson) ;
	bool bGraphOK = false ;

	PatPathoIter    iter ;
	string          sElemLex, sSens, sType, sTemp ;
	string lang = "" ;
//=============================================================================
//il faut recuperer la langue d'utilisateur de la base ou de l'interface
//Voir dans la racine du DPROS!!!!
//=============================================================================
	string sLang  = donneLang() ;
	if (sLang == "")
	{
		sLang ="fr" ;
		pUtilInfo->setLang(sLang) ;
	}

	string sNom    = "" , sPrenom = "" , sSexe   = "" ;
	string sCivilite = "", sTitre = "", sCivilProf = "", sEMail = "";
	string sMetier = "", sSpecialite = "";

/********************************
#ifdef N_TIERS
     //string sIdRoot = pGraphPerson->pDataGraph->getGraphID();
        if(!bCreat)
            return true;
        string sTreeRoot = pGraphPerson->pDataGraph->getGraphID();
        if (pGraphPerson->getGraphAdmin(sTreeRoot, pidsUtilisat, pPatPathoArray))
            bGraphOK = true;
#else
*********************************/

	// on regarde si le graphe n'est pas d�j� charg�
	if (pUtilInfo->pGraphPerson->getRootTree() == "")
	{
		string sPids = pUtilInfo->getNss() ;
		if (pUtilInfo->pGraphPerson->getGraphAdmin(sPids, true, pidsUtilisat, &PatPathoArray))
			bGraphOK = true ;
	}
	else // on ne sort pas pour rafraichir quand m�me les pDonnees (obligatoire � l'ouverture)
	{
		NSDataTreeIter iterTree ;
		NSDataGraph* pDataGraph = pUtilInfo->pGraphPerson->pDataGraph ;

		if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
		{
			(*iterTree)->getPatPatho(&PatPathoArray);
		}
		else
		{
			string sErrorText = string("Impossible de trouver l'arbre [ZADMI1] dans le graphe administratif.") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
			erreur(sErrorText.c_str(), standardError, 0) ;
			return false ;
		}

		if (pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
		{
			NSPatPathoArray PatPathoPDS(pContexte) ;
			(*iterTree)->getPatPatho(&PatPathoPDS) ;
			PatPathoArray.InserePatPatho(PatPathoArray.end(), &PatPathoPDS, 0) ;
		}

		bGraphOK = true;
	}

	if (bGraphOK == false)
		return false ;

	iter = PatPathoArray.begin() ;
	int iColBase = (*iter)->getColonne() ;

	while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() >= iColBase))
	{
		sElemLex = (*iter)->getLexique() ;
		pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    if (sSens == string("ZADMI"))
    {
    	iter++ ;

      while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase))
      {
      	sElemLex = (*iter)->getLexique() ;
        pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

        // Chapitre "identit�" / Identity chapter
        if (sSens == string("LIDET"))
        {
        	int iColIdentity = (*iter)->getColonne() ;
          iter++ ;

          while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColIdentity))
          {
          	sElemLex = (*iter)->getLexique() ;
            pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

            // Nom de l'utilisateur
            if ((sSens == string("LNOM0")) && (sNom == ""))
            {
            	iter++;
              while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColIdentity+1))
              {
              	// on cherche ici un texte libre
                sElemLex = (*iter)->getLexique() ;
                if (string(sElemLex, 0, 3) == string("�CL"))
                	sNom = (*iter)->getTexteLibre() ;
                iter++ ;
              }

              if (sNom != "")
              	pUtilInfo->setNom(sNom) ;
            }
            // Pr�nom de l'utilisateur
            else if ((sSens == string("LNOM2")) && (sPrenom == ""))
            {
            	iter++ ;
              while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColIdentity+1))
              {
              	// on cherche ici un texte libre
                sElemLex = (*iter)->getLexique() ;
                if (string(sElemLex, 0, 3) == string("�CL"))
                	sPrenom = (*iter)->getTexteLibre() ;
                iter++ ;
              }

              if (sPrenom != "")
              	pUtilInfo->setPrenom(sPrenom) ;
            }
            // Sexe de l'utilisateur
            else if (sSens == string("LSEXE"))
            {
            	iter++ ;
              while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColIdentity+1))
              {
              	// on cherche ici un code lexique
                sElemLex = (*iter)->getLexique() ;
                pContexte->getDico()->donneCodeSens(&sElemLex, &sTemp) ;

                sSexe = sTemp ;

                iter++ ;

                while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColIdentity + 2))
                {
                	sElemLex = (*iter)->getLexique() ;
                  pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

                  // Civilit�
                  if (sSens == string("HCIVO"))
                  {
                  	iter++ ;
                    while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColIdentity + 3))
                    {
                    	// on cherche ici un code lexique pour un libelle
                      string sCodeLex = (*iter)->getLexique() ;
                      sCivilite = sCodeLex ;
                      iter++ ;
                    }
                  }
                  else
                  	iter++ ;
                }
              }

              if (sSexe != "")
              	pUtilInfo->setSexe(sSexe) ;

              if (sCivilite != "")
              	pUtilInfo->setCivil(sCivilite) ;
            }
            else
            	iter++ ;
          }
        }
        else
        	iter++ ;
      } // while
    } // if (sSens == string("ZADMI"))
    else if (sSens == string("DPROS"))
    {
    	iter++ ;

      while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase))
      {
      	sElemLex = (*iter)->getLexique() ;
        pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

        // Chapitre "Langue" / Langage chapter
        //
        if (sSens == string("LLANG"))
        {
        	iter++ ;
          while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColBase + 1))
          {
          	// on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

            if (sSens == string("66391"))
            	lang = (*iter)->getComplement() ;
            iter++ ;
          }
        }

        // Chapitre "Comp�tences" / Competence chapter
        //
        else if (sSens == string("LCOMP"))
        {
        	int iColCompetences = (*iter)->getColonne() ;
          iter++ ;

          while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColCompetences))
          {
          	sElemLex = (*iter)->getLexique() ;
            pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

            // metier
            if ((sSens == string("LMETI")) && (sMetier == ""))
            {
            	// on cherche ici un edit lexique (ayant comme fils un code lexique)
              iter++ ;
              sElemLex = (*iter)->getLexique() ;
              if (sElemLex != "")
              	if (string(sElemLex, 0, 3) == string("�C;"))
                {
                	iter++ ;
                  while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColCompetences+2))
                  {
                  	// on cherche ici un code lexique pour un libelle
                    string sCode = string((*iter)->getLexique()) ;
                    pContexte->getDico()->donneLibelle(sLang, &sCode, &sMetier) ;

                    iter++ ;
                  }
                }
                else
                {
                	sMetier = (*iter)->getLexique() ;
                  if (iter != PatPathoArray.end())
                  	iter++ ;
                }
              else
              	iter++ ;

              if (sMetier != "")
              	pUtilInfo->setJob(sMetier) ;
            }
            // Specilit� de l'utilisateur
            else if ((sSens == string("LSPEC")) && (sSpecialite == ""))
            {
            	// on cherche ici un edit lexique (ayant comme fils un code lexique)
              iter++ ;
              sElemLex = (*iter)->getLexique() ;
              if (sElemLex != "")
              	if (string(sElemLex, 0, 3) == string("�C;"))
                {
                	iter++ ;
                  while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColCompetences+2))
                  {
                  	// on cherche ici un code lexique pour un libelle
                    string sCode = string((*iter)->getLexique()) ;
                    pContexte->getDico()->donneLibelle(sLang, &sCode, &sSpecialite) ;

                    iter++ ;
                  }
                }
                else
                {
                	sSpecialite = string((*iter)->getLexique()) ;
                  if (iter != PatPathoArray.end())
                  	iter++ ;
                }
              else    //si "" on avanse
              	iter++ ;

              if (sSpecialite != "")
              	pUtilInfo->setSpecialty(sSpecialite) ;
            }
            else
            	iter++ ;
          }
        }
        // Chapitre "titre"
        else if (sSens == string("LTITR"))
        {
        	int iColTitre = (*iter)->getColonne() ;
          iter++ ;
          while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColTitre))
          {
          	// on cherche ici un code lexique pour un libelle
            sTitre = string((*iter)->getLexique()) ;
            // pContexte->getDico()->donneLibelle(sLang, &sCodeLex, &sCivilite) ;

            iter++ ;
          }

          if (sTitre != "")
          	pUtilInfo->setTitre(sTitre) ;
        }
        // Chapitre "civilit�"
        else if (sSens == string("HCIVO"))
        {
        	int iColCivilite = (*iter)->getColonne() ;
          iter++ ;
          while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColCivilite))
          {
          	// on cherche ici un code lexique pour un libelle
            sCivilProf = (*iter)->getLexique() ;
            // pContexte->getDico()->donneLibelle(sLang, &sCodeLex, &sCivilite) ;

            iter++ ;
          }

          if (sCivilProf != "")
          	pUtilInfo->setCivilProf(sCivilProf) ;

                    /*******************************************
                    if (sCivilite != "")
                    {
                        if (sCivilite == string("HDOCT1"))
                            strcpy(pUtilInfo->pDonnees->type, "O");
                        else if (sCivilite == string("HPROF1"))
                            strcpy(pUtilInfo->pDonnees->type, "P");
                        else if (sCivilite == string("HMOND1"))
                            strcpy(pUtilInfo->pDonnees->type, "1");
                        else if (sCivilite == string("HMADD1"))
                            strcpy(pUtilInfo->pDonnees->type, "2");
                        else if (sCivilite == string("HMONF1"))
                            strcpy(pUtilInfo->pDonnees->type, "R");
                        else if (sCivilite == string("HMADP1"))
                            strcpy(pUtilInfo->pDonnees->type, "M");
                        else if (sCivilite == string("HMONP1"))
                            strcpy(pUtilInfo->pDonnees->type, "A");
                        else if (sCivilite == string("HMADR1"))
                            strcpy(pUtilInfo->pDonnees->type, "B");
                        else if (sCivilite == string("HMADE1"))
                            strcpy(pUtilInfo->pDonnees->type, "C");
                    }
                    *******************************************/
        }
        // Chapitre "lieu d'exercice"
        else if (sSens == string("ULIEX"))
        {
        	int iColLiex = (*iter)->getColonne() ;
          iter++ ;

          while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColLiex))
          {
          	sElemLex = (*iter)->getLexique() ;
            pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

            // Nom de l'utilisateur
            if ((sSens == string("LMAIL")) && (sEMail == ""))
            {
            	iter++ ;
              while ((iter != PatPathoArray.end()) && ((*iter)->getColonne() > iColLiex+1))
              {
              	// on cherche ici un texte libre
                sElemLex = (*iter)->getLexique() ;
                if (string(sElemLex, 0, 3) == string("�CL"))
                	sEMail = (*iter)->getTexteLibre();
                iter++ ;
              }

              if (sEMail != "")
              	pUtilInfo->setMail(sEMail) ;
            }
            else
              	iter++ ;
          } // while
        }
        else
        	iter++ ;
      } // while
    } // else if (sSens == string("DPROS"))
    else
    	iter++ ;
  } // while de base

  //la langue par defaut = "fr"
  if (string("") == lang)
  	pUtilInfo->setLang("fr") ;
  else
  	pUtilInfo->setLang(lang) ;

 	return true ;
}
catch (...)
{
	erreur("Exception NSUtilisateurChoisi::GetGraphUtil.", standardError, 0) ;
  return false ;
}
}

void
NSUtilisateurChoisi::CreateUserFiles(string sUserID)
{
	if (sUserID == string(""))
  	sUserID = getID() ;

	string sGlobalPersoDir = pContexte->PathName("FGLO") ;
  char cDirSeparator = sGlobalPersoDir[strlen(sGlobalPersoDir.c_str()) - 1] ;
	string sPersoDir = sGlobalPersoDir + sUserID + string(1, cDirSeparator) ;

  // First, create user specific Directory
  //
  if (strlen(sPersoDir.c_str()) > MAX_PATH)
  	sPersoDir = string("\\\\?\\") + sPersoDir ;

  BOOL bSuccess = ::CreateDirectory(sPersoDir.c_str(), NULL) ;
  if (!bSuccess)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorCreatingDirectory") ;
    sErrorText += string(" ") + sPersoDir ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return ;
  }

  // Then, copy user specific files
  //
  ifstream inFile ;
  string sFileListFile = sGlobalPersoDir + "userFiles.txt" ;

  inFile.open(sFileListFile.c_str()) ;
	if (!inFile)
  {
  	string sErrMess = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") + string(" ") + sFileListFile ;
    pContexte->getSuperviseur()->trace(&sErrMess, 1, NSSuper::trError) ;
    erreur(sErrMess.c_str(), standardError, 0) ;
    return ;
  }

  string sLine ;
	while (!inFile.eof())
	{
		getline(inFile, sLine) ;
		if (sLine != "")
    {
    	string sModelFileName = sGlobalPersoDir + sLine ;
      string sUserFileName  = sPersoDir + sLine ;
    	bSuccess = ::CopyFile(sModelFileName.c_str(), sUserFileName.c_str(), TRUE) ;

      if (!bSuccess)
			{
  			string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorCopyingFile") ;
    		sErrorText += string(" ") + sModelFileName + string(" -> ") + sUserFileName ;
        pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
				erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
  		}
   	}
	}
	inFile.close() ;

  return ;
}

void
NSUtilisateurChoisi::RenameUserFilesDirectory(string sPreviousID, string sNewID)
{
	if (sNewID == string(""))
  	sNewID = getID() ;

  string sPreviousDir = pContexte->PathName("FGLO") + sPreviousID ;
	string sPersoDir = pContexte->PathName("FGLO") + sNewID ;

  ::MoveFile(sPreviousDir.c_str(), sPersoDir.c_str()) ;
}

void
NSUtilisateurChoisi::setupToolbar()
{
  TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;

  //if (pMyApp->GetToolBarWindow() != 0)
  //{
    // on enl�ve les boutons de la control bar
  TGadget* pGadget = pMyApp->cb1->FirstGadget() ;
  TGadget* pGadgetRemoved ;

  while (pGadget)  {
    pGadgetRemoved = pMyApp->cb1->Remove(*pGadget) ;
    if (!pGadgetRemoved)
    {
      erreur("Erreur � la destruction d'un bouton dans la barre d'outils", standardError, 0) ;
      return ;
    }
    else
      delete pGadgetRemoved ;
    pGadget = pMyApp->cb1->FirstGadget() ;
  }

  pMyApp->cb1->LayoutSession() ;  //}

  ifstream inFile ;

  bool bFileOpened = pContexte->getUtilisateur()->OpenUserFile(&inFile, string("icons.dat"), pContexte->PathName("FGLO")) ;

  if (!bFileOpened || !inFile)
  {
  	pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWDOC, 		CM_NEWDOC, 	 	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWPAT, 		CM_NEWPAT, 	 	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_BUREAU, 		CM_BUREAU, 	 	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TSeparatorGadget) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_IMPORTE, 		CM_IMPORTE, 	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_CHEMISE, 		CM_CHEMISE,  	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_IMPORTIMG, 	CM_IMPORTIMG, 	TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_CAPTUREIMG, CM_CAPTUREIMG,  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TSeparatorGadget) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_ADMIN, 		  CM_ADMIN,  	    TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_LDV, 		    CM_LDV,  	      TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_LDV_DRUGS, 	CM_LDV_DRUGS,  	TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_PROCESS, 	  CM_PROCESS,  	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_LDV_GOALS, 	CM_LDV_GOALS,  	TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TSeparatorGadget) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWTTXT, 		CM_NEWTTXT,  	  TButtonGadget::Command)) ;

    // Insertion du bouton Word si Word.Basic existe dans la base de registre
    HKEY hKeyResult ;
    // cl� du programme Word.Basic dans HKEY_LOCAL_MACHINE
    LPCTSTR lpszKey = _T("SOFTWARE\\CLASSES\\Word.Basic") ;
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, lpszKey, (DWORD)0, KEY_READ, &hKeyResult) == ERROR_SUCCESS)
    	pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWTMPL, 	CM_NEWTMPL,  	  TButtonGadget::Command)) ;

    pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWCR, 		  CM_NEWCR, 	 	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWCS, 		  CM_NEWCS, 	 	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWCONSULT, CM_NEWCONSULT, 	TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TSeparatorGadget) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_ENREGISTRE, CM_ENREGISTRE, 	TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_COMPOSE, 		CM_COMPOSE,  	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_IMPRIME, 		CM_IMPRIME,  	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_VISUAL, 		CM_VISUAL,  	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TSeparatorGadget) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_MAILBOX, 		CM_MAILBOX, 	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_OUTILS, 		CM_OUTILS, 	 	  TButtonGadget::Command)) ;
    pMyApp->cb1->Insert(*new TButtonGadget(CM_ABOUT, 		  CM_ABOUT, 	 	  TButtonGadget::Command)) ;

    pMyApp->cb1->LayoutSession() ;

    return ;
  }

	string line ;
	string sData = "" ;

  while (!inFile.eof())
	{
  	getline(inFile, line) ;
    if (line != "")
    	sData += line + "\n" ;
	}
	inFile.close() ;

	// boucle de chargement des attributs
	size_t i = 0 ;
	while (i < strlen(sData.c_str()))
	{
		string sNomAttrib = "" ;

		while ((i < strlen(sData.c_str())) && (sData[i] != ' ') && (sData[i] != '\t') && (sData[i] != '\n'))
      sNomAttrib += pseumaj(sData[i++]) ;

		while (sData[i] != '\n')
			i++ ;

		i++ ;

    if      (sNomAttrib == "CM_NEWDOC")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWDOC, 		    CM_NEWDOC, 	 	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_NEWPAT")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWPAT, 		    CM_NEWPAT, 	 	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_BUREAU")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_BUREAU, 		    CM_BUREAU, 	 	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_IMPORTE")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_IMPORTE, 		    CM_IMPORTE, 	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_CHEMISE")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_CHEMISE, 		    CM_CHEMISE,  	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_IMPORTIMG")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_IMPORTIMG, 	    CM_IMPORTIMG, 	  TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_CAPTUREIMG")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_CAPTUREIMG,     CM_CAPTUREIMG, 	  TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_ADMIN")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_ADMIN, 		      CM_ADMIN,  	      TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_LDV")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_LDV, 		        CM_LDV,  	        TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_LDV_DRUGS")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_LDV_DRUGS, 	    CM_LDV_DRUGS,  	  TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_LDV_GOALS")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_LDV_GOALS, 	    CM_LDV_GOALS,  	  TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_PROCESS")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_PROCESS, 	      CM_PROCESS,  	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_NEWTTXT")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWTTXT, 		    CM_NEWTTXT,  	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_NEWTMPL")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWTMPL, 		    CM_NEWTMPL,  	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_NEWCR")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWCR, 		      CM_NEWCR, 	 	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_NEWCS")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWCS, 		      CM_NEWCS, 	 	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_NEWCONSULT")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_NEWCONSULT,     CM_NEWCONSULT, 	  TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_ENREGISTRE")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_ENREGISTRE,     CM_ENREGISTRE, 	  TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_PANNEL")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_PANNEL, 		    CM_PANNEL,  	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_COMPOSE")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_COMPOSE, 		    CM_COMPOSE,  	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_IMPRIME")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_IMPRIME, 		    CM_IMPRIME,  	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_VISUAL")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_VISUAL, 		    CM_VISUAL,  	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_MAILBOX")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_MAILBOX, 		    CM_MAILBOX, 	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_OUTILS")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_OUTILS, 		    CM_OUTILS, 	 	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_ABOUT")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_ABOUT, 		      CM_ABOUT, 	 	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_PREDI")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_PREDI, 		      CM_PREDI, 	 	    TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_QUESTIONNAIRE")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_QUESTIONNAIRE,  CM_QUESTIONNAIRE, TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_HEALTHTEAM_ROSE")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_HEALTHTEAM_ROSE, CM_HEALTHTEAM_ROSE, TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_HEALTHTEAM_LIST")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_HEALTHTEAM_LIST, CM_HEALTHTEAM_LIST, TButtonGadget::Command)) ;
    else if (sNomAttrib == "CM_SET_RECONVOC")
      pMyApp->cb1->Insert(*new TButtonGadget(CM_SET_RECONVOC,    CM_SET_RECONVOC, TButtonGadget::Command)) ;
    else if (sNomAttrib == "SEPARATOR")
      pMyApp->cb1->Insert(*new TSeparatorGadget) ;
  }
  pMyApp->cb1->LayoutSession() ;
}



