//---------------------------------------------------------------------------//  NS_HTML.CPP
//  RS Juin 97
//  G�n�ration de fichiers HTML � partir d'un compte-rendu
//---------------------------------------------------------------------------

#define __NS_HTML_CPP

#include <stdio.h>
#include <classlib\filename.h>
#include <sysutils.hpp>

#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "nsdn\nsintrad.h"
#include "nautilus\nsresour.h"
#include "nautilus\nsmodhtm.h"
#include "nautilus\nsanxary.h"
#include "nsbb\nstlibre.h"
#include "nssavoir\nsgraphe.h"
#include "nsbb\nsdico.h"
#include "nsdn\nsdocnoy.h"
#include "nautilus\nsbasimg.h"

// on instancie les donn�es statiques
string NSHtml::marqueurTitreDebut[20] = {"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};
string NSHtml::marqueurTitreFin[20] = {"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};

// -------------------------------------------------------------------------
// ---------------------- METHODES DE NSHtmlArray --------------------------
// -------------------------------------------------------------------------
  /*
NSHtmlArray::NSHtmlArray()
            :NSHtmlModeleArray()
{}

//
//  Constructeur copie
//
NSHtmlArray::NSHtmlArray(NSHtmlArray& rv)
            :NSHtmlModeleArray()
{
try
{
    if (!(rv.empty()))
        for (HtmlIter i = rv.begin(); i != rv.end(); i++)
            push_back(new NSHtml(*(*i)));
}
catch (...)
{
    erreur("Exception (NSHtmlArray copy ctor)", 0, 0);
}
}

////  Destructeur
//
void
NSHtmlArray::vider()
{
    if (empty())
        return ;

    for (HtmlIter i = begin(); i != end(); )
    {
   	    delete *i;
        erase(i);
    }
}

NSHtmlArray::~NSHtmlArray(){
	vider();
}

////  Op�rateur d'affectation
//
NSHtmlArray&
NSHtmlArray::operator=(NSHtmlArray src)
{
try
{
    HtmlIter i;
    //
    // Effacement des �l�ments d�j� contenus dans le vecteur destination
    //
	vider();
	//
    // Copie et insertion des �l�ments de la source
    //
    if (!(src.empty()))
  	    for (i = src.begin(); i != src.end(); i++)
   	        push_back(new NSHtml(*(*i)));

	return *this;
}
catch (...)
{
    erreur("Exception (NSHtmlArray op =)", 0, 0);
    return *this;
}
}
    */
// -------------------------------------------------------------------------// 							METHODES DE NSBlocHtmlArray
// -------------------------------------------------------------------------
/*
NSBlocHtmlArray::NSBlocHtmlArray() : NSBlocHtmlModeleArray()
{
}

//
//  Constructeur copie
//
NSBlocHtmlArray::NSBlocHtmlArray(NSBlocHtmlArray& rv) : NSBlocHtmlModeleArray()
{
try
{
    if (!(rv.empty()))
	    for (NSBlocHtmlArrayIter i = rv.begin(); i != rv.end(); i++)
   	        push_back(new NSBlocHtml(*(*i)));
}
catch (...)
{
    erreur("Exception (NSBlocHtmlArray copy ctor)", 0, 0);
}
}

////  Destructeur
//
void
NSBlocHtmlArray::vider()
{
    if (empty())
        return ;

	for (NSBlocHtmlArrayIter i = begin(); i != end(); )
    {
   	    delete *i;
        erase(i);
    }
}

NSBlocHtmlArray::~NSBlocHtmlArray(){
	vider();
}
           */
// -------------------------------------------------------------------------
// 							METHODES DE NSBlocHtmlMatrice
// -------------------------------------------------------------------------
  /*
NSBlocHtmlMatrice::NSBlocHtmlMatrice() : NSBlocHtmlModeleMatrice()
{
}

////  Constructeur copie
//
NSBlocHtmlMatrice::NSBlocHtmlMatrice(NSBlocHtmlMatrice& rv) : NSBlocHtmlModeleMatrice()
{
try
{
    if (!(rv.empty()))
	    for (NSBlocHtmlMatriceIter i = rv.begin(); i != rv.end(); i++)
   	        push_back(new NSBlocHtmlArray(*(*i)));
}
catch (...)
{
    erreur("Exception (NSBlocHtmlMatrice copy ctor)", 0, 0);
}
}

////  Destructeur
//
void
NSBlocHtmlMatrice::vider()
{
    if (empty())
        return ;

	for (NSBlocHtmlMatriceIter i = begin(); i != end(); )
    {
   	    delete *i;
        erase(i);
    }
}

NSBlocHtmlMatrice::~NSBlocHtmlMatrice(){
	vider();
}   */

//
// Fonctions de conversion des types en tags et vice-versa
//

string
typeString(HtmlTypes th)
{
  string sType ;

  switch (th)
  {
    case tCR :
      sType = "CR" ; break ;
    case tCS :
      sType = "CS" ; break ;
    case tCQ :
      sType = "CQ" ; break ;
    case tRTF :
      sType = "RTF" ; break ;
    case tTXT :
      sType = "TXT" ; break ;
    case tXML :
      sType = "XML" ; break ;
    case tTitle :
      sType = "titre" ; break ;
    case tOperateur :
      sType = "operateur" ; break ;
    case tDate :
      sType = "date" ; break ;
    case tDest :
      sType = "destinataire" ; break ;
    case tIntitule :
      sType = "intitule" ; break ;
    case tSignature :
      sType = "signature" ; break ;
    default :   // on doit introduire un type par d�faut pour pouvoir g�rer les XML
      sType = "nautilus" ;
  }

  return sType ;
}

HtmlTypestypeTag(string sTag)
{
  if (sTag == "CR")
    return tCR ;
  else if (sTag == "CS")
    return tCS ;
  else if (sTag == "CQ")
    return tCQ ;
  else if (sTag == "RTF")
    return tRTF ;
  else if (sTag == "TXT")
    return tTXT ;
  // cas des balises XML (htmlXML, headXML, bodyXML)
  else if (sTag.find("XML") != NPOS)
    return tXML ;
  else if (sTag == "titre")
    return tTitle ;
  else if (sTag == "operateur")
    return tOperateur ;
  else if (sTag == "date")
    return tDate ;
  else if (sTag == "destinataire")
    return tDest ;
  else if (sTag == "intitule")
    return tIntitule ;
  else if (sTag == "signature")
    return tSignature ;
  else // cas de tous les types "string" : on doit savoir que ce sont des tags Nautilus
    return tNautilus ; // pour ne pas les confondre avec des tags XML
}

//----------------------------------------------------------------------------
//		Classe NSHtml
//----------------------------------------------------------------------------

NSHtml::NSHtml(HtmlTypes th, string sTxt){
    type    = th;
    sType   = typeString(th);
    sTexte  = sTxt;
    sURL    = string("");
    size    = 0;
    sFace   = "";
    filsArray.vider();
}

NSHtml::NSHtml(string sTyp, string sTxt)
{
	type    = typeTag(sTyp);
	sType   = sTyp;
    sTexte  = sTxt;
    sURL    = string("");
    size    = 0;
    sFace   = "";
    filsArray.vider();
}

NSHtml::NSHtml(HtmlTypes th, string face, int taille){
    type    = th;
    sType   = typeString(th);
    sTexte  = "";
    sURL    = "";
    size    = taille;
    sFace   = face;
    filsArray.vider();
}

NSHtml::NSHtml(NSHtml& rv)
{
	type        = rv.type ;
    sType       = rv.sType ;
    sPath       = rv.sPath ;
    sTexte      = rv.sTexte ;
    sURL        = rv.sURL ;
    size        = rv.size ;
    sFace       = rv.sFace ;
    filsArray   = rv.filsArray ;
}

NSHtml::~NSHtml(){
}

NSHtml&
NSHtml::operator=(NSHtml src)
{
	if (this == &src)
		return (*this) ;

	type      = src.type ;
	sType     = src.sType ;
	sPath     = src.sPath ;
	sTexte    = src.sTexte ;
	sURL      = src.sURL ;
	size      = src.size ;
	sFace     = src.sFace ;
	filsArray = src.filsArray ;

	return (*this) ;
}

voidNSHtml::init(string titre)
{
try
{
	NSHtml head(tHead), title(tTitle), base(tBase), body(tBody) ;

	title.sTexte = titre ;
	base.sURL = string("file://C:/html/") ;

	head.filsArray.push_back(new NSHtml(title)) ;
  head.filsArray.push_back(new NSHtml(base)) ;
  filsArray.push_back(new NSHtml(head)) ;
  filsArray.push_back(new NSHtml(body)) ;
}
catch (...)
{
	erreur("Exception (NSHtml::init)", standardError, 0) ;
}
}

// Attention GetBody ne s'utilise qu'apr�s init sur un NSHtml(0)NSHtml*
NSHtml::GetBody()
{
	return filsArray[1];
}

// ins�re un nouveau fils � la fin du tableau du p�re
void
NSHtml::insere(NSHtml *pPere, NSHtml *pFils)
{
try
{
	pPere->filsArray.push_back(new NSHtml(*pFils)) ;
}
catch (...)
{
	erreur("Exception (NSHtml::insere)", standardError, 0) ;
}
}

stringNSHtml::marqueurDebut()
{
	string sm ;
	char   texteTag[255] ;

    switch (type)
    {
    	case tHtml:
      		sm = string("<HTML>");
         	break;
      	case tHead:
      		sm = string("<HEAD>");
         	break;
      	case tBody:
      		sm = string("<BODY>");
         	break;
      	case tTitle:
      		sm = string("<TITLE>");
         	break;
      	case tBase:
      		sm = string("<BASE HREF=\"") + sURL + string("\">");
         	break;
        case tXML:
            sm = string("");
            break;
      	case tImage:
      		sm = string("<IMG SRC=\"") + sURL + string("\">");
         	break;
      	case tTitre1:
      		if (marqueurTitreDebut[1] != "")
         		sm = marqueurTitreDebut[1];
         	else
      			sm = string("<H1>");
         	break;
    	case tTitre2:
      		if (marqueurTitreDebut[2] != "")
         		sm = marqueurTitreDebut[2];
         	else      			sm = string("<H2>");
         	break;
      	case tTitre3:
      		if (marqueurTitreDebut[3] != "")
         		sm = marqueurTitreDebut[3];
         	else
      			sm = string("<H3>");
         	break;
      	case tTitre4:
      		if (marqueurTitreDebut[4] != "")
         		sm = marqueurTitreDebut[4];
         	else
      			sm = string("<H4>");
         	break;
      	case tTitre5:
      		if (marqueurTitreDebut[5] != "")
         		sm = marqueurTitreDebut[5];
         	else
      			sm = string("<H5>");
         	break;
      	case tTitre6:
      		if (marqueurTitreDebut[6] != "")
         		sm = marqueurTitreDebut[6];
        	else
      			sm = string("<H6>");
         	break;
        case tTitre7:
      		if (marqueurTitreDebut[7] != "")
         		sm = marqueurTitreDebut[7];
        	else
      			sm = string("<H7>");
         	break;
        case tTitre8:
      		if (marqueurTitreDebut[8] != "")
         		sm = marqueurTitreDebut[8];
        	else
      			sm = string("");
         	break;
        case tTitre9:
      		if (marqueurTitreDebut[9] != "")
         		sm = marqueurTitreDebut[9];
        	else
      			sm = string("");
         	break;
        case tTitre10:
      		if (marqueurTitreDebut[10] != "")
         		sm = marqueurTitreDebut[10];
        	else
      			sm = string("");
         	break;
        case tTitre11:
      		if (marqueurTitreDebut[11] != "")
         		sm = marqueurTitreDebut[11];
        	else
      			sm = string("");
         	break;
        case tTitre12:
      		if (marqueurTitreDebut[12] != "")
         		sm = marqueurTitreDebut[12];
        	else
      			sm = string("");
         	break;
        case tTitre13:
      		if (marqueurTitreDebut[13] != "")
         		sm = marqueurTitreDebut[13];
        	else
      			sm = string("");
         	break;
        case tTitre14:
      		if (marqueurTitreDebut[14] != "")
         		sm = marqueurTitreDebut[14];
        	else
      			sm = string("");
         	break;
        case tTitre15:
      		if (marqueurTitreDebut[15] != "")
         		sm = marqueurTitreDebut[15];
        	else
      			sm = string("");
         	break;
        case tTitre16:
      		if (marqueurTitreDebut[16] != "")
         		sm = marqueurTitreDebut[16];
        	else
      			sm = string("");
         	break;
        case tTitre17:
      		if (marqueurTitreDebut[17] != "")
         		sm = marqueurTitreDebut[17];
        	else
      			sm = string("");
         	break;
        case tTitre18:
      		if (marqueurTitreDebut[18] != "")
         		sm = marqueurTitreDebut[18];
        	else
      			sm = string("");
         	break;
        case tTitre19:
      		if (marqueurTitreDebut[19] != "")
         		sm = marqueurTitreDebut[19];
        	else
      			sm = string("");
         	break;
      	case tTexte:
      		if (marqueurTitreDebut[0] != "")
         		sm = marqueurTitreDebut[0];
        	else
      			sm = string("");
         	break;
      	case tIntitule:
      		if (marqueurTitreDebut[3] != "")
         		sm = marqueurTitreDebut[3];
         	else
      			sm = string("<H3>");
         	break;
      	case tConsult:
      		sm = string("<LI>");
         	break;
      	case tPolice:
        	sprintf(texteTag, "<FONT FACE=\"%s\" SIZE=\"%d\">", sFace.c_str(), size);
        	sm = string(texteTag);
         	break;
      	case tPara:
      		sm = string("<P>");
         	break;
      	case tParaCentre:
      		sm = string("<P ALIGN=\"CENTER\">");
         	break;
      	case tParaDroite:
      		sm = string("<P ALIGN=\"RIGHT\">");
         	break;
      	case tGras:
      		sm = string("<B>");
         	break;
      	case tSouligne:
      		sm = string("<U>");
         	break;
      	case tItalic:
      		sm = string("<I>");
         	break;
      	case tIndent:
      		sm = string("<BLOCKQUOTE>");
         	break;
      	case tSignature:
      		sm = string("<B>");
         	break;
      	default :
      		sm = string("");
	}
   	return sm;
}

string
NSHtml::marqueurFin()
{
    string sm;

    switch (type)
    {
   	    case tHtml:
      	    sm = string("</HTML>");
            break;
        case tHead:
      	    sm = string("</HEAD>");
            break;
        case tBody:
      	    sm = string("</BODY>");
            break;
        case tTitle:
      	    sm = string("</TITLE>");
            break;
        case tBase:
            sm = string("");
            break;
        case tXML:
            sm = string("");
            break;
        case tImage:
            sm = string("");
            break;
        case tTitre1:
      	    if (marqueurTitreFin[1] != "")
         	    sm = marqueurTitreFin[1];
            else
      		    sm = string("</H1>");
            break;
        case tTitre2:
      	    if (marqueurTitreFin[2] != "")
         	    sm = marqueurTitreFin[2];
            else
      		    sm = string("</H2>");
            break;
        case tTitre3:
      	    if (marqueurTitreFin[3] != "")
         	    sm = marqueurTitreFin[3];
            else
      		    sm = string("</H3>");
            break;
        case tTitre4:
      	    if (marqueurTitreFin[4] != "")
         	    sm = marqueurTitreFin[4];
            else
      		    sm = string("</H4>");
            break;
        case tTitre5:
      	    if (marqueurTitreFin[5] != "")
         	    sm = marqueurTitreFin[5];
            else
      		    sm = string("</H5>");
            break;
        case tTitre6:
      	    if (marqueurTitreFin[6] != "")
         	    sm = marqueurTitreFin[6];
            else
      		    sm = string("</H6>");
            break;
        case tTitre7:
      	    if (marqueurTitreFin[7] != "")
         	    sm = marqueurTitreFin[7];
            else
      		    sm = string("</H7>");
            break;
        case tTitre8:
      	    if (marqueurTitreFin[8] != "")
         	    sm = marqueurTitreFin[8];
            else
      		    sm = string("");
            break;
        case tTitre9:
      	    if (marqueurTitreFin[9] != "")
         	    sm = marqueurTitreFin[9];
            else
      		    sm = string("");
            break;
        case tTitre10:
      	    if (marqueurTitreFin[10] != "")
         	    sm = marqueurTitreFin[10];
            else
      		    sm = string("");
            break;
        case tTitre11:
      	    if (marqueurTitreFin[11] != "")
         	    sm = marqueurTitreFin[11];
            else
      		    sm = string("");
            break;
        case tTitre12:
      	    if (marqueurTitreFin[12] != "")
         	    sm = marqueurTitreFin[12];
            else
      		    sm = string("");
            break;
        case tTitre13:
      	    if (marqueurTitreFin[13] != "")
         	    sm = marqueurTitreFin[13];
            else
      		    sm = string("");
            break;
        case tTitre14:
      	    if (marqueurTitreFin[14] != "")
         	    sm = marqueurTitreFin[14];
            else
      		    sm = string("");
            break;
        case tTitre15:
      	    if (marqueurTitreFin[15] != "")
         	    sm = marqueurTitreFin[15];
            else
      		    sm = string("");
            break;
        case tTitre16:
      	    if (marqueurTitreFin[16] != "")
         	    sm = marqueurTitreFin[16];
            else
      		    sm = string("");
            break;
        case tTitre17:
      	    if (marqueurTitreFin[17] != "")
         	    sm = marqueurTitreFin[17];
            else
      		    sm = string("");
            break;
        case tTitre18:
      	    if (marqueurTitreFin[18] != "")
         	    sm = marqueurTitreFin[18];
            else
      		    sm = string("");
            break;
        case tTitre19:
      	    if (marqueurTitreFin[19] != "")
         	    sm = marqueurTitreFin[19];
            else
      		    sm = string("");
            break;
        case tTexte:
      	    if (marqueurTitreFin[0] != "")
         	    sm = marqueurTitreFin[0];
            else
      		    sm = string("");
            break;
        case tIntitule:
      	    if (marqueurTitreFin[3] != "")
         	    sm = marqueurTitreFin[3];
            else
      		    sm = string("</H3>");
            break;
        case tConsult:
      	    sm = string("");
            break;
        case tPolice:
            sm = string("</FONT>");
            break;
        case tPara:
      	    sm = string("</P>");
            break;
        case tParaCentre:
      	    sm = string("</P>");
            break;
        case tParaDroite:
      	    sm = string("</P>");
            break;
        case tGras:
      	    sm = string("</B>");
            break;
        case tSouligne:
      	    sm = string("</U>");
            break;
        case tItalic:
      	    sm = string("</I>");
            break;
        case tIndent:
      	    sm = string("</BLOCKQUOTE>");
            break;
        case tSignature:
      	    sm = string("</B>");
            break;
        default :
      	    sm = string("");
    }
    return sm;
}

bool
NSHtml::ecrire(char *fichier)
{
try
{
	ofstream outFile ;
	string sOut = string("") ;

	outFile.open(fichier) ;
	if (!outFile)
		return false ;

	genere(sOut) ;

	for (size_t i = 0; i < strlen(sOut.c_str()); i++)
		outFile.put(sOut[i]) ;

	outFile.close() ;
	return true ;
}
catch (...)
{
	erreur("Exception (NSHtml::ecrire)", standardError, 0) ;
	return false ;
}
}

stringNSHtml::space(int n)
{
    string texte("");
    for (int i=0; i < n; i++)
   	    texte += string(1,' ');
    return texte;
}

void
NSHtml::genereTexte(string texte, int tab, string& sOut)
{
    if (tab)
   	    sOut += space(tab);

    for (size_t i = 0; i < strlen(texte.c_str()); i++)
    {
   	    if (texte[i] == '\n')     		// remplace les \n par des BR
        {
            sOut += string("<BR>\n");
            if (tab)
   			    sOut += space(tab);
        }
        else
      	    sOut += string(1, texte[i]);
    }
    sOut += string(1,'\n');
}

voidNSHtml::genereTexte(string texte, string& sOut)
{
    if (texte != "")
    {
        for (size_t i = 0; i < strlen(texte.c_str()); i++)
   	    {
   		    if (texte[i] == '\n')
         	    sOut += string("<BR>\n");
      	    else
      		    sOut += string(1, texte[i]);
   	    }
   	    sOut += string(1,'\n');
    }
}

// remplace les accolades du tag titre par des balises htmlvoid
NSHtml::remplaceTitre(string& sTag)
{
    size_t pos = sTag.find("{");

    while (pos != NPOS)    {
    	sTag.replace(pos, 1, "<");
        pos = sTag.find("{", pos+1);
    }

    pos = sTag.find("}");

    while (pos != NPOS)
    {
    	sTag.replace(pos, 1, ">");
        pos = sTag.find("}", pos+1);
    }
}

// initialise marqueurTitreDebut et marqueurTitreFinvoid
NSHtml::initTitres(string& params)
{
    size_t     pos1, pos2;
    int		typeTitre;
   	string 	sTypeTitre;
    string  sMarqueur;

  size_t pos = params.find("T") ;
  while (pos != NPOS)
  {
    // on r�cup�re le type titre
        sTypeTitre = params[pos+1];
        typeTitre = atoi(sTypeTitre.c_str());

        // on r�cup�re le marqueur d�but
        pos1 = params.find("(", pos+2);
        pos2 = params.find("|", pos+2);

        if ((pos1 == NPOS) || (pos2 == NPOS) || (pos1 > pos2))
        {
					erreur("Erreur syntaxique dans un bloc titre du fichier modele", standardError, 0);
            return;
        }

        sMarqueur = string(params, pos1+1, pos2-pos1-1);
        // remplaceTitre(sMarqueur);
        marqueurTitreDebut[typeTitre] = sMarqueur;

        // on r�cup�re le marqueur fin
        pos1 = pos2;
        pos2 = params.find(")", pos1+1);

        if (pos2 == NPOS)
        {
					erreur("Erreur syntaxique dans un bloc titre du fichier modele", standardError, 0) ;
          return ;
        }

        sMarqueur = string(params, pos1+1, pos2-pos1-1);
        // remplaceTitre(sMarqueur);
        marqueurTitreFin[typeTitre] = sMarqueur;

        // on relance le process pour le titre suivant
		pos = params.find("T", pos2+1);
    }
}

voidNSHtml::genere(string& sOut)
{
  string sOpeningTag = marqueurDebut() ;
  string sClosingTag = marqueurFin() ;

	genereTexte(sOpeningTag, sOut) ;

  if ((type == tXML) || (type == tCQ))   // les balises XML ou CQ doivent etre remplac�es telles quelles
    sOut += sTexte ;
  else // pour le texte HTML on remplace les '\n' par des <BR>
  {
    boldifier(sOpeningTag, sClosingTag) ;
    genereTexte(sTexte, sOut) ;
  }

  // appel r�cursif de genere sur les fils �ventuels
  if (false == filsArray.empty())
  {
    // cas des listes, types tCS : tag consultation
    // et type tConsult : �l�ment consultation (cf nscsvue.cpp)
    if ((type == tCS) || (type == tConsult))
      genereTexte("<UL>", sOut) ;

    for (HtmlIter i = filsArray.begin(); i != filsArray.end(); i++)
      (*i)->genere(sOut);

    if (type == tConsult)
      genereTexte("</UL>", sOut) ;
  }

  genereTexte(sClosingTag, sOut) ;
}

void
NSHtml::boldifier(string sOpeningTag, string sClosingTag)
{
  if (string("") == sTexte)
    return ;

  size_t iFirstStart = sTexte.find(START_BOLD) ;
  size_t iFirstEnd   = sTexte.find(END_BOLD) ;

  if ((NPOS == iFirstStart) && (NPOS == iFirstEnd))
    return ;

  string sOpenTag  = string("<strong>") ;
  string sCloseTag = string("</strong>") ;

  // find "bold" or "b" or "strong" tags in sOpeningTag
  //
  size_t iOpenTag = sOpeningTag.find("<") ;
  while (NPOS != iOpenTag)
  {
    size_t iCloseTag = sOpeningTag.find(">", iOpenTag) ;
    if (iCloseTag > iOpenTag + 1)
    {
      string sTag = string(sOpeningTag, iOpenTag + 1, iCloseTag - iOpenTag - 1) ;
      strip(sTag) ;
      pseumaj(&sTag) ;
      if ((string("B") == sTag) || (string("BOLD") == sTag) || (string("STRONG") == sTag))
      {
        sOpenTag  = string("<i>") ;
        sCloseTag = string("</i>") ;
        break ;
      }
    }
    iOpenTag = sOpeningTag.find("<", iCloseTag) ;
  }

  while (NPOS != iFirstStart)
  {
    sTexte.replace(iFirstStart, strlen(START_BOLD), sOpenTag) ;
    iFirstStart = sTexte.find(START_BOLD) ;
  }

  // Re-evaluate iFirstEnd because sTexte was probably changed
  //
  iFirstEnd = sTexte.find(END_BOLD) ;

  while (NPOS != iFirstEnd)
  {
    sTexte.replace(iFirstEnd, strlen(END_BOLD), sCloseTag) ;
    iFirstEnd = sTexte.find(END_BOLD) ;
  }
}

//----------------------------------------------------------------------------//		Classe NSBlocHtml
//----------------------------------------------------------------------------

NSBlocHtml::NSBlocHtml(NSHtml* ph, int nbOccur)
{
try
{
    occur = nbOccur;
    if (ph)
   	    pHtml = new NSHtml(*ph);
    else
        pHtml = 0;
}
catch (...)
{
    erreur("Exception (NSBlocHtml ctor)", standardError, 0);
}
}

NSBlocHtml::NSBlocHtml(NSBlocHtml& rv){
try
{
    occur = rv.occur;
    pHtml = new NSHtml(*(rv.pHtml));
}
catch (...)
{
    erreur("Exception (NSBlocHtml copy ctor)", standardError, 0);
}
}

NSBlocHtml&NSBlocHtml::operator=(NSBlocHtml src)
{
try
{
	occur = src.occur;
    pHtml = new NSHtml(*(src.pHtml));
    return (*this);
}
catch (...)
{
    erreur("Exception (NSBlocHtml = oper)", standardError, 0);
    return *this;
}
}

NSBlocHtml::~NSBlocHtml(){
    if (pHtml)
   	    delete pHtml;
}

//----------------------------------------------------------------------------
//		Classe NSModHtml
// Classe encapsulant un ou plusieurs objets NSHtml et comprenant les
// m�thodes permettant de les g�n�rer sur fichier � partir d'un modele donn�.
//----------------------------------------------------------------------------

// Constructeur : instancie un mod�le vide
NSModHtml::NSModHtml(OperationType typeOp, NSNoyauDocument* pDocNoy, NSContexte* pCtx)
          :NSRoot(pCtx)
{
	nbHtml = 0 ;
	bExisteTable = false ;
	sModele = string("") ;
	sOut    = string("") ;

	if ((pDocNoy) && (pDocNoy->pDocInfo))
  	sCodeDoc = pDocNoy->pDocInfo->getID() ;
	else
  	sCodeDoc = "" ;

  typeOperation = typeOp ;
  sBaseImages   = "" ;       // base d'images � r�cup�rer
  sBaseCompo    = "" ;       // idem pour la composition
  pBaseImages   = 0 ;        // pointeur initialis� par chargeBaseImages()
  pBaseCompo    = 0 ;
  pDocBrut      = pDocNoy ;
}

// destructeur : delete des pointeurs de NSHtmlNSModHtml::~NSModHtml()
{
	if (pBaseImages)
		delete pBaseImages ;

	if (pBaseCompo)
		delete pBaseCompo ;
}

voidNSModHtml::ajoute(NSHtml* ph, int nbOccur)
{
try
{
	blocHtml.push_back(new NSBlocHtml(ph, nbOccur)) ;
	nbHtml++ ;
}
catch (...)
{
	erreur("Exception (NSModHtml::ajoute)", standardError, 0) ;
}
}

bool
NSModHtml::lireModele(string fichier, string entete)
{
try
{
	ifstream inFile ;
	inFile.open(fichier.c_str()) ;
	if (!inFile)
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    sErrorText += string(" ") + fichier ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
  }

	sFichierTemplate = fichier ;
	sFichierEnTete = entete ;

  string line ;
	while (!inFile.eof())
	{
  	getline(inFile, line) ;
    if (string("") != line)
    	sModele += line + string("\n") ;
	}
	inFile.close() ;

	scanPrintParams() ;

	nbTagsImage = compteTags("image") ;

	return true ;
}
catch (...)
{
	erreur("Exception (NSModHtml::lireModele)", standardError, 0) ;
	return false ;
}
}

stringNSModHtml::texteHtml(string texte)
{
	string sHtml("") ;

/*
#ifdef _INCLUS
    sHtml = texte;
#else
*/
	for (size_t i = 0; i < strlen(texte.c_str()); i++)	{
  	switch (texte[i])
    {
      case '�':
        sHtml = sHtml + "&acirc;" ;  break ;
      case '�':
        sHtml = sHtml + "&agrave;" ; break ;
      case '�':
        sHtml = sHtml + "&ccedil;" ; break ;
      case '�':
        sHtml = sHtml + "&eacute;" ; break ;
      case '�':
        sHtml = sHtml + "&ecirc;" ;  break ;
      case '�':
        sHtml = sHtml + "&egrave;" ; break ;
      case '�':
        sHtml = sHtml + "&euml;" ;   break ;
      case '�':
        sHtml = sHtml + "&icirc;" ;  break ;
      case '�':
        sHtml = sHtml + "&iuml;" ;   break ;
      case '�':
        sHtml = sHtml + "&ocirc;" ;  break ;
      case '<':
        sHtml = sHtml + "&lt;" ;     break ;
      case '>':
        sHtml = sHtml + "&gt;" ;     break ;
      case '&':
        sHtml = sHtml + "&ramp;" ;   break ;
      case '"':
        sHtml = sHtml + "&quot;" ;   break ;
      case '|':
      	sHtml = sHtml + "&#124;" ;   break ;
      default :
        sHtml = sHtml + texte[i] ;
    }
	}
//#endif
    return sHtml;
}

string
NSModHtml::nomSansDoublons(string pathRef, string nom, string ext)
{
try
{
  int     cpt = 0;
  bool    exist = true;
  char    suff[4];
  string  suffixe;
  string  nomComplet;
  string  sNomFichier;

  while (exist)
  {
    sprintf(suff,"%03d",cpt);
    suffixe = string(suff);
    nomComplet = nom + string("_") + suffixe;
    // nomFichier = TFileName(sServeur.c_str(),cUnite,pathRef.c_str(),nomComplet.c_str(),ext.c_str());
    sNomFichier = pathRef + nomComplet + string(".") + ext;
    exist = FileExists(AnsiString(sNomFichier.c_str()));
    cpt++;
    if (cpt == 1000) // limite du nombre de doublons
    {
    	erreur("Vous avez atteint la limite du nombre de doublons.", standardError, 0, pContexte->GetMainWindow()->GetHandle());
      nomComplet = "";
      exist = false;
    }
  }

  if (nomComplet != "")
		nomComplet = nomComplet + string(".") + ext ;

  return nomComplet ;
}
catch (...)
{
    erreur("Exception NSModHtml::nomSansDoublons", standardError, 0);
    return "";
}
}

// M�thode d'initialisation d'une base d'images utilis�e pour// la composition. Ins�re les images de la chemise du document brut
// dans la base d'images. pHtmlInfo (pDocInfo) est utilis� en N_TIERS
bool
NSModHtml::chargeBaseImages(string sPathBase, string sPathImages, bool bPreSelect, NSDocumentInfo* pHtmlInfo)
{
try
{
  NSDocumentInfo* pTemplateInfo = pHtmlInfo ;

  // No pHtmlInfo means that the document itself is the template
  //
  if (NULL == pTemplateInfo)
  {
    if (NULL == pDocBrut)
		  return false ;
    pTemplateInfo = pDocBrut->pDocInfo ;
  }

  if (NULL == pTemplateInfo)
    return false ;

  string sCodeChemise = "" ;              // code chemise du document brut
  string sCodeChemDoc = "" ;              // idem plus blancs pour la recherche
  string sCodeDocChemise = "" ;           // code des documents de la chemise
  bool   chemiseAvecImages = false ;
  bool   pathInit = false ;

  if (sPathImages != "")
		pathInit = true ;

	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
	VecteurString  VectString ;
	string         sNodeChemise ;

	// on r�cup�re d'abord la chemise (folder) du document
	pGraphe->TousLesVrais(pTemplateInfo->sCodeDocMeta, NSRootLink::docFolder, &VectString, "ENVERS") ;
	if (VectString.empty())
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("folderErrors", "cannotFindTheFolderThisDocumentIsPartOf") ;
    sErrorText += string(" (") + pTemplateInfo->sCodeDocMeta + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
	}

	sNodeChemise = *(*(VectString.begin())) ;

	// on r�cup�re maintenant la liste de tous les documents de cette chemise
	NSDocumentArray DocusArray ;
	VectString.vider() ;
	pGraphe->TousLesVrais(sNodeChemise, NSRootLink::docFolder, &VectString) ;

	if (false == VectString.empty())
	{
  	for (EquiItemIter i = VectString.begin(); i != VectString.end(); i++)
    	DocusArray.push_back(new NSDocumentInfo(*(*i), pContexte)) ;

    // R�cup�ration des informations des documents
    DocInfoIter iterDoc = DocusArray.begin() ;
    bool bOk = true ;

    while (iterDoc != DocusArray.end())    {
    	VectString.vider() ;

      string sCodePat = string((*iterDoc)->sCodeDocMeta, 0, PAT_NSS_LEN) ;
      string sCodeDoc = string((*iterDoc)->sCodeDocMeta, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;

      (*iterDoc)->setPatient(sCodePat) ;
      (*iterDoc)->setDocument(sCodeDoc) ;

      if ((*iterDoc)->ParseMetaDonnees())
      {
      	if (pContexte->typeDocument((*iterDoc)->getType(), NSSuper::isImage))
        {
        	if (!chemiseAvecImages)
          {
          	// mise � jour de la donnee membre sBaseImages
            // note : la base d'images est ici compos�e des images de la chemise
            sBaseCompo = sPathBase + nomSansDoublons(sPathBase, sCodeChemise, "img") ;

            // creation de la base d'images
            pBaseCompo = new NSBaseImages(sBaseCompo) ;
            chemiseAvecImages = true ;
          }
          // On prend l'extension li�e au type nautilus pour la copie
          // car elle correspond au type mime (inutile de prendre l'extension source)
          string sTypeImage = (*iterDoc)->getType() ;
          string sExtImage = string(sTypeImage, 2, 3) ; // extension du fichier

          // si le path images n'est pas pr�cis� : on prend le r�pertoire serveur li� au type
          // (Ne pas modifier le booleen ici)
          if (!pathInit)
          {
          	if (pContexte->typeDocument(sTypeImage, NSSuper::isImageFixe))
            	sPathImages = pContexte->PathName("SIMG") ;
            else if (pContexte->typeDocument(sTypeImage, NSSuper::isImageAnimee))
            	sPathImages = pContexte->PathName("SVID") ;
          }

          string sNomImage = nomSansDoublons(sPathImages, (*iterDoc)->sCodeDocMeta, sExtImage) ;
          string sPathSource = pContexte->PathName((*iterDoc)->getLocalis()) ;
          string sNomSource = (*iterDoc)->getFichier() ;

          if (!pBaseCompo->ajouter(sNomImage, sPathImages, sPathSource, sNomSource, sTypeImage))
          {
          	string sErrorText = pContexte->getSuperviseur()->getText("imagesManagementErrors", "cannotCopyAnImageToTheTemporaryLocation") ;
            sErrorText += string(" ") + sPathSource + sNomSource + string(" -> ") + sPathImages + sNomImage ;

            DWORD  dwLastError = GetLastError() ;
            LPTSTR lpszTemp = NULL;
            DWORD  dwRet = FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY,
                                          NULL,
                                          dwLastError,
                                          LANG_NEUTRAL,
                                          (LPTSTR)&lpszTemp,
                                          0,
                                          NULL) ;
			      if ((dwRet > 0) && (NULL != lpszTemp))
      	      sErrorText += string(" (") + string(lpszTemp) + string(")") ;
            if (NULL != lpszTemp)
				      LocalFree((HLOCAL) lpszTemp) ;

    				pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
						erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
            return false ;
          }
        }
      }
      // probl�me de r�cup�ration de la patpatho (ou de parsing) : le document
      // ne figure pas dans la liste
      else
      {
      	char msg[255] ;
        sprintf(msg, "Probl�me de r�cup�ration du document [%s%s]", (*iterDoc)->getPatient().c_str(),
                                                                         (*iterDoc)->getDocument().c_str()) ;
        erreur(msg, standardError, 0) ;
        delete *iterDoc ;
        DocusArray.erase(iterDoc) ;
        bOk = false ;
      }

      if (bOk)
      	iterDoc++ ;
    }
  }

	if (chemiseAvecImages)
	{
		// Pr�s�lection des images de la base de composition
    if (bPreSelect)
    {
    	for (int i = 0; i < pBaseCompo->nbImages; i++)
      	pBaseCompo->tableSelect[i] = i + 1 ;
    }

    // S'il existe une base d'images : on reproduit la selection dans la base de composition
    if (pBaseImages)
    {
    	int 	i, j ;

      for (i = 0; i < pBaseImages->nbImages; i++)
      {
      	for (j = 0; j < pBaseCompo->nbImages; j++)
        {
        	if (pBaseCompo->tableCompos[j] == pBaseImages->tableCompos[i])
          {
          	pBaseCompo->tableSelect[j] = pBaseImages->tableSelect[i] ;
            break ;
          }
        }
      }
    }

    if (!pBaseCompo->ecrire())
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("imagesManagementErrors", "cannotCreateImagesList") ;
    	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
			erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      return false ;
    }
  }

	return true ;
}catch (...)
{
	erreur("Exception ChargeBaseImages", standardError, 0) ;
	return false ;
}
}

// charge la base d'images de la publication// (on r�cup�re les images li�es au document � l'aide de pHtmlInfo
//	en allant les chercher dans la base des composants)

boolNSModHtml::chargeBaseImages(string sPathBase, string sPathImages, NSDocumentInfo* pHtmlInfo)
{
try
{
  // If there is already an image index in the right location, we use it
  //
	if ((toImprimer == typeOperation) || (toVisualiser == typeOperation))	{
		if (string("") != pDocBrut->sBaseImages)
    {
      size_t iPathBaseLen = strlen(sPathBase.c_str()) ;
      if ((strlen(pDocBrut->sBaseImages.c_str()) > iPathBaseLen) &&
          (string(pDocBrut->sBaseImages, 0, iPathBaseLen) == sPathBase))
      {
        if (NULL == pBaseImages)
        {
      	  pBaseImages = new NSBaseImages(sBaseImages) ;
      	  if (pBaseImages->lire())
          {
            sBaseImages = pDocBrut->sBaseImages ;
            return true ;
          }
        }
        else
        {
          sBaseImages = pDocBrut->sBaseImages ;
          return true ;
        }
      }
    }
	}

  bool pathInit = false ;
	if (string("") != sPathImages)		pathInit = true ;

	if (NULL == pHtmlInfo)
		return false ;

	bool    baseChargee = false ;

	// creation de la base d'images
  if (NULL == pBaseImages)  {		sBaseImages = sPathBase + nomSansDoublons(sPathBase, pHtmlInfo->getID(), "img") ;
		pBaseImages = new NSBaseImages(sBaseImages) ;
  }

	// En N_TIERS la variable pHtmlInfo est en fait le pDocInfo du document  string sCodeDocMeta = pHtmlInfo->sCodeDocMeta ;  NSPatPathoArray* pPatPatho = pHtmlInfo->pPres ;  if ((NULL == pPatPatho) || (true == pPatPatho->empty()))    return false ;  VecteurString VecteurString ;  NSLinkManager* pLink = pContexte->getPatient()->pGraphPerson->pLinkManager ;  // On doit maintenant retrouver les tags image pour ins�rer leurs liens  // avec les documents images
  string sElemLex, sType ;
  string sIndex = "" ;

  // on doit parcourir la librairie pour charger l'array des chemises
  PatPathoIter iter = pPatPatho->begin() ;
  int iColBase = (*iter)->getColonne() ;
  iter++ ;

  int	nbImages = 0 ;

	while ((pPatPatho->end() != iter) && ((*iter)->getColonne() > iColBase))
	{
  	string sSens = (*iter)->getLexiqueSens(pContexte) ;

    if (string("0TAG0") == sSens)
    {
      string sCodeImage = string("") ;

      string sNodeTag = (*iter)->getNode() ;
      VecteurString.vider() ;
      pLink->TousLesVrais(sNodeTag, NSRootLink::compositionTag, &VecteurString) ;
      if (false == VecteurString.empty())
      	sCodeImage = *(*(VecteurString.begin())) ;

      sIndex = "" ;
      iter++ ;

      // on charge l'index du tag
      while ((pPatPatho->end() != iter) && ((*iter)->getColonne() > iColBase+1))
      {
      	sSens = (*iter)->getLexiqueSens(pContexte) ;

        // tag number
        if (string("VNUMT") == sSens)
        {
        	iter++ ;
          while ((pPatPatho->end() != iter) && ((*iter)->getColonne() > iColBase+2))
          {
          	// on cherche ici un texte libre
            sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 2) == string("�N"))
            	sIndex = (*iter)->getComplement() ;
            iter++ ;
          }
        }
        // tag type
        else if (string("0TYPC") == sSens)
        	iter++ ;
        else
        	iter++ ;
      }

      int indexImage = atoi(sIndex.c_str()) ;

      string sTypeImage     = string("") ;
      string sFichierSource = string("") ;
      string sPathSource    = string("") ;

      // on cherche les donnees complementaires dans le graphe
      if ((string("") != sCodeImage) &&
          (true == donneesImages(sCodeImage, sPathSource, sFichierSource, sTypeImage)))
      {
      	// si le path images n'est pas pr�cis� : on prend le r�pertoire serveur li� au type
      	if (!pathInit)
      	{
      		if (pContexte->typeDocument(sTypeImage, NSSuper::isImageFixe))
        		sPathImages = pContexte->PathName("SIMG") ;
        	else if (pContexte->typeDocument(sTypeImage, NSSuper::isImageAnimee))
        		sPathImages = pContexte->PathName("SVID") ;
      	}

      	// on prend l'extension mime pour la copie   UTILISER sFichierSource      	string sExtImage = string(sTypeImage, 2, 3) ; // extension du fichier
      	string sNomImage = nomSansDoublons(sPathImages,sCodeImage,sExtImage) ;

      	if (!pBaseImages->ajouter(sNomImage, sPathImages, sPathSource, sFichierSource, sTypeImage, indexImage))      	{
      		string sErrorText = pContexte->getSuperviseur()->getText("imagesManagementErrors", "cannotCopyAnImageToTheTemporaryLocation") ;
        	sErrorText += string(" ") + sPathSource + sFichierSource + string(" -> ") + sPathImages + sNomImage ;

          DWORD  dwLastError = GetLastError() ;
          LPTSTR lpszTemp = NULL;
          DWORD  dwRet = FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY,
                                          NULL,
                                          dwLastError,
                                          LANG_NEUTRAL,
                                          (LPTSTR)&lpszTemp,
                                          0,
                                          NULL) ;
          if ((dwRet > 0) && (NULL != lpszTemp))
            sErrorText += string(" (") + string(lpszTemp) + string(")") ;
          if (NULL != lpszTemp)
            LocalFree((HLOCAL) lpszTemp) ;

        	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
        	erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
        	return false ;
      	}

      	nbImages++ ;
      }
    }
    else
    	iter++ ;
	}	if (baseChargee)	{
  	if (!pBaseImages->ecrire())
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("imagesManagementErrors", "cannotCreateImagesList") ;
    	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
			erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      return false ;
    }
	}

	return true ;}
catch (...)
{
	erreur("Exception ChargeBaseImages", standardError, 0) ;
	return false ;
}
}

// cas des images (documents Ixxxx) qui sont stock�es en tant que composants// d'un document. On r�cup�re ici les donn�es du fichier image correspondant
// pour pouvoir les publier.

boolNSModHtml::donneesImages(string sCodeImage, string& sPathSource, string& sFichierSource, string& sTypeImage)
{
try
{
	if (string("") == sCodeImage)
  	return false ;

	NSDocumentInfo DocImage(sCodeImage, pContexte) ;

  // Doc recuperation failed
  if ((NULL == DocImage.pMeta) || (true == DocImage.pMeta->empty()))
		return false ;

	string sCodePat = string(sCodeImage, 0, PAT_NSS_LEN) ;
	string sCodeDoc = string(sCodeImage, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;

	DocImage.setPatient(sCodePat) ;
	DocImage.setDocument(sCodeDoc) ;

	if (DocImage.ParseMetaDonnees())
	{
  	// on r�cupere les donnees de l'image
    sPathSource    = pContexte->PathName(DocImage.getLocalis()) ;
    sFichierSource = DocImage.getFichier() ;
    sTypeImage     = DocImage.getType() ;
	}
	else
		return false ;

	return true ;
}
catch (...)
{
	erreur("Exception NSModHtml::donneesImages", standardError, 0) ;
	return false ;
}
}

// cas des documents images (document Ixxxx)// que l'on veut visualiser => on la charge dans une base pour pouvoir
// l'afficher � l'aide d'un html.
bool
NSModHtml::chargeDocImage(string sPathBase, string sPathImages, NSDocumentInfo* pDocInfo)
{
try
{
	if (NULL == pDocInfo)
		return false ;

	bool pathInit = false ;
	if (sPathImages != "")
		pathInit = true ;

	// on r�cup�re les infos de l'image
	string sCodeImage     = pDocInfo->getID() ;
	string sPathSource    = pContexte->PathName(pDocInfo->getLocalis()) ;
	string sFichierSource = pDocInfo->getFichier() ;
	string sTypeImage     = pDocInfo->getType() ;
	// creation de la base d'images  if (NULL == pBaseImages)  {		sBaseImages = sPathBase + nomSansDoublons(sPathBase, sCodeImage, "img") ;
		pBaseImages = new NSBaseImages(sBaseImages) ;
  }

	// si le path images n'est pas pr�cis� : on prend le r�pertoire serveur li� au type
	if (!pathInit)
	{
  	if (pContexte->typeDocument(sTypeImage, NSSuper::isImageFixe))
    	sPathImages = pContexte->PathName("SIMG") ;
    else // cas des vid�os
    	sPathImages = pContexte->PathName("SVID") ;
	}

	string sExt = string(sTypeImage, 2, 3) ; // extension du fichier
  string sNomImage = nomSansDoublons(sPathImages, sCodeImage, sExt) ;

	if (!pBaseImages->ajouter(sNomImage, sPathImages, sPathSource, sFichierSource, sTypeImage))
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("imagesManagementErrors", "cannotCopyAnImageToTheTemporaryLocation") ;
    sErrorText += string(" ") + sPathSource + sFichierSource + string(" -> ") + sPathImages + sNomImage ;

    DWORD  dwLastError = GetLastError() ;
    LPTSTR lpszTemp = NULL;
    DWORD  dwRet = FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY,
                                          NULL,
                                          dwLastError,
                                          LANG_NEUTRAL,
                                          (LPTSTR)&lpszTemp,
                                          0,
                                          NULL) ;
    if ((dwRet > 0) && (NULL != lpszTemp))
      sErrorText += string(" (") + string(lpszTemp) + string(")") ;
    if (NULL != lpszTemp)
      LocalFree((HLOCAL) lpszTemp) ;

    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return false ;
	}

	if (!pBaseImages->ecrire())
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("imagesManagementErrors", "cannotCreateImagesList") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return false ;
  }

	return true ;
}
catch (...)
{
	erreur("Exception NSModHtml::chargeDocImage", standardError, 0) ;
	return false ;
}
}

boolNSModHtml::genereLienImage(int numImage, string sFichCompo, int largeur, int hauteur)
{
try
{
	string  sUrlCgi = pContexte->PathName("UCGI") ;
	char    sNum[4] ;
	char    sLargeur[6], sHauteur[6] ;
	bool    bExisteImage = false ;
	string  sFich, sBase ;

	// on v�rifie d'abord que l'image est s�lectionn�e dans la base	if (pBaseImages)
	{
  	for (int i = 0; i < pBaseImages->nbImages; i++)
    {
    	if (pBaseImages->tableSelect[i] == numImage)
      {
      	bExisteImage = true ;
        break ;
      }
    }
  }

  // On extrait les noms de fichiers de sFichCompo et sBaseCompo
  // que l'on stocke dans les variables sFich et sBase qui sont
  // les param�tres relatifs que l'on envoie � select.exe
  size_t pos = sFichCompo.find_last_of("\\") ;
  if (NPOS == pos)
		sFich = sFichCompo ;
  else
		sFich = string(sFichCompo, pos+1, strlen(sFichCompo.c_str())-pos-1) ;

  pos = sBaseCompo.find_last_of("\\");
  if (NPOS == pos)
  	sBase = sBaseCompo ;
  else
  	sBase = string(sBaseCompo, pos+1, strlen(sBaseCompo.c_str())-pos-1) ;

  itoa(numImage, sNum, 10) ;
  itoa(largeur, sLargeur, 10) ;
  itoa(hauteur, sHauteur, 10) ;

	sOut += string("<A HREF=\"") ;
	sOut += sUrlCgi ;
  sOut += string("select.exe?choix=") ;
  sOut += string(sNum) ;
  sOut += string("&largeur=") ;
  sOut += string(sLargeur) ;
  sOut += string("&hauteur=") ;
  sOut += string(sHauteur) ;

  sOut += string("&index=") ;
  if (bExisteImage)
  	sOut += string(sNum) ;
	else
  	sOut += "0" ;

  sOut += string("&pannel=1") ;
  sOut += string("&fich=") ;
  sOut += sFich ;
  sOut += string("&base=") ;
  sOut += sBase ;
  sOut += string("\">") ;

	if (bExisteImage)
  {
  	if (!genereImageBase(numImage, largeur, hauteur))
    	return false ;
	}
  else
  	sOut += string("image ") + string(sNum) ;

	sOut += string("</A>") ;
	return true ;
}
catch (...)
{
	erreur("Exception NSModHtml::genereLienImage", standardError, 0) ;
	return false ;
}
}

voidNSModHtml::genereImage(string sUrlImg, string sNomImage, string sTypeImage,
								int largeur, int hauteur)
{
try
{
	if (pContexte->typeDocument(sTypeImage, NSSuper::isImageFixe))
		sOut += string("<IMG SRC=\"") ;
	else // cas des vid�os
		sOut += string("<IMG START=1 LOOP=0 DYNSRC=\"") ;

	sOut += sUrlImg ;
	sOut += sNomImage ;
	sOut += string("\"") ;

	if (largeur && hauteur)
	{
  	char taille[80] ;
		sprintf(taille, " width=\"%d\" height=\"%d\"", largeur, hauteur) ;
		sOut += string(taille) ;
	}

	sOut += string(">") ;
}
catch (...)
{
	erreur("Exception NSModHtml::genereImage", standardError, 0) ;
}
}

// Fonction de transformation des PatPatho en stringbool
NSModHtml::generePatPatho(NSPatPathoArray* pPatPathoArray)
{
	if (NULL == pPatPathoArray)
		return false ;

	if (pContexte->getPatient() == 0)
	{
		erreur("Vous devez choisir un patient.",standardError,0,pContexte->GetMainWindow()->GetHandle()) ;
    return false ;
	}

	sOut += string("{PatPatho ") +
          string("CN040") + // string(pDocBrut->pDocInfo->pDonnees->type) +
          string("|") + pContexte->getPatient()->getNom() +
          string("|") + pContexte->getPatient()->getPrenom() +
          string("|") + pContexte->getPatient()->getNaissance() +
          string("|") + pContexte->getPatient()->getSexe() +
          string("}") ;

	if (!(pPatPathoArray->empty()))	{  	string sPathoChain = string("") ;    pPatPathoArray->genereChaine(&sPathoChain) ;    sOut += sPathoChain ;/*	    for (PatPathoIter i = pPatPathoArray->begin(); i != pPatPathoArray->end(); i++)
        {
   	        sOut += string("{Fiche}");
            sOut += texteHtml(string((*i)->pDonnees->codeLocalisation)) + string("|");
            sOut += texteHtml(string((*i)->pDonnees->type)) + string("|");
            sOut += texteHtml(string((*i)->pDonnees->lexique)) + string("|");

            // cas des textes libres : on r�cup�re le texte point� par complement
            if (!strcmp((*i)->pDonnees->lexique, "�?????"))
            {
                string sTexteLibre = (*i)->pDonnees->getTexteLibre();
                sOut += texteHtml(sTexteLibre) + string("|");
            }
            else
                sOut += texteHtml(string((*i)->pDonnees->complement)) + string("|");

            sOut += texteHtml(string((*i)->pDonnees->certitude)) + string("|");
            sOut += texteHtml(string((*i)->pDonnees->interet)) + string("|");
            sOut += texteHtml(string((*i)->pDonnees->pluriel));
		    sOut += string("{/Fiche}");
        }
*/
	}

	sOut += string("{/PatPatho}") ;

	return true ;
}

// Generation du fichier en-tete (par extension des fichiers HTML bruts)// cette fonction efface les tags <html> et <body> du fichier original
// et ins�re le fichier obtenu dans sModele (le fichier � g�n�rer) � la
// place du tag sNomTag (qui doit etre dans sModele).
bool
NSModHtml::genereHtmlBrut(string sNomTag, string sNomFichier)
{
	if (string("") == sNomFichier)
		return false ;

  ifstream 	inFile ;
	inFile.open(sNomFichier.c_str()) ;
	if (!inFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    sErrorText += string(" ") + sNomFichier ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
	}

  string fichier = "" ;
  string line ;
	while (!inFile.eof())
	{
  	getline(inFile,line) ;
    if (line != "")
    	fichier += line + string("\n") ;
	}
	inFile.close() ;

  string tag = string("[") + sNomTag + string("]") ;

	size_t pos = fichier.find("<html>");
	if (NPOS == pos)
		pos = fichier.find("<HTML>") ;

	if (NPOS != pos)
  	fichier.replace(pos, 6, "") ;

	pos = fichier.find("<body>") ;
	if (NPOS == pos)
		pos = fichier.find("<BODY>") ;

	if (NPOS != pos)
  	fichier.replace(pos, 6, "") ;

	pos = fichier.find("</body>") ;
	if (NPOS == pos)
		pos = fichier.find("</BODY>") ;

	if (NPOS != pos)
		fichier.replace(pos, 7, "") ;

	pos = fichier.find("</html>") ;
	if (NPOS == pos)
		pos = fichier.find("</HTML>") ;

	if (NPOS != pos)
  	fichier.replace(pos, 7, "") ;

	pos = sModele.find(tag) ;

	// modif RS du 08/04/04 : on remplace �ventuellement plusieurs fois le tag
	// (cf cas des en-tete pour l'odonnance bi-zone)
	while (NPOS != pos)	{  	sModele.replace(pos, strlen(tag.c_str()), fichier.c_str()) ;
    pos = sModele.find(tag, pos + strlen(fichier.c_str())) ;
	}
	return true ;
}

// recherche d'une url � partir d'un cheminbool
NSModHtml::chercheUrl(string sChemin, string& sUrl)
{
	if (sChemin == "")
		return false ;

	string sUnite   = "" ;
  string sServeur = "" ;
	string sRacineServeur = pContexte->PathName("RSRV", &sUnite) ;

	size_t pos1 = sChemin.find(sRacineServeur) ;

	// Si le chemin n'est pas sous le serveur :
	// on renvoie le chemin ou vide pour toExporter
	if (NPOS == pos1)
	{
  	if (typeOperation == toExporter)
    	sUrl = "" ;
    else
    	sUrl = sChemin ;
    return true;
	}

	string sSupport ;
	if (sUnite != "")
  	sSupport = sUnite ;
	else
  	sSupport = sServeur ;

	// on enl�ve le support du chemin car on doit passer un chemin relatif � CodeChemin
  //
  string sCheminRelatif = string("") ;
	if (string("") != sSupport)
	{
  	size_t pos2 = sChemin.find(sSupport) ;

    if (NPOS != pos2)
    {
    	pos2 = pos2 + strlen(sSupport.c_str()) ;
      sCheminRelatif = string(sChemin, pos2, strlen(sChemin.c_str())-pos2) ;
    }
    else // cas d'erreur
    {
    	erreur("Le support du serveur n'a pas �t� retrouv� dans le chemin cherch�.",standardError,0,pContexte->GetMainWindow()->GetHandle()) ;
      sCheminRelatif = sChemin ;
    }
  }
  else
  	sCheminRelatif = sChemin ;

	string sLocalis = pContexte->CodeChemin(sCheminRelatif, 'S') ;
	if (string("") == sLocalis)
  	return false ;

	// si le chemin contient la racine du serveur
	string sCodeUrl = sLocalis ;
	sCodeUrl[0] = 'U' ;
	sUrl = pContexte->PathName(sCodeUrl) ;

	return true ;
}

void
NSModHtml::recupTailleImage(int numImage, string sParam, int& largeur, int& hauteur)
{
	// taille par d�faut
  if (sParam == "")
  {
  	largeur = 150 ;
    hauteur = 140 ;
    return ;
	}

  size_t pos = sParam.find(' ') ;
	if (NPOS != pos)
	{
  	string sLargeur = string(sParam, 0, pos) ;
    string sHauteur = string(sParam, pos+1, strlen(sParam.c_str()) - pos - 1) ;
    largeur = atoi(sLargeur.c_str()) ;
    hauteur = atoi(sHauteur.c_str()) ;
    if (largeur || hauteur)
    {
    	// Attention si les deux sont � 0 on laisse tel quel
      // (pour pouvoir afficher l'image en taille r�elle)
      if (largeur == 0)
      	largeur == 150 ;
      if (hauteur == 0)
      	hauteur == 140 ;
    }
  }
  else
  {
  	char msg[255] ;
    sprintf(msg, "Erreur de syntaxe tag image n�%d", numImage) ;
    erreur(msg, standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    largeur = 150 ;
    hauteur = 140 ;
	}
}

bool
NSModHtml::genereImageBase(int numImage, int largeur, int hauteur)
{
	string sUrlImg ;
	string sImage ;
  string sTypeImage ;
  bool   bIsSelect = false ;

	for (int k = 0; k < pBaseImages->nbImages; k++)	{
  	if (pBaseImages->tableSelect[k] == numImage)
    {
    	sImage = pBaseImages->tableImages[k] ;
      sTypeImage = pBaseImages->tableTypImg[k] ;

      // on recherche l'url associ�e au path de l'image k
      if (!chercheUrl(pBaseImages->tableDesImg[k], sUrlImg))
      {
      	char msg[100] ;
        sprintf(msg,"Erreur � la recherche de l'URL de l'image n�%d de la base %s",k+1,sBaseImages.c_str()) ;
        erreur(msg,standardError,0,pContexte->GetMainWindow()->GetHandle()) ;
        return false ;
      }

      bIsSelect = true ;
      break ;
    }
  }

  // Dans le cas ou l'image ne correspond pas � une s�lection
  // on ne met plus d'alerte, on se contente de ne rien g�n�rer
  // Cela r�gle le probl�me des feuilles d'images
  /***********************************************************************
  if (!bIsSelect)
  {
      char msg[100];
      char cOut[80];
      sprintf(msg,"L'image n�%d du modele est introuvable dans le document",numImage);
      erreur(msg,0,0);
      sprintf(cOut, "image %d", numImage);
      sOut += string(cOut);
      return true;
  }
  *************************************************************************/

	if (bIsSelect)
  	genereImage(sUrlImg, sImage, sTypeImage, largeur, hauteur) ;

	return true ;
}

//// Pour les types �num�r�s qui correspondent � des html structur�s
//
void
NSModHtml::remplaceTag(string sTag, string params, string sPath)
{
	// on cherche d'abord les tags g�n�riques
	if (sTag == "nomPatient")
	{
		pContexte->getPatient()->fabriqueNomLong() ;
    sOut += pContexte->getPatient()->getNomLong() ;
    return ;  }

  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  if (sTag == "dateJour")
  {
  	char dateJ[9] ;
    char message[11] ;

    donne_date_duJour(dateJ) ;
    donne_date(dateJ, message, sLang) ;
    sOut += string(message) ;
    return ;
	}

	// on cherche ensuite les tags structur�s
	// si sPath est non vide, il peut y en avoir plusieurs
	//
	if (sPath == "")
	{
  	for (int i = 0; i < nbHtml; i++)
    {
    	if (((blocHtml[i]->pHtml)->sType == sTag) && (blocHtml[i]->occur))
      {
      	if (params != "")
        	(blocHtml[i]->pHtml)->initTitres(params) ;

        (blocHtml[i]->pHtml)->genere(sOut) ;

      	// modif du 08/04/04 : on laisse occur � 1 pour l'ordonnance
        // blocHtml[i]->occur -= 1;
        return ;
      }
    }
  }
  else
  {
  	bool bTagFound = false ;
    for (int i = 0; i < nbHtml; i++)
    {
    	if (((blocHtml[i]->pHtml)->sType == sTag) && (blocHtml[i]->occur))
      {
      	bTagFound = true ;

        string sPathSens ;
        pContexte->getDico()->donneCodeSens(&((blocHtml[i]->pHtml)->sPath), &sPathSens) ;

        if (sPathSens == sPath)
        {
        	if (params != "")
          	(blocHtml[i]->pHtml)->initTitres(params) ;

          (blocHtml[i]->pHtml)->genere(sOut) ;

        	// modif du 08/04/04 : on laisse occur � 1 pour l'ordonnance
          // blocHtml[i]->occur -= 1;
        }
        else
        	remplacePathTag(sPath, params, blocHtml[i]->pHtml) ;
      }
    }
    if (bTagFound)
    	return ;
	}

	// Pour les tags inconnus, on ne fait plus de controle d'erreur
	// � cause des tags XML de type [if ...] [endif].
	// On replace donc simplement le tag tel quel
	sOut += string("[") + sTag ;
	if (params != "")
		sOut += string(" ") + params ;
	sOut += string("]") ;
}

void
NSModHtml::remplacePathTag(string sPath, string sParams, NSHtml* pBloc)
{
	if ((!pBloc) || (sPath == ""))
		return ;
	if (pBloc->filsArray.empty())
  	return ;

	bool bGood = false ;
	for (HtmlIter HtmlIt = pBloc->filsArray.begin(); HtmlIt != pBloc->filsArray.end(); HtmlIt++)
	{
  	if ((*HtmlIt)->sPath == "")
    {
    	if (bGood)
      {
      	if (sParams != "")
        	(*HtmlIt)->initTitres(sParams) ;
        (*HtmlIt)->genere(sOut) ;
      }
		}
    else
    {
    	string sPathSens ;
      pContexte->getDico()->donneCodeSens(&((*HtmlIt)->sPath), &sPathSens) ;

      if (sPathSens == sPath)
      {
      	if (sParams != "")
        	(*HtmlIt)->initTitres(sParams) ;
        (*HtmlIt)->genere(sOut) ;
        bGood = true ;
      }
      else
      {
      	size_t iPathLen  = strlen(sPath.c_str()) ;
        size_t iLocalLen = strlen(sPathSens.c_str()) ;

        if (iLocalLen == iPathLen)
        	bGood = false ;
        else if (iLocalLen > iPathLen)
        {
        	//
          // Le chemin de l'�l�ment en cours commence par sPath : on le traite
          //
          if (string(sPathSens, 0, strlen(sPath.c_str())) == sPath)
          {
          	(*HtmlIt)->genere(sOut) ;
            bGood = true ;
          }
          else
          	bGood = false ;
        }
        else
        {
        	bGood = false ;
          //
          // Le chemin de l'�l�ment en cours est contenu dans sPath, on it�re sur ses fils
          //
          if (string(sPath, 0, strlen(sPathSens.c_str())) == sPathSens)
          	remplacePathTag(sPath, sParams, *HtmlIt) ;
        }
      }
    }
	}
}

//
// Pour les types string (avec tableaux)
//
bool
NSModHtml::valeurTag(string sTag, string& sValeurTag, NSBlocHtmlMatriceIter iterTable)
{
    for (int i = 0; i < nbHtml; i++)
    {
        if ((blocHtml[i]->pHtml)->sType == sTag)
        {
      	    sValeurTag = (blocHtml[i]->pHtml)->sTexte;
            return true;
        }
    }

    if (!((*iterTable)->empty()))
    {
        for (NSBlocHtmlArrayIter itCel = (*iterTable)->begin(); itCel != (*iterTable)->end(); itCel++)
        {
            if (((*itCel)->pHtml)->sType == sTag)
            {
                sValeurTag = ((*itCel)->pHtml)->sTexte;
                return true;
            }
        }
    }

    return false;
}

intNSModHtml::compteTags(string sTag)
{
	size_t  pos     = 0;
   	int     nbTags  = 0;

    // On cherche le tag sous la forme "[image]" puis sous la forme "[image "
    // car il peut y avoir des param�tres (par exemple la taille de l'image
    // comme [image 50 60])
    //
	string sTagR = string("[") + sTag + string("]");

   	pos = sModele.find(sTagR);
   	while ((pos != NPOS) && ((pos + strlen(sTagR.c_str())) <= strlen(sModele.c_str())))
   	{
   		nbTags++;
   		pos = sModele.find(sTagR, pos + strlen(sTagR.c_str()));
   	}

    sTagR = string("[") + sTag + string(" ");

   	pos = sModele.find(sTagR);
   	while ((pos != NPOS) && ((pos + strlen(sTagR.c_str())) <= strlen(sModele.c_str())))
   	{
   		nbTags++;
   		pos = sModele.find(sTagR, pos + strlen(sTagR.c_str()));
   	}

	return nbTags;}

// Avril 04 : scan dans la template des param�tres d'impression pour WebBrowserPrint
void
NSModHtml::scanPrintParams()
{
    string  sComment;
    size_t  comment_begin = 0;
    size_t  comment_end;
    bool    bParamsFound = false;
    size_t  params, tag, equal, value_begin, value_end;
    string  sTag, sValue;

    // on extrait au pr�alable les champs commentaires
    comment_begin = sModele.find("<!--");

    while ((!bParamsFound) && (comment_begin != NPOS))
    {
        comment_end = sModele.find("-->", comment_begin + 4);

        if (comment_end != NPOS)
        {
            sComment = string(sModele, comment_begin + 4, comment_end - comment_begin - 4);
            // on a trouv� un commentaire et on cherche un param�tre d'impression
            params = sComment.find("PrintParams");

            if (params != NPOS)
            {
                // Reset des param�tres d'impression du document
                pDocBrut->nspp.reset();

                int iLenTagParams = strlen("PrintParams");
                sComment = string(sComment, iLenTagParams + 1, strlen(sComment.c_str()) - iLenTagParams - 1);
                tag = sComment.find_first_not_of(' ');

                while (tag != NPOS)
                {
                    equal = sComment.find('=', tag);
                    if ((equal != NPOS) && (equal > tag))
                    {
                        sTag = "";
                        sValue = "";
                        bParamsFound = true;

                        for (size_t i = tag; (i < equal) && (sComment[i] != ' '); i++)
                            sTag += sComment[i];

                        value_begin = sComment.find('\"', equal + 1);

                        if (value_begin != NPOS)
                        {
                            value_end = sComment.find('\"', value_begin + 1);

                            if (value_end != NPOS)
                            {
                                sValue = string(sComment, value_begin + 1, value_end - value_begin - 1);
                            }
                            else
                            {
                                erreur("Erreur de syntaxe dans la d�finition des param�tres d'impression.", standardError, 0);
                                return;
                            }
                        }
                        else
                        {
                            erreur("Erreur de syntaxe dans la d�finition des param�tres d'impression.", standardError, 0);
                            return;
                        }

                    }
                    else
                    {
                        erreur("Erreur de syntaxe dans la d�finition des param�tres d'impression.", standardError, 0);
                        return;
                    }

                    // Setting du param�tre d'impression
                    if (bParamsFound)
                    {
                        if (sTag == "PaperSize")
                            pDocBrut->nspp.sPaperSize = sValue;
                        else if (sTag == "PaperSource")
                            pDocBrut->nspp.sPaperSource = sValue;
                        else if (sTag == "Header")
                            pDocBrut->nspp.sHeader = sValue;
                        else if (sTag == "Footer")
                            pDocBrut->nspp.sFooter = sValue;
                        else if (sTag == "Orientation")
                        {
                            pseumaj(&sValue);

                            if ((sValue == "UNDEFINED") || (sValue == "PORTRAIT") || (sValue == "LANDSCAPE"))
                                pDocBrut->nspp.sOrientation = sValue;
                        }
                        else if (sTag == "LeftMargin")
                            pDocBrut->nspp.sfLeftMargin = sValue;
                        else if (sTag == "TopMargin")
                            pDocBrut->nspp.sfTopMargin = sValue;
                        else if (sTag == "RightMargin")
                            pDocBrut->nspp.sfRightMargin = sValue;
                        else if (sTag == "BottomMargin")
                            pDocBrut->nspp.sfBottomMargin = sValue;
                        else if (sTag == "PrinterName")
                            pDocBrut->nspp.sPrinterName = sValue;
                        else if (sTag == "PrintToFile")
                        {
                            pseumaj(&sValue);

                            if ((sValue == "TRUE") || (sValue == "FALSE") || (sValue == "YES") || (sValue == "NO"))
                                pDocBrut->nspp.sbPrintToFile = sValue;
                        }
                        else if (sTag == "PrintRange")
                        {
                            pseumaj(&sValue);

                            if ((sValue == "UNDEFINED") || (sValue == "ALL") || (sValue == "PAGES") ||
                                (sValue == "SELECTION"))
                                pDocBrut->nspp.sPrintRange = sValue;
                        }
                        else if (sTag == "PrintRangePagesFrom")
                            pDocBrut->nspp.slPrintRangePagesFrom = sValue;
                        else if (sTag == "PrintRangePagesTo")
                            pDocBrut->nspp.slPrintRangePagesTo = sValue;
                        else if (sTag == "Collate")
                        {
                            pseumaj(&sValue);

                            if ((sValue == "TRUE") || (sValue == "FALSE") || (sValue == "YES") || (sValue == "NO"))
                                pDocBrut->nspp.sbCollate = sValue;
                        }
                        else if (sTag == "PrintFrames")
                        {
                            pseumaj(&sValue);

                            if ((sValue == "UNDEFINED") || (sValue == "SCREEN") || (sValue == "SELECTED") ||
                                (sValue == "INDIVIDUALLY"))
                                pDocBrut->nspp.sPrintFrames = sValue;
                        }
                        else if (sTag == "PrintLinks")
                        {
                            pseumaj(&sValue);

                            if ((sValue == "TRUE") || (sValue == "FALSE") || (sValue == "YES") || (sValue == "NO"))
                                pDocBrut->nspp.sbPrintLinks = sValue;
                        }
                        else if (sTag == "PrintLinkTable")
                        {
                            pseumaj(&sValue);

                            if ((sValue == "TRUE") || (sValue == "FALSE") || (sValue == "YES") || (sValue == "NO"))
                                pDocBrut->nspp.sbPrintLinkTable = sValue;
                        }
                    }

                    // Recherche du param�tre suivant
                    if (value_end < (strlen(sComment.c_str()) - 1))
                        tag = sComment.find_first_not_of(' ', value_end + 1);
                    else
                        break;
                }
            }

            if (!bParamsFound)
                comment_begin = sModele.find("<!--", comment_end + 3);
        }
        else // erreur de syntaxe dans un commentaire : on sort
            return;
    }
}

voidNSModHtml::processTable()
{
	NSBlocHtmlMatriceIter iterTable ;
   	string	sLigneGen, sLigne, sNewLigne, sPaquet ;
   	string  sTag, sValTag ;
   	size_t  posTag, posFinTag ;
   	size_t  pos1, pos2 ;

   	iterTable = table.begin();   	posTag = sModele.find("[TBL");

   	while (posTag != NPOS)
   	{
   		// on cherche la TR englobante

      	pos1 = sModele.rfind("<TR", posTag);
      	pos2 = sModele.find("</TR>", posTag);
      	pos2 += strlen("</TR>");

      	sPaquet = "";
      	sLigneGen = string(sModele, pos1, pos2 - pos1);

      	while (iterTable != table.end())
      	{
      		sLigne = sLigneGen;
         	posTag = sLigne.find("[");

         	while (posTag != NPOS)
         	{
         		sNewLigne = string(sLigne, 0, posTag);

            	posFinTag = sLigne.find("]", posTag);
            	sTag = string(sLigne, posTag + 1, posFinTag - posTag - 1);
            	valeurTag(sTag, sValTag, iterTable);

            	sNewLigne += sValTag;
            	sNewLigne += string(sLigne, posFinTag + 1, strlen(sLigne.c_str()) - posFinTag - 1);

            	sLigne = sNewLigne;
            	posTag = sLigne.find("[");
         	}

         	sPaquet += sLigne + string("\n");
         	iterTable++;
      	}

      	sModele.replace(pos1, pos2 - pos1, sPaquet);

      	iterTable = table.begin();
      	posTag = sModele.find("[TBL", pos1 + strlen(sPaquet.c_str()));
	}
}

// reconstitution du fichier html � partir d'une templatebool
NSModHtml::genereModele(string sFichHtml, NSDocumentInfo* pHtmlInfo, string sPathBase,
						string sPathImages, string sFichierExterne, string sTypeFichier)
{
	ofstream outFile ;
  int      numImage    = 0 ;
  bool     baseChargee = false ;
  bool     bExterne    = false ;

	// note : si le path images est pr�cis�
	// on acc�dera aux images directement par le path (FTP)
	// sans passer par une URL (HTTP)

	// s'il s'agit d'un fichier externe (et non d'un document)
	if (sFichierExterne != "")
  	bExterne = true ;

	if (bExisteTable)
  	processTable() ;

	// cas du fichier en-tete
  if (sFichierEnTete != "")
	{
  	if (!genereHtmlBrut("en-tete", sFichierEnTete))
    	return false ;
	}

	outFile.open(sFichHtml.c_str());
	if (!outFile)
	{
  	string sErreur = string("Impossible d'ouvrir ou de cr�er le fichier html � g�n�rer : ")
                                + sFichHtml ;
    erreur(sErreur.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return false ;
	}

	size_t _il = 0 ;

	while (_il < strlen(sModele.c_str()))
	{
  	while ((_il < strlen(sModele.c_str())) && (sModele[_il]!='['))
    	sOut += sModele[_il++] ;

    if (_il < strlen(sModele.c_str()))
    {
      // on analyse le tag
      _il++ ;
      string typeElt  = "" ;
      string params   = "" ;
      string sPath    = "" ;

      while ((_il < strlen(sModele.c_str())) &&
                      (sModele[_il] != ']') && (sModele[_il] != '|') && (sModele[_il] != ' '))
      	// r�cup�ration du type
        typeElt += sModele[_il++] ;

      if ((_il < strlen(sModele.c_str())) && (sModele[_il] == '|'))
      {      	_il++ ;
        while ((_il < strlen(sModele.c_str())) && (sModele[_il] != ']') && (sModele[_il] != '|') && (sModele[_il] != ' '))
        	sPath += sModele[_il++] ;

        if ((_il < strlen(sModele.c_str())) && (sModele[_il] == '|'))
        	_il++ ;
      }

      if ((_il < strlen(sModele.c_str())) && (sModele[_il]==' '))      {      	_il++ ;
        while ((_il < strlen(sModele.c_str())) && (sModele[_il]!=']'))
        	params += sModele[_il++] ;
      }

      if (_il >= strlen(sModele.c_str()))      {
      	erreur("Erreur syntaxique dans le fichier mod�le.",standardError,0,pContexte->GetMainWindow()->GetHandle()) ;
        return false ;
      }

      /* modele[i] == ']' */
      _il++ ;

      if (typeElt == "image")
      {
      	int iLargeur, iHauteur ;

        if (!baseChargee) // on v�rifie si la base est charg�e
        {
        	if (pHtmlInfo)
          {
          	// on charge la base des images du document
            if (!chargeBaseImages(sPathBase, sPathImages, pHtmlInfo))
            {
            	erreur("Impossible de r�cup�rer la base d'images", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
              return false ;
            }
          }

          // si on compose : on charge la base de composition
          if (typeOperation == toComposer)
          {
          	if (!chargeBaseImages(sPathBase, sPathImages, false, pHtmlInfo))
            {
            	erreur("Impossible de cr�er la base d'images", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
              return false ;
            }
          }

          baseChargee = true ;
        }

        numImage++ ;

        // on r�cup�re la taille (largeur,hauteur) de l'image
        recupTailleImage(numImage, params, iLargeur, iHauteur) ;

        // on g�n�re l'image ...
        if (typeOperation == toComposer)
        {
        	if (sBaseCompo != "")
          {
          	// on genere un lien vers select s'il existe au moins 1 image
            if (!genereLienImage(numImage, sFichHtml, iLargeur, iHauteur))
            	return false ;
          }
        }
        else // autres cas : on r�cup�re le composant image
        {
        	if (sBaseImages != "")
          {
          	if (!genereImageBase(numImage, iLargeur, iHauteur))
            	return false ;
          }
        }
      }
      // cas des documents images ou vid�os (cf visualisation)
      else if (typeElt == "docimage")
      {
      	string sImage, sTypeImage ;
        string sPathDestImage, sUrlImg ;

        // cas des fichiers externes
        if (bExterne)
        {
        	// nom de l'image = nom du fichier source
          sImage         = sFichierExterne ;
          sTypeImage     = sTypeFichier ;
          sPathDestImage = sPathImages ;
        }
        else // cas des images r�f�renc�es en tant que document nautilus
        {
        	if (!pHtmlInfo)
          {
          	erreur("Les donn�es de l'image ne sont pas initialis�es", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
            return false ;
          }

          // on cr�e une base d'image contenant le document image
          if (!chargeDocImage(sPathBase, sPathImages, pHtmlInfo))
          {
          	erreur("Impossible de g�n�rer le fichier html image", standardError, 0, pContexte->GetMainWindow()->GetHandle());
            return false ;
          }

          sImage         = pBaseImages->tableImages[0] ;          sTypeImage     = pBaseImages->tableTypImg[0] ;
          sPathDestImage = pBaseImages->tableDesImg[0] ;
        }

        // on recherche l'url associ�e au path de l'image
        if (!chercheUrl(sPathDestImage, sUrlImg))
        {
        	/*
          char msg[100];
          sprintf(msg,"Erreur � la recherche de l'URL d'une image de la base %s",sBaseImages.c_str());
          erreur(msg,standardError,0,pContexte->GetMainWindow()->GetHandle());
          */
        }

        // On g�n�re l'image en taille r�elle
        genereImage(sUrlImg, sImage, sTypeImage) ;
      }
      // cas des compte-rendus : on ecrit la PatPatho
      else if (typeElt == "patpatho")
      {
      	if (!generePatPatho(pDocBrut->pPatPathoArray))
        {
        	erreur("Impossible de g�n�rer la PatPatho", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
          return false ;
        }
      }
      // cas des html structur�s : on remplace le tag par un bloc du tableau blocHtml
      else
      	remplaceTag(typeElt, params, sPath) ;
    }
	}

	for (size_t _i = 0; _i < strlen(sOut.c_str()); _i++)
		outFile.put(sOut[_i]) ;

	outFile.close() ;
	return true ;
}

// appel des fonctions n�c�ssaires pour g�n�rer un fichier html (g�n�rique)// Le fichier html est ici constitu� � partir d'un document pour
// la composition (pHtmlInfo = 0), la publication		[ cas des HDHTM ]
// ou la visualisation (pHtmlInfo <- pDocInfo)			[ cas des HSHTM ]
// On utilise obligatoirement HTTP - Les images sont au besoin copi�es
// dans le r�pertoire Images du serveur
// Pour le cas de l'exportation, on ne passe pas par HTTP :
// on pr�cise alors sPathDest
bool
NSModHtml::genereHtml(string sPathHtml, string& sBaseImg,
					NSDocumentInfo* pHtmlInfo, string sPathDest)
{
	string sPathBase;
   	string sPathImg;

   	// R�pertoire par d�faut de la base d'images
   	if (sPathDest == "")
   	{
   		sPathBase = pContexte->PathName("SHTM");
      	// Par d�faut : Retrouve le path en fonction du type image
      	sPathImg = "";
   	}
   	else // cas de l'exportation : on copie les images dans sPathDest
   	{
   		sPathBase = sPathDest;
      	sPathImg = sPathDest;
   	}

	if (!lireModele(pDocBrut->sTemplate, pDocBrut->sEnTete))
   	{
        char msg[255];
        sprintf(msg, "Pb lecture du modele [%s].", (pDocBrut->sTemplate).c_str());
   		MessageBox(0,msg,0,MB_OK);
      	return false;
   	}

   	if (!genereModele(sPathHtml, pHtmlInfo, sPathBase, sPathImg))
   	{
   		MessageBox(0,"Pb �criture du fichier HTML",0,MB_OK);
      	return false;
   	}

   	// on renvoie le nom de la base d'images
   	if (typeOperation == toComposer)
   	{
   	    sBaseImg = sBaseCompo;
        pDocBrut->sBaseImages = sBaseImages;
   	}
   	else
    {
    	if (typeOperation == toExporter)
        	pDocBrut->bConserveBase = true;

   	    sBaseImg = sBaseImages;
    }

   	return true;
}

// appel des fonctions n�c�ssaires pour g�n�rer un fichier html (g�n�rique)
// Le fichier html est ici constitu� � partir d'un fichier externe
// On transmet le chemin des images, auxquelles on acc�de directement, sans passer
// par une base d'images
bool
NSModHtml::genereHtml(string sTemplate, string sPathHtml, string sPathSource,
						string sNomFichier, string sTypeFichier)
{
	if (!lireModele(sTemplate))
   	{
        char msg[255];
        sprintf(msg, "Pb lecture du modele [%s].", sTemplate.c_str());
   		MessageBox(0,msg,0,MB_OK);
      	return false;
   	}

   	// generation du fichier html
   	// (on g�n�re la base d'images et les images au meme endroit pour l'instant)
   	if (!genereModele(sPathHtml, 0, sPathSource, sPathSource, sNomFichier, sTypeFichier))
   	{
   		MessageBox(0,"Pb �criture du fichier HTML",0,MB_OK);
      	return false;
   	}

   	return true;
}

// fin du fichier nsmodhtm.cpp

