//----------------------------------------------------------------------------// ObjectWindows - (C) Copyright 1991, 1993 by Borland International
//   Tutorial application -- step12dv.cpp
//----------------------------------------------------------------------------

#include <owl\filedoc.h>
#include <iostream.h>
#include <cstring.h>

#include "partage\nsdivfct.h"

#include "nautilus\nssuper.h"
#include "nautilus\nsdecode.h"
#include "nsbb\nsbb.h"
#include "nautilus\nsrechd2.h"
#include "dcodeur\nsdkd.h"

#include "nautilus\nscrdoc.h"
#include "nautilus\nshistdo.h"
#include "nautilus\nscrvue.h"
#include "nautilus\ns_html.h"
#include "nautilus\nsldvdoc.h"

// --------------------------------------------------------------------------
// ---------------------- METHODES DE NSCRDocument --------------------------
// --------------------------------------------------------------------------

bool
afficheCompteRendu(NSDocumentInfo& Document, NSContexte *pCtx)
{
	return false ;
}

//---------------------------------------------------------------------------//
//	Constructeur � partir d'un document existant
//
//---------------------------------------------------------------------------NSCRDocument::NSCRDocument(TDocument* parent, NSDocumentInfo* pDocumentInfo,
                           NSDocumentInfo* pDocHtmlInfo, NSContexte* pCtx,
                           string sTypeCompteRendu, bool bROnly)
             :NSRefDocument(parent, pDocumentInfo, pDocHtmlInfo, pCtx, bROnly)
{
	EstDecode  = false ;
	sFichDecod = "" ;
	pBigBoss   = 0 ;

	strcpy(lexiqueModule, sTypeCompteRendu.c_str()) ;
}

//---------------------------------------------------------------------------
//
//	Constructeur pour un nouveau document
//
//---------------------------------------------------------------------------
NSCRDocument::NSCRDocument(TDocument* parent, NSContexte* pCtx, string sTypeCompteRendu)
             :NSRefDocument(parent, pCtx)
{
	//sCompteRendu = "";
	if (pContexte->userHasPrivilege(NSContexte::createDocument, -1, -1, string(""), string(""), NULL, NULL))
		bReadOnly = false ;
  else
		bReadOnly = true ;

	EstDecode  = false ;
	sFichDecod = "" ;
	pBigBoss   = 0 ;

	strcpy(lexiqueModule, sTypeCompteRendu.c_str()) ;
}

//---------------------------------------------------------------------------
//  Description : Constructeur copie
//---------------------------------------------------------------------------
NSCRDocument::NSCRDocument(NSCRDocument& rv)
			 			:NSRefDocument(rv)
{
try
{
	EstDecode  = rv.EstDecode ;
  sFichDecod = rv.sFichDecod ;

	if (rv.pBigBoss)
		pBigBoss = new NSSmallBrother(*(rv.pBigBoss)) ;
	else
    pBigBoss = 0 ;

	strcpy(lexiqueModule, rv.lexiqueModule) ;
	aCRPhrases = rv.aCRPhrases ;
}
catch (...)
{
  erreur("Exception NSCRDocument ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  Description : Destructeur
//---------------------------------------------------------------------------
NSCRDocument::~NSCRDocument()
{
  // Destruction du fichier temporaire
  if (sFichDecod != "")
  {
    if (!DeleteFile(sFichDecod.c_str()))
      erreur("Erreur � la destruction du fichier temporaire du document.", standardError, 0, pContexte->GetMainWindow()->GetHandle());
  }

  // La Fiche Historique est pr�venue par NSRefDocument
  // Le delete sur pPatPathoArray et sur pBigBoss est fait par NSRefDocument
}

//---------------------------------------------------------------------------//  Description : Operateur =
//---------------------------------------------------------------------------
NSCRDocument&
NSCRDocument::operator=(NSCRDocument& src)
{
try
{
	if (this == &src)
		return *this ;

	NSRefDocument *dest, *source ;
	// Appel de l'operateur = de NSRefDocument
	// (recopie des arguments de la classe NSRefDocument)
	dest = this ;
	source = &src ;
	*dest = *source ;

	EstDecode  = src.EstDecode ;
	sFichDecod = src.sFichDecod ;

	if (src.pBigBoss)
  	pBigBoss = new NSSmallBrother(*(src.pBigBoss)) ;
	else
		pBigBoss = 0 ;

	strcpy(lexiqueModule, src.lexiqueModule) ;
	aCRPhrases = src.aCRPhrases ;

	//	*paLesions 	 = *(src.paLesions);
	//	*paVariables = *(src.paVariables);

	return *this ;
}
catch (...)
{
	erreur("Exception NSCRDocument (= operator).", standardError, 0) ;
	return *this ;
}
}

//---------------------------------------------------------------------------//  Ouvre le document en mettant le CR dans pPatPathoArray
//---------------------------------------------------------------------------
bool
NSCRDocument::Open(int mode, const char far* path)
{
	if (!pDocInfo)
		return true ;

	return bDocumentValide ;
}

//---------------------------------------------------------------------------
//  Function: NSCRDocument::GenereHtml(string sPathHtml, string& sNomHtml, string sAdresseCorresp)
//
//  Arguments:
//				  sPathHtml : 	r�pertoire destination
//				  sNomHtml :   En entr�e -> nom du fichier � g�n�rer
//									En sortie -> nom sans doublons
//				  sAdresseCorresp : nom + adresse du correspondant
//  Description:
//				  G�n�re un fichier html CR dans le r�pertoire sPathName
//				  Utilise les donn�es sTemplate et sBaseImages
//  Returns:
//            true : OK, false : sinon
//---------------------------------------------------------------------------
bool
NSCRDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	string   sFichierHtml ;
	NSHtmlCR hcr(typeOperation, this, pContexte, sAdresseCorresp) ;
	string   sBaseImg ;
	// NSBaseImages* pBase ;

	// on trouve le nom du fichier temporaire � visualiser
	sNomHtml = hcr.nomSansDoublons(sPathHtml, sNomHtml, "htm") ;
	sFichierHtml = sPathHtml + sNomHtml ;

  NSDocumentInfo* pComposInfo = pHtmlInfo ;
  if (NULL == pComposInfo)
  	pComposInfo = pDocInfo ;

	// on passe aussi le path destination pour les images
	if (!hcr.genereHtml(sFichierHtml, sBaseImg, pComposInfo, sPathDest))
  	return false ;

	// Mise � jour de la base d'images
	switch (typeOperation)
	{
  	case toComposer:
    	sBaseCompo = sBaseImg ;
      break ;

    default:
    	sBaseImages = sBaseImg ;
	}

	return true ;
}

//---------------------------------------------------------------------------//  Function: NSCRDocument::decodeCR(NSCRPhraseArray *pPhrases)
//
//  Arguments:
//
//  Description:
//			  Choisi un nom pour le fichier de d�codage s'il n'existe pas d�j�
//            D�code le compte rendu en langage naturel
//  Returns:
//            Rien
//---------------------------------------------------------------------------
int
NSCRDocument::decodeCR(NSCRPhraseArray *pPhrases)
{
try
{
	int Reussi ;
	TModule* pDCModule = 0 ;
	string sNomFichierDecode ;
	string sLocFichierDecode ;
	bool (FAR *pAdresseFct) (char, NSPatPathoArray far *, char far *,
                             NSContexte far *, NSCRPhraseArray far *,
                             NSDocumentData far *);

	if (getPatPatho()->empty())
  	return iErreur ;

  // On choisi un nom pour le fichier de d�codage (s'il n'existe pas)
	if (sFichDecod == "")
  {
  	if (!TrouveNomFichier("ZCN00","tmp",sNomFichierDecode,sLocFichierDecode))
    {
    	erreur("Erreur � l'attribution du nom du fichier temporaire.", standardError, 0, pContexte->GetMainWindow()->GetHandle());
      return iErreur ;
    }

    sFichDecod = pContexte->PathName(sLocFichierDecode) + sNomFichierDecode ;
  }
  //
  // Le premier �l�ment du PatPathoArray donne le type d'examen
  //
  PatPathoIter iJ = getPatPatho()->begin();
  // On prend l'�l�ment
  string sCodeLex = (*iJ)->pDonnees->lexique;
  // Puis son code utile
  string sCodeUtile = "";
  pContexte->getDico()->donneCodeSens(&sCodeLex, &sCodeUtile);

  //
  // Lancement du d�codeur en fonction du code
  //
  pContexte->getSuperviseur()->afficheStatusMessage("Chargement du d�codeur");

	if ((sCodeUtile == "GECHY") || (sCodeUtile == "GECHZ") ||
      (sCodeUtile == "GECHN") || (sCodeUtile == "GECHX") ||
      (sCodeUtile == "GECHR") || (sCodeUtile == "GECHL") ||
      (sCodeUtile == "GECHF"))
	{
    pDCModule = new TModule("NSMDKE.DLL", TRUE);
    if (!pDCModule)
    {
    	erreur("La DLL NSDKE.DLL est introuvable.", standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
      pContexte->getSuperviseur()->afficheStatusMessage("") ;
      return iErreur ;
    }
	}
  else if ((string("GDUOB") == sCodeUtile) ||
           (string("GENTG") == sCodeUtile))
  {
    pDCModule = new TModule("NSMDGG.DLL", TRUE) ;
    if (!pDCModule)
    {
    	erreur("La DLL NSDGG.DLL est introuvable.", standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
      pContexte->getSuperviseur()->afficheStatusMessage("") ;
      return iErreur ;
    }
  }
  else if ((string("GCOLL") == sCodeUtile) ||
           (string("GRECX") == sCodeUtile) ||
           (string("GENTF") == sCodeUtile))
  {
    pDCModule = new TModule("NSMDGC.DLL", TRUE);
    if (!pDCModule)
    {
    	erreur("La DLL NSDGC.DLL est introuvable.", standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
      pContexte->getSuperviseur()->afficheStatusMessage("") ;
      return iErreur ;
    }
	}
  else if (sCodeUtile == "GECHA")
  {
  	pDCModule = new TModule("NSMDEA.DLL", TRUE) ;
    if (!pDCModule)
    {
    	erreur("La DLL NSDEA.DLL est introuvable.", standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
      pContexte->getSuperviseur()->afficheStatusMessage("") ;
      return iErreur ;
    }
  }
  else if (sCodeUtile == "GEDOP")
  {
  	pDCModule = new TModule("NSMDKDV.DLL", TRUE) ;
    if (!pDCModule)
    {
    	erreur("La DLL NSDKDV.DLL est introuvable.", standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
      pContexte->getSuperviseur()->afficheStatusMessage("") ;
      return iErreur ;
    }
  }
  else if (sCodeUtile == "GEFFO")
	{
  	pDCModule = new TModule("NSMDKF.DLL", TRUE) ;
    if (!pDCModule)
    {
    	erreur("La DLL NSDKF.DLL est introuvable.", standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
      pContexte->getSuperviseur()->afficheStatusMessage("") ;
      return iErreur ;
    }
	}
  else if (sCodeUtile == "GHOLT")  {
  	pDCModule = new TModule("NSMDKH.DLL", TRUE) ;
    if (!pDCModule)
    {
    	erreur("La DLL NSDKH.DLL est introuvable.", standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
      pContexte->getSuperviseur()->afficheStatusMessage("") ;
      return iErreur ;
    }
  }
  else if (sCodeUtile == "ZORDO")
  {
  	pDCModule = new TModule("NSMDZZ.DLL", TRUE) ;
    if (!pDCModule)
    {
    	erreur("La DLL NSDZZ.DLL est introuvable.", standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
      pContexte->getSuperviseur()->afficheStatusMessage("") ;
      return iErreur ;
    }
  }
  else
  {
  	pContexte->getSuperviseur()->afficheStatusMessage("") ;
    return iErreur ;
  }

	(FARPROC) pAdresseFct = pDCModule->GetProcAddress(MAKEINTRESOURCE(1)) ;
	if (pAdresseFct == NULL)
  	Reussi = iErreur ;
	else
	{
  	NSDocumentData* pDocData ;
    if ((pDocInfo) && (pDocInfo->getData()))
    	pDocData = pDocInfo->getData() ;
    else
    	pDocData = 0 ;

    pContexte->getSuperviseur()->afficheStatusMessage("Elaboration du compte rendu") ;

    // La fonction de d�codage renvoie 0 (iOk) si le d�codage a r�ussi
    Reussi = ((*pAdresseFct)
                    (' ',
                    (NSPatPathoArray far *) getPatPatho(),
                    (char far *) sFichDecod.c_str(),
                    (NSContexte far *) pContexte,
                    (NSCRPhraseArray far *) pPhrases,
                    (NSDocumentData far *) pDocData
                    )
                 );
	}

	delete pDCModule ;
	pDCModule = 0 ;

	// EstDecode est vrai si Reussi == 0
	EstDecode = !Reussi ;

	pContexte->getSuperviseur()->afficheStatusMessage("") ;

	return Reussi ;
}
catch (...)
{
	erreur("Exception NSCRDocument::decodeCR.", standardError, 0) ;
	return false ;
}
}

//---------------------------------------------------------------------------//  Enregistre le compte rendu
//---------------------------------------------------------------------------
bool
NSCRDocument::enregistre()
{
try
{
	bool existeInfo ;

	if (bEnregEnCours)
		return false ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	string sLang = "" ;
	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;

	bEnregEnCours = true ;

	pSuper->afficheStatusMessage("D�but d'enregistrement") ;

	//
	// Si c'est un nouveau compte rendu on le cr�e en tant que document
	//
	bool bNewDoc ;
	if (pDocInfo == 0)
		bNewDoc = true ;
	else
		bNewDoc = false ;

	if (bNewDoc)
	{
		string sLibelleDoc = "" ;
		if (!pPatPathoArray->empty())
		{
			string sCode = (*(pPatPathoArray->begin()))->pDonnees->lexique ;
			if (sCode != "")
				pContexte->getDico()->donneLibelle(sLang, &sCode, &sLibelleDoc) ;
		}
		existeInfo = Referencer("ZCN00", sLibelleDoc) ;
		if (!existeInfo)
		{
			bEnregEnCours = false ;
			return existeInfo ;
		}
	}
	//
	// On enregistre la patpatho
	//
	string ps = string("Enregistrement patpatho CR n� ") +
                pDocInfo->getID() + string("\n") ;
	pSuper->trace(&ps, 1) ;

	existeInfo = enregistrePatPatho() ;

  // The new document must be inserted in "history" before checking if it resets
  // any goal, because this document's date will be asked to "history"

  //
	// On pr�vient l'historique
	//
	ps = "Rafraichissement historique\n" ;
	pSuper->trace(&ps, 1) ;

	pContexte->getPatient()->pDocHis->Rafraichir(pDocInfo, pPatPathoArray, this) ;

	//
	// Si c'est un nouveau compte rendu on v�rifie s'il remet � z�ro un objectif
	//
	if ((bNewDoc) && (pContexte->getPatient()->pDocLdv))
		pContexte->getPatient()->pDocLdv->showNewTree(pPatPathoArray, GetDateDoc(false)) ;

	ps = "Document enregistr�.\n" ;
	pSuper->trace(&ps, 1) ;
	pSuper->afficheStatusMessage("Document enregistr�") ;

	//
	// Fonction d'exportation pour les comptes rendus
	//
	if (pSuper->getExportDll() != "")
	{
		pSuper->afficheStatusMessage("Exportation") ;

		TModule* pDCModule = new TModule(pSuper->getExportDll().c_str(), TRUE) ;
		if (NULL == pDCModule)
		{
			string sErreur = "Impossible d'ouvrir la DLL d'exportation : " + pSuper->getExportDll() ;
			erreur(sErreur.c_str(), standardError, -1, pContexte->GetMainWindow()->GetHandle()) ;
			pContexte->getSuperviseur()->afficheStatusMessage("") ;
      bEnregEnCours = false ;
			return false ;
		}

    //
    // Is it necessary to export the report as a file ?
    //
    string sExportedFileName = "" ;

		bool (FAR *pAdrFctNeedFile) (NSContexte far *, NSCRDocument far *, string far *, string far *) ;
    (FARPROC) pAdrFctNeedFile = pDCModule->GetProcAddress(MAKEINTRESOURCE(2)) ;
		if (NULL != pAdrFctNeedFile)
		{
    	string sFileName = "" ;
      string sFileType = "" ;
			bool bNeedFile = ((*pAdrFctNeedFile)((NSContexte far *) pContexte,
                                                (NSCRDocument far *) this,
                                                (string far *) &sFileName,
                                                (string far *) &sFileType )) ;
      if (bNeedFile)
      {
      	bool bExported = exportFile(sFileName, sFileType) ;
        if (bExported)
        	sExportedFileName = sFileName ;
      }
    }

    	//string sCivilite = pContexte->getPatient()->pDonnees->sCivilite;

		bool (FAR *pAdresseFct) (NSContexte far *, NSCRDocument far *, string far *) ;
		(FARPROC) pAdresseFct = pDCModule->GetProcAddress(MAKEINTRESOURCE(1)) ;
		if (NULL == pAdresseFct)
		{
			delete pDCModule ;
      bEnregEnCours = false ;
			return false ;
		}

		/* bool bReussi = */ ((*pAdresseFct)((NSContexte far *) pContexte,
                                                (NSCRDocument far *) this,
                                                (string far *) &sExportedFileName)) ;

		delete pDCModule ;
	}

	bEnregEnCours = false ;

	return existeInfo ;
}
catch (...)
{
	erreur("Exception NSCRDocument::enregistre", standardError, 0) ;
  return false ;
}
}

