// -----------------------------------------------------------------------------// nsgoalview.cpp
// Vue Document/Vues de gestion des objectifs Doc/View View for goal management
// -----------------------------------------------------------------------------
// FLP - Janvier/F�vrier 2004
// PA  - Juillet 2003
// -----------------------------------------------------------------------------

#if !defined(OWL_LISTWIND_H)
# include <owl/listwind.h>
#endif

#include <owl/uihelper.h>
#include <owl\owlpch.h>
#include <owl\validate.h>
#include <owl\inputdia.h>

#include "nautilus\nssuper.h"#include "partage\nsdivfct.h"
#include "nautilus\nsldvdoc.h"
#include "nautilus\nsldvvar.h"
#include "nautilus\nsldvgoal.h"
#include "nautilus\nsgoalview.h"
#include "nautilus\nautilus.rh"
#include "nsbb\nspanesplitter.h"
#include "nsbb\nsattvaltools.h"
#include "nautilus\nsldvvue.rh"
#include "nsepisod\objectif_viewer.h"
#include "nsbb\nsbbsmal.h"

bool
goalSortByNameInf(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->name < pObj2->name) ;
}

bool
goalSortByNameSup(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->name > pObj2->name) ;
}

bool
goalSortByLevelInf(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
  return (pObj1->iLevel < pObj2->iLevel) ;
}

bool
goalSortByLevelSup(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
  return (pObj1->iLevel > pObj2->iLevel) ;
}

bool
goalSortByRythmeInf(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->iRythme < pObj2->iRythme) ;
}

bool
goalSortByRythmeSup(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj2->iRythme > pObj1->iRythme) ;
}

bool
goalSortByAutoriseInf(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->dateAuto < pObj2->dateAuto) ;
}

bool
goalSortByAutoriseSup(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->dateAuto > pObj2->dateAuto) ;
}

bool
goalSortByConseilleInf(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->dateCons < pObj2->dateCons) ;
}

bool
goalSortByConseilleSup(NSObjectif *pObj1, NSObjectif *pObj2)
{
    if (!pObj1 || !pObj2)
        return false ;
	return (pObj1->dateCons > pObj2->dateCons) ;
}

bool
goalSortByIdealInf(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->dateIdeal < pObj2->dateIdeal) ;
}

bool
goalSortByIdealSup(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->dateIdeal > pObj2->dateIdeal) ;
}

bool
goalSortByIdealMaxInf(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->dateIdealMax < pObj2->dateIdealMax) ;
}

bool
goalSortByIdealMaxSup(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->dateIdealMax > pObj2->dateIdealMax) ;
}

bool
goalSortByConseilleMaxInf(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->dateConsMax < pObj2->dateConsMax) ;
}

bool
goalSortByConseilleMaxSup(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->dateConsMax > pObj2->dateConsMax) ;
}

bool
goalSortByCriticalInf(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->dateCrit < pObj2->dateCrit) ;
}

bool
goalSortByCriticalSup(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->dateCrit > pObj2->dateCrit) ;
}

bool
goalSortByPreviousInf(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->datePrec < pObj2->datePrec) ;
}

bool
goalSortByPreviousSup(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->datePrec > pObj2->datePrec) ;
}

bool
goalSortByPrevValueInf(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->sValue < pObj2->sValue) ;
}

bool
goalSortByPrevValueSup(NSObjectif *pObj1, NSObjectif *pObj2)
{
  if (!pObj1 || !pObj2)
    return false ;
	return (pObj1->sValue > pObj2->sValue) ;
}

// -----------------------------------------------------------------------------
//
// Class NSGoalView
//
// -----------------------------------------------------------------------------

const int ID_GoalList = 0x100 ;
// Table de r�ponses de la classe NSEpisodView

DEFINE_RESPONSE_TABLE1(NSGoalView, NSMUEView)
  EV_VN_ISWINDOW,
  // EV_LVN_GETDISPINFO(ID_GoalList, DispInfoListe),
  EV_LVN_COLUMNCLICK(ID_GoalList, LVNColumnclick),
  EV_WM_SIZE,
  EV_WM_SETFOCUS,
  EV_COMMAND(CM_REFERENTIAL, CmFct3),
  EV_COMMAND(CM_GOAL_NEW,    CmNouveau),
  EV_COMMAND(CM_GOAL_CHANGE, CmModifier),
  EV_COMMAND(CM_GOAL_TRAIT,  CmTraitSelectedObj),
  EV_COMMAND(CM_GOAL_STOP,   CmClore),
END_RESPONSE_TABLE ;


// Constructeur
NSGoalView::NSGoalView(NSLdvDocument &doc, string sConcern)
  : NSLDVView(doc.pContexte, &doc, 0, string("GoalManagement"), string("LdvDoc"), sConcern)
{
try
{
  pLdVDoc = &doc ;
  pListeWindow = new NSGoalsPropertyWindow(this, ID_GoalList, 0, 0, 0, 0) ;

  iSortedColumn = 1 ;
  bNaturallySorted = true ; // in order to have it naturally sorted

	initMUEViewMenu("menubar_goal") ;

  pToolBar = 0 ;
  bSetupToolBar = true ;

  sViewConcern = sConcern ;

  initCurrentGoals() ;

  setViewName() ;
}
catch (...)
{
  erreur("Exception NSGoalView ctor.", standardError, 0) ;
}
}


// Destructeur
NSGoalView::~NSGoalView()
{
}

void
NSGoalView::setViewName()
{
	sViewName = pContexte->getSuperviseur()->getText("goalsManagement", "goalViewTitle") ;

  addConcernTitle() ;
}

void
NSGoalView::CmNouveau()
{
  NSLdvGoal ldvGoal(pLdVDoc->pContexte) ;
  ObjectifViewerDlg* objDlg = new ObjectifViewerDlg((TWindow*)this, pLdVDoc->pContexte, true, &ldvGoal) ;
  objDlg->Execute() ;
  delete objDlg ;

  NSPatPathoArray pathArray(pLdVDoc->pContexte) ;
	ldvGoal.setGoalPatho(&pathArray) ;

  if (true == pathArray.empty())
    return ;

  pContexte->getPatient()->CreeObjectif(&pathArray, "", "", "", NULL, "") ;

	initCurrentGoals() ;
	AfficheListe() ;
}

void
NSGoalView::CmModifier()
{
	//  NSPatPathoArray* pPathArray = new NSPatPathoArray(pLdVDoc->pContexte);
	int index = pListeWindow->IndexItemSelect() ;

	if (index < 0)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("goalsManagement", "MustSelectGoal") ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return ;
	}
    //NSObjectif* objMod = aGoals[index];

	string sGoalNode = (aGoals[index])->node ;
	ArrayGoals      *pGoals = pLdVDoc->getGoals() ;
	NSLdvGoal       *pLdvGoal = pGoals->getGoal(sGoalNode) ;
	NSLdvGoal* pNewCopy = new NSLdvGoal(*pLdvGoal) ;
	ObjectifViewerDlg* objDlg = new ObjectifViewerDlg((TWindow*)this, pLdVDoc->pContexte, false, pNewCopy);
	objDlg->Execute();
	delete objDlg ;

	//if unchanged goal -> exit
	if(pLdvGoal->estIdentique(pNewCopy))
		return ;

	NSPatPathoArray* pPathArray = new NSPatPathoArray(pNewCopy->pContexte) ;
	pNewCopy->setGoalPatho(pPathArray) ;

	//ferme ancien objectif
	if (!pPathArray)
		return ;

	pLdVDoc->closeGoal(pLdvGoal, NULL) ;

	//creer nouveau objectif
	pContexte->getPatient()->CreeObjectif(pPathArray, "", "", "", NULL, pNewCopy->sReference) ;

	delete pPathArray ;

	initCurrentGoals() ;
	AfficheListe() ;
}

void
NSGoalView::CmClore()
{
try
{
	if (!(pContexte->userHasPrivilege(NSContexte::modifyGoal, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

	int index = pListeWindow->IndexItemSelect() ;

	if (index < 0 /* == -1 */)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("goalsManagement", "StopMustSelect") ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return ;
	}

	NSPatPathoArray StopReason(pContexte) ;

# ifdef __OB1__
	NSSmallBrother *pBigBoss = new NSSmallBrother(pContexte, &StopReason, 0) ;
#else
	NSSmallBrother *pBigBoss = new NSSmallBrother(pContexte, &StopReason, 0, true) ;
#endif

	pBigBoss->pFenetreMere = this ;
#ifdef _MUE
	string sArchID = string("admin.goal.close.1.0") ;
# ifdef __OB1__
	BB1BBInterfaceForKs InterfaceForKs(-1, sArchID, "", false) ;
	/* NSDialog *pClientWin = */ pBigBoss->lanceBbkArchetypeInDialog(sArchID, 0, 0, &InterfaceForKs, true /*modal*/) ;
# else
	/* NSDialog *pClientWin = */ pBigBoss->lanceBbkArchetype(sArchID, 0, 0, true /*modal*/) ;
# endif
#else
	/* NSDialog *pClientWin = */ pBigBoss->lanceBbkArchetype("sfmg.dpio.test.fermeture.1.0", 0, 0, true /*modal*/) ;
#endif
	delete pBigBoss ;

	if (StopReason.empty())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("goalsManagement", "StopNeedReason") ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return ;
	}

	string sGoalNode = (aGoals[index])->node ;

	ArrayGoals *pGoals   = pLdVDoc->getGoals() ;
	NSLdvGoal  *pLdvGoal = pGoals->getGoal(sGoalNode) ;
	if (pLdvGoal == NULL)
		return ;

	pLdVDoc->closeGoal(pLdvGoal, &StopReason) ;

	initCurrentGoals() ;
	AfficheListe() ;

	return ;
}
catch (...)
{
	erreur("Exception NSGoalView::CmArreter.", standardError, 0) ;
}
}

void
NSGoalView::CmFct3()
{
	VecteurString RelatedConcerns ;
  if (sPreoccup != string(""))
  	RelatedConcerns.push_back(new string(sPreoccup)) ;

	pLdVDoc->GoalFromProtocolService(this, &RelatedConcerns) ;
}

void
NSGoalView::CmFct4()
{
}

// GetWindow renvoie this (� red�finir car virtual dans TView)
TWindow
*NSGoalView::GetWindow()
{
  return (TWindow *) this ;
}


// Appel de la fonction de remplissage de la vuevoid
NSGoalView::SetupWindow()
{
	NSMUEView::SetupWindow() ;

	Parent->SetCaption(sViewName.c_str()) ;

	SetupColumns() ;
	AfficheListe() ;

	// we want to have a list sorted by severity at the first opening
	// sortByColumn(1) ;
}

// -----------------------------------------------------------------------------
// Initialisation des colonnes de la ListWindow
// -----------------------------------------------------------------------------
void
NSGoalView::SetupColumns()
{
	string sNameOb0 = pContexte->getSuperviseur()->getText("goalsManagement", "colGoalName") ;
  string sNameOb1 = pContexte->getSuperviseur()->getText("goalsManagement", "colGoalColor") ;
  string sNameOb2 = pContexte->getSuperviseur()->getText("goalsManagement", "colGoalRythme") ;
  string sNameOb3 = pContexte->getSuperviseur()->getText("goalsManagement", "colGoalPermited") ;
  string sNameOb4 = pContexte->getSuperviseur()->getText("goalsManagement", "colGoalAdvised") ;
  string sNameOb5 = pContexte->getSuperviseur()->getText("goalsManagement", "colGoalPerfect") ;
  string sNameOb6 = pContexte->getSuperviseur()->getText("goalsManagement", "colGoalPerfectMax") ;
  string sNameOb7 = pContexte->getSuperviseur()->getText("goalsManagement", "colGoalAdvisedMax") ;
  string sNameOb8 = pContexte->getSuperviseur()->getText("goalsManagement", "colGoalCritical") ;
  string sNameOb9 = pContexte->getSuperviseur()->getText("goalsManagement", "colGoalPrevious") ;
  string sNameObA = pContexte->getSuperviseur()->getText("goalsManagement", "colGoalPrevValue") ;

  pListeWindow->InsertColumn( 0,  TListWindColumn((char*)sNameOb0.c_str(), 150, TListWindColumn::Left,    0)) ;
  pListeWindow->InsertColumn( 1,  TListWindColumn((char*)sNameOb1.c_str(),  20, TListWindColumn::Center,  1)) ;
  pListeWindow->InsertColumn( 2,  TListWindColumn((char*)sNameOb2.c_str(),  65, TListWindColumn::Left,    2)) ;
  pListeWindow->InsertColumn( 3,  TListWindColumn((char*)sNameOb3.c_str(),  75, TListWindColumn::Left,    3)) ;
  pListeWindow->InsertColumn( 4,  TListWindColumn((char*)sNameOb4.c_str(),  75, TListWindColumn::Left,    4)) ;
  pListeWindow->InsertColumn( 5,  TListWindColumn((char*)sNameOb5.c_str(),  75, TListWindColumn::Left,    5)) ;
  pListeWindow->InsertColumn( 6,  TListWindColumn((char*)sNameOb6.c_str(),  75, TListWindColumn::Left,    6)) ;
  pListeWindow->InsertColumn( 7,  TListWindColumn((char*)sNameOb7.c_str(),  75, TListWindColumn::Left,    7)) ;
  pListeWindow->InsertColumn( 8,  TListWindColumn((char*)sNameOb8.c_str(),  75, TListWindColumn::Left,    8)) ;
  pListeWindow->InsertColumn( 9,  TListWindColumn((char*)sNameOb9.c_str(),  75, TListWindColumn::Left,    9)) ;
  pListeWindow->InsertColumn(10,  TListWindColumn((char*)sNameObA.c_str(),  75, TListWindColumn::Right,  10)) ;
}

void
NSGoalView::initCurrentGoals()
{
try
{
	aGoals.vider() ;

  ArrayGoals  *pLdvGoals = pLdVDoc->getGoals() ;
  if (pLdvGoals->empty())
  	return ;

  for (ArrayGoalIter j = pLdvGoals->begin(); j != pLdvGoals->end(); j++)
  {
  	NSObjectif  *pObj = new NSObjectif ;

    if (InitObjectif(pObj, *j))
    {
    	aGoals.push_back(pObj) ;
      //(*j)->selectObjectif();
    }
    else
    	delete pObj ;
	}
  sortByColumn(iSortedColumn) ;
}
catch (...)
{
	erreur("Exception NSGoalView::initCurrentGoals.", standardError, 0) ;
}
}

void
NSGoalView::CmTraitSelectedObj()
{
	pLdVDoc->traiteSelectedObjectifs(sViewConcern);

}

bool
NSGoalView::SelectedObjectifs()
{
	ArrayGoals  *pLdvGoals = pLdVDoc->getGoals() ;
  if (pLdvGoals->empty())
  	return false ;

  int count = pListeWindow->GetItemCount() ;
  bool selectionFound = false ;

  //on reinitialise les selections
  for(ArrayGoalIter iter = pLdvGoals->begin(); iter != pLdvGoals->end(); iter++)
  	(*iter)->unselectObjectif() ;

  for (int i = 0 ; i < count ; i++)  {
    if (pListeWindow->GetItemState(i, LVIS_SELECTED))
    {
      ArrayGoalIter iter = pLdvGoals->begin() ;
      bool found = false ;
      while ((iter != pLdvGoals->end()) && (!found))
      {
      	if ((*iter)->estIdentique(aGoals[i]->pCorrespGoal))
        {
        	selectionFound = true ;
          found = true ;
          (*iter)->selectObjectif() ;
        }
        /* else
        	(*iter)->unselectObjectif(); */
        iter++;
      }
    }
  }
  return selectionFound ;
}
bool
NSGoalView::InitObjectif(NSObjectif *pObj, NSLdvGoal *pGoal){	if (!pObj || !pGoal)		return false ;  // Si on cherche les objectifs d'une pr�occupation pr�cise, on v�rifie  // que cet objectif est concern�  if ((sPreoccup != "") && (sPreoccup != pGoal->sConcern))    return false ;	pObj->pCorrespGoal = pGoal ;  // cas d'un objectif futur non pr�visible  if (pGoal->tOuvertLe.estVide())    return false ;  NVLdVTemps tToday ;  tToday.takeTime() ;  // cas d'un objectif d�j� ferm�  if ((!(pGoal->tFermeLe.estVide())) && (pGoal->tFermeLe <= tToday))    return false ;  bool IsOpened = (tToday >= pGoal->tOuvertLe) ;	if (pGoal->sComplementText != "")		pObj->name    = pGoal->sComplementText ;	else		pObj->name    = pGoal->sTitre ;  pObj->node    = pGoal->getNoeud() ;  // le titre dans Goal est en clair (pas de code lexique)  pObj->code    = "" ;  pObj->sValue  = "" ;  pObj->iLevel  = 0 ;  pObj->iRythme = pGoal->iRythme ;  // Note : un objectif cyclique non ouvert (futur) se comporte comme  // un objectif ponctuel  if      ((pGoal->iRythme == NSLdvGoal::ponctuel) || (!IsOpened))  {    InitDateObjectifPonctuel(pObj->dateAuto,      pGoal, pGoal->sDateDebutAutorise,   pGoal->dDelaiDebutAutorise,   pGoal->sUniteDebutAutorise) ;    InitDateObjectifPonctuel(pObj->dateCons,      pGoal, pGoal->sDateDebutConseille,  pGoal->dDelaiDebutConseille,  pGoal->sUniteDebutConseille) ;    InitDateObjectifPonctuel(pObj->dateIdeal,     pGoal, pGoal->sDateDebutIdeal,      pGoal->dDelaiDebutIdeal,      pGoal->sUniteDebutIdeal) ;    InitDateObjectifPonctuel(pObj->dateIdealMax,  pGoal, pGoal->sDateDebutIdealMax,   pGoal->dDelaiDebutIdealMax,   pGoal->sUniteDebutIdealMax) ;    InitDateObjectifPonctuel(pObj->dateConsMax,   pGoal, pGoal->sDateDebutConseilMax, pGoal->dDelaiDebutConseilMax, pGoal->sUniteDebutConseilMax) ;    InitDateObjectifPonctuel(pObj->dateCrit,      pGoal, pGoal->sDateDebutCritique,   pGoal->dDelaiDebutCritique,   pGoal->sUniteDebutCritique) ;    string sDateOuvert = pGoal->tOuvertLe.donneDate() ;    if      ((pGoal->sDateDebutCritique    != "")  && (pGoal->sDateDebutCritique    <= sDateOuvert))      pObj->iLevel = NSLdvGoalInfo::AProuge ;
    else if ((pGoal->sDateDebutConseilMax  != "")  && (pGoal->sDateDebutConseilMax  <= sDateOuvert))
      pObj->iLevel = NSLdvGoalInfo::APjaune ;
    else if ((pGoal->sDateDebutIdealMax    != "")  && (pGoal->sDateDebutIdealMax    <= sDateOuvert))
      pObj->iLevel = NSLdvGoalInfo::APvert ;
    else if ((pGoal->sDateDebutIdeal       != "")  && (pGoal->sDateDebutIdeal       <= sDateOuvert))
      pObj->iLevel = NSLdvGoalInfo::Bleu ;
    else if ((pGoal->sDateDebutConseille   != "")  && (pGoal->sDateDebutConseille   <= sDateOuvert))
      pObj->iLevel = NSLdvGoalInfo::AVvert ;
    else if ((pGoal->sDateDebutAutorise    != "")  && (pGoal->sDateDebutAutorise    <= sDateOuvert))
      pObj->iLevel = NSLdvGoalInfo::AVjaune ;
    else
      pObj->iLevel = NSLdvGoalInfo::AVrouge ;
  }
  else if (pGoal->iRythme == NSLdvGoal::cyclic)  {    // -------------------------------------------------------------------------    // cas des objectifs cycliques d�j� ouverts et non d�j� ferm�s    // case in which cyclic goals are open but not yet closed    bool  bContinue = true ;    bool  bNow      = false ;    for (GoalInfoRIter i = pGoal->pMetaJalons->rbegin() ; i != pGoal->pMetaJalons->rend() ; i++)    {      if (!bContinue && bNow)        break ;      if (((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonNow) && !bNow)      {        pObj->iLevel          = (*i)->iLevel ;        bNow                  = true ;      }      if (((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonIntermediaire) && bContinue)      {        if      ((*i)->iTimeLevel == NSLdvGoalInfo::AProuge)          pObj->dateCrit      = (*i)->tpsInfo.donneDate() ;        else if ((*i)->iTimeLevel == NSLdvGoalInfo::APjaune)          pObj->dateConsMax   = (*i)->tpsInfo.donneDate() ;        else if ((*i)->iTimeLevel == NSLdvGoalInfo::APvert)          pObj->dateIdealMax  = (*i)->tpsInfo.donneDate() ;        else if ((*i)->iTimeLevel == NSLdvGoalInfo::Bleu)          pObj->dateIdeal     = (*i)->tpsInfo.donneDate() ;        else if ((*i)->iTimeLevel == NSLdvGoalInfo::AVvert)          pObj->dateCons      = (*i)->tpsInfo.donneDate() ;        else if ((*i)->iTimeLevel == NSLdvGoalInfo::AVjaune)          pObj->dateAuto      = (*i)->tpsInfo.donneDate() ;      }      else if ((((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonCycle) || ((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonOuvreCycle)) && bContinue)      {        pObj->datePrec  = (*i)->tpsInfo.donneDate() ;        if ((*i)->getValue() != "")        {          char    szValue[256] ;          string  sLabelUnit ;          string  sCodeUnit = (*i)->sUnit + '1' ;          pContexte->getDico()->donneLibelle(pContexte->getUtilisateur()->donneLang(), &sCodeUnit, &sLabelUnit) ;          sprintf(szValue, "%s %s", (*i)->sValue.c_str(), sLabelUnit.c_str()) ;          pObj->sValue    = string(szValue) ;        }        bContinue = false ;      }      else if ((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonOuverture)        bContinue = false ;    }  }  else if (pGoal->iRythme == NSLdvGoal::permanent)  {    // -------------------------------------------------------------------------    // cas des objectifs permanents d�j� ouverts et non d�j� ferm�s    // case in which permanent goals are open but not yet closed    bool  bContinue = true ;    bool  bNow      = false ;    for (GoalInfoRIter i = pGoal->pMetaJalons->rbegin() ; i != pGoal->pMetaJalons->rend() ; i++)    {      if (!bContinue && bNow)        break ;      if (((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonNow) && !bNow)      {        pObj->iLevel          = (*i)->iLevel ;        bNow                  = true ;      }      if (((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonIntermediaire) && bContinue)      {        if      ((*i)->iTimeLevel == NSLdvGoalInfo::AProuge)          pObj->dateCrit      = (*i)->tpsInfo.donneDate() ;        else if ((*i)->iTimeLevel == NSLdvGoalInfo::APjaune)          pObj->dateConsMax   = (*i)->tpsInfo.donneDate() ;        else if ((*i)->iTimeLevel == NSLdvGoalInfo::APvert)          pObj->dateIdealMax  = (*i)->tpsInfo.donneDate() ;        else if ((*i)->iTimeLevel == NSLdvGoalInfo::Bleu)          pObj->dateIdeal     = (*i)->tpsInfo.donneDate() ;        else if ((*i)->iTimeLevel == NSLdvGoalInfo::AVvert)          pObj->dateCons      = (*i)->tpsInfo.donneDate() ;        else if ((*i)->iTimeLevel == NSLdvGoalInfo::AVjaune)          pObj->dateAuto      = (*i)->tpsInfo.donneDate() ;      }      else if ((((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonCycle) || ((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonOuvreCycle)) && bContinue)        bContinue = false ;      else if ((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonOuverture)        bContinue = false ;    }  }  return true ;}voidNSGoalView::InitDateObjectifPonctuel(string& sDateObj, NSLdvGoal *pGoal, string sDateJalon, double dDelaiJalon, string sUniteJalon)
{
  NVLdVTemps tpsBuff ;
  sDateObj = "" ;

  if      (sDateJalon != "")
    sDateObj = sDateJalon ;  else if (dDelaiJalon > 0)  {    if (pGoal->sOpenEventNode == "")    {      tpsBuff.initFromDate(pGoal->tDateOuverture.donneDate()) ;      tpsBuff.ajouteTemps(int(dDelaiJalon), sUniteJalon, pContexte) ;      sDateObj = tpsBuff.donneDate() ;    }    else if (!(pGoal->tOuvertLe.estVide()))    {      tpsBuff.initFromDate(pGoal->tOuvertLe.donneDate()) ;      tpsBuff.ajouteTemps(int(dDelaiJalon), sUniteJalon, pContexte) ;      sDateObj = tpsBuff.donneDate() ;    }  }}voidNSGoalView::reloadView(string sReason){  initCurrentGoals() ;  AfficheListe() ;}// Affichage des �l�ments de la liste
void
NSGoalView::AfficheListe()
{
  pListeWindow->DeleteAllItems() ;

  if (aGoals.empty())
    return ;

  string sLang = string("") ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  // Attention : insert ins�re au dessus ; il faut inscrire les derniers en premier
  NSObjectifIter itGoal = aGoals.end() ;
  do
  {
    itGoal-- ;
    TListWindItem Item(((*itGoal)->name).c_str(), 0) ;
    switch ((*itGoal)->iLevel)
    {
        case NSLdvGoalInfo::AVrouge : Item.SetStateImage(0) ; break ;
        case NSLdvGoalInfo::AVjaune : Item.SetStateImage(1) ; break ;
        case NSLdvGoalInfo::AVvert  : Item.SetStateImage(2) ; break ;
        case NSLdvGoalInfo::Bleu    : Item.SetStateImage(3) ; break ;
        case NSLdvGoalInfo::APvert  : Item.SetStateImage(4) ; break ;
        case NSLdvGoalInfo::APjaune : Item.SetStateImage(5) ; break ;
        case NSLdvGoalInfo::AProuge : Item.SetStateImage(6) ; break ;
    }
    pListeWindow->InsertItem(Item) ;
  }
  while (itGoal != aGoals.begin()) ;

  string sCyclic = pContexte->getSuperviseur()->getText("goalsManagement", "cyclic") ;
  string sPerman = pContexte->getSuperviseur()->getText("goalsManagement", "permanent") ;
  string sOnce   = pContexte->getSuperviseur()->getText("goalsManagement", "once") ;

  int iLineIndex = 0 ;
	for (itGoal = aGoals.begin() ; itGoal != aGoals.end() ; iLineIndex++, itGoal++)
	{
    int iColIndex = 1 ;

    // State indicator

    char szState[2] ;
    strcpy(szState, "?") ;

    switch ((*itGoal)->iLevel)
    {
      case NSLdvGoalInfo::AVrouge : strcpy(szState, "r") ; break ;
      case NSLdvGoalInfo::AVjaune : strcpy(szState, "j") ; break ;
      case NSLdvGoalInfo::AVvert  : strcpy(szState, "v") ; break ;
      case NSLdvGoalInfo::Bleu    : strcpy(szState, "b") ; break ;
      case NSLdvGoalInfo::APvert  : strcpy(szState, "V") ; break ;
      case NSLdvGoalInfo::APjaune : strcpy(szState, "J") ; break ;
      case NSLdvGoalInfo::AProuge : strcpy(szState, "R") ; break ;
    }

    TListWindItem Item1(szState, iColIndex) ;
    Item1.SetIndex(iLineIndex) ;
    Item1.SetSubItem(iColIndex) ;
    pListeWindow->SetItem(Item1) ;

    iColIndex++ ;

    // Cycle type

    string sCycleType = string("") ;
    switch ((*itGoal)->iRythme)
    {
      case NSLdvGoal::cyclic    : sCycleType = sCyclic ; break ;
      case NSLdvGoal::permanent : sCycleType = sPerman ; break ;
      case NSLdvGoal::ponctuel  : sCycleType = sOnce ;   break ;
    }

    TListWindItem Item2(sCycleType.c_str(), iColIndex) ;
    Item2.SetIndex(iLineIndex) ;
    Item2.SetSubItem(iColIndex) ;
    pListeWindow->SetItem(Item2) ;

    iColIndex++ ;

    for (int iDateType = 0 ; iDateType < 7 ; iDateType++)
    {
      string sDate = string("") ;
      switch(iDateType)
      {
        case 0 : sDate = (*itGoal)->dateAuto ;     break ;
        case 1 : sDate = (*itGoal)->dateCons ;     break ;
        case 2 : sDate = (*itGoal)->dateIdeal ;    break ;
        case 3 : sDate = (*itGoal)->dateIdealMax ; break ;
        case 4 : sDate = (*itGoal)->dateConsMax ;  break ;
        case 5 : sDate = (*itGoal)->dateCrit ;     break ;
        case 6 : sDate = (*itGoal)->datePrec ;     break ;
      }

      char buffer[255] ;
      if ((string("") != sDate) && (strlen(sDate.c_str()) < 20))
      {
        char szDate[20] ;
        strcpy(szDate, sDate.c_str()) ;
        donne_date(szDate, buffer, sLang) ;
      }
      else
        strcpy(buffer, "") ;

      TListWindItem ItemDate(buffer, iColIndex) ;
      ItemDate.SetIndex(iLineIndex) ;
      ItemDate.SetSubItem(iColIndex) ;
      pListeWindow->SetItem(ItemDate) ;

      iColIndex++ ;
    }

    string sPreviousValue = (*itGoal)->sValue ;

    TListWindItem ItemPrevValue(sPreviousValue.c_str(), iColIndex) ;
    ItemPrevValue.SetIndex(iLineIndex) ;
    ItemPrevValue.SetSubItem(iColIndex) ;
    pListeWindow->SetItem(ItemPrevValue) ;
	}

  Invalidate() ;
}

void
NSGoalView::DispInfoListe(TLwDispInfoNotify& dispInfo)
{
  const int       BufLen = 255 ;
  static char     buffer[BufLen] ;
  TListWindItem   &dispInfoItem = *(TListWindItem *) &dispInfo.item ;
  char            szDate[20] ;
  buffer[0] = '\0' ;

  int index = dispInfoItem.GetIndex() ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  // Affiche les informations en fonction de la colonne  switch (dispInfoItem.GetSubItem())
  {
    // niveau de s�v�rit�
    case 1  : // TODO
              {
                switch ((aGoals[index])->iLevel)
                {
                  case NSLdvGoalInfo::AVrouge : strcpy(buffer, "r") ; dispInfoItem.SetText(buffer) ; break ;
                  case NSLdvGoalInfo::AVjaune : strcpy(buffer, "j") ; dispInfoItem.SetText(buffer) ; break ;
                  case NSLdvGoalInfo::AVvert  : strcpy(buffer, "v") ; dispInfoItem.SetText(buffer) ; break ;
                  case NSLdvGoalInfo::Bleu    : strcpy(buffer, "b") ; dispInfoItem.SetText(buffer) ; break ;
                  case NSLdvGoalInfo::APvert  : strcpy(buffer, "V") ; dispInfoItem.SetText(buffer) ; break ;
                  case NSLdvGoalInfo::APjaune : strcpy(buffer, "J") ; dispInfoItem.SetText(buffer) ; break ;
                  case NSLdvGoalInfo::AProuge : strcpy(buffer, "R") ; dispInfoItem.SetText(buffer) ; break ;
                }
              }
              break ;

    // date d�but
    case 2  : if      ((aGoals[index])->iRythme == NSLdvGoal::cyclic)
                strcpy(buffer, "cyclique") ;
              else if ((aGoals[index])->iRythme == NSLdvGoal::permanent)
                strcpy(buffer, "permanent") ;
              else if ((aGoals[index])->iRythme == NSLdvGoal::ponctuel)
                strcpy(buffer, "ponctuel") ;
              else
                strcpy(buffer, "") ;
              dispInfoItem.SetText(buffer) ;
              break ;

    // date d�but autoris�
    case 3  : strcpy(szDate, ((aGoals[index])->dateAuto).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    // date d�but conseill�
    case 4  : strcpy(szDate, ((aGoals[index])->dateCons).c_str()) ;              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    // date d�but id�al
    case 5  : strcpy(szDate, ((aGoals[index])->dateIdeal).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    // date d�but ideal max
    case 6  : strcpy(szDate, ((aGoals[index])->dateIdealMax).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    // date d�but conseill� max
    case 7  : strcpy(szDate, ((aGoals[index])->dateConsMax).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    // date d�but critique
    case 8  : strcpy(szDate, ((aGoals[index])->dateCrit).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    // date pr�c�dent
    case 9  : strcpy(szDate, ((aGoals[index])->datePrec).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    // valeur pr�c�dente
    case 10 : if ((aGoals[index])->sValue != "")
              {
                strcpy(buffer, ((aGoals[index])->sValue).c_str()) ;
                dispInfoItem.SetText(buffer) ;
              }
              break ;
  }
}


void
NSGoalView::LVNColumnclick(TLwNotify& lwn)
{
	int iColumn = lwn.iSubItem ;

    // Si cette colonne �tait d�j� tri�e, c'est qu'on souhaite la trier
    // dans l'ordre inverse
    //
    // If this column was alredy sorted, it means we want to sort it in
    // reverse order
    //
    if (iSortedColumn == iColumn)
	{
    	if (bNaturallySorted)
			bNaturallySorted = false ;
		else
			bNaturallySorted = true ;
	}
	else
		bNaturallySorted = true ;

  	sortByColumn(iColumn) ;
}


// -----------------------------------------------------------------------------
// fonction qui trie les items en fonction d'une colonne
// -----------------------------------------------------------------------------
void
NSGoalView::sortByColumn(int iColumn)
{
	iSortedColumn = iColumn ;

	if (aGoals.empty())
		return ;

	switch (iColumn)
	{
		case 0  :
        	if (bNaturallySorted)
        		sort(aGoals.begin(), aGoals.end(), goalSortByNameInf) ;
            else
            	sort(aGoals.begin(), aGoals.end(), goalSortByNameSup) ;
            break ;

    	// -------------------------------------------------------------------------
    	// functions are not in the same order than the other because we want that
    	// in normal case we sort like the greatest severity is the first
    	case 1  :
        	if (bNaturallySorted)
            	sort(aGoals.begin(), aGoals.end(), goalSortByLevelSup) ;
            else
            	sort(aGoals.begin(), aGoals.end(), goalSortByLevelInf) ;
            break ;
    	// -------------------------------------------------------------------------

        case 2  : if (bNaturallySorted)
                    sort(aGoals.begin(), aGoals.end(), goalSortByRythmeInf) ;
                  else
                    sort(aGoals.begin(), aGoals.end(), goalSortByRythmeSup) ;
                  break ;

        case 3  : if (bNaturallySorted)
                    sort(aGoals.begin(), aGoals.end(), goalSortByAutoriseSup) ;
                  else
                    sort(aGoals.begin(), aGoals.end(), goalSortByAutoriseInf) ;
                  break ;

        case 4  : if (bNaturallySorted)
                    sort(aGoals.begin(), aGoals.end(), goalSortByConseilleSup) ;
                  else
                    sort(aGoals.begin(), aGoals.end(), goalSortByConseilleInf) ;
                  break ;

        case 5  : if (bNaturallySorted)
                    sort(aGoals.begin(), aGoals.end(), goalSortByIdealSup) ;
                  else
                    sort(aGoals.begin(), aGoals.end(), goalSortByIdealInf) ;
                  break ;

        case 6  : if (bNaturallySorted)
                    sort(aGoals.begin(), aGoals.end(), goalSortByIdealMaxSup) ;
                  else
                    sort(aGoals.begin(), aGoals.end(), goalSortByIdealMaxInf) ;
                  break ;

        case 7  : if (bNaturallySorted)
                    sort(aGoals.begin(), aGoals.end(), goalSortByConseilleMaxSup) ;
                  else
                    sort(aGoals.begin(), aGoals.end(), goalSortByConseilleMaxInf) ;
                  break ;

        case 8  : if (bNaturallySorted)
                    sort(aGoals.begin(), aGoals.end(), goalSortByCriticalSup) ;
                  else
                    sort(aGoals.begin(), aGoals.end(), goalSortByCriticalInf) ;
                  break ;

        case 9  : if (bNaturallySorted)
                    sort(aGoals.begin(), aGoals.end(), goalSortByPreviousSup) ;
                  else
                    sort(aGoals.begin(), aGoals.end(), goalSortByPreviousInf) ;
                  break ;

        case 10 : if (bNaturallySorted)
                    sort(aGoals.begin(), aGoals.end(), goalSortByPrevValueInf) ;
                  else
                    sort(aGoals.begin(), aGoals.end(), goalSortByPrevValueSup) ;
                  break ;
	}

	AfficheListe() ;
}


boolNSGoalView::VnIsWindow(HWND hWnd){
  return (HWindow == hWnd) ;
}


// fonction permettant de prendre toute la taille de TWindow par la TListWindowvoid
NSGoalView::EvSize(uint sizeType, ClassLib::TSize& size)
{
  TWindow::EvSize(sizeType, size) ;
  pListeWindow->MoveWindow(GetClientRect(), true) ;
}


// fonction EVSetFocusvoid
NSGoalView::EvSetFocus(HWND hWndLostFocus)
{
	NSMUEView::EvSetFocus(hWndLostFocus);

  focusFct() ;

  pListeWindow->SetFocus() ;
}

void
NSGoalView::focusFct()
{
	activateMUEViewMenu() ;

  TMyApp    *pMyApp = pContexte->getSuperviseur()->getApplication() ;
  if (bSetupToolBar && (GetWindow() != pMyApp->GetToolBarWindow()))
  {
    SetupToolBar() ;
    pMyApp->SetToolBarWindow(GetWindow()) ;
  }

  pPaneSplitter->SetFrameTitle(getFunction(), sViewName) ;
  pContexte->setAideIndex("") ;
  pContexte->setAideCorps("objectifs.htm") ;
}

// SetupToolBarvoid
NSGoalView::SetupToolBar()
{
try
{
	TMyApp *pMyApp = pContexte->getSuperviseur()->getApplication() ;
	pMyApp->FlushControlBar() ;

	pMyApp->cb2->Insert(*new TButtonGadget(CM_GOAL_STOP, CM_GOAL_STOP, TButtonGadget::Command)) ;

	pMyApp->cb2->LayoutSession() ;
}
catch (...)
{
	erreur("Exception NSGoalView::SetupToolBar.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
//
//  					M�thodes de NSDrugsPropertyWindow//
// -----------------------------------------------------------------------------DEFINE_RESPONSE_TABLE1(NSGoalsPropertyWindow, TListWindow)
  EV_WM_SETFOCUS,
  EV_WM_LBUTTONDBLCLK,
  EV_WM_RBUTTONDOWN,
  EV_WM_KEYDOWN,
  EV_COMMAND(CM_GOAL_STOP,   CmClore),
  EV_COMMAND(CM_GOAL_NEW,    CmCreate),
  EV_COMMAND(CM_GOAL_CHANGE, CmModify),
  EV_COMMAND(CM_REFERENTIAL, CmProtocol),
  EV_COMMAND(CM_GOAL_TRAIT,  CmTraitSelectedObj),
END_RESPONSE_TABLE ;

NSGoalsPropertyWindow::NSGoalsPropertyWindow(NSGoalView *parent, int id, int x, int y, int w, int h, TModule *module)
                      :TListWindow((TWindow *) parent, id, x, y, w, h, module)
{
  pView   = parent ;
  iRes    = id ;
  Attr.Style |= LVS_REPORT | LVS_SHOWSELALWAYS ;
  //Attr.ExStyle |= WS_EX_NOPARENTNOTIFY | LVS_EX_FULLROWSELECT ;

  Images  = 0 ;
}

NSGoalsPropertyWindow::~NSGoalsPropertyWindow()
{
	if (Images)
		delete Images ;
}

void
NSGoalsPropertyWindow::SetupWindow()
{
  ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;

  TListWindow::SetupWindow() ;

  HINSTANCE hInstModule = *GetApplication() ;

  Images = new TImageList(NS_CLASSLIB::TSize(16, 16), ILC_COLOR4, 15, 5) ;
  Images->Add(OWL::TBitmap(hInstModule, GOAL_EARLY_RED)) ;
  Images->Add(OWL::TBitmap(hInstModule, GOAL_EARLY_YELLOW)) ;
  Images->Add(OWL::TBitmap(hInstModule, GOAL_EARLY_GREEN)) ;
  Images->Add(OWL::TBitmap(hInstModule, GOAL_BLUE)) ;
  Images->Add(OWL::TBitmap(hInstModule, GOAL_GREEN)) ;
  Images->Add(OWL::TBitmap(hInstModule, GOAL_YELLOW)) ;
  Images->Add(OWL::TBitmap(hInstModule, GOAL_RED)) ;
  SetImageList(*Images, TListWindow::State) ;
}

void
NSGoalsPropertyWindow::CmClore()
{
  pView->CmClore() ;
}

void
NSGoalsPropertyWindow::CmCreate()
{
  pView->CmNouveau() ;
}

void
NSGoalsPropertyWindow::CmModify()
{
  //pView->CmModify() ;
  pView->CmModifier() ;
}

void
NSGoalsPropertyWindow::CmProtocol()
{
  pView->CmFct3() ;
}

void
NSGoalsPropertyWindow::CmTraitSelectedObj()
{
  //pView->CmModify() ;
  pView->CmTraitSelectedObj() ;
}

// -----------------------------------------------------------------------------
// Fonction de r�ponse au double-click
// -----------------------------------------------------------------------------
void
NSGoalsPropertyWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
  TLwHitTestInfo info(point) ;

  HitTest(info) ;
  //if (info.GetFlags() & LVHT_ONITEM)  //  pDlg->CmModifier();
}


void
NSGoalsPropertyWindow::EvRButtonDown(uint modkeys, NS_CLASSLIB::TPoint& point)
{
try
{
	TListWindow::EvLButtonDown(modkeys,point) ;

	//int count = GetItemCount() ;
	TLwHitTestInfo info(point) ;

	//int index = HitTest(info) ;

  NSSuper* pSuper = pView->pContexte->getSuperviseur() ;

	TPopupMenu *menu = new TPopupMenu() ;

	// We can't do that since we don't have a concern to attach the new goal
  //sTitle = pView->pContexte->getSuperviseur()->getText("goalsManagement", "goalCreate") ;
	//menu->AppendMenu(MF_STRING, CM_GOAL_NEW, sTitle.c_str());

  string sModif = pSuper->getText("goalsManagement", "goalModify") ;
  string sSelOb = pSuper->getText("goalsManagement", "goalTraitSelobj") ;
  string sClose = pSuper->getText("goalsManagement", "goalClose") ;
  string sGuide = pSuper->getText("goalsManagement", "newGoalFromGuideline") ;
  string sCreat = pSuper->getText("goalsManagement", "goalCreate") ;

  menu->AppendMenu(MF_STRING, CM_REFERENTIAL, sGuide.c_str()) ;
  menu->AppendMenu(MF_STRING, CM_GOAL_NEW,    sCreat.c_str()) ;
	menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
	menu->AppendMenu(MF_STRING, CM_GOAL_CHANGE, sModif.c_str()) ;
  if (!pView->SelectedObjectifs())
  	menu->AppendMenu(MF_GRAYED, 0, sSelOb.c_str()) ;
  else
    menu->AppendMenu(MF_STRING, CM_GOAL_TRAIT, sSelOb.c_str()) ;
  menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
	menu->AppendMenu(MF_STRING, CM_GOAL_STOP, sClose.c_str()) ;

	ClientToScreen(point) ;
	menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point, 0, HWindow) ;
	delete menu ;
}
catch (...)
{
	erreur("Exception NSGoalsPropertyWindow::EvRButtonDown.", standardError, 0) ;
}
}

void
NSGoalsPropertyWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
	if      (key == VK_DELETE)
		pView->CmClore() ;
	else if (key == VK_INSERT)
	{
  	if (GetKeyState(VK_SHIFT) < 0)
    	pView->CmModifier() ;
    else
    	pView->CmNouveau() ;
	}
  else if (key == VK_TAB)
  {
  	if (GetKeyState(VK_SHIFT) < 0)
    	pView->setFocusToPrevSplitterView() ;
    else
    	pView->setFocusToNextSplitterView() ;
	}
  else
  	TListWindow::EvKeyDown(key, repeatCount, flags) ;
}

// -----------------------------------------------------------------------------//  Retourne l'index du premier item s�lectionn�
// -----------------------------------------------------------------------------
int
NSGoalsPropertyWindow::IndexItemSelect()
{
  int count = GetItemCount() ;
  int index = -1 ;

  for (int i = 0 ; i < count ; i++)    if (GetItemState(i, LVIS_SELECTED))
    {
      index = i ;
      break ;
    }

  return index ;}

void
NSGoalsPropertyWindow::EvSetFocus(HWND hWndLostFocus)
{
  pView->EvSetFocus(hWndLostFocus) ;
}

