#include "nautilus\nsldvgoal.h"

#include "nsbb\nsbbtran.h"
#include "nsbb\nstlibre.h"
#include "nautilus\nssuper.h"
#include "nautilus\nshistdo.h"
#include "nssavoir\nsgraphe.h"
#include "nssavoir\nsconver.h"

// -----------------------------------------------------------------------------
// fonction globale de tri :
//			Permet de trier les NSLdvGoalInfo par ordre de date
// -----------------------------------------------------------------------------
bool
infGoalInfo(NSLdvGoalInfo *s, NSLdvGoalInfo *b)
{
  return (s->tpsInfo < b->tpsInfo) ;
}


// -----------------------------------------------------------------------------
//
// M�thodes de NSLdvGoalInfo
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// NSLdvGoalInfo(string code, string value, string unit)
// -----------------------------------------------------------------------------
NSLdvGoalInfo::NSLdvGoalInfo()
{
  sGoalReference  = "" ;

  iTypeJalon      = jalonNotype ;
  iTypeJalonEvent = jalonNoEvent ;

  iTimeLevel      = None ;
  iValueLevel     = None ;
  iLevel          = None ;

  sEventNode      = "" ;
  tpsInfo.init() ;
  tpsClosed.setNoLimit() ;

	sCode           = "" ;
  dValue          = 0 ;
	sValue	        = "" ;
	sUnit           = "" ;
	sFormat	        = "" ;
}


// -----------------------------------------------------------------------------
// NSLdvGoalInfo(NSLdvGoalInfo& rv)
// -----------------------------------------------------------------------------
NSLdvGoalInfo::NSLdvGoalInfo(NSLdvGoalInfo& rv)
{
  sGoalReference  = rv.sGoalReference ;

	sCode           = rv.sCode ;
  dValue          = rv.dValue ;
	sValue	        = rv.sValue ;
	sUnit           = rv.sUnit ;
	sFormat         = rv.sFormat ;

  tpsInfo         = rv.tpsInfo ;
  tpsClosed       = rv.tpsClosed ;

  iLevel          = rv.iLevel ;
  iTimeLevel      = rv.iTimeLevel ;
  iValueLevel     = rv.iValueLevel ;

  sEventNode      = rv.sEventNode ;
  iTypeJalon      = rv.iTypeJalon ;
  iTypeJalonEvent = rv.iTypeJalonEvent ;
}


// -----------------------------------------------------------------------------
// ~NSLdvGoalInfo()
// -----------------------------------------------------------------------------
NSLdvGoalInfo::~NSLdvGoalInfo()
{
}


// -----------------------------------------------------------------------------
// NSLdvGoalInfo& operator=(NSLdvGoalInfo src)
// -----------------------------------------------------------------------------
NSLdvGoalInfo&
NSLdvGoalInfo::operator=(NSLdvGoalInfo src)
{
  sGoalReference  = src.sGoalReference ;

	sCode           = src.sCode ;
  dValue          = src.dValue ;
	sValue	        = src.sValue ;
	sUnit 	        = src.sUnit ;
	sFormat         = src.sFormat ;

  tpsInfo         = src.tpsInfo ;
  tpsClosed       = src.tpsClosed ;

  iLevel          = src.iLevel ;
  iTimeLevel      = src.iTimeLevel ;
  iValueLevel     = src.iValueLevel ;

  sEventNode      = src.sEventNode ;
  iTypeJalon      = src.iTypeJalon ;
  iTypeJalonEvent = src.iTypeJalonEvent ;

	return (*this) ;
}


void
NSLdvGoalInfo::computeLevel()
{
  if (iValueLevel > iTimeLevel)
    iLevel = iValueLevel ;
  else
    iLevel = iTimeLevel ;
}

NSLdvGoalInfo::JALONSLEVELS
NSLdvGoalInfo::getPreviousColor(NSLdvGoalInfo::JALONSLEVELS iColorLevel)
{
	switch(iColorLevel)
	{
		case AProuge : return APjaune ;
		case APjaune : return APvert ;
		case APvert  : return Bleu ;
		case Bleu    : return AVvert ;
		case AVvert  : return AVjaune ;
		case AVjaune : return AVrouge ;
		case AVrouge : return None ;
		case None    : return None ;
		default      : return None ;
	}
}

NSLdvGoalInfo::JALONSLEVELS
NSLdvGoalInfo::getNextColor(NSLdvGoalInfo::JALONSLEVELS iColorLevel)
{
	switch(iColorLevel)
	{
		case AProuge : return None ;
		case APjaune : return AProuge ;
		case APvert  : return APjaune ;
		case Bleu    : return APvert ;
		case AVvert  : return Bleu ;
		case AVjaune : return AVvert ;
		case AVrouge : return AVjaune ;
		case None    : return None ;
		default      : return None ;
	}
}

// -----------------------------------------------------------------------------
//
// M�thodes de GoalInfoArray
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// GoalInfoArray()
// -----------------------------------------------------------------------------
GoalInfoArray::GoalInfoArray()
  : GoalInfoVector()
{
}


// -----------------------------------------------------------------------------
// GoalInfoArray(GoalInfoArray& rv)
// -----------------------------------------------------------------------------
GoalInfoArray::GoalInfoArray(GoalInfoArray& rv)
{
try
{
	if (!(rv.empty()))
		for (GoalInfoIter i = rv.begin() ; i != rv.end() ; i++)
			push_back(new NSLdvGoalInfo(*(*i))) ;
}
catch (...)
{
	erreur("Exception GoalInfoArray copy ctor.", standardError, 0) ;
}
}


// -----------------------------------------------------------------------------
// ~GoalInfoArray()
// -----------------------------------------------------------------------------
GoalInfoArray::~GoalInfoArray()
{
	vider() ;
}


// -----------------------------------------------------------------------------
// GoalInfoArray& operator=(GoalInfoArray src)
// -----------------------------------------------------------------------------
GoalInfoArray&
GoalInfoArray::operator=(GoalInfoArray src)
{
try
{
	if (this == &src)
		return (*this) ;

	vider() ;

	if (!src.empty())
	{
		for (GoalInfoIter goalInfoIter = src.begin() ; goalInfoIter != src.end() ; goalInfoIter++)
			push_back(new NSLdvGoalInfo(**goalInfoIter)) ;
	}

	return (*this) ;
}
catch (...)
{
	erreur("Exception GoalInfoArray (=).", standardError, 0) ;
	return *this;
}
}


// -----------------------------------------------------------------------------
// void	vider()
// -----------------------------------------------------------------------------
void
GoalInfoArray::vider()
{
	if (empty())
		return ;

	for (GoalInfoIter i = begin() ; i != end() ; )
	{
		delete (*i) ;
		erase(i) ;
	}
}


NSLdvGoalInfo
*GoalInfoArray::getClosingJalon(NSLdvGoalInfo *pJalon)
{
	if (empty())
		return NULL ;

  GoalInfoIter i = begin() ;
  // On retrouve le jalon initial
  for ( ; (i != end()) && (*i != pJalon) ; i++) ;
    if (i == end())
        return NULL ;

  GoalInfoIter j = getClosingJalon(i) ;

  if (j == end())
    return NULL ;
  else
    return *j ;
}


GoalInfoIter
GoalInfoArray::getClosingJalon(GoalInfoIter iJalon)
{
  if (empty())
    return end() ;

  string sGoalRef = (*iJalon)->sGoalReference ;

  GoalInfoIter j = iJalon ;
  j++ ;

  for ( ; (j != end()) && ((*j)->sGoalReference != sGoalRef) ; j++)
    ;

  return j ;
}


/*
// -----------------------------------------------------------------------------
// void	initialiser()
// -----------------------------------------------------------------------------
void
GoalInfoArray::initialiser()
{
}


// -----------------------------------------------------------------------------
// void		loadGoalInfo(PatPathoIter iter, int iColBase)
// -----------------------------------------------------------------------------
void
GoalInfoArray::loadGoalInfo(PatPathoIter iter, int iColBase)
{
}


// -----------------------------------------------------------------------------
// void		reinit()
// -----------------------------------------------------------------------------
void
GoalInfoArray::reinit()
{
}


// -----------------------------------------------------------------------------
// void        reloadGoalInfo(PatPathoIter iter, int iColBase)
// -----------------------------------------------------------------------------
void
GoalInfoArray::reloadGoalInfo(PatPathoIter iter, int iColBase)
{
}
*/


// -----------------------------------------------------------------------------
//
// M�thodes de NSLdvGoal
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// NSLdvGoal(NSContexte *pCtx)
// -----------------------------------------------------------------------------
NSLdvGoal::NSLdvGoal(NSContexte *pCtx)
  : NSRoot(pCtx)
{
try
{
	sLexique                = "" ;
	sTitre                  = "" ;
	sCertitude              = "" ;
	sComplementText         = "" ;
	tDateOuverture.init() ;
	dValueOuverture         = 0 ;
	sValueOuverture         = "" ;
	sUnitFermeture          = "" ;
	bValueOuverture         = false ;
	tDateFermeture.init() ;
	dValueFermeture         = 0 ;
	sValueFermeture         = "" ;
	sUnitFermeture          = "" ;
	bValueFermeture         = false ;
	tOuvertLe.init() ;
	tFermeLe.init() ;

	sOpenEventNode          = "" ;
	sCloseEventNode         = "" ;

	sConcern                = "" ;
	sReference              = "" ;

	iRythme                 = NSLdvGoal::ponctuel ;

	dDelaiDebutAutorise     = -1 ;
	sUniteDebutAutorise     = "" ;
	dDelaiDebutConseille    = -1 ;
	sUniteDebutConseille    = "" ;
	dDelaiDebutIdeal        = -1 ;
	sUniteDebutIdeal        = "" ;
	dDelaiDebutIdealMax     = -1 ;
	sUniteDebutIdealMax     = "" ;
	dDelaiDebutConseilMax   = -1 ;
	sUniteDebutConseilMax   = "" ;
	dDelaiDebutCritique     = -1 ;
	sUniteDebutCritique     = "" ;

	sDateDebutAutorise      = "" ;
	sDateDebutConseille     = "" ;
	sDateDebutIdeal         = "" ;
	sDateDebutIdealMax      = "" ;
	sDateDebutConseilMax    = "" ;
	sDateDebutCritique      = "" ;

	bValue                  = false ;

	bValMinAutorise         = false ;
	dValMinAutorise         = 0 ;
	sUniteValMinAutorise    = "" ;
	bValMinConseille        = false ;
	dValMinConseille        = 0 ;
	sUniteValMinConseille   = "" ;
	bValMinIdeal            = false ;
	dValMinIdeal            = 0 ;
	sUniteValMinIdeal       = "" ;
	bValMaxIdeal            = false ;
	dValMaxIdeal            = 0 ;
	sUniteValMaxIdeal       = "" ;
	bValMaxConseille        = false ;
	dValMaxConseille        = 0 ;
	sUniteValMaxConseille   = "" ;
	bValMaxAutorise         = false ;
	dValMaxAutorise         = 0 ;
	sUniteValMaxAutorise    = "" ;

	pJalons                 = new GoalInfoArray() ;
  pMetaJalons             = new GoalInfoArray() ;
  isSelected							= false ;
}
catch (...)
{
	erreur("Exception NSLdvGoal ctor.", standardError, 0) ;
}
}

int
NSLdvGoal::getGoalType()
{
	char firstCh = sLexique[0];
  switch(firstCh)
  {
  	case 'I':
			return medicament ;
    case '_' :
    	return medicament ;
    case 'G' :
    	return exam ;
    case 'N' :
    	return traitement ;
    case 'T' :
    	return biology ;
    case 'V' :
    	//test if sLexique EST un examen biologique
    	string sCodeSens;
    	pContexte->getDico()->donneCodeSens(&sLexique, &sCodeSens);
      if(pContexte->getSuperviseur()->getFilGuide()->VraiOuFaux(sCodeSens, "ES", "VREBI1"))
      	return biology ;

  } ;
  return  other ;

}


void
NSLdvGoal::init(string sOpenDate, string sCloseDate, string sOpenEvent, string sCloseEvent)
{
  if (sOpenDate != "")
    tDateOuverture.initFromDate(sOpenDate) ;
  if (sCloseDate != "")
    tDateFermeture.initFromDate(sCloseDate) ;

  sOpenEventNode  = sOpenEvent ;
  sCloseEventNode = sCloseEvent ;

  init() ;
}


void
NSLdvGoal::init()
{
try
{
  // L'�v�nement est-il ouvert ?
  // Does event opened ?

  // S'il n'y a pas d'�v�nement d'ouverture, l'ouverture est m�canique
  // If there is no opening event, the goal opens automatically
  if (sOpenEventNode == "")
  {
    // Ce n'est pas g�nant que l'objectif s'ouvre dans le futur
    // The goal can open in the futur - no problem for that
    if (!(tDateOuverture.estVide()))
      tOuvertLe = tDateOuverture ;
  }

  // S'il y a un �v�nement d'ouverture, l'ouverture ne se fait que si l'�v�nement a eu lieu
  // If there is an opening event, the goal only opens if the event occured
  else
  {
    NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

    VecteurString vecteurString ;
    pGraphe->TousLesVrais(sReference, NSRootLink::goalOpener, &vecteurString) ;

    if (false == vecteurString.empty())
    {
      EquiItemIter openIter = vecteurString.begin() ;
      string       sDateDoc = getNodeDate(*(*openIter)) ;

      double       dValue ;
      string       sValue ;
      if (getNodeValue(*(*openIter), &sValue, &dValue))
      {
        sUnitOuverture  = getNodeUnit(*(*openIter)) ;
        dValueOuverture = dValue ;
        sValueOuverture = sValue ;
        bValueOuverture = true ;
        bValue          = true ;
      }

      if (sDateDoc != "")
        tOuvertLe.initFromDate(sDateDoc) ;
    }
  }

  // L'�v�nement a-t-il une date de fermeture ?
  // Does event have a closing date ?

  if (tOuvertLe.estVide())
    return ;

  NSLinkManager* 	pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

  VecteurString vectString ;
  pGraphe->TousLesVrais(sReference, NSRootLink::goalCloser, &vectString, "ENVERS") ;

  if (false == vectString.empty())
  {
    EquiItemIter closeIter = vectString.begin() ;
    string       sDateDoc  = getNodeDate(*(*closeIter)) ;

    double       dValue ;
    string       sValue ;
    if (getNodeValue(*(*closeIter), &sValue, &dValue))
    {
      sUnitFermeture  = getNodeUnit(*(*closeIter)) ;
      dValueFermeture = dValue ;
      sUnitFermeture  = sValue ;
      bValueFermeture = true ;
      bValue          = true ;
    }

    if (sDateDoc != "")
      tFermeLe.initFromDate(sDateDoc) ;
  }

  // S'il n'y a pas d'�v�nement de fermeture, la fermeture est m�canique
  // If there is no closing event, the goal closes automatically
  if ((tFermeLe.estVide()) && (sCloseEventNode == ""))
  {
    // Ce n'est pas g�nant que l'objectif s'ouvre dans le futur
    // The goal can open in the futur - no problem for that
    if (!(tDateFermeture.estVide()))
      tFermeLe = tDateFermeture ;
  }
}
catch (...)
{
	erreur("Exception NSLdvGoal::init().", standardError, 0) ;
}
}
//==============================================================================

void
NSLdvGoal::getADateTree(string sVal, string sCode, NSPatPathoArray* pPatho, int colonne)
{
	if ((string("") == sVal) || (NULL == pPatho))
		return ;

	pPatho->ajoutePatho(sCode, colonne) ;
	colonne++ ;
	pPatho->ajoutePatho("KDAT01", colonne) ;
	colonne++ ;
	Message Msg ;
	Msg.SetUnit("2DA021") ;
	Msg.SetComplement(sVal) ;
	pPatho->ajoutePatho("�T0;19", &Msg, colonne) ;
}

void
NSLdvGoal::getAllDatesTree(NSPatPathoArray* pPatho, int colonne)
{
  if ((sDateDebutIdeal     == "") && (sDateDebutIdealMax   == "") &&
      (sDateDebutConseille == "") && (sDateDebutConseilMax == "") &&
      (sDateDebutAutorise  == "") && (sDateDebutCritique   == "") )
    return ;

  pPatho->ajoutePatho("KMOD01", colonne) ;
  colonne++;
  getADateTree(sDateDebutIdeal,      "KMOD31", pPatho, colonne) ;
  getADateTree(sDateDebutIdealMax,   "KMOD41", pPatho, colonne) ;
  getADateTree(sDateDebutConseille,  "KMOD21", pPatho, colonne) ;
  getADateTree(sDateDebutConseilMax, "KMOD51", pPatho, colonne) ;
  getADateTree(sDateDebutAutorise,   "KMOD11", pPatho, colonne) ;
  getADateTree(sDateDebutCritique,   "KMOD61", pPatho, colonne) ;
}

void
NSLdvGoal::getAPeriodTree(double dVal, string unit, string sCode, NSPatPathoArray* pPatho, int colonne)
{
	if ((dVal <= 0) || (unit == ""))
		return ;

	string sVal =	DoubleToString(&dVal, -1, -1) ;

	pPatho->ajoutePatho(sCode, colonne) ;

	colonne++ ;
	pPatho->ajoutePatho("VDURE1", colonne) ;

	colonne++ ;
	Message Msg ;
	Msg.SetUnit(unit) ;
	Msg.SetComplement(sVal) ;
	pPatho->ajoutePatho("�N0;03", &Msg, colonne) ;
}

void
NSLdvGoal::getAllPeriodesTree(NSPatPathoArray* pPatho, int colonne)
{
	if ((dDelaiDebutIdeal     < 0) && (dDelaiDebutIdealMax   < 0) &&
		  (dDelaiDebutConseille < 0) && (dDelaiDebutConseilMax < 0) &&
		  (dDelaiDebutAutorise  < 0) && (dDelaiDebutCritique   < 0))
		return ;

	pPatho->ajoutePatho("KMOD01", colonne) ;
	colonne++;

	getAPeriodTree(dDelaiDebutIdeal,      sUniteDebutIdeal,      "KMOD31", pPatho, colonne) ;
	getAPeriodTree(dDelaiDebutIdealMax,   sUniteDebutIdealMax,   "KMOD41", pPatho, colonne) ;
	getAPeriodTree(dDelaiDebutConseille,  sUniteDebutConseille,  "KMOD21", pPatho, colonne) ;
	getAPeriodTree(dDelaiDebutConseilMax, sUniteDebutConseilMax, "KMOD51", pPatho, colonne) ;
	getAPeriodTree(dDelaiDebutAutorise,   sUniteDebutAutorise,   "KMOD11", pPatho, colonne) ;
	getAPeriodTree(dDelaiDebutCritique,   sUniteDebutCritique,   "KMOD61", pPatho, colonne) ;
}

void
NSLdvGoal::getAValueTree(double dVal, string unit, string sCode, NSPatPathoArray* pPatho, int colonne)
{
	if ((dVal <= 0) || (unit == ""))
		return ;

	string sVal =	DoubleToString(&dVal, -1, -1) ;

	pPatho->ajoutePatho(sCode, colonne) ;
	colonne++ ;
	Message *pCodeMsg = new Message("", "", "", "A", "", "", "") ;
	pCodeMsg->SetUnit(unit) ;
	pCodeMsg->SetComplement(sVal) ;
	pPatho->ajoutePatho("�N0;03", pCodeMsg, colonne) ;
	delete  pCodeMsg ;
}

void
NSLdvGoal::getAllValuesTree(NSPatPathoArray* pPatho, int colonne)
{
	if ((dValMinIdeal     <= 0) && (dValMaxIdeal     <= 0) &&
      (dValMinConseille <= 0) && (dValMaxConseille <= 0) &&
      (dValMinAutorise  <= 0) && (dValMaxAutorise  <= 0) )
		return ;

	pPatho->ajoutePatho("0ENVV1", colonne) ;
  colonne++ ;
  getAValueTree(dValMinIdeal,     sUniteValMinIdeal,     "VMIN01", pPatho, colonne) ;
  getAValueTree(dValMaxIdeal,     sUniteValMaxIdeal,     "VMAX01", pPatho, colonne) ;
  getAValueTree(dValMinConseille, sUniteValMinConseille, "VMIN11", pPatho, colonne) ;
  getAValueTree(dValMaxConseille, sUniteValMaxConseille, "VMAX11", pPatho, colonne) ;
  getAValueTree(dValMinAutorise,  sUniteValMinAutorise,  "VMIN21", pPatho, colonne) ;
  getAValueTree(dValMaxAutorise,  sUniteValMaxAutorise,  "VMAX21", pPatho, colonne) ;
}

bool
NSLdvGoal::insertDate(string sCode, NVLdVTemps tTemps, NSPatPathoArray* pPatho, int colonne)
{
	if ((tTemps.estVide()) || (string("") == sCode) || (NULL == pPatho))
		return false ;

	pPatho->ajoutePatho(sCode, colonne) ;

  colonne++ ;

	Message Msg ;
	Msg.SetUnit("2DA021") ;
	Msg.SetComplement(tTemps.donneDateHeure()) ;
	pPatho->ajoutePatho("�T0;19", &Msg, colonne) ;

	return true ;
}

bool
NSLdvGoal::insertEveniment(string sCode, string sEvent, NSPatPathoArray* pPatho, int colonne)
{
	if ((string("") == sEvent)|| (string("") == sCode) || (NULL == pPatho))
		return false ;

	pPatho->ajoutePatho(sCode, colonne) ;
	colonne++ ;
	pPatho->ajoutePatho(sEvent, colonne) ;

	return true ;
}

void
NSLdvGoal::setGoalPatho(NSPatPathoArray* pPatho)
{
	if (NULL == pPatho)
		return ;

	int colonne = 0 ;
	if (string("") != sCertitude)
	{
		Message Msg ;
    Msg.SetCertitude(sCertitude) ;
    pPatho->ajoutePatho(sLexique, &Msg, colonne) ;
	}
	else
		pPatho->ajoutePatho(sLexique, colonne) ;

	colonne++ ;
  int iColBase = colonne ;

	if (string("") != sComplementText)
	{
		pPatho->ajoutePatho("LNOMA1", colonne) ;
    colonne++ ;
    Message Msg ;
    Msg.SetTexteLibre(sComplementText) ;
    pPatho->ajoutePatho("�?????", &Msg, 2) ;
    colonne++ ;
	}

  colonne = iColBase ;

	bool res = insertDate("KOUVR1", tDateOuverture, pPatho, colonne) ;
	if (!res)
		res = insertEveniment("KEVOU1", sOpenEventNode, pPatho, colonne) ;
	if (!res)
		return ;

	switch(iRythme)
	{
  	case ponctuel :
    	getAllDatesTree(pPatho, colonne) ;
      getAllValuesTree (pPatho, colonne) ;
      break ;
    case cyclic :
    	pPatho->ajoutePatho("1CYCL1", colonne) ;
      getAllValuesTree(pPatho, colonne) ;
      getAllPeriodesTree(pPatho, colonne) ;
      break ;
    case permanent :
    	pPatho->ajoutePatho("KPERM1", colonne) ;
      getAllValuesTree (pPatho, colonne) ;
      break ;
	}

	res = insertDate("KFERM1", tDateFermeture, pPatho, colonne) ;
	if (!res)
		res = insertEveniment("KEVFE1", sCloseEventNode, pPatho, colonne) ;
}
//==============================================================================

void
NSLdvGoal::initFromPatho(NSPatPathoArray *pPPt, PatPathoIter *pIter)
{
  if ((!pIter) || (*pIter == NULL) || (*pIter == pPPt->end()))
    return ;

  // Libell�
  string sCodeLex = (**pIter)->getLexique() ;
  int    iBaseCol = (**pIter)->getColonne() ;

  string sLangue = pContexte->getUtilisateur()->donneLang() ;

  sLexique = sCodeLex ;

  if (sCodeLex != string("�?????"))
    pContexte->getDico()->donneLibelle(sLangue, &sCodeLex, &sTitre) ;
  // Texte libre - Free text
  else
  	sTitre = (**pIter)->getTexteLibre() ;

  // Noeud
  sReference = (**pIter)->getNode() ;
  sCertitude  = (**pIter)->getCertitude();
  (*pIter)++;

  // Param�tres du probl�me
  while ((*pIter != pPPt->end()) && ((**pIter)->getColonne() > iBaseCol))
  {
    string sElemLex = (**pIter)->getLexique() ;
    string sSens ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    if ((**pIter)->getColonne() == iBaseCol + 1)
    {
      bool	bIncrIter = true ;

			// Identifiant d'objectif au sein du r�f�rentiel
      // Goal ID inside the Referential
      if (sSens == "�RE")
      {
      	sGoalID = (**pIter)->getComplement() ;
			}

      // Dates d'ouverture et de fermeture
      else if (bIncrIter && ((sSens == "KOUVR") || (sSens == "KFERM")))
      {
        (*pIter)++ ;
        int iLigneBase = (**pIter)->getLigne() ;
        // gereDate* pDate = new gereDate(pContexte);
        string sUnite  = "" ;
        string sFormat = "" ;
        string sValeur = "" ;
        string sTemp   = "" ;
        while ((*pIter != pPPt->end()) && ((**pIter)->getLigne() == iLigneBase))
        {
          if (((**pIter)->pDonnees->lexique)[0] == '�')
          {
            sTemp   = (**pIter)->getLexique() ;
            pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
            sValeur = (**pIter)->getComplement() ;
            sTemp   = (**pIter)->getUnit() ;
            pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
            break ;
          }
          (*pIter)++ ;
        }

        // sFormat est du type �D0;03
        if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) && (sValeur != ""))
        {
          if ((sUnite == "2DA01") || (sUnite == "2DA02"))
          {
            if      (sSens == "KOUVR")
              tDateOuverture.initFromDate(sValeur) ;
            else if (sSens == "KFERM")
              tDateFermeture.initFromDate(sValeur) ;
          }
        }
        bIncrIter = false ;
      }

      // cyclique
      else if (sSens == "1CYCL")
      {
        (*pIter)++ ;
        bIncrIter   = false ;
        iRythme     = NSLdvGoal::cyclic ;
      }

      // permanent
      else if (sSens == "KPERM")
      {
        (*pIter)++ ;
        bIncrIter = false ;
        iRythme   = NSLdvGoal::permanent ;
      }
      else if (sSens == "LNOMA")
      {
				(*pIter)++ ;
        if (((**pIter)->getColonne() == iBaseCol + 2) && ((**pIter)->getLexique() == "�?????"))
          sComplementText = (**pIter)->getTexteLibre() ;
        else
          bIncrIter = false ;
      }
      // �v�nement d'ouverture
      else if (sSens == "KEVOU")
      {
        (*pIter)++ ;
        if ((**pIter)->getColonne() == iBaseCol + 2)
          sOpenEventNode = (**pIter)->getLexique() ;
        else
          bIncrIter = false ;
      }

      // �v�nement de fermeture
      else if (sSens == "KEVFE")
      {
        (*pIter)++ ;
        if ((**pIter)->getColonne() == iBaseCol + 2)
          sCloseEventNode = (**pIter)->getLexique() ;
        else
          bIncrIter = false ;
      }

      // moment de d�but
      // starting moment
      else if (sSens == "KMOD0")
      {
        (*pIter)++ ;

        string 	sMoment	    = "" ;
        string  sMomentSens	= "" ;

        int iColBase = (**pIter)->getColonne() ;

        // Type de moment (autoris�, id�al...)
        while ((*pIter != pPPt->end()) && ((**pIter)->getColonne() == iColBase))
        {
          sMoment = (**pIter)->getLexique() ;
          pContexte->getDico()->donneCodeSens(&sMoment, &sMomentSens) ;

          if ((sMomentSens != "")         &&
              (	(sMomentSens == "KMOD1")  ||
                (sMomentSens == "KMOD2")  ||
                (sMomentSens == "KMOD3")  ||
                (sMomentSens == "KMOD4")  ||
                (sMomentSens == "KMOD5")  ||
                (sMomentSens == "KMOD6")))
          {
            (*pIter)++ ;

            // Date fixe ou dur�e depuis le d�marrage du cycle
            while ((*pIter != pPPt->end()) && ((**pIter)->getColonne() > iColBase))
            {
              string sTypeMomentSens;
              string sTypeMoment = (**pIter)->getLexique() ;
              pContexte->getDico()->donneCodeSens(&sTypeMoment, &sTypeMomentSens) ;

              if ((sTypeMomentSens == "VDURE") || (sTypeMomentSens == "KDAT0"))
              {
                (*pIter)++ ;

                string	sUnite	= "" ;
                string	sFormat	= "" ;
                string	sValeur = "" ;
                string	sTemp   = "" ;

                while ((*pIter != pPPt->end()) && (**pIter) && ((**pIter)->getColonne() > iColBase + 1))
                {
                  if (((**pIter)->pDonnees->lexique)[0] == '�')
                  {
                    sTemp   = (**pIter)->getLexique() ;
                    pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
                    sValeur = (**pIter)->getComplement() ;
                    sTemp   = (**pIter)->getUnit() ;
                    pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
                    break ;
                  }
                  (*pIter)++ ;
                }

                // Date pr�cise
                if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) && (sValeur != ""))
                {
                  switch (sMomentSens[4])
                  {
                    case '1'	:   sDateDebutAutorise    = sValeur ;  // moment de d�but autoris�
                                  break ;
                    case '2'	:   sDateDebutConseille   = sValeur ;  // moment de d�but conseill�
                                  break ;
                    case '3'	:   sDateDebutIdeal       = sValeur ;  // moment de d�but id�al
                                  break ;
                    case '4'	:	  sDateDebutIdealMax    = sValeur ;  // moment de d�but id�al maximum
                                  break ;
                    case '5'	:	  sDateDebutConseilMax  = sValeur ; // moment de d�but conseill� maximum
                                  break ;
                    case '6'	:	  sDateDebutCritique    = sValeur ; // moment de d�but critique
                                  break ;
                  }
                }

                // Dur�e
                else if ((sFormat != "") && (sFormat[1] == 'N') && (sValeur != "") && (sUnite != ""))
                {
                  double dvalue = StringToDouble(sValeur) ;

                  switch (sMomentSens[4])
                  {
                    case '1'	:   dDelaiDebutAutorise = dvalue ;   // moment de d�but autoris�
                                  sUniteDebutAutorise = sUnite ;
                                  break ;
                    case '2'	:   dDelaiDebutConseille = dvalue ;  // moment de d�but conseill�
                                  sUniteDebutConseille = sUnite ;
                                  break ;
                    case '3'	:   dDelaiDebutIdeal = dvalue ;      // moment de d�but id�al
                                  sUniteDebutIdeal = sUnite ;
                                  break ;
                    case '4'	:	  dDelaiDebutIdealMax = dvalue ;   // moment de d�but id�al maximum
                                  sUniteDebutIdealMax = sUnite ;
                                  break ;
                    case '5'	:	  dDelaiDebutConseilMax = dvalue ; // moment de d�but conseill� maximum
                                  sUniteDebutConseilMax = sUnite ;
                                  break ;
                    case '6'	:	  dDelaiDebutCritique = dvalue ;   // moment de d�but critique
                                  sUniteDebutCritique = sUnite ;
                                  break ;
                  }
                }
              }
              else
                (*pIter)++ ;
            }
          }
          else
            (*pIter)++ ;
        }
        bIncrIter = false ;
      }

      // moment de fin
      else if (sSens == "KMOF0")
      {
        (*pIter)++ ;

        string 	sMoment     = "" ;
        string  sMomentSens	= "" ;

        int iColBase = (**pIter)->pDonnees->getColonne() ;

        while ((*pIter != pPPt->end()) && ((**pIter)->getColonne() == iColBase))
        {
          sMoment = (**pIter)->getLexique() ;
          pContexte->getDico()->donneCodeSens(&sMoment, &sMomentSens) ;

          if ((sMomentSens != "") &&
              (	(sMomentSens == "KMOF1") ||
                (sMomentSens == "KMOF2") ||
                (sMomentSens == "KMOF3") ||
                (sMomentSens == "KMOF4") ||
                (sMomentSens == "KMOF5") ||
                (sMomentSens == "KMOF6")))
          {
            (*pIter)++ ;
//						int iLigneBase = (*iter)->pDonnees->getLigne() ;
            string	sUnite	= "" ;
            string	sFormat	= "" ;
            string	sValeur = "" ;
            string	sTemp   = "" ;

            while ((*pIter != pPPt->end()) && ((**pIter)->getColonne() > iColBase))
            {
              if (((**pIter)->pDonnees->lexique)[0] == '�')
              {
                sTemp   = (**pIter)->getLexique() ;
                pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
                sValeur = (**pIter)->getComplement() ;
                sTemp   = (**pIter)->getUnit() ;
                pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
                break ;
              }
              (*pIter)++ ;
            }

            if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T') || (sFormat[1] == 'N')) && (sValeur != ""))
            {
              switch (sMomentSens[4])
              {
                case '1'	: // moment de fin autoris�						(sMomentSens == "KMOF1")
                case '2'	: // moment de fin conseill�					(sMomentSens == "KMOF2")
                case '3'	: // moment de fin id�al							(sMomentSens == "KMOF3")
                case '4'	:	// moment de fin id�al maximum			(sMomentSens == "KMOF4")
                case '5'	:	// moment de fin conseill� maximum	(sMomentSens == "KMOF5")
                case '6'	:	// moment de fin critique						(sMomentSens == "KMOF6")
                //pGoal->pGoalInfos->push_back(new NSLdvGoalInfo(sMomentSens, sValeur, sUnite, sFormat)) ;
                break ;
              }
            }
          }
        }
        bIncrIter = false ;
      }

      // dur�e
      else if (sSens == "VDURE")
      {
        (*pIter)++ ;

        string 	sDuree      = "" ;
        string  sDureeSens	= "" ;

        int iColBase = (**pIter)->getColonne() ;

        while ((*pIter != pPPt->end()) && ((**pIter)->getColonne() == iColBase))
        {
          sDuree = (**pIter)->getLexique() ;
          pContexte->getDico()->donneCodeSens(&sDuree, &sDureeSens) ;

          if ((sDureeSens != "") &&
              (	(sDureeSens == "VDUR1") ||
                (sDureeSens == "VDUR2") ||
                (sDureeSens == "VDUR3") ||
                (sDureeSens == "VDUR4") ||
                (sDureeSens == "VDUR5") ||
                (sDureeSens == "VDUR6")))
          {
            (*pIter)++ ;
//						int iLigneBase = (*iter)->pDonnees->getLigne() ;
            string	sUnite	= "" ;
            string	sFormat	= "" ;
            string	sValeur = "" ;
            string	sTemp   = "" ;

            while ((*pIter != pPPt->end()) && ((**pIter)->getColonne() > iColBase))
            {
              if (((**pIter)->pDonnees->lexique)[0] == '�')
              {
                sTemp   = (**pIter)->getLexique() ;
                pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
                sValeur = (**pIter)->getComplement() ;
                sTemp   = (**pIter)->getUnit() ;
                pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
                break ;
              }
              (*pIter)++ ;
            }

            if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T') || (sFormat[1] == 'N')) && (sValeur != ""))
            {
              switch (sDureeSens[4])
              {
                case '1'	: // dur�e|s| minimale autoris�e	(sDureeSens == "VDUR1")
                case '2'	: // dur�e|s| minimale conseill�e	(sDureeSens == "VDUR2")
                case '3'	: // dur�e|s| id�ale minimale			(sDureeSens == "VDUR3")
                case '4'	: // dur�e|s| id�ale maximale			(sDureeSens == "VDUR4")
                case '5'	: // dur�e|s| maximale conseill�e	(sDureeSens == "VDUR5")
                case '6'	: // dur�e|s| maximale autoris�e	(sDureeSens == "VDUR6")
                //pGoal->pGoalInfos->push_back(new NSLdvGoalInfo(sDureeSens, sValeur, sUnite, sFormat)) ;
                break ;
              }
            }
          }
        }
        bIncrIter = false ;
      }

      // enveloppe de valeur
      else if (sSens == "0ENVV")
      {
        (*pIter)++ ;

        string 	sValue      = "" ;
        string  sValueSens	= "" ;

        int iColBase = (**pIter)->getColonne() ;

        while ((*pIter != pPPt->end()) && ((**pIter)->getColonne() == iColBase))
        {
          sValue = (**pIter)->getLexique() ;
          pContexte->getDico()->donneCodeSens(&sValue, &sValueSens) ;

          if ((sValueSens != "") &&
              ( (sValueSens == "VMIN0") ||
                (sValueSens == "VMIN1") ||
                (sValueSens == "VMIN2") ||
                (sValueSens == "VMAX0") ||
                (sValueSens == "VMAX1") ||
                (sValueSens == "VMAX2")))
          {
            (*pIter)++ ;
//						int iLigneBase = (*iter)->pDonnees->getLigne() ;
            string	sUnite	= "" ;
            string	sFormat	= "" ;
            string	sValeur = "" ;
            string	sTemp   = "" ;

            while ((*pIter != pPPt->end()) && ((**pIter)->getColonne() > iColBase))
            {
              if (((**pIter)->pDonnees->lexique)[0] == '�')
              {
                sTemp   = (**pIter)->getLexique() ;
                pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
                sValeur = (**pIter)->getComplement() ;
                sTemp   = (**pIter)->getUnit() ;
                pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
              }
              (*pIter)++ ;
            }

            if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T') || (sFormat[1] == 'N')) && (sValeur != ""))
            {
              double dValue = StringToDouble(sValeur) ;

              if ((sValueSens[2] == 'I') && (sValueSens[3] == 'N'))   // VMINx
              {
                switch (sValueSens[4])
                {
                  case '0'  :   dValMinIdeal          = dValue ;
                                sUniteValMinIdeal     = sUnite ;
                                bValMinIdeal          = true ;
                                bValue                = true ;
                                break ;

                  case '1'	:   dValMinConseille      = dValue ;
                                sUniteValMinConseille = sUnite ;
                                bValMinConseille      = true ;
                                bValue                = true ;
                                break ;

                  case '2'	:   dValMinAutorise       = dValue ;
                                sUniteValMinAutorise  = sUnite ;
                                bValMinAutorise       = true ;
                                bValue                = true ;
                                break ;

                  //pGoal->pGoalInfos->push_back(new NSLdvGoalInfo(sDureeSens, sValeur, sUnite, sFormat)) ;
                }
              }

              if ((sValueSens[2] == 'A') && (sValueSens[3] == 'X'))   // VMAXx
              {
                switch (sValueSens[4])
                {
                  case '0'  :   dValMaxIdeal          = dValue ;
                                sUniteValMaxIdeal     = sUnite ;
                                bValMaxIdeal          = true ;
                                bValue                = true ;
                                break ;

                  case '1'	:   dValMaxConseille      = dValue ;
                                sUniteValMaxConseille = sUnite ;
                                bValMaxConseille      = true ;
                                bValue                = true ;
                                break ;

                  case '2'	:   dValMaxAutorise       = dValue ;
                                sUniteValMaxAutorise  = sUnite ;
                                bValMaxAutorise       = true ;
                                bValue                = true ;
                                break ;

                  //pGoal->pGoalInfos->push_back(new NSLdvGoalInfo(sDureeSens, sValeur, sUnite, sFormat)) ;
                }
              }

            }
          }
        } // end while
        bIncrIter = false ;
      }


      if (bIncrIter)
        (*pIter)++ ;
    }
    else
      (*pIter)++;
  } // Fin de l'�num�ration des param�tres de l'objectif

	initPresetIntervals() ;
}

void
NSLdvGoal::initJalons()
{
try
{
	pJalons->vider() ;

	// Si pas ouvert, on sort
	if (tOuvertLe.estVide())
		return ;

	// Si refus� (ferm� avant (ou en m�me temps) que son ouverture, on sort
	if ((!(tFermeLe.estVide())) && (tOuvertLe >= tFermeLe))
		return ;

	string sDateOuvert = tOuvertLe.donneDate() ;
	NSLdvGoalInfo::JALONSLEVELS iLastValueLevel = NSLdvGoalInfo::None ;

	// Premier jalon : ouverture correspond � tOuvertLe
  //
	NSLdvGoalInfo *pOpenInfo    = new NSLdvGoalInfo() ;

	pOpenInfo->sGoalReference   = sReference ;
	pOpenInfo->iTypeJalonEvent  = NSLdvGoalInfo::jalonOuverture ;
	pOpenInfo->iTypeJalon       = NSLdvGoalInfo::jalonDebut ;

	// Si l'objectif n'est pas cyclique, on d�termine la couleur du jalon
	// d'ouverture, en fonction des dates de d�but
	//                          AVrouge = 1, AVjaune, AVvert, Bleu, APvert, APjaune, AProuge
	if (iRythme == NSLdvGoal::ponctuel)
	{
		// TimeLevel
		/*
		if      ((sDateDebutCritique    != "")  && (sDateDebutCritique    <= sDateOuvert))
			pOpenInfo->iTimeLevel = NSLdvGoalInfo::AProuge ;
		else if ((sDateDebutConseilMax  != "")  && (sDateDebutConseilMax  <= sDateOuvert))
			pOpenInfo->iTimeLevel = NSLdvGoalInfo::APjaune ;
		else if ((sDateDebutIdealMax    != "")  && (sDateDebutIdealMax    <= sDateOuvert))
			pOpenInfo->iTimeLevel = NSLdvGoalInfo::APvert ;
		else if ((sDateDebutIdeal       != "")  && (sDateDebutIdeal       <= sDateOuvert))
			pOpenInfo->iTimeLevel = NSLdvGoalInfo::Bleu ;
		else if ((sDateDebutConseille   != "")  && (sDateDebutConseille   <= sDateOuvert))
			pOpenInfo->iTimeLevel = NSLdvGoalInfo::AVvert ;
		else if ((sDateDebutAutorise    != "")  && (sDateDebutAutorise    <= sDateOuvert))
			pOpenInfo->iTimeLevel = NSLdvGoalInfo::AVjaune ;
		else
			pOpenInfo->iTimeLevel = NSLdvGoalInfo::AVrouge ;
		*/

    pOpenInfo->iTimeLevel = getColorForPonctualDate(sDateOuvert) ;

		// ValueLevel
		if (bValueOuverture)
			pOpenInfo->iValueLevel  = getValueLevel(sValueOuverture, sUnitOuverture, &iLastValueLevel) ;
	}

	if (sOpenEventNode != "")
		pOpenInfo->sEventNode = sOpenEventNode ;

	pOpenInfo->tpsInfo      = tOuvertLe ;
	pOpenInfo->tpsClosed    = tOuvertLe ;
	pOpenInfo->sValue       = sValueOuverture ;
	pOpenInfo->dValue       = dValueOuverture ;
	pOpenInfo->sUnit        = sUnitOuverture ;

	// dans le cas d'un objectif permanent, on suppose qu'� l'ouverture l'objectif
	// n'est pas rempli ; si le premier reseter est <= ouverture, on le remet �
	// bleu plus bas
	//
	// in the case of a permanent goal, we suppose that the goal is not realized
	// at opening
	//
	if (iRythme == NSLdvGoal::permanent)
		pOpenInfo->iTimeLevel = NSLdvGoalInfo::AProuge ;

	pOpenInfo->computeLevel() ;

	pJalons->push_back(pOpenInfo) ;

	// Objectif cyclique, on va de reseter en reseter
	// Cyclic goal : we go from one reseter event to the other
	if (iRythme == NSLdvGoal::cyclic)
	{
        // R�cup�ration des reseters
        // Asking for this goal's reseter events
		NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

        VecteurString *pVecteurString = new VecteurString() ;
        pGraphe->TousLesVrais(sReference, NSRootLink::goalReseter, pVecteurString, "ENVERS") ;

        VecteurString *pVecteurDates  = new VecteurString() ;

        if (!pVecteurString->empty())
        {
            // On remplace les noeuds par leur date
            EquiItemIter strIter = pVecteurString->begin() ;
            for ( ; strIter != pVecteurString->end() ; strIter++)
            {
                string sDateDoc = getNodeDate(*(*strIter)) ;
                // sDateDoc = Date ou ""
                pVecteurDates->push_back(new string(sDateDoc)) ;
            }

            // On cr�e les jalons de reset, par ordre chronologique
            while (!(pVecteurDates->empty()))
            {
                string sDateMin             = "ZZZZ" ;
                EquiItemIter dateIter       = pVecteurDates->begin() ;
                EquiItemIter theDateIter    = pVecteurDates->begin() ;
                EquiItemIter noeudIter      = pVecteurString->begin() ;
                EquiItemIter theNoeudIter   = pVecteurString->begin() ;

                for ( ; dateIter != pVecteurDates->end() ; dateIter++, noeudIter++)
                {
                    if (*(*dateIter) < sDateMin)
                    {
                        sDateMin        = *(*dateIter) ;
                        theDateIter     = dateIter ;
                        theNoeudIter    = noeudIter ;
                    }
                }
                if (sDateMin == "ZZZZ")
                    break ;

                NSLdvGoalInfo *pNewInfo     = new NSLdvGoalInfo() ;

                pNewInfo->sGoalReference    = sReference ;
                pNewInfo->iTypeJalonEvent   = NSLdvGoalInfo::jalonCycle ;
                pNewInfo->iTypeJalon        = NSLdvGoalInfo::jalonDebut ;
                pNewInfo->iTimeLevel        = NSLdvGoalInfo::AVrouge ;

                double  dValue ;
                string  sValue ;
                string  sUnit ;
                if (getNodeValue(*(*theNoeudIter), &sValue, &dValue))
                {
                    sUnit                   = getNodeUnit(*(*theNoeudIter)) ;
                    pNewInfo->iValueLevel   = getValueLevel(sValue, sUnit, &iLastValueLevel) ;
                }

                pNewInfo->computeLevel() ;

                pNewInfo->sEventNode        = *(*theNoeudIter) ;
                pNewInfo->tpsInfo.initFromDate(sDateMin) ;
                // L'�v�nement est consid�r� comme ponctuel
                pNewInfo->tpsClosed.initFromDate(sDateMin) ;

                pNewInfo->dValue            = dValue ;
                pNewInfo->sValue            = sValue ;
                pNewInfo->sUnit             = sUnit ;

                pJalons->push_back(pNewInfo) ;

                delete *theNoeudIter ;
                pVecteurString->erase(theNoeudIter) ;

                delete *theDateIter ;
                pVecteurDates->erase(theDateIter) ;
            }
        }
        delete pVecteurString ;
        delete pVecteurDates ;
    }

    // objectif permanent, utilis� dans le m�dicament, ce que l'on veut traduire
    // par un objectif de ce type de rythme est que lorsqu'un objectif consiste �
    // prescrire un m�dicament, ce m�dicament doit �tre prescrit en "permanence"
    //
    // Permanent Goal, it is used in drug oriented goal, this type of goals is
    // used when we want a goal that consists of a drug administration, the drug
    // which has to be prescript, must be present "permanently" in the current
    // patient's drug prescription
    if (iRythme == NSLdvGoal::permanent)
    {
        // R�cup�ration des reseters et des alarms
        // Asking for this goal's reseter and alarm events
			NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

        VecteurString *pVSReset     = new VecteurString() ;
        VecteurString *pVSAlarm     = new VecteurString() ;
        pGraphe->TousLesVrais(sReference, NSRootLink::goalReseter,  pVSReset, "ENVERS") ;
        pGraphe->TousLesVrais(sReference, NSRootLink::goalAlarm,    pVSAlarm, "ENVERS") ;

        VecteurString *pVDateReset  = new VecteurString() ;
        VecteurString *pVDateAlarm  = new VecteurString() ;

        if (!pVSReset->empty() || !pVSAlarm->empty())
        {
            // On recherche les dates correspondant aux noeuds
            // searching date from nodes

            if (!(pVSReset->empty()))
            {
                EquiItemIter  resetIter = pVSReset->begin() ;
                for ( ; resetIter != pVSReset->end() ; resetIter++)
                {
                    string sDateDoc = getNodeDate(*(*resetIter)) ;
                    // sDateDoc = Date ou ""
                    pVDateReset->push_back(new string(sDateDoc)) ;
                }
            }
            if (!(pVSAlarm->empty()))
            {
                EquiItemIter  alarmIter = pVSAlarm->begin() ;
                for ( ; alarmIter != pVSAlarm->end() ; alarmIter++)
                {
                    string sDateDoc = getNodeDate(*(*alarmIter)) ;
                    // sDateDoc = Date ou ""
                    pVDateAlarm->push_back(new string(sDateDoc)) ;
                }
            }

            int   iResetCpt = 0 ;

            // On cr�e les jalons, par ordre chronologique
            // Creating "jalons", in chronological order
            while (!(pVDateReset->empty()) || !(pVDateAlarm->empty()))
            {
                string        sDateMin      = "ZZZZ" ;
                EquiItemIter  dateResetIter = pVDateReset->begin() ;
                EquiItemIter  dateAlarmIter = pVDateAlarm->begin() ;
                EquiItemIter  theDateIter   = NULL ;
                EquiItemIter  nodeResetIter = pVSReset->begin() ;
                EquiItemIter  nodeAlarmIter = pVSAlarm->begin() ;
                EquiItemIter  theNodeIter   = NULL ;
                bool          bResetNode    = false ;
                bool          bAlarmNode    = false ;

                // on recherche le plus ancien dans les reseters
                // searching in reseters the older one
                for ( ; dateResetIter != pVDateReset->end() ; dateResetIter++, nodeResetIter++)
                {
                    if (*(*dateResetIter) < sDateMin)
                    {
                        sDateMin    = *(*dateResetIter) ;
                        theDateIter = dateResetIter ;
                        theNodeIter = nodeResetIter ;
                        bAlarmNode  = false ;
                        bResetNode  = true ;
                    }
                }

                // on recherche si un alarm n'est pas plus ancien
                // searching in alarms an older one
                for ( ; dateAlarmIter != pVDateAlarm->end() ; dateAlarmIter++, nodeAlarmIter++)
                {
                    if (*(*dateAlarmIter) < sDateMin)
                    {
                        sDateMin    = *(*dateAlarmIter) ;
                        theDateIter = dateAlarmIter ;
                        theNodeIter = nodeAlarmIter ;
                        bResetNode  = false ;
                        bAlarmNode  = true ;
                    }
                }

                // si le plus ancien trouv� est un reseters on incr�mente le compteur
                // si c'est un alarm, on le d�cremente
                if      (bResetNode)
                    iResetCpt++ ;
                else if (bAlarmNode)
                    iResetCpt-- ;

                // Eventuellement, on remet � jour pOpenInfo->iTimeLevel
                //
                if (sDateMin <= pOpenInfo->tpsInfo.donneDateHeure())
                {
                    if (iResetCpt > 0)
                        pOpenInfo->iTimeLevel  = NSLdvGoalInfo::Bleu ;
                    else
                        pOpenInfo->iTimeLevel  = NSLdvGoalInfo::AProuge ;
                    pOpenInfo->computeLevel() ;
                }

                if (sDateMin == "ZZZZ")
                    break ;

                NSLdvGoalInfo *pNewInfo     = new NSLdvGoalInfo() ;

                pNewInfo->sGoalReference    = sReference ;
                pNewInfo->iTypeJalonEvent   = NSLdvGoalInfo::jalonCycle ;
                pNewInfo->iTypeJalon        = NSLdvGoalInfo::jalonDebut ;

                if (iResetCpt > 0)
                    pNewInfo->iTimeLevel  = NSLdvGoalInfo::Bleu ;
                else
                    pNewInfo->iTimeLevel  = NSLdvGoalInfo::AProuge ;

                double        dValue ;
                string        sValue ;
                string        sUnit ;
                if (getNodeValue(*(*theNodeIter), &sValue, &dValue))
                {
                    sUnit                   = getNodeUnit(*(*theNodeIter)) ;
                    pNewInfo->iValueLevel   = getValueLevel(sValue, sUnit, &iLastValueLevel) ;
                }

                pNewInfo->computeLevel() ;

                pNewInfo->sEventNode        = *(*theNodeIter) ;
                pNewInfo->tpsInfo.initFromDate(sDateMin) ;
                // L'�v�nement est consid�r� comme ponctuel
                pNewInfo->tpsClosed.initFromDate(sDateMin) ;

                pNewInfo->dValue            = dValue ;
                pNewInfo->sValue            = sValue ;
                pNewInfo->sUnit             = sUnit ;

                pJalons->push_back(pNewInfo) ;

                if (bResetNode)
                {
                    // le noeud appartient � la liste des noeuds reseter
                    // current node is part of reseter node list
                    delete (*theNodeIter) ;
                    pVSReset->erase(theNodeIter) ;

                    delete (*theDateIter) ;
                    pVDateReset->erase(theDateIter) ;
                }
                else if (bAlarmNode)
                {
                    // le noeud appartient � la liste des noeuds alarm
                    // current node is part of alarm node list
                    delete (*theNodeIter) ;
                    pVSAlarm->erase(theNodeIter) ;

                    delete (*theDateIter) ;
                    pVDateAlarm->erase(theDateIter) ;
                }
            }
        }
/*
    else
    {
      NSLdvGoalInfo *pNewInfo     = new NSLdvGoalInfo() ;

      pNewInfo->sGoalReference    = sReference ;
      pNewInfo->iTypeJalonEvent   = NSLdvGoalInfo::jalonCycle ;
      pNewInfo->iTypeJalon        = NSLdvGoalInfo::jalonDebut ;

      pNewInfo->iTimeLevel        = NSLdvGoalInfo::AProuge ;

      int           iValue ;
      string        sValue ;
      string        sUnit ;

      pNewInfo->computeLevel() ;

      pNewInfo->sEventNode        = NULL ;
      pNewInfo->tpsInfo.initFromDate(sDateMin) ;
      // L'�v�nement est consid�r� comme ponctuel
      pNewInfo->tpsClosed.initFromDate(sDateMin) ;

      pNewInfo->iValue            = iValue ;
      pNewInfo->sValue            = sValue ;
      pNewInfo->sUnit             = sUnit ;

      pJalons->push_back(pNewInfo) ;
    }
*/
    	delete pVSReset ;
    	delete pVSAlarm ;
    	delete pVDateReset ;
    	delete pVDateAlarm ;
	}

  // Dernier jalon : fermeture
  if (!(tFermeLe.estVide()))
  {
    NSLdvGoalInfo *pCloseInfo     = new NSLdvGoalInfo() ;

    pCloseInfo->sGoalReference    = sReference ;
    pCloseInfo->iTypeJalonEvent   = NSLdvGoalInfo::jalonFermeture ;
    pCloseInfo->iTypeJalon        = NSLdvGoalInfo::jalonDebut ;
    if (sCloseEventNode != "")
      pCloseInfo->sEventNode      = sCloseEventNode ;
    pCloseInfo->tpsInfo           = tFermeLe ;
    pCloseInfo->tpsClosed         = tFermeLe ;

    pCloseInfo->dValue            = dValueFermeture ;
    pCloseInfo->sValue            = sValueFermeture ;
    pCloseInfo->sUnit             = sUnitFermeture ;

    pJalons->push_back(pCloseInfo) ;
  }

  // On trie les jalons (ils devraient d�j� l'�tre, mais...)
  sort(pJalons->begin(), pJalons->end(), infGoalInfo) ;

  // Jalons interm�diaires
	if (pJalons->empty())
		return ;

  // Tour de passe-passe interm�diaire : si un jalon pr�c�de le jalon de
  // d�but, il devient jalon de d�but
  GoalInfoIter itGoals = pJalons->begin() ;
  if ((*itGoals)->iTypeJalonEvent != NSLdvGoalInfo::jalonOuverture)
  {
    (*itGoals)->iTypeJalonEvent = NSLdvGoalInfo::jalonOuvreCycle ;
    itGoals++ ;

    // On supprime le jalon d'ouverture
    for ( ; (itGoals != pJalons->end()) && ((*itGoals)->iTypeJalonEvent != NSLdvGoalInfo::jalonOuverture) ; itGoals++)
      ;

    if (itGoals != pJalons->end())
    {
      delete *itGoals ;
      pJalons->erase(itGoals) ;
    }
  }

	// Objectif ponctuel : on pose les jalons interm�diaires apr�s
  // la date d'ouverture, et jusqu'� l'�ventuelle date de fermeture
  //
  if (iRythme == NSLdvGoal::ponctuel)
	{
  	// Recherche du jalon d'ouverture - Looking for opening bookmark
    //
  	GoalInfoIter itGoalsBegin = pJalons->begin() ;
  	for ( ; (itGoalsBegin != pJalons->end()) &&
          ((*itGoalsBegin)->iTypeJalonEvent != NSLdvGoalInfo::jalonOuverture) ;
  					itGoalsBegin++) ;
		if (itGoalsBegin != pJalons->end())
		{
			// Recherche du jalon de fermeture - Looking for closing bookmark
    	//
			itGoals = pJalons->begin() ;
  		for ( ; (itGoals != pJalons->end()) &&
          ((*itGoals)->iTypeJalonEvent != NSLdvGoalInfo::jalonFermeture) ;
  					itGoals++) ;

    	if (itGoals != pJalons->end())
      	initPostDateInterJalons(*itGoalsBegin, (*itGoals)->tpsInfo) ;
			else
      {
      	NVLdVTemps tpsInfinite ;
        tpsInfinite.setNoLimit() ;
        initPostDateInterJalons(*itGoalsBegin, tpsInfinite) ;
			}
		}
	}

	if (iRythme == NSLdvGoal::cyclic)
	{
  	// Recherche du jalon d'ouverture - Looking for opening bookmark
    //
  	itGoals = pJalons->begin() ;
  	for ( ; (itGoals != pJalons->end()) &&
          ((*itGoals)->iTypeJalonEvent != NSLdvGoalInfo::jalonOuverture) ;
  					itGoals++) ;
		if (itGoals != pJalons->end())
		{
    	NSLdvGoalInfo* pRefJalon = *itGoals ;

      itGoals++ ;

      for ( ; (itGoals != pJalons->end()) &&
          ((*itGoals)->iTypeJalonEvent != NSLdvGoalInfo::jalonIntermediaire) &&
          ((*itGoals)->iTypeJalonEvent != NSLdvGoalInfo::jalonFermeture) ; itGoals++)
      {
      	initInterDelayJalons(pRefJalon, (*itGoals)->tpsInfo) ;
        pRefJalon = *itGoals ;
      }

      if ((itGoals != pJalons->end()) &&
          ((*itGoals)->iTypeJalonEvent == NSLdvGoalInfo::jalonFermeture))
    		initInterDelayJalons(pRefJalon, (*itGoals)->tpsInfo) ;
      else
      {
      	NVLdVTemps tpsInfinite ;
        tpsInfinite.setNoLimit() ;
        initInterDelayJalons(pRefJalon, tpsInfinite) ;
			}
		}
	}

/*
  itGoals = pJalons->begin() ;
  for ( ; (itGoals != pJalons->end()) &&
          ((*itGoals)->iTypeJalonEvent != NSLdvGoalInfo::jalonIntermediaire) &&
          ((*itGoals)->iTypeJalonEvent != NSLdvGoalInfo::jalonFermeture) ; itGoals++)
  {
    // Les dates fixes sont cr��es par rapport au jalon d'ouverture
    if ((*itGoals)->iTypeJalonEvent == NSLdvGoalInfo::jalonOuverture)
    {

      // cr�ation des jalons interm�diaires situ�s entre ce jalon et la date d'ouverture
      // we create the intermediate bookmarks situated between this one and the opening date

      // Jalon D�but autoris�

      // La date d'ouverture de l'objectif est plus ancienne que la date de d�but autoris�
      //
      if ((sDateDebutAutorise != "") && (sDateDebutAutorise > sDateOuvert))
      {
        tpsBuff.initFromDate(sDateDebutAutorise) ;

        if (tpsBuff <= (*itGoals)->tpsInfo)
        {
          (*itGoals)->iTimeLevel      = NSLdvGoalInfo::AVjaune ;
          (*itGoals)->iValueLevel     = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
          (*itGoals)->computeLevel() ;
        }
        else
        {
          NSLdvGoalInfo *pCloseInfo   = new NSLdvGoalInfo() ;

          pCloseInfo->sGoalReference  = sReference ;
          pCloseInfo->iTypeJalonEvent = NSLdvGoalInfo::jalonIntermediaire ;
          pCloseInfo->iTypeJalon      = NSLdvGoalInfo::jalonDebut ;
          pCloseInfo->iTimeLevel      = NSLdvGoalInfo::AVjaune ;
          pCloseInfo->iValueLevel     = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
          pCloseInfo->dValue          = (*itGoals)->dValue ;
          pCloseInfo->sValue          = (*itGoals)->sValue ;
          pCloseInfo->sUnit           = (*itGoals)->sUnit ;
          pCloseInfo->tpsInfo         = tpsBuff ;

          pCloseInfo->computeLevel() ;

          pJalons->push_back(pCloseInfo) ;
        }
      }

      // Jalon D�but conseill�
      if ((sDateDebutConseille != "") && (sDateDebutConseille > sDateOuvert))
      {
        tpsBuff.initFromDate(sDateDebutConseille) ;

        if (tpsBuff <= (*itGoals)->tpsInfo)
        {
          (*itGoals)->iTimeLevel      = NSLdvGoalInfo::AVvert ;
          (*itGoals)->iValueLevel     = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
          (*itGoals)->computeLevel() ;
        }
        else
        {
          NSLdvGoalInfo *pCloseInfo   = new NSLdvGoalInfo() ;

          pCloseInfo->sGoalReference  = sReference ;
          pCloseInfo->iTypeJalonEvent = NSLdvGoalInfo::jalonIntermediaire ;
          pCloseInfo->iTypeJalon      = NSLdvGoalInfo::jalonDebut ;
          pCloseInfo->iTimeLevel      = NSLdvGoalInfo::AVvert ;
          pCloseInfo->iValueLevel     = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
          pCloseInfo->dValue          = (*itGoals)->dValue ;
          pCloseInfo->sValue          = (*itGoals)->sValue ;
          pCloseInfo->sUnit           = (*itGoals)->sUnit ;
          pCloseInfo->tpsInfo         = tpsBuff ;

          pCloseInfo->computeLevel() ;

          pJalons->push_back(pCloseInfo) ;
        }
      }

      // Jalon D�but id�al
      if ((sDateDebutIdeal != "") && (sDateDebutIdeal > sDateOuvert))
      {
        tpsBuff.initFromDate(sDateDebutIdeal) ;

        if (tpsBuff <= (*itGoals)->tpsInfo)
        {
          (*itGoals)->iTimeLevel      = NSLdvGoalInfo::Bleu ;
          (*itGoals)->iValueLevel     = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
          (*itGoals)->computeLevel() ;
        }
        else
        {
          NSLdvGoalInfo *pCloseInfo   = new NSLdvGoalInfo() ;

          pCloseInfo->sGoalReference  = sReference ;
          pCloseInfo->iTypeJalonEvent = NSLdvGoalInfo::jalonIntermediaire ;
          pCloseInfo->iTypeJalon      = NSLdvGoalInfo::jalonDebut ;
          pCloseInfo->iTimeLevel      = NSLdvGoalInfo::Bleu ;
          pCloseInfo->iValueLevel     = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
          pCloseInfo->dValue          = (*itGoals)->dValue ;
          pCloseInfo->sValue          = (*itGoals)->sValue ;
          pCloseInfo->sUnit           = (*itGoals)->sUnit ;
          pCloseInfo->tpsInfo         = tpsBuff ;

          pCloseInfo->computeLevel() ;

          pJalons->push_back(pCloseInfo) ;
        }
      }

      // Jalon D�but id�al maximum
      if ((sDateDebutIdealMax != "") && (sDateDebutIdealMax > sDateOuvert))
      {
        tpsBuff.initFromDate(sDateDebutIdealMax) ;

        if (tpsBuff > (*itGoals)->tpsInfo)
        {
          NSLdvGoalInfo *pCloseInfo   = new NSLdvGoalInfo() ;

          pCloseInfo->sGoalReference  = sReference ;
          pCloseInfo->iTypeJalonEvent = NSLdvGoalInfo::jalonIntermediaire ;
          pCloseInfo->iTypeJalon      = NSLdvGoalInfo::jalonDebut ;
          pCloseInfo->iTimeLevel      = NSLdvGoalInfo::APvert ;
          pCloseInfo->iValueLevel     = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
          pCloseInfo->dValue          = (*itGoals)->dValue ;
          pCloseInfo->sValue          = (*itGoals)->sValue ;
          pCloseInfo->sUnit           = (*itGoals)->sUnit ;
          pCloseInfo->tpsInfo         = tpsBuff ;

          pCloseInfo->computeLevel() ;

          pJalons->push_back(pCloseInfo) ;
        }
      }

      // Jalon D�but conseill� maximum
      if ((sDateDebutConseilMax != "") && (sDateDebutConseilMax > sDateOuvert))
      {
        tpsBuff.initFromDate(sDateDebutConseilMax) ;

        if (tpsBuff > (*itGoals)->tpsInfo)
        {
          NSLdvGoalInfo *pCloseInfo   = new NSLdvGoalInfo() ;

          pCloseInfo->sGoalReference  = sReference ;
          pCloseInfo->iTypeJalonEvent = NSLdvGoalInfo::jalonIntermediaire ;
          pCloseInfo->iTypeJalon      = NSLdvGoalInfo::jalonDebut ;
          pCloseInfo->iTimeLevel      = NSLdvGoalInfo::APjaune ;
          pCloseInfo->iValueLevel     = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
          pCloseInfo->dValue          = (*itGoals)->dValue ;
          pCloseInfo->sValue          = (*itGoals)->sValue ;
          pCloseInfo->sUnit           = (*itGoals)->sUnit ;
          pCloseInfo->tpsInfo         = tpsBuff ;

          pCloseInfo->computeLevel() ;

          pJalons->push_back(pCloseInfo) ;
        }
      }

      // Jalon D�but critique
      if ((sDateDebutCritique != "")  && (sDateDebutCritique > sDateOuvert))
      {
        tpsBuff.initFromDate(sDateDebutCritique) ;

        if (tpsBuff > (*itGoals)->tpsInfo)
        {
          NSLdvGoalInfo *pCloseInfo   = new NSLdvGoalInfo() ;

          pCloseInfo->sGoalReference  = sReference ;
          pCloseInfo->iTypeJalonEvent = NSLdvGoalInfo::jalonIntermediaire ;
          pCloseInfo->iTypeJalon      = NSLdvGoalInfo::jalonDebut ;
          pCloseInfo->iTimeLevel      = NSLdvGoalInfo::AProuge ;
          pCloseInfo->iValueLevel     = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
          pCloseInfo->dValue          = (*itGoals)->dValue ;
          pCloseInfo->sValue          = (*itGoals)->sValue ;
          pCloseInfo->sUnit           = (*itGoals)->sUnit ;
          pCloseInfo->tpsInfo         = tpsBuff ;

          pCloseInfo->computeLevel() ;

          pJalons->push_back(pCloseInfo) ;
        }
      }
    }

    // Dur�es
    bool bNextGoal = false ;
    GoalInfoIter itNextGoals = itGoals ;
    if (itNextGoals != pJalons->end())
    {
      itNextGoals++ ;
      if ((itNextGoals != pJalons->end()) && ((*itNextGoals)->iTypeJalonEvent != NSLdvGoalInfo::jalonIntermediaire))
        bNextGoal = true ;
    }

    // Jalon D�but autoris�
    if (dDelaiDebutAutorise > 0)
    {
      tpsBuff = (*itGoals)->tpsInfo ;
      tpsBuff.ajouteTemps(int(dDelaiDebutAutorise), sUniteDebutAutorise, pContexte);

      if ((!bNextGoal) || (bNextGoal && ((*itNextGoals)->tpsInfo > tpsBuff)))
      {
        NSLdvGoalInfo *pNewInfo     = new NSLdvGoalInfo() ;

        pNewInfo->sGoalReference    = sReference ;
        pNewInfo->iTypeJalonEvent   = NSLdvGoalInfo::jalonIntermediaire ;
        pNewInfo->iTypeJalon        = NSLdvGoalInfo::jalonDebut ;
        pNewInfo->iTimeLevel        = NSLdvGoalInfo::AVjaune ;
        pNewInfo->iValueLevel       = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
        pNewInfo->dValue            = (*itGoals)->dValue ;
        pNewInfo->sValue            = (*itGoals)->sValue ;
        pNewInfo->sUnit             = (*itGoals)->sUnit ;
        pNewInfo->tpsInfo           = tpsBuff ;

        pNewInfo->computeLevel() ;

        pJalons->push_back(pNewInfo) ;
      }
    }
    else if (dDelaiDebutAutorise == 0)
    {
      (*itGoals)->iTimeLevel        = NSLdvGoalInfo::AVjaune ;
      (*itGoals)->iValueLevel       = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
      (*itGoals)->computeLevel() ;
    }

    // Jalon D�but conseill�
    if (dDelaiDebutConseille > 0)
    {
      tpsBuff = (*itGoals)->tpsInfo ;
      tpsBuff.ajouteTemps(int(dDelaiDebutConseille), sUniteDebutConseille, pContexte) ;

      if ((!bNextGoal) || (bNextGoal && ((*itNextGoals)->tpsInfo > tpsBuff)))
      {
        NSLdvGoalInfo *pNewInfo     = new NSLdvGoalInfo() ;

        pNewInfo->sGoalReference    = sReference ;
        pNewInfo->iTypeJalonEvent   = NSLdvGoalInfo::jalonIntermediaire ;
        pNewInfo->iTypeJalon        = NSLdvGoalInfo::jalonDebut ;
        pNewInfo->iTimeLevel        = NSLdvGoalInfo::AVvert ;
        pNewInfo->iValueLevel       = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
        pNewInfo->dValue            = (*itGoals)->dValue ;
        pNewInfo->sValue            = (*itGoals)->sValue ;
        pNewInfo->sUnit             = (*itGoals)->sUnit ;
        pNewInfo->tpsInfo           = tpsBuff ;

        pNewInfo->computeLevel() ;

        pJalons->push_back(pNewInfo) ;
      }
    }
    else if (dDelaiDebutConseille == 0)
    {
      (*itGoals)->iTimeLevel        = NSLdvGoalInfo::AVvert ;
      (*itGoals)->iValueLevel       = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
      (*itGoals)->computeLevel() ;
    }

    // Jalon D�but id�al
    if (dDelaiDebutIdeal > 0)
    {
      tpsBuff = (*itGoals)->tpsInfo ;
      tpsBuff.ajouteTemps(int(dDelaiDebutIdeal), sUniteDebutIdeal, pContexte);

      if ((!bNextGoal) || (bNextGoal && ((*itNextGoals)->tpsInfo > tpsBuff)))
      {
        NSLdvGoalInfo *pNewInfo     = new NSLdvGoalInfo() ;

        pNewInfo->sGoalReference    = sReference ;
        pNewInfo->iTypeJalonEvent   = NSLdvGoalInfo::jalonIntermediaire ;
        pNewInfo->iTypeJalon        = NSLdvGoalInfo::jalonDebut ;
        pNewInfo->iTimeLevel        = NSLdvGoalInfo::Bleu ;
        pNewInfo->iValueLevel       = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
        pNewInfo->dValue            = (*itGoals)->dValue ;
        pNewInfo->sValue            = (*itGoals)->sValue ;
        pNewInfo->sUnit             = (*itGoals)->sUnit ;
        pNewInfo->tpsInfo           = tpsBuff ;

        pNewInfo->computeLevel() ;

        pJalons->push_back(pNewInfo) ;
      }
    }
    else if (dDelaiDebutIdeal == 0)
    {
      (*itGoals)->iTimeLevel        = NSLdvGoalInfo::Bleu ;
      (*itGoals)->iValueLevel       = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
      (*itGoals)->computeLevel() ;
    }

    // Jalon D�but id�al maximum
    if (dDelaiDebutIdealMax > 0)
    {
      tpsBuff = (*itGoals)->tpsInfo ;
      tpsBuff.ajouteTemps(int(dDelaiDebutIdealMax), sUniteDebutIdealMax, pContexte);

      if ((!bNextGoal) || (bNextGoal && ((*itNextGoals)->tpsInfo > tpsBuff)))
      {
        NSLdvGoalInfo *pNewInfo     = new NSLdvGoalInfo() ;

        pNewInfo->sGoalReference    = sReference ;
        pNewInfo->iTypeJalonEvent   = NSLdvGoalInfo::jalonIntermediaire ;
        pNewInfo->iTypeJalon        = NSLdvGoalInfo::jalonDebut ;
        pNewInfo->iTimeLevel        = NSLdvGoalInfo::APvert ;
        pNewInfo->iValueLevel       = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
        pNewInfo->dValue            = (*itGoals)->dValue ;
        pNewInfo->sValue            = (*itGoals)->sValue ;
        pNewInfo->sUnit             = (*itGoals)->sUnit ;
        pNewInfo->tpsInfo           = tpsBuff ;

        pNewInfo->computeLevel() ;

        pJalons->push_back(pNewInfo) ;
      }
    }

    // Jalon D�but conseill� maximum
    if (dDelaiDebutConseilMax > 0)
    {
      tpsBuff = (*itGoals)->tpsInfo ;
      tpsBuff.ajouteTemps(int(dDelaiDebutConseilMax), sUniteDebutConseilMax, pContexte);

      if ((!bNextGoal) || (bNextGoal && ((*itNextGoals)->tpsInfo > tpsBuff)))
      {
        NSLdvGoalInfo *pNewInfo     = new NSLdvGoalInfo() ;

        pNewInfo->sGoalReference    = sReference ;
        pNewInfo->iTypeJalonEvent   = NSLdvGoalInfo::jalonIntermediaire ;
        pNewInfo->iTypeJalon        = NSLdvGoalInfo::jalonDebut ;
        pNewInfo->iTimeLevel        = NSLdvGoalInfo::APjaune ;
        pNewInfo->iValueLevel       = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
        pNewInfo->dValue            = (*itGoals)->dValue ;
        pNewInfo->sValue            = (*itGoals)->sValue ;
        pNewInfo->sUnit             = (*itGoals)->sUnit ;
        pNewInfo->tpsInfo           = tpsBuff ;

        pNewInfo->computeLevel() ;

        pJalons->push_back(pNewInfo) ;
      }
    }

    // Jalon D�but critique
    if (dDelaiDebutCritique > 0)
    {
      tpsBuff = (*itGoals)->tpsInfo ;
      tpsBuff.ajouteTemps(int(dDelaiDebutCritique), sUniteDebutCritique, pContexte);

      if ((!bNextGoal) || (bNextGoal && ((*itNextGoals)->tpsInfo > tpsBuff)))
      {
        NSLdvGoalInfo *pNewInfo     = new NSLdvGoalInfo() ;

        pNewInfo->sGoalReference    = sReference ;
        pNewInfo->iTypeJalonEvent   = NSLdvGoalInfo::jalonIntermediaire ;
        pNewInfo->iTypeJalon        = NSLdvGoalInfo::jalonDebut ;
        pNewInfo->iTimeLevel        = NSLdvGoalInfo::AProuge ;
        pNewInfo->iValueLevel       = getValueLevel((*itGoals)->sValue, (*itGoals)->sUnit, &iLastValueLevel) ;
        pNewInfo->dValue            = (*itGoals)->dValue ;
        pNewInfo->sValue            = (*itGoals)->sValue ;
        pNewInfo->sUnit             = (*itGoals)->sUnit ;
        pNewInfo->tpsInfo           = tpsBuff ;

        pNewInfo->computeLevel() ;

        pJalons->push_back(pNewInfo) ;
      }
    }
  }
*/

  // On trie les jalons
  sort(pJalons->begin(), pJalons->end(), infGoalInfo) ;

  // On initialise la date de fermeture des jalons
  GoalInfoIter closingIt ;
  for (GoalInfoIter jalonIt = pJalons->begin() ; jalonIt != pJalons->end() ; jalonIt++)
  {
    // On initialise la date de fermeture du jalon
    closingIt = pJalons->getClosingJalon(jalonIt) ;

    if (closingIt != pJalons->end())
      (*jalonIt)->tpsClosed = (*closingIt)->tpsInfo ;
    else
      (*jalonIt)->tpsClosed.setNoLimit() ;
  }

  // Initialisation des Meta-jalons
  initMetaJalons() ;
}
catch (...)
{
	erreur("Exception NSLdvGoal::initJalons.", standardError, 0) ;
}
}

void
NSLdvGoal::initPostDateInterJalons(NSLdvGoalInfo* pRefJalon, NVLdVTemps tpsNextJalonDate)
{
	// Si la date de r�f�rence est d�j� AProuge, on n'a pas de jalons
  // interm�diaires au del�
	//
	NSLdvGoalInfo::JALONSLEVELS iLevel = getColorForPonctualDate(pRefJalon->tpsInfo.donneDateHeure()) ;
	if ((iLevel == NSLdvGoalInfo::None) || (iLevel == NSLdvGoalInfo::AProuge))
		return ;

	iLevel = pRefJalon->getNextColor(iLevel) ;

	bool bTourner = true ;
	while (bTourner)
	{
  	NSDateZone* pDateZone = aDateZones.getZone(iLevel) ;
    if (pDateZone)
		{
    	NVLdVTemps tpsLow  = pDateZone->getLowDate() ;
      NVLdVTemps tpsHigh = pDateZone->getHighDate() ;
      if (tpsLow > tpsNextJalonDate)
				return ;

      if (tpsLow >= pRefJalon->tpsInfo)
      {
      	NSLdvGoalInfo::JALONSLEVELS iLastValueLevel ;

      	NSLdvGoalInfo *pNewInfo     = new NSLdvGoalInfo() ;

        pNewInfo->sGoalReference    = sReference ;
        pNewInfo->iTypeJalonEvent   = NSLdvGoalInfo::jalonIntermediaire ;
        pNewInfo->iTypeJalon        = NSLdvGoalInfo::jalonDebut ;
        pNewInfo->iTimeLevel        = iLevel ;
        pNewInfo->iValueLevel       = getValueLevel(pRefJalon->sValue, pRefJalon->sUnit, &iLastValueLevel) ;
        pNewInfo->dValue            = pRefJalon->dValue ;
        pNewInfo->sValue            = pRefJalon->sValue ;
        pNewInfo->sUnit             = pRefJalon->sUnit ;
        pNewInfo->tpsInfo           = tpsLow ;

        pNewInfo->computeLevel() ;

        pJalons->push_back(pNewInfo) ;
      }
		}
    iLevel = pRefJalon->getNextColor(iLevel) ;
    if (iLevel == NSLdvGoalInfo::None)
    	bTourner = false ;
	}
}

void
NSLdvGoal::initInterDelayJalons(NSLdvGoalInfo* pRefJalon, NVLdVTemps tpsNextJalonDate)
{
	NSLdvGoalInfo::JALONSLEVELS iLevel = NSLdvGoalInfo::AVrouge ;

	bool bTourner = true ;
	while (bTourner)
	{
  	NSDelayZone* pDelayZone = aDelayZones.getZone(iLevel) ;
    if (pDelayZone)
		{
  		NVLdVTemps tpsBuff = pRefJalon->tpsInfo ;
      tpsBuff.ajouteTemps(int(pDelayZone->dLowDelay), pDelayZone->sLowDelayUnit, pContexte) ;
      if (tpsBuff <= tpsNextJalonDate)
      {
      	NSLdvGoalInfo::JALONSLEVELS iLastValueLevel ;

      	NSLdvGoalInfo *pNewInfo     = new NSLdvGoalInfo() ;

        pNewInfo->sGoalReference    = sReference ;
        pNewInfo->iTypeJalonEvent   = NSLdvGoalInfo::jalonIntermediaire ;
        pNewInfo->iTypeJalon        = NSLdvGoalInfo::jalonDebut ;
        pNewInfo->iTimeLevel        = iLevel ;
        pNewInfo->iValueLevel       = getValueLevel(pRefJalon->sValue, pRefJalon->sUnit, &iLastValueLevel) ;
        pNewInfo->dValue            = pRefJalon->dValue ;
        pNewInfo->sValue            = pRefJalon->sValue ;
        pNewInfo->sUnit             = pRefJalon->sUnit ;
        pNewInfo->tpsInfo           = tpsBuff ;

        pNewInfo->computeLevel() ;

        pJalons->push_back(pNewInfo) ;
      }
		}
    iLevel = pRefJalon->getNextColor(iLevel) ;
    if (iLevel == NSLdvGoalInfo::None)
    	bTourner = false ;
	}
}

void
NSLdvGoal::initMetaJalons()
{
try
{
  if (pJalons->empty())
    return ;

  // Variables qui permettent de savoir quelle est la pire couleur en cours
  // et jusqu'� quand elle est d'actualit�
  NVLdVTemps tpsMaxTimeForColor ;
  tpsMaxTimeForColor.init() ;
  int iColorLevel = -1 ;

  // On �num�re tous les jalons
  for (GoalInfoIter jalonIt = pJalons->begin(); jalonIt != pJalons->end(); )
  {
    // Si le nouveau jalon est plus grave que le plus grave du moment
    // �a devient le plus grave
    //
    // ATTENTION : on ne tient pas compte des jalons "instantan�s"
    //              (moment d'ouverture = moment de fermeture)
    //
    if (((*jalonIt)->iLevel > iColorLevel) && (!((*jalonIt)->tpsClosed == (*jalonIt)->tpsInfo)))
    {
      iColorLevel = (*jalonIt)->iLevel ;

      // On recherche la date de p�remption du jalon
      tpsMaxTimeForColor = (*jalonIt)->tpsClosed ;

      // On v�rifie qu'il n'y a pas d'autres jalons plus graves ou aussi
      // grave mais plus long � la m�me date
      GoalInfoIter refIt = jalonIt ;
      jalonIt++ ;
      while ((jalonIt != pJalons->end()) && ((*jalonIt)->tpsInfo == (*refIt)->tpsInfo))
      {
        if      ((*jalonIt)->iLevel > iColorLevel)
          refIt = jalonIt ;
        else if (((*jalonIt)->iLevel == iColorLevel) && ((*jalonIt)->tpsClosed > tpsMaxTimeForColor))
        {
          tpsMaxTimeForColor = (*jalonIt)->tpsClosed ;
          refIt = jalonIt ;
        }
        jalonIt++ ;
      }

      // On peut maintenant cr�er le nouveau meta-jalon
      NSLdvGoalInfo *pMetaJalon = new NSLdvGoalInfo(**refIt) ;
      pMetaJalons->push_back(pMetaJalon) ;
    }

    // Sinon, on regarde si le nouveau jalon est au del� de tpsMaxTimeForColor
    else if ((*jalonIt)->tpsInfo >= tpsMaxTimeForColor)
    {
      // Le jalon en cours est le premier candidat � la succession
      GoalInfoIter refIt  = jalonIt ;
      iColorLevel         = (*jalonIt)->iLevel ;
      tpsMaxTimeForColor  = (*jalonIt)->tpsClosed ;

      // On doit passer en revue tous les jalons plus anciens ou de
      // m�me date pour voir lequel est susceptible d'imposer sa couleur
      GoalInfoIter jIt = pJalons->begin() ;
      for ( ; (jIt != pJalons->end()) && ((*jIt)->tpsInfo <= (*jalonIt)->tpsInfo) ; jIt++)
      {
        if ((*jIt)->tpsClosed > (*jalonIt)->tpsInfo)
        {
          // Postulant � imposer sa couleur
          if (((*jIt)->iLevel > iColorLevel)    ||
              (((*jIt)->iLevel == iColorLevel)  &&
              ((*jIt)->tpsClosed > tpsMaxTimeForColor)))
          {
            refIt = jIt ;
            iColorLevel         = (*jIt)->iLevel ;
            tpsMaxTimeForColor  = (*jIt)->tpsClosed ;
          }
        }
      }

      // On peut maintenant cr�er le nouveau meta-jalon, avec
      // la date actuelle comme date de d�part
      NSLdvGoalInfo *pMetaJalon = new NSLdvGoalInfo(**refIt) ;
      pMetaJalon->tpsInfo = (*jalonIt)->tpsInfo ;
      pMetaJalons->push_back(pMetaJalon) ;

      jalonIt = jIt ;
    }
    else
      jalonIt++ ;
  }

  // On trie les meta-jalons
  sort(pMetaJalons->begin(), pMetaJalons->end(), infGoalInfo) ;

  // On initialise la date de fermeture des meta-jalons
  GoalInfoIter closingIt ;
  for (GoalInfoIter jalonIt = pMetaJalons->begin() ; jalonIt != pMetaJalons->end() ; jalonIt++)
  {
    // On initialise la date de fermeture du jalon
    closingIt = pMetaJalons->getClosingJalon(jalonIt) ;

    if (closingIt != pMetaJalons->end())
      (*jalonIt)->tpsClosed = (*closingIt)->tpsInfo ;
    else
      (*jalonIt)->tpsClosed.setNoLimit() ;
  }

  // je ne comprends pas pourquoi on faisait ce test, je l'enl�ve
  // don't understand why we test this condition, so I get it out
/*
  if (!bValue)
    return ;
*/

  // les meta-jalons ont �t� cr��s, il faut maintenant cr�er un m�ta-jalon qui
  // correspond � l'instant "now".

  // pour cela on parcourt la liste jusqu'� se trouver � l'emplacement dans la
  // liste o� l'on doit rajouter le meta-jalon "now"
  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

  bool  bInTheFuture = false ;

  for (GoalInfoIter  jalonIt = pMetaJalons->begin() ; jalonIt != pMetaJalons->end() ; jalonIt++)
  {
    if      (((*jalonIt)->tpsClosed >= tpsNow) && (!bInTheFuture))
    {
      if ((*jalonIt)->tpsClosed > tpsNow)
      {
        // on doit cr�er un nouveau jalon
        NSLdvGoalInfo   *pNewJalon = new NSLdvGoalInfo(**jalonIt) ;
        pNewJalon->tpsClosed  = tpsNow ;
        (*jalonIt)->tpsInfo   = tpsNow ;
        jalonIt   = pMetaJalons->insert(jalonIt, pNewJalon) ;
      }
      (*jalonIt)->iTypeJalonEvent = NSLdvGoalInfo::jalonNow ;
      bInTheFuture = true ;
    }

    // on veut modifier les jalons dans le futur pour prendre le iLevel prend la
    // valeur de iTimeLevel
    // on ne prend pas en compte la valeur pour la repr�sentation dans le futur
    else if (bInTheFuture)
      (*jalonIt)->iLevel = (*jalonIt)->iTimeLevel ;
  }

}
catch (...)
{
	erreur("Exception NSLdvGoal::initMetaJalons.", standardError, 0) ;
}
}


// -----------------------------------------------------------------------------
// Pr�venir la pr�occupation � laquelle est rattach�e cet objectif que
// l'objectif existe
// -----------------------------------------------------------------------------
void
NSLdvGoal::initConcern(NSLdvDocument *pDocLdv)
{
  if (!pDocLdv)
    return ;

  pDocLdv->addGoalToConcern(this) ;
}


double
NSLdvGoal::getMeanDelaiInSecond()
{
  int     iNbDelais   = 0 ;
  double  dMeanDelai  = 0 ;

  if ((dDelaiDebutConseille > 0) && (sUniteDebutConseille != ""))
  {
    dMeanDelai += getDelaiInSecond(dDelaiDebutConseille, sUniteDebutConseille) ;
    iNbDelais++ ;
  }
  if ((dDelaiDebutIdeal > 0) && (sUniteDebutIdeal != ""))
  {
    dMeanDelai += getDelaiInSecond(dDelaiDebutIdeal, sUniteDebutIdeal) ;
    iNbDelais++ ;
  }
  if ((dDelaiDebutIdealMax > 0) && (sUniteDebutIdealMax != ""))
  {
    dMeanDelai += getDelaiInSecond(dDelaiDebutIdealMax, sUniteDebutIdealMax) ;
    iNbDelais++ ;
  }
  if ((dDelaiDebutConseilMax > 0) && (sUniteDebutConseilMax != ""))
  {
    dMeanDelai += getDelaiInSecond(dDelaiDebutConseilMax, sUniteDebutConseilMax) ;
    iNbDelais++ ;
  }

  if (iNbDelais > 0)
    return (dMeanDelai / double(iNbDelais)) ;
  else
    return 0 ;
}


double
NSLdvGoal::getDelaiInSecond(double iDelai, string sUnite)
{
  string sUnitConcept ;
  pContexte->getDico()->donneCodeSens(&sUnite, &sUnitConcept) ;

  if (sUnitConcept == "2SEC0")
    return iDelai ;
  if (sUnitConcept == "2MINU")
    return double(60) * iDelai ;
  if (sUnitConcept == "2HEUR")
    return double(3600) * iDelai ;
  if (sUnitConcept == "2DAT0")
    return double(86400) * iDelai ;
  if (sUnitConcept == "2DAT1")
    return getDelaiInSecond(double(7) * iDelai, "2DAT01") ;
  if (sUnitConcept == "2DAT2")
    return getDelaiInSecond(double(30) * iDelai, "2DAT01") ;
  if (sUnitConcept == "2DAT2")
    return getDelaiInSecond(double(365) * iDelai, "2DAT01") ;

  return double(0) ;
}


string
NSLdvGoal::getNodeDate(string sNode)
{
    string  sDocReference   = string(sNode, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) ;
    string  sNodeReference  = string(sNode, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN, strlen(sNode.c_str()) - (PAT_NSS_LEN + DOC_CODE_DOCUM_LEN)) ;
    string  sNodeDate       = "" ;

    // Recherche du document qui contient ce noeud
    // Looking for the document that contains this node
    NSHISTODocument* pHistory = pContexte->getPatient()->pDocHis ;

    if (pHistory->VectDocument.empty())
        return "" ;

    DocumentIter iterDoc = pHistory->VectDocument.TrouveDocHisto(sDocReference) ;
    // Found
    if ((iterDoc == NULL) || (iterDoc == pHistory->VectDocument.end()))
        return "" ;

    // we save the document's date, but we try to search if there is a date in the
    // sons of the Value
    sNodeDate = (*iterDoc)->GetDateDoc() ;

    // now we search in the sub-tree if we have a date
    PatPathoIter iterPat, iterEnd;

	if ((*iterDoc)->sCodeDocMeta == sDocReference)
    {
    	iterPat = (*iterDoc)->pMeta->ChercherNoeud(sNode);
        iterEnd = (*iterDoc)->pMeta->end();
    }
    else
    {
    	iterPat = (*iterDoc)->pPatPathoArray->ChercherNoeud(sNode) ;
    	iterEnd = (*iterDoc)->pPatPathoArray->end();
    }
    // the reseter can be anything... don't test ((*iterPat)->pDonnees->lexique == sLexique)
    if (iterPat && (iterPat != iterEnd))
    {
        int   iColonne = (*iterPat)->getColonne() ;

        string sCodeLex = (*iterPat)->pDonnees->lexique ;
        string sType    = pContexte->getDico()->CodeCategorie(sCodeLex) ;

        string sDateLexSens = "KOUVR" ;
        if      (sType == "V")
            sDateLexSens = "KDARE" ;
        else if (sType == "G")
            sDateLexSens = "KCHIR" ;

        iterPat++ ;

        while ( (iterPat != iterEnd)  &&
                ((*iterPat)->getColonne() > iColonne))
        {
            bool  bDateReference    = false ;
            int   iColDateReference = (*iterPat)->getColonne() ;

            string sNodeLex = (*iterPat)->pDonnees->lexique ;
            string sNodeSens ;
            pContexte->getDico()->donneCodeSens(&sNodeLex, &sNodeSens) ;

            if (sNodeSens == sDateLexSens)
            {
                bDateReference    = true ;
                iColDateReference = (*iterPat)->getColonne() ;
                iterPat++ ;
            }

            bool  bNextIsDate = false ;
            while (bDateReference && (iterPat != iterEnd) && ((*iterPat)->getColonne() > iColDateReference))
            {
                string sLexique = (*iterPat)->getLexique() ;

                if ((sLexique[0] == '�') &&
                    ((sLexique[1] == dateMARK) || (sLexique[1] == dateHeureMARK)) &&
                    (((*iterPat)->getUnit())[0] == '2'))
                {
                    sNodeDate = (*iterPat)->getComplement() ;
                    break ;
                }
                iterPat++ ;
            }

            if (!bDateReference)
                iterPat++ ;
        }
    }

    return (sNodeDate) ;
}

NSLdvGoalInfo::JALONSLEVELS
NSLdvGoal::getValueLevel(string sValue, string sUnit, NSLdvGoalInfo::JALONSLEVELS *iLastLevel)
{
	if (sValue == "")
		return NSLdvGoalInfo::None ;

  double dValue = StringToDouble(sValue) ;

  NSLdvGoalInfo::JALONSLEVELS iLevelValue = aValueZones.getColor(dValue, sUnit) ;

  if (iLevelValue != NSLdvGoalInfo::None)
	{
  	(*iLastLevel) = iLevelValue ;
		return iLevelValue ;
	}

	if ((*iLastLevel) != NSLdvGoalInfo::None)
    iLevelValue = (*iLastLevel) ;
  else
    iLevelValue = NSLdvGoalInfo::None ;

	(*iLastLevel) = iLevelValue ;
	return iLevelValue ;
}


bool
NSLdvGoal::getNodeValue(string sNode, string *sValue, double *dValue)
{
	(*sValue) = "" ;
	(*dValue) = 0 ;

	string sCategorie = pContexte->getSuperviseur()->getDico()->CodeCategorie(sLexique) ;
	if (sCategorie != "V")
		return false ;

	string  sDocReference   = string(sNode, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) ;
	string  sNodeReference  = string(sNode, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN, strlen(sNode.c_str()) - (PAT_NSS_LEN + DOC_CODE_DOCUM_LEN)) ;

	// Recherche du document qui contient ce noeud
	// Looking for the document that contains this node
	NSHISTODocument *pHistory = pContexte->getPatient()->pDocHis ;
	if (pHistory->VectDocument.empty())
		return false ;

	DocumentIter iterDoc  = pHistory->VectDocument.TrouveDocHisto(sDocReference) ;

	// Found
	if ((iterDoc == NULL) || (iterDoc == pHistory->VectDocument.end()))
		return false ;

	// recherche de la valeur contenue dans ce noeud
	// Looking for the Value contained in this node
	PatPathoIter  iterPat = (*iterDoc)->pPatPathoArray->ChercherNoeud(sNode) ;
	if (iterPat && (iterPat != (*iterDoc)->pPatPathoArray->end()) && ((*iterPat)->pDonnees->lexique == sLexique))
	{
		int   iColonne = (*iterPat)->getColonne() ;
		iterPat++ ;
		while ( (iterPat != (*iterDoc)->pPatPathoArray->end())  &&
        		((*iterPat)->getColonne() > iColonne))
		{
			// no need to use ifdef _MUE because we test the same thing in the two cases
			// the only one difference is that in _MUE version the Value is in the first son
			// and in the !_MUE version the Value is the son of the son (so in iterPat++)
			if (((*iterPat)->pDonnees->lexique)[0] == '�')
			{
				(*sValue) = (*iterPat)->pDonnees->complement ;
				(*dValue) = StringToDouble(*sValue) ;
				return true ;
			}

			iterPat++ ;
		}
	}

	return false ;
}


string
NSLdvGoal::getNodeUnit(string sNode)
{
  string  sObjReference   = string(sNode, 0,                                PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) ;
  string  sNodeReference  = string(sNode, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN, strlen(sNode.c_str()) - (PAT_NSS_LEN + DOC_CODE_DOCUM_LEN)) ;

  // Recherche du document qui contient ce noeud
  // Looking for the document that contains this node
  NSHISTODocument *pHistory = pContexte->getPatient()->pDocHis ;

  if (pHistory->VectDocument.empty())
    return "" ;

  DocumentIter iterDoc = pHistory->VectDocument.TrouveDocHisto(sObjReference) ;

  // Found
  if ((iterDoc == NULL) || (iterDoc == pHistory->VectDocument.end()))
    return "" ;

  // recherche de l'unit� contenue dans ce noeud
  // Looking for the Unit of the Value contained in this node
  PatPathoIter  iterPat = (*iterDoc)->pPatPathoArray->ChercherNoeud(sNode) ;
  if (iterPat && (*iterPat) && ((*iterPat)->pDonnees->lexique == sLexique))
  {
    int   iColonne = (*iterPat)->getColonne() ;
    iterPat++ ;
    while ( (iterPat != (*iterDoc)->pPatPathoArray->end())  &&
            ((*iterPat)->getColonne() > iColonne))
    {
      if (((*iterPat)->pDonnees->lexique)[0] == '�')
      {
        string  sUnite = "" ;
        string  sTemp = (*iterPat)->getUnit() ;
        pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
        return sUnite ;
      }
      iterPat++ ;
    }
  }


  return "" ;
}

void
NSLdvGoal::initPresetIntervals()
{
	initPresetDelayIntervals() ;
	initPresetDateIntervals() ;
	initPresetValueIntervals() ;
}

void
NSLdvGoal::initPresetDelayIntervals()
{
  NSLdvGoalInfo::JALONSLEVELS iUpColor   = NSLdvGoalInfo::None ;
  NSLdvGoalInfo::JALONSLEVELS iDownColor = NSLdvGoalInfo::None ;

  if ((dDelaiDebutIdealMax >= 0) || (dDelaiDebutIdeal >= 0))
  {
		iUpColor   = NSLdvGoalInfo::Bleu ;
		iDownColor = NSLdvGoalInfo::Bleu ;
  }

	// Delays
	//
	if (dDelaiDebutIdealMax >= 0)
	{
		aDelayZones.setHighValues(NSLdvGoalInfo::Bleu, dDelaiDebutIdealMax, sUniteDebutIdealMax, true) ;
    aDelayZones.setLowValues(NSLdvGoalInfo::APvert, dDelaiDebutIdealMax, sUniteDebutIdealMax, false) ;

		iUpColor = NSLdvGoalInfo::APvert ;
	}
	if (dDelaiDebutIdeal >= 0)
	{
  	aDelayZones.setLowValues(NSLdvGoalInfo::Bleu, dDelaiDebutIdeal, sUniteDebutIdeal, true) ;
    aDelayZones.setHighValues(NSLdvGoalInfo::AVvert, dDelaiDebutIdeal, sUniteDebutIdeal, false) ;

		iDownColor = NSLdvGoalInfo::AVvert ;
	}
	if (dDelaiDebutConseilMax >= 0)
	{
		if (iUpColor == NSLdvGoalInfo::None)
    	iUpColor = NSLdvGoalInfo::APvert ;

		aDelayZones.setHighValues(iUpColor, dDelaiDebutConseilMax, sUniteDebutConseilMax, true) ;
    aDelayZones.setLowValues(NSLdvGoalInfo::APjaune, dDelaiDebutConseilMax, sUniteDebutConseilMax, false) ;

    iUpColor = NSLdvGoalInfo::APjaune ;
	}
	if (dDelaiDebutConseille >= 0)
	{
  	if (iDownColor == NSLdvGoalInfo::None)
    	iDownColor = NSLdvGoalInfo::AVvert ;

    aDelayZones.setLowValues(iDownColor, dDelaiDebutConseille, sUniteDebutConseille, true) ;
    aDelayZones.setHighValues(NSLdvGoalInfo::AVjaune, dDelaiDebutConseille, sUniteDebutConseille, false) ;

    iDownColor = NSLdvGoalInfo::AVjaune ;
	}
	if (dDelaiDebutCritique >= 0)
	{
  	if (iUpColor == NSLdvGoalInfo::None)
    	iUpColor = NSLdvGoalInfo::APjaune ;

    aDelayZones.setHighValues(iUpColor, dDelaiDebutCritique, sUniteDebutCritique, true) ;
    aDelayZones.setLowValues(NSLdvGoalInfo::AProuge, dDelaiDebutCritique, sUniteDebutCritique, false) ;

    iUpColor = NSLdvGoalInfo::AProuge ;
	}
	if (dDelaiDebutAutorise >= 0)
	{
  	if (iDownColor == NSLdvGoalInfo::None)
    	iDownColor = NSLdvGoalInfo::AVjaune ;

    aDelayZones.setLowValues(iDownColor, dDelaiDebutAutorise, sUniteDebutAutorise, true) ;
    aDelayZones.setHighValues(NSLdvGoalInfo::AVrouge, dDelaiDebutAutorise, sUniteDebutAutorise, false) ;

    iDownColor = NSLdvGoalInfo::AVrouge ;
	}
}

void
NSLdvGoal::initPresetDateIntervals()
{
  NSLdvGoalInfo::JALONSLEVELS iUpColor   = NSLdvGoalInfo::None ;
  NSLdvGoalInfo::JALONSLEVELS iDownColor = NSLdvGoalInfo::None ;

  if ((sDateDebutIdeal != "") || (sDateDebutIdealMax != ""))
  {
		iUpColor   = NSLdvGoalInfo::Bleu ;
		iDownColor = NSLdvGoalInfo::Bleu ;
  }

	// Delays
	//
	if (sDateDebutIdealMax != "")
	{
  	aDateZones.setHighValues(NSLdvGoalInfo::Bleu, sDateDebutIdealMax, true) ;
    aDateZones.setLowValues(NSLdvGoalInfo::APvert, sDateDebutIdealMax, false) ;

		iUpColor = NSLdvGoalInfo::APvert ;
	}
	if (sDateDebutIdeal != "")
	{
		aDateZones.setLowValues(NSLdvGoalInfo::Bleu, sDateDebutIdeal, true) ;
    aDateZones.setHighValues(NSLdvGoalInfo::AVvert, sDateDebutIdeal, false) ;

		iDownColor = NSLdvGoalInfo::AVvert ;
	}
	if (sDateDebutConseilMax != "")
	{
  	if (iUpColor == NSLdvGoalInfo::None)
    	iUpColor = NSLdvGoalInfo::APvert ;

		aDateZones.setHighValues(iUpColor, sDateDebutConseilMax, true) ;
    aDateZones.setLowValues(NSLdvGoalInfo::APjaune, sDateDebutConseilMax, false) ;

    iUpColor = NSLdvGoalInfo::APjaune ;
	}
	if (sDateDebutConseille != "")
	{
  	if (iDownColor == NSLdvGoalInfo::None)
    	iDownColor = NSLdvGoalInfo::AVvert ;

    aDateZones.setLowValues(iDownColor, sDateDebutConseille, true) ;
    aDateZones.setHighValues(NSLdvGoalInfo::AVjaune, sDateDebutConseille, false) ;

    iDownColor = NSLdvGoalInfo::AVjaune ;
	}
	if (sDateDebutCritique != "")
	{
  	if (iUpColor == NSLdvGoalInfo::None)
    	iUpColor = NSLdvGoalInfo::APjaune ;

    aDateZones.setHighValues(iUpColor, sDateDebutCritique, true) ;
    aDateZones.setLowValues(NSLdvGoalInfo::AProuge, sDateDebutCritique, false) ;

    iUpColor = NSLdvGoalInfo::AProuge ;
	}
	if (sDateDebutAutorise != "")
	{
  	if (iDownColor == NSLdvGoalInfo::None)
    	iDownColor = NSLdvGoalInfo::AVjaune ;

    aDateZones.setLowValues(iDownColor, sDateDebutAutorise, true) ;
    aDateZones.setHighValues(NSLdvGoalInfo::AVrouge, sDateDebutAutorise, false) ;

    iDownColor = NSLdvGoalInfo::AVrouge ;
	}
}

void
NSLdvGoal::initPresetValueIntervals()
{
  NSLdvGoalInfo::JALONSLEVELS iUpColor   = NSLdvGoalInfo::None ;
  NSLdvGoalInfo::JALONSLEVELS iDownColor = NSLdvGoalInfo::None ;

  if (bValMaxIdeal || bValMinIdeal)
  {
		iUpColor   = NSLdvGoalInfo::Bleu ;
		iDownColor = NSLdvGoalInfo::Bleu ;
  }

	// Delays
	//
	if (bValMaxIdeal)
	{
  	aValueZones.setHighValues(NSLdvGoalInfo::Bleu, dValMaxIdeal, sUniteValMaxIdeal, true) ;
    aValueZones.setLowValues(NSLdvGoalInfo::APvert, dValMaxIdeal, sUniteValMaxIdeal, false) ;

		iUpColor = NSLdvGoalInfo::APvert ;
	}
	if (bValMinIdeal)
	{
  	aValueZones.setLowValues(NSLdvGoalInfo::Bleu, dValMinIdeal, sUniteValMinIdeal, true) ;
    aValueZones.setHighValues(NSLdvGoalInfo::AVvert, dValMinIdeal, sUniteValMinIdeal, false) ;

		iDownColor = NSLdvGoalInfo::AVvert ;
	}
	if (bValMaxConseille)
	{
  	if (iUpColor == NSLdvGoalInfo::None)
    	iUpColor = NSLdvGoalInfo::APvert ;

		aValueZones.setHighValues(iUpColor, dValMaxConseille, sUniteValMaxConseille, true) ;
    aValueZones.setLowValues(NSLdvGoalInfo::APjaune, dValMaxConseille, sUniteValMaxConseille, false) ;

    iUpColor = NSLdvGoalInfo::APjaune ;
	}
	if (bValMinConseille)
	{
  	if (iDownColor == NSLdvGoalInfo::None)
    	iDownColor = NSLdvGoalInfo::AVvert ;

    aValueZones.setLowValues(iDownColor, dValMinConseille, sUniteValMinConseille, true) ;
    aValueZones.setHighValues(NSLdvGoalInfo::AVjaune, dValMinConseille, sUniteValMinConseille, false) ;

    iDownColor = NSLdvGoalInfo::AVjaune ;
	}
	if (bValMaxAutorise)
	{
  	if (iUpColor == NSLdvGoalInfo::None)
    	iUpColor = NSLdvGoalInfo::APjaune ;

    aValueZones.setHighValues(iUpColor, dValMaxAutorise, sUniteValMaxAutorise, true) ;
    aValueZones.setLowValues(NSLdvGoalInfo::AProuge, dValMaxAutorise, sUniteValMaxAutorise, false) ;

    iUpColor = NSLdvGoalInfo::AProuge ;
	}
	if (bValMinAutorise)
	{
  	if (iDownColor == NSLdvGoalInfo::None)
    	iDownColor = NSLdvGoalInfo::AVjaune ;

    aValueZones.setLowValues(iDownColor, dDelaiDebutAutorise, sUniteDebutAutorise, true) ;
    aValueZones.setHighValues(NSLdvGoalInfo::AVrouge, dDelaiDebutAutorise, sUniteDebutAutorise, false) ;

    iDownColor = NSLdvGoalInfo::AVrouge ;
	}
}

NSLdvGoalInfo::JALONSLEVELS
NSLdvGoal::getColorForPonctualDate(string sDate)
{
	return aDateZones.getColor(sDate) ;
}

void
NSLdvGoal::getValuedGoalFromIndice(int iIndice, bool *pbIsGoal, double *pdGoalValue, string *psGoalUnit)
{
	switch (iIndice)
  {
  	case 0 :
    	*pbIsGoal    = bValMinAutorise ;
      *pdGoalValue = dValMinAutorise ;
      *psGoalUnit  = sUniteValMinAutorise ;
      break ;
    case 1 :
    	*pbIsGoal    = bValMinConseille ;
      *pdGoalValue = dValMinConseille ;
      *psGoalUnit  = sUniteValMinConseille ;
      break ;
    case 2 :
    	*pbIsGoal    = bValMinIdeal ;
      *pdGoalValue = dValMinIdeal ;
      *psGoalUnit  = sUniteValMinIdeal ;
      break ;
    case 3 :
    	*pbIsGoal    = bValMaxIdeal ;
      *pdGoalValue = dValMaxIdeal ;
      *psGoalUnit  = sUniteValMaxIdeal ;
      break ;
    case 4 :
    	*pbIsGoal    = bValMaxConseille ;
      *pdGoalValue = dValMaxConseille ;
      *psGoalUnit  = sUniteValMaxConseille ;
      break ;
    case 5 :
    	*pbIsGoal    = bValMaxAutorise ;
      *pdGoalValue = dValMaxAutorise ;
      *psGoalUnit  = sUniteValMaxAutorise ;
      break ;
    default :
    	*pbIsGoal    = false ;
      *pdGoalValue = double(0) ;
      *psGoalUnit  = string("") ;
      break ;
  }
}

bool
NSLdvGoal::canBeFullyConverted(string sUnit)
{
	bool   bIsDefined ;
  double dValue ;
  string sValueUnit ;

  // First, check if this unit is already goals' values unit
  //
  int i ;
	for (i = 0 ; i < 6; i++)
  {
  	getValuedGoalFromIndice(i, &bIsDefined, &dValue, &sValueUnit) ;
  	if (bIsDefined && (sValueUnit != sUnit))
    	break ;
  }
  if (i == 6)
		return true ;

  // Second, check if concepts are all alike
  //
  string sUnitSens ;
	pContexte->getDico()->donneCodeSens(&sUnit, &sUnitSens) ;

	for (i = 0 ; i < 6; i++)
  {
  	getValuedGoalFromIndice(i, &bIsDefined, &dValue, &sValueUnit) ;
  	if (bIsDefined)
    {
    	string sValueUnitSens ;
			pContexte->getDico()->donneCodeSens(&sValueUnit, &sValueUnitSens) ;

      if (sValueUnitSens != sUnitSens)
    		break ;
    }
  }
  if (i == 6)
		return true ;

	// If we are there, it means that units are really different, we must check
  // if we can convert from one to the other
  //

  NSCV NsCv(pContexte) ;

  DBIResult result = NsCv.open() ;
	if (result != DBIERR_NONE)
    return false ;

	for (i = 0 ; i < 6; i++)
  {
  	getValuedGoalFromIndice(i, &bIsDefined, &dValue, &sValueUnit) ;
  	if (bIsDefined)
    {
    	bool bCvtSuccess = NsCv.ConvertirUnite(&dValue, sUnit, sValueUnit, sLexique) ;
      if (!bCvtSuccess)
    		break ;
    }
  }

  NsCv.close() ;

  if (i == 6)
		return true ;

	return false ;
}

// -----------------------------------------------------------------------------
// NSLdvGoal(NSLdvGoal& rv)
// -----------------------------------------------------------------------------
NSLdvGoal::NSLdvGoal(NSLdvGoal& rv)
  : NSRoot(rv.pContexte)
{
try
{
	sLexique                = rv.sLexique ;
	sTitre                  = rv.sTitre ;
	sConcern                = rv.sConcern ;
	sReference              = rv.sReference ;
	sCertitude              = rv.sCertitude ;
	sComplementText         = rv.sComplementText ;

	tDateOuverture 	        = rv.tDateOuverture ;
	tDateFermeture          = rv.tDateFermeture ;
	tOuvertLe               = rv.tOuvertLe ;
	tFermeLe                = rv.tFermeLe ;
	sOpenEventNode          = rv.sOpenEventNode ;
	sCloseEventNode         = rv.sCloseEventNode ;

	dValueOuverture         = rv.dValueOuverture ;
	sValueOuverture         = rv.sValueOuverture ;
	sUnitOuverture          = rv.sUnitOuverture ;
	bValueOuverture         = rv.bValueOuverture ;
	dValueFermeture         = rv.dValueFermeture ;
	sValueFermeture         = rv.sValueFermeture ;
	sUnitFermeture          = rv.sUnitFermeture ;
	bValueFermeture         = rv.bValueFermeture ;

	iRythme                 = rv.iRythme ;

	dDelaiDebutAutorise     = rv.dDelaiDebutAutorise ;
	sUniteDebutAutorise     = rv.sUniteDebutAutorise ;
	dDelaiDebutConseille    = rv.dDelaiDebutConseille ;
	sUniteDebutConseille    = rv.sUniteDebutConseille ;
	dDelaiDebutIdeal        = rv.dDelaiDebutIdeal ;
	sUniteDebutIdeal        = rv.sUniteDebutIdeal ;
	dDelaiDebutIdealMax     = rv.dDelaiDebutIdealMax ;
	sUniteDebutIdealMax     = rv.sUniteDebutIdealMax ;
	dDelaiDebutConseilMax   = rv.dDelaiDebutConseilMax ;
	sUniteDebutConseilMax   = rv.sUniteDebutConseilMax ;
	dDelaiDebutCritique     = rv.dDelaiDebutCritique ;
	sUniteDebutCritique     = rv.sUniteDebutCritique ;

	sDateDebutAutorise      = rv.sDateDebutAutorise ;
	sDateDebutConseille     = rv.sDateDebutConseille ;
	sDateDebutIdeal         = rv.sDateDebutIdeal ;
	sDateDebutIdealMax      = rv.sDateDebutIdealMax ;
	sDateDebutConseilMax    = rv.sDateDebutConseilMax ;
	sDateDebutCritique      = rv.sDateDebutCritique ;

	bValue                  = rv.bValue ;

	bValMinAutorise         = rv.bValMinAutorise ;
	dValMinAutorise         = rv.dValMinAutorise ;
	sUniteValMinAutorise    = rv.sUniteValMinAutorise ;
	bValMinConseille        = rv.bValMinConseille ;
	dValMinConseille        = rv.dValMinConseille ;
	sUniteValMinConseille   = rv.sUniteValMinConseille ;
	bValMinIdeal            = rv.bValMinIdeal ;
	dValMinIdeal            = rv.dValMinIdeal ;
	sUniteValMinIdeal       = rv.sUniteValMinIdeal ;
	bValMaxIdeal            = rv.bValMaxIdeal ;
	dValMaxIdeal            = rv.dValMaxIdeal ;
	sUniteValMaxIdeal       = rv.sUniteValMaxIdeal ;
	bValMaxConseille        = rv.bValMaxConseille ;
	dValMaxConseille        = rv.dValMaxConseille ;
	sUniteValMaxConseille   = rv.sUniteValMaxConseille ;
	bValMaxAutorise         = rv.bValMaxAutorise ;
	dValMaxAutorise         = rv.dValMaxAutorise ;
	sUniteValMaxAutorise    = rv.sUniteValMaxAutorise ;
	isSelected							= rv.isSelected ;

	pJalons	                = new GoalInfoArray(*(rv.pJalons)) ;
	pMetaJalons	            = new GoalInfoArray(*(rv.pMetaJalons)) ;

	aDelayZones 						= rv.aDelayZones ;
	aDateZones              = rv.aDateZones ;
	aValueZones             = rv.aValueZones ;
}
catch (...)
{
  erreur("Exception NSLdvGoal copy tor.", standardError, 0) ;
}
}


// -----------------------------------------------------------------------------
// ~NSLdvGoal()
// -----------------------------------------------------------------------------

NSLdvGoal::~NSLdvGoal()
{
	delete pJalons ;
  delete pMetaJalons ;
}


// -----------------------------------------------------------------------------
// NSLdvGoal&	operator=(NSLdvGoal& src)
// -----------------------------------------------------------------------------
NSLdvGoal&
NSLdvGoal::operator=(NSLdvGoal& rv)
{
try
{
    sLexique                = rv.sLexique ;
	sTitre                  = rv.sTitre ;
    sConcern                = rv.sConcern ;
	sReference              = rv.sReference ;
    sCertitude              = rv.sCertitude ;
    sComplementText         = rv.sComplementText ;

	tDateOuverture 	        = rv.tDateOuverture ;
	tDateFermeture          = rv.tDateFermeture ;
    tOuvertLe               = rv.tOuvertLe ;
    tFermeLe                = rv.tFermeLe ;
    sOpenEventNode          = rv.sOpenEventNode ;
    sCloseEventNode         = rv.sCloseEventNode ;

    dValueOuverture         = rv.dValueOuverture ;
    sValueOuverture         = rv.sValueOuverture ;
    sUnitOuverture          = rv.sUnitOuverture ;
    bValueOuverture         = rv.bValueOuverture ;
    dValueFermeture         = rv.dValueFermeture ;
    sValueFermeture         = rv.sValueFermeture ;
    sUnitFermeture          = rv.sUnitFermeture ;
    bValueFermeture         = rv.bValueFermeture ;

    iRythme                 = rv.iRythme ;

    dDelaiDebutAutorise     = rv.dDelaiDebutAutorise ;
    sUniteDebutAutorise     = rv.sUniteDebutAutorise ;
    dDelaiDebutConseille    = rv.dDelaiDebutConseille ;
    sUniteDebutConseille    = rv.sUniteDebutConseille ;
    dDelaiDebutIdeal        = rv.dDelaiDebutIdeal ;
    sUniteDebutIdeal        = rv.sUniteDebutIdeal ;
    dDelaiDebutIdealMax     = rv.dDelaiDebutIdealMax ;
    sUniteDebutIdealMax     = rv.sUniteDebutIdealMax ;
    dDelaiDebutConseilMax   = rv.dDelaiDebutConseilMax ;
    sUniteDebutConseilMax   = rv.sUniteDebutConseilMax ;
    dDelaiDebutCritique     = rv.dDelaiDebutCritique ;
    sUniteDebutCritique     = rv.sUniteDebutCritique ;

    sDateDebutAutorise      = rv.sDateDebutAutorise ;
    sDateDebutConseille     = rv.sDateDebutConseille ;
    sDateDebutIdeal         = rv.sDateDebutIdeal ;
    sDateDebutIdealMax      = rv.sDateDebutIdealMax ;
    sDateDebutConseilMax    = rv.sDateDebutConseilMax ;
    sDateDebutCritique      = rv.sDateDebutCritique ;

    bValue                  = rv.bValue ;

    bValMinAutorise         = rv.bValMinAutorise ;
    dValMinAutorise         = rv.dValMinAutorise ;
    sUniteValMinAutorise    = rv.sUniteValMinAutorise ;
    bValMinConseille        = rv.bValMinConseille ;
    dValMinConseille        = rv.dValMinConseille ;
    sUniteValMinConseille   = rv.sUniteValMinConseille ;
    bValMinIdeal            = rv.bValMinIdeal ;
    dValMinIdeal            = rv.dValMinIdeal ;
    sUniteValMinIdeal       = rv.sUniteValMinIdeal ;
    bValMaxIdeal            = rv.bValMaxIdeal ;
    dValMaxIdeal            = rv.dValMaxIdeal ;
    sUniteValMaxIdeal       = rv.sUniteValMaxIdeal ;
    bValMaxConseille        = rv.bValMaxConseille ;
    dValMaxConseille        = rv.dValMaxConseille ;
    sUniteValMaxConseille   = rv.sUniteValMaxConseille ;
    bValMaxAutorise         = rv.bValMaxAutorise ;
    dValMaxAutorise         = rv.dValMaxAutorise ;
    sUniteValMaxAutorise    = rv.sUniteValMaxAutorise ;

    delete pJalons ;
	pJalons	                = new GoalInfoArray(*(rv.pJalons)) ;
    delete pMetaJalons ;
	pMetaJalons	            = new GoalInfoArray(*(rv.pMetaJalons)) ;

	return *this;
}
catch (...)
{
	erreur("Exception NSLdvGoal (=).", standardError, 0) ;
	return *this;
}
}

bool
NSLdvGoal::estIdentique(NSLdvGoal* pModel)
{
	if (!pModel)
		return false ;

  if ((sLexique               == pModel->sLexique)                &&
      (sCertitude             == pModel->sCertitude)              &&
      (sComplementText        == pModel->sComplementText)         &&
      (iRythme                == pModel->iRythme)                 &&
      (dDelaiDebutAutorise    == pModel->dDelaiDebutAutorise)     &&
      (sUniteDebutAutorise    == pModel->sUniteDebutAutorise)     &&
      (dDelaiDebutConseille   == pModel->dDelaiDebutConseille)    &&
      (sUniteDebutConseille   == pModel->sUniteDebutConseille)    &&
      (dDelaiDebutIdeal       == pModel->dDelaiDebutIdeal)        &&
      (sUniteDebutIdeal       == pModel->sUniteDebutIdeal)        &&
      (dDelaiDebutIdealMax    == pModel->dDelaiDebutIdealMax)     &&
      (sUniteDebutIdealMax    == pModel->sUniteDebutIdealMax)     &&
      (dDelaiDebutConseilMax  == pModel->dDelaiDebutConseilMax)   &&
      (sUniteDebutConseilMax  == pModel->sUniteDebutConseilMax)   &&
      (dDelaiDebutCritique    == pModel->dDelaiDebutCritique)     &&
      (sUniteDebutCritique    == pModel->sUniteDebutCritique)     &&
      (sDateDebutAutorise     == pModel->sDateDebutAutorise)      &&
      (sDateDebutConseille    == pModel->sDateDebutConseille)     &&
      (sDateDebutIdeal        == pModel->sDateDebutIdeal)         &&
      (sDateDebutIdealMax     == pModel->sDateDebutIdealMax)      &&
      (sDateDebutConseilMax   == pModel->sDateDebutConseilMax)    &&
      (sDateDebutCritique     == pModel->sDateDebutCritique)      &&

      (bValue                 == pModel->bValue)                  &&

      (bValMinAutorise        == pModel->bValMinAutorise)         &&
      (dValMinAutorise        == pModel->dValMinAutorise)         &&
      (sUniteValMinAutorise   == pModel->sUniteValMinAutorise)    &&
      (bValMinConseille       == pModel->bValMinConseille)        &&
      (dValMinConseille       == pModel->dValMinConseille)        &&
      (sUniteValMinConseille  == pModel->sUniteValMinConseille)   &&
      (bValMinIdeal           == pModel->bValMinIdeal)            &&
      (dValMinIdeal           == pModel->dValMinIdeal)            &&
      (sUniteValMinIdeal      == pModel->sUniteValMinIdeal)       &&
      (bValMaxIdeal           == pModel->bValMaxIdeal)            &&
      (dValMaxIdeal           == pModel->dValMaxIdeal)            &&
      (sUniteValMaxIdeal      == pModel->sUniteValMaxIdeal)       &&
      (bValMaxConseille       == pModel->bValMaxConseille)        &&
      (dValMaxConseille       == pModel->dValMaxConseille)        &&
      (sUniteValMaxConseille  == pModel->sUniteValMaxConseille)   &&
      (bValMaxAutorise        == pModel->bValMaxAutorise)         &&
      (dValMaxAutorise        == pModel->dValMaxAutorise)         &&
      (sUniteValMaxAutorise   == pModel->sUniteValMaxAutorise)    &&

      //(tDateOuverture       == pModel->tDateOuverture)          &&
      //(tDateFermeture       == pModel->tDateFermeture)          &&
      (sOpenEventNode         == pModel->sOpenEventNode)          &&
      (sCloseEventNode        == pModel->sCloseEventNode))
    return true ;

  return false ;
}

// -----------------------------------------------------------------------------
//
// M�thodes de ArrayGoals
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// ArrayGoals(ArrayGoals& rv)
// -----------------------------------------------------------------------------
ArrayGoals::ArrayGoals(ArrayGoals& rv)
  : VectGoal()
{
try
{
	if (!(rv.empty()))
		for (ArrayGoalIter i = rv.begin() ; i != rv.end() ; i++)
			push_back(new NSLdvGoal(*(*i)));

	pDoc = rv.pDoc ;
}
catch (...)
{
  erreur("Exception ArrayGoals copy ctor.", standardError, 0) ;
}
}


// -----------------------------------------------------------------------------
// ~ArrayGoals()
// -----------------------------------------------------------------------------
ArrayGoals::~ArrayGoals()
{
	vider() ;
}


// -----------------------------------------------------------------------------
// void		vider()
// -----------------------------------------------------------------------------
void		ArrayGoals::vider()
{
	if (empty())
		return ;

	for (ArrayGoalIter i = begin() ; i != end() ; )
	{
		delete *i ;
		erase(i) ;
	}
}


// -----------------------------------------------------------------------------
// void		initialiser()
// -----------------------------------------------------------------------------
void
ArrayGoals::initialiser()
{
	if ((!pDoc) || (!(pDoc->pPathoPOMRIndex)) || (pDoc->pPathoPOMRIndex->empty()))
		return ;

	NSPatPathoArray *pPtIndex = pDoc->pPathoPOMRIndex ;

	// On cherche le chapitre "objectifs de sant�"
	PatPathoIter iter = pPtIndex->ChercherItem("0OBJE1") ;

	if ((iter != NULL) && (iter != pPtIndex->end()))
	{
		int iColBase = (*iter)->pDonnees->getColonne() ;
		iter++ ;
		loadGoals(iter, iColBase) ;
	}
}


// -----------------------------------------------------------------------------
// void		loadGoals(PatPathoIter iter, int iColBase)
// -----------------------------------------------------------------------------
void
ArrayGoals::loadGoals(PatPathoIter iter, int iColBase, bool bJustOne, bool bNewGoal)
{
try
{
	NSPatPathoArray *pPtIndex = pDoc->pPathoPOMRIndex ;
	NSLdvGoal       *pGoal = 0 ;

	bool bTourner = true ;

	while ((bTourner) && (iter != pPtIndex->end()) && ((*iter)->pDonnees->getColonne() > iColBase))
	{
		// Probl�me
		if ((*iter)->pDonnees->getColonne() == iColBase + 1)
		{
    	if (bJustOne)
      	bTourner = false ;

			if (pGoal)
			{
				push_back(new NSLdvGoal(*pGoal)) ;
				delete pGoal ;
				pGoal = 0 ;

				pGoal = back() ;
        pGoal->init() ;
        pGoal->initJalons() ;
        pGoal->initConcern(pDoc) ;
			}

      string sCodeLex = string((*iter)->pDonnees->lexique) ;
      string sCodeSensGoal ;
    	pDoc->pContexte->getDico()->donneCodeSens(&sCodeLex, &sCodeSensGoal) ;

      //
      // Objectif cach� -- Hidden health goal
      //
      if (sCodeSensGoal == "90000")
      {
      	iter++ ;
      	while ( (iter != pPtIndex->end()) &&
                ((*iter)->pDonnees->getColonne() > iColBase + 1))
        	iter++ ;
      }
      //
      // Objectif visible -- Visible health goal
      //
      else
      {
        pGoal = new NSLdvGoal(pDoc->pContexte) ;
        pGoal->initFromPatho(pPtIndex, &iter) ;

        // Cet objectif est-il raccord� � une pr�occupation (nsconcern) ?
        // Is this goal attached to a health issue ?

        NSLinkManager* pGraphe = pDoc->pContexte->getPatient()->pGraphPerson->pLinkManager ;

        VecteurString VectString ;
        pGraphe->TousLesVrais(pGoal->getNoeud(), NSRootLink::problemGoals, &VectString) ;
        if (!VectString.empty())
          pGoal->sConcern =  *(*(VectString.begin())) ;
  		}
		}
		else
			iter++;
	}

	if (pGoal)
	{
		push_back(new NSLdvGoal(*pGoal)) ;
		delete pGoal ;
		pGoal = 0 ;

		pGoal = back() ;
		pGoal->init() ;
		pGoal->initJalons() ;
		pGoal->initConcern(pDoc) ;
	}
}
catch (...)
{
	erreur("Exception ArrayGoals::loadGoals.", standardError, 0) ;
	return ;
}
}


// -----------------------------------------------------------------------------
// void    reinit()
// -----------------------------------------------------------------------------

void    ArrayGoals::reinit()
{
	if ((!pDoc) || (!(pDoc->pPathoPOMRIndex)) || (pDoc->pPathoPOMRIndex->empty()))
		return ;

	NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex ;

	// On cherche le chapitre "objectifs de sant�"
	PatPathoIter iter = pPtIndex->ChercherItem("0OBJE1") ;

	if ((iter != NULL) && (iter != pPtIndex->end()))
	{
		int iColBase = (*iter)->pDonnees->getColonne() ;
		iter++ ;

		vider() ;

		loadGoals(iter, iColBase) ;
	}
}

// -----------------------------------------------------------------------------
//  Un nouvel objectif va �tre ajout� : on g�re ses r�percutions sur les objectifs
//  d�j� en place
//
//  A new goal is to be added : we manage it's relationships with other goals
// -----------------------------------------------------------------------------

void
ArrayGoals::initNewGoal(NSLdvGoal *pNewGoal)
{
try
{
    if ((empty()) || (!pNewGoal))
        return ;

    // Objectif qui ne s'ouvre jamais
    if ((pNewGoal->sOpenEventNode == "") && (pNewGoal->tDateOuverture.estVide()))
        return ;

    //
    // On regarde si les conditions d'ouverture sont r�alis�es
    //
    NVLdVTemps tNow ;
    tNow.takeTime() ;
    // Date de fermeture d�j� atteinte : on sort
    if ((!(pNewGoal->tDateFermeture.estVide())) && (pNewGoal->tDateFermeture < tNow))
        return ;

    string sNewConcept ;
    pDoc->pContexte->getDico()->donneCodeSens(&(pNewGoal->sLexique), &sNewConcept) ;

    NSHISTODocument* pHistory = pDoc->pContexte->getPatient()->pDocHis ;

    // On cherche s'il existe un �v�nement
    if (pNewGoal->sOpenEventNode != "")
    {
        if (pHistory->VectDocument.empty())
            return ;

        string      sGoalOpener = "" ;
        NVLdVTemps  tDateDoc ;
        tDateDoc.init() ;

        DocumentIter iterDoc = pHistory->VectDocument.begin() ;
		while (iterDoc != pHistory->VectDocument.end())
		{
			PatPathoIter iter = (*iterDoc)->pPatPathoArray->begin() ;

            string sRootConcept ;
            pDoc->pContexte->getDico()->donneCodeSens(&(string((*iter)->pDonnees->lexique)), &sRootConcept) ;

            if (sRootConcept == sNewConcept)
            {
                string sDate = (*iterDoc)->GetDateDoc() ;
                if (sDate != "")
                {
                    NVLdVTemps tDateOfDoc ;
                    tDateOfDoc.initFromDate(sDate) ;
                    if ((tDateOfDoc > tDateDoc) && (tDateOfDoc > pNewGoal->tDateOuverture))
                    {
                        tDateDoc    = tDateOfDoc ;
                        sGoalOpener = (*iter)->getNode() ;
                    }
                }
            }
            iterDoc++ ;
		}

        if (sGoalOpener != "")
        {
            NSLinkManager* pGraphe = pDoc->pContexte->getPatient()->pGraphPerson->pLinkManager ;

            pGraphe->etablirLien(sGoalOpener, NSRootLink::goalOpener, pNewGoal->sReference) ;
            pNewGoal->tOuvertLe = tDateDoc ;
        }
        else
            return ;
    }
    else
    {
        if (pNewGoal->tDateOuverture <= tNow)
            pNewGoal->tOuvertLe = pNewGoal->tDateOuverture ;
    }

    //
    // On regarde si d'autres objectifs concernent le m�me concept
    //
    for (ArrayGoalIter itGoal = begin() ; itGoal != end() ; itGoal++)
	{
        string sPreviousConcept ;
        pDoc->pContexte->getDico()->donneCodeSens(&((*itGoal)->sLexique), &sPreviousConcept) ;

        if (sPreviousConcept == sNewConcept)
        {
            // Le nouvel objectif est cyclique
            if (pNewGoal->iRythme == NSLdvGoal::cyclic)
            {
                // Si l'ancien est cyclique, le plus fr�quent cache l'autre
                if ((*itGoal)->iRythme == NSLdvGoal::cyclic)
                {
                    double dNewDelai = pNewGoal->getMeanDelaiInSecond() ;
                    double dOldDelai = (*itGoal)->getMeanDelaiInSecond() ;
                    // Nouveau moins fr�quent : on ne le garde que s'il
                    // d�marre plus t�t
                    if (dNewDelai >= dOldDelai)
                    {
                        // if ()
                    }
                }
            }
        }
    }
}
catch (...)
{
	erreur("Exception ArrayGoals::initNewGoal", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// void   	reloadGoals(PatPathoIter iter, int iColBase)
// -----------------------------------------------------------------------------
void
ArrayGoals::reloadGoals(PatPathoIter iter, int iColBase)
{
try
{
	NSPatPathoArray *pPtIndex = pDoc->pPathoPOMRIndex ;

	NSLdvGoal *pGoal = 0 ;

	while ((iter != pPtIndex->end()) && ((*iter)->pDonnees->getColonne() > iColBase))
	{
		// Probl�me
		if ((*iter)->pDonnees->getColonne() == iColBase + 1)
		{
			if (pGoal)
			{
				push_back(new NSLdvGoal(*pGoal)) ;
				delete pGoal ;
				pGoal = 0 ;
			}

      string sCodeLex = string((*iter)->pDonnees->lexique) ;
      string sCodeSensGoal ;
    	pDoc->pContexte->getDico()->donneCodeSens(&sCodeLex, &sCodeSensGoal) ;

      //
      // Objectif cach� -- Hidden health goal
      //
      if (sCodeSensGoal == "90000")
      {
      	iter++ ;
      	while ( (iter != pPtIndex->end()) &&
                ((*iter)->pDonnees->getColonne() > iColBase + 1))
        	iter++ ;
      }
      //
      // Objectif visible -- Visible health goal
      //
      else
      {

        pGoal = new NSLdvGoal(pDoc->pContexte) ;

        // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        // bidouille pour que ca marche
        // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        pGoal->tDateFermeture.setNoLimit() ;

        // Libell�

              pGoal->sLexique = sCodeLex ;

        if (sCodeLex != string("�?????"))
          pDoc->pContexte->getDico()->donneLibelle(pDoc->sLangue, &sCodeLex, &(pGoal->sTitre)) ;

        // Texte libre - Free text
        else
        	pGoal->sTitre = (*iter)->getTexteLibre() ;

        // Noeud
        string sNoeud = (*iter)->pDonnees->getNode() ;
        pGoal->setNoeud(sNoeud) ;

        iter++ ;

        // Param�tres d'objectif
        while ((iter != pPtIndex->end()) && ((*iter)->pDonnees->getColonne() > iColBase + 1))
        {
          string sElemLex = string((*iter)->pDonnees->lexique) ;
          string sSens ;
          pDoc->pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

          if ((*iter)->pDonnees->getColonne() == iColBase + 2)
          {
            // Dates d'ouverture et de fermeture
            if ((sSens == "KOUVR") || (sSens == "KFERM"))
            {
              iter++;
              int iLigneBase = (*iter)->pDonnees->getLigne() ;
              // gereDate* pDate = new gereDate(pContexte) ;
              string sUnite  = "" ;
              string sFormat = "" ;
              string sValeur = "" ;
              string sTemp   = "" ;
              while ((iter != pPtIndex->end()) && ((*iter)->pDonnees->getLigne() == iLigneBase))
              {
                if (((*iter)->pDonnees->lexique)[0] == '�')
                {
                    sTemp   = (*iter)->getLexique() ;
                    pDoc->pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
                    sValeur = (*iter)->getComplement() ;
                    sTemp   = (*iter)->getUnit() ;
                    pDoc->pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
                    break ;
                }
                iter++ ;
              }

              // sFormat est du type �D0;03
              if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) && (sValeur != ""))
              {
                if ((sUnite == "2DA01") || (sUnite == "2DA02"))
                {
                  if (sSens == "KOUVR")
                    pGoal->tDateOuverture.initFromDate(sValeur) ;
                  else
                    if (sSens == "KFERM")
                      pGoal->tDateFermeture.initFromDate(sValeur) ;
                }
              }
            }
            else
              iter++ ;
          }
          else
            iter++ ;
        }

        /*
        // Cette pr�occupation est-elle l'�volution d'une autre ?
        // Is this health concern the evolution of a previous one ?
        VecteurString   *pVecteurString = new VecteurString() ;
        pContexte->getGraphe()->TousLesVrais(sNoeud, NSGraphe::problemRelatedTo, pVecteurString) ;
        if (!pVecteurString->empty())
          pConcern->sPrimoPb =  *(*(pVecteurString->begin())) ;
        delete pVecteurString ;
        */
  		}
		}
		else
			iter++ ;
	}

	if (pGoal)
	{
		push_back(new NSLdvGoal(*pGoal)) ;
		delete pGoal ;
		pGoal = 0 ;
	}
}
catch (...)
{
	erreur("Exception ArrayGoals::reloadConcerns.", standardError, 0) ;
	return ;
}
}

// -----------------------------------------------------------------------------
// void    deleteGoal(NSLdvGoal *pGoal)
// -----------------------------------------------------------------------------
void
ArrayGoals::deleteGoal(NSLdvGoal *pGoal)
{
	if (!pGoal || empty())
		return ;

	for (ArrayGoalIter i = begin() ; i != end() ; i++)
	{
		if (*i == pGoal)
		{
			delete pGoal ;
			erase(i) ;
			return ;
		}
	}
}

GoalInfoArray*
ArrayGoals::giveBaddestJalons(string sConcern, NVLdVRect* pRect)
{
    if (empty())
        return NULL ;

    GoalInfoArray* pGIarray = new GoalInfoArray() ;

    //
    // Etape 1 :    On entasse tous les jalons de tous les objectifs
    //              de cette pr�occupation qui sont en partie dans le rectangle
    //
    for (ArrayGoalIter i = begin(); i != end(); i++)
    {
		if ((*i)->sConcern == sConcern)
        {
            GoalInfoArray* pJalons = (*i)->pMetaJalons ;
            if (pJalons && (!(pJalons->empty())))
            {
                GoalInfoIter itGoals = pJalons->begin() ;
                for ( ; (itGoals != pJalons->end()) && ((*itGoals)->tpsInfo < pRect->getRight()) ; itGoals++)
                    if ((*itGoals)->tpsClosed > pRect->getLeft())
                        pGIarray->push_back(new NSLdvGoalInfo(**itGoals)) ;
            }
        }
    }

    if (pGIarray->empty())
    {
        delete pGIarray ;
        return NULL ;
    }

    //
    // Etape 2 : On trie par ordre chronologique
    //
    sort(pGIarray->begin(), pGIarray->end(), infGoalInfo) ;
    //
    // Etape 3 : On ne garde que les pires pour une p�riode donn�e
    //
    int         iLevel = 0 ;
    NVLdVTemps  tpsEndLevel = pRect->getLeft() ;

    for (GoalInfoIter i = pGIarray->begin(); i != pGIarray->end(); )
    {
        if (((*i)->iLevel > iLevel) || ((*i)->tpsInfo > tpsEndLevel))
        {
            iLevel      = (*i)->iLevel;
            tpsEndLevel = (*i)->tpsClosed ;
            i++ ;
        }
        else
        {
            delete *i ;
            pGIarray->erase(i) ;
        }
    }

    return pGIarray ;
}

// -----------------------------------------------------------------------------
// NSLdvGoal		*getGoal(string sRef)
// -----------------------------------------------------------------------------
NSLdvGoal*
ArrayGoals::getGoal(string sRef)
{
	if (empty())
		return NULL;

	for (ArrayGoalIter i = begin(); i != end(); i++)
		if ((*i)->getNoeud() == sRef)
			return *i;

	return NULL;
}


// -----------------------------------------------------------------------------
// NSLdvGoal		*makeBaddestProjection()
// -----------------------------------------------------------------------------
// cette fonction cr�� un NSLdvGoal qui est la projection de tous les objectifs
// contenu dans l'ArrayGoals qui refl�te la pire situation � chaque instant.
// -----------------------------------------------------------------------------

NSLdvGoal*
ArrayGoals::makeBaddestProjection()
{
	if (empty())
		return NULL ;

	// pour l'instant on renvoie le premier, mais il faudra renvoyer un nouvel
	// objectif qui refl�tera le pire �tat de chaque objectif

	for (ArrayGoalIter i = begin() ; i != end() ; i++)
		return (*i) ;

	return NULL ;
}


// -----------------------------------------------------------------------------
// ArrayGoals& operator=(ArrayGoals src)
// -----------------------------------------------------------------------------
ArrayGoals&
ArrayGoals::operator=(ArrayGoals src)
{
try
{
	vider() ;

	if (!(src.empty()))
		for (ArrayGoalIter i = src.begin() ; i != src.end() ; i++)
			push_back(new NSLdvGoal(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception ArrayGoals (=).", standardError, 0) ;
	return *this ;
}
}

///////////////////////////// NSDelayZone

// Constructor
NSDelayZone::NSDelayZone(NSLdvGoalInfo::JALONSLEVELS iColour, double dLow, string sLow, bool bLow, double dHigh, string sHigh, bool bHigh)
{
	dLowDelay      = dLow ;
	sLowDelayUnit  = sLow ;
	bLowIncluded   = bLow ;

	dHighDelay     = dHigh ;
	sHighDelayUnit = sHigh ;
	bHighIncluded  = bHigh ;

	iLevel         = iColour ;
}

// Copy constructor
NSDelayZone::NSDelayZone(NSDelayZone& rv)
{
	dLowDelay      = rv.dLowDelay ;
	sLowDelayUnit  = rv.sLowDelayUnit ;
	bLowIncluded   = rv.bLowIncluded ;

	dHighDelay     = rv.dHighDelay ;
	sHighDelayUnit = rv.sHighDelayUnit ;
	bHighIncluded  = rv.bHighIncluded ;

	iLevel         = rv.iLevel ;
}

// destructor
NSDelayZone::~NSDelayZone()
{
}

// is this delay inside this zone
bool
NSDelayZone::isInside(double dValue, string sUnit)
{
	if (dLowDelay >= 0)
	{
		if (sUnit != sLowDelayUnit)
			return false ;
    if (bLowIncluded && (dValue < dLowDelay))
			return false ;
		if (!bLowIncluded && (dValue <= dLowDelay))
			return false ;
	}
	if (dHighDelay >= 0)
	{
		if (sUnit != sHighDelayUnit)
			return false ;
    if (bHighIncluded && (dValue > dHighDelay))
			return false ;
		if (!bLowIncluded && (dValue >= dHighDelay))
			return false ;
	}
  return true ;
}

// = operator
NSDelayZone&
NSDelayZone::operator=(NSDelayZone src)
{
	dLowDelay      = src.dLowDelay ;
	sLowDelayUnit  = src.sLowDelayUnit ;
	bLowIncluded   = src.bLowIncluded ;

	dHighDelay     = src.dHighDelay ;
	sHighDelayUnit = src.sHighDelayUnit ;
	bHighIncluded  = src.bHighIncluded ;

	iLevel         = src.iLevel ;

  return *this ;
}

///////////////////////////// NSDelayZoneArray

// Constructor
NSDelayZoneArray::NSDelayZoneArray()
                 :NSDelayZoneVector()
{
}

// Copy constructor
NSDelayZoneArray::NSDelayZoneArray(NSDelayZoneArray& rv)
{
try
{
	if (!(rv.empty()))
		for (NSDelayZoneIter i = rv.begin() ; i != rv.end() ; i++)
			push_back(new NSDelayZone(*(*i))) ;
}
catch (...)
{
	erreur("Exception NSDelayZoneArray copy ctor.", standardError, 0) ;
}
}

// Destructor
NSDelayZoneArray::~NSDelayZoneArray()
{
	vider() ;
}

NSLdvGoalInfo::JALONSLEVELS
NSDelayZoneArray::getColor(double dValue, string sUnit)
{
	if (!(empty()))
		for (NSDelayZoneIter i = begin() ; i != end() ; i++)
			if ((*i)->isInside(dValue, sUnit))
				return (*i)->iLevel ;

	return NSLdvGoalInfo::None ;
}

void
NSDelayZoneArray::setLowValues(NSLdvGoalInfo::JALONSLEVELS iColorZone, double dLow, string sLow, bool bLow)
{
	NSDelayZone* pZone = getZone(iColorZone) ;
	if (pZone)
	{
		pZone->dLowDelay     = dLow ;
		pZone->sLowDelayUnit = sLow ;
		pZone->bLowIncluded  = bLow ;
    return ;
	}

	push_back(new NSDelayZone(iColorZone, dLow, sLow, bLow, -1, "", false)) ;
}

void
NSDelayZoneArray::setHighValues(NSLdvGoalInfo::JALONSLEVELS iColorZone, double dHigh, string sHigh, bool bHigh)
{
	NSDelayZone* pZone = getZone(iColorZone) ;
	if (pZone)
	{
		pZone->dHighDelay     = dHigh ;
		pZone->sHighDelayUnit = sHigh ;
		pZone->bHighIncluded  = bHigh ;
    return ;
	}

	push_back(new NSDelayZone(iColorZone, -1, "", false, dHigh, sHigh, bHigh)) ;
}

NSDelayZone*
NSDelayZoneArray::getZone(NSLdvGoalInfo::JALONSLEVELS iColorZone)
{
	if (!(empty()))
		for (NSDelayZoneIter i = begin() ; i != end() ; i++)
			if ((*i)->iLevel == iColorZone)
				return *i ;

	return NULL ;
}

// = operator
NSDelayZoneArray&
NSDelayZoneArray::operator=(NSDelayZoneArray src)
{
try
{
	vider() ;

	if (!src.empty())
	{
		for (NSDelayZoneIter i = src.begin() ; i != src.end() ; i++)
			push_back(new NSDelayZone(**i)) ;
	}

	return (*this) ;
}
catch (...)
{
	erreur("Exception NSDelayZoneArray (=).", standardError, 0) ;
	return *this;
}
}

// Empty the array
void
NSDelayZoneArray::vider()
{
	if (empty())
		return ;

	for (NSDelayZoneIter i = begin() ; i != end() ; )
	{
		delete (*i) ;
		erase(i) ;
	}
}

///////////////////////////// NSDateZone

// Constructor
NSDateZone::NSDateZone(NSLdvGoalInfo::JALONSLEVELS iColour, string sLow, bool bLow, string sHigh, bool bHigh)
{
	sLowDate       = sLow ;
	bLowIncluded   = bLow ;

	sHighDate      = sHigh ;
	bHighIncluded  = bHigh ;

	iLevel         = iColour ;
}

// Copy constructor
NSDateZone::NSDateZone(NSDateZone& rv)
{
	sLowDate       = rv.sLowDate ;
	bLowIncluded   = rv.bLowIncluded ;

	sHighDate      = rv.sHighDate ;
	bHighIncluded  = rv.bHighIncluded ;

	iLevel         = rv.iLevel ;
}

// destructor
NSDateZone::~NSDateZone()
{
}

// is this delay inside this zone
bool
NSDateZone::isInside(string sDate)
{
	if (sLowDate != "")
	{
    if (bLowIncluded && (sDate < sLowDate))
			return false ;
		if (!bLowIncluded && (sDate <= sLowDate))
			return false ;
	}
	if (sHighDate != "")
	{
    if (bHighIncluded && (sDate > sHighDate))
			return false ;
		if (!bLowIncluded && (sDate >= sHighDate))
			return false ;
	}
  return true ;
}

NVLdVTemps
NSDateZone::getLowDate()
{
	NVLdVTemps tps ;
	if (sLowDate != "")
  	tps.initFromDate(sLowDate) ;
  else
  	tps.init() ;
  return tps ;
}

NVLdVTemps
NSDateZone::getHighDate()
{
	NVLdVTemps tps ;
	if (sLowDate != "")
		tps.initFromDate(sHighDate) ;
	else
		tps.setNoLimit() ;
  return tps ;
}

// = operator
NSDateZone&
NSDateZone::operator=(NSDateZone src)
{
	sLowDate       = src.sLowDate ;
	bLowIncluded   = src.bLowIncluded ;

	sHighDate      = src.sHighDate ;
	bHighIncluded  = src.bHighIncluded ;

	iLevel         = src.iLevel ;

  return *this ;
}

///////////////////////////// NSDelayZoneArray

// Constructor
NSDateZoneArray::NSDateZoneArray()
                :NSDateZoneVector()
{
}

// Copy constructor
NSDateZoneArray::NSDateZoneArray(NSDateZoneArray& rv)
{
try
{
	if (!(rv.empty()))
		for (NSDateZoneIter i = rv.begin() ; i != rv.end() ; i++)
			push_back(new NSDateZone(*(*i))) ;
}
catch (...)
{
	erreur("Exception NSDateZoneArray copy ctor.", standardError, 0) ;
}
}

// Destructor
NSDateZoneArray::~NSDateZoneArray()
{
	vider() ;
}

NSLdvGoalInfo::JALONSLEVELS
NSDateZoneArray::getColor(string sDate)
{
	if (!(empty()))
		for (NSDateZoneIter i = begin() ; i != end() ; i++)
			if ((*i)->isInside(sDate))
				return (*i)->iLevel ;

	return NSLdvGoalInfo::None ;
}

void
NSDateZoneArray::setLowValues(NSLdvGoalInfo::JALONSLEVELS iColorZone, string sLow, bool bLow)
{
	NSDateZone* pZone = getZone(iColorZone) ;
	if (pZone)
	{
		pZone->sLowDate      = sLow ;
		pZone->bLowIncluded  = bLow ;
    return ;
	}

	push_back(new NSDateZone(iColorZone, sLow, bLow, "", false)) ;
}

void
NSDateZoneArray::setHighValues(NSLdvGoalInfo::JALONSLEVELS iColorZone, string sHigh, bool bHigh)
{
	NSDateZone* pZone = getZone(iColorZone) ;
	if (pZone)
	{
		pZone->sHighDate      = sHigh ;
		pZone->bHighIncluded  = bHigh ;
    return ;
	}

	push_back(new NSDateZone(iColorZone, "", false, sHigh, bHigh)) ;
}

NSDateZone*
NSDateZoneArray::getZone(NSLdvGoalInfo::JALONSLEVELS iColorZone)
{
	if (!(empty()))
		for (NSDateZoneIter i = begin() ; i != end() ; i++)
			if ((*i)->iLevel == iColorZone)
				return *i ;

	return NULL ;
}

// = operator
NSDateZoneArray&
NSDateZoneArray::operator=(NSDateZoneArray src)
{
try
{
	vider() ;

	if (!src.empty())
	{
		for (NSDateZoneIter i = src.begin() ; i != src.end() ; i++)
			push_back(new NSDateZone(**i)) ;
	}

	return (*this) ;
}
catch (...)
{
	erreur("Exception NSDateZoneArray (=).", standardError, 0) ;
	return *this;
}
}

// Empty the array
void
NSDateZoneArray::vider()
{
	if (empty())
		return ;

	for (NSDateZoneIter i = begin() ; i != end() ; )
	{
		delete (*i) ;
		erase(i) ;
	}
}

///////////////////////////// NSValueZone

// Constructor
NSValueZone::NSValueZone(NSLdvGoalInfo::JALONSLEVELS iColour, bool bIsLow, double dLow, string sLow, bool bLow, bool bIsHigh, double dHigh, string sHigh, bool bHigh)
{
	bLowExist      = bIsLow ;
	dLowValue      = dLow ;
	sLowValueUnit  = sLow ;
	bLowIncluded   = bLow ;

	bHighExist     = bIsHigh ;
	dHighValue     = dHigh ;
	sHighValueUnit = sHigh ;
	bHighIncluded  = bHigh ;

	iLevel         = iColour ;
}

// Copy constructor
NSValueZone::NSValueZone(NSValueZone& rv)
{
	bLowExist      = rv.bLowExist ;
	dLowValue      = rv.dLowValue ;
	sLowValueUnit  = rv.sLowValueUnit ;
	bLowIncluded   = rv.bLowIncluded ;

	bHighExist     = rv.bHighExist ;
	dHighValue     = rv.dHighValue ;
	sHighValueUnit = rv.sHighValueUnit ;
	bHighIncluded  = rv.bHighIncluded ;

	iLevel         = rv.iLevel ;
}

// destructor
NSValueZone::~NSValueZone()
{
}

// is this delay inside this zone
bool
NSValueZone::isInside(double dValue, string sUnit)
{
	if (bLowExist)
	{
		if (sUnit != sLowValueUnit)
			return false ;
    if (bLowIncluded && (dValue < dLowValue))
			return false ;
		if (!bLowIncluded && (dValue <= dLowValue))
			return false ;
	}
	if (bHighExist)
	{
		if (sUnit != sHighValueUnit)
			return false ;
    if (bHighIncluded && (dValue > dHighValue))
			return false ;
		if (!bLowIncluded && (dValue >= dHighValue))
			return false ;
	}
  return true ;
}

// = operator
NSValueZone&
NSValueZone::operator=(NSValueZone src)
{
  bLowExist      = src.bLowExist ;
	dLowValue      = src.dLowValue ;
	sLowValueUnit  = src.sLowValueUnit ;
	bLowIncluded   = src.bLowIncluded ;

	bHighExist     = src.bHighExist ;
	dHighValue     = src.dHighValue ;
	sHighValueUnit = src.sHighValueUnit ;
	bHighIncluded  = src.bHighIncluded ;

	iLevel         = src.iLevel ;

  return *this ;
}

///////////////////////////// NSValueZoneArray

// Constructor
NSValueZoneArray::NSValueZoneArray()
                 :NSValueZoneVector()
{
}

// Copy constructor
NSValueZoneArray::NSValueZoneArray(NSValueZoneArray& rv)
{
try
{
	if (!(rv.empty()))
		for (NSValueZoneIter i = rv.begin() ; i != rv.end() ; i++)
			push_back(new NSValueZone(*(*i))) ;
}
catch (...)
{
	erreur("Exception NSValueZoneArray copy ctor.", standardError, 0) ;
}
}

// Destructor
NSValueZoneArray::~NSValueZoneArray()
{
	vider() ;
}

NSLdvGoalInfo::JALONSLEVELS
NSValueZoneArray::getColor(double dValue, string sUnit)
{
	if (!(empty()))
		for (NSValueZoneIter i = begin() ; i != end() ; i++)
			if ((*i)->isInside(dValue, sUnit))
				return (*i)->iLevel ;

	return NSLdvGoalInfo::None ;
}

void
NSValueZoneArray::setLowValues(NSLdvGoalInfo::JALONSLEVELS iColorZone, double dLow, string sLow, bool bLow)
{
	NSValueZone* pZone = getZone(iColorZone) ;
	if (pZone)
	{
  	pZone->bLowExist     = true ;
		pZone->dLowValue     = dLow ;
		pZone->sLowValueUnit = sLow ;
		pZone->bLowIncluded  = bLow ;
    return ;
	}

	push_back(new NSValueZone(iColorZone, true, dLow, sLow, bLow, false, -1, "", false)) ;
}

void
NSValueZoneArray::setHighValues(NSLdvGoalInfo::JALONSLEVELS iColorZone, double dHigh, string sHigh, bool bHigh)
{
	NSValueZone* pZone = getZone(iColorZone) ;
	if (pZone)
	{
		pZone->bHighExist     = true ;
		pZone->dHighValue     = dHigh ;
		pZone->sHighValueUnit = sHigh ;
		pZone->bHighIncluded  = bHigh ;
    return ;
	}

	push_back(new NSValueZone(iColorZone, false, -1, "", false, true, dHigh, sHigh, bHigh)) ;
}

NSValueZone*
NSValueZoneArray::getZone(NSLdvGoalInfo::JALONSLEVELS iColorZone)
{
	if (!(empty()))
		for (NSValueZoneIter i = begin() ; i != end() ; i++)
			if ((*i)->iLevel == iColorZone)
				return *i ;

	return NULL ;
}

// = operator
NSValueZoneArray&
NSValueZoneArray::operator=(NSValueZoneArray src)
{
try
{
	vider() ;

	if (!src.empty())
	{
		for (NSValueZoneIter i = src.begin() ; i != src.end() ; i++)
			push_back(new NSValueZone(**i)) ;
	}

	return (*this) ;
}
catch (...)
{
	erreur("Exception NSValueZoneArray (=).", standardError, 0) ;
	return *this;
}
}

// Empty the array
void
NSValueZoneArray::vider()
{
	if (empty())
		return ;

	for (NSValueZoneIter i = begin() ; i != end() ; )
	{
		delete (*i) ;
		erase(i) ;
	}
}

