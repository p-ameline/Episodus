// -----------------------------------------------------------------------------
// Nsldvdoc.cpp
// -----------------------------------------------------------------------------
// $Revision: 1.108 $
// $Author: pameline $
// $Date: 2005/07/01 08:11:27 $
// -----------------------------------------------------------------------------
// Ligne de Vie document
// -----------------------------------------------------------------------------
// FLP - aout 2003
// ...
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
//           Ligne de vie - Document du mod�le Document/Vue
// -----------------------------------------------------------------------------

#include <owl\filedoc.h>
#include <iostream.h>
#include <cstring.h>

#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"
#include "nautilus\nsdecode.h"
#include "nsbb\nsbb.h"
#include "nautilus\nsrechd2.h"
#include "dcodeur\nsdkd.h"
#include "nautilus\nshistdo.h"
#include "nautilus\nstrihis.h"
#include "nssavoir\nsgraphe.h"
#include "nautilus\nscsdoc.h"
#include "dcodeur\nsdkd.h"
#include "nsbb\nsbbtran.h"
#include "nsbb\nstlibre.h"
#include "nsbb\nsmedicdlg.h"
#include "nsbb\nsarc.h"
#include "nssavoir\nsrightsmanager.h"
#include "nautilus\nsldvdoc.h"
#include "nautilus\nsldvvue.h"
#include "nautilus\nsldvgoal.h"
#include "nautilus\nsdrugview.h"
#include "nautilus\nsgoalview.h"
#include "nautilus\nsprocessview.h"
#include "nautilus\nsdocview.h"
#include "nsoutil\ns_arche.h"

#include "nautilus\nssoapview.h"

#include "ns_ob1\TypedVal.h"
#include "ns_ob1\NautilusType.h"
#include "ns_ob1\BB1Task.h"
#include "ns_ob1\Interface.h"

const string drugPhaseSepar    = " | ";
const char   drugMMSSepar      = ':';
const char   drugMMSUpSepar    = '^';
const char   drugMMSBNoonSepar = '[';
const char   drugMMSANoonSepar = ']';
const char   drugMMSDownSepar  = '_';

// --------------------------------------------------------------------------
// ---------------------- METHODES DE NSLdvDocument -------------------------
// --------------------------------------------------------------------------


//---------------------------------------------------------------------------
//            Constructeur
//---------------------------------------------------------------------------

NSLdvDocument::NSLdvDocument(TDocument* parent, NSContexte* pCtx)
	:	TDocument(parent),
		NSRoot(pCtx)
{
try
{
	SetTitle("Ligne de Vie") ;

	// Positionnement du pointeur sur l'index
	pPathoPOMRIndex = 0 ;

	if ((pContexte->getPatient()) && (pContexte->getPatient()->pDocHis))
	{
		NSHISTODocument* pDocHis = pContexte->getPatient()->pDocHis ;
		if (!(pDocHis->VectDocument.empty()))
		{
			bool bContinuer = true ;
			DocumentIter iterDoc = pDocHis->VectDocument.begin() ;
			while ((iterDoc != pDocHis->VectDocument.end()) && bContinuer)
			{
				if (((*iterDoc)->pPatPathoArray) &&
                    (!((*iterDoc)->pPatPathoArray->empty())))
				{
					PatPathoIter iter = (*iterDoc)->pPatPathoArray->begin() ;
					if ((*iter)->getLexiqueSens(pContexte) == string("ZPOMR"))
					{
						pPathoPOMRIndex = (*iterDoc)->pPatPathoArray ;
						bContinuer = false ;
					}
					else
						iterDoc++ ;
				}
				else
					iterDoc++ ;
			}
		}
	}

	// Initialisation de la langue
	sLangue = pContexte->getUtilisateur()->donneLang() ;

	// Initialisation des conteneurs
	pConcerns   = new ArrayConcern(this) ;
	pConcerns->initialiser() ;
	pObjets     = new ArrayObjets(this) ;
	pObjets->initialiser() ;
	pSousObjets	= new ArraySsObjet(this) ;
	pSousObjets->initialiser() ;
	pDrugs	    = new ArrayLdvDrugs(this) ;
	pDrugs->initialiser() ;
  //
  // Do it last, since Goals will get connected to concerns and drugs
  //
	pGoals	    = new ArrayGoals(this) ;
	pGoals->initialiser() ;
}
catch (...)
{
	erreur("Exception NSLdvDocument ctor.", standardError, 0) ;
}
}


//---------------------------------------------------------------------------
//  Description : Constructeur copie
//---------------------------------------------------------------------------

NSLdvDocument::NSLdvDocument(NSLdvDocument& rv)
	:	TDocument(rv.GetParentDoc()),
		NSRoot(rv.pContexte)
{
try
{
	pConcerns   = new ArrayConcern(*(rv.pConcerns)) ;
	pObjets     = new ArrayObjets(*(rv.pObjets)) ;
	pSousObjets	= new ArraySsObjet(*(rv.pSousObjets)) ;
	pGoals      = new ArrayGoals(*(rv.pGoals)) ;
  pDrugs      = new ArrayLdvDrugs(*(rv.pDrugs)) ;

	pPathoPOMRIndex = rv.pPathoPOMRIndex ;
	sLangue         = rv.sLangue ;
}
catch (...)
{
	erreur("Exception NSLdvDocument copy ctor", standardError, 0) ;
}
}


//---------------------------------------------------------------------------
//  Description : Destructeur
//---------------------------------------------------------------------------

NSLdvDocument::~NSLdvDocument()
{
	delete pSousObjets ;
	delete pObjets ;
	delete pConcerns ;
	delete pGoals ;
  delete pDrugs ;

//  TDocTemplate* pTpl = GetTemplate() ;
//  NSLdvTemplate* pLdvTempl = TYPESAFE_DOWNCAST(GetTemplate(), NSLdvTemplate) ;
//  if (pLdvTempl)
//  	delete pLdvTempl ;
}


//---------------------------------------------------------------------------
//  Open
//---------------------------------------------------------------------------

bool
NSLdvDocument::Open(int mode, const char far* path)
{
	return true ;
}


//---------------------------------------------------------------------------
//  Description : Operateur =
//---------------------------------------------------------------------------

NSLdvDocument&
NSLdvDocument::operator=(NSLdvDocument& src)
{
try
{
	if (this == &src)
		return *this ;

	if (src.pConcerns)
	{
		if (pConcerns)
			*pConcerns = *(src.pConcerns);
		else
			pConcerns = new ArrayConcern(*(src.pConcerns));
	}

	if (src.pObjets)
	{
		if (pObjets)
			*pObjets = *(src.pObjets);
		else
			pObjets = new ArrayObjets(*(src.pObjets));
	}

	if (src.pSousObjets)
	{
		if (pSousObjets)
			*pSousObjets = *(src.pSousObjets);
		else
			pSousObjets = new ArraySsObjet(*(src.pSousObjets));
	}

	if (src.pGoals)
	{
		if (pGoals)
			*pGoals = *(src.pGoals) ;
		else
			pGoals = new ArrayGoals(*(src.pGoals)) ;
	}

	pPathoPOMRIndex = src.pPathoPOMRIndex;
	sLangue         = src.sLangue;

	return *this;
}
catch (...)
{
	erreur("Exception NSLdvDocument::operator=.", standardError, 0) ;
	return *this ;
}
}

//
// ----------------------- Drug oriented services -----------------------
//

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugNewService(TWindow* pCallingView, string sDrugLexiCode, VecteurString* pRelatedConcerns)
{
try
{
	if (!(pContexte->userHasPrivilege(NSContexte::createDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ldvseInsuficientRights ;
	}

	NSPatPathoArray PPT(pContexte) ;
  if (sDrugLexiCode != string(""))
  	PPT.ajoutePatho(sDrugLexiCode, 0) ;

  NSSimpleNewDrugDlg *pMedicDlg = new NSSimpleNewDrugDlg(pCallingView, pContexte, &PPT) ;
  int iResult = pMedicDlg->Execute() ;
  bool bComplexMode = pMedicDlg->mustSwitchToComplexMode() ;
  delete (pMedicDlg) ;

  if (bComplexMode)
	{
  	NSMedicamentDlg *pComplexMedicDlg = new NSMedicamentDlg(pCallingView, pContexte, &PPT) ;
    iResult = pComplexMedicDlg->Execute() ;
		delete (pComplexMedicDlg) ;

    // NSComplexMedicamentDlg *pComplexMedicDlg = new NSComplexMedicamentDlg(pCallingView, pContexte, &PPT) ;
    // iResult = pComplexMedicDlg->Execute() ;
		// delete (pComplexMedicDlg) ;
	}

  if (iResult != IDOK)
  	return ldvseCanceledByUser ;

	if (PPT.empty())
  	return ldvseInvalidData ;

	// on enregistre ici dans l'index de sant�
  //
	pContexte->getPatient()->CreeTraitement(&PPT, pRelatedConcerns) ;

  // invalidateViews("DRUG_NEW") ; // Already done by CreeTraitement

  return ldvseNoError ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSLdvDocument::DrugNewService : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
  return ldvseInterfaceError ;
}
catch (...)
{
  erreur("Exception NSLdvDocument::DrugNewService.", standardError, 0) ;
  return ldvseUndefined ;
}
}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugFromProtocolService(TWindow* pCallingView, VecteurString* pRelatedConcerns)
{
try
{
	if (!(pContexte->userHasPrivilege(NSContexte::createDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ldvseInsuficientRights ;
	}

  ReferentialChoiceDialog *pProtocolSelect = new ReferentialChoiceDialog(pCallingView, pContexte, string("N0000"), ReferentialChoiceDialog::sortDrugs) ;
  int iResult = pProtocolSelect->Execute() ;

  if (iResult != IDOK)
	{
  	delete (pProtocolSelect) ;
  	return ldvseCanceledByUser ;
	}

  string sRefID = pProtocolSelect->getSelectedRefId() ;

  delete (pProtocolSelect) ;

	if (string("") == sRefID)
  	return ldvseInvalidData ;

	// on enregistre ici dans l'index de sant�
  //
	pContexte->getPatient()->CmGenericReferentiel(sRefID, string("")) ;

  // invalidateViews("DRUG_NEW") ; // Already done by CreeTraitement

  return ldvseNoError ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSLdvDocument::DrugFromProtocolService : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
  return ldvseInterfaceError ;
}
catch (...)
{
  erreur("Exception NSLdvDocument::DrugFromProtocolService.", standardError, 0) ;
  return ldvseUndefined ;
}
}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugRenewService(TWindow* pCallingView, string sDrugNode)
{
try
{
	if (sDrugNode == string(""))
		return ldvseNothingToDo ;

	if (!(pContexte->userHasPrivilege(NSContexte::modifyDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ldvseInsuficientRights ;
	}

	NSPatPathoArray PPT(pContexte) ;

	NSRenewMedicDlg* pRenewMedicDlg = new NSRenewMedicDlg(pCallingView, pContexte, &PPT) ;
  int iResult = pRenewMedicDlg->Execute() ;
  delete pRenewMedicDlg ;

	if (iResult == IDCANCEL)
		return ldvseCanceledByUser ;

  VecteurString NodeMedic ;
	NodeMedic.push_back(new string(sDrugNode)) ;

	// on renouvelle la pr�c�dente prescription
	pContexte->getPatient()->RenouvelerTraitement(&NodeMedic, &PPT) ;

  // invalidateViews("DRUG_RENEW") ; // Already done by RenouvelerTraitement

  return ldvseNoError ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSLdvDocument::DrugRenewService : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
  return ldvseInterfaceError ;
}
catch (...)
{
  erreur("Exception NSLdvDocument::DrugRenewService.", standardError, 0) ;
  return ldvseUndefined ;
}
}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugModifyService(TWindow* pCallingView, string sDrugNode)
{
try
{
	if (sDrugNode == string(""))
		return ldvseNothingToDo ;

	if (!(pContexte->userHasPrivilege(NSContexte::modifyDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ldvseInsuficientRights ;
	}

  NSLdvDrug* pDrug = pDrugs->getDrug(sDrugNode) ;
  if (pDrug == NULL)
  	return ldvseInvalidData ;

  NSPatPathoArray PPT(pContexte) ;
  string sCodeModif = pDrug->getLexique() ;

  // r�cup�ration de la date du jour
  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

  // on r�cup�re d'abord la sous-patpatho du noeud � modifier
  NSPatPathoArray SousPPT(pContexte) ;
  pContexte->getPatient()->DonneSousArray(sDrugNode, &SousPPT) ;
  // on reconstitue la patpatho � partir du noeud
  PPT.ajoutePatho(sCodeModif, 0) ;
  // Insertion en queue (iter doit �tre ici egal � end())
  PPT.InserePatPatho(PPT.end(), &SousPPT, 1) ;

  // La patpatho source est constitu�e. On doit maintenant remplacer l'ancienne
  // date d'ouverture par la date du jour (car les modifs �ventuelles datent de ce jour)
  PatPathoIter pptIt = PPT.begin() ;
  // Recherche de la date d'ouverture en sous-niveau du noeud  //  PatPathoIter pptItValeur ;  bool bDateTrouvee = false ;  int iColBase = (*pptIt)->getColonne() ;  pptIt++ ;  while ((pptIt != PPT.end()) && ((*pptIt)->getColonne() > iColBase))  {
    string sSens = (*pptIt)->getLexiqueSens(pContexte) ;

    if ((*pptIt)->getColonne() == iColBase + 1)
    {
      // Dates
      if (sSens == "KOUVR")
      {
        pptIt++ ;
        int iLigneBase = (*pptIt)->getLigne() ;
        string sUnite  = "" ;
        string sFormat = "" ;
        string sValeur = "" ;
        string sTemp   = "" ;

        while ( (pptIt != PPT.end()) &&
                ((*pptIt)->getLigne() == iLigneBase))
        {
          if (pContexte->getDico()->CodeCategorie((*pptIt)->getLexique()) == string("�"))
          {
            sFormat = (*pptIt)->getLexiqueSens(pContexte) ;
            sValeur = (*pptIt)->getComplement() ;
            sUnite  = (*pptIt)->getUnitSens(pContexte) ;
            pptItValeur = pptIt ;
            break ;
          }
          pptIt++;
        }

        // sFormat est du type �D0;03
        if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) && (sValeur != ""))
        {
          if ((sUnite == "2DA01") || (sUnite == "2DA02"))
          {
            // on remplace la date d'ouverture par la date du jour
            (*pptItValeur)->setComplement(tpsNow.donneDateHeure()) ;

            bDateTrouvee = true ;
          }
        }
      }
      else
        pptIt++ ;
    }
    else
      pptIt++ ;
  }

  if (!bDateTrouvee)
  {
    string sErrorText = pContexte->getSuperviseur()->getText("drugManagementErrors", "drugToEditHasNoStartingDate") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
    return ldvseUndefined ;
  }

  // on cr�e une copie
  NSPatPathoArray PPTCopy(PPT) ;

  int iResult ;
  bool bComplexMode = false ;

  NSSimpleNewDrugDlg* pSimpleMedicDialog = new NSSimpleNewDrugDlg(pContexte->GetMainWindow(), pContexte, &PPT) ;
  bool bEnableToParse = pSimpleMedicDialog->ParseMedicament() ;
  if (true == bEnableToParse)
  {
  	iResult = pSimpleMedicDialog->Execute() ;
  	bComplexMode = pSimpleMedicDialog->mustSwitchToComplexMode() ;
  }
  else
  	bComplexMode = false ;

	delete pSimpleMedicDialog ;

	if (true == bComplexMode)
  {
  	/*NSMedicDlg */NSMedicamentDlg *pMedicDialog = new NSMedicamentDlg(pContexte->GetMainWindow(), pContexte, &PPT) ;
  	iResult = pMedicDialog->Execute() ;  	delete pMedicDialog ;  }  if (iResult != IDOK)    return ldvseCanceledByUser ;  // Si aucune modif : on sort...  if (PPT.estEgal(&PPTCopy))    return ldvseNothingToDo ;  VecteurString NodeArret ;
  NodeArret.push_back(new string(sDrugNode)) ;  // on cloture la pr�c�dente prescription  pContexte->getPatient()->ArreterElement(&NodeArret, tpsNow.donneDateHeure()) ;  // on enregistre la nouvelle prescription dans l'index de sant�  if (!(PPT.empty()))
    pContexte->getPatient()->CreeTraitement(&PPT, &(pDrug->aConcerns)) ;

  // invalidateViews("DRUG_CHANGED") ;

	return ldvseNoError ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSLdvDocument::DrugModifyService : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
  return ldvseInterfaceError ;
}
catch (...)
{
  erreur("Exception NSLdvDocument::DrugModifyService.", standardError, 0) ;
  return ldvseUndefined ;
}
}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugChangePosoService(TWindow* pCallingView, string sDrugNode)
{
	if (string("") == sDrugNode)
		return ldvseNothingToDo ;

	NSLdvDrug* pLdvDrug = pDrugs->getDrug(sDrugNode) ;
  if (NULL == pLdvDrug)
		return ldvseInvalidData ;

	return DrugChangePosoService(pCallingView, pLdvDrug) ;
}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugChangePosoService(TWindow* pCallingView, NSLdvDrug* pLdvDrug)
{
	if (NULL == pLdvDrug)
		return ldvseNothingToDo ;

	if (!(pContexte->userHasPrivilege(NSContexte::modifyDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ldvseInsuficientRights ;
	}

  string sCodeModif = pLdvDrug->getLexique() ;
  string sDrugNode  = pLdvDrug->getNoeud() ;

  // r�cup�ration de la date du jour
  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

  // on r�cup�re d'abord la sous-patpatho du noeud � modifier
  // getting the tree for drug to modify
  NSPatPathoArray drugPPT(pContexte) ;
  pContexte->getPatient()->DonneArray(sDrugNode, &drugPPT) ;

  // Getting the active phase and its tree
  //
	NSLdvDrugPhase* pActivePhase = pLdvDrug->getCurrentActivePhase() ;
  if (NULL == pActivePhase)
  	return ldvseNothingToDo ;

	string sPhaseNode = pActivePhase->getNoeud() ;
  if (string("") == sPhaseNode)
		return ldvseNothingToDo ;
	NSPatPathoArray phasePPT(pContexte) ;
	pContexte->getPatient()->DonneArray(sPhaseNode, &phasePPT) ;

  // on cr�e une copie - creating a copy
  NSPatPathoArray PPTCopy(phasePPT) ;

	NSMedicModifPosoDlg *pModifPosoDialog = new NSMedicModifPosoDlg(pContexte->GetMainWindow(), pContexte, &phasePPT, &drugPPT) ;  int iResult = pModifPosoDialog->Execute() ;  delete pModifPosoDialog ;  if (iResult != IDOK)    return ldvseCanceledByUser ;	if (true == phasePPT.empty())		return ldvseNothingToDo ;	NVLdVTemps tStart = pActivePhase->tDateOuverture ;	NVLdVTemps tEnd   = pActivePhase->tDateFermeture ;
	// removing all that is not KCYTR in PPTCopy  if (false == PPTCopy.empty())	{		PatPathoIter copyIter = PPTCopy.begin() ;
    int iCol = (*copyIter)->getColonne() ;
    copyIter++ ;
    while (PPTCopy.end() != copyIter)
    {
    	if ((*copyIter)->getColonne() == iCol + 1)
      {
      	string sSens = (*copyIter)->getLexiqueSens(pContexte) ;
        if (string("KCYTR") != sSens)
        	PPTCopy.SupprimerItem(copyIter) ;
        else
        	copyIter++ ;
      }
      else
      	copyIter++ ;
    }
	}
  // Si aucune modif : on sort...  if (phasePPT.estEgal(&PPTCopy))    return ldvseNothingToDo ;	NSPatPathoArray PPTcycles(pContexte) ;  phasePPT.ExtrairePatPatho(phasePPT.begin(), &PPTcycles) ;  phasePPT.SupprimerFils(phasePPT.begin()) ;	// Adding starting and ending dates to PPT  //  NSPatPathoArray PPTdates(pContexte) ;	PPTdates.ajoutePatho("KOUVR1", 0) ;	Message Msg ;
	Msg.SetUnit("2DA021") ;
	Msg.SetComplement(tpsNow.donneDateHeure()) ;
	PPTdates.ajoutePatho("�T0;19", &Msg, 1) ;

	// Date de fin - Date of ending
	if ((false == tEnd.estVide()) && (false == tEnd.estNoLimit()))
	{
		PPTdates.ajoutePatho("KFERM1", 0) ;
		Message Msg ;
    Msg.SetUnit("2DA021") ;
		Msg.SetComplement(tEnd.donneDateHeure()) ;
		PPTdates.ajoutePatho("�T0;19", &Msg, 1) ;
	}	phasePPT.InserePatPathoFille(phasePPT.begin(), &PPTdates) ;  phasePPT.InserePatPathoFille(phasePPT.begin(), &PPTcycles) ;	// Close the previous phase  VecteurString NodeArret ;  NodeArret.push_back(new string(sPhaseNode)) ;  pContexte->getPatient()->ArreterElement(&NodeArret, tpsNow.donneDateHeure()) ;  // Add the new phase  pContexte->getPatient()->addSubElement(sDrugNode, &phasePPT, true) ;	return ldvseNoError ;}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugStopService(TWindow* pCallingView, string sDrugNode)
{
	if (sDrugNode == string(""))
		return ldvseNothingToDo ;

	if (!(pContexte->userHasPrivilege(NSContexte::modifyDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ldvseInsuficientRights ;
	}

  VecteurString NodeArret ;
  NodeArret.push_back(new string(sDrugNode)) ;

  // r�cup�ration de la date du jour
  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;  // on cloture la pr�c�dente prescription  pContexte->getPatient()->ArreterElement(&NodeArret, tpsNow.donneDateHeure()) ;

	return ldvseNoError ;
}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugDeleteService(TWindow* pCallingView, string sDrugNode)
{
	if (sDrugNode == string(""))
		return ldvseNothingToDo ;

	if (!(pContexte->userHasPrivilege(NSContexte::modifyDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ldvseInsuficientRights ;
	}

  pContexte->getPatient()->SupprimerElement(sDrugNode) ;
  pDrugs->deleteDrug(sDrugNode) ;

  invalidateViews("DRUG_DELETED") ;

	return ldvseNoError ;
}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugCreatePrescriptionService(TWindow* pCallingView)
{
	pContexte->getPatient()->CreeOrdonnance(true) ;

	return ldvseNoError ;
}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugCreatePrescriptionForSelectionService(TWindow* pCallingView, VecteurString* pDrugsRefs)
{
	if ((NULL == pDrugsRefs) || (true == pDrugsRefs->empty()))
		return ldvseNothingToDo ;

	pContexte->getPatient()->CreeOrdonnanceFromSelection(true, pDrugsRefs) ;

	return ldvseNoError ;
}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugCreateProtocolForSelectionService(TWindow* pCallingView, VecteurString* pDrugsRefs)
{
	if ((NULL == pDrugsRefs) || (true == pDrugsRefs->empty()))
		return ldvseNothingToDo ;

try
{
	string sTitle   = string("") ;
	string sIdent   = string("") ;
  string sConcept = string("") ;
	ReferentialTitleDialog *pTitleDlg = new ReferentialTitleDialog(pCallingView, pContexte, &sTitle, &sIdent, &sConcept) ;
	int iResult = pTitleDlg->Execute() ;
	delete pTitleDlg ;

  if (IDOK != iResult)
  	return ldvseCanceledByUser ;

	// Creating and initing the Creferentiel object
  //
	Creferentiel referential("", "", 0, pContexte) ;
	referential.addAttribute(ATTRIBUT_REFER_TITLE, sTitle) ;
	string sID = string("trait.ref.") + sIdent + string(".1.0") ;
  referential.addAttribute(ATTRIBUT_REFER_NAME, sID) ;

  // Create CValeur and Creferences
  //
  CValeur* pValeur = new CValeur(LABEL_REFERENCES, string(""), string(""), &referential) ;
	referential.vect_val.push_back(pValeur) ;
  pValeur->pObject = new Creferences(string(""), string(""), &referential) ;

  Creferences* pRef = dynamic_cast<Creferences*>(pValeur->pObject) ;
  CValeur* pValRef = new CValeur(LABEL_CONCERN, string(""), string(""), pRef) ;
	pRef->vect_val.push_back(pValRef) ;
  pValRef->pObject = new Cconcern(string(""), string(""), pRef) ;
  pValRef->pObject->addAttribute(ATTRIBUT_CONCERN_CATEGORY, string("N0000")) ;
  if (string("") != sConcept)
    pValRef->pObject->addAttribute(ATTRIBUT_CONCERN_CODE, sConcept) ;

	// Create Propositions
  //
  string sMaxId = string("0") ;

  EquiItemIter itemsIter = pDrugsRefs->begin() ;
	for ( ; pDrugsRefs->end() != itemsIter ; itemsIter++)
	{
    NSLdvDrug* pDrug = pDrugs->getDrug(**itemsIter) ;

    if (NULL != pDrug)
    {
    	string sPropTitle    = pDrug->sTitreCourt ;
			string sPropGroup    = string("") ;
    	string sPropHelp     = string("") ;
      string sPropCheck    = string("") ;
      string sPropEvidence = string("") ;
      string sUncheckArche = string("") ;
			ReferentialPropParamsDialog *pParamsDlg = new ReferentialPropParamsDialog(pCallingView, pContexte, &sPropTitle, &sPropGroup, &sPropHelp, &(pDrug->sTitreCourt), &(pDrug->sTitre), &sPropCheck, &sPropEvidence, &sUncheckArche) ;
			int iParamsResult = pParamsDlg->Execute() ;
			delete pParamsDlg ;

      if (IDOK == iResult)
      {
        incremente_code(sMaxId) ;
        string sNumId = string("o") + sMaxId ;

      	CValeur* pValProp = new CValeur(LABEL_PROPOSITION, string(""), string(""), &referential) ;
				referential.vect_val.push_back(pValProp) ;
				pValProp->pObject = new Cproposition(string(""), string(""), &referential, pContexte) ;

        Cproposition* pProposition = dynamic_cast<Cproposition*>(pValProp->pObject) ;

        pProposition->addAttribute(ATTRIBUT_PROP_ID,           sNumId) ;
        pProposition->addAttribute(ATTRIBUT_PROP_NOM,          sPropTitle) ;

        if (string("") != sPropGroup)
          pProposition->addAttribute(ATTRIBUT_PROP_GROUPE,       sPropGroup) ;
        if (string("") != sPropHelp)
          pProposition->addAttribute(ATTRIBUT_PROP_HELP,         sPropHelp) ;
        if (string("") != sPropCheck)
          pProposition->addAttribute(ATTRIBUT_PROP_AUTOCHECK,    sPropCheck) ;
        if (string("") != sPropEvidence)
          pProposition->addAttribute(ATTRIBUT_PROP_EVIDENCE_LVL, sPropEvidence) ;
        if (string("") != sUncheckArche)
          pProposition->addAttribute(ATTRIBUT_PROP_UNCHECK_ARCH, sUncheckArche) ;

        CValeur* pValTree = new CValeur(LABEL_TREE, string(""), string(""), pProposition) ;
				pProposition->vect_val.push_back(pValTree) ;
				pValTree->pObject = new Ctree(string(""), string(""), pProposition, pContexte) ;

        Ctree* pTree = dynamic_cast<Ctree*>(pValTree->pObject) ;

        pDrug->createXmlTree(pTree, string("ZPOMR/N0000")) ;
      }
    }
	}

	// Filename = Archetype ID where '.' are replaced with "_"
  //
	string sFileName = sID ;

  size_t j ;
	while ((j = sFileName.find(".")) != NPOS)
		sFileName.replace( j, 1, "_") ;

  sFileName += string(".xml") ;

  ofstream outFile ;
  string sFileToSave = pContexte->PathName("INEW") + sFileName ;
  outFile.open(sFileToSave.c_str(), ios::ate | ios::app) ;
  if (!outFile)
  {
		string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningOutputFile") + string(" ") + sFileToSave ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
    return ldvseInterfaceError ;
	}

	referential.inscritFichier(&outFile, 0, LABEL_REFERENTIEL) ;

  outFile.close() ;

  pContexte->getSuperviseur()->ReferenceTousArchetypes() ;

	return ldvseNoError ;
}
catch (...)
{
	erreur("Exception NSLdvDocument::DrugCreateProtocolForSelectionService.", standardError, 0) ;
  return ldvseInterfaceError ;
}
}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugAddToProtocolForSelectionService(TWindow* pCallingView, VecteurString* pDrugsRefs)
{
try
{
	if ((NULL == pDrugsRefs) || (true == pDrugsRefs->empty()))
		return ldvseNothingToDo ;

	// Selecting the protocol
  //
	ReferentialChoiceDialog *pProtocolSelect = new ReferentialChoiceDialog(pCallingView, pContexte, string("N0000"), ReferentialChoiceDialog::sortDrugs) ;
  int iResult = pProtocolSelect->Execute() ;

  if (iResult != IDOK)
	{
  	delete (pProtocolSelect) ;
  	return ldvseCanceledByUser ;
	}

  string sRefID = pProtocolSelect->getSelectedRefId() ;

  delete (pProtocolSelect) ;

	if (string("") == sRefID)
  	return ldvseInvalidData ;

	// Opening the file and parsing it
  //
  NSSuper *pSuper = pContexte->getSuperviseur() ;
  string sRefFile = pSuper->getArcManager()->DonneFichierArchetypeParNom(NSArcManager::referentiel, sRefID) ;
  if (string("") == sRefFile)
    return ldvseInvalidData ;

  string ps = string("Parsing file ") + sRefFile ;
  pSuper->trace(&ps, 1) ;

  nsrefParseur Parseur(pContexte) ;
  if (!(Parseur.open(sRefFile)))
    return ldvseInvalidData ;

  if ((NULL == Parseur.pReferentiel) || (!(Parseur.pReferentiel->getValArray())))
  {
  	string sErrorText = pSuper->getText("referentialManagement", "invalidReferential") + string(" ") + sRefID ;
    pSuper->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return ldvseInvalidData ;
  }

  //
  // Find max Id for existing propositions
  //
  string sMaxPropId = string("") ;
  if (false == Parseur.pReferentiel->vect_val.empty())
  {
    Creferentiel* pRef = Parseur.pReferentiel ;
    for (ValIter ival = pRef->vect_val.begin() ; pRef->vect_val.end() != ival ; ival++)
    {
      // on r�cup�re l'objet dialogue
      if (LABEL_PROPOSITION == (*ival)->sLabel)
      {
        Cproposition *pCprop = dynamic_cast<Cproposition *>((*ival)->pObject) ;
        if (NULL != pCprop)
        {
          string sProId = pCprop->getStringAttribute(ATTRIBUT_PROP_ID) ;
          if ((strlen(sProId.c_str()) > strlen(sMaxPropId.c_str())) ||
              ((strlen(sProId.c_str()) == strlen(sMaxPropId.c_str())) && (sProId > sMaxPropId))
              )
            sMaxPropId = sProId ;
        }
      }
    }
  }
  if (string("") == sMaxPropId)
    sMaxPropId = string("o0") ;

  // Creating new Propositions
  //
  EquiItemIter itemsIter = pDrugsRefs->begin() ;
	for ( ; pDrugsRefs->end() != itemsIter ; itemsIter++)
	{
    NSLdvDrug* pDrug = pDrugs->getDrug(**itemsIter) ;

    if (NULL != pDrug)
    {
    	string sPropTitle    = pDrug->sTitreCourt ;
			string sPropGroup    = string("") ;
    	string sPropHelp     = string("") ;
      string sPropCheck    = string("") ;
      string sPropEvidence = string("") ;
      string sUncheckArche = string("") ;
			ReferentialPropParamsDialog *pParamsDlg = new ReferentialPropParamsDialog(pCallingView, pContexte, &sPropTitle, &sPropGroup, &sPropHelp, &(pDrug->sTitreCourt), &(pDrug->sTitre), &sPropCheck, &sPropEvidence, &sUncheckArche) ;
			int iParamsResult = pParamsDlg->Execute() ;
			delete pParamsDlg ;

      if (IDOK == iResult)
      {
        if ('o' == sMaxPropId[0])
        {
          if (strlen(sMaxPropId.c_str()) == 1)
            sMaxPropId = string("o1") ;
          else
          {
            string sCounter = string(sMaxPropId, 1, strlen(sMaxPropId.c_str()) - 1) ;
            incremente_code(sCounter) ;
            sMaxPropId = string("o") + sCounter ;
          }
        }
        else
          incremente_code(sMaxPropId) ;

      	CValeur* pValProp = new CValeur(LABEL_PROPOSITION, string(""), string(""), Parseur.pReferentiel) ;
				Parseur.pReferentiel->vect_val.push_back(pValProp) ;
				pValProp->pObject = new Cproposition(string(""), string(""), Parseur.pReferentiel, pContexte) ;

        Cproposition* pProposition = dynamic_cast<Cproposition*>(pValProp->pObject) ;

        pProposition->addAttribute(ATTRIBUT_PROP_ID,           sMaxPropId) ;
        pProposition->addAttribute(ATTRIBUT_PROP_NOM,          sPropTitle) ;

        if (string("") != sPropGroup)
          pProposition->addAttribute(ATTRIBUT_PROP_GROUPE,       sPropGroup) ;
        if (string("") != sPropHelp)
          pProposition->addAttribute(ATTRIBUT_PROP_HELP,         sPropHelp) ;
        if (string("") != sPropCheck)
          pProposition->addAttribute(ATTRIBUT_PROP_AUTOCHECK,    sPropCheck) ;
        if (string("") != sPropEvidence)
          pProposition->addAttribute(ATTRIBUT_PROP_EVIDENCE_LVL, sPropEvidence) ;
        if (string("") != sUncheckArche)
          pProposition->addAttribute(ATTRIBUT_PROP_UNCHECK_ARCH, sUncheckArche) ;

        CValeur* pValTree = new CValeur(LABEL_TREE, string(""), string(""), pProposition) ;
				pProposition->vect_val.push_back(pValTree) ;
				pValTree->pObject = new Ctree(string(""), string(""), pProposition, pContexte) ;

        Ctree* pTree = dynamic_cast<Ctree*>(pValTree->pObject) ;

        pDrug->createXmlTree(pTree, string("ZPOMR/N0000")) ;
      }
    }
	}

  // File saving
  //
	ofstream outFile ;
  string sFileToSave = sRefFile ;
  outFile.open(sFileToSave.c_str(), ios::ate | ios::trunc) ;
  if (!outFile)
  {
		string sErrorText = pSuper->getText("fileErrors", "errorOpeningOutputFile") + string(" ") + sFileToSave ; 
    pSuper->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
    return ldvseInterfaceError ;
	}

	Parseur.pReferentiel->inscritFichier(&outFile, 0, LABEL_REFERENTIEL) ;

  outFile.close() ;

	return ldvseNoError ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSLdvDocument::DrugAddToProtocolForSelectionService : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
  return ldvseInterfaceError ;
}
catch (...)
{
  erreur("Exception NSLdvDocument::DrugAddToProtocolForSelectionService.", standardError, 0) ;
  return ldvseUndefined ;
}
}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::DrugSelectProtocolForConcern(TWindow* pCallingView, string sRelatedConcern)
{
try
{
	if (!(pContexte->userHasPrivilege(NSContexte::createDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ldvseInsuficientRights ;
	}

  string sConcernLexiqueCode = string("") ;

  if (string("") != sRelatedConcern)
  {
    if (NULL == pPathoPOMRIndex)
      return ldvseInvalidData ;

	  PatPathoIter pptIter = pPathoPOMRIndex->ChercherNoeud(sRelatedConcern) ;
    if ((NULL == pptIter) || (pPathoPOMRIndex->end() == pptIter))
		  return ldvseInvalidData ;

    sConcernLexiqueCode = (*pptIter)->getLexiqueSens(pContexte) ;
  }

  string sRefID = string("") ;

  ReferentialChoiceDialog *pProtocolSelect = new ReferentialChoiceDialog(pCallingView, pContexte, string("N0000"), ReferentialChoiceDialog::sortDrugs, sConcernLexiqueCode) ;

  // Check if there is a single proposal
  //
  pProtocolSelect->InitArray() ;
  if (pProtocolSelect->_aArray.size() == 1)
  {
    RefInfoStorageIter it = pProtocolSelect->_aArray.begin() ;
    sRefID = (*it)->sRefId ;
  }
  else
  {
    // If there is no ref for the concept, we extand inquiry to semantic fathers
    //
    if (pProtocolSelect->_aArray.size() == 0)
    {
      pProtocolSelect->_bUseSemanticNetwork = true ;
      pProtocolSelect->InitArray() ;
    }

    int iResult = pProtocolSelect->Execute() ;

    if (iResult != IDOK)
	  {
  	  delete (pProtocolSelect) ;
  	  return ldvseCanceledByUser ;
	  }

    sRefID = pProtocolSelect->getSelectedRefId() ;
  }

  delete (pProtocolSelect) ;

	if (string("") == sRefID)
  	return ldvseInvalidData ;

	// on enregistre ici dans l'index de sant�
  //
	pContexte->getPatient()->CmGenericReferentiel(sRefID, string(""), sRelatedConcern) ;

  // Prise en compte du  sur la Ligne de vie
  invalidateViews("DRUG_NEW") ;

  return ldvseNoError ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSLdvDocument::DrugSelectProtocolForConcern: ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
  return ldvseInterfaceError ;
}
catch (...)
{
  erreur("Exception NSLdvDocument::DrugSelectProtocolForConcern.", standardError, 0) ;
  return ldvseUndefined ;
}
}

//
// Goal oriented services
//

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::GoalFromProtocolService(TWindow* pCallingView, VecteurString* pRelatedConcerns)
{
try
{
	if (!(pContexte->userHasPrivilege(NSContexte::createDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ldvseInsuficientRights ;
	}

  ReferentialChoiceDialog *pProtocolSelect = new ReferentialChoiceDialog(pCallingView, pContexte, string("0OBJE")) ;
  int iResult = pProtocolSelect->Execute() ;

  if (iResult != IDOK)
	{
  	delete (pProtocolSelect) ;
  	return ldvseCanceledByUser ;
	}

  string sRefID = pProtocolSelect->getSelectedRefId() ;

  delete (pProtocolSelect) ;

	if (string("") == sRefID)
  	return ldvseInvalidData ;

	// on enregistre ici dans l'index de sant�
  //
	pContexte->getPatient()->CmReferentiel(sRefID, string("")) ;

  return ldvseNoError ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSLdvDocument::GoalFromProtocolService : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
  return ldvseInterfaceError ;
}
catch (...)
{
  erreur("Exception NSLdvDocument::GoalFromProtocolService.", standardError, 0) ;
  return ldvseUndefined ;
}
}

NSLdvDocument::LDVSERVICESERROR
NSLdvDocument::NewAppointmentService(TWindow* pCallingView)
{
try
{
/*
	if (!(pContexte->userHasPrivilege(NSContexte::createDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ldvseInsuficientRights ;
	}
*/

	string sAppointmentDate = pContexte->getPatient()->getConvoc() ;

	NVLdVTemps tAppointmentDate ;
  if (string("") != sAppointmentDate)
		tAppointmentDate.initFromDate(sAppointmentDate) ;
	else
  	tAppointmentDate.takeTime() ;

  NSConvocDlg *pAppointmentSetter = new NSConvocDlg(pCallingView, pContexte, &tAppointmentDate) ;
  int iResult = pAppointmentSetter->Execute() ;

  if (iResult != IDOK)
	{
  	delete (pAppointmentSetter) ;
  	return ldvseCanceledByUser ;
	}

  pContexte->getPatient()->setConvoc(tAppointmentDate.donneDateHeure()) ;

  delete (pAppointmentSetter) ;

  char szInstance[128] ;
  sprintf(szInstance, "%d", pContexte->getSuperviseur()->getInstance()) ;

  NSPersonsAttributesArray PatiensList ;
  NSBasicAttributeArray    AttrList ;

  AttrList.push_back(new NSBasicAttribute(CONSOLE,          string(pContexte->getSuperviseur()->getConsole()))) ;
  AttrList.push_back(new NSBasicAttribute(INSTANCE,	        string(szInstance))) ;
  AttrList.push_back(new NSBasicAttribute(OPERATOR,         pContexte->getUtilisateurID())) ;
  AttrList.push_back(new NSBasicAttribute(PERSON,           pContexte->getPatient()->getNss())) ;
	AttrList.push_back(new NSBasicAttribute(APPOINTMENT_DATE, pContexte->getPatient()->getConvoc())) ;

  bool bRes = pContexte->pPilot->modifyTraitsForPersonOrObject(NautilusPilot::SERV_MODIFY_PERSON_TRAITS.c_str(), &PatiensList, &AttrList) ;
  if (false == bRes)
  	return ldvseInterfaceError ;

  return ldvseNoError ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSLdvDocument::NewAppointmentService : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
  return ldvseInterfaceError ;
}
catch (...)
{
  erreur("Exception NSLdvDocument::NewAppointmentService.", standardError, 0) ;
  return ldvseUndefined ;
}
}



void
NSLdvDocument::addConcern(string sTitle, string sDateDeb, string sDateFin, string sHIssue, string sRef, string sPbOrigine)
{
try
{
	NSConcern* pLdvPb = new NSConcern(pContexte, this) ;

	pLdvPb->sTitre      = sTitle ;

	pLdvPb->tDateOuverture.initFromDate(sDateDeb) ;
	pLdvPb->tDateFermeture.initFromDate(sDateFin) ;

	pLdvPb->sHealthIssue    = sHIssue ;
	pLdvPb->sPrimoPb        = sPbOrigine ;
	pLdvPb->sReference      = sRef ;

	pConcerns->push_back(pLdvPb) ;

	TView* pView = GetViewList() ;
  if (NULL == pView)
  	return ;

	do
	{
		NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView);
		if (pLdvView)
			pLdvView->addProb(pLdvPb) ;

		pView = NextView(pView) ;
	}
  while (pView) ;
}
catch (...)
{
  erreur("Exception NSLdvDocument::addConcern.", standardError, 0) ;
}
}


void
NSLdvDocument::addObjet(string sTitle, string sDateDeb, string sDateFin, string sPb, string sRef, string sTypDoc, string sTypeContenu)
{
try
{
	NSLdvObjet *pLdvObj = new NSLdvObjet(pContexte) ;

	pLdvObj->sTitre     = sTitle ;
	pLdvObj->tDateHeureDebut.initFromDate(sDateDeb) ;
	pLdvObj->tDateHeureFin.initFromDate(sDateFin) ;
	pLdvObj->sConcern   = sPb ;
	pLdvObj->sReference = sRef ;
	pLdvObj->sTypeDoc   = sTypDoc ;
  pLdvObj->sLexique   = sTypeContenu ;

	pObjets->push_back(pLdvObj) ;

	TView* pView = GetViewList();
  if (NULL == pView)
  	return ;

	do
	{
  	NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView) ;
		if (pLdvView)
			pLdvView->addObj(pLdvObj) ;

		pView = NextView(pView) ;
	}
	while (pView) ;
}
catch (...)
{
	erreur("Exception NSLdvDocument::addObjet.", standardError, 0) ;
}
}


void
NSLdvDocument::addSsObjet(string sTitle, string sDateDeb, string sDateFin, string sPb, string sRef, string sObjet)
{
try
{
	NSLdvSousObjet* pLdvSsObj = new NSLdvSousObjet(pContexte) ;

	pLdvSsObj->sTitre = sTitle ;

	pLdvSsObj->tDateHeureDebut.initFromDate(sDateDeb) ;
	pLdvSsObj->tDateHeureFin.initFromDate(sDateFin) ;

	pLdvSsObj->sConcern     = sPb ;
	pLdvSsObj->sReference   = sRef ;
	pLdvSsObj->sObject      = sRef ;

	pSousObjets->push_back(pLdvSsObj) ;

	TView* pView = GetViewList() ;
  if (NULL == pView)
		return ;

	do
	{
		NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView) ;
		if (pLdvView)
			pLdvView->addSsObj(pLdvSsObj) ;

		pView = NextView(pView) ;
	}
  while (pView) ;
}
catch (...)
{
  erreur("Exception NSLdvDocument::addSsObjet.", standardError, 0) ;
}
}


void
NSLdvDocument::addGoal(string sTitle, string sDateDeb, string sDateFin, string sPb, string sRef)
{
try
{
	NSLdvGoal *pGoal = new NSLdvGoal(pContexte) ;

	pGoal->sTitre = sTitle ;

	pGoal->tDateOuverture.initFromDate(sDateDeb) ;
	pGoal->tDateFermeture.initFromDate(sDateFin) ;

	pGoal->sConcern     = sPb ;
	pGoal->sReference   = sRef ;

	pGoals->push_back(pGoal) ;

	/*

	// ---------------------------------------------------------------------------
	// voir comment on va afficher r�ellement les diff�rents objectifs
	// ---------------------------------------------------------------------------

	TView* pView = GetViewList();
	do
	{
		NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView);
		if (pLdvView)
			pLdvView->addGoal(pGoal);

		pView = NextView(pView);
	}
	while (pView);

	*/
}
catch (...)
{
	erreur("Exception NSLdvDocument::addGoal.", standardError, 0) ;
}
}


void
NSLdvDocument::addFromBasketList()
{
try
{
	SOAPBasketArray *pBasketArray = pContexte->getSuperviseur()->getEpisodus()->pBasketList ;

	if (pBasketArray->empty())
  	return;

	// On passe en revue chaque panier - Looking into each basket
	for (SOAPBasketArrayIter basketIter = pBasketArray->begin() ; basketIter != pBasketArray->end() ; basketIter++)
	{
		// On prend l'objet qui constitue le 'A' du panier
    // Taking the object which represents the 'A' position in the basket
		SOAPObject *pSOAPObj = (*basketIter)->donneDiagObject() ;

		// On regarde s'il appartient d�j� aux sous-objets de la Ligne de vie
		// We check that it doesn't already belongs to Ligne de vie's sub-objects
		ArraySsObjIter ssObjIter = pSousObjets->begin() ;
    for ( ; (ssObjIter != pSousObjets->end()) && ((*ssObjIter)->sReference != pSOAPObj->sNoeud) ; ssObjIter++)
    	;

		if (ssObjIter == pSousObjets->end())
    {
			// Cr�ation d'un sous-objet de la ligne de vie
			// Creation of a new sub-object of the Ligne de vie
			NSLdvSousObjet  *pLdvSsObj = new NSLdvSousObjet(pContexte) ;

			pLdvSsObj->sTitre = pSOAPObj->donneLibelle() ;
			pLdvSsObj->tDateHeureDebut.takeTime() ;
			pLdvSsObj->tDateHeureFin.takeTime() ;
			pLdvSsObj->sReference = pSOAPObj->sNoeud ;
			pLdvSsObj->sObject  = "" ;
			pLdvSsObj->sConcern = "" ;

			pSousObjets->push_back(pLdvSsObj) ;

			// On r�percute la cr�ation � chaque vue
			// We tell each view there is a new sub-object
			TView* pView = GetViewList() ;
      if (NULL != pView)
      {
				do
				{
					NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView) ;
					if (pLdvView)
						pLdvView->addSsObj(pLdvSsObj) ;

					pView = NextView(pView) ;
				}
				while (pView) ;
      }
		}
	}
}
catch (...)
{
	erreur("Exception NSLdvDocument::addFromBasketList.", standardError, 0) ;
}
}


bool
NSLdvDocument::openLdVObject(NSLdvObjet *pObj)
{
	if (!pObj)
		return false ;

	string  sObjRef = pObj->sReference ;

	NSPatientChoisi* pPat = pContexte->getPatient() ;
	if (!pPat)
		return false ;

	// Document his
	NSHISTODocument* pHistory = pPat->pDocHis ;
	if (!pHistory)
  	return false ;

	if (pHistory->VectDocument.empty())
  	return false ;

	DocumentIter iterDoc = pHistory->VectDocument.begin() ;
	for (; iterDoc != pHistory->VectDocument.end(); iterDoc++)
		if (sObjRef == (*iterDoc)->getID())
    	pHistory->AutoriserOuverture((NSDocumentInfo *)(*iterDoc)) ;

	// La Synth�se et l'Index POMR ne sont pas affich�s
	// Synthesis and POMR index are not displayed
	return true ;
}

bool
NSLdvDocument::openLdVObjectsInArray(ArrayObjets* pObjects, NSLdvView* pView)
{
try
{
	if ((!pObjects) || (pObjects->empty()))
		return false ;

	// S'il n'y en a qu'un, on l'ouvre directement
	//
	ArrayObjIter objIt = pObjects->begin() ;
	NSLdvObjet*  pFirstObj = *objIt ;
	objIt++ ;
	if (objIt == pObjects->end())
  	return openLdVObject(pFirstObj) ;

	NSOpenMultiDocsDlg* pOpenDlg = new NSOpenMultiDocsDlg(pView, pContexte, pObjects) ;
	int iResult = pOpenDlg->Execute() ;
	delete pOpenDlg ;

	if ((iResult == IDOK) && (!(pObjects->empty())))
	{
  	objIt = pObjects->begin() ;
    for ( ; objIt != pObjects->end(); objIt++)
    	openLdVObject(*objIt) ;
	}
	return true ;
}
catch (...)
{
	erreur("Exception NSLdvDocument::openLdVObjectsInArray.", standardError, 0) ;
	return false;
}
}

bool
NSLdvDocument::newConcern(string sLexique, string *psNode, string sDateDeb, string sDateFin, int iGravite, string sCocCode, int iRisque, NSPatPathoArray *pDetails, string sTL /*= ""*/)
{
try
{
	string ps2 = "NSLdvDocument::newConcern : begin" ;
  pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trSubSteps) ;

	*psNode = "" ;

	// Can we work ?
	if (!(pContexte->getPatient()))
	{
		erreur("Erreur grave (patient introuvable). Vous devriez relancer le logiciel.", standardError, 0) ;
		return false ;
	}

  DocumentIter iterDoc = pContexte->getPatient()->trouveIndexSante() ;
  if (iterDoc == NULL)
  	return false ;

	// Health index found
	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *((*iterDoc)->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;

	NSPatPathoArray *pPt = Noyau.pPatPathoArray ;

	// On cherche le chapitre "pr�occupations de sant�"
	// Looking for "Health concerns" chapter
	PatPathoIter iter = pPt->ChercherItem("0PRO11") ;

	if ((iter == NULL) || (iter == pPt->end()))
	{
		erreur("Erreur grave : le document Index de sant� de ce patient ne poss�de pas de chapitre Pr�occupations de sant�.", standardError, 0) ;
		return false ;
	}

	// Ajout d'un nouveau segment d'arbre
	// Adding a new tree branch
	NSPatPathoArray PatPatho(pContexte) ;

	if (sLexique != string("�?????"))
		PatPatho.ajoutePatho(sLexique, 0) ;
	else
	{
		Message Msg ;
		Msg.SetLexique(sLexique) ;
		Msg.SetTexteLibre(sTL) ;
		PatPatho.ajoutePatho(sLexique, &Msg, 0) ;
	}

  if (string("") != sCocCode)
  {
    Message Msg ;
		Msg.SetComplement(sCocCode) ;
		PatPatho.ajoutePatho("6CISP1", &Msg, 1) ;
  }

	// Date de d�but - Date of start
	if ((string("") != sDateDeb) && (sDateDeb != string("19000000000000")) && (sDateDeb != string("00000000000000")))
	{
		PatPatho.ajoutePatho("KOUVR1", 1) ;
		Message Msg ;
    Msg.SetUnit("2DA021") ;
		Msg.SetComplement(sDateDeb) ;
		PatPatho.ajoutePatho("�T0;19", &Msg, 2) ;
	}

	// Date de fin - Date of ending
	if ((sDateFin != "") && (sDateFin != string("19000000000000")) &&	(sDateFin != string("00000000000000")))
	{
		PatPatho.ajoutePatho("KFERM1", 1) ;
		Message Msg ;
    Msg.SetUnit("2DA021") ;
		Msg.SetComplement(sDateFin) ;
		PatPatho.ajoutePatho("�T0;19", &Msg, 2) ;
	}

	// Quantification
	if ((iGravite > 0) || (iRisque > 0))
	{
		PatPatho.ajoutePatho("VQUAN1", 1) ;

		PatPatho.ajoutePatho("KDAT01", 2) ;
		Message Msg ;
		Msg.SetUnit("2DA021") ;
		Msg.SetComplement(sDateDeb) ;
		PatPatho.ajoutePatho("�T0;19", &Msg, 3) ;

		// Index de gravit�
		if (iGravite > 0)
		{
			PatPatho.ajoutePatho("VIGRA1", 2) ;

			char szGravite[4] ;
			numacar(szGravite, iGravite, 3) ;
			Message Msg2 ;
      Msg2.SetUnit("200001") ;
			Msg2.SetComplement(string(szGravite)) ;
			PatPatho.ajoutePatho("�N2;04", &Msg2, 3) ;
		}

		// Index de risque
		if (iRisque > 0)
		{
			PatPatho.ajoutePatho("VIRIS1", 2) ;

			char szRisque[4] ;
			numacar(szRisque, iRisque, 3) ;
			Message Msg2 ;
      Msg2.SetUnit("200001") ;
			Msg2.SetComplement(string(szRisque)) ;
			PatPatho.ajoutePatho("�N2;04", &Msg2, 3) ;
		}
	}

	// Details
	if (pDetails && (!(pDetails->empty())))
		PatPatho.InserePatPatho(PatPatho.end(), pDetails, 1) ;

	// Ajout de la branche � l'arbre Index de sant�
	// Adding the branch to the Health index tree

	// On cherche o� il faut ins�rer la branche
	// Looking for the place to insert the branch
	int colonneMere = (*iter)->getColonne() ;
	iter++ ;
	while ((iter != pPt->end()) && ((*iter)->getColonne() > colonneMere))
		iter++ ;

	if (iter != pPt->end())
		pPt->InserePatPatho(iter, &PatPatho, colonneMere + 1) ;
	else
  	pPt->InserePatPatho(iter, &PatPatho, colonneMere + 1) ;

	// En n-tiers, on cr�e les liens avant l'enregistrement de la patpatho
	//
	int ligPreo, colPreo ;

	if (iGravite > 0)
  {
  	// On cherche la pr�occupation qui vient d'�tre cr��e (derni�re du genre)
    // Looking for the concern we have just created (last of the kind)
    pContexte->getPatient()->pGraphPerson->setTree(pPt, "") ;
		iter = pPt->begin() ;
		if ((*iter)->getLexiqueSens(pContexte) != string("ZPOMR"))
		{
			erreur("Erreur � l'inscription de la gravit� et du risque : le document Index de sant� de ce patient semble endommag�.", standardError, 0) ;
			return false ;
		}
		iter = pPt->ChercherItem("0PRO11") ;
		if ((iter == NULL) || (iter == pPt->end()))
		{
			erreur("Erreur � l'inscription de la gravit� et du risque : le document Index de sant� de ce patient ne poss�de pas de chapitre Pr�occupations de sant�.", standardError, 0) ;
			return false ;
		}
		int iConcernCol = (*iter)->getColonne() ;
		iter++ ;

		PatPathoIter iterConcern = pPt->begin() ;
		while ((iter != pPt->end()) && ((*iter)->getColonne() > iConcernCol))
		{
			if ((*iter)->getLexique() == sLexique)
				iterConcern = iter ;
			iter++ ;
		}
		if (iterConcern == pPt->begin())
		{
			erreur("Erreur � l'inscription de la gravit� et du risque : impossible de retrouver la pr�occupation de sant�.", standardError, 0) ;
			return false ;
		}

    PatPathoIter iterQuantif = pPt->ChercherItem(string("VQUAN1"), iterConcern) ;
		if ((iterQuantif == NULL) || (iterQuantif == pPt->end()))
		{
			erreur("Erreur � la connexion � la Ligne de vie des index de quantification : le document de contact ne semble pas correctement sauvegard�.", standardError, 0) ;
			return false ;
		}

    //(*iterQuantif)->addTemporaryLink(*iterConcern, NSRootLink::problemContactElement, NSLinkedNode::dirFleche) ;
    // on fait ici un setTree pour appeler numberTemporarayNodes avant de faire la copie
    // de la patpatho - avec ses liens en attente - qui a lieu dans enregistrePatPatho
    pContexte->getPatient()->pGraphPerson->pLinkManager->etablirLien((*iterQuantif)->getNode(), NSRootLink::problemContactElement, (*iterConcern)->getNode()) ;

    ligPreo = (*iterConcern)->getLigne() ;
    colPreo = (*iterConcern)->getColonne() ;
	}

	ps2 = "NSLdvDocument::newConcern : before enregistrePatPatho" ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trSubSteps) ;

	Noyau.enregistrePatPatho() ;

	ps2 = "NSLdvDocument::newConcern : before chargePatPatho" ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trSubSteps) ;

	// Mise � jour de l'historique
	/* bool bReload = */ Noyau.chargePatPatho() ;
	pPt = Noyau.pPatPathoArray ;
	pContexte->getPatient()->pDocHis->Rafraichir(&Docum, pPt, &Noyau) ;

	if (iGravite > 0)
  {
  	PatPathoIter iterPreo = pPt->ChercherItem(ligPreo, colPreo) ;
    *psNode = (*iterPreo)->getNode() ;
	}

	pContexte->getSuperviseur()->getBBinterface()->insertAnswerOnBlackboard("Preocupation", &PatPatho, Preocupation) ;

	ps2 = "NSLdvDocument::newConcern : before reinit and invalidateViews" ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trSubSteps) ;

	getConcerns()->reinit() ;

	invalidateViews("CONCERN_NEW") ;

	// on appelle la fonction addDatasFromNautilusOnBlackboard par un todo
	//addDatasFromNautilusOnBlackboard(pContexte, pPt) ;
  /*#ifdef __OB1__
  pContexte->getSuperviseur()->blackboardInterface->insertAnswerOnBlackboard("Preocupation", pPt, Preocupation);
  #else
	NSToDoTask  *pTask = new NSToDoTask() ;

	pTask->sWhatToDo = "AddDatasOnBBK" ;
	pTask->pPointer1 = (void *)pPt ;

	pContexte->getSuperviseur()->aToDo.push_back(pTask) ;
	pContexte->getSuperviseur()->pNSApplication->GetMainWindow()->PostMessage(WM_COMMAND, IDM_TODO) ;
  #endif        */
	ps2 = "NSLdvDocument::newConcern : done" ;
  pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trSubSteps) ;

	return true ;
}
catch (...)
{
	erreur("Exception NSLdvDocument::newConcern.", standardError, 0) ;
	return false ;
}
}


bool
NSLdvDocument::evolConcern(NSConcern *pPere, string sLexique, string sDateDeb, string sDateFin)
{
  return true ;
}


bool
NSLdvDocument::changeConcernDateDeb(NSConcern* pConcern, NVLdVTemps* pDateDeb)
{
	if (*pDateDeb == pConcern->tDateOuverture)
		return true ;

	NVLdVTemps tPreviousDateDeb = pConcern->tDateOuverture ;

	// Recherche de cette pr�occupation dans l'index de sant�
	// Looking for this concern in the health index document
	NSPatPathoArray* pPatho ;
	PatPathoIter iter = donnePreoccup(pConcern, &pPatho) ;

	// not found !
	if ((iter == NULL) || (iter == pPatho->end()))
		return false ;

	int iColonne = (*iter)->getColonne() ;

	PatPathoIter iterBis = pPatho->begin() ;
	iterBis = iter ;

	iterBis++;
	while (	(iterBis != pPatho->end()) && ((*iterBis)->getColonne() > iColonne) &&
					(((*iterBis)->getColonne() != iColonne+1) ||
						((*iterBis)->getLexiqueSens(pContexte) != string("KOUVR"))))
		iterBis++ ;

	if ((iterBis == pPatho->end()) || ((*iterBis)->getColonne() != iColonne+1))
		return false ;

	iterBis++ ;
	(*iterBis)->setComplement(pDateDeb->donneDateHeure()) ;

	pConcern->tDateOuverture = *pDateDeb ;

	// S'il y a un �l�ment de quantification qui d�marre � date_deb, il faut
    // le modifier �galement
	iterBis = iter ;

	iterBis++ ;
	while (	(iterBis != pPatho->end()) && ((*iterBis)->getColonne() > iColonne) &&
					(((*iterBis)->getColonne() != iColonne+1) ||
						((*iterBis)->getLexiqueSens(pContexte) != string("VQUAN"))))
		iterBis++ ;

	if ((iterBis == pPatho->end()) || ((*iterBis)->getColonne() != iColonne+1))
  	return true ;

	// On passe en revue tous les �l�ments de quantification
	iterBis++ ;
	while (	(iterBis != pPatho->end()) &&
					((*iterBis)->getColonne() > iColonne+1))
	{
		if (((*iterBis)->getColonne() == iColonne+2) &&
				((*iterBis)->getLexiqueSens(pContexte) == string("KDAT0")))
		{
			iterBis++ ;
			if ((*iterBis)->getComplement() == tPreviousDateDeb.donneDateHeure())
			{
      	(*iterBis)->setComplement(pDateDeb->donneDateHeure()) ;

				// Mise � jour du modificateur
				// Recherche de cette pr�occupation dans l'Array
				// Looking for this health upset in the Array
				if (!(pConcern->aModificateurs.empty()))
				{
					ArrayModifierIter iModif = pConcern->aModificateurs.begin() ;
					for (; iModif != pConcern->aModificateurs.end(); iModif++)
						if ((*iModif)->tDateHeureDeb == tPreviousDateDeb)
							(*iModif)->tDateHeureDeb = *pDateDeb ;
				}
			}
		}
		iterBis++ ;
	}

  return true ;
}

bool
NSLdvDocument::changeConcernDateFin(NSConcern* pConcern, NVLdVTemps* pDateFin)
{
try
{
	if (*pDateFin == pConcern->tDateFermeture)
		return true ;

	NVLdVTemps tPreviousDateFin = pConcern->tDateFermeture ;

	// Recherche de cette pr�occupation dans l'index de sant�
	// Looking for this concern in the health index document
	NSPatPathoArray* pPatho;
	PatPathoIter iter = donnePreoccup(pConcern, &pPatho) ;

    // not found !
	if ((iter == NULL) || (iter == pPatho->end()))
  	return false ;

	int iColonne = (*iter)->getColonne() ;


	// Recherche de la date de fin pour la modifier
	// Looking for ending date - in order to modify it
	PatPathoIter iterBis = pPatho->begin() ;
	iterBis = iter ;

	iterBis++ ;
	while (	(iterBis != pPatho->end()) && ((*iterBis)->getColonne() > iColonne) &&
					(((*iterBis)->getColonne() != iColonne+1) ||
						((*iterBis)->getLexiqueSens(pContexte) != string("KFERM"))))
  	iterBis++ ;

	// On a trouv� une pr�c�dente date de fin, on la modifie modifier
	// We have found a previous ending date, we can change it
	if ((iterBis != pPatho->end()) &&
			((*iterBis)->getColonne() == iColonne+1) &&
			((*iterBis)->getLexiqueSens(pContexte) == string("KFERM")))
	{
		iterBis++ ;
		(*iterBis)->setComplement(pDateFin->donneDateHeure()) ;
	}

	// Si on n'a pas trouv� de date de fin � modifier, on en cr�e une
	// If we didn't find any ending date, we must create it
	else
	{
  	iterBis = iter ;

		// On recherche la date de d�but, pour s'ins�rer juste apr�s
		// Looking for starting date - to insert ending date just after
		iterBis++;
		while (	(iterBis != pPatho->end()) && ((*iterBis)->getColonne() > iColonne) &&
						(((*iterBis)->getColonne() != iColonne+1) ||
						 ((*iterBis)->getLexique() != "KOUVR1")))
			iterBis++ ;

    // Si on est � la fin ou qu'on est tomb� sur un p�re sans passer par une date d'ouverture, on sort
		if ((iterBis == pPatho->end()) || ((*iterBis)->getColonne() != iColonne+1))
    	return false ;

    iterBis++ ;
    while ((iterBis != pPatho->end()) && ((*iterBis)->getColonne() > iColonne+1))
    	iterBis++ ;

		NSPatPathoArray PatPatho(pContexte) ;

    PatPatho.ajoutePatho("KFERM1", 0) ;
    Message Msg ;
    Msg.SetUnit("2DA021") ;
    Msg.SetComplement(pDateFin->donneDateHeure()) ;
    PatPatho.ajoutePatho("�T0;19", &Msg, 1) ;

    pPatho->InserePatPatho(iterBis, &PatPatho, iColonne+1) ;
	}

	pConcern->tDateFermeture = *pDateFin ;

  return true ;
}
catch (...)
{
	erreur("Exception NSLdvDocument::newConcern.", standardError, 0) ;
  return false ;
}
}

bool
NSLdvDocument::changeConcernModifier(NSConcern* pConcern, NSConcernModifier* pModifier, int iSev, int iRisk)
{
try
{
	if (!pModifier)
		return false ;

	NVLdVTemps tDateHeureModif = pModifier->tDateHeureDeb ;

	// Recherche de cette pr�occupation dans l'index de sant�
	// Looking for this concern in the health index document
	NSPatPathoArray* pPatho ;
	PatPathoIter iter = donnePreoccup(pConcern, &pPatho) ;

	// not found !
	if ((iter == NULL) || (iter == pPatho->end()))
		return false ;

	int iColonne = (*iter)->getColonne() ;

	PatPathoIter iterBis = pPatho->begin() ;
  iterBis = iter ;

  iterBis++ ;

	// Positionnement sur le sous arbre des quantifications
	while (	(iterBis != pPatho->end()) && ((*iterBis)->getColonne() > iColonne) &&
					(((*iterBis)->getColonne() != iColonne+1) ||
						((*iterBis)->getLexiqueSens(pContexte) != string("VQUAN"))))
		iterBis++ ;

	if ((pPatho->end() == iterBis) || ((*iterBis)->getColonne() != iColonne+1))
		return true ;

	bool bMisRisk = false;
	bool bMisSeve = false;

	// On passe en revue tous les �l�ments de quantification
	iterBis++;
	while (	(iterBis != pPatho->end()) &&
					((*iterBis)->getColonne() > iColonne+1))
	{
		if (((*iterBis)->getColonne() == iColonne+2) &&
    		((*iterBis)->getLexiqueSens(pContexte) == string("KDAT0")))
		{
			iterBis++ ;
			if ((*iterBis)->getComplement() == tDateHeureModif.donneDateHeure())
			{
				char szGravite[4] ;
				char szRisk[4] ;
				if (iSev > 0)
					numacar(szGravite, iSev, 3) ;
				if (iRisk > 0)
        	numacar(szRisk, iRisk, 3) ;

				while (	(iterBis != pPatho->end()) &&
								((*iterBis)->getColonne() > iColonne+1))
				{
					if (((*iterBis)->getColonne() == iColonne+2) &&
          		((*iterBis)->getLexiqueSens(pContexte) == string("VIGRA")))
					{
						if (iSev > 0)
						{
							iterBis++ ;
							(*iterBis)->setComplement(string(szGravite)) ;
							bMisSeve = true ;
						}
						else
							if (iSev == 0)
							{
								pPatho->SupprimerItem(iterBis) ;
								pPatho->SupprimerItem(iterBis) ;
							}
					}
					else
						if (((*iterBis)->getColonne() == iColonne+2) &&
								((*iterBis)->getLexiqueSens(pContexte) == string("VIRIS")))
						{
							if (iRisk > 0)
							{
								iterBis++ ;
								(*iterBis)->setComplement(string(szRisk)) ;
								bMisRisk = true ;
							}
							else
								if (iRisk == 0)
								{
									pPatho->SupprimerItem(iterBis) ;
									pPatho->SupprimerItem(iterBis) ;
								}
						}
					iterBis++ ;
				}
				if ((!bMisSeve) && (iSev > 0))
				{
					NSPatPathoArray PatPatho(pContexte) ;

					PatPatho.ajoutePatho("VIGRA1", 2) ;

					char szGravite[4] ;
					numacar(szGravite, iSev, 3) ;
					Message Msg ;
          Msg.SetUnit("200001") ;
					Msg.SetComplement(string(szGravite)) ;
					PatPatho.ajoutePatho("�N2;04", &Msg, 3) ;

					pPatho->InserePatPatho(iterBis, &PatPatho, iColonne+1) ;
				}
				if ((!bMisRisk) && (iRisk > 0))
				{
					NSPatPathoArray PatPatho(pContexte) ;

					PatPatho.ajoutePatho("VIRIS1", 2) ;

					char szRisque[4] ;
					numacar(szRisque, iRisk, 3) ;
					Message Msg ;
          Msg.SetUnit("200001") ;
					Msg.SetComplement(string(szRisque)) ;
					PatPatho.ajoutePatho("�N2;04", &Msg, 3) ;

					pPatho->InserePatPatho(iterBis, &PatPatho, iColonne+1) ;
				}
			}
		}
		if (iterBis != pPatho->end())
			iterBis++ ;
	}

	if (iSev != -1)
		pModifier->iSeverite = iSev ;
	if (iRisk != -1)
  	pModifier->iRisque = iRisk ;

	return true;
}
catch (...)
{
	erreur("Exception NSLdvDocument::changeConcernModifier.", standardError, 0) ;
	return false;
}
}


bool
NSLdvDocument::changeConcernType(NSConcern* pConcern, NSPatPathoInfo* pNode)
{
  // Recherche de cette pr�occupation dans l'index de sant�
	// Looking for this concern in the health index document
	NSPatPathoArray* pPatho ;
	PatPathoIter iter = donnePreoccup(pConcern, &pPatho) ;

  // not found !
	if ((iter == NULL) || (iter == pPatho->end()))
		return false ;

  int iColonne = (*iter)->getColonne() ;
	int iLigne   = (*iter)->getLigne() ;
	string sPrevNode = (*iter)->getNode() ;

	(*iter)->setLexique(pNode->getLexique()) ;
	(*iter)->setTexteLibre(pNode->getTexteLibre()) ;

  // Plug all previous links to the new node
  //
  // Now automatically done in NSDataGraph::updateNodesTL
  //
  // NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
	// pGraphe->swapLiens(sPrevNode, *iter) ;

  updateIndex() ;

  // Find back the new node to update the concern
  //
	if (!pPathoPOMRIndex)
		return false ;

	iter = pPathoPOMRIndex->begin() ;
  while (	(pPathoPOMRIndex->end() != iter) &&
					(((*iter)->getColonne() != iColonne) ||
					((*iter)->getLigne() != iLigne)))
    iter++ ;

	// not found !
	if (pPathoPOMRIndex->end() == iter)
		return false ;

  string sNewNode = (*iter)->getNode() ;

  pConcern->sReference = sNewNode ;

	string sCodeLex = (*iter)->getLexique() ;
	if (sCodeLex != string("�?????"))
		pContexte->getDico()->donneLibelle(sLangue, &sCodeLex, &(pConcern->sTitre)) ;
	// Texte libre - Free text
	else
  	pConcern->sTitre = (*iter)->getTexteLibre() ;

	return true ;

/*
	// Recherche de cette pr�occupation dans l'index de sant�
	// Looking for this concern in the health index document
	NSPatPathoArray* pPatho ;
	PatPathoIter iter = donnePreoccup(pConcern, &pPatho) ;

  // not found !
	if ((iter == NULL) || (iter == pPatho->end()))
		return false;

	int iColonne        = (*iter)->getColonne() ;
	int iLigne          = (*iter)->getLigne() ;
	string sPrevNoeud   = (*iter)->getNode() ;

	(*iter)->setLexique(pNode->getLexique()) ;
	(*iter)->setTexteLibre(pNode->getTexteLibre()) ;

	updateIndex() ;

	// On doit retrouver le nouveau noeud pour r�orienter vers lui les liens
	if (!pPathoPOMRIndex)
		return false;

	iter = pPathoPOMRIndex->begin();
	while (	(iter != pPathoPOMRIndex->end()) &&
					(((*iter)->getColonne() != iColonne) ||
					((*iter)->getLigne() != iLigne)))
		iter++;

	// not found !
	if (iter == pPathoPOMRIndex->end())
		return false;

	string sNewNoeud = (*iter)->getNode() ;
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	pGraphe->swapLiens(sPrevNoeud, sNewNoeud);

	pConcern->sReference = sNewNoeud;

	string sCodeLex = (*iter)->getLexique() ;

	if (sCodeLex != string("�?????"))
		pContexte->getDico()->donneLibelle(sLangue, &sCodeLex, &(pConcern->sTitre));

	// Texte libre - Free text
	else
  	pConcern->sTitre = (*iter)->getTexteLibre() ;

	return true ;
*/
}

void
NSLdvDocument::showConcernProperty(NSConcern* pConcern)
{
	if (pContexte->getPatient())
	{
  	string sNode = "" ;
    if (pConcern)
    	sNode = pConcern->getNoeud() ;

    NSSuper *pSuper = pContexte->getSuperviseur() ;

    if ((!(pSuper->getDPIO())) || (!(pSuper->getDPIO()->bMinimalInterface)))
    	pContexte->getPatient()->drugs_show(sNode) ;
    pContexte->getPatient()->goals_show(sNode) ;
    pContexte->getPatient()->followUp_show(sNode) ;
    // if ((!(pSuper->getDPIO())) || (!(pSuper->getDPIO()->bMinimalInterface)))
    //	pContexte->getPatient()->process_show(sNode) ;
  }
    //
    // Recherche de la vue
    //
    /*
    NSLdvView* pLdvView;
    TView* pView = GetViewList();
    do
    {
        pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView);
        if (pLdvView)
            break;

        pView = NextView(pView);
    }
    while (pView);

    if (!pLdvView)
        return;
    */

//    NSConcernPropertyDlg* pCPDialog;
//    pCPDialog = new NSConcernPropertyDlg(pLdvView, pContexte, pConcern);
//    pCPDialog->Create();
}

bool
NSLdvDocument::evolveConcernModifier(NSConcern* pConcern, NVLdVTemps* pDateDeb, int iSev, int iRisk)
{
	// Recherche de cette pr�occupation dans l'index de sant�
	// Looking for this concern in the health index document
	NSPatPathoArray* pPatho ;
	PatPathoIter iter = donnePreoccup(pConcern, &pPatho) ;

	// not found !
	if ((iter == NULL) || (iter == pPatho->end()))
		return false;

	int iColonne = (*iter)->getColonne() ;

	PatPathoIter iterBis = pPatho->begin();
	iterBis = iter;

	// On passe en revue tous les �l�ments de quantification
	iterBis++;
	while (	(iterBis != pPatho->end()) &&
					((*iterBis)->getColonne() > iColonne))
	{
		if (((*iterBis)->getColonne() == iColonne+1) &&
    		((*iterBis)->getLexiqueSens(pContexte) == string("VQUAN")))
		{
			iterBis++;
			while (	(iterBis != pPatho->end()) &&
							((*iterBis)->getColonne() > iColonne+1))
			{
				// Sous arbre date
				if (((*iterBis)->getColonne() == iColonne+1) &&
						((*iterBis)->getLexiqueSens(pContexte) == string("KDAT0")))
				{
					iterBis++ ;
					if ((*iterBis)->getComplement() == pDateDeb->donneDateHeure())
					{
						erreur("Il existe d�j� une modification de s�v�rit� � cette date - utilisez la correction si vous souhaitez la modifier.", standardError, 0) ;
						return false ;
					}
				}
				iterBis++ ;
			}
		}
		if ((iterBis != pPatho->end()) &&
				((*iterBis)->getColonne() > iColonne))
			iterBis++ ;
	}

	// Cr�ation de l'arbre de quantification
	NSPatPathoArray PatPatho(pContexte) ;

	PatPatho.ajoutePatho("VQUAN1", 0) ;

	PatPatho.ajoutePatho("KDAT01", 1) ;
	Message Msg ;
  Msg.SetUnit("2DA021") ;
	Msg.SetComplement(pDateDeb->donneDateHeure()) ;
	PatPatho.ajoutePatho("�T0;19", &Msg, 2) ;

	// Index de gravit�
	if (iSev > 0)
	{
		PatPatho.ajoutePatho("VIGRA1", 1) ;

		char szGravite[4] ;
    numacar(szGravite, iSev, 3) ;
		Message Mes ;
    Mes.SetUnit("200001") ;
		Mes.SetComplement(string(szGravite)) ;
		PatPatho.ajoutePatho("�N2;04", &Mes, 2) ;
	}

	// Index de risque
	if (iRisk > 0)
	{
		PatPatho.ajoutePatho("VIRIS1", 1) ;

		char szRisque[4] ;
		numacar(szRisque, iRisk, 3) ;
		Message Mes ;
    Mes.SetUnit("200001") ;
		Mes.SetComplement(string(szRisque)) ;
		PatPatho.ajoutePatho("�N2;04", &Mes, 2) ;
	}

	// On cherche o� il faut ins�rer la branche
	// Looking for the place to insert the branch
	int iRefLine;

	if (iterBis != pPatho->end())
	{
		iRefLine = (*iterBis)->getLigne() - 1;
		pPatho->InserePatPatho(iterBis, &PatPatho, iColonne + 1);
	}
	else
	{
		iRefLine = pPatho->back()->getLigne();
		pPatho->InserePatPatho(iterBis, &PatPatho, iColonne + 1);
	}

	// Enregistrement du document modifi�
	updateIndex() ;

	iter = donnePreoccup(pConcern, &pPatho) ;

  // not found !
	if ((iter == NULL) || (iter == pPatho->end()))
		return false ;

	string sConcernNode = (*iter)->getNode() ;

	// On passe en revue tous les �l�ments de quantification
	while ((iter != pPatho->end()) && ((*iter)->getLigne() <= iRefLine))
		iter++ ;
	if (iter == pPatho->end())
		return false ;

	if ((*iter)->getLexiqueSens(pContexte) != string("VQUAN"))
  	return false ;

	string sItemNode = (*iter)->getNode() ;
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	pGraphe->etablirLien(sItemNode, NSRootLink::problemContactElement, sConcernNode) ;

	// Cr�ation d'un ConcernModifier
	// Creation of a ConcernModifier
	NVLdVTemps tDateTimeFin ;
	tDateTimeFin.estNoLimit() ;

	NSConcernModifier Modifier(pConcern, *pDateDeb, tDateTimeFin, iSev, 0, iRisk) ;
	Modifier.setNode(sItemNode) ;
	pConcern->aModificateurs.addModifier(&Modifier) ;

	return true ;
}

bool
NSLdvDocument::creeConcernSuite(NSConcern* pConcernPere, NSConcern* pConcernFils)
{
	// P�digr� du p�re
	NSPatPathoArray* pPatho ;
	PatPathoIter iterPere = donnePreoccup(pConcernPere, &pPatho) ;

	if ((NULL == iterPere) || (NULL == pPatho) || (pPatho->end() == iterPere))
		return false ;

	string sNoeudPere = (*iterPere)->getNode() ;

	// P�digr� du fils
	NSPatPathoArray* pPathoBis ;
	PatPathoIter iterFils = donnePreoccup(pConcernFils, &pPathoBis) ;

	if ((NULL == iterFils) || (pPathoBis->end() == iterFils))
		return false ;

	string sNoeudFils = (*iterFils)->getNode() ;
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	// On donne au p�re une date de fin qui correspond � la date de d�but du fils
	changeConcernDateFin(pConcernPere, &(pConcernFils->tDateOuverture)) ;

	updateIndex() ;

	// Cr�ation du lien
	if (!(pGraphe->etablirLien(sNoeudFils, NSRootLink::problemRelatedTo, sNoeudPere)))
  	return false ;

	pConcernFils->sPrimoPb = sNoeudPere ;

  getConcerns()->reinit() ;
	invalidateViews("CONCERN_EVOLUTION") ;

	return true ;
}


bool
NSLdvDocument::chgConcernType(string sLexique)
{
    return true ;
}


bool
NSLdvDocument::chgConcernDate(string sDateDeb, string sDateFin)
{
    return true ;
}


bool
NSLdvDocument::deleteConcern(NSConcern* pConcern)
{
	// Recherche de cette pr�occupation dans l'index de sant�
	// Looking for this concern in the health index document
	NSPatPathoArray* pPatho ;
	PatPathoIter iter = donnePreoccup(pConcern, &pPatho) ;

	// not found !
	if ((iter == NULL) || (iter == pPatho->end()))
		return false ;

	string sNoeud = (*iter)->getNode() ;
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	// Suppression du noeud
	// Killing the node
	pPatho->SupprimerItem(iter) ;

	// Suppression des liens vers le noeud
	// Killing all links concernig the node
	if (!(pGraphe->detruireTousLesLiens(sNoeud)))
		return false ;

	updateIndex() ;

	pConcerns->deleteConcern(pConcern) ;

	return true ;
}

void
NSLdvDocument::manageRights(TWindow* parent, string sNode)
{
try
{
	PatPathoIter iterNode = pPathoPOMRIndex->ChercherNoeud(sNode) ;

	string sNodeRights = (*iterNode)->getNodeRight() ;

	RightsDialog* pRightsDlg = new RightsDialog(parent, pContexte, &sNodeRights) ;
	int iReturn = pRightsDlg->Execute() ;

	if (IDOK == iReturn)
  {
  	(*iterNode)->setNodeRight(sNodeRights) ;
		updateIndex() ;
	}

	delete pRightsDlg ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSLdvDocument::manageRights : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
  return ;
}
catch (...)
{
  erreur("Exception NSLdvDocument::manageRights.", standardError, 0) ;
  return ;
}
}

PatPathoIter
NSLdvDocument::donneElement(string sNodeId, NSPatPathoArray **pPatho)
{
	if ((NULL == pPathoPOMRIndex) || (true == pPathoPOMRIndex->empty()))
	{
		*pPatho = NULL ;
		return NULL ;
	}
	*pPatho = pPathoPOMRIndex ;

  if (string("") == sNodeId)
		return NULL ;

	PatPathoIter iter = pPathoPOMRIndex->ChercherNoeud(sNodeId) ;

	// not found !
	if (pPathoPOMRIndex->end() == iter)
		return NULL ;

	return iter ;
}

PatPathoIter
NSLdvDocument::donnePreoccup(NSConcern* pConcern, NSPatPathoArray** pPatho)
{
  string sNodeId = string("") ;
  if (NULL != pConcern)
  	sNodeId = pConcern->getNoeud() ;

	return donneElement(sNodeId, pPatho) ;
}

PatPathoIter
NSLdvDocument::donneGoal(NSLdvGoal* pGoal, NSPatPathoArray** pPatho)
{
  string sNodeId = string("") ;
  if (NULL != pGoal)
  	sNodeId = pGoal->getNoeud() ;

	return donneElement(sNodeId, pPatho) ;
}

PatPathoIter
NSLdvDocument::donneDrug(NSLdvDrug *pDrug, NSPatPathoArray **pPatho)
{
	string sNodeId = string("") ;
  if (NULL != pDrug)
  	sNodeId = pDrug->getNoeud() ;

	return donneElement(sNodeId, pPatho) ;
}

NSConcern*
NSLdvDocument::donneOpenConcern(string sCodeSens)
{
	if (pConcerns->empty())
		return NULL ;

	NVLdVTemps tToday ;
	tToday.takeTime() ;

	for (ArrayConcernIter j = pConcerns->begin(); j != pConcerns->end(); j++)
	{
		// Pr�occupation ouverte
		if (((*j)->tDateOuverture <= tToday) &&
				(((*j)->tDateFermeture.estNoLimit()) || ((*j)->tDateFermeture >= tToday)))
		{
			PatPathoIter pptIter = pPathoPOMRIndex->ChercherNoeud((*j)->getNoeud()) ;

			if ((pptIter != NULL) && (pptIter != pPathoPOMRIndex->end()))
			{
				string sConcernCodeSens = (*pptIter)->getLexiqueSens(pContexte) ;
				if (sCodeSens == sConcernCodeSens)
        	return *j ;
			}
		}
	}

	return NULL ;
}

NSLdvDrug*
NSLdvDocument::donneMostRecentOpenDrug(string sCodeSens)
{
	return donneNextRecentOpenDrug(sCodeSens, NULL) ;
}

NSLdvDrug*
NSLdvDocument::donneNextRecentOpenDrug(string sCodeSens, NSLdvDrug* pPreviousDrug)
{
	if (pDrugs->empty())
		return NULL ;

	drugsIter iStartIter = pDrugs->begin() ;
  if (pPreviousDrug != NULL)
	{
		for ( ; (iStartIter != pDrugs->end()) && (*iStartIter != pPreviousDrug); iStartIter++) ;
    if (iStartIter == pDrugs->end())
  		return NULL ;
      
		iStartIter++ ;
    if (iStartIter == pDrugs->end())
  		return NULL ;
	}

	NVLdVTemps tToday ;
	tToday.takeTime() ;

  // Exact search
  //
	for (drugsIter j = iStartIter ; j != pDrugs->end() ; j++)
	{
		// Pr�occupation ouverte
		if (((*j)->tDateOuverture <= tToday) &&
				(((*j)->tDateFermeture.estNoLimit()) || ((*j)->tDateFermeture >= tToday)))
		{
    	string sConcern = (*j)->getLexique() ;
      string sConcernCodeSens ;
      pContexte->getDico()->donneCodeSens(&sConcern, &sConcernCodeSens) ;
      if (sCodeSens == sConcernCodeSens)
      	return *j ;
		}
	}

  // Semantic search
  //
  VectString VSEquivalent ;
	pContexte->getSuperviseur()->getFilGuide()->TousLesVrais(sCodeSens, "ES", &VSEquivalent, "ENVERS") ;

  for (drugsIter j = iStartIter ; j != pDrugs->end() ; j++)
	{
		// Pr�occupation ouverte
		if (((*j)->tDateOuverture <= tToday) &&
				(((*j)->tDateFermeture.estNoLimit()) || ((*j)->tDateFermeture >= tToday)))
		{
      string sConcern = (*j)->getLexique() ;
      string sConcernCodeSens ;
      pContexte->getDico()->donneCodeSens(&sConcern, &sConcernCodeSens) ;
      if (VSEquivalent.contains(sConcernCodeSens))
      	return *j ;
		}
	}

	return NULL ;
}

bool
NSLdvDocument::updateIndex()
{
	if (NULL == pPathoPOMRIndex)
		return false;

	// Can we work ?
	if (NULL == pContexte->getPatient())
	{
		erreur("Erreur grave (patient introuvable). Vous devriez relancer le logiciel.", standardError, 0) ;
		return false;
	}
	if (NULL == pContexte->getPatient()->pDocHis)
	{
		erreur("Erreur grave (historique introuvable). Vous devriez relancer le logiciel.", standardError, 0) ;
		return false;
	}
	if (pContexte->getPatient()->pDocHis->VectDocument.empty())
	{
		erreur("Erreur grave (historique vide). Vous devriez relancer le logiciel.", standardError, 0) ;
		return false;
	}

	NSHISTODocument* pHistory = pContexte->getPatient()->pDocHis ;

	// Recherche du document "Index de sant�"
	// Looking for "Health index" document
	DocumentIter iterDoc;

	bool bSearchIndex = true ;
	while (bSearchIndex)
	{
		bool bContinuer = true ;
		iterDoc = pHistory->VectDocument.begin() ;
		while ((iterDoc != pHistory->VectDocument.end()) && bContinuer )
		{
    	if (!(*iterDoc)->pPatPathoArray->empty())
			{
      	PatPathoIter iter = (*iterDoc)->pPatPathoArray->begin() ;
        if ((*iter)->getLexiqueSens(pContexte) == string("ZPOMR"))
        	bContinuer = false ;
        else
        	iterDoc++ ;
      }
      else
      	iterDoc++ ;
		}

		// Index de sant� non trouv� - Health index not found
		if (iterDoc == pHistory->VectDocument.end())
		{
    	// En MUE on signale une erreur car l'index de sant� est normalement cr��
      // lors de l'initialisation du patient (m�thode NSPatientChoisi::CreeRootDocs())
      ::MessageBox(pContexte->GetMainWindow()->GetHandle(),
              "Ce patient ne semble pas avoir de document des Index de sant�.",
                            "Attention", MB_OK) ;

      return false ;

			// Rafraichir l'historique
		}
		else
			bSearchIndex = false ;
	}
	if (iterDoc == pHistory->VectDocument.end())
		return false ;

	// Health index found

	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *((*iterDoc)->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;

	*(Noyau.pPatPathoArray) = *pPathoPOMRIndex ;

	// Enregistrement du document modifi�
	Noyau.enregistrePatPatho() ;

	bool bReload = Noyau.chargePatPatho() ;
	if (!bReload)
		return false ;

	*pPathoPOMRIndex = *(Noyau.pPatPathoArray) ;

	return true ;
}

bool
NSLdvDocument::connectObjectToConcern(string sCodeConcern, int iSeverity, string sNoeud, NSRootLink::NODELINKTYPES iRelation, bool bAutoCreate)
{
try
{
	string sCodeSensConcern ;
	pContexte->getDico()->donneCodeSens(&sCodeConcern, &sCodeSensConcern) ;

	//
	// Recherche d'une pr�occupation OUVERTE correspondant � sCodeConcern
	//
	NSConcern* pConcern = donneOpenConcern(sCodeSensConcern) ;

	if (NULL == pConcern)
	{
		if (!bAutoCreate)
			return false ;

		//
		// Recherche de la vue
		//
		NSLdvView* pLdvView ;
		TView* pView = GetViewList() ;
    if (NULL != pView)
    {
			do
			{
				pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView) ;
				if (pLdvView)
					break ;

				pView = NextView(pView) ;
			}
			while (pView) ;
    }

		bool bVerbose = false ;
		if (bVerbose)
		{
			//
			// Fen�tre de cr�ation de la pr�occupation
			//
			if (!pLdvView)
				return false ;

			string sCreatedConcern = sCodeConcern ;
      string sCocCode = string("") ;
			NSNewConcernDlg* pNPDialog ;

			NSPatPathoArray* pDetails = new NSPatPathoArray(pContexte) ;

			string sNewNode = "" ;
			// NSNewConcernDlg* pNPDialog = new NSNewConcernDlg(pLdvView, pContexte, &sCreatedConcern);
			// else
			if (pLdvView)
				pNPDialog = new NSNewConcernDlg(pLdvView, &sNewNode, this, pContexte, pDetails, &sCocCode, &sCreatedConcern) ;
			else
				pNPDialog = new NSNewConcernDlg(pContexte->GetMainWindow(), &sNewNode, this, pContexte, pDetails, &sCocCode, &sCreatedConcern) ;

			int iExecReturn = pNPDialog->Execute() ;

			delete pDetails ;

			if (iExecReturn != IDOK)
				return false ;
		}
		else
		{
			NVLdVTemps tpsNow ;
			tpsNow.takeTime() ;
			string sNode = "" ;
			if (!(newConcern(sCodeConcern, &sNode, tpsNow.donneDateHeure(), "", iSeverity, string(""), 0, NULL, "")))
				return false ;
		}

		getConcerns()->reinit() ;

		pConcern = donneOpenConcern(sCodeSensConcern) ;
    //
    // D�cidemment �a ne marche pas
    //
    if (NULL == pConcern)
			return false ;
	}

	string sConcernRef = pConcern->getNoeud() ;

  //
	// On a trouv� la pr�occupation, on connecte
	//
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
  pGraphe->etablirLienDocument(sNoeud, iRelation, sConcernRef) ;

	//
	// On met � jour l'Objet qui repr�sente le document
	//
	NSLdvObjet* pObj = pObjets->getObjet(sNoeud) ;

	if (pObj != NULL)
	{
		pObj->sConcern = sConcernRef ;

		TView* pView = GetViewList();
    if (NULL != pView)
    {
			do
			{
				NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView) ;
				if (pLdvView)
					pLdvView->addObjOnConcern(pConcern, pObj) ;

				pView = NextView(pView) ;
			}
			while (pView) ;
    }
	}

	return true ;
}
catch (...)
{
	erreur("Exception NSLdvDocument::connectObjectToConcern.", standardError, 0) ;
	return false ;
}
}

bool
NSLdvDocument::connectObjectToDrug(string sCodeDrug, int iSeverity, string sNoeud, NSRootLink::NODELINKTYPES iRelation, bool bAutoCreate)
{
try
{
	string sCodeSensDrug ;
	pContexte->getDico()->donneCodeSens(&sCodeDrug, &sCodeSensDrug) ;

	//
	// Recherche d'une pr�occupation OUVERTE correspondant � sCodeConcern
	//
	NSLdvDrug* pDrug = donneMostRecentOpenDrug(sCodeSensDrug) ;

  if (pDrug == NULL)
		return false ;

	string sDrugRef = pDrug->getNoeud() ;

  //
	// Drug was found, we connect
	//
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
  pGraphe->etablirLienDocument(sNoeud, iRelation, sDrugRef) ;

	//
	// On met � jour l'Objet qui repr�sente le document
	//
/*
	NSLdvObjet* pObj = pObjets->getObjet(sNoeud);

	if (pObj != NULL)
	{
		pObj->sConcern = sConcernRef;

		TView* pView = GetViewList();
		do
		{
			NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView);
			if (pLdvView)
				pLdvView->addObjOnConcern(pConcern, pObj);

			pView = NextView(pView);
		}
		while (pView);
	}
*/

	return true ;
}
catch (...)
{
	erreur("Exception NSLdvDocument::connectObjectToDrug.", standardError, 0) ;
	return false ;
}
}

void
NSLdvDocument::showNewTree(NSPatPathoArray *pPatPathoArray, string sDateDoc)
{
	if ((NULL == pPatPathoArray) || (pPatPathoArray->empty()))
    	return ;

	if (pGoals->empty())
		return ;

	bool bModified = false ;

	// ---------------------------------------------------------------------------
	// Le noeud racine remet-il � z�ro un objectif ?
	string sRootConcept = (*(pPatPathoArray->begin()))->getLexique() ;
	string sRootSens ;
	pContexte->getDico()->donneCodeSens(&sRootConcept, &sRootSens) ;

	string sRootNode = (*(pPatPathoArray->begin()))->getNode() ;
	if (string("") == sRootNode)
		return ;

	string sDateDocum = sDateDoc ;
	// NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	// si date au format AAAAMMJJ :
  	// on ajoute l'heure
	if (strlen(sDateDocum.c_str()) == 8)
		sDateDocum += "000000" ;

	ArrayGoals GoalsWithValue(this) ;

	// ---------------------------------------------------------------------------
	// On passe en revue tous les objectifs
	for (ArrayGoalIter goalIt = pGoals->begin(); goalIt != pGoals->end(); goalIt++)
	{
		// -------------------------------------------------------------------------
		// Si l'objectif est ouvert, on regarde si le noeud est un reseter
		if (!((*goalIt)->tOuvertLe.estVide()))
		{
			string sDateOuvr = (*goalIt)->tOuvertLe.donneDateHeure() ;
			string sDateFerm = "" ;
			if (!((*goalIt)->tFermeLe.estVide()))
				sDateFerm = (*goalIt)->tFermeLe.donneDateHeure() ;

			if ((sDateDocum >= sDateOuvr) && ((sDateFerm == "") || (sDateDocum < sDateFerm)))
      {
      	// Si l'objectif correspond au document
        string sGoalSens ;
        pContexte->getDico()->donneCodeSens(&((*goalIt)->sLexique), &sGoalSens) ;

        if (sGoalSens == sRootSens)
        {
        	if      ((*goalIt)->iRythme == NSLdvGoal::cyclic)
						pContexte->getPatient()->pGraphPerson->ConnectRootTreeToGoal(sRootNode, (*goalIt)->sReference, NSRootLink::goalReseter) ;
          else if ((*goalIt)->iRythme != NSLdvGoal::permanent)
						pContexte->getPatient()->pGraphPerson->ConnectRootTreeToGoal(sRootNode, (*goalIt)->sReference, NSRootLink::goalCloser) ;

          if ((*goalIt)->iRythme != NSLdvGoal::permanent)
          	bModified = true ;
				}

        string sCloseSens ;
        pContexte->getDico()->donneCodeSens(&((*goalIt)->sCloseEventNode), &sCloseSens) ;
        if (sCloseSens == sRootSens)
        {
					pContexte->getPatient()->pGraphPerson->ConnectRootTreeToGoal(sRootNode, (*goalIt)->sReference, NSRootLink::goalCloser) ;
					bModified = true ;
				}
			}
		}

		// -------------------------------------------------------------------------
		// Si l'objectif est encore ferm�, on regarde si le noeud l'ouvre
		else
		{
			string sOpenSens ;
			pContexte->getDico()->donneCodeSens(&((*goalIt)->sOpenEventNode), &sOpenSens) ;
			if (sOpenSens == sRootSens)
			{
				pContexte->getPatient()->pGraphPerson->ConnectRootTreeToGoal(sRootNode, (*goalIt)->sReference, NSRootLink::goalOpener) ;
				bModified = true ;
			}
		}

		// -------------------------------------------------------------------------
		// on fait une liste des objectifs qui ont une valeur
		if (((*goalIt)->bValue) || ((*goalIt)->sLexique[0] == 'V'))
			GoalsWithValue.push_back((*goalIt)) ;
	}

	//
	// Gestion des objectifs chiffr�s - Managing goals on values
	//
	if (false == GoalsWithValue.empty())
	{
		// -------------------------------------------------------------------------
		// on parcourt la patpatho
		for (PatPathoIter pathoIter = pPatPathoArray->begin() ; pathoIter != pPatPathoArray->end() ; pathoIter++)
		{
			if (pContexte->getDico()->CodeCategorie((*pathoIter)->getLexique()) == string(1, '�'))
			{
				// on est dans le cas d'une valeur chiffr�e
				// on recherche le p�re qui correspond � la valeur mesur�e
				PatPathoIter pptPereIter = pathoIter ;

				while ( (pptPereIter != NULL)                         &&
        				(pptPereIter != pPatPathoArray->begin())      &&
                (pContexte->getDico()->CodeCategorie((*pptPereIter)->getLexique()) != string(1, 'V')) &&
                (pContexte->getDico()->CodeCategorie((*pptPereIter)->getLexique()) != string(1, 'K')))
					pptPereIter = pPatPathoArray->ChercherPere(pptPereIter) ;

				if (pptPereIter != NULL)
				{
					NSPatPathoArray PatPathoPere(pContexte) ;
          NSPatPathoArray PatPathoFils(pContexte) ;

          NSPatPathoInfo racine = *(*pptPereIter) ;
          racine.setLigne(0) ;
          racine.setColonne(0) ;
          PatPathoPere.push_back(new NSPatPathoInfo(racine)) ;
          pPatPathoArray->ExtrairePatPatho(pptPereIter, &PatPathoFils) ;
          PatPathoPere.InserePatPatho(PatPathoPere.end(), &PatPathoFils, 1) ;

          string sPereConcept = (*pptPereIter)->getLexique() ;
          string sPereSens ;
          pContexte->getDico()->donneCodeSens(&sPereConcept, &sPereSens) ;

          string sPereNode    = (*pptPereIter)->getNode() ;

          // on a trouv� le pere, on regarde si ce pere correspond � un objectif � valeur
          for (ArrayGoalIter goalIter = GoalsWithValue.begin() ; goalIter != GoalsWithValue.end() ; goalIter++)
          {
          	// -------------------------------------------------------------------------
            // Si l'objectif est ouvert, on regarde si le noeud est un reseter
            if (!((*goalIter)->tOuvertLe.estVide()))
            {
            	string sDateOuvr = (*goalIter)->tOuvertLe.donneDateHeure() ;
              string sDateFerm = "" ;
              if (!((*goalIter)->tFermeLe.estVide()))
              	sDateFerm = (*goalIter)->tFermeLe.donneDateHeure() ;

              if ((sDateDocum >= sDateOuvr) && ((sDateFerm == "") || (sDateDocum < sDateFerm)))
              {
              	// Si l'objectif correspond au document
                string sGoalSens ;
                pContexte->getDico()->donneCodeSens(&((*goalIter)->sLexique), &sGoalSens) ;

                if (sGoalSens == sPereSens)
                {
                	if      (((*goalIter)->iRythme == NSLdvGoal::cyclic) ||
                  				 ((*goalIter)->iRythme == NSLdvGoal::permanent)) // pour suivi permanent d'une valeur
										pContexte->getPatient()->pGraphPerson->ConnectNodeToGoal(sPereNode, (*goalIter)->sReference, &PatPathoPere, NSRootLink::goalReseter) ;
                  else if ((*goalIter)->iRythme != NSLdvGoal::permanent)
										pContexte->getPatient()->pGraphPerson->ConnectNodeToGoal(sPereNode, (*goalIter)->sReference, &PatPathoPere, NSRootLink::goalCloser) ;

                  // if ((*goalIter)->iRythme != NSLdvGoal::permanent)
                  	bModified = true ;
								}

                string sCloseSens ;
                pContexte->getDico()->donneCodeSens(&((*goalIter)->sCloseEventNode), &sCloseSens) ;
                if (sCloseSens == sPereSens)
                {
									pContexte->getPatient()->pGraphPerson->ConnectNodeToGoal(sPereNode, (*goalIter)->sReference, &PatPathoPere, NSRootLink::goalCloser) ;
									bModified = true ;
								}
							}
						}
						// -------------------------------------------------------------------------
            // Si l'objectif est encore ferm�, on regarde si le noeud l'ouvre
            else
            {
            	string sOpenSens ;
              pContexte->getDico()->donneCodeSens(&((*goalIter)->sOpenEventNode), &sOpenSens) ;
							if (sOpenSens == sPereConcept)
							{
								pContexte->getPatient()->pGraphPerson->ConnectNodeToGoal(sPereNode, (*goalIter)->sReference, &PatPathoPere, NSRootLink::goalOpener) ;
								bModified = true ;
							}
						}
					}
				}
			}
		}

		// -------------------------------------------------------------------------
		// on delete la liste de goals avec valeur sans effacer les objectifs
		GoalsWithValue.clear() ;
	}

	if (bModified)
	{
		reinitAllGoals() ;
		invalidateViews("DOCUM_NEW") ;
	}
}


void
NSLdvDocument::showNewDrug(NSPatPathoArray *pPPT, PatPathoIter iter)
{
  // ---------------------------------------------------------------------------
  // cette fonction est une sp�cialisation de showNewTree pour le m�dicament
  // this function is specialization of function showNewTree for Drugs
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // TODO
  // il faudrait �galement parser les fils de la patpatho point� par iter, afin
  // de pouvoir g�rer des cas particuliers comme une perfusion
  // we have to parse already sons of patpatho represented by iter, to manage
  // some particular cases like perfusion.
  // ---------------------------------------------------------------------------

	if ((NULL == pPPT) || (true == pPPT->empty()) || (pPPT->end() == iter))
  	return ;

	NautilusEvent nsEvent(pPPT, iter, ADD, true) ;
  pContexte->getSuperviseur()->getBBinterface()->addNautilusEvent(&nsEvent) ;
	// pContexte->getSuperviseur()->getBBinterface()->insertAnswerOnBlackboard("Drug", pPPT, Drug) ;

	if (pGoals->empty())
  {
		viewsReloadDrugToons() ;
		return ;
	}

	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
	bool      bModified = false ;

  // Le noeud courant (correspondant � l'iterateur pass� en param�tre) remet-il
  // � z�ro un objectif ?
  // Does current node (which is represented by iterator iter passed in
  // parameter in function) reset a goal ?
  string  sConcept = (*iter)->getLexique() ;
  string  sConceptSens ;
  pContexte->getDico()->donneCodeSens(&sConcept, &sConceptSens) ;

  string  sConceptNode = (*iter)->getNode() ;
  if (sConceptNode == "")
		return ;

  // parsage de la patpatho afin de savoir les informations qu'elle contient
  // parsing the patpatho instance to know what informations are in it

  // variables pour r�cup�rer la date d'ouverture et de fermeture de la
  // prescription du m�dicament
  // variables for retrieving opening and ending date of Drug Administration
  string  sOpeningDate  = "" ;
  string  sEndingDate   = "" ;

  // r�cup�ration de la date d'ouverture et de fermeture
  // getting opening and ending date
  PatPathoIter iterTemp = iter ;
  int iRootCol = (*iterTemp)->getColonne() ;

  iterTemp++ ;

  while (iterTemp != pPPT->end())
  {
  	//
    // Date d'ouverture - Opening date (only the root opening date is taken
    // into account; phases opening dates are not handled there)
    //
		if      ((string("KOUVR") == (*iterTemp)->getLexiqueSens(pContexte)) &&
             ((*iterTemp)->getColonne() == iRootCol + 1))
		{
			int	iColBaseOuverture = (*iterTemp)->getColonne() ;
			if (iterTemp != pPPT->end())
				iterTemp++ ;

			string sCodeSensUnit = (*iterTemp)->getUnitSens(pContexte) ;
      string sRootCodelex = string((*iterTemp)->getLexique(), 0, 2) ;

			if (((*iterTemp)->getColonne() > iColBaseOuverture) &&
      				((sRootCodelex == "�D") || (sRootCodelex == "�T")) &&
      				((sCodeSensUnit == "2DA01") || (sCodeSensUnit == "2DA02")))
			{
				sOpeningDate = (*iterTemp)->getComplement() ;
				if (iterTemp != pPPT->end())
					iterTemp++ ;
			}
		}
    //
    // Date de fermeture - Closing date
    //
		else if ((string("KFERM") == (*iterTemp)->getLexiqueSens(pContexte)) &&
             ((*iterTemp)->getColonne() == iRootCol + 1))
		{
			int iColBaseOuverture = (*iterTemp)->getColonne() ;
			if (iterTemp != pPPT->end())
				iterTemp++ ;
			string sCodeSensUnit = (*iterTemp)->getUnitSens(pContexte) ;
      string sRootCodelex = string((*iterTemp)->getLexique(), 0, 2) ;

			if (((*iterTemp)->getColonne() > iColBaseOuverture) &&
      				((sRootCodelex == "�D") || (sRootCodelex == "�T")) &&
      				((sCodeSensUnit == "2DA01") || (sCodeSensUnit == "2DA02")))
			{
				sEndingDate = (*iterTemp)->getComplement() ;
				if (iterTemp != pPPT->end())
					iterTemp++ ;
			}
		}
		else
			// on passe � l'it�rateur suivant
			// next iterator
			iterTemp++ ;
	}

	// si date au format AAAAMMJJ : on ajoute l'heure 00:00:00
	// if date is in AAAAMMGG format : we add time 00:00:00
	if (strlen(sOpeningDate.c_str()) == 8)
		sOpeningDate += "000000" ;

	VectString VSEquivalent ;
	pContexte->getSuperviseur()->getFilGuide()->TousLesVrais(sConceptSens, "ES", &VSEquivalent, "FLECHE") ;

	// parcours des objectifs
	// searching in the goals
	//  ArrayGoals    *pGoalsWithValue = new ArrayGoals(this) ;
	for (ArrayGoalIter goalIt = pGoals->begin() ; goalIt != pGoals->end() ; goalIt++)
	{
		// Si l'objectif est ouvert, on regarde si le noeud est un reseter
		// if goal is open, we look if the node is a reseter
		if (!((*goalIt)->tOuvertLe.estVide()))
		{
			string sGoalOpeningDate = (*goalIt)->tOuvertLe.donneDateHeure() ;
			string sGoalEndingDate = "" ;
			if (!((*goalIt)->tFermeLe.estVide()))
				sGoalEndingDate = (*goalIt)->tFermeLe.donneDateHeure() ;

			// Ev�nement � l'int�rieur de la p�riode de validit� de l'objectif
			// Event inside this goal's validity period
			if ((sOpeningDate >= sGoalOpeningDate) && ((sGoalEndingDate == "") || (sOpeningDate < sGoalEndingDate)))
			{
				// Si l'objectif correspond au m�dicament
				// Does goal interact with drug
				string sGoalSens ;
				pContexte->getDico()->donneCodeSens(&((*goalIt)->sLexique), &sGoalSens) ;

				if (sGoalSens == sConceptSens)
				{
					pGraphe->etablirLien(sConceptNode, NSRootLink::goalReseter, (*goalIt)->sReference) ;
					bModified = true ;
				}
        // on recherche si le m�dicament a un lien ESTUN avec cet objectif
        // searching if the medic has a IsA link with this goal
        else if (VSEquivalent.contains(sGoalSens))
        {
        	pGraphe->etablirLien(sConceptNode, NSRootLink::goalReseter, (*goalIt)->sReference) ;
          bModified = true ;
				}

				string sCloseSens ;
        pContexte->getDico()->donneCodeSens(&((*goalIt)->sCloseEventNode), &sCloseSens) ;
        if (sCloseSens == sConceptSens)
        {
        	pGraphe->etablirLien(sConceptNode, NSRootLink::goalAlarm, (*goalIt)->sReference) ;
          bModified = true ;
        }
        // on recherche si le m�dicament a un lien ESTUN avec cet objectif
        // searching if the medic has a IsA link with this goal
        else if (VSEquivalent.contains(sCloseSens))
        {
        	pGraphe->etablirLien(sConceptNode, NSRootLink::goalAlarm, (*goalIt)->sReference) ;
          bModified = true ;
        }
      }
    }
		// Si l'objectif est encore ferm�, on regarde si le noeud l'ouvre
		// if goal is currently closed, we look if the node can open it
		else
		{
			string sOpenSens ;
			pContexte->getDico()->donneCodeSens(&((*goalIt)->sOpenEventNode), &sOpenSens) ;
			if (sOpenSens == sConceptSens)
			{
				pGraphe->etablirLien(sConceptNode, NSRootLink::goalOpener, (*goalIt)->sReference) ;
				bModified = true ;
			}
		}
	}

	if (bModified)
	{
		reinitAllGoals() ;
		// no need to invalidateViews this is done in CreeObjectif
		//    invalidateViews("DOCUM_NEW") ;
	}

  //
  //
  viewsReloadDrugToons() ;
}

bool
NSLdvDocument::isALDDrug(string sNodeMedic)
{
	if (sNodeMedic == string(""))
		return false ;


  NSLdvDrug *pDrug = pDrugs->getDrug(sNodeMedic) ;
  if (NULL == pDrug)
    return false ;

  return pDrug->_bALD ;

  //
  // Ancienne m�thode : regarder si le m�dicament est attach� � une PS en ALD
  //
/*
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	VecteurString aConcerns ;
	pGraphe->TousLesVrais(sNodeMedic, NSRootLink::drugOf, &aConcerns) ;
	bool bALDdrug = false ;
	if (aConcerns.empty())
		return false ;

	ArrayConcern* pConcerns = getConcerns() ;
	EquiItemIter iCcc = aConcerns.begin();
	for ( ; iCcc != aConcerns.end(); iCcc++)
	{
		NSConcern* pConcern = pConcerns->getConcern(**iCcc) ;
    if (pConcern && pConcern->pPptDetails && (!(pConcern->pPptDetails->empty())))
    {
    	if (pConcern->pPptDetails->CheminDansPatpatho("LADMI/LBARZ"))
      {
      	bALDdrug = true ;
        break ;
      }
    }
	}
	return bALDdrug ;
*/
}

void
NSLdvDocument::connectValuedNode(NSPatPathoArray *pPatPathoArray, PatPathoIter iter, string sGoalNode)
{
}

void
NSLdvDocument::showDrugProperty(NSLdvDrug *pDrug)
{
	if ((NULL == pDrug) || (NULL == pContexte->getPatient()))
		return ;

	string sNode = pDrug->getNoeud() ;

	pContexte->getPatient()->goals_show(sNode) ;
	pContexte->getPatient()->followUp_show(sNode) ;
}

void
NSLdvDocument::addGoalToConcern(NSLdvGoal* pAddedGoal)
{
	if (!pAddedGoal || (pAddedGoal->sConcern == string("")))
		return ;

	NSConcern* pGoalConcern = pConcerns->getConcern(pAddedGoal->sConcern) ;
	if (pGoalConcern)
  {
  	pGoalConcern->goalAdded(pAddedGoal) ;
		return ;
  }

	NSLdvDrug* pGoalDrug = pDrugs->getDrug(pAddedGoal->sConcern) ;
	if (pGoalDrug)
  {
  	pGoalDrug->goalAdded(pAddedGoal) ;
		return ;
  }
}

void
NSLdvDocument::goalModified(NSLdvGoal* pModifiedGoal)
{
	if (!pModifiedGoal || (pModifiedGoal->sConcern == string("")))
		return ;

	NSConcern* pGoalConcern = pConcerns->getConcern(pModifiedGoal->sConcern) ;
	if (pGoalConcern)
  {
  	goalModifiedForConcern(pModifiedGoal, pGoalConcern) ;
		return ;
  }

	NSLdvDrug* pGoalDrug = pDrugs->getDrug(pModifiedGoal->sConcern) ;
	if (pGoalDrug)
  {
  	goalModifiedForDrug(pModifiedGoal, pGoalDrug) ;
		return ;
  }
}

void
NSLdvDocument::reinitAllGoals()
{
	pGoals->reinit() ;

	// Update for health concerns
  //
	if (!(pConcerns->empty()))
		for (ArrayConcernIter itConcern = pConcerns->begin();
                                    itConcern != pConcerns->end(); itConcern++)
			(*itConcern)->goalModified(NULL) ;

	// Update for drugs
  //
	if (!(pDrugs->empty()))
		for (drugsIter itDrug = pDrugs->begin();
                                    itDrug != pDrugs->end(); itDrug++)
			(*itDrug)->goalModified(NULL) ;
}

void
NSLdvDocument::closeGoal(NSLdvGoal* pGoal, NSPatPathoArray* pPatPathoMotif)
{
	NVLdVTemps tDateFin ;
	tDateFin.takeTime() ;

	closeGoal(pGoal, &tDateFin, pPatPathoMotif) ;
}

void
NSLdvDocument::closeGoal(NSLdvGoal* pGoal, NVLdVTemps* pDateFin, NSPatPathoArray* pPatPathoMotif)
{
try
{
	if (NULL == pGoal)
		return ;

	// Recherche de cette pr�occupation dans l'index de sant�
	// Looking for this concern in the health index document
  //
	NSPatPathoArray* pPatho ;
	PatPathoIter iter = donneGoal(pGoal, &pPatho) ;

    // not found !
	if ((iter == NULL) || (iter == pPatho->end()))
  	return ;

	int iColonne = (*iter)->getColonne() ;

	// Recherche de la date de fin pour la modifier
	// Looking for ending date - in order to modify it
	PatPathoIter iterBis = pPatho->begin() ;
	iterBis = iter ;

	iterBis++ ;
	while (	(iterBis != pPatho->end()) && ((*iterBis)->getColonne() > iColonne) &&
					(((*iterBis)->getColonne() != iColonne+1) ||
						((*iterBis)->getLexique() != "KFERM1")))
		iterBis++ ;

	// On a trouv� une pr�c�dente date de fin, on la modifie
	// We have found a previous ending date, we can change it
	if ((iterBis != pPatho->end()) &&
			((*iterBis)->getColonne() == iColonne+1) &&
			((*iterBis)->getLexique() == "KFERM1"))
	{
		iterBis++ ;
    (*iterBis)->setLexique(string("�T0;19")) ;
		(*iterBis)->setComplement(pDateFin->donneDateHeure()) ;
    (*iterBis)->setUnit(string("2DA021")) ;

    if ((pPatPathoMotif) && (!(pPatPathoMotif->empty())))
    {
    	iterBis++ ;
      while ((iterBis != pPatho->end()) && ((*iterBis)->getColonne() > iColonne+1))
      	iterBis++ ;
      pPatho->InserePatPatho(iterBis, pPatPathoMotif, iColonne+1) ;
    }
	}

	// Si on n'a pas trouv� de date de fin � modifier, on en cr�e une
	// If we didn't find any ending date, we must create it
	else
	{
  	iterBis = iter ;

		// On recherche la date de d�but, pour s'ins�rer juste apr�s
		// Looking for starting date - to insert ending date just after
		iterBis++ ;
		while (	(iterBis != pPatho->end()) && ((*iterBis)->getColonne() > iColonne) &&
						(((*iterBis)->getColonne() != iColonne+1) ||
						((*iterBis)->getLexiqueSens(pContexte) != string("KOUVR"))))
			iterBis++ ;

        // Si on est � la fin ou qu'on est tomb� sur un p�re sans passer par une date d'ouverture, on sort
		if ((iterBis == pPatho->end()) || ((*iterBis)->getColonne() != iColonne+1))
    	return ;

    iterBis++ ;
    while ((iterBis != pPatho->end()) && ((*iterBis)->getColonne() > iColonne+1))
    	iterBis++ ;

    NSPatPathoArray PatPatho(pContexte) ;

  	PatPatho.ajoutePatho("KFERM1", 0) ;
    Message Msg ;
    Msg.SetUnit("2DA021") ;
    Msg.SetComplement(pDateFin->donneDateHeure()) ;
    PatPatho.ajoutePatho("�T0;19", &Msg, 1) ;

    if ((pPatPathoMotif) && (!(pPatPathoMotif->empty())))
    	PatPatho.InserePatPatho(PatPatho.end(), pPatPathoMotif, 0) ;

    pPatho->InserePatPatho(iterBis, &PatPatho, iColonne+1) ;
	}

	pGoal->tDateFermeture = *pDateFin ;

	updateIndex() ;

	reinitAllGoals() ;

	return ;
}
catch (...)
{
	erreur("Exception NSLdvDocument::closeGoal.", standardError, 0) ;
	return ;
}
}

void
NSLdvDocument::goalAdded(NSLdvGoal* pGoal, GoalInfoArray *pWorstJalons)
{
try
{
	if (!pGoal || !pWorstJalons)
		return ;

	GoalInfoArray* pJalons = pGoal->pMetaJalons ;

	if ((!pJalons) || (pJalons->empty()))
		return ;

	if (pWorstJalons->empty())
	{
		*pWorstJalons = *pJalons ;
    return ;
	}

	bool        bNeedSort = false ;

	bool        bContinue ;     // Faut-il traiter les anciens jalons au del�
                              // du premier qui recoupe le nouveau ?
	NVLdVTemps  tpsContinue ;   // Moment de d�part de l'intervalle � prolonger

	GoalInfoIter iOld ;
	GoalInfoIter iNew = pJalons->begin() ;
	//
	// Pour chaque jalon, on regarde son influence pour aWorstJalons
	//
	for ( ; iNew != pJalons->end(); iNew++)
	{
  	// On cherche le premier worstJalon qui inclut celui ci
    //
    for (iOld = pWorstJalons->begin();
                        (iOld != pWorstJalons->end()) &&
                        ((*iOld)->tpsClosed <= (*iNew)->tpsInfo); iOld++) ;
    //
    // S'il n'y en a pas, c'est que ce jalon est au del� du dernier worstJalon
    //
    if (iOld == pWorstJalons->end())
    	break ;

    // Le pire est d�j� sans limites !
    // Worst is already unlimited !
    if (((*iOld)->iLevel == NSLdvGoalInfo::AProuge) &&
        ((*iOld)->tpsClosed.estNoLimit()))
    	break ;

		bContinue = false ;
    tpsContinue.init() ;

    // Cas 1 : le nouveau est inclu dans le worst
    if (((*iOld)->tpsInfo <= (*iNew)->tpsInfo) &&
        ((*iOld)->tpsClosed >= (*iNew)->tpsClosed))
    {
    	// Le nouveau est pire que l'ancien
      if ((*iNew)->iLevel > (*iOld)->iLevel)
      {
      	// recouvrement parfait : le nouveau prend la place de l'ancien
        if (((*iOld)->tpsInfo == (*iNew)->tpsInfo) &&
            ((*iOld)->tpsClosed == (*iNew)->tpsClosed))
        	**iOld = **iNew ;
        // l'ancien commence plus t�t
        else if ((*iOld)->tpsInfo < (*iNew)->tpsInfo)
        {
        	// S'ils finissent en m�me temps : le nouveau tronque
          if ((*iOld)->tpsClosed == (*iNew)->tpsClosed)
          {
          	(*iOld)->tpsClosed = (*iNew)->tpsInfo ;
            pWorstJalons->push_back(new NSLdvGoalInfo(**iNew)) ;
            bNeedSort = true ;
          }
          // si le nouveau est inclu, alors il s'ins�re (-> 3 jalons)
          else
          {
          	NSLdvGoalInfo* pThird = new NSLdvGoalInfo(**iOld) ;
            pThird->tpsInfo = (*iNew)->tpsClosed ;
            (*iOld)->tpsClosed = (*iNew)->tpsInfo ;
            pWorstJalons->push_back(new NSLdvGoalInfo(**iNew)) ;
            pWorstJalons->push_back(pThird) ;
            bNeedSort = true ;
          }
        }
        // Les deux commencent en m�me temps, le nouveau est plus court
        else
        {
        	(*iOld)->tpsInfo = (*iNew)->tpsClosed ;
          pWorstJalons->push_back(new NSLdvGoalInfo(**iNew)) ;
          bNeedSort = true ;
        }
      }
    }
    //
    // Cas 2 : le nouveau pr�c�de le premier ancien
    //
    else if ((*iOld)->tpsInfo > (*iNew)->tpsInfo)
    {
    	//
      // Cas trivial : pas de recoupement
      // Trivial case : no crossing
      //
      if ((*iOld)->tpsInfo >= (*iNew)->tpsClosed)
      {
      	// On ajoute le nouveau et on sort
        pWorstJalons->push_back(new NSLdvGoalInfo(**iNew)) ;
        bNeedSort = true ;
      }
      //
      // Cas avec recoupement
      // Crossing exists
      //
      else
      {
      	//
        // si le nouveau est pire que l'ancien, il le mange ou le tronque
        //
        if ((*iNew)->iLevel > (*iOld)->iLevel)
        {
        	// si le nouveau dure plus longtemps : l'ancien disparait
          if ((*iOld)->tpsClosed <= (*iNew)->tpsClosed)
          {
          	if ((*iOld)->tpsClosed < (*iNew)->tpsClosed)
            {
            	bContinue   = true ;
              tpsContinue = (*iNew)->tpsInfo ;
            }
            delete *iOld ;
            pWorstJalons->erase(iOld) ;
          }
          // sinon, l'ancien est tronqu�
          else
          {
          	(*iOld)->tpsInfo = (*iNew)->tpsClosed ;
            // On ajoute le nouveau et on sort
            pWorstJalons->push_back(new NSLdvGoalInfo(**iNew)) ;
            bNeedSort = true ;
          }
        }
        //
        // sinon, c'est le nouveau qui est raccourci
        //
        else
        {
        	NSLdvGoalInfo* pJalonNew = new NSLdvGoalInfo(**iNew) ;
          pJalonNew->tpsClosed = (*iOld)->tpsInfo ;
          pWorstJalons->push_back(pJalonNew) ;
          bNeedSort = true ;
          if ((*iOld)->tpsClosed < (*iNew)->tpsClosed)
          	bContinue = true ;
        }
      }
    }
    //
    // Cas 3 : le nouveau est � cheval sur plusieurs anciens, ou dure plus longtemps
    //
    else
    {
    	NSLdvGoalInfo newJalon(**iNew) ;

      //
      // On traite le jalon de d�but
      //
      //
      // si le nouveau est pire que l'ancien, il le mange ou le tronque
      //
      if ((*iNew)->iLevel > (*iOld)->iLevel)
      {
      	bContinue   = true ;
        tpsContinue = (*iNew)->tpsInfo ; // c'est le nouveau segment qui fixe sa date de d�but

        // si les deux commencent en m�me temps : l'ancien disparait
        if ((*iOld)->tpsInfo == (*iNew)->tpsInfo)
        {
        	delete *iOld ;
          pWorstJalons->erase(iOld) ;
        }
        // sinon, l'ancien est tronqu�
        else
        {
        	(*iOld)->tpsClosed = (*iNew)->tpsInfo ;
          iOld++ ;
        }
      }
      //
      // sinon, c'est le nouveau qui est raccourci
      //
      else
      	iOld++ ;

      // S'il n'existe plus d'ancien jalon au del�...
      //
      /*
      if (iOld == pWorstJalons->end())
      {
          pWorstJalons->push_back(new NSLdvGoalInfo(newJalon)) ;
          iNew++ ;
          break;
      } */

    }
    //
    // Le nouveau jalon d�borde sur plusieurs anciens jalons, on doit
    // les traiter
    // The new jalon is crossing several existing ones, we must treat them
    //
    if (bContinue)
    {
    	//
      // On traite les �ventuels jalons interm�diaires
      // Jalons fully contained in the new jalon
      //
      for ( ; (iOld != pWorstJalons->end()) &&
                                ((*iOld)->tpsClosed < (*iNew)->tpsClosed) ; )
      {
      	// si le nouveau est pire que l'ancien, il le supprime
        // if the new one is worse, it deletes the previous one
        if ((*iNew)->iLevel > (*iOld)->iLevel)
        {
        	if (tpsContinue.estVide())
          	tpsContinue = (*iOld)->tpsInfo ;
          delete *iOld ;
          pWorstJalons->erase(iOld) ;
        }
        // sinon, on ne prend en compte que la partie plus ancienne de
        // newJalon, si elle existe
        else
        {
        	if (!(tpsContinue.estVide()))
          {
          	NSLdvGoalInfo* pJalonNew = new NSLdvGoalInfo(**iNew) ;
            pJalonNew->tpsInfo   = tpsContinue ;
            pJalonNew->tpsClosed = (*iOld)->tpsInfo ;
            pWorstJalons->push_back(pJalonNew) ;
            bNeedSort = true ;
          }
          iOld++ ;
        }
      }
      //
      // Le nouveau jalon est au moins aussi long que le plus long des anciens
      //
      if (iOld == pWorstJalons->end())
      {
      	if (!(tpsContinue.estVide()))
        {
        	NSLdvGoalInfo* pJalonNew = new NSLdvGoalInfo(**iNew) ;
          pJalonNew->tpsInfo      = tpsContinue ;
          pWorstJalons->push_back(pJalonNew) ;
          bNeedSort = true ;
        }
      }
      //
      // On traite le dernier jalon
      //
      else
      {
      	// si le nouveau est pire que l'ancien, il le mange ou le tronque
        //
        if ((*iNew)->iLevel > (*iOld)->iLevel)
        {
        	if (tpsContinue.estVide())
          	tpsContinue = (*iOld)->tpsInfo ;

        	// si les deux finissent en m�me temps : l'ancien disparait
          if ((*iOld)->tpsClosed == (*iNew)->tpsClosed)
          {
          	delete *iOld ;
            pWorstJalons->erase(iOld) ;
        	}
          // sinon, l'ancien est tronqu�
          else
          	(*iOld)->tpsInfo = (*iNew)->tpsClosed ;

        	NSLdvGoalInfo* pJalonNew = new NSLdvGoalInfo(**iNew) ;
          pJalonNew->tpsInfo = tpsContinue ;
          pWorstJalons->push_back(pJalonNew) ;
          bNeedSort = true ;
        }
        //
        // sinon, c'est le nouveau qui est raccourci
        //
        else
        {
        	if (!(tpsContinue.estVide()))
          {
          	NSLdvGoalInfo* pJalonNew = new NSLdvGoalInfo(**iNew) ;
            pJalonNew->tpsInfo      = tpsContinue ;
            pJalonNew->tpsClosed    = (*iOld)->tpsInfo ;
            pWorstJalons->push_back(pJalonNew) ;
            bNeedSort = true ;
          }
        }
      }
    }

  	//
    // On re-trie par ordre chronologique worstJalons
    //
    if (bNeedSort)
    {
    	sort(pWorstJalons->begin(), pWorstJalons->end(), infGoalInfo) ;
      bNeedSort = false ;
    }
  }
  //
  // Tous les jalons restants sont ajout�s tels quels
  // All remaining steps are added "as is"
  //
  if ((iNew != pJalons->end()) && (iOld == pWorstJalons->end()))
  	for ( ; iNew != pJalons->end(); iNew++)
    	pWorstJalons->push_back(new NSLdvGoalInfo(**iNew)) ;

	//
	// On re-trie par ordre chronologique worstJalons
	//
	if (bNeedSort)
		sort(pWorstJalons->begin(), pWorstJalons->end(), infGoalInfo) ;
}
catch (...)
{
	erreur("Exception NSLdvDocument::goalAdded.", standardError, 0) ;
}
}

void
NSLdvDocument::goalModifiedForDrug(NSLdvGoal* pGoal, NSLdvDrug *pDrug)
{
	if (!pGoal || !pDrug || !pDrug->pWorstJalons)
		return ;

	//
	// On reconstruit enti�rement worstJalons
	// worstJalons is completely rebuilt
	//
	pDrug->pWorstJalons->vider() ;

	ArrayGoals* pLdvGoals = getGoals() ;
	if (pLdvGoals->empty())
		return ;

	// On passe en revue tous les objectifs
	//
	for (ArrayGoalIter goalIt = pLdvGoals->begin();
                                        goalIt != pLdvGoals->end(); goalIt++)
		if ((*goalIt)->sConcern == pDrug->sReference)
    	pDrug->goalAdded(*goalIt) ;
}

void
NSLdvDocument::goalModifiedForConcern(NSLdvGoal* pGoal, NSConcern *pConcern)
{
	if (!pGoal || !pConcern || !pConcern->pWorstJalons)
		return ;

	//
	// On reconstruit enti�rement worstJalons
	// worstJalons is completely rebuilt
	//
	pConcern->pWorstJalons->vider() ;

	ArrayGoals* pLdvGoals = getGoals() ;
	if (pLdvGoals->empty())
		return ;

	// On passe en revue tous les objectifs
	//
	for (ArrayGoalIter goalIt = pLdvGoals->begin();
                                        goalIt != pLdvGoals->end(); goalIt++)
		if ((*goalIt)->sConcern == pConcern->sReference)
    	pConcern->goalAdded(*goalIt) ;
}

// ----------------------------------------------------------------------
//                          Mise � jour des vues
// ----------------------------------------------------------------------
void
NSLdvDocument::invalidateViews(string sReason, string sReference)
{
	//
	// Valeurs possibles de sReason - Possible values for sReason
	//
	// CONCERN_NEW  CONCERN_STOP
	// GOAL_NEW     GOAL_REFUSE
	// DRUG_NEW     DRUG_CHANGED  DRUG_DELETED
	// DOCUM_NEW
	// MISCELLANOUS

	TView* pView = GetViewList() ;
  if (NULL == pView)
  	return ;

	do
	{
		// Vue principale : Ligne de vie
		//
		NSLdvView* pMainLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView) ;
		if (pMainLdvView)
			pMainLdvView->reloadView(sReason, sReference) ;
    else
    {
    	// Vue secondaire
      //
      NSLDVView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLDVView) ;
      if (pLdvView)
      	pLdvView->reloadView(sReason) ;
    }

		pView = NextView(pView) ;
	}
	while (pView) ;
}

void
NSLdvDocument::viewsReloadDrugToons()
{
	TView* pView = GetViewList() ;
  if (NULL == pView)
		return ;

	do
	{
		NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView) ;
		if (pLdvView)
			pLdvView->reinitDrugs() ;

		pView = NextView(pView) ;
	}
  while (pView) ;
}

NSLdvView*
NSLdvDocument::getLdvView(string sConcern)
{
	TView* pView = GetViewList() ;
  if (NULL == pView)
		return NULL ;

	do
	{
  	// LdvView ?
    //
		NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView) ;
		if (pLdvView)
    {
    	string sViewConcern = pLdvView->getConcern() ;
      if (sViewConcern == sConcern)
      	return pLdvView ;
    }

		pView = NextView(pView);
	}
  while (pView) ;

	return NULL ;
}

NSDrugView*
NSLdvDocument::getDrugView(string sConcern)
{
	TView* pView = GetViewList() ;
  if (NULL == pView)
		return NULL ;

	do
	{
  	// DrugView ?
    //
		NSDrugView* pDrugView = TYPESAFE_DOWNCAST(pView, NSDrugView);
		if (pDrugView)
    {
    	string sViewConcern = pDrugView->getConcern() ;
      if (sViewConcern == sConcern)
      	return pDrugView ;
    }

		pView = NextView(pView);
	}
  while (pView) ;

	return NULL ;
}

NSProcessView*
NSLdvDocument::getProcessView(string sConcern)
{
	TView* pView = GetViewList() ;
	if (NULL == pView)
		return NULL ;

	do
	{
  	// NSProcessView ?
    //
		NSProcessView* pProcessView = TYPESAFE_DOWNCAST(pView, NSProcessView) ;
		if (pProcessView)
    {
    	string sViewConcern = pProcessView->getConcern() ;
      if (sViewConcern == sConcern)
      	return pProcessView ;
    }

		pView = NextView(pView) ;
	}
	while (pView) ;

	return NULL ;
}

void
NSLdvDocument::traiteSelectedObjectifs(string sConcern)
{
	ArrayGoals* pLdvGoals = getGoals() ;
  if (pLdvGoals->empty())
		return ;
  ArrayGoals GoalsProcess(this) ;  bool initLogMed = true ;  for(ArrayGoalIter iter = pLdvGoals->begin(); iter!= pLdvGoals->end(); iter++)  {
  	if((*iter)->isASelectedObj())
    {
    	if((*iter)->getGoalType() == NSLdvGoal::medicament)
      {
        transferInDrugView(sConcern, (*iter), initLogMed) ;
        (*iter)->unselectObjectif() ;
        initLogMed = false ;
      }
      else
      {
         	//TO DO for biology, traitement and exam
      	if((*iter)->getGoalType() == NSLdvGoal::biology)
        {
        	GoalsProcess.push_back(new NSLdvGoal(**iter)) ;
          (*iter)->unselectObjectif() ;
        }
      }

    }
  }
  transferInProccess(sConcern, &GoalsProcess) ;
}

//
// le medicament est juste pass� a drug view et la view s'ocupe a faire l'ordonnance et les liens
// avec les objectifs
//
void
NSLdvDocument::transferInDrugView(string sConcern, NSLdvGoal *pGoal, bool initLogMed)
{
	if (!pGoal)
  	return ;

	NSDrugView* pDrugView = getDrugView(sConcern) ;
  if (pDrugView == NULL)
  {
    NSDocViewManager dvManager(pContexte) ;
		dvManager.createView(this, "Drug Management") ;
    pDrugView = getDrugView(sConcern) ;
  }

  NSPatPathoArray PPT(pContexte) ;
  int colonne = 0 ;

  PPT.ajoutePatho(pGoal->sLexique, colonne) ;
  colonne++ ;

  if (pGoal->sComplementText != "")
  	PPT.ajoutePatho(pGoal->sComplementText, colonne) ;

  //ajout la date d'ouverture du medicament
  PPT.ajoutePatho("KOUVR1", 1) ;

  Message CodeMsg ;
  CodeMsg.SetUnit("2DA021") ;
  NVLdVTemps ldvTemp ;
  ldvTemp.takeTime() ;
  string sDateOuverture = ldvTemp.donneDateHeure() ;
  CodeMsg.SetComplement(sDateOuverture) ;
  colonne++ ;
  PPT.ajoutePatho("�T0;19", &CodeMsg, colonne) ;

  //sauvagarde des donn�es avant que les objectifs soit reset�s in CreerTraitement
  string sTitle = pGoal->sTitre ;
  string sCompl = pGoal->sComplementText ;

  pContexte->getSuperviseur()->pBufCopie->vider() ;
  NSCutPaste CP(pContexte) ;
  CP.pPatPatho = new NSPatPathoArray(PPT) ;
  if(!pContexte->getSuperviseur()->pBufCopie)
   	return ;

  *(pContexte->getSuperviseur()->pBufCopie) = CP ;
	pDrugView->autoAddInDrugView(sConcern) ;

  if (pContexte->getSuperviseur()->getDPIO() && pContexte->getSuperviseur()->getDPIO()->bLogPage)
  {
    if (initLogMed)
    {
			pContexte->getSuperviseur()->getDPIO()->addToLogPage(string(""), string("<br>\r\n")) ;
    	pContexte->getSuperviseur()->getDPIO()->addToLogPage(string("Prescription m�dicamenteuse :"), string("<b>"), string("</b><br>\r\n")) ;
    }
		pContexte->getSuperviseur()->getDPIO()->addToLogPage(sTitle, string("<li>")) ;
		if (sCompl != "")
			pContexte->getSuperviseur()->getDPIO()->addToLogPage(string(1, ' ') + sCompl, string("<i>"), string("</i>")) ;
		pContexte->getSuperviseur()->getDPIO()->addToLogPage(string(""), string("</li>\r\n")) ;
		pContexte->getSuperviseur()->getDPIO()->AppendLogFile();
	}
}

void
NSLdvDocument::transferInProccess(string sConcern, ArrayGoals *pGoals)
{
  if((!pGoals)||(pGoals->empty()))
  	return ;

  // Ajout d'un nouveau segment d'arbre
	// Adding a new tree branch
  //
	NSPatPathoArray PatPatho(pContexte) ;

	int colonne = 0 ;
  PatPatho.ajoutePatho("ZPRBI1", colonne) ;
  colonne++;
  bool initLogMed = true ;
  for(ArrayGoalIter pGoalIter = pGoals->begin(); pGoalIter!= pGoals->end(); pGoalIter++)
  {
    int newCol = colonne ;
  	PatPatho.ajoutePatho((*pGoalIter)->sLexique, newCol) ;
  	newCol++ ;
  	if((*pGoalIter)->sComplementText != "")
    {
    	PatPatho.ajoutePatho((*pGoalIter)->sComplementText, newCol) ;
      newCol++ ;
    }

 		PatPatho.ajoutePatho("KOUVR1", newCol) ;

  	Message CodeMsg ;
  	CodeMsg.SetUnit("2DA021") ;
  	NVLdVTemps ldvTemp;
  	ldvTemp.takeTime();
  	string sDateOuverture = ldvTemp.donneDateHeure();
  	CodeMsg.SetComplement(sDateOuverture) ;
  	newCol++;
  	PatPatho.ajoutePatho("�T0;19", &CodeMsg, newCol) ;

    if (pContexte->getSuperviseur()->getDPIO() && pContexte->getSuperviseur()->getDPIO()->bLogPage)
  	{
    	if (initLogMed)
    	{
				pContexte->getSuperviseur()->getDPIO()->addToLogPage(string(""), string("<br>\r\n")) ;
    		pContexte->getSuperviseur()->getDPIO()->addToLogPage(string("Prescription de biologie :"), string("<b>"), string("</b><br>\r\n")) ;
        initLogMed = false ;
    	}
			pContexte->getSuperviseur()->getDPIO()->addToLogPage((*pGoalIter)->sTitre, string("<li>")) ;
   		if ((*pGoalIter)->sComplementText != "")
    		pContexte->getSuperviseur()->getDPIO()->addToLogPage((*pGoalIter)->sComplementText, string("<i>"), string("</i>")) ;
   		pContexte->getSuperviseur()->getDPIO()->addToLogPage(string(""), string("</li>\r\n")) ;
      pContexte->getSuperviseur()->getDPIO()->AppendLogFile();
  	}
  }

  // enregistrement du document
  NSCSDocument CSDoc(0, pContexte) ;
  *(CSDoc.pPatPathoArray) = PatPatho;

  string sLibelle ;
  string sTxt = "ZPRBI1" ;
  pContexte->getDico()->donneLibelle( pContexte->getUtilisateur()->donneLang(), &sTxt, &sLibelle) ;

  bool existeInfo = CSDoc.Referencer("ZCN00", sLibelle, "", "", true, false) ;

  if (existeInfo)
  	existeInfo = CSDoc.enregistrePatPatho() ;

  if (existeInfo)
  {
  	//
    // Rafraichir l'historique
    //
    /* bool bReload = */ CSDoc.NSNoyauDocument::chargePatPatho() ;
    pContexte->getPatient()->pDocHis->Rafraichir(CSDoc.pDocInfo, CSDoc.pPatPathoArray) ;
    PatPatho = *(CSDoc.pPatPathoArray) ;
  }

  PatPathoIter iter;
  string sNodeALier;
  NSLinkManager* pLinks = pContexte->getPatient()->pGraphPerson->pLinkManager ;
  for(ArrayGoalIter pGoalIter = pGoals->begin(); pGoalIter!= pGoals->end(); pGoalIter++)
  {
		iter = PatPatho.ChercherItem((*pGoalIter)->sLexique) ;
    if ((iter != NULL) && (iter != PatPatho.end()))
    {
    	sNodeALier = (*iter)->getNode() ;
      pLinks->etablirLien((*pGoalIter)->getNoeud(), NSRootLink::processWaitingFor, sNodeALier) ;
    }
  }

	if (existeInfo)
		existeInfo = CSDoc.enregistrePatPatho() ;

  NSProcessView* pProcView = getProcessView(sConcern) ;
  if(pProcView == NULL)
  {
  	// TO DO creer la view
  	//pDrugView = new NSDrugView(*this, sConcern) ;
    NSDocViewManager dvManager(pContexte) ;
		dvManager.createView(this, "Process Management") ;
    pProcView = getProcessView(sConcern) ;
  }
  pProcView->initCurentProcesses() ;
  pProcView->AfficheListe() ;
}

NSGoalView*
NSLdvDocument::getGoalView(string sConcern)
{
	TView* pView = GetViewList() ;
  if (NULL == pView)
		return NULL ;

	do
	{
		// GoalView ?
    //
		NSGoalView* pGoalView = TYPESAFE_DOWNCAST(pView, NSGoalView) ;
		if (pGoalView)
    {
    	string sViewConcern = pGoalView->getConcern() ;
      if (sViewConcern == sConcern)
      	return pGoalView ;
    }

		pView = NextView(pView) ;
	}
	while (pView) ;

	return NULL ;
}

void
NSLdvDocument::initGoal(NSLdvGoal* pGoal)
{
	if (NULL == pGoal)
		return ;

	if (pGoal->sLexique == string(""))
		return ;

	// Objectif qui ne s'ouvre jamais
	if ((pGoal->sOpenEventNode == "") && (pGoal->tDateOuverture.estVide()))
		return ;

	//
	// On regarde si les conditions d'ouverture sont r�alis�es
	//
	NVLdVTemps tNow ;
	tNow.takeTime() ;
	// Date de fermeture d�j� atteinte : on sort
	if ((!(pGoal->tDateFermeture.estVide())) && (pGoal->tDateFermeture < tNow))
		return ;

	// Drug ?
  //
  if ((pGoal->sLexique[0] == 'I') || (pGoal->sLexique[0] == '_'))
  {
		initGoalForDrug(pGoal) ;
    return ;
	}

	initGoalForAct(pGoal) ;
}

void
NSLdvDocument::initGoalForDrug(NSLdvGoal* pGoal)
{
	if ((NULL == pGoal) || (pGoal->getNoeud() == string("")))
		return ;

	if (pDrugs->empty())
		return ;

	string sNewConcept ;
	pContexte->getDico()->donneCodeSens(&(pGoal->sLexique), &sNewConcept) ;

	if ((sNewConcept == string("")) || ((sNewConcept[0] != 'I') && (sNewConcept[0] != '_')))
		return ;

  NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

  // Now, we are loooking for open treatments that can open or goal
  //
  NSLdvDrug* pOpenDrug = donneMostRecentOpenDrug(sNewConcept) ;
  while (NULL != pOpenDrug)
	{
  	pGraphe->etablirLien(pOpenDrug->getNoeud(), NSRootLink::goalReseter, pGoal->getNoeud()) ;

    pOpenDrug = donneNextRecentOpenDrug(sNewConcept, pOpenDrug) ;
	}

	return ;
}

void
NSLdvDocument::initGoalForAct(NSLdvGoal* pGoal)
{
	if (NULL == pGoal)
		return ;

	//
	// On regarde le document le plus r�cent du m�me type
	//
	string sNewConcept ;
	pContexte->getDico()->donneCodeSens(&(pGoal->sLexique), &sNewConcept) ;

	NVLdVTemps  tDateDoc ;
	tDateDoc.init() ;

	string sDocId = "" ;

  if ((NULL == pContexte->getPatient()) || (NULL == pContexte->getPatient()->pDocHis))
		return ;

	NSHISTODocument* pDocHis = pContexte->getPatient()->pDocHis ;

	NSPatPathoArray* pPatPathoDoc = new NSPatPathoArray(pContexte) ;
	DocumentIter itDoc = pDocHis->DonnePatPathoDocument(sNewConcept, pPatPathoDoc) ;
	if ((itDoc != NULL) && (itDoc != pDocHis->VectDocument.end()))
	{
  	string sDate = (*itDoc)->GetDateDoc() ;
    tDateDoc.initFromDate(sDate) ;

    PatPathoIter iter = pPatPathoDoc->begin() ;
    sDocId = (*iter)->getNode() ;
	}
	delete pPatPathoDoc ;

  NVLdVTemps tNow ;
	tNow.takeTime() ;

	//
	// Si l'objectif est ponctuel, on regarde si le document est dans les
	// dates pr�vues
	//
	if (!(pGoal->iRythme == NSLdvGoal::cyclic))
	{
		// Si il existe une date de d�but autoris�
    if (pGoal->sDateDebutAutorise != "")
    {
    	NVLdVTemps tDateDebut ;
      tDateDebut.initFromDate(pGoal->sDateDebutAutorise) ;
      // Si le document est ant�rieur � la date de d�but autoris�, on ne
      // doit pas en tenir compte
      if (tDateDoc < tDateDebut)
      	return ;
      // Sinon, le document ferme l'objectif
      closeGoal(pGoal, &tNow, NULL) ;
      return ;
    }
    string sDateMin = "" ;
    if (pGoal->sDateDebutConseille != "")
    	sDateMin = pGoal->sDateDebutConseille ;
    else
    	if (pGoal->sDateDebutIdeal != "" )
      	sDateMin = pGoal->sDateDebutIdeal ;
      else
      	if (pGoal->sDateDebutIdealMax != "" )
        	sDateMin = pGoal->sDateDebutIdealMax ;
        else
        	if (pGoal->sDateDebutConseilMax != "" )
          	sDateMin = pGoal->sDateDebutConseilMax ;
          else
          	if (pGoal->sDateDebutCritique != "" )
            	sDateMin = pGoal->sDateDebutCritique ;

    if (sDateMin == "")
    	return ;

    // Sinon, le document ferme l'objectif
    NVLdVTemps tDateDebut ;
    tDateDebut.initFromDate(sDateMin) ;
    if (tDateDoc >= tDateDebut)
    	closeGoal(pGoal, &tNow, NULL) ;
    return ;
	}

	//
	// ------------------------- Objectif cyclique ------------------------
	//

  // On cherche s'il existe un �v�nement d'ouverture
  if (pGoal->sOpenEventNode != "")
  {
    string sEventConcept ;
    pContexte->getDico()->donneCodeSens(&(pGoal->sOpenEventNode), &sEventConcept) ;

    pPatPathoDoc = new NSPatPathoArray(pContexte) ;
    itDoc = pDocHis->DonnePatPathoDocument(sEventConcept, pPatPathoDoc) ;
    if ((itDoc != NULL) && (itDoc != pDocHis->VectDocument.end()))
    {
    	string sDate = (*itDoc)->GetDateDoc() ;
      tDateDoc.initFromDate(sDate) ;
    }
    else
    {
    	delete pPatPathoDoc ;
      return ;
    }
    PatPathoIter iter = pPatPathoDoc->begin() ;
    string sOpener = (*iter)->getNode() ;
    NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
    pGraphe->etablirLien(sOpener, NSRootLink::goalOpener, pGoal->sReference) ;

    NVLdVTemps tDateOpener ;
    tDateOpener.init() ;
    string sDate = (*itDoc)->GetDateDoc() ;
    tDateOpener.initFromDate(sDate) ;

    delete pPatPathoDoc ;

    // Si l'�v�nement d'ouverture est plus r�cent que le document, on sort
    if (tDateOpener > tDateDoc)
    	return ;
  }

	if (sDocId == "")
		return ;

	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	pGraphe->etablirLien(sDocId, NSRootLink::goalReseter, pGoal->sReference) ;
}

void
NSLdvDocument::initGoalForNumValue(NSLdvGoal* pGoal)
{
	if (NULL == pGoal)
		return ;
}

//-----------------------------------------------------------------------//
//						Classe NSConcernModifier                         //
//-----------------------------------------------------------------------//

NSConcernModifier::NSConcernModifier(NSConcern* pThisConcern,
                                     NVLdVTemps tDateTimeDeb,
                                     NVLdVTemps tDateTimeFin,
                                     int        iSeverity,
                                     int        iFonction,
                                     int        iRisk)
{
	pConcern        = pThisConcern;
	tDateHeureDeb   = tDateTimeDeb;
	tDateHeureFin   = tDateTimeFin;
	iSeverite       = iSeverity;
	iStatFonct      = iFonction;
	iRisque         = iRisk;
}


NSConcernModifier::NSConcernModifier(NSConcernModifier& rv)
{
	pConcern        = rv.pConcern;
	tDateHeureDeb   = rv.tDateHeureDeb;
	tDateHeureFin   = rv.tDateHeureFin;
	iSeverite       = rv.iSeverite;
	iStatFonct      = rv.iStatFonct;
	iRisque         = rv.iRisque;
}


NSConcernModifier::~NSConcernModifier()
{
}


NSConcernModifier&
NSConcernModifier::operator=(NSConcernModifier& src)
{
	pConcern        = src.pConcern;
	tDateHeureDeb   = src.tDateHeureDeb;
	tDateHeureFin   = src.tDateHeureFin;
	iSeverite       = src.iSeverite;
	iStatFonct      = src.iStatFonct;
	iRisque         = src.iRisque;

  return *this;
}


//-----------------------------------------------------------------------//
//				   		Classe ArrayPbModifier                           //
//-----------------------------------------------------------------------//

void
ArrayPbModifier::addModifier(NSConcernModifier* pModifier)
{
try
{
	// Recherche des modificateurs qui "encadrent" le nouveau
  // Looking for the modifiers that surround the new one
	NSConcernModifier* pModifierBefore = 0;
	NSConcernModifier* pModifierAfter = 0;

	if (!(empty()))
	{
		for (ArrayModifierIter i = begin(); i != end(); i++)
		{
			// Before
			if ((*i)->tDateHeureDeb < pModifier->tDateHeureDeb)
			{
				// The latest of the Modif before
				if ((!pModifierBefore) ||
						(pModifierBefore->tDateHeureDeb < (*i)->tDateHeureDeb))
					pModifierBefore = *i;
			}
			// After
			else
			{
				// The earliest of the Modif after
				if ((!pModifierAfter) ||
						(pModifierAfter->tDateHeureDeb > (*i)->tDateHeureDeb))
					pModifierAfter = *i;
			}
		}
	}

	if (pModifierBefore)
		pModifierBefore->tDateHeureFin = pModifier->tDateHeureDeb;

	if (pModifierAfter)
		pModifier->tDateHeureFin = pModifierAfter->tDateHeureDeb;
	else
	{
		if (pModifier->pConcern->tDateFermeture.estNoLimit())
			pModifier->tDateHeureFin.setNoLimit();
		else
			pModifier->tDateHeureFin = pModifier->pConcern->tDateFermeture;
	}

	push_back(new NSConcernModifier(*pModifier));
	return;
}
catch (...)
{
  erreur("Exception ArrayPbModifier::addModifier.", standardError, 0) ;
}
}


ArrayPbModifier::ArrayPbModifier(ArrayPbModifier& rv)
	:	ArrayModifier()
{
try
{
	if (!(rv.empty()))
		for (ArrayModifierIter i = rv.begin(); i != rv.end(); i++)
    	    push_back(new NSConcernModifier(*(*i)));
}
catch (...)
{
  erreur("Exception ArrayPbModifier.", standardError, 0) ;
}
}


void
ArrayPbModifier::vider()
{
	if (empty())
		return;

	for (ArrayModifierIter i = begin(); i != end(); )
	{
		delete *i;
		erase(i);
	}
}


ArrayPbModifier::~ArrayPbModifier()
{
	vider();
}


ArrayPbModifier&
ArrayPbModifier::operator=(ArrayPbModifier src)
{
try
{
	vider();

	if (!(src.empty()))
		for (ArrayModifierIter i = src.begin(); i != src.end(); i++)
			push_back(new NSConcernModifier(*(*i)));

	return *this;
}
catch (...)
{
	erreur("Exception ArrayPbModifier= .", standardError, 0) ;
	return *this;
}
}


//-----------------------------------------------------------------------//
//						    Classe NSConcern                             //
//-----------------------------------------------------------------------//

NSConcern::NSConcern(NSContexte* pCtx, NSLdvDocument* pDocum)
          :NSRoot(pCtx)
{
try
{
	pDoc            = pDocum;

	sTitre          = string("") ;
	sSignificatif   = string("") ;
	sSeverite       = string("") ;
	tDateOuverture.init();
	tDateFermeture.setNoLimit();
	tDateDebut.init();
	tDateAutoClose.init();

	pWorstJalons    = new GoalInfoArray() ;

	sReference      = string("") ;
	sHealthIssue    = string("") ;
	sPrimoPb        = string("") ;
  sCocCode        = string("") ;

	pPptDetails     = NULL ;
}
catch (...)
{
	erreur("Exception NSConcern ctor.", standardError, 0) ;
}
}


NSConcern::NSConcern(NSConcern& rv)
          :NSRoot(rv.pContexte)
{
try
{
	pDoc            = rv.pDoc ;

	sReference      = rv.sReference ;
	sHealthIssue    = rv.sHealthIssue ;
	sPrimoPb        = rv.sPrimoPb ;
  sCocCode        = rv.sCocCode ;

	sTitre          = rv.sTitre ;
	sSignificatif   = rv.sSignificatif ;
	sSeverite       = rv.sSeverite ;
	tDateOuverture  = rv.tDateOuverture ;
	tDateFermeture  = rv.tDateFermeture ;
	tDateDebut      = rv.tDateDebut ;
	tDateAutoClose  = rv.tDateAutoClose ;

	aModificateurs  = rv.aModificateurs ;

	pWorstJalons    = new GoalInfoArray(*(rv.pWorstJalons)) ;

	if (rv.pPptDetails)
		pPptDetails = new NSPatPathoArray(*(rv.pPptDetails)) ;
	else
		pPptDetails = NULL ;
}
catch (...)
{
	erreur("Exception NSConcern copy ctor.", standardError, 0) ;
}
}

NSConcern::~NSConcern()
{
	delete pWorstJalons ;
	if (pPptDetails)
		delete pPptDetails ;
}

void
NSConcern::goalAdded(NSLdvGoal* pGoal)
{
try
{
    if (!pGoal)
        return ;

    GoalInfoArray* pJalons = pGoal->pMetaJalons ;

    if ((!pJalons) || (pJalons->empty()))
        return ;

    if (pWorstJalons->empty())
    {
        *pWorstJalons = *pJalons ;
        return ;
    }

    bool        bNeedSort = false ;

    bool        bContinue ;     // Faut-il traiter les anciens jalons au del�
                                // du premier qui recoupe le nouveau ?
    NVLdVTemps  tpsContinue ;   // Moment de d�part de l'intervalle � prolonger

    GoalInfoIter iOld ;
    GoalInfoIter iNew = pJalons->begin() ;
    //
    // Pour chaque jalon, on regarde son influence pour aWorstJalons
    //
    for ( ; iNew != pJalons->end(); iNew++)
    {
        // On cherche le premier worstJalon qui inclut celui ci
        //
        for (iOld = pWorstJalons->begin();
                        (iOld != pWorstJalons->end()) &&
                        ((*iOld)->tpsClosed <= (*iNew)->tpsInfo); iOld++);
        //
        // S'il n'y en a pas, c'est que ce jalon est au del� du dernier worstJalon
        //
        if (iOld == pWorstJalons->end())
            break ;

        // Le pire est d�j� sans limites !
        // Worst is already unlimited !
        if (((*iOld)->iLevel == NSLdvGoalInfo::AProuge) &&
            ((*iOld)->tpsClosed.estNoLimit()))
            break;

        bContinue = false ;
        tpsContinue.init() ;

        // Cas 1 : le nouveau est inclu dans le worst
        if (((*iOld)->tpsInfo <= (*iNew)->tpsInfo) &&
            ((*iOld)->tpsClosed >= (*iNew)->tpsClosed))
        {
            // Le nouveau est pire que l'ancien
            if ((*iNew)->iLevel > (*iOld)->iLevel)
            {
                // recouvrement parfait : le nouveau prend la place de l'ancien
                if (((*iOld)->tpsInfo == (*iNew)->tpsInfo) &&
                    ((*iOld)->tpsClosed == (*iNew)->tpsClosed))
                    **iOld = **iNew ;
                // l'ancien commence plus t�t
                else if ((*iOld)->tpsInfo < (*iNew)->tpsInfo)
                {
                    // S'ils finissent en m�me temps : le nouveau tronque
                    if ((*iOld)->tpsClosed == (*iNew)->tpsClosed)
                    {
                        (*iOld)->tpsClosed = (*iNew)->tpsInfo ;
                        pWorstJalons->push_back(new NSLdvGoalInfo(**iNew)) ;
                        bNeedSort = true ;
                    }
                    // si le nouveau est inclu, alors il s'ins�re (-> 3 jalons)
                    else
                    {
                        NSLdvGoalInfo* pThird = new NSLdvGoalInfo(**iOld) ;
                        pThird->tpsInfo = (*iNew)->tpsClosed ;
                        (*iOld)->tpsClosed = (*iNew)->tpsInfo;
                        pWorstJalons->push_back(new NSLdvGoalInfo(**iNew)) ;
                        pWorstJalons->push_back(pThird) ;
                        bNeedSort = true ;
                    }
                }
                // Les deux commencent en m�me temps, le nouveau est plus court
                else
                {
                    (*iOld)->tpsInfo = (*iNew)->tpsClosed;
                    pWorstJalons->push_back(new NSLdvGoalInfo(**iNew)) ;
                    bNeedSort = true ;
                }
            }
        }
        //
        // Cas 2 : le nouveau pr�c�de le premier ancien
        //
        else if ((*iOld)->tpsInfo > (*iNew)->tpsInfo)
        {
            //
            // Cas trivial : pas de recoupement
            // Trivial case : no crossing
            //
            if ((*iOld)->tpsInfo >= (*iNew)->tpsClosed)
            {
                // On ajoute le nouveau et on sort
                pWorstJalons->push_back(new NSLdvGoalInfo(**iNew)) ;
                bNeedSort = true ;
            }
            //
            // Cas avec recoupement
            // Crossing exists
            //
            else
            {
                //
                // si le nouveau est pire que l'ancien, il le mange ou le tronque
                //
                if ((*iNew)->iLevel > (*iOld)->iLevel)
                {
                    // si le nouveau dure plus longtemps : l'ancien disparait
                    if ((*iOld)->tpsClosed <= (*iNew)->tpsClosed)
                    {
                        if ((*iOld)->tpsClosed < (*iNew)->tpsClosed)
                        {
                            bContinue   = true ;
                            tpsContinue = (*iNew)->tpsInfo ;
                        }
                        delete *iOld ;
                        pWorstJalons->erase(iOld) ;
                    }
                    // sinon, l'ancien est tronqu�
                    else
                    {
                        (*iOld)->tpsInfo = (*iNew)->tpsClosed ;
                        // On ajoute le nouveau et on sort
                        pWorstJalons->push_back(new NSLdvGoalInfo(**iNew)) ;
                        bNeedSort = true ;
                    }
                }
                //
                // sinon, c'est le nouveau qui est raccourci
                //
                else
                {
                    NSLdvGoalInfo* pJalonNew = new NSLdvGoalInfo(**iNew) ;
                    pJalonNew->tpsClosed = (*iOld)->tpsInfo ;
                    pWorstJalons->push_back(pJalonNew) ;
                    bNeedSort = true ;
                    if ((*iOld)->tpsClosed < (*iNew)->tpsClosed)
                        bContinue = true ;
                }
            }
        }
        //
        // Cas 3 : le nouveau est � cheval sur plusieurs anciens, ou dure plus longtemps
        //
        else
        {
            NSLdvGoalInfo newJalon(**iNew) ;

            //
            // On traite le jalon de d�but
            //
            //
            // si le nouveau est pire que l'ancien, il le mange ou le tronque
            //
            if ((*iNew)->iLevel > (*iOld)->iLevel)
            {
                bContinue   = true ;
                tpsContinue = (*iNew)->tpsInfo ; // c'est le nouveau segment qui fixe sa date de d�but

                // si les deux commencent en m�me temps : l'ancien disparait
                if ((*iOld)->tpsInfo == (*iNew)->tpsInfo)
                {
                    delete *iOld ;
                    pWorstJalons->erase(iOld) ;
                }
                // sinon, l'ancien est tronqu�
                else
                {
                    (*iOld)->tpsClosed = (*iNew)->tpsInfo ;
                    iOld++ ;
                }
            }
            //
            // sinon, c'est le nouveau qui est raccourci
            //
            else
                iOld++ ;

            // S'il n'existe plus d'ancien jalon au del�...
            //
            /*
            if (iOld == pWorstJalons->end())
            {
                pWorstJalons->push_back(new NSLdvGoalInfo(newJalon)) ;
                iNew++ ;
                break;
            } */

        }
        //
        // Le nouveau jalon d�borde sur plusieurs anciens jalons, on doit
        // les traiter
        // The new jalon is crossing several existing ones, we must treat them
        //
        if (bContinue)
        {
            //
            // On traite les �ventuels jalons interm�diaires
            // Jalons fully contained in the new jalon
            //
            for ( ; (iOld != pWorstJalons->end()) &&
                                ((*iOld)->tpsClosed < (*iNew)->tpsClosed) ; )
            {
                // si le nouveau est pire que l'ancien, il le supprime
                // if the new one is worse, it deletes the previous one
                if ((*iNew)->iLevel > (*iOld)->iLevel)
                {
                    if (tpsContinue.estVide())
                        tpsContinue = (*iOld)->tpsInfo ;
                    delete *iOld ;
                    pWorstJalons->erase(iOld) ;
                }
                // sinon, on ne prend en compte que la partie plus ancienne de
                // newJalon, si elle existe
                else
                {
                    if (!(tpsContinue.estVide()))
                    {
                        NSLdvGoalInfo* pJalonNew = new NSLdvGoalInfo(**iNew) ;
                        pJalonNew->tpsInfo      = tpsContinue ;
                        pJalonNew->tpsClosed    = (*iOld)->tpsInfo ;
                        pWorstJalons->push_back(pJalonNew) ;
                        bNeedSort = true ;
                    }
                    iOld++ ;
                }
            }
            //
            // Le nouveau jalon est au moins aussi long que le plus long des anciens
            //
            if (iOld == pWorstJalons->end())
            {
                if (!(tpsContinue.estVide()))
                {
                    NSLdvGoalInfo* pJalonNew = new NSLdvGoalInfo(**iNew) ;
                    pJalonNew->tpsInfo      = tpsContinue ;
                    pWorstJalons->push_back(pJalonNew) ;
                    bNeedSort = true ;
                }
            }
            //
            // On traite le dernier jalon
            //
            else
            {
                // si le nouveau est pire que l'ancien, il le mange ou le tronque
                //
                if ((*iNew)->iLevel > (*iOld)->iLevel)
                {
                    if (tpsContinue.estVide())
                        tpsContinue = (*iOld)->tpsInfo ;

                    // si les deux finissent en m�me temps : l'ancien disparait
                    if ((*iOld)->tpsClosed == (*iNew)->tpsClosed)
                    {
                        delete *iOld ;
                        pWorstJalons->erase(iOld) ;
                    }
                    // sinon, l'ancien est tronqu�
                    else
                        (*iOld)->tpsInfo = (*iNew)->tpsClosed ;

                    NSLdvGoalInfo* pJalonNew = new NSLdvGoalInfo(**iNew) ;
                    pJalonNew->tpsInfo = tpsContinue ;
                    pWorstJalons->push_back(pJalonNew) ;
                    bNeedSort = true ;
                }
                //
                // sinon, c'est le nouveau qui est raccourci
                //
                else
                {
                    if (!(tpsContinue.estVide()))
                    {
                        NSLdvGoalInfo* pJalonNew = new NSLdvGoalInfo(**iNew) ;
                        pJalonNew->tpsInfo      = tpsContinue ;
                        pJalonNew->tpsClosed    = (*iOld)->tpsInfo ;
                        pWorstJalons->push_back(pJalonNew) ;
                        bNeedSort = true ;
                    }
                }
            }
        }

        //
        // On re-trie par ordre chronologique worstJalons
        //
        if (bNeedSort)
        {
            sort(pWorstJalons->begin(), pWorstJalons->end(), infGoalInfo) ;
            bNeedSort = false ;
        }
    }
    //
    // Tous les jalons restants sont ajout�s tels quels
    // All remaining steps are added "as is"
    //
    if ((iNew != pJalons->end()) && (iOld == pWorstJalons->end()))
        for ( ; iNew != pJalons->end(); iNew++)
            pWorstJalons->push_back(new NSLdvGoalInfo(**iNew)) ;

    //
    // On re-trie par ordre chronologique worstJalons
    //
    if (bNeedSort)
        sort(pWorstJalons->begin(), pWorstJalons->end(), infGoalInfo) ;
}
catch (...)
{
	erreur("Exception NSConcern::goalAdded.", standardError, 0) ;
}
}

bool
NSConcern::isActiveConcern()
{
	NVLdVTemps tNow ;
	tNow.takeTime() ;

	if (tDateOuverture <= tNow)
		if (tDateFermeture.estNoLimit())
			return true ;
    else
    	if (tDateFermeture >= tNow)
      	return true ;
      else
      	return false ;
	else
  	return false ;
}

int
NSConcern::getMaxSeverityIndex()
{
	if (aModificateurs.empty())
		return -1 ;

	int iMaxSeverity = -1 ;

	ArrayModifierIter itMod = aModificateurs.begin() ;
  for ( ; itMod != aModificateurs.end() ; itMod++)
  	if ((*itMod)->iSeverite > iMaxSeverity)
    	iMaxSeverity = (*itMod)->iSeverite ;

	return iMaxSeverity ;
}

int
NSConcern::getMinSeverityIndex()
{
	if (aModificateurs.empty())
		return -1 ;

	int iMinSeverity = -1 ;

	ArrayModifierIter itMod = aModificateurs.begin() ;
  for ( ; itMod != aModificateurs.end() ; itMod++)
  	if (((*itMod)->iSeverite < iMinSeverity) || (-1 == iMinSeverity))
    	iMinSeverity = (*itMod)->iSeverite ;

	return iMinSeverity ;
}

void
NSConcern::sendFocusEvent()
{
	sendEvent(FOCUS) ;
}

void
NSConcern::sendActivationEvent()
{
	sendEvent(ACTIVATE) ;
}

void
NSConcern::sendEvent(EventType iEvent)
{
	NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex ;
  if (!pPtIndex)
		return ;

	PatPathoIter pptIter = pPtIndex->ChercherNoeud(sReference) ;
  if ((pptIter == NULL) || (pptIter == pPtIndex->end()))
		return ;

	NautilusEvent nsEvent(pPtIndex, pptIter, iEvent, false) ;
  pContexte->getSuperviseur()->getBBinterface()->addNautilusEvent(&nsEvent) ;
}

void
NSConcern::goalModified(NSLdvGoal* pGoal)
{
	// if (!pGoal)
	//     return ;

	//
	// On reconstruit enti�rement worstJalons
	// worstJalons is completely rebuilt
	//
	pWorstJalons->vider() ;

	ArrayGoals* pLdvGoals = pDoc->getGoals() ;
	if (pLdvGoals->empty())
		return ;

	// On passe en revue tous les objectifs
	//
	for (ArrayGoalIter goalIt = pLdvGoals->begin();
                                        goalIt != pLdvGoals->end(); goalIt++)
		if ((*goalIt)->sConcern == sReference)
    	goalAdded(*goalIt) ;
}

NSConcern&
NSConcern::operator=(NSConcern& src)
{
try
{
	if (this == &src)
		return *this ;

	pDoc            = src.pDoc ;

	sTitre          = src.sTitre ;
	sSignificatif   = src.sSignificatif ;
	sSeverite       = src.sSeverite ;
	tDateOuverture  = src.tDateOuverture ;
	tDateFermeture  = src.tDateFermeture ;
	tDateDebut      = src.tDateDebut ;
	tDateAutoClose  = src.tDateAutoClose ;

	sReference      = src.sReference ;
	sHealthIssue    = src.sHealthIssue ;
	sPrimoPb        = src.sPrimoPb ;
  sCocCode        = src.sCocCode ;

	aModificateurs  = src.aModificateurs ;

	if (src.pPptDetails)
  {
  	if (pPptDetails)
    	*pPptDetails = *(src.pPptDetails) ;
    else
    	pPptDetails = new NSPatPathoArray(*(src.pPptDetails)) ;
	}
	else if (pPptDetails)
	{
		delete pPptDetails ;
    pPptDetails = NULL ;
	}

  pWorstJalons->vider() ;
  if (src.pWorstJalons && !src.pWorstJalons->empty())
  	*pWorstJalons = *(src.pWorstJalons) ;

	return *this ;
}
catch (...)
{
	erreur("Exception NSConcern::operator=.", standardError, 0) ;
	return *this;
}
}


//-----------------------------------------------------------------------//
//				   		 Classe ArrayConcern                             //
//-----------------------------------------------------------------------//

ArrayConcern::ArrayConcern(ArrayConcern& rv)
	:	ArrayPb()
{
try
{
	pDoc = rv.pDoc;

	if (!(rv.empty()))
		for (ArrayConcernIter i = rv.begin(); i != rv.end(); i++)
			push_back(new NSConcern(*(*i)));
}
catch (...)
{
	erreur("Exception ArrayConcern ctor.", standardError, 0) ;
}
}


void
ArrayConcern::vider()
{
	if (empty())
		return ;

	for (ArrayConcernIter i = begin(); i != end(); )
	{
		delete *i ;
		erase(i) ;
	}
}


ArrayConcern::~ArrayConcern()
{
	vider() ;
}

void
ArrayConcern::initialiser()
{
	if ((!pDoc) || (!(pDoc->pPathoPOMRIndex)) || (pDoc->pPathoPOMRIndex->empty()))
		return;

	NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex ;

	// On cherche le chapitre "pr�occupations de sant�"
	PatPathoIter iter = pPtIndex->ChercherItem("0PRO11") ;

	if ((iter != NULL) && (iter != pPtIndex->end()))
	{
		int iColBase = (*iter)->getColonne() ;
		iter++ ;
		loadConcerns(iter, iColBase) ;
	}
}


void
ArrayConcern::reinit()
{
	if ((!pDoc) || (!(pDoc->pPathoPOMRIndex)) || (pDoc->pPathoPOMRIndex->empty()))
		return ;

	NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex ;

	// On cherche le chapitre "pr�occupations de sant�"
	PatPathoIter iter = pPtIndex->ChercherItem("0PRO11") ;

	if ((iter != NULL) && (iter != pPtIndex->end()))
	{
		int iColBase = (*iter)->getColonne() ;
		iter++ ;
		reloadConcerns(iter, iColBase) ;
	}
}

void
ArrayConcern::reloadConcerns(PatPathoIter iter, int iColBase)
{
try
{
	NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex ;

	NSConcern* pConcern = 0;

	while ( (iter != pPtIndex->end()) &&
					((*iter)->getColonne() > iColBase))
	{
		// Probl�me
		if ((*iter)->getColonne() == iColBase+1)
		{
			if (pConcern)
			{
				bool    b2Add = true ;
				if (false == empty())
				{
					for (ArrayConcernIter PbIter = begin() ; PbIter != end() ; PbIter++)
						if ((*PbIter)->sReference == pConcern->sReference)
							b2Add = false ;
				}
				if (b2Add)
				{
					NSConcern *pPb = new NSConcern(*pConcern) ;
					push_back(pPb) ;
          pDoc->getSsObjets()->initForConcern(pPb) ;

					TView* pView = pDoc->GetViewList() ;
          if (NULL != pView)
          {
						do
						{
							NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView) ;
							if (pLdvView)
								pLdvView->addProb(pPb) ;

							pView = pDoc->NextView(pView) ;
						}
						while (pView) ;
          }
				}
				delete pConcern ;
				pConcern = 0 ;
			}

      string sCodeLex = (*iter)->getLexique() ;
      string sCodeSensConcern;
    	pDoc->pContexte->getDico()->donneCodeSens(&sCodeLex, &sCodeSensConcern);

      //
      // Pr�occupation cach�e -- Hidden health concern
      //
      if (sCodeSensConcern == "90000")
      {
      	iter++ ;
      	while ( (iter != pPtIndex->end()) &&
                ((*iter)->getColonne() > iColBase + 1))
        	iter++ ;
      }
      //
      // Pr�occupation visible -- Visible health concern
      //
      else
      {
        pConcern = new NSConcern(pDoc->pContexte, pDoc);

        // Libell�

        if (sCodeLex != string("�?????"))
          pDoc->pContexte->getDico()->donneLibelle(pDoc->sLangue, &sCodeLex, &(pConcern->sTitre));

        // Texte libre - Free text
        else
        	pConcern->sTitre = (*iter)->getTexteLibre() ;

        // Noeud
        pConcern->setNoeud((*iter)->getNode());

        iter++;

        // Param�tres du probl�me
        while ( (iter != pPtIndex->end()) &&
                ((*iter)->getColonne() > iColBase + 1))
        {
          string sSens = (*iter)->getLexiqueSens(pDoc->pContexte) ;

          if ((*iter)->getColonne() == iColBase+2)
          {
            // Dates
            if ((sSens == "KOUVR") || (sSens == "KFERM") || (sSens == "KSYMP"))
            {
              iter++ ;
              int iLigneBase = (*iter)->getLigne() ;
              // gereDate* pDate = new gereDate(pContexte);
              string sUnite  = "";
              string sFormat = "";
              string sValeur = "";
              while (	(iter != pPtIndex->end()) &&
                      ((*iter)->getLigne() == iLigneBase))
              {
                if (pDoc->pContexte->getDico()->CodeCategorie((*iter)->getLexique()) == string(1, '�'))
                {
                	sFormat = (*iter)->getLexiqueSens(pDoc->pContexte) ;
                  sValeur = (*iter)->getComplement() ;
                  sUnite  = (*iter)->getUnitSens(pDoc->pContexte) ;
                  break ;
                }
								iter++ ;
              }

              // sFormat est du type �D0;03
              if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) && (sValeur != ""))
              {
                if ((sUnite == "2DA01") || (sUnite == "2DA02"))
                {
                	if (sSens == "KOUVR")
                    pConcern->tDateOuverture.initFromDate(sValeur);
                  else
                    if (sSens == "KFERM")
                      pConcern->tDateFermeture.initFromDate(sValeur);
                    else
                      if (sSens == "KSYMP")
                        pConcern->tDateDebut.initFromDate(sValeur);
                }
              }
            }
            //
            // Continuity of care Code
            //
            else if (sSens == "6CISP")
            {
              pConcern->sCocCode = (*iter)->getComplement() ;
              iter++ ;
            }
            //
            // Si des d�tails ont �t� pr�cis�s, on les stocke dans leur patpatho
            // If details were given, we store them in their patpatho
            //
            else if (sSens == "0DETA")
            {
            	if (!(pConcern->pPptDetails))
              	pConcern->pPptDetails = new NSPatPathoArray(pDoc->pContexte) ;
              else
              	pConcern->pPptDetails->vider() ;

              int iColDetails = (*iter)->getColonne() ;
              iter++ ;

              int iLigne   = 0 ;
              int iColonne = 0 ;

              while ((iter != pPtIndex->end()) &&
          								((*iter)->getColonne() > iColDetails))
              {
              	iColonne = (*iter)->getColonne() - iColDetails - 1 ;
                pConcern->pPptDetails->ajoutePatho(iter, iLigne, iColonne) ;
                iter++ ;
                iLigne++ ;
              }
            }
            else
              iter++ ;
          }
          else
            iter++ ;
        }
  		}
		}
		else
			iter++ ;
	}

	if (pConcern)
	{
		bool    b2Add = true ;
		if (!empty())
		{
			for (ArrayConcernIter PbIter = begin() ; PbIter != end() ; PbIter++)
				if ((*PbIter)->sReference == pConcern->sReference)
					b2Add = false ;
		}
		if (b2Add)
		{
			NSConcern *pPb = new NSConcern(*pConcern) ;
			push_back(pPb) ;
			pDoc->getSsObjets()->initForConcern(pPb) ;

			TView* pView = pDoc->GetViewList() ;
      if (NULL != pView)
      {
				do
				{
					NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView) ;
					if (pLdvView)
						pLdvView->addProb(pPb) ;

          pView = pDoc->NextView(pView) ;
				}
      	while (pView) ;
      }
		}
		delete pConcern ;
		pConcern = 0 ;
	}
}
catch (...)
{
	erreur("Exception ArrayConcern::reloadConcerns.", standardError, 0) ;
  return ;
}
}


void
ArrayConcern::deleteConcern(NSConcern* pConcern)
{
	if (empty())
		return ;

	for (ArrayConcernIter i = begin(); i != end(); i++)
	{
		if (*i == pConcern)
		{
			delete pConcern ;
			erase(i) ;
			return ;
		}
	}
}

void
ArrayConcern::loadConcerns(PatPathoIter iter, int iColBase)
{
try
{
	NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex ;

	NSConcern* pConcern = 0;

	while ( (iter != pPtIndex->end()) &&
					((*iter)->getColonne() > iColBase))
	{
		// Probl�me
		if ((*iter)->getColonne() == iColBase+1)
		{
			if (pConcern)
			{
				push_back(new NSConcern(*pConcern));
				delete pConcern;
				pConcern = 0;
			}

      string sCodeLex = (*iter)->getLexique() ;
      string sCodeSensConcern;
    	pDoc->pContexte->getDico()->donneCodeSens(&sCodeLex, &sCodeSensConcern);

      //
      // Pr�occupation cach�e -- Hidden health concern
      //
      if (sCodeSensConcern == "90000")
      {
      	iter++ ;
      	while ( (iter != pPtIndex->end()) &&
                ((*iter)->getColonne() > iColBase + 1))
        	iter++ ;
      }
      //
      // Pr�occupation visible -- Visible health concern
      //
      else
      {
        pConcern = new NSConcern(pDoc->pContexte, pDoc);

        // Libell�
        if (sCodeLex != string("�?????"))
          pDoc->pContexte->getDico()->donneLibelle(pDoc->sLangue, &sCodeLex, &(pConcern->sTitre));

        // Texte libre - Free text
        else
        	pConcern->sTitre = (*iter)->getTexteLibre() ;

        // Noeud
        string sNoeud = (*iter)->getNode() ;
        pConcern->setNoeud(sNoeud) ;

        iter++;

        // Param�tres du probl�me
        while ( (iter != pPtIndex->end()) &&
                ((*iter)->getColonne() > iColBase + 1))
        {
          string sSens = (*iter)->getLexiqueSens(pDoc->pContexte) ;

          if ((*iter)->getColonne() == iColBase+2)
          {
            // Dates
            if ((sSens == "KOUVR") || (sSens == "KFERM") || (sSens == "KSYMP"))
            {
              iter++ ;
              int iLigneBase = (*iter)->getLigne() ;
              // gereDate* pDate = new gereDate(pContexte);
              string sUnite  = "" ;
              string sFormat = "" ;
              string sValeur = "" ;
              while ((iter != pPtIndex->end()) &&
                      ((*iter)->getLigne() == iLigneBase))
              {
								if (pDoc->pContexte->getDico()->CodeCategorie((*iter)->getLexique()) == string(1, '�'))
								{
                  sFormat = (*iter)->getLexiqueSens(pDoc->pContexte) ;
                  sValeur = (*iter)->getComplement() ;
                  sUnite  = (*iter)->getUnitSens(pDoc->pContexte) ;
                  break ;
                }
                iter++ ;
              }

              // sFormat est du type �D0;03
              if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) &&
                          (sValeur != ""))
              {
                if ((sUnite == "2DA01") || (sUnite == "2DA02"))
                {
                  if (sSens == "KOUVR")
                    pConcern->tDateOuverture.initFromDate(sValeur) ;
                  else
                    if (sSens == "KFERM")
                      pConcern->tDateFermeture.initFromDate(sValeur) ;
                    else
                      if (sSens == "KSYMP")
                        pConcern->tDateDebut.initFromDate(sValeur) ;
                }
              }
            }
            //
            // Si des d�tails ont �t� pr�cis�s, on les stocke dans leur patpatho
            // If details were given, we store them in their patpatho
            //
            else if (sSens == "0DETA")
            {
            	if (!(pConcern->pPptDetails))
              	pConcern->pPptDetails = new NSPatPathoArray(pDoc->pContexte) ;
              else
              	pConcern->pPptDetails->vider() ;

              int iColDetails = (*iter)->getColonne() ;
              iter++ ;

              int iLigne      = 0 ;
              int iColonne    = 0 ;

              while ( (iter != pPtIndex->end()) &&
                    ((*iter)->getColonne() > iColDetails))
              {
              	iColonne = (*iter)->getColonne() - iColDetails - 1 ;
                pConcern->pPptDetails->ajoutePatho(iter, iLigne, iColonne) ;
                iter++ ;
                iLigne++ ;
              }
            }
            else
              iter++ ;
          }
          else
            iter++ ;
        }

        // Cette pr�occupation est-elle l'�volution d'une autre ?
        // Is this health concern the evolution of a previous one ?
        NSLinkManager* pGraphe = pDoc->pContexte->getPatient()->pGraphPerson->pLinkManager ;
        VecteurString VectString ;
        pGraphe->TousLesVrais(sNoeud, NSRootLink::problemRelatedTo, &VectString) ;
        if (!VectString.empty())
          pConcern->sPrimoPb = *(*(VectString.begin())) ;
      }
		}
		else
			iter++ ;
	}

	if (pConcern)
	{
		push_back(new NSConcern(*pConcern)) ;
		delete pConcern ;
		pConcern = 0 ;
	}
}
catch (...)
{
	erreur("Exception ArrayConcern::loadConcerns.", standardError, 0) ;
	return;
}
}

/*
NSConcern*
ArrayConcern::getConcern(string sRef)
{
	if (empty())
		return NULL;

	for (ArrayConcernIter i = begin(); i != end(); i++)
		if ((*i)->getNoeud() == sRef)
			return *i;

	return NULL;
}
*/


NSConcern*
ArrayConcern::getFils(NSConcern* pConcern)
{
	if (empty())
		return NULL;

	string sNoeud = pConcern->getNoeud();

	for (ArrayConcernIter i = begin(); i != end(); i++)
		if ((*i)->sPrimoPb == sNoeud)
			return *i;

	return NULL;
}


ArrayConcern&
ArrayConcern::operator=(ArrayConcern src)
{
try
{
	if (this == &src)
		return *this ;

	pDoc = src.pDoc ;

	vider() ;

	if (!(src.empty()))
		for (ArrayConcernIter i = src.begin(); i != src.end(); i++)
			push_back(new NSConcern(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception ArrayConcern (=).", standardError, 0) ;
	return *this;
}
}


//-----------------------------------------------------------------------
//
//						 Classe NSLdvSousObjet
//
//-----------------------------------------------------------------------

NSLdvSousObjet::NSLdvSousObjet(NSContexte* pCtx)
	:	NSRoot(pCtx)
{
	sTitre          = "";
	tDateHeureDebut.init();
	tDateHeureFin.init();

	sConcern        = "";
	sObject         = "";
	sReference      = "";
}


NSLdvSousObjet::NSLdvSousObjet(NSLdvSousObjet& rv)
	:	NSRoot(rv.pContexte)
{
	sTitre          = rv.sTitre;
	tDateHeureDebut = rv.tDateHeureDebut;
	tDateHeureFin   = rv.tDateHeureFin;
	sConcern        = rv.sConcern;
	sObject         = rv.sObject;
	sReference      = rv.sReference;
}


NSLdvSousObjet::~NSLdvSousObjet()
{
}


NSLdvSousObjet&
NSLdvSousObjet::operator=(NSLdvSousObjet& src)
{
	sTitre          = src.sTitre;
	tDateHeureDebut = src.tDateHeureDebut;
	tDateHeureFin   = src.tDateHeureFin;
	sConcern        = src.sConcern;
	sObject         = src.sObject;
	sReference      = src.sReference;

	return *this;
}


//-----------------------------------------------------------------------
//
//				   		 Classe ArraySsObjet
//
//-----------------------------------------------------------------------

ArraySsObjet::ArraySsObjet(ArraySsObjet& rv)
	:	ArraySsObj()
{
try
{
	if (!(rv.empty()))
		for (ArraySsObjIter i = rv.begin(); i != rv.end(); i++)
    	push_back(new NSLdvSousObjet(*(*i)));
}
catch (...)
{
  erreur("Exception ArraySsObjet copy ctor.", standardError, 0) ;
}
}


void
ArraySsObjet::vider()
{
	if (empty())
		return;

	for (ArraySsObjIter i = begin(); i != end(); )
	{
		delete *i;
		erase(i);
	}
}


ArraySsObjet::~ArraySsObjet()
{
	vider();
}


ArraySsObjet&
ArraySsObjet::operator=(ArraySsObjet src)
{
try
{
	if (this == &src)
		return *this ;

	vider() ;

	if (!(src.empty()))
		for (ArraySsObjIter i = src.begin(); i != src.end(); i++)
			push_back(new NSLdvSousObjet(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception ArraySsObjet (=).", standardError, 0) ;
	return *this ;
}
}


void
ArraySsObjet::initialiser()
{
try
{
	ArrayConcern* pPbArray = pDoc->getConcerns();

	if (pPbArray->empty())
		return;

	ArrayConcernIter iPb = pPbArray->begin();
	for ( ; iPb != pPbArray->end(); iPb++)
		initForConcern(*iPb);
}
catch (...)
{
	erreur("Exception ArraySsObjet::initialiser.", standardError, 0) ;
}
}

void
ArraySsObjet::initForConcern(NSConcern* pConcern)
{
try
{
	// Recherche des �l�ments de contact li�s � ce probl�me de sant�
	// Looking for the contact elements linked to this health problem
	NSLinkManager* pGraphe = pDoc->pContexte->getPatient()->pGraphPerson->pLinkManager ;
	VecteurString VectString;
	DBITBLNAME sensCle = "ENVERS";
	pGraphe->TousLesVrais(pConcern->sReference, NSRootLink::problemContactElement,
                            &VectString, sensCle);

	if (!(VectString.empty()))
	{
		EquiItemIter stringIter = VectString.begin();
		for (; stringIter != VectString.end(); stringIter++)
			initSmartSsObject(*(*stringIter), pConcern);
	}
}
catch (...)
{
	erreur("Exception ArraySsObjet::initialiser.", standardError, 0) ;
}
}


bool
ArraySsObjet::initSmartSsObject(string sNoeud, NSConcern* pConcern)
{
try
{
	string sObjReference = string(sNoeud, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) ;

	// Recherche du document qui contient ce sous-objet
	// Looking for the document that contains this sub-object
	NSHISTODocument* pHistory = pDoc->pContexte->getPatient()->pDocHis ;

	if (pHistory->VectDocument.empty())
	{
		initStupidSsObject(sNoeud, pConcern) ;
		return true ;
	}

	DocumentIter iterDoc = pHistory->VectDocument.TrouveDocHisto(sObjReference) ;

	// Not found
	if ((iterDoc == NULL) || (iterDoc == pHistory->VectDocument.end()))
	{
		initStupidSsObject(sNoeud, pConcern) ;
		return true ;
	}

	NSPatPathoArray* pPt = (*iterDoc)->pPatPathoArray ;

	if ((!pPt) || (pPt->empty()))
	{
		initStupidSsObject(sNoeud, pConcern) ;
		return true ;
	}

	// Recherche du noeud au sein du document
	// Looking for the node inside the document
	PatPathoIter iter = pPt->begin() ;
	while ((iter != pPt->end()) && ((*iter)->getNode() != sNoeud))
		iter++ ;

	if (iter == pPt->end())
	{
		initStupidSsObject(sNoeud, pConcern) ;
		return true ;
	}

	NSPatPathoArray SousPt(pDoc->pContexte) ;
	pPt->ExtrairePatPatho(iter, &SousPt) ;

	if (SousPt.empty())
	{
		initStupidSsObject(sNoeud, pConcern) ;
		return true;
	}

	string sLang = pDoc->pContexte->getUtilisateur()->donneLang();

	string  sDateDeb    = "";
	string  sDateFin    = "";
	int     iSeverity   = 0;
	int     iRisk       = 0;

	PatPathoIter ssIter = SousPt.begin() ;
	while (ssIter != SousPt.end())
	{
		bool bIncrementer = true ;
		string sCodeSens = (*ssIter)->getLexiqueSens(pDoc->pContexte) ;

		if ((sCodeSens == "KDAT0") || (sCodeSens == "KOUVR") ||
				(sCodeSens == "KFERM"))
		{
			int iRefCol = (*ssIter)->getColonne() ;

			ssIter++ ;

			if ((ssIter != SousPt.end()) &&
					((*ssIter)->getColonne() > iRefCol))
			{
				gereDate Date(pDoc->pContexte, sLang) ;

				int iLigne = (*ssIter)->getLigne() ;

				string sUnite ;
				string sFormat ;
				string sValeur ;

				while (	(ssIter != SousPt.end()) &&
								((*ssIter)->getLigne() == iLigne))
				{
        	if (pDoc->pContexte->getDico()->CodeCategorie((*ssIter)->getLexique()) == string(1, '�'))
          {
            sFormat = (*ssIter)->getLexiqueSens(pDoc->pContexte) ;
            sValeur = (*ssIter)->getComplement() ;
            sUnite  = (*ssIter)->getUnitSens(pDoc->pContexte) ;
            break ;
          }
					ssIter++ ;
				}
				bIncrementer = false ;

				Date.setDate(&sValeur) ;
				Date.setFormat(&sFormat) ;
				Date.setUnite(&sUnite) ;

        if ((sCodeSens == "KDAT0") || (sCodeSens == "KOUVR"))
					sDateDeb = Date.getDate() ;
				else
					if (sCodeSens == "KFERM")
						sDateFin = Date.getDate() ;
			}
		}
		if ((sCodeSens == "VIGRA") || (sCodeSens == "VIRIS"))
		{
			int iRefCol = (*ssIter)->getColonne() ;

			ssIter++ ;

			if ((ssIter != SousPt.end()) && ((*ssIter)->getColonne() > iRefCol))
			{
				gereNum Num(pDoc->pContexte, sLang) ;

				int iLigne = (*ssIter)->getLigne() ;

				string sTemp ;
				string sUnite ;
				string sFormat ;
				string sValeur ;

				while ((ssIter != SousPt.end()) && ((*ssIter)->getLigne() == iLigne))
				{
          if (pDoc->pContexte->getDico()->CodeCategorie((*ssIter)->getLexique()) == string(1, '�'))
          {
          	sFormat = (*ssIter)->getLexique() ;
            sValeur = (*ssIter)->getComplement() ;
            sUnite  = (*ssIter)->getUnit() ;
            break ;
          }
					ssIter++ ;
				}
				bIncrementer = false ;

				Num.instancier(&sValeur, &sUnite, &sFormat) ;

				if (Num.estExact())
				{
					double dValue = Num.getValeur() ;

					if (sCodeSens == "VIGRA")
						iSeverity = dtoi(dValue) ;
					else
						if (sCodeSens == "VIRIS")
							iRisk = dtoi(dValue) ;
				}
			}
		}
		if ((bIncrementer) && (ssIter != SousPt.end()))
			ssIter++ ;
	}

	// Cr�ation d'un Sous objet
	// Creating a SubObject
	NVLdVTemps tDateTimeDeb;
	NVLdVTemps tDateTimeFin;

	if ((sDateDeb == "") && (sDateFin == ""))
		initStupidSsObject(sNoeud, pConcern);
	else
	{
		NSLdvSousObjet* pSSObj = new NSLdvSousObjet(pDoc->pContexte);

		pSSObj->sReference = sNoeud;
		pSSObj->sConcern   = pConcern->sReference;

		if (sDateDeb != "")
			pSSObj->tDateHeureDebut.initFromDate(sDateDeb);
		if (sDateFin != "")
			pSSObj->tDateHeureFin.initFromDate(sDateFin);

		// S'il manque des informations, on va les chercher dans l'objet
		// If some data is missing, we look for it in the Object
		if (((sDateDeb == "") || (sDateFin == "")) && (!(pDoc->getObjets()->empty())))
		{
			ArrayObjets *pObjs = pDoc->getObjets() ;
			ArrayObjIter ObjIter = pObjs->begin();
			for (; (ObjIter != pObjs->end()) &&
				((*ObjIter)->sReference != sObjReference); ObjIter++);
			if (ObjIter != pObjs->end())
			{
				if (sDateDeb == "")
				{
					pSSObj->tDateHeureDebut = (*ObjIter)->tDateHeureDebut ;
					tDateTimeDeb = (*ObjIter)->tDateHeureDebut;
				}
				if (sDateFin == "")
					pSSObj->tDateHeureFin   = (*ObjIter)->tDateHeureFin ;
			}
		}
		push_back(pSSObj);
	}

	if ((iSeverity == 0) && (iRisk == 0))
		return true;

	// Cr�ation d'un ConcernModifier
	// Creation of a ConcernModifier
	tDateTimeFin.estNoLimit();
	if (sDateDeb != "")
		tDateTimeDeb.initFromDate(sDateDeb);

	NSConcernModifier Modifier(pConcern,
                             tDateTimeDeb,
                             tDateTimeFin,
                             iSeverity,
                             0,
                             iRisk) ;
	Modifier.setNode(sNoeud) ;
	pConcern->aModificateurs.addModifier(&Modifier) ;

  return true ;
}
catch (...)
{
	erreur("Exception ArraySsObjet::initSmartSsObject.", standardError, 0) ;
	return false ;
}
}


void
ArraySsObjet::initStupidSsObject(string sNoeud, NSConcern* pConcern)
{
try
{
	NSLdvSousObjet* pSSObj = new NSLdvSousObjet(pDoc->pContexte);

	pSSObj->sReference = sNoeud;
	pSSObj->sConcern   = pConcern->sReference;

	string  sObjReference = string(pSSObj->sReference, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) ;

	// Si le sous-objet appartient � un objet d�j� connu, il prend ses caract�ristiques
	// If this sub-object belongs to a known object, it takes its values
	ArrayObjets *pObjs = pDoc->getObjets() ;

	if (!pObjs->empty() && (sObjReference != ""))
	{
		for (ArrayObjIter ObjIter = pObjs->begin() ; ObjIter != pObjs->end() ; ObjIter++)
		{
			if ((*ObjIter)->sReference == sObjReference)
			{
				pSSObj->tDateHeureDebut = (*ObjIter)->tDateHeureDebut ;
				pSSObj->tDateHeureFin   = (*ObjIter)->tDateHeureFin ;
			}
		}
	}

  push_back(pSSObj);
}
catch (...)
{
	erreur("Exception ArraySsObjet::initStupidSsObject.", standardError, 0) ;
}
}


//-----------------------------------------------------------------------
//
//						  Classe NSLdvObjet
//
//-----------------------------------------------------------------------

NSLdvObjet::NSLdvObjet(NSContexte* pCtx)
	:	NSRoot(pCtx)
{
	sTitre      = "" ;
	sLexique    = "" ;
	tDateHeureDebut.init() ;
	tDateHeureFin.init() ;

	sConcern    = "" ;

	sReference  = "" ;
	sTypeDoc    = "" ;
}


NSLdvObjet::NSLdvObjet(NSLdvObjet& rv)
	:	NSRoot(rv.pContexte)
{
	sTitre          = rv.sTitre ;
  sLexique        = rv.sLexique ;
	tDateHeureDebut = rv.tDateHeureDebut ;
	tDateHeureFin   = rv.tDateHeureFin ;

	sConcern        = rv.sConcern ;

	sReference      = rv.sReference ;
	sTypeDoc        = rv.sTypeDoc ;
}


NSLdvObjet::~NSLdvObjet()
{
}


NSLdvObjet&
NSLdvObjet::operator=(NSLdvObjet& src)
{
	if (this == &src)
		return *this ;

	sTitre          = src.sTitre ;
	sLexique        = src.sLexique ;
	tDateHeureDebut = src.tDateHeureDebut ;
	tDateHeureFin   = src.tDateHeureFin ;

	sConcern        = src.sConcern ;

	sReference      = src.sReference ;
	sTypeDoc        = src.sTypeDoc ;

	return *this ;
}


//-----------------------------------------------------------------------
//
//				   		 Classe ArraySsObjet
//
//-----------------------------------------------------------------------

ArrayObjets::ArrayObjets(ArrayObjets& rv)
	:	ArrayObj()
{
try
{
	if (!(rv.empty()))
		for (ArrayObjIter i = rv.begin(); i != rv.end(); i++)
			push_back(new NSLdvObjet(*(*i)));
}
catch (...)
{
	erreur("Exception ArrayObjets copy ctor.", standardError, 0) ;
}
}


void
ArrayObjets::vider()
{
	if (empty())
		return;

	for (ArrayObjIter i = begin(); i != end(); )
	{
		delete *i;
		erase(i);
	}
}


ArrayObjets::~ArrayObjets()
{
	vider();
}


ArrayObjets&
ArrayObjets::operator=(ArrayObjets src)
{
try
{
	if (this == &src)
		return *this ;

	vider();

	if (!(src.empty()))
		for (ArrayObjIter i = src.begin(); i != src.end(); i++)
			push_back(new NSLdvObjet(*(*i)));

	return *this;
}
catch (...)
{
	erreur("Exception ArrayObjets operator=.", standardError, 0) ;
	return *this;
}
}


void
ArrayObjets::initialiser()
{
try
{
	// Recup�rer un pointeur sur l'Historique
	// Get a pointer on the History tree

	if ((!pDoc) || (!(pDoc->pContexte)))
		return ;

	NSPatientChoisi* pPat = pDoc->pContexte->getPatient() ;
	if (!pPat)
		return ;

	// Document his
	NSHISTODocument* pHistory = pPat->pDocHis ;
	if (!pHistory)
		return ;

	if (pHistory->VectDocument.empty())
		return ;

	DocumentIter iterDoc = pHistory->VectDocument.begin() ;
	for (; iterDoc != pHistory->VectDocument.end(); iterDoc++)
	{
		bool bAjouter = true ;

		string sRootCode = "" ;

		// La Synth�se et l'Index POMR ne sont pas affich�s
		// Synthesis and POMR index are not displayed
		if (((*iterDoc)->pPatPathoArray) &&
				(!((*iterDoc)->pPatPathoArray->empty())))
		{
			NSPatPathoInfo* pPatho = *((*iterDoc)->pPatPathoArray->begin()) ;
      sRootCode = pPatho->getLexique() ;

      string sRootCodeSens = pPatho->getLexiqueSens(pDoc->pContexte) ;
			if (("ZSYNT" == sRootCodeSens) || ("ZPOMR" == sRootCodeSens))
				bAjouter = false ;
		}

		if (bAjouter)
		{
			NSLdvObjet* pObj = new NSLdvObjet(pDoc->pContexte) ;

			string sReference = (*iterDoc)->getID() ;

			pObj->sTitre    = (*iterDoc)->getDocName() ;
      pObj->sLexique  = sRootCode ;
			pObj->tDateHeureDebut.initFromDate(string((*iterDoc)->dateDoc)) ;
			pObj->tDateHeureFin.initFromDate(string((*iterDoc)->dateDoc)) ;

			pObj->sReference = sReference ;
			pObj->sTypeDoc   = (*iterDoc)->getType() ;

			// Ce document est-il li� � un probl�me de sant� ?
			// Is this document linked to a health problem ?

      VecteurString aVectString ;

			NSLinkManager* pGraphe = pDoc->pContexte->getPatient()->pGraphPerson->pLinkManager ;
      pGraphe->TousLesVraisDocument(sReference, NSRootLink::problemRelatedTo, &aVectString) ;

			if (!(aVectString.empty()))
      	pObj->sConcern = *(*(aVectString.begin())) ;

			push_back(new NSLdvObjet(*pObj)) ;
		}
	}
}
catch (...)
{
	erreur("Exception ArrayObjets::initialiser.", standardError, 0) ;
	return;
}
}

NSLdvObjet*
ArrayObjets::getObjet(string sRef)
{
	if (empty())
		return NULL;

	for (ArrayObjIter i = begin(); i != end(); i++)
		if ((*i)->sReference == sRef)
			return *i;

	return NULL;
}

//-----------------------------------------------------------------------//
//          					   Classe NSLdvDrugTake                            //
//-----------------------------------------------------------------------//

NSLdvDrugTake::NSLdvDrugTake(NSContexte *pCtx)
              :NSRoot(pCtx)
{
	sNbDoses       = string("") ;
	sAdminType     = string("") ;
	sAdminLocation = string("") ;
}

NSLdvDrugTake::NSLdvDrugTake(NSLdvDrugTake& rv)
              :NSRoot(rv.pContexte)
{
	sNbDoses       = rv.sNbDoses ;
  tpsClose       = rv.tpsClose ;
  sAdminType     = rv.sAdminType ;
  sAdminLocation = rv.sAdminLocation ;
  tpsAdminHour   = rv.tpsAdminHour ;
}

NSLdvDrugTake::~NSLdvDrugTake()
{
}

void
NSLdvDrugTake::initFromTree(NSPatPathoArray* pTree, PatPathoIter iterSource)
{
	if (!pTree)
		return ;

	PatPathoIter iter = iterSource ;

	int iColBase = (*iter)->getColonne() ;

	while ((iter != pTree->end()) && ((*iter)->getColonne() >= iColBase))
	{
		if ((*iter)->getColonne() == iColBase)
    {
    	string sSens = (*iterSource)->getLexiqueSens(pContexte) ;

    	if (sSens == "VNBDO")
      {
      	iter++ ;
        if (iter != pTree->end())
        {
					string sTemp ;
					string sUnite ;
					string sFormat ;
					string sValeur ;

          if (pContexte->getDico()->CodeCategorie((*iter)->getLexique()) == string(1, '�'))
          {
          	sFormat = (*iter)->getLexique() ;
            sValeur = (*iter)->getComplement() ;
            sUnite  = (*iter)->getUnit() ;

            std::string sNumSeparator = pContexte->getSuperviseur()->getText("0localInformation", "decimalSeparator") ;

            size_t i = sValeur.find(".") ;
  					if (i == NPOS)
  						sNbDoses = sValeur ;
  					else
  					{
            	string sEntier = string("") ;
              string sDecima = string("") ;

  						if (i > 0)
    						sEntier = string(sValeur, 0, i) ;
              else
              	sEntier = string("0") ;
    					sDecima = string(sValeur, i+1, strlen(sValeur.c_str())-i-1) ;

    					sNbDoses = sEntier + sNumSeparator + sDecima ;
  					}
          }
          iter++ ;
        }
      }
      else if (sSens == "KFERM")
      {
      	iter++ ;
        if (iter != pTree->end())
        {
        	string sDate = (*iter)->getComplement() ;
          tpsClose.initFromDateHeure(sDate) ;
          iter++ ;
        }
      }
      else if (sSens == "0ADMI")
      {
      	iter++ ;
        if (iter != pTree->end())
        {
        	sAdminType = (*iter)->getLexique() ;
          iter++ ;
        }
      }
      else if (sSens == "0VADM")
      {
      	iter++ ;
        if (iter != pTree->end())
        {
        	sAdminLocation = (*iter)->getLexique() ;
          iter++ ;
        }
      }
      else
      {
      	string sSens = (*iter)->getLexiqueSens(pContexte) ;
        if (sSens == string("�H0"))
        {
        	string sHour = (*iter)->getComplement() ;
          string sDH   = string("00000000") + sHour ;
          tpsAdminHour.initFromDateHeure(sDH) ;
      		iter++ ;
        }
        else
        	iter++ ;
      }
    }
    else
    	iter++ ;
  }
}

NSLdvDrugTake&
NSLdvDrugTake::operator=(NSLdvDrugTake& src)
{
  if (this == &src)
		return *this ;

	sNbDoses       = src.sNbDoses ;
  tpsClose       = src.tpsClose ;
  sAdminType     = src.sAdminType ;
  sAdminLocation = src.sAdminLocation ;
  tpsAdminHour   = src.tpsAdminHour ;

	return *this ;
}

//-----------------------------------------------------------------------//
//          					   Classe NSLdvDrugCycle                           //
//-----------------------------------------------------------------------//

NSLdvDrugCycle::NSLdvDrugCycle(NSContexte *pCtx, NSLdvDrugPhase* pParent)
               :NSRoot(pCtx)
{
	sTitre      = string("") ;
	sTitreCourt = string("") ;

  pParentPhase = pParent ;
}

NSLdvDrugCycle::NSLdvDrugCycle(NSLdvDrugCycle& rv)
               :NSRoot(rv.pContexte)
{
	sTitre      = rv.sTitre ;
	sTitreCourt = rv.sTitreCourt ;

  pParentPhase = rv.pParentPhase ;
}

NSLdvDrugCycle::~NSLdvDrugCycle()
{
}

void
NSLdvDrugCycle::setTitleFromTree(NSPatPathoArray* pTree, PatPathoIter iterSource, bool bLong, bool bShort)
{
	if (!pTree)
		return ;

	string sSens = (*iterSource)->getLexiqueSens(pContexte) ;
  if (sSens != "KCYTR")
  	return ;

	PatPathoIter iter = iterSource ;

	int iColBase = (*iter)->getColonne() ;
  iter++ ;

	while ((iter != pTree->end()) && ((*iter)->getColonne() > iColBase))
	{
		if ((*iter)->getColonne() == iColBase+1)
    {
    	sSens = (*iter)->getLexiqueSens(pContexte) ;

    	if (sSens == "KRYTH")
      {
      	setTitleForCircadian(pTree, iter, bLong, bShort) ;
        return ;
      }
    	else if (sSens == "KRYTP")
    	{
      	setTitleForNonCircadian(pTree, iter, bLong, bShort) ;
        return ;
    	}
      else
      	iter++ ;
    }
    else
    	iter++ ;
  }
}

/*
void
NSLdvDrugCycle::setTitleForCircadian(NSPatPathoArray* pTree, PatPathoIter iterSource, bool bLong, bool bShort)
{
	if (!pTree)
		return ;

	string sSens = (*iterSource)->getLexiqueSens(pContexte) ;
  if (sSens != "KRYTH")
  	return ;

	PatPathoIter iter = iterSource ;

	int iColBase = (*iter)->getColonne() ;
  iter++ ;

	while ((iter != pTree->end()) && ((*iter)->getColonne() > iColBase))
	{
		if ((*iter)->getColonne() == iColBase+1)
    {
    	sSens = (*iter)->getLexiqueSens(pDoc->pContexte) ;

      if (sSens == std::string("KREVE"))
      {
      	iter++ ;
    	}
      else
      	iter++ ;
    }
    else
    	iter++ ;
  }
}
*/

void
NSLdvDrugCycle::setTitleForCircadian(NSPatPathoArray* pTree, PatPathoIter iterSource, bool bLong, bool bShort)
{
	if ((NULL == pTree) || (NULL == iterSource) || (NULL == *iterSource) || (pTree->end() == iterSource))
		return ;

	string sSens = (*iterSource)->getLexiqueSens(pContexte) ;
  if (sSens != "KRYTH")
  	return ;

	PatPathoIter iter = iterSource ;

	int iColBase = (*iter)->getColonne() ;
  iter++ ;

  string sCircadian[7] ;
  for (int i = 0 ; i < 7 ; i++)
  	sCircadian[i] = string("0") ;

  string sLang = pContexte->getUtilisateur()->donneLang() ;

	while ((pTree->end() != iter) && ((*iter)->getColonne() > iColBase))
	{
		if ((*iter)->getColonne() == iColBase+1)
    {
    	sSens = (*iter)->getLexiqueSens(pContexte) ;

      int iPosDose = -1 ;

      if      (sSens == std::string("KREVE"))
      	iPosDose = 0 ;
      else if (sSens == std::string("KMATI"))
      	iPosDose = 1 ;
    	else if (sSens == std::string("KMIDI"))
      	iPosDose = 2 ;
      else if (sSens == std::string("KGOUT"))
      	iPosDose = 3 ;
    	else if (sSens == std::string("KSOIR"))
      	iPosDose = 4 ;
    	else if (sSens == std::string("KCOUC"))
      	iPosDose = 5 ;
    	else if (sSens == std::string("KNOCT"))
      	iPosDose = 6 ;
      else if (sSens == std::string("VNBDO"))
      {
      	iter++ ;
        string sCompl = (*iter)->getComplement() ;

        if (bShort)
        {
        	string sShortCircadianCode = string("KRYTH3") ;
        	string sShortCircadianLib ;
  				pContexte->getDico()->donneLibelle(sLang, &sShortCircadianCode, &sShortCircadianLib) ;
          sTitreCourt += string(" ") + sCompl + sShortCircadianLib ;
        }
				if (bLong)
        {
        	string sLongCircadianCode = string("KRYTH2") ;
        	string sLongCircadianLib ;
  				pContexte->getDico()->donneLibelle(sLang, &sLongCircadianCode, &sLongCircadianLib) ;
          sTitre += string(" : ") + sCompl + string(" ") + sLongCircadianLib ;
        }
        return ;
      }
      else if (sSens == std::string("KHHMM"))
      {
      	iter++ ;
      	if (iter != pTree->end())
        {
        	NSLdvDrugTake drugTake(pContexte) ;
          drugTake.initFromTree(pTree, iter) ;

        	if (drugTake.sNbDoses != string(""))
          	sTitreCourt += string(" ") + drugTake.sNbDoses +
                     string("-") + drugTake.tpsAdminHour.donneFormattedHeure(pContexte, sLang) ;
        }
      }

    	if (iPosDose >= 0)
      {
      	iter++ ;
        NSLdvDrugTake drugTake(pContexte) ;
        drugTake.initFromTree(pTree, iter) ;
        if (drugTake.sNbDoses != string(""))
        	sCircadian[iPosDose] = drugTake.sNbDoses ;
    	}
      else
      	iter++ ;
    }
    else
    	iter++ ;
  }

  // Building the text
  //

  // Day periods ?
  int iFirst ;
  for (iFirst = 0 ; (iFirst < 7) && (sCircadian[iFirst] == string("0")) ; iFirst++) ;
  if (iFirst < 7)
  {
  	if (bShort)
    {
    	string sDrugMMSSepar = string(1, drugMMSSepar) ;

  		// is it more complex than MMSC
    	if ((sCircadian[0] != string("0")) || (sCircadian[3] != string("0")) || (sCircadian[6] != string("0")))
      {
      	string sDrugMMSUpSepar    = string(1, drugMMSUpSepar) ;
        string sDrugMMSBNoonSepar = string(1, drugMMSBNoonSepar) ;
        string sDrugMMSANoonSepar = string(1, drugMMSANoonSepar) ;
        string sDrugMMSDownSepar  = string(1, drugMMSDownSepar) ;

    		sTitreCourt += sDrugMMSUpSepar    + sCircadian[0] + sDrugMMSSepar      + sCircadian[1] +
      	               sDrugMMSBNoonSepar + sCircadian[2] + sDrugMMSANoonSepar + sCircadian[3] +
                       sDrugMMSSepar      + sCircadian[4] + sDrugMMSSepar      + sCircadian[5] +
                       sDrugMMSDownSepar  + sCircadian[6] ;
      }
      // MMSC
      else if (sCircadian[5] != string("0"))
      	sTitreCourt += sCircadian[1] + sDrugMMSSepar + sCircadian[2] +
                       sDrugMMSSepar + sCircadian[4] + sDrugMMSSepar + sCircadian[5] ;
      else
      	sTitreCourt += sCircadian[1] + sDrugMMSSepar + sCircadian[2] +
                       sDrugMMSSepar + sCircadian[4] ;
    }
  }
}

void
NSLdvDrugCycle::setTitleForNonCircadian(NSPatPathoArray* pTree, PatPathoIter iter, bool bLong, bool bShort)
{
}

NSLdvDrugCycle&
NSLdvDrugCycle::operator=(NSLdvDrugCycle& src)
{
	if (this == &src)
		return *this ;

	sTitre      = src.sTitre ;
	sTitreCourt = src.sTitreCourt ;

  pParentPhase = src.pParentPhase ;

  return *this ;
}

//-----------------------------------------------------------------------//
//          					   Classe NSLdvDrugPhase                           //
//-----------------------------------------------------------------------//

NSLdvDrugPhase::NSLdvDrugPhase(NSContexte *pCtx, NSLdvDrug* pParent)
               :NSRoot(pCtx)
{
	sReference  = string("") ;

	sTitre      = string("") ;
  sTitreCourt = string("") ;

  sIntakeUnitLib      = string("") ;
	sIntakeUnitShortLib = string("") ;

  pParentDrug = pParent ;

	initIntakeUnits() ;
}

NSLdvDrugPhase::NSLdvDrugPhase(NSLdvDrugPhase& rv)
               :NSRoot(rv.pContexte)
{
	sReference          = rv.sReference ;

	sTitre              = rv.sTitre ;
  sTitreCourt         = rv.sTitreCourt ;

  sIntakeUnitLib      = rv.sIntakeUnitLib ;
  sIntakeUnitShortLib = rv.sIntakeUnitShortLib ;

  tDateOuverture      = rv.tDateOuverture ;
	tDateFermeture      = rv.tDateFermeture ;

  aCycles             = rv.aCycles ;
  aPrescriptionRects  = rv.aPrescriptionRects ;

  pParentDrug         = rv.pParentDrug ;
}

NSLdvDrugPhase::~NSLdvDrugPhase()
{
}

void
NSLdvDrugPhase::setTitlesFromCycles(bool bLong, bool bShort)
{
	sTitre      = string("") ;
	sTitreCourt = string("") ;

  if (aCycles.empty())
		return ;

	NSLdvDrugCycleIter itCycle = aCycles.begin() ;
  for ( ; itCycle != aCycles.end() ; itCycle++)
  {
  	if (itCycle != aCycles.begin())
    {
    	sTitre      += string(" - ") ;
			sTitreCourt += drugPhaseSepar ;
    }
    sTitre      += (*itCycle)->sTitre ;
  	sTitreCourt += (*itCycle)->sTitreCourt ;
  }

  compressShortTitle() ;
}

void
NSLdvDrugPhase::compressShortTitle()
{
	return ;

/*
	// If it is a multi-cycle phase, we take out the 0s
  //
	size_t iPipePos = sTitreCourt.find("|") ;
  if (iPipePos == string::npos)
		return ;

	string sDecimalSeparator = pContexte->getSuperviseur()->getText("0localInformation", "decimalSeparator") ;
  if (sDecimalSeparator == string(""))
  	sDecimalSeparator = string(",") ;

  string sDigitGroupSeparator = pContexte->getSuperviseur()->getText("0localInformation", "digitGroupSeparator") ;

	bool bPreviousCharIsNonZeroUnit = false ;
	for (size_t iCurPos = 0 ; iCurPos < strlen(sTitreCourt.c_str()) ; )
	{
  	if (sTitreCourt[iCurPos] == '0')
    {
    	if (!bPreviousCharIsNonZeroUnit)
      {
      	bool bZeroKilled = true ;

      	if (iCurPos == strlen(sTitreCourt.c_str()) - 1)
        	sTitreCourt = string(sTitreCourt, 0, strlen(sTitreCourt.c_str()) - 1) ;
        else if (sTitreCourt[iCurPos+1] != sDecimalSeparator[0])
        {
      		if (iCurPos == 0)
      			sTitreCourt = string(sTitreCourt, 1, strlen(sTitreCourt.c_str()) - 1) ;
        	else
        		sTitreCourt = string(sTitreCourt, 0, iCurPos) + string(sTitreCourt, iCurPos + 1, strlen(sTitreCourt.c_str()) - iCurPos - 1) ;
        }
        else
        {
        	bZeroKilled = false ;
        	iCurPos++ ;
        }

        // If we killed a '0' we may have to kill the separator next to it
        //
				if (bZeroKilled && (iCurPos < strlen(sTitreCourt.c_str())))
        {
        	if (string(sTitreCourt, iCurPos, strlen(drugPhaseSepar.c_str())) == drugPhaseSepar)
          	bPreviousCharIsNonZeroUnit = false ;
          else if (isdigit(sTitreCourt[iCurPos]))
      			bPreviousCharIsNonZeroUnit = true ;
          else
          {
          	if (iCurPos == strlen(sTitreCourt.c_str()) - 1)
        			sTitreCourt = string(sTitreCourt, 0, strlen(sTitreCourt.c_str()) - 1) ;
      			if (iCurPos == 0)
      				sTitreCourt = string(sTitreCourt, 1, strlen(sTitreCourt.c_str()) - 1) ;
        		else
        			sTitreCourt = string(sTitreCourt, 0, iCurPos) + string(sTitreCourt, iCurPos + 1, strlen(sTitreCourt.c_str()) - iCurPos - 1) ;
          }
        }
      }
      else
      	iCurPos++ ;
    }
    else
    {
    	if ((sTitreCourt[iCurPos] == sDecimalSeparator[0]) ||
          (bPreviousCharIsNonZeroUnit && (sDigitGroupSeparator != string("")) && (sTitreCourt[iCurPos] == sDigitGroupSeparator[0])) ||
          isdigit(sTitreCourt[iCurPos]))
      	bPreviousCharIsNonZeroUnit = true ;
      else
      	bPreviousCharIsNonZeroUnit = false ;

    	iCurPos++ ;
    }
  }
*/
}

string
NSLdvDrugPhase::getShortestLibForIntakeUnit()
{
	if (!pParentDrug)
		return string("") ;

	string sLexiCode = pParentDrug->sIntakeUnit ;
  string sLangue   = pParentDrug->pDoc->sLangue ;
  string sReturn   = string("") ;

  pContexte->getDico()->donneShortLibelle(sLangue, &sLexiCode, &sReturn) ;

  return sReturn ;
}

void
NSLdvDrugPhase::initIntakeUnits()
{
	if (!pParentDrug || (pParentDrug->sIntakeUnit == string("")))
		return ;

	sIntakeUnitShortLib = getShortestLibForIntakeUnit() ;
	pContexte->getDico()->donneLibelle(pParentDrug->pDoc->sLangue, &(pParentDrug->sIntakeUnit), &sIntakeUnitLib) ;
}

NSLdvDrugPhase&
NSLdvDrugPhase::operator=(NSLdvDrugPhase& src)
{
	if (&src == this)
		return *this ;

	sReference          = src.sReference ;

	sTitre              = src.sTitre ;
  sTitreCourt         = src.sTitreCourt ;

  sIntakeUnitLib      = src.sIntakeUnitLib ;
  sIntakeUnitShortLib = src.sIntakeUnitShortLib ;

  tDateOuverture      = src.tDateOuverture ;
	tDateFermeture      = src.tDateFermeture ;

  aCycles             = src.aCycles ;
  aPrescriptionRects  = src.aPrescriptionRects ;

  pParentDrug         = src.pParentDrug ;

	return *this ;
}

//-----------------------------------------------------------------------//
//          						    Classe NSLdvDrug                             //
//-----------------------------------------------------------------------//

NSLdvDrug::NSLdvDrug(NSContexte* pCtx, NSLdvDocument* pDocum)
          :NSRoot(pCtx)
{
	pDoc = pDocum ;

	tDateOuverture.init() ;
	tDateFermeture.init() ;

  sTitre      = "" ;
  sTitreCourt = "" ;
	sReference  = "" ;
	sLexique    = "" ;
  sIntakeUnit = "" ;
  _sFreeText  = "" ;
  _bALD       = false ;

  pWorstJalons = new GoalInfoArray() ;
}

NSLdvDrug::NSLdvDrug(NSLdvDrug& rv)
          :NSRoot(rv.pContexte)
{
	pDoc           = rv.pDoc ;

	sReference     = rv.sReference ;
	sLexique       = rv.sLexique ;

	sTitre         = rv.sTitre ;
  sTitreCourt    = rv.sTitreCourt ;
	tDateOuverture = rv.tDateOuverture ;
	tDateFermeture = rv.tDateFermeture ;

  sIntakeUnit    = rv.sIntakeUnit ;
  aPhases        = rv.aPhases ;

  _sFreeText     = rv._sFreeText ;
  _bALD          = rv._bALD ;

	aConcerns      = rv.aConcerns ;

  pWorstJalons   = new GoalInfoArray(*(rv.pWorstJalons)) ;
}

NSLdvDrug::~NSLdvDrug()
{
	delete pWorstJalons ;
}

void
NSLdvDrug::goalAdded(NSLdvGoal *pGoal)
{
	if (NULL == pGoal)
		return ;

	pDoc->goalAdded(pGoal, pWorstJalons) ;
}

void
NSLdvDrug::goalModified(NSLdvGoal *pGoal)
{
	//
	// On reconstruit enti�rement worstJalons
	// worstJalons is completely rebuilt
	//
	pWorstJalons->vider() ;

	ArrayGoals* pLdvGoals = pDoc->getGoals() ;
	if (pLdvGoals->empty())
		return ;

	// On passe en revue tous les objectifs
	//
	for (ArrayGoalIter goalIt = pLdvGoals->begin();
                                        goalIt != pLdvGoals->end(); goalIt++)
		if ((*goalIt)->sConcern == sReference)
    	goalAdded(*goalIt) ;
}

NSLdvDrug&
NSLdvDrug::operator=(NSLdvDrug& src)
{
	if (this == &src)
		return *this ;

	pDoc            = src.pDoc ;

	sTitre          = src.sTitre ;
  sTitreCourt     = src.sTitreCourt ;
	tDateOuverture  = src.tDateOuverture ;
	tDateFermeture  = src.tDateFermeture ;

	sReference      = src.sReference ;
	sLexique        = src.sLexique ;

  sIntakeUnit     = src.sIntakeUnit ;
  aPhases         = src.aPhases ;

  _sFreeText      = src._sFreeText ;
  _bALD           = src._bALD ;

	aConcerns       = src.aConcerns ;

  pWorstJalons->vider() ;
  if (src.pWorstJalons && !src.pWorstJalons->empty())
  	*pWorstJalons = *(src.pWorstJalons) ;

	return *this ;
}

bool
NSLdvDrug::bIsLinkedConcern(string sConcern)
{
	if (aConcerns.empty())
		return false ;

	for (EquiItemIter i = aConcerns.begin() ; i != aConcerns.end() ; i++)
		if (*(*i) == sConcern)
			return true ;

	return false ;
}

void
NSLdvDrug::sendFocusEvent()
{
	sendEvent(FOCUS) ;
}

void
NSLdvDrug::sendActivationEvent()
{
	sendEvent(ACTIVATE) ;
}

void
NSLdvDrug::sendEvent(EventType iEvent)
{
	NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex ;
  if (!pPtIndex)
		return ;

	PatPathoIter pptIter = pPtIndex->ChercherNoeud(sReference) ;
  if ((pptIter == NULL) || (pptIter == pPtIndex->end()))
		return ;

	NautilusEvent nsEvent(pPtIndex, pptIter, iEvent, false) ;
  pContexte->getSuperviseur()->getBBinterface()->addNautilusEvent(&nsEvent) ;
}

void
NSLdvDrug::initPhases(NSPatPathoArray* pTree, PatPathoIter iterSource)
{
	if (!pTree)
		return ;

	string sSens = (*iterSource)->getLexiqueSens(pDoc->pContexte) ;
  if (sSens != "KPHAT")
  	return ;

	NSLdvDrugPhase* pPhase = new NSLdvDrugPhase(pContexte, this) ;

  pPhase->setNoeud((*iterSource)->getNode()) ;

  bool bOpeningDateIsSpecified = false ;
  bool bClosingDateIsSpecified = false ;
  bool bDurationHasBeenSet     = false ;

	// Set default opening date : drug opening date if no previous phase exists
  //                            this phase ending date elsewhere
	//
	NVLdVTemps tPeriodOpen ;
  if (aPhases.empty())
  	tPeriodOpen = tDateOuverture ;
  else
  	tPeriodOpen = aPhases.back()->tDateFermeture ;

  NVLdVTemps tPeriodStart = tPeriodOpen ;
  NVLdVTemps tPeriodClose ;

	PatPathoIter iter = iterSource ;

	int iColBase = (*iter)->getColonne() ;
  iter++ ;

	while ((iter != pTree->end()) && ((*iter)->getColonne() > iColBase))
	{
		if ((*iter)->getColonne() == iColBase+1)
    {
    	sSens = (*iter)->getLexiqueSens(pDoc->pContexte) ;

      // Dates
      //
      if ((sSens == "KOUVR") || (sSens == "KFERM"))
      {
      	iter++ ;
        int iLigneBase = (*iter)->getLigne() ;

        string sUnite  = "" ;
        string sFormat = "" ;
        string sValeur = "" ;
        while (	(iter != pTree->end()) &&
                      ((*iter)->getLigne() == iLigneBase))
        {
        	if (pContexte->getDico()->CodeCategorie((*iter)->getLexique()) == string(1, '�'))
          {
          	sFormat = (*iter)->getLexiqueSens(pDoc->pContexte) ;
            sValeur = (*iter)->getComplement() ;
            sUnite  = (*iter)->getUnitSens(pDoc->pContexte) ;
            break ;
          }
          iter++ ;
        }

        // sFormat est du type �D0;03
        if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) && (sValeur != ""))
        {
        	if ((sUnite == "2DA01") || (sUnite == "2DA02"))
          {
          	if (sSens == "KOUVR")
            {
            	tPeriodOpen.initFromDate(sValeur) ;
              bOpeningDateIsSpecified = true ;
            }
            else
            	if (sSens == "KFERM")
              {
            		tPeriodClose.initFromDate(sValeur) ;
                bClosingDateIsSpecified = true ;
              }
          }
        }
      }
      // Periods
      //
    	else if ((sSens == "VDURE") || (sSens == "VRENO"))
      {
      	iter++ ;

        bDurationHasBeenSet = true ;

        string sUnitDureeCycle = (*iter)->getUnit() ;
				int    iDureeCycle     = atoi(((*iter)->getComplement()).c_str()) ;

        iter++ ;

        NVLdVTemps tPeriodEnd = tPeriodStart ;
        tPeriodEnd.ajouteTemps(iDureeCycle, sUnitDureeCycle, pContexte) ;

        if (bClosingDateIsSpecified && (tPeriodEnd > tPeriodClose))
        	tPeriodEnd = tPeriodClose ;
        if (bOpeningDateIsSpecified && (tPeriodStart < tPeriodOpen))
        	tPeriodStart = tPeriodOpen ;

        if (tPeriodStart > tPeriodClose)
        {
        	NVLdVRect* pPhaseRect = new NVLdVRect(NULL) ;
        	pPhaseRect->setLeft(tPeriodStart) ;
        	pPhaseRect->setRight(tPeriodEnd) ;
        	pPhase->aPrescriptionRects.push_back(pPhaseRect) ;
        }

        tPeriodStart = tPeriodEnd ;
      }
    	else if (sSens == "KCYTR")
    	{
      	NSLdvDrugCycle* pCycle = new NSLdvDrugCycle(pContexte, pPhase) ;
      	pCycle->setTitleFromTree(pTree, iter, true, true) ;
        pPhase->aCycles.push_back(pCycle) ;
      	iter++ ;
    	}
      else
      	iter++ ;
    }
    else
    	iter++ ;
  }

	pPhase->tDateOuverture = tPeriodOpen ;
	pPhase->tDateFermeture = tPeriodStart ;

  if (true == bClosingDateIsSpecified)
  {
  	pPhase->tDateFermeture = tPeriodClose ;

    NVLdVRect* pPhaseRect = new NVLdVRect(NULL) ;
    pPhaseRect->setLeft(pPhase->tDateOuverture) ;
		pPhaseRect->setRight(pPhase->tDateFermeture) ;
    pPhase->aPrescriptionRects.push_back(pPhaseRect) ;
  }

  pPhase->setTitlesFromCycles(true, true) ;

  aPhases.push_back(pPhase) ;
}

NSLdvDrugPhase*
NSLdvDrug::getCurrentActivePhase()
{
	if (aPhases.empty())
		return NULL ;

	// r�cup�ration de la date du jour
  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

	NSLdvDrugPhaseIter itPhase = aPhases.begin() ;
  for ( ; itPhase != aPhases.end() ; itPhase++)
		if ((tpsNow > (*itPhase)->tDateOuverture) && (tpsNow < (*itPhase)->tDateFermeture))
    	return *itPhase ;

	return NULL ;
}

NSLdvDrugPhase*
NSLdvDrug::getLastActivePhase()
{
	if (aPhases.empty())
		return NULL ;

  // If there is a current phase, then take it
  //
  NSLdvDrugPhase* pLastActivePhase = getCurrentActivePhase() ;
  if (NULL != pLastActivePhase)
    return pLastActivePhase ;

  // If there is no current phase, take the preceding one

	// r�cup�ration de la date du jour
  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

	NSLdvDrugPhaseIter itPhase = aPhases.begin() ;
  for ( ; itPhase != aPhases.end() ; itPhase++)
  {
		if (tpsNow > (*itPhase)->tDateOuverture)
    {
      if (NULL == pLastActivePhase)
        pLastActivePhase = *itPhase ;
      else if (pLastActivePhase->tDateFermeture < (*itPhase)->tDateFermeture)
        pLastActivePhase = *itPhase ;
    }
  }

	return pLastActivePhase ;
}

NSLdvDrugPhase*
NSLdvDrug::getPhaseFromNode(string sNode)
{
	if (aPhases.empty())
		return NULL ;

	NSLdvDrugPhaseIter itPhase = aPhases.begin() ;
  for ( ; itPhase != aPhases.end() ; itPhase++)
		if ((*itPhase)->getNoeud() == sNode)
    	return *itPhase ;

	return NULL ;
}

void
NSLdvDrug::setTitlesFromLexique()
{
	pDoc->pContexte->getDico()->donneLibelle(pDoc->sLangue, &sLexique, &sTitre) ;

  // Cut to the first unit
  //
  NSEpiFlechiesDB flechiesDB(pContexte) ;

  bool bKeepSearching = true ;
  size_t iBlankPos = sTitre.find(" ") ;
  size_t iPrevPos  = 0 ;
  while (bKeepSearching && (iBlankPos != NPOS))
  {
  	string sWord = string(sTitre, iPrevPos, iBlankPos - iPrevPos) ;
  	string sUnitCode = flechiesDB.getCodeLexiq(sWord, '2') ;
    if (sUnitCode != string(""))
    	bKeepSearching = false ;
    else if (iBlankPos < strlen(sTitre.c_str()) - 1)
    {
    	iBlankPos++ ;
      while ((sTitre[iBlankPos] == ' ') && (iBlankPos < strlen(sTitre.c_str()) - 1))
      	iBlankPos++ ;

      iPrevPos = iBlankPos ;
      iBlankPos = sTitre.find(" ", iPrevPos) ;
    }
  }

  if (iBlankPos == NPOS)
  	sTitreCourt = sTitre ;
  else
		sTitreCourt = string(sTitre, 0, iBlankPos) ;

  string(sTitreCourt, stripBoth) ;
}

bool
NSLdvDrug::modifyPhaseDate(string sPhaseNode, string sDateType, NVLdVTemps tNewDate)
{
	NSLdvDrugPhase* pPhase = getPhaseFromNode(sPhaseNode) ;
	if (NULL == pPhase)
		return NULL ;

	return modifyPhaseDate(pPhase, sDateType, tNewDate) ;
}

bool
NSLdvDrug::modifyPhaseDate(NSLdvDrugPhase* pPhase, string sDateType, NVLdVTemps tNewDate)
{
	if (NULL == pPhase)
		return false ;

	return pPhase->modifyDate(sDateType, tNewDate) ;
}

NVLdVTemps
NSLdvDrug::getPhaseDate(string sPhaseNode, string sDateType)
{
	NSLdvDrugPhase* pPhase = getPhaseFromNode(sPhaseNode) ;
	if (NULL == pPhase)
  {
  	NVLdVTemps tUndefined ;
		tUndefined.init() ;
		return tUndefined ;
	}

	return getPhaseDate(pPhase, sDateType) ;
}

NVLdVTemps
NSLdvDrug::getPhaseDate(NSLdvDrugPhase* pPhase, string sDateType)
{
	if (NULL == pPhase)
	{
		NVLdVTemps tUndefined ;
		tUndefined.init() ;
		return tUndefined ;
	}

	string sSens ;
	pContexte->getDico()->donneCodeSens(&sDateType, &sSens) ;

  if      (string("KOUVR") == sSens)
		return pPhase->tDateOuverture ;
	else if (string("KFERM") == sSens)
		return pPhase->tDateFermeture ;

	NVLdVTemps tUndefined ;
  tUndefined.init() ;
  return tUndefined ;
}

bool
NSLdvDrug::addNewPhase(NSPatPathoArray* pPhaseTree)
{
	return false ;
}

bool
NSLdvDrug::addNewActivePhase(NSPatPathoArray* pPhaseTree)
{
	return false ;
}

bool
NSLdvDrug::createXmlTree(Ctree* pTreeObject, string sTargetLocalisation)
{
	if (NULL == pTreeObject)
		return false ;

	// Setting the "localisation" attribute
  //
  if (string("") == sTargetLocalisation)
		sTargetLocalisation = string("ZPOMR/N0000") ;

  string sLoc = pTreeObject->getStringAttribute(ATTRIBUT_TREE_LOC) ;
  if (string("") != sLoc)
  {
  	if (sTargetLocalisation != sLoc)
    	pTreeObject->setStringAttribute(ATTRIBUT_TREE_LOC, sTargetLocalisation) ;
  }
  else
  	pTreeObject->addAttribute(ATTRIBUT_TREE_LOC, sTargetLocalisation) ;

	//
  // Adding Root nodes and asking them to create their sons recursively
  //

	// Looking for this drug in the health index document
  //
	NSPatPathoArray* pPatho ;
	PatPathoIter iter = pDoc->donneDrug(this, &pPatho) ;
  // not found !
	if ((NULL == iter) || (pPatho->end() == iter))
  	return false ;

	NSPatPathoArray drugPatho(pContexte) ;

  NSPatPathoInfo racine = *(*iter) ;
  racine.setLigne(0) ;
  racine.setColonne(0) ;
  drugPatho.push_back(new NSPatPathoInfo(racine)) ;

	NSPatPathoArray ssPatho(pContexte) ;
  pPatho->ExtrairePatPatho(iter, &ssPatho) ;
  drugPatho.InserePatPathoFille(drugPatho.begin(), &ssPatho) ;

  // First step: remove referential Ids
  //
  PatPathoIter RefIdIter ;
  bool bIsID = drugPatho.CheminDansPatpatho(string("�RE"), string(1, cheminSeparationMARK), &RefIdIter) ;
  while (true == bIsID)
  {
    drugPatho.SupprimerItem(RefIdIter) ;
    bIsID = drugPatho.CheminDansPatpatho(string("�RE"), string(1, cheminSeparationMARK), &RefIdIter) ;
  }

	int iCol = 0 ;

	// Find opening
  //
  PatPathoIter iter2 = drugPatho.begin() ;
  iter2++ ;
  PatPathoIter iterClose = 0 ;

  int iTotalDurationValueYears  = 0 ;
  int iTotalDurationValueMonths = 0 ;
  int iTotalDurationValueDays   = 0 ;

  while (drugPatho.end() != iter2)
  {
    if (iCol + 1 == (*iter2)->getColonne())
    {
    	string sSens = (*iter2)->getLexiqueSens(pContexte) ;

      // Opening date : switch to "now"
      //
      if      (string("KOUVR") == sSens)
      {
      	iter2++ ;
        if (drugPatho.end() != iter2)
        {
        	sSens = (*iter2)->getLexiqueSens(pContexte) ;
          if ((string("�D0") == sSens) || (string("�T0") == sSens))
          	(*iter2)->setComplement("$KAUJO+000000") ;
        }
      }
      else if (string("KFERM") == sSens)
      {
      	iter2++ ;
        if (drugPatho.end() != iter2)
        {
        	sSens = (*iter2)->getLexiqueSens(pContexte) ;
          if ((string("�D0") == sSens) || (string("�T0") == sSens))
          	iterClose = iter2 ;
        }
      }
      else if (string("KPHAT") == sSens)
      {
      	int iColPhase = (*iter2)->getColonne() ;
      	iter2++ ;

        PatPathoIter iterPhaseClose = 0 ;

        int iPhaseDurationValueYears  = 0 ;
				int iPhaseDurationValueMonths = 0 ;
				int iPhaseDurationValueDays   = 0 ;

        while ((drugPatho.end() != iter2) && ((*iter2)->getColonne() > iColPhase))
        {
        	sSens = (*iter2)->getLexiqueSens(pContexte) ;

          // Opening date : switch to "now"
      		//
      		if      (string("KOUVR") == sSens)
      		{
      			iter2++ ;
        		if (drugPatho.end() != iter2)
        		{
        			sSens = (*iter2)->getLexiqueSens(pContexte) ;
          		if ((string("�D0") == sSens) || (string("�T0") == sSens))
              {
              	string sDeltaTps = donne_deltaTemps(iTotalDurationValueYears, iTotalDurationValueMonths, iTotalDurationValueDays) ;
          			(*iter2)->setComplement(string("$KAUJO+") + sDeltaTps) ;
              }
        		}
      		}
      		else if (string("KFERM") == sSens)
      		{
      			iter2++ ;
        		if (drugPatho.end() != iter2)
        		{
        			sSens = (*iter2)->getLexiqueSens(pContexte) ;
          		if ((string("�D0") == sSens) || (string("�T0") == sSens))
          			iterPhaseClose = iter2 ;
        		}
      		}
          else if (string("VDURE") == sSens)
      		{
      			iter2++ ;
        		if (drugPatho.end() != iter2)
        		{
        			sSens = (*iter2)->getLexiqueSens(pContexte) ;
          		if (string("�N0") == sSens)
              {
                string sValue = (*iter2)->getComplement() ;
                int    iPhaseDurationValue = atoi(sValue.c_str()) ;
								string sPhaseDurationUnit  = (*iter2)->getUnitSens(pContexte) ;

                // Year
            		if      (string("2DAT3") == sPhaseDurationUnit)
                	iPhaseDurationValueYears  = iPhaseDurationValue ;
            		// Month
            		else if (string("2DAT2") == sPhaseDurationUnit)
                	iPhaseDurationValueMonths = iPhaseDurationValue ;
                // Week
            		else if (string("2DAT1") == sPhaseDurationUnit)
                	iPhaseDurationValueDays   = 7 * iPhaseDurationValue ;
            		// Day
            		else if (string("2DAT0") == sPhaseDurationUnit)
                	iPhaseDurationValueDays   = iPhaseDurationValue ;
              }
        		}
      		}
          iter2++ ;
        }
        iTotalDurationValueYears  = iPhaseDurationValueYears ;
				iTotalDurationValueMonths = iPhaseDurationValueMonths ;
				iTotalDurationValueDays   = iPhaseDurationValueDays ;

        if (NULL != iterPhaseClose)
        {
        	string sDeltaTps = donne_deltaTemps(iTotalDurationValueYears, iTotalDurationValueMonths, iTotalDurationValueDays) ;
          (*iterPhaseClose)->setComplement(string("$KAUJO+") + sDeltaTps) ;
        }
      }
    }
    if (drugPatho.end() != iter2)
  		iter2++ ;
  }
  if (NULL != iterClose)
  {
  	string sDeltaTps = donne_deltaTemps(iTotalDurationValueYears, iTotalDurationValueMonths, iTotalDurationValueDays) ;
    (*iterClose)->setComplement(string("$KAUJO+") + sDeltaTps) ;
  }

	*(pTreeObject->pPatPathoArray) = drugPatho ;

	return pTreeObject->initFromPatPatho() ;
}

//-----------------------------------------------------------------------//
//				   		 Classe ArrayLdvDrugs                            //
//-----------------------------------------------------------------------//

ArrayLdvDrugs::ArrayLdvDrugs(ArrayLdvDrugs& rv)
              :ArrayDrugs()
{
try
{
	pDoc = rv.pDoc ;

	if (!(rv.empty()))
		for (drugsIter i = rv.begin(); i != rv.end(); i++)
			push_back(new NSLdvDrug(*(*i))) ;
}
catch (...)
{
	erreur("Exception ArrayLdvDrugs copy ctor.", standardError, 0) ;
}
}


void
ArrayLdvDrugs::vider()
{
	if (empty())
		return ;

	for (drugsIter i = begin(); i != end(); )
	{
		delete *i ;
		erase(i) ;
	}
}

ArrayLdvDrugs::~ArrayLdvDrugs()
{
	vider() ;
}

void
ArrayLdvDrugs::initialiser()
{
	if ((!pDoc) || (!(pDoc->pPathoPOMRIndex)) || (pDoc->pPathoPOMRIndex->empty()))
		return;

	NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex;

	// On cherche le chapitre "traitement"
	PatPathoIter iter = pPtIndex->ChercherItem("N00001");

	if ((iter != NULL) && (iter != pPtIndex->end()))
	{
		int iColBase = (*iter)->getColonne();
		iter++;
		loadDrugs(pPtIndex, iter, iColBase) ;
	}
}

void
ArrayLdvDrugs::reinit()
{
	if ((!pDoc) || (!(pDoc->pPathoPOMRIndex)) || (pDoc->pPathoPOMRIndex->empty()))
		return ;

	NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex ;

	// On cherche le chapitre "traitement"
	PatPathoIter iter = pPtIndex->ChercherItem("N00001") ;

	if ((iter != NULL) && (iter != pPtIndex->end()))
	{
		int iColBase = (*iter)->getColonne() ;
		iter++ ;
		reloadDrugs(pPtIndex, iter, iColBase) ;
	}
}

void
ArrayLdvDrugs::reloadDrugs(NSPatPathoArray* pPtIndex, PatPathoIter iter, int iColBase, bool bJustOne)
{
try
{
	if ((NULL == pPtIndex) || (pPtIndex->empty()))
  	return ;

	// NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex;

	NSLdvDrug* pDrug = 0 ;

	bool bTourner = true ;

	while ((bTourner) && (pPtIndex->end() != iter) &&
         ((*iter)->getColonne() > iColBase))
	{
		// Probl�me
		if ((*iter)->getColonne() == iColBase+1)
		{
			if (pDrug)
			{
				bool    b2Add = true ;
        drugsIter drIter ;

				if (!empty())
				{
					for (drIter = begin() ; drIter != end() ; drIter++)
          {
						if ((*drIter)->sReference == pDrug->sReference)
            {
							b2Add = false ;
              break ;
            }
          }
				}

				if (b2Add)
				{
					NSLdvDrug* pDg = new NSLdvDrug(*pDrug) ;
					push_back(pDg) ;
				}
				else // on remet � jour le medicament
				{
        	*(*drIter) = *pDrug ;
        }

        // Mise � jour des vues - Refresh the views
        /*
        TView* pView = pDoc->GetViewList();
        do
        {
            NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView);
            //if (pLdvView)
            //	pLdvView->addProb(pPb) ;

            pView = pDoc->NextView(pView);
        }
        while (pView);
        */

				delete pDrug ;
				pDrug = 0 ;
			}

      string sCodeLex = (*iter)->getLexique() ;
      string sCodeSensDrug ;
    	pDoc->pContexte->getDico()->donneCodeSens(&sCodeLex, &sCodeSensDrug) ;

      if (bJustOne)
      	bTourner = false ;

      //
      // M�dicament cach� -- Hidden drug
      //
      if ("90000" == sCodeSensDrug)
      {
      	iter++ ;
      	while ( (iter != pPtIndex->end()) &&
                ((*iter)->getColonne() > iColBase + 1))
        	iter++ ;
      }
      //
      // M�dicament visible -- Visible drug
      //
      else
      {
        pDrug = new NSLdvDrug(pDoc->pContexte, pDoc) ;

        // Libell�
        pDrug->setLexique(sCodeLex) ;

        if (sCodeLex != string("�?????"))
          pDrug->setTitlesFromLexique() ;
        // Texte libre - Free text
        else
        	pDrug->sTitre = (*iter)->getTexteLibre() ;

        // Noeud
        pDrug->setNoeud((*iter)->getNode()) ;

        iter++ ;

        // Param�tres du probl�me
        while ( (iter != pPtIndex->end()) &&
                ((*iter)->getColonne() > iColBase + 1))
        {
          string sSens = (*iter)->getLexiqueSens(pDoc->pContexte) ;

          if ((*iter)->getColonne() == iColBase+2)
          {
            // Dates
            if (("KOUVR" == sSens) || ("KFERM" == sSens))
            {
              iter++ ;
              int iLigneBase = (*iter)->getLigne() ;
              // gereDate* pDate = new gereDate(pContexte);
              string sUnite  = "" ;
              string sFormat = "" ;
              string sValeur = "" ;
              while (	(iter != pPtIndex->end()) &&
                      ((*iter)->getLigne() == iLigneBase))
              {
                if (pDoc->pContexte->getDico()->CodeCategorie((*iter)->getLexique()) == string(1, '�'))
                {
                  sFormat = (*iter)->getLexiqueSens(pDoc->pContexte) ;
                  sValeur = (*iter)->getComplement() ;
                  sUnite  = (*iter)->getUnitSens(pDoc->pContexte) ;
                  break ;
                }
								iter++ ;
              }

              // sFormat est du type �D0;03
              if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) && (sValeur != ""))
              {
                if (("2DA01" == sUnite) || ("2DA02" == sUnite))
                {
                	if      ("KOUVR" == sSens)
                    pDrug->tDateOuverture.initFromDate(sValeur) ;
                  else if ("KFERM" == sSens)
                  	pDrug->tDateFermeture.initFromDate(sValeur) ;
                }
              }
            }
            // Unit� de prise
            //
            else if ("0MEDF" == sSens)
            {
            	iter++ ;
              if ((iter != pPtIndex->end()) && ((*iter)->getColonne() > iColBase + 2))
              	pDrug->sIntakeUnit = (*iter)->getLexique() ;
            }
            // Phases
            //
            else if ("KPHAT" == sSens)
            {
            	pDrug->initPhases(pPtIndex, iter) ;
              iter++ ;
              while ((iter != pPtIndex->end()) &&
                     ((*iter)->getColonne() > iColBase + 2))
              	iter++ ;
            }
            else if ("�C;" == sSens)
            {
              pDrug->_sFreeText = (*iter)->getTexteLibre() ;
              iter++ ;
            }
            else if (string("LADMI") == sSens)
            {
              int iColBaseAdmin = (*iter)->getColonne() ;
              iter++ ;
              while ((pPtIndex->end() != iter) && ((*iter)->getColonne() > iColBaseAdmin))
              {
                std::string tempAdm = (*iter)->getLexiqueSens(pDoc->pContexte) ;
                if ("LBARZ" == tempAdm)
                  pDrug->_bALD = true ;
                iter++ ;
              }
            }
            else
              iter++ ;
          }
          else
            iter++ ;
        }
        if (pDrug->tDateFermeture.estVide())
        	pDrug->tDateFermeture.setNoLimit() ;
  		}
		}
		else
			iter++ ;
	}

	if (pDrug)
	{
    bool    b2Add = true ;
    drugsIter drIter ;

    if (!empty())
    {
    	for (drIter = begin() ; drIter != end() ; drIter++)
      {
      	if ((*drIter)->sReference == pDrug->sReference)
        {
        	b2Add = false ;
          break ;
        }
      }
    }

    if (b2Add)
    {
    	NSLdvDrug *pDg = new NSLdvDrug(*pDrug) ;
      push_back(pDg) ;
    }
    else // on remet � jour le medicament
    {
    	*(*drIter) = *pDrug ;
    }

    // Mise � jour des vues - Refresh the views
    /*
    TView* pView = pDoc->GetViewList();
    do
    {
        NSLdvView* pLdvView = TYPESAFE_DOWNCAST(pView, NSLdvView);
        //if (pLdvView)
        //	pLdvView->addProb(pPb) ;

        pView = pDoc->NextView(pView);
    }
    while (pView);
    */

    delete pDrug ;
    pDrug = 0 ;
	}
}
catch (...)
{
	erreur("Exception ArrayLdvDrugs::reloadDrugs.", standardError, 0) ;
  return ;
}
}

bool
ArrayLdvDrugs::deleteDrug(NSLdvDrug* pDrug)
{
	if (empty())
		return false ;

	for (drugsIter i = begin(); i != end(); i++)
	{
		if (*i == pDrug)
		{
			delete pDrug ;
			erase(i) ;
			return true ;
		}
	}

  return false ;
}

bool
ArrayLdvDrugs::deleteDrug(string sRef)
{
	if (empty())
		return false ;

	for (drugsIter i = begin(); i != end(); i++)
	{
		if ((*i)->getNoeud() == sRef)
		{
			delete *i ;
			erase(i) ;
			return true ;
		}
	}

  return false ;
}

bool
ArrayLdvDrugs::getRenewPatPatho(NSPatPathoArray* pPPT, string sNodeRenew)
{
	if ((!pPPT) || (sNodeRenew == string("")))
  	return false ;

	NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex ;

	// On cherche le chapitre "traitement"
	PatPathoIter pptIt = pPtIndex->ChercherItem("N00001") ;

	if ((pptIt == NULL) || (pptIt == pPtIndex->end()))
  	return false ;   // cas aucun traitement d�j� effectu�

  // on note la colonne de base
  int iColBase = (*pptIt)->getColonne() ;

  // on se place sur le noeud renouvelement
  pptIt = pPtIndex->ChercherNoeud(sNodeRenew) ;

	if ((pptIt == NULL) || (pptIt == pPtIndex->end()))
  	return false ;   // cas d'erreur : noeud introuvable

	string sNodePhaseID = "" ;
	string sNodeRenewID = string(sNodeRenew, strlen(sNodeRenew.c_str()) - PPD_NOEUD_LEN, PPD_NOEUD_LEN) ;
	bool bFirstPhase = true ;

  // on remonte en arri�re jusqu'au noeud m�dicament
  // on retient le NodeID de la phase englobante au passage
  // Remarque : on retient ici uniquement le nodeID (valeur du noeud sans treeID)
  // car on compare ensuite cette valeur dans une nouvelle patpatho qui n'a pas de treeID
  while ((*pptIt)->getColonne() > iColBase+1)
  {
  	string sElemLex = (*pptIt)->getLexiqueSens(pDoc->pContexte) ;
    if (bFirstPhase && (sElemLex == "KPHAT"))
    {
    	sNodePhaseID = (*pptIt)->getNodeID() ;
      bFirstPhase = false ;
    }

    pptIt-- ;
  }

  if ((sNodePhaseID == "") || ((*pptIt)->getColonne() != iColBase+1))
  	return false ;   // cas d'erreurs : phase ou m�dicament introuvables

  string sCodeMedic = (*pptIt)->getLexique() ;
  string sNodeMedic = (*pptIt)->getNode() ;

  // on constitue la patpatho du m�dicament
  NSPatPathoArray SousPPT(pDoc->pContexte) ;
  pDoc->pContexte->getPatient()->DonneSousArray(sNodeMedic, &SousPPT) ;

  pPPT->vider();
  // on reconstitue la patpatho � partir du noeud
  pPPT->ajoutePatho(sCodeMedic, 0) ;
  // Insertion en queue (iter doit �tre ici egal � end())
  pPPT->InserePatPatho(pPPT->end(), &SousPPT, 1);

  // on va maintenant "faire le m�nage" dans cette patpatho :
  // - on supprime toutes les phases sauf celle qui correspond � sNodePhase
  // - dans cette phase, on supprime la dur�e, le nombre de renouvelements
  //   et tous les renouvelements sauf celui qui correspond � sNodeRenew
  pptIt = pPPT->begin() ;
  pptIt++ ;

  while (pptIt != pPPT->end())
  {
    string sSens = (*pptIt)->getLexiqueSens(pDoc->pContexte) ;
    string sCurrentNodeID = (*pptIt)->getNodeID() ;

    if (sSens == "KPHAT")
    {
    	if (sCurrentNodeID != sNodePhaseID)
      {
      	pPPT->SupprimerFils(pptIt) ;
        pPPT->SupprimerItem(pptIt) ;
      }
      else
      {
      	// on se trouve ici dans la phase � traiter
        // on parcours la phase pour faire les suppressions n�cessaires
        int iColPhase = (*pptIt)->getColonne() ;
        pptIt++ ;

        while ((pptIt != pPPT->end()) && ((*pptIt)->getColonne() > iColPhase))
        {
        	sSens = (*pptIt)->getLexiqueSens(pDoc->pContexte) ;
          sCurrentNodeID = (*pptIt)->getNodeID() ;

          if ((*pptIt)->getColonne() == iColPhase + 1)
          {
          	// Dur�e : on la supprime
            if (sSens == "VDURE")
            {
            	pPPT->SupprimerFils(pptIt) ;
              pPPT->SupprimerItem(pptIt) ;
            }
            else if (sSens == "VRENO")
            {
            	pPPT->SupprimerFils(pptIt) ;
              pPPT->SupprimerItem(pptIt) ;
            }
            else if (sSens == "GRENT")
            {
            	if (sCurrentNodeID != sNodeRenewID)
              {
              	pPPT->SupprimerFils(pptIt) ;
                pPPT->SupprimerItem(pptIt) ;
              }
              else
              	pptIt++ ;
            }
            else
            	pptIt++ ;
          }
          else
          	pptIt++ ;
        } // fin du while sur la phase
    	} // fin du if sur le node de la phase
    }
    else
    	pptIt++ ;
  }

	return true ;
}

string
ArrayLdvDrugs::getLastRenewNode(string sNodeMedic)
{
	NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex ;

	// on se place sur le noeud m�dicament
	PatPathoIter pptIt = pPtIndex->ChercherNoeud(sNodeMedic) ;

	if ((pptIt == NULL) || (pptIt == pPtIndex->end()))
  	return "" ;   // cas d'erreur : noeud introuvable

  string sLastRenewNode = sNodeMedic ;

	// on note la colonne de base
	int iColBase = (*pptIt)->getColonne() ;
	pptIt++ ;

	while ((pptIt != pPtIndex->end()) && ((*pptIt)->getColonne() > iColBase))
	{
    string sSens = (*pptIt)->getLexiqueSens(pDoc->pContexte) ;
    string sCurrentNode = (*pptIt)->getNode() ;

    if (sSens == "KPHAT")
    {
    	// on se trouve ici dans la phase � traiter
      // on parcours la phase noter le noeud renouvelement s'il existe
      int iColPhase = (*pptIt)->getColonne() ;
      pptIt++ ;

      while ((pptIt != pPtIndex->end()) && ((*pptIt)->getColonne() > iColPhase))
      {
      	sSens = (*pptIt)->getLexiqueSens(pDoc->pContexte) ;
        sCurrentNode = (*pptIt)->getNode() ;

        if ((*pptIt)->getColonne() == iColPhase + 1)
        {
        	if (sSens == "GRENT")
          {
          	sLastRenewNode = sCurrentNode ;
            pptIt++ ;
          }
          else
          	pptIt++ ;
        }
        else
        	pptIt++ ;
      } // fin du while sur la phase
    }
    else
    	pptIt++ ;
  }

	return sLastRenewNode ;
}

void
ArrayLdvDrugs::loadDrugs(NSPatPathoArray* pPtIndex, PatPathoIter iter, int iColBase, bool bJustOne)
{
try
{
  if (!pPtIndex || (pPtIndex->empty()))
  	return ;

	// NSPatPathoArray* pPtIndex = pDoc->pPathoPOMRIndex ;
	NSLdvDrug* pDrug = 0 ;
	NSLinkManager* pGraphe = pDoc->pContexte->getPatient()->pGraphPerson->pLinkManager ;
	bool bTourner = true ;

	while ((bTourner) && (iter != pPtIndex->end()) &&
					((*iter)->getColonne() > iColBase))
	{
		// Probl�me
		if ((*iter)->getColonne() == iColBase+1)
		{
    	if (bJustOne)
      	bTourner = false ;

			if (pDrug)
			{
				push_back(new NSLdvDrug(*pDrug)) ;
				delete pDrug ;
				pDrug = 0 ;
			}

      string sCodeLex      = (*iter)->getLexique() ;
      string sCodeSensDrug = (*iter)->getLexiqueSens(pDoc->pContexte) ;

      //
      // M�dicament cach� -- Hidden drug
      //
      if (sCodeSensDrug == "90000")
      {
      	iter++ ;
      	while ( (iter != pPtIndex->end()) &&
                ((*iter)->getColonne() > iColBase + 1))
        	iter++ ;
      }
      //
      // M�dicament visible -- Visible drug
      //
      else
      {
        pDrug = new NSLdvDrug(pDoc->pContexte, pDoc) ;

        // Libell�
        pDrug->setLexique(sCodeLex) ;

        if (sCodeLex != string("�?????"))
        	pDrug->setTitlesFromLexique() ;
          // pDoc->pContexte->getDico()->donneLibelle(pDoc->sLangue, &sCodeLex, &(pDrug->sTitre));

        // Texte libre - Free text
        else
        	pDrug->sTitre = (*iter)->getTexteLibre() ;

        // Noeud
        string sNoeud = (*iter)->getNode() ;
        pDrug->setNoeud(sNoeud) ;

        iter++ ;

        // Param�tres du m�dicament
        while ( (iter != pPtIndex->end()) &&
                ((*iter)->getColonne() > iColBase + 1))
        {
          string sSens = (*iter)->getLexiqueSens(pDoc->pContexte) ;

          if ((*iter)->getColonne() == iColBase+2)
          {
            // Dates
            if (("KOUVR" == sSens) || ("KFERM" == sSens))
            {
              iter++ ;
              int iLigneBase = (*iter)->getLigne() ;
              // gereDate* pDate = new gereDate(pContexte);
              string sUnite  = "" ;
              string sFormat = "" ;
              string sValeur = "" ;
              while (	(iter != pPtIndex->end()) &&
                      ((*iter)->getLigne() == iLigneBase))
              {
                if (pDoc->pContexte->getDico()->CodeCategorie((*iter)->getLexique()) == string(1, '�'))
                {
                  sFormat = (*iter)->getLexiqueSens(pDoc->pContexte) ;
                  sValeur = (*iter)->getComplement() ;
                  sUnite  = (*iter)->getUnitSens(pDoc->pContexte) ;
                  break ;
                }
                iter++ ;
              }

              // sFormat est du type �D0;03
              if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) &&
                          (sValeur != ""))
              {
                if (("2DA01" == sUnite) || ("2DA02" == sUnite))
                {
                  if ("KOUVR" == sSens)
                    pDrug->tDateOuverture.initFromDate(sValeur);
                  else
                    if ("KFERM" == sSens)
                      pDrug->tDateFermeture.initFromDate(sValeur);
                }
              }
            }
            // Unit� de prise
            //
            else if ("0MEDF" == sSens)
            {
            	iter++ ;
              if ((pPtIndex->end() != iter) && ((*iter)->getColonne() > iColBase + 2))
              	pDrug->sIntakeUnit = (*iter)->getLexique() ;
            }
            // Phases
            //
            else if ("KPHAT" == sSens)
            {
            	pDrug->initPhases(pPtIndex, iter) ;
              iter++ ;
              while ((pPtIndex->end() != iter) &&
                      ((*iter)->getColonne() > iColBase + 2))
               	iter++ ;
            }
            else if ("�C;" == sSens)
            {
              pDrug->_sFreeText = (*iter)->getTexteLibre() ;
              iter++ ;
            }
            else if (string("LADMI") == sSens)
            {
              int iColBaseAdmin = (*iter)->getColonne() ;
              iter++ ;
              while ((pPtIndex->end() != iter) && ((*iter)->getColonne() > iColBaseAdmin))
              {
                std::string tempAdm = (*iter)->getLexiqueSens(pDoc->pContexte) ;
                if ("LBARZ" == tempAdm)
                  pDrug->_bALD = true ;
                iter++ ;
              }
            }
            else
              iter++ ;
          }
          else
            iter++ ;
        }
        if (pDrug->tDateFermeture.estVide())
        	pDrug->tDateFermeture.setNoLimit() ;

        // Ce m�dicament est-il li� � des probl�mes de sant� ?
        // Is this drug linked to a health problem ?
        pGraphe->TousLesVrais(pDrug->getNoeud(), NSRootLink::drugOf,
                                                   &(pDrug->aConcerns)) ;
			}
		}
		else
			iter++ ;
	}

	if (pDrug)
	{
		push_back(new NSLdvDrug(*pDrug)) ;
		delete pDrug ;
		pDrug = 0 ;
	}
}
catch (...)
{
	erreur("Exception ArrayLdvDrugs::loadDrugs.", standardError, 0) ;
	return;
}
}

NSLdvDrug*
ArrayLdvDrugs::getDrug(string sRef)
{
	if ((sRef == string("")) || (empty()))
		return NULL ;

	for (drugsIter i = begin(); i != end(); i++)
  	if ((*i)->getNoeud() == sRef)
    	return *i ;

	return NULL ;
}

ArrayLdvDrugs&
ArrayLdvDrugs::operator=(ArrayLdvDrugs src)
{
try
{
	if (this == &src)
		return *this ;

	pDoc = src.pDoc ;

	vider() ;

	if (!(src.empty()))
		for (drugsIter i = src.begin(); i != src.end(); i++)
			push_back(new NSLdvDrug(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception ArrayLdvDrugs (=).", standardError, 0) ;
	return *this;
}
}

//-----------------------------------------------------------------------//
//				   		 Classe ArrayCopyDrugs                           //
//		   Array de copies de pointeurs : ne jamais faire de delete      //
//-----------------------------------------------------------------------//

ArrayCopyDrugs::ArrayCopyDrugs(ArrayCopyDrugs& rv)
	           :ArrayDrugs()
{
try
{
	if (!(rv.empty()))
		for (drugsIter i = rv.begin(); i != rv.end(); i++)
			push_back(*i) ;
}
catch (...)
{
	erreur("Exception ArrayCopyDrugs ctor.", standardError, 0) ;
}
}


void
ArrayCopyDrugs::vider()
{
	if (empty())
		return ;

	for (drugsIter i = begin(); i != end(); )
		erase(i) ;
}

ArrayCopyDrugs::~ArrayCopyDrugs()
{
	vider() ;
}

ArrayCopyDrugs&
ArrayCopyDrugs::operator=(ArrayCopyDrugs src)
{
try
{
	if (this == &src)
		return *this ;

	vider() ;

	if (!(src.empty()))
		for (drugsIter i = src.begin(); i != src.end(); i++)
			push_back(*i) ;

	return *this ;
}
catch (...)
{
	erreur("Exception ArrayCopyDrugs (=).", standardError, 0) ;
	return *this ;
}
}

