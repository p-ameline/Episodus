#include <owl\applicat.h>#include <owl\olemdifr.h>
#include <owl\mdichild.h>
#include <owl\edit.h>
#include <owl\combobox.h>
#include <owl\button.h>
#include <owl\static.h>

#include <bde.hpp>
#include <stdio.h>
#include <cstring.h>
#include <winsys/registry.h> //base de registre

#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "nautilus\nsresour.h"
#include "nautilus\nautilus.rh"
#include "nautilus\nsadmiwd.h"
#include "nautilus\nsanxary.h"
#include "nautilus\nsperary.h"
#include "nautilus\nspatdlg.h"
#include "nsdn\nsdocdlg.h"
#include "nscompta\nscomdlg.h"
#include "nscompta\nsfsedlg.h"
#include "nscompta\nsdepens.h"
#include "nscompta\nsf16dlg.h"

// *****************************************************************************************
//									M�thodes de NSComptaPatient
// *****************************************************************************************

NSComptaPatient::NSComptaPatient(NSContexte* pCtx, NSPersonInfo* pPat)
                :NSRoot(pCtx)
{
	if (pPat)
		pPatient = new NSPersonInfo(*pPat) ;
	else
		pPatient = NULL ;
}

NSComptaPatient::~NSComptaPatient()
{
	if (pPatient)
		delete pPatient ;
}

//------------------------------------------------------------------------------------------
//  Function:  NSComptaPatient::CherchePatEnCours(string& sNumSS)
//
//  Arguments: Une chaine donnee / resultat sNumSS
//
//  Description: retrouve le numSS du patient dans son blocs 5 ou renvoie sNumSS == ""
//
//  Returns: true->OK false->Sinon
//
//------------------------------------------------------------------------------------------
bool
NSComptaPatient::CherchePatEnCours(string& sNumSS)
{
	NSVitale2 benef(pContexte) ;

	string sCodePatient = pPatient->sPersonID ;

	// on ajoute les Data � la base des carte vitales	benef.lastError = benef.open();
	if (benef.lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture de la base carte vitale.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return false ;
	}

	benef.lastError = benef.chercheClef(&sCodePatient,                                      "NUMPATIENT",
                                      NODEFAULTINDEX,
                                      keySEARCHEQ,
                                      dbiWRITELOCK) ;

	if ((benef.lastError != DBIERR_NONE) && (benef.lastError != DBIERR_RECNOTFOUND))	{
		erreur("Erreur � la recherche d'un b�n�ficiaire.", standardError, benef.lastError, pContexte->GetMainWindow()->GetHandle()) ;
		benef.close() ;
		return false ;
	}

	if (benef.lastError != DBIERR_RECNOTFOUND)	{
		benef.lastError = benef.getRecord() ;
   	if (benef.lastError != DBIERR_NONE)
		{
			erreur("Erreur � la lecture d'un b�n�ficiaire.", standardError, benef.lastError, pContexte->GetMainWindow()->GetHandle());
      benef.close() ;
      return false ;
		}

    // patient trouv� : on renvoie son numSS		sNumSS = string(benef.pDonnees->immatricul) ;
	}
	else
   	sNumSS = "" ;

	// on ferme la base CARTE_SV2	benef.lastError = benef.close() ;

	if (benef.lastError != DBIERR_NONE)	{
		erreur("Erreur de fermeture du fichier ChemDoc.", standardError, benef.lastError, pContexte->GetMainWindow()->GetHandle());
		return false ;
	}

	return true ;
}

//------------------------------------------------------------------------------------------//  Function:  NSComptaPatient::SaisieNumSS(string& sNumSS)
//
//  Arguments: Une chaine resultat sNumSS
//
//  Description: r�cup�re le num�ro de s�curit� sociale (cl� des blocs 4)
//
//  Returns: true->OK false->Sinon
//
//------------------------------------------------------------------------------------------
bool
NSComptaPatient::SaisieNumSS(string& sNumSS)
{
	NumSSDialog* pNumSSDlg = new NumSSDialog(pContexte->GetMainWindow(), pContexte) ;

	if ((pNumSSDlg->Execute()) == IDCANCEL)
	{
		delete pNumSSDlg ;
   	return false ;
	}

	// on stocke les donnees du dialogue dans la string
	sNumSS = string(pNumSSDlg->numImma) ;
	delete pNumSSDlg ;

	return true ;
}

//------------------------------------------------------------------------------------------//  Function:  NSComptaPatient::ChercheNumSS(string& sNumSS, NSVitale1Info* pCarteInfo)
//
//  Arguments: Une chaine donnee / resultat sNumSS
//
//  Description: r�cup�re les infos de la carte si elle existe, ou renvoie une chaine vide
//
//  Returns: true->OK false->Sinon
//
//------------------------------------------------------------------------------------------
bool
NSComptaPatient::ChercheNumSS(string& sNumSS, NSVitale1Info* pCarteInfo)
{
   // on recherche le num�ro dans le fichier Carte_SV1
   NSVitale1* pCarte = new NSVitale1(pContexte);

	pCarte->lastError = pCarte->open();
	if (pCarte->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier Carte_SV1.db", standardError, pCarte->lastError, pContexte->GetMainWindow()->GetHandle()) ;
		delete pCarte;
		return false;
	}

   pCarte->lastError = pCarte->chercheClef(&sNumSS,													 		 "",
													 		 0,													 		 keySEARCHEQ,
                                              dbiWRITELOCK);

   if (pCarte->lastError != DBIERR_NONE)
   {
   	if (pCarte->lastError != DBIERR_RECNOTFOUND)
      {
   		erreur("Erreur � la recherche de la carte vitale.", standardError, pCarte->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      	pCarte->close();
			delete pCarte;
			return false;
      }
   }

   // si la carte existe on r�cup�re les infos
   if (pCarte->lastError != DBIERR_RECNOTFOUND)
   {
   	pCarte->lastError = pCarte->getRecord();
   	if (pCarte->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � lecture du fichier Carte_SV1.db", standardError, pCarte->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      	pCarte->close();
			delete pCarte;
			return false;
   	}

      *pCarteInfo = NSVitale1Info(pCarte);
   }
   else // sinon on renvoie une string vide et on stocke dans pCarteInfo
   {
   	strcpy(pCarteInfo->pDonnees->immatricul, sNumSS.c_str());
      sNumSS = "";
   }

   pCarte->lastError = pCarte->close();
	if (pCarte->lastError != DBIERR_NONE)
	{
		erreur("Erreur � la fermeture du fichier Carte_SV1.db", standardError, pCarte->lastError, pContexte->GetMainWindow()->GetHandle()) ;
		delete pCarte;
		return false;
	}

   delete pCarte;

   return true;
}

//------------------------------------------------------------------------------------------//  Function:  NSComptaPatient::InitDataCarteVitale(NSVitale1Info* pCarteInfo, bool bCreer)
//
//  Arguments: Les infos carte � initialiser ou � modifer
//
//  Description: Appel du dialogue de cr�ation/modification d'une carte
//
//  Returns: true->Les Data sont modifi�es false->Sinon
//
//------------------------------------------------------------------------------------------
bool
NSComptaPatient::InitDataCarteVitale(NSVitale1Info* pCarteInfo, bool bCreer)
{
	CreerCarteVitaleDialog* pCVDlg;

	pCVDlg = new CreerCarteVitaleDialog(pContexte->GetMainWindow(), pContexte);

	if (bCreer) // on conserve le numSS
		strcpy(pCVDlg->pData->immatricul, pCarteInfo->pDonnees->immatricul);
	else	// on est en modification
		*(pCVDlg->pData) = *(pCarteInfo->pDonnees);

	// pCVDlg->Create(); : ne marche pas non plus

	if ((pCVDlg->Execute()) == IDCANCEL)
	{
		delete pCVDlg;
		return false;
	}

	// on stocke les donnees du dialogue dans les Data
	*(pCarteInfo->pDonnees) = *(pCVDlg->pData);

	delete pCVDlg;

	return true;
}

//---------------------------------------------------------------------------//  Function:  NSComptaPatient::CmCarteVitale()
//
//  Arguments:
//
//  Description: Cr�ation d'une nouvelle carte vitale
//
//---------------------------------------------------------------------------
void NSComptaPatient::CmCarteVitale()
{
	NSVitale1Info* pCarteInfo = new NSVitale1Info();
   string 		 	sNumImma = "", sCode = "";
   bool				bCreerCarte = true;

   if (!CherchePatEnCours(sNumImma))
   {
   	delete pCarteInfo;
      return;
   }

   // si le patient n'appartient pas � un bloc 5
   if (sNumImma == "")
   {
   	// on lance le dialogue de saisie du num�ro
   	SaisieNumSS(sNumImma);
   }

   // NOTE : si le num�ro n'existe pas, le nouveau num�ro
   // est conserv� dans pCarteInfo, pour etre ensuite
   // repass� � InitDataCarteVitale.
   if (!ChercheNumSS(sNumImma, pCarteInfo))
   {
   	delete pCarteInfo;
      return;
   }

   // On v�rifie si la carte existe
   if (sNumImma != "")
   {
   	bCreerCarte = false;
   }

   if (!InitDataCarteVitale(pCarteInfo,bCreerCarte))
   {
   	delete pCarteInfo;
      return;
   }

   NSVitale1* pCarte = new NSVitale1(pContexte);

	// on ajoute les Data � la base des carte vitales
   pCarte->lastError = pCarte->open();
   if (pCarte->lastError != DBIERR_NONE)
   {
   	erreur("Erreur � l'ouverture de la base carte vitale.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      delete pCarte;
      delete pCarteInfo;
      return;
   }

   *(pCarte->pDonnees) = *(pCarteInfo->pDonnees);

   if (bCreerCarte)
   {
   	pCarte->lastError = pCarte->appendRecord();
   	if (pCarte->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � l'ajout de la fiche carte vitale.", standardError, pCarte->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      	pCarte->close();
      	delete pCarte;
      	delete pCarteInfo;
      	return;
   	}
   }
   else // on modifie la carte vitale correspondant � sNumImma
   {
   	pCarte->lastError = pCarte->chercheClef(&sNumImma,
													 		 "",
													 		 0,
													 		 keySEARCHEQ,
                                              dbiWRITELOCK);

      if (pCarte->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � la recherche de la carte vitale.", standardError, pCarte->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      	pCarte->close();
			delete pCarte;
         delete pCarteInfo;
			return;
   	}

   	pCarte->lastError = pCarte->modifyRecord(TRUE);
   	if (pCarte->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � la modification de la fiche carte vitale.", standardError, pCarte->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      	pCarte->close();
      	delete pCarte;
      	delete pCarteInfo;
      	return;
   	}
   }

   pCarte->lastError = pCarte->close();
   if (pCarte->lastError != DBIERR_NONE)
   	erreur("Erreur � la fermeture de la base carte vitale.", standardError, pCarte->lastError, pContexte->GetMainWindow()->GetHandle()) ;

   delete pCarte;
   delete pCarteInfo;
}

boolNSComptaPatient::ChercheNumCompt(string& sNumCompt)
{
	string 	sNumero ;
	char 	PremOrdre[CPTA_NUMCOMPT_LEN + 1],
		  	DernOrdre[CPTA_NUMCOMPT_LEN + 1] ;

	//
	// Pr�paration des compteurs mini et maxi
	//
	int i;
	for (i = 0; i < CPTA_NUMCOMPT_LEN; i++)
	{
		PremOrdre[i] = '0';
		DernOrdre[i] = 'z';
	}
	PremOrdre[i] 	= '\0';
	DernOrdre[i] 	= '\0';
	PremOrdre[i-1] = '1';

    // Entr�e en section critique
#ifndef N_TIERS
    if (!pContexte->DemandeAcces("COMPT"))    {
    	erreur("Impossible d'obtenir l'acc�s � la base Compt.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
        return false;
    }
#endif
	//
	// Prise d'un objet NSCompt
	//
	NSCompt* pComptTest = new NSCompt(pContexte);

   	pComptTest->lastError = pComptTest->open();
   	if (pComptTest->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � l'ouverture de la base nscompt.db.", standardError, pComptTest->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      	delete pComptTest;
#ifndef N_TIERS
        pContexte->LibereAcces("COMPT");
#endif
      	return false;
   	}

	//
	// On tente de se positionner sur le dernier code possible : "zzzzzzzz"
	//
   	sNumero = string(DernOrdre);

	pComptTest->lastError = pComptTest->chercheClef(&sNumero,

														 "",
														 0,
														 keySEARCHGEQ,
														 dbiWRITELOCK);
	//
	// Si on se trouve positionn� en fin de fichier on recule
	//
	if (pComptTest->lastError == DBIERR_EOF)
		pComptTest->lastError = pComptTest->precedent(dbiWRITELOCK);
	//
	// Toute autre erreur est anormale
	//
	else if ((pComptTest->lastError != DBIERR_NONE) && (pComptTest->lastError != DBIERR_BOF))
	{
		erreur("Le fichier nscompt.db est endommag�.", standardError, pComptTest->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      	pComptTest->close();
		delete pComptTest;#ifndef N_TIERS
        pContexte->LibereAcces("COMPT");#endif
		return false;
	}

	//
	// On r�cup�re l'enregistrement si fichier non vide
	//
   	if (pComptTest->lastError != DBIERR_BOF)
   	{
		pComptTest->lastError = pComptTest->getRecord();
   		if (pComptTest->lastError != DBIERR_NONE)
		{
			erreur("erreur � la lecture du fichier compt.db.", standardError, pComptTest->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      		pComptTest->close();
			delete pComptTest;#ifndef N_TIERS
            pContexte->LibereAcces("COMPT");#endif
			return false;
		}
   	}

	//
	// Si on est en fin ou d�but de fichier, c'est qu'il est vide
	//
	if ((pComptTest->lastError == DBIERR_BOF) ||
		(pComptTest->lastError == DBIERR_EOF) ||
		(pComptTest->lastError == DBIERR_NOCURRREC))
	{
    	sNumCompt = string(PremOrdre);
        pComptTest->pDonnees->metAZero();
    	strcpy(pComptTest->pDonnees->numcompt, sNumCompt.c_str());

    	pComptTest->lastError = pComptTest->appendRecord();
   		if (pComptTest->lastError != DBIERR_NONE)
   		{
   			erreur("Erreur � l'ajout d'une fiche Compt vierge.", standardError, pComptTest->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      		pComptTest->close();
      		delete pComptTest;#ifndef N_TIERS
            pContexte->LibereAcces("COMPT");#endif
      		return false;
   		}
      	pComptTest->close();
		delete pComptTest;#ifndef N_TIERS
        pContexte->LibereAcces("COMPT");#endif
		return true;
	}

	//
	// Toute autre erreur est anormale
	//
	if (pComptTest->lastError != DBIERR_NONE)
	{
		erreur("Le fichier compt.db est endommag�.", standardError, pComptTest->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      	pComptTest->close();
		delete pComptTest;#ifndef N_TIERS
        pContexte->LibereAcces("COMPT");#endif
		return false;
	}

	//
	// On est positionn� sur le dernier document du patient, que l'on doit
	// incr�menter pour avoir le nouveau code
	//
	char compteur[CPTA_NUMCOMPT_LEN + 1];
	strcpy(compteur, pComptTest->pDonnees->numcompt);

	//
	// On incr�mente le compteur
	//
	int j;
	int calculer = 1;
	i = strlen(compteur) - 1;

	while (calculer)
   	{
    	j = (int) compteur[i];
		j++;
		if (((j >= '0') && (j <= '9')) || ((j >= 'A') && (j <= 'Z')))
		{
			compteur[i] = (char) j;
			calculer = 0;
		}
		else if ((j > '9') && (j < 'A'))
		{
			compteur[i] = 'A';
			calculer = 0;
		}
		else
		{
			compteur[i] = '0';
			if (i == 0)
			{
				erreur("Compteur de fiches compt satur�.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
                pComptTest->close();
				delete pComptTest;#ifndef N_TIERS
        		pContexte->LibereAcces("COMPT");#endif
				return false;
			}
			i--;
		}
	}

	sNumCompt = string(compteur);

    // on stocke une fiche vierge pour etre plus sur
    pComptTest->pDonnees->metAZero();
    strcpy(pComptTest->pDonnees->numcompt, sNumCompt.c_str());

    pComptTest->lastError = pComptTest->appendRecord();
   	if (pComptTest->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � l'ajout d'une fiche Compt vierge.", standardError, pComptTest->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      	pComptTest->close();
      	delete pComptTest;#ifndef N_TIERS
        pContexte->LibereAcces("COMPT");#endif
      	return false;
   	}

    pComptTest->lastError = pComptTest->close();
   	if (pComptTest->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � la fermeture de la base nscompt.db.", standardError, pComptTest->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      	delete pComptTest;#ifndef N_TIERS
        pContexte->LibereAcces("COMPT");#endif
      	return false;
   	}

	delete pComptTest;
#ifndef N_TIERS
    // Sortie de section critique
    pContexte->LibereAcces("COMPT");#endif

	return true;
}
//// Fonction CreerFicheCompt pour la cr�ation des fiches compt :
// on passe le nouveau num�ro de la fiche dans sNumCompt
//
bool
NSComptaPatient::CreerFicheCompt(NSComptInfo* pComptInfo, NSFse1610Info* pFse1610Info, NSFse16Array* pFseArray)
{
try
{
	string		             sCodeExam = "" ;
	CreerFicheComptDialog* pComptDlg ;
	InitFse1610Dialog*     pFse1610Dlg ;
	string					       sNum ;

	pComptDlg = new CreerFicheComptDialog(pContexte->GetMainWindow(), pContexte, pPatient) ;
  pComptDlg->nbPrest = 0 ;

  if (pFseArray && (!(pFseArray->empty())))
  	for (NSFse16Iter i = pFseArray->begin(); i != pFseArray->end(); i++)
    {
   		pComptDlg->pFseArray->push_back(new NSBlocFse16(*(*i))) ;
      pComptDlg->nbPrest++ ;
    }

	// si la fiche compt a des donn�es initiales
  //
	if (pComptInfo)
	{
		sCodeExam = string(pComptInfo->pDonnees->examen) + string(pComptInfo->pDonnees->synonyme) ;
		*(pComptDlg->pData) = *(pComptInfo->pDonnees) ;
	}
	else
		pComptInfo = new NSComptInfo() ;

	if (pFse1610Info)
	{
		pFse1610Dlg = new InitFse1610Dialog(pContexte->GetMainWindow(), pContexte, sCodeExam) ;
		*(pFse1610Dlg->pData) = *(pFse1610Info->pDonnees) ;

		if ((pFse1610Dlg->Execute()) == IDOK)		{
			// on ajoute une Fse1610 au tableau des Fse
			*(pFse1610Info->pDonnees) = *(pFse1610Dlg->pData) ;

			pComptDlg->pFseArray->push_back(new NSBlocFse16(pFse1610Info)) ;
			pComptDlg->nbPrest++ ;
		}
		else
		{
			delete pFse1610Dlg ;
			delete pComptDlg ;
			return true ; 		// pour ne pas afficher de message d'erreur en sortie
		}

		delete pFse1610Dlg ;
	}

	// on execute le dialogue de la fiche compt
	// avec �ventuellement les donn�es stock�es dans les datas
	if ((pComptDlg->Execute()) == IDCANCEL)
	{
		delete pComptDlg ;
		return true ; 		// pour ne pas afficher de message d'erreur en sortie
	}

	// on stocke les donnees du dialogue dans les Info
	*(pComptInfo->pDonnees) = *(pComptDlg->pData) ;

	// ... SECTION CRITIQUE ...
	// on cherche le num�ro compt pour enregistrement
	if (!ChercheNumCompt(sNum))
	{
		delete pComptDlg ;
		return false ;
	}
	// ........................

	// on enregistre la fiche compt dans la base
	// (par modification de la fiche vierge cr�ee sous le num�ro sNum)
	NSCompt compt(pContexte) ;

	compt.lastError = compt.open() ;
	if (compt.lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture de la base Compt.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		delete pComptDlg ;
		return false ;
	}

	compt.lastError = compt.chercheClef(&sNum,
                                      "",
												              0,
												              keySEARCHEQ,
                                      dbiWRITELOCK) ;

	if (compt.lastError != DBIERR_NONE)
	{
		erreur("Erreur � la recherche de la nouvelle fiche compt.", standardError, compt.lastError, pContexte->GetMainWindow()->GetHandle()) ;
		compt.close() ;
		delete pComptDlg ;
		return false ;
	}

	compt.lastError = compt.getRecord() ;
	if (compt.lastError != DBIERR_NONE)
	{
		erreur("Erreur � lecture du fichier Compt.db", standardError, compt.lastError, pContexte->GetMainWindow()->GetHandle()) ;
		compt.close() ;
		delete pComptDlg ;
		return false ;
	}

	*(compt.pDonnees) = *(pComptInfo->pDonnees) ;
	// on enregistre le num�ro compt
	strcpy(compt.pDonnees->numcompt, sNum.c_str()) ;

	compt.lastError = compt.modifyRecord(TRUE) ;
	if (compt.lastError != DBIERR_NONE)
	{
		erreur("Erreur � la modification de la fiche compt.", standardError, compt.lastError, pContexte->GetMainWindow()->GetHandle()) ;
		compt.close() ;
		delete pComptDlg ;
		return false ;
	}

	compt.lastError = compt.close() ;
	if (compt.lastError != DBIERR_NONE)
		erreur("Erreur � la fermeture de la base Compt.", standardError, compt.lastError,pContexte->GetMainWindow()->GetHandle()) ;

	// on enregistre les autres donn�es sous le meme num�ro
	pComptDlg->EnregDonneesCompt(sNum) ;

	delete pComptDlg ;

	return true ;
}
catch (...)
{
	erreur("Exception NSComptaPatient::CreerFicheCompt", standardError, 0) ;
  return false ;
}
}
voidNSComptaPatient::CmFicheCompt(NSComptInfo* pComptInit, NSFse1610Info* pFse1610Init, NSFse16Array* pFseArray)
{
	if (pFse1610Init)
		strcpy(pFse1610Init->pDonnees->numprest, "0000") ;

	if (!CreerFicheCompt(pComptInit, pFse1610Init, pFseArray))
		erreur("La fiche compt n'a pas pu �tre enregistr�e...", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
}

voidNSComptaPatient::CmSituation()
{
	NSListComptDialog* pListComptDlg =
   	    new NSListComptDialog(pContexte->GetMainWindow(), pContexte, pPatient) ;

	if ((pListComptDlg->bErreur) || (pListComptDlg->nbCompt == 0))	{
		delete pListComptDlg ;
		return ;
	}

	// on affiche le dialogue de situation	if ((pListComptDlg->Execute()) == IDCANCEL)
	{
		delete pListComptDlg ;
		return ;
	}
	delete pListComptDlg;
}

// fin de nsadmiwd.cpp
