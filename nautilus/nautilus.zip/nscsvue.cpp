// NSCSVUE.CPP		Document/Vues Consultation// -----------------------------------------

#define __NSCSVUE_CPP

#include <owl\owlpch.h>
#include <owl\validate.h>
#include <owl\inputdia.h>
#include <fstream.h>

#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "nsbb\nspatpat.h"
#include "nautilus\nscsvue.h"
#include "nautilus\nscsdoc.h"
#include "nautilus\nshistdo.h"
#include "nautilus\ns_html.h"
#include "dcodeur\nsdkd.h"
#include "nautilus\nsadmiwd.h"
#include "nsoutil\nsfilgui.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nstrewi.h"
#include "nsbb\nstrnode.h"
#include "nsbb\nsbbsmal.h"
#include "nautilus\nsepicap.h"
#include "nsbb\nsattvaltools.h"

// Table de r�ponses de la classe NSCsVue
////////////////////////////////////////////////////////////////
DEFINE_RESPONSE_TABLE2(NSCsVue, TView, NSTreeWindow)
// DEFINE_RESPONSE_TABLE2(NSCsVue, NSMUEView, NSTreeWindow)
  EV_VN_ISWINDOW,
  EV_WM_SETFOCUS,
  EV_WM_CLOSE,
  EV_WM_DESTROY,
  EV_WM_QUERYENDSESSION,

  EV_WM_SIZE,
  EV_WM_SYSCOMMAND,

  EV_COMMAND(CM_COMPOSE, 	  CmComposer),
  EV_COMMAND(CM_ENREGISTRE, CmEnregistre),
  EV_COMMAND(CM_IMPRIME, 	  CmPublier),
  EV_COMMAND(CM_VISUAL, 	  CmVisualiser),
  EV_COMMAND(CM_FILECLOSE,  EvClose),

  EV_COMMAND(IDC_COMPTA_CR, Compta),

  EV_COMMAND(CM_1P,         Cm1Plus),
  EV_COMMAND(CM_2P,         Cm2Plus),
  EV_COMMAND(CM_3P,         Cm3Plus),
  EV_COMMAND(CM_4P,         Cm4Plus),

  EV_COMMAND_ENABLE(CM_1P,  Ce1Plus),
  EV_COMMAND_ENABLE(CM_2P,  Ce2Plus),
  EV_COMMAND_ENABLE(CM_3P,  Ce3Plus),
  EV_COMMAND_ENABLE(CM_4P,  Ce4Plus),
END_RESPONSE_TABLE ;


// -----------------------------------------------------------------------------
// Constructeur NSCsVue
// -----------------------------------------------------------------------------
NSCsVue::NSCsVue(NSCSDocument& doc, TWindow *parent)
/*    :NSMUEView(doc.pContexte, &doc),
     NSTreeWindow(parent, doc.pContexte, GetNextViewId(), 0, 0, 0, 0) */
    :TView(doc),
    pDoc(&doc),
    NSTreeWindow(parent, doc.pContexte, GetNextViewId(), 0, 0, 0, 0)
{
try
{
  NSSuper *pSuper = NSTreeWindow::pContexte->getSuperviseur() ;
  pMUEViewMenu = 0 ;

  TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;
  pMyApp->setMenu(string("menubar"), &hAccelerator) ;

  pBigBoss = 0 ;
  pToolBar = 0 ;
  pPrinter = 0 ;
  bConsultVide = true ;
  bSetupToolBar = true ;
}
catch (...)
{
	erreur("Exception NSCsVue ctor.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Destructeur NSCsVue
// -----------------------------------------------------------------------------
NSCsVue::~NSCsVue()
{
	if (pBigBoss)
		delete pBigBoss ;

	if (pPrinter)
		delete pPrinter ;

  if (pMUEViewMenu)
  	delete pMUEViewMenu ;

	//deleter les BBItem cr�es dans la consultation	NSTreeWindow *pNSTreeWindow ;
	pNSTreeWindow = this ;
	pNSTreeWindow->LibereBBitemLanceur() ;

  if (0 != hAccelerator)
  {
    DestroyAcceleratorTable(hAccelerator) ;
    hAccelerator = 0 ;
  }
}

// -----------------------------------------------------------------------------
// Fonction: 	NSCsVue::SetupWindow()
// -----------------------------------------------------------------------------
void
NSCsVue::SetupWindow()
{
  string sLang = "" ;
  if ((NSTreeWindow::pContexte) && (NSTreeWindow::pContexte->getUtilisateur()))
    sLang = NSTreeWindow::pContexte->getUtilisateur()->donneLang() ;

  // titre du document
  if (pDoc->pDocInfo)
  {
    // Affiche le titre du document
    NSTreeWindow::SetDocTitle(pDoc->GetTitle(), 0) ;
  }
  else   //r�cuperer le type document
  {
    if (pDoc->sTypeDocument != "")
    {
      string sTitle ;
      NSTreeWindow::pContexte->getDico()->donneLibelle(sLang, &pDoc->sTypeDocument, &sTitle) ;
      pDoc->SetTitle(sTitle.c_str()) ;
      NSTreeWindow::SetDocTitle(sTitle.c_str(), 0) ;
    }
  }

  lanceConsult() ;
  NSTreeWindow::SetupWindow() ;

  NSCSDocument *CSDoc = dynamic_cast<NSCSDocument *>(pDoc) ;
  // Dispatcher la patpatho
  NSTreeWindow::DispatcherPatPatho(CSDoc->pPatPathoArray, 0, 0, "") ;

  if (strncmp(pBigBoss->lexiqueModule, "ZSYNT", 5) == 0)
    SetWindowPosSynthse() ;

  if (!pBigBoss->getPatPatho()->empty())
    pBigBoss->MetTitre() ;
}

TWindow
*NSCsVue::GetWindow()
{
	return (TWindow *) this ;
}

bool
NSCsVue::PreProcessMsg(MSG &msg)
{
  PRECONDITION(GetHandle()) ;
  return hAccelerator ? ::TranslateAccelerator(GetHandle(), hAccelerator, &msg) : false ;
}

// -----------------------------------------------------------------------------
// Fonction: 	NSCsVue::lanceConsult()
// -----------------------------------------------------------------------------
void
NSCsVue::lanceConsult()
{
try
{
	NSTreeWindow *pNSTreeWindow ;
	pNSTreeWindow = this ;
	pBigBoss = new NSSmallBrother(NSTreeWindow::pContexte, pDoc->pPatPathoArray) ;
	pBigBoss->pFenetreMere = TView::GetWindow() /*pFenetre*/ ;
	pBigBoss->lanceConsult(pDoc->sTypeDocument, pNSTreeWindow) ;
}
catch (...)
{
	erreur("Exception NSCsVue::lanceConsult", standardError, 0) ;
}
}

void
NSCsVue::CmEnregistre()
{
  bool          bNewDoc = false ;
  int           retVal ;
  NSTreeWindow  *pNSTreeWindow ;
  pNSTreeWindow = this ;
  pNSTreeWindow->okFermerDialogue() ;
  NSCSDocument *CSDoc = dynamic_cast<NSCSDocument *>(pDoc) ;
  pNSTreeWindow->EnregistrePatPatho(pBigBoss) ;

//  if (!pBigBoss->getPatPatho()->empty())
//  	pBigBoss->MetTitre() ;
  pBigBoss->MetTitre() ;

  if (CSDoc->pDocInfo == 0)
    bNewDoc = true ;

  if (CSDoc->enregistre())
  {
    pDoc->SetDirty(false) ;
    pNSTreeWindow->SetDirty(false) ;

    if (bNewDoc && (NSTreeWindow::pContexte->getSuperviseur()->isComptaAuto()) && (CSDoc->ComptaAuto()))
    {
      string sCaption = string("Message ") + NSTreeWindow::pContexte->getSuperviseur()->getAppName().c_str() ;
      retVal = NSTreeWindow::MessageBox("Il n'existe pas de fiche comptable pour ce document. Voulez-vous lancer la comptabilit� ?", sCaption.c_str(), MB_YESNO) ;
      if (retVal == IDYES)
        Compta() ;
    }
  }
  else
    pDoc->SetDirty(true) ;
}

void
NSCsVue::CmPublier()
{
try
{
	NSCSDocument *CSDoc = dynamic_cast<NSCSDocument *>(pDoc) ;

	if (CSDoc->pHtmlCS)
		delete CSDoc->pHtmlCS ;

	CSDoc->pHtmlCS = new NSHtml(tCS) ; 	// htmlNode racine du html de consultation

	InscrireHtml(CSDoc->pHtmlCS) ;

	if (!bConsultVide)
		CSDoc->Publier() ;
	else
		NSTreeWindow::MessageBox("Le document est vide.") ;
}
catch (...)
{
	erreur("Exception NSCsVue::CmPublier", standardError, 0) ;
}
}

void
NSCsVue::CmVisualiser()
{
try
{
	NSCSDocument *CSDoc = dynamic_cast<NSCSDocument *>(pDoc) ;

	if (CSDoc->pHtmlCS)
		delete CSDoc->pHtmlCS ;

	CSDoc->pHtmlCS = new NSHtml(tCS) ; 	// htmlNode racine du html de consultation

	InscrireHtml(CSDoc->pHtmlCS) ;

	if (!bConsultVide)
		CSDoc->Visualiser() ;
	else
		NSTreeWindow::MessageBox("Le document de synthese est vide.") ;
}
catch (...)
{
	erreur("Exception NSCsVue::CmVisualiser", standardError, 0) ;
}
}

void
NSCsVue::InscrireHtml(NSHtml *pHtml)
{
  NSHtml 	htmlNode(tConsult) ;
  int     cpt = 0 ;

	if (pNodeArray->empty())
		return ;

	for (iterNSTreeNode i = pNodeArray->begin() ; i != pNodeArray->end() ; i++)
	{
		// on prend les �l�ments de premier niveau
		if ((*i)->pere == 0)
		{
			cpt++ ;

			if ((*i)->pControle)
			{
				// on "skippe" les noeuds masqu�s
				if ((*i)->getEtiquette() == "900001")
					continue ;

				htmlNode.sTexte = (*i)->GetText() ;
				if (!(((*i)->VectFrereLie).empty()))
				{
					for (iterNSTreeNode j = ((*i)->VectFrereLie).begin() ; j != ((*i)->VectFrereLie).end() ; j++)
					{
						htmlNode.sTexte += " " ;
						htmlNode.sTexte += (*j)->GetText() ;
					}
				}
				pHtml->filsArray.push_back(new NSHtml(htmlNode)) ;
				InscrireFils(*i, pHtml->filsArray[pHtml->filsArray.size() - 1]) ;
				bConsultVide = false ;
			}
			else if (cpt == 1)
			{
				bConsultVide = true ;
				return ;
      }
    }
  }
}


void
NSCsVue::InscrireFils(NSTreeNode *pNode, NSHtml *pHtml)
{
  NS_CLASSLIB::TRect	rectItem ;
  NSHtml              htmlNode(tConsult) ;

  // s'il existe des fils "visibles", c'est � dire que l'arbre des fils est d�velopp�
  if ((!pNode->VectFils.empty()) && ((pNode->VectFils[0])->GetItemRect(rectItem)))
  {
    for (iterNSTreeNode i = pNode->VectFils.begin() ; i != pNode->VectFils.end() ; i++)
    {
      if ((*i)->pControle)
      {
        // on "skippe" les noeuds masqu�s
        if ((*i)->getEtiquette() == "900001")
            continue;

        htmlNode.sTexte = (*i)->GetText() ;
        if (!(((*i)->VectFrereLie).empty()))
        {
          for (iterNSTreeNode j = ((*i)->VectFrereLie).begin() ; j != ((*i)->VectFrereLie).end() ; j++)
          {
            htmlNode.sTexte += " " ;
            htmlNode.sTexte += (*j)->GetText() ;
          }
        }
        pHtml->filsArray.push_back(new NSHtml(htmlNode)) ;
        InscrireFils(*i, pHtml->filsArray[pHtml->filsArray.size() - 1]) ;
      }
    }
  }
}



// -----------------------------------------------------------------------------
// Lib�ration de la derni�re barre d'outils cr�ee
// -----------------------------------------------------------------------------
void
NSCsVue::EvSetFocus(THandle hWndLostFocus /* may be 0 */)
{
	// activateMUEViewMenu() ;

	// NSTreeWindow  *pNSTreeWindow = this ;
  TMyApp        *pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;
  NSTreeWindow::Initialise(hWndLostFocus) ;
  // NSTreeWindow::EvSetFocus(hWndLostFocus) ;

  pMyApp->setMenu(string("menubar"), &hAccelerator) ;

  if (bSetupToolBar && (GetWindow() != pMyApp->GetToolBarWindow()))
  {
  	SetupToolBar() ;
    pMyApp->SetToolBarWindow(GetWindow()) ;
  }
}


void
NSCsVue::SetupToolBar()
{
	TMyApp *pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;
  pMyApp->FlushControlBar() ;

  // on met un bouton compta sauf pour la synth�se
  if (strncmp(pBigBoss->lexiqueModule, "ZSYNT", 5))
  {
    pMyApp->cb2->Insert(*new TButtonGadget(IDC_COMPTA_CR, IDC_COMPTA_CR, TButtonGadget::Command)) ;
    pMyApp->cb2->Insert(*new TSeparatorGadget) ;
  }

  pMyApp->cb2->Insert(*new TButtonGadget(CM_1P, CM_1P, TButtonGadget::Command)) ;
  pMyApp->cb2->Insert(*new TButtonGadget(CM_2P, CM_2P, TButtonGadget::Command)) ;
  pMyApp->cb2->Insert(*new TButtonGadget(CM_3P, CM_3P, TButtonGadget::Command)) ;
  pMyApp->cb2->Insert(*new TButtonGadget(CM_4P, CM_4P, TButtonGadget::Command)) ;

  pMyApp->cb2->LayoutSession() ;
}


// -----------------------------------------------------------------------------
// Appel automatique d'une fiche Compt � partir d'une consultation
// -----------------------------------------------------------------------------
void
NSCsVue::Compta()
{
try
{
	if (pDoc->pPatPathoArray->empty())
	{
    erreur("Vous devez enregistrer le document avant de le comptabiliser.", warningError, 0, NSTreeWindow::GetHandle()) ;
    return ;
  }

  string			  sCode = "", sExam = "", sSyn = "" ;
  string 			  sLibelleDoc = "", sDateDoc = "", sExtHosp = "" ;
  NSComptInfo   ComptInfo ;
  NSFse1610Info Fse1610Info ;

  if (!pDoc->pBigBoss)
    pDoc->pBigBoss = new NSSmallBrother(NSTreeWindow::pContexte, pDoc->pPatPathoArray) ;

  // date de l'examen
  PatPathoIter iterPpt = pDoc->pPatPathoArray->begin() ;
  iterPpt++ ;
  if (iterPpt != pDoc->pPatPathoArray->end())
  	if ((*iterPpt)->getLexiqueSens(pContexte) == "KCHIR")
    	pDoc->pPatPathoArray->CheminDansPatpatho(0, "KCHIR", &sDateDoc) ;

	if (sDateDoc == "")
  	pDoc->pPatPathoArray->CheminDansPatpatho(pDoc->pBigBoss, "LADMI/KCHIR", &sDateDoc) ;

  if (sDateDoc == "")
  {
    if (pDoc->pDocInfo) // on prend la date de cr�ation (heure = 0)
    	sDateDoc = pDoc->pDocInfo->getCreDate() ;
    else // on prend la date et l'heure du jour
    {
    	NVLdVTemps tpsNow ;
    	tpsNow.takeTime() ;
    	sDateDoc = tpsNow.donneDate() ;
    }
  }

  string sDate = string(sDateDoc, 0, 8) ;
	string sHeure = string("0000") ;
	if (strlen(sDateDoc.c_str()) >= 12)
		sHeure = string(sDateDoc, 8, 4) ;

	strcpy(ComptInfo.pDonnees->date, sDate.c_str()) ;
	strcpy(ComptInfo.pDonnees->heure, sHeure.c_str()) ;
  // on cale la date de la Fse1610 sur celle de la fiche Compt
	strcpy(Fse1610Info.pDonnees->date, ComptInfo.pDonnees->date) ;
	strcat(Fse1610Info.pDonnees->date, ComptInfo.pDonnees->heure) ;

  // Externe / Hospitalis�
  pDoc->pPatPathoArray->CheminDansPatpatho(pDoc->pBigBoss, "LADMI/LCONT", &sExtHosp) ;
  if (sExtHosp != "")
    sExtHosp = string(sExtHosp, 0, 5) ;

  sCode = (*(pDoc->pPatPathoArray->begin()))->pDonnees->lexique ;
  if (sCode != "")
  {
    sExam = string(sCode, 0, 5) ;
    sSyn = string(sCode, 5, 1) ;
  }

  strcpy(ComptInfo.pDonnees->examen, sExam.c_str()) ;
  strcpy(ComptInfo.pDonnees->synonyme, sSyn.c_str()) ;
  strcpy(ComptInfo.pDonnees->contexte, sExtHosp.c_str()) ;

  NSPersonInfo personInfo(pContexte, pContexte->getPatient()->getNss()) ;

  // NSComptaPatient *pCompta = new NSComptaPatient(NSTreeWindow::pContexte, (NSPatInfo *) NSTreeWindow::pContexte->getPatient()) ;
  NSComptaPatient *pCompta = new NSComptaPatient(NSTreeWindow::pContexte, &personInfo) ;

  pCompta->CmFicheCompt(&ComptInfo, &Fse1610Info) ;

  delete pCompta ;
}
catch (...)
{
	erreur("Exception NSCsVue::Compta", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// fermeture du document
// -----------------------------------------------------------------------------
void
NSCsVue::EvClose()
{
}

// -----------------------------------------------------------------------------
// Fonction de Windows r�cup�r�e pour le changement de taille dans SIZE_RESTORED
// Finalement le bug persistait donc on revient � TWindow::EvSize
// -----------------------------------------------------------------------------
void
NSCsVue::EvSize(uint sizeType, NS_CLASSLIB::TSize& size)
{
    NSTreeWindow::EvSize(sizeType, size) ;
}

// -----------------------------------------------------------------------------
// Fonction que l'on n'arrive pas � intercepter
// -----------------------------------------------------------------------------
void
NSCsVue::EvSysCommand(uint cmdType, NS_CLASSLIB::TPoint& point)
{
  switch (cmdType & 0xFFF0)
  {
    case SC_MINIMIZE  : break ;
    case SC_MAXIMIZE  : break ;
    case SC_SIZE      : break ;
    default           : NSTreeWindow::DefaultProcessing() ;
  }
}

// -----------------------------------------------------------------------------
// mettre � jour la base des registres s'il y a modification dans les postition
// des fiches de Synth�se et historique
// -----------------------------------------------------------------------------
void
NSCsVue::EvDestroy()
{
  if (strncmp(pBigBoss->lexiqueModule, "ZSYNT", 5) == 0)
    EnregistrePosSynthse() ;
}

// -----------------------------------------------------------------------------
// Fermeture de Windows
// -----------------------------------------------------------------------------
bool
NSCsVue::EvQueryEndSession()
{
    return NSTreeWindow::EvQueryEndSession() ;
}

// -----------------------------------------------------------------------------
// fixer la position de la Synth�se
// -----------------------------------------------------------------------------
void
NSCsVue::SetWindowPosSynthse()
{
  // fixer la position de la fiche de synth�se selon les valeurs dans UTILISAT.DB
  // Parent->Show(SW_HIDE);

	NS_CLASSLIB::TRect rectDlg = NSTreeWindow::Parent->GetWindowRect() ;//coordonn�es par % � l'�cran

  int     X, Y, W, H ;
  string  sTaille ;
  NS_CLASSLIB::TPoint point(rectDlg.X(), rectDlg.Y()) ;
  if (NSTreeWindow::Parent)
  {
    if (NSTreeWindow::Parent->Parent)
      NSTreeWindow::Parent->Parent->ScreenToClient(point) ;
    else
      NSTreeWindow::Parent->ScreenToClient(point) ;
    X = point.X() ;
    Y = point.Y() ;
  }
  else
  {
    X = 0 ;
    Y = 0 ;
  }
  W = rectDlg.Width() ;
  H = rectDlg.Height() ;

  NSWindowProperty *pWinProp = NSTreeWindow::pContexte->getUtilisateur()->aWinProp.getProperty("Synthesis") ;
  if (pWinProp)
  {
    X = pWinProp->X() ;
    Y = pWinProp->Y() ;
    W = pWinProp->W() ;
    H = pWinProp->H() ;
  }

  // fixer la nouvelle position
  // (on ne tient pas compte de la taille, vu le probleme pour restaurer
  // une fenetre TView,TWindow mise en icone)
  NSTreeWindow::Parent->SetWindowPos(0, X, Y, W, H, SWP_NOZORDER) ;
  NSTreeWindow::Parent->Show(SW_SHOWNORMAL) ;

  /* ********************************
  if      (sTaille == "I")
    Parent->Show(SW_SHOWMINIMIZED) ;
  else if (sTaille == "Z")
    Parent->Show(SW_SHOWMAXIMIZED) ;
  else
    Parent->Show(SW_SHOWNORMAL) ;
  ********************************* */
}

// -----------------------------------------------------------------------------
// enregistrer la position de la Synth�se dans la base Utilisat.db
// -----------------------------------------------------------------------------
void
NSCsVue::EnregistrePosSynthse()
{
	if (!pContexte->getUtilisateur()->bEnregWin)
  	return ;

  NS_CLASSLIB::TRect rectDlg = NSTreeWindow::Parent->GetWindowRect() ; //coordonn�es par % � l'�cran

  NS_CLASSLIB::TPoint point(rectDlg.X(), rectDlg.Y()) ;
  NSTreeWindow::Parent->Parent->ScreenToClient(point) ;
  int X = point.X() ;
  int Y = point.Y() ;
  int W = rectDlg.Width() ;
  int H = rectDlg.Height() ;

	if (NSTreeWindow::Parent->IsIconic())
  	return ;

	string sUserId = NSTreeWindow::pContexte->getUtilisateur()->getNss() ;
  NS_CLASSLIB::TRect  rect(X, Y, X + W, Y + H) ;
  NSWindowProperty wndProp ;
  wndProp.setX(X) ;
  wndProp.setY(Y) ;
  	// wndProp->iW = X + W;
  	// wndProp->iH = Y + H;
  wndProp.setW(W) ;
  wndProp.setH(H) ;
  wndProp.setActivity(NSWindowProperty::undefined) ;
  wndProp.setFunction("Synthesis") ;

  NSTreeWindow::pContexte->getUtilisateur()->aWinProp.saveWindowProperty(sUserId, NSTreeWindow::pContexte->PathName("FGLO"), &wndProp, false) ;
  NSTreeWindow::pContexte->getUtilisateur()->aWinProp.saveWindowProperty(sUserId, NSTreeWindow::pContexte->PathName("FGLO"), &wndProp, true) ;
  //pContexte->getUtilisateur()->aWinProp.setProperty(sUserId, "Synthesis", rect, pContexte->PathName("FGLO")) ;
}

// -----------------------------------------------------------------------------
// Fonction CanClose : Appel de CanClose du document
// -----------------------------------------------------------------------------
bool
NSCsVue::CanClose()
{
  int           retVal ;
  NSTreeWindow  *pNSTreeWindow ;
  char          message[255] ;
  pNSTreeWindow = this ;
  pDoc->SetDirty(pNSTreeWindow->GetDirty()) ;

  TMyApp        *pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;

  if (!pDoc->CanClose())
  {
    string sCaption = string("Message ") + NSTreeWindow::pContexte->getSuperviseur()->getAppName().c_str() ;
    if (pDoc->pDocInfo)
    {
      sprintf(message, "Voulez-vous sauvegarder les modifications du document %s ?", pDoc->GetTitle()) ;
      retVal = NSTreeWindow::MessageBox(message, sCaption.c_str(), MB_YESNOCANCEL) ;
    }
    else
    {
      sprintf(message, "Voulez-vous sauvegarder le document %s ?", pDoc->GetTitle()) ;
      retVal = NSTreeWindow::MessageBox(message, sCaption.c_str(), MB_YESNOCANCEL) ;
    }

    if (retVal == IDCANCEL)
      return false ;
    if (retVal == IDYES)
    {
      CmEnregistre() ;
      pMyApp->FlushControlBar() ;
      bSetupToolBar = false ;
      return true ;
    }
  }
  pDoc->SetDirty(false) ;
  pMyApp->FlushControlBar() ;
  bSetupToolBar = false ;
  return true ;
}

// -----------------------------------------------------------------------------
// Edition du noeud (p�res + fils) sous forme de fil guide
// -----------------------------------------------------------------------------
void
NSCsVue::EditionFilGuide()
{
  // Localisation du noeud qui poss�de le focus
  TTreeNode   noeud = GetSelection() ;
  NSTreeNode  *pNSTreeNode = GetNSTreeNode(&noeud) ;
  if (!pNSTreeNode)
    return ;

  // on appelle okFermerDialogue() pour stocker la patpatho
  // dans le BBFilsItem lanceur (on peut ainsi r�cup�rer le code root)
  okFermerDialogue() ;

  // on "shunte" maintenant EnregistrePatPatho et on r�cup�re directement
  // le chemin racine dans le BBFilsItem lanceur
  BBFilsItem  *pBBFilsLanceur = *(pBBitemNSTreeWindow->aBBItemFils.begin()) ;
  string      sCodeRoot = string(pBBFilsLanceur->getItemData()->chemin) ;

  if (sCodeRoot == "")
  {
    erreur("Impossible de r�cup�rer le code racine de l'arbre de description.", standardError, 0, NSTreeWindow::GetHandle()) ;
    return ;
  }

  // on constitue le chemin - codes lexiques - jusqu'au node (lui-m�me y compris)
  string sCheminNode, sEtiqu ;
  pNSTreeNode->formerCheminLocal(&sCheminNode) ; // chemin des p�res

  // on ajoute la racine avant le chemin local
  // pour obtenir un chemin p�re valide au sens "fil guide"
  sCheminNode = sCodeRoot + string(1, cheminSeparationMARK) + sCheminNode ;

  // on rajoute le node himself
  sEtiqu = pNSTreeNode->getLabel() ;

  if (string("") != sCheminNode)
    sCheminNode += string(1, cheminSeparationMARK) ;
  sCheminNode += sEtiqu ;

  // chemin des fils
  string sEnsembleFils = "" ;
  // on parcourt l'ensemble des fils existants
  if (false == pNSTreeNode->VectFils.empty())
  {
    for (iterNSTreeNode i = pNSTreeNode->VectFils.begin() ; i != pNSTreeNode->VectFils.end() ; i++)
    {
      // Remarque : on ne fait pas ici le test "if ((*i)->pControle)"
      // qui sert � savoir si le fils est propos� (pControle == 0) ou non
      // car on veut �diter dans le fil guide l'ensemble des fils du node
      sEtiqu = (*i)->getLabel() ;

      // Attention, l'ensemble des fils ne constitue pas un chemin.
      // chaque fils doit �tre s�par� du suivant par un '|', ce qui
      // permet de charger le tableau des fils par ::ParsingChemin
      if (sEnsembleFils != "")
        sEnsembleFils += string(1, nodeSeparationMARK) ;
      sEnsembleFils += sEtiqu ;
    }
  }

  // Chargement et appel du dialogue d'�dition des fils guides
  NSEditFilGuideDialog *pEditFGDlg = new NSEditFilGuideDialog((NSTreeWindow*)this, NSTreeWindow::pContexte) ;

  // on charge les tableaux Pere / Fils
  pEditFGDlg->ParsingChemin(sCheminNode, true) ;
  pEditFGDlg->ParsingChemin(sEnsembleFils, false) ;
  pEditFGDlg->Execute() ;

  delete pEditFGDlg ;
}


void
NSCsVue::Encyclop()
{
	// Localisation du noeud qui poss�de le focus
	TTreeNode  noeud        = GetSelection() ;
	NSTreeNode *pNSTreeNode = GetNSTreeNode(&noeud) ;

	if ((NULL == pNSTreeNode) || (string("") == pNSTreeNode->sUrl))
    return ;

	NSSuper *pSuper = NSTreeWindow::pContexte->getSuperviseur() ;

	string sClassif ;
	string sTemp = pNSTreeNode->getEtiquette() ;
	pSuper->getDico()->donneCodeSens(&sTemp, &sClassif);

	// Si ce n'est pas une classification, on navigue directement
  //
	if (false == pSuper->getFilGuide()->VraiOuFaux(sClassif, "ES", "0CODE"))
	{
		NSTreeWindow::pContexte->getSuperviseur()->NavigationEncyclopedie(pNSTreeNode->sUrl, NSTreeWindow::pContexte) ;
		return ;
	}

  string sLink = pNSTreeNode->sUrl ;
  size_t pos = sLink.find(sClassif) ;
  if (string::npos == pos)
  	NSTreeWindow::pContexte->getSuperviseur()->NavigationEncyclopedie(pNSTreeNode->sUrl, NSTreeWindow::pContexte) ;

  string sCode = pNSTreeNode->code ;
  if (strlen(sLink.c_str()) > pos - strlen(sClassif.c_str()))
  	sLink = string(sLink, 0, pos) + sCode + string(sLink, pos + strlen(sClassif.c_str()), strlen(sLink.c_str()) - pos - strlen(sClassif.c_str())) ;
  else
		sLink = string(sLink, 0, pos) + sCode ;
    
  NSTreeWindow::pContexte->getSuperviseur()->NavigationEncyclopedie(sLink, NSTreeWindow::pContexte) ;
}


void
NSCsVue::Cm1Plus()
{
  // Localisation du noeud qui poss�de le focus
  TTreeNode   noeud         = GetSelection() ;
  NSTreeNode  *pNSTreeNode  = GetNSTreeNode(&noeud) ;
  if (NULL == pNSTreeNode)
    return ;

  if (pNSTreeNode->getCertitude() == "B")
    pNSTreeNode->fixeInteret("A") ;
  else
    pNSTreeNode->fixeInteret("B") ;
}


void
NSCsVue::Cm2Plus()
{
  // Localisation du noeud qui poss�de le focus
  TTreeNode   noeud         = GetSelection() ;
  NSTreeNode  *pNSTreeNode  = GetNSTreeNode(&noeud) ;
	if (!pNSTreeNode)
   	return ;

  if (pNSTreeNode->getCertitude() == "C")
    pNSTreeNode->fixeInteret("A") ;
  else
    pNSTreeNode->fixeInteret("C") ;
}


void
NSCsVue::Cm3Plus()
{
  // Localisation du noeud qui poss�de le focus
  TTreeNode   noeud         = GetSelection() ;
  NSTreeNode  *pNSTreeNode  = GetNSTreeNode(&noeud) ;
	if (!pNSTreeNode)
   	return ;

  if (pNSTreeNode->getCertitude() == "D")
    pNSTreeNode->fixeInteret("A") ;
  else
    pNSTreeNode->fixeInteret("D") ;
}


void
NSCsVue::Cm4Plus()
{
  // Localisation du noeud qui poss�de le focus
  TTreeNode   noeud         = GetSelection() ;
  NSTreeNode  *pNSTreeNode  = GetNSTreeNode(&noeud) ;
  if (!pNSTreeNode)
    return ;

  if (pNSTreeNode->getCertitude() == "E")
    pNSTreeNode->fixeInteret("A") ;
  else
    pNSTreeNode->fixeInteret("E") ;
}


void
NSCsVue::Ce1Plus(TCommandEnabler& ce)
{
  uint result = 0 ;

  // Localisation du noeud qui poss�de le focus
  TTreeNode   noeud         = GetSelection() ;
  NSTreeNode  *pNSTreeNode  = GetNSTreeNode(&noeud) ;
  if (!pNSTreeNode)
    return ;

  if (pNSTreeNode->getCertitude() == "B")
    result = 1 ;

  ce.SetCheck(result  ? TCommandEnabler::Checked : TCommandEnabler::Unchecked) ;
}


void
NSCsVue::Ce2Plus(TCommandEnabler& ce)
{
  uint result = 0 ;

  // Localisation du noeud qui poss�de le focus
  TTreeNode   noeud         = GetSelection() ;
  NSTreeNode  *pNSTreeNode  = GetNSTreeNode(&noeud) ;
  if (!pNSTreeNode)
    return ;

  if (pNSTreeNode->getCertitude() == "C")
    result = 1 ;

  ce.SetCheck(result  ? TCommandEnabler::Checked : TCommandEnabler::Unchecked) ;
}


void
NSCsVue::Ce3Plus(TCommandEnabler& ce)
{
  uint result = 0 ;

  // Localisation du noeud qui poss�de le focus
  TTreeNode   noeud         = GetSelection() ;
  NSTreeNode  *pNSTreeNode  = GetNSTreeNode(&noeud) ;
  if (!pNSTreeNode)
    return ;

  if (pNSTreeNode->getCertitude() == "D")
    result = 1 ;

  ce.SetCheck(result  ? TCommandEnabler::Checked : TCommandEnabler::Unchecked) ;
}


void
NSCsVue::Ce4Plus(TCommandEnabler& ce)
{
  uint result = 0 ;

  // Localisation du noeud qui poss�de le focus
  TTreeNode   noeud = GetSelection() ;
  NSTreeNode  *pNSTreeNode = GetNSTreeNode(&noeud) ;
  if (!pNSTreeNode)
    return ;

  if (pNSTreeNode->getCertitude() == "E")
    result = 1 ;

  ce.SetCheck(result  ? TCommandEnabler::Checked : TCommandEnabler::Unchecked) ;
}


void
NSCsVue::CmFileClose()
{
  // On d�truit dans ce cas la partie NSRefDocument avant de d�truire la vue
  NSTreeWindow::GetApplication()->GetDocManager()->CmFileClose() ;
}


// -----------------------------------------------------------------------------
// Fonction de r�ponse � la commande Composer
// -----------------------------------------------------------------------------
void
NSCsVue::CmComposer()
{
	NSCSDocument  *CSDoc = dynamic_cast<NSCSDocument *>(pDoc) ;

  if (CSDoc->pHtmlCS)
  	delete CSDoc->pHtmlCS ;

  // htmlNode racine du html de consultation
  CSDoc->pHtmlCS = new NSHtml(tCS) ;

  InscrireHtml(CSDoc->pHtmlCS) ;

  if (!bConsultVide)
  	CSDoc->Composer() ;
  else
  	NSTreeWindow::MessageBox("Le document est vide.") ;
}

void
NSCsVue::initMUEViewMenu(string sMenuName){	if (pMUEViewMenu)  	delete pMUEViewMenu ;

	nsMenuIniter menuIter(NSTreeWindow::pContexte) ;
	pMUEViewMenu = new OWL::TMenuDescr ;
  menuIter.initMenuDescr(pMUEViewMenu, sMenuName) ;

	return ;}voidNSCsVue::activateMUEViewMenu(){	if (!pMUEViewMenu)		return ;

	TMyApp* pMyApp = NSTreeWindow::pContexte->getSuperviseur()->getApplication() ;
  pMyApp->GetMainWindow()->SetMenuDescr(*pMUEViewMenu) ;
	return ;
}
