//---------------------------------------------------------------------------
#ifndef AutoWordH
#define AutoWordH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>

class NSAutoWordView;

//---------------------------------------------------------------------------
class TAutoWordForm : public TForm
{
__published:	// IDE-managed Components
    TButton *ArchiverButton;
    TButton *PublierButton;
    TButton *EditerButton;
    TButton *FormulesButton;
    TButton *QuitterButton;
    void __fastcall ArchiverButtonClick(TObject *Sender);
    void __fastcall PublierButtonClick(TObject *Sender);
    void __fastcall ComposerButtonClick(TObject *Sender);
    void __fastcall EditerButtonClick(TObject *Sender);
    void __fastcall FormulesButtonClick(TObject *Sender);
    void __fastcall QuitterButtonClick(TObject *Sender);
    void __fastcall VisualiserButtonClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    NSAutoWordView* pView;
    __fastcall TAutoWordForm(TComponent* Owner);
               TAutoWordForm(HWND Parent, NSAutoWordView* View): TForm(Parent)
                { pView = View; }
};
//---------------------------------------------------------------------------
extern PACKAGE TAutoWordForm *AutoWordForm;
//---------------------------------------------------------------------------
#endif
