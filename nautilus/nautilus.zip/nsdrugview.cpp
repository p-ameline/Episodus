// -----------------------------------------------------------------------------// nsdrugview.cpp
// -----------------------------------------------------------------------------
// $Revision: 1.50 $
// $Author: pameline $
// $Date: 2005/06/30 16:27:23 $
// -----------------------------------------------------------------------------
// Vue Document/Vues de gestion du m�dicament
// Doc/View View for drug management
// -----------------------------------------------------------------------------
// modif FLP - mars 2004
// PA  - juillet 2003
// -----------------------------------------------------------------------------
#if !defined(OWL_LISTWIND_H)
# include <owl/listwind.h>
#endif

#include <owl/uihelper.h>
#include <owl\owlpch.h>
#include <owl\validate.h>
#include <owl\inputdia.h>

#include "nautilus\nssuper.h"#include "partage\nsdivfct.h"
#include "nautilus\nsdrugview.h"
#include "nautilus\nshistdo.h"
#include "nautilus\nsldvvue.rh"
#include "nssavoir\nsgraphe.h"
#include "nsbb\nsmedicdlg.h"
#include "nsbb\nspanesplitter.h"
#include "nsbb\nsattvaltools.h"
#include "dcodeur\decoder.h"

bool
drugSortByNameInf(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
	return (pseumaj(pDrug1->sTitre) < pseumaj(pDrug2->sTitre)) ;
}

bool
drugSortByNameSup(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
	return (pseumaj(pDrug1->sTitre) > pseumaj(pDrug2->sTitre)) ;
}

bool
drugSortByAdminInf(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
	return ((true == pDrug1->_bALD) && (false == pDrug2->_bALD)) ;
}

bool
drugSortByAdminSup(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
	return ((false == pDrug1->_bALD) && (true == pDrug2->_bALD)) ;
}

bool
drugSortByDurationInf(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
	return (getDuration(pDrug1) < getDuration(pDrug2)) ;
}

bool
drugSortByDurationSup(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
	return (getDuration(pDrug1) > getDuration(pDrug2)) ;
}

bool
drugSortByBeginInf(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
	return (pDrug1->tDateOuverture < pDrug2->tDateOuverture) ;
}

bool
drugSortByBeginSup(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
	return (pDrug1->tDateOuverture > pDrug2->tDateOuverture) ;
}

bool
drugSortByEndInf(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
	return (pDrug1->tDateFermeture < pDrug2->tDateFermeture) ;
}

bool
drugSortByEndSup(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
	return (pDrug1->tDateFermeture > pDrug2->tDateFermeture) ;
}

bool
drugSortByPrescrEndInf(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
  NSLdvDrugPhase* pPhase1 = pDrug1->getCurrentActivePhase() ;
  NSLdvDrugPhase* pPhase2 = pDrug2->getCurrentActivePhase() ;

  if (NULL == pPhase1)
    return true ;
  if (NULL == pPhase2)
    return false ;

	return (pPhase1->tDateFermeture < pPhase2->tDateFermeture) ;
}

bool
drugSortByPrescrEndSup(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
  NSLdvDrugPhase* pPhase1 = pDrug1->getCurrentActivePhase() ;
  NSLdvDrugPhase* pPhase2 = pDrug2->getCurrentActivePhase() ;

  if (NULL == pPhase2)
    return true ;
  if (NULL == pPhase1)
    return false ;

	return (pPhase1->tDateFermeture > pPhase2->tDateFermeture) ;
}

bool
drugSortByPrescrDateInf(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
	return (getPrescriptionDate(pDrug1) < getPrescriptionDate(pDrug2)) ;
}

bool
drugSortByPrescrDateSup(NSLdvDrug *pDrug1, NSLdvDrug *pDrug2)
{
	return (getPrescriptionDate(pDrug1) > getPrescriptionDate(pDrug2)) ;
}

// -----------------------------------------------------------------------------
//
// Class NSDrugView
//
// -----------------------------------------------------------------------------

const int ID_DrugList = 0x100 ;
// Table de r�ponses de la classe NSDrugView

DEFINE_RESPONSE_TABLE1(NSDrugView, NSLDVView)
  EV_VN_ISWINDOW,
  EV_LVN_GETDISPINFO(ID_DrugList, DispInfoListe),
  EV_LVN_COLUMNCLICK(ID_DrugList, LVNColumnclick),
  EV_WM_SIZE,
  EV_WM_SETFOCUS,
  EV_WM_RBUTTONDOWN,
  EV_COMMAND(CM_DRUG_NEW,         CmAdd),
  EV_COMMAND(CM_REFERENTIAL,      CmFct3),
  EV_COMMAND(IDC_NEW_REF,         CmFct5),
  EV_COMMAND(IDC_ADD_TO_REF,      CmFct6),
  EV_COMMAND(CM_DRUG_RENEW,       CmContinue),
  EV_COMMAND(CM_DRUG_CHANGE,      CmChange),
  EV_COMMAND(CM_DRUG_MODIF_POSO,  CmModifPoso),
  EV_COMMAND(CM_DRUG_STOP,        CmClose),
  EV_COMMAND(CM_DRUG_DELETE,      CmSuppress),
  EV_COMMAND(IDC_ORDONNANCE,      CmFct1),
  EV_COMMAND(IDC_ORDO_SEL,        CmFct4),
  EV_COMMAND(IDC_MANAGE_RIGHTS,   CmRights),
END_RESPONSE_TABLE ;

// Constructeur
NSDrugView::NSDrugView(NSLdvDocument &doc, string sConcern)
//  : NSMUEView(pCtx, &doc, parent, string("DrugManagement"), sPreoccu)
  : NSLDVView(doc.pContexte, &doc, 0, string("DrugManagement"), string("LdvDoc"), sConcern)
{
try
{
  Attr.AccelTable = DRUGS_ACCEL ;

  pLdVDoc       = &doc ;
  pListeWindow  = new NSDrugsPropertyWindow(this, ID_DrugList, 0, 0, 0, 0) ;

	initMUEViewMenu("menubar_drug") ;

  pToolBar      = 0 ;
  bSetupToolBar = true ;
  uButtonsStyle = MYWS_ICONS ;

  iSortedColumn = -1 ;

  // Initialisation des m�dicaments actifs
  initCurentDrugs() ;

	setViewName() ;
}
catch (...)
{
  erreur("Exception NSDrugView ctor.", standardError, 0) ;
  return ;
}
}

// Destructeur
NSDrugView::~NSDrugView()
{
}

void
NSDrugView::setViewName()
{
	sViewName = pContexte->getSuperviseur()->getText("drugManagement", "drugManagement") ;

  addConcernTitle() ;
}

// GetWindow renvoie this (� red�finir car virtual dans TView)
TWindow
*NSDrugView::GetWindow()
{
  return (TWindow *) this ;
}

// Appel de la fonction de remplissage de la vuevoid
NSDrugView::SetupWindow()
{
  NSMUEView::SetupWindow() ;
  Parent->SetCaption(sViewName.c_str()) ;

  SetupColumns() ;
  AfficheListe() ;
}

void
NSDrugView::CmAdd()
{
/*
try
{
	if (!(pContexte->userHasPrivilege(NSContexte::createDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

	string sChoixMed ;

	//NSNewTrt        *pNewTrtDlg = new NSNewTrt(this, &sChoixMed, sPreoccup, pContexte, "GPRSC1") ;
	///	if (pNewTrtDlg->Execute() == IDCANCEL)
	//	return ;
	//if (sChoixMed == "")
	// return ;

	NSPatPathoArray PPT(pContexte) ;
  //pPPT->ajoutePatho(sChoixMed, 0, 0) ;

	// NSMedicDlg      *pMedicDlg  = new NSMedicDlg(this, pContexte, pPPT) ;
  // if (pMedicDlg->Execute() != IDOK)
  // {
  //    delete pPPT ;
  //    return ;
  // }
  // delete pMedicDlg ;

  NSMedicamentDlg *pMedicDlg  = new NSMedicamentDlg(this, pContexte, &PPT) ;
  int iResult = pMedicDlg->Execute() ;
  delete (pMedicDlg) ;

  if (iResult != IDOK)
  	return ;

  // NSSmallBrother  *pBigBoss = new NSSmallBrother(pContexte, pPPT, 0, false) ;
  // pBigBoss->pFenetreMere    = pContexte->GetMainWindow() ;
  // pBigBoss->lance12("GPRSC1", sChoixMed) ;
  // delete pBigBoss ;

	// on enregistre ici dans l'index de sant�
	if (!(PPT.empty()))
		pContexte->getPatient()->CreeTraitement(&PPT, sPreoccup) ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSDrugView::CmNouveau : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
}
catch (...)
{
  erreur("Exception NSDrugView::CmNouveau.", standardError, 0) ;
}
*/

	VecteurString RelatedConcerns ;
  if (sPreoccup != string(""))
  	RelatedConcerns.push_back(new string(sPreoccup)) ;

	pLdVDoc->DrugNewService(this, string(""), &RelatedConcerns) ;

}

void
NSDrugView::CmFct3()
{
	VecteurString RelatedConcerns ;
  if (sPreoccup != string(""))
  	RelatedConcerns.push_back(new string(sPreoccup)) ;

	pLdVDoc->DrugFromProtocolService(this, &RelatedConcerns) ;
}

void
NSDrugView::CmAddWithCode(string sLexiCode)
{
/*
try
{
  if (sLexiCode == "")
  {
    CmNouveau() ;
    return ;
  }

  NSPatPathoArray PPT(pContexte) ;
  PPT.ajoutePatho(sLexiCode, 0, 0) ;

  NSMedicamentDlg *pMedicDlg  = new NSMedicamentDlg(this, pContexte, &PPT) ;
  int iResult = pMedicDlg->Execute() ;
  delete pMedicDlg ;

  if (iResult != IDOK)
    return ;

  // on enregistre ici dans l'index de sant�
  if (!(PPT.empty()))
    pContexte->getPatient()->CreeTraitement(&PPT, sPreoccup) ;
}
catch (...)
{
  erreur("Exception NSDrugView::CmAddWithCode(string).", standardError, 0) ;
  return ;
}
*/

	VecteurString RelatedConcerns ;
  if (sPreoccup != string(""))
  	RelatedConcerns.push_back(new string(sPreoccup)) ;

	pLdVDoc->DrugNewService(this, sLexiCode, &RelatedConcerns) ;
}

void
NSDrugView::CmContinue()
{
/*
	if (!(pContexte->userHasPrivilege(NSContexte::modifyDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

	int index = pListeWindow->IndexItemSelect() ;

	if (index == -1)
	{
		erreur("Vous devez s�lectionner un m�dicament � renouveler dans la liste des m�dicaments en cours.", standardError, 0) ;
		return ;
	}

	string sNodeModif = (aCurrentDrugs[index])->getNoeud() ;

	VecteurString NodeMedic ;
	NodeMedic.push_back(new string(sNodeModif)) ;

	NSPatPathoArray PPT(pContexte) ;

	NSRenewMedicDlg* pRenewMedicDlg = new NSRenewMedicDlg(this, pContexte, &PPT);
  int iResult = pRenewMedicDlg->Execute() ;
  delete pRenewMedicDlg ;

	if (iResult == IDCANCEL)
		return ;

	// on renouvelle la pr�c�dente prescription
	pContexte->getPatient()->RenouvelerTraitement(&NodeMedic, &PPT) ;

	initCurentDrugs() ;
	AfficheListe() ;
*/

	string sNodeToAlter = getDrugRefToModify() ;
  if (sNodeToAlter != string(""))
  	pLdVDoc->DrugRenewService(this, sNodeToAlter) ;
}

/*void
NSDrugView::autoAddInDrugView(string sConcern, NSPatPathoArray *pPPT)  */

void
NSDrugView::autoAddInDrugView(string sConcern)
{

  if ((!pContexte->getSuperviseur()->pBufCopie) ||
      (!pContexte->getSuperviseur()->pBufCopie->pPatPatho))
  	return ;

  NSPatPathoArray *pPPT = pContexte->getSuperviseur()->pBufCopie->pPatPatho ;
  if (pPPT->empty())
  	return ;

	VecteurString NodeConcern ;
	NodeConcern.push_back(new string(sConcern)) ;
	pContexte->getPatient()->CreeTraitement(pPPT, &NodeConcern) ;

  initCurentDrugs() ;
	AfficheListe() ;
}

void
NSDrugView::CmChange()
{
/*
	if (!(pContexte->userHasPrivilege(NSContexte::modifyDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

  int index = pListeWindow->IndexItemSelect() ;

  // if (pConcern == 0)
  // {
  //   erreur("Le m�dicament doit �tre rattach� � une pr�occupation particuli�re.", 0, 0) ;
  //   return ;
  // }

  if (index == -1)
  {
    erreur("Vous devez s�lectionner un m�dicament � modifier dans la liste des m�dicaments en cours.", standardError, 0) ;
    return ;
  }

  string sNodeModif, sCodeModif ;
  NSPatPathoArray PPT(pContexte) ;

  sNodeModif = (aCurrentDrugs[index])->getNoeud() ;
  sCodeModif = (aCurrentDrugs[index])->getLexique() ;

  // r�cup�ration de la date du jour au format AAAAMMJJ

  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

  // char szDateJour[10] ;
  // donne_date_duJour(szDateJour) ;

  // on r�cup�re d'abord la sous-patpatho du noeud � modifier
  NSPatPathoArray SousPPT(pContexte) ;
  pContexte->getPatient()->DonneSousArray(sNodeModif, &SousPPT) ;
  // on reconstitue la patpatho � partir du noeud
  PPT.ajoutePatho(sCodeModif, 0, 1) ;
  // Insertion en queue (iter doit �tre ici egal � end())
  PPT.InserePatPatho(PPT.end(), &SousPPT, 1) ;

  // La patpatho source est constitu�e. On doit maintenant remplacer l'ancienne
  // date d'ouverture par la date du jour (car les modifs �ventuelles datent de ce jour)
  PatPathoIter pptIt = PPT.begin() ;
  // Recherche de la date d'ouverture en sous-niveau du noeud  //  PatPathoIter pptItValeur ;  bool bDateTrouvee = false ;  int iColBase = (*pptIt)->pDonnees->getColonne() ;  pptIt++ ;  while ((pptIt != PPT.end()) && ((*pptIt)->getColonne() > iColBase))  {
    string sElemLex = (*pptIt)->getLexique() ;
    string sSens ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    if ((*pptIt)->getColonne() == iColBase + 1)
    {
      // Dates
      if (sSens == "KOUVR")
      {
        pptIt++ ;
        int iLigneBase = (*pptIt)->getLigne() ;
        string sUnite  = "" ;
        string sFormat = "" ;
        string sValeur = "" ;
        string sTemp   = "" ;

        while ( (pptIt != PPT.end()) &&
                ((*pptIt)->getLigne() == iLigneBase))
        {
          if (((*pptIt)->pDonnees->lexique)[0] == '�')
          {
            sTemp   = (*pptIt)->getLexique() ;
            pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
            sValeur = (*pptIt)->getComplement() ;
            sTemp   = (*pptIt)->getUnit() ;
            pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
            pptItValeur = pptIt ;
            break ;
          }
          pptIt++;
        }

        // sFormat est du type �D0;03
        if ((sFormat != "") && (sFormat[1] == 'D') && (sValeur != ""))
        {
          if ((sUnite == "2DA01") || (sUnite == "2DA02"))
          {
            // on remplace la date d'ouverture par la date du jour
            strcpy((*pptItValeur)->pDonnees->complement, tpsNow.donneDateHeure().c_str()) ;

            bDateTrouvee = true ;
          }
        }
      }
      else
        pptIt++ ;
    }
    else
      pptIt++ ;
  }

  if (!bDateTrouvee)
  {
    erreur("Le m�dicament � modifier ne comporte pas de date d'ouverture.", standardError, 0) ;
    return ;
  }

  // on cr�e une copie
  NSPatPathoArray PPTCopy(PPT) ;

  // NSSmallBrother  *pBigBoss = new NSSmallBrother(pContexte, pPPT, 0, false /- initFromBbk -/) ;
  // pBigBoss->pFenetreMere = pContexte->GetMainWindow() ;
  // on lance l'archetype li� au code m�dicament (avec fil guide associ�)
  // pBigBoss->lance12("GPRSC1", sCodeModif) ;
  // delete pBigBoss ;
  // NSMedicDlg  NSMedicamentDlg *pMedicDialog = new NSMedicamentDlg(pContexte->GetMainWindow(), pContexte, &PPT) ;     //FIXME TABUN  int iResult = pMedicDialog->Execute() ;  delete pMedicDialog ;  if (iResult != IDOK)    return ;  // Si aucune modif : on sort...  if (PPT.estEgal(&PPTCopy))    return ;  // on cloture la pr�c�dente prescription  //pContexte->getPatient()->ArreterElement(sNodeModif, string(szDateJour)) ;  // on enregistre la nouvelle prescription dans l'index de sant� // if (!(pPPT->empty()))

  //delete pBigBoss ;  VecteurString NodeArret ;
  NodeArret.push_back(new string(sNodeModif)) ;  // on cloture la pr�c�dente prescription  // pContexte->getPatient()->ArreterElement(pNodeArret, string(szDateJour)) ;  pContexte->getPatient()->ArreterElement(&NodeArret, tpsNow.donneDateHeure()) ;  // on enregistre la nouvelle prescription dans l'index de sant�  if (!(PPT.empty()))
    pContexte->getPatient()->CreeTraitement(&PPT, sPreoccup) ;

  initCurentDrugs() ;
  AfficheListe() ;
*/

	string sNodeToAlter = getDrugRefToModify() ;
  if (sNodeToAlter != string(""))
  	pLdVDoc->DrugModifyService(this, sNodeToAlter) ;
}

void
NSDrugView::CmModifPoso()
{
	string sNodeToAlter = getDrugRefToModify() ;
  if (sNodeToAlter != string(""))
  	pLdVDoc->DrugChangePosoService(this, sNodeToAlter) ;
}

void
NSDrugView::CmClose()
{
/*
	if (!(pContexte->userHasPrivilege(NSContexte::modifyDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

  int index = pListeWindow->IndexItemSelect() ;

  if (index == -1)
  {
    erreur("Vous devez s�lectionner un m�dicament � arr�ter dans la liste des m�dicaments en cours.", standardError, 0) ;
    return ;
  }

  int retVal = ::MessageBox(0, "Etes-vous s�r de vouloir arr�ter ce traitement ?", "Message Nautilus", MB_YESNO) ;
  if (retVal == IDNO)
    return ;

  string sNodeModif = (aCurrentDrugs[index])->getNoeud() ;
  VecteurString NodeArret ;
  NodeArret.push_back(new string(sNodeModif)) ;

  // r�cup�ration de la date du jour au format AAAAMMJJ
  // char szDateJour[10] ;
  // donne_date_duJour(szDateJour) ;  NVLdVTemps tpsNow ;  tpsNow.takeTime() ;  // on cloture la pr�c�dente prescription  // pContexte->getPatient()->ArreterElement(pNodeArret, string(szDateJour)) ;
  pContexte->getPatient()->ArreterElement(&NodeArret, tpsNow.donneDateHeure()) ;

  initCurentDrugs() ;
  AfficheListe() ;
*/

	string sWarningMsg = pContexte->getSuperviseur()->getText("drugManagementWarnings", "doYouReallyWantToStopThisPrescription") ;

	string sNodeToAlter = getDrugRefToModify(sWarningMsg) ;
  if (sNodeToAlter != string(""))
  	pLdVDoc->DrugStopService(this, sNodeToAlter) ;
}

void
NSDrugView::CmSuppress()
{
/*
	if (!(pContexte->userHasPrivilege(NSContexte::modifyDrug, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

  int index = pListeWindow->IndexItemSelect() ;

  if (index == -1)
  {
    erreur("Vous devez s�lectionner un m�dicament � supprimer dans la liste des m�dicaments en cours.", standardError, 0) ;
    return ;
  }

  int retVal = ::MessageBox(0, "Etes-vous s�r de vouloir supprimer ce traitement ?", "Message Nautilus", MB_YESNO) ;
  if (retVal == IDNO)
    return ;

  string sNodeModif = (aCurrentDrugs[index])->getNoeud() ;

  pContexte->getPatient()->SupprimerElement(sNodeModif) ;
  pLdVDoc->getDrugs()->deleteDrug(aCurrentDrugs[index]) ;

  initCurentDrugs() ;
  AfficheListe() ;
*/

  string sWarningMsg = pContexte->getSuperviseur()->getText("drugManagementWarnings", "doYouReallyWantToDeleteThisPrescription") ;

	string sNodeToAlter = getDrugRefToModify(sWarningMsg) ;
  if (sNodeToAlter != string(""))
		pLdVDoc->DrugDeleteService(this, sNodeToAlter) ;
}

void
NSDrugView::CmFct1()
{
	// pContexte->getPatient()->CreeOrdonnance(true) ;
  pLdVDoc->DrugCreatePrescriptionService(this) ;
  AfficheListe() ;
}

void
NSDrugView::CmFct4()
{
	VecteurString aRefStrings ;

	int count = pListeWindow->GetItemCount() ;

	for (int i = 0 ; i < count ; i++)  	if (pListeWindow->GetItemState(i, LVIS_SELECTED))
    	aRefStrings.push_back(new string((aCurrentDrugs[i])->getNoeud())) ;

  pLdVDoc->DrugCreatePrescriptionForSelectionService(this, &aRefStrings) ;
  AfficheListe() ;
}

// Create new guideline file from selection
//
void
NSDrugView::CmFct5()
{
	VecteurString aRefStrings ;

	int count = pListeWindow->GetItemCount() ;

	for (int i = 0 ; i < count ; i++)  	if (pListeWindow->GetItemState(i, LVIS_SELECTED))
    	aRefStrings.push_back(new string((aCurrentDrugs[i])->getNoeud())) ;

  pLdVDoc->DrugCreateProtocolForSelectionService(this, &aRefStrings) ;
  AfficheListe() ;
}

// Add selection to existing guideline file
//
void
NSDrugView::CmFct6()
{
	VecteurString aRefStrings ;

	int count = pListeWindow->GetItemCount() ;

	for (int i = 0 ; i < count ; i++)  	if (pListeWindow->GetItemState(i, LVIS_SELECTED))
    	aRefStrings.push_back(new string((aCurrentDrugs[i])->getNoeud())) ;

  pLdVDoc->DrugAddToProtocolForSelectionService(this, &aRefStrings) ;
  AfficheListe() ;
}

void
NSDrugView::CmRights()
{
	int index = pListeWindow->IndexItemSelect() ;

  if (index == -1)
    return ;

  string sNodeModif = (aCurrentDrugs[index])->getNoeud() ;
  pLdVDoc->manageRights(this, sNodeModif) ;
}

void
NSDrugView::reloadView(string sReason)
{
  initCurentDrugs() ;
  AfficheListe() ;
}


void
NSDrugView::initCurentDrugs()
{
  aCurrentDrugs.vider() ;

  ArrayLdvDrugs *pDrugs = pLdVDoc->getDrugs() ;
  if (pDrugs->empty())
    return ;

  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

  for (drugsIter itDg = pDrugs->begin() ; itDg != pDrugs->end() ; itDg++)
  {
    if (((*itDg)->tDateFermeture.estNoLimit()) || ((*itDg)->tDateFermeture >= tpsNow))
    {
      if ((sPreoccup == "") || ((*itDg)->bIsLinkedConcern(sPreoccup)))
        aCurrentDrugs.push_back(*itDg) ;
    }
  }
}

// Initialisation des colonnes de la ListWindowvoid
NSDrugView::SetupColumns()
{
	string sDrugName  = pContexte->getSuperviseur()->getText("drugManagement", "drugName") ;
  string sDrugDose  = pContexte->getSuperviseur()->getText("drugManagement", "drugDose") ;
  string sDrugDurat = pContexte->getSuperviseur()->getText("drugManagement", "duration") ;
  string sAdminInfo = pContexte->getSuperviseur()->getText("drugManagement", "adminInformation") ;
  string sStartDate = pContexte->getSuperviseur()->getText("drugManagement", "startingDate") ;
  string sEndDate   = pContexte->getSuperviseur()->getText("drugManagement", "endingDate") ;
  string sPrEndDate = pContexte->getSuperviseur()->getText("drugManagement", "prescriptionEndingDate") ;
  string sPrescDate = pContexte->getSuperviseur()->getText("drugManagement", "prescriptionDate") ;

  pListeWindow->InsertColumn(0, TListWindColumn((char*)sDrugName.c_str(), 300, TListWindColumn::Left, 0)) ;
  pListeWindow->InsertColumn(1, TListWindColumn((char*)sDrugDose.c_str(),  65, TListWindColumn::Left, 1)) ;
  pListeWindow->InsertColumn(2, TListWindColumn((char*)sDrugDurat.c_str(), 65, TListWindColumn::Left, 2)) ;
  pListeWindow->InsertColumn(3, TListWindColumn((char*)sAdminInfo.c_str(), 40, TListWindColumn::Left, 3)) ;
  pListeWindow->InsertColumn(4, TListWindColumn((char*)sStartDate.c_str(), 80, TListWindColumn::Left, 4)) ;
  pListeWindow->InsertColumn(5, TListWindColumn((char*)sEndDate.c_str(),   80, TListWindColumn::Left, 5)) ;
  pListeWindow->InsertColumn(6, TListWindColumn((char*)sPrEndDate.c_str(), 80, TListWindColumn::Left, 6)) ;
  pListeWindow->InsertColumn(7, TListWindColumn((char*)sPrescDate.c_str(), 90, TListWindColumn::Left, 7)) ;
}

// Affichage des �l�ments de la listevoid
NSDrugView::AfficheListe()
{
  pListeWindow->DeleteAllItems() ;

  if (aCurrentDrugs.empty())
    return ;

  // Attention : insert ins�re au dessus ; il faut inscrire les derniers en premier
  drugsIter itDg = aCurrentDrugs.end() ;
  do
  {
    itDg-- ;
    TListWindItem Item(((*itDg)->sTitre).c_str(), 0) ;
    pListeWindow->InsertItem(Item) ;
	}
  while (itDg != aCurrentDrugs.begin()) ;
}

void
NSDrugView::DispInfoListe(TLwDispInfoNotify& dispInfo)
{
  const int       BufLen = 1024 ;
  static char     buffer[BufLen] ;
  TListWindItem   &dispInfoItem = *(TListWindItem *)&dispInfo.item ;
  char            szDate[25] ;
  buffer[0] = '\0' ;

  int index = dispInfoItem.GetIndex() ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  NSLdvDrugPhase* pPhase = (aCurrentDrugs[index])->getCurrentActivePhase() ;

  NSLdvDrugPhase* pLastPhase = 0 ;
  if (NULL == pPhase)
    pLastPhase = (aCurrentDrugs[index])->getLastActivePhase() ;

  // Affiche les informations en fonction de la colonne  switch (dispInfoItem.GetSubItem())
  {
    case 1  : // dose

      if (NULL != pPhase)
      {
        strcpy(buffer, pPhase->sTitreCourt.c_str()) ;
        dispInfoItem.SetText(buffer) ;
      }
      else if (NULL != pLastPhase)
      {
        string sShortTitle = string("(") + pLastPhase->sTitreCourt + string(")") ;
        strcpy(buffer, sShortTitle.c_str()) ;
        dispInfoItem.SetText(buffer) ;
      }
      break ;

    case 2  : // dur�e
    {
      unsigned long ulDeltaDays = getDuration(aCurrentDrugs[index]) ;
      if ((unsigned long) 0 == ulDeltaDays)
        return ;

      string sNumberOf = string("") ;
      string sDeltaDays = IntToString((int)ulDeltaDays) ;

      GlobalDkd Dcode(pContexte, sLang) ;
      string sUnitCode = string("2DAT01") ;
      if (ulDeltaDays > 1)
        sUnitCode += string(1, intranodeSeparationMARK) + string("WPLUR1") ;
      int iGenreObj, iCertObj ;
      string sUnitLib = Dcode.decodeMot(&sUnitCode, 1, &iGenreObj, &iCertObj) ;

      sNumberOf = sDeltaDays + string(" ") + sUnitLib ;

      if (NULL == pPhase)
        sNumberOf = string("(") + sNumberOf + string(")") ;

      strcpy(buffer, sNumberOf.c_str()) ;
      dispInfoItem.SetText(buffer) ;
    }
    break ;

    case 3  : // ALD, etc

      if (true == (aCurrentDrugs[index])->_bALD)
      {
        strcpy(buffer, "ALD") ;
        dispInfoItem.SetText(buffer) ;
      }
      break ;

    case 4  : // date d�but

    	strcpy(szDate, (aCurrentDrugs[index])->tDateOuverture.donneDate().c_str()) ;
      donne_date(szDate, buffer, sLang) ;
      dispInfoItem.SetText(buffer) ;
      break ;

    case 5  : // date fin    	if ((aCurrentDrugs[index])->tDateFermeture.estNoLimit())
      	strcpy(buffer, "...") ;
      else
      {
      	strcpy(szDate, (aCurrentDrugs[index])->tDateFermeture.donneDate().c_str()) ;
        donne_date(szDate, buffer, sLang) ;
      }
      dispInfoItem.SetText(buffer) ;
      break ;

    case 6  : // date fin prescription

      if (NULL != pPhase)
      {
    	  if (false == pPhase->tDateFermeture.estVide())
        {
          NVLdVTemps tpsNow ;
          tpsNow.takeTime() ;

          GlobalDkd Dcode(pContexte, sLang) ;

          string sNumberOf = string("") ;
          unsigned long ulDeltaDays = pPhase->tDateFermeture.daysBetween(tpsNow) ;
          if (ulDeltaDays > 90)
          {
            unsigned long ulDeltaMonths = pPhase->tDateFermeture.monthsBetween(tpsNow) ;
            string sDeltaMonths = IntToString((int)ulDeltaMonths) ;
            string sUnitCode = string("2DAT21") ;
            if (ulDeltaMonths > 1)
              sUnitCode += string(1, intranodeSeparationMARK) + string("WPLUR1") ;
            int iGenreObj, iCertObj ;
            string sUnitLib = Dcode.decodeMot(&sUnitCode, 1, &iGenreObj, &iCertObj) ;
            sNumberOf = sDeltaMonths + string(" ") + sUnitLib ;
          }
          else
          {
            string sDeltaDays = IntToString((int)ulDeltaDays) ;
            string sUnitCode = string("2DAT01") ;
            if (ulDeltaDays > 1)
              sUnitCode += string(1, intranodeSeparationMARK) + string("WPLUR1") ;
            int iGenreObj, iCertObj ;
            string sUnitLib = Dcode.decodeMot(&sUnitCode, 1, &iGenreObj, &iCertObj) ;
            sNumberOf = sDeltaDays + string(" ") + sUnitLib ;
          }

      	  strcpy(szDate, pPhase->tDateFermeture.donneDate().c_str()) ;
          donne_date(szDate, buffer, sLang) ;

          if (string("") != sNumberOf)
          {
            sNumberOf = sNumberOf + string(" (") + string(buffer) + string(")") ;
            strcpy(buffer, sNumberOf.c_str()) ;
          }
        }
        dispInfoItem.SetText(buffer) ;
      }
      break ;

    case 7  : // prescription

      string sPrescriptionDate = getPrescriptionDate(aCurrentDrugs[index]) ;

      if (string("") != sPrescriptionDate)
      {
        strcpy(szDate, sPrescriptionDate.c_str()) ;
        donne_date(szDate, buffer, sLang) ;
      }

/*
			NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
			VecteurString Traitement ;
      string sNodeMedic = (aCurrentDrugs[index])->getNoeud() ;
      string sNodeRenew = pLdVDoc->getDrugs()->getLastRenewNode(sNodeMedic) ;
      if ((sNodeRenew != "") && (sNodeRenew != sNodeMedic))
      	sNodeMedic = sNodeRenew ;
      // on r�cup�re le lien �ventuel sur un traitement
      Traitement.vider() ;
      pGraphe->TousLesVrais(sNodeMedic, NSRootLink::treatmentOf, &Traitement) ;
      if (!Traitement.empty())
      {
      	// on r�cup�re le premier noeud pour avoir le code document ordonnance
        string sNodeOrdo = *(*(Traitement.begin())) ;
        string sDocOrdo = string(sNodeOrdo, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) ;

        // on recherche le pDocHis correspondant dans l'historique
        // et on affiche la date du document (en g�n�ral date de cr�ation)
        if ((pContexte->getPatient()) && (pContexte->getPatient()->pDocHis))
        {
        	DocumentIter iterDoc = pContexte->getPatient()->pDocHis->VectDocument.TrouveDocHisto(sDocOrdo) ;
          if ((iterDoc != NULL) && (iterDoc != pContexte->getPatient()->pDocHis->VectDocument.end()))
          {
          	strcpy(szDate, (*iterDoc)->GetDateDoc()) ;
            donne_date(szDate, buffer, sLang) ;
          }
        }
      }
*/
      else
      {
      	string sText = pContexte->getSuperviseur()->getText("drugManagement", "notPrescribed") ;
      	strcpy(buffer, sText.c_str()) ;
      }

      dispInfoItem.SetText(buffer) ;
			break ;
  }
}

void
NSDrugView::LVNColumnclick(TLwNotify& lwn)
{
  switch ( lwn.iSubItem )
  {
    case 0  : sortByName() ;       break ;
    case 2  : sortByDuration() ;   break ;
    case 3  : sortByAdmin() ;      break ;
    case 4  : sortByBegining() ;   break ;
    case 5  : sortByEnding() ;     break ;
    case 6  : sortByPrescrEnd() ;  break ;
    case 7  : sortByPrescrDate() ; break ;
  }
}

void
NSDrugView::sortByName()
{
  if (iSortedColumn == 0)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = 0 ;
    bNaturallySorted = true ;
  }

  if (aCurrentDrugs.empty())
    return ;

  if (bNaturallySorted)
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByNameInf) ;
  else
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByNameSup) ;

  AfficheListe() ;
}

void
NSDrugView::sortByAdmin()
{
  if (iSortedColumn == 0)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = 0 ;
    bNaturallySorted = true ;
  }

  if (aCurrentDrugs.empty())
    return ;

  if (bNaturallySorted)
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByAdminInf) ;
  else
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByAdminSup) ;

  AfficheListe() ;
}

void
NSDrugView::sortByDuration()
{
  if (iSortedColumn == 0)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = 0 ;
    bNaturallySorted = true ;
  }

  if (aCurrentDrugs.empty())
    return ;

  if (bNaturallySorted)
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByDurationInf) ;
  else
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByDurationSup) ;

  AfficheListe() ;
}

void
NSDrugView::sortByEnding()
{
  if (iSortedColumn == 2)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = 2 ;
    bNaturallySorted = true ;
  }

  if (aCurrentDrugs.empty())
    return ;

  if (bNaturallySorted)
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByEndSup) ;
  else
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByEndInf) ;

  AfficheListe() ;
}

void
NSDrugView::sortByPrescrEnd()
{
  if (iSortedColumn == 1)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = 1 ;
    bNaturallySorted = true ;
  }

  if (aCurrentDrugs.empty())
    return ;

  if (bNaturallySorted)
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByPrescrEndSup) ;
  else
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByPrescrEndInf) ;

  AfficheListe() ;
}

void
NSDrugView::sortByBegining()
{
  if (iSortedColumn == 1)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = 1 ;
    bNaturallySorted = true ;
  }

  if (aCurrentDrugs.empty())
    return ;

  if (bNaturallySorted)
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByBeginSup) ;
  else
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByBeginInf) ;

  AfficheListe() ;
}

void
NSDrugView::sortByPrescrDate()
{
  if (iSortedColumn == 1)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = 1 ;
    bNaturallySorted = true ;
  }

  if (aCurrentDrugs.empty())
    return ;

  if (bNaturallySorted)
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByPrescrDateSup) ;
  else
    sort(aCurrentDrugs.begin(), aCurrentDrugs.end(), drugSortByPrescrDateInf) ;

  AfficheListe() ;
}

boolNSDrugView::VnIsWindow(HWND hWnd){
  return (HWindow == hWnd) ;
}

// fonction permettant de prendre toute la taille de TWindow par la TListWindowvoid
NSDrugView::EvSize(uint sizeType, ClassLib::TSize& size)
{
  NSMUEView::EvSize(sizeType, size) ;
  pListeWindow->MoveWindow(GetClientRect(), true) ;
}

// fonction EVSetFocusvoid
NSDrugView::EvSetFocus(HWND hWndLostFocus)
{
	NSMUEView::EvSetFocus(hWndLostFocus);

  focusFct() ;

  pListeWindow->SetFocus() ;
}

// fonction Click droit : menu contextuel
void
NSDrugView::EvRButtonDown(uint modkeys, NS_CLASSLIB::TPoint& point)
{
	// cr�ation d'un menu popup
	NS_CLASSLIB::TPoint lp = point;

	TPopupMenu *menu = new TPopupMenu();

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	string sNewD = pSuper->getText("drugManagement", "newDrug") ;
  string sProt = pSuper->getText("drugManagement", "newDrugFromGuideline") ;
	string sStop = pSuper->getText("drugManagement", "stopThisDrug") ;
	string sKill = pSuper->getText("drugManagement", "suppresThisDrug") ;
  string sPoso = pSuper->getText("drugManagement", "modifyPosology") ;
	string sModi = pSuper->getText("drugManagement", "modifyThisDrug") ;
	string sRene = pSuper->getText("drugManagement", "renewThisDrug") ;
	string sPres = pSuper->getText("drugManagement", "buildAPrescription") ;
	string sPreS = pSuper->getText("drugManagement", "buildAPrescriptionFromSelectedDrugs") ;
  string sProN = pSuper->getText("drugManagement", "buildAProtocolFromSelectedDrugs") ;
  string sProA = pSuper->getText("drugManagement", "addSelectedDrugsToAProtocol") ;
  string sRigh = pSuper->getText("rightsManagement", "manageRights") ;

	menu->AppendMenu(MF_STRING, CM_DRUG_NEW,    sNewD.c_str()) ;
  menu->AppendMenu(MF_STRING, CM_REFERENTIAL, sProt.c_str()) ;
  menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
  menu->AppendMenu(MF_STRING, CM_DRUG_MODIF_POSO, sPoso.c_str()) ;
	menu->AppendMenu(MF_SEPARATOR, 0, 0);
	menu->AppendMenu(MF_STRING, CM_DRUG_STOP,   sStop.c_str()) ;
	menu->AppendMenu(MF_STRING, CM_DRUG_DELETE, sKill.c_str()) ;
	menu->AppendMenu(MF_STRING, CM_DRUG_CHANGE, sModi.c_str()) ;
	menu->AppendMenu(MF_STRING, CM_DRUG_RENEW,  sRene.c_str()) ;
	menu->AppendMenu(MF_SEPARATOR, 0, 0);
  menu->AppendMenu(MF_STRING, IDC_MANAGE_RIGHTS,  sRigh.c_str()) ;
  menu->AppendMenu(MF_SEPARATOR, 0, 0);
	menu->AppendMenu(MF_STRING, IDC_ORDONNANCE, sPres.c_str()) ;
	menu->AppendMenu(MF_STRING, IDC_ORDO_SEL,   sPreS.c_str()) ;
  menu->AppendMenu(MF_SEPARATOR, 0, 0);
  menu->AppendMenu(MF_STRING, IDC_NEW_REF,    sProN.c_str()) ;
  menu->AppendMenu(MF_STRING, IDC_ADD_TO_REF, sProA.c_str()) ;

	ClientToScreen(lp);
	menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow);
	delete menu;
}

void
NSDrugView::EvRButtonDownOut(uint modkeys, NS_CLASSLIB::TPoint& point)
{
	// cr�ation d'un menu popup
  NS_CLASSLIB::TPoint lp = point ;

  TPopupMenu *menu = new TPopupMenu() ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	string sNewD = pSuper->getText("drugManagement", "newDrug") ;
  string sProt = pSuper->getText("drugManagement", "newDrugFromGuideline") ;
  string sPres = pSuper->getText("drugManagement", "buildAPrescription") ;
  string sPreS = pSuper->getText("drugManagement", "buildAPrescriptionFromSelectedDrugs") ;
  string sProN = pSuper->getText("drugManagement", "buildAProtocolFromSelectedDrugs") ;
  string sProA = pSuper->getText("drugManagement", "addSelectedDrugsToAProtocol") ;

  menu->AppendMenu(MF_STRING, CM_DRUG_NEW,    sNewD.c_str()) ;
  menu->AppendMenu(MF_STRING, CM_REFERENTIAL, sProt.c_str()) ;
  menu->AppendMenu(MF_SEPARATOR, 0, 0);
  menu->AppendMenu(MF_STRING, IDC_ORDONNANCE, sPres.c_str()) ;
  menu->AppendMenu(MF_STRING, IDC_ORDO_SEL,   sPreS.c_str()) ;
	menu->AppendMenu(MF_SEPARATOR, 0, 0);
  menu->AppendMenu(MF_STRING, IDC_NEW_REF,    sProN.c_str()) ;
  menu->AppendMenu(MF_STRING, IDC_ADD_TO_REF, sProA.c_str()) ;

  ClientToScreen(lp) ;
  menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow) ;
  delete menu ;
}

void
NSDrugView::focusFct()
{
	activateMUEViewMenu() ;

  TMyApp  *pMyApp = pContexte->getSuperviseur()->getApplication() ;
  if (bSetupToolBar && (GetWindow() != pMyApp->GetToolBarWindow()))
  {
    SetupToolBar() ;
    pMyApp->SetToolBarWindow(GetWindow()) ;
  }

  pPaneSplitter->SetFrameTitle(getFunction(), sViewName) ;
  pContexte->setAideIndex("") ;
  pContexte->setAideCorps("medicaments.htm") ;
}

// SetupToolBarvoid
NSDrugView::SetupToolBar()
{
/*
	TMyApp  *pMyApp = pContexte->getSuperviseur()->getApplication() ;
  pMyApp->FlushControlBar() ;

	pMyApp->cb2->Insert(*new TButtonGadget(CM_DRUG_NEW,     CM_DRUG_NEW,    TButtonGadget::Command)) ;
  pMyApp->cb2->Insert(*new TButtonGadget(CM_DRUG_STOP,    CM_DRUG_STOP,   TButtonGadget::Command)) ;
  pMyApp->cb2->Insert(*new TButtonGadget(CM_DRUG_CHANGE,  CM_DRUG_CHANGE, TButtonGadget::Command)) ;
  pMyApp->cb2->Insert(*new TButtonGadget(CM_DRUG_RENEW,   CM_DRUG_RENEW,  TButtonGadget::Command)) ;
  pMyApp->cb2->Insert(*new TSeparatorGadget) ;
  pMyApp->cb2->Insert(*new TButtonGadget(IDC_ORDONNANCE,  IDC_ORDONNANCE, TButtonGadget::Command)) ;

  pMyApp->cb2->LayoutSession() ;
*/

	pPaneSplitter->FlushControlBar() ;

  TButtonGadget* pDrugNew  = new TButtonGadget(CM_DRUG_NEW,    CM_GENERAL_ADD,      TButtonGadget::Command) ;
  TButtonGadget* pReferen  = new TButtonGadget(CM_REFERENTIAL, CM_GENERAL_FCT3,     TButtonGadget::Command) ;
  TButtonGadget* pDrugStop = new TButtonGadget(CM_DRUG_STOP,   CM_GENERAL_CLOSE,    TButtonGadget::Command) ;
  TButtonGadget* pModiPoso = new TButtonGadget(CM_DRUG_MODIF_POSO, CM_GENERAL_FCT2, TButtonGadget::Command) ;
  TButtonGadget* pDrugChng = new TButtonGadget(CM_DRUG_CHANGE, CM_GENERAL_MODIFY,   TButtonGadget::Command) ;
  TButtonGadget* pDrugRenw = new TButtonGadget(CM_DRUG_RENEW,  CM_GENERAL_CONTINUE, TButtonGadget::Command) ;
  TButtonGadget* pOrdoDate = new TButtonGadget(IDC_ORDONNANCE, CM_GENERAL_FCT1,     TButtonGadget::Command) ;
  TButtonGadget* pOrdoSele = new TButtonGadget(IDC_ORDO_SEL,   CM_GENERAL_FCT4,     TButtonGadget::Command) ;
  TButtonGadget* pNewRefer = new TButtonGadget(IDC_NEW_REF,    CM_GENERAL_FCT5,     TButtonGadget::Command) ;
  TButtonGadget* pAddRefer = new TButtonGadget(IDC_ADD_TO_REF, CM_GENERAL_FCT6,     TButtonGadget::Command) ;
	pPaneSplitter->Insert(*pDrugNew) ;
  pPaneSplitter->Insert(*pReferen) ;
  pPaneSplitter->Insert(*new TSeparatorGadget) ;
	pPaneSplitter->Insert(*pDrugStop) ;
  pPaneSplitter->Insert(*pModiPoso) ;
	pPaneSplitter->Insert(*pDrugChng) ;
	pPaneSplitter->Insert(*pDrugRenw) ;
	pPaneSplitter->Insert(*new TSeparatorGadget) ;
	pPaneSplitter->Insert(*pOrdoDate) ;
  pPaneSplitter->Insert(*pOrdoSele) ;
  pPaneSplitter->Insert(*new TSeparatorGadget) ;
  pPaneSplitter->Insert(*pNewRefer) ;
  pPaneSplitter->Insert(*pAddRefer) ;

  pPaneSplitter->LayoutSession() ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;
	string sNewD = pSuper->getText("drugManagement", "newDrug") ;

  TTooltip* pTooltipDrugNew = new TTooltip(this) ;
	pTooltipDrugNew->Create() ;
  uint toolId = CM_DRUG_NEW + 1000 ;
  ClassLib::TRect rect = pDrugNew->GetBounds() ;
  TToolInfo ti(HWindow, rect, toolId, sNewD.c_str()) ;
  pTooltipDrugNew->AddTool(ti) ;
  pTooltipDrugNew->Activate() ;
}

string
NSDrugView::getDrugRefToModify(string sWarningMsg)
{
	int index = pListeWindow->IndexItemSelect() ;

  if (index == -1)
  {
    string sErrorMsg = pContexte->getSuperviseur()->getText("drugManagementErrors", "aDrugMustBeSelected") ;
    erreur(sErrorMsg.c_str(), warningError, 0) ;
    return string("") ;
  }

	if (sWarningMsg != string(""))
	{
  	string sWarningTitle = pContexte->getSuperviseur()->getText("generalLanguage", "warning") ;
  	int retVal = ::MessageBox(0, sWarningMsg.c_str(), sWarningTitle.c_str(), MB_YESNO) ;
  	if (retVal == IDNO)
    	return string("") ;
	}

	return (aCurrentDrugs[index])->getNoeud() ;
}

unsigned long getDuration(NSLdvDrug* pLdvDrug)
{
  if (NULL == pLdvDrug)
    return (unsigned long) 0 ;

  NSLdvDrugPhase* pPhase = pLdvDrug->getCurrentActivePhase() ;
  if (NULL == pPhase)
    pPhase = pLdvDrug->getLastActivePhase() ;

  if (NULL == pPhase)
    return (unsigned long) 0 ;

  NVLdVTemps tpsStart = pPhase->tDateOuverture ;
  NVLdVTemps tpsEnd   = pPhase->tDateFermeture ;

  return tpsEnd.daysBetween(tpsStart) ;
}

string getPrescriptionDate(NSLdvDrug* pLdvDrug)
{
  if (NULL == pLdvDrug)
    return string("") ;

  NSLinkManager* pGraphe = pLdvDrug->pContexte->getPatient()->pGraphPerson->pLinkManager ;

  string sNodeMedic = pLdvDrug->getNoeud() ;
  string sNodeRenew = pLdvDrug->pDoc->getDrugs()->getLastRenewNode(sNodeMedic) ;
  if ((sNodeRenew != "") && (sNodeRenew != sNodeMedic))
    sNodeMedic = sNodeRenew ;

  // on r�cup�re le lien �ventuel sur un traitement
  VecteurString Traitement ;
  pGraphe->TousLesVrais(sNodeMedic, NSRootLink::treatmentOf, &Traitement) ;
  if (Traitement.empty())
    return string("") ;

  // on r�cup�re le premier noeud pour avoir le code document ordonnance
  string sNodeOrdo = *(*(Traitement.begin())) ;
  string sDocOrdo = string(sNodeOrdo, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) ;

  // on recherche le pDocHis correspondant dans l'historique
  // et on affiche la date du document (en g�n�ral date de cr�ation)
  if ((pLdvDrug->pContexte->getPatient()) && (pLdvDrug->pContexte->getPatient()->pDocHis))
  {
    DocumentIter iterDoc = pLdvDrug->pContexte->getPatient()->pDocHis->VectDocument.TrouveDocHisto(sDocOrdo) ;
    if ((iterDoc != NULL) && (iterDoc != pLdvDrug->pContexte->getPatient()->pDocHis->VectDocument.end()))
      return (*iterDoc)->GetDateDoc() ;
  }
  
  return string("") ;
}

// -----------------------------------------------------------------------------
//
// M�thodes de NSDrugsPropertyWindow//
// -----------------------------------------------------------------------------DEFINE_RESPONSE_TABLE1(NSDrugsPropertyWindow, TListWindow)  EV_WM_LBUTTONDBLCLK,
  EV_WM_RBUTTONDOWN,
  EV_WM_KEYDOWN,
  EV_WM_KILLFOCUS,
  EV_WM_SETFOCUS,
  EV_WM_LBUTTONUP,
END_RESPONSE_TABLE ;

NSDrugsPropertyWindow::NSDrugsPropertyWindow(NSDrugView *parent, int id, int x, int y, int w, int h, TModule *module)
  : TListWindow((TWindow *) parent, id, x, y, w, h, module)
{
  pView         = parent ;
  iRes          = id ;
  Attr.Style    |= LVS_REPORT | LVS_SHOWSELALWAYS ;
//  Attr.ExStyle  |= WS_EX_NOPARENTNOTIFY ;
}

void
NSDrugsPropertyWindow::SetupWindow()
{
  ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;
  TListWindow::SetupWindow() ;
}


// -----------------------------------------------------------------------------
// Fonction de r�ponse au double-click
// -----------------------------------------------------------------------------
void
NSDrugsPropertyWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point) ;

  HitTest(info) ;
  if (info.GetFlags() & LVHT_ONITEM)  	pView->CmChange() ;
  else
  	pView->CmAdd() ;
}

void
NSDrugsPropertyWindow::EvRButtonDown(uint modkeys, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point) ;

  int indexItem = HitTest(info) ;
  if (info.GetFlags() & LVHT_ONITEM)  {  	SetItemState(indexItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED) ;    Invalidate() ;    pView->EvRButtonDown(modkeys, point) ;
  }
  else
  	pView->EvRButtonDownOut(modkeys, point) ;
}

void
NSDrugsPropertyWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
	if      (key == VK_DELETE)
  	pView->CmSuppress() ;
  else if (key == VK_INSERT)
  {
  	if (GetKeyState(VK_SHIFT) < 0)
    	pView->CmChange() ;
    else
    	pView->CmAdd() ;
  }
  else if (key == VK_TAB)
  {
  	if (GetKeyState(VK_SHIFT) < 0)
    	pView->setFocusToPrevSplitterView() ;
    else
    	pView->setFocusToNextSplitterView() ;
  }
  else
  	TListWindow::EvKeyDown(key, repeatCount, flags) ;
}


void
NSDrugsPropertyWindow::EvLButtonUp(uint modKeys, NS_CLASSLIB::TPoint& pt)
{
	NSContexte  *pContexte  = pView->pContexte ;
  NSSuper     *pSuper     = pContexte->getSuperviseur() ;

  if (pSuper->bDragAndDrop)
  {
  	pSuper->DragDrop->DragLeave( *this ) ;
    pSuper->DragDrop->EndDrag() ;
    delete pSuper->DragDrop ;
    pSuper->DragDrop = 0 ;
    pSuper->bDragAndDrop = false ;
  }
}

// -----------------------------------------------------------------------------
// Retourne l'index du premier item s�lectionn�
// -----------------------------------------------------------------------------
int
NSDrugsPropertyWindow::IndexItemSelect()
{
	int count = GetItemCount() ;
  int index = -1 ;

	for (int i = 0 ; i < count ; i++)  	if (GetItemState(i, LVIS_SELECTED))
    {
    	index = i ;
      break ;
    }

	return index ;}


void
NSDrugsPropertyWindow::EvSetFocus(HWND hWndLostFocus)
{
	SetBkColor(0x00fff0f0) ; // 0x00bbggrr
  SetTextBkColor(0x00fff0f0) ;
  Invalidate();

  pView->focusFct() ;

  int count = GetItemCount() ;

  for (int i = 0 ; i < count ; i++)
  	if (GetItemState(i, LVIS_SELECTED))
    	return ;

	SetItemState(0, LVIS_FOCUSED | LVIS_SELECTED, LVIS_SELECTED) ;
}

void
NSDrugsPropertyWindow::EvKillFocus(HWND hWndGetFocus)
{
	SetBkColor(0x00ffffff) ; // 0x00bbggrr
  SetTextBkColor(0x00ffffff) ;
  Invalidate();
}

// -----------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------
/*
DrugTemplate::DrugTemplate(string sConcernNode)
  : DrugViewTmpl(const char far *filt, const char far *desc, const char far *dir, const char far *ext, long flags = 0, TModule*& module = ::Module, TDocTemplate*& phead = DocTemplateStaticHead)
{
  pLdVDoc = &doc ;
*/

