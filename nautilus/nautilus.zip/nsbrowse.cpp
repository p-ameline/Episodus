// NSBROWSE.CPP : Dialogues de composition et de publication
////////////////////////////////////////////////////////////
#include <cstring.h>#include <stdio.h>#include <assert.h>/** Includes sp�cifiques capture **/#include <string.h>#include <malloc.h>#include <windows.h>#include <wingdi.h>#include <mshtml.h>///////////////////////////////////
#include <owl\clipboar.h>

#include "Compos.h"#include "Import.h"#include "ImpImg.h"#include "Lettre.h"#include "log_form.h"#include "WebService.h"#include "nautilus\nsbrowse.h"#include "nautilus\nsbasimg.h"#include "nautilus\nsdocref.h"#include "nautilus\nautilus.rh"#include "nautilus\nssuper.h"#include "nautilus\nshistdo.h"#include "nautilus\nsmodhtm.h"#include "nautilus\ns_html.h"#include "nautilus\nsvisual.h"#include "nautilus\nsresour.h"#include "nautilus\nsdocview.h"#include "nautilus\nscsdoc.h"#include "ns_grab\nsgrabfc.h"
#include "nsbb\nsbbtran.h"
#include "nsbb\nsattvaltools.h"
#include "nssavoir\nsfilecaptur.h"
#include "nautilus\nsGrabObjects.h"
#include "nsepisod\nsclasser.h"

#include "nautilus\nsepicap.h"

/****************** classe NSComposView **************************/
DEFINE_RESPONSE_TABLE1(NSComposView, TWindowView)  EV_WM_CLOSE,
  EV_COMMAND(CM_FILECLOSE, EvClose),
END_RESPONSE_TABLE;

// Constructeur NSComposView
////////////////////////////////////////////////////////////////
NSComposView::NSComposView(NSRefDocument& doc, TWindow *parent)
	           :TWindowView(doc,parent), pDocBrut(&doc), Form(0)
{
  TMyApp* pMyApp = pDocBrut->pContexte->getSuperviseur()->getApplication() ;
  pMyApp->setMenu(string("menubar"), &hAccelerator) ;
}

// Destructeur NSComposView
////////////////////////////////////////////////////////////////
NSComposView::~NSComposView()
{
	// Delete de la Form
	delete Form ;
	CoUninitialize() ;

  if (0 != hAccelerator)
  {
    DestroyAcceleratorTable(hAccelerator) ;
    hAccelerator = 0 ;
  }
}

// GetWindow renvoie this
////////////////////////////////////////////////////////////////
TWindow*
NSComposView::GetWindow()
{
	return (TWindow*) this ;
}

void
NSComposView::EvClose()
{
	TWindow::EvClose() ;
}

//// Override a TWindow virtual to create the HWND directly.
// NSComposView and the VCL TForm1 class both end up
// wrapping the same HWND.
//
void
NSComposView::PerformCreate(int /*menuOrId*/)
{
try
{
	CoInitialize(NULL) ;
	Form = new TWebCompos(Parent->GetHandle(), this) ;
	Form->Visible = false ;
	Form->ParentWindow = Parent->HWindow ;
	SetHandle(Form->Handle) ;
	::SetParent(Forms::Application->Handle, pDocBrut->pContexte->GetMainWindow()->HWindow) ;

	SetDocTitle(pDocBrut->GetTitle(), 0) ;

	// on navigue vers le fichier html � composer
	Navigate(pDocBrut->sUrlHtml) ;
}
catch (...)
{
	erreur("Exception � la cr�ation de la forme de composition.", standardError, 0) ;
}
}

boolNSComposView::IsTabKeyMessage(MSG &msg)
{
	if (GetCapture() == NULL)
	{
  	if ((WM_KEYDOWN == msg.message) || (WM_KEYUP == msg.message))
    {
    	if (VK_TAB == msg.wParam)
      {
      	SendMessage(CN_BASE + msg.message, msg.wParam, msg.lParam) ;
        return true ;
      }
    }
	}
	return false ;
}

//// Let the form process keystrokes in its own way.  Without
// this method, you can't tab between control on the form.
//
bool
NSComposView::PreProcessMsg(MSG &msg)
{
	bool result = IsTabKeyMessage(msg) ;
	if (result)
    return true ;

	PRECONDITION(GetHandle()) ;
  return hAccelerator ? ::TranslateAccelerator(GetHandle(), hAccelerator, &msg) : false ;
}

// Fonction MakeVisible
void
NSComposView::MakeVisible()
{
	Form->Visible = true ;
}

// Fonction SetupWindow
////////////////////////////////////////////////////////////////
void
NSComposView::SetupWindow()
{
	TWindowView::SetupWindow() ;

	// fichiers d'aide

	pDocBrut->pContexte->setAideIndex("") ;  pDocBrut->pContexte->setAideCorps("Les_Fiches_de.html") ;
  ModifyStyle(WS_BORDER, WS_CHILD) ;
  Form->Show() ;
  MakeVisible() ;
}

// Fonction Navigate
////////////////////////////////////////////////////////////////
void
NSComposView::Navigate(string url)
{
try
{
	wchar_t buff[1024] ;
	Variant  Flags(navNoReadFromCache) ;
	TVariant VFlags = Flags.operator TVariant() ;

	fichCompo = pDocBrut->pContexte->PathName("SHTM") + url ;
	url = pDocBrut->pContexte->PathName("UHTM") + url ;

	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, url.c_str(), -1, buff, sizeof(buff)) ;
	Form->Control->Navigate(buff,&VFlags) ;
}
catch (...)
{
	erreur("Exception NSComposView::Navigate.", standardError, 0) ;
}
}

void
NSComposView::NavigateErrorEvent(int iStatusCode, string sURL)
{
	string ps = string("Ev : NavigateError for URL \"") + sURL + string("\"") ;
  ps += string(" (") + getNavigateErrorShortMsg(iStatusCode) + string(")") ;
	pDocBrut->pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;

  erreur(ps.c_str(), standardError, 0) ;
}

voidNSComposView::CmOk()
{
	TView*        pView ;
	NSVisualView* pVisualView ;

	string fichTmpl = pDocBrut->sTemplate ;
	string enteteTmpl = pDocBrut->sEnTete ;

	size_t pos = fichTmpl.find_last_of('\\') ;
	if (pos != NPOS)
		fichTmpl = string(fichTmpl, pos+1, strlen(fichTmpl.c_str())-pos-1) ;

	pos = enteteTmpl.find_last_of('\\') ;
	if (pos != NPOS)
		enteteTmpl = string(enteteTmpl, pos+1, strlen(enteteTmpl.c_str())-pos-1) ;

	string sDroits ;
  NSPersonGraphManager* pManager = pDocBrut->pContexte->getPatient()->pGraphPerson ;
  // on met les infos de template et d'en-tete dans le graphe
	pManager->setTemplatePres(pDocBrut->pDocInfo->sCodeDocPres, fichTmpl, enteteTmpl) ;
  // on met � jour pDocInfo
  pManager->getTree(pDocBrut->pDocInfo->sCodeDocPres, pDocBrut->pDocInfo->pPres, &sDroits) ;
  // �criture des composants image
  pDocBrut->DetruireComposants(pDocBrut->pDocInfo->pPres) ;
  pDocBrut->EcrireComposants(pDocBrut->pDocInfo->pPres) ;
  // enregistrement des composants et mise � jour de pDocInfo
  pManager->setTree(pDocBrut->pDocInfo->pPres, "", pDocBrut->pDocInfo->sCodeDocPres) ;
  pManager->commitGraphTree(pDocBrut->pDocInfo->sCodeDocPres) ;
  pManager->getTree(pDocBrut->pDocInfo->sCodeDocPres, pDocBrut->pDocInfo->pPres, &sDroits) ;

  pDocBrut->pDocInfo->ParseMetaDonnees() ;
  pDocBrut->pContexte->getPatient()->pDocHis->Rafraichir(pDocBrut->pDocInfo, 0) ;

  // destruction du fichier de composition
  if (fichCompo != "")
  {
  	if (!DeleteFile(fichCompo.c_str()))
    	MessageBox("Pb de destruction du fichier de composition", 0, MB_OK) ;
  }

  // on rafraichit �ventuellement la Visual View
  // pour montrer la nouvelle composition
  for (pView = pDocBrut->GetViewList(); pView != 0; pView = pView->GetNextView())
  {
  	if (!strcmp(pView->GetViewName(), "NSVisualView"))
    {
    	pVisualView = dynamic_cast<NSVisualView*>(pView) ;
      pVisualView->Rafraichir() ;
      break ;
    }
  }

	CloseWindow() ;
}

voidNSComposView::CmCancel()
{
	// destruction du fichier de composition
	if (string("") != fichCompo)
	{
  	if (!DeleteFile(fichCompo.c_str()))
    	MessageBox("Pb de destruction du fichier de composition", 0, MB_OK) ;
	}

	// destruction de la base de composition
	if (string("") != pDocBrut->sBaseCompo)		// si la base a �t� initialis�e
	{
  	NSBaseImages BaseCompo(pDocBrut->sBaseCompo) ;
    BaseCompo.lire() ;
    BaseCompo.detruire() ;
	}

	CloseWindow() ;
}

/****************** classe NSImportWindow **************************/

DEFINE_RESPONSE_TABLE1(NSImportWindow, TWindow)
   EV_WM_CLOSE,
END_RESPONSE_TABLE;

NSImportWindow::NSImportWindow(TWindow* parent, string sFichier, NSContexte* pCtx)
               :TWindow(parent)
{
  sFileName     = sFichier ;

	sHtml         = string("") ;
  sPathName     = string("") ;
  sNomFichier   = string("") ;
  sExtension    = string("") ;
  sNomSeul      = string("") ;
  sTypeNautilus = string("") ;

	pContexte     = pCtx ;
	pNewDoc       = 0 ;
	bCanClose     = false ;
  Form          = 0 ;

	bNavOk = InitInfosFichier() ;

  if (bNavOk)
    bNavOk = InitNautilusType() ;

	if (bNavOk)
		bNavOk = GenereHtml() ;

  TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;
  if (NULL != pMyApp)    pMyApp->setMenu(string("menubar"), &hAccelerator) ;
}

NSImportWindow::~NSImportWindow()
{
	if (string("") != sHtml)
	{
		if (!DeleteFile(sHtml.c_str()))
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("htmlManagement", "temporaryHtmlFileDestructionError") + string(" ") + sHtml ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    	erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
    }
	}

	if (NULL != pNewDoc)
		delete pNewDoc ;

	// Delete de la Form
  if (Form)
	{
		delete Form ;
		CoUninitialize() ;
	}

  if (0 != hAccelerator)
  {
    DestroyAcceleratorTable(hAccelerator) ;
    hAccelerator = 0 ;
  }
}

void
NSImportWindow::EvClose()
{
	TWindow::EvClose() ;
}

//
// Override a TWindow virtual to create the HWND directly.
// NSImportWindow and the VCL TForm1 class both end up
// wrapping the same HWND.
//
void
NSImportWindow::PerformCreate(int /*menuOrId*/)
{
	CoInitialize(NULL) ;
	Form = new TWebImport(Parent->GetHandle(), this) ;
	Form->Visible = false ;
	Form->ParentWindow = Parent->HWindow ;
	SetHandle(Form->Handle) ;
	::SetParent(Forms::Application->Handle, pContexte->GetMainWindow()->HWindow) ;

	// on navigue vers le fichier html � importer
	Navigate() ;
}

bool
NSImportWindow::IsTabKeyMessage(MSG &msg)
{
	if (GetCapture() == NULL)
	{
		if (msg.message == WM_KEYDOWN || msg.message == WM_KEYUP)
    {
    	if (msg.wParam == VK_TAB)
      {
      	SendMessage(CN_BASE + msg.message, msg.wParam, msg.lParam) ;
        return true ;
      }
    }
	}

	return false ;
}

//// Let the form process keystrokes in its own way.  Without
// this method, you can't tab between control on the form.
//
bool
NSImportWindow::PreProcessMsg(MSG &msg)
{
	bool result = IsTabKeyMessage(msg) ;
	if (result)
    return true ;

	PRECONDITION(GetHandle()) ;
  return hAccelerator ? ::TranslateAccelerator(GetHandle(), hAccelerator, &msg) : false ;
}

// Fonction MakeVisiblevoid
NSImportWindow::MakeVisible()
{
  Form->Visible = true ;
}

// Fonction SetupWindow
////////////////////////////////////////////////////////////////
void
NSImportWindow::SetupWindow()
{
	TWindow::SetupWindow() ;

	ModifyStyle(WS_BORDER, WS_CHILD) ;
	Form->Show() ;
	MakeVisible() ;
}

// Fonction Navigate
////////////////////////////////////////////////////////////////
void
NSImportWindow::Navigate()
{
  if ((NULL == Form) || (NULL == Form->Control))
    return ;

	string  url ;
	wchar_t buff[1024] ;
	Variant Flags(navNoReadFromCache) ;
	TVariant VFlags = Flags.operator TVariant() ;

	if (sHtml != "")
		url = sHtml ;
	else
		url = sFileName ;

	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, url.c_str(), -1, buff, sizeof(buff)) ;
	Form->Control->Navigate(buff,&VFlags) ;
}

void
NSImportWindow::NavigateErrorEvent(int iStatusCode, string sURL)
{
	string ps = string("Ev : NavigateError for URL \"") + sURL + string("\"") ;
  ps += string(" (") + getNavigateErrorShortMsg(iStatusCode) + string(")") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;

  erreur(ps.c_str(), standardError, 0) ;
}

bool
NSImportWindow::InitInfosFichier()
{
	if (string("") == sFileName)
		return false ;

	// R�cup�ration du path
  //
	size_t pos1 = sFileName.find_last_of("\\") ;

	if ((NPOS == pos1) || (strlen(sFileName.c_str())-1 == pos1))
	{
		// on doit normalement r�cup�rer au moins 'C:\\'
		// => on g�n�re une erreur s'il n'y a pas de '\\' ou que le '\\' est le dernier caract�re
    string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "cantParsePath") + string(" ") + sFileName ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
		return false ;
	}

	sPathName   = string(sFileName, 0, pos1+1) ;
  sNomFichier = string(sFileName, pos1+1, strlen(sFileName.c_str())-pos1-1) ;

	// R�cup�ration de l'extension
	size_t pos2 = sNomFichier.find_last_of(".");

	if ((NPOS == pos2) || (strlen(sNomFichier.c_str())-1 == pos2))
	{
  	//
    // On v�rifie d'abord si ce n'est pas un fichier texte de l'ancien
    // Nautilus : gastroda
    //
    //sNomSeul = pseumaj(sNomSeul.c_str());
    if (string("GASTRODA") == sNomFichier)
    {
    	if (!convertGdata(&sFileName))
      	return false ;
      pos2 = sFileName.find(".") ;
    }
    else
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "cantFindExtension") + string(" ") + sFileName ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    	erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
      return false ;
    }
  }

  sExtension = string(sNomFichier, pos2+1, strlen(sNomFichier.c_str())-pos2-1) ;

  // nom du fichier sans path et sans extension
  sNomSeul = string(sNomFichier, 0, pos2) ;

  // nom du fichier (sans path)
  // sNomFichier = sNomSeul + "." + sExtension ;

	return true ;
}

bool
NSImportWindow::InitNautilusType()
{
  // On r�cup�re les infos du type mime li� � l'extension du fichier

	NSTypeMimeInfo infoTypeMime ;

	if (false == pContexte->getSuperviseur()->chercheTypeMimeInfo(sExtension, &infoTypeMime))
    return false ;

	sTypeNautilus = string(infoTypeMime.pDonnees->type) ;

	return true ;
}

bool
NSImportWindow::GenereHtml()
{
	string sType = string(sTypeNautilus, 0, 2) ;
	string sTemplateHtml, sPathHtml;

	if (pContexte->typeDocument(sTypeNautilus, NSSuper::isHTML)) // cas des html statiques
	{
		// cas des html : le fichier est sFileName et ne doit pas etre d�truit
    return true ;
	}
  else if (string("ZTPDF") == sTypeNautilus)
	{
		// cas des pdf : le fichier est sFileName et ne doit pas etre d�truit
    return true ;
	}
	else if (pContexte->typeDocument(sTypeNautilus, NSSuper::isImage))
	{
  	// cas des images :
    // on construit un html temporaire dans le r�pertoire FPER
    sPathHtml = pContexte->PathName("FPER") ;

    NSModHtml html(toImporter, 0, pContexte) ;

    // on trouve le nom du fichier temporaire � visualiser
    sHtml = html.nomSansDoublons(sPathHtml,sNomSeul,"htm") ;
    sHtml = sPathHtml + sHtml ;

    // on passe la template des documents images
    sTemplateHtml = pContexte->PathName("NTPL") + string("docimage.htm") ;

    // generation du fichier html (dans le repertoire FPER)
    if (!html.genereHtml(sTemplateHtml, sHtml, sPathName, sNomFichier, sTypeNautilus))
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("importManagement", "errorCreatingImportHtmlFile") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    	erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
      return false ;
    }
  }
	else if (sTypeNautilus == string("ZTRTF"))
  {
		// cas des RTF :
    // on construit un html temporaire dans le r�pertoire FPER
    sPathHtml = pContexte->PathName("FPER") ;

    NSHtmlRTF html(toImporter, 0, sFileName.c_str(), pContexte) ;

    // on trouve le nom du fichier temporaire � visualiser
    sHtml = html.nomSansDoublons(sPathHtml, sNomSeul, "htm") ;
    sHtml = sPathHtml + sHtml ;

    // on convertit le fichier RTF en HTML
    html.Convertir() ;

    // on passe la template des documents RTF
    sTemplateHtml = pContexte->PathName("NTPL") + string("docrtf.htm") ;

    // generation du fichier html (dans le repertoire FPER)
    if (!html.genereHtml(sTemplateHtml,sHtml,sPathName,sNomFichier,sTypeNautilus))
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("importManagement", "errorCreatingImportHtmlFile") ;
    	erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
      return false ;
    }
  }
	else if (sTypeNautilus == string("ZTTXT"))
	{
  	// cas des TXT :
    // on construit un html temporaire dans le r�pertoire FPER
    sPathHtml = pContexte->PathName("FPER") ;

    NSHtmlTXT html(toImporter, 0, sFileName.c_str(), pContexte) ;

    // on trouve le nom du fichier temporaire � visualiser
    sHtml = html.nomSansDoublons(sPathHtml, sNomSeul, "htm") ;
    sHtml = sPathHtml + sHtml ;

    // on passe la template des documents TXT
    sTemplateHtml = pContexte->PathName("NTPL") + string("doctxt.htm") ;

    // generation du fichier html (dans le repertoire FPER)
    if (!html.genereHtml(sTemplateHtml,sHtml,sPathName,sNomFichier,sTypeNautilus))
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("importManagement", "errorCreatingImportHtmlFile") ;
    	erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
      return false ;
    }
  }
  else // types non g�r�s
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("importManagement", "importNotHandledForSuchFile") ;
    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
    return false ;
  }

	return true ;
}

void
NSImportWindow::CmImporter()
{
	pNewDoc = new NSRefDocument(0, pContexte) ;
  pNewDoc->setReadOnly(false) ;

	if ((sHtml == string("")) &&
      (pContexte->typeDocument(sTypeNautilus, NSSuper::isHTML)))
	{
  	// cas de l'importation d'un html
    // on importe le nouveau document html statique
    if (!pNewDoc->ImporterHtml(sFileName))
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("importManagement", "importFailed") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  		erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
    }
  }
  else
  {
  	// cas de l'importation d'un fichier externe
    if (!pNewDoc->ImporterFichier(sTypeNautilus, sNomFichier, sPathName))
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("importManagement", "importFailed") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
  		erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
    }
	}

	bCanClose = true ;
	CloseWindow() ;
}

voidNSImportWindow::CmReferencer()
{
	// on r�f�rence le fichier par un pointeur
	pNewDoc = new NSRefDocument(0, pContexte) ;

	if (sHtml == string(""))
	{
  	// cas du r�f�rencement d'un html statique
    if (!pNewDoc->Referencer("ZSHTM", sNomFichier, sFileName))
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("importManagement", "referenceFailed") ;
  		erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
    }
  }
  else
  {
  	// cas du r�f�rencement d'un fichier externe
    if (!pNewDoc->Referencer(sTypeNautilus, sNomFichier, sFileName))
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("importManagement", "referenceFailed") ;
  		erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
    }
	}

	bCanClose = true ;
	CloseWindow() ;
}

void
NSImportWindow::CmCapturer()
{
	NSCaptureArray  CaptureArray(pContexte) ;
  NSPatPathoArray PPT(pContexte) ;

  NSCaptureFromHPRIM HprimHunter(pContexte) ;

/*
  bool bSuccess = importHPRIM2(&CaptureArray, &PPT) ;

  if (!bSuccess)
		bSuccess = importHPRIM1(&CaptureArray, &PPT) ;
*/

	HprimHunter.setFileName(sFileName) ;

  string sProcessLog = string("") ;

  int iAlertLevel = 0 ;
  bool bHeaderValidity ;
  bool bSuccess = HprimHunter.importHPRIM2(&CaptureArray, &PPT, &iAlertLevel, &sProcessLog, &bHeaderValidity) ;

  if (false == bSuccess)
		bSuccess = HprimHunter.importHPRIM1(&CaptureArray, &PPT, &sProcessLog, &bHeaderValidity) ;

	if (bSuccess && bHeaderValidity)
  {
	  NSCSDocument* pCSDoc = new NSCSDocument(0, pContexte, "") ;
    NSPatPathoArray* pPatPatho = pCSDoc->pPatPathoArray ;
    pPatPatho->ajoutePatho("GBIOL1", 0) ;
    pPatPatho->InserePatPathoFille(pPatPatho->begin(), &PPT) ;

    NSDocViewManager dvManager(pContexte) ;
	  dvManager.createView(pCSDoc, "CS Format") ;
  }
}

bool
NSImportWindow::importHPRIM2(NSCaptureArray* pCaptureArray, NSPatPathoArray* pPPT)
{
	ifstream inFile ;
	string sLine ;
	string sText = "" ;

	inFile.open(sFileName.c_str());	if (!inFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
    return false ;
	}

  parseHPRIM1header(&inFile, pCaptureArray, pPPT) ;

  NSEpiFlechiesDB flechiesDB(pContexte) ;

  bool bFinFound = false ;
  bool bFinFichierFound = false ;

  bool bValueWelcomed = false ;

  bool bLabTagFound = false ;

  // On saute tout jusqu'� la balise LAB
  //
  while (!inFile.eof() && !bLabTagFound)
	{
  	getline(inFile, sLine) ;

    string sStripLine = sLine ;
    strip(sStripLine, stripBoth) ;

    if (sStripLine == string("****LAB****"))
    	bLabTagFound = true ;
	}

  // no LAB tag : not HPRIM2
  //
  if (!bLabTagFound)
  {
  	inFile.close() ;
    return false ;
  }

  string sConcept  = string("") ;
  string sValue    = string("") ;
  string sUnit     = string("") ;
  string sNormInf  = string("") ;
  string sNormSup  = string("") ;
  string sValue2   = string("") ;
  string sUnit2    = string("") ;
  string sNormInf2 = string("") ;
  string sNormSup2 = string("") ;

	while (!inFile.eof())
	{
  	getline(inFile, sLine) ;

    string sStripLine = sLine ;
    strip(sStripLine, stripBoth) ;

    if (sStripLine == string("****FIN****"))
    	bFinFound = true ;
    else if (sStripLine == string("****FINFICHIER****"))
    	bFinFichierFound = true ;
    else if ((sStripLine != string("")) && (strlen(sStripLine.c_str()) > 4))
    {
      NSPatPathoArray PPTnum(pContexte) ;

    	// text: we try to analyze it
      //
      if (string(sStripLine, 0, 4) == string("TEX|"))
      {
      	sStripLine = string(sStripLine, 4, strlen(sStripLine.c_str()) - 4) ;

    		// What is it ?
      	string sPattern = string("") ;

      	// Title ?
      	string sResult = flechiesDB.getCodeLexiq(sStripLine, 'T') ;
  			if (sResult == string(""))
      		sResult = flechiesDB.getCodeLexiq(sStripLine, 'G') ;
      	if (sResult == string(""))
      		sResult = flechiesDB.getCodeLexiq(sStripLine, 'Z') ;

      	// value
      	if (sResult == string(""))
      	{
      		analysedCapture aCapt(pContexte, sStripLine, 0) ;
      		ParseElemArray aRawParseResult ;
      		ParseElemArray aSemanticParseResult ;
      		aCapt.getSemanticParseElemArray(&aRawParseResult, &aSemanticParseResult) ;
        	//
        	// We only use the information if it has been fully recognized
        	// elsewhere, it can lead to much stupid behaviour
        	//
        	bool bFullSuccess ;
      		sPattern = aCapt.getNumPattern(&aRawParseResult, &aSemanticParseResult, &bFullSuccess) ;
        	if (sPattern != string(""))
          {
          	// We try to get the concept here, because sometimes, the RES
            // information only contains sender specific codes
            //
          	string sResult = aCapt.getElementByTagInNumPattern(sPattern, 'V') ;
            if (sResult != string(""))
            	sConcept = sResult ;

        		if (!bFullSuccess)
          		bValueWelcomed = false ;
          	else
          	{
        			if (sConcept != "")
          			bValueWelcomed = true ;
          	}
        	}
        }

      	int iCol = 0 ;
      	if (sResult != string(""))
      		iCol = 0 ;
      	else
      	{
      		if (!PPTnum.empty())
        	{
        		size_t posValue = sPattern.find("[V") ;
          	if (posValue != NPOS)
          		iCol = 0 ;
          	else
          		iCol = 1 ;
        	}
      	}

    		// Pushing the text
      	//
    		Message theMessage ;
      	theMessage.SetTexteLibre(sStripLine) ;
      	pPPT->ajoutePatho("�?????", &theMessage, iCol) ;
      }
      //
      // RES: structured part
      //
      else if (string(sStripLine, 0, 4) == string("RES|"))
      {
      	sStripLine = string(sStripLine, 4, strlen(sStripLine.c_str()) - 4) ;

        int    iNumInfo = 0 ;
        int    iNumSerie = 0 ;

        while (sStripLine != string(""))
        {
        	size_t posPipe = sStripLine.find("|") ;

        	if (posPipe > 0)
          {
          	string sResData ;

          	if (posPipe == NPOS)
            	sResData = sStripLine ;
            else
          		sResData = string(sStripLine, 0, posPipe) ;

            if (sResData == string("N"))
            {
            	iNumSerie++ ;
              iNumInfo = -1 ;
            }
            else if (sResData == string("L"))
            {
            	iNumSerie++ ;
              iNumInfo = -1 ;
            }
            else if (sResData == string("F"))
            {
              iNumInfo = -1 ;
            }
            else
            {
              switch (iNumInfo)
              {
                // Value inside the series
                case 0 :
                	if (iNumSerie == 0)
                  {
                    string sResult = flechiesDB.getCodeLexiq(sResData, 'V') ;
                    if (sResult != string(""))
                      sConcept = sResult ;
                  }
                  else if (iNumSerie == 1)
                    sValue = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                  else if (iNumSerie == 2)
                    sValue2 = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                  break ;
                // Concept outside the series, unit inside
                case 1 :
                {
                  if (iNumSerie == 0)
                  {
                    string sResult = flechiesDB.getCodeLexiq(sResData, 'V') ;
                    if (sResult != string(""))
                      sConcept = sResult ;
                  }
                  else
                  {
                    string sResult = flechiesDB.getCodeLexiq(sResData, '2') ;
                    if (sResult != string(""))
                    {
                      if (iNumSerie == 1)
                        sUnit = sResult ;
                      else if (iNumSerie == 2)
                        sUnit2 = sResult ;
                    }
                  }
                  break ;
                }
                // lower normal value inside the series
                case 2 :
                	if (iNumSerie == 1)
                    sNormInf = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                  else if (iNumSerie == 2)
                    sNormInf2 = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                  break ;
                // upper normal value inside the series
                case 3 :
                	if (iNumSerie == 1)
                    sNormSup = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                  else if (iNumSerie == 2)
                    sNormSup2 = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                  break ;
              }
            }

          	if (posPipe < strlen(sStripLine.c_str()) - 1)
          		sStripLine = string(sStripLine, posPipe + 1, strlen(sStripLine.c_str()) - posPipe - 1) ;
            else
            	sStripLine = string("") ;
          }
          else
          {
						sStripLine = string(sStripLine, 1, strlen(sStripLine.c_str()) - 1) ;
            if (iNumInfo == 1)
            {
            	if (iNumSerie == 1)
              	sUnit = "200001" ;
              else if (iNumSerie == 2)
              	sUnit2 = "200001" ;
            }
          }

          iNumInfo++ ;
        }

        if (sConcept != string(""))
        {
        	pPPT->ajoutePatho(sConcept, 1) ;

          bool bValuesFound = false ;

        	if ((sValue != string("")) && (sUnit != string("")))
          {
          	bValuesFound = true ;

          	Message theMessage ;
      			theMessage.SetComplement(sValue) ;
            theMessage.SetUnit(sUnit) ;
            pPPT->ajoutePatho("�N0;03", &theMessage, 2) ;

          	if (sNormInf != string(""))
          	{
          		pPPT->ajoutePatho("VNOMI1", 2) ;

            	Message theMessage ;
      				theMessage.SetComplement(sNormInf) ;
            	theMessage.SetUnit(sUnit) ;
            	pPPT->ajoutePatho("�N0;03", &theMessage, 3) ;
          	}
          	if (sNormSup != string(""))
          	{
          		pPPT->ajoutePatho("VNOMS1", 2) ;

            	Message theMessage ;
      				theMessage.SetComplement(sNormSup) ;
            	theMessage.SetUnit(sUnit) ;
            	pPPT->ajoutePatho("�N0;03", &theMessage, 3) ;
          	}
          }
          if ((sValue2 != string("")) && (sUnit2 != string("")))
          {
          	bValuesFound = true ;

          	Message theMessage ;
      			theMessage.SetComplement(sValue2) ;
            theMessage.SetUnit(sUnit2) ;
            pPPT->ajoutePatho("�N0;03", &theMessage, 2) ;

          	if (sNormInf2 != string(""))
          	{
          		pPPT->ajoutePatho("VNOMI1", 2) ;

            	Message theMessage ;
      				theMessage.SetComplement(sNormInf2) ;
            	theMessage.SetUnit(sUnit2) ;
            	pPPT->ajoutePatho("�N0;03", &theMessage, 3) ;
          	}
          	if (sNormSup2 != string(""))
          	{
          		pPPT->ajoutePatho("VNOMS1", 2) ;

            	Message theMessage ;
      				theMessage.SetComplement(sNormSup2) ;
            	theMessage.SetUnit(sUnit2) ;
            	pPPT->ajoutePatho("�N0;03", &theMessage, 3) ;
          	}
          }
          if (bValuesFound)
          {
          	PatPathoIter iterPere = pPPT->end() ;
          	iterPere-- ;
          	pPPT->InserePatPathoFille(iterPere, &PPTnum) ;
          }
        }

      	sConcept  = string("") ;
				sValue    = string("") ;
				sUnit     = string("") ;
				sNormInf  = string("") ;
				sNormSup  = string("") ;
				sValue2   = string("") ;
				sUnit2    = string("") ;
				sNormInf2 = string("") ;
				sNormSup2 = string("") ;
      }
    }
  }

	inFile.close() ;

  if (!bFinFound || !bFinFichierFound)
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("hprimManagement", "endOfFileMarkupsNotFound") ;
    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
  }

  return true ;
}

bool
NSImportWindow::importHPRIM1(NSCaptureArray* pCaptureArray, NSPatPathoArray* pPPT)
{
	ifstream inFile ;
	string sLine ;
	string sText = "" ;

	inFile.open(sFileName.c_str());	if (!inFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
    return false ;
	}

  parseHPRIM1header(&inFile, pCaptureArray, pPPT) ;

  NSEpiFlechiesDB flechiesDB(pContexte) ;

  bool bFinFound = false ;
  bool bFinFichierFound = false ;

  bool bValueWelcomed = false ;

	while (!inFile.eof())
	{
  	getline(inFile, sLine) ;

    string sStripLine = sLine ;
    strip(sStripLine, stripBoth) ;

    if (sStripLine == string("****FIN****"))
    	bFinFound = true ;
    else if (sStripLine == string("****FINFICHIER****"))
    	bFinFichierFound = true ;
    else if (sStripLine != string(""))
    {
    	// What is it ?
      string sPattern = string("") ;

      // Title ?
      string sResult = flechiesDB.getCodeLexiq(sStripLine, 'T') ;
  		if (sResult == string(""))
      	sResult = flechiesDB.getCodeLexiq(sStripLine, 'G') ;
      if (sResult == string(""))
      	sResult = flechiesDB.getCodeLexiq(sStripLine, 'Z') ;

      NSPatPathoArray PPTnum(pContexte) ;



      // value
      if (sResult == string(""))
      {
      	analysedCapture aCapt(pContexte, sStripLine, 0) ;
      	ParseElemArray aRawParseResult ;
      	ParseElemArray aSemanticParseResult ;
      	aCapt.getSemanticParseElemArray(&aRawParseResult, &aSemanticParseResult) ;
        //
        // We only use the information if it has been fully recognized
        // elsewhere, it can lead to much stupid behaviour
        //
        bool bFullSuccess ;
      	sPattern = aCapt.getNumPattern(&aRawParseResult, &aSemanticParseResult, &bFullSuccess) ;
        if (sPattern != string(""))
        {
        	if (!bFullSuccess)
          	bValueWelcomed = false ;
          else
          {
        		aCapt.numPatternToTree(&sPattern, &PPTnum) ;
            size_t posValue = sPattern.find("[V") ;
          	if (posValue != NPOS)
          		bValueWelcomed = true ;
          }
        }
      }

      int iCol = 0 ;
      if (sResult != string(""))
      	iCol = 0 ;
      else
      {
      	if (!PPTnum.empty())
        {
        	size_t posValue = sPattern.find("[V") ;
          if (posValue != NPOS)
          	iCol = 0 ;
          else
          	iCol = 1 ;
        }
      }

    	// Pushing the text
      //
    	Message theMessage ;
      theMessage.SetTexteLibre(sStripLine) ;
      pPPT->ajoutePatho("�?????", &theMessage, iCol) ;

      if (sResult != string(""))
      	pPPT->ajoutePatho(sResult, iCol+1) ;
      else
      {
      	if (bValueWelcomed && !PPTnum.empty())
        {
        	PatPathoIter iterPere = pPPT->end() ;
          iterPere-- ;

          size_t posValue = sPattern.find("[V") ;
          if (posValue == NPOS)
          {
          	while ((iterPere != pPPT->begin()) && ((*iterPere)->getLexique() == string("�?????")))
            	iterPere-- ;
            while ((iterPere != pPPT->begin()) && (((*iterPere)->getLexique())[0] != 'V'))
            	iterPere-- ;
          }

        	pPPT->InserePatPathoFille(iterPere, &PPTnum) ;
        }
      }
    }
  }

	inFile.close() ;

  if (!bFinFound || !bFinFichierFound)
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("hprimManagement", "endOfFileMarkupsNotFound") ;
    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
  }

  return true ;
}

bool
NSImportWindow::parseHPRIM1header(ifstream* pInFile, NSCaptureArray* pCaptureArray, NSPatPathoArray* pPPT)
{
	if (!pInFile || !pCaptureArray || !pPPT)
		return false ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	// HPRIM Format
	// line 1 Patient ID (num or name + surname)
	//      2 Patient Familly name
	//      3 Patient name
	//      4 Adresse 1
	//      5 Adresse 2
	//      6 Code Postal / Ville
	//      7 Date Naissance
	//      8 No SS
	//      9 Code ?
	//     10 Date Examen
	//     11 Identifiant Labo
	//     12 Identifiant M�decin

	// Loading header
  //
  size_t iNumLine = 0 ;
  string sLine ;

  while (!pInFile->eof() && (iNumLine < 12))
	{
  	getline(*pInFile, sLine) ;

    string sPathString      = string("") ;
    string sUnitString      = string("") ;
    string sClassifString   = string("") ;
    string sInformationDate = string("") ;

    strip(sLine, stripBoth) ;

    if (sLine != string(""))
    {
    	switch(iNumLine)
      {
      	case 1 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM01", sLine, sClassifString, sUnitString, sInformationDate)) ;
          break ;
        case 2 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM21", sLine, sClassifString, sUnitString, sInformationDate)) ;
          break ;
        case 3 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LCOOR1/LADRE1/LADL11", sLine, sClassifString, sUnitString, sInformationDate)) ;
          break ;
        case 4 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LCOOR1/LADRE1/LADL21", sLine, sClassifString, sUnitString, sInformationDate)) ;
          break ;
        case 5 :
        	{
          	size_t blkPos = sLine.find(" ") ;
            if (blkPos != NPOS)
            {
            	string sZip  = string(sLine, 0, blkPos) ;
              string sCity = string(sLine, blkPos + 1, strlen(sLine.c_str()) - blkPos - 1) ;
              strip(sCity, stripBoth) ;
              pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LCOOR1/LADRE1/LVILL1/LZIP01", sZip, sClassifString, sUnitString, sInformationDate)) ;
              pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LCOOR1/LADRE1/LVILL1/LCOMU1", sCity, sClassifString, sUnitString, sInformationDate)) ;
            }
          }
          break ;
        //
        // Birthdate
        //
        case 6 :
        	{
          	string sDate = string("") ;
          	//
          	// JJ/MM/AA
            //
          	if (strlen(sLine.c_str()) == 8)
            {
          		NVLdVTemps currentDate ;
            	currentDate.takeTime() ;
            	string sCurrentDate = currentDate.donneDate() ;
            	string sTreshold = string(sCurrentDate, 2, 2) ;

            	sDate = getDateFromHPRIM1date(sLine, sTreshold) ;
            }
            //
            // JJ/MM/AAAA
            //
            else if (strlen(sLine.c_str()) == 10)
            	donne_date_inverse(sLine, sDate, sLang) ;

            if (sDate != string(""))
            	pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/KNAIS1", sDate, sClassifString, "2DA011", sInformationDate)) ;
          }
          break ;
        case 7 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LFRAN1/LFRAB1", sLine, sClassifString, sUnitString, sInformationDate)) ;
          break ;
        //
        // Document's date
        //
        case 9 :
        	{
          	string sDate = string("") ;

          	// JJ/MM/AA
          	if (strlen(sLine.c_str()) == 8)
            	sDate = getDateFromHPRIM1date(sLine, "") ;
            // JJ/MM/AAAA
            else if (strlen(sLine.c_str()) == 10)
            	donne_date_inverse(sLine, sDate, sLang) ;

            if (sDate != string(""))
            {
            	pPPT->ajoutePatho("KCHIR2", 0) ;
							Message theMessage ;
    					theMessage.SetUnit("2DA011") ;
							theMessage.SetComplement(sDate) ;
							pPPT->ajoutePatho("�D0;10", &theMessage, 1) ;
            }
          }
      }
    }
    iNumLine++ ;
  }
  return true ;
}

string
NSImportWindow::getDateFromHPRIM1date(string sHPRIMdate, string s2kTreshold)
{
	if (strlen(sHPRIMdate.c_str()) != 8)
		return string("") ;

	if ((sHPRIMdate[2] != '/') || (sHPRIMdate[5] != '/'))
		return string("") ;

  string sYear  = string(sHPRIMdate, 6, 2) ;
  string sMonth = string(sHPRIMdate, 3, 2) ;
  string sDay   = string(sHPRIMdate, 0, 2) ;

  string sDate = sYear + sMonth + sDay ;

  // Year ?
  if (s2kTreshold == string(""))
  	sDate = string("20") + sDate ;
  else
  {
  	int iTreshold = atoi(s2kTreshold.c_str()) ;
    int iYear     = atoi(sYear.c_str()) ;
    if (iYear > iTreshold)
    	sDate = string("19") + sDate ;
    else
    	sDate = string("20") + sDate ;
  }

  return sDate ;
}

voidNSImportWindow::CmAnnuler()
{
	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
  string sErrorText = pContexte->getSuperviseur()->getText("importManagement", "doYouReallyWantToCancelThisImport") ;
	int retVal = MessageBox(sErrorText.c_str(), sCaption.c_str(), MB_YESNO) ;

	if (IDYES == retVal)
	{
		bCanClose = true ;
		CloseWindow() ;
	}
}

bool
NSImportWindow::convertGdata(string* psFichier)
{
	//
	// Ouverture du fichier des modules
	//
	ifstream inFile;
	inFile.open(psFichier->c_str());
	if (!inFile)
	{
		erreur("Erreur � l'ouverture du fichier gastroda", standardError, 0, GetHandle());
		return false;
	}

  string sFichierOut = pContexte->PathName("FPER") + string("GASTRODA.HTM");
  ofstream outFile;
  outFile.open(sFichierOut.c_str());
  if (!outFile)
  {
    erreur("Erreur d'ouverture en �criture du fichier gastroda.htm", standardError, 0) ;
    inFile.close() ;
    return false ;
  }

  outFile.write("<html>\n", 7) ;
  outFile.write("<body>\n", 7) ;

  char buffer[1001] ;
  int	 num_ligne = 0 ;
	//
	// Lecture du fichier
	//
	inFile.unsetf(ios::skipws) ;
  while (inFile.getline(buffer, 1000))
	{
  	OemToAnsi(buffer, buffer) ;

		num_ligne++ ;
    int iTailleBuf = strlen(buffer) ;

    for (int j = 0; j < iTailleBuf; j++)
    {
    	switch (buffer[j])
      {
      	case  9 : // Tabulation, non prise en compte
        	j += 2 ;
          break ;
        case 27 :
        	j++ ;
          break ;        case 28 :
        	j++ ;
          break ;
        default :
        	if ((num_ligne < 4) || (num_ligne > 8))
          	outFile.put(buffer[j]) ;
      }
    }
    outFile.write("<br>\n", 5) ;
	}
	inFile.close() ;

  outFile.write("</body>\n", 8) ;
  outFile.write("</html>\n", 8) ;

  outFile.close() ;

  *psFichier = sFichierOut ;

	return true ;
}

/****************** classe NSImportChild **************************/
DEFINE_RESPONSE_TABLE1(NSImportChild, TMDIChild)   EV_WM_CLOSE,
   EV_COMMAND(CM_FILECLOSE, EvClose),
END_RESPONSE_TABLE;

NSImportChild::NSImportChild(NSContexte* pCtx, TMDIClient& parent, const char far* title, NSImportWindow* clientWnd)
              :TMDIChild(parent, title, clientWnd), NSRoot(pCtx)
{
	pClient = clientWnd;
}

NSImportChild::~NSImportChild()
{
}

void
NSImportChild::EvClose()
{
	if (!pClient->bCanClose)
	{
		string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    string sErrorText = pContexte->getSuperviseur()->getText("importManagement", "doYouReallyWantToCloseImport") ;
		int retVal = MessageBox(sErrorText.c_str(), sCaption.c_str(), MB_YESNO) ;

		if (retVal == IDYES)
			TWindow::EvClose() ;
	}
	else
		TWindow::EvClose() ;
}

/****************** classe NSImpImgWindow **************************/

DEFINE_RESPONSE_TABLE1(NSImpImgWindow, TWindow)
   EV_WM_CLOSE,END_RESPONSE_TABLE;
NSImpImgWindow::NSImpImgWindow(TWindow* parent, NSContexte* pCtx, AssistCaptureDialog* pAssistDlg)               :TWindow(parent, "IMPORTATION_IMAGES"){	sHtml     = "" ;	pContexte = pCtx ;	pNewDoc   = 0 ;	bCanClose = false ;	pAssist   = pAssistDlg ;  Form      = 0 ;
	bNavOk = InitImageArray() ;
	if (bNavOk)		bNavOk = GenerePannel() ;  TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;  if (NULL != pMyApp)    pMyApp->setMenu(string("menubar"), &hAccelerator) ;}
NSImpImgWindow::~NSImpImgWindow(){	string sFichImg, sFichHtm ;
	// on d�truit les html restant dans l'array global	DetruireHtmlTemp() ;
	// on d�truit la pile des images import�es et leurs html associ�s	if (false == aImportArray.empty())    for (NSImgIter i = aImportArray.begin(); i != aImportArray.end(); i++)    {        if ((*i)->html != "")        {            sFichHtm = sPathName + (*i)->html;            if (!DeleteFile(sFichHtm.c_str()))            {                string sMsg = "Pb � la destruction du fichier html associ� � l'image " + (*i)->fichier;                erreur(sMsg.c_str(), standardError, 0, GetHandle()) ;            }            else                (*i)->html = "";        }        if ((*i)->supphtml != "")        {            string sFichHtm = sPathName + (*i)->supphtml;
            if (!DeleteFile(sFichHtm.c_str()))            {                string sMsg = "Pb � la destruction du fichier html associ� � l'image " + (*i)->fichier;                erreur(sMsg.c_str(), standardError, 0, GetHandle()) ;            }            else                (*i)->supphtml = "";        }
        sFichImg = sPathName + (*i)->fichier;
        if (!DeleteFile(sFichImg.c_str()))        {            string sMsg = "Pb � la destruction de l'image " + (*i)->fichier;            erreur(sMsg.c_str(), standardError, 0, GetHandle()) ;        }        else            (*i)->fichier = "";    }

    // on d�truit le fichier pannel.htm
	if (sHtml != "")
	{
		if (!DeleteFile(sHtml.c_str()))
			erreur("Pb � la destruction du fichier pannel html.", standardError, 0, GetHandle()) ;
	}

	// on d�truit le document ayant servi � l'importation
	if (pNewDoc)
		delete pNewDoc ;

	// Delete de la Form
	if (NULL != Form)
	{
		delete Form ;
    CoUninitialize() ;
	}

  if (0 != hAccelerator)
  {
    DestroyAcceleratorTable(hAccelerator) ;
    hAccelerator = 0 ;
  }
}

voidNSImpImgWindow::EvClose(){	TWindow::EvClose() ;}
bool
NSImpImgWindow::CanClose(){	// on r�veille �ventuellement le dialogue assistant	if (pAssist)		pAssist->PostMessage(WM_COMMAND, CM_ASSIST) ;	return true ;}
//
// Override a TWindow virtual to create the HWND directly.
// NSImpImgWindow and the VCL TForm1 class both end up
// wrapping the same HWND.
//
void
NSImpImgWindow::PerformCreate(int /*menuOrId*/)
{
  CoInitialize(NULL) ;
  Form = new TImportImg(Parent->GetHandle(), this) ;
  Form->Visible = false ;
  Form->ParentWindow = Parent->HWindow ;
  SetHandle(Form->Handle) ;
  ::SetParent(Forms::Application->Handle, pContexte->GetMainWindow()->HWindow) ;

  // on navigue vers le fichier html � importer
  Navigate() ;
}

bool
NSImpImgWindow::IsTabKeyMessage(MSG &msg)
{
	if (NULL == GetCapture())
	{
  	if ((WM_KEYDOWN == msg.message) || (WM_KEYUP == msg.message))
    {
    	if (VK_TAB == msg.wParam)
      {
      	SendMessage(CN_BASE + msg.message, msg.wParam, msg.lParam) ;
        return true ;
      }
    }
	}

	return false ;
}

//
// Let the form process keystrokes in its own way.  Without
// this method, you can't tab between control on the form.
//
bool
NSImpImgWindow::PreProcessMsg(MSG &msg)
{
	bool result = IsTabKeyMessage(msg) ;
	if (result)
    return true ;

	PRECONDITION(GetHandle()) ;
  return hAccelerator ? ::TranslateAccelerator(GetHandle(), hAccelerator, &msg) : false ;
}

// Fonction MakeVisiblevoid
NSImpImgWindow::MakeVisible()
{
  Form->Visible = true ;
}

// Fonction SetupWindow
////////////////////////////////////////////////////////////////
void
NSImpImgWindow::SetupWindow()
{
	TWindow::SetupWindow() ;

  ModifyStyle(WS_BORDER, WS_CHILD) ;
  Form->Show() ;
  MakeVisible() ;
}

// Fonction Navigate////////////////////////////////////////////////////////////////
void
NSImpImgWindow::Navigate()
{
  if ((NULL == Form) || (NULL == Form->Control))
    return ;

  string  url ;
  wchar_t buff[1024] ;
  Variant Flags(navNoReadFromCache) ;
  TVariant VFlags = Flags.operator TVariant() ;

  if (string("") != sHtml)
  {
  	url = sHtml ;
    MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, url.c_str(), -1, buff, sizeof(buff)) ;
    Form->Control->Navigate(buff, &VFlags) ;
  }
}

voidNSImpImgWindow::NavigateComplete(){  bool        bSucces = false ;
  WideString autoUrl = Form->Control->LocationURL ;  AnsiString url     = AnsiString(autoUrl) ;  string     sUrl    = string(url.c_str()) ;
  // R�cup�ration du fichier associ� � l'URL  size_t pos = sUrl.find_last_of("/") ;
  if (NPOS == pos)  {    // on doit normalement r�cup�rer une chaine du type : "file:///path/fichier"    // => on g�n�re une erreur s'il n'y a pas de '/'    erreur("Impossible de r�cup�rer le nom du fichier en cours.", standardError, 0, GetHandle()) ;    return ;	}
	string sFich = string(sUrl, pos+1, strlen(sUrl.c_str())-pos-1) ;
	// Si on a navigu� sur une image	// on l'importe automatiquement	if (!(sFich == string("pannel.htm")))	{  	if (!aImageArray.empty())    	for (NSImgIter i = aImageArray.begin(); i != aImageArray.end(); i++)      {      	if ((sFich == (*i)->fichier) || (sFich == (*i)->html))        {        	pNewDoc = new NSRefDocument(0, pContexte) ;          // cas de l'importation d'un fichier externe          if (pNewDoc->ImporterFichier((*i)->type, (*i)->fichier ,sPathName))          {          	// on stocke l'image pour la d�truire ult�rieurement            // car on ne peut pas le faire dans NavigateComplete()            aImportArray.push_back(new NSImage(*(*i))) ;
            // on enleve l'image du tableau            delete (*i) ;            aImageArray.erase(i) ;
            bSucces = true ;          }          else          	Navigate() ;
          break ;        }        else if (sFich == (*i)->supphtml)        {        	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;          int retVal = MessageBox("Etes-vous s�r de vouloir supprimer cette image?", sCaption.c_str(), MB_YESNO) ;          if (retVal == IDYES)          {          	// on stocke l'image pour une destruction ult�rieure            aSuppArray.push_back(new NSImage(*(*i))) ;            // on enl�ve l'image du tableau            delete (*i) ;            aImageArray.erase(i) ;          }          bSucces = true ;          break ;        }      }	}
	// Si l'importation a r�ussi, on r�affiche un nouveau pannel	if (bSucces)  {  	if (GenerePannel())    	Navigate() ;    else    	erreur("Erreur ==> Navigation annul�e.", standardError, 0, GetHandle()) ;	}}voidNSImpImgWindow::NavigateErrorEvent(int iStatusCode, string sURL)
{
	string ps = string("Ev : NavigateError for URL \"") + sURL + string("\"") ;
  ps += string(" (") + getNavigateErrorShortMsg(iStatusCode) + string(")") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;

  erreur(ps.c_str(), standardError, 0) ;
}
voidNSImpImgWindow::DetruireHtmlTemp(){  // Dans cette fonction, on ne d�truit que les liens html  // vers des images � importer ou � supprimer et non  // les fichiers image proprement dits.	// array des images restant � importer	if (false == aImageArray.empty())  	for (NSImgIter i = aImageArray.begin(); aImageArray.end() != i ; i++)    {    	if ((*i)->html != "")      {      	string sFichHtm = sPathName + (*i)->html ;
        if (!DeleteFile(sFichHtm.c_str()))        {        	string sMsg = "Pb � la destruction du fichier html associ� � l'image " + (*i)->fichier ;          erreur(sMsg.c_str(), standardError, 0, GetHandle()) ;        }        else        	(*i)->html = "" ;      }      if ((*i)->supphtml != "")      {      	string sFichHtm = sPathName + (*i)->supphtml ;
        if (!DeleteFile(sFichHtm.c_str()))        {        	string sMsg = "Pb � la destruction du fichier html associ� � l'image " + (*i)->fichier ;          erreur(sMsg.c_str(), standardError, 0, GetHandle()) ;        }        else        	(*i)->supphtml = "" ;      }    }	// array des images supprim�es du pannel	if (false == aSuppArray.empty())  	for (NSImgIter i = aSuppArray.begin(); aSuppArray.end() != i ; i++)    {    	if ((*i)->html != "")      {      	string sFichHtm = sPathName + (*i)->html ;
        if (!DeleteFile(sFichHtm.c_str()))        {        	string sMsg = "Pb � la destruction du fichier html associ� � l'image " + (*i)->fichier ;          erreur(sMsg.c_str(), standardError, 0, GetHandle()) ;        }        else        	(*i)->html = "" ;      }      if ((*i)->supphtml != "")      {      	string sFichHtm = sPathName + (*i)->supphtml ;
        if (!DeleteFile(sFichHtm.c_str()))        {        	string sMsg = "Pb � la destruction du fichier html associ� � l'image " + (*i)->fichier ;          erreur(sMsg.c_str(), standardError, 0, GetHandle()) ;        }        else        	(*i)->supphtml = "" ;      }    }}
boolNSImpImgWindow::InitImageArray(){  WIN32_FIND_DATA FileData ;  HANDLE          hSearch ;  char            szMask[255] ;  bool            bFinish = false ;  size_t          pos ;  string          sFileName, sExtension, sTypeNau ;  NSTypeMime      ficheTypeMime(pContexte) ;  NSTypeMimeInfo  infoTypeMime ;  DWORD           dwAttr ;  int             nbImg = 0, nbVid = 0 ;  string          sFichierHtml ;  string          sFichierSupp ;  aImageArray.vider() ;  aImportArray.vider() ;  aSuppArray.vider() ;  NSSuper* pSuper = pContexte->getSuperviseur() ;
  string ps = string("-- Entr�e dans InitImageArray") ;
  pSuper->trace(&ps, 1) ;  sPathName = pContexte->PathName("IHTM") ;  strcpy(szMask, sPathName.c_str()) ;  strcat(szMask, "*.*") ;
  hSearch = FindFirstFile(szMask, &FileData) ;
  if (hSearch == INVALID_HANDLE_VALUE)  {  	erreur("Aucun fichier trouv� dans le r�pertoire d'importation.", standardError, 0, GetHandle()) ;    return false ;  }
	while (!bFinish)  {    dwAttr = FileData.dwFileAttributes ;

    if (!(dwAttr & FILE_ATTRIBUTE_DIRECTORY))    {    	sFileName = string(FileData.cFileName) ;      // R�cup�ration de l'extension      pos = sFileName.find_last_of(".") ;    }
    if ((!(dwAttr & FILE_ATTRIBUTE_DIRECTORY)) && (pos != NPOS))    {    	sExtension = string(sFileName, pos+1, strlen(sFileName.c_str())-pos-1) ;
      ps = string("Fichier trouv� : ") + sFileName ;
      pSuper->trace(&ps, 1) ;

      ps = string("Extension : ") + sExtension ;
      pSuper->trace(&ps, 1) ;

      // On r�cup�re les infos du type mime li� � l'extension du fichier      if (/*ficheTypeMime.*/pContexte->getSuperviseur()->chercheTypeMimeInfo(sExtension, &infoTypeMime))      {      	sTypeNau = string(infoTypeMime.pDonnees->type) ;        ps = string("Type Nautilus : ") + sTypeNau ;        pSuper->trace(&ps, 1) ;
        if (pContexte->typeDocument(sTypeNau, NSSuper::isImageFixe))
        {          nbImg++ ;          sFichierHtml = "" ;          sFichierSupp = "" ;
          if (EncapsuleImage(sFileName, sTypeNau, nbImg, sFichierHtml, sFichierSupp))          	aImageArray.push_back(new NSImage(sFileName, sTypeNau, sFichierHtml, sFichierSupp)) ;          else          {          	string sMsg = "L'image " + sFileName + " ne peut etre import�e." ;            erreur(sMsg.c_str(), standardError, 0, GetHandle()) ;          }        }        else if (pContexte->typeDocument(sTypeNau, NSSuper::isImageAnimee))        {          nbVid++ ;          sFichierHtml = "" ;          sFichierSupp = "" ;
          if (EncapsuleImage(sFileName, sTypeNau, nbVid, sFichierHtml, sFichierSupp))          	aImageArray.push_back(new NSImage(sFileName, sTypeNau, sFichierHtml, sFichierSupp)) ;          else          {          	string sMsg = "La vid�o " + sFileName + " ne peut etre import�e.";            erreur(sMsg.c_str(), standardError, 0, GetHandle()) ;          }        }      }      else      {      	ps = string("Fiche TypeMime non trouv�e...") ;        pSuper->trace(&ps, 1) ;      }    }
    if (!FindNextFile(hSearch, &FileData))    {    	if (ERROR_NO_MORE_FILES == GetLastError())      	bFinish = true ;      else      {      	erreur("Impossible de trouver le fichier suivant dans le r�pertoire d'importation.", standardError, 0, GetHandle()) ;        return false ;      }    }  }  ps = string("-- Sortie de InitImageArray.") ;  pSuper->trace(&ps, 1) ;
  return true ;}
boolNSImpImgWindow::EncapsuleImage(string sFichier, string sType, int index, string& sFichHtml, string& sFichSupp){  string  sOut = "";  ofstream outFile;  char     fich[255];  char     fichsupp[255];  // On genere d'abord le fichier html image
  sOut += "<HTML>\n" ;  sOut += "<BODY>\n" ;
	if (pContexte->typeDocument(sType, NSSuper::isImageFixe))
  {  	sOut += "<IMG SRC=\"" ;    sprintf(fich, "image%d.htm", index) ;    sprintf(fichsupp, "image%d_x.htm", index) ;  }  else // cas des vid�os  {  	sOut += "<IMG START=1 LOOP=0 DYNSRC=\"" ;    sprintf(fich, "video%d.htm", index) ;    sprintf(fichsupp, "video%d_x.htm", index) ;  }
  sOut += sFichier + "\">\n" ;  sOut += "</BODY>\n" ;  sOut += "</HTML>\n" ;
  // On fixe le nom du fichier html associ�  // pour la visualisation et pour la suppression  string sPathHtml = sPathName + string(fich) ;  string sPathSupp = sPathName + string(fichsupp) ;
  // s'il existait d�j� il est d�truit  if (FileExists(AnsiString(sPathHtml.c_str())))  	if (!DeleteFile(sPathHtml.c_str()))    {    	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorDeletingFile") + string("") + sPathHtml ;      erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;      return false ;    }  if (FileExists(AnsiString(sPathSupp.c_str())))  	if (!DeleteFile(sPathSupp.c_str()))    {    	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorDeletingFile") + string("") + sPathSupp ;      erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;      return false ;    }
  // ecriture du fichier html
  outFile.open(sPathHtml.c_str());  if (!outFile)  {  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningOutputFile") + string(" ") + sFichier ;    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;    return false ;  }
  for (size_t i = 0; i < strlen(sOut.c_str()); i++)  	outFile.put(sOut[i]) ;  outFile.close() ;
  sFichHtml = string(fich) ;  sFichSupp = string(fichsupp) ;  // On genere maintenant le fichier servant � la suppression :  if (!CopyFile(sPathHtml.c_str(), sPathSupp.c_str(), false))  {    string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorCopyingFile") ;  	sErrorText += string(" ") + sPathHtml + string(" -> ") + sPathSupp ;
  	erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;    return false ;  }
	return true ;}
boolNSImpImgWindow::GenerePannel(){  string  sOut = "";  int     nbImages = 1;  ofstream outFile;
  sOut += "<HTML>\n";  sOut += "<HEAD>\n";  sOut += "<TITLE>Pannel d'importation</TITLE>\n";  sOut += "</HEAD>\n";  sOut += "<BODY>\n";  sOut += "<B>Choisissez une image � importer :</B>\n<HR>\n";
  sOut += "<TABLE BORDER=0 WIDTH=100%>\n";
  if (!aImageArray.empty())
  for (NSImgIter i = aImageArray.begin(); i != aImageArray.end(); i++)  {  	if (((nbImages - 1) % 4) == 0)    	sOut += "<TR ALIGN=\"center\">\n" ;    if (pContexte->typeDocument((*i)->type, NSSuper::isImageFixe))    {      sOut += "<TD><A HREF=\"" + (*i)->html + "\"> Importer </A><BR>\n" ;      sOut += "<A HREF=\"" + (*i)->html + "\">" ;      sOut += "<IMG SRC=\"" ;    }    else // cas des vid�os    {      sOut += "<TD><A HREF=\"" + (*i)->html + "\"> Importer </A><BR>\n" ;      sOut += "<A HREF=\"" + (*i)->html + "\">" ;      sOut += "<IMG START=1 LOOP=0 DYNSRC=\"" ;    }
    sOut += (*i)->fichier + "\" width=70 height=70>" ;    sOut += "</A><BR>\n<A HREF=\"" + (*i)->supphtml + "\"> Supprimer </A></TD>\n" ;
    if ((nbImages % 4) == 0)    	sOut += "</TR>\n" ;
    nbImages++ ;	}
	// si on est au milieu d'une ligne, on la termine � vide  if (((nbImages - 1) % 4) != 0)  {  	while (((nbImages - 1) % 4) != 0)    {    	sOut += "<TD></TD>\n" ;      nbImages++ ;    }
    sOut += "</TR>\n" ;	}
  sOut += "</TABLE>\n" ;  sOut += "</BODY>\n" ;  sOut += "</HTML>\n" ;
  // On fixe le nom du fichier pannel  sHtml = sPathName + string("pannel.htm") ;
	// s'il existait un pannel il est d�truit  if (FileExists(AnsiString(sHtml.c_str())))  	if (!DeleteFile(sHtml.c_str()))    	erreur("Pb � la destruction du fichier pannel html.", standardError, 0, GetHandle()) ;
	outFile.open(sHtml.c_str()) ;
	if (!outFile)	{  	erreur("Impossible de cr�er le fichier pannel html � g�n�rer", standardError, 0, GetHandle()) ;    return false ;	}
	for (size_t i = 0; i < strlen(sOut.c_str()); i++)  	outFile.put(sOut[i]) ;
	outFile.close() ;	return true ;}voidNSImpImgWindow::CmQuitter(){	bCanClose = true ;
	if (!aImageArray.empty())	{  	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    int retVal = MessageBox("Voulez-vous d�truire les images qui n'ont pas �t� import�es ?", sCaption.c_str(), MB_YESNO);
    if (IDYES == retVal)    {    	string sFichImg ;
      for (NSImgIter i = aImageArray.begin(); i != aImageArray.end(); i++)      {      	sFichImg = sPathName + (*i)->fichier ;
        if (!DeleteFile(sFichImg.c_str()))        {        	string sMsg = "Pb � la destruction de l'image " + (*i)->fichier ;          erreur(sMsg.c_str(), standardError, 0, GetHandle()) ;        }        else        	(*i)->fichier = "" ;      }    }	}
	CloseWindow() ;}
void
NSImpImgWindow::CmImporterTout()
{
	bool bOk = true ;
	bCanClose = true ;

	if (!aImageArray.empty())
  	for (NSImgIter i = aImageArray.begin(); i != aImageArray.end(); i++)    {    	pNewDoc = new NSRefDocument(0, pContexte) ;      // cas de l'importation d'un fichier externe (sans dialogue)      if (pNewDoc->ImporterFichier((*i)->type, (*i)->fichier ,sPathName, false))      {      	// on stocke l'image pour la d�truire ult�rieurement        aImportArray.push_back(new NSImage(*(*i))) ;      }      else      {      	erreur("Erreur lors de l'importation des images", standardError, 0, GetHandle()) ;        bOk = false ;        break ;      }    }

	// on d�truit aImageArray car les images sont d�j� dans aImportArray
	if (bOk)
		aImageArray.vider() ;

	CloseWindow() ;
}
/****************** classe NSImpImgChild **************************/
DEFINE_RESPONSE_TABLE1(NSImpImgChild, TMDIChild)   EV_WM_CLOSE,
   EV_COMMAND(CM_FILECLOSE, EvClose),
END_RESPONSE_TABLE;

NSImpImgChild::NSImpImgChild(NSContexte* pCtx, TMDIClient& parent, const char far* title, NSImpImgWindow* clientWnd)
              :TMDIChild(parent, title, clientWnd), NSRoot(pCtx)
{
	pClient = clientWnd ;
}

NSImpImgChild::~NSImpImgChild()
{
}

void
NSImpImgChild::EvClose()
{
	if (!pClient->bCanClose)
	{
		string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
		int retVal = MessageBox("Voulez-vous vraiment fermer l'importation ?", sCaption.c_str(), MB_YESNO) ;

		if (retVal == IDYES)
			TWindow::EvClose() ;
	}
	else
		TWindow::EvClose() ;
}

// *********************************// D�finition de la classe NSImage// *********************************
NSImage::NSImage(){  fichier  = "" ;  type     = "" ;  html     = "" ;  supphtml = "" ;}
NSImage::NSImage(string sFichier, string sType, string sFichHtml, string sFichSupp){  fichier  = sFichier ;  type     = sType ;  html     = sFichHtml ;  supphtml = sFichSupp ;
}
NSImage::~NSImage(){}
NSImage::NSImage(NSImage& rv){  fichier  = rv.fichier ;  type     = rv.type ;  html     = rv.html ;  supphtml = rv.supphtml ;
}
NSImage&NSImage::operator=(NSImage src){	if (this == &src)		return *this ;  fichier  = src.fichier ;  type     = src.type ;  html     = src.html ;  supphtml = src.supphtml ;
	return *this ;}
intNSImage::operator==(NSImage& o){	if ((fichier  == o.fichier) &&      (type     == o.type) &&      (html     == o.html) &&      (supphtml == o.supphtml))		return 1 ;
	else
		return 0 ;
}

// **********************************// D�finition de la classe NSImgArray// **********************************
//---------------------------------------------------------------------------//  Constructeur copie//---------------------------------------------------------------------------
/*
NSImgArray::NSImgArray(NSImgArray& rv) : NSImgVector(){    if (!rv.empty())	    for (NSImgIter i = rv.begin(); i != rv.end(); i++)   	        push_back(new NSImage(*(*i)));}
//---------------------------------------------------------------------------//  Destructeur//---------------------------------------------------------------------------
voidNSImgArray::vider(){    if (!empty())	    for (NSImgIter i = begin(); i != end(); )        {   	        delete *i;            erase(i);        }}
NSImgArray::~NSImgArray(){	vider();}           *//****************** classe NSLogWindow **************************/
DEFINE_RESPONSE_TABLE1(NSLogWindow, TWindow)	 EV_WM_CLOSE,
END_RESPONSE_TABLE;

NSLogWindow::NSLogWindow(TWindow* parent, string sFichier, NSContexte* pCtx)						:TWindow(parent)
{
  sFileName = sFichier ;
  pContexte = pCtx ;
  pNewDoc = 0 ;
  bCanClose = false ;

  TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;
  if (NULL != pMyApp)    pMyApp->setMenu(string("menubar"), &hAccelerator) ;
}

NSLogWindow::~NSLogWindow()
{
	if (sHtml != "")
	{
		if (!DeleteFile(sHtml.c_str()))
			erreur("Pb � la destruction du fichier html temporaire.", standardError, 0, GetHandle()) ;
	}

	// Delete de la Form
	delete Form;
	// CoUninitialize();
	OleUninitialize() ;

  if (0 != hAccelerator)
  {
    DestroyAcceleratorTable(hAccelerator) ;
    hAccelerator = 0 ;
  }
}

void
NSLogWindow::EvClose()
{
  TWindow::EvClose() ;
}

//
// Override a TWindow virtual to create the HWND directly.
// NSImportWindow and the VCL TForm1 class both end up
// wrapping the same HWND.
//
void
NSLogWindow::PerformCreate(int /*menuOrId*/)
{
	// CoInitialize(NULL);
  OleInitialize(NULL);    // Use OleInitialize to get clipboard functionality
	Form = new TWebLog(Parent->GetHandle(), this);
	Form->Visible = false;
	Form->ParentWindow = Parent->HWindow;
	SetHandle(Form->Handle);
	::SetParent(Forms::Application->Handle, pContexte->GetMainWindow()->HWindow);

	// on navigue vers le fichier html � importer
	Navigate();
}

boolNSLogWindow::IsTabKeyMessage(MSG &msg)
{
  if (GetCapture() == NULL)
  {
    if (WM_KEYDOWN == msg.message || WM_KEYUP == msg.message)
    {
      if (VK_TAB == msg.wParam)
      {
        SendMessage(CN_BASE + msg.message, msg.wParam, msg.lParam) ;
        return true ;
      }
    }
  }

  return false ;
}

//
// Let the form process keystrokes in its own way.  Without
// this method, you can't tab between control on the form.
//
bool
NSLogWindow::PreProcessMsg(MSG &msg)
{
  bool result = IsTabKeyMessage(msg) ;
	if (result)
    return true ;

	PRECONDITION(GetHandle()) ;
  return hAccelerator ? ::TranslateAccelerator(GetHandle(), hAccelerator, &msg) : false ;
}

// Fonction MakeVisible
void
NSLogWindow::MakeVisible()
{
	Form->Visible = true ;
}

// Fonction SetupWindow
////////////////////////////////////////////////////////////////
void
NSLogWindow::SetupWindow()
{
  TWindow::SetupWindow() ;

  ModifyStyle(WS_BORDER, WS_CHILD) ;
  Form->Show() ;
  MakeVisible() ;

  pContexte->setAideIndex("") ;
  pContexte->setAideCorps("dpio_log.htm") ;
}

// Fonction Navigate////////////////////////////////////////////////////////////////
void
NSLogWindow::Navigate()
{
  if ((NULL == Form) || (NULL == Form->Control))
    return ;

  wchar_t buff[1024] ;
  Variant Flags(navNoReadFromCache) ;
  TVariant VFlags = Flags.operator TVariant() ;

  MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, sFileName.c_str(), -1, buff, sizeof(buff)) ;
  Form->Control->Navigate(buff, &VFlags) ;
}

void
NSLogWindow::NavigateErrorEvent(int iStatusCode, string sURL)
{
	string ps = string("Ev : NavigateError for URL \"") + sURL + string("\"") ;
  ps += string(" (") + getNavigateErrorShortMsg(iStatusCode) + string(")") ;
	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trError) ;

  erreur(ps.c_str(), standardError, 0) ;
}

void
NSLogWindow::Refresh()
{
  Form->Control->Refresh() ;
}

string
NSLogWindow::html2string(string s2convert)
{
	string	sResult = s2convert ;
	size_t  iBeginPos = sResult.find("<") ;
	while (iBeginPos != string::npos)
	{
		int	iEndPos = sResult.find(">") + 1 ;
		sResult.erase(iBeginPos, iEndPos - iBeginPos) ;
		iBeginPos = sResult.find("<") ;
	}
	return texteCourant(sResult) ;
}

void
NSLogWindow::CmClipCopy()
{
	if (OpenClipboard())
	{
		string		sclipdata = html2string(pContexte->getSuperviseur()->getDPIO()->getLogPage()) ;

		HGLOBAL		clipbuffer ;
		char			*buffer ;
		
		EmptyClipboard(); // Empty whatever's already there

		clipbuffer	= GlobalAlloc(GMEM_DDESHARE, strlen(sclipdata.c_str()) + 1) ;
		buffer			= (char *)GlobalLock(clipbuffer) ;
		strcpy(buffer, sclipdata.c_str()) ;
		GlobalUnlock(clipbuffer) ;
		SetClipboardData(CF_TEXT, clipbuffer) ; // Send the data
		CloseClipboard() ; // VERY IMPORTANT
	}
}

void
NSLogWindow::CmFermer()
{
  string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
  int retVal = MessageBox("Voulez-vous vraiment fermer ?", sCaption.c_str(), MB_YESNO) ;

  if (retVal == IDYES)
  {
    bCanClose = true ;
    if (pContexte && (pContexte->getSuperviseur()) && (pContexte->getSuperviseur()->getDPIO()))
    {
      pContexte->getSuperviseur()->getDPIO()->pLogWnd    = 0 ;
      pContexte->getSuperviseur()->getDPIO()->pLogMDIWnd = 0 ;
    }
    CloseWindow() ;
  }
}

void
NSLogWindow::CmImprimer()
{
  IDispatch* pdisp = Form->Control->Document ;
  IOleCommandTarget* command ;
  pdisp->QueryInterface(IID_IOleCommandTarget, (void**)&command) ;
  if (command)
  {
    command->Exec(NULL, Shdocvw_tlb::OLECMDID_PRINT, Shdocvw_tlb::OLECMDEXECOPT_DONTPROMPTUSER, NULL, NULL) ;
    command->Release() ;
  }
  pdisp->Release() ;
}

/****************** classe NSImportChild **************************/DEFINE_RESPONSE_TABLE1(NSLogChild, TMDIChild)
	 EV_WM_CLOSE,
	 EV_COMMAND(CM_FILECLOSE, EvClose),
END_RESPONSE_TABLE;

NSLogChild::NSLogChild(NSContexte* pCtx, TMDIClient& parent, const char far* title, NSLogWindow* clientWnd)					 :TMDIChild(parent, title, clientWnd), NSRoot(pCtx)
{
	pClient = clientWnd ;
}

NSLogChild::~NSLogChild()
{
}

voidNSLogChild::EvClose()
{
	if (!pClient->bCanClose)
	{
		string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
		int retVal = MessageBox("Voulez-vous vraiment fermer ?", sCaption.c_str(), MB_YESNO) ;

		if (IDYES == retVal)
			TWindow::EvClose() ;
	}
	else
		TWindow::EvClose() ;
}
////////////////////////// fin de nsbrowse.cpp ///////////////////////////////
