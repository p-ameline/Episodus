//**************************************************************************//  NOM du FICHIER  : nshistor.CPP : chemises et documents sous forme de TreeView
//  								  Kaddachi Hafedh 20/01/1998
//**************************************************************************

#define __NSHISTOR_CPP

#include <owl\owlpch.h>
#include <owl\validate.h>
#include <owl\inputdia.h>
#include <fstream.h>

#include "partage\nsdivfct.h"
#include "nautilus\nshistor.h"
#include "nautilus\nssuper.h"
#include "nautilus\nautilus.rh"
#include "nautilus\nsmodhtm.h"
#include "nautilus\nsdocaga.h"
#include "nautilus\nsepicap.h"
#include "nsbb\nsattvaltools.h"

//----------------------------------------------------------------------
//----------------------------------------------------------------------
//									 Classe NsHistorique
//----------------------------------------------------------------------
//----------------------------------------------------------------------

DEFINE_RESPONSE_TABLE2(NsHistorique, TView, NSTreeHistorique)
	//	EV_COMMAND (WM_RAFRAICHIR, Rafraichir),
  EV_WM_CLOSE,
  EV_WM_DESTROY,
  EV_WM_SETFOCUS,
  EV_VN_ISWINDOW,
  EV_WM_SYSCOMMAND,
  EV_COMMAND(CM_FILECLOSE, EvClose),
  EV_COMMAND_ENABLE(CM_FILECLOSE, CeFileClose),

  EV_COMMAND(CM_IMPRIME, CmPublier),

 	EV_COMMAND(CM_0P,  Cm0Plus),
  EV_COMMAND(CM_1P,  Cm1Plus),
  EV_COMMAND(CM_2P,  Cm2Plus),
  EV_COMMAND(CM_3P,  Cm3Plus),  EV_COMMAND(CM_4P,  Cm4Plus),

  EV_COMMAND_ENABLE(CM_0P,  Ce0Plus),
  EV_COMMAND_ENABLE(CM_1P,  Ce1Plus),
  EV_COMMAND_ENABLE(CM_2P,  Ce2Plus),
  EV_COMMAND_ENABLE(CM_3P,  Ce3Plus),
  EV_COMMAND_ENABLE(CM_4P,  Ce4Plus),
END_RESPONSE_TABLE;

NsHistorique::NsHistorique(NSHISTODocument& doc, TWindow* parent)
             :TView(doc), pDoc(&doc),
              NSTreeHistorique(parent, doc.pContexte, GetNextViewId(), 0,0,0,0, &doc)
{
	NSSuper* pSuper = doc.pContexte->getSuperviseur() ;

  pMUEViewMenu = 0 ;
  TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;
  pMyApp->setMenu(string("menubar_histo"), &hAccelerator) ;
	// initMUEViewMenu("menubar_histo") ;

	bSetupToolBar = true ;
}

TWindow*NsHistorique::GetWindow()
{
   return (TWindow*) this;
}

//----------------------------------------------------------------------//			Destructeur
//----------------------------------------------------------------------
NsHistorique::~NsHistorique()
{
	if (pMUEViewMenu)
  	delete pMUEViewMenu ;

  if (0 != hAccelerator)
  {
    DestroyAcceleratorTable(hAccelerator) ;
    hAccelerator = 0 ;
  }
}

//---------------------------------------------------------------------------// SetupWindow
//---------------------------------------------------------------------------
void
NsHistorique::SetupWindow()
{
	SetWindowPosHisto();
	Parent->SetCaption("Historique");
	NSTreeHistorique::SetupWindow();
}

bool
NsHistorique::PreProcessMsg(MSG &msg)
{
  PRECONDITION(GetHandle()) ;
  return hAccelerator ? ::TranslateAccelerator(GetHandle(), hAccelerator, &msg) : false ;
}

//-------------------------------------------------------------------------//demander � NSTreeHistorique d'afficher pNSDocumentHisto
//-------------------------------------------------------------------------
void
NsHistorique::Rafraichir(NSDocumentInfo* pNSDocumentInfo, NSPatPathoArray* pNSPatPathoArray,
                         NSNoyauDocument* pNouveauDocument)
{
	NSTreeHistorique* pNSTreeHistorique = this ;
	pNSTreeHistorique->AjouteDocument(pNSDocumentInfo, pNSPatPathoArray, pNouveauDocument) ;
}

//-----------------------------------------------------------------------//demander l'autorisation de NSTreeHistorique de l'ouverture du document
//-----------------------------------------------------------------------
void
NsHistorique::AutoriserOuverture(NSDocumentInfo* pDocument)
{
 	NSTreeHistorique* pNSTreeHistorique = this ;
	pNSTreeHistorique->AutoriserOuverture(pDocument) ;
}

//-----------------------------------------------------------------------//demander l'autorisation de NSTreeHistorique de l'�dition du document
//-----------------------------------------------------------------------
void
NsHistorique::AutoriserEdition(NSDocumentInfo* pDocument)
{
 	NSTreeHistorique* pNSTreeHistorique = this ;
	pNSTreeHistorique->AutoriserEdition(pDocument) ;
}

//-------------------------------------------------------------------------
//demander � NSTreeHistorique d'enlever le document pNSDocumentInfo
//-------------------------------------------------------------------------
void
NsHistorique::EnleverDocument(NSDocumentInfo* pNSDocumentInfo)
{
	NSTreeHistorique* pNSTreeHistorique = this ;
	pNSTreeHistorique->EnleverDocument(pNSDocumentInfo) ;
}

//-------------------------------------------------------------------------
//demander � NSTreeHistorique d'ajouter le document pNSDocumentInfo
//-------------------------------------------------------------------------
void
NsHistorique::AjouterDocument(NSDocumentInfo* pNSDocumentInfo)
{
	NSTreeHistorique* pNSTreeHistorique = this ;
	pNSTreeHistorique->Ajouter(pNSDocumentInfo) ;
}

//-------------------------------------------------------------------------
//rafra�chir l'historique en tenant compte des changements (exemple patpatho)
//de pNSDocumentHisto
//-------------------------------------------------------------------------
void
NsHistorique::VisualiserPatho(NSDocumentInfo* pNSDocumentInfo, NSPatPathoArray* pNSPatPathoArray)
{
	NSTreeHistorique* pNSTreeHistorique = this ;
	pNSTreeHistorique->VisualiserPatho(pNSDocumentInfo, pNSPatPathoArray) ;
}

//-------------------------------------------------------------------------
//demander � NSTreeHistorique de changer la BITmap d'un document qui vient d'�tre
//ferm�
//-------------------------------------------------------------------------
void
NsHistorique::FermetureDocument(NSDocumentInfo* pDocumentInfo)
{
	NSTreeHistorique* pNSTreeHistorique = this ;
	pNSTreeHistorique->FermetureDocument(pDocumentInfo) ;
}

//---------------------------------------------------------------------------
//fixer la position de la fiche historique
//---------------------------------------------------------------------------
void
NsHistorique::SetWindowPosHisto()
{
  Parent->Show(SW_HIDE) ;

  NS_CLASSLIB::TRect rectDlg = Parent->GetWindowRect() ;//coordonn�es par % � l'�cran

  NS_CLASSLIB::TPoint point(rectDlg.X(), rectDlg.Y()) ;
  Parent->Parent->ScreenToClient(point) ;
  int X = rectDlg.X() ;
  int Y = rectDlg.Y() ;
  int W = rectDlg.Width() ;
  int H = rectDlg.Height() ;

  NSWindowProperty* pWinProp = pContexte->getUtilisateur()->aWinProp.getProperty("History") ;
  if (pWinProp)
  {
    X = pWinProp->X() ;
    Y = pWinProp->Y() ;
    W = pWinProp->W() ;
    H = pWinProp->H() ;
  }

  //
  // fixer la nouvelle position
  // (on ne tient pas compte de la taille, vu le probleme pour restaurer
  //  une fenetre TView,TWindow mise en icone)
  //
	Parent->SetWindowPos(0, X, Y, W, H, SWP_NOZORDER) ;
  Parent->Show(SW_SHOWNORMAL) ;

  /************************************
  if (sTaille == "I")
      Parent->Show(SW_SHOWMINIMIZED);
  else if (sTaille == "Z")
      Parent->Show(SW_SHOWMAXIMIZED);
  else
      Parent->Show(SW_SHOWNORMAL);
  *************************************/
}

//---------------------------------------------------------------------------//enregistrer la position de la fiche historique la base UTILISAT.DB
//---------------------------------------------------------------------------
void
NsHistorique::EnregistrePosHisto()
{
	if (!pContexte->getUtilisateur()->bEnregWin)
  	return ;

	NS_CLASSLIB::TRect rectDlg = Parent->GetWindowRect() ;//coordonn�es par % � l'�cran
  int X, Y, W, H ;
  NS_CLASSLIB::TPoint point(rectDlg.X(), rectDlg.Y()) ;
  Parent->Parent->ScreenToClient(point) ;
  X = point.X() ;
  Y = point.Y() ;
  W = rectDlg.Width() ;
  H = rectDlg.Height() ;

	if (Parent->IsIconic())
  	return ;

	string sUserId = pContexte->getUtilisateur()->getNss() ;
	NS_CLASSLIB::TRect  rect(X, Y, X + W, Y + H) ;
  NSWindowProperty wndProp ;
  wndProp.setX(X) ;
  wndProp.setY(Y) ;
  wndProp.setW(W) ;
  wndProp.setH(H) ;
  wndProp.setActivity(NSWindowProperty::undefined) ;
  wndProp.setFunction("History") ;

  pContexte->getUtilisateur()->aWinProp.saveWindowProperty(sUserId, pContexte->PathName("FGLO"), &wndProp, false) ;
  pContexte->getUtilisateur()->aWinProp.saveWindowProperty(sUserId, pContexte->PathName("FGLO"), &wndProp, true) ;
  //pContexte->getUtilisateur()->aWinProp.setProperty(sUserId, "History", rect, pContexte->PathName("FGLO")) ;
}

voidNsHistorique::EvSysCommand(uint cmdType, NS_CLASSLIB::TPoint&)
{
	switch (cmdType&  0xFFF0)
	{
  	case SC_CLOSE:
    	break ;
    default:
    	DefaultProcessing() ;
	}
}

void
NsHistorique::CeFileClose(TCommandEnabler& ce)
{
	ce.Enable(false) ;
}

void
NsHistorique::EvClose()
{
}

voidNsHistorique::EvDestroy()
{
	EnregistrePosHisto() ;
}

//---------------------------------------------------------------------------// Lib�ration de la derni�re barre d'outils cr�ee
//---------------------------------------------------------------------------
void
NsHistorique::EvSetFocus(THandle hWndLostFocus /* may be 0 */)
{
	// activateMUEViewMenu() ;

	TMyApp* pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;

	NSTreeHistorique::EvSetFocus(hWndLostFocus) ;  pMyApp->setMenu(string("menubar_histo"), &hAccelerator) ;
	if (bSetupToolBar && (GetWindow() != pMyApp->GetToolBarWindow()))	{
		SetupHistoBar() ;
		pMyApp->SetToolBarWindow(GetWindow()) ;
	}
}

voidNsHistorique::Cm0Plus()
{
	NSTreeHistorique* pNSTreeHistorique = this ;

	if(pNSTreeHistorique->sImportance == "A")
	{
  	pNSTreeHistorique->sImportance = "" ;
    pNSTreeHistorique->EnlevePatho() ;//enlever les pathos des documents
	}
	else
	{
  	pNSTreeHistorique->sImportance = "A" ;
   	//affichage des patpathos des compte rendus et des consultations
   	pNSTreeHistorique->AffichePatho() ;
	}
}

voidNsHistorique::Cm1Plus()
{
	NSTreeHistorique* pNSTreeHistorique = this ;

	if (pNSTreeHistorique->sImportance == "B")
	{
  	pNSTreeHistorique->sImportance = "" ;
    pNSTreeHistorique->EnlevePatho() ; //enlever les pathos des documents
	}
	else
	{
  	pNSTreeHistorique->sImportance = "B" ;
   	//affichage des patpathos des compte rendus et des consultations
   	pNSTreeHistorique->AffichePatho() ;
	}
}

voidNsHistorique::Cm2Plus()
{
	NSTreeHistorique* pNSTreeHistorique = this ;

	if (pNSTreeHistorique->sImportance == "C")
	{
  	pNSTreeHistorique->sImportance = "" ;
    pNSTreeHistorique->EnlevePatho() ;//enlever les pathos des documents
	}
	else
	{
  	pNSTreeHistorique->sImportance = "C" ;
   	//affichage des patpathos des compte rendus et des consultations
   	pNSTreeHistorique->AffichePatho() ;
	}
}

voidNsHistorique::Cm3Plus()
{
	NSTreeHistorique* pNSTreeHistorique = this ;

	if (pNSTreeHistorique->sImportance == "D")
	{
  	pNSTreeHistorique->sImportance = "" ;
    pNSTreeHistorique->EnlevePatho() ;//enlever les pathos des documents
	}
  else
	{
  	pNSTreeHistorique->sImportance = "D" ;
   	//affichage des patpathos des compte rendus et des consultations
   	pNSTreeHistorique->AffichePatho() ;
	}
}

voidNsHistorique::Cm4Plus()
{
	NSTreeHistorique* pNSTreeHistorique = this ;

	if (pNSTreeHistorique->sImportance == "E")
	{
  	pNSTreeHistorique->sImportance = "" ;
    pNSTreeHistorique->EnlevePatho() ;//enlever les pathos des documents
	}
	else
	{
  	pNSTreeHistorique->sImportance = "E" ;
   	//affichage des patpathos des compte rendus et des consultations
   	pNSTreeHistorique->AffichePatho() ;
	}
}

voidNsHistorique::CmPublier()
{
	NSTreeHistorique* pTreeHis = this ;

	// on doit avoir un utilisateur pour lancer le pDocRefHisto
	if (pContexte->getUtilisateur() == 0)
  	return ;

	if (pDoc->pHtmlCS)
  	delete pDoc->pHtmlCS ;

	pDoc->pHtmlCS = new NSHtml(tCS) ; 	// htmlNode racine du html de consultation

	InscrireHtml(pDoc->pHtmlCS) ;

  // on ne contr�le pas si l'historique est vide
  // car il contient au moins la synth�se
  // on ne doit pas deleter pDocRefHisto car cela est fait
  // par la VisualView en fin d'impression

  pContexte->getUtilisateur()->pDocRefHisto = new NSHistoRefDocument(pDoc, pTreeHis->sImportance) ;
  pContexte->getUtilisateur()->pDocRefHisto->Publier() ;
}

voidNsHistorique::Ce0Plus(TCommandEnabler& ce)
{
	uint result = 0;
	NSTreeHistorique* pNSTreeHistorique = this ;

	if (pNSTreeHistorique->sImportance == "A")
  	result = 1 ;

	ce.SetCheck(result  ? TCommandEnabler::Checked : TCommandEnabler::Unchecked) ;
}

voidNsHistorique::Ce1Plus(TCommandEnabler& ce)
{
	uint result = 0 ;
	NSTreeHistorique* pNSTreeHistorique = this ;

	if (pNSTreeHistorique->sImportance == "B")  	result = 1 ;

	ce.SetCheck(result  ? TCommandEnabler::Checked : TCommandEnabler::Unchecked) ;
}

voidNsHistorique::Ce2Plus(TCommandEnabler& ce)
{
	uint result = 0 ;
	NSTreeHistorique* pNSTreeHistorique = this ;

	if (pNSTreeHistorique->sImportance == "C")
  	result = 1 ;

	ce.SetCheck(result  ? TCommandEnabler::Checked : TCommandEnabler::Unchecked) ;
}

voidNsHistorique::Ce3Plus(TCommandEnabler& ce){
	uint result = 0;
	NSTreeHistorique* pNSTreeHistorique = this ;

	if (pNSTreeHistorique->sImportance == "D")
  	result = 1 ;

	ce.SetCheck(result  ? TCommandEnabler::Checked : TCommandEnabler::Unchecked) ;
}

voidNsHistorique::Ce4Plus(TCommandEnabler& ce)
{
	uint result = 0 ;
	NSTreeHistorique* pNSTreeHistorique = this ;

	if (pNSTreeHistorique->sImportance == "E")
  	result = 1 ;

	ce.SetCheck(result  ? TCommandEnabler::Checked : TCommandEnabler::Unchecked) ;
}

voidNsHistorique::SetupHistoBar()
{
	TMyApp* pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;
	pMyApp->FlushControlBar() ;

	pMyApp->cb2->Insert(*new TButtonGadget(CM_0P, CM_0P, TButtonGadget::Command)) ;
	pMyApp->cb2->Insert(*new TButtonGadget(CM_1P, CM_1P, TButtonGadget::Command)) ;
	pMyApp->cb2->Insert(*new TButtonGadget(CM_2P, CM_2P, TButtonGadget::Command)) ;
	pMyApp->cb2->Insert(*new TButtonGadget(CM_3P, CM_3P, TButtonGadget::Command)) ;
	pMyApp->cb2->Insert(*new TButtonGadget(CM_4P, CM_4P, TButtonGadget::Command)) ;

	pMyApp->cb2->LayoutSession() ;
}

// Fonction CanClose////////////////////////////////////////////////////////////////
bool
NsHistorique::CanClose()
{
	// on ruse avec un bool�en dans PatientChoisi
	// pour r�soudre le bug de la sauvegarde lors de la fermeture historique
	if ((pContexte->getPatient()) && (pContexte->getPatient()->bCanCloseHisto))
	{
		TMyApp* pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;
		pMyApp->FlushControlBar() ;
		bSetupToolBar = false ;
		return true ;
	}

	return false ;
}

voidNsHistorique::InscrireHtml(NSHtml* pHtml)
{
	NSHtml htmlNode(tConsult) ;
	int		 cpt = 0 ;

	if (pNodeArray->empty())
		return ;

	for (iterNSTreeNode i = pNodeArray->begin(); i != pNodeArray->end(); i++)
	{
  	// on prend les �l�ments de premier niveau
    if ((*i)->pere == 0)
    {
    	cpt++ ;

      if ((*i)->pControle)
      {
      	htmlNode.sTexte = (*i)->GetText() ;
        if (!(((*i)->VectFrereLie).empty()))
        {
        	for (iterNSTreeNode j = ((*i)->VectFrereLie).begin(); j != ((*i)->VectFrereLie).end(); j++)
          {
          	htmlNode.sTexte += " " ;
            htmlNode.sTexte += (*j)->GetText() ;
          }
        }
        pHtml->filsArray.push_back(new NSHtml(htmlNode)) ;
        InscrireFils(*i, pHtml->filsArray[pHtml->filsArray.size() - 1]) ;
        // bConsultVide = false;
      }
      else if (cpt == 1)
      {
      	// bConsultVide = true;
        return ;
      }
    }
  }
}

voidNsHistorique::InscrireFils(NSTreeNode* pNode, NSHtml* pHtml)
{
	NS_CLASSLIB::TRect	 rectItem;
  NSHtml htmlNode(tConsult);

  // s'il existe des fils visibles
  if ((!pNode->VectFils.empty()) && ((pNode->VectFils[0])->GetItemRect(rectItem)))
  {
		for (iterNSTreeNode i = pNode->VectFils.begin(); i != pNode->VectFils.end(); i++)
    {
    	if ((*i)->pControle)
      {
      	htmlNode.sTexte = (*i)->GetText();
        if (!(((*i)->VectFrereLie).empty()))
        {
        	for (iterNSTreeNode j = ((*i)->VectFrereLie).begin(); j != ((*i)->VectFrereLie).end(); j++)
          {
          	htmlNode.sTexte += " ";
            htmlNode.sTexte += (*j)->GetText();
          }
        }
        pHtml->filsArray.push_back(new NSHtml(htmlNode));
        InscrireFils(*i, pHtml->filsArray[pHtml->filsArray.size() - 1]);
      }
    }
  }
}

voidNsHistorique::initMUEViewMenu(string sMenuName)
{
	if (pMUEViewMenu)
  	delete pMUEViewMenu ;

	nsMenuIniter menuIter(pDoc->pContexte) ;
	pMUEViewMenu = new OWL::TMenuDescr ;
  menuIter.initMenuDescr(pMUEViewMenu, sMenuName) ;

	return ;
}

void
NsHistorique::activateMUEViewMenu()
{
	if (!pMUEViewMenu)
		return ;

	TMyApp* pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;
  pMyApp->GetMainWindow()->SetMenuDescr(*pMUEViewMenu) ;
	return ;
}
