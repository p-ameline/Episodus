//----------------------------------------------------------------------------
// ObjectWindows - (C) Copyright 1991, 1993 by Borland International
//   Tutorial application -- step12dv.cpp
//----------------------------------------------------------------------------
#include <owl\owlpch.h>
#include <owl\dc.h>

#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"
#include "nautilus\nsdecode.h"
#include "nsbb\nsbb.h"
#include "nsbb\nsbbsmal.h"
#include "nautilus\nsrechd2.h"

#include "nautilus\nscqdoc.h"
#include "nautilus\nscqvue.h"
#include "nautilus\ns_html.h"
#include "nautilus\nshistdo.h"
#include "dcodeur\decoder.h"
#include "nautilus\nsldvdoc.h"
#include "nsbb\nsarc.h"
#include "nssavoir\nsgraphe.h"

# include "ns_ob1\InterfaceForKs.h"

// --------------------------------------------------------------------------
// ---------------------- METHODES DE NSCQDocument --------------------------
// --------------------------------------------------------------------------

NSCQDocument::NSCQDocument(TDocument* parent, NSDocumentInfo* pDocumentInfo,
    					    NSDocumentInfo* pDocHtmlInfo, NSContexte* pCtx, bool bROnly,
                  string sDefaultArc, bool bDefArch)
                :NSRefDocument(parent, pDocumentInfo, pDocHtmlInfo, pCtx, bROnly)
{
	pBigBoss      = 0 ;
	pParseur      = 0 ;
	// Il s'agit ici d'un document enregistr� : le nom de l'archetype
	// sera donc r�cup�r� dans la patpatho du document
	sArchetype         = string("") ;
  _sDefaultArchetype = sDefaultArc ;
  _bForceDefaultArch = bDefArch ;

  pKSdescriptor = NULL ;

	sHtmlView     = string("") ;
  _sSemDocType  = string("") ;

	bCreate       = false ;
	bParsingOk    = ouvreArchetype() ;
  if (bParsingOk)
  {
    string sDocLib = findTitle() ;
    if (string("") != sDocLib)
      SetTitle(sDocLib.c_str()) ;
  }

	iTypeDoc      = NSCQDocument::standard ;
}

NSCQDocument::NSCQDocument(TDocument* parent, NSContexte* pCtx, string sArc,
                  int iTypeFormulaire, string sDefaultArc, bool bDefArch)
             :NSRefDocument(parent, pCtx)
{
	bReadOnly		  = false ;

	pBigBoss      = 0 ;
	pParseur      = 0 ;
	// Il s'agit ici d'un document vierge : on doit donc transmettre le nom
	// de l'archetype (car la patpatho est vide)
	sArchetype         = sArc ;
  _sDefaultArchetype = sDefaultArc ;
  _bForceDefaultArch = bDefArch ;

  pKSdescriptor = NULL ;

	sHtmlView     = string("") ;
  _sSemDocType  = string("") ;

	bCreate       = true ;
	bParsingOk    = ouvreArchetype() ;
  if (bParsingOk)
  {
    string sDocLib = findTitle() ;
    if (string("") != sDocLib)
      SetTitle(sDocLib.c_str()) ;
  }

	iTypeDoc      = iTypeFormulaire ;
}

NSCQDocument::NSCQDocument(TDocument* parent, NSContexte* pCtx, BB1BBInterfaceForKs* pKSdesc)
             :NSRefDocument(parent, pCtx)
{
	bReadOnly		  = false ;

	pBigBoss      = 0 ;
	pParseur      = 0 ;
	// Il s'agit ici d'un document vierge : on doit donc transmettre le nom
	// de l'archetype (car la patpatho est vide)
	sArchetype         = pKSdesc->getArchetypeID() ;
  _sDefaultArchetype = string("") ;
  _bForceDefaultArch = false ;
  pKSdescriptor      = new BB1BBInterfaceForKs(*pKSdesc) ;
	sHtmlView          = string("") ;
  _sSemDocType       = string("") ;

	bCreate       = true ;
  pKSdescriptor->setInitFromBbk(true) ;

	bParsingOk    = ouvreArchetype() ;
  if (bParsingOk)
  {
    string sDocLib = findTitle() ;
    if (string("") != sDocLib)
      SetTitle(sDocLib.c_str()) ;
  }

	iTypeDoc      = NSCQDocument::dpio ;
}

NSCQDocument::NSCQDocument(NSCQDocument& rv)
             :NSRefDocument(rv)
{
	if (rv.pBigBoss)
		pBigBoss = new NSSmallBrother(*(rv.pBigBoss)) ;
	else
		pBigBoss = 0;

	pParseur           = new nsarcParseur(*(rv.pParseur)) ;
	sArchetype         = rv.sArchetype ;  _sSemDocType       = rv._sSemDocType ;  _sDefaultArchetype = rv._sDefaultArchetype ;  _bForceDefaultArch = rv._bForceDefaultArch ;  if (rv.pKSdescriptor)  	pKSdescriptor = new BB1BBInterfaceForKs(*(rv.pKSdescriptor)) ;  else  	pKSdescriptor = NULL ;	sHtmlView   = rv.sHtmlView ;	bCreate     = rv.bCreate ;	bParsingOk  = rv.bParsingOk ;	iTypeDoc    = rv.iTypeDoc ;}

NSCQDocument::~NSCQDocument()
{
	if (pParseur != NULL)
		delete pParseur ;

  if (pKSdescriptor != NULL)
		delete pKSdescriptor ;
}

NSCQDocument&
NSCQDocument::operator=(NSCQDocument& src)
{
  if (this == &src)
		return *this ;

	NSRefDocument *dest, *source ;

	// Appel de l'operateur = de NSRefDocument	// (recopie des arguments de la classe NSRefDocument)
	dest = this ;
	source = &src ;
	*dest = *source ;

  if (pBigBoss)
  	delete pBigBoss ;
	if (src.pBigBoss)
  	pBigBoss = new NSSmallBrother(*(src.pBigBoss)) ;
	else
		pBigBoss = 0 ;

	pParseur           = new nsarcParseur(*(src.pParseur));
	sArchetype         = src.sArchetype ;  _sDefaultArchetype = src._sDefaultArchetype ;  _bForceDefaultArch = src._bForceDefaultArch ;  if (pKSdescriptor)  	delete pKSdescriptor ;  if (src.pKSdescriptor)  	pKSdescriptor = new BB1BBInterfaceForKs(*(src.pKSdescriptor)) ;  else  	pKSdescriptor = NULL ;	sHtmlView    = src.sHtmlView ;  _sSemDocType = src._sSemDocType ;	bCreate      = src.bCreate ;	bParsingOk   = src.bParsingOk ;	iTypeDoc     = src.iTypeDoc ;
	return *this ;}

bool
NSCQDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
    						string sAdresseCorresp, string sPathDest)
{
	string   		sFichierHtml ;
	NSHtmlCQ 		hcq(typeOperation, this, pContexte, sAdresseCorresp) ;
	string			sBaseImg ;
	// NSBaseImages* 	pBase;

	// on trouve le nom du fichier temporaire � visualiser	sNomHtml = hcq.nomSansDoublons(sPathHtml, sNomHtml, "htm") ;
	sFichierHtml = sPathHtml + sNomHtml ;

	// on passe aussi le path destination pour les images	if (!hcq.genereHtml(sFichierHtml, sBaseImg, pHtmlInfo, sPathDest))
		return false ;

	// Mise � jour de la base d'images	switch (typeOperation)
	{
		case toComposer:
    	sBaseCompo = sBaseImg ;
      break ;

    default:    	sBaseImages = sBaseImg ;
	}

	return true ;
}

string
NSCQDocument::InitIntitule()
{
	string sLibelleDoc = "";
	int	 age;
	string sDateDoc;
	char   datex[9] = "";
	string sIntitulePatient;
	string sIntituleDocument;

	string sLang = "";	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;

	if (false == pPatPathoArray->empty())	{
		string sCode = (*(pPatPathoArray->begin()))->getLexique() ;

		if (sCode != "")  	{
    	pContexte->getDico()->donneLibelle(sLang, &sCode, &sLibelleDoc) ;

      if (strlen(sLibelleDoc.c_str()))      	sLibelleDoc[0] = pseumaj(sLibelleDoc[0]) ;
    }
    else
    	sLibelleDoc = "Formulaire" ;
	}
	else
		sLibelleDoc = "Formulaire" ;

	sDateDoc = GetDateDoc(false) ;
	strcpy(datex, sDateDoc.c_str()) ;
	age = donne_age(datex) ;

	donne_intitule_patient(&sIntitulePatient, age) ;
	sIntituleDocument = sLibelleDoc + string(" de ") + sIntitulePatient + string(" ") ;
	sIntituleDocument += pContexte->getPatient()->getNom() + string(" ") ;
	sIntituleDocument += pContexte->getPatient()->getPrenom() ;	return sIntituleDocument ;
}

bool
NSCQDocument::ouvreArchetype()
{
	if (string("") == sArchetype)
	{
		// cas des documents enregistr�s : l'archetype doit etre
    // r�cup�r� � partir de la patpatho
    if (false == pPatPathoArray->empty())
    	sArchetype = (*(pPatPathoArray->begin()))->pDonnees->getArchetype() ;

    if (string("") == sArchetype)
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("archetypesManagement", "cannotFindArchetypeIdForDocument") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
			erreur(sErrorText.c_str(), standardError, 0) ;

      if (string("") == _sDefaultArchetype)
      	return false ;

      sArchetype = _sDefaultArchetype ;
    }
  }

	pParseur = new nsarcParseur(pContexte);

	string sArchetypeFile = pContexte->getSuperviseur()->getArcManager()->DonneFichierArchetypeParNom(NSArcManager::archetype, sArchetype) ;
	if (string("") == sArchetypeFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("archetypesManagement", "cannotFindThisArchetypeFile") ;
  	sErrorText += string(" (") + sArchetype + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

	if (!pParseur->open(sArchetypeFile))
	{
    string sErrorText = pContexte->getSuperviseur()->getText("archetypesManagement", "archetypeParsingError") ;
  	sErrorText += string(" (") + sArchetypeFile + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return false ;
	}

  Citem* pRootItem = pParseur->pArchetype->getRootItem() ;
  if (NULL != pRootItem)
  {
    string sRootCode = pRootItem->getCode() ;
    pContexte->getSuperviseur()->getDico()->donneCodeSens(&sRootCode, &_sSemDocType) ;
  }

	return true ;
}

// M�thodes de gestion des formulaires
bool
NSCQDocument::enregistre(bool bVerbose, bool bSoaping)
{
  bool existeInfo ;

	if (bEnregEnCours)
		return false ;

	bEnregEnCours = true ;

	string sLang = "" ;
	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;

	pContexte->getSuperviseur()->afficheStatusMessage("D�but d'enregistrement") ;

	// Si c'est une nouvelle fiche, on la cr�e en tant que document
	bool bNewDoc ;
	if (pDocInfo == 0)
		bNewDoc = true ;
	else
		bNewDoc = false ;

	if (bNewDoc)
	{
		string sLibelleDoc = string("") ;

    Creferences *pReferenceBlock = pParseur->pArchetype->getReference() ;
    if (NULL != pReferenceBlock)
    {
      Chead *pReferenceHead = pReferenceBlock->getHead(sLang) ;
      if (NULL != pReferenceHead)
        sLibelleDoc = pReferenceHead->getTitle() ;
    }

    if (string("") == sLibelleDoc)
    {
      if (string("") != _sSemDocType)
      {
        string sDocTypeComplet = _sSemDocType ;
        pContexte->getSuperviseur()->getDico()->donneCodeComplet(sDocTypeComplet) ;
			  pContexte->getDico()->donneLibelle(sLang, &sDocTypeComplet, &sLibelleDoc) ;
      }
      else if (false == pPatPathoArray->empty())
      {
    	  string sCode = (*(pPatPathoArray->begin()))->getLexique() ;
        pContexte->getDico()->donneLibelle(sLang, &sCode, &sLibelleDoc) ;
      }
    }

		existeInfo = Referencer("ZCQ00", sLibelleDoc, "", "", true, bVerbose);
		if (!existeInfo)
		{
			bEnregEnCours = false ;
			return existeInfo ;
		}
	}

	// On enregistre la patpatho
	existeInfo = enregistrePatPatho() ;
	if (!existeInfo)
	{
		bEnregEnCours = false ;
		return existeInfo ;
	}

  // Loading the tree in order to get nodes' Ids
  //
	existeInfo = NSNoyauDocument::chargePatPatho() ;
	if (!existeInfo)
	{
		bEnregEnCours = false ;
		return existeInfo ;
	}

  connectToHealthConcern() ;

  // The new document must be inserted in "history" before checking if it resets
  // any goal, because this document's date will be asked to "history"

  // On pr�vient l'historique (fait � part pour les CS et les CN)
	pContexte->getPatient()->pDocHis->Rafraichir(pDocInfo, pPatPathoArray, this) ;

	// Si c'est un nouveau compte rendu on v�rifie s'il remet � z�ro un objectif
	if ((bNewDoc) && (pContexte->getPatient()->pDocLdv))
		pContexte->getPatient()->pDocLdv->showNewTree(pPatPathoArray, GetDateDoc(false)) ;

	pContexte->getSuperviseur()->afficheStatusMessage("Document enregistr�") ;

	bEnregEnCours = false ;

	if (bSoaping)
		makeSOAP() ;

  openReferential() ;

	return existeInfo ;
}

string
NSCQDocument::findTitle()
{
  string sLang = string("") ;
	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;

  string sLibelleDoc = string("") ;

  if ((NULL != pParseur) && (NULL != pParseur->pArchetype))
  {
    Creferences *pReferenceBlock = pParseur->pArchetype->getReference() ;
    if (NULL != pReferenceBlock)
    {
      Chead *pReferenceHead = pReferenceBlock->getHead(sLang) ;
      if (NULL != pReferenceHead)
        sLibelleDoc = pReferenceHead->getTitle() ;
      if (string("") != sLibelleDoc)
        return sLibelleDoc ;
    }
  }

  if (string("") != _sSemDocType)
  {
    string sDocTypeComplet = _sSemDocType ;
    pContexte->getSuperviseur()->getDico()->donneCodeComplet(sDocTypeComplet) ;
    pContexte->getDico()->donneLibelle(sLang, &sDocTypeComplet, &sLibelleDoc) ;
    return sLibelleDoc ;
  }

  if (false == pPatPathoArray->empty())
  {
    string sCode = (*(pPatPathoArray->begin()))->getLexique() ;
    pContexte->getDico()->donneLibelle(sLang, &sCode, &sLibelleDoc) ;
    return sLibelleDoc ;
  }

  return sLibelleDoc ;
}

void
NSCQDocument::connectToHealthConcern()
{
  if ((NULL == pParseur) || (NULL == pParseur->pArchetype))
    return ;

  Creferences *pReferenceBlock = pParseur->pArchetype->getReference() ;
  if (NULL == pReferenceBlock)
    return ;

  Cconcern *pConcernBlock = pReferenceBlock->getFirstCconcern() ;
  if (NULL == pConcernBlock)
    return ;

  string sConcernCode = pConcernBlock->getCode() ;
  if (string("") == sConcernCode)
    return ;

  bool bCreate = pConcernBlock->getAutoCreate() ;
  int  iSevere = pConcernBlock->getSeverity() ;

  // string ps = string("Connecting the document \"") + sLibelleDoc + string("\" to a line.") ;
  // pContexte->getSuperviseur()->trace(&ps, 1) ;
  NSLdvDocument *pDocLdv = pContexte->getPatient()->pDocLdv ;

  string sRacineDoc = DonneDocInfo()->getID() ;

  if (pContexte->getSuperviseur()->getDico()->isDrugOrTreatment(&sConcernCode))
    pDocLdv->connectObjectToDrug(sConcernCode, iSevere, sRacineDoc, NSRootLink::problemRelatedTo, bCreate) ;
  else if (sConcernCode[0] != '#')
    /*bConnected =*/ pDocLdv->connectObjectToConcern(sConcernCode, iSevere, sRacineDoc, NSRootLink::problemRelatedTo, bCreate) ;
  // Si sConcernCode[0] == '#', c'est qu'on se connecte �
  // la pr�occupation lanceuse du formulaire
  else
  {
    string sPreoType = string(sConcernCode, 1, strlen(sConcernCode.c_str()) - 1) ;
    string sQuestion = string("0PRO1/IsA/") + sPreoType ;
    NSPatPathoArray *pAnswer = NULL ;
#ifdef __OB1__
    string sAnswerDate ;
    if (pContexte->getSuperviseur()->getBBinterface()->getAnswer2Question(sQuestion, "", &pAnswer, sAnswerDate, false))
#else
    if (pContexte->getSuperviseur()->getBlackboard()->getAnswer2Question(sQuestion, "", &pAnswer, false))
#endif // !__OB1__
    {
      if (pAnswer && (false == pAnswer->empty()))
      {
        PatPathoIter iter = pAnswer->begin() ;
        string sLaunchingPreoc = (*iter)->getLexique() ;
        pDocLdv->connectObjectToConcern(sLaunchingPreoc, iSevere, sRacineDoc, NSRootLink::problemRelatedTo, bCreate) ;
      }
    }
    if (pAnswer)
      delete pAnswer ;
  }
}

void
NSCQDocument::openReferential()
{
  if ((NULL == pParseur) || (NULL == pParseur->pArchetype))
    return ;

  Cdialogue *pDialogBlock = pParseur->pArchetype->getDialog() ;
  if (NULL == pDialogBlock)
    return ;

  string sNomRef = pDialogBlock->getStringAttribute(ATTRIBUT_DIALOGUE_REF) ;
  if (string("") == sNomRef)
    return ;

  string sRacineDoc = DonneDocInfo()->getID() ;

  pContexte->getPatient()->CmReferentiel(sNomRef, sRacineDoc) ;
}

string
NSCQDocument::donneTexte()
{
	if (!pPatPathoArray || pPatPathoArray->empty())
		return "" ;

	string sTexte = "" ;

	string sLangue = pContexte->getUtilisateur()->donneLang() ;
	string sLibelle ;
	string sCodeLex ;

	NSPatPathoArray aTempPatho(pContexte) ;

	PatPathoIter iter = pPatPathoArray->begin() ;
	for ( ; iter != pPatPathoArray->end() ; iter++)
	{
  	// sCodeLex = string((*iter)->pDonnees->lexique) ;
    // pContexte->getDico()->donneLibelle(sLangue, &sCodeLex, &sLibelle) ;

    aTempPatho.vider() ;
    aTempPatho.push_back(new NSPatPathoInfo(**iter)) ;

    GlobalDkd Dcode(pContexte, sLangue, "", &aTempPatho) ;
    Dcode.decodeNoeud("") ;
    sLibelle = *(Dcode.sDcodeur()) ;

    sTexte += sLibelle + string("<br>\n") ;
	}
	return sTexte ;
}

void
NSCQDocument::genereHtmlView()
{
	sHtmlView = "" ;

	if ((!pParseur) || (!(pParseur->pArchetype)))
	{
		erreur("Il n'est pas possible d'acc�der � l'archetype du document (qui contient les informations de publication).", standardError, 0) ;
		return ;
	}

	// Le parseur est initialis� par le constructeur
	Cpresentation* pPresent = pParseur->pArchetype->getPresentation() ;
	if (!pPresent)
	{
		erreur("L'archetype du document ne poss�de pas d'informations de publication.", standardError, 0) ;
    return ;
	}

	string sPresent = pPresent->getValue() ;
	if (sPresent != "")
		remplaceTagsChemin(sPresent) ;
	sHtmlView = sPresent ;
}

void
NSCQDocument::remplaceTagsChemin(string& sHtml)
{
	// NSPatPathoArray* pPatPathoArray = NULL ;
	pContexte->getPatient()->remplaceTagsChemin(sHtml, pPatPathoArray) ;
  // if (pPatPathoArray)
	//	delete pPatPathoArray ;
}

// implementation des m�thodes virtuelles de TDocument
bool
NSCQDocument::Open(int mode, const char far* path)
{
	if (!pDocInfo)
		return true ;

	return bDocumentValide ;}

bool
NSCQDocument::Close()
{
	return true ;
}

void
NSCQDocument::SetTitle(LPCSTR title)
{
	TDocument::SetTitle(title) ;
}

// fin de nscqdoc.cpp
////////////////////////////////////////////////

