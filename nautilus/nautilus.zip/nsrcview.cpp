// -----------------------------------------------------------------------------// nsrcview.cpp
// -----------------------------------------------------------------------------
// $Revision: 1.20 $
// $Author: pameline $
// $Date: 2005/07/01 07:51:54 $
// -----------------------------------------------------------------------------
// Vue Document/Vues de gestion du tableau de bord des RC
// Doc/View View for RC management
// -----------------------------------------------------------------------------
// PA  - octoble 2003
// -----------------------------------------------------------------------------
#if !defined(OWL_LISTWIND_H)
# include <owl/listwind.h>
#endif

#include <owl/uihelper.h>
#include <owl\owlpch.h>
#include <owl\validate.h>
#include <owl\inputdia.h>

#include "nautilus\nssuper.h"#include "partage\nsdivfct.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbbsmal.h"
#include "nsbb\nsrcdlg.h"
#include "nsbb\nsmview.h"
#include "nsbb\nspanesplitter.h"
#include "nautilus\nsrcview.h"
#include "nautilus\nsldvvue.rh"

#include "nautilus\nscsdoc.h"
#include "nautilus\nscsvue.h"
#include "nautilus\nsdocview.h"
#include "nautilus\nshistdo.h"
#include "nssavoir\nsgraphe.h"

// --------------------------------------------------------------------------
//
// Class NSRCEpisod
//
// --------------------------------------------------------------------------

NSRCEpisod::NSRCEpisod()
{
    pConcern    = NULL ;
    sPosDiag    = "" ;
    sLastDoc    = "" ;
}

NSRCEpisod::NSRCEpisod(NSRCEpisod& rv)
{
    pConcern    = rv.pConcern ;
    sPosDiag    = rv.sPosDiag ;
    sLastDoc    = rv.sLastDoc ;
}

NSRCEpisod::~NSRCEpisod()
{
    // Ne pas faire/Don't do delete pConcern
}

NSRCEpisod&
NSRCEpisod::operator=(NSRCEpisod src)
{
    pConcern    = src.pConcern ;
    sPosDiag    = src.sPosDiag ;
    sLastDoc    = src.sLastDoc ;
    return *this ;
}

// --------------------------------------------------------------------------
//
// Class ArrayRCEpisodes
//
// --------------------------------------------------------------------------

ArrayRCEpisodes::ArrayRCEpisodes(NSEpisodRCView* pRCView)
                :ArrayRCEpiso()
{
    pRCEpiView = pRCView ;
}

ArrayRCEpisodes::ArrayRCEpisodes(ArrayRCEpisodes& rv)
	            :ArrayRCEpiso()
{
try
{
    pRCEpiView = rv.pRCEpiView ;

	if (!(rv.empty()))
		for (ArrayRCEpisodIter i = rv.begin(); i != rv.end(); i++)
    	    push_back(new NSRCEpisod(*(*i)));
}
catch (const exception& e)
{
	string sExept = "Exception ArrayRCEpisodes copy ctor " + string(e.what());
	erreur(sExept.c_str(),  standardError, 0) ;
}
catch (...)
{
    erreur("Exception ArrayRCEpisodes.",  standardError, 0) ;
}
}

void
ArrayRCEpisodes::vider()
{
	if (empty())
		return;

	for (ArrayRCEpisodIter i = begin(); i != end(); )
	{
		delete *i;
		erase(i);
	}
}

void
ArrayRCEpisodes::initialiser(bool bActive, string sMinDate)
{
    if ((!pRCEpiView) || (!(pRCEpiView->getDoc())))
        return ;
    ArrayConcern* pConcerns = pRCEpiView->getDoc()->getConcerns() ;
    if ((!pConcerns) || (pConcerns->empty()))
        return ;

    NVLdVTemps  tDateNow ;
    NVLdVTemps  tDateMin ;

    tDateNow.takeTime() ;
    if ((!bActive) && (sMinDate != ""))
        tDateMin.initFromDate(sMinDate) ;
    else
        tDateMin.takeTime() ;

    ArrayConcernIter itConcerns = pConcerns->begin() ;
    for ( ; itConcerns != pConcerns->end() ; itConcerns++)
    {
        if (((*itConcerns)->tDateFermeture.estNoLimit()) ||
            ((*itConcerns)->tDateFermeture >= tDateMin))
        {
            NSRCEpisod* pRCEpisod = new NSRCEpisod ;
            pRCEpisod->pConcern = (*itConcerns) ;
            push_back(pRCEpisod) ;
        }
    }
}

ArrayRCEpisodes::~ArrayRCEpisodes()
{
	vider();
}

ArrayRCEpisodes&
ArrayRCEpisodes::operator=(ArrayRCEpisodes src)
{
try
{
    pRCEpiView = src.pRCEpiView ;

	vider();
	if (!(src.empty()))
		for (ArrayRCEpisodIter i = src.begin(); i != src.end(); i++)
			push_back(new NSRCEpisod(*(*i)));

	return *this;
}
catch (const exception& e)
{
	string sExept = "Exception ArrayRCEpisodes= " + string(e.what());
	erreur(sExept.c_str(),  standardError, 0) ;
	return *this;
}
catch (...)
{
	erreur("Exception ArrayRCEpisodes= .",  standardError, 0) ;
	return *this;
}
}

bool rcSortByNameInf(NSRCEpisod* p1, NSRCEpisod* p2)
{
	return (p1->pConcern->sTitre < p2->pConcern->sTitre);
}

bool rcSortByNameSup(NSRCEpisod* p1, NSRCEpisod* p2)
{
	return (p1->pConcern->sTitre > p2->pConcern->sTitre);
}

bool rcSortByBeginInf(NSRCEpisod* p1, NSRCEpisod* p2)
{
	return (p1->pConcern->tDateOuverture < p2->pConcern->tDateOuverture);
}

bool rcSortByBeginSup(NSRCEpisod* p1, NSRCEpisod* p2)
{
	return (p1->pConcern->tDateOuverture > p2->pConcern->tDateOuverture);
}

bool rcSortByEndInf(NSRCEpisod* p1, NSRCEpisod* p2)
{
	return (p1->pConcern->tDateFermeture < p2->pConcern->tDateFermeture);
}

bool rcSortByEndSup(NSRCEpisod* p1, NSRCEpisod* p2)
{
	return (p1->pConcern->tDateFermeture > p2->pConcern->tDateFermeture);
}

// --------------------------------------------------------------------------
//
// Class NSEpisodRCView
//
// --------------------------------------------------------------------------

const int ID_EpiRCList = 0x100;
// Table de r�ponses de la classe NSEpisodView

DEFINE_RESPONSE_TABLE1(NSEpisodRCView, NSLDVView)
	EV_VN_ISWINDOW,
	EV_LVN_GETDISPINFO(ID_EpiRCList, DispInfoListe),
	EV_LVN_COLUMNCLICK(ID_EpiRCList, LVNColumnclick),
	EV_WM_SIZE,
	EV_WM_SETFOCUS,
	EV_COMMAND(CM_EPISO_NEW,        CmNouveau),
	EV_COMMAND(CM_EPISO_EVOLUER,    CmEvolve),
END_RESPONSE_TABLE;

// Constructeur

NSEpisodRCView::NSEpisodRCView(NSLdvDocument &doc, string sConcern)               :NSLDVView(doc.pContexte, &doc, 0, string("EpiRCManagement"), sConcern)
{
try
{
	pLdVDoc         = &doc;
	pEpisods        = new ArrayRCEpisodes(this) ;
	pListeWindow    = new NSRCListWindow(this, ID_EpiRCList, 0, 0, 0, 0);

	//SetViewMenu(new TMenuDescr(IDM_DRUG_VIEW));
	pToolBar        = 0 ;
	bSetupToolBar   = true ;

	iSortedColumn   = -1 ;

	// Initialisation des �pisodes actifs
	initCurentEpiRC() ;

	setViewName() ;
}
catch (...)
{
	erreur("Exception NSEpisodRCView ctor.",  standardError, 0) ;
}
}

// Destructeur
NSEpisodRCView::~NSEpisodRCView()
{
}

void
NSEpisodRCView::setViewName()
{
	sViewName = pContexte->getSuperviseur()->getText("RCManagement", "RCEpisodViewTitle") ;

  addConcernTitle() ;
}

// GetWindow renvoie this (� red�finir car virtual dans TView)
TWindow*
NSEpisodRCView::GetWindow()
{
	return (TWindow*) this;
}

// Appel de la fonction de remplissage de la vuevoid
NSEpisodRCView::SetupWindow()
{
	NSMUEView::SetupWindow();

	Parent->SetCaption(sViewName.c_str()) ;

	SetupColumns();
	AfficheListe();
}

void
NSEpisodRCView::CmNouveau()
{
try
{
	NSPatPathoArray *pPPT    = new NSPatPathoArray(pContexte) ;

#ifdef __OB1__
	NSSmallBrother* pBigBoss = new NSSmallBrother(pContexte, pPPT, 0) ;
#else
	NSSmallBrother* pBigBoss = new NSSmallBrother(pContexte, pPPT, 0, false) ;
#endif
	pBigBoss->pFenetreMere   = pContexte->GetMainWindow() ;

	// pBigBoss->lance12("GPRSC1", sChoixMed) ;

	string sNoeud1 = string("ZPOMR1") ;

	pBigBoss->pBBItem = new BBItem(pContexte, pBigBoss) ;

	BBItemData* pDo = new BBItemData() ;
  strcpy(pDo->ouvreDialogue, "N") ;
  strcpy(pDo->fils, "") ;
  strcpy(pDo->decalageNiveau, "+01+01") ;
  strcpy(pDo->fichierDialogue, "NSBB") ;

	*(pBigBoss->pBBItem->pDonnees) = *pDo ;
	pBigBoss->pBBItem->setDialogName(string("")) ;

  string sCodeSens ;
  NSSuper* pSuper = pContexte->getSuperviseur() ;
  pSuper->getDico()->donneCodeSens(&sNoeud1, &sCodeSens) ;
  pBigBoss->pBBItem->sLocalisation = sCodeSens ;

  pBigBoss->pBBItem->setDialog(new NSRCDialog(pContexte, pBigBoss->pBBItem, this)) ;
  int iResult = pBigBoss->pBBItem->getDialog()->Execute() ;

  NSRCDialog* pRCDialog = static_cast<NSRCDialog*>(pBigBoss->pBBItem->getDialog());
  string sChosenRC           = pRCDialog->sCurrentLex ;
  string sChosenArchetype    = pRCDialog->sCurrentArchetype ;

  string sLocalis = pBigBoss->pBBItem->sLocalisation ;
  pBigBoss->pBBItem->okFermerDialogue(true) ;
  // *pPatPathoArray = *(pBigBoss->pBBItem->pPPTEnCours) ;

  delete pBigBoss->pBBItem ;
  delete pBigBoss ;

  if ((sChosenRC == "") || (iResult != IDOK))
  {
  	delete pPPT ;
    return ;
  }

  NSPatPathoArray *pTotalPPT = new NSPatPathoArray(pContexte) ;
  pTotalPPT->ajoutePatho(sChosenRC, 0);

    if (!(pPPT->empty()))
        pTotalPPT->InserePatPatho(pTotalPPT->end(), pPPT, 1) ;
    delete pPPT ;

    NSCsVue* pCSView = 0 ;

    NSPatientChoisi* pPat = pContexte->getPatient() ;
    //
    // S'il n'y a pas de document consultation ouvert, on en ouvre un
    //
    if (!(pPat->pConsultEnCours))
    {
        NSCSDocument* pNewDocCS = new NSCSDocument(0, pContexte, "GCONS1") ;
        pCSView = new NSCsVue(*pNewDocCS, 0) ;

        NSDocViewManager dvManager(pContexte) ;
        dvManager.createView(pNewDocCS, "CS Format", pCSView) ;

        pPat->pConsultEnCours = pNewDocCS ;
    }
    //
    // Sinon, on cherche si le document consultation en cours a une vue ouverte
    //
    else
    {
        TView* pView = pPat->pConsultEnCours->GetViewList() ;
        do
        {
            NSCsVue* pisCsView = TYPESAFE_DOWNCAST(pView, NSCsVue) ;
            if (pisCsView)
                pCSView = pisCsView ;

            pView = pPat->pConsultEnCours->NextView(pView) ;
        }
        while (pView && !pCSView) ;
    }

    if (pCSView)
        pCSView->NewPreoccupRC(pTotalPPT, sChosenArchetype) ;

    delete pTotalPPT ;
}
catch (...)
{
    erreur("Exception NSEpisodRCView::CmNouveau.", standardError, 0) ;
}
}

void
NSEpisodRCView::CmEvolve()
{
try
{
    // R�cup�ration de l'�l�ment s�lectionn�
    //
    int index = pListeWindow->IndexItemSelect() ;
    if (index < 0)
    {
        erreur("Vous devez s�lectionner un RC.", standardError, 0) ;
        return ;
    }

    if (pEpisods->empty())
        return ;
    NSRCEpisod* pSelectedEpisod = (*pEpisods)[index] ;

    NSSuper*            pSuper  = pContexte->getSuperviseur() ;
    NSPatientChoisi*    pPat    = pContexte->getPatient() ;
    //
    // Prise du RC
    //
    NSPatPathoArray* pPatho ;
    PatPathoIter iter = pLdVDoc->donnePreoccup(pSelectedEpisod->pConcern, &pPatho) ;
    if (iter == NULL)
    {
        erreur("Impossible de retrouver ce RC dans l'Index de sant�.", standardError, 0) ;
        return ;
    }
    string sPreviousConcernLex = (*iter)->getLexique() ;
    string sPreviousConcernSens ;
    pSuper->getDico()->donneCodeSens(&sPreviousConcernLex, &sPreviousConcernSens) ;

    //
    // R�cup�ration de la derni�re description
    //
    VecteurString vResult;

    string sSelectedPreoccup = pSelectedEpisod->pConcern->getNoeud() ;

#ifndef N_TIERS
    NSGraphe* pGraphe = new NSGraphe(pContexte) ;
#else
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
#endif
    pGraphe->TousLesVrais(sSelectedPreoccup, NSRootLink::problemContactElement, &vResult, "ENVERS");
#ifndef N_TIERS
    delete pGraphe;
#endif

    if (vResult.empty())
        return ;

    NSPatPathoArray* pPreviousPPt = new NSPatPathoArray(pContexte) ;

    string sMaxDateDoc = "";

    EquiItemIter iterLiens = vResult.begin();
    for (; iterLiens != vResult.end(); iterLiens++)
    {
        NSPatPathoArray*    pPPt ;
        bool                bDeleteAtEnd ;
        string              sDateDoc ;

        //
        // On r�cup�re l'arbre
        //
        string sDocId = string(**iterLiens, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN);

        if ((pPat->pDocHis->donneArbre(sDocId, &pPPt, &sDateDoc, &bDeleteAtEnd)) &&
            (!(pPPt->empty())))
        {
            PatPathoIter pptIt = pPPt->begin() ;
            string sRootLex = (*pptIt)->getLexique() ;
            string sRootLexSens ;
            pSuper->getDico()->donneCodeSens(&sRootLex, &sRootLexSens) ;
            //
            // On ne s'int�resse qu'aux consultations
            //
            if ((sRootLexSens == "GCONS") && (sDateDoc > sMaxDateDoc))
            {
                pptIt = pPPt->ChercherNoeud(**iterLiens) ;
                if ((pptIt != NULL) && (pptIt != pPPt->end()))
                {
                    string sNodeLex = (*pptIt)->getLexique() ;
                    string sNodeSens ;
                    pSuper->getDico()->donneCodeSens(&sNodeLex, &sNodeSens) ;

                    if (sNodeSens == sPreviousConcernSens)
                    {
                        sMaxDateDoc = sDateDoc ;

                        pPreviousPPt->vider() ;

                        int colonneElement  = (*pptIt)->getColonne() ;
                        int ligneElement    = (*pptIt)->getLigne();

                        pPreviousPPt->ajoutePatho(pptIt, 0, 0) ;
                        pptIt++ ;

                        while ((pptIt != pPPt->end()) && ((*pptIt)->getColonne() > colonneElement))
                        {
                            int colonne  = (*pptIt)->getColonne() - colonneElement ;
                            int ligne    = (*pptIt)->getLigne() - ligneElement ;
                            pPreviousPPt->ajoutePatho(pptIt, ligne, colonne) ;
                            pptIt++ ;
                        }
                    }
                }
            }
            if (bDeleteAtEnd)
                delete pPPt ;
        }
    }

    NSPatPathoArray *pPPT       = new NSPatPathoArray(pContexte) ;
    if (!(pPreviousPPt->empty()))
        pPreviousPPt->ExtrairePatPatho(pPreviousPPt->begin(), pPPT) ;

    delete pPreviousPPt ;

    string sChosenRC = sPreviousConcernLex ;

#ifdef __OB1__
	NSSmallBrother* pBigBoss = new NSSmallBrother(pContexte, pPPT, 0) ;
#else
	NSSmallBrother* pBigBoss = new NSSmallBrother(pContexte, pPPT, 0, false) ;
#endif
  pBigBoss->pFenetreMere   = pContexte->GetMainWindow() ;
  pBigBoss->pBBItem        = new BBItem(pContexte, pBigBoss) ;

  BBItemData* pDo = new BBItemData() ;
  strcpy(pDo->ouvreDialogue, "N") ;
  strcpy(pDo->fils, "") ;
  strcpy(pDo->decalageNiveau, "+01+01") ;
	strcpy(pDo->fichierDialogue, "NSBB") ;

	*(pBigBoss->pBBItem->pDonnees) = *pDo ;
  pBigBoss->pBBItem->setDialogName(string("")) ;

    string sNoeud1 = string("ZPOMR1") ;

    string sCodeSens ;
    pSuper = pContexte->getSuperviseur() ;
    pSuper->getDico()->donneCodeSens(&sNoeud1, &sCodeSens) ;
    pBigBoss->pBBItem->sLocalisation = sCodeSens ;

    pBigBoss->pBBItem->setDialog(new NSRCDialog(pContexte, pBigBoss->pBBItem, this)) ;
    NSRCDialog* pRCDialog = static_cast<NSRCDialog*>(pBigBoss->pBBItem->getDialog()) ;
    pRCDialog->sCurrentLex = sPreviousConcernLex ;

    int iResult = pBigBoss->pBBItem->getDialog()->Execute() ;

    sChosenRC = pRCDialog->sCurrentLex ;
    string sChosenArchetype = pRCDialog->sCurrentArchetype ;

    string sLocalis = pBigBoss->pBBItem->sLocalisation ;
    pBigBoss->pBBItem->okFermerDialogue(true) ;
    // *pPatPathoArray = *(pBigBoss->pBBItem->pPPTEnCours) ;

    delete pBigBoss->pBBItem ;
    delete pBigBoss ;

    if ((sChosenRC == "") || (iResult != IDOK))
    {
        delete pPPT ;
        return ;
    }

    NSPatPathoArray *pTotalPPT = new NSPatPathoArray(pContexte) ;
    pTotalPPT->ajoutePatho(sChosenRC, 0);

    if (!(pPPT->empty()))
        pTotalPPT->InserePatPatho(pTotalPPT->end(), pPPT, 1) ;
    delete pPPT ;

    NSCsVue* pCSView = 0 ;
    //
    // S'il n'y a pas de document consultation ouvert, on en ouvre un
    //
    if (!(pPat->pConsultEnCours))
    {
        NSCSDocument* pNewDocCS = new NSCSDocument(0, pContexte, "GCONS1") ;
        pCSView = new NSCsVue(*pNewDocCS, 0) ;

        NSDocViewManager dvManager(pContexte) ;
        dvManager.createView(pNewDocCS, "CS Format", pCSView) ;

        pPat->pConsultEnCours = pNewDocCS ;
    }
    //
    // Sinon, on cherche si le document consultation en cours a une vue ouverte
    //
    else
    {
        TView* pView = pPat->pConsultEnCours->GetViewList() ;
        do
        {
            NSCsVue* pisCsView = TYPESAFE_DOWNCAST(pView, NSCsVue) ;
            if (pisCsView)
                pCSView = pisCsView ;

            pView = pPat->pConsultEnCours->NextView(pView) ;
        }
        while (pView && !pCSView) ;
    }

    if (pCSView)
    {
        string sChosenConcernSens ;
        pSuper->getDico()->donneCodeSens(&sChosenRC, &sChosenConcernSens) ;

        if (sChosenConcernSens == sPreviousConcernSens)
            pCSView->EvolPreoccupRC(pTotalPPT, pSelectedEpisod->pConcern, sChosenArchetype) ;
        else
            pCSView->ChangePreoccupRC(pTotalPPT, pSelectedEpisod->pConcern, sChosenArchetype) ;
    }

    delete pTotalPPT ;
}
catch(TWindow::TXWindow& e)
{
    string sErr = string("Exception NSEpisodRCView::CmEvolve : ") + e.why() ;
    erreur(sErr.c_str(), standardError, 0) ;
}
catch (...)
{
    erreur("Exception NSEpisodRCView::CmEvolve.",  standardError, 0) ;
}
}

void
NSEpisodRCView::CmSelect()
{
    int index = pListeWindow->IndexItemSelect() ;

    if (index < 0)
        return ;

    if (pEpisods->empty())
        return ;

    NSRCEpisod* pSelectedEpisod = (*pEpisods)[index] ;
    getPaneSplitter()->concernChanged(pSelectedEpisod->pConcern->getNoeud()) ;
}

void
NSEpisodRCView::reloadView(string sReason)
{
    initCurentEpiRC() ;
    AfficheListe() ;
}

void
NSEpisodRCView::initCurentEpiRC()
{
    pEpisods->vider() ;
    pEpisods->initialiser(true, "") ;
}

// Initialisation des colonnes de la ListWindowvoid
NSEpisodRCView::SetupColumns()
{
    pListeWindow->InsertColumn(0, TListWindColumn("D�nomination", 450, TListWindColumn::Left, 0));
    pListeWindow->InsertColumn(1, TListWindColumn("PD", 30, TListWindColumn::Left, 1));
    pListeWindow->InsertColumn(2, TListWindColumn("D. d�but", 90, TListWindColumn::Left, 2));
    pListeWindow->InsertColumn(3, TListWindColumn("Probable fin", 90, TListWindColumn::Left, 3));
}

// Affichage des �l�ments de la listevoid
NSEpisodRCView::AfficheListe()
{
    pListeWindow->DeleteAllItems();

    if (pEpisods->empty())
        return ;

    // Attention : insert ins�re au dessus ; il faut inscrire les derniers en premier
    ArrayRCEpisodIter itDg = pEpisods->end() ;
    do
    {
        itDg-- ;
        TListWindItem Item(((*itDg)->pConcern->sTitre).c_str(), 0);
        pListeWindow->InsertItem(Item);
    }
    while (itDg != pEpisods->begin()) ;
}

void
NSEpisodRCView::DispInfoListe(TLwDispInfoNotify& dispInfo)
{
    const int       BufLen = 255;
    static char     buffer[BufLen];
    TListWindItem   &dispInfoItem = *(TListWindItem*)&dispInfo.item;
    char            szDate[30];
    buffer[0] = '\0' ;

    int index = dispInfoItem.GetIndex();

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	// Affiche les informations en fonction de la colonne	switch (dispInfoItem.GetSubItem())
	{
  	case 1: // Position diagnostique

    	dispInfoItem.SetText(((*pEpisods)[index])->sPosDiag.c_str()) ;
      break ;

    case 2: // date d�but

    	strcpy(szDate, ((*pEpisods)[index])->pConcern->tDateOuverture.donneDate().c_str()) ;
      donne_date(szDate, buffer, sLang) ;
      dispInfoItem.SetText(buffer) ;
      break ;

    case 3: // date fin
    	if (((*pEpisods)[index])->pConcern->tDateFermeture.estNoLimit())
      	strcpy(buffer, "...") ;
      else
      {
      	strcpy(szDate, ((*pEpisods)[index])->pConcern->tDateFermeture.donneDate().c_str()) ;
        donne_date(szDate, buffer, sLang) ;
      }
      dispInfoItem.SetText(buffer) ;
      break;
	}
}

void
NSEpisodRCView::LVNColumnclick(TLwNotify& lwn)
{
    switch ( lwn.iSubItem )
    {
        case 0 :
            sortByName();
            break;
        case 2 :
            sortByBegining();
            break;
        case 3 :
            sortByEnding();
            break;
    }
}

void
NSEpisodRCView::sortByName()
{
    if (iSortedColumn == 0)
    {
        if (bNaturallySorted)
            bNaturallySorted = false ;
        else
            bNaturallySorted = true ;
    }
    else
    {
        iSortedColumn = 0 ;
        bNaturallySorted = true ;
    }

    if (pEpisods->empty())
        return ;

    if (bNaturallySorted)
        sort(pEpisods->begin(), pEpisods->end(), rcSortByNameInf) ;
    else
        sort(pEpisods->begin(), pEpisods->end(), rcSortByNameSup) ;

    AfficheListe() ;
}

void
NSEpisodRCView::sortByEnding()
{
    if (iSortedColumn == 2)
    {
        if (bNaturallySorted)
            bNaturallySorted = false ;
        else
            bNaturallySorted = true ;
    }
    else
    {
        iSortedColumn = 2 ;
        bNaturallySorted = true ;
    }

    if (pEpisods->empty())
        return ;

    if (bNaturallySorted)
        sort(pEpisods->begin(), pEpisods->end(), rcSortByEndSup) ;
    else
        sort(pEpisods->begin(), pEpisods->end(), rcSortByEndInf) ;

    AfficheListe() ;
}

void
NSEpisodRCView::sortByBegining()
{
    if (iSortedColumn == 1)
    {
        if (bNaturallySorted)
            bNaturallySorted = false ;
        else
            bNaturallySorted = true ;
    }
    else
    {
        iSortedColumn = 1 ;
        bNaturallySorted = true ;
    }

    if (pEpisods->empty())
        return ;

    if (bNaturallySorted)
        sort(pEpisods->begin(), pEpisods->end(), rcSortByBeginSup) ;
    else
        sort(pEpisods->begin(), pEpisods->end(), rcSortByBeginInf) ;

    AfficheListe() ;
}

boolNSEpisodRCView::VnIsWindow(HWND hWnd){
  	return HWindow == hWnd;
}

// fonction permettant de prendre toute la taille de TWindow par la TListWindowvoid
NSEpisodRCView::EvSize(uint sizeType, ClassLib::TSize& size)
{
    TWindow::EvSize(sizeType, size);
    pListeWindow->MoveWindow(GetClientRect(), true);
}

// fonction EVSetFocusvoid
NSEpisodRCView::EvSetFocus(HWND hWndLostFocus)
{
	NSMUEView::EvSetFocus(hWndLostFocus) ;

	focusFct() ;

	pListeWindow->SetFocus() ;
}

void
NSEpisodRCView::focusFct()
{
	TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;

	if (bSetupToolBar && (GetWindow() != pMyApp->GetToolBarWindow()))
	{
		SetupToolBar() ;
		pMyApp->SetToolBarWindow(GetWindow()) ;
	}

	pPaneSplitter->SetFrameTitle(getFunction(), sViewName) ;
	pContexte->setAideIndex("") ;
	pContexte->setAideCorps("rc_episode.htm") ;
}

// SetupToolBarvoid
NSEpisodRCView::SetupToolBar()
{
try
{
	TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;
	pMyApp->FlushControlBar() ;

	pMyApp->cb2->Insert(*new TButtonGadget(CM_EPISO_NEW,        CM_EPISO_NEW,       TButtonGadget::Command)) ;
	pMyApp->cb2->Insert(*new TButtonGadget(CM_EPISO_CLOSE,      CM_EPISO_CLOSE,     TButtonGadget::Command)) ;
	pMyApp->cb2->Insert(*new TButtonGadget(CM_EPISO_EVOLUER,    CM_EPISO_EVOLUER,   TButtonGadget::Command)) ;

	pMyApp->cb2->LayoutSession() ;
}
catch (...)
{
	erreur("Exception NSEpisodRCView::SetupToolBar.",  standardError, 0) ;
}
}

//***************************************************************************
//
//  					M�thodes de NSDrugsPropertyWindow//
//***************************************************************************
DEFINE_RESPONSE_TABLE1(NSRCListWindow, TListWindow)   EV_WM_LBUTTONDBLCLK,
   EV_WM_KEYDOWN,
   EV_WM_SETFOCUS,
END_RESPONSE_TABLE;

NSRCListWindow::NSRCListWindow(NSEpisodRCView* parent, int id, int x, int y, int w, int h, TModule* module)
               :TListWindow((TWindow *) parent, id, x, y, w, h, module)
{
    pView   = parent;
    iRes    = id;
    Attr.Style |= LVS_REPORT | LVS_SHOWSELALWAYS;
    // Attr.ExStyle |= WS_EX_NOPARENTNOTIFY;
}
void
NSRCListWindow::SetupWindow()
{
	ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;

	TListWindow::SetupWindow() ;
}

//---------------------------------------------------------------------------
//  Fonction de r�ponse au double-click
//---------------------------------------------------------------------------
void
NSRCListWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
    TLwHitTestInfo info(point);

    HitTest(info);
    if (info.GetFlags() & LVHT_ONITEM)        pView->CmSelect() ;
}

void
NSRCListWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
    //if      (key == VK_DELETE)
    //    CmSupprCorr() ;
    if (key == VK_INSERT)
    {
        if (GetKeyState(VK_SHIFT) < 0)
            pView->CmEvolve() ;
        else
            pView->CmNouveau() ;
    }
    else
    	TListWindow::EvKeyDown(key, repeatCount, flags) ;
}

//---------------------------------------------------------------------------//  Retourne l'index du premier item s�lectionn�
//---------------------------------------------------------------------------
int
NSRCListWindow::IndexItemSelect()
{
    int count = GetItemCount();
    int index = -1;

    for (int i = 0; i < count; i++)   	    if (GetItemState(i, LVIS_SELECTED))
        {
      	    index = i;
            break;
        }

    return index;}

void
NSRCListWindow::EvSetFocus(HWND hWndLostFocus)
{
	pView->focusFct() ;

	int count = GetItemCount() ;

	for (int i = 0; i < count; i++)
  	if (GetItemState(i, LVIS_SELECTED))
    	return ;

	SetItemState(0, LVIS_FOCUSED | LVIS_SELECTED, LVIS_SELECTED) ;
}

// -------------------------------------------------------------------------
//
// -------------------------------------------------------------------------

/*
DrugTemplate::DrugTemplate(string sConcernNode)
             :DrugViewTmpl(const char far* filt, const char far* desc, const char far* dir, const char far* ext, long flags = 0, TModule*& module = ::Module, TDocTemplate*& phead = DocTemplateStaticHead)
{
    pLdVDoc = &doc;
*/

// --------------------------------------------------------------------------
//
// Class NSRCHistoryView
//
// --------------------------------------------------------------------------

// Table de r�ponses de la classe NSRCHistoryView
DEFINE_RESPONSE_TABLE1(NSRCHistoryView, NSLDVView)
	EV_WM_VSCROLL,
	EV_WM_HSCROLL,
	EV_MESSAGE(WM_MOUSEWHEEL, EvMouseWheel),
	EV_WM_SETFOCUS,
END_RESPONSE_TABLE;

// Constructeur

NSRCHistoryView::NSRCHistoryView(NSLdvDocument &doc, string sConcern)               :NSLDVView(doc.pContexte, &doc, 0, string("RcItemHistory"), sConcern)
{
	//
	// Initialise le style avec des ascenseurs horizontaux et verticaux
	//
	Attr.Style = Attr.Style | WS_HSCROLL | WS_VSCROLL;

	sClassifSens    = "6MGIT" ;

	pLdVDoc         = &doc ;
	pToolBar        = 0 ;
	bSetupToolBar   = true ;

	initParams() ;

  setViewName() ;
}

void
NSRCHistoryView::setViewName()
{
	sViewName = pContexte->getSuperviseur()->getText("RCManagement", "RCHistoryViewTitle") ;

  addConcernTitle() ;
}

void
NSRCHistoryView::concernChanged(string sConcern)
{
    sPreoccup = sConcern ;

    reInitParams() ;
}

void
NSRCHistoryView::initParams()
{
    sArchetype      = "" ;
    pParseur        = 0 ;

    sConcernText    = "" ;

    PremLigne       = 1 ;
    HautGcheFenetre.x = HautGcheFenetre.y = 0 ;
    LargeurPolice   = 0 ;

    initArchetype() ;
}

void
NSRCHistoryView::reInitParams()
{
    sArchetype      = "" ;
    sConcernText    = "" ;

    PremLigne       = 1 ;
    HautGcheFenetre.x = HautGcheFenetre.y = 0 ;
    LargeurPolice   = 0 ;

    if (!(Lignes.empty()))
        Lignes.vider() ;
    if (!(StylesPolice.empty()))
        StylesPolice.vider() ;
    if (!(StylesParagraphe.empty()))
        StylesParagraphe.vider() ;

    if (pParseur)
    {
        delete pParseur ;
        pParseur = 0 ;
    }

    initArchetype() ;

    initLines() ;
    if (Lignes.empty())
        return ;

    initHistory() ;
    InitialiseLignes() ;

    Invalidate() ;
}

void
NSRCHistoryView::initArchetype()
{
try
{
    //
    // Recherche de l'Archetype
    //
    if (sPreoccup == "")
        return ;

    // Localisation : ZPOMR / sConcern
    string sNoeud1 = string("ZPOMR1") ;
    string sCodeSens ;
    NSSuper* pSuper = pContexte->getSuperviseur() ;
    pSuper->getDico()->donneCodeSens(&sNoeud1, &sCodeSens) ;
    string sLocalisation = sCodeSens ;

    //recherche du fil guide

    NSConcern* pConcern = pLdVDoc->getConcerns()->getConcern(sPreoccup);
    if (!pConcern)
        return ;

    sConcernText = pConcern->sTitre ;

    NSPatPathoArray* pPatho ;
    PatPathoIter iter = pLdVDoc->donnePreoccup(pConcern, &pPatho) ;
    if (iter == NULL)
        return ;

    string sConcernLex = (*iter)->getLexique() ;

    VecteurRechercheSelonCritere* pVecteurSelonCritere = new VecteurRechercheSelonCritere(GUIDE) ;
    pSuper->getDico()->donneCodeSens(&sConcernLex, &sCodeSens) ;
    pVecteurSelonCritere->AjouteEtiquette(sCodeSens) ;
    pSuper->getFilGuide()->chercheChemin(&sLocalisation ,
                             pVecteurSelonCritere, NSFilGuide :: compReseau) ;
    bool        trouve ;
    BBItemData* pDonnees = new BBItemData ;
    pVecteurSelonCritere->SetData(sCodeSens, &trouve, pDonnees) ;
    string sEtiquette ;
    if (trouve)
    {
        if (pDonnees->ouvreDialogue[0] == 'A')
            sArchetype = string(pDonnees->fils) ;
    }
    delete pDonnees ;
    delete pVecteurSelonCritere ;

    if (sArchetype == "")
        return ;

    // Ouverture du fichier, et parsing
    string sArchetypeFile = pContexte->getSuperviseur()->getArcManager()->DonneFichierArchetypeParNom(NSArcManager::archetype, sArchetype) ;
    if (sArchetypeFile == "")
        return ;

    pParseur = new nsarcParseur(pContexte) ;
    if (!(pParseur->open(sArchetypeFile)))
    {
        delete pParseur ;
        pParseur = 0 ;
        return ;
    }
}
catch (...)
{
    erreur("Exception NSRCHistoryView::initArchetype.",  standardError, 0) ;
}
}

// Destructeur
NSRCHistoryView::~NSRCHistoryView()
{
    if (pParseur)
        delete pParseur ;
}

// GetWindow renvoie this (� red�finir car virtual dans TView)
TWindow*
NSRCHistoryView::GetWindow()
{
    return (TWindow*) this;
}

// Appel de la fonction de remplissage de la vuevoid
NSRCHistoryView::SetupWindow()
{
	NSMUEView::SetupWindow();

	Parent->SetCaption(sViewName.c_str()) ;

	if (!pParseur)
		return ;

	initLines() ;
	if (Lignes.empty())
		return ;

	initHistory() ;
	InitialiseLignes() ;
}

// fonction EVSetFocus
void
NSRCHistoryView::EvSetFocus(HWND hWndLostFocus)
{
  NSMUEView::EvSetFocus(hWndLostFocus) ;

  pPaneSplitter->SetFrameTitle(getFunction(), sViewName) ;
  // pContexte->setAideIndex("") ;
  // pContexte->setAideCorps("objectifs.htm") ;
}

void
NSRCHistoryView::initLines()
{
try
{
    if ((!pParseur) || (!(pParseur->pArchetype)))
        return ;
    Citem* pItems = pParseur->pArchetype->getRootItem() ;
    if (!pItems)
        return ;

    if (pItems->vect_val.empty())
        return ;

    NSEpiClassif* pClassif = new NSEpiClassif(pContexte) ;

    pClassif->lastError = pClassif->open() ;
    if (pClassif->lastError != DBIERR_NONE)
    {
        erreur("Erreur � l'ouverture de Classif.", standardError, pClassif->lastError) ;
        delete pClassif ;
        return ;
    }

    for (ValIter ival = pItems->vect_val.begin() ; ival != pItems->vect_val.end() ; ival++)
    {
        if ((*ival)->sLabel == LABEL_ITEM) // item
        {
            Citem* pItem = dynamic_cast<Citem*>((*ival)->pObject);
            if (pItem)
                initLines(pItem, pClassif) ;
        }
    }

    pClassif->lastError = pClassif->close() ;
    if (pClassif->lastError != DBIERR_NONE)
    {
        erreur("Erreur � la fermeture de classer.", standardError, pClassif->lastError) ;
        delete pClassif ;
        return ;
    }
}
catch (...)
{
    erreur("Exception NSRCHistoryView::initLines 1",  standardError, 0) ;
}
}

void
NSRCHistoryView::initLines(Citem* pItem, NSEpiClassif* pClassif)
{
try
{
    if (!pItem)
        return ;

    //
    // Prise en compte de l'Item en cours
    //
    string sCode = pItem->getCode() ;
    size_t iSepare = sCode.find(cheminSeparationMARK) ;
    if (iSepare != NPOS)
    {
        string sLexi = string(sCode, 0, iSepare) ;
        sCode = string(sCode, iSepare + 1, strlen(sCode.c_str()) - iSepare - 1) ;
        if (sCode[0] == '$')
            sCode = string(sCode, 1, strlen(sCode.c_str()) - 1) ;

        string sLexSens;
        pContexte->getDico()->donneCodeSens(&sLexi, &sLexSens);

        if (sLexSens == sClassifSens)
        {
            NSItemHistoriser* pItemHisto = new NSItemHistoriser ;

            pItemHisto->sLexique     = sLexi ;
            pItemHisto->sComplement  = sCode ;

            string sClasserKey = sLexSens + pItemHisto->sComplement ;
            pClassif->lastError = pClassif->chercheClef(&sClasserKey,
                                                        "",
                                            		    0,
                                                        keySEARCHEQ,
                                            		    dbiWRITELOCK) ;
            if (pClassif->lastError != DBIERR_NONE)
            {
                string sErrMess =   string("Impossible de trouver le code ") +
                                    pItemHisto->sComplement +
                                    string(" dans la base des classifications.") ;
                erreur(sErrMess.c_str(), standardError, pClassif->lastError) ;
            }
            else
            {
                pClassif->lastError = pClassif->getRecord() ;
		        if (pClassif->lastError != DBIERR_NONE)
		        {
			        erreur("Erreur de lecture dans la base Classif.", standardError, pClassif->lastError) ;
			        return ;
		        }
                pItemHisto->pTextLine = new NSLigne ;
                pItemHisto->pTextLine->Texte = string(pClassif->pDonnees->libelle) ;
            }

            Lignes.push_back(pItemHisto) ;
        }
    }

    //
    // Prise en compte de ses sous-items
    //
    if (pItem->vect_val.empty())
        return ;

    for (ValIter ival = pItem->vect_val.begin() ; ival != pItem->vect_val.end() ; ival++)
    {
        if ((*ival)->sLabel == LABEL_ITEM) // item
        {
            Citem* pItemFils = dynamic_cast<Citem*>((*ival)->pObject);
            if (pItemFils)
                initLines(pItemFils, pClassif) ;
        }
    }
}
catch (...)
{
    erreur("Exception NSRCHistoryView::initLines 2",  standardError, 0) ;
}
}

void
NSRCHistoryView::initHistory()
{
try
{
    if (sPreoccup == "")
        return ;
    if (Lignes.empty())
        return ;

    NSPatientChoisi* pPat = pContexte->getPatient();
    if ((!pPat) || (!(pPat->pDocHis)))
        return ;

    //
    // On cherche tous les noeuds en relation "problemContactElement" avec la pr�occupation
    // We look for every node linked to this concern with the "problemContactElement" relationship
    //
    VecteurString vResult;

#ifndef N_TIERS
    NSGraphe* pGraphe = new NSGraphe(pContexte) ;
#else
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
#endif
    pGraphe->TousLesVrais(sPreoccup, NSRootLink::problemContactElement, &vResult, "ENVERS");
#ifndef N_TIERS
    delete pGraphe;
#endif

    if (vResult.empty())
        return ;

    string sMaxDateDoc = "";

    EquiItemIter iterLiens = vResult.begin();
    for (; iterLiens != vResult.end(); iterLiens++)
    {
        NSPatPathoArray*    pPPt ;
        bool                bDeleteAtEnd ;
        string              sDateDoc ;

        //
        // On r�cup�re l'arbre
        //
        string sDocId = string(**iterLiens, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN);

        if (pPat->pDocHis->donneArbre(sDocId, &pPPt, &sDateDoc, &bDeleteAtEnd))
        {
            if (sDateDoc >= sMaxDateDoc)
                sMaxDateDoc = sDateDoc ;

            PatPathoIter pptIt = pPPt->ChercherNoeud(**iterLiens);

            if ((pptIt != NULL) && (pptIt != pPPt->end()))
            {
                // On est sur le RC
                //
                int iColonne = (*pptIt)->getColonne() ;

                pptIt++ ;
                //
                // On passe en revue les items
                //
                while ((pptIt != pPPt->end()) && ((*pptIt)->getColonne() > iColonne))
                {
                    string sLexSens ;
                    string sLexique = (*pptIt)->getLexique() ;
                    pContexte->getDico()->donneCodeSens(&sLexique, &sLexSens) ;

                    if (sLexSens == sClassifSens)
                    {
                        string sCode = (*pptIt)->getComplement() ;
                        for (ItemHistoIter it = Lignes.begin(); it != Lignes.end(); it++)
                        {
                            if (sCode == (*it)->sComplement)
                            {
                                NVLdVTemps* pCsTime = new NVLdVTemps ;
                                pCsTime->initFromDate(sDateDoc) ;
                                (*it)->aDates.push_back(pCsTime) ;
                            }
                        }
                    }
                    pptIt++ ;
                }
            }
            if (bDeleteAtEnd)
                delete pPPt ;
        }
    }

    NVLdVTemps maxTime ;
    maxTime.initFromDate(sMaxDateDoc) ;

    for (ItemHistoIter it = Lignes.begin(); it != Lignes.end(); it++)
    {
        if (!((*it)->aDates.empty()))
        {
            (*it)->aDates.sortDates(true) ;
            if (**((*it)->aDates.begin()) == maxTime)
                (*it)->bInLastConsult = true ;
        }
    }
}
catch (...)
{
    erreur("Exception NSRCHistoryView::initHistory.",  standardError, 0) ;
}
}

void
NSRCHistoryView::InitialiseLignes()
{
try
{
    if (Lignes.empty())
        return ;

    RectangleGlobal.left    = 0 ;
	RectangleGlobal.top     = 0 ;
    RectangleGlobal.right   = 0 ;
    RectangleGlobal.bottom  = 0 ;

	//
	// Mise en place des polices dans le tableau - Storing fonts in their array
	//
    // Rappel : NSFont(facename, height, width, escapement, orientation, weight,
    //                 pitchAndFamily, italic, underline, strikeout, charSet,
    //                 outputPrecision, clipPrecision, quality)
    //
    // Police 0 : El�ments non utilis�s - Font 0 : not used elements
	StylesPolice.push_back(new NSFont("Helvetica",14,0,0,0,0,0,0,0,0,1));
    // Police 1 : El�ments utilis�s - Font 0 : used elements
	StylesPolice.push_back(new NSFont("Helvetica",14,0,0,0,0,0,0,0,0,1));
    // Police 2 : El�ments en cours - Font 0 : current elements
	StylesPolice.push_back(new NSFont("Helvetica",14,0,0,0,0,700,0,0,0,1));

    //
	// On r�cup�re un "contexte d'information" concernant l'�cran
	//
	TIC* pDC = new TIC("DISPLAY", NULL, NULL);
	pDC->SetMapMode(MM_LOMETRIC);

   	NS_CLASSLIB::TRect RectangleTexte;
   	RectangleTexte.Set(RectangleGlobal.Left() + 5,
                      RectangleGlobal.Top() - 5,
                      RectangleGlobal.Right(),
                      RectangleGlobal.Bottom()) ;
	//
	// On initialise le point de r�f�rence en haut et � gauche
	//
    NS_CLASSLIB::TPoint PointRef ;
	PointRef.x = RectangleTexte.Left() ;
   	PointRef.y = RectangleTexte.Top() ;

    // TFont* pPolice ;

    for (ItemHistoIter it = Lignes.begin(); it != Lignes.end(); it++)
    {
        NSFont PoliceVoulue ;

        // Item non utilis�
        if      ((*it)->aDates.empty())
        {
            PoliceVoulue = *(StylesPolice[0]) ;
            (*it)->pTextLine->CouleurTexte = TColor::LtGray ;
        }
        // Item en cours
        //
        else if ((*it)->bInLastConsult)
        {
            PoliceVoulue = *(StylesPolice[2]) ;
            (*it)->pTextLine->CouleurTexte = TColor::LtRed ;
        }
        // Item qui a �t� utilis� mais n'est pas en cours
        //
        else
        {
            PoliceVoulue = *(StylesPolice[1]) ;
            (*it)->pTextLine->CouleurTexte = TColor::Black ;
        }

        if (PoliceVoulue.logFont.lfHeight >= 0)
        {
            NS_CLASSLIB::TPoint	PointTransfert ;
            PointTransfert.x = PoliceVoulue.logFont.lfHeight ;
            PointTransfert.y = PoliceVoulue.logFont.lfWidth ;
            pDC->DPtoLP(&PointTransfert) ;
            PoliceVoulue.logFont.lfHeight = PointTransfert.x ;
            PoliceVoulue.logFont.lfWidth  = PointTransfert.y ;
        }

        TFont* pPolice = new TFont(&(PoliceVoulue.logFont)) ;
        pDC->SelectObject(*pPolice) ;
        TEXTMETRIC  TextMetric ;
        LONG        lPolicetmHeight = 0 ;
        if (pDC->GetTextMetrics(TextMetric))
        {
            if ((LargeurPolice == 0) || (LargeurPolice > TextMetric.tmAveCharWidth))
                LargeurPolice = TextMetric.tmAveCharWidth ;
            lPolicetmHeight = TextMetric.tmHeight + TextMetric.tmDescent ;
        }
        //
        // On pr�voit l'espace au dessus du paragraphe
        //
        // PointRef.Offset(0, -StylePara.EspaceDessus);
        //
        // Initialisation de tous les param�tres d�j� connus
        //
        (*it)->pTextLine->Boite.left    = RectangleTexte.Left() ;
        (*it)->pTextLine->Boite.top	    = PointRef.y ;
        (*it)->pTextLine->Boite.bottom  = PointRef.y ;

        string sTexte = (*it)->pTextLine->Texte ;
        NS_CLASSLIB::TSize TailleChaine = pDC->GetTextExtent(sTexte.c_str(), strlen(sTexte.c_str())) ;
        (*it)->pTextLine->Boite.right = (*it)->pTextLine->Boite.left + TailleChaine.cx ;

        LONG lHauteur = lPolicetmHeight ;
        if (lHauteur == 0)
            lHauteur = TailleChaine.cy ;
        (*it)->pTextLine->Boite.bottom -= lHauteur ;
        PointRef.Offset(0, -lHauteur) ;

        delete pPolice ;

        // Mise � jour de RectangleGlobal
        //
        if (RectangleGlobal.right < (*it)->pTextLine->Boite.right)
            RectangleGlobal.right = (*it)->pTextLine->Boite.right ;
        RectangleGlobal.bottom = (*it)->pTextLine->Boite.bottom ;
    }
	delete pDC;
}
catch (...)
{
    erreur("Exception NSRCHistoryView::InitialiseLignes.",  standardError, 0) ;
}
}

void
NSRCHistoryView::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectAPeindre)
{
    if (Lignes.empty())
        return ;

	int iAncDC = dc.SaveDC() ;
	//
	// Fixe la m�trique et l'origine
	//
	dc.SetMapMode(MM_LOMETRIC) ;
	//
	// Stockage des points sup�rieurs gauches et inf�rieurs droits du rectangle
	//
    NS_CLASSLIB::TPoint Points[2] ;
	Points[0] = RectAPeindre.TopLeft() ;
	Points[1] = RectAPeindre.BottomRight() ;
	//
	// Transformation de ces points en coordonn�es logiques
	//
	dc.DPtoLP(Points, 2) ;
	//
	// Calcul du rectangle du document qui correspond au RectAPeindre de
	// l'�cran
	// ATTENTION : dans le mode MM_LOMETRIC les coordonn�es en ordonn�es
	//				  sont n�gatives
	//
	NS_CLASSLIB::TRect* pRectDocument = new NS_CLASSLIB::TRect(Points[0], Points[1]) ;
	*pRectDocument = pRectDocument->Offset(HautGcheFenetre.x, HautGcheFenetre.y) ;
	pRectDocument->Normalized() ;

	//
	// On demande � toutes les lignes concern�es de se repeindre
	//

    // repeinte de la zone d'affichage
    for (ItemHistoIter it = Lignes.begin(); it != Lignes.end(); it++)
    {
        NS_CLASSLIB::TRect BoiteNormale = (*it)->pTextLine->Boite;
		BoiteNormale.Normalized();
		if ((BoiteNormale.right  >= pRectDocument->left)  &&
			 (BoiteNormale.left   <= pRectDocument->right) &&
			 (BoiteNormale.bottom <= pRectDocument->top)   &&
			 (BoiteNormale.top 	 >= pRectDocument->bottom))
			//  ATTENTION : la m�thode Touches de TRect ne fonctionne pas
			//	if (pRectDocument->Touches(BoiteNormale))
    	{
            string sTexte = (*it)->pTextLine->Texte ;
            //
            // Choix de la police
            //
            NSFont PoliceVoulue ;

            if      ((*it)->aDates.empty())
                PoliceVoulue = *(StylesPolice[0]) ;
            else if ((*it)->bInLastConsult)
                PoliceVoulue = *(StylesPolice[2]) ;
            else
                PoliceVoulue = *(StylesPolice[1]) ;

            if (PoliceVoulue.logFont.lfHeight >= 0)
            {
                NS_CLASSLIB::TPoint	PointTransfert ;
                PointTransfert.x = PoliceVoulue.logFont.lfHeight ;
                PointTransfert.y = PoliceVoulue.logFont.lfWidth ;
                dc.DPtoLP(&PointTransfert) ;
                PoliceVoulue.logFont.lfHeight = PointTransfert.x ;
                PoliceVoulue.logFont.lfWidth  = PointTransfert.y ;
            }

            TFont* pPolice = new TFont(&(PoliceVoulue.logFont)) ;
            dc.SelectObject(*pPolice) ;
            //
	        // Calcul de la taille effective de la ligne
        	//
            SIZE lpSize ;
	        BOOL Continuer = GetTextExtentPoint(HDC(dc), sTexte.c_str(), strlen(sTexte.c_str()), &lpSize) ;
	        if (Continuer)
            {
	            //
	            // Calcul du point �cran o� afficher
            	//
                NS_CLASSLIB::TPoint PointAffichage ;
	            PointAffichage.x = (*it)->pTextLine->Boite.left ;
	            PointAffichage.y = (*it)->pTextLine->Boite.top ;
	            PointAffichage -= HautGcheFenetre ;

	            dc.SetTextJustification(0, 0) ;                dc.SetTextColor((*it)->pTextLine->CouleurTexte) ;	            dc.TextOut(PointAffichage, sTexte.c_str()) ;
            }

	        dc.RestoreFont() ;
	        delete pPolice ;        }
	}
	delete pRectDocument ;
	dc.RestoreDC(iAncDC) ;
}

//---------------------------------------------------------------------------
//  Scroll vertical
//---------------------------------------------------------------------------
void
NSRCHistoryView::EvVScroll(UINT scrollCode, UINT thumbPos, HWND hWndCtl)
{
	if (Lignes.empty())
		return ;

	const 	 NSItemHistoriser* pLigne;
	int		 iTailleScroll;
	NS_CLASSLIB::TPoint* pPointRef;
	//
	// On sort tout de suite si on est sur les lignes extr�mes
	//
	if (((scrollCode == SB_LINEDOWN) && (PremLigne == Lignes.size())) ||
        ((scrollCode == SB_PAGEDOWN) && (PremLigne == Lignes.size())) ||
        ((scrollCode == SB_LINEUP) && (PremLigne == 1)) ||
        ((scrollCode == SB_PAGEUP) && (PremLigne == 1)))
		return;
	//
	// On r�cup�re un "contexte d'information" concernant l'�cran
	//
	TIC* pDC = new TIC("DISPLAY", NULL, NULL);
	pDC->SetMapMode(MM_LOMETRIC);
	//
	// Scroll vers le haut (fl�che basse)
	//
	if (scrollCode == SB_LINEDOWN)
	{
		//
		// Calcul de la quantit� � scroller (hauteur de la premi�re ligne)
		//
		pLigne = Lignes[PremLigne-1];
		iTailleScroll = pLigne->pTextLine->Boite.Height();
		//
		// Conversion en pixels
		//
		pPointRef = new NS_CLASSLIB::TPoint(0, iTailleScroll);
		pDC->LPtoDP(pPointRef);
		//
		// Demande de scroll
		//
		ScrollWindow(0, -pPointRef->y);
		delete pPointRef;
        pPointRef = 0;
		//
		// Ajustement des variables PremLigne et HautGcheFenetre
		//
		PremLigne++;
		HautGcheFenetre.y += iTailleScroll;
		//UpdateWindow();
	}
    //
	// Scroll vers le haut (page basse)	//
	else if (scrollCode == SB_PAGEDOWN)
    {
        NS_CLASSLIB::TRect rectClient = GetClientRect();
        int cyScroll = ::GetSystemMetrics(SM_CYHSCROLL);
        int hauteurLignes = 0;
        UINT numLigne = PremLigne; // num�ro de la premi�re ligne visible
        int hauteurFen = rectClient.bottom - rectClient.top - cyScroll; // hauteur fenetre en pixels
        int hBoite = 0, hLigne = 0;
        int tailleScroll = 0;

        while ((numLigne < Lignes.size()) && (hauteurLignes < hauteurFen))
        {
            pLigne = Lignes[numLigne - 1];
            hBoite = pLigne->pTextLine->Boite.Height();
            NS_CLASSLIB::TPoint py(0, hBoite);
            pDC->LPtoDP(&py);
            hLigne = py.y;

            tailleScroll += hBoite;
            hauteurLignes += hLigne;
            numLigne++;
        }

        PremLigne = numLigne;
        ScrollWindow(0, -hauteurLignes);
        HautGcheFenetre.y += tailleScroll;
    }
	//
	// Scroll vers le bas (fl�che haute)
	//
	else if (scrollCode == SB_LINEUP)
	{
		//
		// Calcul de la quantit� � scroller (hauteur de l'avant-premi�re ligne)
		//
		pLigne = Lignes[PremLigne-2];
		iTailleScroll = pLigne->pTextLine->Boite.Height();
		//
		// Conversion en pixels
		//
		pPointRef = new NS_CLASSLIB::TPoint(0, iTailleScroll);
		pDC->LPtoDP(pPointRef);
		//
		// Demande de scroll
		//
		ScrollWindow(0, pPointRef->y);
		delete pPointRef;
        pPointRef = 0;
		//
		// Ajustement des variables PremLigne et HautGcheFenetre
		//
		PremLigne--;
		HautGcheFenetre.y -= iTailleScroll;
		//UpdateWindow();
	}
    //
	// Scroll vers le bas (page haute)
	//
	else if (scrollCode == SB_PAGEUP)
    {
        NS_CLASSLIB::TRect rectClient = GetClientRect();
        int cyScroll = ::GetSystemMetrics(SM_CYHSCROLL);
        int hauteurLignes = 0;
        int numLigne = PremLigne; // num�ro de la premi�re ligne visible
        int hauteurFen = rectClient.bottom - rectClient.top - cyScroll; // hauteur fenetre en pixels
        int hBoite = 0, hLigne = 0;
        int tailleScroll = 0;

        while ((numLigne > 1) && (hauteurLignes < hauteurFen))
        {
            pLigne = Lignes[numLigne - 2];  // Ligne pr�c�dente
            hBoite = pLigne->pTextLine->Boite.Height();
            NS_CLASSLIB::TPoint py(0, hBoite);
            pDC->LPtoDP(&py);
            hLigne = py.y;

            tailleScroll += hBoite;
            hauteurLignes += hLigne;
            numLigne--;
        }

        PremLigne = numLigne;
        ScrollWindow(0, hauteurLignes);
        HautGcheFenetre.y -= tailleScroll;
    }

	delete pDC;
    pDC = 0;
	SetScrollPos(SB_VERT, PremLigne);
}

//---------------------------------------------------------------------------
//  Scroll horizontal
//---------------------------------------------------------------------------
void
NSRCHistoryView::EvHScroll(UINT scrollCode, UINT thumbPos, HWND hWndCtl)
{
	if (Lignes.empty())
        return ;

	NS_CLASSLIB::TPoint* pPointRef;
	//
	// On sort tout de suite si on est sur les lignes extr�mes
	//
	if (((scrollCode == SB_LINERIGHT) && (HautGcheFenetre.x == RectangleGlobal.Width())) ||
        ((scrollCode == SB_PAGERIGHT) && (HautGcheFenetre.x == RectangleGlobal.Width())) ||
		((scrollCode == SB_LINELEFT) && (HautGcheFenetre.x == 0)) ||
        ((scrollCode == SB_PAGELEFT) && (HautGcheFenetre.x == 0)))
		return;
	//
	// On r�cup�re un "contexte d'information" concernant l'�cran
	//
	TIC* pDC = new TIC("DISPLAY", NULL, NULL);
	pDC->SetMapMode(MM_LOMETRIC);
	//
	// Scroll vers la gauche (fl�che droite)
	//
	if (scrollCode == SB_LINERIGHT)
	{
		//
		// Conversion en pixels
		//
		pPointRef = new NS_CLASSLIB::TPoint(LargeurPolice, 0);
		pDC->LPtoDP(pPointRef);
		//
		// Demande de scroll
		//
		ScrollWindow(-pPointRef->x, 0);
		delete pPointRef;
        pPointRef = 0;
		//
		// Ajustement de HautGcheFenetre
		//
		HautGcheFenetre.x += LargeurPolice;
	}
    //
	// Scroll vers la gauche (page droite)
	//
	if (scrollCode == SB_PAGERIGHT)
	{
		//
		// Conversion en pixels
		//
        int k = 1;
        pPointRef = new NS_CLASSLIB::TPoint(LargeurPolice, 0);
        pDC->LPtoDP(pPointRef);

        while ((k <= 10) && ((HautGcheFenetre.x + LargeurPolice) <= RectangleGlobal.Width()))
        {
		    //
		    // Demande de scroll
		    //
		    ScrollWindow(-pPointRef->x, 0);
            //
		    // Ajustement de HautGcheFenetre
		    //
            HautGcheFenetre.x += LargeurPolice;
            k++;
        }

		delete pPointRef;
        pPointRef = 0;
	}
	//
	// Scroll vers la droite (fl�che gauche)
	//
	else if (scrollCode == SB_LINELEFT)
	{
		//
		// Conversion en pixels
		//
		pPointRef = new NS_CLASSLIB::TPoint(LargeurPolice, 0);
		pDC->LPtoDP(pPointRef);
		//
		// Demande de scroll
		//
		ScrollWindow(pPointRef->x, 0);
		delete pPointRef;
        pPointRef = 0;
		//
		// Ajustement de HautGcheFenetre
		//
		HautGcheFenetre.x -= LargeurPolice;
	}
    //
	// Scroll vers la droite (page gauche)
	//
	if (scrollCode == SB_PAGELEFT)
	{
		//
		// Conversion en pixels
		//
        int k = 1;
        pPointRef = new NS_CLASSLIB::TPoint(LargeurPolice, 0);
        pDC->LPtoDP(pPointRef);

        while ((k <= 10) && ((HautGcheFenetre.x - LargeurPolice) >= 0))
        {
		    //
		    // Demande de scroll
		    //
		    ScrollWindow(pPointRef->x, 0);
            //
		    // Ajustement de HautGcheFenetre
		    //
            HautGcheFenetre.x -= LargeurPolice;
            k++;
        }

		delete pPointRef;
        pPointRef = 0;
	}

	delete pDC;
    pDC = 0;
    if (LargeurPolice > 0)
		SetScrollPos(SB_HORZ, HautGcheFenetre.x / LargeurPolice);
}

//---------------------------------------------------------------------------
//  Molette
//---------------------------------------------------------------------------
LRESULT
NSRCHistoryView::EvMouseWheel(WPARAM wParam, LPARAM lParam)
{
	if (Lignes.empty())
		return 0 ;

    // WORD    fwKeys  = LOWORD(wParam) ;           // key flags
    short   zDelta  = (short) HIWORD(wParam) ;   // wheel rotation
    // short   xPos    = (short) LOWORD(lParam) ;   // horizontal position of pointer
    // short   yPos    = (short) HIWORD(lParam) ;   // vertical position of pointer

    UINT    scrollCode;

    // A positive value indicates that the wheel was rotated forward,
    // away from the user
    //
    if (zDelta > 0)
        scrollCode = SB_LINEUP ;

    // a negative value indicates that the wheel was rotated backward,
    // toward the user.
    //
    else if (zDelta < 0)
        scrollCode = SB_LINEDOWN ;

    for (int i = 0; i < 4; i++)
        EvVScroll(scrollCode, 0, 0) ;

    return 0 ;
}

void
NSRCHistoryView::reloadView(string sReason)
{
}

// --------------------------------------------------------------------------
//
// Class NSItemHistoriser
//
// --------------------------------------------------------------------------

NSItemHistoriser::NSItemHistoriser()
{
    sLocalisation   = "" ;
    sLexique        = "" ;
    sComplement     = "" ;

    pTextLine       = 0 ;
    bInLastConsult  = false ;
}

NSItemHistoriser::NSItemHistoriser(NSItemHistoriser& rv)
{
try
{
    sLocalisation   = rv.sLocalisation ;
    sLexique        = rv.sLexique ;
    sComplement     = rv.sComplement ;

    if (rv.pTextLine)
        pTextLine   = new NSLigne(*(rv.pTextLine)) ;
    else
        pTextLine   = 0 ;
    aDates          = rv.aDates ;
    bInLastConsult  = rv.bInLastConsult ;
}
catch (...)
{
    erreur("Exception NSItemHistoriser copy ctor.", standardError, 0) ;
}
}

NSItemHistoriser::~NSItemHistoriser()
{
    if (pTextLine)
        delete pTextLine ;
}

NSItemHistoriser&
NSItemHistoriser::operator=(NSItemHistoriser src)
{
try
{
    sLocalisation   = src.sLocalisation ;
    sLexique        = src.sLexique ;
    sComplement     = src.sComplement ;

    if (pTextLine)
        delete pTextLine ;
    if (src.pTextLine)
        pTextLine   = new NSLigne(*(src.pTextLine)) ;
    else
        pTextLine   = 0 ;
    aDates          = src.aDates ;
    bInLastConsult  = src.bInLastConsult ;

    return *this ;
}
catch (...)
{
    erreur("Exception NSItemHistoriser = operator.", standardError, 0) ;
    return *this ;
}
}

// --------------------------------------------------------------------------
// ----------------------- METHODES DE ItemHistoArray -----------------------
// --------------------------------------------------------------------------

ItemHistoArray::ItemHistoArray()
               :ItemHistoVector()
{
}

ItemHistoArray::ItemHistoArray(ItemHistoArray& rv)               :ItemHistoVector()
{
try
{
    if (!(rv.empty()))
        for (ItemHistoIter i = rv.begin(); i != rv.end(); i++)
            push_back(new NSItemHistoriser(*(*i)));
}
catch (...)
{
    erreur("Exception ItemHistoArray copy ctor.",  standardError, 0) ;
}
}

void
ItemHistoArray::vider()
{
    if (empty())
        return;

    for (ItemHistoIter i = begin(); i != end(); )
    {
   	    delete *i;
        erase(i);
    }
}

ItemHistoArray::~ItemHistoArray()
{
	vider();
}

ItemHistoArray&
ItemHistoArray::operator=(ItemHistoArray src)
{
try
{
    vider();

    if (!(src.empty()))
        for (ItemHistoIter i = src.begin(); i != src.end(); i++)
            push_back(new NSItemHistoriser(*(*i)));
    return *this;
}
catch (...)
{
    erreur("Exception ItemHistoArray = operator.",  standardError, 0) ;
    return *this;
}
}

