// -----------------------------------------------------------------------------
// nsldvvar.cpp
// -----------------------------------------------------------------------------
// $Revision: 1.61 $
// $Author: philippe $
// $Date: 2005/06/09 13:11:08 $
// -----------------------------------------------------------------------------
// Ligne de vie - Arrays d'objets de type Vue (au sens Document/Vue)
// Ligne de vie - Arrays of View objects (for Document/View model)
// -----------------------------------------------------------------------------
// FLP - aout 2003
// PA  - juillet 2003
// ...
// -----------------------------------------------------------------------------

#include <owl\owlpch.h>
#include <owl\dc.h>
#include <owl\gauge.h>

#include "nautilus\nssuper.h"
#include "nautilus\nsldvvar.h"
#include "nautilus\nsldvvue.h"
#include "nautilus\nsldvvuetech.h"
#include "nautilus\nsldvdoc.h"
#include "nautilus\nsldvvue.rh"
#include "nautilus\nstrihis.h"
#include "nautilus\nsepicap.h"
#include "nsbb\nstlibre.h"
#include "nssavoir\nsgraphe.h"
#include "nssavoir\nspathor.h"
#include "nsbb\nsmedicdlg.h"
#include "nsbb\nsmediccycle.h"
#include "nsbb\ns_cisp.h"
#include "nsbb\nsbbtran.h"
#include "nsepisod\nsclasser.h"
#include "nsepisod\nssoapdiv.h"

// --------------------------------------------------------------------------
// --------------------- METHODES DE ArrayPreoccupView ----------------------
// --------------------------------------------------------------------------

ArrayPreoccupView::ArrayPreoccupView(ArrayPreoccupView& rv)
                  :ArrayPreocView()
{
try
{
	if (false == rv.empty())
  	for (ArrayPreoccupViewIter i = rv.begin(); i != rv.end(); i++)
    	push_back(new NSPreoccupView(*(*i))) ;
}
catch (...)
{
	erreur("Exception ArrayPreoccupView copy ctor.",  standardError, 0) ;
}
}


// va falloir revenir sur la m�thode init pour l'index
void
ArrayPreoccupView::init(ArrayConcern* pConcerns, NSContexte* pCtx, NSLdvView* pView, int iIdx)
{
/*
    if (!(pConcerns->empty()))
        for (ArrayPreoccuIter i = pPreoccupations->begin() ; i != pPreoccupations->end() ; i++)
            push_back(new NSPreoccupView(pCtx, pView, *i, iIdx));
*/
}

void
ArrayPreoccupView::vider()
{
	if (empty())
  	return ;

	for (ArrayPreoccupViewIter i = begin(); end() != i ; )
	{
  	delete *i ;
    erase(i) ;
	}
}

ArrayPreoccupView::~ArrayPreoccupView()
{
	vider();
}

ArrayPreoccupView&
ArrayPreoccupView::operator=(ArrayPreoccupView src)
{
try
{
	if (this == &src)
  	return *this ;

	vider() ;

	if (false == src.empty())
  	for (ArrayPreoccupViewIter i = src.begin(); src.end() != i ; i++)
    	push_back(new NSPreoccupView(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception ArrayPreoccupView (=).",  standardError, 0) ;
	return *this ;
}
}

// --------------------------------------------------------------------------
// ---------------------- METHODES DE ArrayObjetsView -----------------------
// --------------------------------------------------------------------------

ArrayObjetsView::ArrayObjetsView(ArrayObjetsView& rv)
                :ArrayObjView()
{
try
{
	if (false == rv.empty())
  	for (ArrayObjViewIter i = rv.begin(); rv.end() != i; i++)
    	push_back(new NSLdvObjetView(*(*i))) ;
}
catch (...)
{
	erreur("Exception ArrayObjetsView copy ctor.",  standardError, 0) ;
}
}

void
ArrayObjetsView::init(ArrayObjets* pObj, NSContexte* pCtx, NSLdvView* pView)
{
try
{
	if ((NULL == pObj) || pObj->empty())
		return ;

  NSLdvViewArea* pActiveWorkingArea = pView->getActiveWorkingArea() ;
  if (NULL == pActiveWorkingArea)
    return ;

	for (ArrayObjIter i = pObj->begin() ; pObj->end() != i ; i++)
	{
		NSConcernView   *pPbView ;
		bool            bContinue = true ;

		for (ToonsIter PbIter = pView->aToons.begin() ; (PbIter != pView->aToons.end()) && bContinue ; PbIter++)
		{
			if (dynamic_cast<NSConcernView *>(*PbIter))
			{
				pPbView = (NSConcernView *)(*PbIter) ;
				if ((*i)->sConcern == pPbView->pConcern->sReference)
					bContinue = false ;
			}
		}

		push_back(new NSLdvObjetView(pCtx, pActiveWorkingArea, *i, pPbView)) ;
	}
}
catch (...)
{
	erreur("Exception ArrayObjetsView::init.", standardError, 0) ;
}
}

void
ArrayObjetsView::vider()
{
	if (empty())
  	return ;

	for (ArrayObjViewIter i = begin() ; end() != i ; )
  {
  	delete *i ;
    erase(i) ;
  }
}

ArrayObjetsView::~ArrayObjetsView()
{
	vider() ;
}

ArrayObjetsView&
ArrayObjetsView::operator=(ArrayObjetsView src)
{
try
{
  if (this == &src)
		return *this ;

	vider() ;

	if (false == src.empty())
  	for (ArrayObjViewIter i = src.begin(); src.end() != i ; i++)
    	push_back(new NSLdvObjetView(*(*i))) ;

	return *this ;
}
catch (...)
{
	erreur("Exception ArrayObjetsView (=).",  standardError, 0) ;
	return *this ;
}
}

// -----------------------------------------------------------------
//
//  M�thodes de NSNewConcernDlg
//
// -----------------------------------------------------------------
// -----------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSNewConcernDlg, NSUtilDialog)
  EV_COMMAND(IDOK,                        CmOk),
  EV_COMMAND(IDCANCEL,                    CmCancel),
  EV_COMMAND_AND_ID(IDR_CHRONIQUE,        UserName),
  EV_COMMAND_AND_ID(IDR_DANS,             UserName),
  EV_COMMAND_AND_ID(IDR_DUREE,            UserName),
  EV_COMMAND_AND_ID(IDR_LE,               UserName),
  EV_CHILD_NOTIFY_ALL_CODES(IDC_GRAVITE,  UpdateSeverity),
  EV_COMMAND(DUSOI_BTN,                   EvaluateDusoi),
  EV_COMMAND(IDC_COC,                     SetCocCodeVerbose),
END_RESPONSE_TABLE;

NSNewConcernDlg::NSNewConcernDlg(NSLdvView* pView, string* psNode, NSContexte* pCtx, NSPatPathoArray* pDetails, string *pCocCode, string *sLabel, string *pLibelle, int iSever)
                :NSUtilDialog((TWindow*) pView, pCtx, "NEW_PROBLEM", pCtx->GetMainWindow()->GetModule())
{
try
{
  pLdvView    = pView ;
  pLdvDoc     = 0 ;
  iSeverity   = iSever ;

  psNewNode   = psNode ;

  pType        = new NSUtilLexique(pContexte, this, PREOCCUP_EDIT, pContexte->getDico()) ;
  pType->setLostFocusFunctor(new MemFunctor<NSNewConcernDlg>( (NSNewConcernDlg*)this, &NSNewConcernDlg::SetCocCodeNoVerbose )) ;

  //pRc         = new OWL::TRadioButton(this, IDC_RC) ;
  pDateDebText = new OWL::TStatic(this, DATE_DEB_TEXT) ;
  pDateDeb     = new NSUtilEditDateHeure(pContexte, this, PROB_DATE_DEB) ;
  pGroupFin    = new TGroupBox(this, DATE_FIN_TEXT) ;
  pDateFin     = new NSUtilEditDateHeure(pContexte, this, PROB_DATE_FIN) ;
  pNbJours     = new NSEditNum(pContexte, this, IDC_NBJOURS, 10) ;
  pRChronique  = new OWL::TRadioButton(this, IDR_CHRONIQUE) ;
  pRDans       = new OWL::TRadioButton(this, IDR_DANS) ;
  pRDuree      = new OWL::TRadioButton(this, IDR_DUREE) ;
  pJoursText   = new OWL::TStatic(this, JOURS_TEXT) ;
  pRLe         = new OWL::TRadioButton(this, IDR_LE) ;
  pGravite     = new OWL::THSlider(this, IDC_GRAVITE) ;
  // pRisque 	= new OWL::THSlider(this, IDC_RISQUE);

  pSeverityText = new OWL::TStatic(this, SEVER_TEXT) ;
  pGravGauge    = new OWL::TGauge(this, "%d%%", IDC_PROGRESSGRAV, 18, 182, 300, 20) ;
  // pGravGauge  = new OWL::TGauge(this, "%d%%", IDC_PROGRESSGRAV, 25, 209, 215, 20) ;
  pGravGauge->SetRange(0, 100) ;
  pGravGauge->SetNativeUse(nuNever) ;

  pDusoiButton = new OWL::TButton(this, DUSOI_BTN) ;
  bDusoiWasCalculated = false ;
  iDusoiValue         = 0 ;
  iSymptomValue       = 0 ;
  iComplicationValue  = 0 ;
  iPrognosisValue     = 0 ;
  iTreatabilityValue  = 0 ;

  pCocButton = new OWL::TButton(this, IDC_COC) ;

  // pRiskGauge  = new OWL::TGauge(this, "%d%%", IDC_PROGRESSRISK, 25, 261, 215, 20) ;
  // pRiskGauge->SetNativeUse(nuNever) ;

  if ((strlen(sLabel->c_str()) > 0) && (sLabel->rfind(")") == strlen(sLabel->c_str()) - 1))
  {
		int iPos = sLabel->rfind("(") ;
		sLabel->replace(iPos - 1, NPOS, "\0") ;
  }

  psType      = sLabel ;
  psLibelle   = pLibelle ;
  psCode      = 0 ;
  psDateDeb   = 0 ;
  psCocCode   = pCocCode ;

  pPtDetails  = pDetails ;
}
catch (...)
{
    erreur("Exception NSNewConcernDlg ctor.",  standardError, 0) ;
}
}

NSNewConcernDlg::NSNewConcernDlg(TWindow* pPere, string* psNode, NSLdvDocument* pDoc, NSContexte* pCtx, NSPatPathoArray* pDetails, string *pCocCode, string *pCode, string *psDate)
                :NSUtilDialog(pPere, pCtx, "NEW_PROBLEM", pCtx->GetMainWindow()->GetModule())
{
try
{
  pLdvView    = 0 ;
  pLdvDoc     = pDoc ;
  iSeverity   = 10 ;

  psNewNode   = psNode ;

  pType        = new NSUtilLexique(pContexte, this, PREOCCUP_EDIT, pContexte->getDico()) ;
  //pRc         = new OWL::TRadioButton(this, IDC_RC) ;
  pDateDebText = new OWL::TStatic(this, DATE_DEB_TEXT) ;
  pDateDeb     = new NSUtilEditDateHeure(pContexte, this, PROB_DATE_DEB) ;
  pGroupFin    = new TGroupBox(this, DATE_FIN_TEXT) ;
  pDateFin     = new NSUtilEditDateHeure(pContexte, this, PROB_DATE_FIN) ;
  pNbJours     = new NSEditNum(pContexte, this, IDC_NBJOURS, 10) ;
  pRChronique  = new OWL::TRadioButton(this, IDR_CHRONIQUE) ;
  pRDans       = new OWL::TRadioButton(this, IDR_DANS) ;
  pRDuree      = new OWL::TRadioButton(this, IDR_DUREE) ;
  pJoursText   = new OWL::TStatic(this, JOURS_TEXT) ;
  pRLe         = new OWL::TRadioButton(this, IDR_LE) ;
  pGravite 	   = new OWL::THSlider(this, IDC_GRAVITE) ;
  // pRisque 	= new OWL::THSlider(this, IDC_RISQUE) ;

  pSeverityText = new OWL::TStatic(this, SEVER_TEXT) ;
  pGravGauge    = new OWL::TGauge(this, "%d%%", IDC_PROGRESSGRAV, 18, 182, 300, 20) ;
  // pGravGauge  = new OWL::TGauge(this, "%d%%", IDC_PROGRESSGRAV, 25, 209, 215, 20) ;
  pGravGauge->SetRange(0, 100) ;
  pGravGauge->SetNativeUse(nuNever) ;

  pDusoiButton = new OWL::TButton(this, DUSOI_BTN) ;
  bDusoiWasCalculated = false ;
  iDusoiValue         = 0 ;
  iSymptomValue       = 0 ;
  iComplicationValue  = 0 ;
  iPrognosisValue     = 0 ;
  iTreatabilityValue  = 0 ;

  pCocButton = new OWL::TButton(this, IDC_COC) ;

  // pRiskGauge  = new OWL::TGauge(this, "%d%%", IDC_PROGRESSRISK, 25, 261, 215, 20) ;
  // pRiskGauge->SetNativeUse(nuNever) ;

  psType      = 0 ;
  psCode      = pCode ;
  psLibelle   = 0 ;
  psDateDeb   = psDate ;

  pPtDetails  = pDetails ;
  psCocCode   = pCocCode ;
}
catch (...)
{
	erreur("Exception NSNewConcernDlg ctor.",  standardError, 0) ;
}
}

NSNewConcernDlg::~NSNewConcernDlg()
{
  delete pType ;
  delete pDateDebText ;
  //delete pRc ;
  delete pDateDeb ;
  delete pGroupFin ;
  delete pDateFin ;
  delete pNbJours ;
  delete pRChronique ;
  delete pRDans ;
  delete pRDuree ;
  delete pJoursText ;
  delete pRLe ;
  delete pGravite ;
  delete pSeverityText ;
  delete pGravGauge ;
  // delete pRisque ;
  // delete pRiskGauge ;
  delete pDusoiButton ;
  delete pCocButton ;
}

void
NSNewConcernDlg::SetupWindow()
{
	TDialog::SetupWindow() ;

	// char szDateJour[9];
	// donne_date_duJour(szDateJour);
	NVLdVTemps tpsNow ;
	tpsNow.takeTime() ;

	if (psDateDeb)
	{
		// We must normalize the incoming date
		NVLdVTemps tpsNormalizer ;
    if (tpsNormalizer.initFromDate(*psDateDeb))
		{
    	tpsNormalizer.normalize() ;
			pDateDeb->setDate(tpsNormalizer.donneDateHeure()) ;
		}
    else
			pDateDeb->setDate(tpsNow.donneDateHeure()) ;
	}
	else
		pDateDeb->setDate(tpsNow.donneDateHeure()) ;

	pDateFin->setDate(tpsNow.donneDateHeure()) ;

	if (psCode)
		pType->setLabel(*psCode) ;
	else
		pType->SetText(psType->c_str()) ;

	pNbJours->SetText("") ;

	pRChronique->SetCheck(BF_CHECKED) ;
	pDateFin->SetReadOnly(true) ;
	pNbJours->SetReadOnly(true) ;

	pGravite->SetRange(0, 100) ;   //fixer min et max
	pGravite->SetRuler(5, false) ; //espacement entre deux graduations
	pGravite->SetPosition(10) ;

	pGravGauge->SetValue(iSeverity) ;

	//pRisque->SetRange(0, 100);
	//pRisque->SetRuler(5, false);
	//pRisque->SetPosition(0);

	//pRiskGauge->SetRange(0, 100);

  // Texts
  //
  NSSuper *pSuper = pContexte->getSuperviseur() ;
  string sTitle = pSuper->getText("healthConcernDialog", "newHealthConcern") ;
  SetCaption(sTitle.c_str()) ;

  string sText = pSuper->getText("healthConcernDialog", "startingDate") ;
  pDateDebText->SetCaption(sText.c_str()) ;
  sText = pSuper->getText("healthConcernDialog", "endingDate") ;
  pGroupFin->SetCaption(sText.c_str()) ;
  sText = pSuper->getText("healthConcernDialog", "undetermined") ;
  pRChronique->SetCaption(sText.c_str()) ;
  sText = pSuper->getText("healthConcernDialog", "fromNow") ;
  pRDans->SetCaption(sText.c_str()) ;
  sText = pSuper->getText("healthConcernDialog", "totalDuration") ;
  pRDuree->SetCaption(sText.c_str()) ;
  sText = pSuper->getText("healthConcernDialog", "onThe") ;
  pRLe->SetCaption(sText.c_str()) ;
  sText = pSuper->getText("healthConcernDialog", "days") ;
  pJoursText->SetCaption(sText.c_str()) ;
  sText = pSuper->getText("healthConcernDialog", "severityIndex") ;
  pSeverityText->SetCaption(sText.c_str()) ;
  sText = pSuper->getText("healthConcernDialog", "dusoi") ;
  pDusoiButton->SetCaption(sText.c_str()) ;
  sText = pSuper->getText("healthConcernDialog", "continuityOfCareCode") ;
  pCocButton->SetCaption(sText.c_str()) ;
}

void
NSNewConcernDlg::ResultCons()
{
}

void
NSNewConcernDlg::UserName(WPARAM wParam)
{
  switch (wParam)
  {
    case (IDR_CHRONIQUE) :
    	pDateFin->SetReadOnly(true) ;
      pNbJours->SetReadOnly(true) ;
      break ;
    case (IDR_DANS) :
    	pDateFin->SetReadOnly(true) ;
      pNbJours->SetReadOnly(false) ;
      pNbJours->SetFocus() ;
      break ;
    case (IDR_DUREE) :
    	pDateFin->SetReadOnly(true) ;
      pNbJours->SetReadOnly(false) ;
      pNbJours->SetFocus() ;
      break ;
    case (IDR_LE) :
    	pNbJours->SetReadOnly(true) ;
      pDateFin->SetReadOnly(false) ;
      pDateFin->SetFocus() ;
      break ;
  }
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
void
NSNewConcernDlg::CmOk()
{
try
{
  // on r�cup�re d'abord un �ventuel �l�ment lexique s�lectionn� par les fl�ches
  // Le Return n'envoie pas d'EvKeyDown et appelle directement CmOk
  if (pType->pDico->pDicoDialog->EstOuvert())
  {
    pType->pDico->pDicoDialog->InsererElementLexique() ;
    return ;
  }

  // On v�rifie qu'un edit n'�tait pas en cours de saisie
  // Le Return n'envoie pas de KillFocus et appelle directement CmOk
  //
  killControlFocusOnReturnClose() ;

  string sTL = "" ;

  // Ne pas accepter les textes libres
  if (pType->getCode() == string("�?????"))
  {
    if (!(pContexte->getSuperviseur()->getEpisodus()->bAllowFreeTextLdV))
    {
      string sWarningTxt = pContexte->getSuperviseur()->getText("lexiqueManagement", "freeTextNotAllowed") ;
      erreur(sWarningTxt.c_str(), warningError, 0, GetHandle()) ;
      pType->SetFocus() ;
      return ;
    }

    int       iBuffLen  = pType->GetTextLen() ;
    char far  *szBuff   = new char[iBuffLen + 1] ;
    pType->GetText(szBuff, iBuffLen + 1) ;
    sTL = string(szBuff) ;
    delete[] szBuff ;

    if (psLibelle)
      *psLibelle = sTL ;
  }

  string sDateDeb ;
  pDateDeb->getDate(&sDateDeb) ;

  string sDateFin ;

  // r�cup�ration de la valeur du champs edit correspondant au nombre de jours
  pNbJours->donneValeur() ;

  // si on est dans le cas o� "chronique" est coch�e
  if (pRChronique->GetCheck() == BF_CHECKED)
    sDateFin = "00000000000000" ;

  // si on dans le cas o� "dans" est coch�e
  if (pRDans->GetCheck() == BF_CHECKED)
  {
    if (pNbJours->dValeur < 1)
    {
      erreur("La pr�occupation doit durer au moins 1 jour.", standardError, 0, GetHandle()) ;
      return ;
    }

    NVLdVTemps  tDateFin ;
    tDateFin.takeTime() ;
    tDateFin.ajouteJours(pNbJours->dValeur) ;
    sDateFin = tDateFin.donneDateHeure() ;
  }

  // si on est dans le cas o� "dur�e" est coch�e
  if (pRDuree->GetCheck() == BF_CHECKED)
  {
    if (pNbJours->dValeur < 1)
    {
      erreur("La pr�occupation doit durer au moins 1 jour.", standardError, 0, GetHandle()) ;
      return ;
    }

    NVLdVTemps  tDateFin ;
    tDateFin.initFromDate(sDateDeb) ;
    tDateFin.ajouteJours(pNbJours->dValeur) ;
    sDateFin = tDateFin.donneDateHeure() ;
  }

  // si on est dans le cas o� "le" est coch�e
  if (pRLe->GetCheck() == BF_CHECKED)
    pDateFin->getDate(&sDateFin) ;

  int iGravite    = pGravite->GetPosition() ;
  int iRisque     = 0 ; // pRisque->GetPosition() ;

  NSLdvDocument *pDoc = pLdvDoc ;
  if ((NULL == pDoc) && pLdvView)
    pDoc = pLdvView->getDoc() ;

  if (!pDoc)
    return ;

  /* bool bResult = */ pDoc->newConcern(pType->getCode(), psNewNode, sDateDeb, sDateFin, iGravite, *psCocCode, iRisque, pPtDetails, sTL) ;

  if (psType)
    *psType = pType->getCode() ;
  if (psCode)
    *psCode = pType->getCode() ;

	CloseWindow(IDOK) ;
}
catch (...)
{
  erreur("Exception NSNewConcernDlg::CmOk.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
void
NSNewConcernDlg::CmCancel()
{
	Destroy(IDCANCEL) ;
}

void
NSNewConcernDlg::UpdateSeverity(uint)
{
	int setting = pGravite->GetPosition() ;

	if      (setting < 25)
		pGravGauge->SetColor(NS_CLASSLIB::TColor(0, 0, 128)) ;   // Blue
	else if (setting < 50)
		pGravGauge->SetColor(NS_CLASSLIB::TColor(0, 128, 0)) ;   // Green
	else if (setting < 75)
		pGravGauge->SetColor(NS_CLASSLIB::TColor(128, 128, 0)) ; // Yellow
	else
		pGravGauge->SetColor(NS_CLASSLIB::TColor(128, 0, 0)) ;   // Red

	pGravGauge->SetValue(setting) ;
}

/*
void
NSNewConcernDlg::UpdateRisk(uint)
{
    int setting = pRisque->GetPosition();

    if      (setting < 10)
        pRiskGauge->SetColor(NS_CLASSLIB::TColor(0, 0, 128));
    else if (setting < 15)
        pRiskGauge->SetColor(NS_CLASSLIB::TColor(0, 128, 0));
    else if (setting < 20)
        pRiskGauge->SetColor(NS_CLASSLIB::TColor(128, 128, 0));
    else
        pRiskGauge->SetColor(NS_CLASSLIB::TColor(128, 0, 0));

    pRiskGauge->SetValue(setting);
} */

void
NSNewConcernDlg::SetDetails()
{
try
{
# ifdef __OB1__
	NSSmallBrother* pBigBoss = new NSSmallBrother(pContexte, pPtDetails, 0) ;
#else
	NSSmallBrother* pBigBoss = new NSSmallBrother(pContexte, pPtDetails, 0, false /* initFromBbk */) ;
#endif
	pBigBoss->pFenetreMere = pContexte->GetMainWindow() ;
	// on lance l'archetype li� au code m�dicament (avec fil guide associ�)
	pBigBoss->lance12("0PRO11", "0DETA1") ;
	delete pBigBoss ;
}
catch (...)
{
	erreur("Exception NSNewConcernDlg::SetDetails.",  standardError, 0) ;
}
}

void
NSNewConcernDlg::EvaluateDusoi()
{
try
{
  int iDusoi = iDusoiValue ;
  int iSympt = iSymptomValue ;
  int iCompl = iComplicationValue ;
  int iProgn = iPrognosisValue ;
  int iTreat = iTreatabilityValue ;

  NSDusoiDlg* pDusoiDialog = new NSDusoiDlg(this, pContexte, &iDusoi, &iSympt,
                                            &iCompl, &iProgn, &iTreat) ;
  int iExecReturn = pDusoiDialog->Execute() ;
  delete pDusoiDialog ;

  if (iExecReturn != IDOK)
    return ;

  iDusoiValue        = iDusoi ;
  iSymptomValue      = iSympt ;
  iComplicationValue = iCompl ;
  iPrognosisValue    = iProgn ;
  iTreatabilityValue = iTreat ;

  bDusoiWasCalculated = true ;

  iSeverity = iDusoiValue ;
  pGravite->SetPosition(iSeverity) ;
  UpdateSeverity(iSeverity) ;
	// pGravGauge->SetValue(iSeverity) ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSNewConcernDlg::EvaluateDusoi : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
}
catch (...)
{
	erreur("Exception NSNewConcernDlg::EvaluateDusoi.",  standardError, 0) ;
}
}

void
NSNewConcernDlg::SetCocCodeVerbose()
{
  FindCocCode(true) ;
}

void
NSNewConcernDlg::SetCocCodeNoVerbose()
{
  FindCocCode(false) ;
}

void
NSNewConcernDlg::FindCocCode(bool bVerbose)
{
try
{
  string sClassif  = string("6CISP") ;
  string sPostCase = string("0SOA41") ;

  string sHealthConcern = pType->getCode() ;
  if (string("") == sHealthConcern)
    return ;

  string sConcept ;
  pContexte->getDico()->donneCodeSens(&sHealthConcern, &sConcept) ;

  string sResO = string("") ;
  string sResP = string("") ;
  string sResI = string("") ;
  string sRes3 = string("") ;

/*
  if (sConcept == string("�??"))
  {
  	string sLibelle  = pType->sTexteGlobal ;
    string sLocalize = pNSTreeNode->getPosition() ;

    ParseSOAP Parser(pContexte, &sClassif) ;
    Parser.computeParsing(&sLibelle, &sLocalize, &sResO, &sResP, &sResI, &sRes3) ;
  }
  else
  {
*/
  	Classify ClassifTool(pContexte, &sClassif, &sConcept, &sPostCase) ;
  	ClassifTool.computeParsing(&sResO, &sResP, &sResI) ;
//  }

  //
  // On trouve le code
  //
  NSEpisodus* pEpisodus = pContexte->getSuperviseur()->getEpisodus() ;

  classifExpert* pExpert = pEpisodus->pClassifExpert ;
  if (NULL == pExpert)
    return ;

  NSEpiClassifInfoArray arrayClassif ;

  ElemSetArray* pElemDomain = 0 ;
  //
  // On instancie le domaine
  // Instanciating the domain
  //
  string sDomain  = sResP ;
  ParseCategory Parser(pExpert->donneCodeSize(sClassif), sClassif,
                                             pExpert->donnePattern(sClassif)) ;
  pElemDomain = Parser.DefDomain(sDomain) ;
  //
  // On trouve les codes qui correspondent au domaine
  // Finding the codes that belong to the domain
  //
  string sCaseSens ;
  pContexte->getDico()->donneCodeSens(&sPostCase, &sCaseSens) ;

  pExpert->fillList(sClassif, pElemDomain, &arrayClassif, sCaseSens) ;

  if (pElemDomain)
    delete pElemDomain ;

  int      iBuffLen = pType->GetTextLen() ;
  char far *szBuff  = new char[iBuffLen + 1] ;
  pType->GetText(szBuff, iBuffLen + 1) ;

  string sLabel = string(szBuff) ;

  string sGoodCode = "" ;
  //
  //
  //
  if (arrayClassif.size() != 1)
  {
    if (bVerbose)
    {
  	  SOAPObject SOAPObj(sLabel, sResP, sClassif, 0, string("")) ;
#ifndef _EXT_CAPTURE
		  NSCapture Capture(pContexte) ;
#else
		  NSCapture Capture ;
#endif

		  Capture.sClassifResultO = sResO ;
      Capture.sClassifResultP = sResP ;
      Capture.sClassifResultI = sResI ;
      Capture.sClassifResult3 = sRes3 ;

      SOAPObj.pCaptElemnt = &Capture ;
      SOAPObj.sCase       = sCaseSens ;

      sGoodCode = pExpert->chooseCode(&SOAPObj) ;
    }
  }
  else
  {
  	sGoodCode = (*(arrayClassif.begin()))->pDonnees->code ;

    string sCtrlData = "" ;
    NVLdVTemps tpsDebut ;
    tpsDebut.takeTime() ;
    pExpert->setControlString(&sCtrlData, sClassif, sCaseSens, sLabel,
                                  classifExpert::niveauPreselection, 0,
                                  &tpsDebut, &tpsDebut, sGoodCode, sConcept) ;
    pExpert->storeControlData(sCtrlData) ;
  }

  if (string("") == sGoodCode)
  {
    *psCocCode = string("") ;
    string sText = pContexte->getSuperviseur()->getText("healthConcernDialog", "continuityOfCareCode") ;
    pCocButton->SetCaption(sText.c_str()) ;
  	return ;
  }

  *psCocCode = sGoodCode ;

  NSEpiClassifDB   dbClassif(pContexte) ;
  NSEpiClassifInfo classifInfo ;
  bool bFoundCode = dbClassif.searchCode(sClassif, sGoodCode, &classifInfo) ;

  string sCaption = sGoodCode ;
  if (bFoundCode)
    sCaption += string(" - ") + classifInfo.getLibelle() ;

  pCocButton->SetCaption(sCaption.c_str()) ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSNewConcernDlg::FindCocCode : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
}
catch (...)
{
	erreur("Exception NSNewConcernDlg::FindCocCode.",  standardError, 0) ;
}
}

// -----------------------------------------------------------------
//
//  M�thodes de NSSimpleNewDrugDlg
//
// -----------------------------------------------------------------
// -----------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSSimpleNewDrugDlg, NSUtilDialog)
  EV_COMMAND(IDOK,                     CmOk),
  EV_COMMAND(IDCANCEL,                 CmCancel),
  EV_COMMAND_AND_ID(IDR_DRG_CHRONIQUE, UserName),
  EV_COMMAND_AND_ID(IDR_DRG_DANS,      UserName),
  EV_COMMAND_AND_ID(IDR_DRG_DUREE,     UserName),
  EV_COMMAND_AND_ID(IDR_DRG_LE,        UserName),
  EV_COMMAND(DRUG_COMPLEX_MODE,        switchToComplexMode),
  EV_COMMAND(FREE_TEXT_BUTTON,         editFreeText),
END_RESPONSE_TABLE;

NSSimpleNewDrugDlg::NSSimpleNewDrugDlg(TWindow* pView, NSContexte *pCtx, NSPatPathoArray *pPPTinit)
                   :NSUtilDialog(pView, pCtx, "NEW_DRUG")
{
try
{
	_sLexiqCode     = string("") ;
	_sPriseUnit     = string("") ;
	_sDateOuverture = string("") ;
	_sDateFermeture = string("") ;
  _sReferential   = string("") ;

  _pPhase = 0 ;

  // Creating interface elements
  //
  createInterfaceElements() ;

  pPPT = pPPTinit ;

  bMustSwitchToComplexMode = false ;
}
catch (...)
{
	erreur("Exception NSSimpleNewDrugDlg ctor.",  standardError, 0) ;
}
}

void
NSSimpleNewDrugDlg::createInterfaceElements()
{
	pTrtGroup      = new OWL::TGroupBox(this, TRT_GROUP) ;

	pType          = new NSUtilLexique(pContexte, this, DRUG_EDIT, pContexte->getSuperviseur()->getDico()) ;
  pType->setLostFocusFunctor(new MemFunctor<NSSimpleNewDrugDlg>( (NSSimpleNewDrugDlg*)this, &NSSimpleNewDrugDlg::ExecutedAfterDrugSelection )) ;
  
	pUnitePriseTxt = new OWL::TStatic(this, DRG_UNIT_TXT) ;
	pUnitePrise    = new NSUtilLexique(pContexte, this, DRG_UNIT, pContexte->getSuperviseur()->getDico()) ;

  _pALD            = new OWL::TCheckBox(this, ALD_BUTTON) ;
  _pFreeTextButton = new OWL::TButton(this, FREE_TEXT_BUTTON) ;

	pDateDebTxt    = new OWL::TStatic(this, DATE_DEBPRESC_TEXT) ;
	pDateDeb       = new NSUtilEditDateHeure(pContexte, this, DRUG_DATE_DEB) ;
  pDateDeb->setLostFocusFunctor(new MemFunctor<NSSimpleNewDrugDlg>( (NSSimpleNewDrugDlg*)this, &NSSimpleNewDrugDlg::ExecutedAfterTrtBeginDate )) ;
  pDateFinGroup  = new OWL::TGroupBox(this, DATE_FIN_DRG_GROUP) ;
	pRChronique    = new OWL::TRadioButton(this, IDR_DRG_CHRONIQUE) ;
	pRDans         = new OWL::TRadioButton(this, IDR_DRG_DANS) ;
	pRDuree        = new OWL::TRadioButton(this, IDR_DRG_DUREE) ;
	pRLe           = new OWL::TRadioButton(this, IDR_DRG_LE) ;
	pNbJours       = new NSEditNum(pContexte, this, IDC_DRG_NBJOURS, 10) ;
  pNbJours->setLostFocusFunctor(new MemFunctor<NSSimpleNewDrugDlg>( (NSSimpleNewDrugDlg*)this, &NSSimpleNewDrugDlg::ExecutedAfterTrtEndDate ));
  char *temp1[] = {"2HEUR1","2DAT01","2DAT11","2DAT21"} ;
  pCBDureeTtt    = new NSComboBox(this, IDC_DRG_NBJOURS_TXT, pContexte, temp1) ;
  pCBDureeTtt->SetLostFocusResponse(new MemFunctor<NSSimpleNewDrugDlg>( (NSSimpleNewDrugDlg*)this, &NSSimpleNewDrugDlg::ExecutedAfterTrtEndDate ));
	pDateFin       = new NSUtilEditDateHeure(pContexte, this, DRUG_DATE_FIN) ;

	pPrescriptionGroup = new OWL::TGroupBox(this, PRESCR_GROUP) ;

	pDureePhaseTxt         = new OWL::TStatic(this, PRESCR_DURA_TXT) ;
	pDureePhase            = new NSUpDownEdit(this, pContexte, "", PRESCR_DURA, PRESCR_DURA_UPDN) ;
  pDureePhase->getEditNum()->SetLostFocusResponse(new MemFunctor<NSSimpleNewDrugDlg>( (NSSimpleNewDrugDlg*)this, &NSSimpleNewDrugDlg::ActualisePhase )) ;
  pDureePhase->getUpDown()->SetLostFocusResponse(new MemFunctor<NSSimpleNewDrugDlg>( (NSSimpleNewDrugDlg*)this, &NSSimpleNewDrugDlg::ActualisePhase )) ;

  char *temp[] = {"2HEUR1","2DAT01","2DAT11","2DAT21"} ;
  pCBDureePhase          = new NSComboBox(this, PRESCR_DURA_UNIT, pContexte, temp) ;
  pCBDureePhase->SetLostFocusResponse(new MemFunctor<NSSimpleNewDrugDlg>( (NSSimpleNewDrugDlg*)this, &NSSimpleNewDrugDlg::ActualisePhase ));
	pRenouvellementTxt     = new OWL::TStatic(this, PRESCR_RENEW_TXT) ;
	pRenouvellement        = new NSUpDownEdit(this, pContexte, "", PRESCR_RENEW, PRESCR_RENEW_UPDN) ;

	pRenouvellementTimeTxt = new OWL::TStatic(this, PRESCR_RENEW_NBTXT) ;

	pDateDebPrescrTxt      = new OWL::TStatic(this, DATE_DEB_DRG_TEXT) ;
	pDateDebPrescr         = new NSUtilEditDateHeure(pContexte, this, PRESC_DATE_DEB) ;
	pDateFinPrescrTxt      = new OWL::TStatic(this, DATE_FINPRESC_TEXT) ;
	pDateFinPrescr         = new NSUtilEditDateHeure(pContexte, this, PRESC_DATE_FIN) ;

  pPosologieGroup        = new OWL::TGroupBox(this, POSO_GROUP) ;

	pPriseMatin            = new NSUpDownEdit(this, pContexte, "", POSO_MORNING, POSO_MORNING_UPDN) ;
  pPriseMidi             = new NSUpDownEdit(this, pContexte, "", POSO_NOON,    POSO_NOON_UPDN) ;
  pPriseSoir             = new NSUpDownEdit(this, pContexte, "", POSO_NIGHT,   POSO_NIGHT_UPDN) ;
  pPriseCoucher          = new NSUpDownEdit(this, pContexte, "", POSO_BED,     POSO_BED_UPDN) ;

	pPriseMatinTxt         = new OWL::TStatic(this, POSO_MORNING_TXT) ;
  pPriseMidiTxt          = new OWL::TStatic(this, POSO_NOON_TXT) ;
  pPriseSoirTxt          = new OWL::TStatic(this, POSO_NIGHT_TXT) ;
  pPriseCoucherTxt       = new OWL::TStatic(this, POSO_BED_TXT) ;

	pComplexModeButton     = new OWL::TButton(this, DRUG_COMPLEX_MODE) ;
}

NSSimpleNewDrugDlg::~NSSimpleNewDrugDlg()
{
  delete pTrtGroup ;

	delete pType ;
	delete pUnitePriseTxt ;
	delete pUnitePrise ;

	delete pDateDebTxt ;
	delete pDateDeb ;
  delete pDateFinGroup ;
	delete pRChronique ;
	delete pRDans ;
	delete pRDuree ;
	delete pRLe ;
	delete pNbJours ;
	delete pCBDureeTtt ;
	delete pDateFin ;

	delete pPrescriptionGroup ;

	delete pDureePhaseTxt ;
	delete pDureePhase ;
  delete pCBDureePhase ;
	delete pRenouvellementTxt ;
	delete pRenouvellement ;
	delete pRenouvellementTimeTxt ;

	delete pDateDebPrescrTxt ;
	delete pDateDebPrescr ;
	delete pDateFinPrescrTxt ;
	delete pDateFinPrescr ;

  delete pPosologieGroup ;

	delete pPriseMatin ;
  delete pPriseMidi ;
  delete pPriseSoir ;
  delete pPriseCoucher ;

	delete pPriseMatinTxt ;
  delete pPriseMidiTxt ;
  delete pPriseSoirTxt ;
  delete pPriseCoucherTxt ;

  delete pComplexModeButton ;
}

void
NSSimpleNewDrugDlg::SetupWindow()
{
	TDialog::SetupWindow() ;

  initInterfaceElements() ;

	// NVLdVTemps tpsNow ;
	// tpsNow.takeTime() ;

	// pDateDeb->setDate(tpsNow.donneDateHeure()) ;
	// pDateDebPrescr->setDate(tpsNow.donneDateHeure()) ;

	// pRChronique->SetCheck(BF_CHECKED) ;
	// pDateFin->SetReadOnly(true) ;
	// pNbJours->SetReadOnly(true) ;
  //pCBDureeTtt->SetReadOnly(true) ;
}

void
NSSimpleNewDrugDlg::initInterfaceElements()
{
	// Init static texts
  //
	string sTxt = pContexte->getSuperviseur()->getText("drugDialog", "newDrug") ;
  SetCaption(sTxt.c_str()) ;

  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "treatment") ;
	pTrtGroup->SetCaption(sTxt.c_str()) ;

	sTxt = pContexte->getSuperviseur()->getText("drugDialog", "takeUnit") ;
	pUnitePriseTxt->SetText(sTxt.c_str()) ;

  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "startingDate") ;
	pDateDebTxt->SetText(sTxt.c_str()) ;
  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "endingDate") ;
  pDateFinGroup->SetCaption(sTxt.c_str()) ;
  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "undetermined") ;
	pRChronique->SetCaption(sTxt.c_str()) ;
  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "fromNow") ;
	pRDans->SetCaption(sTxt.c_str()) ;
  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "totalDuration") ;
	pRDuree->SetCaption(sTxt.c_str()) ;
  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "onThe") ;
	pRLe->SetCaption(sTxt.c_str()) ;

	sTxt = pContexte->getSuperviseur()->getText("drugDialog", "prescription") ;
	pPrescriptionGroup->SetCaption(sTxt.c_str()) ;

	sTxt = pContexte->getSuperviseur()->getText("drugDialog", "during") ;
	pDureePhaseTxt->SetText(sTxt.c_str()) ;
  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "mayBeRenewed") ;
	pRenouvellementTxt->SetText(sTxt.c_str()) ;
  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "time") ;
	pRenouvellementTimeTxt->SetText(sTxt.c_str()) ;

	sTxt = pContexte->getSuperviseur()->getText("drugDialog", "from") ;
	pDateDebPrescrTxt->SetText(sTxt.c_str()) ;
	sTxt = pContexte->getSuperviseur()->getText("drugDialog", "to") ;
	pDateFinPrescrTxt->SetText(sTxt.c_str()) ;

	sTxt = pContexte->getSuperviseur()->getText("drugDialog", "posology") ;
  pPosologieGroup->SetCaption(sTxt.c_str()) ;

  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "morning") ;
	pPriseMatinTxt->SetText(sTxt.c_str()) ;
  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "noon") ;
  pPriseMidiTxt->SetText(sTxt.c_str()) ;
  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "evening") ;
  pPriseSoirTxt->SetText(sTxt.c_str()) ;
  sTxt = pContexte->getSuperviseur()->getText("drugDialog", "bedtime") ;
  pPriseCoucherTxt->SetText(sTxt.c_str()) ;

  string sLang = pContexte->getUtilisateur()->donneLang() ;

  // Init contents
  //
  std::string sForme = "" ;
  std::string sLabel = "" ;

  if (string("") != _sLexiqCode)
  {
		pContexte->getDico()->donneLibelle(sLang, &_sLexiqCode, &sLabel) ;
    pType->setLabel(_sLexiqCode.c_str(), sLabel.c_str()) ;
    sForme = initDispUnit(sLang, _sLexiqCode, sLabel, pContexte) ;
  }
  else
    pType->SetText("") ;

  if (string("") != _sPriseUnit)
    pUnitePrise->setLabel(_sPriseUnit) ;
  else
  {
  	string sMsgTxt = pContexte->getSuperviseur()->getText("drugDialog", "missingInformation") ;
    pUnitePrise->SetText(sMsgTxt.c_str()) ;
    if ((string("") != sForme) && (sForme != sMsgTxt))
			pUnitePrise->setLabel(sForme) ;
		else
			pUnitePrise->SetText(sMsgTxt.c_str()) ;
  }

  if (string("") != _sALD)
  	_pALD->SetCheck(BF_CHECKED) ;
  else
    _pALD->SetCheck(BF_UNCHECKED) ;

  NVLdVTemps tpNow ;
	tpNow.takeTime() ;

  if (string("") != _sDateOuverture)
		pDateDeb->setDate(_sDateOuverture) ;
  else
		pDateDeb->setDate(tpNow.donneDateHeure()) ;

  if (string("") != _sDateFermeture)
  {
  	pRLe->SetCheck(BF_CHECKED) ;
  	pDateFin->setDate(_sDateFermeture) ;
  }
  else
  {
  	pRChronique->SetCheck(BF_CHECKED) ;
    pDateFin->SetReadOnly(true) ;
  }
  pNbJours->SetReadOnly(true) ;

  if (NULL == _pPhase)
  {
  	pDateDebPrescr->setDate(tpNow.donneDateHeure()) ;
		return ;
	}

	pDureePhase->initControle(_pPhase->GetDureePhase()) ;
	pCBDureePhase->setCode(_pPhase->GetSymBolOfPhase()) ;
	pRenouvellement->initControle(_pPhase->GetNumberOfRenouvellement()) ;
  pDateDebPrescr->setDate(_pPhase->GetStartingDate().donneDateHeure()) ;
  pDateFinPrescr->setDate(_pPhase->GetClosingDate().donneDateHeure()) ;

  std::vector<NSMedicCycleGlobal*>* pCycles = _pPhase->getCycles() ;

  if ((NULL == pCycles) || pCycles->empty())
		return ;

	NSMedicCycleGlobal* pCurrentCycle = *(pCycles->begin()) ;
  NSCircadien* pCirc = pCurrentCycle->GetCycleCircadien() ;
  if ((NULL == pCirc) || (pCirc->getType() != MMS))
		return ;

	// unfortunately not possible : pCirc->Load() ;

  BaseCirc* pCircData = pCirc->getData() ;
  if (NULL == pCircData)
		return ;

	CircBaseMMS* pMMSData = dynamic_cast<CircBaseMMS*>(pCircData) ;
  if (NULL == pMMSData)
		return ;

  pPriseMatin->getEditNum()->setText(pMMSData->getMatin()) ;
	pPriseMidi->getEditNum()->setText(pMMSData->getMidi()) ;
	pPriseSoir->getEditNum()->setText(pMMSData->getSoir()) ;
	pPriseCoucher->getEditNum()->setText(pMMSData->getCoucher()) ;
}

void
NSSimpleNewDrugDlg::BuildPatpatho()
{
	pPPT->vider() ;

	// Insert root (drug name)
	//
	int iColonne = 0 ;
  std::string sMEdicName = pType->getCode() ;

  if (string("") == sMEdicName)
		return ;

  pPPT->ajoutePatho(sMEdicName, iColonne++) ;

  int iMedicRoot  = iColonne ;

  // Insert dates
  //
  string sDate ;

  pDateDeb->getDate(&sDate) ;
  if ((sDate != "") && (sDate != string("19000000000000")) &&	(sDate != string("00000000000000")))
	{
  	pPPT->ajoutePatho("KOUVR1", iColonne++) ;
  	Message CodeMsg ;
		CodeMsg.SetUnit("2DA021") ;
		CodeMsg.SetComplement(sDate) ;
		pPPT->ajoutePatho("�D0;19", &CodeMsg, iColonne++) ;
	}
	iColonne = iMedicRoot ;

	pDateFin->getDate(&sDate) ;
  if ((sDate != "") && (sDate != string("19000000000000")) &&	(sDate != string("00000000000000")))
	{
    pPPT->ajoutePatho("KFERM1", iColonne++) ;
    Message CodeMsg ;
		CodeMsg.SetUnit("2DA021") ;
		CodeMsg.SetComplement(sDate) ;
		pPPT->ajoutePatho("�D0;19", &CodeMsg, iColonne++) ;
	}
	iColonne = iMedicRoot ;

  std::string sTakeUnitCode = pUnitePrise->getCode() ;
	if (string("") != sTakeUnitCode)
  {
  	pPPT->ajoutePatho("0MEDF1", iColonne++) ;
    pPPT->ajoutePatho(sTakeUnitCode, iColonne++) ;
  }
  iColonne = iMedicRoot ;

  if (string("") != _sALD)
  {
    pPPT->ajoutePatho("LADMI1", iColonne++) ;
    pPPT->ajoutePatho("LBARZ1", iColonne++) ;
  }
  iColonne = iMedicRoot ;

	NSPatPathoArray phaseTree(pContexte) ;
  BuildPhaseTree(&phaseTree) ;

  if (!(phaseTree.empty()))
		pPPT->InserePatPatho(pPPT->end(), &phaseTree, iColonne) ;

  if (string("") != _sFreeText)
	{
    Message CodeMsg ;
		CodeMsg.SetTexteLibre(_sFreeText) ;
		pPPT->ajoutePatho("�C;020", &CodeMsg, iColonne) ;
	}
}

void
NSSimpleNewDrugDlg::BuildPhaseTree(NSPatPathoArray *pPptPhase)
{
	if (NULL == pPptPhase)
		return ;

	pPptPhase->vider() ;

	int iColonne = 0 ;
  int iColBasePhase = iColonne ;

  // Insert root ("phase")
	//
  pPptPhase->ajoutePatho("KPHAT1", iColonne) ;

  // Insert dates
  //
  string sDate ;
  iColonne = iColBasePhase + 1 ;

  pDateDebPrescr->getDate(&sDate) ;
  if ((sDate != "") && (sDate != string("19000000000000")) &&	(sDate != string("00000000000000")))
	{
  	pPptPhase->ajoutePatho("KOUVR1", iColonne++) ;
  	Message CodeMsg ;
		CodeMsg.SetUnit("2DA021") ;
		CodeMsg.SetComplement(sDate) ;
		pPptPhase->ajoutePatho("�D0;19", &CodeMsg, iColonne++) ;
	}
	iColonne = iColBasePhase + 1 ;

	pDateFinPrescr->getDate(&sDate) ;
  if ((sDate != "") && (sDate != string("19000000000000")) &&	(sDate != string("00000000000000")))
	{
    pPptPhase->ajoutePatho("KFERM1", iColonne++) ;
    Message CodeMsg ;
		CodeMsg.SetUnit("2DA021") ;
		CodeMsg.SetComplement(sDate) ;
		pPptPhase->ajoutePatho("�D0;19", &CodeMsg, iColonne++) ;
	}
	iColonne = iColBasePhase + 1 ;

  // traitement des param�tres de la phase
  // pendant
  int iPhaseDurationValue = pDureePhase->getValue() ;
	string sPhaseDurationUnit = pCBDureePhase->getSelCode() ;

  if ((iPhaseDurationValue > 0) && (string("") != sPhaseDurationUnit))
  {
  	pPptPhase->ajoutePatho("VDURE2", iColonne++) ;    // code pour pendant
    createNodeComplement(pPptPhase, "�N0;03", sPhaseDurationUnit, iPhaseDurationValue, iColonne) ;
	}
  iColonne = iColBasePhase + 1 ;

  int iRenewValue = pRenouvellement->getValue() ;

  if (iRenewValue > 0)
  {
  	pPptPhase->ajoutePatho("VRENO1", iColonne++) ;    // code pour � renouveler
    createNodeComplement(pPptPhase, "�N0;03", "200001", iRenewValue, iColonne) ;
	}
  iColonne = iColBasePhase + 1 ;

  // Cycle insertion
  //
  NSPatPathoArray cycleTree(pContexte) ;
  BuildCycleTree(&cycleTree) ;

  if (!(cycleTree.empty()))
  {
  	pPptPhase->ajoutePatho("KCYTR1", iColonne++) ;
		pPptPhase->InserePatPatho(pPptPhase->end(), &cycleTree, iColonne) ;
	}
}

void
NSSimpleNewDrugDlg::BuildCycleTree(NSPatPathoArray *pPptCycle)
{
	if (NULL == pPptCycle)
		return ;

	pPptCycle->vider() ;

  // Insert root ("cycle")
	//
	pPptCycle->ajoutePatho("KRYTH1", 0) ;

	std::string temp ;

  temp = pPriseMatin->getText() ;
  if (isValidValue(&temp))
		func_create_patho_quant("KMATI1", temp, pPptCycle, 1) ;

	temp = pPriseMidi->getText() ;
	if (isValidValue(&temp))
		func_create_patho_quant("KMIDI1", temp, pPptCycle, 1) ;

	temp = pPriseSoir->getText() ;
	if (isValidValue(&temp))
		func_create_patho_quant("KSOIR1", temp, pPptCycle, 1) ;

	temp = pPriseCoucher->getText() ;
	if (isValidValue(&temp))
		func_create_patho_quant("KCOUC1", temp, pPptCycle, 1) ;
}

bool
NSSimpleNewDrugDlg::ParseMedicament()
{
	if ((NULL == pPPT) || (true == pPPT->empty()))
		return true ;

	int phasesCount = 0 ;

  PatPathoIter pptIter = pPPT->begin() ;
	_sLexiqCode = (*pptIter)->getLexique() ; // Recuperation du nom  du medicament

  pptIter++ ;

  while (pPPT->end() != pptIter)
  {
    std::string temp = (*pptIter)->getLexiqueSens(pContexte) ;

    if (string("KOUVR") == temp)
    {
    	int iColBase = (*pptIter)->getColonne() ;

			pptIter++ ;
      if (pPPT->end() == pptIter)
      	return false ;

			if (((*pptIter)->getColonne() > iColBase)  &&
          (((*pptIter)->getUnitSens(pContexte) == "2DA02") ||
                     ((*pptIter)->getUnitSens(pContexte) == "2DA01")) &&
           ((*pptIter)->getLexiqueSens(pContexte) == "�D0"))
				_sDateOuverture = (*pptIter)->getComplement() ;
      else
      	return false ;

      pptIter++ ;
    }
    else if (string("KFERM") == temp)
    {
    	int iColBase = (*pptIter)->getColonne() ;

			pptIter++ ;
      if (pPPT->end() == pptIter)
      	return false ;

			if (((*pptIter)->getColonne() > iColBase)  &&
          (((*pptIter)->getUnitSens(pContexte) == "2DA02") ||
                     ((*pptIter)->getUnitSens(pContexte) == "2DA01")) &&
           ((*pptIter)->getLexiqueSens(pContexte) == "�D0"))
				_sDateFermeture = (*pptIter)->getComplement() ;
      else
      	return false ;

    	pptIter++ ;
    }
    else if (string("0MEDF") == temp)
		{
			int iColBase = (*pptIter)->getColonne() ;

			pptIter++ ;
      if (pPPT->end() == pptIter)
      	return false ;

      if ((*pptIter)->getColonne() > iColBase)
				_sPriseUnit = (*pptIter)->getLexique() ;

			pptIter++ ;
    }
    else if (string("KPHAT") == temp) // Charge une phase
    {
    	// This interface element can only manage single phase treatments
      //
    	phasesCount++ ;
      if (phasesCount > 1)
      	return false ;

    	_pPhase = new NSphaseMedic(pContexte) ;
      if (false == ParsePhase(pptIter))
      	return false ;
    }
    else if ("�RE" == temp) // Proposition Id
    {
      _sReferential = (*pptIter)->getComplement() ;
      pptIter++ ;
    }
    else if ("�C;" == temp)
    {
      _sFreeText = (*pptIter)->getTexteLibre() ;
      pptIter++ ;
    }
    else if ("LADMI" == temp)
    {
      int iColBaseAdmin = (*pptIter)->getColonne() ;
      pptIter++ ;
      while ((pPPT->end() != pptIter) && ((*pptIter)->getColonne() > iColBaseAdmin))
      {
        std::string tempAdm = (*pptIter)->getLexiqueSens(pContexte) ;
        if ("LBARZ" == tempAdm)
        {
          _sALD = "LBARZ" ;
          pptIter++ ;
        }
        else
          return false ;
      }
    }
    else
    	return false ;
  }
  return true ;
}

bool
NSSimpleNewDrugDlg::ParsePhase(PatPathoIter &pptIter)
{
	if (NULL == _pPhase)
		return false ;

	if (pPPT->end() == pptIter)
		return true ;

	int iColBase = (*pptIter)->getColonne() ;

  pptIter++ ;
	if (pPPT->end() == pptIter)
		return false ;

	int cyclesCount = 0 ;

	while ((pPPT->end() != pptIter) && ((*pptIter)->getColonne() > iColBase))
  {
  	string temp = (*pptIter)->getLexiqueSens(pContexte) ;

  	if (string("KOUVR") == temp)
    {
    	int iColLevel = (*pptIter)->getColonne() ;

			pptIter++ ;
      if (pPPT->end() == pptIter)
      	return false ;

			if (((*pptIter)->getColonne() > iColLevel)  &&
          (((*pptIter)->getUnitSens(pContexte) == "2DA02") ||
                     ((*pptIter)->getUnitSens(pContexte) == "2DA01")) &&
           ((*pptIter)->getLexiqueSens(pContexte) == "�D0"))
      	_pPhase->setStartingDate((*pptIter)->getComplement()) ;
      else
      	return false ;

      pptIter++ ;
    }
		else if (string("KFERM") == temp)
    {
    	int iColLevel = (*pptIter)->getColonne() ;

			pptIter++ ;
      if (pPPT->end() == pptIter)
      	return false ;

			if (((*pptIter)->getColonne() > iColLevel)  &&
          (((*pptIter)->getUnitSens(pContexte) == "2DA02") ||
                     ((*pptIter)->getUnitSens(pContexte) == "2DA01")) &&
           ((*pptIter)->getLexiqueSens(pContexte) == "�D0"))
      	_pPhase->setClosingDate((*pptIter)->getComplement()) ;
      else
      	return false ;

      pptIter++ ;
    }
    else if (string("VDURE") == temp)
    {
    	int iColLevel = (*pptIter)->getColonne() ;

			pptIter++ ;
      if (pPPT->end() == pptIter)
      	return false ;

			if ((*pptIter)->getColonne() > iColLevel)
      {
      	_pPhase->setSymBolOfPhase((*pptIter)->getUnit()) ;
				_pPhase->setDureePhase(atoi(((*pptIter)->getComplement()).c_str())) ;
      }
      else
      	return false ;

      pptIter++ ;
    }
    else if (string("VRENO") == temp)
    {
    	int iColLevel = (*pptIter)->getColonne() ;

			pptIter++ ;
      if (pPPT->end() == pptIter)
      	return false ;

			if ((*pptIter)->getColonne() > iColLevel)
				_pPhase->setNumberOfRenouvellement(atoi(((*pptIter)->getComplement()).c_str())) ;
      else
      	return false ;

      pptIter++ ;
    }
    else if (string("KCYTR") == temp)
    {
    	cyclesCount++ ;
      if (cyclesCount > 1)
    		return false ;

      NSMedicCycleGlobal* cycle = new NSMedicCycleGlobal(pContexte, _pPhase) ;
      PatPathoIter pptEnd = pPPT->end() ;
      cycle->Load(pptIter, pptEnd) ;

      // Check that there is only circadian information
      //
      NSRythme* pRythme = cycle->GetRythme() ;
      if ((NULL != pRythme) && (NULL != pRythme->getData()))
      	return false ;

      NSCircadien* pCirc = cycle->GetCycleCircadien() ;
      if ((NULL != pCirc) && (pCirc->getType() != MMS) &&
                             (pCirc->getType() != UndefinedCircadien))
      	return false ;

      _pPhase->getCycles()->push_back(cycle) ;
    }
    else
    	return false ;
	}
  return true ;
}

void
NSSimpleNewDrugDlg::ExecutedAfterDrugSelection()
{
	string sLexiqCode = pType->getCode() ;

  if (string("") == sLexiqCode)
		return ;

	string sLabel ;
	string sLang = pContexte->getUtilisateur()->donneLang() ;
	pContexte->getDico()->donneLibelle(sLang, &sLexiqCode, &sLabel) ;

	string sMITxt = pContexte->getSuperviseur()->getText("drugDialog", "missingInformation") ;

	string sCodeDisp = initDispUnit(sLang, sLexiqCode, sLabel, pContexte) ;
	if (sCodeDisp != sMITxt) // Verifie que le code exite
		pUnitePrise->setLabel(sCodeDisp) ;
	else
		pUnitePrise->SetText(sCodeDisp.c_str()) ;

	// initPosoAndCycleForDrug() ;
}

void
NSSimpleNewDrugDlg::ExecutedAfterTrtBeginDate()
{
	std::string dateDeb ;
  pDateDeb->getDate(&dateDeb) ;
  NVLdVTemps data ;
  data.initFromDate(dateDeb) ;

  std::string date ;
  pDateDebPrescr->getDate(&date) ;
  NVLdVTemps dataPrescr ;
  dataPrescr.initFromDate(date) ;

	NVLdVTemps tpsNow ;
	tpsNow.takeTime() ;

  if (data >= tpsNow)
	{
		pDateDebPrescr->setDate(data.donneDateHeure()) ;
    ActualiseEndOfPrescription() ;
	}
}

void
NSSimpleNewDrugDlg::ExecutedAfterTrtEndDate()
{
	pNbJours->donneValeur() ;
	int iTrtDurationValue = (int) pNbJours->dValeur ;
	if (iTrtDurationValue <= 0)
		return ;

	string sTrtDurationUnit = pCBDureeTtt->getSelCode() ;
	if (string("") == sTrtDurationUnit)
		return ;

	NVLdVTemps tDateFin ;

  std::string sDateDeb ;
	pDateDeb->getDate(&sDateDeb) ;

	// si on dans le cas o� "dans" est coch�e
  if (pRDans->GetCheck() == BF_CHECKED)
    tDateFin.takeTime() ;

  // si on est dans le cas o� "dur�e" est coch�e
  else if (pRDuree->GetCheck() == BF_CHECKED)
    tDateFin.initFromDate(sDateDeb) ;

  else
  	return ;

	tDateFin.ajouteTemps(iTrtDurationValue, sTrtDurationUnit, pContexte) ;
	string sDateFin = tDateFin.donneDateHeure() ;

  pDateFin->setDate(sDateFin) ;
  pDateFinPrescr->setDate(sDateFin) ;

  std::string dateDebPresc ;
  pDateDebPrescr->getDate(&dateDebPresc) ;

  // si on dans le cas o� "dans" est coch�e, on remplit la dur�e de prescription
  if ((pRDans->GetCheck() == BF_CHECKED) ||
      ((pRDuree->GetCheck() == BF_CHECKED) && (dateDebPresc == sDateDeb)))
	{
		pDureePhase->setValue(iTrtDurationValue) ;
    pCBDureePhase->setCode(sTrtDurationUnit) ;
    ActualiseEndOfPrescription() ;
  }
}

void
NSSimpleNewDrugDlg::ActualisePhase()
{
	ActualiseEndOfPrescription() ;
}

void
NSSimpleNewDrugDlg::ActualiseEndOfPrescription()
{
	int iPhaseDurationValue = pDureePhase->getValue() ;
	if (iPhaseDurationValue <= 0)
		return ;

	string sPhaseDurationUnit = pCBDureePhase->getSelCode() ;
	if (string("") == sPhaseDurationUnit)
		return ;

	std::string date ;
  pDateDebPrescr->getDate(&date) ;
  NVLdVTemps data ;
  data.initFromDate(date) ;

  data.ajouteTemps(iPhaseDurationValue, sPhaseDurationUnit, pContexte) ;

  date = data.donneDateHeure() ;
  pDateFinPrescr->setDate(date) ;
}

void
NSSimpleNewDrugDlg::UserName(WPARAM wParam)
{
  switch (wParam)
  {
    case (IDR_DRG_CHRONIQUE) :
    	pDateFin->SetReadOnly(true) ;
      pNbJours->SetReadOnly(true) ;
      //pCBDureeTtt->SetReadOnly(true) ;
      break ;
    case (IDR_DRG_DANS) :
    	pDateFin->SetReadOnly(true) ;
      pNbJours->SetReadOnly(false) ;
      //pCBDureeTtt->SetReadOnly(false) ;
      pNbJours->SetFocus() ;
      break ;
    case (IDR_DRG_DUREE) :
    	pDateFin->SetReadOnly(true) ;
      pNbJours->SetReadOnly(false) ;
      //pCBDureeTtt->SetReadOnly(false) ;
      pNbJours->SetFocus() ;
      break ;
    case (IDR_DRG_LE) :
    	pNbJours->SetReadOnly(true) ;
      //pCBDureeTtt->SetReadOnly(true) ;
      pDateFin->SetReadOnly(false) ;
      pDateFin->SetFocus() ;
      break ;
  }
}

void
NSSimpleNewDrugDlg::editFreeText()
{
  string sFreeText = _sFreeText ;

  NSFreeTextDlg* pFreeTextDlg = new NSFreeTextDlg(this, pContexte, &sFreeText) ;
  int iExecReturn = pFreeTextDlg->Execute() ;
  delete pFreeTextDlg ;

  if (iExecReturn != IDOK)
    return ;

  _sFreeText = sFreeText ;
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
void
NSSimpleNewDrugDlg::CmOk()
{
try
{
  // on r�cup�re d'abord un �ventuel �l�ment lexique s�lectionn� par les fl�ches
  // Le Return n'envoie pas d'EvKeyDown et appelle directement CmOk
  if (pType->pDico->pDicoDialog->EstOuvert())
    pType->pDico->pDicoDialog->InsererElementLexique() ;

	if (pUnitePrise->pDico->pDicoDialog->EstOuvert())
    pUnitePrise->pDico->pDicoDialog->InsererElementLexique() ;

  string sTL = "" ;

  // Ne pas accepter les textes libres
  if (string("�?????") == pType->sCode)
  {
    if (!(pContexte->getSuperviseur()->getEpisodus()->bAllowFreeTextLdV))
    {
    	string sErrorTxt = pContexte->getSuperviseur()->getText("drugDialogErrors", "freeTextNotAllowedForTreatment") ;
      erreur(sErrorTxt.c_str(), standardError, 0, GetHandle()) ;
      pType->SetFocus() ;
      return ;
    }
  }

	if (string("�?????") == pUnitePrise->sCode)
  {
    string sLabel = pUnitePrise->getLabel() ;
    NSPatPathoArray pptTest(pContexte) ;
    BuildCycleTree(&pptTest) ;
    if ((string("") != sLabel) || (false == pptTest.empty()))
    {
  	  string sErrorTxt = pContexte->getSuperviseur()->getText("drugDialogErrors", "freeTextNotAllowedForPrescriptionUnit") ;
      erreur(sErrorTxt.c_str(), standardError, 0, GetHandle()) ;
      pUnitePrise->SetFocus() ;
    }
    return ;
  }

  if (_pALD->GetCheck() == BF_CHECKED)
    _sALD = string("LBARZ1") ;

  // On v�rifie qu'un edit n'�tait pas en cours de saisie
  // Le Return n'envoie pas de KillFocus et appelle directement CmOk
  //
  killControlFocusOnReturnClose() ;

  BuildPatpatho() ;

	CloseWindow(IDOK) ;
}
catch (...)
{
  erreur("Exception NSSimpleNewDrugDlg::CmOk.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
void
NSSimpleNewDrugDlg::CmCancel()
{
	Destroy(IDCANCEL) ;
}

void
NSSimpleNewDrugDlg::switchToComplexMode()
{
	bMustSwitchToComplexMode = true ;

  BuildPatpatho() ;

	CloseWindow(IDOK) ;
}

// -----------------------------------------------------------------
//
//  M�thodes de NSModifConcernTypeDlg
//
// -----------------------------------------------------------------
// -----------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSModifConcernTypeDlg, NSUtilDialog)
    EV_COMMAND(IDOK,        CmOk),
    EV_COMMAND(IDCANCEL,    CmCancel),
END_RESPONSE_TABLE;

NSModifConcernTypeDlg::NSModifConcernTypeDlg(NSPatPathoInfo* pNode, NSContexte* pCtx)
                      :NSUtilDialog(0, pCtx, "MODIF_PREO_TYPE")
{
try
{
	pNoeud = pNode ;
	pType  = new NSUtilLexique(pContexte, this, PREOCCUP_EDIT, pContexte->getDico()) ;
}
catch (...)
{
	erreur("Exception NSModifConcernTypeDlg ctor.", standardError, 0) ;
}
}

NSModifConcernTypeDlg::~NSModifConcernTypeDlg()
{
	delete pType ;
}

void
NSModifConcernTypeDlg::SetupWindow()
{
	TDialog::SetupWindow();

	string sCodeLex = pNoeud->getLexique() ;

	if (sCodeLex != string("�?????"))
		pType->setLabel(sCodeLex) ;
	//
	// Texte libre - Free text
	//
	else
		pType->SetText(pNoeud->getTexteLibre().c_str()) ;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSModifConcernTypeDlg::CmOk()
{
try
{
  //
  // on r�cup�re d'abord un �ventuel �l�ment lexique s�lectionn� par les fl�ches
  // Le Return n'envoie pas d'EvKeyDown et appelle directement CmOk
  if (pType->pDico->pDicoDialog->EstOuvert())
  {
    pType->pDico->pDicoDialog->InsererElementLexique() ;
    return ;
  }
  //
  // Ne pas accepter les textes libres
  //
  if (pType->sCode == string("�?????"))
  {
        if (!(pContexte->getSuperviseur()->getEpisodus()->bAllowFreeTextLdV))
        {
            erreur("Il faut choisir un code lexique et non pas du texte libre ", standardError, 0, GetHandle());
            pType->SetFocus();
            return;
        }

        int iBuffLen = pType->GetTextLen();
	    char far* szBuff = new char[iBuffLen+1];
        pType->GetText(szBuff, iBuffLen+1);
        pNoeud->pDonnees->setTexteLibre(string(szBuff));
        delete[] szBuff;
    }
    else
        pNoeud->pDonnees->setTexteLibre("");

    strcpy(pNoeud->pDonnees->lexique, pType->sCode.c_str());
    strcpy(pNoeud->pDonnees->complement, "");

	CloseWindow(IDOK);
}
catch (...)
{
    erreur("Exception NSModifConcernTypeDlg::CmOk.",  standardError, 0) ;
}
}

void
NSModifConcernTypeDlg::CmCancel()
{
    Destroy(IDCANCEL);
}

// -----------------------------------------------------------------
//
//  M�thodes de NSModifConcernDateDlg
//
// -----------------------------------------------------------------
// -----------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSModifConcernDateDlg, NSUtilDialog)
    EV_COMMAND(IDOK,        CmOk),
    EV_COMMAND(IDCANCEL,    CmCancel),
    EV_COMMAND_AND_ID(IDR_CHRONIQUE, adminDates),
    EV_COMMAND_AND_ID(IDR_DANS,      adminDates),
    EV_COMMAND_AND_ID(IDR_DUREE,     adminDates),
    EV_COMMAND_AND_ID(IDR_LE,        adminDates),
END_RESPONSE_TABLE;

NSModifConcernDateDlg::NSModifConcernDateDlg(NVLdVTemps* pDeb, NVLdVTemps* pFin, NSContexte* pCtx)
                      :NSUtilDialog(0, pCtx, "MODIF_PREO_DATE")
{
try
{
    ptpsDeb     = pDeb;
    ptpsFin     = pFin;

    pDateDeb    = new NSUtilEditDateHeure(pContexte, this, PROB_DATE_DEB) ;
    pDateFin    = new NSUtilEditDateHeure(pContexte, this, PROB_DATE_FIN) ;
    pNbJours    = new NSEditNum(pContexte, this, IDC_NBJOURS, 10) ;
    pRChronique = new OWL::TRadioButton(this, IDR_CHRONIQUE) ;
    pRDans      = new OWL::TRadioButton(this, IDR_DANS) ;
    pRDuree     = new OWL::TRadioButton(this, IDR_DUREE) ;
    pRLe        = new OWL::TRadioButton(this, IDR_LE) ;
}
catch (...)
{
    erreur("Exception NSModifConcernDateDlg ctor.",  standardError, 0) ;
}
}

NSModifConcernDateDlg::~NSModifConcernDateDlg()
{
    delete pDateDeb;
    delete pDateFin;
    delete pNbJours;
    delete pRChronique;
    delete pRDans;
    delete pRDuree;
    delete pRLe;
}

void
NSModifConcernDateDlg::SetupWindow()
{
    NSUtilDialog::SetupWindow();

    string sDateDeb = ptpsDeb->donneDateHeure();
    pDateDeb->setDate(sDateDeb.c_str());

    if ((ptpsFin->estVide()) || (ptpsFin->estNoLimit()))
        pRChronique->SetCheck(BF_CHECKED) ;
    else
    {
        string sDateFin = ptpsFin->donneDateHeure();
        pDateFin->setDate(sDateFin) ;
        pRLe->SetCheck(BF_CHECKED) ;
    }

    pNbJours->SetText("0") ;

    pDateFin->SetReadOnly(false) ;
    pNbJours->SetReadOnly(true) ;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSModifConcernDateDlg::CmOk()
{
try
{
  // On v�rifie qu'un edit n'�tait pas en cours de saisie
  // Le Return n'envoie pas de KillFocus et appelle directement CmOk
  //
  killControlFocusOnReturnClose() ;

  string sDDeb;
  pDateDeb->getDate(&sDDeb);
  ptpsDeb->initFromDateHeure(sDDeb) ;

  string sDFin;

  // r�cup�ration de la valeur du champs edit correspondant au nombre de jours
  pNbJours->donneValeur() ;

  // si on est dans le cas o� "chronique" est coch�e
  if (pRChronique->GetCheck() == BF_CHECKED)
    ptpsFin->setNoLimit() ;

  // si on dans le cas o� "dans" est coch�e
  else if (pRDans->GetCheck() == BF_CHECKED)
  {
        if (pNbJours->dValeur < 1)
        {
            erreur("La pr�occupation doit durer au moins 1 jour.", standardError, 0, GetHandle());
            return;
        }
        ptpsFin->takeTime() ;
        ptpsFin->ajouteJours(pNbJours->dValeur) ;
    }

    // si on est dans le cas o� "dur�e" est coch�e
    else if (pRDuree->GetCheck() == BF_CHECKED)
    {
        if (pNbJours->dValeur < 1)
        {
            erreur("La pr�occupation doit durer au moins 1 jour.", standardError, 0, GetHandle());
            return;
        }
        ptpsFin->initFromDateHeure(sDDeb) ;
        ptpsFin->ajouteJours(pNbJours->dValeur) ;
    }

    // si on est dans le cas o� "le" est coch�e
    if (pRLe->GetCheck() == BF_CHECKED)
    {
        pDateFin->getDate(&sDFin) ;
        ptpsFin->initFromDateHeure(sDFin) ;
    }

	CloseWindow(IDOK);
}
catch (...)
{
    erreur("Exception NSModifConcernDateDlg::CmOk.",  standardError, 0) ;
}
}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
void
NSModifConcernDateDlg::CmCancel()
{
    Destroy(IDCANCEL);
}

void
NSModifConcernDateDlg::adminDates(WPARAM wParam)
{
    switch (wParam)
    {
        case (IDR_CHRONIQUE) :
            pDateFin->SetReadOnly(true) ;
            pNbJours->SetReadOnly(true) ;
            break ;
        case (IDR_DANS) :
            pDateFin->SetReadOnly(true) ;
            pNbJours->SetReadOnly(false) ;
            break ;
        case (IDR_DUREE) :
            pDateFin->SetReadOnly(true) ;
            pNbJours->SetReadOnly(false) ;
            break ;
        case (IDR_LE) :
            pNbJours->SetReadOnly(true) ;
            pDateFin->SetReadOnly(false) ;
            break ;
    }
}

// -----------------------------------------------------------------
//
//  M�thodes de NSModifConcernIndexDlg
//
// -----------------------------------------------------------------
// -----------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSModifConcernIndexDlg, NSUtilDialog)
    EV_COMMAND(IDOK,        CmOk),
    EV_COMMAND(IDCANCEL,    CmCancel),
    EV_CHILD_NOTIFY_ALL_CODES(IDC_GRAVITE,  UpdateSeverity),
    // EV_CHILD_NOTIFY_ALL_CODES(IDC_RISQUE,   UpdateRisk),
END_RESPONSE_TABLE;

NSModifConcernIndexDlg::NSModifConcernIndexDlg(int* pSev, NSContexte* pCtx)
                       :NSUtilDialog(0, pCtx, "MODIF_PREO_INDEX")
{
try
{
    piSeverite  = pSev;
    // piRisque    = pRisk;

    pGravite 	= new OWL::THSlider(this, IDC_GRAVITE);
    // pRisque 	= new OWL::THSlider(this, IDC_RISQUE);

    pGravGauge  = new OWL::TGauge(this, "%d%%", IDC_PROGRESSGRAV, 24, 45, 215, 20);
    pGravGauge->SetRange(0, 100);
    pGravGauge->SetNativeUse(nuNever);

    // pRiskGauge  = new OWL::TGauge(this, "%d%%", IDC_PROGRESSRISK, 24, 78, 215, 20);
    // pRiskGauge->SetNativeUse(nuNever);
}
catch (...)
{
    erreur("Exception NSModifConcernIndexDlg ctor.",  standardError, 0) ;
}
}

NSModifConcernIndexDlg::~NSModifConcernIndexDlg()
{
    delete pGravite;
    // delete pRisque;
    delete pGravGauge;
    // delete pRiskGauge;
}

void
NSModifConcernIndexDlg::SetupWindow()
{
    TDialog::SetupWindow();

    pGravite->SetRange(0, 100);   //fixer min et max
    pGravite->SetRuler(5, false); //espacement entre deux graduations
    pGravite->SetPosition(*piSeverite);
    pGravGauge->SetValue(*piSeverite);

    // pRisque->SetPosition(*piRisque);
    // pRiskGauge->SetValue(*piRisque);
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSModifConcernIndexDlg::CmOk()
{
try
{
  // On v�rifie qu'un edit n'�tait pas en cours de saisie
  // Le Return n'envoie pas de KillFocus et appelle directement CmOk
  //
  killControlFocusOnReturnClose() ;

  *piSeverite = pGravite->GetPosition() ;
    // *piRisque   = pRisque->GetPosition();

	CloseWindow(IDOK) ;
}
catch (...)
{
    erreur("Exception NSModifConcernIndexDlg::CmOk.",  standardError, 0) ;
}
}

void
NSModifConcernIndexDlg::CmCancel()
{
    Destroy(IDCANCEL);
}

void
NSModifConcernIndexDlg::UpdateSeverity(uint)
{
    int setting = pGravite->GetPosition();

    if      (setting < 25)
        pGravGauge->SetColor(NS_CLASSLIB::TColor(0, 0, 128));   // Blue
    else if (setting < 50)
        pGravGauge->SetColor(NS_CLASSLIB::TColor(0, 128, 0));   // Green
    else if (setting < 75)
        pGravGauge->SetColor(NS_CLASSLIB::TColor(128, 128, 0)); // Yellow
    else
        pGravGauge->SetColor(NS_CLASSLIB::TColor(128, 0, 0));   // Red

    pGravGauge->SetValue(setting);
}

/*******************************************
void
NSModifConcernIndexDlg::UpdateRisk(uint)
{
    int setting = pRisque->GetPosition();

    if      (setting < 10)
        pRiskGauge->SetColor(NS_CLASSLIB::TColor(0, 0, 128));
    else if (setting < 15)
        pRiskGauge->SetColor(NS_CLASSLIB::TColor(0, 128, 0));
    else if (setting < 20)
        pRiskGauge->SetColor(NS_CLASSLIB::TColor(128, 128, 0));
    else
        pRiskGauge->SetColor(NS_CLASSLIB::TColor(128, 0, 0));

    pRiskGauge->SetValue(setting);
}
*******************************************/

// -----------------------------------------------------------------
//
//  M�thodes de NSModifConcernIndexDlg
//
// -----------------------------------------------------------------
// -----------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSEvolConcernIndexDlg, NSUtilDialog)
    EV_COMMAND(IDOK,        CmOk),
    EV_COMMAND(IDCANCEL,    CmCancel),
    EV_CHILD_NOTIFY_ALL_CODES(IDC_GRAVITE,  UpdateSeverity),
    // EV_CHILD_NOTIFY_ALL_CODES(IDC_RISQUE,   UpdateRisk),
END_RESPONSE_TABLE;

NSEvolConcernIndexDlg::NSEvolConcernIndexDlg(NVLdVTemps* pDeb, int* pSev, NSContexte* pCtx)
                      :NSUtilDialog(0, pCtx, "EVOL_PREO_INDEX")
{
try
{
    ptpsDeb     = pDeb;
    piSeverite  = pSev;
    // piRisque    = pRisk;

    pDate       = new NSUtilEditDateHeure(pContexte, this, PROB_DATE_DEB);
    pGravite 	= new OWL::THSlider(this, IDC_GRAVITE);
    // pRisque 	= new OWL::THSlider(this, IDC_RISQUE);

    pGravGauge  = new OWL::TGauge(this, "%d%%", IDC_PROGRESSGRAV, 24, 74, 215, 20);
    pGravGauge->SetRange(0, 100);
    pGravGauge->SetNativeUse(nuNever);

    // pRiskGauge  = new OWL::TGauge(this, "%d%%", IDC_PROGRESSRISK, 24, 78, 215, 20);
    // pRiskGauge->SetNativeUse(nuNever);
}
catch (...)
{
    erreur("Exception NSModifConcernIndexDlg ctor.",  standardError, 0) ;
}
}

NSEvolConcernIndexDlg::~NSEvolConcernIndexDlg()
{
    delete pDate;
    delete pGravite;
    // delete pRisque;
    delete pGravGauge;
    // delete pRiskGauge;
}

void
NSEvolConcernIndexDlg::SetupWindow()
{
    TDialog::SetupWindow();

    string sDateDeb = ptpsDeb->donneDateHeure();
    pDate->setDate(sDateDeb.c_str());

    pGravite->SetRange(0, 100);   //fixer min et max
    pGravite->SetRuler(5, false); //espacement entre deux graduations
    pGravite->SetPosition(*piSeverite);
    pGravGauge->SetValue(*piSeverite);

    // pRisque->SetPosition(*piRisque);
    // pRiskGauge->SetValue(*piRisque);
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSEvolConcernIndexDlg::CmOk()
{
try
{
  // On v�rifie qu'un edit n'�tait pas en cours de saisie
  // Le Return n'envoie pas de KillFocus et appelle directement CmOk
  //
  killControlFocusOnReturnClose() ;

  string sDDeb ;
  pDate->getDate(&sDDeb) ;
  ptpsDeb->initFromDate(sDDeb) ;

  *piSeverite = pGravite->GetPosition() ;
    // *piRisque   = pRisque->GetPosition();

	CloseWindow(IDOK) ;
}
catch (...)
{
    erreur("Exception NSModifConcernIndexDlg::CmOk.",  standardError, 0) ;
}
}

void
NSEvolConcernIndexDlg::CmCancel()
{
    Destroy(IDCANCEL);
}

void
NSEvolConcernIndexDlg::UpdateSeverity(uint)
{
    int setting = pGravite->GetPosition();

    if      (setting < 25)
        pGravGauge->SetColor(NS_CLASSLIB::TColor(0, 0, 128));   // Blue
    else if (setting < 50)
        pGravGauge->SetColor(NS_CLASSLIB::TColor(0, 128, 0));   // Green
    else if (setting < 75)
        pGravGauge->SetColor(NS_CLASSLIB::TColor(128, 128, 0)); // Yellow
    else
        pGravGauge->SetColor(NS_CLASSLIB::TColor(128, 0, 0));   // Red

    pGravGauge->SetValue(setting);
}

/*******************
void
NSEvolConcernIndexDlg::UpdateRisk(uint)
{
    int setting = pRisque->GetPosition();

    if      (setting < 10)
        pRiskGauge->SetColor(NS_CLASSLIB::TColor(0, 0, 128));
    else if (setting < 15)
        pRiskGauge->SetColor(NS_CLASSLIB::TColor(0, 128, 0));
    else if (setting < 20)
        pRiskGauge->SetColor(NS_CLASSLIB::TColor(128, 128, 0));
    else
        pRiskGauge->SetColor(NS_CLASSLIB::TColor(128, 0, 0));

    pRiskGauge->SetValue(setting);
}
********************************/

// -----------------------------------------------------------------
//
//  M�thodes de NSModifConcern
//
// -----------------------------------------------------------------
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSModifConcernDlg, NSUtilDialog)
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_COMMAND_AND_ID(IDR_CHRONIQUE, UserName),
    EV_COMMAND_AND_ID(IDR_DANS, UserName),
    EV_COMMAND_AND_ID(IDR_DUREE, UserName),
    EV_COMMAND_AND_ID(IDR_LE, UserName),
END_RESPONSE_TABLE;

NSModifConcernDlg::NSModifConcernDlg(NSLdvView* pView, NSContexte* pCtx, NSConcern* pPb)
                  :NSUtilDialog((TWindow*) pView, pCtx, "MODIF_PROBLEM")
{
try
{
    pLdvView    = pView;

    pType       = new NSUtilLexique(pContexte, this, PREOCCUP_EDIT, pContexte->getDico());
    pDateDeb    = new NSUtilEditDateHeure(pContexte, this, PROB_DATE_DEB);
    pDateFin    = new NSUtilEditDateHeure(pContexte, this, PROB_DATE_FIN);
    pNbJours    = new NSEditNum(pContexte, this, IDC_NBJOURS, 10) ;
    pRChronique = new OWL::TRadioButton(this, IDR_CHRONIQUE) ;
    pRDans      = new OWL::TRadioButton(this, IDR_DANS) ;
    pRDuree     = new OWL::TRadioButton(this, IDR_DUREE) ;
    pRLe        = new OWL::TRadioButton(this, IDR_LE) ;

    pConcern    = pPb;
}
catch (...)
{
    erreur("Exception NSModifConcernDlg ctor.",  standardError, 0) ;
}
}

NSModifConcernDlg::~NSModifConcernDlg()
{
    delete pType;
    delete pDateDeb;
    delete pDateFin;
    delete pNbJours ;
    delete pRChronique ;
    delete pRDans ;
    delete pRDuree ;
    delete pRLe ;
}

void
NSModifConcernDlg::SetupWindow()
{
    TDialog::SetupWindow();

    string sDateDeb = pConcern->tDateOuverture.donneDateHeure();
    pDateDeb->setDate(sDateDeb.c_str());

    if ((pConcern->tDateFermeture.estVide()) ||
        (pConcern->tDateFermeture.estNoLimit()))
        pRChronique->SetCheck(BF_CHECKED) ;
    else
    {
        string sDateFin = pConcern->tDateFermeture.donneDateHeure();
        pDateFin->setDate(sDateFin.c_str()) ;
        pRLe->SetCheck(BF_CHECKED) ;
    }

    pNbJours->SetText("0") ;

    pDateFin->SetReadOnly(false) ;
    pNbJours->SetReadOnly(true) ;

    // Recherche de cette pr�occupation dans l'Array
    // Looking for this health upset in the Array
    //
    if ((!pConcern->pDoc) || (!(pConcern->pDoc->pPathoPOMRIndex)) ||
        (pConcern->pDoc->pPathoPOMRIndex->empty()))
        return;

    NSPatPathoArray* pPtIndex = pConcern->pDoc->pPathoPOMRIndex;

    PatPathoIter iter = pPtIndex->begin();
    while ( (iter != pPtIndex->end()) &&
            ((*iter)->getNode() != pConcern->getNoeud()))
        iter++;

    // not found !
    if (iter == pPtIndex->end())
        return;

    sLexique = (*iter)->pDonnees->lexique;
    pType->setLabel(sLexique);
}

void    NSModifConcernDlg::UserName(WPARAM wParam)
{
    switch (wParam)
    {
        case (IDR_CHRONIQUE) :
            pDateFin->SetReadOnly(true) ;
            pNbJours->SetReadOnly(true) ;
            break ;
        case (IDR_DANS) :
            pDateFin->SetReadOnly(true) ;
            pNbJours->SetReadOnly(false) ;
            break ;
        case (IDR_DUREE) :
            pDateFin->SetReadOnly(true) ;
            pNbJours->SetReadOnly(false) ;
            break ;
        case (IDR_LE) :
            pNbJours->SetReadOnly(true) ;
            pDateFin->SetReadOnly(false) ;
            break ;
    }
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSModifConcernDlg::CmOk()
{
try
{
	//
	// on r�cup�re d'abord un �ventuel �l�ment lexique s�lectionn� par les fl�ches
	// Le Return n'envoie pas d'EvKeyDown et appelle directement CmOk
	if (pType->pDico->pDicoDialog->EstOuvert())
	{
		pType->pDico->pDicoDialog->InsererElementLexique() ;
		return ;
	}
	//
	// Ne pas accepter les textes libres
	//
	if (pType->sCode == string("�?????"))
	{
		erreur("Il faut choisir un code lexique et non pas du texte libre ", standardError, 0, GetHandle()) ;
		pType->SetFocus() ;
		return ;
	}

  // On v�rifie qu'un edit n'�tait pas en cours de saisie
  // Le Return n'envoie pas de KillFocus et appelle directement CmOk
  //
  killControlFocusOnReturnClose() ;

	string sDDeb ;
	pDateDeb->getDate(&sDDeb) ;

	string sDFin ;

	// r�cup�ration de la valeur du champs edit correspondant au nombre de jours
	pNbJours->donneValeur() ;

	// si on est dans le cas o� "chronique" est coch�e
	if (pRChronique->GetCheck() == BF_CHECKED)
		sDFin = "00000000000000" ;

	// si on dans le cas o� "dans" est coch�e
	if (pRDans->GetCheck() == BF_CHECKED)
	{
  	NVLdVTemps  tDateFin ;
    tDateFin.takeTime() ;
    tDateFin.ajouteJours(pNbJours->dValeur) ;
    sDFin = tDateFin.donneDateHeure() ;
	}

	// si on est dans le cas o� "dur�e" est coch�e
	if (pRDuree->GetCheck() == BF_CHECKED)
	{
  	NVLdVTemps  tDateFin ;
    tDateFin.initFromDate(sDDeb) ;
    tDateFin.ajouteJours(pNbJours->dValeur) ;
    sDFin = tDateFin.donneDateHeure() ;
	}

	// si on est dans le cas o� "le" est coch�e
	if (pRLe->GetCheck() == BF_CHECKED)
		pDateFin->getDate(&sDFin) ;

	//
	// Le titre de la pr�occupation a chang�
	// Health concern's title changed
	//
	if (pType->sCode != sLexique)


	// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	//
	// maintenant il faut modifier le probl�me dans l'index
	//
	// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	//
	// Positionnement du pointeur sur l'index
	//
	// NSPatPathoArray* pPathoIndex = 0 ;

	if ((pContexte->getPatient()) && (pContexte->getPatient()->pDocHis))
	{
		if (!(pContexte->getPatient()->pDocHis->VectDocument.empty()))
		{
			//
			// Enum�ration des documents
			//
			bool bContinuer = true ;
			DocumentIter iterDoc = pContexte->getPatient()->pDocHis->VectDocument.begin() ;
			while ((iterDoc != pContexte->getPatient()->pDocHis->VectDocument.end()) &&
                            bContinuer )
			{
				if (((*iterDoc)->pPatPathoArray) && (!((*iterDoc)->pPatPathoArray->empty())))
				{
					PatPathoIter iter = (*iterDoc)->pPatPathoArray->begin();
          if (strcmp((*iter)->pDonnees->lexique, "ZPOMR1") == 0)
          {
          	NSDocumentInfo Docum(pContexte) ;
            *(Docum.getData()) = *((*iterDoc)->getData()) ;

            NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;

            NSPatPathoArray* pPt = Noyau.pPatPathoArray ;

            //
            // On cherche le chapitre "pr�occupations de sant�"
            //
            PatPathoIter iter = pPt->ChercherItem("0PRO11") ;

            if ((NULL != iter) && (pPt->end() != iter))
            {
            	int colonneMere = (*iter)->getColonne() ;

              iter++ ;
              NSPatPathoInfo* pRepere = 0 ;
              if (pPt->end() != iter)
              	pRepere = *iter ;

              Message* pCodeMsg = new Message("") ;
              pCodeMsg->SetLexique(pType->sCode) ;
              int iDecalLigne ;
              if (pPt->end() != iter)
              	iDecalLigne = 0 ;
              else
              	iDecalLigne = 1 ;
              pPt->ajoutePatho(iter, pType->sCode,
                                                   pCodeMsg, colonneMere+1,
                                                   iDecalLigne, true) ;
              delete pCodeMsg ;

              //
              // Date de d�but
              //
              if ((sDDeb != "") &&
                  (sDDeb != string("19000000000000")) &&
                  (sDDeb != string("00000000000000")))
              {
              	//
                // Recalage
                //
                if (pRepere == 0)
                	iter = pPt->end() ;
                else
                {
                	iter = pPt->begin() ;
                  while ((pPt->end() != iter) && (*iter != pRepere))
                  	iter++ ;
                }

                Message* pCodeMsg = new Message("") ;

                pCodeMsg->SetLexique("KOUVR1") ;
                int iDecalLigne ;
                if (pPt->end() != iter)
                	iDecalLigne = 0 ;
                else
                	iDecalLigne = 1 ;
                pPt->ajoutePatho(iter, "KOUVR1", pCodeMsg, colonneMere+2,
                                                   iDecalLigne, true) ;

                //
                // Recalage
                //
                if (0 == pRepere)
                	iter = pPt->end() ;
                else
                {
                	iter = pPt->begin() ;
                  while ((pPt->end() != iter) && (*iter != pRepere))
                  	iter++ ;
                }


                pCodeMsg->SetLexique("�T0;19");
                pCodeMsg->SetComplement(sDDeb);
                pCodeMsg->SetUnit("2DA021");
                pPt->ajoutePatho(iter, "�T0;19", pCodeMsg, colonneMere+3,
                                                   iDecalLigne, false) ;

                delete pCodeMsg ;
              }

              //
              // Date de fin
              //
              if ((sDFin != "") &&
                  (sDFin != string("19000000000000")) &&
                  (sDFin != string("00000000000000")))
              {
              	//
                // Recalage
                //
                if (pRepere == 0)
                	iter = pPt->end() ;
                else
                {
                	iter = pPt->begin() ;
                  while ((iter != pPt->end()) && (*iter != pRepere))
                  	iter++ ;
                }

                Message* pCodeMsg = new Message("") ;

                pCodeMsg->SetLexique("KFERM1") ;
                int iDecalLigne ;
                if (iter != pPt->end())
                	iDecalLigne = 0 ;
                else
                	iDecalLigne = 1 ;
                pPt->ajoutePatho(iter, "KFERM1", pCodeMsg, colonneMere+2,
                                                   iDecalLigne, true) ;

                //
                // Recalage
                //
                if (pRepere == 0)
                	iter = pPt->end() ;
                else
              	{
                	iter = pPt->begin() ;
                  while ((iter != pPt->end()) && (*iter != pRepere))
                  	iter++ ;
                }

                pCodeMsg->SetLexique("�D0;19") ;
                pCodeMsg->SetComplement(sDFin) ;
                pCodeMsg->SetUnit("2DA021") ;
                pPt->ajoutePatho(iter, "�D0;19", pCodeMsg, colonneMere+3,
                                                   iDecalLigne, false) ;
                delete pCodeMsg ;
              }
              //
              // Enregistrement du document modifi�
              //
              Noyau.enregistrePatPatho() ;
              //
              // Mise � jour de l'historique
              //
              /* bool bReload = */ Noyau.chargePatPatho() ;
              pPt = Noyau.pPatPathoArray ;
              pContexte->getPatient()->pDocHis->Rafraichir(&Docum, pPt, &Noyau) ;
            }
            bContinuer = false ;
          }
          else
          	iterDoc++ ;
				}
			}
		}
	}

        // *sType = pType->sCode ;
	CloseWindow(IDOK) ;
}
catch (...)
{
	erreur("Exception NSModifConcernDlg::CmOk.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
void
NSModifConcernDlg::CmCancel()
{
    Destroy(IDCANCEL);
}

///////////////////////////////////////////////////////////////
//
// Classe NSMedic
//
///////////////////////////////////////////////////////////////

NSMedic::NSMedic()
{
    name = "";
    node = "";
    code = "";
    datedeb = "";
    datefin = "";
}

NSMedic::NSMedic(string sName, string sNode)
{
    name = sName;
    node = sNode;
    code = "";
    datedeb = "";
    datefin = "";
}

NSMedic::~NSMedic()
{
}

NSMedic::NSMedic(NSMedic& rv)
{
    name = rv.name;
    node = rv.node;
    code = rv.code;
    datedeb = rv.datedeb;
    datefin = rv.datefin;
}

NSMedic&
NSMedic::operator=(NSMedic src)
{
    name = src.name;
    node = src.node;
    code = src.code;
    datedeb = src.datedeb;
    datefin = src.datefin;

    return *this;
}

// Classe NSMedicArray
//////////////////////////////////////////

//---------------------------------------------------------------------------
//  Constructeur copie//---------------------------------------------------------------------------
NSMedicArray::NSMedicArray(NSMedicArray& rv) : NSMedicVector(){    if (!rv.empty())	for (NSMedicIter i = rv.begin(); i != rv.end(); i++)   	    push_back(new NSMedic(*(*i)));}
NSMedicArray&
NSMedicArray::operator=(NSMedicArray src)
{    if (!src.empty())	for (NSMedicIter i = src.begin(); i != src.end(); i++)   	    push_back(new NSMedic(*(*i)));    return *this;}

//---------------------------------------------------------------------------//  Destructeur//---------------------------------------------------------------------------
voidNSMedicArray::vider(){	if (!empty())		for (NSMedicIter i = begin(); i != end(); )    {			delete *i ;			erase(i) ;    }}
NSMedicArray::~NSMedicArray(){	vider();}

///////////////////////////////////////////////////////////////
//
// Classe NSObjectif
//
///////////////////////////////////////////////////////////////

NSObjectif::NSObjectif()
{
  name          = "" ;
  node          = "" ;
  code          = "" ;
  iRythme       = 0 ;
  dateAuto      = "" ;
  dateCons      = "" ;
  dateIdeal     = "" ;
  dateIdealMax  = "" ;
  dateConsMax   = "" ;
  dateCrit      = "" ;
  datePrec      = "" ;
  sValue        = "" ;
  iLevel        = 0 ;
  pCorrespGoal  = 0 ;
}

NSObjectif::NSObjectif(string sName, string sNode)
{
  name          = sName ;
  node          = sNode ;
  code          = "" ;
  iRythme       = 0 ;
  dateAuto      = "" ;
  dateCons      = "" ;
  dateIdeal     = "" ;
  dateIdealMax  = "" ;
  dateConsMax   = "" ;
  dateCrit      = "" ;
  datePrec      = "" ;
  sValue        = "" ;
  iLevel        = 0 ;
	pCorrespGoal  = 0 ;
}

NSObjectif::~NSObjectif()
{
}

NSObjectif::NSObjectif(NSObjectif& rv)
{
  name          = rv.name ;
  node          = rv.node ;
  code          = rv.code ;
  iRythme       = rv.iRythme ;
  dateAuto      = rv.dateAuto ;
  dateCons      = rv.dateCons ;
  dateIdeal     = rv.dateIdeal ;
  dateIdealMax  = rv.dateIdealMax ;
  dateConsMax   = rv.dateConsMax ;
  dateCrit      = rv.dateCrit ;
  datePrec      = rv.datePrec ;
  sValue        = rv.sValue ;
  iLevel        = rv.iLevel ;

	pCorrespGoal  = rv.pCorrespGoal ;
}

NSObjectif&
NSObjectif::operator=(NSObjectif src)
{
  name          = src.name ;
  node          = src.node ;
  code          = src.code ;
  iRythme       = src.iRythme ;
  dateAuto      = src.dateAuto ;
  dateCons      = src.dateCons ;
  dateIdeal     = src.dateIdeal ;
  dateIdealMax  = src.dateIdealMax ;
  dateConsMax   = src.dateConsMax ;
  dateCrit      = src.dateCrit ;
  datePrec      = src.datePrec ;
  sValue        = src.sValue ;
  iLevel        = src.iLevel ;

	pCorrespGoal  = src.pCorrespGoal ;

  return *this ;
}

// Classe NSObjectifArray
//////////////////////////////////////////

//---------------------------------------------------------------------------
//  Constructeur copie//---------------------------------------------------------------------------  /*
NSObjectifArray::NSObjectifArray(NSObjectifArray& rv) : NSObjectifVector(){    if (!rv.empty())	for (NSObjectifIter i = rv.begin(); i != rv.end(); i++)   	    push_back(new NSObjectif(*(*i)));}
NSObjectifArray&
NSObjectifArray::operator=(NSObjectifArray src)
{    if (!src.empty())	for (NSObjectifIter i = src.begin(); i != src.end(); i++)   	    push_back(new NSObjectif(*(*i)));    return *this;}

//---------------------------------------------------------------------------//  Destructeur//---------------------------------------------------------------------------
voidNSObjectifArray::vider(){    if (!empty())	for (NSObjectifIter i = begin(); i != end(); )    {   	    delete *i;        erase(i);    }}
NSObjectifArray::~NSObjectifArray(){	vider();}      */

//***************************************************************************
//
//  							M�thodes de NSConcernPropertyWindow//
//***************************************************************************
DEFINE_RESPONSE_TABLE1(NSConcernPropertyWindow, TListWindow)   EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

//---------------------------------------------------------------------------//  Function: NSConcernPropertyWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------

voidNSConcernPropertyWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
    TLwHitTestInfo info(point);

    HitTest(info);
    if (info.GetFlags() & LVHT_ONITEM)        pDlg->CmModifier();
}

//---------------------------------------------------------------------------//  Function: NSConcernPropertyWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------

intNSConcernPropertyWindow::IndexItemSelect()
{
    int count = GetItemCount();
    int index = -1;

    for (int i = 0; i < count; i++)   	    if (GetItemState(i, LVIS_SELECTED))
        {
      	    index = i;
            break;
        }

    return index;}

//***************************************************************************//
//  M�thodes de NSConcernPropertyDlg
//
//***************************************************************************

DEFINE_RESPONSE_TABLE1(NSConcernPropertyDlg, NSUtilDialog)    EV_LV_DISPINFO_NOTIFY(IDC_LISTVIEW_ACTUEL, LVN_GETDISPINFO, DispInfoListeActuel),
    EV_LV_DISPINFO_NOTIFY(IDC_LISTVIEW_ANCIEN, LVN_GETDISPINFO, DispInfoListeAncien),
    EV_LV_DISPINFO_NOTIFY(IDC_LISTVIEW_GOALS, LVN_GETDISPINFO, DispInfoListeExams),
    EV_BN_CLICKED(IDC_GLOBAL, CmGlobal),
    EV_BN_CLICKED(IDC_LOCAL, CmLocal),
    EV_COMMAND(IDC_NOUVEAU, CmNouveau),
    EV_COMMAND(IDC_RENOUV, CmRenouveler),
    EV_COMMAND(IDC_MODIFIER, CmModifier),
    EV_COMMAND(IDC_ARRETER, CmArreter),
    EV_COMMAND(IDC_ORDONNANCE, CmOrdonnance),
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    // EV_WM_DRAWITEM,
END_RESPONSE_TABLE;

NSConcernPropertyDlg::NSConcernPropertyDlg(NSLdvView* pView, NSContexte* pCtx, NSConcern* pPb)
                        :NSUtilDialog((TWindow*) pView, pCtx, "PROP_PREO")
{
    pLdvView        = pView ;
    pConcern        = pPb ;
    pOldConcern     = 0;
    pListeActuel    = new NSConcernPropertyWindow(this, IDC_LISTVIEW_ACTUEL) ;
    pListeAncien    = new NSConcernPropertyWindow(this, IDC_LISTVIEW_ANCIEN) ;
    pListeExams     = new NSConcernPropertyWindow(this, IDC_LISTVIEW_GOALS) ;

    pListGroup      = new TGroupBox(this, IDC_LIST_GROUP);
    pGlobal         = new TRadioButton(this, IDC_GLOBAL, pListGroup);
    pLocal          = new TRadioButton(this, IDC_LOCAL, pListGroup);
    pNouveau        = new TButton(this, IDC_NOUVEAU) ;
    pRenouveler     = new TButton(this, IDC_RENOUV);
    pModifier       = new TButton(this, IDC_MODIFIER);
    pArreter        = new TButton(this, IDC_ARRETER);
    pOrdonnance     = new TButton(this, IDC_ORDONNANCE);

    pMedicActuel    = new NSMedicArray() ;
    pMedicAncien    = new NSMedicArray() ;
    pExams          = new NSObjectifArray() ;
}

NSConcernPropertyDlg::~NSConcernPropertyDlg()
{
    delete pListeActuel ;
    delete pListeAncien ;
    delete pListeExams ;
    delete pMedicActuel ;
    delete pMedicAncien ;
    delete pExams ;
    delete pGlobal;
    delete pLocal;
    delete pListGroup;
    delete pNouveau ;
    delete pRenouveler;
    delete pModifier;
    delete pArreter;
    delete pOrdonnance;
}

void
NSConcernPropertyDlg::SetupWindow()
{
    NSUtilDialog::SetupWindow() ;
    if (pConcern)
    {
        pLocal->Check();
        bGlobal = false;
    }
    else
    {
        pGlobal->Check();
        bGlobal = true;
    }

    InitListeActuel() ;
    InitListeAncien() ;
    InitListeExams() ;
    InitListes();
}

void
NSConcernPropertyDlg::InitListes()
{
try
{
    //
    // M�dicaments - Drugs
    //
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
    VecteurString* pVecteurString = new VecteurString() ;
    if (pConcern == 0)
    {
        // on r�cup�re ici l'ensemble des noeuds m�dicaments li�s � chaque pr�occupation
        if ((pLdvView->getDoc()->getConcerns() == 0) || (pLdvView->getDoc()->getConcerns()->empty()))
        {
            delete pVecteurString;
            return;
        }

        for (ArrayConcernIter k = pLdvView->getDoc()->getConcerns()->begin(); k != pLdvView->getDoc()->getConcerns()->end(); k++)
        {
            pGraphe->TousLesVrais((*k)->getNoeud(), NSRootLink::drugOf, pVecteurString, "ENVERS") ;
        }
    }
    else
	    pGraphe->TousLesVrais(pConcern->getNoeud(), NSRootLink::drugOf, pVecteurString, "ENVERS") ;

    pMedicActuel->vider();
    pMedicAncien->vider();
    pExams->vider();
    nbMedicActuel = 0;
    nbMedicAncien = 0;
    nbExams = 0;

    // r�cup�ration de la date du jour au format AAAAMMJJ
    char szDateJour[10];
    donne_date_duJour(szDateJour);

    if (!(pVecteurString->empty()))
    {
        for (EquiItemIter i = pVecteurString->begin(); i != pVecteurString->end(); i++)
        {
            NSMedic* pMedic = new NSMedic;

            if (InitMedicament(pMedic, *(*i)))
            {
                if ((pMedic->datedeb <= string(szDateJour)) &&
                    ((pMedic->datefin > string(szDateJour)) ||
                                                            (pMedic->datefin == "")))
                {
                    pMedicActuel->push_back(new NSMedic(*pMedic));
                    nbMedicActuel++;
                }
                else
                {
                    pMedicAncien->push_back(new NSMedic(*pMedic));
                    nbMedicAncien++;
                }
            }
        }
    }

    delete pVecteurString ;

    //
    // Objectifs - Goals
    //
    for (ArrayGoalIter j = pLdvView->getDoc()->getGoals()->begin(); j != pLdvView->getDoc()->getGoals()->end(); j++)
    {
        NSObjectif* pObj = new NSObjectif;

        if (InitObjectif(pObj, *j))
        {
            pExams->push_back(new NSObjectif(*pObj));
            nbExams++;
        }
    }

    AfficheListeActuel() ;
    AfficheListeAncien() ;
    AfficheListeExams() ;
}
catch (...)
{
    erreur("Exception NSConcernPropertyDlg::InitListes",  standardError, 0) ;
}
}

bool
NSConcernPropertyDlg::InitMedicament(NSMedic* pMedic, string sNoeud)
{
    if (!pMedic)
        return false;

    NSPatientChoisi* pPat = pContexte->getPatient() ;
    if (!pPat)
        return false;

	if ((!pPat->pDocHis) || (pPat->pDocHis->VectDocument.empty()))
		return false;    if (strlen(sNoeud.c_str()) != PAT_NSS_LEN + DOC_CODE_DOCUM_LEN + PPD_NOEUD_LEN)        return false;	string sDocument = string(sNoeud, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN);    NSPatPathoArray* pPpt = NULL ;    PatPathoIter pptIt ;    //    // Recherche du document auquel appartient le noeud    //	DocumentIter DocIt = pPat->pDocHis->VectDocument.begin();	for (; DocIt != pPat->pDocHis->VectDocument.end(); DocIt++)	{		if (((*DocIt)->pPatPathoArray) && (!((*DocIt)->pPatPathoArray->empty())))		{			pptIt = (*DocIt)->pPatPathoArray->begin();            if ((*pptIt)->getDoc() == sDocument)            {                pPpt = (*DocIt)->pPatPathoArray ;                break ;            }        }    }    if (pPpt == NULL)        return false;    //    // Recherche du noeud    //    pptIt = pPpt->begin();    for (; (pptIt != pPpt->end()) && (sNoeud != (*pptIt)->getNode()); pptIt++);    if (pptIt == pPpt->end())        return false;    pMedic->node    = sNoeud ;    string sLexique = (*pptIt)->pDonnees->lexique ;    pMedic->code    = sLexique;    string sLang = "";    if ((pContexte) && (pContexte->getUtilisateur()))
        sLang = pContexte->getUtilisateur()->donneLang() ;    pContexte->getDico()->donneLibelle(sLang, &sLexique, &(pMedic->name)) ;    // Param�tres du m�dicament    //    int iColBase = (*pptIt)->pDonnees->getColonne() ;    pptIt++ ;    while ((pptIt != pPpt->end()) && ((*pptIt)->pDonnees->getColonne() > iColBase))    {
        string sElemLex = string((*pptIt)->pDonnees->lexique);
        string sSens;
        pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

        if ((*pptIt)->pDonnees->getColonne() == iColBase+1)
        {
            // Dates
            if ((sSens == "KOUVR") || (sSens == "KFERM"))
            {
                pptIt++;
                int iLigneBase = (*pptIt)->pDonnees->getLigne();
                string sUnite  = "";
                string sFormat = "";
                string sValeur = "";
                string sTemp   = "";

                while ((pptIt != pPpt->end()) &&
                            ((*pptIt)->pDonnees->getLigne() == iLigneBase))
                {
                    if (((*pptIt)->pDonnees->lexique)[0] == '�')
                    {
                        sTemp   = (*pptIt)->getLexique() ;
                        pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
                        sValeur = (*pptIt)->getComplement() ;
                        sTemp   = (*pptIt)->getUnit() ;
                        pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
                        break ;
                    }
                    pptIt++;
                }

                // sFormat est du type �D0;03
                if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) && (sValeur != ""))
                {
                    if ((sUnite == "2DA01") || (sUnite == "2DA02"))
                    {
                        if      (sSens == "KOUVR")
                            pMedic->datedeb = sValeur ;
                        else if (sSens == "KFERM")
                            pMedic->datefin = sValeur ;
                    }
                }
            }
            else
                pptIt++;
        }
        else
            pptIt++;
    }    return true;}boolNSConcernPropertyDlg::InitObjectif(NSObjectif* pObj, NSLdvGoal* pGoal){    // Si on cherche les objectifs d'une pr�occupation pr�cise, on v�rifie    // que cet objectif est concern�    //    if ((pConcern != 0) && (pConcern->getNoeud() != pGoal->sConcern))        return false;    // cas d'un objectif futur non pr�visible    if (pGoal->tOuvertLe.estVide())        return false;    NVLdVTemps tToday;    tToday.takeTime();    // cas d'un objectif d�j� ferm�    if ((!(pGoal->tFermeLe.estVide())) && (pGoal->tFermeLe <= tToday))        return false;    bool IsOpened = (tToday >= pGoal->tOuvertLe);    pObj->name = pGoal->sTitre;    pObj->node = pGoal->getNoeud();    // le titre dans Goal est en clair (pas de code lexique)    pObj->code = "";    pObj->iRythme = pGoal->iRythme ;    // Note : un objectif cyclique non ouvert (futur) se comporte comme    // un objectif ponctuel    if ((pGoal->iRythme != NSLdvGoal::cyclic) || (!IsOpened))    {        InitDateObjectifPonctuel(pObj->dateAuto, pGoal, pGoal->sDateDebutAutorise,                                    pGoal->dDelaiDebutAutorise, pGoal->sUniteDebutAutorise);        InitDateObjectifPonctuel(pObj->dateCons, pGoal, pGoal->sDateDebutConseille,                                    pGoal->dDelaiDebutConseille, pGoal->sUniteDebutConseille);        InitDateObjectifPonctuel(pObj->dateIdeal, pGoal, pGoal->sDateDebutIdeal,                                    pGoal->dDelaiDebutIdeal, pGoal->sUniteDebutIdeal);        InitDateObjectifPonctuel(pObj->dateIdealMax, pGoal, pGoal->sDateDebutIdealMax,                                    pGoal->dDelaiDebutIdealMax, pGoal->sUniteDebutIdealMax);        InitDateObjectifPonctuel(pObj->dateConsMax, pGoal, pGoal->sDateDebutConseilMax,                                    pGoal->dDelaiDebutConseilMax, pGoal->sUniteDebutConseilMax);        InitDateObjectifPonctuel(pObj->dateCrit, pGoal, pGoal->sDateDebutCritique,                                    pGoal->dDelaiDebutCritique, pGoal->sUniteDebutCritique);    }    else    {        // cas des objectifs cycliques d�j� ouverts        // et non d�j� ferm�s        GoalInfoIter i = pGoal->pJalons->end();        do        {            i--;            if ((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonIntermediaire)            {                if ((*i)->iLevel == NSLdvGoalInfo::AProuge)                    pObj->dateCrit = (*i)->tpsInfo.donneDate();                else if ((*i)->iLevel == NSLdvGoalInfo::APjaune)                    pObj->dateConsMax = (*i)->tpsInfo.donneDate();                else if ((*i)->iLevel == NSLdvGoalInfo::APvert)                    pObj->dateIdealMax = (*i)->tpsInfo.donneDate();                else if ((*i)->iLevel == NSLdvGoalInfo::Bleu)                    pObj->dateIdeal = (*i)->tpsInfo.donneDate();                else if ((*i)->iLevel == NSLdvGoalInfo::AVvert)                    pObj->dateCons = (*i)->tpsInfo.donneDate();                else if ((*i)->iLevel == NSLdvGoalInfo::AVjaune)                    pObj->dateAuto = (*i)->tpsInfo.donneDate();            }            else if ((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonCycle)            {                pObj->datePrec = (*i)->tpsInfo.donneDate();                break;            }            else if ((*i)->iTypeJalonEvent == NSLdvGoalInfo::jalonOuverture)                break;        }        while (i != pGoal->pJalons->begin());    }    return true;}
void
NSConcernPropertyDlg::InitDateObjectifPonctuel(string& sDateObj, NSLdvGoal* pGoal, string sDateJalon,
                                                    double dDelaiJalon, string sUniteJalon)
{
	NVLdVTemps tpsBuff;
	sDateObj = "";

	if (sDateJalon != "")
		sDateObj = sDateJalon ;	else if (dDelaiJalon > 0)	{		if (pGoal->sOpenEventNode == "")		{			tpsBuff.initFromDate(pGoal->tDateOuverture.donneDate()) ;			tpsBuff.ajouteTemps(int(dDelaiJalon), sUniteJalon, pContexte) ;			sDateObj = tpsBuff.donneDate() ;		}		else if (!(pGoal->tOuvertLe.estVide()))		{			tpsBuff.initFromDate(pGoal->tOuvertLe.donneDate()) ;			tpsBuff.ajouteTemps(int(dDelaiJalon), sUniteJalon, pContexte) ;			sDateObj = tpsBuff.donneDate() ;		}	}}
void
NSConcernPropertyDlg::InitListeActuel()
{
    TListWindColumn colMedic("Medicament", 150, TListWindColumn::Left, 0);
  	pListeActuel->InsertColumn(0, colMedic);

    TListWindColumn colDateDeb("Date debut", 80, TListWindColumn::Left, 1);    pListeActuel->InsertColumn(1, colDateDeb);

    TListWindColumn colDateFin("Date fin", 80, TListWindColumn::Left, 2);
    pListeActuel->InsertColumn(2, colDateFin);
}

void
NSConcernPropertyDlg::AfficheListeActuel()
{
    pListeActuel->DeleteAllItems();

	for (int i = nbMedicActuel - 1; i >= 0; i--)    {
        TListWindItem Item((((*pMedicActuel)[i])->name).c_str(), 0);
        pListeActuel->InsertItem(Item);
    }
}

void
NSConcernPropertyDlg::DispInfoListeActuel(TLwDispInfoNotify& dispInfo)
{
	const int      BufLen = 255 ;
  static char    buffer[BufLen] ;
  TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;
  int  index ;
  char szDate[10] ;

	index = dispInfoItem.GetIndex() ;
  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	// Affiche les informations en fonction de la colonne	switch (dispInfoItem.GetSubItem())
	{
  	case 1: // date d�but

    	strcpy(szDate, (((*pMedicActuel)[index])->datedeb).c_str()) ;
      donne_date(szDate, buffer, sLang) ;
      dispInfoItem.SetText(buffer) ;
      break ;

    case 2: // date fin
    	strcpy(szDate, (((*pMedicActuel)[index])->datefin).c_str()) ;
      if (!strcmp(szDate, ""))
      	strcpy(buffer, "indetermin�e") ;
      else
      	donne_date(szDate, buffer, sLang) ;
      dispInfoItem.SetText(buffer) ;
      break ;
   } // fin du switch
}

void
NSConcernPropertyDlg::InitListeAncien()
{
    TListWindColumn colMedic("Medicament", 150, TListWindColumn::Left, 0);
  	pListeAncien->InsertColumn(0, colMedic);

    TListWindColumn colDateDeb("Date debut", 80, TListWindColumn::Left, 1);    pListeAncien->InsertColumn(1, colDateDeb);

    TListWindColumn colDateFin("Date fin", 80, TListWindColumn::Left, 2);
    pListeAncien->InsertColumn(2, colDateFin);
}

void
NSConcernPropertyDlg::AfficheListeAncien()
{
    pListeAncien->DeleteAllItems();

	for (int i = nbMedicAncien - 1; i >= 0; i--)    {
        TListWindItem Item((((*pMedicAncien)[i])->name).c_str(), 0);
        pListeAncien->InsertItem(Item);
    }
}

void
NSConcernPropertyDlg::DispInfoListeAncien(TLwDispInfoNotify& dispInfo)
{
    const int 	    BufLen = 255;
    static char     buffer[BufLen];
    TListWindItem&  dispInfoItem = *(TListWindItem*)&dispInfo.item;
    int 			index;
    char            szDate[10];

    index = dispInfoItem.GetIndex();
	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	// Affiche les informations en fonction de la colonne	switch (dispInfoItem.GetSubItem())
	{
  	case 1: // date d�but

    	strcpy(szDate, (((*pMedicAncien)[index])->datedeb).c_str()) ;
      donne_date(szDate, buffer, sLang) ;
      dispInfoItem.SetText(buffer) ;
      break ;

    case 2: // date fin
    	strcpy(szDate, (((*pMedicAncien)[index])->datefin).c_str()) ;
      if (!strcmp(szDate, ""))
      	strcpy(buffer, "indetermin�e") ;
      else
      	donne_date(szDate, buffer, sLang) ;
      dispInfoItem.SetText(buffer) ;
    	break ;
	} // fin du switch
}

void
NSConcernPropertyDlg::InitListeExams()
{
    TListWindColumn colExam("Examen", 150, TListWindColumn::Left, 0);
  	pListeExams->InsertColumn(0, colExam);

    TListWindColumn colType("Type", 55, TListWindColumn::Left, 1);
  	pListeExams->InsertColumn(1, colType);

    TListWindColumn colDateDebAuto("Autoris�", 75, TListWindColumn::Left, 2);    pListeExams->InsertColumn(2, colDateDebAuto);

    TListWindColumn colDateDebCons("Conseill�", 75, TListWindColumn::Left, 3);
    pListeExams->InsertColumn(3, colDateDebCons);

    TListWindColumn colDateDebIdeal("Id�al", 75, TListWindColumn::Left, 4);
    pListeExams->InsertColumn(4, colDateDebIdeal);

    TListWindColumn colDateDebIdealMax("Id�al max", 75, TListWindColumn::Left, 5);
    pListeExams->InsertColumn(5, colDateDebIdealMax);

    TListWindColumn colDateDebConsMax("Cons. max", 75, TListWindColumn::Left, 6);
    pListeExams->InsertColumn(6, colDateDebConsMax);

    TListWindColumn colDateDebCrit("Critique", 75, TListWindColumn::Left, 7);
    pListeExams->InsertColumn(7, colDateDebCrit);

    TListWindColumn colDatePrec("Pr�c�dent", 75, TListWindColumn::Left, 8);
    pListeExams->InsertColumn(8, colDatePrec);
}

void
NSConcernPropertyDlg::AfficheListeExams()
{
    pListeExams->DeleteAllItems();

	for (int i = nbExams - 1; i >= 0; i--)    {
        TListWindItem Item((((*pExams)[i])->name).c_str(), 0);
        pListeExams->InsertItem(Item);
    }
}

void
NSConcernPropertyDlg::DispInfoListeExams(TLwDispInfoNotify& dispInfo)
{
  const int 	    BufLen            = 255 ;
  static char     buffer[BufLen] ;
  TListWindItem&  dispInfoItem      = *(TListWindItem *)&dispInfo.item ;
  int 			      index ;
  char            szDate[10] ;

  index = dispInfoItem.GetIndex() ;  strcpy(buffer, "") ;
	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  // Affiche les informations en fonction de la colonne  switch (dispInfoItem.GetSubItem())
  {
    case  1 : // type objectif
              if       (((*pExams)[index])->iRythme == NSLdvGoal::cyclic)
                strcpy(buffer, "cyclique") ;
              else if  (((*pExams)[index])->iRythme == NSLdvGoal::permanent)
                strcpy(buffer, "permanent") ;
              else if  (((*pExams)[index])->iRythme == NSLdvGoal::ponctuel)
                strcpy(buffer, "ponctuel") ;
              else
                strcpy(buffer, "") ;
              dispInfoItem.SetText(buffer) ;
              break ;

    case  2 : // date d�but autoris�
              strcpy(szDate, (((*pExams)[index])->dateAuto).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    case  3 : // date d�but conseill�              strcpy(szDate, (((*pExams)[index])->dateCons).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    case  4 : // date d�but id�al
              strcpy(szDate, (((*pExams)[index])->dateIdeal).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    case  5 : // date d�but ideal max
              strcpy(szDate, (((*pExams)[index])->dateIdealMax).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    case  6 : // date d�but conseill� max
              strcpy(szDate, (((*pExams)[index])->dateConsMax).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    case  7 : // date d�but critique
              strcpy(szDate, (((*pExams)[index])->dateCrit).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;

    case  8 : // date pr�c�dent
              strcpy(szDate, (((*pExams)[index])->datePrec).c_str()) ;
              if (strcmp(szDate, ""))
                donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;
   } // fin du switch
}

void
NSConcernPropertyDlg::EvDrawItem(uint ctrlId, DRAWITEMSTRUCT far& drawInfo)
{
	// const int 	    BufLen = 255;
	// static char     buffer[BufLen+1];
	//
	// Liste des objectifs
	//
	if (ctrlId == IDC_LISTVIEW_GOALS)
	{
  	if (drawInfo.itemID == -1)
    	return ;

    // On retrouve l'�l�ment qui correspond � cet index
    // Finding this index correponding element
    //
    /* int index = */ drawInfo.itemID ;
    ListView_SetTextBkColor(drawInfo.hwndItem, RGB(8,0,0));


        /*************************************
        TListWindItem Item ;
        Item.SetIndex(index) ;
        // Item.SetSubItem(0) ;
        Item.mask = LVIF_PARAM ;

        if (!(pListeExams->GetItem(Item)))            return ;

        Item.GetText(buffer);
        TDC dcItem(drawInfo.hDC);

        switch (index)
        {
            case 0:
                dcItem.SetBkColor(TColor::LtRed);
                break;

            case 1: // type objectif
                dcItem.SetBkColor(TColor::LtGreen);
                break;
        } // fin du switch

        // dcItem.TextOut(drawInfo.rcItem.left, drawInfo.rcItem.top, buffer);
        *****************************/
    }
}

void
NSConcernPropertyDlg::CmNouveau()
{
    string sChoixMed ;

    if (pConcern == 0)
    {
        erreur("Le m�dicament doit �tre rattach� � une pr�occupation particuli�re.",  standardError, 0) ;
        return;
    }

	NSNewTrt* pNewTrtDlg = new NSNewTrt(this, &sChoixMed, pConcern->getNoeud(), pContexte, "GPRSC1") ;
    int iRetour = pNewTrtDlg->Execute() ;
    delete pNewTrtDlg ;

	if (iRetour == IDCANCEL)
		return ;

    if (sChoixMed == "")
        return ;
}

void
NSConcernPropertyDlg::CmRenouveler()
{
}

void
NSConcernPropertyDlg::CmModifier()
{
try
{
	int index = pListeActuel->IndexItemSelect() ;

	if (pConcern == 0)
  {
  	erreur("Le m�dicament doit �tre rattach� � une pr�occupation particuli�re.",  standardError, 0) ;
    return ;
  }

	if (index == -1)
	{
  	erreur("Vous devez s�lectionner un m�dicament � modifier dans la liste des m�dicaments en cours.",  standardError, 0) ;
    return ;
  }

	string sNodeModif, sCodeModif ;
	NSPatPathoArray PPT(pContexte) ;

	sNodeModif = ((*pMedicActuel)[index])->node ;
	sCodeModif = ((*pMedicActuel)[index])->code ;

	// on r�cup�re d'abord la sous-patpatho du noeud � modifier
	NSPatPathoArray SousPPT(pContexte) ;
	pContexte->getPatient()->DonneSousArray(sNodeModif, &SousPPT) ;
	// on reconstitue la patpatho � partir du noeud
	PPT.ajoutePatho(sCodeModif, 0) ;
	// Insertion en queue (iter doit �tre ici egal � end())
	PPT.InserePatPatho(PPT.end(), &SousPPT, 1) ;
	// on cr�e une copie
	NSPatPathoArray PPTCopy(PPT) ;

	NSSmallBrother BigBoss(pContexte, &PPT, 0) ;
	BigBoss.pFenetreMere = pContexte->GetMainWindow() ;
	// on lance l'archetype li� au code m�dicament (avec fil guide associ�)
	BigBoss.lance12("GPRSC1", sCodeModif) ;
	// Si aucune modif : on sort...	if (PPT.estEgal(&PPTCopy))  	return ;	// r�cup�ration de la date du jour au format AAAAMMJJ	// char szDateJour[10];
	// donne_date_duJour(szDateJour);	NVLdVTemps tpsNow ;	tpsNow.takeTime() ;	VecteurString NodeArret ;	NodeArret.push_back(new string(sNodeModif)) ;	// on cloture la pr�c�dente prescription	pContexte->getPatient()->ArreterElement(&NodeArret, tpsNow.donneDateHeure()) ;	// on enregistre ici dans l'index de sant�	if (!(PPT.empty()))
  {
  	VecteurString NodeConcern ;
    NodeConcern.push_back(new string(pConcern->getNoeud())) ;
		pContexte->getPatient()->CreeTraitement(&PPT, &NodeConcern) ;
  }

	InitListes() ;
}
catch (...)
{
	erreur("Exception NSConcernPropertyDlg::CmModifier.",  standardError, 0) ;
}}

void
NSConcernPropertyDlg::CmArreter()
{
    int index = pListeActuel->IndexItemSelect();

    if (index == -1)
    {
        erreur("Vous devez s�lectionner un m�dicament � arreter dans la liste des m�dicaments en cours.",  standardError, 0) ;
        return;
    }

    string sNodeModif = ((*pMedicActuel)[index])->node;

    // r�cup�ration de la date du jour au format AAAAMMJJ
    // char szDateJour[10];
    // donne_date_duJour(szDateJour);    NVLdVTemps tpsNow ;  	tpsNow.takeTime() ;    VecteurString* pNodeArret = new VecteurString() ;    pNodeArret->push_back(new string(sNodeModif)) ;    // on cloture la pr�c�dente prescription    // pContexte->getPatient()->ArreterElement(pNodeArret, string(szDateJour));
    pContexte->getPatient()->ArreterElement(pNodeArret, tpsNow.donneDateHeure()) ;

    InitListes();

    delete pNodeArret;
}

void
NSConcernPropertyDlg::CmOrdonnance()
{
    pContexte->getPatient()->CreeOrdonnance(true);
}

void
NSConcernPropertyDlg::CmGlobal()
{
    if (bGlobal)
    {
        pGlobal->Check();
        pLocal->Uncheck();
        return;
    }

    bGlobal = true;
    pOldConcern = pConcern;
    pConcern = 0;
    pGlobal->Check();
    pLocal->Uncheck();
    InitListes();
}

void
NSConcernPropertyDlg::CmLocal()
{
    if (!bGlobal)
    {
        pLocal->Check();
        pGlobal->Uncheck();
        return;
    }

    if ((pConcern == 0) && (pOldConcern != 0))
    {
        bGlobal = false;
        pConcern = pOldConcern;
        pOldConcern = 0;
        pLocal->Check();
        pGlobal->Uncheck();
        InitListes();
    }
    else if ((pConcern == 0) && (pOldConcern == 0))
    {
        erreur("Cette option n'est utilisable qu'� partir d'une pr�occupation particuli�re.",  standardError, 0) ;
        bGlobal = true;
        pLocal->Uncheck();
        pGlobal->Check();
    }
}

void
NSConcernPropertyDlg::CmOk()
{
  NSUtilDialog::CmOk();
}

void
NSConcernPropertyDlg::CmCancel()
{
    NSUtilDialog::CmCancel();
}

// -----------------------------------------------------------------------------
//
//                         CHOIX D'UN NOUVEAU TRAITEMENT
//                                classe NSNewTrt
//
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSNewTrt, TDialog)  EV_COMMAND(IDOK,      CmOk),
  EV_COMMAND(IDCANCEL,  CmCancel),
END_RESPONSE_TABLE ;

// NSNewTrt::NSNewTrt(NSConcernPropertyDlg* parent, string* pTypeDocument, string sPreoccup, NSContexte* pCtx)//         :TDialog((TWindow *) parent, "TYPE_MEDIC"), NSRoot(pCtx)NSNewTrt::NSNewTrt(TWindow *parent, string *pTypeDocument, string sPreoccup, NSContexte *pCtx, string sArcCode, string sCaptionDlg)         :NSUtilDialog(parent, pCtx, "TYPE_MEDIC")
{
//    pDlg          = parent ;
    pType           = new NSUtilLexique(pContexte, this, IDC_MEDIC_EDIT, pContexte->getDico()) ;
    pTypeDocum      = pTypeDocument ;
    sPreoccupation  = sPreoccup ;
    sDlgCaption     = sCaptionDlg ;
    sCodeArc        = sArcCode ;
}


NSNewTrt::~NSNewTrt(){
    delete pType ;
}


void
NSNewTrt::SetupWindow()
{
    TDialog::SetupWindow() ;
    if (sDlgCaption != "")
        SetCaption(sDlgCaption.c_str()) ;
    if (pTypeDocum && (*pTypeDocum != ""))
        pType->setLabel(*pTypeDocum) ;
}


//----------------------------------------------------------------------------//----------------------------------------------------------------------------
void
NSNewTrt::CmOk()
{
try
{
  // on r�cup�re d'abord un �ventuel �l�ment lexique s�lectionn� par les fl�ches
  // Le Return n'envoie pas d'EvKeyDown et appelle directement CmOk
  if (pType->pDico->pDicoDialog->EstOuvert())
  {
    pType->pDico->pDicoDialog->InsererElementLexique() ;
    return ;
  }

  // Ne pas accepter les textes libres  if (pType->sCode == string("�?????"))
  {
    erreur("Il faut choisir un code lexique et non pas du texte libre ", standardError, 0, GetHandle()) ;
    pType->SetFocus() ;
    return ;
  }

  *pTypeDocum = pType->sCode ;

/*
  NSPatPathoArray *pPPT     = new NSPatPathoArray(pContexte) ;
  NSSmallBrother  *pBigBoss = new NSSmallBrother(pContexte, pPPT, 0, false /- initFromBbk -/) ;
  pBigBoss->pFenetreMere    = pContexte->GetMainWindow() ;

  if (sCodeArc != "")
    pBigBoss->lance12(sCodeArc, pType->sCode) ;
  else
  {
    // normalement on devrait jamais �tre dans ce cas

    // on lance l'archetype li� au code m�dicament (avec fil guide associ�)
    pBigBoss->lance12("GPRSC1", pType->sCode) ;
  }
  //pBigBoss->lanceBbkArchetype(sArchetype) ;  delete pBigBoss ;
  // on enregistre ici dans l'index de sant�
  if (!(pPPT->empty()))
  {
    pContexte->getPatient()->CreeTraitement(pPPT, sPreoccupation) ;
    // pDlg->InitListes();
  }

  delete pPPT ;
*/
	CloseWindow(IDOK) ;
}
catch (...)
{
  erreur("Exception NSNewTrt::CmOk.",  standardError, 0) ;
  return ;
}
}

//-------------------------------------------------------------------------//-------------------------------------------------------------------------
void
NSNewTrt::CmCancel()
{
    *pTypeDocum = "";
    Destroy(IDCANCEL);
}


// -----------------------------------------------------------------
//
//  M�thodes de NSOpenMultiDocsDlg
//
// -----------------------------------------------------------------
// -----------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSOpenMultiDocsDlg, NSUtilDialog)
    EV_LV_DISPINFO_NOTIFY(IDC_LISTVIEW_DOCS, LVN_GETDISPINFO, DispInfoListeDocs),
    EV_COMMAND(IDOK,            CmOk),
    EV_COMMAND(IDCANCEL,        CmCancel),
    EV_COMMAND(IDC_SELECT_ALL,  CmSelectAll),
END_RESPONSE_TABLE;

NSOpenMultiDocsDlg::NSOpenMultiDocsDlg(NSLdvView* pView, NSContexte* pCtx, ArrayObjets* pObjects)
                    :NSUtilDialog((TWindow*) pView, pCtx, "OPEN_MULTIDOCS")
{
try
{
    pObjectsArray   = pObjects ;

    pSelectAllBtn   = new TButton(this, IDC_SELECT_ALL) ;
    pObjectsList    = new NSMultiDocsWindow(this, IDC_LISTVIEW_DOCS) ;
}
catch (...)
{
  erreur("Exception NSOpenMultiDocsDlg ctor.",  standardError, 0) ;
}
}

NSOpenMultiDocsDlg::~NSOpenMultiDocsDlg()
{
}

void
NSOpenMultiDocsDlg::SetupWindow()
{
    // ListView_SetExtendedListViewStyle(pObjectsList->HWindow, LVS_EX_FULLROWSELECT) ;

    TDialog::SetupWindow();

    InitListeDocs() ;
    AfficheListeDocs() ;
}

void
NSOpenMultiDocsDlg::dblClickDoc()
{
    CmOk() ;
}

void
NSOpenMultiDocsDlg::CmOk()
{
	if (pObjectsArray->empty())
		return ;

	int* pObjectsIndex = new int[pObjectsArray->size()] ;
	ArrayObjets* pObjectsSelArray = new ArrayObjets(pObjectsArray->pDoc) ;
	int index, nbSel ;

	nbSel = pObjectsList->GetSelIndexes(pObjectsIndex, pObjectsArray->size()) ;
	// max = pObjectsArray->size() - 1 ;

	for (int i = 0; i < nbSel; i++)
	{
		index = pObjectsIndex[i] ;
		// pObjectsSelArray->push_back(new NSLdvObjet(*((*pObjectsArray)[max - index])));
		pObjectsSelArray->push_back(new NSLdvObjet(*((*pObjectsArray)[index]))) ;
	}

	// Attention � ne pas utiliser vider() pour ne pas deleter les objets
	for (ArrayObjIter objIt = pObjectsArray->begin(); objIt != pObjectsArray->end(); )
		pObjectsArray->erase(objIt) ;

	// l'operateur = appelle vider() mais comme pObjectsArray est vide
	// il ne fait que la recopie
	*pObjectsArray = *pObjectsSelArray ;

	for (ArrayObjIter objIt = pObjectsSelArray->begin(); objIt != pObjectsSelArray->end(); )
		pObjectsSelArray->erase(objIt) ;
	delete pObjectsSelArray ;

	TDialog::CmOk() ;
}

void
NSOpenMultiDocsDlg::CmCancel()
{
    TDialog::CmCancel();
}

void
NSOpenMultiDocsDlg::CmSelectAll()
{
	if (pObjectsArray->empty())
		return ;

	int* pObjectsIndex = new int[pObjectsArray->size()] ;
	int k = 0 ;

	for (ArrayObjIter objIt = pObjectsArray->begin() ; objIt != pObjectsArray->end(); objIt++)
	{
		pObjectsIndex[k] = k ;
		k++ ;
	}

	pObjectsList->SetSelIndexes(pObjectsIndex, k, true) ;
	pObjectsList->SetFocus() ;
  delete pObjectsIndex ;
}

void
NSOpenMultiDocsDlg::InitListeDocs()
{
    TListWindColumn colExam("Examen", 300, TListWindColumn::Left, 0);
  	pObjectsList->InsertColumn(0, colExam);
	TListWindColumn colNombre("Date", 100, TListWindColumn::Left, 1);
  	pObjectsList->InsertColumn(1, colNombre);
}

void
NSOpenMultiDocsDlg::AfficheListeDocs()
{
	pObjectsList->DeleteAllItems() ;
    if (pObjectsArray->empty())
        return ;

    char cLibExam[255] = "" ;
    string sCodeExam, sLibExam ;

    ArrayObjIter objIt = pObjectsArray->end() ;
    do
    {
        objIt-- ;

        strcpy(cLibExam, (*objIt)->sTitre.c_str()) ;
   	    TListWindItem Item(cLibExam, 0) ;
        pObjectsList->InsertItem(Item) ;
    }
    while (objIt != pObjectsArray->begin()) ;
}

void
NSOpenMultiDocsDlg::DispInfoListeDocs(TLwDispInfoNotify& dispInfo)
{
	if (pObjectsArray->empty())
  	return ;

	const int 	    BufLen = 255;
	static char     buffer[BufLen];
	TListWindItem&  dispInfoItem = *(TListWindItem*)&dispInfo.item;
	// char			cCodeExam[80];
	// int			    occur;

	int index = dispInfoItem.GetIndex();

	ArrayObjIter objIt = pObjectsArray->begin() ;
	for (int i = 0 ; (i < index) && (objIt != pObjectsArray->end()); i++, objIt++) ;
    if (objIt == pObjectsArray->end())
        return ;

	string sLang = "";
	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;

	// Affiche les informations en fonction de la colonne

	switch (dispInfoItem.GetSubItem())
	{
  	case 1: // nombre d'examens

    	string sDate = (*objIt)->tDateHeureDebut.donneDate() ;
      donne_date((char*)(sDate.c_str()), buffer, sLang) ;
      dispInfoItem.SetText(buffer) ;
      break ;
	}

	return ;
}

//***************************************************************************
//
//  					M�thodes de NSDrugsPropertyWindow//
//***************************************************************************
DEFINE_RESPONSE_TABLE1(NSMultiDocsWindow, TListWindow)   EV_WM_LBUTTONDBLCLK,
   // EV_WM_SETFOCUS,
END_RESPONSE_TABLE;

NSMultiDocsWindow::NSMultiDocsWindow(NSOpenMultiDocsDlg* parent, int id, TModule* module)
    :TListWindow((TWindow *) parent, id, module)
{
    pView   = parent;
    iRes    = id;
    Attr.Style |= LVS_REPORT | LVS_SHOWSELALWAYS;
    // Attr.ExStyle |= WS_EX_NOPARENTNOTIFY;
}
void
NSMultiDocsWindow::SetupWindow()
{
    ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;

    TListWindow::SetupWindow() ;
}

//---------------------------------------------------------------------------
//  Fonction de r�ponse au double-click
//---------------------------------------------------------------------------
void
NSMultiDocsWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
    TLwHitTestInfo info(point) ;

    HitTest(info) ;
    if (info.GetFlags() & LVHT_ONITEM)        pView->CmOk() ;
}

//---------------------------------------------------------------------------//  Retourne l'index du premier item s�lectionn�
//---------------------------------------------------------------------------
int
NSMultiDocsWindow::IndexItemSelect()
{
	int count = GetItemCount() ;
  int index = -1 ;

	for (int i = 0; i < count; i++)  	if (GetItemState(i, LVIS_SELECTED))
    {
    	index = i ;
      break ;
    }

	return index ;}

void
NSMultiDocsWindow::EvSetFocus(HWND hWndLostFocus)
{
    pView->EvSetFocus(hWndLostFocus) ;
}

// -----------------------------------------------------------------
//
//  M�thodes de NSNewCurveDlg
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSNewCurveDlg, NSUtilDialog)
	EV_COMMAND(IDOK,     CmOk),
	EV_COMMAND(IDCANCEL, CmCancel),
  EV_COMMAND_AND_ID(COLORSAMPLE_RED,     ColorSample),
  EV_COMMAND_AND_ID(COLORSAMPLE_GREEN,   ColorSample),
  EV_COMMAND_AND_ID(COLORSAMPLE_YELLOW,  ColorSample),
  EV_COMMAND_AND_ID(COLORSAMPLE_BLUE,    ColorSample),
  EV_COMMAND_AND_ID(COLORSAMPLE_MAGENTA, ColorSample),
  EV_COMMAND_AND_ID(COLORSAMPLE_CYAN,    ColorSample),
  EV_COMMAND_AND_ID(TYPE_SOLID,          DotStyle),
  EV_COMMAND_AND_ID(TYPE_DASH,           DotStyle),
  EV_COMMAND_AND_ID(TYPE_DOT,            DotStyle),
  EV_COMMAND_AND_ID(TYPE_DASHDOT,        DotStyle),
  EV_COMMAND_AND_ID(TYPE_DASHDOTDOT,     DotStyle),
  EV_COMMAND_AND_ID(POINT_CIRCLE,        PointAspect),
  EV_COMMAND_AND_ID(POINT_SQUARE,        PointAspect),
  EV_COMMAND_AND_ID(POINT_TRIANGLE,      PointAspect),
  EV_COMMAND_AND_ID(POINT_STAR,          PointAspect),
END_RESPONSE_TABLE;

NSNewCurveDlg::NSNewCurveDlg(TWindow* pPere, NSContexte* pCtx, NSLdvCurve* pCurveToEdit, bool bModif)
              :NSUtilDialog(pPere, pCtx, "NEW_CURVE")
{
try
{
	pCurve         = pCurveToEdit ;

  bModifyMode    = bModif ;

  pConceptGroup  = new OWL::TGroupBox(this, SHADE_CURVE) ;

	pType          = new NSUtilLexique(pContexte, this, CURVE_EDIT, pContexte->getDico()) ;
  pUnitText      = new OWL::TStatic(this, UNIT_TEXT) ;
  pUnit          = new NSUtilLexique(pContexte, this, UNIT_EDIT, pContexte->getDico()) ;

  pAxisPropertiesGroup  = new OWL::TGroupBox(this, SHADE_AXIS) ;

  pMinAxisText   = new OWL::TStatic(this, LOWER_AXIS_TEXT) ;
  pMaxAxisText   = new OWL::TStatic(this, UPPER_AXIS_TEXT) ;

  pMinAxisValue  = new NSUpDownEdit(this, pContexte, "", LOWER_AXIS_EDIT, LOWER_AXIS_UPDN) ;
  pMaxAxisValue  = new NSUpDownEdit(this, pContexte, "", UPPER_AXIS_EDIT, UPPER_AXIS_UPDN) ;

  pIncludeZeroBtn = new OWL::TRadioButton(this, INCLUDE_ZERO) ;

  pLineColourGroup = new OWL::TGroupBox(this, SHADE_TYPE) ;

  pRedText       = new OWL::TStatic(this, COLOR_RED_TEXT) ;
  pGreenText     = new OWL::TStatic(this, COLOR_GRE_TEXT) ;
  pBlueText      = new OWL::TStatic(this, COLOR_BLU_TEXT) ;

  pRedValue      = new NSUpDownEdit(this, pContexte, "", COLOR_RED_EDIT, COLOR_RED_UPDN) ;
  pGreenValue    = new NSUpDownEdit(this, pContexte, "", COLOR_GRE_EDIT, COLOR_GRE_UPDN) ;
  pBlueValue     = new NSUpDownEdit(this, pContexte, "", COLOR_BLU_EDIT, COLOR_BLU_UPDN) ;

  pRedSampleColorBtn     = new OWL::TRadioButton(this, COLORSAMPLE_RED, pLineColourGroup) ;
  pGreenSampleColorBtn   = new OWL::TRadioButton(this, COLORSAMPLE_GREEN, pLineColourGroup) ;
  pYellowSampleColorBtn  = new OWL::TRadioButton(this, COLORSAMPLE_YELLOW, pLineColourGroup) ;
  pBlueSampleColorBtn    = new OWL::TRadioButton(this, COLORSAMPLE_BLUE, pLineColourGroup) ;
  pMagentaSampleColorBtn = new OWL::TRadioButton(this, COLORSAMPLE_MAGENTA, pLineColourGroup) ;
  pCyanSampleColorBtn    = new OWL::TRadioButton(this, COLORSAMPLE_CYAN, pLineColourGroup) ;

  pLineTypeGroup = new OWL::TGroupBox(this, SHADE_LINE_TYPE) ;

  pWidthValue    = new NSUpDownEdit(this, pContexte, "", SIZE_EDIT, SIZE_UPDN) ;
  pWidthText     = new OWL::TStatic(this, SIZE_TEXT) ;

  pTSolid        = new OWL::TRadioButton(this, TYPE_SOLID, pLineTypeGroup) ;
  pTDash         = new OWL::TRadioButton(this, TYPE_DASH, pLineTypeGroup) ;
  pTDot          = new OWL::TRadioButton(this, TYPE_DOT, pLineTypeGroup) ;
  pTDashDot      = new OWL::TRadioButton(this, TYPE_DASHDOT, pLineTypeGroup) ;
  pTDashDotDot   = new OWL::TRadioButton(this, TYPE_DASHDOTDOT, pLineTypeGroup) ;

  pPointTypeGroup = new OWL::TGroupBox(this, SHADE_POINT) ;

  pDynamicColouringBtn = new OWL::TRadioButton(this, DYNAMIC_COLOURING, pLineTypeGroup) ;

  pPointAspectCircleBtn   = new OWL::TRadioButton(this, POINT_CIRCLE, pLineTypeGroup) ;
  pPointAspectSquareBtn   = new OWL::TRadioButton(this, POINT_SQUARE, pLineTypeGroup) ;
  pPointAspectTriangleBtn = new OWL::TRadioButton(this, POINT_TRIANGLE, pLineTypeGroup) ;
  pPointAspectStarBtn     = new OWL::TRadioButton(this, POINT_STAR, pLineTypeGroup) ;

  pPointRadiusText   = new OWL::TStatic(this, POINT_RADIUS_TEXT) ;
  pPointRadiusValue  = new NSUpDownEdit(this, pContexte, "", POINT_RADIUS_EDIT, POINT_RADIUS_UPDN) ;

  pSampleGroup   = new OWL::TGroupBox(this, SHADE_SAMPLE) ;
}
catch (...)
{
	erreur("Exception NSNewCurveDlg ctor.",  standardError, 0) ;
}
}

NSNewCurveDlg::~NSNewCurveDlg()
{
	delete pConceptGroup ;

	delete pType ;
  delete pUnitText ;
  delete pUnit ;

  delete pAxisPropertiesGroup ;

  delete pMinAxisText ;
  delete pMaxAxisText ;

  delete pMinAxisValue ;
  delete pMaxAxisValue ;

  delete pIncludeZeroBtn ;

  delete pLineColourGroup ;

  delete pRedText ;
  delete pGreenText ;
  delete pBlueText ;

  delete pRedValue ;
  delete pGreenValue ;
  delete pBlueValue ;

  delete pRedSampleColorBtn ;
  delete pGreenSampleColorBtn ;
  delete pYellowSampleColorBtn ;
  delete pBlueSampleColorBtn ;
  delete pMagentaSampleColorBtn ;
  delete pCyanSampleColorBtn ;

  delete pLineTypeGroup ;

  delete pWidthValue ;
  delete pWidthText ;

  delete pTSolid ;
  delete pTDash ;
  delete pTDot ;
  delete pTDashDot ;
  delete pTDashDotDot ;

  delete pPointTypeGroup ;

  delete pDynamicColouringBtn ;

  delete pPointAspectCircleBtn ;
  delete pPointAspectSquareBtn ;
  delete pPointAspectTriangleBtn ;
  delete pPointAspectStarBtn ;

  delete pPointRadiusText ;
  delete pPointRadiusValue ;

  delete pSampleGroup ;
}

void
NSNewCurveDlg::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

  // ------- Information group
  //

  if (pCurve->sItemValue != string(""))
		pType->setLabel(pCurve->sItemValue) ;
  if (pCurve->sUnit != string(""))
		pUnit->setLabel(pCurve->sUnit) ;

  // ------- Axis group
  //

  pMinAxisValue->setValue(pCurve->pAxis->_dLowAxisValue) ;
  pMaxAxisValue->setValue(pCurve->pAxis->_dHighAxisValue) ;

  if (pCurve->pAxis->_bIncludeZero)
  	pIncludeZeroBtn->SetCheck(BF_CHECKED) ;

  // ------- Line color group
  //
	pRedValue->setMinMaxValue(0, 255) ;
  pRedValue->setValue(pCurve->color.Red()) ;
  pRedValue->getEditNum()->SetLostFocusResponse(new MemFunctor<NSNewCurveDlg>( (NSNewCurveDlg*)this, &NSNewCurveDlg::drawExampleLine ));
  pRedValue->getUpDown()->SetLostFocusResponse(new MemFunctor<NSNewCurveDlg>( (NSNewCurveDlg*)this, &NSNewCurveDlg::drawExampleLine ));
  pGreenValue->setMinMaxValue(0, 255) ;
  pGreenValue->setValue(pCurve->color.Green()) ;
  pGreenValue->getEditNum()->SetLostFocusResponse(new MemFunctor<NSNewCurveDlg>( (NSNewCurveDlg*)this, &NSNewCurveDlg::drawExampleLine ));
  pGreenValue->getUpDown()->SetLostFocusResponse(new MemFunctor<NSNewCurveDlg>( (NSNewCurveDlg*)this, &NSNewCurveDlg::drawExampleLine ));
  pBlueValue->setMinMaxValue(0, 255) ;
  pBlueValue->setValue(pCurve->color.Blue()) ;
  pBlueValue->getEditNum()->SetLostFocusResponse(new MemFunctor<NSNewCurveDlg>( (NSNewCurveDlg*)this, &NSNewCurveDlg::drawExampleLine ));
  pBlueValue->getUpDown()->SetLostFocusResponse(new MemFunctor<NSNewCurveDlg>( (NSNewCurveDlg*)this, &NSNewCurveDlg::drawExampleLine ));

  // ------- Line style group
  //

  pWidthValue->setValue(pCurve->dotWidth) ;
  pWidthValue->getEditNum()->SetLostFocusResponse(new MemFunctor<NSNewCurveDlg>( (NSNewCurveDlg*)this, &NSNewCurveDlg::drawExampleLine ));
  pWidthValue->getUpDown()->SetLostFocusResponse(new MemFunctor<NSNewCurveDlg>( (NSNewCurveDlg*)this, &NSNewCurveDlg::drawExampleLine ));

  switch (pCurve->dotStyle)
  {
  	case PS_SOLID :
  		pTSolid->SetCheck(BF_CHECKED) ;
      break ;
    case PS_DASH :
    	pTDash->SetCheck(BF_CHECKED) ;
      break ;
    case PS_DOT :
    	pTDot->SetCheck(BF_CHECKED) ;
      break ;
    case PS_DASHDOT :
    	pTDashDot->SetCheck(BF_CHECKED) ;
      break ;
    case PS_DASHDOTDOT :
    	pTDashDotDot->SetCheck(BF_CHECKED) ;
      break ;
    default :
    	pTSolid->SetCheck(BF_CHECKED) ;
  }

  // ------- Point style group
  //

  pPointRadiusValue->setValue(pCurve->pointRadius) ;
  pPointRadiusValue->getEditNum()->SetLostFocusResponse(new MemFunctor<NSNewCurveDlg>( (NSNewCurveDlg*)this, &NSNewCurveDlg::drawExampleLine ));
  pPointRadiusValue->getUpDown()->SetLostFocusResponse(new MemFunctor<NSNewCurveDlg>( (NSNewCurveDlg*)this, &NSNewCurveDlg::drawExampleLine ));

  switch (pCurve->pointAspect)
  {
  	case NSLdvCurve::paCircle :
  		pPointAspectCircleBtn->SetCheck(BF_CHECKED) ;
      break ;
    case NSLdvCurve::paSquare :
    	pPointAspectSquareBtn->SetCheck(BF_CHECKED) ;
      break ;
    case NSLdvCurve::paTriangle :
    	pPointAspectTriangleBtn->SetCheck(BF_CHECKED) ;
      break ;
    case NSLdvCurve::paStar :
    	pPointAspectStarBtn->SetCheck(BF_CHECKED) ;
      break ;
    default :
    	pPointAspectCircleBtn->SetCheck(BF_CHECKED) ;
  }
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
void
NSNewCurveDlg::CmOk()
{
try
{
  if (!bModifyMode)
  {
  	// on r�cup�re d'abord un �ventuel �l�ment lexique s�lectionn� par les fl�ches
  	// Le Return n'envoie pas d'EvKeyDown et appelle directement CmOk
  	if (pType->pDico->pDicoDialog->EstOuvert())
  	{
    	pType->pDico->pDicoDialog->InsererElementLexique() ;
    	return ;
  	}

  	// Ne pas accepter les textes libres
  	if (pType->sCode == string("�?????"))
  	{
  		erreur("Il faut choisir un code lexique et non pas du texte libre ", standardError, 0, GetHandle()) ;
    	pType->SetFocus() ;
    	return ;
  	}

  	pCurve->sItemValue = pType->sCode ;
  }

  // idem for Unit
  //
  if (pUnit->pDico->pDicoDialog->EstOuvert())
  {
    pUnit->pDico->pDicoDialog->InsererElementLexique() ;
    return ;
  }

  // Ne pas accepter les textes libres
  if (pUnit->sCode == string("�?????"))
  {
  	erreur("Il faut choisir un code lexique et non pas du texte libre ", standardError, 0, GetHandle()) ;
    pUnit->SetFocus() ;
    return ;
  }

  // On v�rifie qu'un edit n'�tait pas en cours de saisie
  // Le Return n'envoie pas de KillFocus et appelle directement CmOk
  //
  killControlFocusOnReturnClose() ;

  pCurve->sUnit = pUnit->sCode ;

  // ------- Axis group
  //

  pCurve->pAxis->_dLowAxisValue  = pMinAxisValue->getValue() ;
  pCurve->pAxis->_dHighAxisValue = pMaxAxisValue->getValue() ;

  if (pIncludeZeroBtn->GetCheck() == BF_CHECKED)
		pCurve->pAxis->_bIncludeZero = true ;
  else
  	pCurve->pAxis->_bIncludeZero = false ;

  // ------- Line color group
  //
  int iRedColor = pRedValue->getValue() ;
  int iGreColor = pGreenValue->getValue() ;
  int iBluColor = pBlueValue->getValue() ;

  pCurve->color = NS_CLASSLIB::TColor(iRedColor, iGreColor, iBluColor);

  // ------- Line style group
  //

  // Dot size
  //
  pCurve->dotWidth = pWidthValue->getValue() ;

  // Dot type
  //
  pCurve->dotStyle = getDotStyle() ;

  // ------- Point style group
  //

  if (pDynamicColouringBtn->GetCheck() == BF_CHECKED)
		pCurve->bAdjustPointColorToValue = true ;
  else
  	pCurve->bAdjustPointColorToValue = false ;

  pCurve->pointRadius = pPointRadiusValue->getValue() ;

  pCurve->pointAspect = getPointStyle() ;

	CloseWindow(IDOK) ;
}
catch (...)
{
  erreur("Exception NSNewCurveDlg::CmOk.", standardError, 0) ;
}
}

void
NSNewCurveDlg::CmCancel()
{
	Destroy(IDCANCEL) ;
}

void
NSNewCurveDlg::ColorSample(WPARAM wParam)
{
	int iRed   = 0 ;
  int iGreen = 0 ;
  int iBlue  = 0 ;

	switch (wParam)
	{
  	case (COLORSAMPLE_RED) :
    	iRed   = 255 ;
      break ;
  	case (COLORSAMPLE_GREEN) :
    	iGreen = 255 ;
      break ;
    case (COLORSAMPLE_YELLOW) :
    	iRed   = 255 ;
    	iGreen = 255 ;
      break ;
    case (COLORSAMPLE_BLUE) :
    	iBlue  = 255 ;
      break ;
    case (COLORSAMPLE_MAGENTA) :
    	iRed   = 255 ;
    	iBlue  = 255 ;
      break ;
    case (COLORSAMPLE_CYAN) :
    	iGreen = 255 ;
    	iBlue  = 255 ;
      break ;
  }

  pRedValue->setValue(iRed) ;
  pGreenValue->setValue(iGreen) ;
  pBlueValue->setValue(iBlue) ;

  drawExampleLine() ;
}

void
NSNewCurveDlg::DotStyle(WPARAM wParam)
{
	switch (wParam)
	{
  	case (TYPE_DASH) :
  	case (TYPE_DOT) :
    case (TYPE_DASHDOT) :
    case (TYPE_DASHDOTDOT) :
    	pWidthValue->setValue(1) ;
      break ;
  }

  drawExampleLine() ;
}

void
NSNewCurveDlg::PointAspect(WPARAM wParam)
{
	drawExampleLine() ;
}

void
NSNewCurveDlg::drawExampleLine()
{
	// Get information
  //
	int iRedColor = pRedValue->getValue() ;
  int iGreColor = pGreenValue->getValue() ;
  int iBluColor = pBlueValue->getValue() ;

  int iDotStyle = getDotStyle() ;

  int iDotWidth = pWidthValue->getValue() ;

  int iPtRadius = pPointRadiusValue->getValue() ;
  int iPtStyle  = getPointStyle() ;

  // Draw sample
  //
	NS_CLASSLIB::TRect groupScreenRect  = pSampleGroup->GetWindowRect() ;
  NS_CLASSLIB::TRect dialogScreenRect = GetWindowRect() ;
  NS_CLASSLIB::TPoint upperLeftPoint(groupScreenRect.Left() - dialogScreenRect.Left(), groupScreenRect.Top() - dialogScreenRect.Top()) ;
  NS_CLASSLIB::TRect groupRect(upperLeftPoint.X(),
                               upperLeftPoint.Y(),
                               upperLeftPoint.X() + groupScreenRect.Width(),
                               upperLeftPoint.Y() + groupScreenRect.Height()) ;
  NS_CLASSLIB::TRect drawingRect(groupRect.Left() + 3, groupRect.Top() + 3, groupRect.Right() - 3, groupRect.Bottom() - 3) ;

  TWindowDC* pWinDC = new TWindowDC(this->HWindow) ; // HWnd

  // Draw a white background
  //
  pWinDC->FillRect(drawingRect, NS_CLASSLIB::TColor::White) ;

  // Prepare pen and brush
  //
  OWL::TPen curvePen(NS_CLASSLIB::TColor(iRedColor, iGreColor, iBluColor), iDotWidth, iDotStyle) ;
  ::SelectObject(pWinDC->GetHDC(), curvePen) ;

  OWL::TBrush curvePointsBrush(NS_CLASSLIB::TColor(iRedColor, iGreColor, iBluColor)) ;
  ::SelectObject(pWinDC->GetHDC(), curvePointsBrush) ;

  // Draw the line
  //
  NS_CLASSLIB::TPoint leftLinePoint(drawingRect.Left() + 3, groupRect.Top() + groupRect.Height() / 2) ;
  NS_CLASSLIB::TPoint rightLinePoint(drawingRect.Right() - 3, leftLinePoint.Y()) ;

  pWinDC->MoveTo(leftLinePoint) ;
  pWinDC->LineTo(rightLinePoint) ;

  // Draw some points
  //
  NSLdvViewArea* pActiveWorkingArea = pCurve->getCurvesPannel()->pView->getActiveWorkingArea() ;
  if (NULL == pActiveWorkingArea)
    return ;

  NSHistoryValueManagement historyValue ;
  historyValue.setDate(string("20060723115410")) ;
  NSLdvCurvePoint curvePoint(pContexte, pActiveWorkingArea, pCurve, &historyValue) ;

  int iNbSamples = 3 ;
  int iLineLenght = rightLinePoint.X() - leftLinePoint.X() ;

  for (int i = 0 ; i < iNbSamples ; i++)
  {
  	NS_CLASSLIB::TPoint samplePoint(leftLinePoint.X() + (i + 1) * iLineLenght / (iNbSamples + 1), leftLinePoint.Y()) ;

  	NS_CLASSLIB::TRect pointDrawingBox(samplePoint.X() - iPtRadius,
                                       samplePoint.Y() - iPtRadius,
                                       samplePoint.X() + iPtRadius,
                                       samplePoint.Y() + iPtRadius) ;

  	switch(iPtStyle)
  	{
  		case NSLdvCurve::paCircle :
    		curvePoint.drawPointCircle(pWinDC, pointDrawingBox, &curvePointsBrush, &curvePen) ;
      	break ;
    	case NSLdvCurve::paSquare :
    		curvePoint.drawPointSquare(pWinDC, pointDrawingBox, &curvePointsBrush, &curvePen) ;
      	break ;
    	case NSLdvCurve::paTriangle :
    		curvePoint.drawPointUpTriangle(pWinDC, pointDrawingBox, &curvePointsBrush, &curvePen) ;
      	break ;
    	case NSLdvCurve::paStar :
    		curvePoint.drawPointStar(pWinDC, pointDrawingBox, &curvePointsBrush, &curvePen) ;
      	break ;
  	}
  }

	delete pWinDC ;
}

int
NSNewCurveDlg::getDotStyle()
{
	if      (pTSolid->GetCheck()      == BF_CHECKED)
  	return PS_SOLID ;
  else if (pTDash->GetCheck()       == BF_CHECKED)
  	return PS_DASH ;
  else if (pTDot->GetCheck()        == BF_CHECKED)
  	return PS_DOT ;
  else if (pTDashDot->GetCheck()    == BF_CHECKED)
  	return PS_DASHDOT ;
  else if (pTDashDotDot->GetCheck() == BF_CHECKED)
  	return PS_DASHDOTDOT ;

  return PS_SOLID ;
}

int
NSNewCurveDlg::getPointStyle()
{
	if      (pPointAspectCircleBtn->GetCheck()   == BF_CHECKED)
  	return NSLdvCurve::paCircle ;
  else if (pPointAspectSquareBtn->GetCheck()   == BF_CHECKED)
  	return NSLdvCurve::paSquare ;
  else if (pPointAspectTriangleBtn->GetCheck() == BF_CHECKED)
  	return NSLdvCurve::paTriangle ;
  else if (pPointAspectStarBtn->GetCheck()     == BF_CHECKED)
  	return NSLdvCurve::paStar ;

  return NSLdvCurve::paCircle ;
}

// -----------------------------------------------------------------
//
//  M�thodes de NSConvocDlg
//
// -----------------------------------------------------------------
// -----------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSConvocDlg, NSUtilDialog)
	EV_COMMAND(IDOK,        CmOk),
	EV_COMMAND(IDCANCEL,    CmCancel),
END_RESPONSE_TABLE;

NSConvocDlg::NSConvocDlg(TWindow* pPere, NSContexte* pCtx, NVLdVTemps* pDeb)
            :NSUtilDialog(pPere, pCtx, "CONVOC_DLG")
{
try
{
	ptpsDeb     = pDeb ;
	pDateDeb    = new NSUtilEditDateHeure(pContexte, this, PROB_DATE_DEB) ;

	pNbJoursTxt = new OWL::TStatic(this, IDR_DRG_DANS) ;
  pNbJours    = new NSEditNum(pContexte, this, IDC_DRG_NBJOURS, 10) ;

  char *temp1[] = {"2HEUR1", "2DAT01", "2DAT11", "2DAT21"} ;
  pCBDureeTtt    = new NSComboBox(this, IDC_DRG_NBJOURS_TXT, pContexte, temp1) ;
  pCBDureeTtt->SetLostFocusResponse(new MemFunctor<NSConvocDlg>((NSConvocDlg*)this, &NSConvocDlg::ExecutedAfterDelayChoiceDate)) ;
}
catch (...)
{
	erreur("Exception NSConvocDlg ctor.", standardError, 0) ;
}
}

NSConvocDlg::~NSConvocDlg()
{
  delete pDateDeb ;
  delete pNbJoursTxt ;
  delete pNbJours ;
  delete pCBDureeTtt ;
}

void
NSConvocDlg::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	string sDateDeb = ptpsDeb->donneDateHeure() ;
	pDateDeb->setDate(sDateDeb.c_str()) ;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
void
NSConvocDlg::CmOk()
{
try
{
  // On v�rifie qu'un edit n'�tait pas en cours de saisie
  // Le Return n'envoie pas de KillFocus et appelle directement CmOk
  //
  killControlFocusOnReturnClose() ;

	string sDDeb ;
	pDateDeb->getDate(&sDDeb) ;
	ptpsDeb->initFromDateHeure(sDDeb) ;

	CloseWindow(IDOK) ;
}
catch (...)
{
	erreur("Exception NSConvocDlg::CmOk.", standardError, 0) ;
}
}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
void
NSConvocDlg::CmCancel()
{
	Destroy(IDCANCEL) ;
}

void
NSConvocDlg::ExecutedAfterDelayChoiceDate()
{
	pNbJours->donneValeur() ;
	int iTrtDurationValue = (int) pNbJours->dValeur ;
	if (iTrtDurationValue <= 0)
		return ;

	string sTrtDurationUnit = pCBDureeTtt->getSelCode() ;
	if (string("") == sTrtDurationUnit)
		return ;

	NVLdVTemps tDateFin ;
	tDateFin.takeTime() ;

	tDateFin.ajouteTemps(iTrtDurationValue, sTrtDurationUnit, pContexte) ;
	string sDateFin = tDateFin.donneDateHeure() ;

  pDateDeb->setDate(sDateFin) ;
}

// fin de nsldvvar.cpp
/////////////////////////////////////////////////////

