// -----------------------------------------------------------------------------
//                  Ligne de vie - Vue du mod�le Document/Vue
// -----------------------------------------------------------------------------

#include <vcl.h>
#include <owl\owlpch.h>
#include <owl\dc.h>

#include "nautilus\nssuper.h"
#include "dcodeur\nsdkd.h"
#include "dcodeur\nsgen.h"

#include "nautilus\nautilus.rh"
#include "nautilus\nsadmiwd.h"
#include "nsbb\nstlibre.h"

#include "nsepisod\nsepidiv.h"

#include "nautilus\nshistdo.h"
#include "nautilus\nstrihis.h"
#include "nautilus\nsepicap.h"

#include <windows.h>
#include <owl\scrollba.h>

#include "nssavoir\nsgraphe.h"
#include "nssavoir\nsconver.h"

#include "nsbb\nsattvaltools.h"
#include "nautilus\nsldvvue.rh"
#include "nautilus\nsldvvue.h"
#include "nautilus\nsldvvuetech.h"

#include "nautilus\nsldvgoal.h"

#define VSCROLLBAR_ID 301

// -----------------------------------------------------------------------------
//                              NSLdvWindowToon
// -----------------------------------------------------------------------------

NSLdvWindowToon::NSLdvWindowToon(NSContexte* pCtx, NSLdvWindowToon* parent, NSLdvView* pTheView)
                :NSLdvToon(pCtx, pTheView)
{
	toonCategory = windowToon ;

  pInterface   = 0 ;
  pParent      = parent ;

  bLeftSet   = false ;
  bRightSet  = false ;
  bTopSet    = false ;
  bBottomSet = false ;

  iLeftValue   = 0 ;
  iRightValue  = 0 ;
  iTopValue    = 0 ;
  iBottomValue = 0 ;

  bWidthSet    = false ;
  bFixedWidth  = false ;
  iWidthValue  = 0 ;
  bHeightSet   = false ;
  bFixedHeight = false ;
  iHeightValue = 0 ;

  registerAsToon() ;
}


NSLdvWindowToon::NSLdvWindowToon(NSLdvWindowToon& rv)
                :NSLdvToon(rv.pContexte, rv.pView)
{
	initialiser(&rv) ;
}

void
NSLdvWindowToon::initialiser(NSLdvWindowToon* pSrc)
{
  NSLdvToon::initialiser((NSLdvToon*)(pSrc)) ;

  pInterface   = pSrc->pInterface ;
  pParent      = pSrc->pParent ;
	// wBox        = pSrc->wBox ;
	// wVisibleBox = pSrc->wVisibleBox ;
  sSkinName    = pSrc->sSkinName ;

  bLeftSet     = pSrc->bLeftSet ;
  bRightSet    = pSrc->bRightSet ;
  bTopSet      = pSrc->bTopSet ;
  bBottomSet   = pSrc->bBottomSet ;

  iLeftValue   = pSrc->iLeftValue ;
  iRightValue  = pSrc->iRightValue ;
  iTopValue    = pSrc->iTopValue ;
  iBottomValue = pSrc->iBottomValue ;

  bWidthSet    = pSrc->bWidthSet ;
  bFixedWidth  = pSrc->bFixedWidth ;
  iWidthValue  = pSrc->iWidthValue ;
  bHeightSet   = pSrc->bHeightSet ;
  bFixedHeight = pSrc->bFixedHeight ;
  iHeightValue = pSrc->iHeightValue ;
}

void
NSLdvWindowToon::registerAsToon()
{
  if ((NULL == pParent) && (NULL == pView))
    return ;

  if (NULL == pParent)
  {
    pView->aToons.push_back(this) ;
    return ;
  }

  pParent->aToons.push_back(this) ;
}

bool
NSLdvWindowToon::Touches(NS_CLASSLIB::TRect rect)
{
  NS_CLASSLIB::TRect visibleBox = donneVisibleRectangle() ;

	return ((rect.Right()  >= visibleBox.Left())  &&
          (rect.Left()   <= visibleBox.Right()) &&
          (rect.Bottom() >= visibleBox.Top())   &&
          (rect.Top()    <= visibleBox.Bottom())) ;
}

bool
NSLdvWindowToon::Contains(const NS_CLASSLIB::TPoint& point)
{
  NS_CLASSLIB::TRect visibleBox = donneVisibleRectangle() ;

  return visibleBox.Contains(point) ;
}

NS_CLASSLIB::TRect
NSLdvWindowToon::donneRectangle()
{
  NS_CLASSLIB::TRect theoreticalBox(iLeftValue, iTopValue, iRightValue, iBottomValue) ;
  return theoreticalBox ;
}

NS_CLASSLIB::TRect
NSLdvWindowToon::donneVisibleRectangle()
{
  NS_CLASSLIB::TRect VisibleBox(0, 0, 0, 0) ;

  if ((NULL != pInterface) && (true == pInterface->IsWindow()))
  {
    VisibleBox = pInterface->GetClientRect() ;
  	return VisibleBox ;
  }

  if (true == isPosValid())
    VisibleBox = donneRectangle() ;

  return VisibleBox ;
}

void
NSLdvWindowToon::resetPos()
{
  bLeftSet   = false ;
  bRightSet  = false ;
  bTopSet    = false ;
  bBottomSet = false ;

  iLeftValue   = -1 ;
  iRightValue  = -1 ;
  iTopValue    = -1 ;
  iBottomValue = -1 ;

  if (false == bFixedWidth)
  {
    bWidthSet   = false ;
    iWidthValue = -1 ;
  }
  if (false == bFixedHeight)
  {
    bHeightSet   = false ;
    iHeightValue = -1 ;
  }
}

bool
NSLdvWindowToon::isPosValid()
{
  return bLeftSet && bRightSet && bTopSet && bBottomSet ;
}

void
NSLdvWindowToon::initDimensions()
{
  nsSkin* pSkin = pContexte->getSkins()->donneSkin(sSkinName) ;
  if (NULL == pSkin)
  	return ;

  // Absolute values
  //
  nsBoxPosition* pBoxPos = pSkin->getBoxPosition() ;
  if (NULL != pBoxPos)
  {
    if (string("PIX") == pBoxPos->getWidthUnit())
    {
      iWidthValue = pBoxPos->getWidthValue() ;
      bWidthSet   = true ;
      bFixedWidth = true ;
    }
    if (string("PIX") == pBoxPos->getHeightUnit())
    {
      iHeightValue = pBoxPos->getHeightValue() ;
      bHeightSet   = true ;
      bFixedHeight = true ;
    }
    if ((true == bWidthSet) && (true == bHeightSet))
      return ;
  }

  // Skin dependant values
  //
  OWL::TDib* pDrawing = pSkin->getBackBmp() ;
  if (NULL == pDrawing)
    return ;

  int iDibHeight = pDrawing->Height() ;
  if (iDibHeight < 0)
  	iDibHeight = - iDibHeight ;

  int iDibWidth  = pDrawing->Width() ;
  if (iDibWidth < 0)
  	iDibWidth = - iDibWidth ;

  if (pSkin->getBackDraw() == nsSkin::DrawAsForm)
  {
    iWidthValue = iDibWidth ;
    bWidthSet   = true ;
    bFixedWidth = true ;

    iHeightValue = iDibHeight ;
    bHeightSet   = true ;
    bFixedHeight = true ;
  }

  if (NULL == pBoxPos)
    return ;

  if (string(FOCUS_SKIN) == pBoxPos->getWidthUnit())
  {
    iWidthValue = iDibWidth ;
    bWidthSet   = true ;
    bFixedWidth = true ;
  }
  if (string(FOCUS_SKIN) == pBoxPos->getHeightUnit())
  {
    iHeightValue = iDibHeight ;
    bHeightSet   = true ;
    bFixedHeight = true ;
  }
}

bool
NSLdvWindowToon::initBoxFromSkin()
{
/*
	nsSkin* pSkin = pContexte->getSkins()->donneSkin(sSkinName) ;

  if ((NULL == pSkin) || !pSkin->getBackBmp() || (pSkin->getBackDraw() != nsSkin::DrawAsForm))
  	return false ;

	OWL::TDib* pDrawing = pSkin->getBackBmp() ;

  int iDibHeight = pDrawing->Height() ;
  if (iDibHeight < 0)
  	iDibHeight = - iDibHeight ;

  int iDibWidth  = pDrawing->Width() ;
  if (iDibWidth < 0)
  	iDibWidth = - iDibWidth ;

  // Full width: only dib's height is taken into account
  //
  if (toonShape == toonFullWidth)
  {
  	wVisibleBox = NS_CLASSLIB::TRect(0, 0, 10000, iDibHeight) ;
    return true ;
  }
  //
  // Full height: only dib's width is taken into account
  //
  if (toonShape == toonFullHeight)
  {
  	wVisibleBox = NS_CLASSLIB::TRect(0, 0, iDibWidth, 100000) ;
    return true ;
  }
  //
  // Limited: both width and height are taken into account
  //
  if (toonShape == toonSizeLimited)
  {
  	wVisibleBox = NS_CLASSLIB::TRect(0, 0, iDibWidth, iDibHeight) ;
    return true ;
  }
*/

  return false ;
}

void
NSLdvWindowToon::calculateWidthValue()
{
  if ((false == bLeftSet) || (false == bRightSet) || (true == bWidthSet))
    return ;

  iWidthValue = iRightValue - iLeftValue ;
  bWidthSet   = true ;
}

void
NSLdvWindowToon::calculateHeightValue()
{
  if ((false == bTopSet) || (false == bBottomSet) || (true == bHeightSet))
    return ;

  iHeightValue = iTopValue - iBottomValue ;
  bHeightSet   = true ;
}

void
NSLdvWindowToon::calculateLeftValue()
{
  if ((false == bRightSet) || (false == bWidthSet) || (true == bLeftSet))
    return ;

  iLeftValue = iRightValue - iWidthValue ;
  bLeftSet   = true ;
}

void
NSLdvWindowToon::calculateRightValue()
{
  if ((false == bLeftSet) || (false == bWidthSet) || (true == bRightSet))
    return ;

  iRightValue = iLeftValue + iWidthValue ;
  bRightSet   = true ;
}

void
NSLdvWindowToon::calculateTopValue()
{
  if ((false == bHeightSet) || (false == bBottomSet) || (true == bTopSet))
    return ;

  iTopValue = iBottomValue + iHeightValue ;
  bTopSet   = true ;
}

void
NSLdvWindowToon::calculateBottomValue()
{
  if ((false == bTopSet) || (false == bHeightSet) || (true == bBottomSet))
    return ;

  iBottomValue = iTopValue - iHeightValue ;
  bBottomSet   = true ;
}

void
NSLdvWindowToon::draw(TDC* pDc, NVLdVRect* pRectARepeindre)
{
	NS_CLASSLIB::TRect screenRect = pView->getGlobalPhysicalRect(*pRectARepeindre) ;
  draw(pDc, &screenRect) ;
}

void
NSLdvWindowToon::draw(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
	skinDraw(pDc, pRectARepeindre) ;
}

void
NSLdvWindowToon::skinDraw(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
	if ((string("") == sSkinName) || (NULL == pInterface) || (false == pInterface->IsWindow()))
  	return ;

	nsSkin* pSkin = pContexte->getSkins()->donneSkin(sSkinName) ;

  if (NULL == pSkin)
		return ;

  if (nsSkin::DrawAsForm == pSkin->getBackDraw())
    skinDrawForm(pDc, pRectARepeindre) ;
  if (nsSkin::DrawTile   == pSkin->getBackDraw())
    skinDrawTile(pDc, pRectARepeindre) ;
}

void
NSLdvWindowToon::skinDrawForm(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
  if ((string("") == sSkinName) || (NULL == pInterface) || (false == pInterface->IsWindow()))
  	return ;

	nsSkin* pSkin = pContexte->getSkins()->donneSkin(sSkinName) ;

  if (NULL == pSkin)
		return ;

  NS_CLASSLIB::TRect clientRect = pInterface->GetClientRect() ;

	OWL::TDib* pBackgrnd = pSkin->getBackBmp() ;
  if (!pBackgrnd)
		return ;

  NS_CLASSLIB::TPoint dibOrigin ;
  bool bBottomUp ;

  //
  // Bottom up dib : origin lies at the lower left corner
  //
  if (pBackgrnd->Height() > 0)
  {
  	bBottomUp = true ;
    dibOrigin = NS_CLASSLIB::TPoint(0, 0) ;
  }
  //
  // top down dib : origin lies at the upper left corner
  //
  else
  {
  	bBottomUp = false ;
    dibOrigin = NS_CLASSLIB::TPoint(0, 0) ;
  }

  pDc->SetDIBitsToDevice(clientRect, dibOrigin, *pBackgrnd) ;
}

void
NSLdvWindowToon::skinDrawTile(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
  if ((string("") == sSkinName) || (NULL == pInterface) || (false == pInterface->IsWindow()))
  	return ;

	nsSkin* pSkin = pContexte->getSkins()->donneSkin(sSkinName) ;

  if (NULL == pSkin)
		return ;

  NS_CLASSLIB::TRect clientRect = pInterface->GetClientRect() ;

	OWL::TDib* pBackgrnd = pSkin->getBackBmp() ;
  if (!pBackgrnd)
		return ;

  NS_CLASSLIB::TPoint dibOrigin ;
  bool bBottomUp ;

  //
  // Bottom up dib : origin lies at the lower left corner
  //
  if (pBackgrnd->Height() > 0)
  {
  	bBottomUp = true ;
    dibOrigin = NS_CLASSLIB::TPoint(0, 0) ;
  }
  //
  // top down dib : origin lies at the upper left corner
  //
  else
  {
  	bBottomUp = false ;
    dibOrigin = NS_CLASSLIB::TPoint(0, 0) ;
  }

  int iTop  = clientRect.Top() ;
  int iLeft = clientRect.Left() ;
  int x = 0 ;
  int y = 0 ;
  while (y < clientRect.Height())
  {
  	while (x < clientRect.Width())
    {
      int iWidthToPaint  = pBackgrnd->Width() ;
      if (x + iWidthToPaint > clientRect.Width())
        iWidthToPaint = clientRect.Width() - x ;

      int iHeightToPaint = pBackgrnd->Height() ;
      if (y + iHeightToPaint > clientRect.Height())
        iHeightToPaint = clientRect.Height() - y ;

    	NS_CLASSLIB::TRect drawRect = NS_CLASSLIB::TRect(x + iLeft, y + iTop, x + iLeft + iWidthToPaint, y + iTop + iHeightToPaint) ;
      pDc->SetDIBitsToDevice(drawRect, dibOrigin, *pBackgrnd) ;

      x += pBackgrnd->Width() ;
    }
    if (bBottomUp)
    	y += pBackgrnd->Height() ;
    else
    	y -= pBackgrnd->Height() ;

    x = 0 ;
  }

	// ---------------------------------------------------------------------------
	// Restauration des objets initiaux (pen et brush)
	// ::SelectObject(pDc->GetHDC(), oldPen);
	// ::SelectObject(pDc->GetHDC(), oldBrush);
}

/*
void
NSLdvWindowToon::skinDraw(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
	if (string("") == sSkinName)
  	return ;

	nsSkin* pSkin = pContexte->getSkins()->donneSkin(sSkinName) ;

  if (NULL == pSkin)
		return ;

	NS_CLASSLIB::TRect clientRect = pView->GetClientRect() ;

	OWL::TDib* pBackgrnd = pSkin->getBackBmp() ;
  if (!pBackgrnd)
		return ;

	wBox = NS_CLASSLIB::TRect(0, 0, clientRect.Width(), pBackgrnd->Height()) ;

  NS_CLASSLIB::TPoint dibOrigin ;
  bool bBottomUp ;

  //
  // Bottom up dib : origin lies at the lower left corner
  //
  if (pBackgrnd->Height() > 0)
  {
  	bBottomUp = true ;
    dibOrigin = NS_CLASSLIB::TPoint(0, 0) ;
  }
  //
  // top down dib : origin lies at the upper left corner
  //
  else
  {
  	bBottomUp = false ;
    dibOrigin = NS_CLASSLIB::TPoint(0, 0) ;
  }

  NS_CLASSLIB::TRect winRect = wVisibleBox ;

  int iTop  = wVisibleBox.Top() ;
  int iLeft = wVisibleBox.Left() ;
  int x = 0 ;
  int y = 0 ;
  while (y < wVisibleBox.Height())
  {
  	while (x < wVisibleBox.Width())
    {
      int iWidthToPaint  = pBackgrnd->Width() ;
      if (x + iWidthToPaint > winRect.Width())
        iWidthToPaint = winRect.Width() - x ;

      int iHeightToPaint = pBackgrnd->Height() ;
      if (y + iHeightToPaint > winRect.Height())
        iHeightToPaint = winRect.Height() - y ;

    	NS_CLASSLIB::TRect drawRect = NS_CLASSLIB::TRect(x + iLeft, y + iTop, x + iLeft + iWidthToPaint, y + iTop + iHeightToPaint) ;
      pDc->SetDIBitsToDevice(drawRect, dibOrigin, *pBackgrnd) ;

      x += pBackgrnd->Width() ;
    }
    if (bBottomUp)
    	y += pBackgrnd->Height() ;
    else
    	y -= pBackgrnd->Height() ;

    x = 0 ;
  }

	// ---------------------------------------------------------------------------
	// Restauration des objets initiaux (pen et brush)
	// ::SelectObject(pDc->GetHDC(), oldPen);
	// ::SelectObject(pDc->GetHDC(), oldBrush);
}
*/

bool
NSLdvWindowToon::MoveWindow(bool repaint)
{
  if (false == isPosValid())
    return false ;

  NS_CLASSLIB::TRect ToonRect = donneRectangle()  ;
  if (NULL == pParent)
    ToonRect = pView->getGlobalPhysicalRect(ToonRect) ;
  else
  {
    ToonRect = pParent->getRelativeRect(ToonRect) ;
    ToonRect = pParent->getRectForDraw(&ToonRect) ;
  }

  bool bMoveResult = MoveWindow(ToonRect, repaint) ;

  if (true == bMoveResult)
    setScrollParams() ;

  return bMoveResult ;
}

bool
NSLdvWindowToon::MoveWindow(const NS_CLASSLIB::TRect& rect, bool repaint)
{
  if ((NULL == pInterface) || (false == pInterface->IsWindow()))
    return false ;

  return pInterface->MoveWindow(rect, repaint) ;
}

void
NSLdvWindowToon::EvaluateWinToonsPos()
{
  if ((NULL == pInterface) || (false == pInterface->IsWindow()))
    return ;

  pView->EvaluateWinToonsPos(pInterface, &aToons) ;
}

int
NSLdvWindowToon::getYValueFromChildYValue(int iLdVYValue, TWindow* pChild)
{
  if ((NULL == pChild) || (false == pChild->IsWindow()))
    return iLdVYValue ;

  NS_CLASSLIB::TRect screenRect      = pInterface->GetWindowRect() ;
  NS_CLASSLIB::TRect childScreenRect = pChild->GetWindowRect() ;

  int iReturnValue = iLdVYValue + screenRect.Bottom() - childScreenRect.Bottom() ;

  // If it is a working area, take scrolling into account
  //
  if (toonWorkingArea == toonType)
  {
    NSLdvViewArea *pWorkArea = TYPESAFE_DOWNCAST(this, NSLdvViewArea) ;
    if (NULL != pWorkArea)
      iReturnValue += pWorkArea->getPosInfDroit() ;
  }

  return iReturnValue ;
}

int
NSLdvWindowToon::getWindowYValueFromLdVYValue(int iLdVYValue)
{
	// First, for windows, Y = 0 is on top of the screen, while it is on the
  // bottom of the chronoLine for the LdV. We have to reverse it.
  //
  NS_CLASSLIB::TRect clientRect = GetClientRect() ;
  int iWinYValue = clientRect.Height() - iLdVYValue ;

  // Then, the LdV can be scrolled of a lPosInfDroit quantity
  //
  // iWinYValue += pView->getPosInfDroit() ;

  return iWinYValue ;
}

NS_CLASSLIB::TRect
NSLdvWindowToon::getScreenRectFromLdvRect(NVLdVRect* pLdvRect)
{
  NS_CLASSLIB::TPoint ptTopLeft = pView->getGlobalPhysicalPoint(pLdvRect->TopLeft()) ;
	NS_CLASSLIB::TPoint ptBotRigh = pView->getGlobalPhysicalPoint(pLdvRect->BottomRight()) ;

  NS_CLASSLIB::TRect screenRect(ptTopLeft.x, ptTopLeft.y, ptBotRigh.x, ptBotRigh.y) ;

  return screenRect ;
}

NS_CLASSLIB::TRect
NSLdvWindowToon::getScreenRect(NS_CLASSLIB::TRect *pFixedRect)
{
  return NS_CLASSLIB::TRect(0, 0, 0, 0) ;
}

// Window's reference frame has top-left as origin, while ldv has bottom-left
//
NS_CLASSLIB::TPoint
NSLdvWindowToon::getPointForDraw(NS_CLASSLIB::TPoint *pLdvPoint)
{
  NS_CLASSLIB::TPoint windowsFramePoint = *pLdvPoint ;

  if ((NULL == pInterface) || (false == pInterface->IsWindow()))
  {
    windowsFramePoint.y = iHeightValue - windowsFramePoint.y ;
    return windowsFramePoint ;
  }

  NS_CLASSLIB::TRect clientRect = pInterface->GetClientRect() ;
  windowsFramePoint.y = clientRect.Height() - windowsFramePoint.y ;

  return windowsFramePoint ;
}

NS_CLASSLIB::TRect
NSLdvWindowToon::getRectForDraw(NS_CLASSLIB::TRect *pLdvRect)
{
  NS_CLASSLIB::TPoint ptTopLeft = getPointForDraw(&(pLdvRect->TopLeft())) ;
	NS_CLASSLIB::TPoint ptBotRigh = getPointForDraw(&(pLdvRect->BottomRight())) ;

  return NS_CLASSLIB::TRect(ptTopLeft, ptBotRigh) ;
}

NS_CLASSLIB::TPoint
NSLdvWindowToon::getPointForDraw(NVLdVPoint ldvPoint)
{
  NS_CLASSLIB::TPoint physicalPoint(0, 0) ;

  if ((NULL == pView) || (NULL == pInterface) || (false == pInterface->IsWindow()))
    return physicalPoint ;

  // For time, the reference is given by the right side of Chronoline
  //
  NSLdvChronoLine* pChronoLine = pView->getLdVChronoLine() ;
  if (NULL == pChronoLine)
    return physicalPoint ;

  NS_CLASSLIB::TRect ChronoRect = pChronoLine->donneVisibleRectangle() ;
  NS_CLASSLIB::TRect ThisRect   = donneVisibleRectangle() ;
  int iDeltaRight = ThisRect.Right() - ChronoRect.Right() ;

	// On place le point en bas � droite
	// Instantiating the point as clientRect bottom right point
  //
	NS_CLASSLIB::TRect clientRect = pInterface->GetClientRect() ;
	physicalPoint = clientRect.BottomRight() ;

	// Translation du point
	// Translating the point

	NVLdVRect ldvRect(pView,
										ldvPoint.getX(),
										pView->getDateHeureInfDroit(),
										0, // lPosInfDroit,
										ldvPoint.getY()) ;

	physicalPoint.x -= pView->getPhysicalWidthFromTimeUnit(ldvRect.Width()) ;
  physicalPoint.x -= iDeltaRight ;

  if (physicalPoint.x > numeric_limits<int>::max())
  	physicalPoint.x = numeric_limits<int>::max() ;
  if (physicalPoint.x < - numeric_limits<int>::max())
  	physicalPoint.x = - numeric_limits<int>::max() ;

	physicalPoint.y += ldvRect.Height() ;

  if (physicalPoint.y > numeric_limits<int>::max())
  	physicalPoint.y = numeric_limits<int>::max() ;
  if (physicalPoint.y < - numeric_limits<int>::max())
  	physicalPoint.y = - numeric_limits<int>::max() ;

	return physicalPoint ;
}

NS_CLASSLIB::TRect
NSLdvWindowToon::getRectForDraw(NVLdVRect ldvRect)
{
	NS_CLASSLIB::TPoint ptTopLeft = getPointForDraw(ldvRect.TopLeft()) ;
	NS_CLASSLIB::TPoint ptBotRigh = getPointForDraw(ldvRect.BottomRight()) ;

  return NS_CLASSLIB::TRect(ptTopLeft, ptBotRigh) ;
}

NS_CLASSLIB::TPoint
NSLdvWindowToon::getRelativePoint(NS_CLASSLIB::TPoint ldvPoint)
{
  // Local reference frame is bottom-left
  NS_CLASSLIB::TRect  viewRect = donneRectangle() ;
  NS_CLASSLIB::TPoint ptResult = NS_CLASSLIB::TPoint(ldvPoint.X() - viewRect.Left(), ldvPoint.Y() - viewRect.Bottom()) ;

  return ptResult ;
}

NS_CLASSLIB::TRect
NSLdvWindowToon::getRelativeRect(NS_CLASSLIB::TRect ldvRect)
{
	NS_CLASSLIB::TPoint ptTopLeft = getRelativePoint(ldvRect.TopLeft()) ;
	NS_CLASSLIB::TPoint ptBotRigh = getRelativePoint(ldvRect.BottomRight()) ;

  return NS_CLASSLIB::TRect(ptTopLeft, ptBotRigh) ;
}

TWindow*
NSLdvWindowToon::getParentInterface()
{
  if (NULL == pParent)
    return pView ;

  return pParent->getInterface() ;
}

/*
NSLdvVerticalScrollBar*
NSLdvWindowToon::getVerticalScroll()
{
  if (aToons.empty())
    return NULL ;

  for (ToonsIter toonIter = aToons.begin() ; aToons.end() != toonIter ; toonIter++)
  {
    if (NSLdvToon::toonVerticalScroll == (*toonIter)->getType())
    {
      NSLdvVerticalScrollBar *pVScroll = TYPESAFE_DOWNCAST(*toonIter, NSLdvVerticalScrollBar) ;
      if (NULL != pVScroll)
        return pVScroll ;
    }
  }

  return NULL ;
}
*/

// -----------------------------------------------------------------------------
// ------------------- METHODES DE NSLdvCommandPannel --------------------------
// -----------------------------------------------------------------------------

NSLdvCommandPannel::NSLdvCommandPannel(NSContexte* pCtx, NSLdvWindowToon* pLdvParent, NSLdvView* pTheView)
                   :NSLdvWindowToon(pCtx, pLdvParent, pTheView)
{
	iZOrder   = LEVEL_COMMANDS ;
  toonType  = toonPannel ;
  // toonShape = toonFullWidth ;
  sSkinName = string("LdvCommandPannel") ;

  initDimensions() ;
  // if (!initBoxFromSkin())
	//	wVisibleBox = pView->getDateTimeArea() ;
  // else
  //	pView->setDateTimeArea(wVisibleBox) ;

  pInterface = new NSLdvCommandPannelInterface(pContexte, getParentInterface(), this) ;

	// pSeverityThresholdSlider = 0 ;
  // pDrugsDisplayOnOff       = 0 ;
  // pCompressedMode          = 0 ;
}


NSLdvCommandPannel::NSLdvCommandPannel(NSLdvCommandPannel& rv)
                   :NSLdvWindowToon(rv.pContexte, rv.getToonParent(), rv.pView)
{
	initialiser((NSLdvWindowToon*)(&rv)) ;
}


NSLdvCommandPannel::~NSLdvCommandPannel()
{
	// if (NULL != pSeverityThresholdSlider)
	// 	delete pSeverityThresholdSlider ;
	// if (NULL != pDrugsDisplayOnOff)
  //	delete pDrugsDisplayOnOff ;
  // if (NULL != pCompressedMode)
	//	delete pCompressedMode ;
}

void
NSLdvCommandPannel::SetupWindow()
{
}

void
NSLdvCommandPannel::EvRButtonDown()
{
}

/*
void
NSLdvCommandPannel::draw(TDC* pDc, NVLdVRect* pRectARepeindre)
{
  NS_CLASSLIB::TRect screenRect = pView->getGlobalPhysicalRect(*pRectARepeindre) ;
  draw(pDc, &screenRect) ;
}

void
NSLdvCommandPannel::draw(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
	skinDraw(pDc, pRectARepeindre) ;
}
*/

void
NSLdvCommandPannel::dysplayStatusMessage(string* pMessage)
{
	if (!pMessage || (*pMessage == string("")))
		return ;

  string sLangue  = pContexte->getUtilisateur()->donneLang() ;

	// Get the lib of "years" (plural of "year")
  //
  string sCodeLexAn = string("2DAT33") ;
  NSPathologData Data ;
  pContexte->getDico()->trouvePathologData(sLangue, &sCodeLexAn, &Data) ;
  int iGenre ;
  Data.donneGenre(&iGenre) ;
  Data.donneGenrePluriel(&iGenre) ;
  string sLibel ;
  NSGenerateur* pGene = pContexte->getDico()->pGenerateur ;
  pGene->donneLibelleAffiche(&sLibel, &Data, iGenre) ;

  string sCodeLexMois = string("2DAT21") ;
  pContexte->getDico()->trouvePathologData(sLangue, &sCodeLexMois, &Data) ;
  Data.donneGenre(&iGenre) ;
  Data.donneGenrePluriel(&iGenre) ;
  string sLibelMois ;
  pGene->donneLibelleAffiche(&sLibelMois, &Data, iGenre) ;

	char  sAge[20] ;
	sAge[0] = '\0';
  char  szAge[4] ;

	NVLdVTemps tNaissance = pView->getDateNaissance() ;

  string  sCurDate = string(*pMessage, 6, 4) + string(*pMessage, 3, 2) + string(*pMessage, 0, 2) ;
  int iAge = donne_age((char *) sCurDate.c_str(), (char *) (tNaissance.donneDate().c_str())) ;

  if (iAge >= 2)
  {
    if (iAge >= 0)
      itoa(iAge, sAge, 10) ;
    else
      strcpy(sAge, "?") ;
    *pMessage = *pMessage + string("  ->  ") + sAge + string(" ") + sLibel ;
  }
  else
  {
    iAge = donne_age_mois((char *) sCurDate.c_str(), (char *) (tNaissance.donneDate().c_str())) ;
    *pMessage = *pMessage + string("  ->  ") + string(itoa(iAge, szAge, 10)) + string(" ") + sLibelMois ;
  }

  TWindowDC* pWinDC = new TWindowDC(pView->HWindow) ; // HWnd
  // drawText(pWinDC, *pMessage, "LdvCommandPannelMouseTime", &wBox) ;
	delete pWinDC ;
}

void
NSLdvCommandPannel::dysplayPatientInformation()
{
	char  sAge[20] ;
	sAge[0] = '\0';

	string sLangue  = pContexte->getUtilisateur()->donneLang() ;
	string sTitre   = pContexte->getPatient()->donneTitre(sLangue) ;

	NVLdVTemps tNaissance = pView->getDateNaissance() ;
	if (!(tNaissance.estVide()))
	{
  	// Get the lib of "years" (plural of "year")
    //
  	string sCodeLexAn = string("2DAT33") ;
    NSPathologData Data ;
    pContexte->getDico()->trouvePathologData(sLangue, &sCodeLexAn, &Data) ;
    int iGenre ;
    Data.donneGenre(&iGenre) ;
    Data.donneGenrePluriel(&iGenre) ;
    string sLibel ;
    NSGenerateur* pGene = pContexte->getDico()->pGenerateur ;
    pGene->donneLibelleAffiche(&sLibel, &Data, iGenre) ;

    string sCodeLexMois = string("2DAT21") ;
    pContexte->getDico()->trouvePathologData(sLangue, &sCodeLexMois, &Data) ;
    Data.donneGenre(&iGenre) ;
    Data.donneGenrePluriel(&iGenre) ;
    string sLibelMois ;
    pGene->donneLibelleAffiche(&sLibelMois, &Data, iGenre) ;

		char    szCurrentDate[9] ;
		char    szAge[4];
		donne_date_duJour(szCurrentDate) ;
		int     iCurrentAge = donne_age(szCurrentDate, (char *) (tNaissance.donneDate().c_str())) ;

		if (iCurrentAge >= 2)
			sTitre += string(" (") + string(itoa(iCurrentAge, szAge, 10)) + string(" ") + sLibel + string(")") ;
		else if (iCurrentAge >= 0)
		{
    	iCurrentAge = donne_age_mois(szCurrentDate, (char *) (tNaissance.donneDate().c_str())) ;
      sTitre += string(" (") + string(itoa(iCurrentAge, szAge, 10)) + string(" ") + sLibelMois + string(")") ;
    }
  }

  TWindowDC* pWinDC = new TWindowDC(pView->HWindow) ; // HWnd
  // drawText(pWinDC, sTitre, "LdvCommandPannelPatInfo", &wBox) ;
	delete pWinDC ;
}

void
NSLdvCommandPannel::drawText(TDC* pDc, string sText, string sSkinName, NS_CLASSLIB::TRect* pRect)
{
	nsSkin* pSkin = pContexte->getSkins()->donneSkin(sSkinName) ;

  NS_CLASSLIB::TRect displayRect = *pRect ;

  if (pSkin)
  {
  	// NS_CLASSLIB::TRect* pLocalRect = pSkin->getPosition() ;
  	// if (pLocalRect)
    //	displayRect = NS_CLASSLIB::TRect(wBox.Left() + pLocalRect->Left(),
    //                                   wBox.Top() + pLocalRect->Top(),
    //                                   wBox.Right(), wBox.Bottom()) ;

    ClassLib::TColor* pFontColor = pSkin->getFontColor() ;
    if (pFontColor)
    	pDc->SetTextColor(*pFontColor) ;

    ClassLib::TColor* pBackColor = pSkin->getFontBackColor() ;
    if (pBackColor)
    	pDc->SetBkColor(*pBackColor) ;

    LOGFONT* pLogFont = pSkin->getLogFont() ;
    if (pLogFont)
    	pDc->SelectObject(OWL::TFont(pLogFont)) ;
  }
  else
		pDc->FillRect(displayRect, NS_CLASSLIB::TColor::White) ;

	pDc->DrawText(sText.c_str(), -1, displayRect, DT_CENTER) ;
}

void
NSLdvCommandPannel::setScrollParams()
{
}

int
NSLdvCommandPannel::getSeverityThreshold()
{
  if (NULL == pInterface)
    return 0 ;

  NSLdvCommandPannelInterface* pPannel = TYPESAFE_DOWNCAST(pInterface, NSLdvCommandPannelInterface) ;
  if (NULL != pPannel)
    return pPannel->getSeverityThreshold() ;

  return 0 ;
}

// -----------------------------------------------------------------------------
// --------------- METHODES DE NSLdvCommandPannelInterface ------------------
// -----------------------------------------------------------------------------

#define ID_SEVERITY_SLIDER 201

DEFINE_RESPONSE_TABLE1(NSLdvCommandPannelInterface, TWindow)
  EV_WM_RBUTTONDOWN,
  EV_CHILD_NOTIFY_ALL_CODES(ID_SEVERITY_SLIDER, UpdateThresholdSlider),
END_RESPONSE_TABLE ;

NSLdvCommandPannelInterface::NSLdvCommandPannelInterface(NSContexte* pCtx, TWindow* parent, NSLdvCommandPannel* pToon)
                            :TWindow(parent), NSRoot(pCtx)
{
  _pToon = pToon ;

  SetCaption(_pToon->sSkinName.c_str()) ;

  NS_CLASSLIB::TRect rectDTArea = _pToon->getView()->getDateTimeArea() ;
  _pSeverityThresholdSlider = new TVSlider(this, ID_SEVERITY_SLIDER, rectDTArea.Left() + rectDTArea.Width(), 2, 20, pToon->getHeightValue() - 4) ;
}

NSLdvCommandPannelInterface::NSLdvCommandPannelInterface(NSLdvCommandPannelInterface& rv)
                            :TWindow(rv.GetParent()), NSRoot(rv.pContexte)
{
  _pToon = rv.getToon() ;
}

NSLdvCommandPannelInterface::~NSLdvCommandPannelInterface()
{
  delete _pSeverityThresholdSlider ;
}

void
NSLdvCommandPannelInterface::SetupWindow()
{
  TWindow::SetupWindow() ;

  _pSeverityThresholdSlider->SetRuler(10, true) ;
  _pSeverityThresholdSlider->SetRange(-1, 100) ;
  _pSeverityThresholdSlider->SetPosition(-1) ;
}

void
NSLdvCommandPannelInterface::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectAPeindre)
{
  _pToon->skinDraw(&dc, &RectAPeindre) ;
}

void
NSLdvCommandPannelInterface::EvRButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
  TWindow::EvRButtonDown(modKeys, point) ;
}

int
NSLdvCommandPannelInterface::getSeverityThreshold()
{
  if (NULL == _pSeverityThresholdSlider)
    return 0 ;

  return _pSeverityThresholdSlider->GetPosition() ;
}

void
NSLdvCommandPannelInterface::UpdateThresholdSlider(WPARAM code)
{
  if ((NULL == _pToon) || (NULL == _pToon->pView))
    return ;

  int iPos = _pSeverityThresholdSlider->GetPosition() ;
  int iThr = _pToon->pView->getSeverityThreshold() ;

  if (iPos == iThr)
    return ;

  _pToon->pView->UpdateSeverityThreshold(iThr) ;
}

NSLdvCommandPannelInterface&
NSLdvCommandPannelInterface::operator=(NSLdvCommandPannelInterface& src)
{
  if (this == &src)
    return *this ;

  _pToon = src.getToon() ;

  return *this ;
}

// -----------------------------------------------------------------------------
// ------------------- METHODES DE NSLdvChronoLine --------------------------
// -----------------------------------------------------------------------------

NSLdvChronoLine::NSLdvChronoLine(NSContexte* pCtx, NSLdvWindowToon* pLdvParent, NSLdvView* pTheView)
                :NSLdvWindowToon(pCtx, pLdvParent, pTheView)
{
  _bUnitIsChanging = false ;

	iZOrder   = LEVEL_COMMANDS ;
  toonType  = toonChronoLine ;
  // toonShape = toonFullWidth ;
  sSkinName = string("LdvChronoLine") ;

  initDimensions() ;

/*
  if (!initBoxFromSkin())
  {
  	TEXTMETRIC tm;

		TWindowDC* pWinDC = new TWindowDC(pView->GetParent()) ; // HWnd

		int iSimpleLineHeight = 0 ;
		if (pWinDC->GetTextMetrics(tm))
			iSimpleLineHeight = tm.tmHeight + tm.tmInternalLeading + tm.tmExternalLeading ;

		int iHauteur = iSimpleLineHeight * 2 + 10 ;

		delete pWinDC;

    // wVisibleBox = NS_CLASSLIB::TRect(0, 0, 10000, iHauteur) ;
	}
*/

  pInterface = new NSLdvChronoLineInterface(pContexte, getParentInterface(), this) ;
}

NSLdvChronoLine::NSLdvChronoLine(NSLdvChronoLine& rv)
                :NSLdvWindowToon(rv.pContexte, rv.getToonParent(), rv.pView)
{
  _bUnitIsChanging = rv._bUnitIsChanging ;
	initialiser((NSLdvWindowToon*)(&rv)) ;
}


NSLdvChronoLine::~NSLdvChronoLine()
{
}

void
NSLdvChronoLine::EvRButtonDown()
{
}

void
NSLdvChronoLine::SetupWindow()
{
}

void
NSLdvChronoLine::setScrollParams()
{
}

void
NSLdvChronoLine::draw(TDC* pDc, NVLdVRect* pRectARepeindre)
{
	NS_CLASSLIB::TRect screenRect = pView->getGlobalPhysicalRect(*pRectARepeindre) ;

  draw(pDc, &screenRect) ;
}

void
NSLdvChronoLine::draw(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
  // Recalculate wVisibleBox
  //
  // wVisibleBox = NS_CLASSLIB::TRect(0, pView->GetClientRect().Height() - wVisibleBox.Height(), pView->GetClientRect().Width(), wVisibleBox.Height()) ;

	skinDraw(pDc, pRectARepeindre) ;

	NVLdVTemps tDateHeureInfGauche = pView->getDateHeureInfDroit() ;

  int iTimeUnitWidth = pView->getTimeUnitFromPhysicalWidth(pInterface->GetClientRect().Width()) ;

  pixUnit iViewXUnit = pView->getXunit() ;
	switch (iViewXUnit)
	{
  	case pixSeconde :
			tDateHeureInfGauche.ajouteSecondes(-iTimeUnitWidth) ;

			drawChronoStepMinutes(pDc, pRectARepeindre, tDateHeureInfGauche) ;
			drawChronoContextHours(pDc, pRectARepeindre, tDateHeureInfGauche) ;
			break ;

  	case pixMinute :
			tDateHeureInfGauche.ajouteMinutes(-iTimeUnitWidth) ;

			drawChronoStepHours(pDc, pRectARepeindre, tDateHeureInfGauche) ;
			drawChronoContextDays(pDc, pRectARepeindre, tDateHeureInfGauche) ;
			break ;

		case pixHeure :
			tDateHeureInfGauche.ajouteHeures(-iTimeUnitWidth) ;

			drawChronoStepDays(pDc, pRectARepeindre, tDateHeureInfGauche) ;
			drawChronoContextMonths(pDc, pRectARepeindre, tDateHeureInfGauche) ;
			break ;

		case pixJour :
			tDateHeureInfGauche.ajouteJours(-iTimeUnitWidth) ;

			drawChronoStepMonths(pDc, pRectARepeindre, tDateHeureInfGauche) ;
			drawChronoContextYears(pDc, pRectARepeindre, tDateHeureInfGauche) ;
			break ;

		case pixSemaine :
			tDateHeureInfGauche.ajouteJours(-iTimeUnitWidth * 7) ;

			drawChronoStepYears(pDc, pRectARepeindre, tDateHeureInfGauche) ;
			break ;

		case pixMois :
			tDateHeureInfGauche.ajouteMois(-iTimeUnitWidth) ;

			drawChronoStepDecads(pDc, pRectARepeindre, tDateHeureInfGauche) ;
			drawChronoContextDecads(pDc, pRectARepeindre, tDateHeureInfGauche) ;
			break ;
  }
}

void
NSLdvChronoLine::drawChronoStep(TDC *pDc, NVLdVTemps tGauche, NVLdVTemps tDroite, string sTexte, bool bRed)
{
	int iSimpleLineHeight = getLineHeight() ;

	NVLdVRect textDisplay = NVLdVRect(pView, tGauche, tDroite, long(iSimpleLineHeight), long(iSimpleLineHeight * 2)) ;
  NVLdVRect periodDisplay = NVLdVRect(pView, tGauche, tDroite, long(iSimpleLineHeight * 2), long(iSimpleLineHeight * 2 + 5)) ;

  // NS_CLASSLIB::TRect textRect = pView->getGlobalPhysicalRect(textDisplay) ;
  // NS_CLASSLIB::TRect stepRect = pView->getGlobalPhysicalRect(periodDisplay) ;

  NS_CLASSLIB::TRect textRect = getRectForDraw(textDisplay) ;
  NS_CLASSLIB::TRect stepRect = getRectForDraw(periodDisplay) ;

	pDc->DrawText(sTexte.c_str(), -1, textRect, DT_CENTER) ;
  pDc->FillRect(textRect.X(), textRect.Y(), textRect.X() + 1, textRect.Y() + 5, OWL::TBrush(pView->getBlackBrushHandle())) ;

	if (bRed)
  	pDc->FillRect(stepRect, OWL::TBrush(pView->getRedBrushHandle())) ;
  else
  	pDc->FillRect(stepRect, OWL::TBrush(pView->getBlackBrushHandle())) ;
}


// -----------------------------------------------------------------------------
// affichage de la chronoline
// -----------------------------------------------------------------------------
// La chronoline est divis� en deux parties. La partie sup�rieure est la partie
// que nous appelerons step (unit� la plus repr�sentative), la partie inf�rieure
// est la partie que nous appelerons context (contexte de l'unit� la plus
// repr�sentative).
// -----------------------------------------------------------------------------
// Par exemple si on est � l'echelle : 1 pixel == 1 heure alors l'affichage de
// * la partie sup�rieure (step) sera par jour (24 pixels de largeur)
// * la partie inf�rieure (context) sera par mois (28 � 31 jours)
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// affichage de la partie sup�rieure de la chronoline (step) par minutes
// -----------------------------------------------------------------------------
// NSLdvView::drawChronoStepMinutes(TDC *, NVLdVRect *, NVLdVTemps)
// -----------------------------------------------------------------------------
// �chelle : 1 pixel == 1 seconde
// -----------------------------------------------------------------------------

void
NSLdvChronoLine::drawChronoStepMinutes(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre, NVLdVTemps tDateHeureInfGauche)
{
try
{
	NVLdVTemps  tDroite = pView->getDateHeureInfDroit() ;
	NVLdVTemps  tGauche = NVLdVTemps(	tDroite.donneAns(),
																		tDroite.donneMois(),
																		tDroite.donneJours(),
																		tDroite.donneHeures(),
																		tDroite.donneMinutes(),
																		0) ;
	bool        bRed = false ;

	while (tDroite > tDateHeureInfGauche)
	{
    int iMinute = tGauche.donneMinutes() ;
    string sText = IntToString(iMinute) ;

    drawChronoStep(pDc, tGauche, tDroite, sText, bRed) ;

		bRed = !bRed ;
		tDroite = tGauche ;
		tGauche.ajouteMinutes(-1) ;
	}
}
catch (...)
{
  erreur("Exception NSLdvChronoLine drawChronoStepDays.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// affichage de la partie sup�rieure de la chronoline (step) par heure
// -----------------------------------------------------------------------------
// NSLdvView::drawChronoStepHours(TDC *, NVLdVRect *, NVLdVTemps)
// -----------------------------------------------------------------------------
// �chelle : 1 pixel == 1 minute
// -----------------------------------------------------------------------------
void
NSLdvChronoLine::drawChronoStepHours(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre, NVLdVTemps tDateHeureInfGauche)
{
try
{
	NVLdVTemps  tDroite = pView->getDateHeureInfDroit() ;
	NVLdVTemps  tGauche = NVLdVTemps(	tDroite.donneAns(),
																		tDroite.donneMois(),
																		tDroite.donneJours(),
																		tDroite.donneHeures(),
																		0,
																		0) ;
	bool        bRed = false ;

	while (tDroite > tDateHeureInfGauche)
	{
		int iHour = tGauche.donneHeures() ;
    string sText = IntToString(iHour) ;

    drawChronoStep(pDc, tGauche, tDroite, sText, bRed) ;

		bRed = !bRed ;
		tDroite = tGauche ;
		tGauche.ajouteHeures(-1) ;
	}
}
catch (...)
{
  erreur("Exception NSLdvChronoLine drawChronoStepDays.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------// affichage de la partie sup�rieure de la chronoline (step) par jour
// -----------------------------------------------------------------------------
// NSLdvView::drawChronoStepDays(TDC *, NVLdVRect *, NVLdVTemps)
// -----------------------------------------------------------------------------
// �chelle : 1 pixel == 1 heure
// -----------------------------------------------------------------------------

void
NSLdvChronoLine::drawChronoStepDays(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre, NVLdVTemps tDateHeureInfGauche)
{
try
{
	NVLdVTemps  tDroite = pView->getDateHeureInfDroit() ;
	NVLdVTemps  tGauche = NVLdVTemps(	tDroite.donneAns(),
																		tDroite.donneMois(),
																		tDroite.donneJours(),
																		0,
																		0,
																		0) ;
	bool        bRed = false ;

	while (tDroite > tDateHeureInfGauche)
	{
		int iJour = tGauche.donneJours() ;
		string sText = IntToString(iJour) ;

    drawChronoStep(pDc, tGauche, tDroite, sText, bRed) ;

		bRed = !bRed ;
		tDroite = tGauche ;
		tGauche.ajouteJours(-1) ;
	}
}
catch (...)
{
  erreur("Exception NSLdvChronoLine drawChronoStepDays.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// affichage de la partie sup�rieure de la chronoline (step) par mois
// -----------------------------------------------------------------------------
// NSLdvView::drawChronoStepMonths(TDC *, NVLdVRect *, NVLdVTemps)
// -----------------------------------------------------------------------------
// �chelle : 1 pixel == 1 jour
// -----------------------------------------------------------------------------
void
NSLdvChronoLine::drawChronoStepMonths(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre, NVLdVTemps tDateHeureInfGauche)
{
try
{
	NVLdVTemps tDroite = pView->getDateHeureInfDroit() ;
	NVLdVTemps tGauche = NVLdVTemps(tDroite.donneAns(), tDroite.donneMois(), 1, 0, 0, 0) ;

	bool        bRed = false ;

	while (tDroite > tDateHeureInfGauche)
	{
		int iMois = tGauche.donneMois() ;
		string sText = IntToString(iMois) ;

    drawChronoStep(pDc, tGauche, tDroite, sText, bRed) ;

		bRed = !bRed ;
		tDroite = tGauche ;
		tGauche.ajouteMois(-1) ;
	}
}
catch (...)
{
	erreur("Exception NSLdvChronoLine drawChronoStepMonths.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// affichage de la partie sup�rieure de la chronoline (step) par ann�e
// -----------------------------------------------------------------------------
// NSLdvView::drawChronoStepYears(TDC *, NVLdVRect *, NVLdVTemps)
// -----------------------------------------------------------------------------
// �chelle : 1 pixel == 1 semaine
// -----------------------------------------------------------------------------
void
NSLdvChronoLine::drawChronoStepYears(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre, NVLdVTemps tDateHeureInfGauche)
{
try
{
	NVLdVTemps  tDroite = pView->getDateHeureInfDroit() ;
	NVLdVTemps  tGauche = NVLdVTemps(tDroite.donneAns(), 1, 1, 0, 0, 0) ;

	bool        bRed = false ;

	while (tDroite > tDateHeureInfGauche)
	{
		int iAnnee = tGauche.donneAns() ;
		string sText = IntToString(iAnnee) ;

    drawChronoStep(pDc, tGauche, tDroite, sText, bRed) ;

		bRed = !bRed ;
		tDroite = tGauche ;
		tGauche.ajouteAns(-1) ;
	}
}
catch (...)
{
	erreur("Exception NSLdvChronoLine drawChronoStepYears.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// affichage de la partie sup�rieure de la chronoline (step) par d�cennie
// -----------------------------------------------------------------------------
// NSLdvView::drawChronoStepDecads(TDC *, NVLdVRect *, NVLdVTemps)
// -----------------------------------------------------------------------------
// �chelle : 1 pixel == 1 mois
// -----------------------------------------------------------------------------
void
NSLdvChronoLine::drawChronoStepDecads(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre, NVLdVTemps tDateHeureInfGauche)
{
try
{
	NVLdVTemps  tDroite = pView->getDateHeureInfDroit() ;
	NVLdVTemps  tGauche = NVLdVTemps(tDroite.donneAns(), 1, 1, 0, 0, 0) ;

	bool        bRed = false ;

	while (tDroite > tDateHeureInfGauche)
	{
		int iAnnee = tGauche.donneAns() % 10 ;
		string sText = IntToString(iAnnee) ;

    drawChronoStep(pDc, tGauche, tDroite, sText, bRed) ;

		bRed = !bRed ;
		tDroite = tGauche ;
		tGauche.ajouteAns(-1) ;
	}
}
catch (...)
{
	erreur("Exception NSLdvChronoLine drawChronoStepDecads.", standardError, 0) ;
}
}

void
NSLdvChronoLine::drawChronoContext(TDC *pDc, NVLdVTemps tGauche, NVLdVTemps tDroite, string sTexte)
{
	int iSimpleLineHeight = getLineHeight() ;

	NVLdVRect rectDisplay = NVLdVRect(pView, tGauche, tDroite, long(0), long(iSimpleLineHeight)) ;

  NS_CLASSLIB::TPoint ptTopLeft = getPointForDraw(rectDisplay.TopLeft()) ;
  NS_CLASSLIB::TPoint ptBotRigh = getPointForDraw(rectDisplay.BottomRight()) ;

	// NS_CLASSLIB::TPoint ptTopLeft = pView->getGlobalPhysicalPoint(rectDisplay.TopLeft());
	// NS_CLASSLIB::TPoint ptBotRigh = pView->getGlobalPhysicalPoint(rectDisplay.BottomRight());

  pDc->DrawText(sTexte.c_str(), -1, NS_CLASSLIB::TRect(ptTopLeft.x, ptTopLeft.y, ptBotRigh.x, ptBotRigh.y), DT_CENTER) ;
}

// -----------------------------------------------------------------------------
// affichage de la partie inf�rieure de la chronoline (context) par heure
// -----------------------------------------------------------------------------
// NSLdvView::drawChronoContextMonths(TDC *, NVLdVRect *, NVLdVTemps)
// -----------------------------------------------------------------------------
// �chelle : 1 pixel == 1 minute
// -----------------------------------------------------------------------------
void
NSLdvChronoLine::drawChronoContextHours(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre, NVLdVTemps tDateHeureInfGauche)
{
try
{
	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	NVLdVTemps tDroite = pView->getDateHeureInfDroit() ;
	NVLdVTemps tGauche = NVLdVTemps(tDroite.donneAns(), tDroite.donneMois(), tDroite.donneJours(), tDroite.donneHeures(), 1, 0) ;

	while (tDroite > tDateHeureInfGauche)
	{
		if (tGauche < tDateHeureInfGauche)
			tGauche = tDateHeureInfGauche ;

    int     iHour   = tGauche.donneHeures() ;
    int     iJour   = tGauche.donneJours() ;
		int     iMois   = tGauche.donneMois() ;
		string  sMois   = donne_mois(iMois, sLang) ;
		int     iAnnees = tGauche.donneAns() ;
		char    pcDate[20] ;
		sprintf(pcDate, "%d %s %d %d:00", iJour, sMois.c_str(), iAnnees, iHour) ;

    string sTexte = string(pcDate) ;
    drawChronoContext(pDc, tGauche, tDroite, sTexte) ;

		tDroite = tGauche ;
		tGauche.ajouteHeures(-1) ;
	}
}
catch (...)
{
	erreur("Exception NSLdvChronoLine drawChronoContextDays.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// affichage de la partie inf�rieure de la chronoline (context) par jour
// -----------------------------------------------------------------------------
// NSLdvView::drawChronoContextMonths(TDC *, NVLdVRect *, NVLdVTemps)
// -----------------------------------------------------------------------------
// �chelle : 1 pixel == 1 minute
// -----------------------------------------------------------------------------
void
NSLdvChronoLine::drawChronoContextDays(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre, NVLdVTemps tDateHeureInfGauche)
{
try
{
	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	NVLdVTemps tDroite = pView->getDateHeureInfDroit() ;
	NVLdVTemps tGauche = NVLdVTemps(tDroite.donneAns(), tDroite.donneMois(), tDroite.donneJours(), 1, 0, 0) ;

	while (tDroite > tDateHeureInfGauche)
	{
		if (tGauche < tDateHeureInfGauche)
			tGauche = tDateHeureInfGauche ;

    int     iJour   = tGauche.donneJours() ;
		int     iMois   = tGauche.donneMois() ;
		string  sMois   = donne_mois(iMois, sLang) ;
		int     iAnnees = tGauche.donneAns() ;
		char    pcDate[20] ;
		sprintf(pcDate, "%d %s %d", iJour, sMois.c_str(), iAnnees) ;

    string sTexte = string(pcDate) ;
    drawChronoContext(pDc, tGauche, tDroite, sTexte) ;

		tDroite = tGauche ;
		tGauche.ajouteJours(-1) ;
	}
}
catch (...)
{
	erreur("Exception NSLdvChronoLine drawChronoContextDays.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// affichage de la partie inf�rieure de la chronoline (context) par mois
// -----------------------------------------------------------------------------
// NSLdvView::drawChronoContextMonths(TDC *, NVLdVRect *, NVLdVTemps)
// -----------------------------------------------------------------------------
// �chelle : 1 pixel == 1 heure
// -----------------------------------------------------------------------------
void
NSLdvChronoLine::drawChronoContextMonths(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre, NVLdVTemps tDateHeureInfGauche)
{
try
{
	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	NVLdVTemps tDroite = pView->getDateHeureInfDroit() ;
	NVLdVTemps tGauche = NVLdVTemps(tDroite.donneAns(), tDroite.donneMois(), 1, 0, 0, 0) ;

	while (tDroite > tDateHeureInfGauche)
	{
		if (tGauche < tDateHeureInfGauche)
			tGauche = tDateHeureInfGauche ;

		int     iMois   = tGauche.donneMois() ;
		string  sMois   = donne_mois(iMois, sLang) ;
		int     iAnnees = tGauche.donneAns() ;
		char    pcDate[20] ;
		sprintf(pcDate, "%s %d", sMois.c_str(), iAnnees) ;

    string sTexte = string(pcDate) ;
    drawChronoContext(pDc, tGauche, tDroite, sTexte) ;

		tDroite = tGauche ;
		tGauche.ajouteMois(-1) ;
	}
}
catch (...)
{
	erreur("Exception NSLdvChronoLine drawChronoContextMonths.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// affichage de la partie inf�rieure de la chronoline (context) par ann�e
// -----------------------------------------------------------------------------
// NSLdvView::drawChronoContextYears(TDC *, NVLdVRect *, NVLdVTemps)
// -----------------------------------------------------------------------------
// �chelle : 1 pixel == 1 jour
// -----------------------------------------------------------------------------
void
NSLdvChronoLine::drawChronoContextYears(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre, NVLdVTemps tDateHeureInfGauche)
{
try
{
	NVLdVTemps tDroite = pView->getDateHeureInfDroit() ;
	NVLdVTemps tGauche = NVLdVTemps(tDroite.donneAns(), 1, 1, 0, 0, 0) ;

	while (tDroite > tDateHeureInfGauche)
	{
		if (tGauche < tDateHeureInfGauche)
			tGauche = tDateHeureInfGauche ;

		int     iAnnees = tGauche.donneAns() ;
		char    pcDate[5] ;
		sprintf(pcDate, "%d", iAnnees) ;

    string sTexte = string(pcDate) ;
    drawChronoContext(pDc, tGauche, tDroite, sTexte) ;

		tDroite = tGauche ;
		tGauche.ajouteAns(-1) ;
	}
}
catch (...)
{
	erreur("Exception NSLdvChronoLine drawChronoContextYears.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// affichage de la partie inf�rieure de la chronoline (context) par d�cenies
// -----------------------------------------------------------------------------
// NSLdvView::drawChronoContextDecads(TDC *, NVLdVRect *, NVLdVTemps)
// -----------------------------------------------------------------------------
// �chelle : 1 pixel == 1 mois
// -----------------------------------------------------------------------------
void
NSLdvChronoLine::drawChronoContextDecads(TDC *pDc, NS_CLASSLIB::TRect* pRectARepeindre, NVLdVTemps tDateHeureInfGauche)
{
try
{
	NVLdVTemps tDroite = pView->getDateHeureInfDroit() ;
	NVLdVTemps tGauche = NVLdVTemps((tDroite.donneAns() / 10) * 10, 1, 1, 0, 0, 0) ;

	while (tDroite > tDateHeureInfGauche)
	{
		if (tGauche < tDateHeureInfGauche)
			tGauche = tDateHeureInfGauche ;

		int     iAnnees = tGauche.donneAns() ;
		char    pcDate[5] ;
		sprintf(pcDate, "%d", iAnnees) ;

    string sTexte = string(pcDate) ;
    drawChronoContext(pDc, tGauche, tDroite, sTexte) ;

		tDroite = tGauche ;
		tGauche.ajouteAns(-10) ;
	}
}
catch (...)
{
	erreur("Exception NSLdvChronoLine drawChronoContextDecads.", standardError, 0) ;
}
}

void
NSLdvChronoLine::refresh()
{
  NSTimeZoomLevel* pTimeInfo  = pView->getCurrentZoomInfo() ;

  NSLdvChronoLineInterface* pChrono = TYPESAFE_DOWNCAST(pInterface, NSLdvChronoLineInterface) ;
  if (NULL == pChrono)
    return ;

  pChrono->getSlider()->SetRange(pTimeInfo->getLowerLimit(), pTimeInfo->getUpperLimit() - 1) ;
  pChrono->getSlider()->SetPosition(pTimeInfo->getUppRate()) ;
}

int
NSLdvChronoLine::getLineHeight()
{
	// return (wVisibleBox.Height() - 10) / 2 ;

  int iInterfaceHeight = 0 ;

  if ((NULL != pInterface) && (true == pInterface->IsWindow()))
  {
    NS_CLASSLIB::TRect clientRect = pInterface->GetClientRect() ;
    iInterfaceHeight = clientRect.Height() ;
  }
  else
    iInterfaceHeight = iHeightValue ;

  return (iInterfaceHeight - 10) / 2 ;
}

int
NSLdvChronoLine::getPpuRatePosition()
{
  if (NULL == pInterface)
    return 0 ;

  NSLdvChronoLineInterface* pChrono = TYPESAFE_DOWNCAST(pInterface, NSLdvChronoLineInterface) ;
  if (NULL != pChrono)
    return pChrono->getPpuRatePosition() ;

  return 0 ;
}

void
NSLdvChronoLine::unitChanging()
{
  _bUnitIsChanging = true ;
}

void
NSLdvChronoLine::unitChanged()
{
  _bUnitIsChanging = false ;
}

void
NSLdvChronoLine::initPpuRateInterface(NSTimeZoomLevel* pTimeInfo)
{
  if (NULL == pTimeInfo)
    return ;

  NSLdvChronoLineInterface* pChrono = TYPESAFE_DOWNCAST(pInterface, NSLdvChronoLineInterface) ;
  if (NULL == pChrono)
    return ;

  pChrono->getSlider()->SetRange(pTimeInfo->getLowerLimit(), pTimeInfo->getUpperLimit() - 1) ;
  pChrono->getSlider()->SetPosition(pTimeInfo->getUppRate()) ;
}

// -----------------------------------------------------------------------------
// ----------------- METHODES DE NSLdvChronoLineInterface --------------------
// -----------------------------------------------------------------------------

#define ID_SLIDER 201

DEFINE_RESPONSE_TABLE1(NSLdvChronoLineInterface, TWindow)
  EV_WM_RBUTTONDOWN,
  EV_COMMAND(CM_LDV_PIXSECOND,    CmLdvPixSecond),    // pixel == 1 seconde
	EV_COMMAND(CM_LDV_PIXMINUTE,    CmLdvPixMinute),    // pixel == 1 minute
	EV_COMMAND(CM_LDV_PIXHOUR,      CmLdvPixHour),      // pixel == 1 heure
	EV_COMMAND(CM_LDV_PIXDAY,       CmLdvPixDay),       // pixel == 1 jour
	EV_COMMAND(CM_LDV_PIXWEEK,      CmLdvPixWeek),      // pixel == 1 semaine
	EV_COMMAND(CM_LDV_PIXMONTH,     CmLdvPixMonth),     // pixel == 1 mois
  EV_CHILD_NOTIFY_ALL_CODES(ID_SLIDER, UpdateTimeSlider),
END_RESPONSE_TABLE ;

NSLdvChronoLineInterface::NSLdvChronoLineInterface(NSContexte* pCtx, TWindow* parent, NSLdvChronoLine* pToon)
                         :TWindow(parent), NSRoot(pCtx)
{
  _pToon   = pToon ;
  _pSlider = new THSlider(this, ID_SLIDER, 5, pToon->getHeightValue() - 15, 200, 15) ;

  SetCaption(_pToon->sSkinName.c_str()) ;
}

NSLdvChronoLineInterface::NSLdvChronoLineInterface(NSLdvChronoLineInterface& rv)
                         :TWindow(rv.GetParent()), NSRoot(rv.pContexte)
{
  _pToon = rv.getToon() ;
}

NSLdvChronoLineInterface::~NSLdvChronoLineInterface()
{
  delete _pSlider ;
}

void
NSLdvChronoLineInterface::SetupWindow()
{
  TWindow::SetupWindow() ;

  _pSlider->SetRuler(1, true) ;

  NSTimeZoomLevel* pTimeInfo = _pToon->pView->getCurrentZoomInfo() ;
  if (NULL != pTimeInfo)
  {
    _pSlider->SetRange(pTimeInfo->getLowerLimit(), pTimeInfo->getUpperLimit() - 1) ;
    _pSlider->SetPosition(pTimeInfo->getUppRate()) ;
  }
}

void
NSLdvChronoLineInterface::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectAPeindre)
{
  if (NULL != _pToon)
    _pToon->draw(&dc, &RectAPeindre) ;
}

void
NSLdvChronoLineInterface::EvRButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
  OWL::TPopupMenu *zoomMenu = new OWL::TPopupMenu() ;

  string sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "1pixelPerSecond") ;
  zoomMenu->AppendMenu(MF_STRING, CM_LDV_PIXSECOND, sMenuText.c_str()) ;
  sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "1pixelPerMinute") ;
  zoomMenu->AppendMenu(MF_STRING, CM_LDV_PIXMINUTE, sMenuText.c_str()) ;
  sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "1pixelPerHour") ;
  zoomMenu->AppendMenu(MF_STRING, CM_LDV_PIXHOUR,  sMenuText.c_str()) ;
  sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "1pixelPerDay") ;
  zoomMenu->AppendMenu(MF_STRING, CM_LDV_PIXDAY,   sMenuText.c_str()) ;
  sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "1pixelPerWeek") ;
  zoomMenu->AppendMenu(MF_STRING, CM_LDV_PIXWEEK,  sMenuText.c_str()) ;
  sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "1pixelPerMonth") ;
  zoomMenu->AppendMenu(MF_STRING, CM_LDV_PIXMONTH, sMenuText.c_str()) ;

  ClientToScreen(point) ;
  zoomMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point, 0, HWindow) ;
  delete zoomMenu ;

  TWindow::EvRButtonDown(modKeys, point) ;
}

void
NSLdvChronoLineInterface::CmLdvPixSecond()
{
	_pToon->pView->setXunit(pixSeconde) ;
  _pToon->pView->Invalidate(true) ;
}

void
NSLdvChronoLineInterface::CmLdvPixMinute()
{
  _pToon->pView->setXunit(pixMinute) ;
  _pToon->pView->Invalidate(true) ;
}

void
NSLdvChronoLineInterface::CmLdvPixHour()
{
  _pToon->pView->setXunit(pixHeure) ;
  _pToon->pView->Invalidate(true) ;
}

void
NSLdvChronoLineInterface::CmLdvPixDay()
{
  _pToon->pView->setXunit(pixJour) ;
  _pToon->pView->Invalidate(true) ;
}

void
NSLdvChronoLineInterface::CmLdvPixWeek()
{
  _pToon->pView->setXunit(pixSemaine) ;
  _pToon->pView->Invalidate(true) ;
}

void
NSLdvChronoLineInterface::CmLdvPixMonth()
{
  _pToon->pView->setXunit(pixMois) ;
  _pToon->pView->Invalidate(true) ;
}

int
NSLdvChronoLineInterface::getPpuRatePosition()
{
  if (NULL == _pSlider)
    return 0 ;

  int iPos = _pSlider->GetPosition() ;

  return iPos ;
}

void
NSLdvChronoLineInterface::UpdateTimeSlider(WPARAM code)
{
  if ((NULL == _pToon) || (_pToon->isUnitChanging()) || (NULL == _pToon->pView))
    return ;

  int iPos = _pSlider->GetPosition() ;
  int iPpu = _pToon->pView->getPpuRate() ;

  if (iPos == iPpu)
    return ;

  _pToon->pView->UpdatePixelPerUnitRate(getPpuRatePosition()) ;
}

NSLdvChronoLineInterface&
NSLdvChronoLineInterface::operator=(NSLdvChronoLineInterface& src)
{
  if (this == &src)
    return *this ;

  _pToon = src.getToon() ;

  return *this ;
}

// -----------------------------------------------------------------------------
//                       NSLdvVerticalScrollBar VSCROLLBAR_ID
// -----------------------------------------------------------------------------

/*

NSLdvVerticalScrollBar::NSLdvVerticalScrollBar(NSContexte* pCtx, NSLdvWindowToon* pLdvParent, NSLdvView* pTheView)
                       :NSLdvWindowToon(pCtx, pLdvParent, pTheView)

{
	toonType = toonVerticalScroll ;

  sSkinName = string("LdvVerticalScrollBar") ;

  initDimensions() ;

  pInterface = new NSLdvVerticalScrollBarInterface(pContexte, getParentInterface(), this) ;
}

void
NSLdvVerticalScrollBar::SetupWindow()
{
}

void
NSLdvVerticalScrollBar::setVisibleBox()
{
  // int iRight  = pView->getWorkingSpaceRight() ;
  // int iTop    = pView->getWorkingSpaceTop() ;
  // int iBottom = pView->getWorkingSpaceBottom() ;

  int iWidth = 10 ;

  // wVisibleBox = NS_CLASSLIB::TRect(iRight - iWidth, iTop, iRight, iBottom) ;
}

void
NSLdvVerticalScrollBar::draw(TDC* pDc, NVLdVRect* pRectARepeindre)
{
	NS_CLASSLIB::TRect screenRect = pView->getGlobalPhysicalRect(*pRectARepeindre) ;

  draw(pDc, &screenRect) ;
}
*/

// void
// NSLdvVerticalScrollBar::draw(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
// {
/*
	setVisibleBox() ;

  int iWorkingSpaceHeight = pView->getWorkingSpaceHeight() ;
  int iCurrentYRange      = pView->getGlobalBox().Height() ;

  // Every toon fits inside the workingspace
  //
	if (iCurrentYRange <= iWorkingSpaceHeight)
  {
  	pInterface->Show(SW_HIDE) ;
    return ;
  }

  int iRight = pView->getWorkingSpaceRight() ;
  int iTop   = pView->getWorkingSpaceTop() ;

  int iWidth = 10 ;
  // pInterface->SetWindowPos(0, wVisibleBox.Left(), wVisibleBox.Top(), wVisibleBox.Width(), wVisibleBox.Height(), SWP_NOZORDER) ;

  // Since we start from the bottom, we must "reverse" nPos
  //
  int iMaxDeltaPos = iCurrentYRange - iWorkingSpaceHeight ;
  int iThumbPos    = iMaxDeltaPos - pView->getPosInfDroit() ;

  SCROLLINFO scInfo ;
	scInfo.cbSize = (UINT) sizeof(scInfo) ;
	scInfo.fMask = SIF_ALL ;
	scInfo.nMin  = 0 ;
	scInfo.nMax  = iCurrentYRange ;
	scInfo.nPage = (UINT) (iWorkingSpaceHeight) ;
	scInfo.nPos  = iThumbPos ;

  OWL::TScrollBar* pScroll = TYPESAFE_DOWNCAST(pInterface, OWL::TScrollBar) ;
  if (NULL != pScroll)
    pScroll->SetScrollInfo(&scInfo, TRUE) ;

  pInterface->Show(SW_SHOW) ;
*/
// }

/*
void
NSLdvVerticalScrollBar::EvRButtonDown()
{
}

void
NSLdvVerticalScrollBar::FixeRange(int max, int taille)
{
}

void
NSLdvVerticalScrollBar::PositionneCurseur()
{
}

// -----------------------------------------------------------------------------
// ----------------- METHODES DE NSLdvChronoLineInterface --------------------
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSLdvVerticalScrollBarInterface, OWL::TScrollBar)
  EV_WM_PAINT,
END_RESPONSE_TABLE ;

NSLdvVerticalScrollBarInterface::NSLdvVerticalScrollBarInterface(NSContexte* pCtx, TWindow* parent, NSLdvVerticalScrollBar* pToon)
                                :OWL::TScrollBar(parent, VSCROLLBAR_ID, 0, 0, 0, 0, false), NSRoot(pCtx)
{
  _pToon = pToon ;

  SetCaption(_pToon->sSkinName.c_str()) ;
}

NSLdvVerticalScrollBarInterface::NSLdvVerticalScrollBarInterface(NSLdvVerticalScrollBarInterface& rv)
                                :OWL::TScrollBar((TWindow*)(rv.GetParent()), VSCROLLBAR_ID, 0, 0, 0, 0, false), NSRoot(rv.pContexte)
{
  _pToon = rv.getToon() ;
}

NSLdvVerticalScrollBarInterface::~NSLdvVerticalScrollBarInterface()
{
}

void
NSLdvVerticalScrollBarInterface::SetupWindow()
{
  OWL::TScrollBar::SetupWindow() ;
}

void
NSLdvVerticalScrollBarInterface::EvPaint()
{
  TPaintDC dc(*this) ;
}

void
NSLdvVerticalScrollBarInterface::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectAPeindre)
{
  _pToon->draw(&dc, &RectAPeindre) ;

  NSLdvWindowToon* pParentToon = _pToon->getToonParent() ;
  if ((NULL == pParentToon) || (NSLdvToon::toonWorkingArea != pParentToon->getType()))
  {
    OWL::TScrollBar::Paint(dc, true, RectAPeindre) ;
    return ;
  }

  NSLdvViewArea *pWorkingArea = TYPESAFE_DOWNCAST(pParentToon, NSLdvViewArea) ;
  if (NULL == pWorkingArea)
  {
    OWL::TScrollBar::Paint(dc, true, RectAPeindre) ;
    return ;
  }

  int iWorkingSpaceHeight = pWorkingArea->getWorkingSpaceHeight() ;
  int iCurrentYRange      = pWorkingArea->getGlobalBox()->Height() ;

  // Every toon fits inside the workingspace
  //
	if (iCurrentYRange <= iWorkingSpaceHeight)
  {
  	Show(SW_HIDE) ;
    return ;
  }

  int iRight = pWorkingArea->getWorkingSpaceRight() ;
  int iTop   = pWorkingArea->getWorkingSpaceTop() ;

  int iWidth = 10 ;
  // pInterface->SetWindowPos(0, wVisibleBox.Left(), wVisibleBox.Top(), wVisibleBox.Width(), wVisibleBox.Height(), SWP_NOZORDER) ;

  // Since we start from the bottom, we must "reverse" nPos
  //
  int iMaxDeltaPos = iCurrentYRange - iWorkingSpaceHeight ;
  int iThumbPos    = iMaxDeltaPos - pWorkingArea->getPosInfDroit() ;

  SCROLLINFO scInfo ;
	scInfo.cbSize = (UINT) sizeof(scInfo) ;
	scInfo.fMask = SIF_ALL ;
	scInfo.nMin  = 0 ;
	scInfo.nMax  = iCurrentYRange ;
	scInfo.nPage = (UINT) (iWorkingSpaceHeight) ;
	scInfo.nPos  = iThumbPos ;

  SetScrollInfo(&scInfo, TRUE) ;
  Show(SW_SHOW) ;

  // OWL::TScrollBar::Paint(dc, true, RectAPeindre) ;
}

void
NSLdvVerticalScrollBarInterface::EvRButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
  OWL::TScrollBar::EvRButtonDown(modKeys, point) ;
}

void
NSLdvVerticalScrollBarInterface::SBLineDown()
{
  if ((NULL == _pToon) || (NULL == _pToon->getToonParent()))
    return ;

  NSLdvViewArea *pWorkingArea = TYPESAFE_DOWNCAST(_pToon->getToonParent(), NSLdvViewArea) ;
  if (NULL != pWorkingArea)
    pWorkingArea->increasePosInfDroit(-5) ;
}

void
NSLdvVerticalScrollBarInterface::SBLineUp()
{
  if ((NULL == _pToon) || (NULL == _pToon->getToonParent()))
    return ;

  NSLdvViewArea *pWorkingArea = TYPESAFE_DOWNCAST(_pToon->getToonParent(), NSLdvViewArea) ;
  if (NULL != pWorkingArea)
    pWorkingArea->increasePosInfDroit(5) ;
}

void
NSLdvVerticalScrollBarInterface::SBPageDown()
{
}

void
NSLdvVerticalScrollBarInterface::SBPageUp()
{
}

NSLdvVerticalScrollBarInterface&
NSLdvVerticalScrollBarInterface::operator=(NSLdvVerticalScrollBarInterface& src)
{
  if (this == &src)
    return *this ;

  _pToon = src.getToon() ;

  return *this ;
}

bool
NSLdvVerticalScrollBarInterface::PreProcessMsg(MSG& msg)
{
  switch(msg.message)
  {
    case WM_PAINT:
    {
      // NS_CLASSLIB::TPoint pt1(LOWORD(msg.lParam), HIWORD(msg.lParam)) ;
      // NS_CLASSLIB::TPoint pt2(LOWORD(msg.wParam), HIWORD(msg.wParam)) ;
      // NS_CLASSLIB::TRect  rect1(pt1, pt2) ;

      TPaintDC dc(*this) ;
      NS_CLASSLIB::TRect& rect = *(NS_CLASSLIB::TRect*)&dc.Ps.rcPaint ;
      Paint(dc, true, rect) ;

      DefWindowProc(msg.message, msg.wParam, msg.lParam) ;

      break ;
    }
    case WM_NCPAINT:
      DefWindowProc(msg.message, msg.wParam, msg.lParam) ;
      break ;
  }

  return TWindow::PreProcessMsg(msg) ;
}
*/

// -----------------------------------------------------------------------------
//                       NSLdvCurveYAxis
// -----------------------------------------------------------------------------

NSLdvCurveYAxis::NSLdvCurveYAxis(NSContexte* pCtx, NSLdvWindowToon* pLdvParent, NSLdvView* pView, NSLdvCurve* pTheCurve)
                :NSLdvWindowToon(pCtx, pLdvParent, pView)
{
	pCurve = pTheCurve ;

	iZOrder   = LEVEL_COMMANDS ;
  toonType  = toonYAxis ;
  // toonShape = toonFullHeight ;
  sSkinName = string("LdvCurvesYAxis") ;

  initDimensions() ;

	_dLowAxisValue   = double(0) ;
  _dHighAxisValue  = double(0) ;

  _dLowActualValue = double(0) ;
  _dHigActualValue = double(0) ;

  _bIncludeZero    = true ;

  if (!initBoxFromSkin())
  {
    // int iBottom = pView->getPixelPosAboveChronoline(0) ;
    // int iHeight = pCurve->getCurvesPannel()->getYAxisPixelRange() ;

    // wVisibleBox = NS_CLASSLIB::TRect(0, iBottom + iHeight, 100, iBottom) ;
	}

  pInterface = new NSLdvCurveYAxisInterface(pContexte, getParentInterface(), this) ;
}

NSLdvCurveYAxis::NSLdvCurveYAxis(NSLdvCurveYAxis& rv)
                :NSLdvWindowToon(rv.pContexte, rv.getToonParent(), rv.pView)
{
  pCurve          = rv.pCurve ;

  _dLowActualValue = rv._dLowActualValue ;
  _dHigActualValue = rv._dHigActualValue ;

	_dLowAxisValue   = rv._dLowAxisValue ;
  _dHighAxisValue  = rv._dHighAxisValue ;

  _bIncludeZero    = rv._bIncludeZero ;
}

NSLdvCurveYAxis::~NSLdvCurveYAxis()
{
  if (NULL != pInterface)
    delete pInterface ;
}

void
NSLdvCurveYAxis::SetupWindow()
{
}

void
NSLdvCurveYAxis::setScrollParams()
{
}

void
NSLdvCurveYAxis::draw(TDC* pDc, NVLdVRect* pRectARepeindre)
{
  NSLdvViewArea* pWorkArea = pView->getActiveWorkingArea() ;
  if (NULL == pWorkArea)
    return ;

  NS_CLASSLIB::TRect screenRect = pWorkArea->getScrollablePhysicalRect(*pRectARepeindre) ;

  draw(pDc, &screenRect) ;
}

void
NSLdvCurveYAxis::draw(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
	drawAxis(pDc, pRectARepeindre) ;
}

bool
NSLdvCurveYAxis::MoveWindow(bool repaint)
{
  bool bMoveResult = NSLdvWindowToon::MoveWindow(repaint) ;

  if (NULL != pCurve->getFirstPoint())
    pCurve->reinit(false) ;

  return bMoveResult ;
}

void
NSLdvCurveYAxis::setVisible()
{
  bVisible = true ;
  if (NULL != pInterface)
    pInterface->Show(SW_SHOW) ;
}

void
NSLdvCurveYAxis::setHidden()
{
  bVisible = false ;
  if (NULL != pInterface)
    pInterface->Show(SW_HIDE) ;
}

void
NSLdvCurveYAxis::EvRButtonDown()
{
}

void
NSLdvCurveYAxis::drawAxis(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
	if (aTicks.empty())
  	return ;

  int iMaxTextHeight = 0 ;
  int iMaxTextWidth  = 0 ;

  vector<string>::iterator iter = aTicks.begin() ;
	for ( ; iter != aTicks.end() ; iter++)
	{
  	NS_CLASSLIB::TSize textSize = pDc->GetTextExtent((*iter).c_str(), strlen((*iter).c_str())) ;
    iMaxTextWidth  = max(textSize.X(), iMaxTextWidth) ;
    iMaxTextHeight = max(textSize.Y(), iMaxTextHeight) ;
  }

  // Need to resize the wVisibleBox ?
  //
  // if (wVisibleBox.Width() != iMaxTextWidth + 10)
  // 	wVisibleBox.Set(wVisibleBox.Left(), wVisibleBox.Top(),
  //              wVisibleBox.Left() + iMaxTextWidth + 10, wVisibleBox.Bottom()) ;

  // Erase the area
  //
  // NS_CLASSLIB::TRect windowsBox(wVisibleBox.Left(),
  //                              getWindowYValueFromLdVYValue(wVisibleBox.Top()),
  //                              wVisibleBox.Right(),
  //                              getWindowYValueFromLdVYValue(wVisibleBox.Bottom())) ;
  NS_CLASSLIB::TRect windowsBox = donneVisibleRectangle() ;
	pDc->FillRect(windowsBox, NS_CLASSLIB::TColor::White) ;

  // Draw ticks
  //
	iter = aTicks.begin() ;
	for ( ; iter != aTicks.end() ; iter++)
	{
		double dTickValue  = StringToDouble(*iter) ;
    int    iYPos       = giveYCoordinateForValue(dTickValue) ;
    int    iWinYPos    = getWindowYValueFromLdVYValue(iYPos) ;

    // Drawing the tick's text
    //
    int    iTextTop    = iWinYPos - iMaxTextHeight / 2 ;
    int    iTextBottom = iTextTop + iMaxTextHeight ;
    int    iTextLeft   = windowsBox.Left() ;
    int    iTextRight  = windowsBox.Left() + iMaxTextWidth ;

    NS_CLASSLIB::TRect textRect(iTextLeft, iTextTop, iTextRight, iTextBottom) ;
    pDc->DrawText((*iter).c_str(), -1, textRect, DT_RIGHT | DT_VCENTER) ;

    // Drawing the Tick's line
    //
    int iLeftTickLine  = windowsBox.Left() + iMaxTextWidth + 1 ;
    int iRightTickLine = windowsBox.Left() + iMaxTextWidth + 10 ;
    NS_CLASSLIB::TPoint ptLeft(iLeftTickLine, iWinYPos) ;
    pDc->MoveTo(ptLeft) ;
    NS_CLASSLIB::TPoint ptRight(iRightTickLine, iWinYPos) ;
    pDc->LineTo(ptRight) ;
  }

  // Draw the vertical separator
  //
  NS_CLASSLIB::TPoint ptTop = windowsBox.TopRight() ;
  pDc->MoveTo(ptTop) ;
  NS_CLASSLIB::TPoint ptBottom = windowsBox.BottomRight() ;
  pDc->LineTo(ptBottom) ;
}

//
// Return 0 for _dLowAxisValue and lYAxisPixelRange for _dHighAxisValue
//
int
NSLdvCurveYAxis::giveYCoordinateForValue(double dValue, bool bLimitedToAxisLimits)
{
	double dValueToCompute = dValue ;

  // Special cases
  //
  if (dValueToCompute == numeric_limits<double>::max())
  {
  	if (bLimitedToAxisLimits)
    	dValueToCompute = _dHighAxisValue ;
    else
			return numeric_limits<int>::max() ;
	}
  if (dValue == - numeric_limits<double>::max())
	{
  	if (bLimitedToAxisLimits)
    	dValueToCompute = _dLowAxisValue ;
    else
			return - numeric_limits<int>::max() ;
  }

  double dDeltaScale = _dHighAxisValue - _dLowAxisValue ;
  //
  // Since we will divide by dDeltaScale, better check it is != 0
  //
  if (dDeltaScale == double(0))
  	return 0 ;

  double dDeltaValue = dValueToCompute - _dLowAxisValue ;

	// int    iDeltaY         = pCurve->getCurvesPannel()->getYAxisPixelRange() ;
  NS_CLASSLIB::TRect windowsBox = donneVisibleRectangle() ;
  int    iDeltaY         = windowsBox.Height() ;
  int    iDeltaYForValue = iDeltaY * dDeltaValue / dDeltaScale ;

  int iReturnValue = iDeltaYForValue ;

  if (bLimitedToAxisLimits)
  {
  	if (iReturnValue < _dLowAxisValue)
    	iReturnValue = int(_dLowAxisValue) ;
    if (iReturnValue > _dHighAxisValue)
      iReturnValue = int(_dHighAxisValue) ;
  }

  return iReturnValue ;
}

int
NSLdvCurveYAxis::giveWorkingAreaYCoordinateForValue(double dValue, bool bLimitedToAxisLimits)
{
  int iInternalCoordinate = giveYCoordinateForValue(dValue, bLimitedToAxisLimits) ;

  if ((NULL == pInterface) || (false == pInterface->IsWindow()) || (NULL == pParent))
    return iInternalCoordinate ;

  int iAreaCoordinate = pParent->getYValueFromChildYValue(iInternalCoordinate, pInterface) ;

  return iAreaCoordinate ;
}

void
NSLdvCurveYAxis::initAxisValues(NSLdvCurvePoint* pFirstPoint)
{
  if (NULL == pFirstPoint)
    return ;

	_dLowActualValue = numeric_limits<double>::max() ;
  // _dHighAxisValue = numeric_limits<double>::min() ; // this give the lower exponent (E-x)
  _dHigActualValue = - numeric_limits<double>::max() ;

  NSLdvCurvePoint* pPoint = pFirstPoint ;

	while (NULL != pPoint)
  {
    if (pPoint->_dValue > _dHigActualValue)
    	_dHigActualValue = pPoint->_dValue ;
    if (pPoint->_dValue < _dLowActualValue)
    	_dLowActualValue = pPoint->_dValue ;

    pPoint = pPoint->_pNextBrother ;
  }

  // To be modified
  //
  _dLowAxisValue  = _dLowActualValue ;
  _dHighAxisValue = _dHigActualValue ;

  // Taking the background into account (background interval plus 10% margin)
  //
  if ((pCurve->pBackground) &&
      ((pCurve->pBackground->_bExistMinLimit || pCurve->pBackground->_bExistMaxLimit)))
  {
  	double dBgMargin = double(0) ;
    if (pCurve->pBackground->_bExistMinLimit && pCurve->pBackground->_bExistMaxLimit)
    	dBgMargin = 0.1 * (pCurve->pBackground->_dMaxLimit - pCurve->pBackground->_dMinLimit) ;
    else
		{
    	double dBgMinMargin = double(0) ;
      double dBgMaxMargin = double(0) ;
    	if (pCurve->pBackground->_bExistMinLimit)
      	dBgMinMargin = 0.1 * fabs(pCurve->pBackground->_dMinLimit) ;
      if (pCurve->pBackground->_bExistMaxLimit)
      	dBgMaxMargin = 0.1 * fabs(pCurve->pBackground->_dMaxLimit) ;

      dBgMargin = dBgMinMargin + dBgMaxMargin ;
    }

  	if (pCurve->pBackground->_bExistMinLimit)
    {
    	double dBgLowLowLimit = pCurve->pBackground->_dMinLimit - dBgMargin ;
      if (dBgLowLowLimit < _dLowAxisValue)
    		_dLowAxisValue = dBgLowLowLimit ;

      double dBgLowHighLimit = pCurve->pBackground->_dMinLimit + dBgMargin ;
      if (dBgLowHighLimit > _dHighAxisValue)
    		_dHighAxisValue = dBgLowHighLimit ;
    }

		if (pCurve->pBackground->_bExistMaxLimit)
    {
    	double dBgHighHighLimit = pCurve->pBackground->_dMaxLimit + dBgMargin ;
      if (dBgHighHighLimit > _dHighAxisValue)
    		_dHighAxisValue = dBgHighHighLimit ;

      double dBgHighLowLimit = pCurve->pBackground->_dMaxLimit - dBgMargin ;
      if (dBgHighLowLimit < _dLowAxisValue)
    		_dLowAxisValue = dBgHighLowLimit ;
    }
  }

	adjustAxisMinMaxValues(_dLowAxisValue, _dHighAxisValue) ;

  computeTicks(_dLowAxisValue, _dHighAxisValue, 20) ;
}

void
NSLdvCurveYAxis::adjustAxisMinMaxValues(double& axisMinVal, double& axisMaxVal)
{
	if ((axisMinVal == double(0)) && (axisMaxVal == double(0)))
  {
  	_dHighAxisValue = 1 ;
    return ;
  }

  double dCommonValue ;
  int    iCommon10log ;
  bool bIsCommonValue = getCommonValue(axisMinVal, axisMaxVal, dCommonValue, iCommon10log) ;

  	//
    // Example : min = 1.345 max = 1.352
    //           -> commonValue 1.3 common10log -1
    //           roundDown -> minAxis = 1.3 roundUp -> maxAxis = 1.4
    //           nice
    //
    // Example : min = 90 max = 95
    //           -> commonValue 90 common10log 1
    //           roundDown -> minAxis = 90 roundUp -> maxAxis = 100
    //           not nice because min values are stuck to the bottom line
    //           so, remove one power10 of common10log
    //           -> minAxis = 80 maxAxis = 100 : nice
    //

  if (!bIsCommonValue)
  	//
    // Example : min = 1.345 max = 2.512
    //           -> commonValue 1.3 common10log -1
    //           roundDown -> minAxis = 1.3 roundUp -> maxAxis = 1.4
    //           nice
    //
    iCommon10log = min(getPrecision(axisMinVal), getPrecision(axisMaxVal)) ;

  double dRoundedValue ;

  dRoundedValue = roundDown(axisMinVal, -iCommon10log) ;
  if (axisMinVal == dRoundedValue)
  	axisMinVal -= pow(double(10), double(iCommon10log)) ;
  else
  	axisMinVal = dRoundedValue ;

  dRoundedValue = roundUp(axisMaxVal, -iCommon10log) ;
  if (axisMaxVal == dRoundedValue)
  	axisMaxVal += pow(double(10), double(iCommon10log)) ;
  else
  	axisMaxVal = dRoundedValue ;

  if (_bIncludeZero)
  {
  	if (axisMinVal > 0)
    	axisMinVal = 0 ;
    else if (axisMaxVal < 0)
    	axisMaxVal = 0 ;
  }

  return ;
}

void
NSLdvCurveYAxis::emptyTicks()
{
	if (aTicks.empty())
		return ;

	vector<string>::iterator iter;
	for (iter = aTicks.begin(); iter != aTicks.end();)
  	aTicks.erase(iter) ;
}

void
NSLdvCurveYAxis::computeTicks(double ticMinVal, double ticMaxVal, int maxTicks)
{
	emptyTicks() ;

  if (ticMaxVal <= ticMinVal)
		return ;

	double xStep = quantaRoundUp((ticMaxVal - ticMinVal) / maxTicks) ;
	int numfracdigits = numFracDigits(xStep) ;

	// Compute x starting point so it is a multiple of xStep.
	double xStart = xStep * ceil(ticMinVal / xStep) ;

	// Label the axis.  The labels are quantized so that
	// they don't have excess resolution.
	for (double xpos = xStart; xpos <= ticMaxVal; xpos += xStep)
  	aTicks.push_back(DoubleToString(&xpos, 0, numfracdigits)) ;
}

//
// Given a number, round up to the nearest power of ten
// times 1, 2, or 5.
//
// Note: The argument must be strictly positive.
//
double
NSLdvCurveYAxis::quantaRoundUp(double val)
{
	int exponent = (int) floor(log10(val)) ;

  val *= pow(10, -exponent) ;
  if (val > 5.0)
  	val = 10.0 ;
	else if (val > 2.0)
  	val = 5.0 ;
	else if (val > 1.0)
		val = 2.0 ;

	val *= pow(10, exponent) ;
	return val ;
}

//
// Return the number of fractional digits required to display the
// given number.  No number larger than 15 is returned (if
// more than 15 digits are required, 15 is returned).
//
int
NSLdvCurveYAxis::numFracDigits(double num)
{
	int numdigits = 0 ;
  while ((numdigits <= 15) && (num != floor(num)))
	{
		num *= 10.0 ;
		numdigits += 1 ;
	}
	return numdigits ;
}

//
// Return the common value for val1 and val2
// ie if val1 = 1.23 and val2 = 1.25 then common = 1.2
//
// iCommon10log is limited to -15
//
bool
NSLdvCurveYAxis::getCommonValue(double val1, double val2, double& common, int& iCommon10log)
{
	if (val1 == val2)
	{
  	common = val1 ;
    iCommon10log = getPrecision(common) + 1 ;
    return true ;
  }

	double dMax = max(val1, val2) ;
  double dMin = min(val1, val2) ;

  if ((dMax > double(0)) && (dMin < double(0)))
  	return false ;

  double dLog = log10(dMax) ;
  int	   iLog = int(dLog) ;
  double dMult = pow(double(10), double(iLog)) ;
  double dResuMax ;
  double dResuMin ;

  bool   bResult = false ;

  common = double(0) ;

  // Comparing the integer value
  //
  while (iLog >= -15)
  {
    dResuMax = floor(dMax / dMult) ;
    dResuMin = floor(dMin / dMult) ;

    if (dResuMax == dResuMin)
    {
    	bResult = true ;

    	common = dResuMax * dMult ;
      iCommon10log = iLog ;

      dMax = dMax - (dResuMax * dMult) ;
      dMin = dMin - (dResuMin * dMult) ;

    	dMult = dMult / 10 ;
    	iLog-- ;
    }
    else
    	return bResult ;
  }
  return bResult ;
}

int
NSLdvCurveYAxis::getPrecision(double dVal)
{
	int    iPrecision = 0 ;
  double dTruncatedVal = trunc(dVal, 0) ;

  // Means it is an integer : look for the number of zeros
  //
  if (dTruncatedVal == dVal)
  {
  	while ((iPrecision > -15) && (dTruncatedVal == dVal))
    {
    	iPrecision-- ;
      dTruncatedVal = trunc(dVal, iPrecision) ;
    }
    iPrecision++ ;
  }
  //
  // Means it in the forme X.Y: look for the precision
  //
  else
  {
  	while ((iPrecision < 15) && (dTruncatedVal == dVal))
    {
    	iPrecision++ ;
      dTruncatedVal = trunc(dVal, iPrecision) ;
    }
    iPrecision-- ;
  }

  return iPrecision ;
}

//
// Rounds the given number up to the supplied number of decimal places
//
// roundUp(76.9,0) returns 77
// roundUp(31415.92654, -2) returns 31500
//
double
NSLdvCurveYAxis::roundUp(double dVal, int iPrecision)
{
	return ceil(dVal * pow(double(10), double(iPrecision))) / pow(double(10), double(iPrecision)) ;
}

//
// Rounds a number down
//
// ROUNDDOWN(3.14159, 3) returns 31.141
// ROUNDDOWN(31415.92654, -2) returns 31.400
//
double
NSLdvCurveYAxis::roundDown(double dVal, int iPrecision)
{
	return floor(dVal * pow(double(10), double(iPrecision))) / pow(double(10), double(iPrecision)) ;
}

//
// Removes the fractional part of a number to the specified precision
// without rounding the number
//
// TRUNC(123.456, 2) returns 123.45
// TRUNC(9899.435, �2) returns 9800
//
double
NSLdvCurveYAxis::trunc(double dVal, int iPrecision)
{
	int iVal = int(dVal * pow(double(10), double(iPrecision))) ;
	return double(iVal) / pow(double(10), double(iPrecision)) ;
}

NSLdvCurveYAxis&
NSLdvCurveYAxis::operator=(NSLdvCurveYAxis& src)
{
	if (this == &src)
	  return *this ;

  pCurve          = src.pCurve ;

  _dLowActualValue = src._dLowActualValue ;
  _dHigActualValue = src._dHigActualValue ;

	_dLowAxisValue   = src._dLowAxisValue ;
  _dHighAxisValue  = src._dHighAxisValue ;

  _bIncludeZero    = src._bIncludeZero ;

  return *this ;
}

// -----------------------------------------------------------------------------
// ----------------- METHODES DE NSLdvCurveYAxisInterface --------------------
// -----------------------------------------------------------------------------

NSLdvCurveYAxisInterface::NSLdvCurveYAxisInterface(NSContexte* pCtx, TWindow* parent, NSLdvCurveYAxis* pToon)
                         :TWindow(parent), NSRoot(pCtx)
{
  _pToon = pToon ;

  SetCaption(_pToon->sSkinName.c_str()) ;
}

NSLdvCurveYAxisInterface::NSLdvCurveYAxisInterface(NSLdvCurveYAxisInterface& rv)
                         :TWindow(rv.GetParent()), NSRoot(rv.pContexte)
{
  _pToon = rv.getToon() ;
}

NSLdvCurveYAxisInterface::~NSLdvCurveYAxisInterface()
{
}

void
NSLdvCurveYAxisInterface::SetupWindow()
{
  TWindow::SetupWindow() ;
}

void
NSLdvCurveYAxisInterface::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectAPeindre)
{
  _pToon->draw(&dc, &RectAPeindre) ;
}

void
NSLdvCurveYAxisInterface::EvRButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
  TWindow::EvRButtonDown(modKeys, point) ;
}

NSLdvCurveYAxisInterface&
NSLdvCurveYAxisInterface::operator=(NSLdvCurveYAxisInterface& src)
{
  if (this == &src)
    return *this ;

  _pToon = src.getToon() ;

  return *this ;
}

// -----------------------------------------------------------------------------
//                       NSLdvCurveBackgroundQuadri
// -----------------------------------------------------------------------------

NSLdvCurveBackgroundQuadri::NSLdvCurveBackgroundQuadri(NSLdvView* pVw)
{
	pView = pVw ;

  color = NS_CLASSLIB::TColor(NS_CLASSLIB::TColor::White) ;

	_tpsLowerLeft.init() ;
	_dValueLowerLeft    = double(0) ;
  _sUnitSensLowerLeft = string("") ;

  _tpsLowerRight.init() ;
	_dValueLowerRight    = double(0) ;
	_sUnitSensLowerRight = string("") ;

	_tpsUpperLeft.init() ;
	_dValueUpperLeft    = double(0) ;
	_sUnitSensUpperLeft = string("") ;

  _tpsUpperRight.init() ;
	_dValueUpperRight    = double(0) ;
	_sUnitSensUpperRight = string("") ;
}

NSLdvCurveBackgroundQuadri::NSLdvCurveBackgroundQuadri(NSLdvView* pVw, NS_CLASSLIB::TColor qColor, NVLdVTemps beginDate, NVLdVTemps endDate, double lowerValue, string lowerUnit, double upperValue, string upperUnit)
{
	pView = pVw ;

  color = qColor ;

	string sLowerUnitSens ;
  pView->pContexte->getDico()->donneCodeSens(&lowerUnit, &sLowerUnitSens) ;

  _tpsLowerLeft        = beginDate ;
	_dValueLowerLeft     = lowerValue ;
  _sUnitSensLowerLeft  = sLowerUnitSens ;

  _tpsLowerRight       = endDate ;
	_dValueLowerRight    = lowerValue ;
	_sUnitSensLowerRight = sLowerUnitSens ;

  string sUpperUnitSens ;
  pView->pContexte->getDico()->donneCodeSens(&upperUnit, &sUpperUnitSens) ;

	_tpsUpperLeft        = beginDate ;
	_dValueUpperLeft     = upperValue ;
	_sUnitSensUpperLeft  = sUpperUnitSens ;

  _tpsUpperRight       = endDate ;
	_dValueUpperRight    = upperValue ;
	_sUnitSensUpperRight = sUpperUnitSens ;
}

NSLdvCurveBackgroundQuadri::~NSLdvCurveBackgroundQuadri()
{
}

NSLdvCurveBackgroundQuadri::NSLdvCurveBackgroundQuadri(NSLdvCurveBackgroundQuadri& rv)
{
	pView = rv.pView ;

  color = rv.color ;

  _tpsLowerLeft        = rv._tpsLowerLeft ;
	_dValueLowerLeft     = rv._dValueLowerLeft ;
  _sUnitSensLowerLeft  = rv._sUnitSensLowerLeft ;

  _tpsLowerRight       = rv._tpsLowerRight ;
	_dValueLowerRight    = rv._dValueLowerRight ;
	_sUnitSensLowerRight = rv._sUnitSensLowerRight ;

	_tpsUpperLeft        = rv._tpsUpperLeft ;
	_dValueUpperLeft     = rv._dValueUpperLeft ;
	_sUnitSensUpperLeft  = rv._sUnitSensUpperLeft ;

  _tpsUpperRight       = rv._tpsUpperRight ;
	_dValueUpperRight    = rv._dValueUpperRight ;
	_sUnitSensUpperRight = rv._sUnitSensUpperRight ;
}

NSLdvCurveBackgroundQuadri&
NSLdvCurveBackgroundQuadri::operator=(NSLdvCurveBackgroundQuadri& src)
{
	if (this == &src)
		return *this ;

	pView = src.pView ;

  color = src.color ;

  _tpsLowerLeft        = src._tpsLowerLeft ;
	_dValueLowerLeft     = src._dValueLowerLeft ;
  _sUnitSensLowerLeft  = src._sUnitSensLowerLeft ;

  _tpsLowerRight       = src._tpsLowerRight ;
	_dValueLowerRight    = src._dValueLowerRight ;
	_sUnitSensLowerRight = src._sUnitSensLowerRight ;

	_tpsUpperLeft        = src._tpsUpperLeft ;
	_dValueUpperLeft     = src._dValueUpperLeft ;
	_sUnitSensUpperLeft  = src._sUnitSensUpperLeft ;

  _tpsUpperRight       = src._tpsUpperRight ;
	_dValueUpperRight    = src._dValueUpperRight ;
	_sUnitSensUpperRight = src._sUnitSensUpperRight ;

  return *this ;
}

// -----------------------------------------------------------------------------
//                       NSLdvCurveBackground
// -----------------------------------------------------------------------------

NSLdvCurveBackground::NSLdvCurveBackground(NSContexte* pCtx, NSLdvViewArea *pWorkArea, NSLdvCurve* pTheCurve)
                     :NSLdvTimeToon(pCtx, pWorkArea, true)
{
	iZOrder  = LEVEL_BACKGROUND ;
  toonType = toonBackground ;

	pCurve = pTheCurve ;

	_bExistMaxLimit = false ;
	_dMaxLimit      = double(0) ;
	_sMaxLimitUnit  = string("") ;

	_bExistMinLimit = false ;
	_dMinLimit      = double(0) ;
	_sMinLimitUnit  = string("") ;

  _bInterceptRButtonDown = false ;
}

NSLdvCurveBackground::NSLdvCurveBackground(NSLdvCurveBackground& rv)
                     :NSLdvTimeToon(rv.pContexte, rv._pWorkingArea, rv._bVerticalScrollEnabled)
{
	pCurve   = rv.pCurve ;
  aQuadris = rv.aQuadris ;

  _bExistMaxLimit = rv._bExistMaxLimit ;
	_dMaxLimit      = rv._dMaxLimit ;
	_sMaxLimitUnit  = rv._sMaxLimitUnit ;

	_bExistMinLimit = rv._bExistMinLimit ;
	_dMinLimit      = rv._dMinLimit ;
	_sMinLimitUnit  = rv._sMinLimitUnit ;
}

NSLdvCurveBackground::~NSLdvCurveBackground()
{
}

void
NSLdvCurveBackground::SetupWindow()
{
}

void
NSLdvCurveBackground::draw(TDC* pDc, NVLdVRect* pRectARepeindre)
{
  NSLdvViewArea* pWorkArea = pView->getActiveWorkingArea() ;
  if (NULL == pWorkArea)
    return ;

	NS_CLASSLIB::TRect screenRect = pWorkArea->getScrollablePhysicalRect(*pRectARepeindre) ;

  draw(pDc, &screenRect) ;
}

void
NSLdvCurveBackground::draw(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
	drawQuadris(pDc, pRectARepeindre) ;
}

void
NSLdvCurveBackground::EvRButtonDown()
{
}

void
NSLdvCurveBackground::drawQuadris(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
	if (aQuadris.empty())
  	return ;

	for (NSLdvQuadriIter QIt = aQuadris.begin() ; QIt != aQuadris.end() ; QIt++ )
  	drawAQuadri(pDc, pRectARepeindre, *QIt) ;
}

TRegion
NSLdvCurveBackground::getQuadriAsARegion(NSLdvCurveBackgroundQuadri* pQuadri, bool* pSuccess)
{
	if (NULL != pSuccess)
  	*pSuccess = true ;

	// We ask for Y values limited to axis' reference frame
  //
	bool bSuccess ;
  int iYforLowerLeft  = pCurve->giveYCoordinateForValue(pQuadri->_dValueLowerLeft,  &bSuccess, pQuadri->_sUnitSensLowerLeft, true) ;
  int iYforUpperLeft  = pCurve->giveYCoordinateForValue(pQuadri->_dValueUpperLeft,  &bSuccess, pQuadri->_sUnitSensUpperLeft, true) ;
  int iYforUpperRight = pCurve->giveYCoordinateForValue(pQuadri->_dValueUpperRight, &bSuccess, pQuadri->_sUnitSensUpperRight, true) ;
  int iYforLowerRight = pCurve->giveYCoordinateForValue(pQuadri->_dValueLowerRight, &bSuccess, pQuadri->_sUnitSensLowerRight, true) ;

  if ((bSuccess == false) || ((iYforLowerLeft == iYforUpperLeft) && (iYforUpperRight == iYforLowerRight)))
  {
  	if (NULL != pSuccess)
  		*pSuccess = false ;
    return TRegion() ;
  }

	NS_CLASSLIB::TPoint aQuadPts[5] ;

  NSLdvViewArea* pWorkArea = pView->getActiveWorkingArea() ;
  if (NULL == pWorkArea)
    return TRegion(aQuadPts, 5, ALTERNATE) ;

  NVLdVPoint ldvPoint(pView) ;

  ldvPoint.setX(pQuadri->_tpsLowerLeft) ;
  ldvPoint.setY(iYforLowerLeft) ;
  aQuadPts[0] = pWorkArea->getScrollablePhysicalPoint(ldvPoint) ;

  ldvPoint.setX(pQuadri->_tpsUpperLeft) ;
  ldvPoint.setY(iYforUpperLeft) ;
  aQuadPts[1] = pWorkArea->getScrollablePhysicalPoint(ldvPoint) ;

  ldvPoint.setX(pQuadri->_tpsUpperRight) ;
  ldvPoint.setY(iYforUpperRight) ;
  aQuadPts[2] = pWorkArea->getScrollablePhysicalPoint(ldvPoint) ;

  ldvPoint.setX(pQuadri->_tpsLowerRight) ;
  ldvPoint.setY(iYforLowerRight) ;
  aQuadPts[3] = pWorkArea->getScrollablePhysicalPoint(ldvPoint) ;

  aQuadPts[4] = aQuadPts[0] ;

  return TRegion(aQuadPts, 5, ALTERNATE) ;
}

void
NSLdvCurveBackground::drawAQuadri(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre, NSLdvCurveBackgroundQuadri* pQuadri)
{
	if (NULL == pDc)
		return ;

	bool bSuccess ;
	TRegion region = getQuadriAsARegion(pQuadri, &bSuccess) ;

  if (false == bSuccess)
		return ;

	int iAncDC = pDc->SaveDC() ;
  pDc->FillRgn(region, pQuadri->color) ;
  pDc->RestoreDC(iAncDC) ;
}

void
NSLdvCurveBackground::addQuadri(NSLdvCurveBackgroundQuadri* pQuadri)
{
	aQuadris.push_back(new NSLdvCurveBackgroundQuadri(*pQuadri)) ;
}

void
NSLdvCurveBackground::eraseQuadri()
{
	aQuadris.vider() ;
}

NSLdvCurveBackground&
NSLdvCurveBackground::operator=(NSLdvCurveBackground& src)
{
	if (this == &src)
		return *this ;

	pCurve          = src.pCurve ;
  aQuadris        = src.aQuadris ;

	_bExistMaxLimit = src._bExistMaxLimit ;
	_dMaxLimit      = src._dMaxLimit ;
	_sMaxLimitUnit  = src._sMaxLimitUnit ;

	_bExistMinLimit = src._bExistMinLimit ;
	_dMinLimit      = src._dMinLimit ;
	_sMinLimitUnit  = src._sMinLimitUnit ;

  return *this ;
}

// -----------------------------------------------------------------------------
//                       NSLdvCurvesManagementPannel
// -----------------------------------------------------------------------------

const int ID_CurvesList = 0x100 ;

NSLdvCurvesManagementPannel::NSLdvCurvesManagementPannel(NSContexte* pCtx, NSLdvWindowToon* pLdvParent, NSLdvView* pView)
                            :NSLdvWindowToon(pCtx, pLdvParent, pView)
{
	iZOrder   = LEVEL_COMMANDS ;
  toonType  = toonCurvePannel ;
  // toonShape = toonSizeLimited ;
  sSkinName = string("LdvCurvesManagementPannel") ;

  initDimensions() ;

  if (!initBoxFromSkin())
  {
  	NS_CLASSLIB::TRect wRect = pView->GetClientRect() ;
  	NS_CLASSLIB::TRect pannelRect = pView->getDateTimeArea() ;
		// wVisibleBox = NS_CLASSLIB::TRect(600, 0, 800, pannelRect.Height()) ;
  }

  pInterface = new NSLdvCurvesManagementPannelInterface(pContexte, getParentInterface(), this) ;

  pCurvesListManager = new NSCurvesProperty(pContexte, this, pView) ;

  iSortedColumn = -1 ;
  bNaturallySorted = false ;
}

NSLdvCurvesManagementPannel::NSLdvCurvesManagementPannel(NSLdvCurvesManagementPannel& rv)
                            :NSLdvWindowToon(rv.pContexte, rv.getToonParent(), rv.pView)
{
	sSkinName = rv.sSkinName ;

	initialiser((NSLdvWindowToon*)(&rv)) ;
}


NSLdvCurvesManagementPannel::~NSLdvCurvesManagementPannel()
{
}

void
NSLdvCurvesManagementPannel::setScrollParams()
{
}

void
NSLdvCurvesManagementPannel::CmNew()
{
try
{
	NSLdvCurve* pNewCurve = new NSLdvCurve(this) ;
  searchNextCurveParams(&(pNewCurve->color), &(pNewCurve->pointAspect), &(pNewCurve->pointRadius), &(pNewCurve->dotWidth)) ;

	NSNewCurveDlg* pNewCurvDialog = new NSNewCurveDlg(pView, pContexte, pNewCurve) ;
  int iExecReturn = pNewCurvDialog->Execute() ;
  delete pNewCurvDialog ;

	if (iExecReturn != IDOK)
  {
  	delete pNewCurve ;
    return ;
  }

  NSLdvViewArea* pActiveWorkingArea = pView->getActiveWorkingArea() ;
  if (NULL != pActiveWorkingArea)
  {
    if ((NULL != pNewCurve->pAxis) && (NULL != pNewCurve->pAxis->getInterface()))
      pNewCurve->pAxis->getInterface()->Create() ;
    pView->EvaluateWinToonsPos(pActiveWorkingArea->getInterface(), pActiveWorkingArea->getToonsArray()) ;

    pView->addToToonsArray(pActiveWorkingArea->getToonsArray(), pNewCurve->pBackground) ;
  }

  pNewCurve->init() ;

  aCurves.push_back(pNewCurve) ;

  pCurvesListManager->displayElement(pNewCurve) ;
  CmPutUp(pNewCurve->sCompoundLabel) ;

  pView->Invalidate(true) ;
}
catch (...)
{
	erreur("Exception NSLdvCurvesManagementPannel::CmNew", standardError, 0) ;
}
}

bool
NSLdvCurvesManagementPannel::CmSupres(string sLabelToSuppress)
{
	if (sLabelToSuppress == string(""))
		return false ;

  if (aCurves.empty())
		return false ;

  ArrayOfCurvesIter curveIter = aCurves.begin() ;
  for (; (curveIter != aCurves.end()) && ((*curveIter)->sCompoundLabel != sLabelToSuppress); curveIter++) ;

  if (curveIter == aCurves.end())
  	return false ;

	// Suppress the curve
  //
  (*curveIter)->close() ;
  delete *curveIter ;
  aCurves.erase(curveIter) ;

  // PutUp next curve
  //
  if (!(aCurves.empty()))
  {
  	if (curveIter == aCurves.end())
    	curveIter-- ;
    CmPutUp((*curveIter)->sCompoundLabel) ;
  }
  else
  	pView->Invalidate(true) ;

  return true ;
}

void
NSLdvCurvesManagementPannel::CmPutUp(string sLabelToPutUp)
{
	if (sLabelToPutUp == string(""))
		return ;

  if (aCurves.empty())
		return ;

	ArrayOfCurvesIter curveIter = aCurves.begin() ;
  for (; curveIter != aCurves.end() ; curveIter++)
  {
  	if ((*curveIter)->sCompoundLabel == sLabelToPutUp)
    {
    	(*curveIter)->pAxis->setVisible() ;
      (*curveIter)->pBackground->setVisible() ;
    }
    else
    {
    	(*curveIter)->pAxis->setHidden() ;
      (*curveIter)->pBackground->setHidden() ;
    }
  }

  pCurvesListManager->selectItem(sLabelToPutUp) ;

  pView->Invalidate(true) ;
}

void
NSLdvCurvesManagementPannel::CmModify(string sLabelToModify)
{
	if (sLabelToModify == string(""))
		return ;

  if (aCurves.empty())
		return ;

	ArrayOfCurvesIter curveIter = aCurves.begin() ;
  for (; (curveIter != aCurves.end()) && ((*curveIter)->sCompoundLabel != sLabelToModify); curveIter++) ;

  if (curveIter == aCurves.end())
  	return ;

  string sPreviousUnitSens ;
  pContexte->getDico()->donneCodeSens(&((*curveIter)->sUnit), &sPreviousUnitSens) ;

  NSNewCurveDlg* pNewCurvDialog = new NSNewCurveDlg(pView, pContexte, *curveIter, true) ;
  int iExecReturn = pNewCurvDialog->Execute() ;
  delete pNewCurvDialog ;

  string sNewUnitSens ;
  pContexte->getDico()->donneCodeSens(&((*curveIter)->sUnit), &sNewUnitSens) ;

  (*curveIter)->reinit(sPreviousUnitSens != sNewUnitSens) ;

  pView->Invalidate(true) ;
}

void
NSLdvCurvesManagementPannel::autoCreateNewCurve(string sLexiqueCode)
{
	if (sLexiqueCode == string(""))
		return ;

	// If a curve already exists, it is not useful to draw another one
  //
	NSLdvCurve* pExistingCurve = searchExistingCurveForThisConcept(sLexiqueCode) ;
  if (NULL != pExistingCurve)
		return ;

	NSLdvCurve* pNewCurve = new NSLdvCurve(this) ;

	pNewCurve->sItemValue = sLexiqueCode ;

  searchNextCurveParams(&(pNewCurve->color), &(pNewCurve->pointAspect), &(pNewCurve->pointRadius), &(pNewCurve->dotWidth)) ;

  pNewCurve->init() ;

  aCurves.push_back(pNewCurve) ;

  NSLdvViewArea* pActiveWorkingArea = pView->getActiveWorkingArea() ;
  if (NULL != pActiveWorkingArea)
  {
    pView->addToToonsArray(pActiveWorkingArea->getToonsArray(), pNewCurve->pAxis) ;
    pView->addToToonsArray(pActiveWorkingArea->getToonsArray(), pNewCurve->pBackground) ;
  }

  pCurvesListManager->displayElement(pNewCurve) ;
  CmPutUp(pNewCurve->sCompoundLabel) ;

  pView->Invalidate(true) ;
}

void
NSLdvCurvesManagementPannel::searchNextCurveParams(NS_CLASSLIB::TColor* pColor, int* pPtAspect, int* pPtRadius, int* pLineWidth)
{
  if (NULL != pColor)
    findNextColor(pColor) ;

  if (NULL != pPtAspect)
    *pPtAspect = NSLdvCurve::paCircle ;

  if (NULL != pPtRadius)
    *pPtRadius = findCommonPointRadius() ;

  if (NULL != pLineWidth)
    *pLineWidth = findCommonLineWidth() ;
}

NSLdvCurve*
NSLdvCurvesManagementPannel::searchExistingCurveForThisConcept(string sLexique)
{
	if (aCurves.empty())
		return NULL ;

	string sCodeSens ;
	pContexte->getDico()->donneCodeSens(&sLexique, &sCodeSens) ;

  ArrayOfCurvesIter curveIter = aCurves.begin() ;
  for (; curveIter != aCurves.end() ; curveIter++)
  {
  	string sCurveLex = (*curveIter)->sItemValue ;
    string sCurveLexSens ;
		pContexte->getDico()->donneCodeSens(&sCurveLex, &sCurveLexSens) ;

    if (sCurveLexSens == sCodeSens)
    	return *curveIter ;
  }
  
  return NULL ;
}

NSLdvCurve*
NSLdvCurvesManagementPannel::searchExistingCurveForThisColor(int iRed, int iGreen, int iBlue)
{
	if (aCurves.empty())
		return NULL ;

  ArrayOfCurvesIter curveIter = aCurves.begin() ;
  for (; curveIter != aCurves.end() ; curveIter++)
  	if (((*curveIter)->color.Red()   == iRed)   &&
        ((*curveIter)->color.Green() == iGreen) &&
        ((*curveIter)->color.Blue()  == iBlue))
  		return *curveIter ;

	return NULL ;
}

int
NSLdvCurvesManagementPannel::findCommonLineWidth()
{
  if (aCurves.empty())
		return 2 ;

  int iMinLineWidth = 1000 ;
  int iMaxLineWidth = -1 ;

  ArrayOfCurvesIter curveIter = aCurves.begin() ;
  for (; curveIter != aCurves.end() ; curveIter++)
  {
    if ((*curveIter)->getDotWidth() > iMaxLineWidth)
      iMaxLineWidth = (*curveIter)->getDotWidth() ;

    if ((*curveIter)->getDotWidth() < iMinLineWidth)
      iMinLineWidth = (*curveIter)->getDotWidth() ;
  }

  return ((iMinLineWidth + iMaxLineWidth) / 2) ;
}

int
NSLdvCurvesManagementPannel::findCommonPointRadius()
{
  if (aCurves.empty())
		return 3 ;

  int iMinRadius = 1000 ;
  int iMaxRadius = -1 ;

  ArrayOfCurvesIter curveIter = aCurves.begin() ;
  for (; curveIter != aCurves.end() ; curveIter++)
  {
    if ((*curveIter)->getDotWidth() > iMaxRadius)
      iMaxRadius = (*curveIter)->getPointRadius() ;

    if ((*curveIter)->getDotWidth() < iMinRadius)
      iMinRadius = (*curveIter)->getPointRadius() ;
  }

  return ((iMinRadius + iMaxRadius) / 2) ;
}

void
NSLdvCurvesManagementPannel::findNextColor(NS_CLASSLIB::TColor* pColor)
{
  // algorithm: we take 'legal' values as combination of RGB values in the range
	// 0, 51, 102, 153, 204, 255 (see http://en.wikipedia.org/wiki/RGB_color_model)
  //
	// We take a combination at random, then check if it is not already used
  // If already in use, we select a new random color

  int aColors[6] ;
  for (int i = 0; i < 6; i++)
  	aColors[i] = 51 * i ;

	int iRed   = 255 ;
  int iGreen = 255 ;
  int iBlue  = 255 ;

	bool bChooseColor = true ;
  while (bChooseColor)
  {
  	iRed   = aColors[random(6)] ;
    iGreen = aColors[random(6)] ;
    iBlue  = aColors[random(6)] ;

    // White is not allowed
    //
    if ((iRed != 255) || (iGreen != 255) || (iBlue != 255))
    {
    	NSLdvCurve* pColorCurve = searchExistingCurveForThisColor(iRed, iGreen, iBlue) ;
      if (NULL == pColorCurve)
      	bChooseColor = false ;
    }
  }
	*pColor = NS_CLASSLIB::TColor(iRed, iGreen, iBlue) ;
}

void
NSLdvCurvesManagementPannel::EvRButtonDown()
{
}

void
NSLdvCurvesManagementPannel::SetupWindow()
{
	// pListeWindow->MoveWindow(wVisibleBox, true) ;

  // Setting the lYAxisPixelRange value: space left between the main Panel and
  // the chronoLine
  //
  NS_CLASSLIB::TRect screenRect = pView->GetClientRect() ;

  lYAxisPixelRange = screenRect.Height() ;

  // NSLdvWindowToon* pPannel = pView->getLdVWinToon(toonPannel) ;
  // if (pPannel)
  //	lYAxisPixelRange -= pPannel->wVisibleBox.Height() ;

  // NSLdvWindowToon* pChrono = pView->getLdVWinToon(toonChronoLine) ;
  // if (pChrono)
  //	lYAxisPixelRange -= pChrono->wVisibleBox.Height() ;
}

void
NSLdvCurvesManagementPannel::draw(TDC* pDc, NVLdVRect* pRectARepeindre)
{
  NS_CLASSLIB::TRect screenRect = pView->getGlobalPhysicalRect(*pRectARepeindre) ;

  draw(pDc, &screenRect) ;
}

void
NSLdvCurvesManagementPannel::draw(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
	skinDraw(pDc, pRectARepeindre) ;
}

void
NSLdvCurvesManagementPannel::DispInfoListe(TLwDispInfoNotify& dispInfo)
{
}

void
NSLdvCurvesManagementPannel::LVNColumnclick(TLwNotify& lwn)
{
}

void
NSLdvCurvesManagementPannel::sortByName()
{
}

void
NSLdvCurvesManagementPannel::sortByEnding()
{
}

void
NSLdvCurvesManagementPannel::sortByBegining()
{
}

// -----------------------------------------------------------------------------
// --------------- METHODES DE NSLdvCommandPannelInterface ------------------
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSLdvCurvesManagementPannelInterface, TWindow)
  EV_WM_RBUTTONDOWN,
END_RESPONSE_TABLE ;

NSLdvCurvesManagementPannelInterface::NSLdvCurvesManagementPannelInterface(NSContexte* pCtx, TWindow* parent, NSLdvCurvesManagementPannel* pToon)
                                     :TWindow(parent), NSRoot(pCtx)
{
  _pToon = pToon ;

  SetCaption(_pToon->sSkinName.c_str()) ;
}

NSLdvCurvesManagementPannelInterface::NSLdvCurvesManagementPannelInterface(NSLdvCurvesManagementPannelInterface& rv)
                                     :TWindow(rv.GetParent()), NSRoot(rv.pContexte)
{
  _pToon = rv.getToon() ;
}

NSLdvCurvesManagementPannelInterface::~NSLdvCurvesManagementPannelInterface()
{
}

void
NSLdvCurvesManagementPannelInterface::SetupWindow()
{
  TWindow::SetupWindow() ;
}

void
NSLdvCurvesManagementPannelInterface::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectAPeindre)
{
  _pToon->skinDraw(&dc, &RectAPeindre) ;

/*
  uint iChildrenNb = NumChildren() ;
  if (iChildrenNb <= 0)
    return ;

  TWindow* pChild = GetFirstChild() ;
  int i = 0 ;
  while ((NULL != pChild) && (i < iChildrenNb))
  {
    pChild->Paint(dc, erase, RectAPeindre) ;
    pChild = pChild->Next() ;
    i++ ;
  }
*/
}

void
NSLdvCurvesManagementPannelInterface::EvRButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
  TWindow::EvRButtonDown(modKeys, point) ;
}

NSLdvCurvesManagementPannelInterface&
NSLdvCurvesManagementPannelInterface::operator=(NSLdvCurvesManagementPannelInterface& src)
{
  if (this == &src)
    return *this ;

  _pToon = src.getToon() ;

  return *this ;
}

// -----------------------------------------------------------------------------
//                                 NSLdvCurve
// -----------------------------------------------------------------------------

NSLdvCurve::NSLdvCurve(NSLdvCurvesManagementPannel* pPannel)
{
	pCurvesPannel  = pPannel ;

  sItemLabel     = string("") ;
  sUnitLabel     = string("") ;
  sCompoundLabel = string("") ;

	sItemValue  = string("") ;
	sPath       = string("") ;
	sUnit       = string("") ;

	pFirstPoint = NULL ;

  color       = NS_CLASSLIB::TColor::Black ;
  dotWidth    = 1 ;
  dotStyle    = PS_SOLID ;

  pointAspect = paCircle ;
  pointRadius = 2 ;

  bAdjustPointColorToValue = true ;

  pAxis       = new NSLdvCurveYAxis(pCurvesPannel->pContexte, pCurvesPannel->pView->getActiveWorkingArea(), pCurvesPannel->pView, this) ;
  pBackground = new NSLdvCurveBackground(pCurvesPannel->pContexte, pCurvesPannel->pView->getActiveWorkingArea(), this) ;
}

NSLdvCurve::NSLdvCurve(NSLdvCurve& rv)
{
	pCurvesPannel = rv.pCurvesPannel ;

  sItemLabel     = rv.sItemLabel ;
  sUnitLabel     = rv.sUnitLabel ;
  sCompoundLabel = rv.sCompoundLabel ;

	sItemValue  = rv.sItemValue ;
	sPath       = rv.sPath ;
	sUnit       = rv.sUnit ;

	pFirstPoint = rv.pFirstPoint ;

  color       = rv.color ;
  dotWidth    = rv.dotWidth ;
  dotStyle    = rv.dotStyle ;

  pointAspect = rv.pointAspect ;
  pointRadius = rv.pointRadius ;

  bAdjustPointColorToValue = rv.bAdjustPointColorToValue ;

  if (rv.pAxis)
  	pAxis = new NSLdvCurveYAxis(*(rv.pAxis)) ;
  else
  	pAxis = NULL ;

	if (rv.pBackground)
  	pBackground = new NSLdvCurveBackground(*(rv.pBackground)) ;
  else
  	pBackground = NULL ;
}

NSLdvCurve::~NSLdvCurve()
{
  NSLdvViewArea* pActiveWorkingArea = 0 ;
  if ((NULL != pAxis) || (NULL != pBackground))
    pActiveWorkingArea = pCurvesPannel->pView->getActiveWorkingArea() ;

	if (pAxis)
  {
    if (NULL != pActiveWorkingArea)
  	  pCurvesPannel->pView->removeFromToonsArray(pActiveWorkingArea->getToonsArray(), pAxis) ;
    delete pAxis ;
  }

  if (pBackground)
  {
    if (NULL != pActiveWorkingArea)
  	  pCurvesPannel->pView->removeFromToonsArray(pActiveWorkingArea->getToonsArray(), pBackground) ;
    delete pBackground ;
  }
}

void
NSLdvCurve::init()
{
	// Setting the labels
	//
  string sLang  = pCurvesPannel->pContexte->getUtilisateur()->donneLang() ;
  pCurvesPannel->pContexte->getDico()->donneLibelle(sLang, &sItemValue, &sItemLabel) ;
  if (sUnit != string(""))
  	pCurvesPannel->pContexte->getDico()->donneLibelle(sLang, &sUnit, &sUnitLabel) ;
  setCompoundLabel() ;

	//
	// Getting history for this data
  //
	NSHistoryValManagementArray histoManager(pCurvesPannel->pContexte) ;

  histoManager.ChargeHistoryValueItem(sItemValue) ;
  histoManager.ChargeCaptureValueItem(sItemValue) ;
  if (histoManager.empty())
  	return ;

	sort(histoManager.begin(), histoManager.end(), sortByDateInf) ;

  NSHistoryValManagementIter histoIt ;

  // If unit has not been chosen, we take the most selected
  //
  if (sUnit == string(""))
  {
  	ClasseStringVector aUnitCounter ;
    iterString stringIt ;
  	for (histoIt = histoManager.begin(); histoIt != histoManager.end(); histoIt++)
		{
    	// Unit counter
    	//
    	string sDataUnit = (*histoIt)->getUnit() ;
    	string sDataUnitSens ;
    	pCurvesPannel->pContexte->getDico()->donneCodeSens(&sDataUnit, &sDataUnitSens) ;

    	if (!(aUnitCounter.empty()))
    	{
    		stringIt = aUnitCounter.begin() ;
      	for (; (stringIt != aUnitCounter.end()) && ((*stringIt)->sItem != sDataUnitSens) ; stringIt++) ;
      	if (stringIt == aUnitCounter.end())
      		aUnitCounter.push_back(new classString(sDataUnitSens, 1)) ;
      	else
      		(*stringIt)->colonne++ ;
    	}
    	else
    		aUnitCounter.push_back(new classString(sDataUnitSens, 1)) ;
    }

    int iCurrentCounter = 0 ;
  	for (stringIt = aUnitCounter.begin(); stringIt != aUnitCounter.end() ; stringIt++)
    {
    	if ((*stringIt)->colonne > iCurrentCounter)
      {
      	iCurrentCounter = (*stringIt)->colonne ;
        setUnit((*stringIt)->sItem + string("1")) ;
      }
    }
  }

  // Creating the points as toons
  //
  NSLdvCurvePoint* pPreviousPoint = NULL ;

  NSLdvViewArea* pActiveWorkingArea = pCurvesPannel->pView->getActiveWorkingArea() ;
  if (NULL == pActiveWorkingArea)
    return ;

  // Creating the points
  //
  for (histoIt = histoManager.begin() ; histoIt != histoManager.end(); histoIt++)
	{
    NSLdvCurvePoint* pPoint = new NSLdvCurvePoint(pCurvesPannel->pContexte, pActiveWorkingArea, this, *histoIt) ;

    if (NULL == pPreviousPoint)
    	pFirstPoint = pPoint ;
    else
    {
    	pPreviousPoint->_pNextBrother = pPoint ;
      pPoint->_pPreviousBrother     = pPreviousPoint ;
    }

    pCurvesPannel->pView->addToToonsArray(pActiveWorkingArea->getToonsArray(), pPoint) ;

    pPreviousPoint = pPoint ;
  }

  // Setting the points to current unit (and hidding them when not possible)
  //
  pointsSetUnit() ;

  // Setting background information
  //
  ArrayGoals *pGoals = pCurvesPannel->pView->getDoc()->getGoals() ;
  initHistoryOfValuedGoals(pGoals) ;

  buildBackgroundQuadrisFromGoals() ;

  // Initing the Axis
  //
  pAxis->initAxisValues(pFirstPoint) ;

  // Ending points initialization
  //
	pointsSetup() ;
}

void
NSLdvCurve::reinit(bool bUnitChanged)
{
	if (bUnitChanged)
  	pointsSetUnit() ;

	// Initing the Axis
  //
  pAxis->initAxisValues(pFirstPoint) ;

  // Setting points according to changes
  //
  pointsSetup() ;

  // reinit background
  //
  pBackground->eraseQuadri() ;
  buildBackgroundQuadrisFromGoals() ;
}

void
NSLdvCurve::pointsSetUnit()
{
	if (NULL == pFirstPoint)
		return ;
  if (sUnit == string(""))
  	return ;

  string sNewUnitSens ;
  pCurvesPannel->pContexte->getDico()->donneCodeSens(&sUnit, &sNewUnitSens) ;

  bool bConvertOpen = false ;
  NSCV NsCv(pCurvesPannel->pContexte) ;

  bool bOddConvert  = false ;
  bool bSomeUnconvertibleUnit = false ;

	NSLdvCurvePoint* pPoint = pFirstPoint ;
  while (NULL != pPoint)
  {
  	if (sNewUnitSens != pPoint->_sUnitSens)
    {
    	// Main value with good unit
      //
    	if      (pPoint->_value.getUnit() == sNewUnitSens)
    	{
    		double dValue = StringToDouble(pPoint->_value.getValue()) ;
    		pPoint->setActualValues(dValue, sNewUnitSens) ;
        pPoint->setVisible() ;
    	}
      // Secondary value with good unit
      //
    	else if (pPoint->_value.getUnit2() == sNewUnitSens)
    	{
    		double dValue = StringToDouble(pPoint->_value.getValue2()) ;
    		pPoint->setActualValues(dValue, sNewUnitSens) ;
        pPoint->setVisible() ;
    	}
      // Conversion needed
      //
      else
      {
    		// Opening the conversion database
      	//
    		if (!bConvertOpen && !bOddConvert)
      	{
        	DBIResult Resultat = NsCv.open() ;
        	if (Resultat != DBIERR_NONE)
        	{
        		string sErrorMessage = pCurvesPannel->pContexte->getSuperviseur()->getText("unitConversion", "errorOpeningConversionDatabase") ;
        		erreur(sErrorMessage.c_str(), standardError, Resultat) ;
          	bOddConvert = true ;
        	}
        	else
        		bConvertOpen = true ;
      	}
      	if (bConvertOpen)
      	{
          bool bSuccess = false ;

          // Try to convert the primary value
          //
      		double dVal = StringToDouble(pPoint->_value.getValue()) ;

      		if (NsCv.ConvertirUnite(&dVal, sUnit, pPoint->_value.getUnit(), sItemValue))
        	{
          	// Successfull conversion
        		//
        		pPoint->setActualValues(dVal, sNewUnitSens) ;
          	pPoint->setVisible() ;

            bSuccess = true ;
        	}

          // Try to convert the secondary value
          //
          if (!bSuccess && (pPoint->_value.getUnit2() != string("")))
          {
          	dVal = StringToDouble(pPoint->_value.getValue2()) ;

      			if (NsCv.ConvertirUnite(&dVal, sUnit, pPoint->_value.getUnit2(), sItemValue))
        		{
              // Successfull conversion
        			//
        			pPoint->setActualValues(dVal, sNewUnitSens) ;
          		pPoint->setVisible() ;

            	bSuccess = true ;
        		}
          }
        	// Unsuccessfull conversion
        	//
        	if (false == bSuccess)
        	{
        		pPoint->resetActualValues() ;
        		pPoint->setHidden() ;

          	if (false == bSomeUnconvertibleUnit)
          	{
        			string sErrorMessage = pCurvesPannel->pContexte->getSuperviseur()->getText("LigneDeVieCurves", "cannotConvertUnit") ;
              string sLang  = pCurvesPannel->pContexte->getUtilisateur()->donneLang() ;
              string sUnitLabel ;
              if ((string("") == sUnit) || (string("200001") == sUnit))
              	sUnitLabel = string("\"\"") ;
              else
								pCurvesPannel->pContexte->getDico()->donneLibelle(sLang, &sUnit, &sUnitLabel) ;
              string sPointUnit = pPoint->_value.getUnit() ;
              string sPointUnitLabel ;
              if ((string("") == sPointUnit) || (string("200001") == sPointUnit))
              	sPointUnitLabel = string("\"\"") ;
              else
								pCurvesPannel->pContexte->getDico()->donneLibelle(sLang, &sPointUnit, &sPointUnitLabel) ;
              sErrorMessage += string(" (") + sPointUnitLabel + string(" -> ") + sUnitLabel + string(")");
        			erreur(sErrorMessage.c_str(), standardError, 0) ;
          		bSomeUnconvertibleUnit = true ;
          	}
        	}
      	}
      	if (bOddConvert)
      	{
      		pPoint->resetActualValues() ;
        	pPoint->setHidden() ;
      	}
      }
    }

    pPoint = pPoint->_pNextBrother ;
  }

  if (bConvertOpen)
  	NsCv.close() ;
}

void
NSLdvCurve::pointsSetup()
{
	NSLdvCurvePoint* pPoint = pFirstPoint ;
  while (NULL != pPoint)
  {
  	pPoint->SetupWindow() ;
    pPoint = pPoint->_pNextBrother ;
  }
}

void
NSLdvCurve::close()
{
	// First step : remove the NSLdvCurvePoint(s) from ldv toons array
  //              and delete them
  //
  NSLdvViewArea* pActiveWorkingArea = pCurvesPannel->pView->getActiveWorkingArea() ;

  NSLdvCurvePoint* pPoint = pFirstPoint ;
  while (NULL != pPoint)
  {
  	NSLdvCurvePoint* pNextPoint = pPoint->_pNextBrother ;
    if (NULL != pActiveWorkingArea)
  	  pCurvesPannel->pView->removeFromToonsArray(pActiveWorkingArea->getToonsArray(), pPoint) ;
    delete pPoint ;
    pPoint = pNextPoint ;
  }
}

int
NSLdvCurve::giveYCoordinateForValue(double dValue, bool* pSuccess, string sValueUnitSens, bool bLimitedToAxisLimits)
{
	if (NULL != pSuccess)
		*pSuccess = true ;

	if (sValueUnitSens == string(""))
    return pAxis->giveWorkingAreaYCoordinateForValue(dValue, bLimitedToAxisLimits) ;

  string sCurveUnitSens ;
  pCurvesPannel->pContexte->getDico()->donneCodeSens(&sUnit, &sCurveUnitSens) ;

  if (sValueUnitSens == sCurveUnitSens)
		return pAxis->giveWorkingAreaYCoordinateForValue(dValue, bLimitedToAxisLimits) ;

  NSCV NsCv(pCurvesPannel->pContexte) ;
	DBIResult Resultat = NsCv.open() ;
  if (Resultat != DBIERR_NONE)
  {
  	string sErrorMessage = pCurvesPannel->pContexte->getSuperviseur()->getText("unitConversion", "errorOpeningConversionDatabase") ;
    erreur(sErrorMessage.c_str(), standardError, Resultat) ;
    if (NULL != pSuccess)
			*pSuccess = false ;
		return -1 ;
  }

  // Try to convert the value
  //
  double dConvertedVal = dValue ;

  bool bSuccCv = NsCv.ConvertirUnite(&dConvertedVal, sUnit, sValueUnitSens, sItemValue) ;

  NsCv.close() ;

	if (bSuccCv)
  	return pAxis->giveWorkingAreaYCoordinateForValue(dConvertedVal, bLimitedToAxisLimits) ;
  else
  {
  	if (NULL != pSuccess)
			*pSuccess = false ;
  	return -1 ;
  }
}

void
NSLdvCurve::setUnit(string sUnitToSet)
{
	sUnit = sUnitToSet ;
	string sLang = pCurvesPannel->pContexte->getUtilisateur()->donneLang() ;
  pCurvesPannel->pContexte->getDico()->donneLibelle(sLang, &sUnit, &sUnitLabel) ;
  setCompoundLabel() ;
}

void
NSLdvCurve::setCompoundLabel()
{
	sCompoundLabel = sItemLabel ;
  if (sUnitLabel != string(""))
  	sCompoundLabel += string(" (") + sUnitLabel + string(")");
}

void
NSLdvCurve::initHistoryOfValuedGoals(ArrayGoals *pGoals)
{
	if ((NULL == pGoals) || (pGoals->empty()))
		return ;

	string sItemSens ;
  pCurvesPannel->pContexte->getDico()->donneCodeSens(&sItemValue, &sItemSens) ;

	for (ArrayGoalIter goalIter = pGoals->begin() ; goalIter != pGoals->end() ; goalIter++ )
  {
  	if ((*goalIter)->containsGoalsOnValue())
    {
  		string sGoalItemSens ;
			pCurvesPannel->pContexte->getDico()->donneCodeSens(&((*goalIter)->sLexique), &sGoalItemSens) ;

    	if (sGoalItemSens == sItemSens)
      	aHistoryOfValuedGoals.push_back(*goalIter) ;
    }
  }
}

void
NSLdvCurve::buildBackgroundQuadrisFromGoals()
{
	if (aHistoryOfValuedGoals.empty())
		return ;

	pBackground->_bExistMaxLimit = false ;
	pBackground->_dMaxLimit      = - numeric_limits<double>::max() ;
	pBackground->_sMaxLimitUnit  = string("") ;

	pBackground->_bExistMinLimit = false ;
	pBackground->_dMinLimit      = numeric_limits<double>::max() ;
	pBackground->_sMinLimitUnit  = string("") ;

	// Voir http://www.pitt.edu/~nisg/cis/web/cgi/rgb.html
  //
	NS_CLASSLIB::TColor paleBlue ;
  nsSkin* pBlueSkin = pCurvesPannel->pContexte->getSkins()->donneSkin("CurveBackgroundBlue") ;
	if (pBlueSkin && pBlueSkin->getBackColor())
  	paleBlue = *(pBlueSkin->getBackColor()) ;
  else
  	paleBlue = NS_CLASSLIB::TColor(240, 255, 240) ;

  NS_CLASSLIB::TColor paleGreen ;
  nsSkin* pGreenSkin = pCurvesPannel->pContexte->getSkins()->donneSkin("CurveBackgroundGreen") ;
	if (pGreenSkin && pGreenSkin->getBackColor())
  	paleGreen = *(pGreenSkin->getBackColor()) ;
  else
  	paleGreen = NS_CLASSLIB::TColor(220, 255, 220) ;

  NS_CLASSLIB::TColor paleYellow ;
  nsSkin* pYellowSkin = pCurvesPannel->pContexte->getSkins()->donneSkin("CurveBackgroundYellow") ;
	if (pYellowSkin && pYellowSkin->getBackColor())
  	paleYellow = *(pYellowSkin->getBackColor()) ;
  else
  	paleYellow = NS_CLASSLIB::TColor(255, 250, 220) ;

	NS_CLASSLIB::TColor paleRed ;
  nsSkin* pRedSkin = pCurvesPannel->pContexte->getSkins()->donneSkin("CurveBackgroundRed") ;
	if (pRedSkin && pRedSkin->getBackColor())
  	paleRed = *(pRedSkin->getBackColor()) ;
  else
  	paleRed = NS_CLASSLIB::TColor(255, 240, 220) ;

	// This algorithm mimics ObjectifViewerDlg::repaintColorBar algorithm
  //
	// The only possible algoritm is to define the center color (hearth)
	// then move up from there, using existing values as color transitions
  // then start again from the center and go down (in the same way we went up)

  //
  // Every goals' value is converted to the curve's unit
  //

  NVLdVTemps minDate ;
  minDate.setNoLimit() ;

  NVLdVTemps maxDate ;
  maxDate.init() ;

	vector<NSLdvGoal*>::iterator goalIt = aHistoryOfValuedGoals.begin() ;
  for ( ; goalIt != aHistoryOfValuedGoals.end() ; goalIt++)
  {
  	// First, take begin and end dates
    //
    if (!((*goalIt)->tOuvertLe.estVide()) ||
        !((*goalIt)->tDateOuverture.estVide()) ||
        !((*goalIt)->canBeFullyConverted(sUnit)))
    {
    	NVLdVTemps beginDate ;
      if (!((*goalIt)->tOuvertLe.estVide()))
      	beginDate = (*goalIt)->tOuvertLe ;
      else
      	beginDate = (*goalIt)->tDateOuverture ;

      NVLdVTemps endDate ;
      if (!((*goalIt)->tFermeLe.estVide()))
      	endDate = (*goalIt)->tFermeLe ;
      else if (!((*goalIt)->tDateFermeture.estVide()))
      	endDate = (*goalIt)->tDateFermeture ;
      else
      	endDate.setNoLimit() ;

      if (beginDate < minDate)
      	minDate = beginDate ;

      if (endDate > maxDate)
      	maxDate = endDate ;

  		// looking for the color of the central quadri
  		//
      NS_CLASSLIB::TColor centerColor ;
      // Next up color
      NS_CLASSLIB::TColor upperColor = NS_CLASSLIB::TColor::White ;
      double dUpperValue = numeric_limits<double>::max() ;
      // Next down color
      NS_CLASSLIB::TColor lowerColor = NS_CLASSLIB::TColor::White ;
      double dLowerValue = - numeric_limits<double>::max() ;

      if ((*goalIt)->bValMinIdeal || (*goalIt)->bValMaxIdeal)
      {
      	centerColor = paleBlue ;

        if ((*goalIt)->bValMinIdeal)
        {
        	lowerColor = paleGreen ;
          dLowerValue = (*goalIt)->dValMinIdeal ;
          pCurvesPannel->pView->convertUnit(&dLowerValue, sUnit, (*goalIt)->sUniteValMinIdeal, sItemValue, false) ;
        }
        if ((*goalIt)->bValMaxIdeal)
        {
        	upperColor = paleGreen ;
          dUpperValue = (*goalIt)->dValMaxIdeal ;
          pCurvesPannel->pView->convertUnit(&dUpperValue, sUnit, (*goalIt)->sUniteValMaxIdeal, sItemValue, false) ;
        }
      }
      else if ((*goalIt)->bValMinConseille || (*goalIt)->bValMaxConseille)
      {
      	centerColor = paleGreen ;

        if ((*goalIt)->bValMinConseille)
        {
        	lowerColor = paleYellow ;
          dLowerValue = (*goalIt)->dValMinConseille ;
          pCurvesPannel->pView->convertUnit(&dLowerValue, sUnit, (*goalIt)->sUniteValMinConseille, sItemValue, false) ;
        }
        if ((*goalIt)->bValMaxConseille)
        {
        	upperColor = paleYellow ;
          dUpperValue = (*goalIt)->dValMaxConseille ;
          pCurvesPannel->pView->convertUnit(&dUpperValue, sUnit, (*goalIt)->sUniteValMaxConseille, sItemValue, false) ;
        }
      }
      else if ((*goalIt)->bValMinAutorise || (*goalIt)->bValMaxAutorise)
      {
      	centerColor = paleYellow ;

        if ((*goalIt)->bValMinAutorise)
        {
        	lowerColor = paleRed ;
          dLowerValue = (*goalIt)->dValMinAutorise ;
          pCurvesPannel->pView->convertUnit(&dLowerValue, sUnit, (*goalIt)->sUniteValMinAutorise, sItemValue, false) ;
        }
        if ((*goalIt)->bValMaxAutorise)
        {
        	upperColor = paleRed ;
          dUpperValue = (*goalIt)->dValMaxAutorise ;
          pCurvesPannel->pView->convertUnit(&dUpperValue, sUnit, (*goalIt)->sUniteValMaxAutorise, sItemValue, false) ;
        }
      }
      else
      	return ;

      bool bCenterDrawn = false ;

      // Quadri bottom when going up
      double dBottomValue = dLowerValue ;

      // Quadri top when going down (since we first go up, the center will
      // already have been drawn when going down, this is the reason why
      // we also start from dLowerValue)
      double dTopValue = dLowerValue ;

      // Drawing center quadri
      //
      if (lowerColor == upperColor)
      {
      	NSLdvCurveBackgroundQuadri bgQuadri(pCurvesPannel->pView, centerColor, beginDate, endDate, dLowerValue, sUnit, dUpperValue, sUnit) ;
      	pBackground->addQuadri(&bgQuadri) ;
        bCenterDrawn = true ;

        dBottomValue = dUpperValue ;
      }

      // Going up
      //

      // Transition toward yellow
      if ((*goalIt)->bValMaxConseille)
      {
      	// If center was not drawn, it means that we don't have a bValMinConseille
        // So, we either have :
        // - a bValMinIdeal :    we must draw a blue central quadri
        // - a bValMinAutorise : we must draw a green central quadri
        // - no Min information : we must draw a green lower part quadri
      	if (false == bCenterDrawn)
        {
        	upperColor = centerColor ;
        	bCenterDrawn = true ;
        }

        double dTopOfTheBoxValue = (*goalIt)->dValMaxConseille ;
        pCurvesPannel->pView->convertUnit(&dTopOfTheBoxValue, sUnit, (*goalIt)->sUniteValMaxConseille, sItemValue, false) ;

        NSLdvCurveBackgroundQuadri bgQuadri(pCurvesPannel->pView, upperColor, beginDate, endDate, dBottomValue, sUnit, dTopOfTheBoxValue, sUnit) ;
        pBackground->addQuadri(&bgQuadri) ;

        dBottomValue = dTopOfTheBoxValue ;
        upperColor = paleYellow ;
      }
      // Transition toward red
      if ((*goalIt)->bValMaxAutorise)
      {
        if (false == bCenterDrawn)
        {
        	upperColor = centerColor ;
        	bCenterDrawn = true ;
        }

        double dTopOfTheBoxValue = (*goalIt)->dValMaxAutorise ;
        pCurvesPannel->pView->convertUnit(&dTopOfTheBoxValue, sUnit, (*goalIt)->sUniteValMaxAutorise, sItemValue, false) ;

        NSLdvCurveBackgroundQuadri bgQuadri(pCurvesPannel->pView, upperColor, beginDate, endDate, dBottomValue, sUnit, dTopOfTheBoxValue, sUnit) ;
        pBackground->addQuadri(&bgQuadri) ;

        dBottomValue = dTopOfTheBoxValue ;
        upperColor = paleRed ;
      }

      // Upper part
      //
      if (false == bCenterDrawn)
      {
      	upperColor = centerColor ;
        bCenterDrawn = true ;
      }

      NSLdvCurveBackgroundQuadri bgQuadri(pCurvesPannel->pView, upperColor, beginDate, endDate, dBottomValue, sUnit, numeric_limits<double>::max(), sUnit) ;
      pBackground->addQuadri(&bgQuadri) ;

      // Going down
      //

      // Transition toward yellow
      if ((*goalIt)->bValMinConseille)
      {
      	double dBottomOfTheBoxValue = (*goalIt)->dValMinConseille ;
        pCurvesPannel->pView->convertUnit(&dBottomOfTheBoxValue, sUnit, (*goalIt)->sUniteValMinConseille, sItemValue, false) ;

      	if ((dTopValue != - numeric_limits<double>::max()) && (lowerColor != centerColor))
        {
        	NSLdvCurveBackgroundQuadri bgQuadri(pCurvesPannel->pView, lowerColor, beginDate, endDate, dBottomOfTheBoxValue, sUnit, dTopValue, sUnit) ;
        	pBackground->addQuadri(&bgQuadri) ;
        }

        dTopValue = dBottomOfTheBoxValue ;
        lowerColor = paleYellow ;
      }

      // Transition toward red
      if ((*goalIt)->bValMinAutorise)
      {
      	double dBottomOfTheBoxValue = (*goalIt)->dValMinAutorise ;
        pCurvesPannel->pView->convertUnit(&dBottomOfTheBoxValue, sUnit, (*goalIt)->sUniteValMinAutorise, sItemValue, false) ;

      	if ((dTopValue != - numeric_limits<double>::max()) && (lowerColor != centerColor))
        {
        	NSLdvCurveBackgroundQuadri bgQuadri(pCurvesPannel->pView, lowerColor, beginDate, endDate, dBottomOfTheBoxValue, sUnit, dTopValue, sUnit) ;
        	pBackground->addQuadri(&bgQuadri) ;
        }

        dTopValue = dBottomOfTheBoxValue ;
        lowerColor = paleYellow ;
      }

      // Lower part
      //
      if ((dTopValue != - numeric_limits<double>::max()) && (lowerColor != centerColor))
      {
      	NSLdvCurveBackgroundQuadri bgQuadri(pCurvesPannel->pView, lowerColor, beginDate, endDate, - numeric_limits<double>::max(), sUnit, dTopValue, sUnit) ;
        pBackground->addQuadri(&bgQuadri) ;
      }

      // Updating min and max limits
      //
      if (numeric_limits<double>::max() != dBottomValue)
      {
      	if (!(pBackground->_bExistMaxLimit))
      	{
					pBackground->_dMaxLimit      = dBottomValue ;
        	pBackground->_bExistMaxLimit = true ;
      	}
      	else
      		if (dBottomValue > pBackground->_dMaxLimit)
        		pBackground->_dMaxLimit = dBottomValue ;
      }

      if (-numeric_limits<double>::max() != dTopValue)
      {
  			if (!(pBackground->_bExistMinLimit))
      	{
					pBackground->_dMinLimit      = dTopValue ;
        	pBackground->_bExistMinLimit = true ;
      	}
      	else
      		if (dTopValue < pBackground->_dMinLimit)
        		pBackground->_dMinLimit = dTopValue ;
      }
    }
  }

  NS_CLASSLIB::TRect YAxisBox = pAxis->donneVisibleRectangle() ;
  pBackground->fixeRectangle(minDate, maxDate, YAxisBox.Bottom(), YAxisBox.Top()) ;
}

NSLdvCurve&
NSLdvCurve::operator=(NSLdvCurve& src)
{
  if (this == &src)
		return *this ;

	pCurvesPannel = src.pCurvesPannel ;

  sItemLabel     = src.sItemLabel ;
  sUnitLabel     = src.sUnitLabel ;
  sCompoundLabel = src.sCompoundLabel ;

	sItemValue  = src.sItemValue ;
	sPath       = src.sPath ;
	sUnit       = src.sUnit ;

	pFirstPoint = src.pFirstPoint ;

  color       = src.color ;
  dotWidth    = src.dotWidth ;
  dotStyle    = src.dotStyle ;

  pointAspect = src.pointAspect ;
  pointRadius = src.pointRadius ;

  bAdjustPointColorToValue = src.bAdjustPointColorToValue ;

  if (pAxis)
  {
    NSLdvViewArea* pActiveWorkingArea = pCurvesPannel->pView->getActiveWorkingArea() ;
    if (NULL != pActiveWorkingArea)
  	  pCurvesPannel->pView->removeFromToonsArray(pActiveWorkingArea->getToonsArray(), pAxis) ;
  	delete pAxis ;
  }

  if (src.pAxis)
  	pAxis = new NSLdvCurveYAxis(*(src.pAxis)) ;
  else
  	pAxis = NULL ;

  return *this ;
}

// -----------------------------------------------------------------------------
//                            NSCurvesPropertyWindow
// -----------------------------------------------------------------------------

NSCurvesProperty::NSCurvesProperty(NSContexte* pCtx, NSLdvWindowToon* pLdvParent, NSLdvView* pTheView)
                 :NSLdvWindowToon(pCtx, pLdvParent, pTheView)
{
  iZOrder   = LEVEL_COMMANDS ;
  sSkinName = string("LdvCurvesList") ;

  initDimensions() ;

  pInterface = new NSCurvesPropertyWindow(pContexte, getParentInterface(), this, ID_CurvesList, 0, 0, 0, 0) ;
}

NSCurvesProperty::NSCurvesProperty(NSCurvesProperty& rv)
                 :NSLdvWindowToon(rv.pContexte, rv.getToonParent(), rv.pView)
{
  initialiser((NSLdvWindowToon*)(&rv)) ;
}

NSCurvesProperty::~NSCurvesProperty()
{
}

void
NSCurvesProperty::SetupWindow()
{
}

void
NSCurvesProperty::setScrollParams()
{
}

void
NSCurvesProperty::draw(TDC* pDc, NVLdVRect* pRectARepeindre)
{
}

void
NSCurvesProperty::draw(TDC* pDc, NS_CLASSLIB::TRect* pRectARepeindre)
{
}

void
NSCurvesProperty::EvRButtonDown()
{
}

void
NSCurvesProperty::CmNew()
{
  NSLdvCurvesManagementPannel* pPannel = getCurveManagementPannel() ;
  if (NULL == pParent)
    return ;

  pPannel->CmNew() ;
}

bool
NSCurvesProperty::CmSupres(string sLabelToSuppress)
{
  NSLdvCurvesManagementPannel* pPannel = getCurveManagementPannel() ;
  if (NULL == pParent)
    return false ;

  return pPannel->CmSupres(sLabelToSuppress) ;
}

void
NSCurvesProperty::CmPutUp(string sLabelToPutUp)
{
  NSLdvCurvesManagementPannel* pPannel = getCurveManagementPannel() ;
  if (NULL == pParent)
    return ;

  pPannel->CmPutUp(sLabelToPutUp) ;
}

void
NSCurvesProperty::CmModify(string sLabelToPutUp)
{
  NSLdvCurvesManagementPannel* pPannel = getCurveManagementPannel() ;
  if (NULL == pParent)
    return ;

  pPannel->CmModify(sLabelToPutUp) ;
}

void
NSCurvesProperty::displayElement(NSLdvCurve* pCurve)
{
  NSCurvesPropertyWindow* pList = getInterfaceAsList() ;
  if (NULL == pList)
    return ;

  pList->displayElement(pCurve) ;
}

void
NSCurvesProperty::selectItem(string sItemLabel)
{
  NSCurvesPropertyWindow* pList = getInterfaceAsList() ;
  if (NULL == pList)
    return ;

  pList->selectItem(sItemLabel) ;
}

NSLdvCurvesManagementPannel*
NSCurvesProperty::getCurveManagementPannel()
{
  if (NULL == pParent)
    return 0 ;

  NSLdvCurvesManagementPannel* pPannel = TYPESAFE_DOWNCAST(pParent, NSLdvCurvesManagementPannel) ;
  return pPannel ;
}

NSCurvesPropertyWindow*
NSCurvesProperty::getInterfaceAsList()
{
  if (NULL == pInterface)
    return 0 ;

  NSCurvesPropertyWindow* pList = TYPESAFE_DOWNCAST(pInterface, NSCurvesPropertyWindow) ;
  return pList ;
}

NSCurvesProperty&
NSCurvesProperty::operator=(NSCurvesProperty& src)
{
  if (this == &src)
    return *this ;

  return *this ;
}

#define MENU_INSER 101
#define MENU_SUPPR 102
#define MENU_MODIF 103
#define MENU_PUTUP 104

DEFINE_RESPONSE_TABLE1(NSCurvesPropertyWindow, TListWindow)
  EV_WM_LBUTTONDBLCLK,
  EV_WM_RBUTTONDOWN,
  EV_WM_KEYDOWN,
  EV_WM_KILLFOCUS,
  EV_WM_SETFOCUS,
  // EV_WM_LBUTTONUP,
  EV_WM_PAINT,
  EV_COMMAND(MENU_INSER, newCurve),
  EV_COMMAND(MENU_SUPPR, suppress),
  EV_COMMAND(MENU_MODIF, modify),
  EV_COMMAND(MENU_PUTUP, putUp),
  // EV_NOTIFY_AT_CHILD(WM_LBUTTONDBLCLK, ButtonDblClk),
  // EV_NOTIFY_AT_CHILD(WM_RBUTTONDOWN, RButtonDown),
  // EV_NOTIFY_AT_CHILD(LVN_GETDISPINFO, LvnGetDispInfo),
END_RESPONSE_TABLE ;

NSCurvesPropertyWindow::NSCurvesPropertyWindow(NSContexte* pCtx, TWindow* parent, NSCurvesProperty* pToon, int id, int x, int y, int w, int h, TModule *module)
                       :TListWindow(parent, id, x, y, w, h, module), NSRoot(pCtx)
{
  iRes = id ;
  // Attr.ExStyle  |= WS_EX_NOPARENTNOTIFY ;

  // Inactivate HScroll, activate report
  ModifyStyle(WS_HSCROLL, LVS_REPORT|LVS_SHOWSELALWAYS) ;

  _pToon = pToon ;

  SetCaption(_pToon->sSkinName.c_str()) ;

  DisableTransfer() ;
  // SetFlag(wfAutoCreate) ;
}

void
NSCurvesPropertyWindow::SetupWindow()
{
  ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;
  TListWindow::SetupWindow() ;

  string sTitle = pContexte->getSuperviseur()->getText("LigneDeVieCurves", "biometricalCurves") ;

  // int iListWidth = pCurvesPannel->wVisibleBox.Width() - 10 ;
  // InsertColumn(0, TListWindColumn((char far*) sTitle.c_str()/* , iListWidth*/)) ;

  int iListWidth = _pToon->getWidthValue() - 30 ;
  InsertColumn(0, TListWindColumn((char far*) sTitle.c_str(), iListWidth)) ;
}

void
NSCurvesPropertyWindow::EvPaint()
{  TListWindow::EvPaint() ;}

void
NSCurvesPropertyWindow::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectAPeindre)
{
  TListWindow::Paint(dc, erase, RectAPeindre) ;
}

void
NSCurvesPropertyWindow::displayElement(NSLdvCurve* pCurve)
{
	InsertItem(TListWindItem(pCurve->sCompoundLabel.c_str(), 0)) ;
}

void
NSCurvesPropertyWindow::suppress()
{
	string sSelectedLabel = string("") ;
  int iIndex = getLabelOfSelectedItem(&sSelectedLabel) ;
  if (iIndex == -1)
  	return ;

	bool bReallyDeleted = ((NSCurvesProperty *)(_pToon))->CmSupres(sSelectedLabel) ;
	if (bReallyDeleted)
  	DeleteAnItem(iIndex) ;
}

void
NSCurvesPropertyWindow::putUp()
{
	string sSelectedLabel = string("") ;
  int iIndex = getLabelOfSelectedItem(&sSelectedLabel) ;
  if (iIndex == -1)
  	return ;

  ((NSCurvesProperty *)(_pToon))->CmPutUp(sSelectedLabel) ;
}

void
NSCurvesPropertyWindow::modify()
{
	string sSelectedLabel = string("") ;
  int iIndex = getLabelOfSelectedItem(&sSelectedLabel) ;
  if (iIndex == -1)
  	return ;

  ((NSCurvesProperty *)(_pToon))->CmModify(sSelectedLabel) ;
}

void
NSCurvesPropertyWindow::newCurve()
{
	((NSCurvesProperty *)(_pToon))->CmNew() ;
}

// -----------------------------------------------------------------------------
// Fonction de r�ponse au double-click
// -----------------------------------------------------------------------------
void
NSCurvesPropertyWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point) ;

  HitTest(info) ;
  if (info.GetFlags() & LVHT_ONITEM)  	putUp() ;  else
  	newCurve() ;

  TListWindow::EvLButtonDblClk(modKeys, point) ;
}

void
NSCurvesPropertyWindow::EvRButtonDown(uint modkeys, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point) ;
  int indexItem = HitTest(info) ;

  NSSuper* pSuper = pContexte->getSuperviseur() ;
  string sAdd = pSuper->getText("generalLanguageForLists", "add") ;

  if (info.GetFlags() & LVHT_ONITEM)  {  	SetItemState(indexItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED) ;    Invalidate() ;		string sModify = pSuper->getText("generalLanguageForLists", "modify") ;
    string sSuppre = pSuper->getText("generalLanguageForLists", "remove") ;    string sPutUp  = pSuper->getText("LigneDeVieCurves", "putFront") ;    // cr�ation d'un menu popup    NS_CLASSLIB::TPoint lp = point ;

    OWL::TPopupMenu *pPopupMenu = new OWL::TPopupMenu() ;

    pPopupMenu->AppendMenu(MF_STRING, MENU_PUTUP, sPutUp.c_str()) ;
    pPopupMenu->AppendMenu(MF_STRING, MENU_MODIF, sModify.c_str()) ;
    pPopupMenu->AppendMenu(MF_STRING, MENU_SUPPR, sSuppre.c_str()) ;
    pPopupMenu->AppendMenu(MF_SEPARATOR, 0, 0);
    pPopupMenu->AppendMenu(MF_STRING, MENU_INSER, sAdd.c_str()) ;

    ClientToScreen(lp) ;
  	pPopupMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow) ;
  	delete pPopupMenu ;  }
  else
  {
    // cr�ation d'un menu popup
    NS_CLASSLIB::TPoint lp = point ;

    OWL::TPopupMenu *pPopupMenu = new OWL::TPopupMenu() ;

    pPopupMenu->AppendMenu(MF_STRING, MENU_INSER, sAdd.c_str()) ;

    ClientToScreen(lp) ;
  	pPopupMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow) ;
  	delete pPopupMenu ;
  }

  TListWindow::EvRButtonDown(modkeys, point) ;
}

void
NSCurvesPropertyWindow::ButtonDblClk()
{
}

void
NSCurvesPropertyWindow::RButtonDown()
{
}

void
NSCurvesPropertyWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
	if      (key == VK_DELETE)
  	suppress() ;
  else if (key == VK_INSERT)
  {
  	if (GetKeyState(VK_SHIFT) < 0)
    	putUp() ;
    else
    	newCurve() ;
  }
  else
  	TListWindow::EvKeyDown(key, repeatCount, flags) ;
}

void
NSCurvesPropertyWindow::EvLButtonUp(uint modKeys, NS_CLASSLIB::TPoint& pt)
{
	NSContexte *pContexte = pContexte ;
  NSSuper    *pSuper    = pContexte->getSuperviseur() ;

  if (pSuper->bDragAndDrop)
  {
  	pSuper->DragDrop->DragLeave( *this ) ;
    pSuper->DragDrop->EndDrag() ;
    delete pSuper->DragDrop ;
    pSuper->DragDrop = 0 ;
    pSuper->bDragAndDrop = false ;
  }

  TListWindow::EvLButtonUp(modKeys, pt) ;
}

// -----------------------------------------------------------------------------
// Retourne l'index du premier item s�lectionn�
// -----------------------------------------------------------------------------
int
NSCurvesPropertyWindow::IndexItemSelect()
{
	int count = GetItemCount() ;
  int index = -1 ;

	for (int i = 0 ; i < count ; i++)  	if (GetItemState(i, LVIS_SELECTED))
    {
    	index = i ;
      break ;
    }

	return index ;}

int
NSCurvesPropertyWindow::getLabelOfSelectedItem(string* pLabelString)
{
	int iIndex = IndexItemSelect() ;
  if (iIndex == -1)
  {
  	string sWarning = pContexte->getSuperviseur()->getText("generalLanguageForLists", "anElementMustBeSelected") ;
    erreur(sWarning.c_str(), warningError, 0) ;
    if (NULL == pLabelString)
    	*pLabelString = string("") ;
    return iIndex ;
  }

  if (NULL != pLabelString)
  {
  	char szItemText[2048] ;

  	int iReturnedTextSize = GetItemText(iIndex, 0, szItemText, 2048) ;
  	if (iReturnedTextSize > 0)
  		*pLabelString = string(szItemText) ;
  	else
  	 	*pLabelString = string("") ;
  }

  return iIndex ;
}

void
NSCurvesPropertyWindow::selectItem(string sItemLabel)
{
	int iNbItem = GetItemCount() ;
  for (int iIndex = 0 ; iIndex < iNbItem ; iIndex++)
  {
  	char szItemText[2048] ;

  	int iReturnedTextSize = GetItemText(iIndex, 0, szItemText, 2048) ;
  	if (iReturnedTextSize > 0)
    {
    	if (sItemLabel == string(szItemText))
      {
      	SetItemState(iIndex, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED) ;
        return ;
      }
    }
  }
}

void
NSCurvesPropertyWindow::EvSetFocus(HWND hWndLostFocus)
{
	SetBkColor(0x00fff0f0) ; // 0x00bbggrr
  SetTextBkColor(0x00fff0f0) ;
  Invalidate();

  // pCurvesPannel->focusFct() ;

  int count = GetItemCount() ;

  for (int i = 0 ; i < count ; i++)
  	if (GetItemState(i, LVIS_SELECTED))
    	return ;

	SetItemState(0, LVIS_FOCUSED | LVIS_SELECTED, LVIS_SELECTED) ;

  TListWindow::EvSetFocus(hWndLostFocus) ;
}

void
NSCurvesPropertyWindow::EvKillFocus(HWND hWndGetFocus)
{
	SetBkColor(0x00ffffff) ; // 0x00bbggrr
  SetTextBkColor(0x00ffffff) ;
  Invalidate();
  TListWindow::EvKillFocus(hWndGetFocus) ;
}

void
NSCurvesPropertyWindow::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
}

/*
bool
NSCurvesPropertyWindow::PreProcessMsg(MSG& msg)
{
  switch(msg.message)
  {
    case WM_PAINT:
    {
      // NS_CLASSLIB::TPoint pt1(LOWORD(msg.lParam), HIWORD(msg.lParam)) ;
      // NS_CLASSLIB::TPoint pt2(LOWORD(msg.wParam), HIWORD(msg.wParam)) ;
      // NS_CLASSLIB::TRect  rect1(pt1, pt2) ;

      TPaintDC dc(*this) ;
      NS_CLASSLIB::TRect& rect = *(NS_CLASSLIB::TRect*)&dc.Ps.rcPaint ;
      Paint(dc, true, rect) ;

      DefWindowProc(msg.message, msg.wParam, msg.lParam) ;

      break ;
    }
    case WM_NCPAINT:
      DefWindowProc(msg.message, msg.wParam, msg.lParam) ;
      break ;
  }

  return TWindow::PreProcessMsg(msg) ;
}
*/

