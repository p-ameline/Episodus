//----------------------------------------------------------------------------// ObjectWindows - (C) Copyright 1991, 1993 by Borland International
//   Tutorial application -- step12dv.cpp
//----------------------------------------------------------------------------
#include <owl\owlpch.h>
#include <owl\dc.h>

#define __NSCRVUE_CPP

//#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"
#include "dcodeur\nsdkd.h"

#include "nautilus\nautilus.rh"
#include "nautilus\nscrvue.h"
#include "nautilus\nshistdo.h"
#include "nautilus\nsadmiwd.h"
#include "nsepisod\nsldvuti.h"
#include "nsbb\nstlibre.h"

// --------------------------------------------------------------------------
// -------------------- METHODES DE NSCRReadOnlyView ------------------------
// --------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSCRReadOnlyView, NSRefVue)
    EV_WM_VSCROLL,
    EV_WM_HSCROLL,
    EV_WM_LBUTTONDOWN,
    EV_WM_RBUTTONDOWN,
    EV_WM_CLOSE,
    EV_WM_DESTROY,
    EV_WM_SETFOCUS,
    EV_WM_QUERYENDSESSION,
    EV_COMMAND(CM_ENREGISTRE,     CmEnregistre),
    EV_COMMAND(IDC_CORRIGER,      CorrigerCR),
    EV_COMMAND(IDC_REPRENDRE_CR,  ReprendreCR),
    EV_COMMAND(IDC_SUPPRIMER,     SupprimerLigne),
    EV_COMMAND(IDC_CONCLUSION_CR, Conclusion),
    EV_COMMAND(IDC_COMPTA_CR,     Compta),
    EV_COMMAND(IDC_CODAGE_CR,     Codage),
    EV_COMMAND(IDC_TLIB_ORDO,     TLibreOrdonnance),
    EV_COMMAND(IDC_MEDIC_ALD,     MedicEnALD),
    EV_COMMAND(IDC_MEDIC_NONALD,  MedicHorsALD),
    EV_COMMAND(IDC_SELECTALL_CR,  SelectAll),
    EV_COMMAND(IDC_COPYTEXT_CR,   CopyToClipboard),
    EV_COMMAND(IDC_COPY_ARBRE,    CopyArbre),
    EV_COMMAND(CM_FILECLOSE,      EvClose),
END_RESPONSE_TABLE;
//---------------------------------------------------------------------------//  Constructeur
//
//  doc 	: NSCRDocument � afficher
//---------------------------------------------------------------------------
NSCRReadOnlyView::NSCRReadOnlyView(NSCRDocument& doc, TWindow* parent)
                 :NSRefVue(doc, doc.pContexte, parent)
{
try
{
	HautGcheFenetre.x = HautGcheFenetre.y = 0;
	//
	// Initialise le style avec des ascenseurs horizontaux et verticaux
	//
	Attr.Style = Attr.Style | WS_HSCROLL | WS_VSCROLL;

	// vieux        SetViewMenu(new TMenuDescr(IDM_CRVIEW));
	// moins vieux  SetViewMenu(new TMenuDescr(IDM_MDICMNDS));
	bSetupToolBar = true;
	bEnConclusion = false;
	bEnCodage     = false;

	//Scroller = new TScroller();
	ToolBar 	 = 0;
	pBigBoss  = 0;
	ImpDriver = "";
	ImpDevice = "";
	ImpOutput = "";
	LargeurPolice = 0;
	sLocalisationSelectionne = "";

  TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;
  pMyApp->setMenu(string("menubar_cr"), &hAccelerator) ;
}
catch (...)
{
	erreur("Exception NSCRReadOnlyView ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCRReadOnlyView::~NSCRReadOnlyView()
{}

//
// Destructor for a TWindow: disposes of each window in its ChildList
// and removes itself from a non-0 parent's list of children
//
// Destroys a still-associated MS-Windows interface element and frees
// the instance thunk used for association of an MS-Windows element
// to the TWindow
//
// Disposes of its Scroller if the TScroller object was constructed
//
static void NSshutDown(TWindow* win, void*)
{
	win = 0 ;
}

//---------------------------------------------------------------------------
//  SetupWindow() : Initialise la fen�tre
//---------------------------------------------------------------------------
void
NSCRReadOnlyView::SetupWindow()
{
	string sLibelleDoc ;

	// Pr�paration des �l�ments de mise en page du document
	if (!InitAspect('N'))
  {
		string sErrMsg = pContexte->getSuperviseur()->getText("CREdit", "aspectInitFailed") ;
    erreur(sErrMsg.c_str(), warningError, 0) ;
  	return ;
  }

	// Elaboration d'un nouveau Compte Rendu ?
  NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;

	string sLang = "";
  if ((pContexte) && (pContexte->getUtilisateur()))
  	sLang = pContexte->getUtilisateur()->donneLang() ;

	if (!(CRDoc->IsOpen()))
  {
  	if (!nouveauCR())
    	return ;
    else
    {
    	sLibelleDoc = "" ;
      if (!CRDoc->pPatPathoArray->empty())
      {
      	string sCode = (*(CRDoc->pPatPathoArray->begin()))->pDonnees->lexique ;
        if (sCode != "")
        	pContexte->getDico()->donneLibelle(sLang, &sCode, &sLibelleDoc) ;
      }
      sLibelleDoc += " (en cours)" ;

			CRDoc->SetTitle(sLibelleDoc.c_str()) ;
		}
	}

	// Initialisation de la vue
	PremLigne = 1 ;
  int decodage = Initialisation() ;

	while ((decodage == iAnnule) || (decodage == iCorrige) || (decodage == iAutomatique))
  {
  	if (decodage == iAnnule)  //iAnnule, iCorrige
    {
    	// CloseWindow(); ne marche pas car la fenetre doit se r�f�rencer
		  // proprement au sein du document/vue avant de se fermer
      // Pr�voir d'envoyer un message de fermeture WM_CLOSE
      return ;
    }
    if (decodage == iCorrige)
    	ReprendreCR() ;

    decodage = Initialisation() ;
  }

	// Initialisation des barres de d�filement
	SetScrollRange(SB_VERT, 1, Lignes.size()) ;
  if (LargeurPolice)
		SetScrollRange(SB_HORZ, 1, RectangleGlobal.Width()/LargeurPolice) ;
}


//---------------------------------------------------------------------------//  G�n�re un nouveau compte rendu.//---------------------------------------------------------------------------
bool
NSCRReadOnlyView::nouveauCR()
{
try
{
	//
	pDoc->SetDirty(true) ;

	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;

	bool bTourner = true ;
	while (bTourner)
	{
		//
		// Lancement de la boite de dialogue de choix de module
		//
		if (!pContexte->getDico()->Prend())
			return false ;
		//
		// R�cup�ration des param�tres choisis par l'utilisateur
		//
		//
		// Initialisation du BigBrother
		//
		if (!pBigBoss)
			pBigBoss = new NSSmallBrother(pContexte, CRDoc->pPatPathoArray) ;

		pBigBoss->pFenetreMere 	 = GetWindow() /*pFenetre*/;

		pBigBoss->contexteModule = CRDoc->contexteModule ;
		strcpy(pBigBoss->lexiqueModule, CRDoc->lexiqueModule) ;
		pBigBoss->reprise() ;
		if (pBigBoss->ouvreResModule())
		{
    	pBigBoss->lanceModule() ;
			bTourner = false ;
		}
	}

	if ((pContexte->getSuperviseur()->isCodageAuto()) && (!(CRDoc->pPatPathoArray->empty())))
	{
  	bool bFoundCoding = false ;
  	PatPathoIter iter = CRDoc->pPatPathoArray->ChercherPremierFils(CRDoc->pPatPathoArray->begin()) ;
    while ((iter != NULL) && (iter != CRDoc->pPatPathoArray->end()))
    {
    	if ((*iter)->getLexiqueSens(pContexte) == string("0CODE"))
      {
      	bFoundCoding = true ;
        break ;
      }
      iter = CRDoc->pPatPathoArray->ChercherFrere(iter) ;
    }

    if (false == bFoundCoding)
			Codage() ;
	}

	return true ;
}
catch (...)
{
	erreur("Exception NSCRReadOnlyView::nouveauCR", standardError, 0) ;
	return false ;
}
}

//---------------------------------------------------------------------------//  Initialise les paragraphes et les lignes
//---------------------------------------------------------------------------
int
NSCRReadOnlyView::Initialisation()
{
	int iReussi ;
	//
	// Demande au document de se d�coder dans un fichier
	//
	::SetCursor(::LoadCursor(0, IDC_WAIT)) ; //sablier

	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;
	iReussi = CRDoc->decodeCR(&(CRDoc->aCRPhrases)) ;

	::SetCursor(::LoadCursor(0, IDC_ARROW)) ;

	if (iReussi != iOk)
	{
		if (iReussi == iErreur)
			erreur("Impossible de d�coder le compte-rendu.", warningError, 0, GetHandle()) ;

		return iReussi ;
	}
	//
	// Initialise les paragraphes et les lignes
	//
	BOOL Reussi = InitialiseLignes() ;

	if (PremLigne > Lignes.size())
		PremLigne = Lignes.size() ;

	return iOk ;
}

//---------------------------------------------------------------------------//  Correction d'un compte rendu.
//---------------------------------------------------------------------------
bool
NSCRReadOnlyView::corrigeCR()
{
	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;

try
{
	//
  // Initialisation du BigBrother
  //
  if (!pBigBoss)
  {
  	pBigBoss = new NSSmallBrother(pContexte, CRDoc->pPatPathoArray) ;

    if (pBigBoss)
    {
    	PatPathoIter iterPremier = (CRDoc->pPatPathoArray)->begin() ;

      // strcpy(pBigBoss->noeudModule, (*iterPremier)->pDonnees->noeud);

      string sLexiqueModule = string((*iterPremier)->pDonnees->lexique) ;
      strcpy(CRDoc->lexiqueModule, sLexiqueModule.c_str()) ;

      pBigBoss->contexteModule = CRDoc->contexteModule ;
      strcpy(pBigBoss->lexiqueModule, CRDoc->lexiqueModule) ;
    }
  }
  if (!pBigBoss->pContexte->getFilGuide()->Prend())
  	return false;
  if (!pBigBoss->pContexte->getDico()->Prend())
  	return false;
  pBigBoss->pBBFiche = static_cast<BBFiche*>(pBigBoss->pContexte->getFilGuide()->pBBFiche) ;

  pBigBoss->pFenetreMere = GetWindow() /*pFenetre*/;

  if (pBigBoss->ouvreResModule())
  {
  	if (pBigBoss->corrigeModule(&sLocalisationSelectionne))
    {
    	Invalidate() ;
      pDoc->SetDirty(true) ;
      return true ;
    }
    else
    	return false ;
  }
}
catch (...)
{
	erreur("Exception NSCRReadOnlyView::corrigeCR.", standardError, 0, GetHandle()) ;
  return false ;
}
	return false ;
}

//-----------------------------------------------------------------------//-----------------------------------------------------------------------

voidNSCRReadOnlyView::CorrigerCR()
{
	int iInit ;

	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc);
  NSPatPathoArray Path = *(CRDoc->pPatPathoArray) ;
	if (corrigeCR())  {
  	iInit = Initialisation() ;

    while (iInit != iOk)    {
    	if (iInit == iAnnule)
      	*(CRDoc->pPatPathoArray) = Path ;

      if (iInit == iCorrige)      	corrigeCR() ;

      iInit = Initialisation() ;    }

    UpdateWindow() ;    Invalidate() ;
  }
}

voidNSCRReadOnlyView::CopyArbre()
{
try
{
	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc);

	if ((CRDoc->pPatPathoArray)->empty())		return;

	NSSuper* pSuper = pContexte->getSuperviseur();	pSuper->pBufCopie->vider();

	PatPathoIter iter = (CRDoc->pPatPathoArray)->begin();	for ( ; (iter != (CRDoc->pPatPathoArray)->end()) &&
			((*iter)->pDonnees->codeLocalisation != sLocalisationSelectionne);
				iter++) ;

	if (iter == (CRDoc->pPatPathoArray)->end())		return ;

	NSCutPaste CP(pContexte) ;
	NSPatPathoArray* pSousPatho = new NSPatPathoArray(pContexte) ;	(CRDoc->pPatPathoArray)->ExtrairePatPatho(iter, pSousPatho) ;

	// Attention : pSouspatho contient la sous-patpatho de l'�lement en cours,	//             dans laquelle l'�l�ment en cours n'est pas ; on ne peut
	//             donc pas faire simplement *(CP.pPatPatho) = *pSousPatho;
	//
	NSPatPathoInfo racine = *(*iter);
	racine.pDonnees->setLigne(0);
	racine.pDonnees->setColonne(0);
	CP.pPatPatho->push_back(new NSPatPathoInfo(racine));

	if (pSousPatho->empty())	{
		delete pSousPatho ;
		*(pSuper->pBufCopie) = CP ;
		return ;
	}

	PatPathoIter ssiter;	for (ssiter = pSousPatho->begin(); ssiter != pSousPatho->end(); ssiter++)
	{
		(*ssiter)->pDonnees->setLigne((*ssiter)->pDonnees->getLigne() + 1) ;
		(*ssiter)->pDonnees->setColonne((*ssiter)->pDonnees->getColonne() + 1) ;

		CP.pPatPatho->push_back(new NSPatPathoInfo(*(*ssiter)));	}
	delete pSousPatho;

	*(pSuper->pBufCopie) = CP;}
catch (...)
{
	erreur("Exception NSCRReadOnlyView::CopyArbre", standardError, 0) ;
}
}

/*** Fonction de r�ponse au menu "Supprimer une ligne"* Response function for the "Line delete" menu entry*/
void
NSCRReadOnlyView::SupprimerLigne()
{
	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc);
	NSPatPathoArray Path = *(CRDoc->pPatPathoArray);

	if (!SupprimerLigneCR())		return ;
	int iInit = Initialisation();
	while (iInit != iOk)
	{
		if (iInit == iAnnule)
			*(CRDoc->pPatPathoArray) = Path;
		if (iInit == iCorrige)
			ReprendreCR();

		iInit = Initialisation();	}

	UpdateWindow();
	Invalidate();
}

/**
* Suppression d'un segment d'arbre au sein d'un compte rendu* Delete a sub-tree inside an exam report*/
boolNSCRReadOnlyView::SupprimerLigneCR()
{
try
{
	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;
	//
	// Initialisation du BigBrother
	//
	if (!pBigBoss)
	{
		pBigBoss = new NSSmallBrother(pContexte, CRDoc->pPatPathoArray) ;

		PatPathoIter iterPremier = (CRDoc->pPatPathoArray)->begin();
		string sLexiqueModule = string((*iterPremier)->pDonnees->lexique);

		strcpy(CRDoc->lexiqueModule, sLexiqueModule.c_str());

		pBigBoss->contexteModule = CRDoc->contexteModule;
		strcpy(pBigBoss->lexiqueModule, CRDoc->lexiqueModule);
  }

	pBigBoss->pFenetreMere = GetWindow() /*pFenetre*/;

	if (!pBigBoss->pContexte->getFilGuide()->Prend())
		return false;
	if (!pBigBoss->pContexte->getDico()->Prend())
		return false;

	pBigBoss->pBBFiche = static_cast<BBFiche*>(pBigBoss->pContexte->getFilGuide()->pBBFiche);

	if (!(pBigBoss->ouvreResModule()))
  	return false ;

	if (pBigBoss->SupprimerLigneCR(&sLocalisationSelectionne))
	{
		Invalidate() ;
		pDoc->SetDirty(true) ;
		return true ;
	}

  return false ;
}
catch (...)
{
	erreur("Exception NSCRReadOnlyView::SupprimerLigneCR", standardError, 0) ;
	return false ;
}
}

//-----------------------------------------------------------------------// Fonction : NSCRReadOnlyView::ReprendreCR()
//-----------------------------------------------------------------------
void
NSCRReadOnlyView::ReprendreCR()
{
	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;

	NSPatPathoArray Path = *(CRDoc->pPatPathoArray);
	if (ReprendreCompteRendu())	{
		int iInit = Initialisation() ;

		while (iInit != iOk)		{
			if (iInit == iAnnule)
				*(CRDoc->pPatPathoArray) = Path ;
			if (iInit == iCorrige)
				ReprendreCR() ;

			iInit = Initialisation();		}
		UpdateWindow() ;
		Invalidate() ;
	}
}

boolNSCRReadOnlyView::ReprendreCompteRendu()
{
	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;

try
{
	//
  // Initialisation du BigBrother
  //
  if (!pBigBoss)
  {
  	pBigBoss = new NSSmallBrother(pContexte, CRDoc->pPatPathoArray) ;
    pBigBoss->pBBFiche = static_cast<BBFiche*>(pBigBoss->pContexte->getFilGuide()->pBBFiche) ;
    if (pBigBoss)
    {
    	PatPathoIter iterPremier = (CRDoc->pPatPathoArray)->begin() ;
      string sLexiqueModule = string((*iterPremier)->pDonnees->lexique) ;
      strcpy(CRDoc->lexiqueModule, sLexiqueModule.c_str()) ;

      pBigBoss->contexteModule = CRDoc->contexteModule ;
      strcpy(pBigBoss->lexiqueModule, CRDoc->lexiqueModule) ;
      // strcpy(pBigBoss->noeudModule, (*iterPremier)->pDonnees->noeud);
    }
  }

  if (!pBigBoss->pContexte->getFilGuide()->Prend())
  	return false ;
	if (!pBigBoss->pContexte->getDico()->Prend())
  	return false ;
	pBigBoss->pBBFiche = static_cast<BBFiche*>(pBigBoss->pContexte->getFilGuide()->pBBFiche) ;

	pBigBoss->pFenetreMere = GetWindow() /*pFenetre*/ ;

	if (pBigBoss->ouvreResModule())
  {
		if (pBigBoss->lanceModule())
		{
			Invalidate() ;
			pDoc->SetDirty(true) ;
			return true ;
		}
		else
			return false ;
	}
}
catch (...)
{	erreur("Exception NSCRReadOnlyView::ReprendreCompteRendu", standardError, 0, GetHandle()) ;
	return false ;
}
	return true ;
}

//------------------------------------------------------------------//  Appel automatique d'une fiche Compt � partir du compte-rendu
//------------------------------------------------------------------
void
NSCRReadOnlyView::Compta()
{
try
{
  NSCRDocument* 	CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;
	if (CRDoc->pPatPathoArray->empty())
	{
		erreur("Il n'existe aucune donn�e pour ce document", warningError, 0, GetHandle()) ;
		return ;
	}

	struct date 	dateSys ;
	struct time		heureSys ;
	string			sCode = "", sExam = "", sSyn = "" ;
	string 			sLibelleDoc = "", sDateDoc = "", sExtHosp = "" ;

	NSComptInfo   comptInfo ;
	NSFse1610Info	fse1610Info ;

	if (!CRDoc->pBigBoss)
		CRDoc->pBigBoss = new NSSmallBrother(pContexte, CRDoc->pPatPathoArray) ;

	// date de l'examen
  PatPathoIter iterPpt = pDoc->pPatPathoArray->begin() ;
  iterPpt++ ;
  if (iterPpt != pDoc->pPatPathoArray->end())
  	if ((*iterPpt)->getLexiqueSens(pContexte) == "KCHIR")
    	pDoc->pPatPathoArray->CheminDansPatpatho(0, "KCHIR", &sDateDoc) ;

	if (sDateDoc == "")
		CRDoc->pPatPathoArray->CheminDansPatpatho(CRDoc->pBigBoss, "LADMI/KCHIR", &sDateDoc) ;

	if (sDateDoc == "")
	{
		if (CRDoc->pDocInfo) // on prend la date de cr�ation (heure = 0)
		{
			strcpy(comptInfo.pDonnees->date, CRDoc->pDocInfo->getCreDate().c_str()) ;
			strcpy(comptInfo.pDonnees->heure, "0000") ;
		}
		else // on prend la date et l'heure du jour
		{
			getdate(&dateSys) ;
			gettime(&heureSys) ;
			sprintf(comptInfo.pDonnees->date, "%4d%02d%02d", dateSys.da_day,
							dateSys.da_mon, dateSys.da_day) ;
			sprintf(comptInfo.pDonnees->heure, "%02d%02d", heureSys.ti_hour,
							heureSys.ti_min) ;
		}

		// on cale la date de la Fse1610 sur celle de la fiche Compt
		strcpy(fse1610Info.pDonnees->date, comptInfo.pDonnees->date) ;
		strcat(fse1610Info.pDonnees->date, comptInfo.pDonnees->heure) ;
	}
	else // on prend la date du document (heure = 0)
	{
  	NVLdVTemps tpsDateDoc ;
    tpsDateDoc.initFromDate(sDateDoc) ;

    // Warning : in the accounting module, hour just means hhmm and not hhmmss
    string sAccountingHour = string(tpsDateDoc.donneHeure(), 0, 4) ;

		strcpy(comptInfo.pDonnees->date, tpsDateDoc.donneDate().c_str()) ;
		strcpy(comptInfo.pDonnees->heure, sAccountingHour.c_str()) ;
		strcpy(fse1610Info.pDonnees->date, tpsDateDoc.donneDate().c_str()) ;
		strcat(fse1610Info.pDonnees->date, sAccountingHour.c_str()) ;
	}

	// Externe / Hospitalis�
	CRDoc->pPatPathoArray->CheminDansPatpatho(CRDoc->pBigBoss, "LADMI/LCONT", &sExtHosp) ;
	if (sExtHosp != "")
		sExtHosp = string(sExtHosp, 0, 5) ;

	sCode = (*(CRDoc->pPatPathoArray->begin()))->pDonnees->lexique ;
	if (sCode != "")
	{
		sExam = string(sCode,0,5) ;
		sSyn = string(sCode,5,1) ;
	}

  NSFse16Array aFseCCAM ;

  // Code CCAM examen
	string sCodeActe = "" ;
  string sChemin = string("0CODE/6CCAM") ;
  CRDoc->pPatPathoArray->CheminDansPatpatho(CRDoc->pBigBoss, sChemin, &sCodeActe) ;
  if (sCodeActe != "")
  {
    NSCcam     ccamFile(pContexte) ;
    NSCcamInfo ccamInfo ;
    DBIResult result = ccamFile.getRecordByCode(sCodeActe, &ccamInfo, true, true) ;
    int        nbPrest = 0 ;

    if (string(ccamInfo.pDonnees->code) == sCodeActe)
    {
    	NSFseCCAMInfo ccamFSEInfo ;
    	ccamFSEInfo.initFromCCAMinfo(&ccamInfo) ;

      // on cale la date de la FseCCAM sur celle de la fiche Compt
			strcpy(ccamFSEInfo.pDonnees->date, comptInfo.pDonnees->date) ;
			strcat(ccamFSEInfo.pDonnees->date, comptInfo.pDonnees->heure) ;

      // on copie le num�ro de la prestation
      char numero[FSECCAM_NUMPREST_LEN + 1] ;
			sprintf(numero, "%04d", nbPrest) ;
   		strcpy(ccamFSEInfo.pDonnees->numprest, numero) ;
      nbPrest++ ;

  		aFseCCAM.push_back(new NSBlocFse16(&ccamFSEInfo)) ;
    }
  }

	strcpy(comptInfo.pDonnees->examen,   sExam.c_str()) ;
	strcpy(comptInfo.pDonnees->synonyme, sSyn.c_str()) ;
	strcpy(comptInfo.pDonnees->contexte, sExtHosp.c_str()) ;

  NSPersonInfo personInfo(pContexte, pContexte->getPatient()->getNss()) ;

	// NSComptaPatient compta(pContexte, (NSPatInfo*) pContexte->getPatient()) ;
  NSComptaPatient compta(pContexte, &personInfo) ;

  // if (aFseCCAM.empty())
  if (pContexte->getSuperviseur()->isNoCcamForReport())
		compta.CmFicheCompt(&comptInfo, &fse1610Info) ;
  else
  	compta.CmFicheCompt(&comptInfo, NULL, &aFseCCAM) ;
}
catch (...)
{
	erreur("Exception NSCRReadOnlyView::Compta", standardError, 0) ;
}
}

//------------------------------------------------------------------//  g�n�rer les conclusions manuelle et automatique
//------------------------------------------------------------------
void
NSCRReadOnlyView::Conclusion()
{
try
{
    if (bEnConclusion)
        return;

    bEnConclusion = true;
    NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc);
    if (!pBigBoss)   	    pBigBoss = new NSSmallBrother(pContexte, CRDoc->pPatPathoArray);

    if (!pBigBoss->ouvreResModule())   	    return;

    if (!pBigBoss->pContexte->getFilGuide()->Prend())   	    return;

    if (!pBigBoss->pContexte->getDico()->Prend())   	    return;

    pBigBoss->pFenetreMere 	 = GetWindow() /*pFenetre*/;
    pBigBoss->Conclusion();
    pBigBoss->contexteModule = CRDoc->contexteModule;
    Initialisation();
    UpdateWindow();    Invalidate();
    pDoc->SetDirty(true);
    bEnConclusion = false;
}
catch (...)
{
	erreur("Exception NSCRReadOnlyView::Conclusion", standardError, 0) ;
}
}

//------------------------------------------------------------------//  g�n�rer les conclusions manuelle et automatique
//------------------------------------------------------------------
void
NSCRReadOnlyView::Codage()
{
try
{
	if (bEnCodage)
		return ;
	bEnCodage = true ;

	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;

	if (!pBigBoss)		pBigBoss = new NSSmallBrother(pContexte, CRDoc->pPatPathoArray) ;

	if (!pBigBoss->ouvreResModule())
		return ;
	if (!pBigBoss->pContexte->getFilGuide()->Prend())
		return ;
	if (!pBigBoss->pContexte->getDico()->Prend())
		return ;

	pBigBoss->pFenetreMere 	 = GetWindow() /*pFenetre*/;

	pBigBoss->Codage() ;	pBigBoss->contexteModule = CRDoc->contexteModule ;
	Initialisation() ;
	UpdateWindow() ;
	Invalidate() ;
	pDoc->SetDirty(true) ;
	bEnCodage = false ;
}
catch (...)
{
	erreur("Exception NSCRReadOnlyView::Codage", standardError, 0) ;
}
}
voidNSCRReadOnlyView::TLibreOrdonnance(){try{    string sCodeSens ;    NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc);
    NSPatPathoArray* pPPT = CRDoc->getPatPatho();
    if (pPPT->empty())
        return;
    PatPathoIter iter = pPPT->begin() ;

    //
    // Trouver le noeud ayant pLocalisation comme localisation
    //
    bool trouve = false ;
    while (iter != pPPT->end())
    {
        // Note : sLocalisationSelectionne est une variable de classe, initialis�e en
        // fonction de la ligne s�lectionn�e dans le click droit.
        if (strcmp((*iter)->pDonnees->codeLocalisation, sLocalisationSelectionne.c_str()) == 0)
        {
            trouve = true ;
            break;
        }

        iter++ ;
    }

    if (!trouve)
   	    return;    // Le noeud p�re retrouv� ici est un noeud m�dicament.    // Il a une ensemble de fils (forme, phase, etc.) et �ventuellement    // un fils qui a comme code sens "#TLI#" qui est le p�re d'un bloc de    // texte libre, avec lequel on constitue une patpatho    NSPatPathoArray* pPatPathoTLibre = new NSPatPathoArray(pContexte);    NSPatPathoArray* pSousPatPatho = new NSPatPathoArray(pContexte);    int iColBase = (*iter)->pDonnees->getColonne() ;    bool bTLibre = false;    iter++ ;    while ((iter != pPPT->end()) && ((*iter)->pDonnees->getColonne() > iColBase))    {
        string sElemLex = string((*iter)->pDonnees->lexique);
        string sSens;
        pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

        if ((*iter)->pDonnees->getColonne() == iColBase+1)
        {
            // Dates
            if (sSens == "#TLI#")
            {
                bTLibre = true;
                pPPT->ExtrairePatPatho(iter, pSousPatPatho);
                pPPT->SupprimerFils(iter);
                pPPT->SupprimerItem(iter);
            }
            else
                iter++;
        }
        else
            iter++;
    }  if (bTLibre)  {    pPatPathoTLibre->ajoutePatho("#TLI#1", 0) ;    // Insertion en queue (iter doit �tre ici egal � end())    pPatPathoTLibre->InserePatPatho(pPatPathoTLibre->end(), pSousPatPatho, 1) ;  }    NSPatPathoArray* pPatPathoCopy = new NSPatPathoArray(pContexte);    *pPatPathoCopy = *pPatPathoTLibre;    NSSmallBrother* pBigBossTL = new NSSmallBrother(pContexte, pPatPathoTLibre);    pBigBossTL->pFenetreMere 	 = GetWindow() /*pFenetre*/;    pBigBossTL->EditionTexteLibre();    *pPatPathoTLibre = *(pBigBossTL->getPatPatho());    if (!pPatPathoTLibre->estEgal(pPatPathoCopy))    {        // Insertion avant iter du nouveau TL        pPPT->InserePatPatho(iter, pPatPathoTLibre, iColBase+1);        // r�initialisation pour nouvel affichage du document        Initialisation();
        UpdateWindow();        Invalidate();
        pDoc->SetDirty(true);    }	delete pPatPathoTLibre ;  delete pSousPatPatho ;  delete pPatPathoCopy ;	delete pBigBossTL ;}catch (...){
	erreur("Exception TLibreOrdonnance.", standardError, 0) ;
}
}
void
NSCRReadOnlyView::MedicEnALD()
{
try
{
  string sCodeSens ;
  NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc);
  NSPatPathoArray* pPPT = CRDoc->getPatPatho();
  if (pPPT->empty())
      return;
  PatPathoIter iter = pPPT->begin() ;
  // on note la colonne de base
  int iColBase = (*iter)->pDonnees->getColonne() ;

  //
  // Trouver le noeud ayant pLocalisation comme localisation
  //
  bool trouve = false ;
  while (iter != pPPT->end())
  {
      // Note : sLocalisationSelectionne est une variable de classe, initialis�e en
      // fonction de la ligne s�lectionn�e dans le click droit.
      if (strcmp((*iter)->pDonnees->codeLocalisation, sLocalisationSelectionne.c_str()) == 0)
      {
          trouve = true ;
          break;
      }

      iter++ ;
  }

  if (!trouve)
      return;

  PatPathoIter iterNode = iter;
  int colonne;

  // on remonte en arri�re jusqu'au premier chap�tre ALD ou Hors-ALD
  while ((*iter)->pDonnees->getColonne() > iColBase)
  {
      string sElemLex = string((*iter)->pDonnees->lexique);
      pContexte->getDico()->donneCodeSens(&sElemLex, &sCodeSens);

      if ((sCodeSens == "GPALD") || (sCodeSens == "GPCOD"))
          break;

      iter--;
  }

  colonne = (*iter)->pDonnees->getColonne() ;

  if (colonne == iColBase)
  {
      // on est remont� au noeud root => chap�tre ALD ou Hors-ALD introuvables
      erreur("Vous devez passer votre ordonnance en mode ALD avant d'utiliser cette option.", warningError, 0) ;
      return;
  }

  if (sCodeSens == "GPALD")
  {
      erreur("Ce m�dicament est d�j� class� en ALD.", warningError, 0) ;
      return;
  }

  // on reconstruit la patpatho m�dicament (� d�placer)
  NSPatPathoArray* pPPTMedic = new NSPatPathoArray(pContexte);
  // on extrait d'abord la sous patpatho du m�dicament
  NSPatPathoArray* pSousPPT = new NSPatPathoArray(pContexte);
  pPPT->ExtrairePatPatho(iterNode, pSousPPT);

  // on copie le node m�dicament dans sa nouvelle patpatho
  // et on ins�re ses fils
  pPPTMedic->ajoutePatho(iterNode, standardError, 0) ;
  pPPTMedic->InserePatPatho(pPPTMedic->end(), pSousPPT, 1);

  // on supprime maintenant le m�dicament de la patpatho source
  pPPT->SupprimerFils(iterNode);
  pPPT->SupprimerItem(iterNode);

  // on recherche le chap�tre source pour voir s'il contient encore des m�dicaments
  // car sinon, on devra le supprimer
  iter = pPPT->ChercherItem("GPCOD1") ;
  PatPathoIter iterChapter = iter;
  int iColChapter = (*iter)->pDonnees->getColonne() ;
  int iNbMedic = 0;
  iter++;

  while ((iter != pPPT->end()) && ((*iter)->pDonnees->getColonne() > iColChapter))
  {
      if ((*iter)->pDonnees->getColonne() == (iColChapter + 1))
          iNbMedic++;

      iter++;
  }

  // cas suppression du chap�tre source
  if (iNbMedic == 0)
      pPPT->SupprimerItem(iterChapter);

  // on recherche maintenant le chap�tre destination pour voir s'il existe
  // sinon, on devra le cr�er dans l'ordre : 1.GPALD 2.GPCOD
  bool bExisteALD = true;

  iter = pPPT->ChercherItem("GPALD1") ;
  if (iter == pPPT->end())
      bExisteALD = false;

  if (!bExisteALD)
  {
    // on reconstruit pPPTMedic avec le chap�tre ALD
    pSousPPT->vider() ;
    *pSousPPT = *pPPTMedic ;
    pPPTMedic->vider() ;
    pPPTMedic->ajoutePatho("GPALD1", 0) ;
    pPPTMedic->InserePatPatho(pPPTMedic->end(), pSousPPT, 1) ;
  }

  // on cherche le chap�tre suivant pour insertion avant iter
  // car iter est au pire �gal � end()
  iter = pPPT->ChercherItem("GPCOD1") ;
  if (bExisteALD)
      pPPT->InserePatPatho(iter, pPPTMedic, iColBase+2);
  else
      pPPT->InserePatPatho(iter, pPPTMedic, iColBase+1);

  // r�initialisation pour nouvel affichage du document
  Initialisation();
  UpdateWindow();  Invalidate();
  pDoc->SetDirty(true);

  delete pSousPPT;
  delete pPPTMedic;
}
catch (...)
{
    erreur("Exception MedicEnALD.", standardError, 0) ;
}
}

void
NSCRReadOnlyView::MedicHorsALD()
{
try
{
  string sCodeSens ;
  NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc);
  NSPatPathoArray* pPPT = CRDoc->getPatPatho();
  if (pPPT->empty())
      return;
  PatPathoIter iter = pPPT->begin() ;
  // on note la colonne de base
  int iColBase = (*iter)->pDonnees->getColonne() ;

  //
  // Trouver le noeud ayant pLocalisation comme localisation
  //
  bool trouve = false ;
  while (iter != pPPT->end())
  {
      // Note : sLocalisationSelectionne est une variable de classe, initialis�e en
      // fonction de la ligne s�lectionn�e dans le click droit.
      if (strcmp((*iter)->pDonnees->codeLocalisation, sLocalisationSelectionne.c_str()) == 0)
      {
          trouve = true ;
          break;
      }

      iter++ ;
  }

  if (!trouve)
      return;

  PatPathoIter iterNode = iter;
  int colonne;

  // on remonte en arri�re jusqu'au premier chap�tre ALD ou Hors-ALD
  while ((*iter)->pDonnees->getColonne() > iColBase)
  {
      string sElemLex = string((*iter)->pDonnees->lexique);
      pContexte->getDico()->donneCodeSens(&sElemLex, &sCodeSens);

      if ((sCodeSens == "GPALD") || (sCodeSens == "GPCOD"))
          break;

      iter--;
  }

  colonne = (*iter)->pDonnees->getColonne() ;

  if (colonne == iColBase)
  {
      // on est remont� au noeud root => chap�tre ALD ou Hors-ALD introuvables
      erreur("Vous devez passer votre ordonnance en mode ALD avant d'utiliser cette option.", warningError, 0) ;
      return;
  }

  if (sCodeSens == "GPCOD")
  {
      erreur("Ce m�dicament est d�j� class� Hors-ALD.", warningError, 0) ;
      return;
  }

  // on reconstruit la patpatho m�dicament (� d�placer)
  NSPatPathoArray* pPPTMedic = new NSPatPathoArray(pContexte);
  // on extrait d'abord la sous patpatho du m�dicament
  NSPatPathoArray* pSousPPT = new NSPatPathoArray(pContexte);
  pPPT->ExtrairePatPatho(iterNode, pSousPPT);

  // on copie le node m�dicament dans sa nouvelle patpatho
  // et on ins�re ses fils
  pPPTMedic->ajoutePatho(iterNode, standardError, 0) ;
  pPPTMedic->InserePatPatho(pPPTMedic->end(), pSousPPT, 1);

  // on supprime maintenant le m�dicament de la patpatho source
  pPPT->SupprimerFils(iterNode);
  pPPT->SupprimerItem(iterNode);

  // on recherche le chap�tre source pour voir s'il contient encore des m�dicaments
  // car sinon, on devra le supprimer
  iter = pPPT->ChercherItem("GPALD1") ;
  PatPathoIter iterChapter = iter;
  int iColChapter = (*iter)->pDonnees->getColonne() ;
  int iNbMedic = 0;
  iter++;

  while ((iter != pPPT->end()) && ((*iter)->pDonnees->getColonne() > iColChapter))
  {
      if ((*iter)->pDonnees->getColonne() == (iColChapter + 1))
          iNbMedic++;

      iter++;
  }

  // cas suppression du chap�tre source
  if (iNbMedic == 0)
      pPPT->SupprimerItem(iterChapter);

  // on recherche maintenant le chap�tre destination pour voir s'il existe
  // sinon, on devra le cr�er dans l'ordre : 1.GPALD 2.GPCOD
  bool bExisteHorsALD = true;

  iter = pPPT->ChercherItem("GPCOD1") ;
  if (iter == pPPT->end())
      bExisteHorsALD = false;

  if (!bExisteHorsALD)
  {
    // on reconstruit pPPTMedic avec le chap�tre ALD
    pSousPPT->vider() ;
    *pSousPPT = *pPPTMedic ;
    pPPTMedic->vider() ;
    pPPTMedic->ajoutePatho("GPCOD1", 0) ;
    pPPTMedic->InserePatPatho(pPPTMedic->end(), pSousPPT, 1) ;
  }

  // on ins�re en queue dans tous les cas
  if (bExisteHorsALD)
    pPPT->InserePatPatho(pPPT->end(), pPPTMedic, iColBase+2) ;
  else
    pPPT->InserePatPatho(pPPT->end(), pPPTMedic, iColBase+1) ;

  // r�initialisation pour nouvel affichage du document
  Initialisation();
  UpdateWindow();  Invalidate();
  pDoc->SetDirty(true);

  delete pSousPPT;
  delete pPPTMedic;
}
catch (...)
{
    erreur("Exception MedicHorsALD.", standardError, 0) ;
}
}
// Fonction CanClose : Appel de CanClose du document////////////////////////////////////////////////////////////////
bool
NSCRReadOnlyView::CanClose()
{
	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc);

	TMyApp* 	  pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;
	if (!CRDoc->CanClose())
	{
		string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;

    string sText ;
		if (pDoc->pDocInfo)
    	sText = pContexte->getSuperviseur()->getText("documentManagement", "doYouWantToSaveChangesForDocument") ;
		else
    	sText = pContexte->getSuperviseur()->getText("documentManagement", "doYouWantToSaveDocument") ;
    sText += string(" ") + CRDoc->GetTitle() + string(" ?") ;

    int retVal = MessageBox(sText.c_str(), sCaption.c_str(), MB_YESNOCANCEL) ;
		if (retVal == IDCANCEL)
			return false ;
		if (retVal == IDYES)
		{
			bool okEnreg = CRDoc->enregistre() ;

			if (okEnreg)
			{
				pMyApp->FlushControlBar() ;
				bSetupToolBar = false ;
			}
			return okEnreg ;
		}
	}
	pDoc->SetDirty(false) ;

	pMyApp->FlushControlBar() ;
	bSetupToolBar = false ;
	return true ;
}

//-------------------------------------------------------------------------//--------------------------------------------------------------------------
void
NSCRReadOnlyView::EvLButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	bool invalider = NSRefVue::EvLButtonDown(modKeys, point) ;
	if (invalider)
		Invalidate() ;
}

// Click droit//////////////////////////////////////////////////////
voidNSCRReadOnlyView::EvRButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
try
{

	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;
	NS_CLASSLIB::TPoint ptClick = point ;
	// pPopupMenuLigne->TrackPopupMenu(TPM_RIGHTBUTTON, point, 0, *this);	//
	// On r�cup�re un "contexte d'information" concernant l'�cran
	//

	TIC* pDC = new TIC("DISPLAY", NULL, NULL) ;	pDC->SetMapMode(MM_LOMETRIC) ;

	//	// On transforme les unit�s physiques d'�cran en unit�s logiques
	//

	pDC->DPtoLP(&ptClick) ;	delete pDC ;

	//	// On positionne le point dans la page
	//

	ptClick.x += HautGcheFenetre.x ;	ptClick.y += HautGcheFenetre.y ;

	//	// On cherche si ce point se situe sur une ligne
	// Attention, les ordonn�es sont < 0
	//

	NSLignesArrayIter iter ;
	bool tourner = true ;
  if (false == Lignes.empty())
		for (iter = Lignes.begin(); (iter != Lignes.end()) && (tourner); )		{
    	if ((ptClick.x >= (*iter)->Boite.left) && (ptClick.x <= (*iter)->Boite.right) &&
          (ptClick.y <= (*iter)->Boite.top)  && (ptClick.y >= (*iter)->Boite.bottom) )
    		tourner = false ;
      else
      	iter++ ;
    }

	//	// Si ce point se situe sur une ligne, on cherche la phrase correspondante
	//
	if (!tourner)
	{
		UINT iPhrase = (*iter)->iNumPhrase ;
    NSCRPhrArrayIter it ;
    bool bOrdo = false ;

    if (!CRDoc->getPatPatho()->empty())
    {
    	string sElemLex = (*(CRDoc->getPatPatho()->begin()))->getLexique() ;
      string sSens ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;
      if (sSens == "ZORDO")
      	bOrdo = true ;
    }

    for (it = CRDoc->aCRPhrases.begin(); (it != CRDoc->aCRPhrases.end()) && ((*it)->iNumero != iPhrase); it++) ;

		//		// Si on a trouv� une phrase, on remonte � la (aux) l�sion(s)
		//

    TPopupMenu *menu = new TPopupMenu();
		if (it != CRDoc->aCRPhrases.end())		{
    	if (!((*it)->aLesions.empty()))
      	sLocalisationSelectionne = *((*it)->aLesions)[(*it)->aLesions.size() - 1] ;

      if (!bOrdo)
      {
      	if ((*it)->aLesions.empty())        	menu->AppendMenu(MF_GRAYED, 0, "Corriger") ;
        else
        	menu->AppendMenu(MF_STRING, IDC_CORRIGER, "Corriger") ;

        menu->AppendMenu(MF_STRING, IDC_REPRENDRE_CR, "Reprendre compte rendu") ;        menu->AppendMenu(MF_STRING, IDC_CONCLUSION_CR, "Conclusion") ;
      }
      else
      {
      	menu->AppendMenu(MF_STRING, IDC_TLIB_ORDO, "Texte libre") ;
        menu->AppendMenu(MF_STRING, IDC_MEDIC_ALD, "Passer en ALD") ;
        menu->AppendMenu(MF_STRING, IDC_MEDIC_NONALD, "Passer hors ALD") ;
      }

      menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
      menu->AppendMenu(MF_STRING, IDC_COPY_ARBRE, "Copier arbre") ;

      // s'il existe une ligne s�lectionn�e au moins      if (iLigneEnCours)
      	menu->AppendMenu(MF_STRING, IDC_COPYTEXT_CR, "Copier texte") ;
      else
      	menu->AppendMenu(MF_GRAYED, 0, "Copier texte") ;

      menu->AppendMenu(MF_STRING, IDC_SELECTALL_CR, "Tout s�lectionner") ;      menu->AppendMenu(MF_SEPARATOR, 0, 0);

      if ((*it)->aLesions.empty())      	menu->AppendMenu(MF_GRAYED, 0, "Supprimer") ;
      else
      	menu->AppendMenu(MF_STRING, IDC_SUPPRIMER, "Supprimer") ;

      ClientToScreen(point) ;
      menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point, 0, HWindow) ;		}

    delete menu ;	}
}
catch (...)
{
	erreur("Exception NSCRReadOnlyView::EvRButtonDown", standardError, 0) ;
}
}

//---------------------------------------------------------------------------
// Lib�ration de la derni�re barre d'outils cr�ee
//---------------------------------------------------------------------------
void
NSCRReadOnlyView::EvSetFocus(THandle hWndLostFocus /* may be 0 */)
{
	activateMUEViewMenu() ;

	TMyApp* pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;
	NSRefVue::EvSetFocus(hWndLostFocus) ;
	if (bSetupToolBar && (GetWindow() != pMyApp->GetToolBarWindow()))  {
  	SetupToolBar() ;
    pMyApp->SetToolBarWindow(GetWindow()) ;
  }

  pMyApp->setMenu(string("menubar_cr"), &hAccelerator) ;
}

voidNSCRReadOnlyView::SetupToolBar()
{
	TMyApp* pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;
	pMyApp->FlushControlBar() ;

	pMyApp->cb2->Insert(*new TButtonGadget(IDC_COMPTA_CR, IDC_COMPTA_CR, TButtonGadget::Command)) ;
	pMyApp->cb2->Insert(*new TButtonGadget(IDC_CODAGE_CR, IDC_CODAGE_CR, TButtonGadget::Command)) ;
	pMyApp->cb2->Insert(*new TButtonGadget(IDC_CONCLUSION_CR, IDC_CONCLUSION_CR, TButtonGadget::Command)) ;

	pMyApp->cb2->LayoutSession() ;}

voidNSCRReadOnlyView::CmEnregistre()
{
	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc) ;

	bool          bNewDoc = false ;	int           retVal ;

	if (CRDoc->pDocInfo == 0)		bNewDoc = true ;

	if (CRDoc->enregistre())	{
		// on remet � jour le titre
		SetDocTitle(CRDoc->GetTitle(), 0) ;
		pDoc->SetDirty(false) ;

		if (bNewDoc && (pContexte->getSuperviseur()->isComptaAuto()) && (CRDoc->ComptaAuto()))		{
			string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
			retVal = MessageBox("Il n'existe pas de fiche comptable pour ce document. Voulez-vous lancer la comptabilit� ?", sCaption.c_str(), MB_YESNO) ;
			if (retVal == IDYES)
				Compta() ;
		}
	}
	else
		pDoc->SetDirty(true) ;
}

//---------------------------------------------------------------------------//  Function: NSCRReadOnlyView::InitialiseLignes()
//
//  Arguments: Aucuns
//
//  Description:
//            Initialise le style du document � partir du fichier N.MOD
//  Returns:
//            TRUE/FALSE
//---------------------------------------------------------------------------
bool
NSCRReadOnlyView::InitialiseLignes()
{
try
{
	NSLigne*					pLigne ;
	string 			  		Chaine = "", ChaineLigne, sLocLes, sPhrase ;
	NSStyleParagraphe	StylePara ;
	TFont*						pPolice ;
	unsigned					NumeroPara, NumeroPolice, NumeroPage ;
	size_t						Curseur, NouBlanc, PreBlanc ;
	NS_CLASSLIB::TPoint PointRef, PointTransfert ;
	ifstream 					inFile ;
	long							TraiteLigne = 0 ;
  long              LargeurPossible = 0 ;
  long              LargeurGauche = 0 ;
	NS_CLASSLIB::TSize	TailleChaine ;
	LONG 							lPolicetmHeight ;
	NSFont		 		 		PoliceVoulue ;
	NSCRPhrase*		  	pPhrase ;
	unsigned					iNumPhrase = 0 ;
	//NSCRPhraLes*		pPhraLes;
	TEXTMETRIC				TextMetric ;
	NSPage						stylePage, *pStylePage ;
	bool							bGerePages = false ;
	string						line ;

	NSCRPhraLesArray	aLesBuf ;   // Localisation(s)
	NSCRPhraLesArray	aLesPath ;  // Chemin(s)
	//
	// Mise � z�ro des phrases et des lignes
	//
	NSCRDocument* CRDoc = dynamic_cast<NSCRDocument*>(pDoc);

	CRDoc->aCRPhrases.vider() ;
	Lignes.vider() ;
	//
	// Tentative d'ouverture du fichier qui contient le compte rendu
	//
	inFile.open((CRDoc->sFichDecod).c_str()) ;
	if (!inFile)
		return false ;
	//
	// Chargement du fichier dans une string
	//
	while (!inFile.eof())
	{
  	getline(inFile,line) ;
    if (line != "")
    	Chaine += line + "\n" ;
	}
	//
	inFile.close() ;
	//
	// On r�cup�re un "contexte d'information" concernant l'�cran
	//
	TIC* pDC = new TIC("DISPLAY", NULL, NULL) ;
	pDC->SetMapMode(MM_LOMETRIC) ;
	//
	// On initialise le style du paragraphe n�1 et la police qui correspond
	//
	NumeroPara 	= 1 ;
	StylePara 	= *(StylesParagraphe[NumeroPara-1]) ;
	NumeroPolice = StylePara.NumPolice ;
	PoliceVoulue = *(StylesPolImp[NumeroPolice-1]) ;
	//
	// La taille de la police est stock�e en unit� physiques d'�cran,
	// il faut donc la transformer en unit�s logiques
	//
	if (PoliceVoulue.logFont.lfHeight >= 0)
	{
		PointTransfert.x = PoliceVoulue.logFont.lfHeight ;
		PointTransfert.y = PoliceVoulue.logFont.lfWidth ;
		pDC->DPtoLP(&PointTransfert) ;
		PoliceVoulue.logFont.lfHeight = PointTransfert.x ;
		PoliceVoulue.logFont.lfWidth  = PointTransfert.y ;
	}
	//
	// Si la hauteur est <0, elle est en points.
	//
	//
	// On s�lectionne la police dans le DC
	//
	pPolice	= new TFont(&(PoliceVoulue.logFont)) ;
	pDC->SelectObject(*pPolice) ;
	//if ((LargeurPolice == 0) || (NumeroPara == 4))
   	//{
	if (pDC->GetTextMetrics(TextMetric))
	{
  	LargeurPolice = TextMetric.tmAveCharWidth ;
    lPolicetmHeight = TextMetric.tmHeight + TextMetric.tmDescent ;
	}
   	//}
	//
	// On initialise le rectangle de texte dans la page
	//
	NumeroPage = 1 ;
	pStylePage = donnePage(NumeroPage) ;
	if (pStylePage == 0)
  	pStylePage = donnePage(0) ;

	if (pStylePage != 0)
  	stylePage = *pStylePage ;
	else
  	stylePage.loadDefault() ;

	NS_CLASSLIB::TRect RectanglePage, RectangleTexte ;
	RectanglePage.Set(RectangleGlobal.Left(),
    				        RectangleGlobal.Top(),
                    RectangleGlobal.Right()-stylePage.MargeGauche-stylePage.MargeDroite,
                    RectangleGlobal.Bottom()+stylePage.MargeHaute+stylePage.MargeBasse) ;

	RectangleTexte.Set(RectanglePage.Left() + stylePage.MargeTxtGch,
                      RectanglePage.Top() - stylePage.MargeTxtHaut,
                      RectanglePage.Right() - stylePage.MargeTxtDte,
                      RectanglePage.Bottom() + stylePage.MargeTxtBas) ;
	//
	// On initialise le point de r�f�rence en haut et � gauche
	//
	PointRef.x = RectangleTexte.Left() ;
	PointRef.y = RectangleTexte.Top() ;

	sPhrase = "" ;
	// on appelle metDecor au d�but pour tenter d'avoir un tableau Lignes
	// avec les lignes d'en-tete AVANT les lignes de texte.
	metDecor(&RectanglePage, pDC, NumeroPage, 1) ;

	//
	// Lecture de la chaine
	//
	size_t ik = 0 ;
	while (ik < strlen(Chaine.c_str()))
	{
		//
    // On avance jusqu'au prochain tag de d�but (chr(27))
    //
    VaA27(&Chaine, &ik, &aLesBuf, &aLesPath) ;

    if (ik >= strlen(Chaine.c_str()))
    	break ;
    ik++ ;
    //
    // On pr�pare le style de paragraphe, en cas de texte ordinaire,
    // on prend d'autorit� le paragraphe 6
    //
    if (Chaine[ik] == 'T')
    	NumeroPara = 6 ;
    else
    	NumeroPara = donneDigit(Chaine[ik]) ;
    ik++ ;

		//
		// Gestion particuli�re pour les tableaux
  	//
    // L'ensemble du tableau est situ� entre un (27)'9' et un (28)'9'
    //
    if (9 == NumeroPara)
    {
    	pPhrase = new NSCRPhrase ;
      if (!(aLesBuf.empty()))
      {
      	pPhrase->aLesions = aLesBuf ;
        aLesBuf.vider() ;
      }
      if (!(aLesPath.empty()))
      {
      	pPhrase->aChemins = aLesPath ;
        aLesPath.vider() ;
      }
      iNumPhrase++ ;
      pPhrase->iNumero = iNumPhrase ;

      string sChaineTableau = "" ;
      bool   tourner  = true ;
      size_t ikLastTr = 0 ;
      size_t ikLastTd = 0 ;
      while (tourner && (ik < strlen(Chaine.c_str())))
      {
      	if (char(28) == Chaine[ik])
        {
        	ik++ ;
          if ('9' == Chaine[ik])
          	tourner = false ;
          else
          {
          	if      ('8' == Chaine[ik])
            	ikLastTr = ik ;
            else if ('7' == Chaine[ik])
            	ikLastTd = ik ;
          	sChaineTableau += char(28) ;
            sChaineTableau += Chaine[ik] ;
          }
        }
        else
        	sChaineTableau += Chaine[ik] ;
        ik++ ;
      }
      // Let's suppose an end of table was not found, close after the last tr
      //
      if (ik >= strlen(Chaine.c_str()))
      {
      	if (ikLastTr > 0)
        {
        	ik = ikLastTr ;
          string sToFind = string(1, char(28)) + string(1, '8') ;
          size_t iLastTr = sChaineTableau.find_last_of(sToFind) ;
          if (iLastTr != string::npos)
          	sChaineTableau[iLastTr + 2] = '\0' ;
        }
        else if (ikLastTd > 0)
        {
        	ik = ikLastTd ;
          string sToFind = string(1, char(28)) + string(1, '7') ;
          size_t iLastTd = sChaineTableau.find_last_of(sToFind) ;
          if (iLastTd != string::npos)
          	sChaineTableau[iLastTd + 2] = '\0' ;
          string sToAdd = string(1, char(28)) + string(1, '8') ;
          sChaineTableau += sToAdd ;
        }
      }
      //
      // On prend d'autorit� le paragraphe 7
      //
      StylePara  	 = *(StylesParagraphe[6]) ;
      NumeroPolice = StylePara.NumPolice ;
      delete pPolice ;
      pPolice = 0 ;
      PoliceVoulue = *(StylesPolice[NumeroPolice-1]) ;
      if (PoliceVoulue.logFont.lfHeight >= 0)
      {
      	PointTransfert.x = PoliceVoulue.logFont.lfHeight ;
        PointTransfert.y = PoliceVoulue.logFont.lfWidth ;
        pDC->DPtoLP(&PointTransfert) ;
        PoliceVoulue.logFont.lfHeight = PointTransfert.x ;
        PoliceVoulue.logFont.lfWidth  = PointTransfert.y ;
      }
      pPolice = new TFont(&(PoliceVoulue.logFont)) ;
      pDC->SelectObject(*pPolice) ;
      if (pDC->GetTextMetrics(TextMetric))
      {
      	LargeurPolice 	= TextMetric.tmAveCharWidth ;
        lPolicetmHeight = TextMetric.tmHeight + TextMetric.tmDescent ;
      }
      string tableau[50][50] ;
      size_t ikl        = 0 ;
      int    iLigne     = 0 ;
      int    iColonne   = 0 ;
      int    iNbColonne = 0 ;
      string sBuff      = string("") ;

      for (ikl = 0; ikl < strlen(sChaineTableau.c_str()); ikl++)
      {
      	if      (char(27) == sChaineTableau[ikl])
        	ikl++ ;
        else if (char(28) == sChaineTableau[ikl])
        {
        	ikl++ ;
          //
          // Fin colonne
          //
          if 		('7' == sChaineTableau[ikl])
          {
          	tableau[iLigne][iColonne] = sBuff ;
            sBuff = "" ;
            iColonne++ ;
          }
          //
          // Fin ligne
          //
          else if ('8' == sChaineTableau[ikl])
          {
          	if (iColonne > iNbColonne)
            	iNbColonne = iColonne ;
            iLigne++ ;
            iColonne = 0 ;
          }
        }
        else
        	sBuff += sChaineTableau[ikl] ;
      }
      //
      // On cherche la largeur de chaque colonne
      //
      LargeurPossible = LargeurGauche -
                            (RectangleTexte.Left() + StylePara.RetraitGauche) ;
      int LargeurColonne = LargeurPossible / iNbColonne ;
      //
      // On tabule avec des ' ' => connaitre la largeur d'un ' '
      //
      NS_CLASSLIB::TSize sizeBlanc = pDC->GetTextExtent(" ", 1) ;
      int Tailleblanc = sizeBlanc.cx ;

      string sGrandePhrase = "" ;
      int iTailleTexte ;
      for (int iLignTab = 0; iLignTab < iLigne; iLignTab++)
      {
      	sPhrase = "" ;
        for (int jTab = 0; jTab < iNbColonne; jTab++)        {
        	int nbrBlancsAvant = 0 ;
          int nbrBlancsApres = 0 ;
          string sTxtCol = tableau[iLignTab][jTab] ;
          TailleChaine = pDC->GetTextExtent(sTxtCol.c_str(), strlen(sTxtCol.c_str())) ;
          iTailleTexte = TailleChaine.cx ;
          if (iTailleTexte < LargeurColonne)
          {
          	int nbBlanc = (LargeurColonne - iTailleTexte) / Tailleblanc ;
            if (nbBlanc > 1)
            	nbrBlancsAvant = nbBlanc / 2 ;
            nbrBlancsApres = nbBlanc - nbrBlancsAvant ;
          }

          sPhrase += string(nbrBlancsAvant, ' ') +
                               sTxtCol +
                               string(nbrBlancsApres, ' ');

          sGrandePhrase += sPhrase ;
        }
        //
        // Cr�ation d'une ligne vierge
        //
        pLigne = new NSLigne() ;
        //
        // Initialisation de tous les param�tres d�j� connus
        //
        pLigne->iNumPhrase = iNumPhrase ;
        pLigne->numPage = NumeroPage ;
        if (TraiteLigne == 1)
        	pLigne->Boite.left = RectangleTexte.Left() + StylePara.RetraitPremLigne ;
        else
        	pLigne->Boite.left = RectangleTexte.Left() + StylePara.RetraitGauche ;
        pLigne->Boite.right  = LargeurGauche ;
        pLigne->Boite.top    = PointRef.y ;
        pLigne->Boite.bottom = PointRef.y ;
        // pLigne->CouleurTexte  = *(StylePara.pCouleurTexte);
        pLigne->numParagraphe = 7 ;
        pLigne->numLigne      = TraiteLigne ;
        pLigne->Texte         = sPhrase ;
        LONG lHauteur         = lPolicetmHeight ;
        if (lHauteur < StylePara.HauteurLigne)
        	lHauteur = StylePara.HauteurLigne ;
        pLigne->Boite.bottom -= lHauteur ;
        PointRef.Offset(0, -lHauteur) ;
        //
        //
        //
        if (iLignTab < iLigne-1)
        {
        	TraiteLigne++ ;
          pLigne->DerniereLigne = FALSE ;
        }
        else
        {
        	TraiteLigne = 0 ;
          pLigne->DerniereLigne = TRUE ;
        }
        Lignes.push_back(new NSLigne(*pLigne)) ;
        delete pLigne ;
        pLigne = 0 ;
      }
      //
      // Cr�ation du tableau comme d'une seule "phrase"
      //
      pPhrase->sTexte = sGrandePhrase ;
      CRDoc->aCRPhrases.push_back(new NSCRPhrase(*pPhrase)) ;
      delete pPhrase ;
      pPhrase = 0 ;
      sPhrase = "" ;
    }
    //
    // Gestion pour les lignes ordinaires
    //
    else
    {
      StylePara  	 = *(StylesParagraphe[NumeroPara-1]);
      NumeroPolice = StylePara.NumPolice;
      delete pPolice;
      pPolice = 0;
      PoliceVoulue = *(StylesPolice[NumeroPolice-1]);
      if (PoliceVoulue.logFont.lfHeight >= 0)
      {
        PointTransfert.x = PoliceVoulue.logFont.lfHeight;
        PointTransfert.y = PoliceVoulue.logFont.lfWidth;
        pDC->DPtoLP(&PointTransfert);
        PoliceVoulue.logFont.lfHeight = PointTransfert.x;
        PoliceVoulue.logFont.lfWidth  = PointTransfert.y;
      }
      pPolice = new TFont(&(PoliceVoulue.logFont));
      pDC->SelectObject(*pPolice);
      //if ((LargeurPolice == 0) || (NumeroPara == 4))
      //{
      if (pDC->GetTextMetrics(TextMetric))
      {
        LargeurPolice 	= TextMetric.tmAveCharWidth;
        lPolicetmHeight = TextMetric.tmHeight + TextMetric.tmDescent;
      }
      //}
      //
      // On traite la phrase (ou les phrases) jusqu'au tag de fin (chr(28))
      //
      //
      while ((ik < strlen(Chaine.c_str())) && (Chaine[ik] != char(28)))
      {
      	//
        // CR LF -> changement de paragraphe
        //
				if ((Chaine[ik] == char(13)) || (Chaine[ik] == char(10)))
        {
        	ik++ ;
          if ((Chaine[ik] == char(13)) || (Chaine[ik] == char(10)))
          	ik++ ;
          //
          // On cr�e un nouveau NSCRPhrase
          //
          pPhrase = new NSCRPhrase ;
					//
          // On lui transmet l'�ventuel aLesBuf
          //
          if (!(aLesBuf.empty()))
          {
          	pPhrase->aLesions = aLesBuf ;
            aLesBuf.vider() ;
          }
          if (!(aLesPath.empty()))
          {
          	pPhrase->aChemins = aLesPath ;
            aLesPath.vider() ;
          }
          pPhrase->sTexte = sPhrase ;
					iNumPhrase++ ;
					pPhrase->iNumero = iNumPhrase ;
          CRDoc->aCRPhrases.push_back(new NSCRPhrase(*pPhrase)) ;
					delete pPhrase ;
          pPhrase = 0 ;
					//
					// On pr�voit l'espace au dessus du paragraphe
					//
					PointRef.Offset(0, -int(StylePara.EspaceDessus));
					//
					// Calcul de la largeur utilisable sans le retrait gauche
					//
					LargeurGauche = RectangleTexte.Width() - StylePara.RetraitDroit;
					//
					// On traite le paragraphe, ligne par ligne
					//
					Curseur = 0; PreBlanc = 0;
					TraiteLigne = 1;
					while (TraiteLigne > 0)
					{
          	//
						// Cr�ation d'une ligne vierge
						//
						pLigne = new NSLigne();
						//
						// Initialisation de tous les param�tres d�j� connus
						//
						pLigne->iNumPhrase = iNumPhrase;
						pLigne->numPage = NumeroPage;
						if (TraiteLigne == 1)
							pLigne->Boite.left = RectangleTexte.Left()+StylePara.RetraitPremLigne;
						else
							pLigne->Boite.left = RectangleTexte.Left()+StylePara.RetraitGauche;
						pLigne->Boite.right   = LargeurGauche;
						pLigne->Boite.top	  	 = PointRef.y;
						pLigne->Boite.bottom  = PointRef.y;
						// pLigne->CouleurTexte  = *(StylePara.pCouleurTexte);
						pLigne->numParagraphe = NumeroPara;
						pLigne->numLigne		 = TraiteLigne;
						//
						// Traitement des chaines de taille non nulle
						//
						if (strlen(sPhrase.c_str()) > 0)
						{
							//
							// D�termination de la largeur utilisable
							//
							LargeurPossible = UINT(pLigne->Boite.Width());
							//
							// Recherche du segment de cha�ne qui "tient" dans cette largeur
							//
							NouBlanc = Curseur;
							do
							{
								PreBlanc = NouBlanc;
								NouBlanc = sPhrase.find(' ', PreBlanc+1);
								if (NouBlanc == NPOS)
									break;

								TailleChaine = pDC->GetTextExtent(string(sPhrase, Curseur, NouBlanc-Curseur).c_str(),
															 int(NouBlanc-Curseur));
							}
							while (TailleChaine.cx < LargeurPossible);
							//
							// Si on est en fin de cha�ne, on regarde
                            // si le dernier mot "tient"
							//
							if (NouBlanc == NPOS)
							{
								TailleChaine = pDC->GetTextExtent(string(sPhrase, Curseur, strlen(sPhrase.c_str())-Curseur).c_str(),
															 int(strlen(sPhrase.c_str())-Curseur));
								if (TailleChaine.cx < LargeurPossible)
									PreBlanc = strlen(sPhrase.c_str());
							}
							//
							// On met le segment de chaine "qui tient" dans la chaine Texte
							// de la ligne en cours
							//
							pLigne->Texte = string(sPhrase, Curseur, PreBlanc-Curseur);
							//
							// On calcule la vraie taille de cette chaine
							//
                        	strip(pLigne->Texte);

							TailleChaine = pDC->GetTextExtent(pLigne->Texte.c_str(),
														 int(strlen(pLigne->Texte.c_str())));

							//
							// On initialise Boite : rectangle exinscrit � la ligne
							//

              LONG lHauteur = lPolicetmHeight ;
              if (lHauteur < StylePara.HauteurLigne)
								lHauteur = StylePara.HauteurLigne ;
							pLigne->Boite.bottom -= lHauteur ;
							PointRef.Offset(0, -lHauteur) ;
							//
							//
							//
							if (PreBlanc < strlen(sPhrase.c_str()))
							{
								Curseur = PreBlanc + 1 ;
								TraiteLigne++ ;
								pLigne->DerniereLigne = FALSE ;
							}
							else
							{
								TraiteLigne = 0 ;
								pLigne->DerniereLigne = TRUE ;
							}
						}
						//
						// Traitement des chaines vides
						//
						else
						{
							pLigne->Texte = "" ;
							//
							// On initialise Boite : rectangle exinscrit � la ligne
							//
							TailleChaine = pDC->GetTextExtent(" ", 1) ;
							if (TailleChaine.cy < StylePara.HauteurLigne)
								TailleChaine.cy = StylePara.HauteurLigne ;
							pLigne->Boite.bottom -= TailleChaine.cy ;
							PointRef.Offset(0, -TailleChaine.cy) ;
							//
							// On pr�cise que le traitement est termin�
							//
							TraiteLigne = 0 ;
							pLigne->DerniereLigne = TRUE ;
						}
            //
            // Si la ligne d�borde de la page, elle passe en page suivante
            //
            if ((abs(PointRef.y) > abs(RectangleTexte.Height())) && bGerePages)
            {
            	metDecor(&RectanglePage, pDC, NumeroPage, 1) ;
              NumeroPage++ ;

              pStylePage = donnePage(NumeroPage) ;
              if (pStylePage == 0)
              	pStylePage = donnePage(0) ;

              if (pStylePage != 0)
              	stylePage = *pStylePage ;
              else
              	stylePage.loadDefault() ;

              NS_CLASSLIB::TRect RectanglePage, RectangleTexte ;
              RectanglePage.Set(RectangleGlobal.Left(),
                                RectangleGlobal.Top(),
                     						RectangleGlobal.Right()-stylePage.MargeGauche-stylePage.MargeDroite,
                     						RectangleGlobal.Bottom()+stylePage.MargeHaute+stylePage.MargeBasse) ;

              RectangleTexte.Set(RectanglePage.Left() + stylePage.MargeTxtGch,
                                 RectanglePage.Top() - stylePage.MargeTxtHaut,
                                 RectanglePage.Right() - stylePage.MargeTxtDte,
                                 RectanglePage.Bottom() + stylePage.MargeTxtBas) ;

              //
							// On initialise le point de r�f�rence en haut et � gauche
              //
							PointRef.x = RectangleTexte.Left() ;
              PointRef.y = RectangleTexte.Top() ;
              pLigne->numPage = NumeroPage ;
              pLigne->Boite.top	= PointRef.y ;
              pLigne->Boite.bottom = PointRef.y - TailleChaine.cy ;
							PointRef.Offset(0, -TailleChaine.cy) ;
            }
						//
						// On ajoute la ligne � Lignes
						//
            Lignes.push_back(new NSLigne(*pLigne)) ;
						delete pLigne ;
            pLigne = 0 ;
					}
					//
					// On pr�voit l'espace au dessous du paragraphe
					//
					PointRef.Offset(0, -int(StylePara.EspaceDessous)) ;
					sPhrase = "" ;        }
        else
        {
        	sPhrase += Chaine[ik] ;
          ik++ ;
        }
      }
    }
    if (Chaine[ik] == char(28))
    {
    	ik++ ;
      if (ik < strlen(Chaine.c_str()))
      	ik++ ;
    }
	}

	// on mettait avant le titre � la fin du tableau Lignes
	// et �a fout la zone pour la s�lection de texte
	// metDecor(&RectanglePage, pDC, NumeroPage, 1);

	delete pDC ;
	delete pPolice ;
	inFile.close() ;
	return true ;
}
catch (...)
{
	erreur("Exception NSCRReadOnlyView::InitialiseLignes", standardError, 0) ;
	return false ;
}
}

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void
NSCRReadOnlyView::VaA27(string *pChaine, size_t *pik, NSCRPhraLesArray *pLesBuf, NSCRPhraLesArray *pLesPath)
{
try
{
	string sLocLes = "" ;
	//
  // On avance jusqu'au prochain tag de d�but (chr(27))
  //
	while ((*pik < strlen(pChaine->c_str())) && ((*pChaine)[*pik] != char(27)))
	{
  	//
    // Si on rencontre un indicateur de patpatho, on le traite
    //
    // Si le paragraphe commence par un indicateur de l�sions
    //
    if ((*pChaine)[*pik] == '|')
    {
    	pLesBuf->vider() ;
      sLocLes = "" ;
      (*pik)++ ;
      while ((*pik < strlen(pChaine->c_str())) && ((*pChaine)[*pik] != '|'))
      {
      	// Prise des localisations
        //
        while ((*pik < strlen(pChaine->c_str())) && ((*pChaine)[*pik] != '|') && ((*pChaine)[*pik] != '['))
        {
        	while ((*pik < strlen(pChaine->c_str())) && ((*pChaine)[*pik] != '|') && ((*pChaine)[*pik] != '[') && ((*pChaine)[*pik] != '/'))
          {
          	sLocLes += (*pChaine)[*pik] ;
            (*pik)++ ;
          }
          if (sLocLes != "")
          {
          	pLesBuf->push_back(new string(sLocLes)) ;
            sLocLes = "" ;
          }
          if ((*pik < strlen(pChaine->c_str())) && ((*pChaine)[*pik] == '/'))
          	(*pik)++ ;
        }
        //
        // Prise des chemins
        //
        if ((*pChaine)[*pik] == '[')
        {
        	(*pik)++ ;
          while ((*pik < strlen(pChaine->c_str())) && ((*pChaine)[*pik] != '|'))
          {
          	while ((*pik < strlen(pChaine->c_str())) && ((*pChaine)[*pik] != '|') && ((*pChaine)[*pik] != ']'))
            {
            	sLocLes += (*pChaine)[*pik] ;
              (*pik)++ ;
            }
            if (sLocLes != "")
            {
            	pLesPath->push_back(new string(sLocLes)) ;
              sLocLes = "" ;
            }
            if ((*pik < strlen(pChaine->c_str())) && ((*pChaine)[*pik] == ']'))
            	(*pik)++ ;
            if ((*pik < strlen(pChaine->c_str())) && ((*pChaine)[*pik] == '['))
            	(*pik)++ ;
          }
        }
      }
      if (*pik < strlen(pChaine->c_str()))
      	(*pik)++ ;
    }
    else
    	(*pik)++ ;
  }
}
catch (...)
{
	erreur("Exception NSCRReadOnlyView::VaA27.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------// fermeture du document :
// L'historique est averti de la fermeture par le destructeur du document
// car lorsque la derniere vue se ferme, cela tue le document.
//---------------------------------------------------------------------------
void
NSCRReadOnlyView::EvClose()
{
	TWindow::EvClose() ;
}

void
NSCRReadOnlyView::EvDestroy()
{
}

bool
NSCRReadOnlyView::EvQueryEndSession()
{
	return TWindow::EvQueryEndSession() ;
}

