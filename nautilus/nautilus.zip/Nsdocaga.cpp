//---------------------------------------------------------------------------//  NSDOCAGA.CPP
//  RS Octobre 98
//  Objet document AGA
//---------------------------------------------------------------------------

#define __NSDOCAGA_CPP

#include "nautilus\nssuper.h"
#include "nautilus\nsdocaga.h"
#include "nautilus\ns_html.h"
#include "nautilus\nsrechdl.h"      // pour doc convoc

NSConvocRefDocument::NSConvocRefDocument(NSVarConvoc* pVar, int* pTab, int n, NSContexte* pCtx)
                    :NSRefDocument(0, 0, 0, pCtx, true)
{
	pDocInfo = new NSDocumentInfo ;
	pDocInfo->setType("ZTCVC") ;

	pVarConvoc = new NSVarConvoc(*pVar) ;
	pTabSelect = new int[n] ;
	for (int i = 0; i < n; i++)
  	pTabSelect[i] = pTab[i] ;
	nbConvoc = n ;
}

NSConvocRefDocument::~NSConvocRefDocument()
{
  // pDocInfo is deleted by ~NSNoyauDocument()
	delete pVarConvoc ;
	delete[] pTabSelect ;
}

bool
NSConvocRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
        				string sAdresseCorresp, string sPathDest)
{
	string   	   sFichierHtml ;
	NSHtmlConvoc hconvoc(typeOperation, this, pContexte, sAdresseCorresp) ;
	string 		   sBaseImg ;

	// on trouve le nom du fichier temporaire � visualiser
	sNomHtml = hconvoc.nomSansDoublons(sPathHtml, sNomHtml, "htm") ;
	sFichierHtml = sPathHtml + sNomHtml ;

	// on passe aussi le path destination pour les images
	if (!hconvoc.genereHtml(sFichierHtml,sBaseImg,pHtmlInfo,sPathDest))
  	return false ;

	// Mise � jour de la base d'images
	switch (typeOperation)
	{
  	case toComposer:
    	sBaseCompo = sBaseImg ;
      break ;

    default:
    	sBaseImages = sBaseImg ;
	}

	return true ;
}

//
// NSSecuRefDocument
//

NSSecuRefDocument::NSSecuRefDocument(NSContexte* pCtx)
                  :NSRefDocument(0, 0, 0, pCtx, true)
{
	pDocInfo = new NSDocumentInfo ;
	pDocInfo->setType("ZSECU") ;

	pAssuInfo 	 = 0 ;
	pCarteMalade = 0 ;
	pCarte 		   = 0 ;

	bInitOk = InitDonneesMalade() ;
}

NSSecuRefDocument::~NSSecuRefDocument()
{
  // pDocInfo is deleted by ~NSNoyauDocument()
	if (pAssuInfo)
		delete pAssuInfo ;
	if (pCarteMalade)
		delete pCarteMalade;
	if (pCarte)
		delete pCarte;
}

boolNSSecuRefDocument::InitDonneesMalade()
{
  string sNumPat = pContexte->getPatient()->getNss();
  NSVitale2* pCarteV2 = new NSVitale2(pContexte);  pCarteMalade = new NSVitale2Info();
  bNonAssure = false;

  // on retrouve d'abord la carte vitale du patient
  pCarteV2->lastError = pCarteV2->open();
  if (pCarteV2->lastError != DBIERR_NONE)
  {
  	erreur("Erreur � l'ouverture de la base ayant-droits.", standardError, pCarteV2->lastError,pContexte->GetMainWindow()->GetHandle()) ;
    delete pCarteV2;
    return false;
	}

  pCarteV2->lastError = pCarteV2->chercheClef(&sNumPat,
											  "NUMPATIENT",
											  NODEFAULTINDEX,
											  keySEARCHEQ,
                                              dbiWRITELOCK);

	if ((pCarteV2->lastError != DBIERR_NONE) && (pCarteV2->lastError != DBIERR_RECNOTFOUND))
	{
  	erreur("Erreur � la recherche de la carte vitale.", standardError, pCarteV2->lastError, pContexte->GetMainWindow()->GetHandle()) ;
    pCarteV2->close() ;
		delete pCarteV2 ;
    return false ;
	}
  else if (pCarteV2->lastError == DBIERR_RECNOTFOUND)
  {
  	erreur("Ce patient n'est pas rattach� � une carte vitale.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    pCarteV2->close() ;
		delete pCarteV2 ;
    return false ;
	}

	pCarteV2->lastError = pCarteV2->getRecord();
  if (pCarteV2->lastError != DBIERR_NONE)
  {
  	erreur("Erreur � la modification de la fiche carte vitale.", standardError, pCarteV2->lastError,pContexte->GetMainWindow()->GetHandle()) ;
    pCarteV2->close() ;
    delete pCarteV2 ;
    return false ;
	}

	// on conserve les donn�es du malade
	*(pCarteMalade->pDonnees) = *(pCarteV2->pDonnees) ;

  // Si le malade n'est pas l'assur� :
  // on recherche l'assur� correspondant au m�me num�ro
  if (strcmp(pCarteMalade->pDonnees->qualite, "00"))
  {
    bool   trouve = false ;
    // l'index primaire comprend num s�cu + num�ro � deux chiffres
    string sNumSS = string(pCarteMalade->pDonnees->immatricul) ;
    string sClef  = sNumSS + string("  ") ;

    bNonAssure = true ;

    pCarteV2->lastError = pCarteV2->chercheClef(&sClef,
                    "",
                    0,
                    keySEARCHGEQ,
                                          dbiWRITELOCK);

    if (pCarteV2->lastError != DBIERR_NONE)
    {
    	erreur("Erreur � la recherche de la carte vitale.", standardError, pCarteV2->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      pCarteV2->close() ;
      delete pCarteV2 ;
      return false ;
    }

    do
    {
      pCarteV2->lastError = pCarteV2->getRecord() ;
      if (pCarteV2->lastError != DBIERR_NONE)
      {
      	erreur("Erreur � la lecture de la fiche carte vitale.", standardError, pCarteV2->lastError,pContexte->GetMainWindow()->GetHandle()) ;
        pCarteV2->close() ;
        delete pCarteV2 ;
        return false ;
      }

      // Si on n'est plus sur la bonne carte : on sort...
      if (!(string(pCarteV2->pDonnees->immatricul) == sNumSS))
      	break ;
      else if (string(pCarteV2->pDonnees->qualite) == "00")
      {
      	// on a trouv� l'assur�
        trouve = true ;
        break ;
      }

      pCarteV2->lastError = pCarteV2->suivant(dbiWRITELOCK) ;
      if ((pCarteV2->lastError != DBIERR_NONE) && (pCarteV2->lastError != DBIERR_EOF))
      {
      	erreur("Erreur d'acc�s � la fiche carte vitale suivante.", standardError, pCarteV2->lastError, pContexte->GetMainWindow()->GetHandle()) ;
        pCarteV2->close() ;
        delete pCarteV2 ;
        return false ;
      }
    }
    while (pCarteV2->lastError != DBIERR_EOF) ;

    if (trouve)
    {
    	// on conserve le num�ro de patient de l'assur�
      sNumPat = string(pCarteV2->pDonnees->patient) ;
    }
    else
    {
    	erreur("La carte vitale du patient ne correspond � aucun assur�.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      pCarteV2->close() ;
      delete pCarteV2 ;
      return false ;
    }
	}

	pCarteV2->lastError = pCarteV2->close() ;
	if (pCarteV2->lastError != DBIERR_NONE)
  	erreur("Erreur � la fermeture de la base carte vitale.", standardError, pCarteV2->lastError, pContexte->GetMainWindow()->GetHandle()) ;

	delete pCarteV2 ;
// A revoir pour MUE...
#ifndef _MUE
    // on recherche maintenant les donn�es de l'assur�    //
    NSPatient* pPatient = new NSPatient(pContexte);

    pPatient->lastError = pPatient->open();
    if (pPatient->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur � l'ouverture de la base des patients.",0,0,pContexte->GetMainWindow()->GetHandle());
        delete pPatient;
        return false;
    }

    pPatient->lastError = pPatient->chercheClef(&sNumPat,
											  "",
											  0,
											  keySEARCHEQ,
                                              dbiWRITELOCK);

    if ((pPatient->lastError != DBIERR_NONE) && (pPatient->lastError != DBIERR_RECNOTFOUND))
   	{
   		erreur("Erreur � la recherche dans la base des patients.", 0, pPatient->lastError, pContexte->GetMainWindow()->GetHandle());
      	pPatient->close();
		delete pPatient;
        return false;
   	}
    else if (pPatient->lastError == DBIERR_RECNOTFOUND)
    {
        erreur("Impossible de retrouver les donn�es de l'assur�.",0,0,pContexte->GetMainWindow()->GetHandle());
        pPatient->close();
		delete pPatient;
        return false;
    }

    pPatient->lastError = pPatient->getRecord();
   	if (pPatient->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � la lecture dans la base des patients.",0,pPatient->lastError,pContexte->GetMainWindow()->GetHandle());
      	pPatient->close();
      	delete pPatient;
      	return false;
   	}

    // on stocke les donn�es du malade
    //
    pAssuInfo = new NSPatInfo(pPatient);
    pAssuInfo->initAdresseInfo();

    pPatient->lastError = pPatient->close();
    if (pPatient->lastError != DBIERR_NONE)
   	    erreur("Erreur � la fermeture de la base des patients.",0,pPatient->lastError,pContexte->GetMainWindow()->GetHandle());

    delete pPatient;
#endif

    // on recherche maintenant les donn�es de la carte    //
    NSVitale1* pV1 = new NSVitale1(pContexte);

    pV1->lastError = pV1->open();
    if (pV1->lastError != DBIERR_NONE)
    {
   	    erreur("Erreur � l'ouverture de la base des cartes vitales.", standardError, pV1->lastError,pContexte->GetMainWindow()->GetHandle()) ;
        delete pV1;
        return false;
    }

    string sNumSS = string(pCarteMalade->pDonnees->immatricul);

    pV1->lastError = pV1->chercheClef(&sNumSS,
    								  "",
                                      0,
                                      keySEARCHEQ,
                                      dbiWRITELOCK);

    if ((pV1->lastError != DBIERR_NONE) && (pV1->lastError != DBIERR_RECNOTFOUND))
   	{
   		erreur("Erreur � la recherche dans la base des ca.", standardError, pV1->lastError, pContexte->GetMainWindow()->GetHandle()) ;
      	pV1->close();
		delete pV1;
        return false;
   	}
    else if (pV1->lastError == DBIERR_RECNOTFOUND)
    {
        erreur("Impossible de retrouver la carte vitale de l'assur�.", standardError, pV1->lastError, pContexte->GetMainWindow()->GetHandle()) ;
        pV1->close();
		delete pV1;
        return false;
    }

    pV1->lastError = pV1->getRecord();
   	if (pV1->lastError != DBIERR_NONE)
   	{
   		erreur("Erreur � la lecture dans la base des patients.", standardError, pV1->lastError,pContexte->GetMainWindow()->GetHandle());
      	pV1->close();
      	delete pV1;
      	return false;
   	}

    // on stocke les donn�es du malade
    pCarte = new NSVitale1Info(pV1);

    pV1->lastError = pV1->close();
    if (pV1->lastError != DBIERR_NONE)
   	    erreur("Erreur � la fermeture de la base des cartes vitales.", standardError, pV1->lastError,pContexte->GetMainWindow()->GetHandle());

    delete pV1;

    return true;
}

boolNSSecuRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	string   	  sFichierHtml;
	NSHtmlSecu    hsecu(typeOperation, this, pContexte);
    string 		  sBaseImg;
   	NSBaseImages* pBase;

   	// on trouve le nom du fichier temporaire � visualiser
   	sNomHtml = hsecu.nomSansDoublons(sPathHtml,sNomHtml,"htm");
   	sFichierHtml = sPathHtml + sNomHtml;

   	// on passe aussi le path destination pour les images
   	if (!hsecu.genereHtml(sFichierHtml,sBaseImg,pHtmlInfo,sPathDest))
   		return false;

	// Mise � jour de la base d'images
   	switch (typeOperation)
   	{
   		case toComposer:
   			sBaseCompo = sBaseImg;
         	break;

   		default:
   			sBaseImages = sBaseImg;
   	}

	return true;
}

//// NSHistoRefDocument
//
NSHistoRefDocument::NSHistoRefDocument(NSHISTODocument* pDocHis, string sImp)
			:NSRefDocument(pDocHis->GetParentDoc(), 0, 0, pDocHis->pContexte, true)
{
	pDocInfo = new NSDocumentInfo ;
	pDocInfo->setType("ZHIST") ;

	sImportance = sImp ;

	if (pDocHis->pHtmlCS)
		pHtmlCS = new NSHtml(*(pDocHis->pHtmlCS)) ;
	else
		pHtmlCS = 0 ;
}

NSHistoRefDocument::~NSHistoRefDocument(){
  // pDocInfo is deleted by ~NSNoyauDocument()
	if (pHtmlCS)
    delete pHtmlCS ;
}

//---------------------------------------------------------------------------//  Function: NSHistoRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, string sAdresseCorresp)//
//  Arguments:
//				  sPathHtml : 	r�pertoire destination
//				  sNomHtml :    En entr�e -> nom du fichier � g�n�rer
//								En sortie -> nom sans doublons
//				  sAdresseCorresp : nom + adresse du correspondant
//  Description:
//				  G�n�re un fichier html HISTO dans le r�pertoire sPathName
//				  Utilise les donn�es sTemplate et sBaseImages
//  Returns:
//            true : OK, false : sinon
//---------------------------------------------------------------------------
bool
NSHistoRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	string   	    sFichierHtml ;
	NSHtmlHisto   hhisto(typeOperation, this, pContexte, sAdresseCorresp) ;
	string 		    sBaseImg ;
	NSBaseImages* pBase ;

	// on trouve le nom du fichier temporaire � visualiser
	sNomHtml = hhisto.nomSansDoublons(sPathHtml,sNomHtml,"htm") ;
	sFichierHtml = sPathHtml + sNomHtml ;

	// on passe aussi le path destination pour les images
	if (!hhisto.genereHtml(sFichierHtml,sBaseImg,pHtmlInfo,sPathDest))
		return false ;

	// Mise � jour de la base d'images
	switch (typeOperation)
	{
  	case toComposer:
    	sBaseCompo = sBaseImg ;
      break ;

		default:
    	sBaseImages = sBaseImg ;
	}

	return true ;
}

NSAgaRefDocument::NSAgaRefDocument(NSAgaDocument *pAgaDoc)                 :NSRefDocument(pAgaDoc->GetParentDoc(), 0, 0, pAgaDoc->pContexte, true)
{
	// on met en place une pDocInfo pour la publication
	pDocInfo = new NSDocumentInfo ;
	pDocInfo->setType("ZCAGA") ;

	// Initialisation des donnees
	pCriteres = new NSCriteres(*(pAgaDoc->pCriteres)) ;
	pAgaArray = new NSAgaArray(*(pAgaDoc->pAgaArray)) ;
	nbAga 	  = pAgaDoc->nbAga ;
	pVar 	  	= new NSVarCompta(pContexte) ;

	pTotaux	 	= new NSEncaissData(*(pAgaDoc->pTotaux)) ;
	pPartiels = new NSEncaissData(*(pAgaDoc->pPartiels)) ;
	bAgaCumules = pAgaDoc->bAgaCumules ;
}NSAgaRefDocument::~NSAgaRefDocument()
{
  // pDocInfo is deleted by ~NSNoyauDocument()
	delete pPartiels ;
  delete pTotaux ;
	delete pVar ;
  delete pAgaArray ;
  delete pCriteres ;
}

// G�n�ration du html correspondant au document////////////////////////////////////////////////////////////////
bool
NSAgaRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	string    sFichierHtml ;
	NSHtmlAga haga(typeOperation, this, pContexte, sAdresseCorresp) ;
  string    sBaseImg ;

  // on trouve le nom du fichier temporaire � visualiser
  sNomHtml = haga.nomSansDoublons(sPathHtml,sNomHtml,"htm") ;
  sFichierHtml = sPathHtml + sNomHtml ;

	haga.initTotaux() ;
	haga.ajouteLignes() ;

	// on passe une base d'images � cause de la r�f�rence
	// pHtml == 0 et sPathDest == ""
	if (!haga.genereHtml(sFichierHtml,sBaseImg))
		return false ;

	return true ;
}
NSReqRefDocument::NSReqRefDocument(NSResultReqDialog *pDlg)                 :NSRefDocument(0, pDlg->pContexte)
{
	// on met en place une pDocInfo pour la publication
	pDocInfo = new NSDocumentInfo ;
	pDocInfo->setType("ZRMUL") ;

	// Initialisation des donnees
	bReqModeDoc     = pDlg->bReqModeDoc ;
	nbPatTotal      = pDlg->nbPatTotal ;
  nbPatCritPat    = pDlg->nbPatCritPat ;
  nbPatCritDoc    = pDlg->nbPatCritDoc ;
  nbPatResult     = pDlg->nbPatResult ;
  nbDocCritPat    = pDlg->nbDocCritPat ;
  nbDocCritDoc    = pDlg->nbDocCritDoc ;
  nbDocResult     = pDlg->nbDocResult ;
  VectDocResultat = pDlg->VectDocResultat ;
  VectPatResultat = pDlg->VectPatResultat ;
}NSReqRefDocument::~NSReqRefDocument()
{
  // pDocInfo is deleted by ~NSNoyauDocument()
}

// G�n�ration du html correspondant au document////////////////////////////////////////////////////////////////
bool
NSReqRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{

	string    sFichierHtml ;	NSHtmlReq hreq(typeOperation, this, pContexte, sAdresseCorresp) ;
	string    sBaseImg ;

	// on trouve le nom du fichier temporaire � visualiser	sNomHtml = hreq.nomSansDoublons(sPathHtml, sNomHtml, "htm") ;

	sFichierHtml = sPathHtml + sNomHtml ;
	hreq.initTotaux() ;	hreq.ajouteLignes() ;

	// on passe une base d'images � cause de la r�f�rence	// pHtml == 0 et sPathDest == ""

	if (!hreq.genereHtml(sFichierHtml, sBaseImg))  	return false ;

	return true ;}

NSDepRefDocument::NSDepRefDocument(NSDepensDocument *pDepDoc)
                 :NSRefDocument(pDepDoc->GetParentDoc(), 0, 0, pDepDoc->pContexte, true)
{
	// on met en place une pDocInfo pour la publication
	pDocInfo = new NSDocumentInfo ;
	pDocInfo->setType("ZCDEP") ;

	// Initialisation des donnees	pCriteres    = new NSCriteres(*(pDepDoc->pCriteres)) ;
	pDepensArray = new NSAffDepensArray(*(pDepDoc->pDepensArray)) ;
  nbDepens 	   = pDepDoc->nbDepens ;
	pVar 	       = new NSVarCompta(pContexte) ;
  pTotaux	     = new NSEncaissData(*(pDepDoc->pTotaux)) ;
}

NSDepRefDocument::~NSDepRefDocument(){
	delete pTotaux ;
	delete pVar ;
  delete pDepensArray ;
  delete pCriteres ;
}

// G�n�ration du html correspondant au document////////////////////////////////////////////////////////////////

boolNSDepRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	string    sFichierHtml ;
	NSHtmlDep hdep(typeOperation, this, pContexte, sAdresseCorresp) ;
	string    sBaseImg ;

	// on trouve le nom du fichier temporaire � visualiser	sNomHtml = hdep.nomSansDoublons(sPathHtml,sNomHtml,"htm") ;
	sFichierHtml = sPathHtml + sNomHtml ;

	hdep.initTotaux() ;	hdep.ajouteLignes() ;

	// on passe une base d'images � cause de la r�f�rence	// pHtml == 0 et sPathDest == ""
	if (!hdep.genereHtml(sFichierHtml,sBaseImg))
		return false ;

	return true ;}

//// D�finition de NSImpRefDocument
//
NSImpRefDocument::NSImpRefDocument(NSImpDocument *pImpDoc)
                 :NSRefDocument(pImpDoc->GetParentDoc(), 0, 0, pImpDoc->pContexte, true)
{
	// on met en place une pDocInfo pour la publication
	pDocInfo 	= new NSDocumentInfo ;
	pDocInfo->setType("ZCIMP") ;

	// Initialisation des donnees
  if (NULL != pImpDoc)
  {
	  pCriteres	= new NSMultiCriteres(*(pImpDoc->pCriteres)) ;
	  pImpArray = new NSImpArray(*(pImpDoc->pImpArray)) ;
	  nbImp 	  = pImpDoc->nbImp ;
  }
	pVar 	  	= new NSVarCompta(pContexte) ;
	bEuro	  	= pImpDoc->bEuro ;
}

NSImpRefDocument::~NSImpRefDocument(){
  // pDocInfo is deleted by ~NSNoyauDocument()
	delete pVar ;
	delete pImpArray ;
	delete pCriteres ;
}

// G�n�ration du html correspondant au document////////////////////////////////////////////////////////////////
bool
NSImpRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	string    sFichierHtml ;
	NSHtmlImp himp(typeOperation, this, pContexte, sAdresseCorresp) ;
	string    sBaseImg ;

	// on trouve le nom du fichier temporaire � visualiser
	sNomHtml = himp.nomSansDoublons(sPathHtml,sNomHtml,"htm") ;
	sFichierHtml = sPathHtml + sNomHtml ;

	himp.ajouteLignes() ;

	// on passe une base d'images � cause de la r�f�rence
	if (!himp.genereHtml(sFichierHtml,sBaseImg))
  	return false ;

	return true ;
}

//// D�finition de NSListActRefDocument
//
NSListActRefDocument::NSListActRefDocument(NSActDocument *pActDoc)
                     :NSRefDocument(pActDoc->GetParentDoc(), 0, 0, pActDoc->pContexte, true)
{
	// on met en place une pDocInfo pour la publication
	pDocInfo 	= new NSDocumentInfo ;
	pDocInfo->setType("ZCLAC") ;

	// Initialisation des donnees
	pCriteres = new NSMultiCriteres(*(pActDoc->pCriteres)) ;
	pActArray = new NSListActArray(*(pActDoc->pActArray)) ;
	nbAct 	  = pActDoc->nbAct ;
	pVar 	  	= new NSVarCompta(pContexte) ;
}

NSListActRefDocument::~NSListActRefDocument(){
  // pDocInfo is deleted by ~NSNoyauDocument()
	delete pVar ;
  delete pActArray ;
  delete pCriteres ;
}

// G�n�ration du html correspondant au document
////////////////////////////////////////////////////////////////
bool
NSListActRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	string    sFichierHtml ;
	NSHtmlLac hlac(typeOperation, this, pContexte, sAdresseCorresp) ;
	string    sBaseImg ;

	// on trouve le nom du fichier temporaire � visualiser
	sNomHtml = hlac.nomSansDoublons(sPathHtml, sNomHtml, "htm") ;
	sFichierHtml = sPathHtml + sNomHtml ;

	hlac.ajouteLignes() ;

	// on passe une base d'images � cause de la r�f�rence
	if (!hlac.genereHtml(sFichierHtml, sBaseImg))
		return false ;

	return true ;
}

//// D�finition de NSSomActRefDocument
//
NSSomActRefDocument::NSSomActRefDocument(NSActDocument *pActDoc)
                    :NSRefDocument(pActDoc->GetParentDoc(), 0, 0, pActDoc->pContexte, true)
{
	// on met en place une pDocInfo pour la publication
	pDocInfo 		= new NSDocumentInfo ;
	pDocInfo->setType("ZCSAC") ;

	// Initialisation des donnees
	pCriteres  	= new NSMultiCriteres(*(pActDoc->pCriteres)) ;
	pExamArray 	= new NSExamArray(*(pActDoc->pExamArray)) ;
	nbExam 	   	= pActDoc->nbExam ;
	totaux	   	= pActDoc->totaux ;
	pVar 	   		= new NSVarCompta(pContexte) ;
}

NSSomActRefDocument::~NSSomActRefDocument(){
  // pDocInfo is deleted by ~NSNoyauDocument()
	delete pVar ;
	delete pExamArray ;
	delete pCriteres ;
}

// G�n�ration du html correspondant au document
////////////////////////////////////////////////////////////////
bool
NSSomActRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	string    sFichierHtml ;
	NSHtmlSac hsac(typeOperation, this, pContexte, sAdresseCorresp) ;
	string    sBaseImg ;

	// on trouve le nom du fichier temporaire � visualiser
	sNomHtml = hsac.nomSansDoublons(sPathHtml, sNomHtml, "htm") ;
	sFichierHtml = sPathHtml + sNomHtml ;

	hsac.initTotaux() ;
	hsac.ajouteLignes() ;

	// on passe une base d'images � cause de la r�f�rence
	if (!hsac.genereHtml(sFichierHtml, sBaseImg))
		return false ;

	return true ;
}

//// D�finition de NSSomEncaissRefDocument
//
NSSomEncaissRefDocument::NSSomEncaissRefDocument(NSEncaissDocument *pEncaissDoc)
                        :NSRefDocument(pEncaissDoc->GetParentDoc(), 0, 0, pEncaissDoc->pContexte, true)
{
	// on met en place une pDocInfo pour la publication
	pDocInfo 	= new NSDocumentInfo ;
	pDocInfo->setType("ZCSEN") ;

	// Initialisation des donnees
	pCriteres = new NSMultiCriteres(*(pEncaissDoc->pCriteres)) ;

	pTotaux	  = new NSEncaissData(*(pEncaissDoc->pTotaux)) ;
	pPartiels = new NSEncaissData(*(pEncaissDoc->pPartiels)) ;

	pVar 	  	= new NSVarCompta(pContexte) ;
}

NSSomEncaissRefDocument::~NSSomEncaissRefDocument(){
  // pDocInfo is deleted by ~NSNoyauDocument()
	delete pVar ;
  delete pTotaux ;
  delete pPartiels ;
  delete pCriteres ;
}

// G�n�ration du html correspondant au document////////////////////////////////////////////////////////////////
bool
NSSomEncaissRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	string    sFichierHtml ;
	NSHtmlSen hsen(typeOperation, this, pContexte, sAdresseCorresp) ;
	string    sBaseImg ;

	// on trouve le nom du fichier temporaire � visualiser
	sNomHtml = hsen.nomSansDoublons(sPathHtml, sNomHtml, "htm") ;
	sFichierHtml = sPathHtml + sNomHtml ;

	hsen.initTotaux() ;

	// on passe une base d'images � cause de la r�f�rence
	if (!hsen.genereHtml(sFichierHtml, sBaseImg))
		return false ;

	return true ;
}

//***************************************************************************// Impl�mentation des m�thodes NSVoidArray
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSVoidArray::NSVoidArray(NSVoidArray& rv)
            :NSVoidVector()
{
	if (!(rv.empty()))
		for (VoidIter i = rv.begin(); i != rv.end(); i++)
			push_back(*i) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
void
NSVoidArray::vider()
{
	if (!empty())
		for (VoidIter i = begin(); i != end();)
  		// ATTENTION : on ne fait pas de delete *i;
    	// car les variables n'appartiennent pas au tableau
    	erase(i) ;
}

NSVoidArray::~NSVoidArray()
{
	vider() ;
}

//// D�finition de NSPubliRefDocument
//
NSPubliRefDocument::NSPubliRefDocument(NSVoidArray* pVarArray, string sType, NSContexte* pCtx)
                   :NSRefDocument(0, 0, 0, pCtx, true)
{
	// on met en place une pDocInfo pour la publication
	pDocInfo = new NSDocumentInfo ;
	// On copie le type de document
	pDocInfo->setType(sType) ;

	// on copie les pointeurs void de base
	pVoidArray = new NSVoidArray(*pVarArray) ;
}

NSPubliRefDocument::~NSPubliRefDocument(){
  // pDocInfo is deleted by ~NSNoyauDocument()
	delete pVoidArray ;
}

boolNSPubliRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	string    	sFichierHtml ;
	NSHtmlPubli hpubli(typeOperation, this, pContexte, sAdresseCorresp) ;
	string    	sBaseImg ;

	// on trouve le nom du fichier temporaire � visualiser
	sNomHtml = hpubli.nomSansDoublons(sPathHtml, sNomHtml, "htm") ;
	sFichierHtml = sPathHtml + sNomHtml ;

	hpubli.ajouteLignes() ;

	// on passe une base d'images � cause de la r�f�rence
	if (!hpubli.genereHtml(sFichierHtml, sBaseImg))
		return false ;

	return true ;
}

/****************************************************************************/// 				Classe NSDocCompta pour l'utilisateur choisi
/****************************************************************************/

NSDocCompta::NSDocCompta()
{
	pAgaRefDoc = 0 ;
	pDepRefDoc = 0 ;  pImpRefDoc = 0 ;
  pListActRefDoc = 0 ;
  pSomActRefDoc = 0 ;
  pSomEncaissRefDoc = 0 ;
}

NSDocCompta::~NSDocCompta(){
	if (pAgaRefDoc)
		delete pAgaRefDoc ;

	if (pDepRefDoc)		delete pDepRefDoc ;	if (pImpRefDoc)
   	delete pImpRefDoc ;

	if (pListActRefDoc)   	delete pListActRefDoc ;

	if (pSomActRefDoc)   	delete pSomActRefDoc ;

	if (pSomEncaissRefDoc)   	delete pSomEncaissRefDoc ;
}

// fin du fichier nsdocaga.cpp////////////////////////////////////////////////

