//----------------------------------------------------------------------------// ObjectWindows - (C) Copyright 1991, 1993 by Borland International
//   Tutorial application -- step12dv.cpp
//----------------------------------------------------------------------------
#include <owl\owlpch.h>
#include <owl\dc.h>
#include <owl\inputdia.h>
#include <owl\chooseco.h>
#include <owl\gdiobjec.h>
#include <owl\docmanag.h>
#include <owl\filedoc.h>
#include <iostream.h>
#include <cstring.h>

#include "partage\nsdivfct.h"
#include "nautilus\nssuper.h"
#include "nautilus\nsdecode.h"
#include "nsbb\nsbb.h"
#include "nautilus\nsrechd2.h"
#include "nautilus\nsmodhtm.h"

#include "nautilus\nshistdo.h"
#include "nsbb\nstrnode.h"
#include "nautilus\nsldvdoc.h"
#include "nssavoir\nsgraphe.h"
#include "nautilus\nshistor.h"

//-----------------------------------------------------------------------// fonction globale de tri :
//			afficher les documents dans ordre anti-chronologique : selon
//			le num�ro de document
//-----------------------------------------------------------------------
bool
inferieur(NSDocumentHisto* s, NSDocumentHisto* b)
{
	if (string(s->GetDateDoc()) > string(b->GetDateDoc()))
		return true ;
	if (string(s->GetDateDoc()) < string(b->GetDateDoc()))
		return false ;
	return (s->getDocument() > b->getDocument()) ;
}

// --------------------------------------------------------------------------
// ---------------------- METHODES DE NSHISTODocument --------------------------
// --------------------------------------------------------------------------
NSHISTODocument::NSHISTODocument(TDocument* parent, NSContexte* pCtx)
                :TDocument(parent), NSRoot(pCtx)
{
  string sLang = "" ;
  if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;
	string sCode = string("ZHIST1") ;
	pContexte->getDico()->donneLibelle(sLang, &sCode, &sTitre) ;

	// sTitre = "Historique" ;
	SetTitle(sTitre.c_str()) ;

	pHtmlCS  = 0 ;	pLibChem = 0 ;	AjouteDocument() ;}
//---------------------------------------------------------------------------//  Description : Destructeur
//---------------------------------------------------------------------------
NSHISTODocument::~NSHISTODocument()
{
	// on ne fait pas de delete de pDocHis car pDocHis == this
	if (pContexte)
		if (pContexte->getUtilisateur())
			if (pContexte->getPatient())
				if (pContexte->getPatient()->pDocHis)
					pContexte->getPatient()->pDocHis = 0;

	if (pHtmlCS)		delete pHtmlCS ;
	if (pLibChem)
		delete pLibChem ;

/*
	NsHsitorTemplate* pHistTempl = TYPESAFE_DOWNCAST(GetTemplate(), NsHsitorTemplate) ;
	if (pHistTempl)
		delete pHistTempl ;
*/
}

//---------------------------------------------------------------------------//  Description : Constructeur copie
//---------------------------------------------------------------------------
NSHISTODocument::NSHISTODocument(NSHISTODocument& rv)
                :TDocument(rv), NSRoot(rv.pContexte)
{
try
{
	sTitre = rv.sTitre;

	VectDocument       = rv.VectDocument; //vecteur des documents	VectDocumentOuvert = rv.VectDocumentOuvert; // vecteur des documents ouverts
	VectChemise        = rv.VectChemise;  //vecteur des chemises
	// VectChemDoc  		= rv.VectChemDoc;

	if (rv.pHtmlCS)		pHtmlCS = new NSHtml(*(rv.pHtmlCS)) ;
	else
		pHtmlCS = 0 ;

	if (rv.pLibChem)
		pLibChem = new NSDocumentHisto(rv.pLibChem) ;
	else
		pLibChem = 0 ;
}
catch (...)
{
    erreur("Exception NSHISTODocument copy ctor.", standardError, 0) ;
}
}
//---------------------------------------------------------------------------//  Description : Operateur =
//---------------------------------------------------------------------------

NSHISTODocument&NSHISTODocument::operator=(NSHISTODocument& src)
{
try
{
	if (this == &src)
		return *this ;

	sTitre 	  = src.sTitre;

	VectDocument 		= src.VectDocument; //vecteur des documents
	VectDocumentOuvert 	= src.VectDocumentOuvert;
	VectChemise  		= src.VectChemise;  //vecteur des chemises
	// VectChemDoc  		= src.VectChemDoc;

  if (pHtmlCS)
		delete pHtmlCS ;

	if (src.pHtmlCS)		pHtmlCS = new NSHtml(*(src.pHtmlCS));
	else
		pHtmlCS = 0;

	if (pLibChem)
		delete pLibChem ;

	if (src.pLibChem)
		pLibChem = new NSDocumentHisto(src.pLibChem) ;
	else
		pLibChem = 0 ;
	return *this ;}catch (...)
{
	erreur("Exception NSHISTODocument = operator.", standardError, 0) ;
	return *this ;
}
}
boolNSHISTODocument::Open(int mode, const char far* path)
{
	return true ;
}

boolNSHISTODocument::Close()
{
	return true ;
}

boolNSHISTODocument::CanClose()
{
	return TDocument::CanClose() ;
}

voidNSHISTODocument::SetTitle(LPCSTR title)
{
	TDocument::SetTitle(sTitre.c_str()) ;
}

//// Renvoit l'arbre qui correspond � cet identifiant
//
// Deux cas de figure :
//  1) l'arbre est d�j� stock� de fa�on perenne en m�moire
//      *ppNSPPt pointe dessus, *pbDeleteAtEnd vaut false
//      (l'appelant ne doit jamais d�truire l'arbre)
//  2) l'arbre est charg� en m�moire par cette fonction
//      *ppNSPPt est instanci�, *pbDeleteAtEnd vaut true
//      (l'appelant doit d�truire l'arbre en sortant)
//
bool
NSHISTODocument::donneArbre(string sIdentifiant, NSPatPathoArray** ppNSPPt, string* pDateExam, bool* pbDeleteAtEnd)
{
	if (VectDocument.empty())
		return false ;

	//
	// Recherche du document
	//
	DocumentIter DocIt = VectDocument.begin() ;
	DocIt = VectDocument.TrouveDocHisto(sIdentifiant) ;

	if ((DocIt == NULL) || (DocIt == VectDocument.end()))
		return false ;

	//
	// Arbre
	//
	*ppNSPPt        = (*DocIt)->pPatPathoArray ;
	*pbDeleteAtEnd  = false ;
	*pDateExam      = string((*DocIt)->dateDoc) ;

	return true ;
}

void
NSHISTODocument::RangeDocumentOuvert(NSDocumentInfo* pDocumentInfo, NSNoyauDocument* pDoc)
{
	VectDocumentOuvert.push_back(new NSDocumentHisto(pDocumentInfo, pDoc)) ;
}

void
NSHISTODocument::FermeDocumentOuvert(NSDocumentInfo* pDocumentInfo)
{
try
{
	if ((!pDocumentInfo) || (VectDocumentOuvert.empty()))
		return ;

	NSDocumentHisto DocHisto(pDocumentInfo) ;
	string codeDocHisto = DocHisto.getID() ;

	for (DocumentIter iterDoc = VectDocumentOuvert.begin(); iterDoc != VectDocumentOuvert.end(); iterDoc++)
	{
		if ((*iterDoc)->getID() == codeDocHisto)
		{
    	delete (*iterDoc) ; // of course (*iterDoc)->pDocNoy n'est pas delet� ici
      VectDocumentOuvert.erase(iterDoc) ;
      break ;
    }
  }
}
catch (...)
{
	erreur("Exception FermeDocumentOuvert.", standardError, 0) ;
}
}

NSNoyauDocument*
NSHISTODocument::EstUnDocumentOuvert(NSDocumentInfo* pDocumentInfo)
{
try
{
	if (!pDocumentInfo || (VectDocumentOuvert.empty()))
		return NULL ;

	NSDocumentHisto DocHisto(pDocumentInfo) ;
	string codeDocHisto = DocHisto.getID() ;

	for (DocumentIter iterDoc = VectDocumentOuvert.begin(); iterDoc != VectDocumentOuvert.end(); iterDoc++)
		if ((*iterDoc)->getID() == codeDocHisto)
			return (*iterDoc)->pDocNoy ;

	return NULL ;
}
catch (...)
{
	erreur("Exception EstUnDocumentOuvert.", standardError, 0) ;
	return NULL ;
}
}

NSNoyauDocument*NSHISTODocument::EstUnDocumentOuvert(NSTreeNode* pNode)
{
	if (!pNode)
		return NULL ;

	NSNoyauDocument* pDocNoy;

	NSDocumentHisto* pDocHisto = static_cast<NSDocumentHisto*>(pNode->pDocument) ;
  if (!pDocHisto)
		return NULL ;

	NSDocumentInfo* pDocInfo = new NSDocumentInfo(pContexte) ;
	*(pDocInfo->getData()) = *(pDocHisto->getData()) ;

	pDocNoy = EstUnDocumentOuvert(pDocInfo) ;

	delete pDocInfo ;

	return pDocNoy ;
}

bool
NSHISTODocument::ChargeDocInfo(NSDocumentInfo* pDocumentInfo)
{
	if (!pDocumentInfo)
		return false ;

  NSDocumentInfo* pNSDocumentInfo ;
	string sCodeDocData = pDocumentInfo->getID() ;

	// on traite d'abord le cas des documents sans data
	// dans ce cas les pDonnees sont d�j� charg�es et contiennent
	// le code du document Meta
	if (sCodeDocData == pDocumentInfo->sCodeDocMeta)
		return true ;

	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager;
	VecteurString aVecteurString ;
	pGraphe->TousLesVrais(sCodeDocData, NSRootLink::docData, &aVecteurString, "ENVERS") ;
	if (!aVecteurString.empty())
	{
		string sCodeDocMeta = *(*(aVecteurString.begin())) ;
		pNSDocumentInfo = new NSDocumentInfo(sCodeDocMeta, pContexte);
	}
	else
	{
		return false ;
	}

	pNSDocumentInfo->setPatient(pDocumentInfo->getPatient()) ;
	pNSDocumentInfo->setDocument(pDocumentInfo->getDocument()) ;

	if (!pNSDocumentInfo->ParseMetaDonnees())
	{
		return false ;
	}

	*pDocumentInfo = *pNSDocumentInfo ;

	return true ;
}
//---------------------------------------------------------------------------------// Ajouter un nouveau document � la fiche historique, l'enlever ou rafraichir
// les infos du document ou sa patpatho.
// Pour les documents nouvellement cr��s, on aura un pNouveauDocument != 0
// Par contre, si on rajoute � l'historique un document cr�� ant�rieurement,
// on aura pNouveauDocument == 0 (exemple NSDocuBox::Parametres dans nsrechdl.cpp)
//---------------------------------------------------------------------------------
void
NSHISTODocument::Rafraichir(NSDocumentInfo* pNSDocumentInfo,
                            NSPatPathoArray* pNSPatPathoArray,
                            NSNoyauDocument* pNouveauDocument)
{
	if (NULL == pNSDocumentInfo)
		return ;

	TView* pTView = GetViewList() ;
  if (NULL == pTView)
		return ;
	NsHistorique* pNsHistorique = static_cast<NsHistorique*>(pTView) ;
  if (NULL == pNsHistorique)
  	return ;
  //
  // Chercher pNSDocumentInfo dans VectDocument
  // Looking for pNSDocumentInfo inside VectDocument
  //
  DocumentIter iterDoc = VectDocument.TrouveDocHisto(pNSDocumentInfo->getID()) ;
  //
  // Document visible
  // Visible document
  //
  if (pNSDocumentInfo->estVisible())
  {
  	if ((iterDoc == NULL) || (VectDocument.end() == iterDoc))
    {
    	// note : les NOUVEAUX documents (nouvellement cr��s) doivent
      // etre d�clar�s ouverts � la cr�ation (d'o� le param pNouveauDocument)
      // warn : NEW document (that were just created) must be declared
      // open when created (it is the aim of the pNouveauDocument param)
      pNsHistorique->Rafraichir(pNSDocumentInfo, pNSPatPathoArray, pNouveauDocument) ;
      //
      // Il vaut mieux re-trier, sinon la m�thode DonnePrevPatPathoDocument ne
      // fonctionne pas
      //
      sort(VectDocument.begin(), VectDocument.end(), inferieur) ;

      AjouteALdV(pNSDocumentInfo) ;
    }
    else
    	//
      // Rafra�chir l'historique en tenant compte des changements
      // (exemple patpatho) de pNSDocumentInfo
      //
			pNsHistorique->VisualiserPatho(pNSDocumentInfo, pNSPatPathoArray) ;
	}
  //
  // Document non visible - Not visible document
  //
  else
  {
  	if ((iterDoc != NULL) && (iterDoc != VectDocument.end()))
    {
    	pNsHistorique->EnleverDocument(pNSDocumentInfo) ;
      delete *iterDoc ;
      VectDocument.erase(iterDoc) ;
    }
  }
}

//-----------------------------------------------------------------------// demander l'ajout d'un nouveau document
//-----------------------------------------------------------------------
void
NSHISTODocument::AjouteDocument(NSDocumentInfo* pNSDocumentInfo)
{
	if (NULL == pNSDocumentInfo)
		return ;

	//
	// Ajout � l'historique
	//
	TView* pTView = GetViewList() ;
  if (!pTView)
		return ;
	NsHistorique* pNsHistorique = static_cast<NsHistorique*>(pTView) ;
  if (NULL != pNsHistorique)
		pNsHistorique->AjouterDocument(pNSDocumentInfo) ;
	//
  // Il vaut mieux re-trier, sinon la m�thode DonnePrevPatPathoDocument ne
  // fonctionne pas
  //
  sort(VectDocument.begin(), VectDocument.end(), inferieur) ;

  //
  // Ajout � la Ligne de vie
  //
	AjouteALdV(pNSDocumentInfo) ;
}

voidNSHISTODocument::AjouteALdV(NSDocumentInfo* pNSDocumentInfo)
{
	if (NULL == pNSDocumentInfo)
		return ;

	NSLdvDocument* pLdvDoc = pContexte->getPatient()->pDocLdv ;
	if (NULL == pLdvDoc)
		return ;

	string sCodeDoc = pNSDocumentInfo->getID() ;
  string sDate    = "" ;
  string sType    = pNSDocumentInfo->getType() ;
	string sTitle   = pNSDocumentInfo->getDocName() ;

	DocumentIter iterDoc = VectDocument.TrouveDocHisto(sCodeDoc) ;
	if ((iterDoc != NULL) && (iterDoc != VectDocument.end()))
		sDate = (*iterDoc)->GetDateDoc() ;

	pLdvDoc->addObjet(sTitle, sDate, sDate, "", sCodeDoc, sType, pNSDocumentInfo->getContent()) ;
}

//-----------------------------------------------------------------------// demander l'autorisation de l'ouverture du document
//-----------------------------------------------------------------------
void
NSHISTODocument::AutoriserOuverture(NSDocumentInfo* pDocument)
{
	TView* pTView = GetViewList() ;
	NsHistorique* pNsHistorique = static_cast<NsHistorique*>(pTView) ;
  if (pNsHistorique)
		pNsHistorique->AutoriserOuverture(pDocument) ;
}

//-----------------------------------------------------------------------// demander l'autorisation de l'�dition du document (cf fichiers Word...)
//-----------------------------------------------------------------------
void
NSHISTODocument::AutoriserEdition(NSDocumentInfo* pDocument)
{
	if (NULL == pDocument)
		return ;

	TView* pTView = GetViewList() ;
	NsHistorique* pNsHistorique = static_cast<NsHistorique*>(pTView) ;
	if (pNsHistorique)
		pNsHistorique->AutoriserEdition(pDocument) ;
}

/*** Fermeture d'un document - Closing a document*/
void
NSHISTODocument::FermetureDocument(NSDocumentInfo* pNSDocumentInfo)
{
	if (NULL == pNSDocumentInfo)
		return ;

	TView* pTView = GetViewList() ;
	NsHistorique* pNsHistorique = static_cast<NsHistorique*>(pTView) ;
	if (pNsHistorique)
		pNsHistorique->FermetureDocument(pNSDocumentInfo) ;
}

//--------------------------------------------------------------------------// on affiche tous les documents dans un ordre chronologique
// on commence par touver les documents pour une chemise donn�e, on les met dans
// pDocumentArray
//--------------------------------------------------------------------------
void
NSHISTODocument::AjouteDocument()
{
	string sDocRoot = pContexte->getPatient()->pGraphPerson->getRootTree() ;
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
	VecteurString aVecteurString ;

	// chargement de l'index de sant�
  //
	pGraphe->TousLesVrais(sDocRoot, NSRootLink::personHealthIndex, &aVecteurString) ;
	if (!aVecteurString.empty())
	{
		string sCodeDocIndex = *(*(aVecteurString.begin())) ;
		NSDocumentHisto* pNSDocumentHisto = new NSDocumentHisto(new NSDocumentInfo(sCodeDocIndex, pContexte)) ;
    VectDocument.push_back(pNSDocumentHisto) ;
	}

	// chargement de la synth�se
  //
  aVecteurString.vider() ;
	pGraphe->TousLesVrais(sDocRoot, NSRootLink::personSynthesis, &aVecteurString) ;
  if (!aVecteurString.empty())
  {
  	string sCodeDocSynth = *(*(aVecteurString.begin())) ;
    NSDocumentHisto* pNSDocumentHisto = new NSDocumentHisto(new NSDocumentInfo(sCodeDocSynth, pContexte)) ;
    VectDocument.push_back(pNSDocumentHisto) ;
  }

  // chargement de la fiche administrative
  //
  aVecteurString.vider() ;
  pGraphe->TousLesVrais(sDocRoot, NSRootLink::personAdminData, &aVecteurString) ;
  if (!aVecteurString.empty())
  {
  	string sCodeDocAdmin = *(*(aVecteurString.begin())) ;
    NSDocumentHisto* pNSDocumentHisto = new NSDocumentHisto(new NSDocumentInfo(sCodeDocAdmin, pContexte)) ;
    VectDocument.push_back(pNSDocumentHisto) ;
  }

	// fabTODO
	// chargement de l'Equipe de Sant�
	// Loading HealthTeam
	aVecteurString.vider() ;
  pGraphe->TousLesVrais(sDocRoot, NSRootLink::personHealthTeam, &aVecteurString) ;
  if (!aVecteurString.empty())
  {
  	string	sCodeDocAdmin = *(*(aVecteurString.begin())) ;
    NSDocumentHisto *pNSDocumentHisto = new NSDocumentHisto(new NSDocumentInfo(sCodeDocAdmin, pContexte)) ;
    VectDocument.push_back(pNSDocumentHisto) ;
  }

  // chargement de la biblioth�que de chemises
  // Note : ce document est stock� � part dans pDocHis
  aVecteurString.vider() ;
  pGraphe->TousLesVrais(sDocRoot, NSRootLink::personFolderLibrary, &aVecteurString) ;
  if (!aVecteurString.empty())
  {
  	string sCodeDocLibChem = *(*(aVecteurString.begin())) ;
    pLibChem = new NSDocumentHisto(new NSDocumentInfo(sCodeDocLibChem, pContexte)) ;
    if (false == pLibChem->LoadMetaAndData())
    {
      string sErrorText = pContexte->getSuperviseur()->getText("folderErrors", "cannotLoadFoldersInformation") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    }
  }

  // chargement de tous les documents
  //
  aVecteurString.vider() ;
  pGraphe->TousLesVrais(sDocRoot, NSRootLink::personDocument, &aVecteurString) ;
  if (!aVecteurString.empty())
  {
  	for (EquiItemIter i = aVecteurString.begin(); i != aVecteurString.end(); i++)
    {
    	NSDocumentHisto* pNSDocumentHisto = new NSDocumentHisto(new NSDocumentInfo(*(*i), pContexte)) ;
      VectDocument.push_back(pNSDocumentHisto) ;
    }
  }

	// Chargement de la couche de donn�es
	///////////////////////////////////////

	// on s'occuppe d'abord de la biblioth�que de chemises
  //
	if ((NULL != pLibChem) && (string("") != pLibChem->getID()))
	{
    if (false == pLibChem->DonnePatPatho(pLibChem->pPatPathoArray))
    {
      string sErrorText = pContexte->getSuperviseur()->getText("folderErrors", "cannotLoadFoldersInformation") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    }
  }

	// on traite maintenant tous les documents visibles
  //
  DocumentIter iterDoc = VectDocument.begin() ;
  bool bOk ;

	while (iterDoc != VectDocument.end())	{
  	(*iterDoc)->pPatPathoArray->vider() ;
    aVecteurString.vider() ;
    bOk = false ;

    // On remonte le lien data du m�ta-document
    pGraphe->TousLesVrais((*iterDoc)->sCodeDocMeta, NSRootLink::docData, &aVecteurString) ;
    if (false == aVecteurString.empty())
    {
    	string sCodeDocData = *(*(aVecteurString.begin())) ;
      string sCodePat = string(sCodeDocData, 0, PAT_NSS_LEN) ;
      string sCodeDoc = string(sCodeDocData, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;

      (*iterDoc)->setPatient(sCodePat) ;
      (*iterDoc)->setDocument(sCodeDoc) ;

      if (false == (*iterDoc)->ParseMetaDonnees())
      {
        string sErrorText = pContexte->getSuperviseur()->getText("graphAndTreeErrors", "invalidDocumentLabelTree") ;
        sErrorText += string(" (") + (*iterDoc)->sCodeDocMeta ;
        if (string("") != (*iterDoc)->getDocName())
          sErrorText += string(" - ") + sCodeDocData ;
        sErrorText += string(")") ;
        pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		    erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      }
      else
      {
        if (((*iterDoc)->estVisible()) &&
          ((*iterDoc)->DonnePatPatho((*iterDoc)->pPatPathoArray)))
        {
          if ((NULL == (*iterDoc)->pPatPathoArray) || (*iterDoc)->pPatPathoArray->empty())
          {
            string sErrorText = pContexte->getSuperviseur()->getText("graphAndTreeErrors", "cannotFindDataTree") ;
            sErrorText += string(" (") + sCodeDocData ;
            if (string("") != (*iterDoc)->getDocName())
              sErrorText += string(" - ") + sCodeDocData ;
            sErrorText += string(")") ;
            pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		        erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
          }
          else
          {
      	    if ((*iterDoc)->checkPptConsistency())
      		    bOk = true ;
          }
        }
      }
    }
    else
    {
    	// m�ta-document sans lien data
      // NOTE : pour ce type de documents on met dans pDonnees le code document du Meta
      // cela permet de les retrouver dans l'historique

      string sCodePat = string((*iterDoc)->sCodeDocMeta, 0, PAT_NSS_LEN) ;
      string sCodeDoc = string((*iterDoc)->sCodeDocMeta, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;

      (*iterDoc)->setPatient(sCodePat) ;
      (*iterDoc)->setDocument(sCodeDoc) ;

      if (false == (*iterDoc)->ParseMetaDonnees())
      {
        string sErrorText = pContexte->getSuperviseur()->getText("graphAndTreeErrors", "invalidDocumentLabelTree") ;
        sErrorText += string(" (") + (*iterDoc)->sCodeDocMeta ;
        if (string("") != (*iterDoc)->getDocName())
          sErrorText += string(" - ") + (*iterDoc)->sCodeDocMeta ;
        sErrorText += string(")") ;
        pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		    erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      }
      else
      {
        if ((*iterDoc)->estVisible())
        {
      	  (*iterDoc)->pPatPathoArray->ajoutePatho("ZDOCU1", 0) ;
          bOk = true ;
        }
      }
    }

    //probl�me de r�cup�ration de la patpatho (ou de parsing) : le document
    //ne figure pas dans l'historique

    if (!bOk)    {
    	delete *iterDoc ;
      VectDocument.erase(iterDoc) ;
    }
    else
    	iterDoc++ ;
	}

	sort(VectDocument.begin(), VectDocument.end(), inferieur) ;
}

//-----------------------------------------------------------------------//demander la patpatho de la synth�se
//-----------------------------------------------------------------------
/*
void
NSHISTODocument::DonnePathoSynthese(NSPatPathoArray* pPathoSynthese)
{
  DocumentReverseIter iterReverseDocEnd = VectDocument.rend();
	for (DocumentReverseIter iterReverseDoc = VectDocument.rbegin(); iterReverseDoc != iterReverseDocEnd; iterReverseDoc++)
    {
        PatPathoIter iter = (*iterReverseDoc)->pPatPathoArray->begin();
        if (strcmp((*iter)->pDonnees->lexique, "ZSYNT1") == 0)
        {
      	    *pPathoSynthese = *((*iterReverseDoc)->pPatPathoArray);
            return;
        }
    }
}  */

//--------------------------------------------------------------------------//on affiche tous les documents dans un ordre chronologique
//on commence par touver les documents pour une chemise donn�e, on les met dans
//pDocumentArray
//--------------------------------------------------------------------------
void
NSHISTODocument::AjouteDocumentParChemise()
{
}

//-----------------------------------------------------------------------------------
// Activer la vue correspondant au document (qui est ouvert)
// Recherche le type de vue correspondant au document ouvert en fonction
// du type document -- correspond aux vues lanc�es par NSSuper::OuvreDocument
// Note : si le type document est connu, on peut alors activer une vue
// sp�cifique du document en passant sViewName != "" (cf NSTreeHis::AutoriserEdition)
// Valuer de retour : retourne un pointeur sur la vue (TView*) si ok, 0 sinon.
//-----------------------------------------------------------------------------------
TView*
NSHISTODocument::ActiveFenetre(NSDocumentInfo* pDocumentInfo, string sViewName)
{
	if (NULL == pDocumentInfo)
		return NULL ;

	TView*           pView = 0;
	NSNoyauDocument* pDocNoy = 0;

	if (!(VectDocumentOuvert.empty()))
	{
		NSDocumentHisto DocHisto(pDocumentInfo) ;
		string codeDocHisto = DocHisto.getID() ;

    for (DocumentIter iterDoc = VectDocumentOuvert.begin(); iterDoc != VectDocumentOuvert.end(); iterDoc++)
    {
    	if ((*iterDoc)->getID() == codeDocHisto)
      {
      	pDocNoy = (*iterDoc)->pDocNoy ;
        break ;
      }
    }
  }

	if (NULL == pDocNoy)
		return NULL ;

	// on consid�re ici le type du pDocNoy, qui n'est pas n�c�ssairement
	// le type du DocHisto o� il est stock� (cas des HDHTM)
	// on regarde donc le type de pDocNoy->pDocInfo qui correspond au document brut.
	//
	string sTypeDoc = "" ;
	if (pDocNoy->pDocInfo)
		sTypeDoc = string(pDocNoy->pDocInfo->getType()) ;
	string sTypeVue = sViewName ;

	if (sTypeVue == "")
	{
		// on prend dans ce cas la vue d'ouverture par d�faut
		// (cf NSuper::OuvreDocument)
		if      (string("ZCN00") == sTypeDoc)
    	sTypeVue = "NSCRReadOnlyView" ;
    else if (string("ZCS00") == sTypeDoc)
    	sTypeVue = "NSCsVue" ;
    else if (string("ZTRTF") == sTypeDoc)
    	sTypeVue = "NSTtxView" ;
    else if (string("ZTHTM") == sTypeDoc)
    	sTypeVue = "NSVisualView" ;
    else if (pContexte->typeDocument(sTypeDoc, NSSuper::isHTML)) // cas des HSHTM et des HIHTM
    	sTypeVue = "NSVisualView" ;
    else if (pContexte->typeDocument(sTypeDoc, NSSuper::isImage)) // cas des IFxxx et des IAxxx
    	sTypeVue = "NSVisualView" ;
    else
    	return NULL ;               // ne correspond � aucun type de document
	}

	// on parcourt la liste des vues de ce document
	//
	for (pView = pDocNoy->GetViewList(); pView != 0; pView = pView->GetNextView())
	{
		if (sTypeVue == string(pView->GetViewName()))
		{
			// si on a trouv� une vue valide, on active sa fenetre Parent (TMDIChild)
      // car en g�n�ral la vue elle-m�me (TWindow) ne concerne que la zone client
      SetFocus(pView->GetWindow()->Parent->GetHandle()) ;
      break ;
    }
  }

	return pView ;
}

//----------------------------------------------------------------------// Enum�rer toutes les fen�tres filles et activer celle dont le titre
// est sTitre
// NOTE : depuis la modif du 7/11/00, le document est stock� dans
// VectDocumentOuvert, et cette fonction a �t� remplac�e par
// ::ActiveFenetre(NSDocumentInfo* pDocumentInfo)
// -- on conserve le code pour le fonctionnement de EnumChildWindows
//----------------------------------------------------------------------
void
NSHISTODocument::ActiveFenetre(string sTitre)
{
	/* HINSTANCE hInstance = */ pContexte->getSuperviseur()->getApplication()->GetInstance() ;
	WNDENUMPROC lpEnumDlgFunc = (WNDENUMPROC) MakeProcInstance((FARPROC) NSHISTODocument::EnumereVues, hInstance) ;
	//
	// On passe comme param�tre de EnumChildWindows LPARAM(this), l'adresse de
	// this puisque dans les fonctions static on ne peut pas r�cup�rer
	// le pointeur this.
	//
	EnumChildWindows(pContexte->getSuperviseur()->getApplication()->prendClient()->GetHandle(), lpEnumDlgFunc,
                 LPARAM((string*)(&sTitre))) ;
}

//----------------------------------------------------------------------
//  Si iter == 0, trouve le premier document de ce type, sinon, trouve le
//  premier �l�ment de ce type situ� au del� de iter
//
//  Si sLexique contient un code complet, on fait une comparaison exacte,
//  si sLexique contient un code sens, on fait une comparaison sur le concept
//
//  If iter == 0, it finds the first document of the kind, else it finds the
//  first document of the kind beyond iter
//
//----------------------------------------------------------------------
DocumentIter
NSHISTODocument::DonnePatPathoDocument(string sLexique, NSPatPathoArray* pPatPatho, DocumentIter iter)
{
	if (VectDocument.empty())
  	return NULL ;

	bool bContinuer = true ;
  DocumentIter iterDoc ;

  if (iter == 0)
  	iterDoc = VectDocument.begin() ;
	else if (iter != VectDocument.end())
  {
  	iterDoc = iter ;
    iterDoc++ ;
	}
	else
		return NULL ;

	while ((iterDoc != VectDocument.end()) && bContinuer)
	{
		if ((*iterDoc)->pPatPathoArray->empty())
		{
			iterDoc++ ;
    	continue ;
		}

		PatPathoIter iterPat = (*iterDoc)->pPatPathoArray->begin() ;
		string sRoot = (*iterPat)->getLexique() ;

		//
		// On compare la racine avec le code cherch� puis le code sens de
		// la racine
		//
		bool bFound = false ;
		if (sRoot == sLexique)
			bFound = true ;
		else
		{
			string sRootSens ;
			pContexte->getDico()->donneCodeSens(&sRoot, &sRootSens) ;
			if (sRootSens == sLexique)
				bFound = true ;
		}
		if (bFound)
		{
			if (pPatPatho)
				*pPatPatho = *((*iterDoc)->pPatPathoArray) ;
			bContinuer = false ;
		}
		else
			iterDoc++ ;
	}

	return iterDoc ;
}
//--------------------------------------------------------------------//--------------------------------------------------------------------
BOOL FAR PASCAL _export NSHISTODocument::EnumereVues(HWND hWnd, LPARAM lParam)
{
	//
	// Adresse de l'objet bo�te de dialogue courante
	//
	string* pTitre = reinterpret_cast<string*>(lParam) ;
  string  sTitreFenetre = "" ;
	char	  titre[256] ;
	int 	  length ;

	if (IsWindow(hWnd))
	{
  	//GetWindowText(hWnd, lpString, 255);
    length = GetWindowTextLength(hWnd) ;

    // on limite le titre � 255 car GetWindowText renvoie
    // le texte des fenetres RichEdit
    if ((length > 0) && (length <= 255))
    {
    	GetWindowText(hWnd, titre, length + 1) ;
      sTitreFenetre = string(titre) ;
    }
    else
    	sTitreFenetre = "" ;

    if (*pTitre  == sTitreFenetre)
    {
    	SetFocus(hWnd) ;
      //      return FALSE;
    }
  }
  return TRUE ;
}

