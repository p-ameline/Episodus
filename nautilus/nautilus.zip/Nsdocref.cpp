//----------------------------------------------------------------------------// NSRefDocument : P�re des documents NAUTILUS, il permet de leur attacher un
//						 pointeur sur un DocumentInfo.
//----------------------------------------------------------------------------
#define __NSDOCREF_CPP

#include <owl\docmanag.h>
#include <stdio.h>
#include <classlib\filename.h>

#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "partage\nsperson.h"
#include "nautilus\nshistdo.h"	// pour rafraichir l'historique
#include "nsdn\nsdocdlg.h"   // pour EnregDocDialog
#include "nsdn\nsintrad.h"   
#include "nautilus\nsmodhtm.h"	// pour InitIntitule
#include "nautilus\nscompub.h"   // pour composer et publier
#include "nautilus\nsvisual.h"	// pour visualiser
#include "nautilus\nsbrowse.h"  // pour composer
#include "nautilus\nsldvdoc.h"
#include "nscompta\nscpta.h"    // pour ComptaAuto
#include "nsbb\nstlibre.h"      // pour l'importation des textes libres
#include "nsbb\nsbbsmal.h"
#include "nssavoir\nsgraphe.h"  // pour la cr�ation des liens#include "nautilus\nsdocref.h"
#include "nsepisod\nssoapdiv.h"
#include "dcodeur\decoder.h"
#include "nautilus\nssoapview.h"
#include "nautilus\nsdocview.h"
#include "export\html2word.h"

// --------------------------------------------------------------------------
// --------------------- METHODES DE NSRefDocument --------------------------
// --------------------------------------------------------------------------

//---------------------------------------------------------------------------
//  Constructeur
//
//  parent 	  	   : TDocument parent (?)
//	 pDocumentInfo : pointeur sur l'objet NSDocumentInfo qui
//						  permet de r�f�rencer le NSDocument
//	 pSuper		   : pointeur sur le superviseur
//---------------------------------------------------------------------------
NSRefDocument::NSRefDocument(TDocument* parent, NSDocumentInfo* pDocumentInfo,
                             NSDocumentInfo* pDocHtmlInfo, NSContexte* pCtx,
                             bool bROnly)
              :NSNoyauDocument(parent, pDocumentInfo, pDocHtmlInfo, pCtx, bROnly)
{
    pBigBoss = 0;
    pPubli = 0;
    nbImpress = 0;
    indexCorresp = -1;
    bImprimerLettre = false;
    sCodeLettre = "";
}

NSRefDocument::NSRefDocument(TDocument* parent, NSContexte* pCtx)              :NSNoyauDocument(parent, pCtx)
{
	pBigBoss	= 0;
	pPubli 		= 0;
	nbImpress	= 0;
	indexCorresp = -1;
	bImprimerLettre = false;
	sCodeLettre = "";
}

//---------------------------------------------------------------------------//   Destructeur
//---------------------------------------------------------------------------
NSRefDocument::~NSRefDocument()
{
	if ((NULL != pContexte) && (NULL != pContexte->getPatient()))
	{
  	NSPatientChoisi* pPatient = pContexte->getPatient() ;

		if (NULL != pHtmlInfo)
		{
			if ((NULL != pPatient->pDocHis) &&
                         pPatient->pDocHis->EstUnDocumentOuvert(pHtmlInfo))
				pPatient->pDocHis->FermetureDocument(pHtmlInfo) ;
		}
		// on n'utilise pas l'historique pour les documents compta (CP) et publication (PB)
		// ainsi que pour le document de publication de l'historique (HISTO)
		else if ((NULL != pDocInfo) && (string("") != pDocInfo->getType()) &&
                        (string("CP") != string(pDocInfo->getType(), 0, 2)) &&
                        (string("PB") != string(pDocInfo->getType(), 0, 2)) &&
                        (string("HISTO") != pDocInfo->getType()))
		{
			if ((NULL != pPatient->pDocHis) &&
                            pPatient->pDocHis->EstUnDocumentOuvert(pDocInfo))
				pPatient->pDocHis->FermetureDocument(pDocInfo) ;
		}
	}

	if (pBigBoss)
		delete pBigBoss;
	if (pPubli)
  	delete pPubli;
}

// Constructeur copieNSRefDocument::NSRefDocument(NSRefDocument& rv)
							:NSNoyauDocument(rv.GetParentDoc(), rv.pDocInfo, rv.pHtmlInfo, rv.pContexte, rv.isReadOnly())
{
   pBigBoss  = new NSSmallBrother(*(rv.pBigBoss)) ;
   pPubli    = 0 ;
   nbImpress = rv.nbImpress ;

   indexCorresp = rv.indexCorresp ;

   bImprimerLettre = rv.bImprimerLettre ;
   sCodeLettre = rv.sCodeLettre ;
}

// Operateur =// Pb : comment affecter le document parent destination ?????????????????
NSRefDocument&
NSRefDocument::operator=(NSRefDocument& src)
{
	if (this == &src)
		return *this ;

	NSNoyauDocument* pNoyau = (NSNoyauDocument*) this ;
	*pNoyau = (NSNoyauDocument) src ;

	pBigBoss  = new NSSmallBrother(*(src.pBigBoss)) ;
	pPubli    = 0 ;
	nbImpress = src.nbImpress ;

	indexCorresp = src.indexCorresp ;

	bImprimerLettre = src.bImprimerLettre ;
	sCodeLettre = src.sCodeLettre ;

	return *this ;
}

// Fonction qui renvoie la date stock�e dans la PatPatho
// au format jj/mm/aaaa ou au format Nautilus (aaaammjj) selon bDateClaire
string
NSRefDocument::GetDateDoc(bool bDateClaire)
{
try
{
	string sDate = "" ;
	string sMessage ;
	string sIntro ;

	string sLang = "" ;
	if (NULL != pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	if (pDocInfo)
	{
		sDate = pDocInfo->getDateExm() ;

		if (sDate == "")
			sDate = pDocInfo->getCreDate() ;
	}

	if ((!bDateClaire) || (sDate == ""))
		return sDate ;

	donne_date_claire(sDate, &sMessage, &sIntro, sLang) ;

	if (sIntro != "")
		sDate = sIntro + " " + sMessage ;
	else
		sDate = sMessage ;

	return sDate ;
}
catch (...)
{
	erreur("Exception NSRefDocument::GetDateDoc.", standardError, 0) ;
	return "" ;
}
}


// Modele de la fonction GenereHtml// Cette m�thode ne sert que pour les html statiques (ou documents images)// A priori ce type de document ne se compose pas et n'a pas de pHtmlInfobool
NSRefDocument::GenereHtml(string sPathHtml, string& sNomHtml, OperationType typeOperation,
									string sAdresseCorresp, string sPathDest)
{
	string    sFichierHtml ;
	NSModHtml html(typeOperation, this, pContexte) ;
	string    sBaseImg ;

	// on trouve le nom du fichier temporaire � visualiser
	sNomHtml = html.nomSansDoublons(sPathHtml, sNomHtml, "htm") ;
	sFichierHtml = sPathHtml + sNomHtml ;

	// generation du fichier html (dans le repertoire du serveur)
	if (pHtmlInfo)
	{
		// cas des html dynamiques
		if (!html.genereHtml(sFichierHtml, sBaseImg, pHtmlInfo))
			return false ;
	}
	else
	{
		// on fournit ici le pDocInfo car le document brut est un html statique
		if (!html.genereHtml(sFichierHtml, sBaseImg, pDocInfo))
			return false ;
	}

	// Mise � jour de la base d'images
	switch (typeOperation)
	{
		case toComposer:
			sBaseCompo = sBaseImg ;
			break ;

		default:
			sBaseImages = sBaseImg ;
	}

	return true ;
}

voidNSRefDocument::Composer()
{
try
{
	// char   nomModele[TMPL_FICHIER_LEN + 1] ;
	// char   nomEnTete[TMPL_EN_TETE_LEN + 1] ;
	// char   typeModele[TMPL_TYPE_LEN + 1] ;

  string sNomModele  = string("") ;
  string sNomEntete  = string("") ;
  string sTypeModele = string("") ;

	int    numModele ;
	string sNomHtml ;
	string sPathHtml ;
	string codeDoc ;
	bool   bExisteImages = false ;

   	// si pas d'utilisateur ou pas de patient en cours : on sort
	if ((NULL == pContexte->getUtilisateur()) || (NULL == pContexte->getPatient()))
		return ;

	if (NULL == pDocInfo)
	{
  	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    MessageBox(0, "Sauvegardez le document avant de le composer", sCaption.c_str(), MB_OK) ;
    return ;
	}

	// test pr�alable : la chemise contient-elle des images ?
	if (!ChemiseAvecImages(bExisteImages))
	{
  	erreur("Impossible de d�terminer s'il existe des images dans la chemise du document.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return ;
	}

	if (!bExisteImages)
	{
  	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    int idRet = MessageBox(0, "La chemise du document ne contient pas d'images. Voulez-vous continuer ?", sCaption.c_str(), MB_YESNO) ;
    if (idRet == IDNO)
    	return ;
	}

	codeDoc = pDocInfo->getID() ;
	sNomDocHtml = "" ;

   	/**************************** cr�ation d'un fichier html simple
   	NSHtml htest;
   	NSHtml hsdp(tTexte);
   	NSHtml *pBody;
   	htest.init("testsdp");
   	pBody = htest.GetBody();
   	hsdp.sTexte = string("\x0C");
   	htest.insere(pBody,&hsdp);
   	htest.ecrire("htest.htm");
   	return;
   	**************************************************************/

/*
   	// Cas des documents deja composes (pHtmlInfo != 0)
   	if (pHtmlInfo)
   	{
   		NomCompoDialog* pNomCompoDlg =
      	new NomCompoDialog(pContexte->GetMainWindow(), pContexte);
      	if (pNomCompoDlg->Execute() == IDCANCEL)
      	{
      		delete pNomCompoDlg;
   			return;
      	}
      	sNomDocHtml = pNomCompoDlg->sNomDocHtml;
      	delete pNomCompoDlg;
   	}
*/

	// les HIHTM (Fichiers pannels) sont eux-m�mes des templates
	if (string("ZIHTM") != pDocInfo->getType())
	{
		string sCodeLexRoot  = string("") ;
    string sCodeSensRoot = string("") ;

		if (!pPatPathoArray->empty())
		{
			sCodeLexRoot  = (*(pPatPathoArray->begin()))->getLexique() ;
      sCodeSensRoot = (*(pPatPathoArray->begin()))->getLexiqueSens(pContexte) ;
		}

		// Dialogue de choix du template
		ChoixTemplateDialog* pChoixTemplateDlg =
		    new ChoixTemplateDialog(pContexte->GetMainWindow(), pContexte, pDocInfo->getType(), sCodeSensRoot);

		if (IDCANCEL == pChoixTemplateDlg->Execute())
		{
			delete pChoixTemplateDlg ;
			return ;
		}

		numModele = pChoixTemplateDlg->TemplateChoisi ;

		if (numModele)
		{
      int iCursor = numModele - 1 ;
			sNomModele  = (*(pChoixTemplateDlg->pTemplateArray))[iCursor]->getFichier() ;			sNomEntete  = (*(pChoixTemplateDlg->pTemplateArray))[iCursor]->getEnTete() ;
			sTypeModele = (*(pChoixTemplateDlg->pTemplateArray))[iCursor]->getType() ;
		}
		else
		{
			erreur("Vous devez s�lectionner une template", warningError, 0, pContexte->GetMainWindow()->GetHandle());
			return;
		}

		delete pChoixTemplateDlg;
		sTemplate = pContexte->PathName("NTPL") + sNomModele ;		sEnTete   = pContexte->PathName("NTPL") + sNomEntete ;
	}
	else
	{
		sTemplate = pContexte->PathName(pDocInfo->getLocalis()) + pDocInfo->getFichier() ;
		sEnTete = "";
	}

	// On r�cup�re le chemin o� on va g�n�rer le fichier de composition	sPathHtml = pContexte->PathName("SHTM");
	sNomHtml = codeDoc;

	if (!GenereHtml(sPathHtml, sNomHtml, toComposer))	{
		erreur("Impossible de cr�er le fichier html de composition", standardError, 0, pContexte->GetMainWindow()->GetHandle());
		return;
	}

	// on instancie cette variable pour le navigate de la ComposView
	sUrlHtml = sNomHtml;

	NSDocViewManager dvManager(pContexte) ;	dvManager.createView(this, "Compos Format") ;}catch (...)
{
	erreur("Exception NSRefDocument::Composer", standardError, 0) ;
}
}

voidNSRefDocument::Publier(bool bCorrespPatient)
{
try
{
	string ps;

	// si pas d'utilisateur ou pas de patient en cours : on sort
	if ((pContexte->getUtilisateur() == 0) ||
   	 	(bCorrespPatient && (pContexte->getPatient() == 0)))
		return ;

	if (NULL == pDocInfo)
	{
  	string sWarningText = pContexte->getSuperviseur()->getText("documentManagement", "youMustSaveBeforePublishing") ;
		MessageBox(0, sWarningText.c_str(), 0, MB_OK) ;
		return ;
	}

	if (pPubli)
		delete pPubli ;

	// on publie le document en cours (pointeur this) avec ou sans corresp
	if (bCorrespPatient)
		pPubli = new NSPublication(pContexte->getPatient(), this, pContexte) ;
	else
		pPubli = new NSPublication(0, this, pContexte) ;

	pPubli->Publier();

	// boucle de synchronisation sur le fin du processus d'impression
	// le processus est d�bloqu� par NSVisualView::CmPublier()
	// le seul probleme c'est que �a ne marche pas : l'impression se bloque
	// si on ne rend pas la main ici
	// while (pPubli->ImpressionEnCours())
	// {
	// on applique un d�lai de 1/10�me de sec.
	// pContexte->getSuperviseur()->Delay(10);
	// }
}
catch (...)
{
	erreur("Exception NSRefDocument::Publier", standardError, 0) ;
}
}

void
NSRefDocument::Visualiser()
{
try
{
	// si pas d'utilisateur ou pas de patient en cours : on sort
	if ((pContexte->getUtilisateur() == 0) || (pContexte->getPatient() == 0))
		return ;

	if (pDocInfo == 0)	{
  	string sErrorText = pContexte->getSuperviseur()->getText("documentManagement", "youMustSaveBeforeVisualization") ;
    erreur(sErrorText.c_str(), warningError, 0, 0) ;
		return ;
	}

	// S'il existe d�j� une visualisation du document, on l'active et on sort
	if (pContexte->getPatient()->pDocHis->ActiveFenetre(pDocInfo, "NSVisualView"))
		return ;

	pContexte->getPatient()->pGraphPerson->getTemplatePres(pDocInfo->sCodeDocPres, sTemplate, sEnTete) ;

	if ((sTemplate == "") || (sEnTete == ""))
	{
		if (pContexte->typeDocument(pDocInfo->getType(), NSSuper::isTree))
		{
    	// s'il existe une template et un en-tete non vides
			// on les r�cup�re, sinon on prend les fichiers par d�faut
			sTemplate = TemplateInfoBrut(false) ;
			sEnTete   = EnTeteInfoBrut(false) ;

			if ((sTemplate == "") || (sEnTete == ""))
				TemplateCompo(pDocInfo->getType(), sTemplate, sEnTete) ;		}
		else
			TemplateCompo(pDocInfo->getType(), sTemplate, sEnTete) ;
	}

	if (sTemplate != "")		sTemplate = pContexte->PathName("NTPL") + sTemplate ;
	else
		sTemplate = "" ;

	if (sEnTete != "")      // cas important lorsqu'on n'a pas d'en-tete		sEnTete = pContexte->PathName("NTPL") + sEnTete ;
	else
		sEnTete = "" ;

	nbImpress = 0 ;  NSDocViewManager dvManager(pContexte) ;	dvManager.createView(this, "Visual Format") ;}
catch (...)
{
	erreur("Exception Visualiser.", standardError, 0) ;
}
}

/**
* Exporting the document in a specified file format
*/
bool
NSRefDocument::exportFile(string sFileName, string sFileType)
{
	// s'il existe une template et un en-tete non vides
	// on les r�cup�re, sinon on prend les fichiers par d�faut

	string fichTmpl   = TemplateInfoBrut(false) ;
	string enteteTmpl = EnTeteInfoBrut(false) ;

	if ((fichTmpl == "") || (enteteTmpl == ""))
		TemplateCompo(pDocInfo->getType(), fichTmpl, enteteTmpl) ;
	if (fichTmpl != "")
		sTemplate = pContexte->PathName("NTPL") + fichTmpl ;
	else
		sTemplate = "" ;

	if (enteteTmpl != "")
		sEnTete = pContexte->PathName("NTPL") + enteteTmpl ;
	else
		sEnTete = "" ;

	string sPathExport = pContexte->PathName("EHTM") ;
	string sNameExport = string("temp") ;

	if (!(GenereHtml(sPathExport, sNameExport, toExporter, "", sPathExport)))
		return false ;

	if ("HTM" == sFileType)
	{
		string sTempFileName = sPathExport + sNameExport ;
    if (!MoveFile(sTempFileName.c_str(), sFileName.c_str()))
    {
    	DWORD  dwLastError = GetLastError() ;
      LPTSTR lpszTemp = NULL;
      DWORD  dwRet = FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY,
                         NULL,
                         dwLastError,
                         LANG_NEUTRAL,
                         (LPTSTR)&lpszTemp,
                         0,
                         NULL) ;

			string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorMovingFile") ;
      sErrorText += string(" ") + sTempFileName + string(" -> ") + sFileName ;

      // supplied buffer is not long enough
			if ((dwRet > 0) && (NULL != lpszTemp))
      	sErrorText += string(" (") + string(lpszTemp) + string(")");

			pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
			erreur(sErrorText.c_str(), warningError, 0, 0) ;

			if (NULL != lpszTemp)
				LocalFree((HLOCAL) lpszTemp) ;

      return false ;
    }
		return true ;
	}

	//
	// Export as a word file
	//
	if (sFileType == "DOC")
	{
		string sPathExportHtml = pContexte->PathName("EHTM");

		char* pNomLibre;
		DonneNomFichier("nau", "doc", sPathExportHtml.c_str(), &pNomLibre);
		string sNomFich = string(pNomLibre);
		delete[] pNomLibre;

		//
		// Document
		//
		NSTtxDocumentExp* pTxtDoc = new NSTtxDocumentExp(NULL, pContexte) ;
		strcpy(pTxtDoc->nomFichier, sPathExport.c_str()) ;
		strcat(pTxtDoc->nomFichier, sNameExport.c_str()) ;

		//
		// View
		//
		NSAutoWordViewExp* pAutoView = new NSAutoWordViewExp(*pTxtDoc) ;

		//
		// Doc/View management
		//
		NSDocViewManager dvManager(pContexte) ;
    dvManager.createView(pTxtDoc, "HTML to Word Format", pAutoView) ;

    pAutoView->saveHTMLtoWORD(sFileName) ;

    return true ;
	}
	return false ;
}

//-------------------------------------------------------------------------------------//  Fonction:		NSRefDocument::ComptaAuto()
//  Description:	V�rifie s'il existe une fiche compta pour un document du meme type
//  Retour:			True s'il n'en existe pas, False sinon
//-------------------------------------------------------------------------------------
bool NSRefDocument::ComptaAuto()
{
try
{
	return true ;
}
catch (...)
{
	erreur("Exception NSRefDocument::ComptaAuto.", standardError, 0) ;
	return false ;
}
}

//---------------------------------------------------------------------------//  Fonction:		NSRefDocument::CreeDocument()
//  Description:	Cr�e et r�f�rence un document en mode N_TIERS
//  Retour:			True si �a r�ussit, False sinon
//---------------------------------------------------------------------------
bool
NSRefDocument::CreeDocument(NSDocumentInfo* pDoc, int typeLink,
                            string* psCodeChemise, bool bVerbose,
                            NSPersonGraphManager* pGraphManager)
{
try
{
  return NSNoyauDocument::CreeDocument(pDoc, typeLink, psCodeChemise, bVerbose,
                                       pGraphManager) ;
}
catch (...){
  erreur("Exception NSRefDocument::CreeDocument.", standardError, 0) ;
  return false ;
}
}

//---------------------------------------------------------------------------//  Fonction:		NSRefDocument::ParamDoc()
//  Description:	Permet de modifier les param�tres (titre, date, importance)
//                  d'un document.
//  Retour:			True si �a r�ussit, False sinon
//---------------------------------------------------------------------------
bool
NSRefDocument::ParamDoc()
{
try
{
	char NumChemise[PATLINK_QUALIFIE_LEN + 1] ;
	memset(NumChemise, 0, PATLINK_QUALIFIE_LEN + 1) ;

	NSDocumentInfo* pParamInfo ;

	if (pHtmlInfo)
  	pParamInfo = new NSDocumentInfo(*pHtmlInfo) ;
	else if (pDocInfo)
		pParamInfo = new NSDocumentInfo(*pDocInfo) ;
	else
	{
		erreur("Document non initialis�.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return false ;
	}

	if (pHtmlInfo)
	{
		erreur("Ce document est un document compos�. Vous ne pouvez pas modifier ses param�tres.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return false ;
	}

	// Note : Dans pParamInfo, on remplace codeDocument par le code du meta
	// ce qui permet de voir si on a un lien systeme (IsDocRoot) et permet
	// aussi d'appeler EnregDocDialog avec le code du meta, pour rester
	// coh�rent avec Referencer() et pour pouvoir r�cup�rer la chemise du document
	string sNewCodeDoc = string(pDocInfo->sCodeDocMeta, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;
	pParamInfo->setDocument(sNewCodeDoc) ;

	string sCodeDoc = pParamInfo->getID() ;
	if (pContexte->getPatient()->IsDocRoot(sCodeDoc))
	{
		erreur("Ce document est un document syst�me. Vous ne pouvez pas modifier ses param�tres.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return false ;
	}

	//
	// Appel de la boite de dialogue de r�f�rencement
	//
	string sRights = pParamInfo->getRights() ;
	EnregDocDialog* EnregDocDl =
		new EnregDocDialog(pContexte->GetMainWindow(), pParamInfo->getData(),
        									NumChemise, sRights, pContexte) ;
	int retVal = EnregDocDl->Execute() ;
	delete EnregDocDl;
	if (retVal == IDCANCEL)
	{
  	delete pParamInfo ;
		return false ;
	}

	//
	// V�rification de la pr�sence des �l�ments obligatoires
	//
  if ((string("") == pParamInfo->getDocName()) ||
		  (string(strlen(pParamInfo->getDocName().c_str()), ' ') == pParamInfo->getDocName()))
	{
		delete pParamInfo ;
		return false ;
	}
	if ((NumChemise[0] == '\0') ||
		 (strspn(NumChemise, " ") == strlen(NumChemise)))
	{
		delete pParamInfo ;
		return false ;
	}

	string sElemLex, sSens ;
  // on remet ici le codeDocument du data dans pParamInfo
  // pour pouvoir comparer les changements directement avec l'operateur ==
  // on doit le faire de toute fa�on avant de remettre � jour pDocInfo
	pParamInfo->setDocument(pDocInfo->getDocument()) ;

	if (!((*pParamInfo) == (*pDocInfo)))
	{
  	// on doit r�-enregistrer le document Meta pour changer les param�tres
    // Les param�tres modifiables sont : visible, interet, le nom et la chemise
    NSDocumentInfo* pDocInfoMeta = new NSDocumentInfo(pContexte) ;

    // remise � jour du pDocInfoMeta pour charger le document Meta
    // on pr�cise ici uniquement codePatient et codeDocument sans pr�ciser le type
    // on doit ensuite charger la patpatho � la main (cf NSDocumentInfo::ChargeDocMeta())
    pDocInfoMeta->setPatient(pDocInfo->getPatient()) ;
    string sNewCodeDoc = string(pDocInfo->sCodeDocMeta, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;
    pDocInfoMeta->setDocument(sNewCodeDoc) ;
    // on recharge la patpatho avec les arrays de donn�es
    NSNoyauDocument* pDocMeta = new NSNoyauDocument(0, pDocInfoMeta, 0, pContexte, false) ;
    /* bool resultat = */ pDocMeta->chargePatPatho() ;

    // on met � jour les droits du document - pour cela on doit acc�der au graphe.
    // ceci est fait par un setTree sur le Meta dans Referencer(). Ici on met �
    // jour directement le NSNodeRightArray pour le Meta, qui est envoy� ensuite au pilote.
    NSDataGraph* pDataGraph = pContexte->getPatient()->pGraphPerson->pDataGraph ;
    pDataGraph->aRights.set(pDocInfo->sCodeDocMeta, pParamInfo->getRights()) ;

    // on remplace les donn�es visible et interet du noeud racine    PatPathoIter iterDoc = pDocMeta->pPatPathoArray->begin() ;    int iColBase = (*iterDoc)->getColonne() ;    string sTemp ;    (*iterDoc)->setVisible(pParamInfo->getVisible()) ;    (*iterDoc)->setInteret(pParamInfo->getInteret()) ;    // on remplace le nom (noeud suivant par construction)    iterDoc++ ;    while ((pDocMeta->pPatPathoArray->end() != iterDoc) && ((*iterDoc)->getColonne() > iColBase))
    {
    	sElemLex = (*iterDoc)->getLexique() ;
      sSens    = (*iterDoc)->getLexiqueSens(pContexte) ;

      if (string("0INTI") == sSens)
      {
      	iterDoc++ ;
        string sNom = "" ;
        while ((pDocMeta->pPatPathoArray->end() != iterDoc) && ((*iterDoc)->getColonne() > iColBase+1))
        {
        	// on cherche ici un texte libre
          sElemLex = (*iterDoc)->getLexique() ;
          if (sElemLex == string("�?????"))
          {
          	sNom = (*iterDoc)->getTexteLibre() ;

            if (sNom != pParamInfo->getDocName())
            	(*iterDoc)->setTexteLibre(pParamInfo->getDocName()) ;

            break ;
          }

          iterDoc++ ;
        }
      }
      // date de r�daction
      else if (sSens == string("KREDA"))
      {
      	iterDoc++ ;
        // int iLigneBase = (*iter)->pDonnees->getLigne() ;

        string sUnite  = (*iterDoc)->getUnitSens(pContexte) ;
        string sFormat = (*iterDoc)->getLexiqueSens(pContexte) ;
        string sValeur = (*iterDoc)->getComplement() ;

        if (sUnite != string("2DA02"))
        	(*iterDoc)->setUnit("2DA021") ;

        if ((string("") == sFormat) || (sFormat[0] != '�') || (sFormat[1] != 'D'))
        	(*iterDoc)->setLexique("�T0;19") ;

        if (strlen(sValeur.c_str()) > 14)
        	sValeur = string(sValeur, 0, 14) ;

        if (sValeur != pParamInfo->getCreDate())
        {
        	string sDateReda = pParamInfo->getCreDate() ;
          if (strlen(sDateReda.c_str()) == 8)
          	sDateReda += string("000000") ;
        	(*iterDoc)->setComplement(sDateReda) ;
        }

        iterDoc++ ;
      }
      else
      	iterDoc++ ;
    }

    // on enregistre enfin le meta et on remet � jour pParamInfo
    if (pDocMeta->enregistrePatPatho())
    	pDocMeta->NSNoyauDocument::chargePatPatho() ;    *(pParamInfo->pMeta) = *(pDocMeta->pPatPathoArray) ;
  }

  // on regarde maintenant � quelle chemise est li� le document
  // Si cette chemise est diff�rente de la nouvelle, on change le lien
  // Note : la nouvelle chemise ne peut pas �tre la corbeille (voir EnregDocDialog)
  string sCodeDocMeta = pParamInfo->sCodeDocMeta ;
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
  VecteurString VecteurString ;
	pGraphe->TousLesVrais(sCodeDocMeta, NSRootLink::docFolder, &VecteurString, "ENVERS") ;

	if (false == VecteurString.empty())
	{
  	string sNodeChemise = *(*(VecteurString.begin())) ;
    pGraphe->detruireLien(sNodeChemise, NSRootLink::docFolder, sCodeDocMeta) ;
	}

	pGraphe->etablirLien(string(NumChemise), NSRootLink::docFolder, sCodeDocMeta) ;

	// En dernier lieu on v�rifie si il faut restaurer le document
	// (si le document �tait auparavant d�truit)
	string sNodeRoot = pContexte->getPatient()->getNss() + string("_") + string(DOC_CODE_DOCUM_LEN - 1, '0') ;

	if (!pGraphe->existeLien(sNodeRoot, NSRootLink::personDocument, sCodeDocMeta))
  	pGraphe->etablirLien(sNodeRoot, NSRootLink::personDocument, sCodeDocMeta) ;

	// Remise � jour des pDocInfo ou pHtmlInfo en m�moire d'apr�s les pParamInfo
	if (pHtmlInfo)
  	*(pHtmlInfo) = *(pParamInfo) ;
	else if (pDocInfo)
  	*(pDocInfo) = *(pParamInfo) ;

	delete pParamInfo ;
	return true ;
}
catch(TWindow::TXWindow& e)
{
	string sErr = string("Exception NSRefDocument::ParamDoc : ") + e.why() ;
	erreur(sErr.c_str(), standardError, 0) ;
	return false ;
}
catch (...)
{
	erreur("Exception NSRefDocument::ParamDoc", standardError, 0) ;
	return false ;
}
}

// ---------------------------------------------------------------------------
//   Inscrit le document dans le fichier DOCUMENT
//
//   Lance la boite de dialogue de r�f�rencement (choix du titre,
//	 de la chemise, de l'importance du document)
//
//	  Sauvegarde le document dans DOCUMENT//	  Cr�e un enregistrement dans CHEMDOC pour le ranger dans sa chemise
// ---------------------------------------------------------------------------

// Referencement d'un document dans la base des documents en mode N_TIERS
// (on travaille avec un graphManager qui par d�faut est le graphe du patient)// ---------------------------------------------------------------------------bool
NSRefDocument::Referencer(string typeDoc, string nomDoc, string nomFichier,
                          string cheminDoc, bool bDocVisible, bool bVerbose,
                          string sCodeDoc, NSRootLink::NODELINKTYPES typeLink,
                          NSPersonGraphManager* pGraphManager,
                          string sAuthorId, string tmplDoc, string enteteDoc,
                          string sDestinataire, string sContent,
                          string sMasterDoc, NSRootLink::NODELINKTYPES masterLink)
{
try
{
  if (false == NSNoyauDocument::Referencer(typeDoc, nomDoc, nomFichier,
                                           cheminDoc, bDocVisible, bVerbose,
                                           sCodeDoc, typeLink, pGraphManager,
                                           sAuthorId, tmplDoc, enteteDoc,
                                           sDestinataire, sContent, sMasterDoc,
                                           masterLink))
    return false ;

	// ajout d'un nouveau document type fichier :  // remise � jour de l'historique ...
  // Les documents de type global 'C' (CS ou CN)
  // appelle Rafraichir dans leur fonction enregistrer pour
  // pouvoir passer la patpatho

	if (pContexte->typeDocument(typeDoc, NSSuper::isFile))	{
    if (pContexte->getPatient()->pDocHis)
    	pContexte->getPatient()->pDocHis->Rafraichir(pDocInfo, 0, this) ;	}
	return true ;
}
catch (...)
{
	erreur("Exception NSRefDocument::Referencer.", standardError, 0) ;
	return false ;
}
}

bool
NSRefDocument::ReferencerHtml(string typeDoc, string nomDoc, string tempDoc, string enteteDoc, bool bIsVisible)
{
	return NSNoyauDocument::ReferencerHtml(typeDoc, nomDoc, tempDoc, enteteDoc, bIsVisible);
}

stringNSRefDocument::texteCourant(string textHtml)
{
    string  textOut = textHtml;
    size_t  pos = textOut.find("&");
    int     len;

    while (pos != NPOS)
    {
        len = strlen(textOut.c_str()) - pos;

   	    if ((len >= 7) && (string(textOut,pos,7) == "&acirc;"))
      	    textOut.replace(pos,7,"�");
        else if ((len >= 8) && (string(textOut,pos,8) == "&agrave;"))
      	    textOut.replace(pos,8,"�");
        else if ((len >= 8) && (string(textOut,pos,8) == "&ccedil;"))
      	    textOut.replace(pos,8,"�");
        else if ((len >= 8) && (string(textOut,pos,8) == "&eacute;"))
      	    textOut.replace(pos,8,"�");
        else if ((len >= 7) && (string(textOut,pos,7) == "&ecirc;"))
      	    textOut.replace(pos,7,"�");
        else if ((len >= 8) && (string(textOut,pos,8) == "&egrave;"))
      	    textOut.replace(pos,8,"�");
        else if ((len >= 6) && (string(textOut,pos,6) == "&euml;"))
      	    textOut.replace(pos,6,"�");
        else if ((len >= 7) && (string(textOut,pos,7) == "&icirc;"))
			textOut.replace(pos,7,"�");
        else if ((len >= 6) && (string(textOut,pos,6) == "&iuml;"))
      	    textOut.replace(pos,6,"�");
        else if ((len >= 7) && (string(textOut,pos,7) == "&ocirc;"))
      	    textOut.replace(pos,7,"�");
        else if ((len >= 4) && (string(textOut,pos,4) == "&lt;"))
      	    textOut.replace(pos,4,"<");
        else if ((len >= 4) && (string(textOut,pos,4) == "&gt;"))
      	    textOut.replace(pos,4,">");
        else if ((len >= 6) && (string(textOut,pos,6) == "&ramp;"))
      	    textOut.replace(pos,6,"&");
        else if ((len >= 6) && (string(textOut,pos,6) == "&quot;"))
      	    textOut.replace(pos,6,"\"");
        else if ((len >= 6) && (string(textOut,pos,6) == "&#124;"))
            textOut.replace(pos,6,"|");

        pos++;

        pos = textOut.find("&",pos);
    }

    return textOut;
}

// chargement de la PatPatho depuis un tableau de stringbool
NSRefDocument::chargePatPatho(string sVersion, string* sTab)
{
try
{
	string sTexteLibre;
	string sCodeTexte = "";

	NSPatPathoInfo Info ;

	if (pContexte->typeDocument(sVersion, NSSuper::isTree))
	{
		Info.setPerson(pContexte->getPatient()->getszNss()) ;
		Info.setDocum("") ;		// ce code est mis � jour apr�s r�f�rencement    Info.setLocalisation(texteCourant(sTab[0])) ;
    Info.setType        (texteCourant(sTab[1])) ;
    Info.setLexique     (texteCourant(sTab[2])) ;

    // cas des textes libres : on r�cup�re le texte situ� dans le complement
    // on g�n�re un nouveau TL et on place son pointeur dans complement
    if (!strcmp(Info.pDonnees->lexique, "�?????"))
    {
      sTexteLibre = texteCourant(sTab[3]) ;
      if (sTexteLibre == "")
      	sTexteLibre = "[texte non r�cup�r�]" ;
      else
      	Info.setTexteLibre(sTexteLibre) ;
    }
    else
    	Info.setComplement(texteCourant(sTab[3])) ;

    Info.setCertitude(texteCourant(sTab[4])) ;
    Info.setInteret  (texteCourant(sTab[5])) ;
    Info.setPluriel  (texteCourant(sTab[6])) ;
	}
  else
  	return false ;

  pPatPathoArray->push_back(new NSPatPathoInfo(Info));

  return true ;
}
catch (...)
{
    erreur("Exception chargePatPatho.", standardError, 0);
    return false ;
}
}

boolNSRefDocument::ExtraitNomImage(string sLien, string& sNom, string& sExt)
{
    size_t  i;
    string  sUrl = "";
    string  sTemp;

    sNom = "";
    sExt = "";

    for (i = 0; (i < strlen(sLien.c_str())) && (sLien[i] != '\"'); i++);
    i++;

    // on r�cup�re le nom de l'image

    while ((i < strlen(sLien.c_str())) && (sLien[i] != '.'))
    {
   	    sTemp = "";
   	    while ((i < strlen(sLien.c_str())) && (sLien[i] != '/') &&
   			 (sLien[i] != '\\') && (sLien[i] != '.'))
   		    sTemp += sLien[i++];

        if (i < strlen(sLien.c_str()))
        {
      	    if ((sLien[i] == '/') || (sLien[i] == '\\'))
            {
         	    sUrl += sTemp + sLien[i];
                i++;
            }
            else // cas sLien[i] == '.' => sortie du while
         	    sNom = sTemp;
        }
        else
            return false;
    }
    i++;

    // on r�cup�re l'extension de l'image
    while ((i < strlen(sLien.c_str())) && (sLien[i] != '\"'))
   	    sExt += sLien[i++];

    sNom += string(".") + sExt;

    return true;
}

// R�f�rencement automatique d'un document � l'aide d'un NSDocumentInfo// On ne passe pas par le dialogue qui permet de choisir le nom, la chemise, etc...
// Actuellement utilis� pour r�f�rencer les composants des html import�s.
bool
NSRefDocument::ReferencerDocument(NSDocumentInfo* pInfo)
{
try
{
	return false ;
}
catch (...)
{
	erreur("Exception ReferencerDocument.", standardError, 0) ;
	return false ;}}

//// R�f�rencement du tableau d'images constitu� par ImporterHtml
//
void
NSRefDocument::ReferencerImages(NSDocumentArray* pImageArray)
{
	// on met � jour (d'apr�s pDocInfo) le tableau d'infos images et on r�f�rence chaque image
  int    j = 0  ;
  char   cImage[20] ;
	for (DocInfoIter k = pImageArray->begin(); k != pImageArray->end(); k++)	{
  	sprintf(cImage, " (image %d)", j++) ;
    // size_t nbCars = DOC_NOM_LEN - strlen(cImage) ;

    string sImageName = pDocInfo->getDocName() + string(cImage) ;
    (*k)->setNom(sImageName) ;

    ReferencerDocument(*k) ;
	}
}

//// Referencement du document contenant la PatPatho du fichier html import�
//
bool
NSRefDocument::ReferencerDocumentPatPatho(NSRefDocument* pMasterDoc, NSPatPathoArray* pPPt, string sNomDoc, string sTypeDoc)
{
  if ((NULL == pMasterDoc) || (NULL == pPPt))
    return false ;

try
{
  string sLang = "";
  if ((pContexte) && (pContexte->getUtilisateur()))
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  NSRefDocument NewDocTree(0, pContexte) ;
  NewDocTree.setReadOnly(false) ;

  NSPatPathoArray* pPatPatho = NewDocTree.pPatPathoArray ;
  *pPatPatho = *pPPt ;

  string sRootCode = (*(pPatPatho->begin()))->getLexique() ;

	string sLibelleDoc = sNomDoc ;
  if (string("") == sLibelleDoc)
  {
    pContexte->getDico()->donneLibelle(sLang, &sRootCode, &sLibelleDoc) ;
    if (string("") != sLibelleDoc)
  	  sLibelleDoc[0] = pseumaj(sLibelleDoc[0]) ;
  }

  if (string("") == sTypeDoc)
    sTypeDoc = string("ZCS00") ;

  if (false == NewDocTree.Referencer(sTypeDoc, sLibelleDoc,
                                    string(""), string(""),  // file and path
                                    true, true,
                                    string(""),              // doc ID
                                    NSRootLink::personDocument, 0,
                                    string("_User_"),
                                    string(""), string(""),  // tpl and heading
                                    string(""), string(""),  // Dest and content
                                    pMasterDoc->sCodeDocMeta,  // Master document
                                    NSRootLink::semantizedDocument))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("importManagement", "importFailed") ;
		erreur(sErrorText.c_str(), standardError, 0) ;
    return false ;
	}

  // On enregistre la patpatho
	bool bSavePpt = NewDocTree.enregistrePatPatho() ;
	if (false == bSavePpt)
		return false ;

  // The new document must be inserted in "history" before checking if it resets
  // any goal, because this document's date will be asked to "history"

  // On pr�vient l'historique (fait � part pour les CS et les CN)
	pContexte->getPatient()->pDocHis->Rafraichir(NewDocTree.DonneDocInfo(), pPPt, &NewDocTree) ;

	// Si c'est un nouveau compte rendu on v�rifie s'il remet � z�ro un objectif
	if (pContexte->getPatient()->pDocLdv)
		pContexte->getPatient()->pDocLdv->showNewTree(pPPt, pMasterDoc->GetDateDoc(false)) ;

	return true ;
}
catch (...)
{
	erreur("Exception ReferencerDocumentPatPatho.", standardError, 0) ;
	return false ;}
}

boolNSRefDocument::GetModules(NSModuleArray* pModArray)
{
try
{
    char 	buffer[201];
	string  Chaine, sCode;
    string  sFichierModules;
	int	    i, j;

    string sLang = "";
    if ((pContexte) && (pContexte->getUtilisateur()))
        sLang = pContexte->getUtilisateur()->donneLang();

    pModArray->vider();

	sFichierModules = pContexte->PathName("FPER") + string("MODULES.LUS");
	//
	// Ouverture du fichier des modules
	//
	ifstream inFile;
	inFile.open(sFichierModules.c_str());
	if (!inFile)
	{
		erreur("Erreur � l'ouverture du fichier des modules.", standardError, 0, pContexte->GetMainWindow()->GetHandle());
		return false;
	}
	//
	// Lecture du fichier
	//
	NSModuleInfo* pModule = new NSModuleInfo;
	inFile.unsetf(ios::skipws);
	while (inFile.getline(buffer, 200))
	{
		if (strlen(buffer) >= 8)
		{
			i = 0;
			//
			// Prise du nom du module
			//
			for (j = 0; j < MODU_LEXIQUE_LEN; j++, i++)
				pModule->pDonnees->lexique[j] = buffer[i];
			pModule->pDonnees->lexique[j] = '\0';
			i += 2;
			//
			// Prise du code du module
			//
			for (j = 0; j < MODU_CODE_LEN; j++, i++)
				pModule->pDonnees->code[j] = buffer[i];
			pModule->pDonnees->code[j] = '\0';
			//
			// Recherche du libell�
			//
            sCode = string(pModule->pDonnees->lexique);
			pContexte->getDico()->donneLibelle(sLang, &sCode, &pModule->pDonnees->libelle);
			//
			// Ajout du module � l'array
			//
			pModArray->push_back(new NSModuleInfo(*pModule));
		}
		pModule->pDonnees->metAZero();
	}
	delete pModule;
	inFile.close();
    return true;
}
catch (...)
{
    erreur("Exception NSRefDocument::GetModules.", standardError, 0) ;
    return false ;
}
}

boolNSRefDocument::PatEnCours(string sParam, string& sVer)
{
    string  sVersion = "", sNom = "", sPrenom = "", sDateN = "", sSexe = "";
    size_t  i = 0;
    int     retVal;
    char    nom[PAT_NOM_LEN + 1] = "";
    char    prenom[PAT_PRENOM_LEN + 1] = "";

    // num�ro de version
    while ((i < strlen(sParam.c_str())) && (sParam[i] != '|'))
        sVersion += sParam[i++];
    i++;
    sVer = sVersion;

    while ((i < strlen(sParam.c_str())) && (sParam[i] != '|'))        sNom += sParam[i++];    i++;

    if (strlen(sNom.c_str()) <= PAT_NOM_LEN)
        strcpy(nom, sNom.c_str());
    sNom = string(strupr(nom));

    while ((i < strlen(sParam.c_str())) && (sParam[i] != '|'))
        sPrenom += sParam[i++];
    i++;

    if (strlen(sPrenom.c_str()) <= PAT_PRENOM_LEN)
        strcpy(prenom, sPrenom.c_str());
    sPrenom = string(strupr(prenom));

    while ((i < strlen(sParam.c_str())) && (sParam[i] != '|'))
        sDateN += sParam[i++];
    i++;

    while (i < strlen(sParam.c_str()))
        sSexe += sParam[i++];

    strcpy(nom, pContexte->getPatient()->getszNom());
    strcpy(prenom, pContexte->getPatient()->getszPrenom());

    if ((sNom == string(strupr(nom))) &&        (sPrenom == string(strupr(prenom))) &&
        (sDateN == string(pContexte->getPatient()->getszNaissance())) &&
        (sSexe == string(pContexte->getPatient()->getszSexe())))
    {
        return true;
    }
    else    {
        // cas des anciens compte-rendus
        if ((sNom == "") && (sPrenom == "") && (sDateN == "") && (sSexe == ""))
            return true;

        string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
        retVal = ::MessageBox(pContexte->GetMainWindow()->GetHandle(), "Attention le patient du document import� ne correspond pas au patient en cours. Voulez-vous continuer ?", sCaption.c_str(), MB_YESNO);

        if (retVal == IDYES)
            return true;
        else
            return false;
    }
}

// Importation des fichiers html statiquesbool
NSRefDocument::ImporterHtml(string sFichierSource)
{
try
{
	string scr = "" ;
	string ppt = "" ;
  string sOut = "" ;
  string sNomTag, sParamTag, sVersion ;
  string sExt = "" ;
  string sLocalis = "" ;
  string sPathSource ;
  string sNomFichier ;  string sFiche[50] ;  // pour r�cup�rer les fiches PatPatho
  string sCodeDocPatPatho = "" ;
  string sNomDocPatPatho = "" ;

  size_t i, numImage = 0 ;
  ifstream inFile ;
  ofstream outFile ;
  string   line ;

  string sLang = "" ;
  if ((pContexte) && (pContexte->getUtilisateur()))
  	sLang = pContexte->getUtilisateur()->donneLang() ;

	inFile.open(sFichierSource.c_str()) ;	if (!inFile)
	{
  	erreur("Erreur � l'ouverture du fichier html � importer.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return false ;
	}

	NSDocumentArray ImageArray ; // pour pouvoir r�f�rencer les composants images

	while (!inFile.eof())	{
		getline(inFile,line) ;
    if (line != "")
    	scr += line + "\n" ;
	}
	inFile.close() ;
	// on r�cup�re le pathname du fichier source	size_t pos = sFichierSource.find_last_of('\\') ;	if (pos != NPOS)		sPathSource = string(sFichierSource, 0, pos+1) ;	else		sPathSource = "" ;
	// on r�cup�re l'extension du fichier source	for (i = 0; (i < strlen(sFichierSource.c_str())) && (sFichierSource[i] != '.'); i++) ;

	if (i < strlen(sFichierSource.c_str()))
	{
  	// sFichierSource[i] == '.'
    i++ ;
    while (i < strlen(sFichierSource.c_str()))
    	sExt += sFichierSource[i++] ;
	}

	// on lance l'interpretation du html	i = 0 ;
	while (i < strlen(scr.c_str()))
	{
  	while ((i < strlen(scr.c_str())) && (scr[i] != '<'))
    	sOut += scr[i++] ;

    if (i < strlen(scr.c_str()))    {
    	// Lecture du Tag ...
			/* scr[i] == '<' */

      i++ ;

      sNomTag = "" ;      sParamTag = "" ;

      while ((i < strlen(scr.c_str())) && (scr[i] != '>')&&(scr[i] != ' '))      	sNomTag += scr[i++] ;

      if (scr[i] == ' ')      {
      	i++ ;

        while ((i < strlen(scr.c_str())) && (scr[i] != '>'))        	sParamTag += scr[i++] ;
      }

      /* scr[i] == '>' */
      i++ ;
      // cas des commentaires : on cherche la PatPatho      if ((strlen(sNomTag.c_str()) > 0) && (sNomTag[0] == '!'))
      {
      	// On r��crit le commentaire en entier
        sOut += string("<") + sNomTag + string(" ") + sParamTag + string(">") ;

        ppt = sParamTag ;
        size_t n = 0;

        // on lit le premier tag PatPatho        sNomTag = "" ;
        sParamTag = "" ;

				while ((n < strlen(ppt.c_str())) && (ppt[n] != '{'))        	n++ ;

        if (n < strlen(ppt.c_str()))        {
        	n++ ;

          while ((n < strlen(ppt.c_str())) &&                                    (ppt[n] != '}') && (ppt[n] != ' '))
          	sNomTag += ppt[n++] ;

          if ((n < strlen(ppt.c_str())) && (ppt[n] == ' '))          {
          	n++ ;

            while ((n < strlen(ppt.c_str())) && (ppt[n] != '}'))            	sParamTag += ppt[n++] ;
          }

          /* ppt[n] == '}' */
          n++ ;        }

        if (sNomTag == string("PatPatho"))        {
        	// on controle si la PatPatho correspond au patient en cours
          if (!PatEnCours(sParamTag, sVersion))
          	return false ;

          // on initialise le PatPathoArray          pPatPathoArray = new NSPatPathoArray(pContexte) ;

          pPatPathoArray->initialiseDepuisChaine(&ppt) ;

/*
          while ((n < strlen(ppt.c_str())) && (sNomTag != string("/PatPatho")))          {
          	// on lit le prochain tag
            sNomTag = "" ;

            while ((n < strlen(ppt.c_str())) && (ppt[n] != '{'))            	n++ ;

            n++ ;
            while ((n < strlen(ppt.c_str())) && (ppt[n] != '}'))            	sNomTag += ppt[n++] ;

            // ppt[n] == '}'
            n++ ;
            if (sNomTag == string("Fiche"))            {
            	size_t index = 0 ;
              sFiche[index] = "" ;

              // on lit chaque enregistrement jusqu'au tag de fin              while ((n < strlen(ppt.c_str())) && (ppt[n] != '{'))
              {
              	while ((n < strlen(ppt.c_str())) && (ppt[n] != '{') && (ppt[n] != '|'))
                	sFiche[index] += ppt[n++] ;

                if (ppt[n] == '|') // tag champ suivant                {
                	index++ ;
                  n++ ;

                  sFiche[index] = "" ;                }
              }

              // ppt[n] == '{'
              n++ ;
              if (n < strlen(ppt.c_str()))              {
              	if (!chargePatPatho(sVersion, sFiche))
                {
                	erreur("Le fichier import� n'a pas un bon num�ro de version.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
                  delete pImageArray ;
                  return false ;
                }
              }
              else
              {
              	erreur("Le fichier � importer contient une PatPatho erron�e.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
                delete pImageArray ;
                return false ;
              }
            }
          }
*/
        }
      }
      else if (sNomTag == string("IMG")) /* sNomTag != string("PatPatho") */
      {
      	// On traite ensemble le cas des images fixes et anim�es (vid�os)
        string sNomSource ;
        string sNomImage ;
        string sExtImage ;
        string sTypeImage ;
        string sLocImage = "" ;
        string sImageSource ;
        string sImageDest ;
        char   msg[100] ;

        NSDocumentInfo ImageInfo ;
        numImage++ ;
        // On extrait le nom de l'image de sParamTag        if (!ExtraitNomImage(sParamTag, sNomSource, sExtImage))
        {
        	erreur("Impossible de r�cup�rer une image du fichier � importer", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
          return false ;
        }

        // On r�cup�re les infos du type mime li� � l'extension du fichier
        NSTypeMime 	   ficheTypeMime(pContexte) ;
        NSTypeMimeInfo infoTypeMime ;

        if (!/*ficheTypeMime.*/pContexte->getSuperviseur()->chercheTypeMimeInfo(sExtImage, &infoTypeMime))
        {
        	sprintf(msg,"L'extension du fichier image %s n'appartient pas � la base des types mime",sNomSource.c_str()) ;
          erreur(msg, standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
          return false ;
        }

				sTypeImage = string(infoTypeMime.pDonnees->type) ;

        // cas en principe impossible, mais bon...
        if (false == pContexte->typeDocument(sTypeImage, NSSuper::isImage))
        {
        	sprintf(msg,"Le fichier image %s ne correspond pas � un type image Nautilus",sNomSource.c_str()) ;
          erreur(msg, standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
          return false ;
        }

        // On lui trouve un nouveau nom
        if (!TrouveNomFichier(sTypeImage, sExtImage, sNomImage, sLocImage))
        {
        	erreur("Erreur � l'attribution d'un nouveau nom pour une image.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
          return false ;
        }

        if (sPathSource == "")
        	sImageSource = sNomSource ;
        else
        	sImageSource = sPathSource + sNomSource ;

        sImageDest = pContexte->PathName(sLocImage) + sNomImage ;
        // on la copie depuis le repertoire d'importation sous son nouveau nom
        if (!CopyFile(sImageSource.c_str(), sImageDest.c_str(), false))
        {
        	erreur("Erreur � la copie d'une image � importer", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
          return false ;
        }

        // on copie les donn�es de l'image pour la r�f�rencer ult�rieurement
        ImageInfo.setType(sTypeImage) ;
        ImageInfo.setLocalisa(sLocImage) ;
        ImageInfo.setFichier(sNomImage) ;
        ImageArray.push_back(new NSDocumentInfo(ImageInfo)) ;

        // on remplace le tag image html par un tag nautilus
        // le tag nautilus [image] est g�n�rique pour les images et les vid�os
        sOut += string("[image]") ;
      }      else /* cas des autres Tags : on r��crit le tag */
      {
      	sOut += string("<") + sNomTag + string(" ") + sParamTag + string(">") ;
      }
    }
  }
	// fin de l'analyse syntaxique...

  // R�f�rencement du document principal : deux cas
  // soit CS -> on r�f�rence un CS (PatPatho) + un HSHTM
  // soit CN -> on r�f�rence un CN
  // les images sont r�f�renc�es dans les deux cas

  bool bEstDansModules = false ;
  bool bImporterCN ;
  int  retVal ;

	if ((pPatPathoArray) && (!pPatPathoArray->empty()))
	{
		// on r�cup�re l'array des modules utilis�s
  	NSModuleArray ModuleArray ;  // pour l'importation des CN
		if (GetModules(&ModuleArray))
		{
    	string sCodeExamen = (*(pPatPathoArray->begin()))->pDonnees->lexique ;

      for (NSModuInfoArrayIter k = ModuleArray.begin(); k != ModuleArray.end(); k++)
      {
      	// on compare les deux codes sens
        if (!strncmp((*k)->pDonnees->lexique, sCodeExamen.c_str(), MODU_LEXIQUE_LEN - 1))
        {
        	bEstDansModules = true ;
          break ;
        }
      }
    }

    if (bEstDansModules)
    {
    	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
      retVal = ::MessageBox(pContexte->GetMainWindow()->GetHandle(), "D�sirez-vous importer ce document en tant que document cr�� par vous-m�me ?", sCaption.c_str(), MB_YESNO) ;
      if (retVal == IDYES)
      	bImporterCN = true ;
      else
      	bImporterCN = false ;
    }
    else
    	bImporterCN = false ;
  }
  else
  {
  	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    retVal = ::MessageBox(pContexte->GetMainWindow()->GetHandle(), "D�sirez-vous importer ce document en tant que fichier HTML statique ?", sCaption.c_str(), MB_YESNO) ;
    if (retVal == IDYES)
    	bImporterCN = false ;
    else
    	return true ;
  }

	// Importation en tant que document CN
	if (bImporterCN)
	{
  	bool   bOk ;
    string sLibelleDoc = "" ;

    if ((pPatPathoArray) && (!pPatPathoArray->empty()))
    {
    	string sCode = (*(pPatPathoArray->begin()))->pDonnees->lexique ;
      if (sCode != "")
      	pContexte->getDico()->donneLibelle(sLang, &sCode, &sLibelleDoc) ;
    }
    bOk = Referencer("ZCN00", sLibelleDoc) ;
    if (!bOk)
    	return false ;

    //
    // On enregistre la patpatho
    //
    bOk = enregistrePatPatho() ;
    if (!bOk)
    	return false ;
    //
    // On pr�vient l'historique
    //
    pContexte->getPatient()->pDocHis->Rafraichir(pDocInfo, pPatPathoArray, this) ;

    // on r�f�rence les images qui ont besoin de sCodeChemise mis � jour par Referencer
    ReferencerImages(&ImageArray) ;
	}
  else
  { // R�f�rencement CS (PatPatho) + HSHTM
  	// on trouve un nouveau nom pour le fichier html statique
    // if (!TrouveNomFichier("HSHTM",sExt,sNomFichier,sLocalis))
    if (!TrouveNomFichier("ZSHTM", sExt, sNomFichier, sLocalis))
    {
    	erreur("Erreur � l'attribution d'un nouveau nom pour le fichier html import�.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      return false ;
    }

    outFile.open((pContexte->PathName(sLocalis) + sNomFichier).c_str()) ;
    if (!outFile)
    {
    	erreur("Erreur � l'ouverture du fichier de sortie du fichier html import�.", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      return false ;
    }

    // on r�f�rence le fichier html statique
    if (!Referencer("ZSHTM", "", sNomFichier, sLocalis))
    {
    	erreur("Le fichier html import� n'a pas pu etre r�f�renc�", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      return false ;
    }

    /* ecriture du nouveau fichier html */    for (size_t j = 0; j < strlen(sOut.c_str()); j++)
    	outFile.put(sOut[j]) ;
    outFile.close() ;

    // s'il y a une PatPatho : on r�f�rence le document PatPatho
    if ((pPatPathoArray) && (!pPatPathoArray->empty()))
    {
      sNomDocPatPatho = pDocInfo->getDocName() + string(" (PatPatho)") ;
      if (!ReferencerDocumentPatPatho(this, pPatPathoArray, sNomDocPatPatho, "ZCS00"))
      {
      	erreur("La PatPatho du fichier � importer n'a pas pu etre r�f�renc�e", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
        return false ;
      }
    }

    // on r�f�rence les images qui ont besoin de sCodeChemise mis � jour par Referencer
    ReferencerImages(&ImageArray) ;

    // on met � jour la base des composants
    // (les images doivent d�j� avoir �t� r�f�renc�es)
    if (!EcrireComposants(sCodeDocPatPatho, &ImageArray))
    {
    	erreur("Erreur � la sauvegarde des composants du fichier html import�", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      return false ;    }
  }

	return true ;}
catch (...)
{
	erreur("Exception ImporterHtml.", standardError, 0) ;
	return false ;
}
}

// Routine d'importation d'un fichier quelconque (non html)bool
NSRefDocument::ImporterFichier(string sTypeNautilus, string sFichierSource, string sPathSource, bool bVerbose, bool bDocVisible)
{
try
{
	string  sNomFichier, sLocFichier ;
	string  sNomSource, sNomDest ;

	// R�cup�ration de l'extension
	size_t pos = sFichierSource.find_last_of(".") ;
	if (pos == NPOS)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "cantFindExtension") + string(" ") + sFichierSource ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return false ;
	}

	string sExt = string(sFichierSource, pos+1, strlen(sFichierSource.c_str())-pos-1) ;

	// On trouve un nouveau nom pour le fichier � importer
	if (!TrouveNomFichier(sTypeNautilus, sExt, sNomFichier, sLocFichier))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorSettingAnImportedName") + string(" ") + sFichierSource ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return false ;
	}

	// on le copie depuis le repertoire source sous son nouveau nom
	sNomSource = sPathSource + sFichierSource ;
	sNomDest = pContexte->PathName(sLocFichier) + sNomFichier ;

	if (!CopyFile(sNomSource.c_str(), sNomDest.c_str(), false))
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorCopyingFile") + string(" ") + sNomSource + string(" -> ") + sNomDest ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
    return false ;
	}

	// Le document dans ce cas sera visible dans l'historique sauf pour les images
	if (!Referencer(sTypeNautilus, sFichierSource, sNomFichier, sLocFichier, bDocVisible, bVerbose))
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("importManagement", "referenceFailed") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
		return false ;
	}

	return true ;
}
catch (...)
{
	erreur("Exception ImporterFichier.", standardError, 0) ;
	return false ;
}
}

boolNSRefDocument::TrouveNomFichier(string typeDoc, string sExt, string& sNomFichier, string& sLocalis)
{
	if (string("") == typeDoc)
		return false ;

	string sCodePatient = pContexte->getPatient()->getNss() ;
	string sPath        = string("") ;
	string sTypeImage   = string("") ;
	string sTypeCR      = string("") ;
	string sNomServeur  = string("") ;
	string sUnite       = string("") ;

	sNomFichier = "" ;

	// On ne reconnait que les types de fichiers statiques	if ((pContexte->typeDocument(typeDoc, NSSuper::isText)) ||
	    (pContexte->typeDocument(typeDoc, NSSuper::isHTML)) ||	    (pContexte->typeDocument(typeDoc, NSSuper::isImage)))	{
		sExt = string(typeDoc, 2, 3) ;
    //
    // First, check if a specific path has been set for such document
    //
    string sTypePath = typeDoc ;
    sPath = pContexte->getSuperviseur()->PathNameType(sTypePath, sLocalis, sUnite, sNomServeur, pContexte) ;
    //
    // If not, use a "reasonnable" path
    //
		if (sPath == "")
    {
    	sTypePath = string("") ;

			// les fichiers HIHTM sont stock�s au m�me endroit que les HSHTM
			// (les HIHTM sont un cas particulier de fichier HTML statique)
			if      (typeDoc == "ZIHTM")
				sTypePath = string("ZSHTM") ;
			else if (typeDoc == "ZTHTM")
				sTypePath = string("ZTRTF") ;
    	else if (typeDoc == "ZTPDF")
				sTypePath = string("ZTRTF") ;
    	else if (typeDoc == "ZTTXT")
				sTypePath = string("ZTRTF") ;
    	//
    	// Images
    	//
    	else if (pContexte->typeDocument(typeDoc, NSSuper::isImageFixe))
				sTypePath = string("ZIF00") ;
    	else if (pContexte->typeDocument(typeDoc, NSSuper::isImageAnimee))
				sTypePath = string("ZIA00") ;

      if (string("") != sTypePath)				sPath = pContexte->getSuperviseur()->PathNameType(sTypePath, sLocalis, sUnite, sNomServeur, pContexte) ;
    }
		if (sPath == "")
			return false ;
	}
	else if (typeDoc == string("ZCN00"))	// cas des comptes-rendus : cr�ation d'un fichier .tmp
	{
		sTypeCR = typeDoc ;
		sPath = pContexte->getSuperviseur()->PathNameType(sTypeCR, sLocalis, sUnite, sNomServeur, pContexte) ;
		if (sPath == "")
			return false ;
	}
	else
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("documentManagement", "cantFindFileNameAccordingToFileType") + string(" (") + typeDoc + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), warningError, 0, 0) ;
		return false ;
	}

	// si l'extension n'est pas sp�cifi�e, on ne prend plus l'extension par d�faut :
	// Anciennement, Pour tous les fichiers statiques = les 3 derniers caract�res du typeDoc
	if (sExt == "")
	{
		// sExt = string(typeDoc,2,3);
		erreur("Extension non pr�cis�e dans ::TrouveNomFichier().", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;		return false ;	}	// On trouve un nouveau nom pour le fichier	sNomFichier = nomSansDoublons(sNomServeur, sUnite, sPath, sCodePatient, sExt) ;

	return true ;
}

stringNSRefDocument::InitIntitule()
{
try
{
	NSHtml htmlTitre(tTitre2) ;

	string sIntituleDocument ;

	string sLang = "" ;
	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;

	string sLibelleDoc = "Document" ;
	if (!pPatPathoArray->empty())
	{
  	string sCode = (*(pPatPathoArray->begin()))->pDonnees->lexique ;
    if (sCode != "")
    {
    	pContexte->getDico()->donneLibelle(sLang, &sCode, &sLibelleDoc) ;
      if (strlen(sLibelleDoc.c_str()))
      	sLibelleDoc[0] = pseumaj(sLibelleDoc[0]) ;
    }
  }

	if (!pBigBoss)  	pBigBoss = new NSSmallBrother(pContexte, pPatPathoArray) ;
	string sDateExamen = string("") ;

	// on cherche d'abord dans la patpatho
	if (!pPatPathoArray->empty())
	{
  	// First, check if first element is a KCHIR
    //
  	PatPathoIter iterPpt = pPatPathoArray->begin() ;
    iterPpt++ ;
    if (iterPpt != pPatPathoArray->end())
    	if ((*iterPpt)->getLexiqueSens(pContexte) == "KCHIR")
      	pPatPathoArray->CheminDansPatpatho(pBigBoss, "KCHIR", &sDateExamen) ;

    if (sDateExamen == "")
			pPatPathoArray->CheminDansPatpatho(pBigBoss, "LADMI/KCHIR", &sDateExamen) ;
	}

	if (sDateExamen == "")	{
  	sIntituleDocument = sLibelleDoc + string(" de ") ;
    sIntituleDocument += pContexte->getPatient()->getPrenom() + string(" ") ;
		sIntituleDocument += pContexte->getPatient()->getNom() ;
	}
	else
	{
  	char datex[15] ;
  	strcpy(datex, sDateExamen.c_str()) ;
    int age = donne_age(datex) ;

    string sIntitulePatient = string("") ;
    donne_intitule_patient(&sIntitulePatient, age) ;

    sIntituleDocument = sLibelleDoc + string(" de ") + sIntitulePatient + string(" ") ;
    sIntituleDocument += pContexte->getPatient()->getPrenom() + string(" ") ;
		sIntituleDocument += pContexte->getPatient()->getNom() ;
	}
	return sIntituleDocument ;
}
catch (...)
{
	erreur("Exception NSRefDocument::InitIntitule.", standardError, 0) ;
	return "" ;
}
}

bool
NSRefDocument::EcrireComposants(NSPatPathoArray* pPatPatho)
{
	return NSNoyauDocument::EcrireComposants(pPatPatho) ;
}

// Fonction d'�criture des composants html statiquesbool
NSRefDocument::EcrireComposants(string sCodeDocPatPatho, NSDocumentArray* pImageArray)
{
try
{
	return true ;
}
catch (...)
{
	erreur("Exception EcrireComposants.", standardError, 0) ;
	return false ;
}
}

//// On recherche les �l�ments de classification et on les envoie au SOAPer//boolNSRefDocument::makeSOAP(){try{	if (NULL == pPatPathoArray)		return false ;	if (pPatPathoArray->empty())		return true ;	VectString aVecteurString ;	NSSuper* pSuper = pContexte->getSuperviseur() ;	pSuper->getFilGuide()->TousLesVrais("0CODE", "ES", &aVecteurString, "ENVERS") ;	if (aVecteurString.empty())		return true ;	string sCodeSens ;	string sLang = "" ;	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;  //  // On recherche tous les codes pr�sents dans le document  //  PatPathoIter pptIt = pPatPathoArray->begin() ;  for (; pptIt != pPatPathoArray->end(); pptIt++)  {    string sLexique = (*pptIt)->pDonnees->lexique ;    pSuper->getDico()->donneCodeSens(&sLexique, &sCodeSens) ;    IterString itStr = aVecteurString.begin() ;    for (; itStr != aVecteurString.end(); itStr++)    {      if (*(*itStr) == sCodeSens)      {        string sLibellePere = "" ;        PatPathoIter itPere = pPatPathoArray->ChercherPere(pptIt) ;        if ((NULL != itPere) && (pPatPathoArray->end() != itPere))        {          string sLexiPere = (*itPere)->getLexique() ;          if (string("�?????") != sLexiPere)            pContexte->getDico()->donneLibelle(sLang, &sLexiPere, &sLibellePere) ;          else            sLibellePere = (*itPere)->getTexteLibre() ;          //          // Recherche de la case          //          string sCase = string("") ;          PrinciplesArray* pPrincipes = pSuper->getEpisodus()->pPrincipes ;          if ((pPrincipes) && (false == pPrincipes->empty()))          {            bool         bChercher = true ;            PatPathoIter itCurrent = pptIt ;            while (bChercher)            {              PatPathoIter pereIter = pPatPathoArray->ChercherPere(itCurrent) ;              if ((NULL == pereIter) || (pPatPathoArray->end() == pereIter))                bChercher = false ;              else              {                string sCaseSens = (*pereIter)->getLexiqueSens(pContexte) ;                for (PrinciplesIter i = pPrincipes->begin(); pPrincipes->end() != i ; i++)                {
                  string sCasePrcp = (*i)->sCase ;
                  string sCasePrcpSens ;
                  pContexte->getDico()->donneCodeSens(&sCasePrcp, &sCasePrcpSens) ;

                  if ((sCaseSens == sCasePrcpSens) && ((*i)->sClassification == sCodeSens))
                  {
                    sCase     = (*i)->sCase ;
                    bChercher = false ;
                  }                }                itCurrent = pereIter ;              }            }          }          if (string("") != sCase)          {            SOAPObject* pSOAPObj = new SOAPObject(sLibellePere, (*pptIt)->pDonnees->complement, sLexique, 100, (*pptIt)->pDonnees->getNode()) ;            pSOAPObj->sCase = sCase ;            pSuper->getEpisodus()->addToSOAP(pSOAPObj) ;            if (pSuper->getEpisodus()->pSOAPView && pSuper->getEpisodus()->pSOAPView->getDoc())              pSuper->getEpisodus()->pSOAPView->getDoc()->pDocInfo = pDocInfo ;          }        }      }    }  }  //  // On recherche les 'O' � recenser (optionnel)  //  string sFichierTempo = pContexte->PathName("FPER") + string("soap_o.dat") ;
  ifstream inFile ;
  inFile.open(sFichierTempo.c_str()) ;  if (!inFile)
    return true ;

  VectString aOtoSOAP ;
  string     sLine ;
  while (!inFile.eof())  {
    getline(inFile, sLine) ;
    if (string("") != sLine)
      aOtoSOAP.push_back(new string(sLine)) ;
  }
  inFile.close() ;
  if (aOtoSOAP.empty())    return true ;  //  // On recherche tous les codes pr�sents dans le document  //  pptIt = pPatPathoArray->begin() ;  for (; pptIt != pPatPathoArray->end(); pptIt++)  {    string sChemin = pPatPathoArray->donneCheminItem(pptIt) ;    string sNode = (*pptIt)->getLexique() ;    if ((*pptIt)->getPluriel() != "")
      sNode += string(1, cheminSeparationMARK) + (*pptIt)->getPluriel() ;
    if ((*pptIt)->getCertitude() != "")
      sNode += string(1, cheminSeparationMARK) + (*pptIt)->getCertitude() ;    if (sChemin != "")      sChemin += string(1, cheminSeparationMARK) ;    sChemin += sNode ;    string sCheminSens ;    pSuper->getDico()->donneCodeSens(&sChemin, &sCheminSens) ;    IterString itStr = aOtoSOAP.begin();    for (; itStr != aOtoSOAP.end(); itStr++)    {      if (*(*itStr) == sCheminSens)      {        NSPatPathoArray sousPT(pContexte) ;        pPatPathoArray->ExtrairePatPatho(pptIt, &sousPT) ;        // D�codage de l'�l�ment lexique        // on forme une patpatho contenant l'�l�ment
        NSPatPathoArray PT(pContexte) ;
        PT.ajoutePatho(pptIt, 0, 0) ;
        PT.InserePatPatho(PT.end(), &sousPT, 1) ;

        GlobalDkd Dcode(pContexte, sLang, sCheminSens, &PT) ;
        Dcode.decode(pContexte->getSuperviseur()->getDico()->dcTiret) ;
        // pDcode->decodeNoeud(sChemin) ;
        string sLabel = *(Dcode.sDcodeur()) ;

        SOAPObject* pSOAPObj = new SOAPObject(sLabel, "", "", 100, (*pptIt)->pDonnees->getNode()) ;        pSOAPObj->sCase = "0SOA21" ;        pSuper->getEpisodus()->addToSOAP(pSOAPObj) ;      }    }  }  return true ;}catch (...)
{
  erreur("Exception NSCSDocument makeSOAP.", standardError, 0) ;
  return false ;
}}
// Fin de Nsdocref.cpp////////////////////////////////////////////////////////////////////////

