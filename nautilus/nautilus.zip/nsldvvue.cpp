// -----------------------------------------------------------------------------
//                  Ligne de vie - Vue du mod�le Document/Vue
// -----------------------------------------------------------------------------

#include <vcl.h>
#include <owl\owlpch.h>
#include <owl\dc.h>
#include <classlib\date.h>

#include "nautilus\nssuper.h"
#include "dcodeur\nsdkd.h"

#include "nsepisod\nsldvuti.h"
#include "nautilus\nautilus.rh"
#include "nautilus\nsadmiwd.h"
#include "nsbb\nstlibre.h"

#include "nsepisod\nsepidiv.h"

#include "nautilus\nshistdo.h"
#include "nautilus\nstrihis.h"
#include "nautilus\nsepicap.h"

#include <windows.h>
#include <owl\scrollba.h>

#include "nssavoir\nsgraphe.h"
#include "nssavoir\nsconver.h"
#include "nsbb\nsattvaltools.h"
#include "dcodeur\nsgen.h"
#include "nautilus\nsldvvue.rh"
#include "nautilus\nsldvvue.h"
#include "nautilus\nsldvvuetech.h"
#include "nautilus\nsFollowUpView.h"

#include "nautilus\nsldvgoal.h"
#include "nautilus\nsdocview.h"

#include "nsepisod\objectif_viewer.h"

#define ICONWIDTH 16

// -----------------------------------------------------------------------------
// -------------------------- METHODES DE NSLdvView ----------------------------
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
//  D�finition de la table de r�ponse de la vue NSLdvView
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSLdvView, TWindowView)
	EV_WM_VSCROLL,																			// scroll vertival
	EV_WM_HSCROLL,                                      // scroll horizontal
	EV_MESSAGE(WM_MOUSEWHEEL, EvMouseWheel),	          // mouse wheel
	EV_WM_MOUSEMOVE,                                    // mouvement de la souris
	EV_WM_LBUTTONDOWN,                                  // bouton gauche enfonc�
	EV_WM_RBUTTONDOWN,                                  // bouton droit enfonc�
	EV_WM_LBUTTONUP,                                    // bouton gauche relach�
	EV_WM_LBUTTONDBLCLK,                                // dbl-clicke avec bouton gauche
	EV_WM_TIMER,                                        // timer
	EV_WM_HOTKEY,                                       // raccourci (hotkey)
  EV_WM_KEYDOWN,
  EV_WM_SYSKEYDOWN,
	EV_WM_CLOSE,                                        // fermeture de la fen�tre
	EV_WM_DESTROY,                                      // destruction de la fen�tre
	EV_WM_SIZE,                                         // redimensionnement de la fen�tre
	EV_WM_SETFOCUS,                                     // focus
	EV_WM_QUERYENDSESSION,
	EV_COMMAND(IDC_NEWPREOCCUP,     CmNewPreoccup),     // nouvelle pr�occup.
	// EV_COMMAND(IDC_CHG_PREO_TYP,    CmChgPreoType),     // correction type
	// EV_COMMAND(IDC_CHG_PREO_DAT,    CmChgPreoDate),     // correction date
	// EV_COMMAND(IDC_CHG_PREO_IDX,    CmChgPreoIndx),     // correction s�v�rite
	// EV_COMMAND(IDC_EVOL_PREO_TYP,   CmEvolPreoType),    // �volution type
	// EV_COMMAND(IDC_EVOL_PREO_IDX,   CmEvolPreoIndx),    // �volution s�v�rite
	// EV_COMMAND(IDC_SUPPRESS_PREO,   CmSuppressPreo),    // suppression pr�occup
  EV_COMMAND(CM_DRUG_NEW,         CmDrugNew),
  // EV_COMMAND(CM_DRUG_RENEW,       CmDrugRenew),
  // EV_COMMAND(CM_DRUG_CHANGE,      CmDrugModify),
  // EV_COMMAND(CM_DRUG_MODIF_POSO,  CmDrugChangePoso),
  // EV_COMMAND(CM_DRUG_STOP,        CmDrugStop),
  // EV_COMMAND(CM_DRUG_DELETE,      CmDrugDelete),
  // EV_COMMAND(IDC_ORDONNANCE,      CmDrugPrescription),
	// EV_COMMAND(IDC_ADD_PREO_OBJ,    CmAddObjectifs),     // ajouter un objectif
	// EV_COMMAND(IDC_MANAGE_RIGHTS,   CmManageRights),    // gestion des droits
	// EV_COMMAND(IDC_EVOL_PREOCCUP,   CmEvolPreoccup),    // command CmNewPreoccup
	EV_COMMAND(IDI_LDVCURS16,       CmChange2Cursor),   // command CmChange2Cursor
	EV_COMMAND(IDI_LDVZOOM16,       CmChange2Zoom),     // command CmChange2Zoom
	EV_COMMAND(CM_LDV_ZOOMIN,       CmLdvZoomIn),       // command CmLdvZoomIn
	EV_COMMAND(CM_LDV_ZOOMOUT,      CmLdvZoomOut),      // command CmLdvZoomOut
	EV_COMMAND(CM_LDV_PIXSECOND,    CmLdvPixSecond),    // pixel == 1 seconde
	EV_COMMAND(CM_LDV_PIXMINUTE,    CmLdvPixMinute),    // pixel == 1 minute
	EV_COMMAND(CM_LDV_PIXHOUR,      CmLdvPixHour),      // pixel == 1 heure
	EV_COMMAND(CM_LDV_PIXDAY,       CmLdvPixDay),       // pixel == 1 jour
	EV_COMMAND(CM_LDV_PIXWEEK,      CmLdvPixWeek),      // pixel == 1 semaine
	EV_COMMAND(CM_LDV_PIXMONTH,     CmLdvPixMonth),     // pixel == 1 mois
	EV_COMMAND_ENABLE(IDI_LDVCURS16,  CmCursorEnable),  // passage en mode Curseur
	EV_COMMAND_ENABLE(IDI_LDVZOOM16,  CmZoomEnable),    // passage en mode Zoom
	EV_COMMAND(CM_TIPTIMER_ON,      setTipsTimer),
	EV_COMMAND(CM_TIPTIMER_OFF,     killTipsTimer),
  EV_COMMAND(CM_APPOINTMENT,      setAppointment),
  EV_COMMAND(CM_HELP,             CmHelp),
  EV_CHILD_NOTIFY_ALL_CODES(ID_PIXEL_PU, UpdatePixelPerUnitRate),
  EV_CHILD_NOTIFY_ALL_CODES(ID_SEVERITY, UpdateSeverityThreshold),
END_RESPONSE_TABLE;


// -----------------------------------------------------------------------------
//  Constructeur
//
//  doc 	: NSLdvDocument � afficher
// -----------------------------------------------------------------------------

NSLdvView::NSLdvView(NSLdvDocument& doc, TWindow* parent)
	        :TWindowView(doc, parent),
           NSRoot(doc.pContexte)
           // ,GlobalBox(this), currentPoint(this)
{
try
{
	pLdVDoc = &doc ;

  _sConcern = string("") ;
  
	// Initialisation des variables de l'objet
	// Initializing object datas

	Attr.Style = Attr.Style | WS_HSCROLL ;
	// Attr.AccelTable = LDV_ACCEL ;

	iZoomFactor = 1;
	skinName = string("ldvView");

/*
  aZoomLevels.push_back(new NSTimeZoomLevel(pixSeconde, 1, 1, 10)) ;
  aZoomLevels.push_back(new NSTimeZoomLevel(pixMinute,  1, 1, 60)) ;
  aZoomLevels.push_back(new NSTimeZoomLevel(pixHeure,   1, 1, 60)) ;
  aZoomLevels.push_back(new NSTimeZoomLevel(pixJour,    1, 1, 24)) ;
  aZoomLevels.push_back(new NSTimeZoomLevel(pixSemaine, 1, 1,  7)) ;
  aZoomLevels.push_back(new NSTimeZoomLevel(pixMois,    1, 1,  4)) ;
*/

  aZoomLevels.push_back(new NSTimeZoomLevel(pixSeconde, 0, 0, 60)) ;
  aZoomLevels.push_back(new NSTimeZoomLevel(pixMinute,  0, 0, 60)) ;
  aZoomLevels.push_back(new NSTimeZoomLevel(pixHeure,   0, 0, 24)) ;
  aZoomLevels.push_back(new NSTimeZoomLevel(pixJour,    0, 0,  7)) ;
  aZoomLevels.push_back(new NSTimeZoomLevel(pixSemaine, 0, 0,  4)) ;
  aZoomLevels.push_back(new NSTimeZoomLevel(pixMois,    0, 0, 12)) ;

  // iPixelPerUnitRate = 1 ;
  // iLowerPpuLevel    = 1 ;
  // iUpperPpuLevel    = 5 ;

	// bLButtonDown    = false ;
	// pToon2Drag      = NULL ;

	//iLargeurLigne    	= 19 ;
	//iLargeurSubLigne	= 5 ;
	//iLargeurBaseline 	= 20 ;
//  begin - test fab
	//iInterligne      	= 15 ;
  //iDrugInterLigne   = 25 ;

/*
	TEXTMETRIC tm;

	TWindowDC* pWinDC = new TWindowDC(GetParent()); // HWnd

	if (pWinDC->GetTextMetrics(tm))
  {
		iInterligne     = tm.tmHeight + tm.tmInternalLeading + tm.tmExternalLeading + 5 ;
    iDrugInterLigne = tm.tmHeight + tm.tmInternalLeading + tm.tmExternalLeading + 15 ;
  }

	delete pWinDC;
*/
	//  end   - test fab

	_bSystemColors = true ;
	_bDisplayDrugs = true ;
	_bDisplayGoals = false ;

  _iMinSeverityOfDisplayedConcerns = -1 ;

	// _iMaxConcernIndex	= 0 ;
	// _iMaxGoalsIndex 		= 0 ;
	// _iMaxDrugsIndex 		= 0 ;

	// Date and time for bottom right corner of the view is set to current time
	// La date et l'heure du coin inf�rieur droit sont fix�s au moment pr�sent

	//iLeftServiceAreaMargin      = 50 ;
	//iRightServiceAreaMargin     = 50 ;
	//iTopServiceAreaMargin       = 50 ;
	//iBottomServiceAreaMargin    = 50 ;

	// d�finition de la date du coin inf�rieur droit
	// on se met � minuit (au soir) du jour courant (ou 0h00 du jour d'apr�s)
	tDateHeureInfDroit.takeTime() ;
	tDateHeureInfDroit.placeHeures(0) ;
	tDateHeureInfDroit.placeMinutes(0) ;
	tDateHeureInfDroit.placeSecondes(0) ;

	// tDateHeureInfDroit.ajouteJours(1) ;
	// tDateHeureInfDroit.ajouteJours(30) ;

	// lPosInfDroit = 0 ;

	// initialisation de l'�chelle de zoom et du mode de curseur
	iXunit = pixHeure;

	if (pContexte->getSuperviseur()->getEpisodus()->sOpenModeLdV != "")
	{
		char cZoom = pseumaj(pContexte->getSuperviseur()->getEpisodus()->sOpenModeLdV[0]);
		switch (cZoom)
		{
    	case 'E' : iXunit = pixSeconde ; break ;
			case 'I' : iXunit = pixMinute ;  break ;
			case 'H' : iXunit = pixHeure ;   break ;
			case 'J' : iXunit = pixJour ;    break ;
			case 'S' : iXunit = pixSemaine ; break ;
			case 'M' : iXunit = pixMois ;    break ;
		}
	}

  pCurrentTimeInfo = getTimeZoomInfo(iXunit) ;
  
/*
  if (NULL != pCurrentTimeInfo)
  {
  	iPixelPerUnitRate = pCurrentTimeInfo->getUppRate() ;
		iUpperPpuLevel    = pCurrentTimeInfo->getUpperLimit() ;
		iLowerPpuLevel    = pCurrentTimeInfo->getLowerLimit() ;
  }
*/

	iMouseMode = modeCursor ;

	// initialisation de la barre de temps
	// � faire absolument avant l'initialisation des autres lignes
	// modification du calcul du placement en y
	// initChronoLine() ;

	// cr�ation de la liste d'image pour le drag and drop
	ImgDragDrop = new OWL::TImageList(NS_CLASSLIB::TSize(16, 16), ILC_COLOR16, 0, 0) ;
	ImgDragDrop->SetBkColor(NS_CLASSLIB::TColor::White) ;
	ImgDragDrop->Add(OWL::TIcon(*GetApplication(), (TResId)IDI_LDVSSOBJ16)) ;
	ImgDragDrop->Add(OWL::TIcon(*GetApplication(), (TResId)IDI_LDVOBJET16)) ;

	// Cr�ation et stockage de tous les toons
	// Creation and storage of each and every toon

  // d�finition de la zone o� est affich� en temps la position de la souris
	setDateTimeArea(0, 0, 500, 48) ;

  // Command pannel
  /* NSLdvCommandPannel* pPanel = */ new NSLdvCommandPannel(pContexte, 0, this) ;
	// aToons.push_back(pPanel) ;

  // Curves command pannel
  /* NSLdvCurvesManagementPannel* pCurvesPanel = */ new NSLdvCurvesManagementPannel(pContexte, 0, this) ;
	// aToons.push_back(pCurvesPanel) ;

  // Chrono Line
  /* NSLdvChronoLine* pChronoLine = */ new NSLdvChronoLine(pContexte, 0, this) ;
  // iLargeurChronoLine = pChronoLine->wVisibleBox.Height() ;
	// aToons.push_back(pChronoLine) ;

  // Vertical scrollbar
  /* NSLdvVerticalScrollBar* pScrollBar = */ // new NSLdvVerticalScrollBar(pContexte, 0, this) ;
	// aToons.push_back(pScrollBar) ;

  // new NSCurvesProperty(pContexte, 0, this) ;

	// Pr�occupations et d�riv�s - health issues and components
	// aToons.init(doc.getPreoccupations(), pContexte, this);

  createWorkingArea(string("")) ;

/*
  NSLdvViewArea* pWorkingArea = new NSLdvViewArea(pContexte, 0, this, true) ;
	// aToons.push_back(pWorkingArea) ;

  // Ligne de base - base line
  NSBaseLineView* pBaseLine = new NSBaseLineView(pContexte, pWorkingArea) ;
	pWorkingArea->aToons.push_back(pBaseLine) ;

	// Probl�mes
	pWorkingArea->aToons.init(pLdVDoc->getConcerns(), pContexte, pWorkingArea) ;

	// Objets et sous objets - objects and components
	pWorkingArea->aToons.init(pLdVDoc->getObjets(), pContexte, pWorkingArea) ;
	pWorkingArea->aToons.init(pLdVDoc->getSsObjets(), pContexte, pWorkingArea) ;

	// Objectifs de sant�
	pWorkingArea->aToons.init(pLdVDoc->getGoals(), pContexte, pWorkingArea) ;

  // Drugs
	pWorkingArea->aToons.init(pLdVDoc->getDrugs(), pContexte, pWorkingArea) ;

  pWorkingArea->afterToonsInit() ;
*/

  // calculRectangleGlobal() ;

	pLdvTankView = new NSLdvTankView(this, pContexte) ;
	pLdvTankView->setCoords(0, 50, 400, 300) ;

	// nsMenuIniter menuIter(pContexte) ;
	// OWL::TMenuDescr* menuBar = new OWL::TMenuDescr ;
  // menuIter.initMenuDescr(menuBar, "menubar") ;
  // SetViewMenu(menuBar) ;

  // OWL::TMenuDescr menuBar ;
  // menuIter.initMenuDescr(&menuBar, "menubar") ;
  TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;
  // pMyApp->GetMainWindow()->SetMenuDescr(menuBar) ;
  pMyApp->setMenu(string("menubar"), &hAccelerator) ;

	bSetupToolBar   = true ;

	// Construction de la barre de statut
	pSB = new OWL::TStatusBar(this, TGadget::Recessed) ;

	iNbTimerTicks   = 0 ;
	pToolTip        = new NSTitleTip(this, pContexte) ;

	// pHitToon        = 0 ;
	// pCurrentToon    = 0 ;
	// pCurrentConcern = 0 ;
}
catch (...)
{
	erreur("Exception NSLdvView ctor.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Constructeur copie
// NSLdvView::NSLdvView(NSLdvView &)
// -----------------------------------------------------------------------------

NSLdvView::NSLdvView(NSLdvView& src)
	:	TWindowView(src.GetDocument(), (TWindow*)src.GetParent()),
		NSRoot(src.pContexte)
		// ,GlobalBox(this), currentPoint(this)
{
  pLdVDoc                  = src.pLdVDoc ;
  _sConcern                = src._sConcern ;
	iXunit                   = src.iXunit ;
	iZoomFactor              = src.iZoomFactor ;
	//iLargeurLigne            = src.iLargeurLigne ;
	//iLargeurBaseline         = src.iLargeurBaseline ;
	iLargeurChronoLine       = src.iLargeurChronoLine ;
	//iInterligne              = src.iInterligne ;
  //iDrugInterLigne          = src.iDrugInterLigne ;
	_bSystemColors           = src._bSystemColors ;
	_bDisplayDrugs				   = src._bDisplayDrugs ;
	_bDisplayGoals 				   = src._bDisplayGoals ;
  _iMinSeverityOfDisplayedConcerns = src._iMinSeverityOfDisplayedConcerns ;

	skinName                 = src.skinName ;

	// GlobalBox                = src.GlobalBox ;

	tDateHeureInfDroit       = src.tDateHeureInfDroit ;
	// lPosInfDroit             = src.lPosInfDroit ;

	//iLeftServiceAreaMargin   = src.iLeftServiceAreaMargin ;
	//iRightServiceAreaMargin  = src.iRightServiceAreaMargin ;
	//iTopServiceAreaMargin    = src.iTopServiceAreaMargin ;
	//iBottomServiceAreaMargin = src.iBottomServiceAreaMargin ;

	ImgDragDrop              = src.ImgDragDrop ;

	aToons                   = src.aToons ;

  hAccelerator             = 0 ;
}

// -----------------------------------------------------------------------------
//  SetupWindow() : Initialise la fen�tre
// -----------------------------------------------------------------------------
void
NSLdvView::SetupWindow()
{
try
{
	SetWindowPosLdv() ;
	// SetWindowPosit() ;

	TWindowView::SetupWindow() ;

  EvaluateWinToonsPos(this, &aToons) ;

	skinSwitchOn(skinName) ;

	pPinceauFond        = new ldvBrush(NS_CLASSLIB::TColor::LtGray);
	pPinceauFondSys     = new ldvBrush(NS_CLASSLIB::TColor::Sys3dFace);

	pPinceauBlack       = new ldvBrush(NS_CLASSLIB::TColor::Black);
	pPinceauRed         = new ldvBrush(NS_CLASSLIB::TColor::LtRed);
	pPinceauBleu        = new ldvBrush(NS_CLASSLIB::TColor::LtBlue);
	pPinceauS1          = new ldvBrush(NS_CLASSLIB::TColor::LtCyan);
	pPinceauS2          = new ldvBrush(NS_CLASSLIB::TColor::LtGreen);
	pPinceauS3          = new ldvBrush(NS_CLASSLIB::TColor::LtYellow);
	pPinceauS4          = new ldvBrush(NS_CLASSLIB::TColor::LtRed);

	pPenEclaire         = new OWL::TPen(NS_CLASSLIB::TColor::White, /* int width */ 1 /*, int style=PS_SOLID*/);
	pPenEclaireSys      = new OWL::TPen(NS_CLASSLIB::TColor::Sys3dHilight, /* int width */ 1 /*, int style=PS_SOLID*/);
	pPenOmbre           = new OWL::TPen(NS_CLASSLIB::TColor::Gray, /* int width */ 1 /*, int style=PS_SOLID*/);
	pPenOmbreSys        = new OWL::TPen(NS_CLASSLIB::TColor::Sys3dDkShadow, /* int width */ 1 /*, int style=PS_SOLID*/);
	pPenTransition      = new OWL::TPen(NS_CLASSLIB::TColor::LtGray, /* int width */ 1 /*, int style=PS_SOLID*/);
	pPenTransitionSys   = new OWL::TPen(NS_CLASSLIB::TColor::Sys3dShadow, /* int width */ 1 /*, int style=PS_SOLID*/);

	pSelPenEclaire      = new OWL::TPen(NS_CLASSLIB::TColor::LtBlue, /* int width */ 1 /*, int style=PS_SOLID*/);
	pSelPenOmbre        = new OWL::TPen(NS_CLASSLIB::TColor::Gray, /* int width */ 1 /*, int style=PS_SOLID*/);
	pSelPenTransition   = new OWL::TPen(NS_CLASSLIB::TColor(0, 0, 10), /* int width */ 1 /*, int style=PS_SOLID*/);

	pLdvObject          = new OWL::TIcon(*GetApplication(), (TResId)IDI_LDVOBJET16);
	pLdvSsObject        = new OWL::TIcon(*GetApplication(), (TResId)IDI_LDVSSOBJ16);

	SetScrollRange(SB_HORZ, 0, 100) ;
	SetScrollPos(SB_HORZ, 100) ;

	NS_CLASSLIB::TRect wRect = GetClientRect() ;
	int iTiers = wRect.Width() / 3 ;
	if (iTiers > 10)
	{
  	switch (iXunit)
    {
    	case pixSeconde :
      	tDateHeureInfDroit.ajouteSecondes(iTiers) ;
        break ;
      case pixMinute :
      	tDateHeureInfDroit.ajouteMinutes(iTiers) ;
        break ;
    	case pixHeure :
      	tDateHeureInfDroit.ajouteHeures(iTiers) ;
        break ;
			case pixJour :
      	tDateHeureInfDroit.ajouteJours(iTiers) ;
        break ;
			case pixSemaine :
      	tDateHeureInfDroit.ajouteJours(7*iTiers) ;
        break ;
			case pixMois :
      	tDateHeureInfDroit.ajouteMois(iTiers) ;
        break ;
    }
  }
  // timeBumper() ;

  if (!(aToons.empty()))
  	for (ToonsIter toonIter = aToons.begin() ; toonIter != aToons.end() ; toonIter++)
    	(*toonIter)->SetupWindow() ;

	setTipsTimer() ;
	pToolTip->Create() ;
	pToolTip->Hide() ;
}
catch (...)
{
	erreur("Exception NSLdvView SetupWindow.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
//  Destructeur
// -----------------------------------------------------------------------------
NSLdvView::~NSLdvView()
{
try
{
	delete pLdvTankView;

	delete pSB;

	ImgDragDrop->RemoveAll() ;
	delete ImgDragDrop ;

	killTipsTimer();

	delete pToolTip;

	delete pPinceauFond;
	delete pPinceauFondSys;

	delete pPinceauBlack;
	delete pPinceauRed;
	delete pPinceauBleu;
	delete pPinceauS1;
	delete pPinceauS2;
	delete pPinceauS3;
	delete pPinceauS4;

	delete pPenEclaire;
	delete pPenEclaireSys;
	delete pPenOmbre;
	delete pPenOmbreSys;
	delete pPenTransition;
	delete pPenTransitionSys;

	delete pSelPenEclaire;
	delete pSelPenOmbre;
	delete pSelPenTransition;

	delete pLdvObject;
	delete pLdvSsObject;

  if (0 != hAccelerator)
  {
    DestroyAcceleratorTable(hAccelerator) ;
    hAccelerator = 0 ;
  }
}
catch (...)
{
  erreur("Exception NSLdvView destructor.", standardError, 0) ;
}
}

//
// Destructor for a TWindow: disposes of each window in its ChildList
// and removes itself from a non-0 parent's list of children
//
// Destroys a still-associated MS-Windows interface element and frees
// the instance thunk used for association of an MS-Windows element
// to the TWindow
//
// Disposes of its Scroller if the TScroller object was constructed
//

static void NSshutDown(TWindow* win, void*)
{
	win = 0;
}

void
NSLdvView::EvHotKey(int idHotKey)
{
}

void
NSLdvView::reinit()
{
try
{
  reinitWorkingAreas() ;

/*
	aToons.vider() ;

  // Command pannel
  new NSLdvCommandPannel(pContexte, 0, this) ;
	// aToons.push_back(pPanel) ;

  // Curves command pannel
  new NSLdvCurvesManagementPannel(pContexte, 0, this) ;
	// aToons.push_back(pCurvesPanel) ;

  // Chrono Line
  new NSLdvChronoLine(pContexte, 0, this) ;
  // iLargeurChronoLine = pChronoLine->wVisibleBox.Height() ;
	// aToons.push_back(pChronoLine) ;

  // Vertical scrollbar
  new NSLdvVerticalScrollBar(pContexte, 0, this) ;
	// aToons.push_back(pScrollBar) ;

  new NSCurvesProperty(pContexte, 0, this) ;

	// Pr�occupations et d�riv�s - health issues and components
	// aToons.init(doc.getPreoccupations(), pContexte, this);

  NSLdvViewArea* pWorkingArea = new NSLdvViewArea(pContexte, 0, this, true) ;
	// aToons.push_back(pWorkingArea) ;

  // Ligne de base - base line
  NSBaseLineView* pBaseLine = new NSBaseLineView(pContexte, pWorkingArea) ;
	pWorkingArea->aToons.push_back(pBaseLine) ;

	// Probl�mes
	pWorkingArea->aToons.init(pLdVDoc->getConcerns(), pContexte, pWorkingArea) ;

	// Objets et sous objets - objects and components
	pWorkingArea->aToons.init(pLdVDoc->getObjets(), pContexte, pWorkingArea) ;
	pWorkingArea->aToons.init(pLdVDoc->getSsObjets(), pContexte, pWorkingArea) ;

	// Objectifs de sant�
	pWorkingArea->aToons.init(pLdVDoc->getGoals(), pContexte, pWorkingArea) ;

  // Drugs
	pWorkingArea->aToons.init(pLdVDoc->getDrugs(), pContexte, pWorkingArea) ;

  pWorkingArea->afterToonsInit() ;
*/

  EvaluateWinToonsPos(this, &aToons) ;
}
catch (...)
{
  erreur("Exception NSLdvView reinit.", standardError, 0) ;
}
}

bool
NSLdvView::PreProcessMsg(MSG &msg)
{
  PRECONDITION(GetHandle()) ;
  // return hAccelerator ? ::TranslateAccelerator(GetHandle(), hAccelerator, &msg) : false ;

  if (NULL != hAccelerator)
  {
    bool bTranslated = ::TranslateAccelerator(GetHandle(), hAccelerator, &msg) ;
    if (bTranslated)
      return true ;

    if (WM_KEYDOWN == msg.message)
    {
      bool bTranslated = ::TranslateAccelerator(GetHandle(), hAccelerator, &msg) ;
      if (bTranslated)
        return true ;
      else
      {
        int cAccelerators = CopyAcceleratorTable(hAccelerator, NULL, 0);
        LPACCEL lpaccelNew = (LPACCEL) LocalAlloc(LPTR, cAccelerators * sizeof(ACCEL)) ;
        if (lpaccelNew != NULL)
        {
          CopyAcceleratorTable(hAccelerator, lpaccelNew, cAccelerators) ;
          LPACCEL lpaccelPt = lpaccelNew ;
          for (int i = 0 ; i < cAccelerators ; i++)
            ACCEL accel = *lpaccelPt++ ;
        }
      }
    }
  }
  return false ;
}

void
NSLdvView::createWorkingArea(string sConcernRef)
{
  NSLdvViewArea* pWorkingArea = new NSLdvViewArea(pContexte, 0, this, sConcernRef, true) ;
  initWorkingArea(pWorkingArea, true) ;
}

void
NSLdvView::initWorkingArea(NSLdvViewArea* pWorkArea, bool bAtCreation)
{
  if (NULL == pWorkArea)
    return ;

  if (false == bAtCreation)
    pWorkArea->reinit() ;

  // Ligne de base - base line
  NSBaseLineView* pBaseLine = new NSBaseLineView(pContexte, pWorkArea) ;
	pWorkArea->getToonsArray()->push_back(pBaseLine) ;

	// Probl�mes
	pWorkArea->getToonsArray()->init(pLdVDoc->getConcerns(), pContexte, pWorkArea) ;

	// Objets et sous objets - objects and components
	pWorkArea->getToonsArray()->init(pLdVDoc->getObjets(), pContexte, pWorkArea) ;
	pWorkArea->getToonsArray()->init(pLdVDoc->getSsObjets(), pContexte, pWorkArea) ;

	// Objectifs de sant�
	pWorkArea->getToonsArray()->init(pLdVDoc->getGoals(), pContexte, pWorkArea) ;

  // Drugs
	pWorkArea->getToonsArray()->init(pLdVDoc->getDrugs(), pContexte, pWorkArea) ;

  pWorkArea->afterToonsInit() ;
}

void
NSLdvView::emptyWorkingAreas()
{
  if (true == aToons.empty())
    return ;

  for (ToonsIter toonIter = aToons.begin() ; aToons.end() != toonIter ; toonIter++)
  {
    if (NSLdvToon::toonWorkingArea == (*toonIter)->getType())
    {
      NSLdvViewArea *pWorkArea = TYPESAFE_DOWNCAST(*toonIter, NSLdvViewArea) ;
      if (NULL != pWorkArea)
        pWorkArea->reinit() ;
    }
  }
}

void
NSLdvView::reinitWorkingAreas()
{
  if (true == aToons.empty())
    return ;

  for (ToonsIter toonIter = aToons.begin() ; aToons.end() != toonIter ; toonIter++)
  {
    if (NSLdvToon::toonWorkingArea == (*toonIter)->getType())
    {
      NSLdvViewArea *pWorkArea = TYPESAFE_DOWNCAST(*toonIter, NSLdvViewArea) ;
      if (NULL != pWorkArea)
        initWorkingArea(pWorkArea) ;
    }
  }
}

// -----------------------------------------------------------------------------
// affichage des dates importantes : naissance, aujourd'hui...
// -----------------------------------------------------------------------------
// NSLdvView::drawSpecialDates(TDC *, NVLdVRect *)
// -----------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------

/*
void
NSLdvView::drawSpecialDates(TDC* pDc, NVLdVRect *pRectARepeindre)
{
try
{
	NVLdVTemps tpsBirthDay = getDateNaissance() ;
	NVLdVTemps tpsNow ;
	tpsNow.takeTime() ;

	if ((pRectARepeindre->getLeft() <= tpsBirthDay) && (pRectARepeindre->getRight() >= tpsBirthDay))
  {
    NVLdVPoint PtBas(this) ;
    PtBas.setX(tpsBirthDay) ;
    PtBas.setY(pRectARepeindre->getBottom()) ;
    NS_CLASSLIB::TPoint Bottom = getScrollablePhysicalPoint(PtBas) ;
    pDc->MoveTo(Bottom) ;

    NVLdVPoint PtHaut(PtBas) ;
    PtHaut.setY(pRectARepeindre->getTop() + 1) ;
    NS_CLASSLIB::TPoint Top = getScrollablePhysicalPoint(PtHaut) ;
    pDc->LineTo(Top) ;
  }

  if ((pRectARepeindre->getLeft() <= tpsNow) && (pRectARepeindre->getRight() >= tpsNow))
  {
    NVLdVPoint PtBas(PtBas) ;
    PtBas.setX(tpsNow) ;
    PtBas.setY(pRectARepeindre->getBottom()) ;
    NS_CLASSLIB::TPoint Bottom = getScrollablePhysicalPoint(PtBas) ;
    pDc->MoveTo(Bottom) ;

    NVLdVPoint PtHaut(PtBas) ;
    PtHaut.setY(pRectARepeindre->getTop() + 1) ;
    NS_CLASSLIB::TPoint Top = getScrollablePhysicalPoint(PtHaut) ;
    pDc->LineTo(Top) ;
  }

  return ;
}
catch (...)
{
	erreur("Exception NSLdvView drawSpecialDates.", standardError, 0) ;
}
}
*/

// -----------------------------------------------------------------------------
// calcul de la date de naissance du patient en NVLdVTemps
// -----------------------------------------------------------------------------
// NVLdVTemps	NSLdvView::getDateNaissance()
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
NVLdVTemps
NSLdvView::getDateNaissance()
{
	NVLdVTemps  tNaissancePatient ;

	char szDateNaissance[PAT_NAISSANCE_LEN + 1];
	pContexte->getPatient()->donneNaissance(szDateNaissance);
	string sDate = string(szDateNaissance) ;

	if (sDate == "00000000")
	{
  	tNaissancePatient.init() ;
    return tNaissancePatient ;
	}

	//string  sDate   = pContexte->getPatient()->pFicheAdmin->pDateN->sContenuBrut ;

	int     iDay    = atoi(string(sDate, 6, 2).c_str()) ;
	int     iMonth  = atoi(string(sDate, 4, 2).c_str()) ;
	int     iYear   = atoi(string(sDate, 0, 4).c_str()) ;
	if (iDay == 0)
		iDay = 1 ;
	if (iMonth == 0)
		iMonth = 1 ;
	tNaissancePatient = NVLdVTemps(iYear, iMonth, iDay, 0, 0, 0) ;

	return tNaissancePatient ;
}

// -----------------------------------------------------------------------------
// r�cup�ration de l'�v�nement d�clench� lors d'un scroll horizontal
// -----------------------------------------------------------------------------
// NSLdvView::EvHScroll(UINT, UINT, HWND)
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
void
NSLdvView::EvHScroll(UINT scrollCode, UINT thumbPos, HWND hWndCtl)
{
try
{
	// r�cup�ration de la date de naissance du patient
	NVLdVTemps  tNaissancePatient = getDateNaissance() ;

	NVLdVTemps  tCurrentDate ;
	tCurrentDate.takeTime() ;
	float   fDen = float((tCurrentDate.donneAns() * 12 + tCurrentDate.donneMois()) - (tNaissancePatient.donneAns() * 12 + tNaissancePatient.donneMois())) ;

	string sMessage = "";

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	switch (iXunit)
	{
  	case pixSeconde :
			if (scrollCode == SB_LINERIGHT)
			{
				tDateHeureInfDroit.ajouteMinutes(1) ;
				break ;
			}
			if (scrollCode == SB_LINELEFT)
			{
				tDateHeureInfDroit.ajouteMinutes(-1) ;
				break ;
			}
			if (scrollCode == SB_PAGERIGHT)
			{
				tDateHeureInfDroit.ajouteHeures(1) ;
				break ;
			}
			if (scrollCode == SB_PAGELEFT)
			{
				tDateHeureInfDroit.ajouteHeures(-1) ;
				break ;
			}
			if (scrollCode == SB_THUMBPOSITION)
			{
				int iMois = ((float(thumbPos) / 100) * fDen) + (tNaissancePatient.donneAns() * 12 + tNaissancePatient.donneMois()) ;
				int iAnnee = iMois / 12 ;
				iMois = iMois - iAnnee * 12 + 1 ;
				tDateHeureInfDroit = NVLdVTemps(iAnnee, iMois, 1, 0, 0, 0) ;
				break ;
			}
			if (scrollCode == SB_THUMBTRACK)
			{
				int iMois = ((float(thumbPos) / 100) * fDen) + (tNaissancePatient.donneAns() * 12 + tNaissancePatient.donneMois()) ;
				int iAnnee = iMois / 12 ;
				iMois = iMois - iAnnee * 12 + 1 ;
				NVLdVTemps tScrollingDateInfDroit = NVLdVTemps(iAnnee, iMois, 1, 0, 0, 0) ; // donne tDateHeureInfDroit
				int iLargeurFenetreEnJours = GetClientRect().Width() / 86400 ;
				tScrollingDateInfDroit.ajouteJours(-(iLargeurFenetreEnJours / 2)) ;

				string sDate  = tScrollingDateInfDroit.donneDate();
				string sHeure = tScrollingDateInfDroit.donneHeure();

				char szDate[11];
				string sHeureLib;

				donne_date((char*)(sDate.c_str()), szDate, sLang) ;
				donne_heure((char*)(sHeure.c_str()), sHeureLib) ;

				sMessage = string(szDate) + string(" ") + sHeureLib;
				afficheStatusMessage(&sMessage, true);
				break ;
			}

		case pixMinute :
			if (scrollCode == SB_LINERIGHT)
			{
				tDateHeureInfDroit.ajouteHeures(1) ;
				break ;
			}
			if (scrollCode == SB_LINELEFT)
			{
				tDateHeureInfDroit.ajouteHeures(-1) ;
				break ;
			}
			if (scrollCode == SB_PAGERIGHT)
			{
				tDateHeureInfDroit.ajouteJours(1) ;
				break ;
			}
			if (scrollCode == SB_PAGELEFT)
			{
				tDateHeureInfDroit.ajouteJours(-1) ;
				break ;
			}
			if (scrollCode == SB_THUMBPOSITION)
			{
				int iMois = ((float(thumbPos) / 100) * fDen) + (tNaissancePatient.donneAns() * 12 + tNaissancePatient.donneMois()) ;
				int iAnnee = iMois / 12 ;
				iMois = iMois - iAnnee * 12 + 1 ;
				tDateHeureInfDroit = NVLdVTemps(iAnnee, iMois, 1, 0, 0, 0) ;
				break ;
			}
			if (scrollCode == SB_THUMBTRACK)
			{
				int iMois = ((float(thumbPos) / 100) * fDen) + (tNaissancePatient.donneAns() * 12 + tNaissancePatient.donneMois()) ;
				int iAnnee = iMois / 12 ;
				iMois = iMois - iAnnee * 12 + 1 ;
				NVLdVTemps tScrollingDateInfDroit = NVLdVTemps(iAnnee, iMois, 1, 0, 0, 0) ; // donne tDateHeureInfDroit
				int iLargeurFenetreEnJours = GetClientRect().Width() / 1440 ;
				tScrollingDateInfDroit.ajouteJours(-(iLargeurFenetreEnJours / 2)) ;

				string sDate  = tScrollingDateInfDroit.donneDate();
				string sHeure = tScrollingDateInfDroit.donneHeure();

				char szDate[11];
				string sHeureLib;

				donne_date((char*)(sDate.c_str()), szDate, sLang) ;
				donne_heure((char*)(sHeure.c_str()), sHeureLib) ;

				sMessage = string(szDate) + string(" ") + sHeureLib ;
				afficheStatusMessage(&sMessage, true) ;
				break ;
			}

		case pixHeure :
			if (scrollCode == SB_LINERIGHT)
			{
				tDateHeureInfDroit.ajouteJours(1) ;
				break ;
			}
			if (scrollCode == SB_LINELEFT)
			{
				tDateHeureInfDroit.ajouteJours(-1) ;
				break ;
			}
			if (scrollCode == SB_PAGERIGHT)
			{
				tDateHeureInfDroit.ajouteMois(1) ;
				break ;
			}
			if (scrollCode == SB_PAGELEFT)
			{
				tDateHeureInfDroit.ajouteMois(-1) ;
				break ;
			}
			if (scrollCode == SB_THUMBPOSITION)
			{
				int iMois = ((float(thumbPos) / 100) * fDen) + (tNaissancePatient.donneAns() * 12 + tNaissancePatient.donneMois()) ;
				int iAnnee = iMois / 12 ;
				iMois = iMois - iAnnee * 12 + 1 ;
				tDateHeureInfDroit = NVLdVTemps(iAnnee, iMois, 1, 0, 0, 0) ;
				break ;
			}
			if (scrollCode == SB_THUMBTRACK)
			{
				int iMois = ((float(thumbPos) / 100) * fDen) + (tNaissancePatient.donneAns() * 12 + tNaissancePatient.donneMois()) ;
				int iAnnee = iMois / 12 ;
				iMois = iMois - iAnnee * 12 + 1 ;
				NVLdVTemps tScrollingDateInfDroit = NVLdVTemps(iAnnee, iMois, 1, 0, 0, 0) ; // donne tDateHeureInfDroit
				int iLargeurFenetreEnJours = GetClientRect().Width() / 24 ;
				tScrollingDateInfDroit.ajouteJours(-(iLargeurFenetreEnJours / 2)) ;

				string sDate  = tScrollingDateInfDroit.donneDate() ;
				string sHeure = tScrollingDateInfDroit.donneHeure() ;

				char szDate[11] ;
				string sHeureLib ;

				donne_date((char*)(sDate.c_str()), szDate, sLang) ;
				donne_heure((char*)(sHeure.c_str()), sHeureLib) ;

				sMessage = string(szDate) + string(" ") + sHeureLib ;
				afficheStatusMessage(&sMessage, true) ;
				break ;
			}

		case pixJour :
			if (scrollCode == SB_LINERIGHT)
			{
				tDateHeureInfDroit.ajouteMois(1) ;
				break ;
			}
			if (scrollCode == SB_LINELEFT)
			{
				tDateHeureInfDroit.ajouteMois(-1) ;
				break ;
			}
			if (scrollCode == SB_PAGERIGHT)
			{
				tDateHeureInfDroit.ajouteAns(1) ;
				break ;
			}
			if (scrollCode == SB_PAGELEFT)
			{
				tDateHeureInfDroit.ajouteAns(-1) ;
				break ;
			}
			if (scrollCode == SB_THUMBPOSITION)
			{
				int iMois = ((float(thumbPos) / 100) * fDen) + (tNaissancePatient.donneAns() * 12 + tNaissancePatient.donneMois()) ;
				int iAnnee = iMois / 12 ;
				iMois = iMois - iAnnee * 12 + 1 ;
				tDateHeureInfDroit = NVLdVTemps(iAnnee, 1, 1, 0, 0, 0) ;
				break ;
			}
			if (scrollCode == SB_THUMBTRACK)
			{
				int iMois = ((float(thumbPos) / 100) * fDen) + (tNaissancePatient.donneAns() * 12 + tNaissancePatient.donneMois()) ;
				int iAnnee = iMois / 12 ;
				iMois = iMois - iAnnee * 12 + 1 ;
				NVLdVTemps tScrollingDateInfDroit = NVLdVTemps(iAnnee, iMois, 1, 0, 0, 0) ; // donne tDateHeureInfDroit
				int iLargeurFenetreEnJours = GetClientRect().Width() ;
				tScrollingDateInfDroit.ajouteJours(-(iLargeurFenetreEnJours / 2)) ;

				string sDate  = tScrollingDateInfDroit.donneDate() ;
				string sHeure = tScrollingDateInfDroit.donneHeure() ;

				char szDate[11] ;
				string sHeureLib ;

				donne_date((char*)(sDate.c_str()), szDate, sLang) ;
				donne_heure((char*)(sHeure.c_str()), sHeureLib) ;

				sMessage = string(szDate) + string(" ") + sHeureLib ;
				afficheStatusMessage(&sMessage, true) ;
				break ;
			}

		case pixSemaine :
		case pixMois :

			if (scrollCode == SB_LINERIGHT)
			{
				tDateHeureInfDroit.ajouteAns(1) ;
				break ;
			}
			if (scrollCode == SB_LINELEFT)
			{
				tDateHeureInfDroit.ajouteAns(-1) ;
				break ;
			}
			if (scrollCode == SB_PAGERIGHT)
			{
				tDateHeureInfDroit.ajouteAns(10) ;
				break ;
			}
			if (scrollCode == SB_PAGELEFT)
			{
				tDateHeureInfDroit.ajouteAns(-10) ;
				break ;
			}
			if (scrollCode == SB_THUMBPOSITION)
			{
				int iMois = ((float(thumbPos) / 100) * fDen) + (tNaissancePatient.donneAns() * 12 + tNaissancePatient.donneMois()) ;
				int iAnnee = iMois / 12 ;
				iMois = iMois - iAnnee * 12 + 1 ;
				tDateHeureInfDroit = NVLdVTemps(iAnnee, 1, 1, 0, 0, 0) ;
				break ;
			}

			break ;
	}
  timeBumper() ;

	if (tDateHeureInfDroit < tCurrentDate)
	{
		float   fNum = float((tDateHeureInfDroit.donneAns() * 12 + tDateHeureInfDroit.donneMois()) - (tNaissancePatient.donneAns() * 12 + tNaissancePatient.donneMois())) ;
		float   fPosition = (fNum / fDen) * 100 ;

		SetScrollPos(SB_HORZ, int(fPosition)) ;
	}
	else
		SetScrollPos(SB_HORZ, 100) ;

	if (scrollCode != SB_THUMBTRACK)
		Invalidate() ;
}
catch (...)
{
	erreur("Exception NSLdvView EvHScroll.", standardError, 0) ;
}
}

LRESULT
NSLdvView::EvMouseWheel(WPARAM wParam, LPARAM lParam)
{
try
{
	// WORD    fwKeys  = LOWORD(wParam);           // key flags
	short   zDelta  = (short) HIWORD(wParam);   // wheel rotation
	// short   xPos    = (short) LOWORD(lParam);   // horizontal position of pointer
	// short   yPos    = (short) HIWORD(lParam);   // vertical position of pointer

	UINT    scrollCode;

	// A positive value indicates that the wheel was rotated forward,
	// away from the user
	if (zDelta > 0)
		scrollCode = SB_LINERIGHT;

	// a negative value indicates that the wheel was rotated backward,
	// toward the user.
	else
		if (zDelta < 0)
			scrollCode = SB_LINELEFT;

	for (int i = 0; i < 4; i++)
		EvHScroll(scrollCode, standardError, 0) ;

    return 0 ;
}
catch (...)
{
	erreur("Exception NSLdvView EvMouseWheel.", standardError, 0) ;
	return 0 ;
}
}

void
NSLdvView::EvKeyDown(uint key, uint repeatCount, uint flags)
{
	if (key == VK_F1)
		CmHelp() ;

	TWindowView::EvKeyDown(key, repeatCount, flags) ;
}

void
NSLdvView::EvSysKeyDown(uint key, uint repeatCount, uint flags)
{
	if (key == VK_F1)
		CmHelp() ;

	TWindowView::EvSysKeyDown(key, repeatCount, flags) ;
}

void
NSLdvView::CmHelp()
{
	pContexte->NavigationAideEnLigne() ;
}

void
NSLdvView::UpdatePixelPerUnitRate(uint)
{
	NSLdvChronoLine* pChronoLine = getLdVChronoLine() ;
  if (NULL == pChronoLine)
		return ;

	int iPpuPos = pChronoLine->getPpuRatePosition() ;
	if (iPpuPos == pCurrentTimeInfo->getUppRate())
		return ;

  if (iPpuPos >= pCurrentTimeInfo->getUpperLimit())
    CmLdvZoomOut() ;
  else
  {
    pCurrentTimeInfo->setUppRate(iPpuPos) ;
    pixelUnitChanged() ;
  }
}

void
NSLdvView::UpdateSeverityThreshold(uint)
{
	NSLdvCommandPannel* pCommandPannel = getLdVCommandPannel() ;
  if (NULL == pCommandPannel)
		return ;

  int iThreshold = pCommandPannel->getSeverityThreshold() ;

	if (iThreshold == _iMinSeverityOfDisplayedConcerns)
		return ;

	_iMinSeverityOfDisplayedConcerns = iThreshold ;

  reinitWorkingAreas() ;

  Invalidate() ;
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

bool
NSLdvView::CanClose()
{
	return true;
}


// -----------------------------------------------------------------------------
// traitement de l'�v�nement g�n�r� par le mouvement de la souris
// -----------------------------------------------------------------------------
// void	NSLdvView::EvMouseMove(unint modKeys, point)
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
/*
void
NSLdvView::EvMouseMove(uint modKeys, NS_CLASSLIB::TPoint& point)
{
try
{
	iNbTimerTicks = 0;

	NS_CLASSLIB::TRect  clientRect = GetClientRect();
	NS_CLASSLIB::TPoint ptOrigine  = clientRect.BottomRight();

	if (bLButtonDown)
		ImgDragDrop->DragMove(point.x, point.y) ;

	if (iMouseMode == modeZoom)
		point.x += GetSystemMetrics(SM_CXCURSOR) / 2 ;

	// Calcul du point click�

	NVLdVPoint pointClick(this);
	pointClick.initialise(&ptOrigine, &point);
	NVLdVTemps tDateHeure = pointClick.getX();

	string sDate  = tDateHeure.donneDate();
	string sHeure = tDateHeure.donneHeure();

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	char szDate[11] ;
	string sHeureLib ;

	donne_date((char*)(sDate.c_str()), szDate, sLang) ;
	donne_heure((char*)(sHeure.c_str()), sHeureLib) ;

	string sMessage = string(szDate) + string(" ") + sHeureLib ;
	afficheStatusMessage(&sMessage, false) ;
}
catch (...)
{
	erreur("Exception NSLdvView EvMouseMove.", standardError, 0) ;
}
}
*/

void		NSLdvView::EvDragDrop()
{
}

// -----------------------------------------------------------------------------
// traitement de l'�v�nement g�n�r� par l'enfoncement du bouton gauche de la
// souris
// -----------------------------------------------------------------------------
// NSLdvView::EvLButtonDown(uint modKeys, point)
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

/*

voidNSLdvView::EvLButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
try
{
	if (iMouseMode == modeZoom)
	{
		CmLdvZoomIn() ;
    return ;
	}

	NSLdvToon *theToon = HitTest(point) ;

	bLButtonDown    = true ;
	pToon2Drag      = theToon ;

	string stheToonLibelle ;

	if      (dynamic_cast<NSConcernView *>(theToon))
	{
  	NSConcernView   *pToon = (NSConcernView *)theToon ;
    stheToonLibelle = pToon->pConcern->sTitre ;
    if (pCurrentConcern != pToon)
    {
    	pCurrentConcern = pToon ;
      Invalidate() ;
    }
	}
  else if (dynamic_cast<NSSsObjView *>(theToon))
  {    NSSsObjView     *pToon = (NSSsObjView *)theToon ;
    stheToonLibelle = pToon->pSsObjet->sTitre ;

    // !!!!!!!!!!!!!!!!!
    // in the sequence :
    // ImgDragDrop->BeginDrag(0, 16, 16) ;
    // "16, 16" is the icon's size (the icon we use in the drag n drop mode)
    // it MUST be change if we want to use another icon (with another size)
    // or another object than an icon
    // this parameter corresponds to the size of the image that is used to
    // follow the cursor in drag n drop mode
    // !!!!!!!!!!!!!!!!!

    ImgDragDrop->BeginDrag(0, 16, 16) ;

    // Attention, pour DragEnter, x et y se r�f�rent � la fen�tre et
    // pas � l'espace client. Au contraire point se r�f�re � l'espace
    // client

    //ClientToScreen(point);
    //NS_CLASSLIB::TRect winRect = Parent->GetWindowRect();
    //ImgDragDrop->DragEnter(*this, point.x - winRect.X(), point.y - winRect.Y()) ;
    ImgDragDrop->DragEnter(*this, point.x, point.y) ;
	}
	else if (dynamic_cast<NSLdvObjetView *>(theToon))
	{
    NSLdvObjetView  *pToon = (NSLdvObjetView *)theToon ;
    stheToonLibelle = pToon->pObjet->sTitre ;

    // !!!!!!!!!!!!!!!!!
    // in the sequence :
    // ImgDragDrop->BeginDrag(1, 16, 16) ;
    // "16, 16" is the icon's size (the icon we use in the drag n drop mode)
    // it MUST be change if we want to use another icon (with another size)
    // or another object than an icon
    // this parameter corresponds to the size of the image that is used to
    // follow the cursor in drag n drop mode
    // !!!!!!!!!!!!!!!!!

    ImgDragDrop->BeginDrag(1, 16, 16) ;

    //ClientToScreen(point);
    //NS_CLASSLIB::TRect winRect = Parent->GetWindowRect();
    //ImgDragDrop->DragEnter(*this, point.x - winRect.X(), point.y - winRect.Y()) ;

    ImgDragDrop->DragEnter(*this, point.x, point.y) ;
	}
}
catch (...)
{
	erreur("Exception NSLdvView EvLButtonDown.", standardError, 0) ;
}
}

*/

// -----------------------------------------------------------------------------
// traitement de l'�v�nement g�n�r� par le relachement du bouton gauche de la
// souris
// -----------------------------------------------------------------------------
// NSLdvView::EvLButtonDown(uint modKeys, point)
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

/*
void
NSLdvView::EvLButtonUp(uint modKeys, NS_CLASSLIB::TPoint& point)
{
try
{
	NSLdvToon *theToon = HitTest(point) ;

	// End of drag and drop - Fin de drag and drop

	if (bLButtonDown)
	{
		// Drop d'un SsObjet sur une pr�occupation
		// Dropping a SubObject on a Health concern
		if (TYPESAFE_DOWNCAST(pToon2Drag, NSSsObjView) && TYPESAFE_DOWNCAST(theToon, NSConcernView))
		{
			NSSsObjView   *pSsObjV = TYPESAFE_DOWNCAST(pToon2Drag, NSSsObjView) ;
			NSConcernView *pPbV    = TYPESAFE_DOWNCAST(theToon,    NSConcernView) ;

			bool bContinue = true ;

			if (pSsObjV->pSsObjet->tDateHeureDebut < pPbV->pConcern->tDateOuverture)
				bContinue = false ;

			if (pSsObjV->pSsObjet->tDateHeureFin > pPbV->pConcern->tDateFermeture)
				bContinue = false ;

			if (bContinue)
			{
				pSsObjV->setConcernView(pPbV) ;
				pSsObjV->pSsObjet->sConcern = pPbV->pConcern->sTitre ;
				NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
				pGraphe->etablirLien(pSsObjV->pSsObjet->sReference, NSRootLink::problemContactElement, pPbV->pConcern->sReference) ;
*/
				/*
				for (SsObjViewIterator ssObjIter = pLdvTankView->pSsObjetTankArray->begin() ; ssObjIter != pLdvTankView->pSsObjetTankArray->end() ; )
				{
					if (*ssObjIter == pSsObjV)
						pLdvTankView->pSsObjetTankArray->erase(ssObjIter) ;
					else
						ssObjIter++ ;
				}
				*/

				// Le "r�servoir" de sous-objets orphelins est remis � jour lors
				// du rafraichissement de l'affichage
/*
				Invalidate(true) ;
			}
		}

		// Drop d'un Objet sur une pr�occupation
		// Dropping an Object on a Health concern
		else
			if (TYPESAFE_DOWNCAST(pToon2Drag, NSLdvObjetView) && TYPESAFE_DOWNCAST(theToon, NSConcernView))
			{
				NSLdvObjetView  *pObjV  = TYPESAFE_DOWNCAST(pToon2Drag, NSLdvObjetView) ;
				NSConcernView   *pPbV   = TYPESAFE_DOWNCAST(theToon, NSConcernView) ;

				bool            bContinue = true ;

				if (pObjV->pObjet->tDateHeureDebut < pPbV->pConcern->tDateOuverture)
					bContinue = false ;

				if (pObjV->pObjet->tDateHeureFin > pPbV->pConcern->tDateFermeture)
					bContinue = false ;

				if (bContinue)
				{
					pObjV->setLigneView((NSLigneView *) pPbV) ;
					pObjV->pObjet->sConcern = pPbV->pConcern->sTitre ;

          VecteurString aVecteurString ;

					NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

          pGraphe->TousLesVraisDocument(pObjV->pObjet->sReference, NSRootLink::problemRelatedTo, &aVecteurString) ;
          if (!aVecteurString.empty())
						pGraphe->detruireTousLesLiensDocument(pObjV->pObjet->sReference, NSRootLink::problemRelatedTo) ;

					pGraphe->etablirLienDocument(pObjV->pObjet->sReference, NSRootLink::problemRelatedTo, pPbV->pConcern->sReference) ;

					pObjV->Box.setTop(pPbV->Box.getTop()) ;
					pObjV->Box.setBottom(pPbV->Box.getBottom()) ;

					Invalidate(true) ;
				}
			}
			// Drop d'un Objet sur la ligne de base
			// Dropping an Object on the base line
			else
				if (TYPESAFE_DOWNCAST(pToon2Drag, NSLdvObjetView) && TYPESAFE_DOWNCAST(theToon, NSBaseLineView))
				{
					NSLdvObjetView  *pObjV  = TYPESAFE_DOWNCAST(pToon2Drag, NSLdvObjetView) ;
					NSBaseLineView  *pPbV   = TYPESAFE_DOWNCAST(theToon, NSBaseLineView) ;

					pObjV->setLigneView((NSLigneView *) pPbV) ;
					pObjV->pObjet->sConcern = "" ;

          VecteurString aVecteurString ;

					NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
          pGraphe->TousLesVraisDocument(pObjV->pObjet->sReference, NSRootLink::problemRelatedTo, &aVecteurString) ;
					if (!aVecteurString.empty())
						pGraphe->detruireTousLesLiensDocument(pObjV->pObjet->sReference, NSRootLink::problemRelatedTo) ;

					pObjV->Box.setTop(pPbV->Box.getTop()) ;
					pObjV->Box.setBottom(pPbV->Box.getBottom()) ;

					Invalidate(true) ;
				}
	}

	bLButtonDown = false ;

	ImgDragDrop->DragLeave(this->GetWindow()->HWindow) ;
	ImgDragDrop->EndDrag() ;

	pToon2Drag = NULL ;
}
catch (...)
{
	erreur("Exception NSLdvView EvLButtonUp.", standardError, 0) ;
}
}
*/

// -----------------------------------------------------------------------------
// traitement de l'�v�nement g�n�r� par l'enfoncement du bouton droit de la
// souris
// -----------------------------------------------------------------------------
// NSLdvView::EvLButtonDown(uint modKeys, point)
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

/*
void
NSLdvView::EvRButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
try
{
	NS_CLASSLIB::TRect  clientRect = GetClientRect();
	NS_CLASSLIB::TPoint ptOrigine  = clientRect.BottomRight();

	currentPoint.initialise(&ptOrigine, &point) ;

  NSLdvChronoLine* pChrono = getLdVChronoLine() ;

	// Click droit dans la partie basse : menu de changement d'�chelle
	if ((NULL != pChrono) && (true == pChrono->Contains(point)))
	{
		OWL::TPopupMenu *zoomMenu = new OWL::TPopupMenu() ;

    string sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "1pixelPerSecond") ;
		zoomMenu->AppendMenu(MF_STRING, CM_LDV_PIXSECOND, sMenuText.c_str()) ;
    sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "1pixelPerMinute") ;
		zoomMenu->AppendMenu(MF_STRING, CM_LDV_PIXMINUTE, sMenuText.c_str()) ;
    sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "1pixelPerHour") ;
		zoomMenu->AppendMenu(MF_STRING, CM_LDV_PIXHOUR,  sMenuText.c_str()) ;
    sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "1pixelPerDay") ;
		zoomMenu->AppendMenu(MF_STRING, CM_LDV_PIXDAY,   sMenuText.c_str()) ;
    sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "1pixelPerWeek") ;
		zoomMenu->AppendMenu(MF_STRING, CM_LDV_PIXWEEK,  sMenuText.c_str()) ;
    sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "1pixelPerMonth") ;
		zoomMenu->AppendMenu(MF_STRING, CM_LDV_PIXMONTH, sMenuText.c_str()) ;

		ClientToScreen(point) ;
		zoomMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point, 0, HWindow) ;
		delete zoomMenu ;

    return ;
	}

	// Click droit dans la partie d'affichage
	else
	{
		if (iMouseMode == modeCursor)
		{
			// begin - add fab
			pCurrentToon = HitTest(point) ;

			NSSsObjView     *pSsObjView = TYPESAFE_DOWNCAST(pCurrentToon, NSSsObjView) ;
			NSConcernView   *pPbView    = TYPESAFE_DOWNCAST(pCurrentToon, NSConcernView) ;
      NSDrugLineView  *pDrugView  = TYPESAFE_DOWNCAST(pCurrentToon, NSDrugLineView) ;

			// Probl�me ou sous-objet
			if (pSsObjView || pPbView)
			{
				if (pSsObjView && (pSsObjView->pConcernView == NULL))
				{
					// on est dans le cas o� c'est un sous-objet affich� dans
					// le r�servoir (en haut � gauche) et qui n'est donc pas
					// encore rattach� � un probl�me. On veut faire en sorte
					// qu'il puisse devenir un probl�me
					try
					{
						string  sConcernCode    = pSsObjView->pSsObjet->sTitre ;
						string  sLibelle        = "" ;
            string  sNewNode        = "" ;

            NSPatPathoArray PptDetails(pContexte) ;

						NSNewConcernDlg* pNPDialog = new NSNewConcernDlg(this, &sNewNode, pContexte, &PptDetails, &sConcernCode, &sLibelle);
						int iExecReturn = pNPDialog->Execute();

						if (iExecReturn == IDOK)
						{
							// pContexte->getPatient()->pDocLdv->getConcerns()->reinit() ;
							string  sConcernTitre = "" ;
							if (sConcernCode != string("�?????"))
								pContexte->getDico()->donneLibelle(this->pLdVDoc->sLangue, &sConcernCode, &sConcernTitre) ;
							else
								sConcernTitre = sLibelle;

							// on ne veut plus detruire le sous objets mais
              // l'inclure au probl�me que l'on vient de creer

              NSConcernView *pLastPbV = 0;

							for (ToonsIter toonIter = aToons.begin() ; toonIter != aToons.end() ; toonIter++)
							{
								NSConcernView   *pPbV = TYPESAFE_DOWNCAST(*toonIter, NSConcernView) ;
								if (pPbV && (pPbV->pConcern->sTitre == sConcernTitre))
									pLastPbV = pPbV;
							}

							if (pLastPbV)
							{
								pSsObjView->setConcernView(pLastPbV) ;
								pSsObjView->pSsObjet->sConcern = pLastPbV->pConcern->sTitre ;
								NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
								pGraphe->etablirLien(pSsObjView->pSsObjet->sReference, NSRootLink::problemContactElement, pLastPbV->pConcern->sReference) ;

								// maintenant on doit supprimer le ssObjView
								// de la LdvTankView et initialiser la box
								// correspondant au ssObj inclus au pb.
								pSsObjView->Box.setTop(pLastPbV->Box.getTop()) ;
								pSsObjView->Box.setBottom(pLastPbV->Box.getBottom()) ;

								// suppression de la LdvTankView
*/
								/*
								for (SsObjViewIterator ssObjIter = pLdvTankView->pSsObjetTankArray->begin() ; ssObjIter != pLdvTankView->pSsObjetTankArray->end() ; )
								{
									if (*ssObjIter == pSsObjView)
										pLdvTankView->pSsObjetTankArray->erase(ssObjIter) ;
									else
										ssObjIter++ ;
								}
								*/
/*
								// Le "r�servoir" de sous-objets orphelins est remis � jour lors
								// du rafraichissement de l'affichage

								Invalidate(true) ;
							}
*/
							/*
							for (ToonsIter toonIter = aToons.begin() ; toonIter != aToons.end() ; )
							{
								if (*toonIter == theToon)
									aToons.erase(toonIter) ;
								else
									toonIter++ ;
							}
							for (SsObjViewIterator ssObjIter = pLdvTankView->pSsObjetTankArray->begin() ; ssObjIter != pLdvTankView->pSsObjetTankArray->end() ; )
							{
								if (*ssObjIter == pSsObjView)
									pLdvTankView->pSsObjetTankArray->erase(ssObjIter) ;
								else
									ssObjIter++ ;
							}
							delete theToon ;

							Invalidate(true) ;
							*/
/*
						}
					}
					catch (...)
					{
						erreur("Exception CmNewPreoccup.", standardError, 0) ;
					}
				}

				// Click droit sur une pr�occupation existante
				if (pPbView)
				{
					try
					{
						OWL::TMenu *menu            = new OWL::TMenu(HINSTANCE(*GetApplication()), TResId(IDM_PREOCCUP));
						OWL::TPopupMenu *popupMenu  = new OWL::TPopupMenu(*menu);

						/*
						OWL::TPopupMenu *menu = new OWL::TPopupMenu();

						if (pContexte->getPatient()->bReadOnly)
						{
							menu->AppendMenu(MF_GRAYED, 0, "Evolution");
							menu->AppendMenu(MF_GRAYED, 0, "Correction");
						}
						else
						{
							menu->AppendMenu(MF_STRING, IDC_EVOL_PREOCCUP, "Evolution");
							menu->AppendMenu(MF_STRING, IDC_CHG_PREOCCUP,  "Correction");
						}
						*/
/*
						ClientToScreen(point) ;
						popupMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point, 0, HWindow) ;
						delete popupMenu ;
            delete menu ;
					}
					catch (...)
					{
						erreur("Exception EvRButtonDown.", standardError, 0) ;
					}
				}
        return ;
			}
      else if (pDrugView)
      {
      	// cr�ation d'un menu popup
				NS_CLASSLIB::TPoint lp = point ;

				OWL::TPopupMenu *menu = new OWL::TPopupMenu() ;

				NSSuper* pSuper = pContexte->getSuperviseur() ;

				string sNewD = pSuper->getText("drugManagement", "newDrug") ;
				string sStop = pSuper->getText("drugManagement", "stopThisDrug") ;
				string sKill = pSuper->getText("drugManagement", "suppresThisDrug") ;
				string sModi = pSuper->getText("drugManagement", "modifyThisDrug") ;
        string sPoso = pSuper->getText("drugManagement", "modifyPosology") ;
				string sRene = pSuper->getText("drugManagement", "renewThisDrug") ;
				string sPres = pSuper->getText("drugManagement", "buildAPrescription") ;
  			string sRigh = pSuper->getText("rightsManagement", "manageRights") ;

				menu->AppendMenu(MF_STRING, CM_DRUG_NEW,    sNewD.c_str()) ;
        menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
        menu->AppendMenu(MF_STRING, CM_DRUG_MODIF_POSO, sPoso.c_str()) ;
				menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
				menu->AppendMenu(MF_STRING, CM_DRUG_STOP,   sStop.c_str()) ;
				menu->AppendMenu(MF_STRING, CM_DRUG_CHANGE, sModi.c_str()) ;
				menu->AppendMenu(MF_STRING, CM_DRUG_RENEW,  sRene.c_str()) ;
        menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
        menu->AppendMenu(MF_STRING, CM_DRUG_DELETE, sKill.c_str()) ;
				menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
  			menu->AppendMenu(MF_STRING, IDC_MANAGE_RIGHTS,  sRigh.c_str()) ;
  			menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
				menu->AppendMenu(MF_STRING, IDC_ORDONNANCE, sPres.c_str()) ;

				ClientToScreen(lp) ;
				menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow) ;
				delete menu ;

        return ;
      }

      // Other cases
      //
      try
      {
      	NS_CLASSLIB::TRect  clientRect = GetClientRect() ;
        NS_CLASSLIB::TPoint ptOrigine  = clientRect.BottomRight() ;

        // Calcul du point click�
        NVLdVPoint pointClick(this) ;
        pointClick.initialise(&ptOrigine, &point) ;

        // On cherche l'�l�ment de plus haut zOrder que touche ce point
        // Looking for the highest zOrder object touching the point

        int  iLevel      = 10000 ;
        int  iFuturLevel = -1 ;
        bool tourner     = true ;
        while (tourner)
        {
        	for (ToonsIter i = aToons.begin(); i != aToons.end(); i++)
          {
          	if ((*i)->iZOrder == iLevel)
            {
            	NSLdvTimeToon* pTimeToon = TYPESAFE_DOWNCAST(*i, NSLdvTimeToon) ;
              if (pTimeToon && pTimeToon->Box.Contains(pointClick))
              {
              	if ((*i)->_bInterceptRButtonDown)
                {
              		(*i)->EvRButtonDown() ;
                	return ;
                }
              }
            }
            else
            {
            	if (((*i)->iZOrder < iLevel) && ((*i)->iZOrder > iFuturLevel))
              	iFuturLevel = (*i)->iZOrder ;
            }
          }
          if (iFuturLevel == -1)
          	tourner = false ;
          else
          {
          	iLevel = iFuturLevel ;
            iFuturLevel = -1 ;
          }
        }

        // Si nous sommes l�, c'est que le click est en dehors de
        // tout objet
        // If we are there, it means that the click is outside any object

        OWL::TPopupMenu *menu = new OWL::TPopupMenu() ;

        string sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "newHealthConcern") ;
        if (pContexte->getPatient()->getReadOnly())
        	menu->AppendMenu(MF_GRAYED, 0, sMenuText.c_str()) ;
        else
        	menu->AppendMenu(MF_STRING, IDC_NEWPREOCCUP, sMenuText.c_str()) ;

        sMenuText = pContexte->getSuperviseur()->getText("drugManagement", "newDrug") ;
        if (pContexte->getPatient()->getReadOnly())
        	menu->AppendMenu(MF_GRAYED, 0, sMenuText.c_str()) ;
        else
        	menu->AppendMenu(MF_STRING, CM_DRUG_NEW, sMenuText.c_str()) ;

        menu->AppendMenu(MF_SEPARATOR, 0, 0) ;

        sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "zoom") + string(" (Ctrl+Z)") ;

        if (iXunit == pixSeconde)
        	menu->AppendMenu(MF_GRAYED, 0, sMenuText.c_str()) ;
        else
        	menu->AppendMenu(MF_STRING, CM_LDV_ZOOMIN, sMenuText.c_str()) ;

        sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "enlarge") + string(" (Ctrl+E)") ;

        if (iXunit == pixMois)
        	menu->AppendMenu(MF_GRAYED, 0, sMenuText.c_str()) ;
        else
        	menu->AppendMenu(MF_STRING, CM_LDV_ZOOMOUT, sMenuText.c_str()) ;

        ClientToScreen(point);
        menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point, 0, HWindow);
        delete menu;
      }
      catch (...)
      {
      	erreur("Exception EvRButtonDown.", standardError, 0) ;
      }
    }

		// Outil zoom : click droit = d�-zoomer
		if (iMouseMode == modeZoom)
			CmLdvZoomOut() ;
	}
}
catch (...)
{
  erreur("Exception NSLdvView EvRButtonDown.", standardError, 0) ;
}
}
*/

// -----------------------------------------------------------------------------
// traitement de l'�v�nement g�n�r� par le double-click du bouton gauche de la
// souris
// -----------------------------------------------------------------------------
// NSLdvView::EvLButtonDown(uint modKeys, point)
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

/*
void
NSLdvView::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
try
{
	if (iMouseMode == modeCursor)
	{
		NSLdvToon       *theToon = HitTest(point) ;

		NSLdvObjetView  *pObjV  = TYPESAFE_DOWNCAST(theToon, NSLdvObjetView) ;
		if (pObjV && pObjV->pObjet)
		{
    	// pLdVDoc->openLdVObject(pObjV->pObjet) ;

    	//
      // On pr�pare l'ouverture de tous les objets � cet endroit
      //
      ArrayOfToons aToons ;
      int          iObjZorder = pObjV->iZOrder ;
      HitTestAll(point, &aToons, iObjZorder, false) ;

      // Pr�caution...
      if (aToons.empty())
      	return ;

      // On fabrique l'array d'objets
      //
      ArrayObjets aObjs(pLdVDoc) ;
      for (ToonsIter i = aToons.begin(); i != aToons.end(); i++)
      {
      	NSLdvObjetView *pTheObjV = TYPESAFE_DOWNCAST(*i, NSLdvObjetView) ;
      	if (pTheObjV && pTheObjV->pObjet)
        	aObjs.push_back(pTheObjV->pObjet) ;
      }

      if (!(aObjs.empty()))
      	pLdVDoc->openLdVObjectsInArray(&aObjs, this) ;

      // Vider l'array de toons sans d�truire les objets
      //
      for (ToonsIter toonIt = aToons.begin(); toonIt != aToons.end(); )
      	aToons.erase(toonIt) ;

      // Vider l'array d'objets sans d�truire les objets
      //
      if (!(aObjs.empty()))
      	for (ArrayObjIter objIt = aObjs.begin(); objIt != aObjs.end(); )
        	aObjs.erase(objIt) ;

      return ;
    }

    NSConcernView  *pCrnV  = TYPESAFE_DOWNCAST(theToon, NSConcernView) ;
		if (pCrnV && pCrnV->pConcern)
    {
    	displayCurvesForBiometricalGoals(pCrnV->pConcern->getNoeud()) ;
    	pCrnV->pConcern->sendActivationEvent() ;
			pLdVDoc->showConcernProperty(pCrnV->pConcern) ;
    	return ;
    }

    NSDrugLineView  *pDrgV  = TYPESAFE_DOWNCAST(theToon, NSDrugLineView) ;
		if (pDrgV && pDrgV->pDrug)
    {
    	displayCurvesForBiometricalGoals(pDrgV->pDrug->getNoeud()) ;
    	pDrgV->pDrug->sendActivationEvent() ;
			pLdVDoc->showDrugProperty(pDrgV->pDrug) ;
    	return ;
    }

    NSBaseLineView  *pBasV  = TYPESAFE_DOWNCAST(theToon, NSBaseLineView) ;
		if (pBasV)
    {
    	pLdVDoc->showConcernProperty(0) ;
      return ;
    }

        // NSBaseLineView
	}
}
catch (...)
{
  erreur("Exception NSLdvView EvLButtonDblClk.", standardError, 0) ;
}
}
*/

//---------------------------------------------------------------------------
//fixer la position de la fiche historique
//---------------------------------------------------------------------------
void
NSLdvView::SetWindowPosLdv()
{
  NSWindowProperty* pWinProp = pContexte->getUtilisateur()->aWinProp.getProperty("LigneDeVie") ;
  if (NULL == pWinProp)
	{
  	SetWindowPosit() ;
    return ;
	}

  Parent->Show(SW_HIDE) ;

  NS_CLASSLIB::TRect rectDlg = Parent->GetWindowRect() ;//coordonn�es par % � l'�cran

  NS_CLASSLIB::TPoint point(rectDlg.X(), rectDlg.Y()) ;
  Parent->Parent->ScreenToClient(point) ;
  int X = rectDlg.X() ;
  int Y = rectDlg.Y() ;
  int W = rectDlg.Width() ;
  int H = rectDlg.Height() ;

  if (pWinProp)
  {
    X = pWinProp->X() ;
    Y = pWinProp->Y() ;
    W = pWinProp->W() ;
    H = pWinProp->H() ;
  }

  //
  // fixer la nouvelle position
  // (on ne tient pas compte de la taille, vu le probleme pour restaurer
  //  une fenetre TView,TWindow mise en icone)
  //
	Parent->SetWindowPos(0, X, Y, W, H, SWP_NOZORDER) ;
  Parent->Show(SW_SHOWNORMAL) ;

  /************************************
  if (sTaille == "I")
      Parent->Show(SW_SHOWMINIMIZED);
  else if (sTaille == "Z")
      Parent->Show(SW_SHOWMAXIMIZED);
  else
      Parent->Show(SW_SHOWNORMAL);
  *************************************/
}

//---------------------------------------------------------------------------
//enregistrer la position de la fiche historique la base UTILISAT.DB
//---------------------------------------------------------------------------
void
NSLdvView::EnregistrePosLdv()
{
	if (!pContexte->getUtilisateur()->bEnregWin)
  	return ;

	NS_CLASSLIB::TRect rectDlg = Parent->GetWindowRect() ;//coordonn�es par % � l'�cran
  int X, Y, W, H ;
  NS_CLASSLIB::TPoint point(rectDlg.X(), rectDlg.Y()) ;
  Parent->Parent->ScreenToClient(point) ;
  X = point.X() ;
  Y = point.Y() ;
  W = rectDlg.Width() ;
  H = rectDlg.Height() ;

	if (Parent->IsIconic())
  	return ;

	string sUserId = pContexte->getUtilisateur()->getNss() ;
	NS_CLASSLIB::TRect  rect(X, Y, X + W, Y + H) ;
  NSWindowProperty wndProp ;
  wndProp.setX(X) ;
  wndProp.setY(Y) ;
  wndProp.setW(W) ;
  wndProp.setH(H) ;
  wndProp.setActivity(NSWindowProperty::undefined) ;
  wndProp.setFunction("LigneDeVie") ;

  pContexte->getUtilisateur()->aWinProp.saveWindowProperty(sUserId, pContexte->PathName("FGLO"), &wndProp, false) ;
  pContexte->getUtilisateur()->aWinProp.saveWindowProperty(sUserId, pContexte->PathName("FGLO"), &wndProp, true) ;
  //pContexte->getUtilisateur()->aWinProp.setProperty(sUserId, "History", rect, pContexte->PathName("FGLO")) ;
}

//
// Deprecated
//
void
NSLdvView::SetWindowPosit()
{
try
{
	string sPosition = pContexte->getSuperviseur()->getEpisodus()->sPosLdV;
	if (sPosition == "")
		return;

	int     X,Y,W,H;
	string  sTaille;
	size_t  debut = 0;
	size_t  positVide = sPosition.find("|");  //cha�ne vide
	int     nbCoords = 0;

	vector<string> Coordonnees;  //contient les coordonn�es sous forme de string

	while (positVide != NPOS)
	{
		Coordonnees.push_back(string(sPosition, debut, positVide - debut));
		nbCoords++;
		debut = positVide + 1;
		positVide = sPosition.find("|", debut+1);
	}
	Coordonnees.push_back(string(sPosition, debut, strlen(sPosition.c_str()) - debut));
	nbCoords++;

	// r�cup�rer les coordonn�es
	vector<string> :: iterator i;
	i = Coordonnees.begin();
	X = StringToDouble(*i);
	i++;
	Y = StringToDouble(*i);
	i++;
	W  = StringToDouble(*i);
	i++;
	H = StringToDouble(*i);

	// cas en icone ou plein ecran
	if (nbCoords > 4)
	{
		i++;
		sTaille = *i;
	}
	else
		sTaille = "N";

	Parent->SetWindowPos(0, X, Y, W, H, SWP_NOZORDER);

	if (sTaille == "I")
		Parent->Show(SW_SHOWMINIMIZED);
	else
		if (sTaille == "Z")
    	Parent->Show(SW_SHOWMAXIMIZED);
    else
        Parent->Show(SW_SHOWNORMAL);
}
catch (...)
{
	erreur("Exception NSLdvView SetWindowPosit.", standardError, 0) ;
}
}

void
NSLdvView::RecordWindowPosit()
{
try
{
	string sPosLigne = pContexte->getSuperviseur()->getEpisodus()->sPosLdV;

	NS_CLASSLIB::TRect rectDlg = Parent->GetWindowRect();//coordonn�es par % � l'�cran
	NS_CLASSLIB::TPoint point(rectDlg.X(), rectDlg.Y());
	Parent->Parent->ScreenToClient(point);
	int X = point.X() ;
	int Y = point.Y() ;
	// int W = rectDlg.Width() ;
	// int H = rectDlg.Height() ;

	double TamponX  = (double)X;
	double TamponY  = (double)Y;
	double TamponW  = (double)rectDlg.Width();
	double TamponH  = (double)rectDlg.Height();
	string sPosition = DoubleToString(&TamponX, 0 , 0)
												+ "|" + DoubleToString(&TamponY, 0 , 0)
												+ "|" + DoubleToString(&TamponW, 0 , 0)
												+ "|" + DoubleToString(&TamponH, 0 , 0);

	// On regarde si la fenetre est en icone ou en plein ecran
	if ((Parent->IsIconic()) || (Parent->IsZoomed()))
	{
		size_t poslast;

		sPosition = sPosLigne;
		poslast = sPosition.find_last_of("|");
		// si le '|' n'est pas le dernier caractere
		if ((poslast != NPOS) && (poslast < (strlen(sPosition.c_str()) - 1)))
		{
			// si la fenetre �tait d�ja en icone ou en zoom :
			// on reprend l'ancienne taille
			if ((sPosition[poslast + 1] == 'I') || (sPosition[poslast + 1] == 'Z'))
				sPosition = string(sPosition, 0, poslast);

			if (Parent->IsIconic())
				sPosition += "|I";
			else
				sPosition += "|Z";
		}
		else
		{
			erreur("Coordonn�e �ronn�e.", standardError, 0, GetHandle());
			// on remet dans ce cas la fenetre a une taille par d�faut
			sPosition = "0|0|100|100";
		}
	}
	pContexte->getSuperviseur()->getEpisodus()->sPosLdV = sPosition;
}
catch (...)
{
	erreur("Exception NSLdvView RecordWindowPosit.", standardError, 0) ;
}
}

void
NSLdvView::reloadView(string sReason, string sReference)
{
  if (true == aToons.empty())
    return ;

  bool bMustReinitView = false ;

  for (ToonsIter toonIter = aToons.begin() ; aToons.end() != toonIter ; toonIter++)
  {
    if (NSLdvToon::toonWorkingArea == (*toonIter)->getType())
    {
      NSLdvViewArea *pWorkArea = TYPESAFE_DOWNCAST(*toonIter, NSLdvViewArea) ;
      if (NULL != pWorkArea)
      {
	      if      (string("DRUG_DELETED") == sReason)
	      {
  	      deleteAllFromToonsArray(pWorkArea->getToonsArray(), NSLdvToon::toonDrug) ;
		      pWorkArea->getToonsArray()->init(pLdVDoc->getDrugs(), pContexte, pWorkArea) ;
        }
        else if (string("DRUG_NEW") == sReason)
  	      bMustReinitView = true ;
      }
    }
  }

  if (bMustReinitView)
    reinit() ;

	Invalidate() ;
}

/*********************************
void
NSLdvView::PerformCreate(int menuOrId)
{
    // pLdVDoc->SetTitle("Ligne de vie Episodus");
}
**************************************/

void
NSLdvView::EvTimer(uint timerId)
{
	if (ID_LDVTIMER != timerId)
		return ;

	THandle hFocused = GetFocus() ;
	if (GetHandle() != hFocused)
		return ;

	iNbTimerTicks++ ;
	if (iNbTimerTicks > 3)
	{
		iNbTimerTicks = 0 ;
		//killTipsTimer();

    NSLdvViewArea* pWorkArea = getActiveWorkingArea() ;
    if (NULL == pWorkArea)
		  pWorkArea->showContextHelp() ;
	}
}

void
NSLdvView::timeBumper()
{
try
{
  NSLdvViewArea* pWorkArea = getActiveWorkingArea() ;
  if (NULL == pWorkArea)
    return ;

  TWindow* pWinWorkArea = pWorkArea->getInterface() ;
  if (NULL == pWinWorkArea)
    return ;

	NS_CLASSLIB::TRect wRect = pWinWorkArea->GetClientRect() ;
	int iWidth = wRect.Width() ;

	string sRootDate = string("19010101000000") ;

  // Don't do this, because the multiplier, as an int, would not be accurate
  //
  // int iMultiplier = pCurrentTimeInfo->getUpperLimit() / (pCurrentTimeInfo->getUpperLimit() - pCurrentTimeInfo->getUppRate()) ;

	// pix/month is the only mode that cannot get mapped into seconds
	//
	if (pixMois == iXunit)
  {
  	unsigned int iWidthInMonth = iWidth * pCurrentTimeInfo->getUpperLimit() / (pCurrentTimeInfo->getUpperLimit() - pCurrentTimeInfo->getUppRate()) ;
    unsigned int iMonthsInfDroit = 12 * (tDateHeureInfDroit.donneAns() - 1901) + tDateHeureInfDroit.donneMois() ;

    if (iWidthInMonth > iMonthsInfDroit)
    {
    	tDateHeureInfDroit.initFromDateHeure(sRootDate) ;
      tDateHeureInfDroit.ajouteMois(iWidthInMonth + 1, true) ;
    }

    return ;
  }

  unsigned long lWidthInSeconds = 0 ;

  switch (iXunit)
	{
		case pixSeconde :
    	lWidthInSeconds = iWidth ;
      break ;
  	case pixMinute :
    	lWidthInSeconds = 60 * iWidth ;
      break ;
    case pixHeure :
    	lWidthInSeconds = 3600 * iWidth ;
      break ;
  	case pixJour :
    	lWidthInSeconds = 24 * 3600 * iWidth ;
      break ;
    case pixSemaine :
    	lWidthInSeconds = 7 * 24 * 3600 * iWidth ;
      break ;
  }

  if ((pCurrentTimeInfo->getUpperLimit() > pCurrentTimeInfo->getUppRate()))
    lWidthInSeconds = lWidthInSeconds * pCurrentTimeInfo->getUpperLimit() / (pCurrentTimeInfo->getUpperLimit() - pCurrentTimeInfo->getUppRate()) ;

	ClassLib::TDate tdDate = ClassLib::TDate(tDateHeureInfDroit.donneJours(), tDateHeureInfDroit.donneMois(), tDateHeureInfDroit.donneAns()) ;
	ClassLib::TTime ttTime = ClassLib::TTime(tdDate, tDateHeureInfDroit.donneHeures(), tDateHeureInfDroit.donneMinutes(), tDateHeureInfDroit.donneSecondes()) ;
	ClockTy nbSecSince19010101 = ttTime.Seconds() ;

	if (lWidthInSeconds > nbSecSince19010101)
	{
		tDateHeureInfDroit.initFromDateHeure(sRootDate) ;
		tDateHeureInfDroit.ajouteSecondes(lWidthInSeconds + 1) ;
	}

	return ;
}
catch (...)
{
	erreur("Exception NSLdvView::timeBumper.", standardError, 0) ;
}
}

void
NSLdvView::pixelUnitChanged()
{
  pCurrentTimeInfo = getTimeZoomInfo(iXunit) ;
  refreshChronoLine() ;
	timeBumper() ;
	Invalidate() ;
}

void
NSLdvView::showMousePositionMessage()
{
/*
	NS_CLASSLIB::TPoint point ;
  GetCursorPos(point) ;

  NS_CLASSLIB::TRect  clientRect = GetClientRect();
  NS_CLASSLIB::TPoint ptOrigine  = clientRect.BottomRight();

  if (iMouseMode == modeZoom)
  	point.x += GetSystemMetrics(SM_CXCURSOR) / 2 ;

  // Calcul du point click�

  NVLdVPoint pointClick(this);
  pointClick.initialise(&ptOrigine, &point);
  NVLdVTemps tDateHeure = pointClick.getX();

  string sDate  = tDateHeure.donneDate();
  string sHeure = tDateHeure.donneHeure();

  char szDate[11];
  string sHeureLib;

  donne_date((char*)(sDate.c_str()),   szDate,  sLang);
  donne_heure((char*)(sHeure.c_str()), sHeureLib);

  string sMessage = string(szDate) + string(" ") + sHeureLib;
  afficheStatusMessage(&sMessage, false);
*/
}

void
NSLdvView::skinSwitchOn(string sSkinName)
{
	// bool bSkinable = false ;

	nsSkin* pSkin = pContexte->getSkins()->donneSkin(sSkinName) ;

	if (pSkin)
	{
  	ClassLib::TColor* pBackColor        = pSkin->getBackColor() ;
    // ClassLib::TColor* pBackTextColor    = pSkin->getFontBackColor() ;
    // ClassLib::TColor* pTextColor        = pSkin->getFontColor() ;

    if (pBackColor)
    {
    	// bSkinable = true ;

      SetBkgndColor(*pBackColor) ;
    }
  }

	/****************************
  if (!bSkinable)
  {
        SetBkgndColor(0x00fff0f0) ; // 0x00bbggrr
  }
  ****************************/

	Invalidate() ;
}

void
NSLdvView::skinSwitchOff(string sSkinName)
{
    bool bSkinable = false ;

    nsSkin* pSkin = pContexte->getSkins()->donneSkin(sSkinName) ;

    if (pSkin)
    {
        ClassLib::TColor* pBackColor        = pSkin->getBackColor() ;
        // ClassLib::TColor* pBackTextColor    = pSkin->getFontBackColor() ;
        // ClassLib::TColor* pTextColor        = pSkin->getFontColor() ;

        if (pBackColor)
        {
            bSkinable = true ;

            SetBkgndColor(*pBackColor) ;
        }
    }

    if (!bSkinable)
    {
        SetBkgndColor(0x00ffffff) ; // 0x00bbggrr
    }

    Invalidate() ;
}

/*
NSLdvToon
*NSLdvView::HitTest(NS_CLASSLIB::TPoint& point)
{
try
{
	NS_CLASSLIB::TRect  clientRect  = GetClientRect();
	NS_CLASSLIB::TPoint ptOrigine   = clientRect.BottomRight();
	NS_CLASSLIB::TPoint ptTemp      = point ;

	NVLdVPoint ldvPoint(this) ;
	ldvPoint.initialise(&ptOrigine, &point) ;

	int             iToonZOrder = -1 ;
	NSLdvToon       *pToon = 0;

	for (ToonsIter theToonsIter = aToons.begin() ; theToonsIter != aToons.end() ; theToonsIter++)
	{
  	NSLdvTimeToon* pTimeToon = TYPESAFE_DOWNCAST(*theToonsIter, NSLdvTimeToon) ;
		if (pTimeToon && (pTimeToon->VisibleBox.Contains(ldvPoint)) &&
				(pTimeToon->iZOrder >= iToonZOrder))
		{
			pToon = *theToonsIter ;
			iToonZOrder = (*theToonsIter)->iZOrder ;
		}
	}

  return (pToon) ;
*/
/*
	// on construit un rectangle autour du point o� se situe le point pass� en
	// param�tre, ce rectangle est en faits un carr� de 32 pixels (2 fois la
	// taille d'un ic�ne) de c�t� dont le point pass� en param�tre est le centre.
	// L'id�e est de tester si ce rectangle � une intersection avec un objet
	// quelconque et de renvoyer cet objet, s'il y a plusieurs objets on
	// retourne le premier objet qui a le ZOrder le plus important.

	// test des dates � une largeur d'ic�ne � gauche, � une largeur d'ic�ne en haut
	ptTemp.x = point.x - ICONWIDTH ;   // les ic�nes font 16 pixels de largeur
	ptTemp.y = point.y + 1 ;   // les ic�nes font 16 pixels de hauteur
	NVLdVPoint  HitTestTopLeft(this) ;
	HitTestTopLeft.initialise(&ptOrigine, &ptTemp) ;

	// test des dates � une largeur d'ic�ne � droite
	ptTemp.x = point.x ;   // les ic�nes font 16 pixels de largeur
	ptTemp.y = point.y - 1 ;   // les ic�nes font 16 pixels de hauteur
	NVLdVPoint  HitTestBotRigh(this) ;
	HitTestBotRigh.initialise(&ptOrigine, &ptTemp) ;

	NVLdVRect   rectHitTest = NVLdVRect(this, HitTestTopLeft.getX(), HitTestBotRigh.getX(), HitTestTopLeft.getY(), HitTestBotRigh.getY()) ;

//	ArrayOfToons    *pToons = new ArrayOfToons() ;
	int             iToonZOrder = -1 ;
	NSLdvToon       *pToon = 0;

	for (ToonsIter theToonsIter = aToons.begin() ; theToonsIter != aToons.end() ; theToonsIter++)
	{
		if (TYPESAFE_DOWNCAST(*theToonsIter, NSBaseLineView))
		{
			NSBaseLineView  *pPbV = TYPESAFE_DOWNCAST(*theToonsIter, NSBaseLineView) ;
			if (pPbV->Box.Touches(rectHitTest))
			{
				if ((*theToonsIter)->iZOrder >= iToonZOrder)
				{
					pToon = *theToonsIter ;
					iToonZOrder = (*theToonsIter)->iZOrder ;
				}
			}
		}
		else
			if (TYPESAFE_DOWNCAST(*theToonsIter, NSConcernView))
			{
				NSConcernView   *pPbV = TYPESAFE_DOWNCAST(*theToonsIter, NSConcernView) ;
				if (pPbV->Box.Touches(rectHitTest))
				{
					if ((*theToonsIter)->iZOrder >= iToonZOrder)
					{
						pToon = *theToonsIter ;
						iToonZOrder = (*theToonsIter)->iZOrder ;
					}
				}
			}
			else
				if (TYPESAFE_DOWNCAST(*theToonsIter, NSLdvObjetView))
				{
					NSLdvObjetView  *pObjV = TYPESAFE_DOWNCAST(*theToonsIter, NSLdvObjetView) ;
					if (pObjV->Box.Touches(rectHitTest))
					{
						if ((*theToonsIter)->iZOrder >= iToonZOrder)
						{
							pToon = *theToonsIter ;
							iToonZOrder = (*theToonsIter)->iZOrder ;						}
					}
	    	}
				else
					if (TYPESAFE_DOWNCAST(*theToonsIter, NSSsObjView))
					{
						NSSsObjView     *pSsObjV = TYPESAFE_DOWNCAST(*theToonsIter, NSSsObjView) ;
						if (pSsObjV->Box.Touches(rectHitTest))
						{
							if ((*theToonsIter)->iZOrder >= iToonZOrder)
							{
								pToon = *theToonsIter ;
        	      iToonZOrder = (*theToonsIter)->iZOrder ;
	            }
  	        }
					}

//	if ((*theToonsIter)->Box.Contains(HitTestPoint))
//	{
//  	if ((*theToonsIter)->iZOrder > iToonZOrder)
//    {
//    	pToon = *theToonsIter ;
//	    iToonZOrder = (*theToonsIter)->iZOrder ;
//  	 }
//	}

	}

	return (pToon) ;
	*/
/*
}
catch (...)
{
	erreur("Exception NSLdvView HitTest.", standardError, 0) ;
    return 0;
}
}
*/

/*
//
// Put in pAToons all toons within that point (with the proper zOrder)
//
void
NSLdvView::HitTestAll(NS_CLASSLIB::TPoint& point, ArrayOfToons* pAToons, int iToonZOrder, bool bResetArray)
{
try
{
    if (!pAToons)
        return ;

    if (bResetArray)
    {
        // Vider l'array sans d�truire les objets
        //
        if (!(pAToons->empty()))
	        for (ToonsIter i = pAToons->begin(); i != pAToons->end(); )
		        pAToons->erase(i);
	}

	NS_CLASSLIB::TRect  clientRect  = GetClientRect();
	NS_CLASSLIB::TPoint ptOrigine   = clientRect.BottomRight();
	NS_CLASSLIB::TPoint ptTemp      = point ;

	NVLdVPoint ldvPoint(this) ;
	ldvPoint.initialise(&ptOrigine, &point) ;

	int             iToonZOrder = -1 ;
	// NSLdvToon       *pToon = 0;

	for (ToonsIter theToonsIter = aToons.begin() ; theToonsIter != aToons.end() ; theToonsIter++)
  {
  	NSLdvTimeToon* pTimeToon = TYPESAFE_DOWNCAST(*theToonsIter, NSLdvTimeToon) ;
		if (pTimeToon && (pTimeToon->VisibleBox.Contains(ldvPoint)) &&
            (((*theToonsIter)->iZOrder == iToonZOrder) || (iToonZOrder == -1)))
		    pAToons->push_back(*theToonsIter) ;
  }

    return ;
}
catch (...)
{
	erreur("Exception NSLdvView HitTestAll.", standardError, 0) ;
	return ;
}
}

NSLdvToon*
NSLdvView::nextHitTest(NS_CLASSLIB::TPoint& point, NSLdvToon* pFormerToon)
{
try
{
	NS_CLASSLIB::TRect  clientRect  = GetClientRect();
	NS_CLASSLIB::TPoint ptOrigine   = clientRect.BottomRight();
	NS_CLASSLIB::TPoint ptTemp      = point ;

	// on construit un rectangle autour du point o� se situe le point pass� en
	// param�tre, ce rectangle est en faits un carr� de 32 pixels (2 fois la
	// taille d'un ic�ne) de c�t� dont le point pass� en param�tre est le centre.
	// L'id�e est de tester si ce rectangle � une intersection avec un objet
	// quelconque et de renvoyer cet objet, s'il y a plusieurs objets on
	// retourne le premier objet qui a le ZOrder le plus important.

	// test des dates � une largeur d'ic�ne � gauche, � une largeur d'ic�ne en haut
	ptTemp.x = point.x - ICONWIDTH ;   // les ic�nes font 16 pixels de largeur
	ptTemp.y = point.y + 1 ;   // les ic�nes font 16 pixels de hauteur
	NVLdVPoint  HitTestTopLeft(this) ;
	HitTestTopLeft.initialise(&ptOrigine, &ptTemp) ;

	// test des dates � une largeur d'ic�ne � droite
	ptTemp.x = point.x ;   // les ic�nes font 16 pixels de largeur
	ptTemp.y = point.y - 1 ;   // les ic�nes font 16 pixels de hauteur
	NVLdVPoint  HitTestBotRigh(this) ;
	HitTestBotRigh.initialise(&ptOrigine, &ptTemp) ;

	NVLdVRect   rectHitTest = NVLdVRect(this, HitTestTopLeft.getX(), HitTestBotRigh.getX(), HitTestTopLeft.getY(), HitTestBotRigh.getY()) ;

//	ArrayOfToons    *pToons = new ArrayOfToons() ;
	int             iToonZOrder = -1 ;
	NSLdvToon       *pToon = 0;

	for (ToonsIter theToonsIter = aToons.begin() ; theToonsIter != aToons.end() ; theToonsIter++)
	{
		if (*theToonsIter == pFormerToon)
			return (pToon) ;

		if (TYPESAFE_DOWNCAST(*theToonsIter, NSBaseLineView))
		{
			NSBaseLineView  *pPbV = TYPESAFE_DOWNCAST(*theToonsIter, NSBaseLineView) ;
			if (pPbV->Box.Touches(rectHitTest))
			{
				if ((*theToonsIter)->iZOrder >= iToonZOrder)
				{
					pToon = *theToonsIter ;
					iToonZOrder = (*theToonsIter)->iZOrder ;
				}
			}
		}

		else
			if (TYPESAFE_DOWNCAST(*theToonsIter, NSConcernView))
			{
				NSConcernView   *pPbV = TYPESAFE_DOWNCAST(*theToonsIter, NSConcernView) ;
				if (pPbV->Box.Touches(rectHitTest))
				{
					if ((*theToonsIter)->iZOrder >= iToonZOrder)
					{
						pToon = *theToonsIter ;
						iToonZOrder = (*theToonsIter)->iZOrder ;
					}
				}
			}

			else
				if (TYPESAFE_DOWNCAST(*theToonsIter, NSLdvObjetView))
				{
					NSLdvObjetView  *pObjV = TYPESAFE_DOWNCAST(*theToonsIter, NSLdvObjetView) ;
					if (pObjV->Box.Touches(rectHitTest))
					{
						if ((*theToonsIter)->iZOrder >= iToonZOrder)
						{
							pToon = *theToonsIter ;
							iToonZOrder = (*theToonsIter)->iZOrder ;
						}
					}
				}

				else
					if (TYPESAFE_DOWNCAST(*theToonsIter, NSSsObjView))
					{
						NSSsObjView     *pSsObjV = TYPESAFE_DOWNCAST(*theToonsIter, NSSsObjView) ;
						if (pSsObjV->Box.Touches(rectHitTest))
						{
							if ((*theToonsIter)->iZOrder >= iToonZOrder)
							{
								pToon = *theToonsIter ;
								iToonZOrder = (*theToonsIter)->iZOrder ;
							}
						}
					}
	}

	return (pToon) ;
}
catch (...)
{
	erreur("Exception NSLdvView nextHitTest.", standardError, 0) ;
	return 0;
}
}
*/

/*
NS_CLASSLIB::TRect
NSLdvView::getServiceAreaMargin()
{
	NS_CLASSLIB::TRect   rectResult = NS_CLASSLIB::TRect(GetClientRect()) ;
	int iLeft   = rectResult.Left() + iLeftServiceAreaMargin ;
	int iRight  = rectResult.Right() - iRightServiceAreaMargin ;
	int iTop    = rectResult.Top() + iTopServiceAreaMargin ;
	int iBottom = rectResult.Bottom() - iBottomServiceAreaMargin ;
	rectResult.Set(iLeft, iTop, iRight, iBottom) ;

	return rectResult ;
}
*/

void
NSLdvView::CmNewPreoccup()
{
try
{
	string sNewNode = string("") ;
  string sCocCode = string("") ;
	NSPatPathoArray pptDetails(pContexte) ;

	NSNewConcernDlg* pNPDialog = new NSNewConcernDlg(this, &sNewNode, pContexte, &pptDetails, &sCocCode) ;
	/* int iExecReturn = */ pNPDialog->Execute() ;

	// if (iExecReturn == IDOK)
	//	pContexte->getPatient()->pDocLdv->getConcerns()->reinit() ;
}
catch (...)
{
	erreur("Exception CmNewPreoccup.", standardError, 0) ;
}
}

void
NSLdvView::CmChgPreoDate(NSConcern* pConcern)
{
try
{
	if (NULL == pConcern)
		return ;

	NVLdVTemps tDeb = pConcern->tDateOuverture ;
	NVLdVTemps tFin = pConcern->tDateFermeture ;

	NSModifConcernDateDlg* pMPDialog =
						new NSModifConcernDateDlg(&tDeb, &tFin, pContexte) ;
	int iExecReturn = pMPDialog->Execute() ;
	if (iExecReturn != IDOK)
		return ;

	if ((tDeb == pConcern->tDateOuverture) &&
			(tFin == pConcern->tDateFermeture))
		return ;


	// Recherche de cette pr�occupation dans l'Array
	// Looking for this health upset in the Array

	if (NULL == pConcern->pDoc)
		return ;

	if (!(tDeb == pConcern->tDateOuverture))
		pConcern->pDoc->changeConcernDateDeb(pConcern, &tDeb) ;

	// Date de fin modifi�e - Ending date has been changed
	if (!(tFin == pConcern->tDateFermeture))
		pConcern->pDoc->changeConcernDateFin(pConcern, &tFin) ;

	pConcern->pDoc->updateIndex() ;

	pContexte->getPatient()->pDocLdv->getConcerns()->reinit() ;

	Invalidate() ;
}
catch (...)
{
	erreur("Exception CmChgPreoDate.", standardError, 0) ;
}
}

void
NSLdvView::CmChgPreoIndx(NSConcern* pConcern, NVLdVTemps tpsTarget)
{
try
{
  if (NULL == pConcern)
		return ;

	if (pConcern->aModificateurs.empty())
		return ;

	ArrayModifierIter iModif = pConcern->aModificateurs.begin() ;
	for (; pConcern->aModificateurs.end() != iModif ; iModif++)
	{
		if (((*iModif)->tDateHeureDeb <= tpsTarget) &&
				((*iModif)->tDateHeureFin >= tpsTarget))
			break;
	}
	if (pConcern->aModificateurs.end() == iModif)
		return ;

	int iS = (*iModif)->iSeverite ;
	int iR = (*iModif)->iRisque ;

	// NSModifConcernIndexDlg* pMPDialog = new NSModifConcernIndexDlg(	&iS, &iR, pContexte);
  NSModifConcernIndexDlg* pMPDialog = new NSModifConcernIndexDlg(&iS, pContexte) ;

	int iExecReturn = pMPDialog->Execute() ;
	if (IDOK != iExecReturn)
		return ;

	if ((iS == (*iModif)->iSeverite) && (iR == (*iModif)->iRisque))
  	return ;

	if (iS == (*iModif)->iSeverite)
		iS = -1 ;
	if (iR == (*iModif)->iRisque)
		iR = -1 ;

	pConcern->pDoc->changeConcernModifier(pConcern, *iModif, iS, iR) ;

	pConcern->pDoc->updateIndex() ;
	Invalidate() ;
}
catch (...)
{
	erreur("Exception CmChgPreoIndx.", standardError, 0) ;
}
}

void
NSLdvView::CmEvolPreoType(NSConcern* pConcern)
{
try
{
  if (NULL == pConcern)
		return ;

  string sFatherNode = pConcern->getNoeud() ;

	string sNewNode = string("") ;
  string sCocCode = string("") ;
	NSPatPathoArray Details(pContexte) ;

	NSNewConcernDlg* pNPDialog = new NSNewConcernDlg(this, &sNewNode, pContexte, &Details, &sCocCode) ;
	int iExecReturn = pNPDialog->Execute() ;
	if (iExecReturn != IDOK)
		return ;

  ArrayConcern* pConcernArray = pLdVDoc->getConcerns() ;
	pConcernArray->reinit() ;

	NSConcern* pFatherConcern = pConcernArray->getConcern(sFatherNode) ;
  NSConcern* pSonConcern    = pConcernArray->getConcern(sNewNode) ;

  pLdVDoc->creeConcernSuite(pFatherConcern, pSonConcern) ;
}
catch (...)
{
	erreur("Exception NSLdvView::CmEvolPreoType.", standardError, 0) ;
}
}

void
NSLdvView::CmAddObjectifs(NSConcern* pConcern)
{
try
{
  if (NULL == pConcern)
		return ;

	if (false == pConcern->isActiveConcern())
	{
		string sErrorText = pContexte->getSuperviseur()->getText("goalsManagement", "inactiveProcedure") ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return ;
	}

	NSLdvGoal* pObjectif = new NSLdvGoal(pContexte) ;

	ObjectifViewerDlg* objDlg = new ObjectifViewerDlg((TWindow*)this, pLdVDoc->pContexte, true, pObjectif) ;
	objDlg->Execute() ;
	delete objDlg ;

	NSPatPathoArray* pPathArray = new NSPatPathoArray(pLdVDoc->pContexte) ;
	pObjectif->setGoalPatho(pPathArray) ;
	delete pObjectif ;

	if (!pPathArray)
		return ;

  // CreeObjectif(NSPatPathoArray *pPatPathoCree, string sDocument, string sRefId, NSPatPathoArray *pPatPathoMotif, string goal = "") ;
	pContexte->getPatient()->CreeObjectif(pPathArray, "", "", "", NULL, pConcern->sReference) ;
	delete pPathArray ;
}
catch (...)
{
	erreur("Exception NSLdvView CmAddObjectifs.", standardError, 0) ;
}
}

void
NSLdvView::CmEvolPreoIndx(NSConcern* pConcern, NVLdVTemps tpsTarget)
{
try
{
  if (NULL == pConcern)
		return ;

	int iS = 10 ;
	int iR = 0 ;
	if (false == pConcern->aModificateurs.empty())
	{
		ArrayModifierIter iModif = pConcern->aModificateurs.begin() ;
		for (; pConcern->aModificateurs.end() != iModif ; iModif++)
			if (((*iModif)->tDateHeureDeb <= tpsTarget) &&
					((*iModif)->tDateHeureFin >= tpsTarget))
				break ;
		if (pConcern->aModificateurs.end() != iModif)
		{
			iS = (*iModif)->iSeverite ;
			iR = (*iModif)->iRisque ;
		}
	}

	NVLdVTemps tDeb ;
  tDeb.takeTime() ;

	NSEvolConcernIndexDlg* pMPDialog =
													new NSEvolConcernIndexDlg(&tDeb, &iS, pContexte) ;
	int iExecReturn = pMPDialog->Execute() ;
	if (iExecReturn != IDOK)
		return ;

	pConcern->pDoc->evolveConcernModifier(pConcern, &tDeb, iS, iR) ;

	Invalidate() ;
}
catch (...)
{
	erreur("Exception NSLdvView CmEvolPreoType.", standardError, 0) ;
}
}

void
NSLdvView::CmSuppressPreo(NSConcern* pConcern)
{
try
{
  if (NULL == pConcern)
		return ;

	pConcern->pDoc->deleteConcern(pConcern) ;

	reinit() ;
	Invalidate() ;
}
catch (...)
{
	erreur("Exception NSLdvView CmSuppressPreo.", standardError, 0) ;
}
}

void
NSLdvView::CmDrugNew()
{
  NSLdvViewArea* pWorkingArea = getActiveWorkingArea() ;
  if (NULL != pWorkingArea)
  {
    TWindow* pWorkInterface = pWorkingArea->getInterface() ;
    if (NULL != pWorkInterface)
    {
      NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pWorkInterface, NSLdvViewAreaWindow) ;
      if (NULL != pWorkWin)
      {
        pWorkWin->CmDrugNew() ;
        return ;
      }
    }
  }

  CmDrugNewForConcern(0) ;
}

void
NSLdvView::CmDrugNewForConcern(NSConcern* pRelatedConcern)
{
	VecteurString aRelatedConcerns ;

	if (NULL != pRelatedConcern)
    aRelatedConcerns.push_back(new string(pRelatedConcern->sReference)) ;

	pLdVDoc->DrugNewService(this, string(""), &aRelatedConcerns) ;
}

void
NSLdvView::CmDrugRenew(NSLdvDrug* pDrug)
{
	if (NULL == pDrug)
		return ;

	string sNodeToAlter = pDrug->getNoeud() ;
  if (string("") != sNodeToAlter)
  	pLdVDoc->DrugRenewService(this, sNodeToAlter) ;
}

void
NSLdvView::CmDrugModify(NSLdvDrug* pDrug)
{
  if (NULL == pDrug)
		return ;

	string sNodeToAlter = pDrug->getNoeud() ;
	if (string("") != sNodeToAlter)
		pLdVDoc->DrugModifyService(this, sNodeToAlter) ;
}

void
NSLdvView::CmDrugChangePoso(NSLdvDrug* pDrug)
{
	if (NULL == pDrug)
		return ;

	pLdVDoc->DrugChangePosoService(this, pDrug) ;
}

void
NSLdvView::CmDrugStop(NSLdvDrug* pDrug)
{
  if (NULL == pDrug)
		return ;

	// string sWarningMsg = pContexte->getSuperviseur()->getText("drugManagementWarnings", "doYouReallyWantToStopThisPrescription") ;

	string sNodeToAlter = pDrug->getNoeud() ;
  if (sNodeToAlter != string(""))
  	pLdVDoc->DrugStopService(this, sNodeToAlter) ;
}

void
NSLdvView::CmDrugDelete(NSLdvDrug* pDrug)
{
  if (NULL == pDrug)
		return ;

	// string sWarningMsg = pContexte->getSuperviseur()->getText("drugManagementWarnings", "doYouReallyWantToDeleteThisPrescription") ;

	string sNodeToAlter = pDrug->getNoeud() ;
  if (sNodeToAlter != string(""))
		pLdVDoc->DrugDeleteService(this, sNodeToAlter) ;
}

void
NSLdvView::CmDrugPrescription()
{
	pLdVDoc->DrugCreatePrescriptionService(this) ;
}

void
NSLdvView::CmManageRights(NSConcern* pConcern)
{
  if (NULL == pConcern)
		return ;

  pLdVDoc->manageRights(this, pConcern->getNoeud()) ;
}

void
NSLdvView::CmManageRights(NSLdvDrug* pDrug)
{
  if (NULL == pDrug)
		return ;

  pLdVDoc->manageRights(this, pDrug->getNoeud()) ;
}

void
NSLdvView::CmNewDrugsFromRefForConcern(NSConcern* pConcern)
{
try
{
  if (NULL == pConcern)
		return ;

  pLdVDoc->DrugSelectProtocolForConcern(this, pConcern->sReference) ;
}
catch (...)
{
	erreur("Exception CmNewDrugsFromRefForConcern.", standardError, 0) ;
}
}

void
NSLdvView::CmNewGoalsFromRefForConcern(NSConcern* pConcern)
{
try
{
  if (NULL == pConcern)
		return ;
}
catch (...)
{
	erreur("Exception CmNewGoalsFromRefForConcern.", standardError, 0) ;
}
}

void
NSLdvView::CmChgPreoccup()
{
try
{
	/*
	OWL::TPopupMenu *menu = new OWL::TPopupMenu();

	menu->AppendMenu(MF_STRING, IDC_EVOL_PREOCCUP, "Type");
	menu->AppendMenu(MF_STRING, IDC_CHG_PREOCCUP,  "Dates");
	menu->AppendMenu(MF_STRING, IDC_CHG_PREOCCUP,  "S�v�rit�");

	ClientToScreen(point);
	menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point, 0, HWindow);
	delete menu;
	*/
}
catch (...)
{
	erreur("Exception CmNewPreoccup.", standardError, 0) ;
}
}

void
NSLdvView::CmChgPreoType(NSConcern* pConcern)
{
try
{
  if (NULL == pConcern)
		return ;

	// Recherche de cette pr�occupation dans l'Array
	// Looking for this health upset in the Array

	if (NULL == pConcern->pDoc)
		return ;

	NSPatPathoArray* pPatho ;
	PatPathoIter iter = pLdVDoc->donnePreoccup(pConcern, &pPatho) ;

	// not found !
	if (NULL == iter)
		return ;

	NSPatPathoInfo noeud = *(*iter) ;

	string sLexique = (*iter)->getLexique() ;

	NSModifConcernTypeDlg* pMPDialog = new NSModifConcernTypeDlg(&noeud, pContexte) ;
	int iExecReturn = pMPDialog->Execute() ;
	if (IDOK != iExecReturn)
		return ;

	if (noeud == *(*iter))
		return ;

	pLdVDoc->changeConcernType(pConcern, &noeud) ;

	Invalidate() ;
}
catch (...)
{
	erreur("Exception NSLdvView CmNewPreoccup.", standardError, 0) ;
}
}

void
NSLdvView::CmEvolPreoccup()
{
try
{
	string sNewNode = string("") ;
  string sCocCode = string("") ;
	NSPatPathoArray Details(pContexte) ;

	NSNewConcernDlg* pNPDialog = new NSNewConcernDlg(this, &sNewNode, pContexte, &Details, &sCocCode) ;
	pNPDialog->Execute() ;

	pContexte->getPatient()->pDocLdv->getConcerns()->reinit() ;
}
catch (...)
{
	erreur("Exception CmNewPreoccup.", standardError, 0) ;
}
}

void
NSLdvView::CmChange2Cursor()
{
	iMouseMode = modeCursor ;
}

void
NSLdvView::CmCursorEnable(TCommandEnabler &ce)
{
	if (iMouseMode == modeCursor)
	{
		ce.SetCheck(TCommandEnabler::Checked) ;
		SetCursor(GetModule(), IDC_ARROW) ;
	}
	else
	{
		ce.SetCheck(TCommandEnabler::Unchecked) ;
		SetCursor(GetModule(), IDC_ZOOMCURSOR) ;
	}
}

void
NSLdvView::CmChange2Zoom()
{
	iMouseMode = modeZoom ;
}

void
NSLdvView::CmZoomEnable(TCommandEnabler &ce)
{
	if (iMouseMode == modeZoom)
	{
		ce.SetCheck(TCommandEnabler::Checked) ;
		SetCursor(GetModule(), IDC_ZOOMCURSOR) ;
	}
	else
	{
		ce.SetCheck(TCommandEnabler::Unchecked) ;
		SetCursor(GetModule(), IDC_ARROW) ;
	}
}

void
NSLdvView::CmLdvZoomIn()
{
try
{
  NSLdvViewArea* pActiveWorkingArea = getActiveWorkingArea() ;
  if (NULL == pActiveWorkingArea)
    return ;
  TWindow* pActiveWorkingWindow = pActiveWorkingArea->getInterface() ;
  if (NULL == pActiveWorkingWindow)
    return ;

	NS_CLASSLIB::TRect  clientRect = GetClientRect() ;
	NS_CLASSLIB::TPoint ptOrigine  = clientRect.BottomRight() ;
	// int                 iLargeurFenetre = clientRect.Width() ;

  // Take care: GetCursorPos is in screen coordinates
  //
	NS_CLASSLIB::TPoint point ;
	GetCursorPos(point) ;

  // Correction, from screen coordinates to Windows coordinates
  //
  pActiveWorkingWindow->ScreenToClient(point) ;

  // ??? don't do this
	// point.x += GetSystemMetrics(SM_CXCURSOR) / 2 ;

	// Calcul du point o� est la souris
	NVLdVPoint pointClick(this) ;
	pointClick.initialise(&ptOrigine, &point, pActiveWorkingArea) ;
	NVLdVTemps tDateHeure = pointClick.getX() ;

  int iDistance2InfDroit = getTimeUnitFromPhysicalWidth(ptOrigine.X() - point.X()) ;

	switch (iXunit)
	{
  	case pixMinute :
			tDateHeure.ajouteSecondes(iDistance2InfDroit) ;
			tDateHeureInfDroit = tDateHeure ;
      CmLdvPixSecond() ;
			break ;

  	case pixHeure :
			tDateHeure.ajouteMinutes(iDistance2InfDroit) ;
			tDateHeureInfDroit = tDateHeure ;
      CmLdvPixMinute() ;
			break ;

		case pixJour :
			tDateHeure.ajouteHeures(iDistance2InfDroit) ;
			tDateHeureInfDroit = tDateHeure ;
      CmLdvPixHour() ;
			break ;

		case pixSemaine :
			tDateHeure.ajouteJours(iDistance2InfDroit) ;
			tDateHeureInfDroit = tDateHeure ;
      CmLdvPixDay() ;
			break ;

		case pixMois :
			tDateHeure.ajouteJours(iDistance2InfDroit * 7) ;
			tDateHeureInfDroit = tDateHeure ;
      CmLdvPixWeek() ;
			break ;
	}
}
catch (...)
{
	erreur("Exception NSLdvView CmLdvZoomIn.", standardError, 0) ;
}
}

void
NSLdvView::CmLdvZoomOut()
{
try
{
  NSLdvViewArea* pActiveWorkingArea = getActiveWorkingArea() ;
  if (NULL == pActiveWorkingArea)
    return ;
  TWindow* pActiveWorkingWindow = pActiveWorkingArea->getInterface() ;
  if (NULL == pActiveWorkingWindow)
    return ;

	NS_CLASSLIB::TRect  clientRect = GetClientRect() ;
	NS_CLASSLIB::TPoint ptOrigine  = clientRect.BottomRight() ;
	// int                 iLargeurFenetre = clientRect.Width() ;

  // Take care: GetCursorPos is in screen coordinates
  //
	NS_CLASSLIB::TPoint point ;
	GetCursorPos(point) ;

  // Correction, from screen coordinates to Windows coordinates
  //
  pActiveWorkingWindow->ScreenToClient(point) ;

  // ??? don't do this
	// point.x += GetSystemMetrics(SM_CXCURSOR) / 2 ;

	// Calcul du point o� est la souris
	NVLdVPoint pointClick(this) ;
	pointClick.initialise(&ptOrigine, &point, pActiveWorkingArea) ;
	NVLdVTemps tDateHeure = pointClick.getX() ;

  int iDistance2InfDroit = getTimeUnitFromPhysicalWidth(ptOrigine.X() - point.X()) ;

	switch (iXunit)
	{
  	case pixSeconde :
			tDateHeure.ajouteMinutes(iDistance2InfDroit) ;
			tDateHeureInfDroit = tDateHeure ;
      CmLdvPixMinute() ;
			break ;

  	case pixMinute :
			tDateHeure.ajouteHeures(iDistance2InfDroit) ;
			tDateHeureInfDroit = tDateHeure ;
      CmLdvPixHour() ;
			break ;

		case pixHeure :
			tDateHeure.ajouteJours(iDistance2InfDroit) ;
			tDateHeureInfDroit = tDateHeure ;
      CmLdvPixDay() ;
			break ;

		case pixJour :
			tDateHeure.ajouteJours(iDistance2InfDroit * 7) ;
			tDateHeureInfDroit = tDateHeure ;
      CmLdvPixWeek() ;
			break ;

		case pixSemaine :
			tDateHeure.ajouteMois(iDistance2InfDroit) ;
			tDateHeureInfDroit = tDateHeure ;
      CmLdvPixMonth() ;
			break ;
	}
}
catch (...)
{
	erreur("Exception NSLdvView CmLdvZoomOut.", standardError, 0) ;
}
}

void
NSLdvView::CmLdvPixSecond()
{
	iXunit = pixSeconde ;
  pixelUnitChanged() ;
}

void
NSLdvView::CmLdvPixMinute()
{
	iXunit = pixMinute ;
  pixelUnitChanged() ;
}

void
NSLdvView::CmLdvPixHour()
{
	iXunit = pixHeure ;
  pixelUnitChanged() ;
}

void
NSLdvView::CmLdvPixDay()
{
	iXunit = pixJour ;
  pixelUnitChanged() ;
}

void
NSLdvView::CmLdvPixWeek()
{
	iXunit = pixSemaine ;
  pixelUnitChanged() ;
}

void
NSLdvView::CmLdvPixMonth()
{
	iXunit = pixMois ;
  pixelUnitChanged() ;
}

void
NSLdvView::handlePixelUnitChange()
{
	if (!(aToons.empty()))
  	for (ToonsIter toonIter = aToons.begin() ; toonIter != aToons.end() ; toonIter++)
    {
    	NSLdvTimeToon* pTimeToon = TYPESAFE_DOWNCAST(*toonIter, NSLdvTimeToon) ;
      if (pTimeToon)
    		pTimeToon->adjustToPixelTimeUnit() ;
    }
}

/*
void
NSLdvView::setZoomLevelInfo()
{
  NSTimeZoomLevel* pTimeZoomInfo = getTimeZoomInfo(iXunit) ;
  if (NULL == pTimeZoomInfo)
    return ;

	iPixelPerUnitRate = pTimeZoomInfo->getUppRate() ;
	iUpperPpuLevel    = pTimeZoomInfo->getUpperLimit() ;
	iLowerPpuLevel    = pTimeZoomInfo->getLowerLimit() ;
}
*/

string
NSLdvView::getLdvPixLexiqueCode()
{
	switch (iXunit)
  {
  	case pixSeconde : return string("2SEC01") ;
    case pixMinute  : return string("2MINU1") ;
    case pixHeure   : return string("2HE001") ;
    case pixJour    : return string("2DAT01") ;
    case pixSemaine : return string("2DAT11") ;
    case pixMois    : return string("2DAT21") ;
    default         : return string("") ;
  }
}

void
NSLdvView::EvSize(uint sizeType, ClassLib::TSize& size)
{
  EvaluateWinToonsPos(this, &aToons) ;
	Invalidate(true) ;
}

// -----------------------------------------------------------------------------
// Lib�ration de la derni�re barre d'outils cr�ee
// -----------------------------------------------------------------------------

void
NSLdvView::EvSetFocus(THandle hWndLostFocus /* may be 0 */)
{
try
{
  TWindowView::EvSetFocus(hWndLostFocus) ;
  // TWindow* pWnd = GetParent() ;
  TMDIChild* pWndChild = TYPESAFE_DOWNCAST(Parent, TMDIChild) ;
  if (NULL != pWndChild)
    pWndChild->BringWindowToTop() ; 

	TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;

	if (bSetupToolBar && (GetWindow() != pMyApp->GetToolBarWindow()))
	{
		SetupToolBar();
		pMyApp->SetToolBarWindow(GetWindow());
	}

	string sViewName = pContexte->getSuperviseur()->getText("LigneDeVieManagement", "ligneDeVie") ;
  Parent->SetCaption(sViewName.c_str()) ;

  pMyApp->setMenu(string("menubar"), &hAccelerator) ;

	pContexte->setAideIndex(pContexte->getSuperviseur()->getText("help", "helpLDVindex"));
	pContexte->setAideCorps(pContexte->getSuperviseur()->getText("help", "helpLDV")) ;
}
catch (...)
{
	erreur("Exception NSLdvView EvSetFocus.", standardError, 0) ;
}
}

void
NSLdvView::SetupToolBar()
{
try
{
	TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;
	pMyApp->FlushControlBar();

	pMyApp->cb2->Insert(*new TButtonGadget(IDI_LDVCURS16, IDI_LDVCURS16, TButtonGadget::Command));
	pMyApp->cb2->Insert(*new TButtonGadget(IDI_LDVZOOM16, IDI_LDVZOOM16, TButtonGadget::Command));

	pMyApp->cb2->LayoutSession();
}
catch (...)
{
	erreur("Exception NSLdvView SetupToolBar.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// fermeture du document :
// L'historique est averti de la fermeture par le destructeur du document
// car lorsque la derniere vue se ferme, cela tue le document.
// -----------------------------------------------------------------------------

void
NSLdvView::EvClose()
{
	TWindow::EvClose();
}

void
NSLdvView::EvDestroy()
{
	EnregistrePosLdv() ;
	// if (pContexte->getSuperviseur()->getEpisodus()->bAutoSave)
	//	RecordWindowPosit();
}

bool
NSLdvView::EvQueryEndSession()
{
	return TWindow::EvQueryEndSession() ;
}

void
NSLdvView::refreshChronoLine()
{
  NSLdvChronoLine* pChrono = getLdVChronoLine() ;
  if (NULL == pChrono)
    return ;

  pChrono->unitChanging() ;
  pChrono->refresh() ;
  pChrono->unitChanged() ;
}

//
// If iPixelPerUnitRate = 1, there is a 1 pixel to 1 time unit ratio
//                           for example, 1 pixel = 1 month in px/month mode
//
// If iPixelPerUnitRate > 1, the principle is to have the above graduation
//                           get step by step reduced: by example, in pix/hour
//                           mode, a day is 24 pixel width ; it will become
//                           23 pixels wide, then 22, etc, until it becomes
//                           just 1 pixel wide, and the system switches to
//                           the pix/week mode
//
// physicalPoint.x = actual number of pixels
// ldvRect.Width() = number of time units
//
// In px/hour mode, 24 hours should be 24 pixels, but become 24 - iPixelPerUnitRate pixels
// so, x pixels become x * (24 - iPixelPerUnitRate) / 24

/*
int
NSLdvView::getPhysicalWidthFromTimeUnit(int iTimeUnitCount)
{
  if ((pCurrentTimeInfo->getUppRate() == 0) || (pCurrentTimeInfo->getUpperLimit() == 0))
    return iTimeUnitCount ;

  return iTimeUnitCount * (pCurrentTimeInfo->getUpperLimit() - pCurrentTimeInfo->getUppRate()) / pCurrentTimeInfo->getUpperLimit() ;
}

int
NSLdvView::getTimeUnitFromPhysicalWidth(int iPhysicalWidth)
{
  if ((pCurrentTimeInfo->getUppRate() == 0) || (pCurrentTimeInfo->getUpperLimit() == pCurrentTimeInfo->getUppRate()))
    return iPhysicalWidth ;

  return iPhysicalWidth * pCurrentTimeInfo->getUpperLimit() / (pCurrentTimeInfo->getUpperLimit() - pCurrentTimeInfo->getUppRate()) ;
}
*/

NSTimeZoomLevel*
NSLdvView::getTimeZoomInfo(pixUnit iU)
{
  if (aZoomLevels.empty())
		return 0 ;

  NSTimeZoomLevelIter zoomLevelIt = aZoomLevels.begin() ;
  for ( ; (aZoomLevels.end() != zoomLevelIt) && ((*zoomLevelIt)->getPixUnit() != iU) ; zoomLevelIt++) ;
  if (aZoomLevels.end() != zoomLevelIt)
    return *zoomLevelIt ;

  return 0 ;
}

// -----------------------------------------------------------------------------
//  Function: NSRefVue::Paint(TDC& dc, bool, TRect& RectAPeindre)
//
//  Arguments:   dc 				: device contexte de la fen�tre
//					  RectAPeindre : Rectangle � repeindre
//
//  Description: Peint/repeint tout/une partie de la fen�tre
//
//  Returns:	  Rien
// -----------------------------------------------------------------------------

void
NSLdvView::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectAPeindre)
{
	showMousePositionMessage() ;

/*
	if (aToons.empty())
		return ;

	int iAncDC = dc.SaveDC() ;

	NS_CLASSLIB::TRect  clientRect = GetClientRect() ;//this->getServiceAreaMargin() ;
	NS_CLASSLIB::TPoint ptOrigine  = clientRect.BottomRight() ;

	// Calcul du "rectangle" � repeindre

	NVLdVRect rectARepeindre(this) ;
	rectARepeindre.initialise(&ptOrigine, &RectAPeindre) ;

	// drawSpecialDates(&dc, &rectARepeindre) ;

	// On demande aux �l�ments qui ont une partie dans ce rectangle de
	// se repeindre, dans l'ordre de leur zOrder
	//
	// Asking each and every element touching that rectangle to redraw,
	// following their zOrder

	int  iLevel      = 0 ;
	int  iFuturLevel = 10000 ;
	bool tourner     = true ;
	while (tourner)
	{
		for (ToonsIter i = aToons.begin(); i != aToons.end(); i++)
		{
			if ((*i)->iZOrder == iLevel)
			{
      	NSLdvTimeToon* pTimeToon = TYPESAFE_DOWNCAST(*i, NSLdvTimeToon) ;

				if (pTimeToon && pTimeToon->bVisible && pTimeToon->Box.Touches(rectARepeindre))
        {
        	if ((_bDisplayDrugs || ((*i)->toonType != NSLdvToon::toonDrug)) &&
              (_bDisplayGoals || ((*i)->toonType != NSLdvToon::toonGoal)) &&
              ((-1 == _iMinSeverityOfDisplayedConcerns) || ((*i)->toonType != NSLdvToon::toonConcern) || ((NULL != dynamic_cast<NSConcernView *>(*i)) && (NULL != (dynamic_cast<NSConcernView *>(*i))->pConcern) && ((dynamic_cast<NSConcernView *>(*i))->pConcern->getMaxSeverityIndex() > _iMinSeverityOfDisplayedConcerns)))
             )
						(*i)->draw(&dc, &rectARepeindre) ;
        }
        else
        {
        	NSLdvWindowToon* pWinToon = TYPESAFE_DOWNCAST(*i, NSLdvWindowToon) ;
					// if (pWinToon && pWinToon->bVisible && (pWinToon->Touches(RectAPeindre)))
					// 	(*i)->draw(&dc, &rectARepeindre) ;
        }
			}
			else
			{
				if (((*i)->iZOrder > iLevel) && ((*i)->iZOrder < iFuturLevel))
					iFuturLevel = (*i)->iZOrder;
			}
		}
		if (iFuturLevel == 10000)
			tourner = false;
		else
		{
			iLevel = iFuturLevel;
			iFuturLevel = 10000;
		}
	}

	// Affichage des sous-�l�ments de contacts en attente
	pLdvTankView->affiche(&dc, RectAPeindre) ;

	dc.RestoreDC(iAncDC);
*/
}

/*
void
NSLdvView::calculRectangleGlobal()
{
	NVLdVTemps  tDateMin, tDateMax;
	long        lHauMin, lHaumax;

	NVLdVTemps tDebut;
	tDebut.takeTime();

	NVLdVTemps tFin;
	tFin.takeTime();

	long lPlancher = 0;
	long lPlafond  = 0;
	lHauMin  = 0;
	lHaumax  = 0;

	if (!(aToons.empty()))
	{
		ToonsIter i = aToons.begin();
		for (; i != aToons.end(); i++)
		{
    	NSLdvTimeToon* pTimeToon = TYPESAFE_DOWNCAST(*i, NSLdvTimeToon) ;
      if (pTimeToon)
				pTimeToon->donneRectangle(&tDateMin, &tDateMax, &lHauMin, &lHaumax) ;

			if (tDateMin < tDebut)
				tDebut = tDateMin ;
			if (tDateMax > tFin)
				tFin = tDateMax ;

			if (lHauMin < lPlancher)
				lPlancher = lHauMin ;
			if (lHaumax > lPlafond)
				lPlafond = lHaumax ;
		}
	}
	GlobalBox.initialise(tDebut, tFin, lPlafond, lPlancher) ;
}
*/

void
NSLdvView::EvaluateWinToonsPos(TWindow* pWindow, ArrayOfToons* pToons)
{
  if ((NULL == pWindow) || (NULL == pToons) || (pToons->empty()))
    return ;

  NS_CLASSLIB::TRect  clientRect = pWindow->GetClientRect() ;
	NS_CLASSLIB::TPoint ptOrigine  = clientRect.BottomRight() ;

  WinToonsVector aWinToons ;

  // First step : unset them all
  //
  int iUnsetToonsNb = 0 ;
  for (ToonsIter i = pToons->begin() ; pToons->end() != i ; i++)
  {
    NSLdvWindowToon* pWinToon = TYPESAFE_DOWNCAST(*i, NSLdvWindowToon) ;
    if (NULL != pWinToon)
    {
      aWinToons.push_back(pWinToon) ;
      pWinToon->resetPos() ;
      iUnsetToonsNb++ ;
    }
  }

  if (aWinToons.empty())
    return ;

  // All the basic coordinates are based on LdvView, the coordinates inside
  // parent are estimated afterward
  //
  bool bNothingNew = false ;

  while (false == bNothingNew)
	{
    bNothingNew = true ;

		for (WinToonsIterator i = aWinToons.begin() ; aWinToons.end() != i ; i++)
		{
      if ((false == (*i)->isPosValid()) && (string("") != (*i)->sSkinName))
      {
        nsBoxPosition* pBoxPos = 0 ;

        nsSkin* pSkin = pContexte->getSkins()->donneSkin((*i)->sSkinName) ;
        if (NULL != pSkin)
          pBoxPos = pSkin->getBoxPosition() ;

        if (NULL != pBoxPos)
        {
          // Evaluate right and left (don't forget that: |<- +Left- -Right+ -> |)
          //
          if (false == (*i)->isLeftSet())
          {
            //
            //
            if ((string("") != pBoxPos->getLeftUnit()) && (string(FOCUS_AUTO) != pBoxPos->getLeftUnit()))
            {
              int iRefPosit = 0 ;
              if (getRelativeValue(&iRefPosit, pWindow, *i, pBoxPos->getLeftPosRef(), string(VIEW_LEFT)))
              {
                (*i)->setLeftValue(iRefPosit + pBoxPos->getLeftValue()) ;
                (*i)->setLeftSet(true) ;
                bNothingNew = false ;

                (*i)->calculateWidthValue() ;
              }
            }
          }
          if (false == (*i)->isRightSet())
          {
            //
            //
            if ((string("") != pBoxPos->getRightUnit()) && (string(FOCUS_AUTO) != pBoxPos->getRightUnit()))
            {
              int iRefPosit = 0 ;
              if (getRelativeValue(&iRefPosit, pWindow, *i, pBoxPos->getRightPosRef(), string(VIEW_RIGHT)))
              {
                (*i)->setRightValue(iRefPosit - pBoxPos->getRightValue()) ;
                (*i)->setRightSet(true) ;
                bNothingNew = false ;

                (*i)->calculateWidthValue() ;
              }
            }
          }
          //
          // Try again, using specs on Width
          //
          if (false == (*i)->isLeftSet())
          {
            (*i)->calculateLeftValue() ;

            if (true == (*i)->isLeftSet())
              bNothingNew = false ;
          }
          if (false == (*i)->isRightSet())
          {
            (*i)->calculateRightValue() ;

            if (true == (*i)->isRightSet())
              bNothingNew = false ;
          }
          //                                             ___            -
          // Evaluate top and bottom  don't forget that:  ^  +     | Bottom
          //                                              | Top    V    +
          //                                                 -    ___
          if (false == (*i)->isBottomSet())
          {
            //
            //
            if ((string("") != pBoxPos->getBottomUnit()) && (string(FOCUS_AUTO) != pBoxPos->getBottomUnit()))
            {
              int iRefPosit = 0 ;
              if (getRelativeValue(&iRefPosit, pWindow, *i, pBoxPos->getBottomPosRef(), string(VIEW_BOTTOM)))
              {
                (*i)->setBottomValue(iRefPosit + pBoxPos->getBottomValue()) ;
                (*i)->setBottomSet(true) ;
                bNothingNew = false ;

                (*i)->calculateHeightValue() ;
              }
            }
          }
          if (false == (*i)->isTopSet())
          {
            //
            //
            if ((string("") != pBoxPos->getTopUnit()) && (string(FOCUS_AUTO) != pBoxPos->getTopUnit()))
            {
              int iRefPosit = 0 ;
              if (getRelativeValue(&iRefPosit, pWindow, *i, pBoxPos->getTopPosRef(), string(VIEW_TOP)))
              {
                (*i)->setTopValue(iRefPosit - pBoxPos->getTopValue()) ;
                (*i)->setTopSet(true) ;
                bNothingNew = false ;

                (*i)->calculateHeightValue() ;
              }
            }
          }
          //
          // Try again, using specs on Height
          //
          if (false == (*i)->isTopSet())
          {
            (*i)->calculateTopValue() ;

            if (true == (*i)->isTopSet())
              bNothingNew = false ;
          }
          if (false == (*i)->isBottomSet())
          {
            (*i)->calculateBottomValue() ;

            if (true == (*i)->isBottomSet())
              bNothingNew = false ;
          }
        }
      }
		}
	}

  // Assign their relative position to windows (position inside parent)
  //
  for (WinToonsIterator i = aWinToons.begin() ; aWinToons.end() != i ; i++)
    (*i)->MoveWindow(true) ;

  // Iterate
  //
  for (WinToonsIterator i = aWinToons.begin() ; aWinToons.end() != i ; i++)
    (*i)->EvaluateWinToonsPos() ;
}

bool
NSLdvView::getRelativeValue(int* piNewValue, TWindow* pRefWindow, NSLdvWindowToon* pToon, string sReference, string sDirection)
{
  if ((NULL == piNewValue) || (NULL == pToon))
    return false ;

  string sRefName      = string("") ;
  string sRefDirection = string("") ;

  getReferenceAndDirection(sReference, sDirection, &sRefName, &sRefDirection) ;

  if ((string("") == sRefName) || (string("") == sRefDirection))
    return false ;

  // Reference is the LdvView
  //
  if ((string(REF_WINDOW) == sRefName) ||
      ((string(REF_PARENT) == sRefName) && (NULL == pToon->getToonParent())))
  {
    if ((VIEW_LEFT == sRefDirection) || (VIEW_BOTTOM == sRefDirection))
    {
      *piNewValue = 0 ;
      return true ;
    }

    if ((NULL == pRefWindow) || (false == pRefWindow->IsWindow()))
      return false ;

    NS_CLASSLIB::TRect wRect = pRefWindow->GetClientRect() ;

    if (VIEW_RIGHT == sRefDirection)
    {
      *piNewValue = wRect.Width() ;
      return true ;
    }
    if (VIEW_TOP == sRefDirection)
    {
      *piNewValue = wRect.Height() ;
      return true ;
    }
    if (VIEW_HMIDDLE == sRefDirection)
    {
      *piNewValue = wRect.Width() / 2 ;
      return true ;
    }
    if (VIEW_VMIDDLE == sRefDirection)
    {
      *piNewValue = wRect.Height() / 2 ;
      return true ;
    }

    return false ;
  }

  // Reference is the parent
  //
  if (string(REF_PARENT) == sRefName)
  {
    NSLdvWindowToon* pParent = pToon->getToonParent() ;

    if (VIEW_LEFT == sRefDirection)
    {
      if (pParent->isLeftSet())
      {
        *piNewValue = pParent->getLeftValue() ;
        return true ;
      }
      return false ;
    }
    if (VIEW_BOTTOM == sRefDirection)
    {
      if (pParent->isBottomSet())
      {
        *piNewValue = pParent->getBottomValue() ;
        return true ;
      }
      return false ;
    }
    if (VIEW_RIGHT == sRefDirection)
    {
      if (pParent->isRightSet())
      {
        *piNewValue = pParent->getRightValue() ;
        return true ;
      }
      return false ;
    }
    if (VIEW_TOP == sRefDirection)
    {
      if (pParent->isTopSet())
      {
        *piNewValue = pParent->getTopValue() ;
        return true ;
      }
      return false ;
    }
    if (VIEW_HMIDDLE == sRefDirection)
    {
      if (pParent->isRightSet() && pParent->isLeftSet())
      {
        *piNewValue = (pParent->getRightValue() - pParent->getLeftValue()) / 2 ;
        return true ;
      }
      return false ;
    }
    if (VIEW_VMIDDLE == sRefDirection)
    {
      if (pParent->isTopSet() && pParent->isBottomSet())
      {
        *piNewValue = (pParent->getTopValue() - pParent->getBottomValue()) / 2 ;
        return true ;
      }
      return false ;
    }
  }

  return false ;
}

void
NSLdvView::getReferenceAndDirection(string sReferenceString, string sNeededDirection, string* psReference, string* psDirection)
{
  if ((NULL == psReference) && (NULL == psDirection))
    return ;

  // Parent is the default reference
  //
  string sRefName      = string(REF_PARENT) ;
  //
  // The provided direction is the default direction
  //
  string sRefDirection = sNeededDirection ;

  if (string("") != sReferenceString)
  {
    size_t iPos = sReferenceString.find(':') ;
    if (iPos != NPOS)
    {
      // Only direction is specified
      //
      if (0 == iPos)
        sRefDirection = string(sReferenceString, 1, strlen(sReferenceString.c_str()) - 1) ;
      //
      // Only reference window is specified
      //
      else if (strlen(sReferenceString.c_str()) - 1 == iPos)
        sRefName = string(sReferenceString, 0, iPos) ;
      //
      // Both are defined
      //
      else
      {
        sRefName      = string(sReferenceString, 0, iPos) ;
        sRefDirection = string(sReferenceString, iPos+1, strlen(sReferenceString.c_str())-iPos-1) ;
      }
    }
    else
      sRefName = sReferenceString ;
  }
  strip(sRefName, stripBoth) ;
  strip(sRefDirection, stripBoth) ;

  sRefName      = pseumaj(sRefName) ;
  sRefDirection = pseumaj(sRefDirection) ;

  if (NULL != psReference)
    *psReference = sRefName ;
  if (NULL != psDirection)
    *psDirection = sRefDirection ;

  return ;
}

void
NSLdvView::addToToonsArray(ArrayOfToons* pToonsArray, NSLdvToon* pToon)
{
  if ((NULL == pToonsArray) || (NULL == pToon))
		return ;

	pToonsArray->push_back(pToon) ;
}

bool
NSLdvView::removeFromToonsArray(ArrayOfToons* pToonsArray, NSLdvToon* pToon)
{
	if ((NULL == pToonsArray) || (NULL == pToon) || pToonsArray->empty())
		return false ;

  ToonsIter tIt = pToonsArray->begin() ;
	for (; (pToonsArray->end() != tIt) && (*tIt != pToon); tIt++) ;

  if (pToonsArray->end() == tIt)
  	return false ;

  pToonsArray->erase(tIt) ;

  return true ;
}

void
NSLdvView::deleteAllFromToonsArray(ArrayOfToons* pToonsArray, NSLdvToon::TOONTYPE tType)
{
	if ((NULL == pToonsArray) || pToonsArray->empty())
		return ;

	for (ToonsIter tIt = pToonsArray->begin() ; pToonsArray->end() != tIt ; )
  {
  	if ((*tIt)->getType() == tType)
    {
    	delete *tIt ;
    	pToonsArray->erase(tIt) ;
    }
    else
    	tIt++ ;
  }
}

NSLdvTimeToon*
NSLdvView::getLdVTimeToon(ArrayOfToons* pToonsArray, NSLdvToon::TOONTYPE tType)
{
	NSLdvToon* pToon = getLdVToon(pToonsArray, tType) ;

  if (NULL == pToon)
  	return NULL ;

	NSLdvTimeToon* pTimeToon = TYPESAFE_DOWNCAST(pToon, NSLdvTimeToon) ;
  return pTimeToon ;
}

NSLdvWindowToon*
NSLdvView::getLdVWinToon(ArrayOfToons* pToonsArray, NSLdvToon::TOONTYPE tType)
{
	NSLdvToon* pToon = getLdVToon(pToonsArray, tType) ;

  if (NULL == pToon)
  	return NULL ;

	NSLdvWindowToon* pTimeToon = TYPESAFE_DOWNCAST(pToon, NSLdvWindowToon) ;
  return pTimeToon ;
}

NSLdvToon*
NSLdvView::getLdVToon(ArrayOfToons* pToonsArray, NSLdvToon::TOONTYPE tType)
{
	if ((NULL == pToonsArray) || pToonsArray->empty())
		return NULL ;

	for (ToonsIter it = pToonsArray->begin(); pToonsArray->end() != it ; it++)
  	if ((*it)->toonType == tType)
    	return *it ;

	return NULL ;
}

NSLdvChronoLine*
NSLdvView::getLdVChronoLine()
{
	NSLdvWindowToon* pWinToon = getLdVWinToon(&aToons, NSLdvToon::toonChronoLine) ;
  if (NULL == pWinToon)
  	return NULL ;

	NSLdvChronoLine* pChronoLine = TYPESAFE_DOWNCAST(pWinToon, NSLdvChronoLine) ;
  return pChronoLine ;
}

NSLdvCommandPannel*
NSLdvView::getLdVCommandPannel()
{
	NSLdvWindowToon* pWinToon = getLdVWinToon(&aToons, NSLdvToon::toonPannel) ;
  if (NULL == pWinToon)
  	return NULL ;

	NSLdvCommandPannel* pCmdPannel = TYPESAFE_DOWNCAST(pWinToon, NSLdvCommandPannel) ;
  return pCmdPannel ;
}

NSLdvViewArea*
NSLdvView::getActiveWorkingArea()
{
  NSLdvWindowToon* pWinToon = getLdVWinToon(&aToons, NSLdvToon::toonWorkingArea) ;
  if (NULL == pWinToon)
  	return NULL ;

	NSLdvViewArea* pWorkingArea = TYPESAFE_DOWNCAST(pWinToon, NSLdvViewArea) ;
  return pWorkingArea ;
}

/*

int
NSLdvView::getPixelPosAboveChronoline(int iYPos)
{
	//
  // Return a point above ChronoLine and above Base Line
  //
  NSLdvChronoLine*   pChrono = getLdVChronoLine() ;
  NS_CLASSLIB::TRect vBox    = pChrono->donneVisibleRectangle() ;

	// return iYPos + iLargeurChronoLine ;
  return iYPos + vBox.Height() ;
}

int
NSLdvView::getPixelPosAboveBaseline(int iYPos)
{
	//
  // Return a point above ChronoLine and above Base Line
  //
	return getPixelPosAboveChronoline(iYPos) + iLargeurBaseline + iInterligne ;
}

NS_CLASSLIB::TRect
NSLdvView::getClientRectAboveChronoline()
{
	NS_CLASSLIB::TRect clientRect = GetClientRect() ;

  int iBottom = getPixelPosAboveChronoline(0) ;

  int iCommandPannelHeight = rectDateTimeArea.Height() ;
	NSLdvWindowToon* pPannel = getLdVWinToon(NSLdvToon::toonPannel) ;
  if (pPannel)
  	iCommandPannelHeight = pPannel->donneVisibleRectangle().Height() ;

  int iTop   = clientRect.Height() - iCommandPannelHeight ;
  int iLeft  = 0 ;
  int iRight = clientRect.Width() ;

  NSLdvWindowToon* pLdvWinToon = getLdVWinToon(NSLdvToon::toonYAxis) ;
  if (NULL != pLdvWinToon)
  	// iLeft += pLdvWinToon->wVisibleBox.Width() ;
    iLeft += pLdvWinToon->donneVisibleRectangle().Width() ;

  return NS_CLASSLIB::TRect(iLeft, iBottom, iRight, iTop) ;
}

NS_CLASSLIB::TRect
NSLdvView::getClientRectAboveBaseline()
{
	NS_CLASSLIB::TRect cR = getClientRectAboveChronoline() ;
  return NS_CLASSLIB::TRect(cR.Left(), getPixelPosAboveBaseline(0), cR.Right(), cR.Bottom()) ;
}

int
NSLdvView::getProccupGrossHeight()
{
	return iLargeurLigne + iInterligne ;
}

long
NSLdvView::preoccupDonneBottomBox(int iIndex)
{
	// Memo : Preoccup 1 -> iIndex == 0
	return (getPixelPosAboveBaseline(0) + iIndex * getProccupGrossHeight()) ;
}

long
NSLdvView::preoccupDonneTopBox(int iIndex)
{
	// Memo : Preoccup 1 -> iIndex == 0
	return preoccupDonneBottomBox(iIndex) + getProccupGrossHeight() ;
}

long
NSLdvView::preoccupDonneBottomLine(int iIndex)
{
	// Memo : Preoccup 1 -> iIndex == 0
	return (getPixelPosAboveBaseline(0) + iIndex * getProccupGrossHeight()) ;
}

long
NSLdvView::preoccupDonneTopLine(int iIndex)
{
	// Memo : Preoccup 1 -> iIndex == 0
	return (preoccupDonneBottomLine(iIndex) + iLargeurLigne) ;
}

int
NSLdvView::getGoalBasePosition()
{
	return (preoccupDonneTopBox(_iMaxConcernIndex) + iInterligne) ;
}

int
NSLdvView::getGoalGrossHeight()
{
	return iLargeurSubLigne + iInterligne ;
}

long
NSLdvView::goalDonneBottomBox(int iIndex)
{
	return (getGoalBasePosition() + iIndex * getGoalGrossHeight()) ;
}

long
NSLdvView::goalDonneTopBox(int iIndex)
{
	return (goalDonneBottomBox(iIndex) + getGoalGrossHeight()) ;
}

long
NSLdvView::goalDonneBottomLine(int iIndex)
{
	return (getGoalBasePosition() + iIndex * getGoalGrossHeight()) ;
}

long
NSLdvView::goalDonneTopLine(int iIndex)
{
	return (goalDonneBottomLine(iIndex) + iLargeurSubLigne) ;
}

int
NSLdvView::getDrugBasePosition()
{
	return (goalDonneTopBox(_iMaxGoalsIndex) + iInterligne) ;
}

int
NSLdvView::getDrugGrossHeight()
{
	return iLargeurSubLigne + iDrugInterLigne ;
}

long
NSLdvView::drugDonneBottomBox(int iIndex)
{
	return (getDrugBasePosition() + iIndex * getDrugGrossHeight()) ;
}

long
NSLdvView::drugDonneTopBox(int iIndex)
{
	return (drugDonneBottomBox(iIndex) + getDrugGrossHeight()) ;
}

long
NSLdvView::drugDonneBottomLine(int iIndex)
{
	return (getDrugBasePosition() + iIndex * getDrugGrossHeight()) ;
}

long
NSLdvView::drugDonneTopLine(int iIndex)
{
	return (drugDonneBottomLine(iIndex) + iLargeurSubLigne ) ;
}

*/

void
NSLdvView::afficheStatusMessage(string* pMessage, bool bScroll)
{
	char  sAge[20] ;
	sAge[0] = '\0';

	string sLangue = pContexte->getUtilisateur()->donneLang();
	string sTitre  = pContexte->getPatient()->donneTitre(sLangue) ;

	NVLdVTemps tNaissance = getDateNaissance() ;
	if (!(tNaissance.estVide()))
	{
  	// Get the lib of "years" (plural of "year")
    //
  	string sCodeLexAn = string("2DAT33") ;
    NSPathologData Data ;
    pContexte->getDico()->trouvePathologData(sLangue, &sCodeLexAn, &Data) ;
    int iGenre ;
    Data.donneGenre(&iGenre) ;
    Data.donneGenrePluriel(&iGenre) ;
    string sLibel ;
    NSGenerateur* pGene = pContexte->getDico()->pGenerateur ;
    pGene->donneLibelleAffiche(&sLibel, &Data, iGenre) ;

    string sCodeLexMois = string("2DAT21") ;
    pContexte->getDico()->trouvePathologData(sLangue, &sCodeLexMois, &Data) ;
    Data.donneGenre(&iGenre) ;
    Data.donneGenrePluriel(&iGenre) ;
    string sLibelMois ;
    pGene->donneLibelleAffiche(&sLibelMois, &Data, iGenre) ;

		char    szCurrentDate[9] ;
		char    szAge[4];
		donne_date_duJour(szCurrentDate) ;
		int     iCurrentAge = donne_age(szCurrentDate, (char *) (tNaissance.donneDate().c_str())) ;

		if (iCurrentAge >= 2)
			sTitre += string(" (") + string(itoa(iCurrentAge, szAge, 10)) + string(" ") + sLibel + string(")") ;
		else if (iCurrentAge >= 0)
		{
    	iCurrentAge = donne_age_mois(szCurrentDate, (char *) (tNaissance.donneDate().c_str())) ;
      sTitre += string(" (") + string(itoa(iCurrentAge, szAge, 10)) + string(" ") + sLibelMois + string(")") ;
    }

    if (*pMessage != "")
    {
    	string  sCurDate = string(*pMessage, 6, 4) + string(*pMessage, 3, 2) + string(*pMessage, 0, 2) ;
      int iAge = donne_age((char *) sCurDate.c_str(), (char *) (tNaissance.donneDate().c_str())) ;

      if (iAge >= 2)
      {
      	if (iAge >= 0)
      		itoa(iAge, sAge, 10) ;
      	else
      		strcpy(sAge, "?") ;
      	*pMessage = *pMessage + string("  ->  ") + sAge + string(" ") + sLibel ;
      }
      else
      {
      	iAge = donne_age_mois((char *) sCurDate.c_str(), (char *) (tNaissance.donneDate().c_str())) ;
        *pMessage = *pMessage + string("  ->  ") + string(itoa(iAge, szAge, 10)) + string(" ") + sLibelMois ;
      }
    }
	}

	*pMessage = *pMessage + string(" - ") + sTitre ;

	TWindowDC* pWinDC = new TWindowDC(HWindow); // HWnd

	NS_CLASSLIB::TRect rectDTArea = getDateTimeArea() ;
	pWinDC->FillRect(rectDTArea, NS_CLASSLIB::TColor::White) ;

	NS_CLASSLIB::TColor  textColor ;

	if (bScroll)
		textColor = NS_CLASSLIB::TColor::LtBlue ;
  else
		textColor = NS_CLASSLIB::TColor::Black ;

	pWinDC->SetTextColor(textColor) ;
	pWinDC->DrawText(pMessage->c_str(), -1, rectDTArea, DT_CENTER) ;

	delete pWinDC ;

	pContexte->getSuperviseur()->afficheStatusMessage((char *)pMessage->c_str()) ;
}

/*
void
NSLdvView::showContextHelp()
{
	NS_CLASSLIB::TPoint curPos;
	GetCursorPos(curPos);
	ScreenToClient(curPos);

	NSLdvToon* pNewHitToon = HitTest(curPos) ;
	if (pHitToon == 0)
	{
		pHitToon = pNewHitToon;
		return;
	}
	if (pNewHitToon != pHitToon)
	{
		pHitToon = pNewHitToon;
		return;
	}

	if (dynamic_cast<NSLdvObjetView *>(pHitToon))
	{
		NSLdvObjetView *pObject = (NSLdvObjetView *)pHitToon ;
		string stheToonLibelle = pObject->pObjet->sTitre ;

		NSLdvToon* pOtherToon = nextHitTest(curPos, pHitToon) ;
		while (pOtherToon)
		{
			if (dynamic_cast<NSLdvObjetView *>(pOtherToon))
			{
				pObject = (NSLdvObjetView *)pOtherToon ;
				stheToonLibelle += string(1, '\n') + pObject->pObjet->sTitre ;
			}
			pOtherToon = nextHitTest(curPos, pOtherToon) ;
		}

		NS_CLASSLIB::TRect rectDoc = pHitToon->donneRectangle();
		rectDoc.right += ICONWIDTH;
		pToolTip->Show(rectDoc, &stheToonLibelle, 0,-1,NULL,NULL, 10);
	}
  else
    pToolTip->Hide();
}
*/

NS_CLASSLIB::TPoint
NSLdvView::getGlobalPhysicalPoint(NVLdVPoint ldvPoint)
{
	// On place le point en bas � droite
	// Instantiating the point as clientRect bottom right point
  //
	NS_CLASSLIB::TRect  clientRect    = GetClientRect() ;
	NS_CLASSLIB::TPoint physicalPoint = clientRect.BottomRight() ;

	// Translation du point
	// Translating the point
	NVLdVRect ldvRect(this,
										ldvPoint.getX(),
										tDateHeureInfDroit,
										0, // lPosInfDroit,
										ldvPoint.getY()) ;

  // physicalPoint.x -= ldvRect.Width() / iPixelPerUnitRate ;

  physicalPoint.x -= getPhysicalWidthFromTimeUnit(ldvRect.Width()) ;

  if (physicalPoint.x > numeric_limits<int>::max())
  	physicalPoint.x = numeric_limits<int>::max() ;
  if (physicalPoint.x < - numeric_limits<int>::max())
  	physicalPoint.x = - numeric_limits<int>::max() ;

	physicalPoint.y += ldvRect.Height() ;

  if (physicalPoint.y > numeric_limits<int>::max())
  	physicalPoint.y = numeric_limits<int>::max() ;
  if (physicalPoint.y < - numeric_limits<int>::max())
  	physicalPoint.y = - numeric_limits<int>::max() ;

	return physicalPoint ;
}

NS_CLASSLIB::TRect
NSLdvView::getGlobalPhysicalRect(NVLdVRect ldvRect)
{
	NS_CLASSLIB::TPoint ptTopLeft = getGlobalPhysicalPoint(ldvRect.TopLeft()) ;
	NS_CLASSLIB::TPoint ptBotRigh = getGlobalPhysicalPoint(ldvRect.BottomRight()) ;

  return NS_CLASSLIB::TRect(ptTopLeft, ptBotRigh) ;
}

NS_CLASSLIB::TRect
NSLdvView::getGlobalPhysicalRect(NS_CLASSLIB::TRect ldvWinRect)
{
  NS_CLASSLIB::TRect  clientRect    = GetClientRect() ;
	NS_CLASSLIB::TPoint physicalPoint = clientRect.BottomRight() ;

  NS_CLASSLIB::TPoint ptTopLeft = ldvWinRect.TopLeft() ;
  ptTopLeft.y = clientRect.Height() - ptTopLeft.y ;
  if (ptTopLeft.y > numeric_limits<int>::max())
  	ptTopLeft.y = numeric_limits<int>::max() ;
  if (ptTopLeft.y < - numeric_limits<int>::max())
  	ptTopLeft.y = - numeric_limits<int>::max() ;

	NS_CLASSLIB::TPoint ptBotRigh = ldvWinRect.BottomRight() ;
  ptBotRigh.y = clientRect.Height() - ptBotRigh.y ;
  if (ptBotRigh.y > numeric_limits<int>::max())
  	ptBotRigh.y = numeric_limits<int>::max() ;
  if (ptBotRigh.y < - numeric_limits<int>::max())
  	ptBotRigh.y = - numeric_limits<int>::max() ;

  return NS_CLASSLIB::TRect(ptTopLeft, ptBotRigh) ;
}

/*
NS_CLASSLIB::TPoint
NSLdvView::getScrollablePhysicalPoint(NVLdVPoint ldvPoint)
{
	// On place le point en bas � droite
	// Instantiating the point as clientRect bottom right point
  //
	NS_CLASSLIB::TRect  clientRect    = GetClientRect() ;
	NS_CLASSLIB::TPoint physicalPoint = clientRect.BottomRight() ;

	// Translation du point
	// Translating the point
	NVLdVRect ldvRect(this,
										ldvPoint.getX(),
										tDateHeureInfDroit,
										lPosInfDroit,
										ldvPoint.getY()) ;

	physicalPoint.x -= ldvRect.Width() * iPixelPerUnitRate ;

  if (physicalPoint.x > numeric_limits<int>::max())
  	physicalPoint.x = numeric_limits<int>::max() ;
  if (physicalPoint.x < - numeric_limits<int>::max())
  	physicalPoint.x = - numeric_limits<int>::max() ;

	physicalPoint.y += ldvRect.Height() ;

  if (physicalPoint.y > numeric_limits<int>::max())
  	physicalPoint.y = numeric_limits<int>::max() ;
  if (physicalPoint.y < - numeric_limits<int>::max())
  	physicalPoint.y = - numeric_limits<int>::max() ;

	return physicalPoint ;
}

NS_CLASSLIB::TRect
NSLdvView::getScrollablePhysicalRect(NVLdVRect ldvRect)
{
	NS_CLASSLIB::TPoint ptTopLeft = getScrollablePhysicalPoint(ldvRect.TopLeft()) ;
	NS_CLASSLIB::TPoint ptBotRigh = getScrollablePhysicalPoint(ldvRect.BottomRight()) ;

  return NS_CLASSLIB::TRect(ptTopLeft, ptBotRigh) ;
}
*/

bool
NSLdvView::convertUnit(double* pdValue, string sResultUnit, string sInitialUnit, string sRelatedTo, bool bVerbose)
{
	if (NULL == pdValue)
		return false ;

	if (sResultUnit == sInitialUnit)
		return true ;

	NSCV NsCv(pContexte) ;

  DBIResult result = NsCv.open() ;
	if (result != DBIERR_NONE)
  {
  	if (bVerbose)
    {
    	string sErrorMessage = pContexte->getSuperviseur()->getText("unitConversion", "errorOpeningConversionDatabase") ;
      erreur(sErrorMessage.c_str(), standardError, result) ;
    }
    return false ;
  }

	bool bCvtSuccess = NsCv.ConvertirUnite(pdValue, sResultUnit, sInitialUnit, sRelatedTo) ;

  NsCv.close() ;

  return bCvtSuccess ;
}

int
NSLdvView::getLargeurChronoLine()
{
  NSLdvChronoLine*   pChrono = getLdVChronoLine() ;
  NS_CLASSLIB::TRect vBox    = pChrono->donneVisibleRectangle() ;
  return vBox.Height() ;
}

/*
void
NSLdvView::increasePosInfDroit(int iDeltaPos)
{
	if (0 == iDeltaPos)
		return ;
	if ((0 >= lPosInfDroit) && (iDeltaPos < 0))
		return ;

	int iMaxPos = GlobalBox.Height() - getWorkingSpaceHeight() ;
  if ((iMaxPos <= lPosInfDroit) && (iDeltaPos > 0))
		return ;

	if (lPosInfDroit + iDeltaPos <= 0)
  	lPosInfDroit = 0 ;
	else if (lPosInfDroit + iDeltaPos >= iMaxPos)
  	lPosInfDroit = iMaxPos ;
  else
  	lPosInfDroit += iDeltaPos ;

	InvalidateRect(getWorkingSpaceRect(), true) ;

	return ;
}

void
NSLdvView::setPosInfDroit(long lNewPosition)
{
	if (lNewPosition < 0)
  	lPosInfDroit = 0 ;
	else if (lNewPosition > GlobalBox.Height() - getWorkingSpaceHeight())
  	lPosInfDroit = GlobalBox.Height() - getWorkingSpaceHeight() ;
  else
  	lPosInfDroit = lNewPosition ;

	Invalidate() ;
	return ;
}
*/

/*
int
NSLdvView::getWorkingSpaceTop()
{
	NS_CLASSLIB::TRect clientRect = getWorkingSpaceRect() ;
	return clientRect.Top() ;
}

int
NSLdvView::getWorkingSpaceBottom()
{
	NS_CLASSLIB::TRect clientRect = getWorkingSpaceRect() ;
	return clientRect.Bottom() ;
}

int
NSLdvView::getWorkingSpaceRight()
{
	NS_CLASSLIB::TRect clientRect = getWorkingSpaceRect() ;
	return clientRect.Right() ;
}

int
NSLdvView::getWorkingSpaceLeft()
{
	NS_CLASSLIB::TRect clientRect = getWorkingSpaceRect() ;
	return clientRect.Left() ;
}

int
NSLdvView::getWorkingSpaceHeight()
{
  NS_CLASSLIB::TRect clientRect = getWorkingSpaceRect() ;
	return clientRect.Height() ;
}

int
NSLdvView::getWorkingSpaceWidth()
{
  NS_CLASSLIB::TRect clientRect = getWorkingSpaceRect() ;
	return clientRect.Width() ;
}

NS_CLASSLIB::TRect
NSLdvView::getWorkingSpaceRect()
{
	NS_CLASSLIB::TRect LdvFrameRect = getClientRectAboveBaseline() ;
  int iClientRectHeight = GetClientRect().Height() ;

	return NS_CLASSLIB::TRect(LdvFrameRect.Left(),
                            iClientRectHeight - LdvFrameRect.Bottom(),
                            LdvFrameRect.Right(),
                            iClientRectHeight - LdvFrameRect.Top()) ;
}
*/

// Trouver une ligne qui contient une place libre pour cette pr�occupation
// Looking for a line with room for this health concern

/*
int
NSLdvView::getLigneProb(NSConcern* pConcern, int iLineBegin)
{
	if (!pConcern)
		return 0;
	if (aToons.empty())
		return 0 ;

	// Si cette pr�occupation est fille d'une autre, elle est sur la m�me ligne
	// If this health concern is son of another one, put it on same line
	if (pConcern->sPrimoPb != "")
	{
		NSConcernView* pConcView = aToons.getPbView(pConcern->sPrimoPb);
		if (pConcView != NULL)
			return pConcView->iIndex;
	}

	NVLdVTemps tDateDebut, tDateFin;

	tDateDebut  = pConcern->tDateOuverture;
	tDateFin    = pConcern->tDateFermeture;

	//
	// Si cette pr�occupation n'est pas fille d'une autre, on regarde si elle
	// n'a pas de fille : si elle en a, on doit trouver une ligne capable
	// d'accueillir toutes les filles
	// If this health concern is not the son of another one, we have to check
	// wether it is not itself the father of other health concerns ; if it is,
	// we must find a lign with room enough for all sons
	//
	NSConcern* pSonConcern = pLdVDoc->getConcerns()->getFils(pConcern);
	NSConcern* pLastSon = NULL;

	while (pSonConcern != NULL)
	{
		pLastSon = pSonConcern;
		pSonConcern = pLdVDoc->getConcerns()->getFils(pLastSon);
	}
	if (pLastSon != NULL)
		tDateFin = pLastSon->tDateFermeture;

	//
	// On cherche une ligne susceptible d'accueillir la pr�occupation
	// Looking for a line with room enough for this health concern
	//
	int     iLineResult = iLineBegin ;
	bool    bNewLine = true ;
	while (bNewLine)
	{
		bNewLine = false ;
		for (ToonsIter toonIter = aToons.begin() ; toonIter != aToons.end() ; toonIter++)
		{
			NSConcernView *pToon = TYPESAFE_DOWNCAST(*toonIter, NSConcernView) ;
			if (pToon)
			{
				bool    bContinue = true ;

				if ((tDateDebut >= pToon->pConcern->tDateOuverture) &&
						(tDateDebut <= pToon->pConcern->tDateFermeture))
					bContinue = false ;

				if ((tDateFin >= pToon->pConcern->tDateOuverture) &&
						(tDateFin <= pToon->pConcern->tDateFermeture))
					bContinue = false ;

				if ((pToon->pConcern->tDateOuverture >= tDateDebut) &&
						(pToon->pConcern->tDateOuverture <= tDateFin))
					bContinue = false ;

				if ((pToon->pConcern->tDateFermeture >= tDateDebut) &&
						(pToon->pConcern->tDateFermeture <= tDateFin))
					bContinue = false ;

				if ((bContinue == false) && (iLineResult == pToon->iIndex))
				{
					iLineResult = pToon->iIndex + 1 ;
					bNewLine = true ;
				}
			}
		}
	}

	// Si l'�l�ment est le premier d'une s�rie de fils, on attribue cette ligne
	// � tous les descendants
	// If this health concern has sons, we set this line for each son

	if (pLastSon != NULL)
	{
		pSonConcern = pLdVDoc->getConcerns()->getFils(pConcern);

		while (pSonConcern != NULL)
		{
			NSConcernView* pConcView = aToons.getPbView(pSonConcern->getNoeud());
			if (pConcView != NULL)
				pConcView->iIndex = iLineResult;

			pSonConcern = pLdVDoc->getConcerns()->getFils(pSonConcern);
		}
	}

	return (iLineResult) ;
}
*/

bool
NSLdvView::addObj(NSLdvObjet *pObj)
{
try
{
	if ((NULL == pObj) || aToons.empty())
		return false ;

  for (ToonsIter toonIter = aToons.begin() ; aToons.end() != toonIter ; toonIter++)
  {
    if (NSLdvToon::toonWorkingArea == (*toonIter)->getType())
    {
      NSLdvViewArea *pWorkArea = TYPESAFE_DOWNCAST(*toonIter, NSLdvViewArea) ;
      if ((NULL != pWorkArea) && (pWorkArea->isMainView()))
        pWorkArea->addObj(pObj) ;
    }
  }

	Invalidate(true) ;
	return true ;
}
catch (...)
{
	erreur("Exception NSLdvView::addObj.", standardError, 0) ;
	return false ;
}
}

bool
NSLdvView::addProb(NSConcern *pPb)
{
try
{
  if ((NULL == pPb) || aToons.empty())
    return false ;

  for (ToonsIter toonIter = aToons.begin() ; aToons.end() != toonIter ; toonIter++)
  {
    if (NSLdvToon::toonWorkingArea == (*toonIter)->getType())
    {
      NSLdvViewArea *pWorkArea = TYPESAFE_DOWNCAST(*toonIter, NSLdvViewArea) ;
      if ((NULL != pWorkArea) && (pWorkArea->isMainView()))
        pWorkArea->addProb(pPb) ;
    }
  }

/*
	NSConcernView* pProbView = new NSConcernView(pContexte, this, pPb, getLigneProb(pPb, 1)) ;
	pProbView->boxFitting() ;
	// pProbView->createComponents(this);
	aToons.push_back(pProbView) ;
*/

  reinit() ;

	Invalidate(true) ;
	return true ;
}
catch (...)
{
  erreur("Exception NSLdvView::addProb.", standardError, 0) ;
  return false ;
}
}

bool
NSLdvView::addSsObj(NSLdvSousObjet *pSsObj)
{
try
{
  if ((NULL == pSsObj) || aToons.empty())
    return false ;

  for (ToonsIter toonIter = aToons.begin() ; aToons.end() != toonIter ; toonIter++)
  {
    if (NSLdvToon::toonWorkingArea == (*toonIter)->getType())
    {
      NSLdvViewArea *pWorkArea = TYPESAFE_DOWNCAST(*toonIter, NSLdvViewArea) ;
      if ((NULL != pWorkArea) && (pWorkArea->isMainView()))
        pWorkArea->addSsObj(pSsObj) ;
    }
  }

	Invalidate(true) ;
	return true;
}
catch (...)
{
	erreur("Exception NSLdvView::addSsObj.", standardError, 0) ;
  return false ;
}
}

bool
NSLdvView::addObjOnConcern(NSConcern *pPb, NSLdvObjet *pObj)
{
  if ((NULL == pPb) || (NULL == pObj) || aToons.empty())
		return false ;

  for (ToonsIter toonIter = aToons.begin() ; aToons.end() != toonIter ; toonIter++)
  {
    if (NSLdvToon::toonWorkingArea == (*toonIter)->getType())
    {
      NSLdvViewArea *pWorkArea = TYPESAFE_DOWNCAST(*toonIter, NSLdvViewArea) ;
      if ((NULL != pWorkArea) && (pWorkArea->isMainView()))
        pWorkArea->addObjOnConcern(pPb, pObj) ;
    }
  }

	Invalidate(true) ;

	return true ;
}

void
NSLdvView::reorganizeLines()
{
}

void
NSLdvView::reinitDrugs()
{
  if (aToons.empty())
		return ;

  for (ToonsIter toonIter = aToons.begin() ; aToons.end() != toonIter ; toonIter++)
  {
    if (NSLdvToon::toonWorkingArea == (*toonIter)->getType())
    {
      NSLdvViewArea *pWorkArea = TYPESAFE_DOWNCAST(*toonIter, NSLdvViewArea) ;
      if ((NULL != pWorkArea) && (pWorkArea->isMainView()))
        pWorkArea->getToonsArray()->reinit(pLdVDoc->getDrugs(), pContexte, pWorkArea) ;
    }
  }
}

void
NSLdvView::displayCurvesForBiometricalGoals(string sReference)
{
	if (sReference == string(""))
		return ;

	ArrayGoals* pArrayOfGoals = pLdVDoc->getGoals() ;
  if ((NULL == pArrayOfGoals) || (pArrayOfGoals->empty()))
		return ;

	// Looking for the NSLdvCurvesManagementPannel toon
  //
  if (aToons.empty())
		return ;

	NSLdvCurvesManagementPannel* pCurvesPanel = NULL ;
	for (ToonsIter toonIter = aToons.begin() ; toonIter != aToons.end() ; toonIter++)
  	if ((*toonIter)->toonType == NSLdvToon::toonCurvePannel)
    {
			pCurvesPanel = dynamic_cast<NSLdvCurvesManagementPannel *>(*toonIter) ;
      break ;
    }

	if (NULL == pCurvesPanel)
		return ;

	// Enumerating goals
	//
	for (ArrayGoalIter goalIt = pArrayOfGoals->begin();
                                goalIt != pArrayOfGoals->end(); goalIt++)
		if ((*goalIt)->sConcern == sReference)
    {
    	if (((*goalIt)->sLexique != string("")) && ((*goalIt)->sLexique[0] == 'V'))
      	pCurvesPanel->autoCreateNewCurve((*goalIt)->sLexique) ;
    }
}

void
NSLdvView::setAppointment()
{
	pLdVDoc->NewAppointmentService(this) ;
}

NSLdvView&
NSLdvView::operator=(NSLdvView& src)
{
	if (this == &src)
		return *this ;

  pLdVDoc                  = src.pLdVDoc ;
  _sConcern                = src._sConcern ;

	iXunit                   = src.iXunit ;
	iZoomFactor              = src.iZoomFactor ;
	// iLargeurLigne            = src.iLargeurLigne ;
	// iLargeurBaseline         = src.iLargeurBaseline ;
	// iLargeurChronoLine       = src.iLargeurChronoLine ;
	// iInterligne              = src.iInterligne ;
  // iDrugInterLigne          = src.iDrugInterLigne ;
	_bSystemColors           = src._bSystemColors ;
  _bDisplayDrugs				   = src._bDisplayDrugs ;
  _bDisplayGoals 				   = src._bDisplayGoals ;
  skinName                 = src.skinName ;

  _iMinSeverityOfDisplayedConcerns = src._iMinSeverityOfDisplayedConcerns ;

	// GlobalBox                = src.GlobalBox ;

	tDateHeureInfDroit       = src.tDateHeureInfDroit ;
	//lPosInfDroit             = src.lPosInfDroit ;

	//iLeftServiceAreaMargin   = src.iLeftServiceAreaMargin ;
	//iRightServiceAreaMargin  = src.iRightServiceAreaMargin ;
	//iTopServiceAreaMargin    = src.iTopServiceAreaMargin ;
	//iBottomServiceAreaMargin = src.iBottomServiceAreaMargin ;

	aToons                   = src.aToons ;

	return *this ;
}

// -----------------------------------------------------------------------------
// ---------------------- METHODES DE NSLdvViewArea ----------------------------
// -----------------------------------------------------------------------------

NSLdvViewArea::NSLdvViewArea(NSContexte* pCtx, NSLdvWindowToon* pLdvParent, NSLdvView* pTheView, string sConcernRef, bool bMain)
              :NSLdvWindowToon(pCtx, pLdvParent, pTheView), _GlobalBox(pTheView)
{
  _sConcernReference = sConcernRef ;
  _bMainView         = bMain ;

  iZOrder    = LEVEL_COMMANDS ;
  toonType   = toonWorkingArea ;
  sSkinName  = string("LdvWorkingArea") ;

  pInterface = 0 ;

  reinit() ;
}

NSLdvViewArea::NSLdvViewArea(NSLdvViewArea& rv)
              :NSLdvWindowToon(rv.pContexte, rv.getToonParent(), rv.pView), _GlobalBox(rv.pView)
{
  _bMainView = rv._bMainView ;
	initialiser((NSLdvWindowToon*)(&rv)) ;
}

NSLdvViewArea::~NSLdvViewArea()
{
}

void
NSLdvViewArea::SetupWindow()
{
}

void
NSLdvViewArea::reinit()
{
  if (false == aToons.empty())
    aToons.vider() ;

  _iMaxConcernIndex	= 0 ;
	_iMaxGoalsIndex 	= 0 ;
	_iMaxDrugsIndex 	= 0 ;

  _iLargeurLigne    = 19 ;
	_iLargeurSubLigne =  5 ;
	_iLargeurBaseline = 20 ;
	_iInterligne      = 15 ;
  _iDrugInterLigne  = 25 ;
  _iBottomMargin    =  5 ;

  initDimensions() ;

  if (NULL == pInterface)
    pInterface = new NSLdvViewAreaWindow(pContexte, getParentInterface(), this) ;

  // NSLdvVerticalScrollBar* pVScroll = getVerticalScroll() ;
  // if (NULL == pVScroll)
  //   new NSLdvVerticalScrollBar(pContexte, this, getView()) ;

  // Don't forget to reinit the GUI because _iInterligne and _iDrugInterLigne
  // are set there
  //
  if (NULL != pInterface)
  {
    NSLdvViewAreaWindow *pWorkAreaWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
    if (NULL != pWorkAreaWin)
      pWorkAreaWin->reinit() ;
  }
}

void
NSLdvViewArea::EvRButtonDown()
{
}

void
NSLdvViewArea::showContextHelp()
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    pWorkWin->showContextHelp() ;
}

void
NSLdvViewArea::afterToonsInit()
{
  calculRectangleGlobal() ;
  setScrollParams() ;
}

void
NSLdvViewArea::setScrollParams()
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    pWorkWin->setScrollParams() ;
}

bool
NSLdvViewArea::addSsObj(NSLdvSousObjet *pSsObj)
{
try
{
  if (NULL == pSsObj)
    return false ;

	NSLdvObjetView *pObjV = aToons.getObjView(pSsObj->sObject) ;
	NSConcernView  *pPbV  = aToons.getPbView(pSsObj->sConcern) ;

	NSSsObjView *pSsObjView = new NSSsObjView(pContexte, this, pSsObj, pObjV, pPbV) ;
	aToons.push_back(pSsObjView) ;

	pInterface->Invalidate(true) ;
	return true;
}
catch (...)
{
	erreur("Exception NSLdvViewArea::addSsObj.", standardError, 0) ;
  return false;
}
}

bool
NSLdvViewArea::addObj(NSLdvObjet *pObj)
{
try
{
	if (NULL == pObj)
		return false ;

	NSLigneView *pLineView = aToons.getLigneView(pObj->sConcern) ;

	NSLdvObjetView *pObjView = new NSLdvObjetView(pContexte, this, pObj, pLineView) ;
	aToons.push_back(pObjView) ;

	pInterface->Invalidate(true) ;
	return true ;
}
catch (...)
{
	erreur("Exception NSLdvViewArea::addObj.", standardError, 0) ;
	return false ;
}
}

bool
NSLdvViewArea::addProb(NSConcern *pPb)
{
try
{
	NSConcernView* pProbView = new NSConcernView(pContexte, this, pPb, getLigneProb(pPb, 1)) ;
	pProbView->boxFitting() ;
	// pProbView->createComponents(this);
	aToons.push_back(pProbView) ;

	pInterface->Invalidate(true) ;
	return true ;
}
catch (...)
{
	erreur("Exception NSLdvViewArea::addProb.", standardError, 0) ;
  return false ;
}
}

bool
NSLdvViewArea::addObjOnConcern(NSConcern *pPb, NSLdvObjet *pObj)
{
	if ((NULL == pObj) || (NULL == pPb) || aToons.empty())
		return false ;

	NSLdvObjetView* pObjView     = 0 ;
	NSConcernView*  pConcernView = 0 ;
	//
	// Recherche des objets "vue" qui conrrepondent � pPb et pObj
	//
	for (ToonsIter toonIter = aToons.begin() ; toonIter != aToons.end() ; toonIter++)
	{
  	NSLdvObjetView *pObjV = TYPESAFE_DOWNCAST(*toonIter, NSLdvObjetView) ;
    if (pObjV)
    {
    	if (pObjV->pObjet == pObj)
      	pObjView = pObjV ;
    }
    else
    {
    	NSConcernView *pCcnV = TYPESAFE_DOWNCAST(*toonIter, NSConcernView) ;
      if (pCcnV && (pCcnV->pConcern == pPb))
      	pConcernView = pCcnV ;
    }
    if (pObjView && pConcernView)
    	break ;
	}

	if (!pObjView || !pConcernView)
		return false ;

	pObjView->setLigneView((NSLigneView *) pConcernView) ;
	pInterface->Invalidate(true) ;

	return true ;
}

// Trouver une ligne qui contient une place libre pour cette pr�occupation
// Looking for a line with room for this health concern
int
NSLdvViewArea::getLigneProb(NSConcern* pConcern, int iLineBegin)
{
	if ((NULL == pConcern) || (aToons.empty()))
		return 0 ;

	// Si cette pr�occupation est fille d'une autre, elle est sur la m�me ligne
	// If this health concern is son of another one, put it on same line
	if (string("") != pConcern->sPrimoPb)
	{
		NSConcernView* pConcView = aToons.getPbView(pConcern->sPrimoPb) ;
		if (NULL != pConcView)
			return pConcView->getIndex() ;
	}

	NVLdVTemps tDateDebut = pConcern->tDateOuverture ;
	NVLdVTemps tDateFin   = pConcern->tDateFermeture ;

	//
	// Si cette pr�occupation n'est pas fille d'une autre, on regarde si elle
	// n'a pas de fille : si elle en a, on doit trouver une ligne capable
	// d'accueillir toutes les filles
	// If this health concern is not the son of another one, we have to check
	// wether it is not itself the father of other health concerns ; if it is,
	// we must find a lign with room enough for all sons
	//
  NSLdvDocument* pLdVDoc = getView()->getDoc() ;
  if (NULL == pLdVDoc)
    return 0 ;

	NSConcern* pSonConcern = pLdVDoc->getConcerns()->getFils(pConcern) ;
	NSConcern* pLastSon = NULL ;

	while (NULL != pSonConcern)
	{
		pLastSon    = pSonConcern ;
		pSonConcern = pLdVDoc->getConcerns()->getFils(pLastSon) ;
	}
	if (NULL != pLastSon)
		tDateFin = pLastSon->tDateFermeture ;

	//
	// On cherche une ligne susceptible d'accueillir la pr�occupation
	// Looking for a line with room enough for this health concern
	//
	int  iLineResult = iLineBegin ;
	bool bNewLine = true ;
	while (bNewLine)
	{
		bNewLine = false ;
		for (ToonsIter toonIter = aToons.begin() ; aToons.end() != toonIter ; toonIter++)
		{
			NSConcernView *pToon = TYPESAFE_DOWNCAST(*toonIter, NSConcernView) ;
			if (NULL != pToon)
			{
				bool    bContinue = true ;

				if ((tDateDebut >= pToon->pConcern->tDateOuverture) &&
						(tDateDebut <= pToon->pConcern->tDateFermeture))
					bContinue = false ;

				if ((tDateFin >= pToon->pConcern->tDateOuverture) &&
						(tDateFin <= pToon->pConcern->tDateFermeture))
					bContinue = false ;

				if ((pToon->pConcern->tDateOuverture >= tDateDebut) &&
						(pToon->pConcern->tDateOuverture <= tDateFin))
					bContinue = false ;

				if ((pToon->pConcern->tDateFermeture >= tDateDebut) &&
						(pToon->pConcern->tDateFermeture <= tDateFin))
					bContinue = false ;

				if ((false == bContinue) && (pToon->getIndex() == iLineResult))
				{
					iLineResult = pToon->getIndex() + 1 ;
					bNewLine = true ;
				}
			}
		}
	}

	// Si l'�l�ment est le premier d'une s�rie de fils, on attribue cette ligne
	// � tous les descendants
	// If this health concern has sons, we set this line for each son

	if (NULL != pLastSon)
	{
		pSonConcern = pLdVDoc->getConcerns()->getFils(pConcern) ;

		while (NULL != pSonConcern)
		{
			NSConcernView* pConcView = aToons.getPbView(pSonConcern->getNoeud()) ;
			if (pConcView != NULL)
				pConcView->setIndex(iLineResult) ;

			pSonConcern = pLdVDoc->getConcerns()->getFils(pSonConcern) ;
		}
	}

	return (iLineResult) ;
}

void
NSLdvViewArea::calculRectangleGlobal()
{
	NVLdVTemps tDateMin, tDateMax ;

	NVLdVTemps tDebut ;
	tDebut.takeTime() ;

	NVLdVTemps tFin ;
	tFin.takeTime() ;

	long lPlancher = 0 ;
	long lPlafond  = 0 ;
	long lHauMin   = 0 ;
	long lHaumax   = 0 ;

	if (aToons.empty())
  {
    _GlobalBox.initialise(tDebut, tFin, lPlafond, lPlancher) ;
    return ;
  }

  for (ToonsIter it = aToons.begin() ; aToons.end() != it ; it++)
  {
    NSLdvTimeToon* pTimeToon = TYPESAFE_DOWNCAST(*it, NSLdvTimeToon) ;
    if (NULL != pTimeToon)
      pTimeToon->donneRectangle(&tDateMin, &tDateMax, &lHauMin, &lHaumax) ;

    if (tDateMin < tDebut)
      tDebut = tDateMin ;
    if (tDateMax > tFin)
      tFin = tDateMax ;

    if (lHauMin < lPlancher)
      lPlancher = lHauMin ;
    if (lHaumax > lPlafond)
      lPlafond = lHaumax ;
  }
  
	_GlobalBox.initialise(tDebut, tFin, lPlafond, lPlancher) ;
}

void
NSLdvViewArea::reinitCurves()
{
  if (aToons.empty())
    return ;

  for (ToonsIter toonIter = aToons.begin() ; aToons.end() != toonIter ; toonIter++)
	{
    if (toonYAxis == (*toonIter)->getType())
    {
  	  NSLdvCurveYAxis *pYaxis = TYPESAFE_DOWNCAST(*toonIter, NSLdvCurveYAxis) ;
      if ((NULL != pYaxis) &&
          (NULL != pYaxis->getCurve()) &&
          (NULL != pYaxis->getCurve()->getFirstPoint()))
        pYaxis->getCurve()->reinit(false) ;
    }
  }
}

NSConcernView*
NSLdvViewArea::getCurrentConcern()
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->_pCurrentConcern ;

  return 0 ;
}

void
NSLdvViewArea::increasePosInfDroit(int iDeltaPos)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->increasePosInfDroit(iDeltaPos) ;

  return ;
}

NS_CLASSLIB::TPoint
NSLdvViewArea::getAreaPhysicalPoint(NVLdVPoint ldvPoint)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getAreaPhysicalPoint(ldvPoint) ;

  return NS_CLASSLIB::TPoint(0, 0) ;
}

NS_CLASSLIB::TRect
NSLdvViewArea::getAreaPhysicalRect(NVLdVRect ldvRect)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getAreaPhysicalRect(ldvRect) ;

  return NS_CLASSLIB::TRect(0, 0, 0, 0) ;
}

NS_CLASSLIB::TRect
NSLdvViewArea::getAreaPhysicalRect(NS_CLASSLIB::TRect ldvWinRect)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getAreaPhysicalRect(ldvWinRect) ;

  return NS_CLASSLIB::TRect(0, 0, 0, 0) ;
}

NS_CLASSLIB::TPoint
NSLdvViewArea::getScrollablePhysicalPoint(NVLdVPoint ldvPoint)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getScrollablePhysicalPoint(ldvPoint) ;

  return NS_CLASSLIB::TPoint(0, 0) ;
}

NS_CLASSLIB::TRect
NSLdvViewArea::getScrollablePhysicalRect(NVLdVRect ldvRect)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getScrollablePhysicalRect(ldvRect) ;

  return NS_CLASSLIB::TRect(0, 0, 0, 0) ;
}

NVLdVPoint
NSLdvViewArea::getAreaLogicalPointFromWindowPoint(NS_CLASSLIB::TPoint scrPoint)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getAreaLogicalPointFromWindowPoint(scrPoint) ;

  return NVLdVPoint(getView()) ;
}

NVLdVRect
NSLdvViewArea::getAreaLogicalRectFromWindowRect(NS_CLASSLIB::TRect scrRect)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getAreaLogicalRectFromWindowRect(scrRect) ;

  return NVLdVRect(getView()) ;
}

NS_CLASSLIB::TRect
NSLdvViewArea::getWorkingSpaceRect()
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getWorkingSpaceRect() ;

  return NS_CLASSLIB::TRect(0, 0, 0, 0) ;
}

int
NSLdvViewArea::getWorkingSpaceHeight()
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getWorkingSpaceHeight() ;

  return 0 ;
}

int
NSLdvViewArea::getWorkingSpaceRight()
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getWorkingSpaceRight() ;

  return 0 ;
}

int
NSLdvViewArea::getWorkingSpaceLeft()
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getWorkingSpaceLeft() ;

  return 0 ;
}

int
NSLdvViewArea::getWorkingSpaceTop()
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getWorkingSpaceTop() ;

  return 0 ;
}

int
NSLdvViewArea::getWorkingSpaceBottom()
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->getWorkingSpaceBottom() ;

  return 0 ;
}

long
NSLdvViewArea::preoccupDonneTopLine(int iIndex)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->preoccupDonneTopLine(iIndex) ;

  return long(0) ;
}

long
NSLdvViewArea::preoccupDonneBottomLine(int iIndex)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->preoccupDonneBottomLine(iIndex) ;

  return long(0) ;
}

long
NSLdvViewArea::preoccupDonneTopBox(int iIndex)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->preoccupDonneTopBox(iIndex) ;

  return long(0) ;
}

long
NSLdvViewArea::preoccupDonneBottomBox(int iIndex)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->preoccupDonneBottomBox(iIndex) ;

  return long(0) ;
}

long
NSLdvViewArea::drugDonneTopBox(int iIndex)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->drugDonneTopBox(iIndex) ;

  return long(0) ;
}

long
NSLdvViewArea::drugDonneBottomBox(int iIndex)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->drugDonneBottomBox(iIndex) ;

  return long(0) ;
}

long
NSLdvViewArea::drugDonneTopLine(int iIndex)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->drugDonneTopLine(iIndex) ;

  return long(0) ;
}

long
NSLdvViewArea::drugDonneBottomLine(int iIndex)
{
  NSLdvViewAreaWindow *pWorkWin = TYPESAFE_DOWNCAST(pInterface, NSLdvViewAreaWindow) ;
  if (NULL != pWorkWin)
    return pWorkWin->drugDonneBottomLine(iIndex) ;

  return long(0) ;
}

NSLdvViewArea&
NSLdvViewArea::operator=(NSLdvViewArea& src)
{
  if (this == &src)
    return *this ;

  _bMainView = src._bMainView ;
  initialiser((NSLdvWindowToon*)(&src)) ;

  return *this ;
}

// -----------------------------------------------------------------------------
// --------------------- METHODES DE NSLdvViewAreaWindow -----------------------
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
//  D�finition de la table de r�ponse de la vue NSLdvViewAreaWindow
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSLdvViewAreaWindow, TWindow)
	EV_WM_VSCROLL,																			// scroll vertival
	EV_WM_MOUSEMOVE,                                    // mouvement de la souris
	EV_WM_LBUTTONDOWN,                                  // bouton gauche enfonc�
	EV_WM_RBUTTONDOWN,                                  // bouton droit enfonc�
	EV_WM_LBUTTONUP,                                    // bouton gauche relach�
	EV_WM_LBUTTONDBLCLK,                                // dbl-clicke avec bouton gauche
	// EV_WM_TIMER,                                        // timer
	// EV_WM_HOTKEY,                                       // raccourci (hotkey)
  EV_WM_KEYDOWN,
  EV_WM_SYSKEYDOWN,
	EV_WM_CLOSE,                                        // fermeture de la fen�tre
	EV_WM_DESTROY,                                      // destruction de la fen�tre
	EV_WM_SIZE,                                         // redimensionnement de la fen�tre
	EV_WM_SETFOCUS,                                     // focus
	EV_WM_QUERYENDSESSION,
	EV_COMMAND(IDC_NEWPREOCCUP,     CmNewPreoccup),     // nouvelle pr�occup.
	EV_COMMAND(IDC_CHG_PREO_TYP,    CmChgPreoType),     // correction type
	EV_COMMAND(IDC_CHG_PREO_DAT,    CmChgPreoDate),     // correction date
	EV_COMMAND(IDC_CHG_PREO_IDX,    CmChgPreoIndx),     // correction s�v�rite
	EV_COMMAND(IDC_EVOL_PREO_TYP,   CmEvolPreoType),    // �volution type
	EV_COMMAND(IDC_EVOL_PREO_IDX,   CmEvolPreoIndx),    // �volution s�v�rite
	EV_COMMAND(IDC_SUPPRESS_PREO,   CmSuppressPreo),    // suppression pr�occup
  EV_COMMAND(CM_DRUG_NEW,         CmDrugNew),
  EV_COMMAND(CM_DRUG_RENEW,       CmDrugRenew),
  EV_COMMAND(CM_DRUG_CHANGE,      CmDrugModify),
  EV_COMMAND(CM_DRUG_MODIF_POSO,  CmDrugChangePoso),
  EV_COMMAND(CM_DRUG_STOP,        CmDrugStop),
  EV_COMMAND(CM_DRUG_DELETE,      CmDrugDelete),
  EV_COMMAND(CM_DRUG_FROM_REF,    CmNewDrugsFromRefForConcern),
  EV_COMMAND(IDC_ORDONNANCE,      CmDrugPrescription),
	EV_COMMAND(IDC_ADD_PREO_OBJ,    CmAddObjectifs),     // ajouter un objectif
  EV_COMMAND(CM_GOAL_FROM_REF,    CmNewGoalsFromRefForConcern),
	EV_COMMAND(IDC_MANAGE_RIGHTS,   CmManageRights),    // gestion des droits
	EV_COMMAND(IDC_EVOL_PREOCCUP,   CmEvolPreoccup),    // command CmNewPreoccup
	EV_COMMAND(CM_LDV_ZOOMIN,       CmLdvZoomIn),       // command CmLdvZoomIn
	EV_COMMAND(CM_LDV_ZOOMOUT,      CmLdvZoomOut),      // command CmLdvZoomOut
	// EV_COMMAND(CM_LDV_PIXSECOND,    CmLdvPixSecond),    // pixel == 1 seconde
	// EV_COMMAND(CM_LDV_PIXMINUTE,    CmLdvPixMinute),    // pixel == 1 minute
	// EV_COMMAND(CM_LDV_PIXHOUR,      CmLdvPixHour),      // pixel == 1 heure
	// EV_COMMAND(CM_LDV_PIXDAY,       CmLdvPixDay),       // pixel == 1 jour
	// EV_COMMAND(CM_LDV_PIXWEEK,      CmLdvPixWeek),      // pixel == 1 semaine
	// EV_COMMAND(CM_LDV_PIXMONTH,     CmLdvPixMonth),     // pixel == 1 mois
	// EV_COMMAND_ENABLE(IDI_LDVCURS16,  CmCursorEnable),  // passage en mode Curseur
	// EV_COMMAND_ENABLE(IDI_LDVZOOM16,  CmZoomEnable),    // passage en mode Zoom
	// EV_COMMAND(CM_TIPTIMER_ON,      setTipsTimer),
	// EV_COMMAND(CM_TIPTIMER_OFF,     killTipsTimer),
  // EV_COMMAND(CM_APPOINTMENT,      setAppointment),
  // EV_COMMAND(CM_HELP,             CmHelp),
  // EV_CHILD_NOTIFY_ALL_CODES(ID_PIXEL_PU, UpdatePixelPerUnitRate),
  // EV_CHILD_NOTIFY_ALL_CODES(ID_SEVERITY, UpdateSeverityThreshold),
END_RESPONSE_TABLE;

// -----------------------------------------------------------------------------
//  SetupWindow() : Initialise la fen�tre
// -----------------------------------------------------------------------------

NSLdvViewAreaWindow::NSLdvViewAreaWindow(NSContexte* pCtx, TWindow* parent, NSLdvViewArea* pToon)
                    :TWindow(parent), NSRoot(pCtx), _currentPoint(pToon->getView())
{
  Attr.Style = Attr.Style | WS_VSCROLL ;
  Attr.AccelTable = LDV_ACCEL ;

  _pToon = pToon ;

  SetCaption(_pToon->sSkinName.c_str()) ;

  _lPosInfDroit = 0 ;

  _bLButtonDown = false ;
	_pToon2Drag   = NULL ;

  reinit() ;
}

void
NSLdvViewAreaWindow::SetupWindow()
{
try
{
	TWindow::SetupWindow() ;

  if (true == _pToon->isMainView())
    getView()->timeBumper() ;

  if (false == _pToon->getToonsArray()->empty())
  	for (ToonsIter toonIter = _pToon->getToonsArray()->begin() ; _pToon->getToonsArray()->end() != toonIter ; toonIter++)
    	(*toonIter)->SetupWindow() ;
}
catch (...)
{
	erreur("Exception NSLdvView SetupWindow.", standardError, 0) ;
}
}

void
NSLdvViewAreaWindow::reinit()
{
  TEXTMETRIC tm ;
	TWindowDC* pWinDC = new TWindowDC(GetParent()) ; // HWnd
	if (pWinDC->GetTextMetrics(tm))
  {
		_pToon->setInterligne(tm.tmHeight + tm.tmInternalLeading + tm.tmExternalLeading + 5) ;
    _pToon->setDrugInterligne(tm.tmHeight + tm.tmInternalLeading + tm.tmExternalLeading + 15) ;
  }
	delete pWinDC ;

  _pHitToon        = 0 ;
	_pCurrentToon    = 0 ;
	_pCurrentConcern = 0 ;

  _pToon->calculRectangleGlobal() ;

  setScrollParams() ;
}

bool
NSLdvViewAreaWindow::PreProcessMsg(MSG &msg)
{
  PRECONDITION(GetHandle()) ;
  HACCEL hAccelerator = getView()->getAcceleratorHandle() ;
  return hAccelerator ? ::TranslateAccelerator(GetHandle(), hAccelerator, &msg) : false ;
}

// -----------------------------------------------------------------------------
//  Description: Peint/repeint tout/une partie de la fen�tre
// -----------------------------------------------------------------------------
void
NSLdvViewAreaWindow::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectAPeindre)
{
  _pToon->skinDraw(&dc, &RectAPeindre) ;

	if (_pToon->getToonsArray()->empty())
		return ;

	int iAncDC = dc.SaveDC() ;

	// Calcul du "rectangle" � repeindre

	NVLdVRect rectARepeindre(getView()) ;
  rectARepeindre = (NVLdVRect&) getAreaLogicalRectFromWindowRect(RectAPeindre) ;

	drawSpecialDates(&dc, &rectARepeindre) ;

	// On demande aux �l�ments qui ont une partie dans ce rectangle de
	// se repeindre, dans l'ordre de leur zOrder
	//
	// Asking each and every element touching that rectangle to redraw,
	// following their zOrder

	int  iLevel      = 0 ;
	int  iFuturLevel = 10000 ;
	bool tourner     = true ;
	while (tourner)
	{
		for (ToonsIter i = _pToon->getToonsArray()->begin(); _pToon->getToonsArray()->end() != i ; i++)
		{
			if ((*i)->iZOrder == iLevel)
			{
      	NSLdvTimeToon* pTimeToon = TYPESAFE_DOWNCAST(*i, NSLdvTimeToon) ;
				if (pTimeToon && pTimeToon->bVisible && pTimeToon->Box.Touches(rectARepeindre))
        {
        	if (((true == getView()->mustDisplayDrugs()) || (NSLdvToon::toonDrug != (*i)->toonType)) &&
              ((true == getView()->mustDisplayGoals()) || (NSLdvToon::toonGoal != (*i)->toonType)) &&
              ((-1 == getView()->getSeverityThreshold()) || (NSLdvToon::toonConcern != (*i)->toonType) ||
               ((NULL != dynamic_cast<NSConcernView *>(*i)) &&
                (NULL != (dynamic_cast<NSConcernView *>(*i))->pConcern) &&
                ((dynamic_cast<NSConcernView *>(*i))->pConcern->getMaxSeverityIndex() > getView()->getSeverityThreshold()))
               )
             )
						(*i)->draw(&dc, &rectARepeindre) ;
        }
			}
			else
			{
				if (((*i)->iZOrder > iLevel) && ((*i)->iZOrder < iFuturLevel))
					iFuturLevel = (*i)->iZOrder ;
			}
		}
		if (iFuturLevel == 10000)
			tourner = false ;
		else
		{
			iLevel = iFuturLevel ;
			iFuturLevel = 10000 ;
		}
	}

	dc.RestoreDC(iAncDC) ;
}

void
NSLdvViewAreaWindow::EvRButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
try
{
  // Outil zoom : click droit = d�-zoomer
  if (NSLdvView::modeZoom == getView()->getMouseMode())
  {
    getView()->CmLdvZoomOut() ;
    return ;
  }

  _currentPoint = (NVLdVPoint&) getAreaLogicalPointFromWindowPoint(point) ;

  // begin - add fab
  _pCurrentToon = HitTest(point) ;

  // NSSsObjView     *pSsObjView = TYPESAFE_DOWNCAST(pCurrentToon, NSSsObjView) ;
  NSConcernView *pPbView = TYPESAFE_DOWNCAST(_pCurrentToon, NSConcernView) ;

  // Click droit sur une pr�occupation existante
  if (NULL != pPbView)
  {
    OWL::TMenu *menu           = new OWL::TMenu(HINSTANCE(*GetApplication()), TResId(IDM_PREOCCUP)) ;
    OWL::TPopupMenu *popupMenu = new OWL::TPopupMenu(*menu) ;

    ClientToScreen(point) ;
    popupMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point, 0, HWindow) ;

    delete popupMenu ;
    delete menu ;
  }

  NSDrugLineView *pDrugView = TYPESAFE_DOWNCAST(_pCurrentToon, NSDrugLineView) ;

  if (NULL != pDrugView)
  {
    // cr�ation d'un menu popup
    NS_CLASSLIB::TPoint lp = point ;

    OWL::TPopupMenu *menu = new OWL::TPopupMenu() ;

    NSSuper* pSuper = pContexte->getSuperviseur() ;

    string sNewD = pSuper->getText("drugManagement", "newDrug") ;
    string sStop = pSuper->getText("drugManagement", "stopThisDrug") ;
    string sKill = pSuper->getText("drugManagement", "suppresThisDrug") ;
    string sModi = pSuper->getText("drugManagement", "modifyThisDrug") ;
    string sPoso = pSuper->getText("drugManagement", "modifyPosology") ;
    string sRene = pSuper->getText("drugManagement", "renewThisDrug") ;
    string sPres = pSuper->getText("drugManagement", "buildAPrescription") ;
    string sRigh = pSuper->getText("rightsManagement", "manageRights") ;

    menu->AppendMenu(MF_STRING, CM_DRUG_NEW,    sNewD.c_str()) ;
    menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
    menu->AppendMenu(MF_STRING, CM_DRUG_MODIF_POSO, sPoso.c_str()) ;
    menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
    menu->AppendMenu(MF_STRING, CM_DRUG_STOP,   sStop.c_str()) ;
    menu->AppendMenu(MF_STRING, CM_DRUG_CHANGE, sModi.c_str()) ;
    menu->AppendMenu(MF_STRING, CM_DRUG_RENEW,  sRene.c_str()) ;
    menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
    menu->AppendMenu(MF_STRING, IDC_MANAGE_RIGHTS,  sRigh.c_str()) ;
    menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
    menu->AppendMenu(MF_STRING, IDC_ORDONNANCE, sPres.c_str()) ;
    menu->AppendMenu(MF_SEPARATOR, 0, 0) ;
    menu->AppendMenu(MF_STRING, CM_DRUG_DELETE, sKill.c_str()) ;

    ClientToScreen(lp) ;
    menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, lp, 0, HWindow) ;
    delete menu ;

    return ;
  }

  // Other cases
  //

  // Calcul du point click�
  NVLdVPoint pointClick(getView()) ;
  pointClick = (NVLdVPoint&) getAreaLogicalPointFromWindowPoint(point) ;

  // On cherche l'�l�ment de plus haut zOrder que touche ce point
  // Looking for the highest zOrder object touching the point

  int  iLevel      = 10000 ;
  int  iFuturLevel = -1 ;
  bool tourner     = true ;
  while (tourner)
  {
    for (ToonsIter i = _pToon->getToonsArray()->begin(); i != _pToon->getToonsArray()->end() ; i++)
    {
      if ((*i)->iZOrder == iLevel)
      {
        NSLdvTimeToon* pTimeToon = TYPESAFE_DOWNCAST(*i, NSLdvTimeToon) ;
        if (pTimeToon && pTimeToon->Box.Contains(pointClick))
        {
          if ((*i)->_bInterceptRButtonDown)
          {
            (*i)->EvRButtonDown() ;
            return ;
          }
        }
      }
      else
      {
        if (((*i)->iZOrder < iLevel) && ((*i)->iZOrder > iFuturLevel))
          iFuturLevel = (*i)->iZOrder ;
      }
    }
    if (iFuturLevel == -1)
      tourner = false ;
    else
    {
      iLevel = iFuturLevel ;
      iFuturLevel = -1 ;
    }
  }

  // Si nous sommes l�, c'est que le click est en dehors de
  // tout objet
  // If we are there, it means that the click is outside any object

  OWL::TPopupMenu *menu = new OWL::TPopupMenu() ;

  string sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "newHealthConcern") ;
  if (pContexte->getPatient()->getReadOnly())
    menu->AppendMenu(MF_GRAYED, 0, sMenuText.c_str()) ;
  else
    menu->AppendMenu(MF_STRING, IDC_NEWPREOCCUP, sMenuText.c_str()) ;

  sMenuText = pContexte->getSuperviseur()->getText("drugManagement", "newDrug") ;
  if (pContexte->getPatient()->getReadOnly())
    menu->AppendMenu(MF_GRAYED, 0, sMenuText.c_str()) ;
  else
    menu->AppendMenu(MF_STRING, CM_DRUG_NEW, sMenuText.c_str()) ;

  menu->AppendMenu(MF_SEPARATOR, 0, 0) ;

  sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "zoom") + string(" (Ctrl+Z)") ;

  if (getView()->isZoomMax())
    menu->AppendMenu(MF_GRAYED, 0, sMenuText.c_str()) ;
  else
    menu->AppendMenu(MF_STRING, CM_LDV_ZOOMIN, sMenuText.c_str()) ;

  sMenuText = pContexte->getSuperviseur()->getText("LigneDeVieMenus", "enlarge") + string(" (Ctrl+E)") ;

  if (getView()->isZoomMin())
    menu->AppendMenu(MF_GRAYED, 0, sMenuText.c_str()) ;
  else
    menu->AppendMenu(MF_STRING, CM_LDV_ZOOMOUT, sMenuText.c_str()) ;

  ClientToScreen(point) ;
  menu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point, 0, HWindow) ;
  delete menu ;
}
catch (...)
{
  erreur("Exception NSLdvViewAreaWindow EvRButtonDown.", standardError, 0) ;
}
}

void
NSLdvViewAreaWindow::CmLdvZoomIn()
{
  getView()->CmLdvZoomIn() ;
}

void
NSLdvViewAreaWindow::CmLdvZoomOut()
{
  getView()->CmLdvZoomOut() ;
}

void
NSLdvViewAreaWindow::EvLButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
try
{
  // Make certain that the focus doesn't get stuck in sub-area
  //
  THandle focusHdle = GetFocus() ;
  if (GetHandle() != focusHdle)
    SetFocus() ;

  if (NSLdvView::modeZoom == getView()->getMouseMode())
  {
    getView()->CmLdvZoomIn() ;
    return ;
	}

	NSLdvToon *theToon = HitTest(point) ;

	_bLButtonDown = true ;
	_pToon2Drag   = theToon ;

	string stheToonLibelle ;

	if      (dynamic_cast<NSConcernView *>(theToon))
	{
  	NSConcernView *pToon = (NSConcernView *)theToon ;
    stheToonLibelle = pToon->pConcern->sTitre ;
    if (_pCurrentConcern != pToon)
    {
    	_pCurrentConcern = pToon ;
      Invalidate() ;
    }
	}
  else if (dynamic_cast<NSSsObjView *>(theToon))
  {    NSSsObjView *pToon = (NSSsObjView *)theToon ;
    stheToonLibelle = pToon->pSsObjet->sTitre ;

    // !!!!!!!!!!!!!!!!!
    // in the sequence :
    // ImgDragDrop->BeginDrag(0, 16, 16) ;
    // "16, 16" is the icon's size (the icon we use in the drag n drop mode)
    // it MUST be change if we want to use another icon (with another size)
    // or another object than an icon
    // this parameter corresponds to the size of the image that is used to
    // follow the cursor in drag n drop mode
    // !!!!!!!!!!!!!!!!!

    getView()->getImgDragDrop()->BeginDrag(0, 16, 16) ;

    // Attention, pour DragEnter, x et y se r�f�rent � la fen�tre et
    // pas � l'espace client. Au contraire point se r�f�re � l'espace
    // client

    //ClientToScreen(point);
    //NS_CLASSLIB::TRect winRect = Parent->GetWindowRect();
    //ImgDragDrop->DragEnter(*this, point.x - winRect.X(), point.y - winRect.Y()) ;

    getView()->getImgDragDrop()->DragEnter(*this, point.x, point.y) ;
	}
	else if (dynamic_cast<NSLdvObjetView *>(theToon))
	{
    NSLdvObjetView *pToon = (NSLdvObjetView *)theToon ;
    stheToonLibelle = pToon->pObjet->sTitre ;

    // !!!!!!!!!!!!!!!!!
    // in the sequence :
    // ImgDragDrop->BeginDrag(1, 16, 16) ;
    // "16, 16" is the icon's size (the icon we use in the drag n drop mode)
    // it MUST be change if we want to use another icon (with another size)
    // or another object than an icon
    // this parameter corresponds to the size of the image that is used to
    // follow the cursor in drag n drop mode
    // !!!!!!!!!!!!!!!!!

    getView()->getImgDragDrop()->BeginDrag(1, 16, 16) ;

    //ClientToScreen(point);
    //NS_CLASSLIB::TRect winRect = Parent->GetWindowRect();
    //ImgDragDrop->DragEnter(*this, point.x - winRect.X(), point.y - winRect.Y()) ;

    getView()->getImgDragDrop()->DragEnter(*this, point.x, point.y) ;
	}
}
catch (...)
{
	erreur("Exception NSLdvViewAreaWindow EvLButtonDown.", standardError, 0) ;
}
}

void
NSLdvViewAreaWindow::EvLButtonUp(uint modKeys, NS_CLASSLIB::TPoint& point)
{
try
{
	NSLdvToon *theToon = HitTest(point) ;

	// End of drag and drop - Fin de drag and drop

	if (_bLButtonDown)
	{
		// Drop d'un SsObjet sur une pr�occupation
		// Dropping a SubObject on a Health concern
		if (TYPESAFE_DOWNCAST(_pToon2Drag, NSSsObjView) && TYPESAFE_DOWNCAST(theToon, NSConcernView))
		{
			NSSsObjView   *pSsObjV = TYPESAFE_DOWNCAST(_pToon2Drag, NSSsObjView) ;
			NSConcernView *pPbV    = TYPESAFE_DOWNCAST(theToon,    NSConcernView) ;

			bool bContinue = true ;

			if (pSsObjV->pSsObjet->tDateHeureDebut < pPbV->pConcern->tDateOuverture)
				bContinue = false ;

			if (pSsObjV->pSsObjet->tDateHeureFin > pPbV->pConcern->tDateFermeture)
				bContinue = false ;

			if (bContinue)
			{
				pSsObjV->setConcernView(pPbV) ;
				pSsObjV->pSsObjet->sConcern = pPbV->pConcern->sTitre ;
				NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
				pGraphe->etablirLien(pSsObjV->pSsObjet->sReference, NSRootLink::problemContactElement, pPbV->pConcern->sReference) ;

				// Le "r�servoir" de sous-objets orphelins est remis � jour lors
				// du rafraichissement de l'affichage

				Invalidate(true) ;
			}
		}

		// Drop d'un Objet sur une pr�occupation
		// Dropping an Object on a Health concern
		else
			if (TYPESAFE_DOWNCAST(_pToon2Drag, NSLdvObjetView) && TYPESAFE_DOWNCAST(theToon, NSConcernView))
    {
      NSLdvObjetView *pObjV = TYPESAFE_DOWNCAST(_pToon2Drag, NSLdvObjetView) ;
      NSConcernView  *pPbV  = TYPESAFE_DOWNCAST(theToon, NSConcernView) ;

      bool bContinue = true ;

      if (pObjV->pObjet->tDateHeureDebut < pPbV->pConcern->tDateOuverture)
        bContinue = false ;

      if (pObjV->pObjet->tDateHeureFin > pPbV->pConcern->tDateFermeture)
        bContinue = false ;

      if (bContinue)
      {
        pObjV->setLigneView((NSLigneView *) pPbV) ;
        pObjV->pObjet->sConcern = pPbV->pConcern->sTitre ;

        VecteurString aVecteurString ;

        NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

        pGraphe->TousLesVraisDocument(pObjV->pObjet->sReference, NSRootLink::problemRelatedTo, &aVecteurString) ;
        if (!aVecteurString.empty())
          pGraphe->detruireTousLesLiensDocument(pObjV->pObjet->sReference, NSRootLink::problemRelatedTo) ;

        pGraphe->etablirLienDocument(pObjV->pObjet->sReference, NSRootLink::problemRelatedTo, pPbV->pConcern->sReference) ;

        pObjV->Box.setTop(pPbV->Box.getTop()) ;
        pObjV->Box.setBottom(pPbV->Box.getBottom()) ;

        Invalidate(true) ;
      }
    }
    // Drop d'un Objet sur la ligne de base
    // Dropping an Object on the base line
    else
      if (TYPESAFE_DOWNCAST(_pToon2Drag, NSLdvObjetView) && TYPESAFE_DOWNCAST(theToon, NSBaseLineView))
    {
      NSLdvObjetView *pObjV = TYPESAFE_DOWNCAST(_pToon2Drag, NSLdvObjetView) ;
      NSBaseLineView *pPbV  = TYPESAFE_DOWNCAST(theToon, NSBaseLineView) ;

      pObjV->setLigneView((NSLigneView *) pPbV) ;
      pObjV->pObjet->sConcern = "" ;

      VecteurString aVecteurString ;

      NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
      pGraphe->TousLesVraisDocument(pObjV->pObjet->sReference, NSRootLink::problemRelatedTo, &aVecteurString) ;
      if (!aVecteurString.empty())
        pGraphe->detruireTousLesLiensDocument(pObjV->pObjet->sReference, NSRootLink::problemRelatedTo) ;

      pObjV->Box.setTop(pPbV->Box.getTop()) ;
      pObjV->Box.setBottom(pPbV->Box.getBottom()) ;

      Invalidate(true) ;
    }
	}

	_bLButtonDown = false ;

	getView()->getImgDragDrop()->DragLeave(getView()->GetWindow()->HWindow) ;
	getView()->getImgDragDrop()->EndDrag() ;

	_pToon2Drag = NULL ;
}
catch (...)
{
	erreur("Exception NSLdvViewAreaWindow EvLButtonUp.", standardError, 0) ;
}
}

void
NSLdvViewAreaWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
try
{
  if (NSLdvView::modeZoom == getView()->getMouseMode())
    return ;

  NSLdvToon *theToon = HitTest(point) ;

  NSLdvObjetView *pObjV = TYPESAFE_DOWNCAST(theToon, NSLdvObjetView) ;
  if ((NULL != pObjV) && (NULL != pObjV->pObjet))
  {
    // pLdVDoc->openLdVObject(pObjV->pObjet) ;

    //
    // On pr�pare l'ouverture de tous les objets � cet endroit
    //
    ArrayOfToons aToons ;
    int          iObjZorder = pObjV->iZOrder ;
    HitTestAll(point, &aToons, iObjZorder, false) ;

    // Pr�caution...
    if (aToons.empty())
      return ;

    // On fabrique l'array d'objets
    //
    ArrayObjets aObjs(getView()->getDoc()) ;
    for (ToonsIter i = aToons.begin(); i != aToons.end(); i++)
    {
      NSLdvObjetView *pTheObjV = TYPESAFE_DOWNCAST(*i, NSLdvObjetView) ;
      if (pTheObjV && pTheObjV->pObjet)
        aObjs.push_back(pTheObjV->pObjet) ;
    }

    if (!(aObjs.empty()))
      getView()->getDoc()->openLdVObjectsInArray(&aObjs, getView()) ;

    // Vider l'array de toons sans d�truire les objets
    //
    for (ToonsIter toonIt = aToons.begin(); toonIt != aToons.end(); )
      aToons.erase(toonIt) ;

    // Vider l'array d'objets sans d�truire les objets
    //
    if (!(aObjs.empty()))
      for (ArrayObjIter objIt = aObjs.begin(); objIt != aObjs.end(); )
        aObjs.erase(objIt) ;

    return ;
  }

  NSConcernView *pCrnV  = TYPESAFE_DOWNCAST(theToon, NSConcernView) ;
  if (pCrnV && pCrnV->pConcern)
  {
    getView()->displayCurvesForBiometricalGoals(pCrnV->pConcern->getNoeud()) ;
    pCrnV->pConcern->sendActivationEvent() ;
    getView()->getDoc()->showConcernProperty(pCrnV->pConcern) ;
    return ;
  }

  NSDrugLineView *pDrgV  = TYPESAFE_DOWNCAST(theToon, NSDrugLineView) ;
  if (pDrgV && pDrgV->pDrug)
  {
    getView()->displayCurvesForBiometricalGoals(pDrgV->pDrug->getNoeud()) ;
    pDrgV->pDrug->sendActivationEvent() ;
    getView()->getDoc()->showDrugProperty(pDrgV->pDrug) ;
    return ;
  }

  NSBaseLineView *pBasV  = TYPESAFE_DOWNCAST(theToon, NSBaseLineView) ;
  if (pBasV)
  {
    getView()->getDoc()->showConcernProperty(0) ;
    return ;
  }
}
catch (...)
{
  erreur("Exception NSLdvViewAreaWindow EvLButtonDblClk.", standardError, 0) ;
}
}

void
NSLdvViewAreaWindow::EvVScroll(UINT scrollCode, UINT thumbPos, HWND hWndCtl)
{
try
{
  int iWorkingSpaceHeight = getWorkingSpaceHeight() ;
  int iCurrentYRange      = _pToon->getGlobalBox()->Height() ;

  int iMaxDeltaPos = iCurrentYRange - iWorkingSpaceHeight ;

  if (iMaxDeltaPos <= 0)
    return ;

  switch(scrollCode)
  {
    case SB_LINEUP:
      increasePosInfDroit(5) ;
      break ;
    case SB_LINEDOWN:
      increasePosInfDroit(-5) ;
      break ;
    case SB_PAGEUP:
      increasePosInfDroit(iWorkingSpaceHeight - 5) ;
      break ;
    case SB_PAGEDOWN:
      increasePosInfDroit(-iWorkingSpaceHeight + 5) ;
      break ;
    case SB_THUMBPOSITION:
    {
      // Just remember that when we set thumbPos, we do iThumbPos = iMaxDeltaPos - getPosInfDroit() ;
      int iNewPosInfDroit = iMaxDeltaPos - thumbPos ;
      int iDeltaPos = iNewPosInfDroit - (int)getPosInfDroit() ;
      increasePosInfDroit(iDeltaPos) ;
      break ;
    }
    case SB_THUMBTRACK:
    {
      // Just remember that when we set thumbPos, we do iThumbPos = iMaxDeltaPos - getPosInfDroit() ;
      int iNewPosInfDroit = iMaxDeltaPos - thumbPos ;
      int iDeltaPos = iNewPosInfDroit - (int)getPosInfDroit() ;
      if ((iDeltaPos >= 5) || (iDeltaPos <= -5))
        increasePosInfDroit(iDeltaPos) ;
      break ;
    }
  }

	if (scrollCode != SB_THUMBTRACK)
  {
    _pToon->reinitCurves() ;
		Invalidate() ;
  }
}
catch (...)
{
	erreur("Exception NSLdvViewAreaWindow EvVScroll.", standardError, 0) ;
}
}

void
NSLdvViewAreaWindow::setScrollParams()
{
  int iWorkingSpaceHeight = getWorkingSpaceHeight() ;
  int iCurrentYRange      = _pToon->getGlobalBox()->Height() ;

  SCROLLINFO scInfo ;
	scInfo.cbSize = (UINT) sizeof(scInfo) ;
	scInfo.fMask = SIF_ALL ;
	scInfo.nMin  = 0 ;
	scInfo.nMax  = 0 ;
	scInfo.nPage = 0 ;
	scInfo.nPos  = 0 ;

  // Every toon fits inside the workingspace
  //
	if (iCurrentYRange <= iWorkingSpaceHeight)
  {
  	SetScrollInfo(SB_VERT, &scInfo, TRUE) ;
    return ;
  }

  // Since we start from the bottom, we must "reverse" nPos
  //
  int iMaxDeltaPos = iCurrentYRange - iWorkingSpaceHeight ;
  int iThumbPos    = iMaxDeltaPos - getPosInfDroit() ;

	scInfo.nMax  = iCurrentYRange ;
	scInfo.nPage = (UINT) (iWorkingSpaceHeight) ;
	scInfo.nPos  = iThumbPos ;

  SetScrollInfo(SB_VERT, &scInfo, TRUE) ;
}

void
NSLdvViewAreaWindow::EvMouseMove(uint modKeys, NS_CLASSLIB::TPoint& point)
{
try
{
  getView()->resetNbTimerTicks() ;

	if (_bLButtonDown)
		getView()->getImgDragDrop()->DragMove(point.x, point.y) ;

	if (getView()->getMouseMode() == NSLdvView::modeZoom)
		point.x += GetSystemMetrics(SM_CXCURSOR) / 2 ;

	// Calcul du point click�

	NVLdVPoint pointClick(getView()) ;
  pointClick = (NVLdVPoint&) getAreaLogicalPointFromWindowPoint(point) ;

	NVLdVTemps tDateHeure = pointClick.getX() ;

	string sDate  = tDateHeure.donneDate() ;
	string sHeure = tDateHeure.donneHeure() ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	char szDate[11] ;
	string sHeureLib ;

	donne_date((char*)(sDate.c_str()), szDate, sLang) ;
	donne_heure((char*)(sHeure.c_str()), sHeureLib) ;

	string sMessage = string(szDate) + string(" ") + sHeureLib ;
	getView()->afficheStatusMessage(&sMessage, false) ;
}
catch (...)
{
	erreur("Exception NSLdvViewAreaWindow EvMouseMove.", standardError, 0) ;
}
}

void
NSLdvViewAreaWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
  getView()->EvKeyDown(key, repeatCount, flags) ;
}

void
NSLdvViewAreaWindow::EvSysKeyDown(uint key, uint repeatCount, uint flags)
{
  getView()->EvSysKeyDown(key, repeatCount, flags) ;
}

void
NSLdvViewAreaWindow::EvSize(uint sizeType, ClassLib::TSize& size)
{
  getView()->EvSize(sizeType, size) ;
}

void
NSLdvViewAreaWindow::EvSetFocus(THandle hWndLostFocus)
{
  getView()->EvSetFocus(hWndLostFocus) ;
}

void
NSLdvViewAreaWindow::CmNewPreoccup()
{
  getView()->CmNewPreoccup() ;
}

void
NSLdvViewAreaWindow::CmEvolPreoccup()
{
  getView()->CmEvolPreoccup() ;
}

void
NSLdvViewAreaWindow::drawSpecialDates(TDC* pDc, NVLdVRect *pRectARepeindre)
{
try
{
	NVLdVTemps tpsBirthDay = getView()->getDateNaissance() ;
	NVLdVTemps tpsNow ;
	tpsNow.takeTime() ;

	if ((pRectARepeindre->getLeft() <= tpsBirthDay) && (pRectARepeindre->getRight() >= tpsBirthDay))
  {
    NVLdVPoint PtBas(getView()) ;
    PtBas.setX(tpsBirthDay) ;
    PtBas.setY(pRectARepeindre->getBottom()) ;
    NS_CLASSLIB::TPoint Bottom = getScrollablePhysicalPoint(PtBas) ;
    pDc->MoveTo(Bottom) ;

    NVLdVPoint PtHaut(PtBas) ;
    PtHaut.setY(pRectARepeindre->getTop() + 1) ;
    NS_CLASSLIB::TPoint Top = getScrollablePhysicalPoint(PtHaut) ;
    pDc->LineTo(Top) ;
  }

  if ((pRectARepeindre->getLeft() <= tpsNow) && (pRectARepeindre->getRight() >= tpsNow))
  {
    NVLdVPoint PtBas(PtBas) ;
    PtBas.setX(tpsNow) ;
    PtBas.setY(pRectARepeindre->getBottom()) ;
    NS_CLASSLIB::TPoint Bottom = getScrollablePhysicalPoint(PtBas) ;
    pDc->MoveTo(Bottom) ;

    NVLdVPoint PtHaut(PtBas) ;
    PtHaut.setY(pRectARepeindre->getTop() + 1) ;
    NS_CLASSLIB::TPoint Top = getScrollablePhysicalPoint(PtHaut) ;
    pDc->LineTo(Top) ;
  }

  return ;
}
catch (...)
{
	erreur("Exception NSLdvViewAreaWindow drawSpecialDates.", standardError, 0) ;
}
}

NSLdvToon*
NSLdvViewAreaWindow::HitTest(NS_CLASSLIB::TPoint& point)
{
try
{
  if (_pToon->getToonsArray()->empty())
    return 0 ;

	NS_CLASSLIB::TPoint ptTemp     = point ;

	NVLdVPoint ldvPoint(getView()) ;
  ldvPoint = (NVLdVPoint&) getAreaLogicalPointFromWindowPoint(point) ;

	int       iToonZOrder = -1 ;
	NSLdvToon *pToon = 0 ;

	for (ToonsIter theToonsIter = _pToon->getToonsArray()->begin() ; _pToon->getToonsArray()->end() != theToonsIter ; theToonsIter++)
	{
  	NSLdvTimeToon* pTimeToon = TYPESAFE_DOWNCAST(*theToonsIter, NSLdvTimeToon) ;
		if (pTimeToon && (pTimeToon->VisibleBox.Contains(ldvPoint)) &&
				(pTimeToon->iZOrder >= iToonZOrder))
		{
			pToon = *theToonsIter ;
			iToonZOrder = (*theToonsIter)->iZOrder ;
		}
	}

  return (pToon) ;
}
catch (...)
{
	erreur("Exception NSLdvViewAreaWindow HitTest.", standardError, 0) ;
  return 0 ;
}
}

//
// Put in pAToons all toons within that point (with the proper zOrder)
//
void
NSLdvViewAreaWindow::HitTestAll(NS_CLASSLIB::TPoint& point, ArrayOfToons* pAToons, int iToonZOrder, bool bResetArray)
{
try
{
  if (NULL == pAToons)
    return ;

  if (true == bResetArray)
  {
    // Vider l'array sans d�truire les objets
    //
    if (false == pAToons->empty())
      for (ToonsIter i = pAToons->begin(); i != pAToons->end(); )
        pAToons->erase(i) ;
  }

  if (_pToon->getToonsArray()->empty())
    return ;

	NS_CLASSLIB::TPoint ptTemp     = point ;

	NVLdVPoint ldvPoint(getView()) ;
  ldvPoint = (NVLdVPoint&) getAreaLogicalPointFromWindowPoint(point) ;

	int iToonZOrder = -1 ;
	for (ToonsIter theToonsIter = _pToon->getToonsArray()->begin() ; _pToon->getToonsArray()->end() != theToonsIter ; theToonsIter++)
  {
  	NSLdvTimeToon* pTimeToon = TYPESAFE_DOWNCAST(*theToonsIter, NSLdvTimeToon) ;
		if (pTimeToon && (pTimeToon->VisibleBox.Contains(ldvPoint)) &&
            (((*theToonsIter)->iZOrder == iToonZOrder) || (iToonZOrder == -1)))
      pAToons->push_back(*theToonsIter) ;
  }

  return ;
}
catch (...)
{
	erreur("Exception NSLdvViewAreaWindow HitTestAll.", standardError, 0) ;
	return ;
}
}

NSLdvToon*
NSLdvViewAreaWindow::nextHitTest(NS_CLASSLIB::TPoint& point, NSLdvToon* pFormerToon)
{
try
{
	NS_CLASSLIB::TRect  clientRect = GetClientRect() ;
	NS_CLASSLIB::TPoint ptOrigine  = clientRect.BottomRight() ;
	NS_CLASSLIB::TPoint ptTemp     = point ;

	// on construit un rectangle autour du point o� se situe le point pass� en
	// param�tre, ce rectangle est en faits un carr� de 32 pixels (2 fois la
	// taille d'un ic�ne) de c�t� dont le point pass� en param�tre est le centre.
	// L'id�e est de tester si ce rectangle � une intersection avec un objet
	// quelconque et de renvoyer cet objet, s'il y a plusieurs objets on
	// retourne le premier objet qui a le ZOrder le plus important.

	// test des dates � une largeur d'ic�ne � gauche, � une largeur d'ic�ne en haut
	ptTemp.x = point.x - ICONWIDTH ;   // les ic�nes font 16 pixels de largeur
	ptTemp.y = point.y + 1 ;   // les ic�nes font 16 pixels de hauteur
	NVLdVPoint  HitTestTopLeft(getView()) ;
	HitTestTopLeft = (NVLdVPoint&) getAreaLogicalPointFromWindowPoint(ptTemp) ;

	// test des dates � une largeur d'ic�ne � droite
	ptTemp.x = point.x ;   // les ic�nes font 16 pixels de largeur
	ptTemp.y = point.y - 1 ;   // les ic�nes font 16 pixels de hauteur
	NVLdVPoint  HitTestBotRigh(getView()) ;
	HitTestBotRigh = (NVLdVPoint&) getAreaLogicalPointFromWindowPoint(ptTemp) ;

	NVLdVRect   rectHitTest = NVLdVRect(getView(), HitTestTopLeft.getX(), HitTestBotRigh.getX(), HitTestTopLeft.getY(), HitTestBotRigh.getY()) ;

//	ArrayOfToons    *pToons = new ArrayOfToons() ;
	int             iToonZOrder = -1 ;
	NSLdvToon       *pToon = 0;

	for (ToonsIter theToonsIter = _pToon->getToonsArray()->begin() ; _pToon->getToonsArray()->end() != theToonsIter ; theToonsIter++)
	{
		if (*theToonsIter == pFormerToon)
			return (pToon) ;

		if (TYPESAFE_DOWNCAST(*theToonsIter, NSBaseLineView))
		{
			NSBaseLineView *pPbV = TYPESAFE_DOWNCAST(*theToonsIter, NSBaseLineView) ;
			if (pPbV->Box.Touches(rectHitTest))
			{
				if ((*theToonsIter)->iZOrder >= iToonZOrder)
				{
					pToon = *theToonsIter ;
					iToonZOrder = (*theToonsIter)->iZOrder ;
				}
			}
		}
		else
			if (TYPESAFE_DOWNCAST(*theToonsIter, NSConcernView))
			{
				NSConcernView *pPbV = TYPESAFE_DOWNCAST(*theToonsIter, NSConcernView) ;
				if (pPbV->Box.Touches(rectHitTest))
				{
					if ((*theToonsIter)->iZOrder >= iToonZOrder)
					{
						pToon = *theToonsIter ;
						iToonZOrder = (*theToonsIter)->iZOrder ;
					}
				}
			}

			else
				if (TYPESAFE_DOWNCAST(*theToonsIter, NSLdvObjetView))
				{
					NSLdvObjetView *pObjV = TYPESAFE_DOWNCAST(*theToonsIter, NSLdvObjetView) ;
					if (pObjV->Box.Touches(rectHitTest))
					{
						if ((*theToonsIter)->iZOrder >= iToonZOrder)
						{
							pToon = *theToonsIter ;
							iToonZOrder = (*theToonsIter)->iZOrder ;
						}
					}
				}

				else
					if (TYPESAFE_DOWNCAST(*theToonsIter, NSSsObjView))
					{
						NSSsObjView *pSsObjV = TYPESAFE_DOWNCAST(*theToonsIter, NSSsObjView) ;
						if (pSsObjV->Box.Touches(rectHitTest))
						{
							if ((*theToonsIter)->iZOrder >= iToonZOrder)
							{
								pToon = *theToonsIter ;
								iToonZOrder = (*theToonsIter)->iZOrder ;
							}
						}
					}
	}

	return (pToon) ;
}
catch (...)
{
	erreur("Exception NSLdvView nextHitTest.", standardError, 0) ;
	return 0;
}
}

void
NSLdvViewAreaWindow::CmChgPreoType()
{
	NSConcernView *pPbView = TYPESAFE_DOWNCAST(_pCurrentToon, NSConcernView) ;
	if (NULL == pPbView)
		return ;

	// Recherche de cette pr�occupation dans l'Array
	// Looking for this health upset in the Array

	if (NULL == pPbView->pConcern)
		return ;

  getView()->CmChgPreoType(pPbView->pConcern) ;
}

void
NSLdvViewAreaWindow::CmChgPreoDate()
{
	NSConcernView *pPbView = TYPESAFE_DOWNCAST(_pCurrentToon, NSConcernView) ;
	if (NULL == pPbView)
		return ;

	// Recherche de cette pr�occupation dans l'Array
	// Looking for this health upset in the Array

	if (NULL == pPbView->pConcern)
		return ;

  getView()->CmChgPreoDate(pPbView->pConcern) ;
}

void
NSLdvViewAreaWindow::CmChgPreoIndx()
{
	NSConcernView *pPbView = TYPESAFE_DOWNCAST(_pCurrentToon, NSConcernView) ;
	if (NULL == pPbView)
		return ;

	// Recherche de cette pr�occupation dans l'Array
	// Looking for this health upset in the Array

	if (NULL == pPbView->pConcern)
		return ;

  getView()->CmChgPreoIndx(pPbView->pConcern, _currentPoint.getX()) ;
}

void
NSLdvViewAreaWindow::CmAddObjectifs()
{
	NSConcernView *pPbView = TYPESAFE_DOWNCAST(_pCurrentToon, NSConcernView) ;
	if (NULL == pPbView)
		return ;

	// Recherche de cette pr�occupation dans l'Array
	// Looking for this health upset in the Array

	if (NULL == pPbView->pConcern)
		return ;

  getView()->CmAddObjectifs(pPbView->pConcern) ;
}

void
NSLdvViewAreaWindow::CmEvolPreoIndx()
{
	NSConcernView *pPbView = TYPESAFE_DOWNCAST(_pCurrentToon, NSConcernView) ;
	if (NULL == pPbView)
		return ;

	// Recherche de cette pr�occupation dans l'Array
	// Looking for this health upset in the Array

	if (NULL == pPbView->pConcern)
		return ;

  getView()->CmEvolPreoIndx(pPbView->pConcern, _currentPoint.getX()) ;
}

void
NSLdvViewAreaWindow::CmEvolPreoType()
{
	NSConcernView *pPbView = TYPESAFE_DOWNCAST(_pCurrentToon, NSConcernView) ;
	if (NULL == pPbView)
		return ;

	// Recherche de cette pr�occupation dans l'Array
	// Looking for this health upset in the Array

	if (NULL == pPbView->pConcern)
		return ;

  getView()->CmEvolPreoType(pPbView->pConcern) ;
}

void
NSLdvViewAreaWindow::CmSuppressPreo()
{
	NSConcernView *pPbView = TYPESAFE_DOWNCAST(_pCurrentToon, NSConcernView) ;
	if (NULL == pPbView)
		return ;

	// Recherche de cette pr�occupation dans l'Array
	// Looking for this health upset in the Array

	if (NULL == pPbView->pConcern)
		return ;

  string sTitleText = pContexte->getSuperviseur()->getText("LigneDeVieManagement", "ligneDeVie") ;
  string sMenuText  = pContexte->getSuperviseur()->getText("LigneDeVieManagement", "doYouReallyWantToDeleteThisHealthConcern?") ;

  int retVal = MessageBox(sMenuText.c_str(), sTitleText.c_str(), MB_YESNO) ;
	if (retVal != IDYES)
		return ;

  getView()->CmSuppressPreo(pPbView->pConcern) ;
}

void
NSLdvViewAreaWindow::CmDrugNew()
{
  NSConcern* pRelatedConcern = 0 ;

  if ((NULL != _pCurrentToon) && (NSLdvToon::toonConcern == _pCurrentToon->toonType))
  {
		NSConcernView *pPbView = TYPESAFE_DOWNCAST(_pCurrentToon, NSConcernView) ;
		if (NULL != pPbView)
      pRelatedConcern = pPbView->pConcern ;
  }

  getView()->CmDrugNewForConcern(pRelatedConcern) ;
}

void
NSLdvViewAreaWindow::CmDrugRenew()
{
  if ((NULL == _pCurrentToon) || (NSLdvToon::toonDrug != _pCurrentToon->toonType))
		return ;

	NSDrugLineView *pDrugLine = TYPESAFE_DOWNCAST(_pCurrentToon, NSDrugLineView) ;
	if ((NULL == pDrugLine) || (NULL == pDrugLine->pDrug))
		return ;

  getView()->CmDrugRenew(pDrugLine->pDrug) ;
}

void
NSLdvViewAreaWindow::CmDrugModify()
{
  if ((NULL == _pCurrentToon) || (NSLdvToon::toonDrug != _pCurrentToon->toonType))
		return ;

	NSDrugLineView *pDrugLine = TYPESAFE_DOWNCAST(_pCurrentToon, NSDrugLineView) ;
	if ((NULL == pDrugLine) || (NULL == pDrugLine->pDrug))
		return ;

  getView()->CmDrugModify(pDrugLine->pDrug) ;
}

void
NSLdvViewAreaWindow::CmDrugChangePoso()
{
  if ((NULL == _pCurrentToon) || (NSLdvToon::toonDrug != _pCurrentToon->toonType))
		return ;

	NSDrugLineView *pDrugLine = TYPESAFE_DOWNCAST(_pCurrentToon, NSDrugLineView) ;
	if ((NULL == pDrugLine) || (NULL == pDrugLine->pDrug))
		return ;

  getView()->CmDrugChangePoso(pDrugLine->pDrug) ;
}

void
NSLdvViewAreaWindow::CmDrugStop()
{
  if ((NULL == _pCurrentToon) || (NSLdvToon::toonDrug != _pCurrentToon->toonType))
		return ;

	NSDrugLineView *pDrugLine = TYPESAFE_DOWNCAST(_pCurrentToon, NSDrugLineView) ;
	if ((NULL == pDrugLine) || (NULL == pDrugLine->pDrug))
		return ;

  getView()->CmDrugStop(pDrugLine->pDrug) ;
}

void
NSLdvViewAreaWindow::CmDrugDelete()
{
  if ((NULL == _pCurrentToon) || (NSLdvToon::toonDrug != _pCurrentToon->toonType))
		return ;

	NSDrugLineView *pDrugLine = TYPESAFE_DOWNCAST(_pCurrentToon, NSDrugLineView) ;
	if ((NULL == pDrugLine) || (NULL == pDrugLine->pDrug))
		return ;

  getView()->CmDrugDelete(pDrugLine->pDrug) ;
}

void
NSLdvViewAreaWindow::CmNewDrugsFromRefForConcern()
{
  if (NULL == _pCurrentToon)
		return ;

	NSConcernView *pPbView = TYPESAFE_DOWNCAST(_pCurrentToon, NSConcernView) ;
	if (NULL == pPbView)
		return ;

  getView()->CmNewDrugsFromRefForConcern(pPbView->pConcern) ;
}

void
NSLdvViewAreaWindow::CmNewGoalsFromRefForConcern()
{
  if ((NULL == _pCurrentToon) || (NSLdvToon::toonDrug != _pCurrentToon->toonType))
		return ;

	NSConcernView *pPbView = TYPESAFE_DOWNCAST(_pCurrentToon, NSConcernView) ;
	if (NULL != pPbView)
		return ;

  getView()->CmNewGoalsFromRefForConcern(pPbView->pConcern) ;
}

void
NSLdvViewAreaWindow::CmDrugPrescription()
{
  getView()->CmDrugPrescription() ;
}

void
NSLdvViewAreaWindow::CmManageRights()
{
  if (NULL == _pCurrentToon)
    return ;

	NSConcernView *pPbView = TYPESAFE_DOWNCAST(_pCurrentToon, NSConcernView) ;
	if (NULL != pPbView)
  {
		if (NULL == pPbView->pConcern)
			return ;

    getView()->CmManageRights(pPbView->pConcern) ;

    return ;
	}

  NSDrugLineView *pDrugLine = TYPESAFE_DOWNCAST(_pCurrentToon, NSDrugLineView) ;
  if (NULL != pDrugLine)
  {
    if (NULL == pDrugLine->pDrug)
      return ;

    getView()->CmManageRights(pDrugLine->pDrug) ;

    return ;
  }
}

int
NSLdvViewAreaWindow::getPixelPosAboveChronoline(int iYPos)
{
  return iYPos ;
}

int
NSLdvViewAreaWindow::getPixelPosAboveBaseline(int iYPos)
{
	//
  // Return a point above ChronoLine and above Base Line
  //
	return iYPos + getLargeurBaseline() + getInterligne() ;
}

NS_CLASSLIB::TRect
NSLdvViewAreaWindow::getClientRectAboveChronoline()
{
	NS_CLASSLIB::TRect clientRect = GetClientRect() ;

  int iBottom = getPixelPosAboveChronoline(0) ;
  int iTop    = clientRect.Height() ;
  int iLeft   = 0 ;
  int iRight  = clientRect.Width() ;

/*
  NSLdvWindowToon* pLdvWinToon = getLdVWinToon(NSLdvToon::toonYAxis) ;
  if (NULL != pLdvWinToon)
  	// iLeft += pLdvWinToon->wVisibleBox.Width() ;
    iLeft += pLdvWinToon->donneVisibleRectangle().Width() ;
*/

  return NS_CLASSLIB::TRect(iLeft, iBottom, iRight, iTop) ;
}

NS_CLASSLIB::TRect
NSLdvViewAreaWindow::getClientRectAboveBaseline()
{
	NS_CLASSLIB::TRect cR = getClientRectAboveChronoline() ;
  return NS_CLASSLIB::TRect(cR.Left(), getPixelPosAboveBaseline(0), cR.Right(), cR.Bottom()) ;
}

int
NSLdvViewAreaWindow::getProccupGrossHeight()
{
	return getLargeurLigne() + getInterligne() ;
}

long
NSLdvViewAreaWindow::preoccupDonneBottomBox(int iIndex)
{
	// Memo : Preoccup 1 -> iIndex == 0
	// return (getPixelPosAboveBaseline(0) + iIndex * getProccupGrossHeight()) ;
  return preoccupDonneBottomLine(iIndex) ;
}

long
NSLdvViewAreaWindow::preoccupDonneTopBox(int iIndex)
{
	// Memo : Preoccup 1 -> iIndex == 0
	return preoccupDonneBottomBox(iIndex) + getProccupGrossHeight() ;
}

long
NSLdvViewAreaWindow::preoccupDonneBottomLine(int iIndex)
{
	// Memo : Preoccup 1 -> iIndex == 0
  //        Baseline   -> iIndex == -1

  if (iIndex >= 0)
	  return (getPixelPosAboveBaseline(0) + iIndex * getProccupGrossHeight()) ;
  else
    return _pToon->getBottomMargin() ;
}

long
NSLdvViewAreaWindow::preoccupDonneTopLine(int iIndex)
{
	// Memo : Preoccup 1 -> iIndex == 0
	return (preoccupDonneBottomLine(iIndex) + getLargeurLigne()) ;
}

int
NSLdvViewAreaWindow::getGoalBasePosition()
{
	return (preoccupDonneTopBox(getMaxConcernIndex()) + getInterligne()) ;
}

int
NSLdvViewAreaWindow::getGoalGrossHeight()
{
	return getLargeurSubLigne() + getInterligne() ;
}

long
NSLdvViewAreaWindow::goalDonneBottomBox(int iIndex)
{
	return (getGoalBasePosition() + iIndex * getGoalGrossHeight()) ;
}

long
NSLdvViewAreaWindow::goalDonneTopBox(int iIndex)
{
	return (goalDonneBottomBox(iIndex) + getGoalGrossHeight()) ;
}

long
NSLdvViewAreaWindow::goalDonneBottomLine(int iIndex)
{
	return (getGoalBasePosition() + iIndex * getGoalGrossHeight()) ;
}

long
NSLdvViewAreaWindow::goalDonneTopLine(int iIndex)
{
	return (goalDonneBottomLine(iIndex) + getLargeurSubLigne()) ;
}

int
NSLdvViewAreaWindow::getDrugBasePosition()
{
	return (goalDonneTopBox(getMaxGoalIndex()) + getInterligne()) ;
}

int
NSLdvViewAreaWindow::getDrugGrossHeight()
{
	return getLargeurSubLigne() + getDrugInterligne() ;
}

long
NSLdvViewAreaWindow::drugDonneBottomBox(int iIndex)
{
	return (getDrugBasePosition() + iIndex * getDrugGrossHeight()) ;
}

long
NSLdvViewAreaWindow::drugDonneTopBox(int iIndex)
{
	return (drugDonneBottomBox(iIndex) + getDrugGrossHeight()) ;
}

long
NSLdvViewAreaWindow::drugDonneBottomLine(int iIndex)
{
	return (getDrugBasePosition() + iIndex * getDrugGrossHeight()) ;
}

long
NSLdvViewAreaWindow::drugDonneTopLine(int iIndex)
{
	return (drugDonneBottomLine(iIndex) + getLargeurSubLigne() ) ;
}

void
NSLdvViewAreaWindow::showContextHelp()
{
	NS_CLASSLIB::TPoint curPos;
	GetCursorPos(curPos);
	ScreenToClient(curPos);

	NSLdvToon* pNewHitToon = HitTest(curPos) ;
	if (NULL == _pHitToon)
	{
		_pHitToon = pNewHitToon;
		return ;
	}
	if (pNewHitToon != _pHitToon)
	{
		_pHitToon = pNewHitToon ;
		return ;
	}

	if (dynamic_cast<NSLdvObjetView *>(_pHitToon))
	{
		NSLdvObjetView *pObject = (NSLdvObjetView *)_pHitToon ;
		string stheToonLibelle = pObject->pObjet->sTitre ;

		NSLdvToon* pOtherToon = nextHitTest(curPos, _pHitToon) ;
		while (pOtherToon)
		{
			if (dynamic_cast<NSLdvObjetView *>(pOtherToon))
			{
				pObject = (NSLdvObjetView *)pOtherToon ;
				stheToonLibelle += string(1, '\n') + pObject->pObjet->sTitre ;
			}
			pOtherToon = nextHitTest(curPos, pOtherToon) ;
		}

		NS_CLASSLIB::TRect rectDoc = _pHitToon->donneRectangle() ;
		rectDoc.right += ICONWIDTH ;
		getView()->getToolTip()->Show(rectDoc, &stheToonLibelle, 0,-1,NULL,NULL, 10) ;
	}
  else
    getView()->getToolTip()->Hide() ;
}

NS_CLASSLIB::TPoint
NSLdvViewAreaWindow::getAreaPhysicalPoint(NVLdVPoint ldvPoint)
{
	// On place le point en bas � droite
	// Instantiating the point as clientRect bottom right point
  //
	NS_CLASSLIB::TRect  clientRect    = GetClientRect() ;
	NS_CLASSLIB::TPoint physicalPoint = clientRect.BottomRight() ;

	// Translation du point
	// Translating the point
	NVLdVRect ldvRect(getView(),
										ldvPoint.getX(),
										getView()->getDateHeureInfDroit(),
										0, // lPosInfDroit,
										ldvPoint.getY()) ;

	physicalPoint.x -= getView()->getPhysicalWidthFromTimeUnit(ldvRect.Width()) ;

  if (physicalPoint.x > numeric_limits<int>::max())
  	physicalPoint.x = numeric_limits<int>::max() ;
  if (physicalPoint.x < - numeric_limits<int>::max())
  	physicalPoint.x = - numeric_limits<int>::max() ;

	physicalPoint.y += ldvRect.Height() ;

  if (physicalPoint.y > numeric_limits<int>::max())
  	physicalPoint.y = numeric_limits<int>::max() ;
  if (physicalPoint.y < - numeric_limits<int>::max())
  	physicalPoint.y = - numeric_limits<int>::max() ;

	return physicalPoint ;
}

NS_CLASSLIB::TRect
NSLdvViewAreaWindow::getAreaPhysicalRect(NVLdVRect ldvRect)
{
	NS_CLASSLIB::TPoint ptTopLeft = getAreaPhysicalPoint(ldvRect.TopLeft()) ;
	NS_CLASSLIB::TPoint ptBotRigh = getAreaPhysicalPoint(ldvRect.BottomRight()) ;

  return NS_CLASSLIB::TRect(ptTopLeft, ptBotRigh) ;
}

NS_CLASSLIB::TRect
NSLdvViewAreaWindow::getAreaPhysicalRect(NS_CLASSLIB::TRect ldvWinRect)
{
  NS_CLASSLIB::TRect  clientRect    = GetClientRect() ;
	NS_CLASSLIB::TPoint physicalPoint = clientRect.BottomRight() ;

  NS_CLASSLIB::TPoint ptTopLeft = ldvWinRect.TopLeft() ;
  ptTopLeft.y = clientRect.Height() - ptTopLeft.y ;
  if (ptTopLeft.y > numeric_limits<int>::max())
  	ptTopLeft.y = numeric_limits<int>::max() ;
  if (ptTopLeft.y < - numeric_limits<int>::max())
  	ptTopLeft.y = - numeric_limits<int>::max() ;

	NS_CLASSLIB::TPoint ptBotRigh = ldvWinRect.BottomRight() ;
  ptBotRigh.y = clientRect.Height() - ptBotRigh.y ;
  if (ptBotRigh.y > numeric_limits<int>::max())
  	ptBotRigh.y = numeric_limits<int>::max() ;
  if (ptBotRigh.y < - numeric_limits<int>::max())
  	ptBotRigh.y = - numeric_limits<int>::max() ;

  return NS_CLASSLIB::TRect(ptTopLeft, ptBotRigh) ;
}

NS_CLASSLIB::TPoint
NSLdvViewAreaWindow::getScrollablePhysicalPoint(NVLdVPoint ldvPoint)
{
	// On place le point en bas � droite
	// Instantiating the point as clientRect bottom right point
  //
	NS_CLASSLIB::TRect  clientRect    = GetClientRect() ;
	NS_CLASSLIB::TPoint physicalPoint = clientRect.BottomRight() ;

	// Translation du point
	// Translating the point
	NVLdVRect ldvRect(getView(),
										ldvPoint.getX(),
										getView()->getDateHeureInfDroit(),
										_lPosInfDroit,
										ldvPoint.getY()) ;

	physicalPoint.x -= getView()->getPhysicalWidthFromTimeUnit(ldvRect.Width()) ;

  if (physicalPoint.x > numeric_limits<int>::max())
  	physicalPoint.x = numeric_limits<int>::max() ;
  if (physicalPoint.x < - numeric_limits<int>::max())
  	physicalPoint.x = - numeric_limits<int>::max() ;

	physicalPoint.y += ldvRect.Height() ;

  if (physicalPoint.y > numeric_limits<int>::max())
  	physicalPoint.y = numeric_limits<int>::max() ;
  if (physicalPoint.y < - numeric_limits<int>::max())
  	physicalPoint.y = - numeric_limits<int>::max() ;

	return physicalPoint ;
}

NS_CLASSLIB::TRect
NSLdvViewAreaWindow::getScrollablePhysicalRect(NVLdVRect ldvRect)
{
	NS_CLASSLIB::TPoint ptTopLeft = getScrollablePhysicalPoint(ldvRect.TopLeft()) ;
	NS_CLASSLIB::TPoint ptBotRigh = getScrollablePhysicalPoint(ldvRect.BottomRight()) ;

  return NS_CLASSLIB::TRect(ptTopLeft, ptBotRigh) ;
}

NVLdVPoint
NSLdvViewAreaWindow::getAreaLogicalPointFromWindowPoint(NS_CLASSLIB::TPoint winPoint)
{
  NVLdVPoint resultPt(getView()) ;

  NS_CLASSLIB::TRect clientRect = GetClientRect() ;
  NS_CLASSLIB::TPoint ptOrigine = clientRect.BottomRight() ;

  NVLdVTemps tX = getView()->getDateHeureInfDroit() ;
	//
	// Calcul de la diff�rence en pixels sur l'axe des X (temps)
	//
	int iDelta = getView()->getTimeUnitFromPhysicalWidth(winPoint.X() - ptOrigine.X()) ;
	//
	// Conversion en AAAAMMJJhhmmss
	//
	switch (getView()->getXunit())
	{
		case pixAns :
			tX.ajouteAns(iDelta) ;
			break ;
		case pixMois :
			tX.ajouteMois(iDelta) ;
			break ;
		case pixSemaine :
			tX.ajouteJours(iDelta * 7) ;
			break ;
		case pixJour :
			tX.ajouteJours(iDelta) ;
			break ;
		case pixHeure :
			tX.ajouteHeures(iDelta) ;
			break ;
		case pixMinute :
			tX.ajouteMinutes(iDelta) ;
			break ;
		case pixSeconde :
			tX.ajouteSecondes(iDelta) ;
			break ;
	}
  resultPt.setX(tX) ;

	//
	// Calcul de la diff�rence en pixels sur l'axe des Y
	//
	long dY = long(ptOrigine.Y() - winPoint.Y()) ;

  // Baseline doesn't scroll
  //
  if (dY > getPixelPosAboveBaseline(0))
    dY += _pToon->getPosInfDroit() ;

  resultPt.setY(dY) ;

  return resultPt ;
}

NVLdVRect
NSLdvViewAreaWindow::getAreaLogicalRectFromWindowRect(NS_CLASSLIB::TRect scrRect)
{
  // fixme : if a point is in Baseline (no scroll) and another above (scroll),
  //         then there is a problem

  NVLdVPoint ptTopLeft = getAreaLogicalPointFromWindowPoint(scrRect.TopLeft()) ;
	NVLdVPoint ptBotRigh = getAreaLogicalPointFromWindowPoint(scrRect.BottomRight()) ;

  return NVLdVRect(getView(), &ptTopLeft, &ptBotRigh) ;
}

void
NSLdvViewAreaWindow::increasePosInfDroit(int iDeltaPos)
{
	if (0 == iDeltaPos)
		return ;
	if ((0 >= _lPosInfDroit) && (iDeltaPos < 0))
		return ;

	int iMaxPos = _pToon->getGlobalBox()->Height() - getWorkingSpaceHeight() ;
  if ((iMaxPos <= _lPosInfDroit) && (iDeltaPos > 0))
		return ;

	if (_lPosInfDroit + iDeltaPos <= 0)
  	_lPosInfDroit = 0 ;
	else if (_lPosInfDroit + iDeltaPos >= iMaxPos)
  	_lPosInfDroit = iMaxPos ;
  else
  	_lPosInfDroit += iDeltaPos ;

  setScrollParams() ;

	InvalidateRect(getWorkingSpaceRect(), true) ;

	return ;
}

void
NSLdvViewAreaWindow::setPosInfDroit(long lNewPosition)
{
	if (lNewPosition < 0)
  	_lPosInfDroit = 0 ;
	else if (lNewPosition > _pToon->getGlobalBox()->Height() - getWorkingSpaceHeight())
  	_lPosInfDroit = _pToon->getGlobalBox()->Height() - getWorkingSpaceHeight() ;
  else
  	_lPosInfDroit = lNewPosition ;

  setScrollParams() ;

	Invalidate() ;
	return ;
}

int
NSLdvViewAreaWindow::getWorkingSpaceTop()
{
	NS_CLASSLIB::TRect clientRect = getWorkingSpaceRect() ;
	return clientRect.Top() ;
}

int
NSLdvViewAreaWindow::getWorkingSpaceBottom()
{
	NS_CLASSLIB::TRect clientRect = getWorkingSpaceRect() ;
	return clientRect.Bottom() ;
}

int
NSLdvViewAreaWindow::getWorkingSpaceRight()
{
	NS_CLASSLIB::TRect clientRect = getWorkingSpaceRect() ;
	return clientRect.Right() ;
}

int
NSLdvViewAreaWindow::getWorkingSpaceLeft()
{
	NS_CLASSLIB::TRect clientRect = getWorkingSpaceRect() ;
	return clientRect.Left() ;
}

int
NSLdvViewAreaWindow::getWorkingSpaceHeight()
{
  NS_CLASSLIB::TRect clientRect = getWorkingSpaceRect() ;
	return clientRect.Height() ;
}

int
NSLdvViewAreaWindow::getWorkingSpaceWidth()
{
  NS_CLASSLIB::TRect clientRect = getWorkingSpaceRect() ;
	return clientRect.Width() ;
}

NS_CLASSLIB::TRect
NSLdvViewAreaWindow::getWorkingSpaceRect()
{
	NS_CLASSLIB::TRect LdvFrameRect = getClientRectAboveBaseline() ;
  int iClientRectHeight = GetClientRect().Height() ;

	return NS_CLASSLIB::TRect(LdvFrameRect.Left(),
                            iClientRectHeight - LdvFrameRect.Bottom(),
                            LdvFrameRect.Right(),
                            iClientRectHeight - LdvFrameRect.Top()) ;
}


// -----------------------------------------------------------------------------
// --------------------- METHODES DE NSTimeZoomLevel ---------------------------
// -----------------------------------------------------------------------------

NSTimeZoomLevel::NSTimeZoomLevel(pixUnit iPixUnit, int iNbUPP, int iLowerUPP, int iUpperUPP)
{
	_iPixUnit                   = iPixUnit ;
	_iNumberOfUnitPerPixel      = iNbUPP ;
	_iUpperLimitForUnitPerPixel = iUpperUPP ;
	_iLowerLimitForUnitPerPixel = iLowerUPP ;
}

NSTimeZoomLevel::~NSTimeZoomLevel()
{
}

// -----------------------------------------------------------------------------
// ------------------------ METHODES DE NSLdvToon ------------------------------
// -----------------------------------------------------------------------------

NSLdvToon::NSLdvToon(NSContexte* pCtx, NSLdvView* pTheView)	        :NSRoot(pCtx)
{
	pView    = pTheView ;

	sLibelle = "" ;
	iZOrder  = 0 ;

  bVisible = true ;

  _bInterceptRButtonDown = true ;
}

NSLdvToon::NSLdvToon(NSLdvToon& rv)
          :NSRoot(rv.pContexte)
{
	initialiser(&rv) ;
}

void
NSLdvToon::initialiser(NSLdvToon* pSrc)
{
	pView        = pSrc->pView ;

	sLibelle     = pSrc->sLibelle ;
	iZOrder      = pSrc->iZOrder ;
	toonType     = pSrc->toonType ;
  toonCategory = pSrc->toonCategory ;
  bVisible     = pSrc->bVisible ;

  _bInterceptRButtonDown = pSrc->_bInterceptRButtonDown ;
}

NSLdvToon&
NSLdvToon::operator=(NSLdvToon& src)
{
	if (this == &src)
		return *this ;

	initialiser(&src);

	return *this;
}

// -----------------------------------------------------------------------------
// ---------------------- METHODES DE NSLdvTimeToon ----------------------------
// -----------------------------------------------------------------------------

NSLdvTimeToon::NSLdvTimeToon(NSContexte* pCtx, NSLdvViewArea *pWorkArea, bool bVScrollEnabled)
              :NSLdvToon(pCtx, pWorkArea->getView()), Box(pWorkArea->getView()), VisibleBox(pWorkArea->getView())
{
	toonCategory            = timeToon ;

	_iFixedWidthInPixels    = 0 ;
  _bVerticalScrollEnabled = bVScrollEnabled ;
  _pWorkingArea           = pWorkArea ;
}


NSLdvTimeToon::NSLdvTimeToon(NSLdvTimeToon& rv)
              :NSLdvToon(rv.pContexte, rv.pView), Box(rv.pView), VisibleBox(rv.pView)
{
	initialiser(&rv) ;
}

void
NSLdvTimeToon::initialiser(NSLdvTimeToon* pSrc)
{
  NSLdvToon::initialiser((NSLdvToon*)pSrc) ;

	Box         = pSrc->Box ;
	VisibleBox  = pSrc->VisibleBox ;

  _iFixedWidthInPixels    = pSrc->_iFixedWidthInPixels ;
  _bVerticalScrollEnabled = pSrc->_bVerticalScrollEnabled ;
  _pWorkingArea           = pSrc->_pWorkingArea ;
}

NSLdvTimeToon&
NSLdvTimeToon::operator=(NSLdvTimeToon& src)
{
	if (this == &src)
		return *this ;

	initialiser(&src);

	return *this;
}

void
NSLdvTimeToon::fixeRectangle(	NVLdVTemps tDeb,
													NVLdVTemps tFin,
													long lPlancher,
													long lPlafond)
{
	Box.initialise(tDeb, tFin, lPlancher, lPlafond) ;
}

NS_CLASSLIB::TRect
NSLdvTimeToon::donneRectangle()
{
	NVLdVPoint ldvTL = Box.TopLeft() ;
	NVLdVPoint ldvBR = Box.BottomRight() ;

  NS_CLASSLIB::TPoint ptTL ;
  NS_CLASSLIB::TPoint ptBR ;

	if (_bVerticalScrollEnabled)
	{
  	ptTL = _pWorkingArea->getScrollablePhysicalPoint(ldvTL) ;
  	ptBR = _pWorkingArea->getScrollablePhysicalPoint(ldvBR) ;
	}
  else
	{
  	ptTL = _pWorkingArea->getAreaPhysicalPoint(ldvTL) ;
  	ptBR = _pWorkingArea->getAreaPhysicalPoint(ldvBR) ;
  }

	return NS_CLASSLIB::TRect(ptTL, ptBR) ;
}

NS_CLASSLIB::TRect
NSLdvTimeToon::donneVisibleRectangle()
{
	NVLdVPoint ldvTL = VisibleBox.TopLeft() ;
	NVLdVPoint ldvBR = VisibleBox.BottomRight() ;

  NS_CLASSLIB::TPoint ptTL ;
	NS_CLASSLIB::TPoint ptBR ;

	if (_bVerticalScrollEnabled)
	{
		ptTL = _pWorkingArea->getScrollablePhysicalPoint(ldvTL) ;
  	ptBR = _pWorkingArea->getScrollablePhysicalPoint(ldvBR) ;
	}
  else
	{
  	ptTL = _pWorkingArea->getAreaPhysicalPoint(ldvTL) ;
  	ptBR = _pWorkingArea->getAreaPhysicalPoint(ldvBR) ;
  }

	return NS_CLASSLIB::TRect(ptTL, ptBR) ;
}

void
NSLdvTimeToon::donneRectangle(NVLdVTemps* ptDeb,
													NVLdVTemps* ptFin,
													long* plPlancher,
													long* plPlafond)
{
	*ptDeb      = Box.getLeft() ;
	*ptFin      = Box.getRight() ;
	*plPlancher = Box.getTop() ;
	*plPlafond  = Box.getBottom() ;
}

// If an object has a fixed size, for example an icon, its NVLdVRect width
// depends on the time unit scale, so, we have to adjust it each time the
// time unit changes
//
void
NSLdvTimeToon::adjustToPixelTimeUnit()
{
	if (_iFixedWidthInPixels <= 0)
		return ;

	NS_CLASSLIB::TRect pixelRect ;
	if (_bVerticalScrollEnabled)
		pixelRect = _pWorkingArea->getScrollablePhysicalRect(Box) ;
  else
  	pixelRect = _pWorkingArea->getAreaPhysicalRect(Box) ;

  int iExcedingPixels = _iFixedWidthInPixels - pixelRect.Width() ;

  if (iExcedingPixels <= 0)
  {
  	VisibleBox = Box ;
    return ;
  }

  int iExcedingPixelsLeft  = iExcedingPixels / 2 ;
  int iExcedingPixelsRight = iExcedingPixels - iExcedingPixelsLeft ;

  string sPixelUnitCode = pView->getLdvPixLexiqueCode() ;
  if (sPixelUnitCode == string(""))
		return ;

  NVLdVTemps startingTime = Box.getLeft() ;
  if (iExcedingPixelsLeft != 0)
  	startingTime.ajouteTemps(-iExcedingPixelsLeft, sPixelUnitCode, pContexte) ;

  NVLdVTemps endingTime   = Box.getRight() ;
  if (iExcedingPixelsRight != 0)
  	endingTime.ajouteTemps(iExcedingPixelsRight, sPixelUnitCode, pContexte) ;

  VisibleBox.setLeft(startingTime) ;
  VisibleBox.setRight(endingTime) ;
}

// -----------------------------------------------------------------------------
// ---------------------- METHODES DE NSPbModifView ----------------------------// -----------------------------------------------------------------------------

NSPbModifView::NSPbModifView(NSContexte* pCtx, NSLdvViewArea *pWorkArea, NSConcernModifier* pModif)              :NSLdvTimeToon(pCtx, pWorkArea, true)

{
	pModifier = pModif;

	Box.setLeft(pModifier->tDateHeureDeb);
	Box.setRight(pModifier->tDateHeureFin);

	iZOrder  = LEVEL_PREOCCUP + RELPRLEVEL_PBEVENT;
	toonType = toonConcernEvent;
}

NSPbModifView::NSPbModifView(NSPbModifView& rv)
	            :NSLdvTimeToon(rv.pContexte, rv._pWorkingArea, rv._bVerticalScrollEnabled)
{
	initialiser((NSLdvTimeToon*)(&rv));
}

NSPbModifView::~NSPbModifView()
{
}

void
NSPbModifView::SetupWindow()
{
}

void
NSPbModifView::draw(TDC* pDc, NVLdVRect* pRectARepeindre)
{
}


void
NSPbModifView::EvRButtonDown()
{
}


void
NSPbModifView::createComponents(ArrayOfToons* pToonsArray)
{
}


NSPbModifView&
NSPbModifView::operator=(NSPbModifView& src)
{
	if (this == &src)
		return *this ;

	initialiser((NSLdvTimeToon*)(&src));

  return *this;
}


// -----------------------------------------------------------------------------
// ---------------------- METHODES DE NSConcernView ----------------------------
// -----------------------------------------------------------------------------

NSConcernView::NSConcernView(NSContexte* pCtx, NSLdvViewArea *pWorkArea, NSConcern* pPb, int iIdx /*= -1*/)
              :NSLigneView(pCtx, pWorkArea, true)
{
	pConcern = pPb;

	// Recherche de la ligne capable d'h�berger cette pr�occupation de sant�
	iIndex = iIdx;

	if (pWorkArea->getLargeurLigne() >= 30)
	{
		iLeftMargin   = 2;
		iRigthMargin  = 2;
		iTopMargin    = 2;
		iBottomMargin = 2;
	}
	else
	{
		iLeftMargin   = 1;
		iRigthMargin  = 1;
		iTopMargin    = 1;
		iBottomMargin = 1;
	}

	Box.setLeft(pConcern->tDateOuverture);

	if (!(pConcern->tDateFermeture.estVide()))
		Box.setRight(pConcern->tDateFermeture);
	else
	{
		NVLdVTemps tNoLimit;
		tNoLimit.setNoLimit();
		Box.setRight(tNoLimit);
	}

	iZOrder  = LEVEL_PREOCCUP + RELPRLEVEL_LINE;
	toonType = toonConcern ;

/*
	pConcern = pPb;

	Box.setLeft(pConcern->tDateDebut);

	if (pConcern->tDateFermeture.estVide())
		Box.setRight(pConcern->tDateFermeture);
	else
		if (!(pConcern->tDateAutoClose.estVide()))
			Box.setRight(pConcern->tDateAutoClose);
		else
		{
			NVLdVTemps tNoLimit;
			tNoLimit.setNoLimit();
			Box.setRight(tNoLimit);
		}

	iZOrder  = LEVEL_PREOCCUP + RELPRLEVEL_PROBLEM;
	toonType = toonConcern;
*/
}


NSConcernView::NSConcernView(NSConcernView& rv)
              :NSLigneView(rv.pContexte, rv._pWorkingArea, rv._bVerticalScrollEnabled)
{
	initialiser((NSLdvTimeToon*)(&rv)) ;

	pConcern        = rv.pConcern ;
	iIndex          = rv.iIndex ;
	iLeftMargin     = rv.iLeftMargin ;
	iRigthMargin    = rv.iRigthMargin ;
	iTopMargin      = rv.iTopMargin ;
	iBottomMargin   = rv.iBottomMargin ;
}


NSConcernView::~NSConcernView()
{
}

void
NSConcernView::SetupWindow()
{
}

void
NSConcernView::draw(TDC* pDc, NVLdVRect* pRectARepeindre)
{
	OWL::TBrush* pPinceau;
	OWL::TPen*   pPenEclaire;
	OWL::TPen*   pPenOmbre;
	OWL::TPen*   pPenTransition;

	// Sauvegarde des �l�ments en cours (pen et brush)
	HPEN oldPen     = (HPEN) pDc->GetCurrentObject(OBJ_PEN) ;
	HBRUSH oldBrush = (HBRUSH) pDc->GetCurrentObject(OBJ_BRUSH) ;

	if (this == _pWorkingArea->getCurrentConcern())
	{
		pPinceau        = new OWL::TBrush(pView->pPinceauFond->GetHandle()) ;
		pPenEclaire     = pView->pSelPenEclaire ;
		pPenOmbre       = pView->pSelPenOmbre ;
		pPenTransition  = pView->pSelPenTransition ;
	}
	else
	{
  	if (pView->useSystemColors())
    {
    	pPinceau        = new OWL::TBrush(pView->pPinceauFondSys->GetHandle()) ;
      pPenEclaire     = pView->pPenEclaireSys ;
      pPenOmbre       = pView->pPenOmbreSys ;
      pPenTransition  = pView->pPenTransitionSys ;
    }
    else
    {
    	pPinceau        = new OWL::TBrush(pView->pPinceauFond->GetHandle()) ;
      pPenEclaire     = pView->pPenEclaire ;
      pPenOmbre       = pView->pPenOmbre ;
      pPenTransition  = pView->pPenTransition ;
    }
	}
	// Rectangle � repeindre pour l'objet lui m�me
	// Object's rectangle to repaint
	NVLdVPoint ldvTopLeft(pView) ;
	// Left time
	NVLdVTemps tLeftTime = pRectARepeindre->getLeft() ;
	if (pConcern->tDateOuverture > tLeftTime)
		tLeftTime = pConcern->tDateOuverture ;

	ldvTopLeft.setX(tLeftTime) ;
	ldvTopLeft.setY(_pWorkingArea->preoccupDonneTopLine(iIndex)) ;

	NVLdVPoint ldvBottomRight(pView);
	// Right time
	NVLdVTemps tRightTime = pRectARepeindre->getRight() ;
	if (pConcern->tDateFermeture < tRightTime)
		tRightTime = pConcern->tDateFermeture ;

	ldvBottomRight.setX(tRightTime) ;
	ldvBottomRight.setY(_pWorkingArea->preoccupDonneBottomLine(iIndex)) ;

	NS_CLASSLIB::TPoint ptTopLeft = _pWorkingArea->getScrollablePhysicalPoint(ldvTopLeft) ;
	NS_CLASSLIB::TPoint ptBotRigh = _pWorkingArea->getScrollablePhysicalPoint(ldvBottomRight) ;

	// On colore le fond
	// Filling the rectangle
	pDc->FillRect(ptTopLeft.x, ptTopLeft.y, ptBotRigh.x, ptBotRigh.y, *pPinceau) ;

	delete pPinceau ;

	// On fixe la visibleBox
	NS_CLASSLIB::TRect PixelVisibleBox = NS_CLASSLIB::TRect(ptTopLeft, ptBotRigh) ;
	VisibleBox = (NVLdVRect&) _pWorkingArea->getAreaLogicalRectFromWindowRect(PixelVisibleBox) ;

	if (!(pConcern->aModificateurs.empty()))
	{
		for (ArrayModifierIter ModIt = pConcern->aModificateurs.begin() ;
						ModIt != pConcern->aModificateurs.end() ;
						ModIt++)
		{
			// Modificateur situ� au moins en partie dans le rectangle en cours
			if (((*ModIt)->tDateHeureDeb < tRightTime) && ((*ModIt)->tDateHeureFin > tLeftTime))
			{
				NVLdVPoint severityTopLeft(ldvTopLeft) ;
				NVLdVPoint severityBottomRight(ldvBottomRight) ;
				if ((*ModIt)->tDateHeureDeb > tLeftTime)
					severityTopLeft.setX((*ModIt)->tDateHeureDeb) ;
				if ((*ModIt)->tDateHeureFin < tRightTime)
					severityBottomRight.setX((*ModIt)->tDateHeureFin) ;

				NS_CLASSLIB::TPoint ptTL = _pWorkingArea->getScrollablePhysicalPoint(severityTopLeft) ;
				NS_CLASSLIB::TPoint ptBR = _pWorkingArea->getScrollablePhysicalPoint(severityBottomRight) ;

				//OWL::TBrush PinceauS1(NS_CLASSLIB::TColor::LtCyan);
				//OWL::TBrush PinceauS2(NS_CLASSLIB::TColor::LtGreen);
				//OWL::TBrush PinceauS3(NS_CLASSLIB::TColor::LtYellow);
				//OWL::TBrush PinceauS4(NS_CLASSLIB::TColor::LtRed);

				if ((*ModIt)->iSeverite > 0)
				{
					if ((*ModIt)->iSeverite < 25)
						pPinceau = new OWL::TBrush(pView->pPinceauS1->GetHandle()) ;
					else
						if ((*ModIt)->iSeverite < 50)
							pPinceau = new OWL::TBrush(pView->pPinceauS2->GetHandle()) ;
						else
							if ((*ModIt)->iSeverite < 75)
								pPinceau = new OWL::TBrush(pView->pPinceauS3->GetHandle()) ;
							else
								pPinceau = new OWL::TBrush(pView->pPinceauS4->GetHandle()) ;

					pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau) ;

					delete pPinceau ;
				}
				if ((*ModIt)->iRisque > 0)
				{
                    /*
					ptTL.y = ptBR.y + (ptTL.y - ptBR.y) / 2 + 1;
					ptBR.y = ptTL.y - 3;

					if ((*ModIt)->iRisque < 10)
						pPinceau = new OWL::TBrush(pView->pPinceauS1->GetHandle());
					else
						if ((*ModIt)->iRisque < 15)
							pPinceau = new OWL::TBrush(pView->pPinceauS2->GetHandle());
						else
							if ((*ModIt)->iRisque < 20)
								pPinceau = new OWL::TBrush(pView->pPinceauS3->GetHandle());
							else
								pPinceau = new OWL::TBrush(pView->pPinceauS4->GetHandle());

					pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau);

					delete pPinceau;

					// pDc->SelectObject(*pPenEclaire);
					::SelectObject(pDc->GetHDC(), *pPenEclaire);
					pDc->MoveTo(ptTL.x, ptTL.y);
					pDc->LineTo(ptBR.x, ptTL.y);

					// pDc->SelectObject(*pPenOmbre);
					::SelectObject(pDc->GetHDC(), *pPenOmbre);
					pDc->MoveTo(ptTL.x, ptBR.y - 1);
					pDc->LineTo(ptBR.x, ptBR.y - 1);
                    */
				}
			}
		}
	}

	// D�corations 3D
	// 3D decorating

	bool bLeftHedgeDraw;
	if (pConcern->tDateOuverture > pRectARepeindre->getLeft())
		bLeftHedgeDraw = true;
	else
		bLeftHedgeDraw = false;
	bool bRightHedgeDraw;	if (pConcern->tDateFermeture < pRectARepeindre->getRight())		bRightHedgeDraw = true;
	else
		bRightHedgeDraw = false;

	for (int i = 0; i < iLeftMargin; i++)
	{
		// Partie �clair�e
		// Highlighted part

		// pDc->SelectObject(*pPenEclaire);
		::SelectObject(pDc->GetHDC(), *pPenEclaire);

		// Doit-on dessiner le bord gauche de la preoccupation
		// Shall-we have to draw health issue's left hedge
		if (bLeftHedgeDraw)
		{
			pDc->MoveTo(ptTopLeft.x + i, ptBotRigh.y + i + 1);
			// pDc->SelectObject(*pPenEclaire);
			::SelectObject(pDc->GetHDC(), *pPenEclaire);
			pDc->LineTo(ptTopLeft.x + i, ptTopLeft.y - i);
		}
		else
			pDc->MoveTo(ptTopLeft.x, ptTopLeft.y - i);

		pDc->LineTo(ptBotRigh.x - i, ptTopLeft.y - i);

		// Doit-on dessiner le bord droit de la pr�occupation
		// Shall-we have to draw health issue's right hedge
		if (bRightHedgeDraw)
		{
			// Point de transition
			// Transition point
			// pDc->SelectObject(*pPenTransition);
			::SelectObject(pDc->GetHDC(), *pPenTransition);
			pDc->LineTo(ptBotRigh.x - i, ptTopLeft.y - i - 1);

			// Partie ombr�e
			// Shadow part
			// pDc->SelectObject(*pPenOmbre);
			::SelectObject(pDc->GetHDC(), *pPenOmbre);
			pDc->LineTo(ptBotRigh.x - i, ptBotRigh.y + i);
		}
		else
		{
			pDc->LineTo(ptBotRigh.x + 1, ptTopLeft.y - i);
			// pDc->SelectObject(*pPenOmbre);
			::SelectObject(pDc->GetHDC(), *pPenOmbre);
			pDc->MoveTo(ptBotRigh.x, ptBotRigh.y + i);
		}

		pDc->LineTo(ptTopLeft.x + i, ptBotRigh.y + i);

		if (bLeftHedgeDraw)
		{
			// Point de transition
			// Transition point
			// pDc->SelectObject(*pPenTransition);
			::SelectObject(pDc->GetHDC(), *pPenTransition);
			pDc->LineTo(ptTopLeft.x + i, ptBotRigh.y + i + 1);
		}
		else
			pDc->LineTo(ptBotRigh.x -1, ptBotRigh.y + i);
	}


	// affichage du titre
  NS_CLASSLIB::TRect  clientRect = _pWorkingArea->GetClientRect() ;
	NS_CLASSLIB::TPoint tptBotLeft  = clientRect.BottomLeft() ;
	NS_CLASSLIB::TPoint tptBotRight = clientRect.BottomRight() ;

	NVLdVPoint  ldvLeft(pView) ;
	ldvLeft = (NVLdVPoint&) _pWorkingArea->getAreaLogicalPointFromWindowPoint(tptBotLeft) ;

	NVLdVPoint  ldvRight(pView) ;
	ldvRight = (NVLdVPoint&) _pWorkingArea->getAreaLogicalPointFromWindowPoint(tptBotRight) ;

	NVLdVTemps tNoLimit;
	tNoLimit.setNoLimit();

	if ((ldvRight.getX() > pConcern->tDateFermeture) && (!pConcern->tDateFermeture.estNoLimit()))
		ldvRight.setX(pConcern->tDateFermeture) ;

	if (ldvLeft.getX() < pConcern->tDateOuverture)
		ldvLeft.setX(pConcern->tDateOuverture) ;

	tptBotLeft  = _pWorkingArea->getScrollablePhysicalPoint(ldvLeft) ;
	tptBotRight = _pWorkingArea->getScrollablePhysicalPoint(ldvRight) ;

	NS_CLASSLIB::TRect  rectDisplay = NS_CLASSLIB::TRect(tptBotLeft.X(), ptTopLeft.y - (_pWorkingArea->getInterligne() - 5), tptBotRight.X(), ptTopLeft.y) ;
	NS_CLASSLIB::TRect  rect2Compare = NS_CLASSLIB::TRect(rectDisplay) ;

	pDc->DrawText(pConcern->sTitre.c_str(), -1, rect2Compare, DT_CALCRECT) ;
	if (rectDisplay.Width() < rect2Compare.Width())
	{
		int decal = rect2Compare.Width() - rectDisplay.Width() ;
		rectDisplay.left -= decal ;
		rectDisplay.right += decal ;
	}

	pDc->DrawText(pConcern->sTitre.c_str(), -1, rectDisplay, DT_CENTER) ;

	// -----------------------------------------------------------------------
	// Affichage des objectifs
	// -----------------------------------------------------------------------

	if ((pConcern->pWorstJalons) && (!(pConcern->pWorstJalons->empty())))
	{
  	GoalInfoIter jalonIt = pConcern->pWorstJalons->begin() ;
    for ( ; jalonIt != pConcern->pWorstJalons->end(); jalonIt++)
    {
    	if (((*jalonIt)->tpsInfo < tRightTime) &&
                                        ((*jalonIt)->tpsClosed > tLeftTime))
      {
      	NVLdVPoint goalTopLeft(ldvTopLeft) ;
        NVLdVPoint goalBottomRight(ldvBottomRight) ;
        if ((*jalonIt)->tpsInfo > tLeftTime)
        	goalTopLeft.setX((*jalonIt)->tpsInfo) ;
        if ((*jalonIt)->tpsClosed < tRightTime)
        	goalBottomRight.setX((*jalonIt)->tpsClosed) ;

        NS_CLASSLIB::TPoint ptTL = _pWorkingArea->getScrollablePhysicalPoint(goalTopLeft) ;
      	NS_CLASSLIB::TPoint ptBR = _pWorkingArea->getScrollablePhysicalPoint(goalBottomRight) ;

        ptTL.y = ptBR.y + (ptTL.y - ptBR.y) / 2 + 1 ;
        ptBR.y = ptTL.y - 3 ;

        switch ((*jalonIt)->iLevel)
        {
        	// puisqu'il n'y a rien � faire, est-ce raisonnable d'afficher du rouge ?
          //case NSLdvGoalInfo::AVrouge :
          //    pPinceau = new OWL::TBrush(pView->pPinceauS4->GetHandle()) ;
          //    pDc->FillRect(ptTL.x, ptTL.y - 1, ptBR.x, ptBR.y + 1, *pPinceau) ;
          //    break;
          case NSLdvGoalInfo::AVjaune :
          	pPinceau = new OWL::TBrush(pView->pPinceauS3->GetHandle()) ;
            pDc->FillRect(ptTL.x, ptTL.y - 1, ptBR.x, ptBR.y + 1, *pPinceau) ;
            break ;
          case NSLdvGoalInfo::AVvert  :
          	pPinceau = new OWL::TBrush(pView->pPinceauS2->GetHandle()) ;
            pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau) ;
            break ;
          case NSLdvGoalInfo::Bleu    :
          	pPinceau = new OWL::TBrush(pView->pPinceauS1->GetHandle()) ;
            pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau) ;
            break ;
          case NSLdvGoalInfo::APvert  :
          	pPinceau = new OWL::TBrush(pView->pPinceauS2->GetHandle()) ;
            pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau) ;
            break ;
          case NSLdvGoalInfo::APjaune :
          	pPinceau = new OWL::TBrush(pView->pPinceauS3->GetHandle()) ;
            pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau) ;
            break ;
          case NSLdvGoalInfo::AProuge :
          	pPinceau = new OWL::TBrush(pView->pPinceauS4->GetHandle()) ;
            pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau) ;
            break ;
        }

        delete pPinceau ;

        // pDc->SelectObject(*pPenEclaire);
        ::SelectObject(pDc->GetHDC(), *pPenEclaire) ;
        pDc->MoveTo(ptTL.x, ptTL.y) ;
        pDc->LineTo(ptBR.x, ptTL.y) ;

        // pDc->SelectObject(*pPenOmbre);
        ::SelectObject(pDc->GetHDC(), *pPenOmbre);
        pDc->MoveTo(ptTL.x, ptBR.y - 1);
        pDc->LineTo(ptBR.x, ptBR.y - 1);
      }
    }
  }

	// drawBaddestGoal(pDc, pRectARepeindre) ;

/*  ArrayGoals* pGoals = pConcern->pDoc->getGoals();
    if (!pGoals || (pGoals->empty()))
        return ;

    GoalInfoArray* pJalons = pGoals->giveBaddestJalons(pConcern->sReference, pRectARepeindre) ;

    if (pJalons == NULL)
        return ;

    if (pJalons->empty())
    {
        delete pJalons;
        return ;
    }

    bool bBaddestGoal = true ;
    //
    // Variables qui permettent de savoir quelle est la pire couleur en cours
    // et jusqu'� quand elle est d'actualit�
    //
    NVLdVTemps tpsMaxTimeForColor ;
    tpsMaxTimeForColor.init() ;
    int iColorLevel = -1 ;

    //
    // On �num�re tous les jalons
    //
    for (GoalInfoIter jalonIt = pJalons->begin(); jalonIt != pJalons->end(); )
    {
        NVLdVPoint goalTopLeft(ldvTopLeft) ;
        NVLdVPoint goalBottomRight(ldvBottomRight) ;
        if ((*jalonIt)->tpsInfo > tLeftTime)
            goalTopLeft.setX((*jalonIt)->tpsInfo) ;

        NSLdvGoalInfo* pCurrentJalon = *jalonIt ;
        NVLdVTemps tpsDebut = pCurrentJalon->tpsInfo ;
        string sCurrentGoal = pCurrentJalon->sGoalReference ;

        bool bTracer = false ;

        if (bBaddestGoal && ((pCurrentJalon->iLevel > iColorLevel) ||
                            (tpsMaxTimeForColor < tRightTime)))
        {
            //
            // On cherche le prochain jalon du m�me objectif (qui ferme celui ci)
            //
            GoalInfoIter jIt = jalonIt ;
            jIt++ ;

            NVLdVTemps tpsFinGoal ;
            for (; (jIt != pJalons->end()) && ((*jIt)->sGoalReference != sCurrentGoal); jIt++) ;
            if (jIt != pJalons->end())
                tpsFinGoal = (*jIt)->tpsInfo ;
            else
                tpsFinGoal = tRightTime ;

            if (pCurrentJalon->iLevel > iColorLevel)
            {
                iColorLevel = pCurrentJalon->iLevel ;
                tpsMaxTimeForColor = tpsFinGoal ;
                bTracer = true ;
                goalBottomRight.setX(tpsMaxTimeForColor) ;
            }
            else if ((tpsMaxTimeForColor < tRightTime) &&
                                    (tpsMaxTimeForColor < tpsFinGoal))
            {
                goalTopLeft.setX(tpsMaxTimeForColor) ;
                goalBottomRight.setX(tpsMaxTimeForColor) ;
                bTracer = true ;
                if (pCurrentJalon->iLevel > iColorLevel)
                    tpsMaxTimeForColor = (*jIt)->tpsInfo ;
            }

            jalonIt++ ;
        }
        else
        {
            bTracer = true ;

            jalonIt++ ;

            if ((jalonIt != pJalons->end()) &&
                ((*jalonIt)->tpsInfo < tRightTime) && (tpsDebut > tLeftTime))
                goalBottomRight.setX((*jalonIt)->tpsInfo) ;
        }

        NS_CLASSLIB::TPoint ptTL = pView->getPhysicalPoint(goalTopLeft) ;
        NS_CLASSLIB::TPoint ptBR = pView->getPhysicalPoint(goalBottomRight) ;

        ptTL.y = ptBR.y + (ptTL.y - ptBR.y) / 2 + 1 ;
        ptBR.y = ptTL.y - 3 ;

        switch (pCurrentJalon->iLevel)
        {
            case NSLdvGoalInfo::AVrouge :
            case NSLdvGoalInfo::AVjaune :
                pPinceau = new OWL::TBrush(pView->pPinceauS3->GetHandle()) ;
                break;
            case NSLdvGoalInfo::AVvert  :
                pPinceau = new OWL::TBrush(pView->pPinceauS2->GetHandle()) ;
                break;
            case NSLdvGoalInfo::Bleu    :
                pPinceau = new OWL::TBrush(pView->pPinceauS1->GetHandle()) ;
                break;
            case NSLdvGoalInfo::APvert  :
                pPinceau = new OWL::TBrush(pView->pPinceauS2->GetHandle()) ;
                break;
            case NSLdvGoalInfo::APjaune :
                pPinceau = new OWL::TBrush(pView->pPinceauS3->GetHandle()) ;
                break;
            case NSLdvGoalInfo::AProuge :
                pPinceau = new OWL::TBrush(pView->pPinceauS4->GetHandle()) ;
                break;
        }

        pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau) ;

        delete pPinceau ;

        // pDc->SelectObject(*pPenEclaire);
        ::SelectObject(pDc->GetHDC(), *pPenEclaire) ;
        pDc->MoveTo(ptTL.x, ptTL.y) ;
        pDc->LineTo(ptBR.x, ptTL.y) ;

        // pDc->SelectObject(*pPenOmbre);
        ::SelectObject(pDc->GetHDC(), *pPenOmbre);
        pDc->MoveTo(ptTL.x, ptBR.y - 1);
        pDc->LineTo(ptBR.x, ptBR.y - 1);

        if ((jalonIt != pJalons->end()) && ((*jalonIt)->tpsInfo >= tRightTime))
            break ;

        // Tout est d�j� rouge
        if (bBaddestGoal && ((pCurrentJalon->iLevel == NSLdvGoalInfo::AProuge) ||
                            (tpsMaxTimeForColor >= tRightTime)))
            break ;
    }

    delete pJalons ;
    */

	// ---------------------------------------------------------------------------
	// Restauration des objets initiaux (pen et brush)
	::SelectObject(pDc->GetHDC(), oldPen) ;
	::SelectObject(pDc->GetHDC(), oldBrush) ;
}


void
NSConcernView::drawBaddestGoal(TDC* pDc, NVLdVRect* pRectARepeindre)
{
    /*
    ArrayGoals* pGoals = pConcern->pDoc->getGoals();
    if (!pGoals || (pGoals->empty()))
        return ;

    GoalInfoArray* pJalons = pGoals->giveBaddestJalons(pConcern->sReference, pRectARepeindre) ;

    if (pJalons == NULL)
        return ;

    if (pJalons->empty())
    {
        delete pJalons;
        return ;
    }

    // Rectangle � repeindre pour l'objet lui m�me
	// Object's rectangle to repaint
	NVLdVPoint ldvTopLeft(pView);
	// Left time
	NVLdVTemps tLeftTime = pRectARepeindre->getLeft();
	if (pConcern->tDateOuverture > tLeftTime)
		tLeftTime = pConcern->tDateOuverture;

	ldvTopLeft.setX(tLeftTime);
	ldvTopLeft.setY(pView->preoccupDonneTopLine(iIndex));

	NVLdVPoint ldvBottomRight(pView);
	// Right time
	NVLdVTemps tRightTime = pRectARepeindre->getRight();
	if (pConcern->tDateFermeture < tRightTime)
		tRightTime = pConcern->tDateFermeture;

	ldvBottomRight.setX(tRightTime);
	ldvBottomRight.setY(pView->preoccupDonneBottomLine(iIndex));

	NS_CLASSLIB::TPoint ptTopLeft = pView->getPhysicalPoint(ldvTopLeft);
	NS_CLASSLIB::TPoint ptBotRigh = pView->getPhysicalPoint(ldvBottomRight);

    for (GoalInfoIter jalonIt = pGIarray->begin(); jalonIt != pGIarray->end(); jalonIt++)
    {
        NS_CLASSLIB::TPoint ptTopLeft = pView->getPhysicalPoint(ldvTopLeft);
	    NS_CLASSLIB::TPoint ptBotRigh = pView->getPhysicalPoint(ldvBottomRight);

        NVLdVPoint severityTopLeft(ldvTopLeft);
        NVLdVPoint severityBottomRight(ldvBottomRight);
        if ((*jalonIt)->tpsInfo > tLeftTime)
            severityTopLeft.setX((*ModIt)->tDateHeureDeb);
        if ((*ModIt)->tDateHeureFin < tRightTime)
            severityBottomRight.setX((*ModIt)->tDateHeureFin);

        NS_CLASSLIB::TPoint ptTL = pView->getPhysicalPoint(severityTopLeft);
        NS_CLASSLIB::TPoint ptBR = pView->getPhysicalPoint(severityBottomRight);

        ptTL.y = ptBR.y + (ptTL.y - ptBR.y) / 2 + 1;
        ptBR.y = ptTL.y - 3;

					if ((*ModIt)->iRisque < 10)
						pPinceau = new OWL::TBrush(pView->pPinceauS1->GetHandle());
					else
						if ((*ModIt)->iRisque < 15)
							pPinceau = new OWL::TBrush(pView->pPinceauS2->GetHandle());
						else
							if ((*ModIt)->iRisque < 20)
								pPinceau = new OWL::TBrush(pView->pPinceauS3->GetHandle());
							else
								pPinceau = new OWL::TBrush(pView->pPinceauS4->GetHandle());

					pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau);

					delete pPinceau;

					// pDc->SelectObject(*pPenEclaire);
					::SelectObject(pDc->GetHDC(), *pPenEclaire);
					pDc->MoveTo(ptTL.x, ptTL.y);
					pDc->LineTo(ptBR.x, ptTL.y);

					// pDc->SelectObject(*pPenOmbre);
					::SelectObject(pDc->GetHDC(), *pPenOmbre);
					pDc->MoveTo(ptTL.x, ptBR.y - 1);
					pDc->LineTo(ptBR.x, ptBR.y - 1);
    }

    delete pJalons ;

    return ;    */

	ArrayGoals *concernGoals = new ArrayGoals(pConcern->pDoc) ;
	if (!pConcern->pDoc->getGoals()->empty())
		for (ArrayGoalIter goalIter = pConcern->pDoc->getGoals()->begin() ; goalIter != pConcern->pDoc->getGoals()->end() ; goalIter++)
			if ((*goalIter)->sConcern == pConcern->sReference)
				concernGoals->push_back(new NSLdvGoal(**goalIter)) ;

	NSLdvGoal *pGoal = concernGoals->makeBaddestProjection() ;

	if (pGoal == NULL)
		return ;

	// ---------------------------------------------------------------------------
	// � faire autant de fois qu'il y a d'�v�nement qui font recommencer le cycle
	// pour l'instant on se base juste sur l'objectif par rapport � la date
	// d'origine (date d'ouverture)
	// ---------------------------------------------------------------------------

	NVLdVTemps	tDateOrigine 	= pGoal->tDateOuverture ;
	NVLdVTemps	tDateLeft		 	= tDateOrigine ;
	NVLdVTemps	tDateRight ; tDateRight.setNoLimit() ;

	NVLdVTemps	tDateDebutAuthMin, tDateDebutConsMin, tDateDebutIdealMin ;
	NVLdVTemps	tDateDebutAuthMax, tDateDebutConsMax, tDateDebutIdealMax ;

	NVLdVTemps	tDateFinAuthMin, tDateFinConsMin, tDateFinIdealMin ;
	NVLdVTemps	tDateFinAuthMax, tDateFinConsMax, tDateFinIdealMax ;

	for (GoalInfoIter iter = pGoal->pJalons->begin() ; iter != pGoal->pJalons->end() ; iter++)
	{
		string	sCode		= (*iter)->getCode() ;
		string	sValue	= (*iter)->getValue() ;
		string	sUnit		= (*iter)->getUnit() ;
		string	sFormat	= (*iter)->getFormat() ;

		if (strncmp((*iter)->getCode().c_str(), "KMOD", 4) == 0)
		{
			switch ((*iter)->getCode()[4])
			{
				case '1'	:	tDateDebutAuthMin = getGoalInfoDate(*iter, tDateOrigine) ;
										break ;
				case '2'	: tDateDebutConsMin = getGoalInfoDate(*iter, tDateOrigine) ;
										break ;
				case '3'	: tDateDebutIdealMin = getGoalInfoDate(*iter, tDateOrigine) ;
										break ;
				case '4'	: tDateDebutIdealMax = getGoalInfoDate(*iter, tDateOrigine) ;
										break ;
				case '5'	: tDateDebutConsMax = getGoalInfoDate(*iter, tDateOrigine) ;
										break ;
				case '6'	: tDateDebutAuthMax = getGoalInfoDate(*iter, tDateOrigine) ;
										break ;
			}
		}

		if (strncmp((*iter)->getCode().c_str(), "KMOF", 4) == 0)
		{
			switch ((*iter)->getCode()[4])
			{
				case '1'	: tDateFinAuthMin = getGoalInfoDate(*iter, tDateOrigine) ;
										break ;
				case '2'	: tDateFinConsMin = getGoalInfoDate(*iter, tDateOrigine) ;
										break ;
				case '3'	: tDateFinIdealMin = getGoalInfoDate(*iter, tDateOrigine) ;
										break ;
				case '4'	: tDateFinIdealMax = getGoalInfoDate(*iter, tDateOrigine) ;
										break ;
				case '5'	: tDateFinConsMax = getGoalInfoDate(*iter, tDateOrigine) ;
										break ;
				case '6'	: tDateFinAuthMax = getGoalInfoDate(*iter, tDateOrigine) ;
										break ;
			}
		}

		// Rectangle � repeindre pour l'objectif lui m�me
		// Object's rectangle to repaint
		NVLdVPoint ldvLeft(pView) ;

/*
		// Left time
		NVLdVTemps tLeftTime = pRectARepeindre->getLeft() ;
		if (tDateOrigine > tLeftTime)
		{
			if (iter == pGoal->pGoalInfos->begin())
				tLeftTime = tDateOrigine ;
		}
*/
		ldvLeft.setX(tDateLeft) ;
		ldvLeft.setY(_pWorkingArea->preoccupDonneTopLine(iIndex)) ;

		NVLdVPoint ldvRight(pView) ;
/*
		// Right time
		NVLdVTemps tRightTime = pRectARepeindre->getRight() ;
		if ((pGoal->tDateFermeture < tRightTime) && (!pGoal->tDateFermeture.estNoLimit()))
			tRightTime = pGoal->tDateFermeture ;
*/
		ldvRight.setX(tDateRight) ;
		ldvRight.setY(_pWorkingArea->preoccupDonneBottomLine(iIndex)) ;

		NS_CLASSLIB::TPoint tptLeft  = _pWorkingArea->getScrollablePhysicalPoint(ldvLeft) ;
		NS_CLASSLIB::TPoint tptRight = _pWorkingArea->getScrollablePhysicalPoint(ldvRight) ;

		pDc->FillRect(tptLeft.X(), tptLeft.Y() - 2, tptRight.X(), tptLeft.Y() - 1, pView->pPinceauRed->GetHandle()) ;
	}

	delete concernGoals ;
}


NVLdVTemps	NSConcernView::getGoalInfoDate(NSLdvGoalInfo *pInfoGoal, NVLdVTemps tDateOrigine)
{
	NVLdVTemps	resultDate ;

	if (pInfoGoal->getFormat()[1] == 'N')
	{
		resultDate = tDateOrigine ;

		string sVal = pInfoGoal->getValue() ;
		int	iVal = 0 ;

		// -------------------------------------------------------------------------
		// conversion atoi sur 2 digits
		// -------------------------------------------------------------------------
		if (strlen(sVal.c_str()) == 2)
			iVal = (sVal[0] - '0') * 10 + (sVal[1] - '0') ;
		if (strlen(sVal.c_str()) == 1)
			iVal = sVal[0] - '0' ;

		// code lexique unit� de temps
		// ann�es : 2DAT31 - mois : 2DAT21 - jour : 2DAT01 - heure : 2HE001 - minute : 2MINU1 - seconde : 2SEC01

		if (strncmp(pInfoGoal->getUnit().c_str(), "2DAT", 4) == 0)
		{
			switch (pInfoGoal->getUnit()[4])
			{
				case '3'	: resultDate.ajouteAns(iVal) ;
										break ;
				case '2'	:	resultDate.ajouteMois(iVal) ;
										break ;
				case '0'	:	resultDate.ajouteJours(iVal) ;
										break ;
			}
		}
		else
		{
			switch (pInfoGoal->getUnit()[1])
			{
				case 'H'	:	resultDate.ajouteHeures(iVal) ;
										break ;
				case 'M'	: resultDate.ajouteMinutes(iVal) ;
										break ;
				case 'S'	: resultDate.ajouteSecondes(iVal) ;
										break ;
			}
		}
		return resultDate ;
	}

	if ((pInfoGoal->getFormat()[1] == 'D') || (pInfoGoal->getFormat()[1] == 'T'))
		resultDate.initFromDate(pInfoGoal->getValue()) ;

	return resultDate ;
}


void
NSConcernView::EvRButtonDown()
{
}


void    NSConcernView::createComponents(ArrayOfToons* pToonsArray)
{
/*
	if (!(pConcern->aModificateurs.empty()))
  {
  	ArrayModifierIter i = pConcern->aModificateurs.begin();
    for (; i != pConcern->aModificateurs.end(); i++)
    {
    	NSPbModifView* pPbModiView = new NSPbModifView(pContexte, pView, *i);
      pToonsArray->push_back((NSLdvToon*)(new NSPbModifView(*pPbModiView)));
      pPbModiView->createComponents(pToonsArray);
      delete pPbModiView;
    }
  }
*/
}


NSConcernView&	NSConcernView::operator=(NSConcernView& src)
{
	if (this == &src)
		return *this ;

	initialiser((NSLdvTimeToon*)(&src));

  iIndex          = src.iIndex;
  pConcern        = src.pConcern;
  iLeftMargin     = src.iLeftMargin;
  iRigthMargin    = src.iRigthMargin;
  iTopMargin      = src.iTopMargin;
  iBottomMargin   = src.iBottomMargin;

  return *this;
}


// -----------------------------------------------------------------------------
// ----------------------- METHODES DE NSLigneView -----------------------------
// -----------------------------------------------------------------------------

NSLigneView::NSLigneView(NSContexte* pCtx, NSLdvViewArea *pWorkArea, bool bVScrollEnabled)
            :NSLdvTimeToon(pCtx, pWorkArea, bVScrollEnabled)
{
}


NSLigneView::NSLigneView(NSLigneView& rv)
            :NSLdvTimeToon(rv.pContexte, rv._pWorkingArea, rv._bVerticalScrollEnabled)
{
	initialiser((NSLdvTimeToon*)(&rv));

  iIndex = rv.iIndex;
}

NSLigneView::~NSLigneView()
{
}

void
NSLigneView::SetupWindow()
{
}

void
NSLigneView::draw(TDC* pDc, NVLdVRect* pRectARepeindre)
{
}

void
NSLigneView::EvRButtonDown()
{
}

void
NSLigneView::boxFitting()
{
	Box.setTop(_pWorkingArea->preoccupDonneTopBox(iIndex)) ;
  Box.setBottom(_pWorkingArea->preoccupDonneBottomBox(iIndex)) ;
}

NSLigneView&
NSLigneView::operator=(NSLigneView& src)
{
	if (this == &src)
		return *this ;

	initialiser((NSLdvTimeToon*)(&src)) ;
  iIndex = src.iIndex ;

	return *this ;
}

// -----------------------------------------------------------------------------
// ---------------------- METHODES DE NSPreoccupView ---------------------------
// -----------------------------------------------------------------------------

NSPreoccupView::NSPreoccupView(NSContexte* pCtx, NSLdvViewArea *pWorkArea, NSConcern* pPreoccup, int iIdx)
               :NSLigneView(pCtx, pWorkArea, true)
{
	iIndex         = iIdx;

	if (_pWorkingArea->getLargeurLigne() >= 30)
	{
		iLeftMargin   = 2;
		iRigthMargin  = 2;
		iTopMargin    = 2;
		iBottomMargin = 2;
	}
	else
	{
		iLeftMargin   = 1;
		iRigthMargin  = 1;
		iTopMargin    = 1;
		iBottomMargin = 1;
	}

	pPreoccupation = pPreoccup;

	Box.setLeft(pPreoccupation->tDateOuverture);

	if (pPreoccupation->tDateFermeture.estVide())
		Box.setRight(pPreoccupation->tDateFermeture);
	else
	{
		NVLdVTemps tNoLimit;
		tNoLimit.setNoLimit();
		Box.setRight(tNoLimit);
	}

	Box.setTop(_pWorkingArea->preoccupDonneTopBox(iIndex));
	Box.setBottom(_pWorkingArea->preoccupDonneBottomBox(iIndex));

	iZOrder  = LEVEL_PREOCCUP + RELPRLEVEL_LINE;
	toonType = toonLine;
}

NSPreoccupView::NSPreoccupView(NSPreoccupView& rv)
               :NSLigneView(rv.pContexte, rv._pWorkingArea, rv._bVerticalScrollEnabled)
{
	initialiser((NSLdvTimeToon*)(&rv));

	iIndex          = rv.iIndex;
	pPreoccupation  = rv.pPreoccupation;
	iLeftMargin     = rv.iLeftMargin;
	iRigthMargin    = rv.iRigthMargin;
	iTopMargin      = rv.iTopMargin;
	iBottomMargin   = rv.iBottomMargin;
}

NSPreoccupView::~NSPreoccupView()
{
}

void
NSPreoccupView::SetupWindow()
{
}

void
NSPreoccupView::draw(TDC* pDc, NVLdVRect* pRectARepeindre){
	OWL::TBrush* pPinceau;
	OWL::TPen*   pPenEclaire;
	OWL::TPen*   pPenOmbre;
	OWL::TPen*   pPenTransition;

	// Sauvegarde des �l�ments en cours (pen et brush)
	HPEN oldPen     = (HPEN) pDc->GetCurrentObject(OBJ_PEN);
	HBRUSH oldBrush = (HBRUSH) pDc->GetCurrentObject(OBJ_BRUSH);

	if (pView->useSystemColors())
	{
		pPinceau        = new OWL::TBrush(pView->pPinceauFondSys->GetHandle());
		pPenEclaire     = pView->pPenEclaireSys;
		pPenOmbre       = pView->pPenOmbreSys;
		pPenTransition  = pView->pPenTransitionSys;
	}
	else
	{
		pPinceau        = new OWL::TBrush(pView->pPinceauFond->GetHandle());
		pPenEclaire     = pView->pPenEclaire;
		pPenOmbre       = pView->pPenOmbre;
		pPenTransition  = pView->pPenTransition;
	}

	// Rectangle � repeindre pour l'objet lui m�me
	// Object's rectangle to repaint
	NVLdVPoint ldvTopLeft(pView);
	// Left time
	NVLdVTemps tLeftTime = pRectARepeindre->getLeft();
	if (pPreoccupation->tDateOuverture > tLeftTime)
		tLeftTime = pPreoccupation->tDateOuverture;

	ldvTopLeft.setX(tLeftTime);
	ldvTopLeft.setY(_pWorkingArea->preoccupDonneTopLine(iIndex));

	NVLdVPoint ldvBottomRight(pView);
	// Right time
	NVLdVTemps tRightTime = pRectARepeindre->getRight();
	if (pPreoccupation->tDateFermeture < tRightTime)
  	tLeftTime = pPreoccupation->tDateFermeture;
	ldvBottomRight.setX(tRightTime);	ldvBottomRight.setY(_pWorkingArea->preoccupDonneBottomLine(iIndex));
	NS_CLASSLIB::TPoint ptTopLeft = _pWorkingArea->getScrollablePhysicalPoint(ldvTopLeft);
	NS_CLASSLIB::TPoint ptBotRigh = _pWorkingArea->getScrollablePhysicalPoint(ldvBottomRight);

	// On colore le fond
	// Filling the rectangle
	pDc->FillRect(ptTopLeft.x, ptTopLeft.y, ptBotRigh.x, ptBotRigh.y, *pPinceau);

	delete pPinceau;

	// On fixe la visibleBox
	NS_CLASSLIB::TRect PixelVisibleBox = NS_CLASSLIB::TRect(ptTopLeft, ptBotRigh) ;
  VisibleBox = (NVLdVRect&) _pWorkingArea->getAreaLogicalRectFromWindowRect(PixelVisibleBox) ;

	// D�corations 3D
	// 3D decorating

	bool bLeftHedgeDraw;
	if (pPreoccupation->tDateOuverture > pRectARepeindre->getLeft())
		bLeftHedgeDraw = true;
	else
		bLeftHedgeDraw = false;

	bool bRightHedgeDraw;
	if (pPreoccupation->tDateFermeture < pRectARepeindre->getRight())
		bRightHedgeDraw = true;
	else
		bRightHedgeDraw = false;

	for (int i = 0; i < iLeftMargin; i++)
	{
		// Partie �clair�e
		// Highlighted part

    // pDc->SelectObject(*pPenEclaire);
		::SelectObject(pDc->GetHDC(), *pPenEclaire);

		// Doit-on dessiner le bord gauche de la preoccupation
		// Shall-we have to draw health issue's left hedge
		if (bLeftHedgeDraw)
		{
			pDc->MoveTo(ptTopLeft.x + i, ptBotRigh.y + i + 1);
			// pDc->SelectObject(*pPenEclaire);
			::SelectObject(pDc->GetHDC(), *pPenEclaire);
			pDc->LineTo(ptTopLeft.x + i, ptTopLeft.y - i);
		}
		else
			pDc->MoveTo(ptTopLeft.x, ptTopLeft.y - i);

		pDc->LineTo(ptBotRigh.x - i, ptTopLeft.y - i);

		// Doit-on dessiner le bord droit de la pr�occupation
		// Shall-we have to draw health issue's right hedge
		if (bRightHedgeDraw)
		{
			// Point de transition
			// Transition point
			// pDc->SelectObject(*pPenTransition);
			::SelectObject(pDc->GetHDC(), *pPenTransition);
			pDc->LineTo(ptBotRigh.x - i, ptTopLeft.y - i - 1);
			// Partie ombr�e
			// Shadow part
			// pDc->SelectObject(*pPenOmbre);
			::SelectObject(pDc->GetHDC(), *pPenOmbre);
			pDc->LineTo(ptBotRigh.x - i, ptBotRigh.y + i);
		}
		else
		{
			pDc->LineTo(ptBotRigh.x + 1, ptTopLeft.y - i);
			// pDc->SelectObject(*pPenOmbre);
			::SelectObject(pDc->GetHDC(), *pPenOmbre);
			pDc->MoveTo(ptBotRigh.x, ptBotRigh.y + i);
		}

		pDc->LineTo(ptTopLeft.x + i, ptBotRigh.y + i);

		if (bLeftHedgeDraw)
		{
			// Point de transition
      // Transition point
			// pDc->SelectObject(*pPenTransition);
			::SelectObject(pDc->GetHDC(), *pPenTransition);
			pDc->LineTo(ptTopLeft.x + i, ptBotRigh.y + i + 1);
		}
		else
			pDc->LineTo(ptBotRigh.x -1, ptBotRigh.y + i);
	}

	// Restauration des objets initiaux (pen et brush)
	::SelectObject(pDc->GetHDC(), oldPen);
  ::SelectObject(pDc->GetHDC(), oldBrush);
}

void
NSPreoccupView::EvRButtonDown()
{
}

void
NSPreoccupView::createComponents(ArrayOfToons* pToonsArray)
{
/*
  if (!(pPreoccupation->aConcerns.empty()))
  {
  	ArrayConcernIter i = pPreoccupation->aConcerns.begin();
    for (; i != pPreoccupation->aConcerns.end(); i++)
    {
    	NSConcernView* pPbView = new NSConcernView(pContexte, pView, *i);
      pToonsArray->push_back(new NSConcernView(*pPbView));
      pPbView->createComponents(pToonsArray);
      delete pPbView;
    }
  }
*/
}

NSPreoccupView&
NSPreoccupView::operator=(NSPreoccupView& src)
{
	if (this == &src)
		return *this ;

	initialiser((NSLdvTimeToon*)(&src));

	iIndex          = src.iIndex;
	pPreoccupation  = src.pPreoccupation;
	iLeftMargin     = src.iLeftMargin;
	iRigthMargin    = src.iRigthMargin;
	iTopMargin      = src.iTopMargin;
	iBottomMargin   = src.iBottomMargin;

	return *this;
}


// -----------------------------------------------------------------------------
// ---------------------- METHODES DE NSDrugLineView ---------------------------
// -----------------------------------------------------------------------------

NSDrugLineView::NSDrugLineView(NSContexte* pCtx, NSLdvViewArea *pWorkArea, NSLdvDrug* pLdvDrug, int iIdx)
               :NSLigneView(pCtx, pWorkArea, true)
{
	iIndex         = iIdx ;

	if (_pWorkingArea->getLargeurSubLigne() >= 30)
	{
		iLeftMargin   = 2 ;
		iRigthMargin  = 2 ;
		iTopMargin    = 2 ;
		iBottomMargin = 2 ;
	}
	else
	{
		iLeftMargin   = 1 ;
		iRigthMargin  = 1 ;
		iTopMargin    = 1 ;
		iBottomMargin = 1 ;
	}

	pDrug = pLdvDrug ;

	Box.setLeft(pDrug->tDateOuverture) ;

	if (!(pDrug->tDateFermeture.estVide()))
		Box.setRight(pDrug->tDateFermeture) ;
	else
	{
		NVLdVTemps tNoLimit ;
		tNoLimit.setNoLimit() ;
		Box.setRight(tNoLimit) ;
	}

	Box.setTop(_pWorkingArea->drugDonneTopBox(iIndex)) ;
	Box.setBottom(_pWorkingArea->drugDonneBottomBox(iIndex)) ;

	iZOrder  = LEVEL_PREOCCUP + RELPRLEVEL_LINE ;
	toonType = toonDrug ; // was toonLine 
}


NSDrugLineView::NSDrugLineView(NSDrugLineView& rv)
               :NSLigneView(rv.pContexte, rv._pWorkingArea, rv._bVerticalScrollEnabled)
{
	initialiser((NSLdvTimeToon*)(&rv)) ;

	iIndex          = rv.iIndex ;
	pDrug  			= rv.pDrug ;
	iLeftMargin     = rv.iLeftMargin ;
	iRigthMargin    = rv.iRigthMargin ;
	iTopMargin      = rv.iTopMargin ;
	iBottomMargin   = rv.iBottomMargin ;
}

NSDrugLineView::~NSDrugLineView()
{
}

void
NSDrugLineView::SetupWindow()
{
}

void
NSDrugLineView::draw(TDC* pDc, NVLdVRect* pRectARepeindre){
	OWL::TBrush* pPinceau;
	OWL::TPen*   pPenEclaire;
	OWL::TPen*   pPenOmbre;
	OWL::TPen*   pPenTransition;

	// Sauvegarde des �l�ments en cours (pen et brush)
	HPEN oldPen     = (HPEN) pDc->GetCurrentObject(OBJ_PEN);
	HBRUSH oldBrush = (HBRUSH) pDc->GetCurrentObject(OBJ_BRUSH);

	if (pView->useSystemColors())
	{
		pPinceau        = new OWL::TBrush(pView->pPinceauFondSys->GetHandle());
		pPenEclaire     = pView->pPenEclaireSys;
		pPenOmbre       = pView->pPenOmbreSys;
		pPenTransition  = pView->pPenTransitionSys;
	}
	else
	{
		pPinceau        = new OWL::TBrush(pView->pPinceauFond->GetHandle());
		pPenEclaire     = pView->pPenEclaire;
		pPenOmbre       = pView->pPenOmbre;
		pPenTransition  = pView->pPenTransition;
	}

	// Rectangle � repeindre pour l'objet lui m�me
	// Object's rectangle to repaint
	NVLdVPoint ldvTopLeft(pView) ;
	// Left time
	NVLdVTemps tLeftTime = pRectARepeindre->getLeft() ;
	if (pDrug->tDateOuverture > tLeftTime)
		tLeftTime = pDrug->tDateOuverture ;

	ldvTopLeft.setX(tLeftTime);
	ldvTopLeft.setY(_pWorkingArea->drugDonneTopLine(iIndex)) ;

	NVLdVPoint ldvBottomRight(pView) ;
	// Right time
	NVLdVTemps tRightTime = pRectARepeindre->getRight() ;
	if (pDrug->tDateFermeture < tRightTime)
  	tRightTime = pDrug->tDateFermeture ;
	ldvBottomRight.setX(tRightTime) ;	ldvBottomRight.setY(_pWorkingArea->drugDonneBottomLine(iIndex)) ;
	NS_CLASSLIB::TPoint ptTopLeft = _pWorkingArea->getScrollablePhysicalPoint(ldvTopLeft) ;
	NS_CLASSLIB::TPoint ptBotRigh = _pWorkingArea->getScrollablePhysicalPoint(ldvBottomRight) ;

	// On colore le fond
	// Filling the rectangle
	pDc->FillRect(ptTopLeft.x, ptTopLeft.y, ptBotRigh.x, ptBotRigh.y, *pPinceau) ;

	delete pPinceau;

	// On fixe la visibleBox
	NS_CLASSLIB::TRect PixelVisibleBox = NS_CLASSLIB::TRect(ptTopLeft, ptBotRigh) ;
  VisibleBox = (NVLdVRect&) _pWorkingArea->getAreaLogicalRectFromWindowRect(PixelVisibleBox) ;

	// D�corations 3D
	// 3D decorating

	bool bLeftHedgeDraw ;
	if (pDrug->tDateOuverture > pRectARepeindre->getLeft())
		bLeftHedgeDraw = true ;
	else
		bLeftHedgeDraw = false ;

	bool bRightHedgeDraw ;
	if (pDrug->tDateFermeture < pRectARepeindre->getRight())
		bRightHedgeDraw = true ;
	else
		bRightHedgeDraw = false ;

	for (int i = 0; i < iLeftMargin; i++)
	{
		// Partie �clair�e
		// Highlighted part

    	// pDc->SelectObject(*pPenEclaire);
		::SelectObject(pDc->GetHDC(), *pPenEclaire) ;

		// Doit-on dessiner le bord gauche de la preoccupation
		// Shall-we have to draw health issue's left hedge
		if (bLeftHedgeDraw)
		{
			pDc->MoveTo(ptTopLeft.x + i, ptBotRigh.y + i + 1) ;
			// pDc->SelectObject(*pPenEclaire);
			::SelectObject(pDc->GetHDC(), *pPenEclaire) ;
			pDc->LineTo(ptTopLeft.x + i, ptTopLeft.y - i) ;
		}
		else
			pDc->MoveTo(ptTopLeft.x, ptTopLeft.y - i) ;

		pDc->LineTo(ptBotRigh.x - i, ptTopLeft.y - i) ;

		// Doit-on dessiner le bord droit de la pr�occupation
		// Shall-we have to draw health issue's right hedge
		if (bRightHedgeDraw)
		{
			// Point de transition
			// Transition point
			// pDc->SelectObject(*pPenTransition);
			::SelectObject(pDc->GetHDC(), *pPenTransition) ;
			pDc->LineTo(ptBotRigh.x - i, ptTopLeft.y - i - 1) ;
			// Partie ombr�e
			// Shadow part
			// pDc->SelectObject(*pPenOmbre);
			::SelectObject(pDc->GetHDC(), *pPenOmbre) ;
			pDc->LineTo(ptBotRigh.x - i, ptBotRigh.y + i) ;
		}
		else
		{
			pDc->LineTo(ptBotRigh.x + 1, ptTopLeft.y - i) ;
			// pDc->SelectObject(*pPenOmbre);
			::SelectObject(pDc->GetHDC(), *pPenOmbre) ;
			pDc->MoveTo(ptBotRigh.x, ptBotRigh.y + i) ;
		}

		pDc->LineTo(ptTopLeft.x + i, ptBotRigh.y + i) ;

		if (bLeftHedgeDraw)
		{
			// Point de transition
      		// Transition point
			// pDc->SelectObject(*pPenTransition);
			::SelectObject(pDc->GetHDC(), *pPenTransition) ;
			pDc->LineTo(ptTopLeft.x + i, ptBotRigh.y + i + 1) ;
		}
		else
			pDc->LineTo(ptBotRigh.x -1, ptBotRigh.y + i) ;
	}

  // affichage du titre
  NS_CLASSLIB::TRect  clientRect = _pWorkingArea->GetClientRect() ;
	NS_CLASSLIB::TPoint tptBotLeft  = clientRect.BottomLeft() ;
	NS_CLASSLIB::TPoint tptBotRight = clientRect.BottomRight() ;

	NVLdVPoint ldvBotLeft(pView) ;
	ldvBotLeft = (NVLdVPoint&) _pWorkingArea->getAreaLogicalPointFromWindowPoint(tptBotLeft) ;

	NVLdVPoint ldvBotRight(pView) ;
	ldvBotRight = (NVLdVPoint&) _pWorkingArea->getAreaLogicalPointFromWindowPoint(tptBotRight) ;

  NVLdVPoint ldvLeft(ldvBotLeft) ;
  NVLdVPoint ldvRight(ldvBotRight) ;

	NVLdVTemps tNoLimit ;
	tNoLimit.setNoLimit();

	if ((ldvRight.getX() > pDrug->tDateFermeture) && (!pDrug->tDateFermeture.estNoLimit()))
		ldvRight.setX(pDrug->tDateFermeture) ;

	if (ldvLeft.getX() < pDrug->tDateOuverture)
		ldvLeft.setX(pDrug->tDateOuverture) ;

	tptBotLeft  = _pWorkingArea->getScrollablePhysicalPoint(ldvLeft) ;
	tptBotRight = _pWorkingArea->getScrollablePhysicalPoint(ldvRight) ;

	NS_CLASSLIB::TRect rectDisplay = NS_CLASSLIB::TRect(tptBotLeft.X(), ptTopLeft.y - (_pWorkingArea->getInterligne() - 5), tptBotRight.X(), ptTopLeft.y) ;
	NS_CLASSLIB::TRect rect2Compare = NS_CLASSLIB::TRect(rectDisplay) ;

  // Affichage des doses
  //
  if ((pView->getXunit() > pixSemaine) && (!(pDrug->aPhases.empty())))
  {
  	NSLdvDrugPhaseIter itPhase = pDrug->aPhases.begin() ;

    HFONT hOldFont = (HFONT) pDc->GetCurrentObject(OBJ_FONT) ;

    OWL::TFont drugDoseFont("Arial", 12) ;
    pDc->SelectObject(drugDoseFont) ;

    bool bDoseDisplayed = false ;
    int  iDoseTextHeight = 0 ;

  	for (; itPhase != pDrug->aPhases.end() ; itPhase++)
    {
    	// Phase indicator

			// Left time
			NVLdVTemps tpsPhaseStart = (*itPhase)->tDateOuverture ;
      // If start is visible, draw it
      if ((tpsPhaseStart > ldvBotLeft.getX()) && (tpsPhaseStart < ldvBotRight.getX()))
      {
      	NVLdVPoint ldvPhaseTopLeft(pView) ;
      	NVLdVPoint ldvPhaseBottomLeft(pView) ;
        ldvPhaseTopLeft.setX(tpsPhaseStart) ;
				ldvPhaseTopLeft.setY(_pWorkingArea->drugDonneTopLine(iIndex) + _pWorkingArea->getInterligne() / 2) ;
        ldvPhaseBottomLeft.setX(tpsPhaseStart) ;
				ldvPhaseBottomLeft.setY(_pWorkingArea->drugDonneTopLine(iIndex)) ;
        NS_CLASSLIB::TPoint ptPhaseTopLeft    = _pWorkingArea->getScrollablePhysicalPoint(ldvPhaseTopLeft) ;
        NS_CLASSLIB::TPoint ptPhaseBottomLeft = _pWorkingArea->getScrollablePhysicalPoint(ldvPhaseBottomLeft) ;
        pDc->MoveTo(ptPhaseBottomLeft.x, ptPhaseBottomLeft.y) ;
        pDc->LineTo(ptPhaseTopLeft.x, ptPhaseTopLeft.y) ;
        // pDc->LineTo(ptPhaseTopLeft.x+1, ptPhaseTopLeft.y) ;
        // pDc->LineTo(ptPhaseBottomLeft.x+1, ptPhaseBottomLeft.y) ;
      }

      // Right time
      NVLdVTemps tpsPhaseEnd = (*itPhase)->tDateFermeture ;
      if ((tpsPhaseEnd < ldvBotRight.getX()) && (tpsPhaseEnd > ldvBotLeft.getX()))
      {
      	NVLdVPoint ldvPhaseTopRight(pView) ;
      	NVLdVPoint ldvPhaseBottomRight(pView) ;
        ldvPhaseTopRight.setX(tpsPhaseEnd) ;
				ldvPhaseTopRight.setY(_pWorkingArea->drugDonneTopLine(iIndex) + _pWorkingArea->getInterligne() / 2) ;
        ldvPhaseBottomRight.setX(tpsPhaseEnd) ;
				ldvPhaseBottomRight.setY(_pWorkingArea->drugDonneTopLine(iIndex)) ;
        NS_CLASSLIB::TPoint ptPhaseTopRight    = _pWorkingArea->getScrollablePhysicalPoint(ldvPhaseTopRight) ;
        NS_CLASSLIB::TPoint ptPhaseBottomRight = _pWorkingArea->getScrollablePhysicalPoint(ldvPhaseBottomRight) ;
        pDc->MoveTo(ptPhaseBottomRight.x, ptPhaseBottomRight.y) ;
        pDc->LineTo(ptPhaseTopRight.x, ptPhaseTopRight.y) ;
        // pDc->LineTo(ptPhaseTopRight.x-1, ptPhaseTopRight.y) ;
        // pDc->LineTo(ptPhaseBottomRight.x-1, ptPhaseBottomRight.y) ;
      }

      if ((tpsPhaseStart < ldvRight.getX()) && (tpsPhaseEnd > ldvLeft.getX()))
      {
      	string sShortTitle = (*itPhase)->sTitreCourt ;
      	if (sShortTitle != string(""))
      	{
        	NVLdVPoint ldvPhaseTLeft(pView) ;
      		NVLdVPoint ldvPhaseBRight(pView) ;

          if (ldvRight.getX() < (*itPhase)->tDateFermeture)
          	ldvPhaseBRight.setX(ldvRight.getX()) ;
          else
          	ldvPhaseBRight.setX((*itPhase)->tDateFermeture) ;
          ldvPhaseBRight.setY(_pWorkingArea->drugDonneTopLine(iIndex)) ;

          if (ldvLeft.getX() > (*itPhase)->tDateOuverture)
          	ldvPhaseTLeft.setX(ldvLeft.getX()) ;
          else
          	ldvPhaseTLeft.setX((*itPhase)->tDateOuverture) ;
          ldvPhaseTLeft.setY(_pWorkingArea->drugDonneTopLine(iIndex) + _pWorkingArea->getInterligne() / 2) ;

        	NS_CLASSLIB::TPoint tptPhaseTLeft  = _pWorkingArea->getScrollablePhysicalPoint(ldvPhaseTLeft) ;
					NS_CLASSLIB::TPoint tptPhaseBRight = _pWorkingArea->getScrollablePhysicalPoint(ldvPhaseBRight) ;

          NS_CLASSLIB::TRect rectPhaseDisplay = NS_CLASSLIB::TRect(tptPhaseTLeft.X(), tptPhaseTLeft.Y(), tptPhaseBRight.X(), tptPhaseBRight.Y()) ;
					NS_CLASSLIB::TRect rectPhase2Compare = NS_CLASSLIB::TRect(rectDisplay) ;

          pDc->DrawText(sShortTitle.c_str(), -1, rectPhase2Compare, DT_CALCRECT) ;
          if (rectPhaseDisplay.Width() >= rectPhase2Compare.Width())
          {
          	rectPhaseDisplay = NS_CLASSLIB::TRect(rectPhaseDisplay.Left(), rectPhaseDisplay.Bottom()-rectPhase2Compare.Height(), rectPhaseDisplay.Right(), rectPhaseDisplay.Bottom()) ;
          	pDc->DrawText(sShortTitle.c_str(), -1, rectPhaseDisplay, DT_CENTER) ;
            if (rectPhase2Compare.Height() > iDoseTextHeight)
            	iDoseTextHeight = rectPhase2Compare.Height() ;
            bDoseDisplayed = true ;
          }
        }
      }
    }

    if (bDoseDisplayed)
    	rectDisplay.Set(rectDisplay.Left(),
                      rectDisplay.Top() - iDoseTextHeight,
                      rectDisplay.Right(),
                      rectDisplay.Bottom() - iDoseTextHeight) ;

    ::SelectObject(pDc->GetHDC(), hOldFont) ;
  }

	pDc->DrawText(pDrug->sTitreCourt.c_str(), -1, rect2Compare, DT_CALCRECT) ;
	if (rectDisplay.Width() < rect2Compare.Width())
	{
		int decal = rect2Compare.Width() - rectDisplay.Width() ;
		rectDisplay.left -= decal ;
		rectDisplay.right += decal ;
	}

	pDc->DrawText(pDrug->sTitreCourt.c_str(), -1, rectDisplay, DT_CENTER) ;

  // -----------------------------------------------------------------------
	// Affichage des objectifs
	// -----------------------------------------------------------------------

	if ((pDrug->pWorstJalons) && (!(pDrug->pWorstJalons->empty())))
	{
  	GoalInfoIter jalonIt = pDrug->pWorstJalons->begin() ;
    for ( ; jalonIt != pDrug->pWorstJalons->end(); jalonIt++)
    {
    	if (((*jalonIt)->tpsInfo < tRightTime) &&
                                        ((*jalonIt)->tpsClosed > tLeftTime))
      {
      	NVLdVPoint goalTopLeft(ldvTopLeft) ;
        NVLdVPoint goalBottomRight(ldvBottomRight) ;
        if ((*jalonIt)->tpsInfo > tLeftTime)
        	goalTopLeft.setX((*jalonIt)->tpsInfo) ;
        if ((*jalonIt)->tpsClosed < tRightTime)
        	goalBottomRight.setX((*jalonIt)->tpsClosed) ;

        NS_CLASSLIB::TPoint ptTL = _pWorkingArea->getScrollablePhysicalPoint(goalTopLeft) ;
      	NS_CLASSLIB::TPoint ptBR = _pWorkingArea->getScrollablePhysicalPoint(goalBottomRight) ;

        ptTL.y = ptBR.y + (ptTL.y - ptBR.y) / 2 + 1 ;
        ptBR.y = ptTL.y - 3 ;

        switch ((*jalonIt)->iLevel)
        {
        	// puisqu'il n'y a rien � faire, est-ce raisonnable d'afficher du rouge ?
          //case NSLdvGoalInfo::AVrouge :
          //    pPinceau = new OWL::TBrush(pView->pPinceauS4->GetHandle()) ;
          //    pDc->FillRect(ptTL.x, ptTL.y - 1, ptBR.x, ptBR.y + 1, *pPinceau) ;
          //    break;
          case NSLdvGoalInfo::AVjaune :
          	pPinceau = new OWL::TBrush(pView->pPinceauS3->GetHandle()) ;
            pDc->FillRect(ptTL.x, ptTL.y - 1, ptBR.x, ptBR.y + 1, *pPinceau) ;
            break ;
          case NSLdvGoalInfo::AVvert  :
          	pPinceau = new OWL::TBrush(pView->pPinceauS2->GetHandle()) ;
            pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau) ;
            break ;
          case NSLdvGoalInfo::Bleu    :
          	pPinceau = new OWL::TBrush(pView->pPinceauS1->GetHandle()) ;
            pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau) ;
            break ;
          case NSLdvGoalInfo::APvert  :
          	pPinceau = new OWL::TBrush(pView->pPinceauS2->GetHandle()) ;
            pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau) ;
            break ;
          case NSLdvGoalInfo::APjaune :
          	pPinceau = new OWL::TBrush(pView->pPinceauS3->GetHandle()) ;
            pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau) ;
            break ;
          case NSLdvGoalInfo::AProuge :
          	pPinceau = new OWL::TBrush(pView->pPinceauS4->GetHandle()) ;
            pDc->FillRect(ptTL.x, ptTL.y, ptBR.x, ptBR.y, *pPinceau) ;
            break ;
        }

        delete pPinceau ;

        // pDc->SelectObject(*pPenEclaire);
        ::SelectObject(pDc->GetHDC(), *pPenEclaire) ;
        pDc->MoveTo(ptTL.x, ptTL.y) ;
        pDc->LineTo(ptBR.x, ptTL.y) ;

        // pDc->SelectObject(*pPenOmbre);
        ::SelectObject(pDc->GetHDC(), *pPenOmbre);
        pDc->MoveTo(ptTL.x, ptBR.y - 1);
        pDc->LineTo(ptBR.x, ptBR.y - 1);
      }
    }
  }

	// Restauration des objets initiaux (pen et brush)
	::SelectObject(pDc->GetHDC(), oldPen);
  ::SelectObject(pDc->GetHDC(), oldBrush);
}

void
NSDrugLineView::EvRButtonDown()
{
}

void
NSDrugLineView::createComponents(ArrayOfToons* pToonsArray)
{
/*
  if (!(pPreoccupation->aConcerns.empty()))
  {
  	ArrayConcernIter i = pPreoccupation->aConcerns.begin();
    for (; i != pPreoccupation->aConcerns.end(); i++)
    {
    	NSConcernView* pPbView = new NSConcernView(pContexte, pView, *i);
      pToonsArray->push_back(new NSConcernView(*pPbView));
      pPbView->createComponents(pToonsArray);
      delete pPbView;
    }
  }
*/
}


NSDrugLineView&
NSDrugLineView::operator=(NSDrugLineView& src)
{
	if (this == &src)
		return *this ;

	initialiser((NSLdvTimeToon*)(&src)) ;

	iIndex          = src.iIndex ;
	pDrug  			    = src.pDrug ;
	iLeftMargin     = src.iLeftMargin ;
	iRigthMargin    = src.iRigthMargin ;
	iTopMargin      = src.iTopMargin ;
	iBottomMargin   = src.iBottomMargin ;

	return *this ;
}


// -----------------------------------------------------------------------------
// ---------------------- METHODES DE NSBaseLineView ---------------------------
// -----------------------------------------------------------------------------

NSBaseLineView::NSBaseLineView(NSContexte* pCtx, NSLdvViewArea *pWorkArea)
               :NSLigneView(pCtx, pWorkArea, false)
{
	NVLdVTemps tTemps;

	// Initialisation de la "boite"
	// Box initialisation

	// Time : from year 0 to year 9999
	tTemps.init();
	Box.setLeft(tTemps);
	tTemps.setNoLimit();
	Box.setRight(tTemps);
	// Height : from 0 to NSLdvView::dLargeurLigne
	Box.setTop(_pWorkingArea->getBottomMargin() + _pWorkingArea->getLargeurBaseline()) ;
	Box.setBottom(_pWorkingArea->getBottomMargin()) ;

	iIndex   = -1 ;
	iZOrder  = LEVEL_BASELINE;
  toonType = toonLine;
}

NSBaseLineView::NSBaseLineView(NSBaseLineView& rv)
               :NSLigneView(rv.pContexte, rv._pWorkingArea, rv._bVerticalScrollEnabled)
{
	initialiser((NSLdvTimeToon*)(&rv));
}

NSBaseLineView::~NSBaseLineView()
{
}

void
NSBaseLineView::SetupWindow()
{
}

voidNSBaseLineView::draw(TDC* pDc, NVLdVRect* pRectARepeindre){
	NVLdVPoint ldvTopLeft(pView) ;
	ldvTopLeft.setX(pRectARepeindre->getLeft()) ;
	ldvTopLeft.setY(long(_pWorkingArea->getBottomMargin() + _pWorkingArea->getLargeurBaseline())) ;
	NVLdVPoint ldvBottomRight(pView) ;
	ldvBottomRight.setX(pRectARepeindre->getRight()) ;
	ldvBottomRight.setY(long(_pWorkingArea->getBottomMargin())) ;

	NS_CLASSLIB::TPoint ptTopLeft = _pWorkingArea->getAreaPhysicalPoint(ldvTopLeft) ;
	NS_CLASSLIB::TPoint ptBotRigh = _pWorkingArea->getAreaPhysicalPoint(ldvBottomRight) ;

	//OWL::TBrush PinceauBleu(NS_CLASSLIB::TColor::LtBlue);
	pDc->FillRect(ptTopLeft.x, ptTopLeft.y, ptBotRigh.x, ptBotRigh.y, OWL::TBrush(pView->pPinceauBleu->GetHandle())) ;

	// d�termination de la VisibleBox
	VisibleBox.initialise(ldvTopLeft.getX(),
												ldvBottomRight.getX(),
												ldvBottomRight.getY(),
												ldvTopLeft.getY());

	// pDc->Rectangle(ptTopLeft, ptBotRigh);
}

void
NSBaseLineView::EvRButtonDown()
{
}

NSBaseLineView&
NSBaseLineView::operator=(NSBaseLineView& src)
{
	if (this == &src)
		return *this ;

	initialiser((NSLdvTimeToon*)(&src)) ;

  return *this ;
}

// -----------------------------------------------------------------------------
//                               NSLdvCurvePoint
// -----------------------------------------------------------------------------

NSLdvCurvePoint::NSLdvCurvePoint(NSContexte* pCtx, NSLdvViewArea *pWorkArea, NSLdvCurve* pTheCurve, NSHistoryValueManagement* pHistoryValue)
                :NSLdvTimeToon(pCtx, pWorkArea, true)
{
	_pCurve           = pTheCurve ;

	_pPreviousBrother = NULL ;
  _pNextBrother     = NULL ;

  _value            = *pHistoryValue ;

  _dValue           = 0 ;
  _sUnitSens        = string("") ;

  // When the point is created, the Y axis is not initialized yet (since the
  // axis is configured from the array of points). So the top and bottom
  // information are not set up in the constructor, but in SetupWindow()
  //
  NVLdVTemps pointDate ;
  pointDate.initFromDate(_value.getDate()) ;

  Box.setLeft(pointDate) ;
  Box.setRight(pointDate) ;

  _iFixedWidthInPixels = 2 * _pCurve->pointRadius ;

	iZOrder  = LEVEL_CURVES ;
	toonType = toonCurvePoint ;
}

NSLdvCurvePoint::NSLdvCurvePoint(NSLdvCurvePoint& rv)
                :NSLdvTimeToon(rv.pContexte, rv._pWorkingArea, rv._bVerticalScrollEnabled)
{
  _pCurve           = rv._pCurve ;

	_value            = rv._value ;

  _dValue           = rv._dValue ;
  _sUnitSens        = rv._sUnitSens ;

	_pPreviousBrother = rv._pPreviousBrother ;
  _pNextBrother     = rv._pNextBrother ;
}

NSLdvCurvePoint::~NSLdvCurvePoint()
{
}

void
NSLdvCurvePoint::SetupWindow()
{
	bool bSuccess ;
	int iYcoordinate = _pCurve->giveYCoordinateForValue(_dValue, &bSuccess, _sUnitSens) ;

	Box.setTop(iYcoordinate) ;
	Box.setBottom(iYcoordinate) ;
}

void
NSLdvCurvePoint::draw(TDC* pDc, NVLdVRect* pRectARepeindre)
{
	// Sauvegarde des �l�ments en cours (pen et brush)
	HPEN oldPen     = (HPEN) pDc->GetCurrentObject(OBJ_PEN) ;
	HBRUSH oldBrush = (HBRUSH) pDc->GetCurrentObject(OBJ_BRUSH) ;

  OWL::TPen curvePen(_pCurve->color, _pCurve->dotWidth, _pCurve->dotStyle) ;
  ::SelectObject(pDc->GetHDC(), curvePen) ;

  OWL::TBrush curvePointsBrush(_pCurve->color) ;
  ::SelectObject(pDc->GetHDC(), curvePointsBrush) ;

	// Drawing the lines
  //
  NVLdVPoint PtThis(pView) ;
  PtThis.setX(Box.getLeft()) ;
  PtThis.setY(Box.getTop()) ;

  NS_CLASSLIB::TPoint physicalThis = _pWorkingArea->getScrollablePhysicalPoint(PtThis) ;

  if (NULL != _pPreviousBrother)
  {
  	NVLdVPoint PtPrevious(pView) ;
    PtPrevious.setX(_pPreviousBrother->Box.getLeft()) ;
  	PtPrevious.setY(_pPreviousBrother->Box.getTop()) ;
  	NS_CLASSLIB::TPoint physicalPrevious = _pWorkingArea->getScrollablePhysicalPoint(PtPrevious) ;
    pDc->MoveTo(physicalPrevious) ;
    pDc->LineTo(physicalThis) ;
  }
  else
  	pDc->MoveTo(physicalThis) ;

  if (NULL != _pNextBrother)
  {
  	NVLdVPoint PtNext(pView) ;
    PtNext.setX(_pNextBrother->Box.getLeft()) ;
  	PtNext.setY(_pNextBrother->Box.getTop()) ;
  	NS_CLASSLIB::TPoint physicalNext = _pWorkingArea->getScrollablePhysicalPoint(PtNext) ;
    pDc->LineTo(physicalNext) ;
  }

  // Drawing the point
  //
  drawPoint(pDc, physicalThis, &curvePointsBrush, &curvePen) ;

	// Restauration des objets initiaux (pen et brush)
	::SelectObject(pDc->GetHDC(), oldPen) ;
	::SelectObject(pDc->GetHDC(), oldBrush) ;
}

void
NSLdvCurvePoint::drawPoint(TDC* pDc, NS_CLASSLIB::TPoint screenPoint, OWL::TBrush* pCurvePointsBrush, OWL::TPen* pCurvePen)
{
	NS_CLASSLIB::TRect pointDrawingBox(screenPoint.X() - _pCurve->pointRadius,
                                     screenPoint.Y() - _pCurve->pointRadius,
                                     screenPoint.X() + _pCurve->pointRadius,
                                     screenPoint.Y() + _pCurve->pointRadius) ;

  switch(_pCurve->pointAspect)
  {
  	case NSLdvCurve::paCircle :
    	drawPointCircle(pDc, pointDrawingBox, pCurvePointsBrush, pCurvePen) ;
      break ;
    case NSLdvCurve::paSquare :
    	drawPointSquare(pDc, pointDrawingBox, pCurvePointsBrush, pCurvePen) ;
      break ;
    case NSLdvCurve::paTriangle :
    	drawPointUpTriangle(pDc, pointDrawingBox, pCurvePointsBrush, pCurvePen) ;
      break ;
    case NSLdvCurve::paStar :
    	drawPointStar(pDc, pointDrawingBox, pCurvePointsBrush, pCurvePen) ;
      break ;
  }
}

void
NSLdvCurvePoint::drawPointCircle(TDC* pDc, NS_CLASSLIB::TRect pointDrawingBox, OWL::TBrush* pCurvePointsBrush, OWL::TPen* pCurvePen)
{
	pDc->Ellipse(pointDrawingBox) ;
}

void
NSLdvCurvePoint::drawPointSquare(TDC* pDc, NS_CLASSLIB::TRect pointDrawingBox, OWL::TBrush* pCurvePointsBrush, OWL::TPen* pCurvePen)
{
	pDc->FillRect(pointDrawingBox, *pCurvePointsBrush) ;
}

void
NSLdvCurvePoint::drawPointUpTriangle(TDC* pDc, NS_CLASSLIB::TRect pointDrawingBox, OWL::TBrush* pCurvePointsBrush, OWL::TPen* pCurvePen)
{
	NS_CLASSLIB::TPoint trianglePoints[3] ;
  trianglePoints[0] = NS_CLASSLIB::TPoint(pointDrawingBox.Left(), pointDrawingBox.Bottom()) ;
  trianglePoints[1] = NS_CLASSLIB::TPoint(pointDrawingBox.Right(), pointDrawingBox.Bottom()) ;
  trianglePoints[2] = NS_CLASSLIB::TPoint(pointDrawingBox.Left() + pointDrawingBox.Width() / 2, pointDrawingBox.Top()) ;

  pDc->Polygon(trianglePoints, 3) ;
}

void
NSLdvCurvePoint::drawPointDownTriangle(TDC* pDc, NS_CLASSLIB::TRect pointDrawingBox, OWL::TBrush* pCurvePointsBrush, OWL::TPen* pCurvePen)
{
	NS_CLASSLIB::TPoint trianglePoints[3] ;
  trianglePoints[0] = NS_CLASSLIB::TPoint(pointDrawingBox.Left(), pointDrawingBox.Top()) ;
  trianglePoints[1] = NS_CLASSLIB::TPoint(pointDrawingBox.Right(), pointDrawingBox.Top()) ;
  trianglePoints[2] = NS_CLASSLIB::TPoint(pointDrawingBox.Left() + pointDrawingBox.Width() / 2, pointDrawingBox.Bottom()) ;

  pDc->Polygon(trianglePoints, 3) ;
}

void
NSLdvCurvePoint::drawPointStar(TDC* pDc, NS_CLASSLIB::TRect pointDrawingBox, OWL::TBrush* pCurvePointsBrush, OWL::TPen* pCurvePen)
{
	// Taking the upper 2/3 rect and drawing an Up triangle
  //
	NS_CLASSLIB::TRect upperTriangleDrawingBox(pointDrawingBox.Left(),
                                             pointDrawingBox.Top(),
                                             pointDrawingBox.Right(),
                                             pointDrawingBox.Top() + pointDrawingBox.Height() * 2 / 3) ;
  drawPointUpTriangle(pDc, upperTriangleDrawingBox, pCurvePointsBrush, pCurvePen) ;

  // Taking the lower 2/3 rect and drawing a Down triangle
  //
	upperTriangleDrawingBox = NS_CLASSLIB::TRect(pointDrawingBox.Left(),
                                               pointDrawingBox.Top() + pointDrawingBox.Height() * 2 / 3,
                                               pointDrawingBox.Right(),
                                               pointDrawingBox.Bottom() ) ;
  drawPointDownTriangle(pDc, upperTriangleDrawingBox, pCurvePointsBrush, pCurvePen) ;
}

void
NSLdvCurvePoint::EvRButtonDown()
{
}

void
NSLdvCurvePoint::setActualValues(double dNewValue, string sNewUnitSens)
{
	_dValue    = dNewValue ;
  _sUnitSens = sNewUnitSens ;
}

void
NSLdvCurvePoint::resetActualValues()
{
	_dValue    = 0 ;
  _sUnitSens = string("") ;
}

NSLdvCurvePoint&
NSLdvCurvePoint::operator=(NSLdvCurvePoint& src)
{
	if (this == &src)
		return *this ;

  _pCurve           = src._pCurve ;

	_value            = src._value ;

  _dValue           = src._dValue ;
  _sUnitSens        = src._sUnitSens ;

	_pPreviousBrother = src._pPreviousBrother ;
  _pNextBrother     = src._pNextBrother ;

  return *this ;
}

// --------------------------------------------------------------------------
// ----------------------- METHODES DE NSSsObjView --------------------------
// --------------------------------------------------------------------------

NSSsObjView::NSSsObjView(NSContexte* pCtx, NSLdvViewArea *pWorkArea, NSLdvSousObjet* pSsObj, NSLdvObjetView *pObjV, NSConcernView *pPbV)
            :NSLdvTimeToon(pCtx, pWorkArea, false)
{
	pSsObjet = pSsObj;

	pObjetView   = pObjV ;
	pConcernView = pPbV ;

  if (NULL != pObjetView)
  	_bVerticalScrollEnabled = pObjetView->isVerticalScrollEnabled() ;

	Box.setLeft(pSsObjet->tDateHeureDebut) ;
	Box.setRight(pSsObjet->tDateHeureFin) ;

	if (pPbV)
	{
		Box.setTop(pPbV->Box.getTop()) ;
		Box.setBottom(pPbV->Box.getBottom()) ;
	}
	else
	{
		Box.setTop(500) ;
		Box.setBottom(0) ;
	}

	if ((NULL != pObjetView) && (LEVEL_BASE_OBJECTS + RELOBLEVEL_OBJECT == pObjetView->iZOrder))
  	iZOrder  = LEVEL_BASE_OBJECTS + RELOBLEVEL_SSOBJT ;
  else
		iZOrder  = LEVEL_OBJECTS + RELOBLEVEL_SSOBJT ;

	toonType = toonObjectPart ;
}

NSSsObjView::NSSsObjView(NSSsObjView& rv)            :NSLdvTimeToon(rv.pContexte, rv._pWorkingArea, rv._bVerticalScrollEnabled)
{
	initialiser((NSLdvTimeToon*)(&rv));

	pSsObjet        = rv.pSsObjet;
	pObjetView      = rv.pObjetView;
	pConcernView    = rv.pConcernView;
}

NSSsObjView::~NSSsObjView(){
}

void
NSSsObjView::SetupWindow()
{
}

voidNSSsObjView::draw(TDC* pDc, NVLdVRect* pRectARepeindre){
	NVLdVPoint ldvTopLeft(pView) ;
	// Left time
	NVLdVTemps tLeftTime = pRectARepeindre->getLeft() ;
	if (pSsObjet->tDateHeureDebut > tLeftTime)
		tLeftTime = pSsObjet->tDateHeureDebut ;

	ldvTopLeft.setX(tLeftTime) ;
	if (NULL != pConcernView)
		ldvTopLeft.setY(_pWorkingArea->preoccupDonneTopLine(pConcernView->getIndex()) - 2) ;

	NS_CLASSLIB::TPoint ptTopLeft ;
	if (_bVerticalScrollEnabled)
		ptTopLeft = _pWorkingArea->getScrollablePhysicalPoint(ldvTopLeft) ;
	else
  	ptTopLeft = _pWorkingArea->getAreaPhysicalPoint(ldvTopLeft) ;

	// choix de l'ic�ne

	// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	// attention l'icone depend du type de l'objet. Le type de l'objet est donn�
	// par la variable "sTypeDoc" du NSLdvObjet correspondant
	// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	// chemin : this->pObjetView->pObjet->sTypeDoc
	// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	//OWL::TIcon  icObjet(*(pView->GetApplication()), (TResId)IDI_LDVSSOBJ16) ;
	//ICONINFO iconInfo;
	//icObjet.GetIconInfo(&iconInfo);
	//pDc->DrawIcon(ptTopLeft.X() - 8, ptTopLeft.Y(), icObjet, 16, 16) ;

	// On donne � DrawIcon le point en haut � gauche du rectangle qui doit contenir le dessin
	pDc->DrawIcon(ptTopLeft.X() - 8, ptTopLeft.Y(), *(pView->pLdvSsObject), 16, 16) ;

	NS_CLASSLIB::TRect PixelVisibleBox = NS_CLASSLIB::TRect(ptTopLeft.X() - 8,
																													ptTopLeft.Y(),
																													ptTopLeft.X() + 8,
                                                          ptTopLeft.Y() + 16);

	VisibleBox = (NVLdVRect&) _pWorkingArea->getAreaLogicalRectFromWindowRect(PixelVisibleBox) ;

  // pDc->RestorePen();
}


void
NSSsObjView::drawInBasket(TDC *pDc, NVLdVRect *pRectARepeindre)
{
}


void
NSSsObjView::EvRButtonDown()
{
}

void
NSSsObjView::createComponents(ArrayOfToons* pToonsArray)
{
}

NSSsObjView&
NSSsObjView::operator=(NSSsObjView& src)
{
	if (this == &src)
		return *this ;

	initialiser((NSLdvTimeToon*)(&src));

	pSsObjet        = src.pSsObjet;
	pObjetView      = src.pObjetView;
	pConcernView    = src.pConcernView;

  return *this;
}


// --------------------------------------------------------------------------
// ---------------------- METHODES DE NSLdvObjetView ------------------------
// --------------------------------------------------------------------------

NSLdvObjetView::NSLdvObjetView(NSContexte* pCtx, NSLdvViewArea *pWorkArea, NSLdvObjet* pObj, NSLigneView *pLineView)
               :NSLdvTimeToon(pCtx, pWorkArea, pLineView->isVerticalScrollEnabled())
{
	pObjet     = pObj ;
  pLigneView = pLineView ;

  Box.setLeft(pObjet->tDateHeureDebut) ;
  Box.setRight(pObjet->tDateHeureFin) ;

  Box.setTop(pLineView->Box.getTop() - 5) ;
  Box.setBottom(pLineView->Box.getBottom() + 5) ;

  NSLigneView* pBaseLine = _pWorkingArea->getToonsArray()->getBaseLine() ;
  if (pBaseLine == pLigneView)
  	iZOrder  = LEVEL_BASE_OBJECTS + RELOBLEVEL_OBJECT ;
  else
  	iZOrder  = LEVEL_OBJECTS + RELOBLEVEL_OBJECT ;

  toonType = toonObject ;
}


NSLdvObjetView::NSLdvObjetView(NSLdvObjetView& rv)
               :NSLdvTimeToon(rv.pContexte, rv._pWorkingArea, rv._bVerticalScrollEnabled)
{
  initialiser((NSLdvTimeToon*)(&rv)) ;

  pObjet     = rv.pObjet ;
  pLigneView = rv.pLigneView ;
}


NSLdvObjetView::~NSLdvObjetView()
{
}

void		NSLdvObjetView::createComponents(ArrayOfToons* pToonsArray)
{
/*
	if (!(pObjet->aSousObjets.empty()))
  {
  	ArraySsObjIter i = pObjet->aSousObjets.begin();
    for (; i != pObjet->aSousObjets.end(); i++)
    {
    	NSSsObjView* pSsObjView = new NSSsObjView(pContexte, pView, *i);
      pToonsArray->push_back(new NSSsObjView(*pSsObjView));
      pSsObjView->createComponents(pToonsArray);
      delete pSsObjView;
    }
  }
*/
}

void
NSLdvObjetView::SetupWindow()
{
}

voidNSLdvObjetView::draw(TDC* pDc, NVLdVRect* pRectARepeindre){
	NVLdVPoint ldvTopLeft(pView);
	// Left time
	NVLdVTemps tLeftTime = pRectARepeindre->getLeft();
	if (pObjet->tDateHeureDebut > tLeftTime)
		tLeftTime = pObjet->tDateHeureDebut ;

	ldvTopLeft.setX(tLeftTime);	ldvTopLeft.setY(_pWorkingArea->preoccupDonneTopLine(pLigneView->getIndex()) - 2/*Box.getTop()*/);

  NS_CLASSLIB::TPoint ptTopLeft ;
	if (_bVerticalScrollEnabled)
		ptTopLeft = _pWorkingArea->getScrollablePhysicalPoint(ldvTopLeft) ;
	else
  	ptTopLeft = _pWorkingArea->getAreaPhysicalPoint(ldvTopLeft) ;

	// choix de l'ic�ne	// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	// attention l'icone depend du type de l'objet. Le type de l'objet est donn�
	// par la variable "sTypeDoc" du NSLdvObjet correspondant
	// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	// chemin : this->pObjet->sTypeDoc
	// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	// OWL::TIcon  icObjet(*(pView->GetApplication()), (TResId)IDI_LDVOBJET16) ;	// ICONINFO iconInfo;
	// icObjet.GetIconInfo(&iconInfo);
	// pDc->DrawIcon(ptTopLeft.X(), ptTopLeft.Y(), icObjet, 16, 16) ;

	NS_CLASSLIB::TRect PixelVisibleBox ;

  nsSkin* pSkin = 0 ;
  if (pObjet->sLexique != "")
  {
    string sCodeSens ;
    pContexte->getDico()->donneCodeSens(&(pObjet->sLexique), &sCodeSens) ;
    string sCodeIcon = string("icon_") + sCodeSens ;
    pSkin = pContexte->getSkins()->donneSkin(sCodeIcon) ;
  }

  // Skin
  //
  if (pSkin && pSkin->getBackBmp())
  {
  	OWL::TDib* pBackgrnd = pSkin->getBackBmp() ;

    _iFixedWidthInPixels = pBackgrnd->Width() ;

    NS_CLASSLIB::TPoint dibOrigin ;
    bool bBottomUp ;
    //
    // Bottom up dib : origin lies at the lower left corner
    //
    if (pBackgrnd->Height() > 0)
    {
    	bBottomUp = true ;
      dibOrigin = NS_CLASSLIB::TPoint(0, 0) ;
    }
    //
    // top down dib : origin lies at the upper left corner
    //
    else
    {
    	bBottomUp = false ;
      dibOrigin = NS_CLASSLIB::TPoint(0, 0) ;
    }

    // NS_CLASSLIB::TRect winRect(ptTopLeft.X(), ptTopLeft.Y(),
    //                                    ptTopLeft.X() + pBackgrnd->Width(),
    //                                    ptTopLeft.Y() + pBackgrnd->Height());

		int iLeftExcess = pBackgrnd->Width() / 2 ;
    int iRightExcess = pBackgrnd->Width() - iLeftExcess ;
    NS_CLASSLIB::TRect winRect(ptTopLeft.X() - iLeftExcess, ptTopLeft.Y(),
                                        ptTopLeft.X() + iRightExcess,
                                        ptTopLeft.Y() + pBackgrnd->Height()) ;

    //  Using SetDIBitsToDevice
    //
    // pDc->SetDIBitsToDevice(winRect, dibOrigin, *pBackgrnd) ;

    // Using BitBlt
    //
    HDC hdcMem = CreateCompatibleDC(pDc->GetHDC()) ;

    HBITMAP bitmap = ::CreateDIBitmap(
               *pDc,
               (LPBITMAPINFOHEADER)pBackgrnd->GetInfoHeader(),
               CBM_INIT,
               (const uint8 far*)pBackgrnd->GetBits(),
               (LPBITMAPINFO)pBackgrnd->GetInfo(),
               pBackgrnd->Usage()
            ) ;

    HGDIOBJ hbmOld = SelectObject(hdcMem, bitmap) ;

    BITMAP bm ;
    GetObject(bitmap, sizeof(bm), &bm) ;
    int x = bm.bmWidth ;
    int y = bm.bmHeight ;

    // pDc->BitBlt(winRect.Left(), winRect.Top(), x, y, hdcMem, 0, 0, SRCCOPY) ;
    TransparentBlt(*pDc, winRect.Left(), winRect.Top(), winRect.Width(), winRect.Height(), hdcMem, 0, 0, x, y, RGB(255, 0, 255)) ;

    SelectObject(hdcMem, hbmOld) ;
    DeleteDC(hdcMem) ;

    PixelVisibleBox = winRect ;

    /*
    PixelVisibleBox = NS_CLASSLIB::TRect(   ptTopLeft.X(),
                                                ptTopLeft.Y(),
                                                ptTopLeft.X() + 16,
                                                ptTopLeft.Y() + 16); */
	}
  //
  // Icon standard
  //
  else
  {
  	// On donne � DrawIcon le point en haut � gauche du rectangle qui doit contenir le dessin
    pDc->DrawIcon(ptTopLeft.X(), ptTopLeft.Y(), *(pView->pLdvObject), 16, 16) ;
    //PixelVisibleBox = NS_CLASSLIB::TRect(ptTopLeft.X(),
    //                                            ptTopLeft.Y(),
    //                                            ptTopLeft.X() + 16,
    //                                            ptTopLeft.Y() + 16) ;
    PixelVisibleBox = NS_CLASSLIB::TRect(ptTopLeft.X() - 8,
                                                ptTopLeft.Y(),
                                                ptTopLeft.X() + 8,
                                                ptTopLeft.Y() + 16) ;
    _iFixedWidthInPixels = 16 ;
  }

  VisibleBox = (NVLdVRect&) _pWorkingArea->getAreaLogicalRectFromWindowRect(PixelVisibleBox) ;
}

voidNSLdvObjetView::EvRButtonDown(){
}

NSLdvObjetView&NSLdvObjetView::operator=(NSLdvObjetView& src){
	if (this == &src)
		return *this ;

	initialiser((NSLdvTimeToon*)(&src));

	pObjet = src.pObjet ;
  return *this;}

// -----------------------------------------------------------------------------// class NSLdvTankView
// -----------------------------------------------------------------------------

NSLdvTankView::NSLdvTankView(NSLdvView *pView, NSContexte *pCtx)
              :NSRoot(pCtx)
{
	pLdvView          = pView ;

	pSsObjetTankArray = new SsObjViewVector() ;
  updateTankList() ;}

void
NSLdvTankView::updateTankList()
{
	if (pLdvView->aToons.empty())
		return;

	for (ToonsIter toonIter = pLdvView->aToons.begin() ; toonIter != pLdvView->aToons.end() ; toonIter++)
	{
		NSSsObjView *pSsObjView = TYPESAFE_DOWNCAST(*toonIter, NSSsObjView) ;
		if (pSsObjView)
		{
			// L'objet appartient-il � la liste ?
      // Does this sub-object belong to the orphean list
			// bool    bAlreadyExists = false ;
			if (!(pSsObjetTankArray->empty()))
			{
				SsObjViewIterator SsObjVIter = pSsObjetTankArray->begin() ;
				for (; (SsObjVIter != pSsObjetTankArray->end()) &&  ((*SsObjVIter) != pSsObjView); SsObjVIter++)
					;

				// Il n'appartient pas � la liste
				if (SsObjVIter == pSsObjetTankArray->end())
				{
					// S'il est orphelin, on l'ajoute � la liste
					if (pSsObjView->pSsObjet->sConcern == "")
						pSsObjetTankArray->push_back(pSsObjView) ;
				}

				// Il appartient � la liste
				else
				{
					// S'il n'est pas orphelin, on l'enl�ve
					if (pSsObjView->pSsObjet->sConcern != "")
					{
						pSsObjetTankArray->erase(SsObjVIter) ;

						// Si c'�tait le dernier sous-objet du r�servoir et
						// qu'Episodus est en mode "Episode", on passe au stade
            // suivant
						if ((pSsObjetTankArray->empty()) &&
								(pContexte->getSuperviseur()->getEpisodus()->GetEpisoState() == NSEpisodus::stateEpisod))
							pContexte->getSuperviseur()->getEpisodus()->SetEpisoState(NSEpisodus::stateMessage);
					}
				}
			}

			// La liste est vide
			else
			{
      	if (pSsObjView->pSsObjet->sConcern == "")
					pSsObjetTankArray->push_back(pSsObjView) ;
			}
		}
	}
}


NSLdvTankView::~NSLdvTankView()
{
//	pSsObjetTankArray->vider() ;
	delete pSsObjetTankArray ;
}


NS_CLASSLIB::TRect
NSLdvTankView::coords()
{
  return rectCoords ;
}


bool
NSLdvTankView::setCoords(NS_CLASSLIB::TRect rect)
{
	rectCoords = rect ;
  return true;
}


bool
NSLdvTankView::setCoords(int left, int top, int right, int bottom)
{
	rectCoords = NS_CLASSLIB::TRect(left, top, right, bottom) ;
  return true;
}


void
NSLdvTankView::affiche(TDC *pDc, NS_CLASSLIB::TRect rectARepeindre)
{
	updateTankList() ;

	if (pSsObjetTankArray->empty())
  	return;

	NS_CLASSLIB::TPoint ptTopLeft = rectCoords.TopLeft() ;

	for (SsObjViewIterator SsObjVIter = pSsObjetTankArray->begin() ; SsObjVIter != pSsObjetTankArray->end() ; SsObjVIter++)
	{
		OWL::TIcon  icObjet(*(pLdvView->GetApplication()), (TResId)IDI_LDVSSOBJ16) ;
		ICONINFO iconInfo;
		icObjet.GetIconInfo(&iconInfo);
		pDc->DrawIcon(ptTopLeft.X(), ptTopLeft.Y(), icObjet, 16, 16) ;

		NS_CLASSLIB::TRect  rectDisplay     = NS_CLASSLIB::TRect(ptTopLeft.X() + 16, ptTopLeft.Y(), ptTopLeft.X() + 16, ptTopLeft.Y() + 16) ;
		NS_CLASSLIB::TRect  rect2Compare    = rectDisplay ;
		pDc->DrawText((*SsObjVIter)->pSsObjet->sTitre.c_str(), -1, rect2Compare, DT_CALCRECT) ;
		if (rectDisplay.Width() < rect2Compare.Width())
		{
			int decal = rect2Compare.Width() ;
//    rectDisplay.left -= decal ;
			rectDisplay.right += decal ;
		}

		// (*SsObjVIter)->Box.initialise(&pLdvView->GetClientRect().BottomRight(), &rectDisplay, _pWorkingArea) ;
		// (*SsObjVIter)->VisibleBox.initialise(&pLdvView->GetClientRect().BottomRight(), &rectDisplay, _pWorkingArea) ;
		// pDc->DrawText((*SsObjVIter)->pSsObjet->sTitre.c_str(), -1, rectDisplay, DT_CENTER) ;

		ptTopLeft.y += 16 ;

//  (*SsObjVIter)->drawInBasket(dc, rectarepeindre)
	}
}


bool
NSLdvTankView::addSsObj(NSLdvSousObjet *pSsObj)
{
//	pSsObjetBasketArray->push_back(new NSLdvSousObjet(pSsObj)) ;
  return true;
}


bool
NSLdvTankView::delSsObj(SsObjViewIterator SsObjIter)
{
	pSsObjetTankArray->erase(SsObjIter) ;
	return true;
}


// -----------------------------------------------------------------------------
// M�thodes de NSLdvGoalCycleView
// afichage des objectifs sur la Ligne de Vie
// -----------------------------------------------------------------------------

NSLdvGoalCycleView::NSLdvGoalCycleView(NSContexte *pCtx, NSLdvViewArea *pWorkArea, NSLdvGoal* pGo, NSLigneView *pPbView)
                   :NSLdvTimeToon(pCtx, pWorkArea, true)
{
	pGoal      = pGo ;
	pLigneView = pPbView ;

	/*
	Box.setLeft(pObjet->tDateHeureDebut) ;
	Box.setRight(pObjet->tDateHeureFin) ;

	Box.setTop(pLineView->Box.getTop() - 5) ;
	Box.setBottom(pLineView->Box.getBottom() + 5) ;
	*/

	iZOrder  = LEVEL_BASELINE + RELPRLEVEL_GOAL ;
	toonType = toonGoal ;
}


NSLdvGoalCycleView::NSLdvGoalCycleView(NSLdvGoalCycleView& rv)
                   :NSLdvTimeToon(rv.pContexte, rv._pWorkingArea, rv._bVerticalScrollEnabled)
{
	pGoal      = rv.pGoal ;
	pLigneView = rv.pLigneView ;
}


NSLdvGoalCycleView::~NSLdvGoalCycleView()
{
}

void
NSLdvGoalCycleView::SetupWindow()
{
}

void
NSLdvGoalCycleView::draw(TDC *pDC, NVLdVRect *pRectARepeindre)
{
}

NSLdvGoalCycleView&
NSLdvGoalCycleView::operator=(NSLdvGoalCycleView& src)
{
	if (this == &src)
		return *this ;

	initialiser((NSLdvTimeToon*)(&src)) ;

	return *this ;
}


// --------------------------------------------------------------------------
// ----------------------- METHODES DE ArrayOfToons -------------------------
// --------------------------------------------------------------------------

/*
ArrayOfToons::ArrayOfToons(ArrayOfToons& rv)
	:	ArrayLdvToon()
{
	try
	{
  	if (!(rv.empty()))
    	for (ToonsIter i = rv.begin(); i != rv.end(); i++)
      	push_back(new NSLdvToon(*(*i)));
	}
	catch (const exception& e)
	{
  	string sExept = "Exception " + string(e.what());
    erreur(sExept.c_str(), standardError, 0) ;
	}
	catch (...)
	{
    erreur("Exception.", standardError, 0) ;
	}
}
*/


NSLigneView*
ArrayOfToons::getBaseLine()
{
	if (empty())
		return NULL ;

	for (ToonsIter  toonIter = begin() ; toonIter != end() ; toonIter++)
	{
		NSBaseLineView  *pBLView = TYPESAFE_DOWNCAST(*toonIter, NSBaseLineView) ;
		if (pBLView)
			return ((NSLigneView *) (*toonIter)) ;
	}

	return NULL ;
}


NSLigneView*
ArrayOfToons::getLigneView(string sToon)
{
	if (sToon == "")
		return (getBaseLine()) ;

	if (empty())
		return NULL ;

	NSConcernView *pPbView = getPbView(sToon) ;

	if (pPbView == NULL)
		return (getBaseLine()) ;
	else
		return ((NSLigneView *)(pPbView)) ;
}


NSConcernView*
ArrayOfToons::getPbView(string sToon)
{
	if (sToon == "")
		return NULL ;

	if (empty())
		return NULL ;

	for (ToonsIter  toonIter = begin() ; toonIter!= end() ; toonIter++)
	{
		NSConcernView* pPbView = TYPESAFE_DOWNCAST(*toonIter, NSConcernView);
		if ((pPbView) && (sToon == pPbView->pConcern->sReference))
			return (pPbView) ;
	}

	return NULL ;
}


NSLdvObjetView*
ArrayOfToons::getObjView(string sToon)
{
	if ((empty()) || (string("") == sToon))
		return NULL ;

	for (ToonsIter  toonIter = begin() ; toonIter != end() ; toonIter++)
	{
		NSLdvObjetView  *pObjView = TYPESAFE_DOWNCAST(*toonIter, NSLdvObjetView) ;
		if ((pObjView) && (sToon == pObjView->pObjet->sReference))
			return pObjView ;
	}

	return NULL ;
}


void
ArrayOfToons::init(ArrayObjets* pObj, NSContexte* pCtx, NSLdvViewArea* pWrk)
{
try
{
	if (pObj->empty())
		return ;

	ToonsIter thisIter ;
	for (ArrayObjIter i = pObj->begin(); i != pObj->end(); i++)
	{
		NSLigneView *pLineView = getLigneView((*i)->sConcern) ;

    // If there is no line to plug this object to, then it is not displayed
    //
    if (NULL != pLineView)
    {
		  NSLdvObjetView *pObjView = new NSLdvObjetView(pCtx, pWrk, *i, pLineView) ;
		  push_back(pObjView) ;

		  thisIter = end() ;
		  thisIter-- ;
		  pObjView = (NSLdvObjetView*)(*thisIter) ;
		  pObjView->createComponents(this) ;
    }
	}
}
catch (...)
{
	erreur("Exception ArrayOfToons::init(ArrayObjets).", standardError, 0) ;
	return ;
}
}

void
ArrayOfToons::init(ArraySsObjet* pSsObj, NSContexte* pCtx, NSLdvViewArea* pWrk)
{
try
{
	if (pSsObj->empty())
		return ;

	ToonsIter thisIter ;
	for (ArraySsObjIter i = pSsObj->begin() ; i != pSsObj->end() ; i++)
	{
		NSLdvObjetView  *pObjV  = getObjView((*i)->sObject) ;

    if (NULL != pObjV)
    {
		  NSConcernView *pPbV = getPbView((*i)->sConcern) ;

		  NSSsObjView *pSsObjView = new NSSsObjView(pCtx, pWrk, *i, pObjV, pPbV) ;
		  push_back(pSsObjView) ;

		  thisIter = end() ;
		  thisIter-- ;
		  pSsObjView = (NSSsObjView *)(*thisIter) ;
		  pSsObjView->createComponents(this) ;
    }
	}
}
catch (...)
{
	erreur("Exception ArrayOfToons::init(ArraySsObjet).", standardError, 0) ;
	return;
}
}

void
ArrayOfToons::init(ArrayGoals *pGoals, NSContexte* pCtx, NSLdvViewArea* pWrk)
{
try
{
/*
	if (pGoals->empty())
		return;

    NVLdVTemps tDebut;
    NVLdVTemps tFin;

	ToonsIter   thisIter ;
	for (ArrayGoalIter i = pGoals->begin() ; i != pGoals->end() ; i++)
	{
        NSLdvGoalCycleView *pGoalView = new NSLdvGoalCycleView(pCtx, pView, *i, pObjV, pPbV) ;

        tDebut = (*i)->tDateOuverture;
        //
        // On cherche les �v�nements qui r�initialisent l'objectif
        //
        VecteurString   *pVecteurString = new VecteurString() ;
        pContexte->getGraphe()->TousLesVrais(sNoeud, NSGraphe::goalReseter, pVecteurString) ;
        if (!pVecteurString->empty())
        {
            pGoal->sConcern =  *(*(pVecteurString->begin()));
            EquiItemIter stringIter = pVecteurString->begin();
		    for (; stringIter != pVecteurString->end(); stringIter++)
            {
                string sResetNode = *(*stringIter);

                string sObjReference = string(sResetNode, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN);
	            // Recherche du document qui contient ce noeud
	            // Looking for the document that contains this node
	            NSHISTODocument* pHistory = pDoc->pContexte->getPatient()->pDocHis;

	            if (!(pHistory->VectDocument.empty()))
	            {
	                DocumentIter iterDoc = pHistory->VectDocument.TrouveDocHisto(sObjReference);
	                // Found
	                if ((iterDoc != NULL) && (iterDoc != pHistory->VectDocument.end()))
	                {
                        tFin.initFromDate(string((*iterDoc)->GetDateDoc()));
                        pGoalView->fixeRectangle(tDebut, tFin, 0, 0);
                        push_back(new NSLdvGoalView(*pGoalView)) ;
		                delete pGoalView ;
                    }
	            }
            }
        }
        delete pVecteurString ;

		NSLigneView *pLineView = getLigneView((*i)->sConcern);


		push_back(new NSSsObjView(*pSsObjView)) ;
		delete pSsObjView ;
		thisIter = end() ;
		thisIter-- ;
		pSsObjView = (NSSsObjView *)(*thisIter) ;
		pSsObjView->createComponents(this) ;
	}
    */
}
catch (...)
{
	erreur("Exception ArrayOfToons::init(ArraySsObjet).", standardError, 0) ;
	return;
}
}

void
ArrayOfToons::init(ArrayLdvDrugs *pDrugs, NSContexte* pCtx, NSLdvViewArea* pWrk)
{
try
{
	if (pDrugs->empty())
		return ;

	int iIndex = 0 ;
	for (drugsIter i = pDrugs->begin() ; i != pDrugs->end() ; i++)
	{
  	// Searching the same drug to put it on the same line
    //
    int iRefIndex = -1 ;
    if (!empty())
    	for (ToonsIter iToon = begin(); end() != iToon ; iToon++)
    		if (dynamic_cast<NSDrugLineView*>(*iToon))
    		{
        	NSDrugLineView* pDrugLine = (NSDrugLineView*)(*iToon) ;
          //
          // Check that they are refering to the same drug, and have no time overlap
          //
          if (pDrugLine && pDrugLine->pDrug && (pDrugLine->pDrug->sLexique == (*i)->sLexique) &&
               ((pDrugLine->Box.getLeft() > (*i)->tDateOuverture) ||
                (pDrugLine->Box.getRight() < (*i)->tDateFermeture))
               )
          	iRefIndex = pDrugLine->getIndex() ;
        }

    if (iRefIndex == -1)
    {
    	iRefIndex = iIndex ;
      iIndex++ ;
    }

		NSDrugLineView *pdrugLine = new NSDrugLineView(pCtx, pWrk, *i, iRefIndex) ;
		push_back(pdrugLine) ;
	}
}
catch (...)
{
	erreur("Exception ArrayOfToons::init(ArrayLdvDrugs).", standardError, 0) ;
	return;
}
}

void
ArrayOfToons::reinit(ArrayLdvDrugs *pDrugs, NSContexte* pCtx, NSLdvViewArea* pWrk)
{
	viderType(NSLdvToon::toonDrug) ;

  init(pDrugs, pCtx, pWrk) ;
}

void
ArrayOfToons::init(ArrayConcern* pConcerns, NSContexte* pCtx, NSLdvViewArea* pWrk)
{
try
{
	if (pConcerns->empty())
		return ;

	// ToonsIter thisIter;
	int iIndex = 0 ;

	// Premi�re �tape : cr�er les NSConcernView
	// First step : create all the NSConcernView

  int iSeverityThreshold = -1 ;
  if ((NULL != pWrk) && (NULL != pWrk->getView()))
    iSeverityThreshold = pWrk->getView()->getSeverityThreshold() ;

	for (ArrayConcernIter i = pConcerns->begin(); i != pConcerns->end(); i++)
  {
    if ((*i)->getMaxSeverityIndex() >= iSeverityThreshold)
    {
  	  NSConcernView* pConcernView = new NSConcernView(pCtx, pWrk, *i) ;
		  push_back(pConcernView) ;
    }
  }

	// Deuxi�me �tape : leur attribuer une ligne
	//      Il est obligatoire d'attribuer les lignes apr�s que l'on a cr��
	//      les NSConcernView afin de pouvoir attribuer la m�me ligne aux
	//      pr�occupations cha�n�es
	// Second step : find a line for each one
	//      We have to find the lines after we have created all NSConcernView
	//      in order to put linked health concerns on the same line
	for (ToonsIter toonIt = begin(); toonIt != end(); toonIt++)
	{
		NSConcernView* pConcernView = TYPESAFE_DOWNCAST(*toonIt, NSConcernView);
		if ((pConcernView) && (pConcernView->getIndex() == -1))
    {
      pConcernView->setIndex(pWrk->getLigneProb(pConcernView->pConcern, iIndex)) ;
      if (pConcernView->getIndex() > pWrk->getMaxConcernIndex())
        pWrk->setMaxConcernIndex(pConcernView->getIndex()) ;
    }
	}

	// Troisi�me �tape : cr�er leurs composants
	// Third step : create their components
	for (ToonsIter toonIt = begin(); toonIt != end(); toonIt++)
	{
		NSConcernView* pConcernView = TYPESAFE_DOWNCAST(*toonIt, NSConcernView);
		if (pConcernView)
		{
			pConcernView->boxFitting();
			pConcernView->createComponents(this);
		}
	}

/*
	NSConcernView* pProbView = new NSConcernView(pCtx, pView, *i, 0 iIndex);
	push_back(new NSConcernView(*pProbView));
	delete pProbView;
	thisIter = end();
	thisIter--;
	pProbView = (NSConcernView*)(*thisIter);
	pProbView->createComponents(this);
  iIndex++;
*/
}
catch (...)
{
	erreur("Exception ArrayOfToons::init(ArrayConcern).", standardError, 0) ;
  	return ;
}
}

void
ArrayOfToons::vider()
{
	if (empty())
		return ;

	for (ToonsIter i = begin(); i != end(); )
	{
		delete *i ;
		erase(i) ;
	}
}

void
ArrayOfToons::viderType(NSLdvToon::TOONTYPE toonTypeToKill)
{
	if (empty())
		return ;

	for (ToonsIter i = begin(); i != end(); )
	{
  	if ((*i)->toonType == toonTypeToKill)
    {
			delete *i ;
			erase(i) ;
    }
    else
    	i++ ;
	}
}

ArrayOfToons::~ArrayOfToons()
{
	vider();
}


/*
ArrayOfToons&		ArrayOfToons::operator=(ArrayOfToons src)
{
	try
	{
    vider();

    if (!(src.empty()))
    	for (ToonsIter i = src.begin(); i != src.end(); i++)
      	push_back(new NSLdvToon(*(*i)));
    return *this;
	}
	catch (const exception& e)
	{
    string sExept = "Exception " + string(e.what());
    erreur(sExept.c_str(), standardError, 0) ;
    return *this;
	}
	catch (...)
	{
    erreur("Exception.", standardError, 0) ;
    return *this;
	}
}
*/

ldvBrush::ldvBrush(const NS_CLASSLIB::TColor& color)
{
  ShouldDelete = false;

#if 0
  if (color.IsSysColor())
    Handle = ::GetSysColorBrush(color.Index());
  else
#endif
  {
    COLORREF cr = color;
		/*
		if ((Handle = GetBrushCache().Lookup(cr)) != 0)
			return;
		*/
    Handle = ::CreateSolidBrush(cr);
  }
  WARNX(OwlGDI, !Handle, 0, "Cannot create solid TBrush " << hex << color);
  CheckValid();

  //GetBrushCache().Add(Handle, color);

  // TRACEX(OwlGDI, OWL_CDLEVEL, "TBrush constructed @" << (void*)this <<
  //                            " with color " << (COLORREF)color);
}

