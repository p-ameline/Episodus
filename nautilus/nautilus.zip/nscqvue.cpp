// -----------------------------------------------------------------------------
// NSCQVUE.CPP		Document/Vues Formulaires
// -----------------------------------------------------------------------------

#define __NSCQVUE_CPP
#include <owl\owlpch.h>#include <owl\validate.h>
#include <owl\inputdia.h>
#include <fstream.h>

#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "nautilus\nscqvue.h"
#include "nautilus\nshistdo.h"
#include "nautilus\nsepicap.h"
#include "nsbb\nsbbitem.h"
#include "nsbb\nsbbsmal.h"
#include "nsbb\nsarc.h"
#include "nsbb\nsattval.h"
#include "nsbb\nsdlg.h"
#include "nsbb\nsPaneSplitter.h"
#include "nsbb\nsattvaltools.h"
#include "nsbb\nstrewi.h"
#include "nsbb\nsdico.h"
#include "nsbb\ns_skins.h"
#include "nautilus\nscqdoc.h"

#include "nscompta\nscpta.h"
#include "nscompta\nsfse16.h"
#include "nautilus\nsadmiwd.h"

#include "ns_ob1\nautilus-bbk.h"

// -----------------------------------------------------------------------------
// Classe NSMDIChild
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSMDIChildContent, TWindow)
	EV_WM_SIZE,
  EV_COMMAND(IDC_OK_PANESPLIT,     CmChildOK),
	EV_COMMAND(IDC_HELP_PANESPLIT,   CmChildHelp),
	EV_COMMAND(IDC_CANCEL_PANESPLIT, CmChildCancel),
	EV_COMMAND(CM_HELP,              CmChildHelp),
END_RESPONSE_TABLE;

NSMDIChildContent::NSMDIChildContent(NSContexte* pCtx, TWindow* parent)
                  :TWindow(parent), NSRoot(pCtx)
{
	_pSplitter = NULL ;
	_pToolBar  = NULL ;
}
voidNSMDIChildContent::EvSize(uint sizeType, ClassLib::TSize &size){	TWindow::EvSize(sizeType, size) ;
  if ((NULL == _pToolBar) && (NULL == _pSplitter))
  	return ;

  NS_CLASSLIB::TRect clientRect = GetClientRect() ;

  if (NULL != _pToolBar)
	{
  	int iPanelHeight = _pToolBar->getGadgetsHeight() ;
    if (0 == iPanelHeight)
    	_pSplitter->MoveWindow(clientRect, true) ;
    else
    {
    	NS_CLASSLIB::TRect barRect   = NS_CLASSLIB::TRect(clientRect.Left(), clientRect.Top(), clientRect.Right(), clientRect.Left() + iPanelHeight) ;
      NS_CLASSLIB::TRect splitRect = NS_CLASSLIB::TRect(clientRect.Left(), barRect.Bottom(), clientRect.Right(), clientRect.Bottom()) ;
      _pToolBar->MoveWindow(barRect, true) ;
      _pSplitter->MoveWindow(splitRect, true) ;
    }
  }
  else
  	_pSplitter->MoveWindow(clientRect, true) ;}
void
NSMDIChildContent::CmChildOK()
{
	if (NULL != _pSplitter)
		_pSplitter->CmOk() ;
}

void
NSMDIChildContent::CmChildHelp()
{
	if (NULL != _pSplitter)
		_pSplitter->CmHelp() ;
}

void
NSMDIChildContent::CmChildCancel()
{
	if (NULL != _pSplitter)
		_pSplitter->CmCancel() ;
}

// -----------------------------------------------------------------------------
// Classe NSMDIChild
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSMDIChild, TMDIChild)
	// EV_WM_CLOSE,
	EV_WM_DESTROY,
	EV_WM_SETFOCUS,
	EV_WM_ACTIVATE,
	EV_WM_NCACTIVATE,
	EV_WM_LBUTTONDOWN,
END_RESPONSE_TABLE;


NSMDIChild::NSMDIChild(NSContexte* pCtx, TMDIClient& parent, const char far *title, TWindow *clientWnd, bool shrinkToClient, TModule *module)
           :TMDIChild(parent, title, clientWnd, shrinkToClient, module), NSRoot(pCtx)
{
	bShrinkToClient = shrinkToClient ;
	client          = clientWnd ;
	wndCreatePanel  = NULL ;
	hWndToFocus     = 0 ;
}

NSMDIChild::NSMDIChild(NSContexte* pCtx, HWND hWnd, TModule *module)
           :TMDIChild(hWnd, module), NSRoot(pCtx)
{
	bShrinkToClient = true ;
	wndCreatePanel  = NULL ;
	hWndToFocus     = 0 ;
}

NSMDIChild::~NSMDIChild()
{
	if (wndCreatePanel != NULL)
	{
		NSMUEView* wndCreate = TYPESAFE_DOWNCAST(getCreateWindow(), NSMUEView) ;
		if (wndCreate)
		{
    	NSMDIChildContent* pChildContent = TYPESAFE_DOWNCAST(client, NSMDIChildContent) ;
			if (NULL != pChildContent)
			{
				NSPaneSplitter* pSplitter = pChildContent->getSplitter() ;
				if (NULL != pSplitter)
        {
					pSplitter->closeAllWindows() ;
          return ;
        }
      }
		}
		else
		{
			NSDialog* wndCr = TYPESAFE_DOWNCAST(getCreateWindow(), NSDialog) ;
			if (wndCr)
				wndCr->Desactive() ;
		}
	//  delete wndCreatePanel;
	}
}

void
NSMDIChild::initClient(NSDialog *pDlg)
{
	TFrameWindow::Init(pDlg, bShrinkToClient) ;
}

void
NSMDIChild::initClientArchetype(NSCQWindowsView *pView)
{
  TFrameWindow::Init(pView, bShrinkToClient) ;
}

void
NSMDIChild::split(TWindow * pMaster, TWindow * pSlave, TSplitDirection splitDir, float percent)
{
	NSMDIChildContent* pChildContent = TYPESAFE_DOWNCAST(client, NSMDIChildContent) ;
	if (NULL == pChildContent)
		return ;

	NSPaneSplitter* pSplitter = pChildContent->getSplitter() ;
  if (NULL == pSplitter)
		return ;

	pSplitter->nsSplitPane(pMaster, pSlave, splitDir, percent) ;
}

int MyEnumEachPane(TWindow &p, void*)
{
	ClassLib::TRect rectMother, rectChild ;
	// Trect rectChild;
	// NSMUEView* wndMother;
	TSplitDirection dir ;
	// NSPaneSplitter* pPanelSplitter;
	float percent = 1.0 ;
	// NSSplittingWindowProperty *wndProp = new  NSSplittingWindowProperty();

	NSMUEView* wndChild = TYPESAFE_DOWNCAST(&p, NSMUEView) ;
	if  (wndChild)
	{
		//pour tous les fenetre sauf la premiere qui a fait le MDIChild
		if (wndChild->getSplittedWindow())
		{
			NSMUEView* wndMother = TYPESAFE_DOWNCAST(wndChild->getSplittedWindow(), NSMUEView) ;
			NSPaneSplitter* pPanelSplitter = wndChild->getPaneSplitter() ;
			rectChild = pPanelSplitter->computeMetaRectWindow(wndChild) ;
			rectMother = pPanelSplitter->computeMetaRectWindow(wndMother) ;
			dir = wndChild->getSplitDirection();
			switch (dir)
			{
				case psHorizontal :
					percent = (1.0 - ((float)rectChild.Height())/((float)rectMother.Height() )) ;
					break ;
				case psVertical   :
					percent = (1.0 - ((float)rectChild.Width())/((float)rectMother.Width())) ;
					break ;
				case psNone       :
					percent = 1.0 ;
					break ;
			}

			//wndChild->getCreateWindow() la fenetre qui a cr�� le MDIChild
			NSMUEView* wndCreateChild = TYPESAFE_DOWNCAST(wndChild->getCreateWindow(), NSMUEView) ;
      if (wndCreateChild)
			{
				NSWindowProperty *pWinProp = wndCreateChild->pContexte->getUtilisateur()->aWinProp.getProperty(wndCreateChild->getFunction()) ;
				if ((pWinProp) && (wndMother))
					pWinProp->addSplit(wndMother->getFunction(), wndChild->getFunction(), dir, percent) ;
    	}
		}
		return 1 ;
	}
	else
		return 1 ;
}

void
NSMDIChild::RecordChildPos()
{
	if (!pContexte->getUtilisateur()->bEnregWin)
  	return ;

	NSWindowProperty wndProp ;

	ClassLib::TRect rect = GetWindowRect() ;
	wndProp.setX(rect.left) ;
	wndProp.setY(rect.top) ;
	wndProp.setW(rect.Width()) ;
	wndProp.setH(rect.Height()) ;
  wndProp.setActivity(NSWindowProperty::undefined) ;

	TWindow *pWnd = getCreateWindow() ;
	if (!pWnd)
		return ;


	NSMUEView* wndCreate = TYPESAFE_DOWNCAST(pWnd, NSMUEView) ;
	if (wndCreate)
		wndProp.setFunction(wndCreate->getFunction()) ;
	else
	{
		NSDialog* wndCr = TYPESAFE_DOWNCAST(pWnd, NSDialog) ;
		if (wndCr)
		{
			TWindow* pWV = wndCr->pView ;
			NSMUEView* pGenuineView = TYPESAFE_DOWNCAST(pWV, NSMUEView) ;
			if (pGenuineView)
				wndProp.setFunction(pGenuineView->getFunction()) ;
		}
	}
	//NSWindowProperty *pProp = pContexte->getUtilisateur()->aWinProp.getProperty(wndProp->sFunction) ;
	//  pProp->resetSplitList();

	string sUserId = pContexte->getUtilisateur()->getNss() ;

	pContexte->getUtilisateur()->aWinProp.saveWindowProperty(sUserId, pContexte->PathName("FGLO"), &wndProp, false) ;

	/* NSWindowProperty *pProp = pContexte->getUtilisateur()->aWinProp.getProperty(wndProp->sFunction) ;
	pProp->resetSplitList();   */

  NSMDIChildContent* pChildContent = TYPESAFE_DOWNCAST(client, NSMDIChildContent) ;
	if (NULL != pChildContent)
	{
		NSPaneSplitter* pSplitter = pChildContent->getSplitter() ;
		if (NULL != pSplitter)
			pSplitter->ForEachPane(MyEnumEachPane,(void*) wndCreate) ;
  }

	pContexte->getUtilisateur()->aWinProp.saveWindowProperty(sUserId, pContexte->PathName("FGLO"), &wndProp, true) ;
}

int
NSMDIChild::GetFrameIndex()
{
  return GetDocTitleIndex() ;
}

void
NSMDIChild::PerformCreate(int menuOrId)
{
  TMDIChild::PerformCreate(menuOrId) ;
}

void
NSMDIChild::EvDestroy()
{
  RecordChildPos() ;

   /* NSMUEView* wndCreate = TYPESAFE_DOWNCAST(getCreateWindow(), NSMUEView) ;
    if (wndCreate)
    {
        NSPaneSplitter* pPanelSplitter = wndCreate->getPaneSplitter();
        pPanelSplitter->closeAllWindows();
    }
    else
    {
        NSDialog* wndCr = TYPESAFE_DOWNCAST(getCreateWindow(), NSDialog) ;
        if (wndCr)
          wndCr->Desactive();
    } */
}

void
NSMDIChild::EvSetFocus(THandle hWndLostFocus)
{
	TMDIChild::EvSetFocus(hWndLostFocus) ;

  if ((GetHandle() == hWndLostFocus) || IsChild(hWndLostFocus))
		return ;

  // Les SetFocus viennent de la MDIClient
  // TMDIClient* pMDIClt = pContexte->getSuperviseur()->getApplication()->prendClient() ;
  // if (pMDIClt->GetHandle() == hWndLostFocus)
	// 	return ;

  NSMDIChildContent* pChildContent = TYPESAFE_DOWNCAST(client, NSMDIChildContent) ;
	if (NULL == pChildContent)
		return ;

	NSPaneSplitter* pClientSplit = pChildContent->getSplitter() ;
	if (pClientSplit && !hWndToFocus)
	{
  	NSMUEView* pInitialFocusedView = pClientSplit->pCurrentFocusedView ;

		if (pClientSplit->pCurrentFocusedView)
    	// pClientSplit->pCurrentFocusedView->SetFocus() ;
			pClientSplit->pCurrentFocusedView->EvSetFocus(hWndLostFocus) ;
		else
			pClientSplit->setFocusToNextView(0, hWndLostFocus) ;

		if (pClientSplit->pCurrentFocusedView)
    	hWndToFocus = pClientSplit->pCurrentFocusedView->GetHandle() ;
    else
    	hWndToFocus = 0 ;

  	// Action sp�cifique pour les CQVues
    // Specific action for NSCQVue : set focus to the dialog inside
    // Warning : it may turn around and not allow to select another view
  	if (pClientSplit->pCurrentFocusedView && !pInitialFocusedView)
    {
  		NSCQVue* pCQfocused = dynamic_cast<NSCQVue*>(pClientSplit->pCurrentFocusedView) ;
  		if (pCQfocused && pCQfocused->clientWin)
      	hWndToFocus = pCQfocused->clientWin->GetHandle() ;
      	// HoldFocusHWnd(hWndLostFocus, pCQfocused->clientWin->GetHandle()) ;
      	// if ((pCQfocused->clientWin->GetHandle() != hWndLostFocus) && (!(pCQfocused->clientWin->IsChild(hWndLostFocus))))
				//	 pCQfocused->clientWin->EvSetFocus(hWndLostFocus) ;
		}
	}
  // if (hWndToFocus)
	// 	::SetFocus(hWndToFocus) ;
}

void
NSMDIChild::EvActivate(uint active, bool minimized, HWND hwnd)
{
	TMDIChild::EvActivate(active, minimized, hwnd) ;
}

bool
NSMDIChild::EvNCActivate(bool active)
{
	return TMDIChild::EvNCActivate(active) ;
}

void
NSMDIChild::EvLButtonDown(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TMDIChild::EvLButtonDown(modKeys, point) ;
}

void
NSMDIChild::EvParentNotify(uint event, uint childHandleOrX, uint childIDOrY)
{
	if (event == WM_LBUTTONDOWN)
	{
	}
}

bool
NSMDIChild::SetDocTitle(const char far* docname, int index)
{
	NSMDIChildContent* pChildContent = TYPESAFE_DOWNCAST(client, NSMDIChildContent) ;
	if (NULL == pChildContent)
  {
  	if (docname && (docname[0] != '\0'))
			return TFrameWindow::SetDocTitle(docname, index) ;
    else
			return true ;
  }

	// SetDocTitle puts document's name as view caption
  // If the view has a viewName, it means it does it itself (in SetFocus)
	//
  NSPaneSplitter* pClientSplit = pChildContent->getSplitter() ;
	if (!pClientSplit || !(pClientSplit->pCurrentFocusedView) ||
  		(pClientSplit->pCurrentFocusedView->getViewName() == ""))
	{
    // If document's name exists, we let OWL work
    //
  	if (docname && (docname[0] != '\0'))
			return TFrameWindow::SetDocTitle(docname, index) ;

    // If we have got an Archetype, we paste dialog's title in MDI title
    //
    if (pClientSplit && pClientSplit->pCurrentFocusedView)
		{
			NSCQVue* pCQfocused = dynamic_cast<NSCQVue*>(pClientSplit->pCurrentFocusedView) ;
			if (pCQfocused && pCQfocused->clientWin)
			{
    		char szDialogTitle[256] ;
    		int iLen = pCQfocused->clientWin->GetWindowText(szDialogTitle, 255) ;
      	if (iLen > 0)
    			SetWindowText(szDialogTitle) ;
			}
		}
	}

  return true ;

/*
	if (index >= 0) {
    string title;

    if (Title && *Title) {
      title = Title;
      title += " - ";
    }

    if (docname)
      title += docname;

    if (index > 0) {
      title += ':';
      char num[10];
      itoa(index, num, 10);
      title += num;
    }

    SetWindowText(title.c_str());
  }  // else if index negative, simply acknowledge that title will display

  return true ;
*/
}

//------------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Table de r�ponses de la classe NSCQVue
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSCQWindowsView, NSBBMUEView)
  EV_WM_SETFOCUS,
  EV_WM_CLOSE,
  EV_WM_DESTROY,
  //EV_WM_DESTROY,
  EV_COMMAND(CM_ENREGISTRE, CmEnregistre),
  //EV_COMMAND(CM_IMPRIME, 	  CmPublier),
  //EV_COMMAND(CM_VISUAL, 	  CmVisualiser),
  EV_COMMAND(CM_FILECLOSE,  EvClose),
END_RESPONSE_TABLE ;
NSCQWindowsView::NSCQWindowsView(NSCQDocument& doc, TWindow *parent)
                :NSBBMUEView(doc.pContexte, &doc, parent), pDoc(&doc)
{
  Attr.AccelTable = REFVIEW_ACCEL ;

	NSSuper *pSuper = pContexte->getSuperviseur() ;

	string ps = string("Entr�e dans le constructeur de NSCQVue") ;
	pSuper->trace(&ps, 1) ;

	initMUEViewMenu("menubar") ;

	pToolBar  = 0 ;
	pBigBoss  = 0 ;
	bSetupToolBar = true ;

  bCanClose = true ;
  bOkActivated = false ;

	ps = string("Constructeur de NSCQVue, lancement de l'Archetype : ") + pDoc->sArchetype ;
	pSuper->trace(&ps, 1) ;

	lanceArchetype() ;

  setViewName() ;

  ps = string("Sortie du constructeur de NSCQVue") ;
	pSuper->trace(&ps, 1) ;
}

NSCQWindowsView::~NSCQWindowsView()
{
/*
    if (sFonction != "")
    {
        NS_CLASSLIB::TRect rectDlg = Parent->GetWindowRect() ;//coordonn�es par % � l'�cran
    int X, Y, W, H ;
    NS_CLASSLIB::TPoint point(rectDlg.X(), rectDlg.Y()) ;
    Parent->Parent->ScreenToClient(point) ;
    X = point.X() ;
  	Y = point.Y() ;
    W = rectDlg.Width() ;
    H = rectDlg.Height() ;

        if (Parent->IsIconic())
            return ;

        //string sUserId = string(pContexte->getUtilisateur()->pDonnees->indice) ;
    //NS_CLASSLIB::TRect  rect(X, Y, X + W, Y + H) ;
    //pContexte->getUtilisateur()->aWinProp.setProperty(sUserId, sFonction, rectDlg, pContexte->PathName("FGLO")) ;
  }
*/

  if (pBigBoss)
    delete pBigBoss ;
}

void
NSCQWindowsView::setViewName()
{
	sViewName = "" ;

	if (NULL == pDoc->pDocInfo)
  {
    // Note : on fixe ici le titre du document avec le titre du dialogue
    // si le document est vierge (sinon le titre est fix� par NSNoyauDocument)
    // Il est inutile d'appeler la m�thode SetDocTitle, le TDocument::SetTitle suffit
    // car l'affichage du titre dans la vue est fait par la TMDIChild

    string sLang = "" ;
    if (pContexte->getUtilisateur())
		  sLang = pContexte->getUtilisateur()->donneLang() ;

    // The right place to look is in the "references" block
    //
    Creferences *pRefBlock = pDoc->pParseur->pArchetype->Carchetype::getReference() ;
    if (NULL != pRefBlock)
    {
      Chead *pReferenceHead = pRefBlock->getHead(sLang) ;
      if (NULL != pReferenceHead)
        sViewName = pReferenceHead->getTitle() ;
    }

    // If not found, have a look in the dialog box
    //
    if (string("") == sViewName)
    {
      Cdialogbox* pDialogBox = pDoc->pParseur->pArchetype->getDialogBox(sLang) ;
      if (pDialogBox)
        sViewName = pDialogBox->getCaption() ;
    }

    if (string("") == sViewName)
      sViewName = pContexte->getSuperviseur()->getText("archetypesManagement", "archetype") ;

    addConcernTitle() ;
  }
  else
	{
	}
}

voidNSCQWindowsView::lanceArchetype(){try{  if (pDoc->sArchetype == "")    return ;	// Ici on doit laisser les BBItem "pr�cocher" l'arch�type	// � partir de la patpatho du document et non par le blackboard
	//
	// En mode OB1, le document fixe la variable bInitFromBbk dans pDoc->pKSdescriptor
	//
	pBigBoss = new NSSmallBrother(pContexte, pDoc->pPatPathoArray) ;

  pBigBoss->pFenetreMere = pContexte->GetMainWindow() ;

	bool bSuccess = pBigBoss->lanceBbkArchetypeInView(pDoc->sArchetype, pDoc->pParseur, 0, this, pDoc->pKSdescriptor) ;
  if (false == bSuccess)
    return ;

  pBBItem = pBigBoss->pBBItem ;

  if ((pDoc->pParseur) && (pDoc->pParseur->pArchetype))
    sFonction = pDoc->pParseur->pArchetype->getFunction() ;

	// pPaneSplitter->SetFrameTitle(getFunction(), sViewName) ;
}
catch (...)
{
  erreur("Exception NSCQVue::lanceArchetype.", standardError, 0) ;
}
}

TWindow*
NSCQWindowsView::GetWindow()
{
  return (TWindow *) this ;
}

void
NSCQWindowsView::SetupToolBar()
{
	// Ici pas de barre de boutons sp�cifique :
	// on se contente de virer la barre en cours
	// TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;
	// pMyApp->FlushControlBar() ;

  pPaneSplitter->FlushControlBar() ;

  pPaneSplitter->pGadgetPanelWindow->setButtonsStyle(uButtonsStyle) ;
  pPaneSplitter->pGadgetPanelWindow->insertMainGadgets() ;

/*
  if ((uButtonsStyle & MYWS_OK) == MYWS_OK)
		pPaneSplitter->Insert(*new TButtonGadget(IDC_OK_PANESPLIT,     IDC_OK_PANESPLIT,     TButtonGadget::Command)) ;
	if ((uButtonsStyle & MYWS_CANCEL) == MYWS_CANCEL)
  	pPaneSplitter->Insert(*new TButtonGadget(IDC_CANCEL_PANESPLIT, IDC_CANCEL_PANESPLIT, TButtonGadget::Command)) ;
	if ((uButtonsStyle & MYWS_HELP) == MYWS_HELP)
  	pPaneSplitter->Insert(*new TButtonGadget(IDC_HELP_PANESPLIT,   IDC_HELP_PANESPLIT,   TButtonGadget::Command)) ;
*/

  pPaneSplitter->LayoutSession() ;
}

void
NSCQWindowsView::PerformCreate(int menuOrId)
{
  string ps = string("NSCQVue, entr�e dans PerformCreate") ;
  pContexte->getSuperviseur()->trace(&ps, 1) ;

  if (!pDoc->pDocInfo)
  {
    // Note : on fixe ici le titre du document avec le titre du dialogue
    // si le document est vierge (sinon le titre est fix� par NSNoyauDocument)
    // Il est inutile d'appeler la m�thode SetDocTitle, le TDocument::SetTitle suffit
    // car l'affichage du titre dans la vue est fait par la TMDIChild
    char far szTitle[256] ;
    strcpy(szTitle, "Archetype") ;
    pPaneSplitter->SetFrameTitle(getFunction(), szTitle) ;
    // pDoc->SetTitle(szTitle) ;
  }

  ps = string("NSCQVue, sortie de PerformCreate") ;
  pContexte->getSuperviseur()->trace(&ps, 1) ;

  NSBBMUEView::PerformCreate(menuOrId) ;
}

void
NSCQWindowsView::SetupWindow()
{
  char szThis[20] ;
  sprintf(szThis, "%p", HWindow) ;
  string psHeader = string("NSCQVue ") + string(szThis) + string(" : ") ;
  string ps = psHeader + string("Entering SetupWindow.") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trDetails) ;

  NSBBMUEView::SetupWindow() ;

  SetCaption(sViewName.c_str()) ;

  if (pCreateWindow)
  {
    char szCreate[20] ;
    sprintf(szCreate, "%p", pCreateWindow->HWindow) ;
    ps = psHeader + string("Create Window ") + string(szCreate) ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
  }
  if (pSplittedWindow)
  {
    char szSplitted[20] ;
    sprintf(szSplitted, "%p", pSplittedWindow->HWindow) ;
    ps = psHeader + string("Splitted Window ") + string(szSplitted) ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
  }
  if (pPaneSplitter)
  {
    char szPane[20] ;
    sprintf(szPane, "%p", pPaneSplitter->HWindow) ;
    ps = psHeader + string("PaneSplitter ") + string(szPane) ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

    if (pPaneSplitter->pMDIChild)
    {
      char szMdiChild[20] ;
      sprintf(szMdiChild, "%p", pPaneSplitter->pMDIChild->HWindow) ;
      ps = psHeader + string("PaneSplitter's Child ") + string(szMdiChild) ;
      pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
    }
  }
  if (pGadgetPanelWindow)
  {
    char szGadget[20] ;
    sprintf(szGadget, "%p", pGadgetPanelWindow->HWindow) ;
    ps = psHeader + string("GadgetWindow ") + string(szGadget) ;
    pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
  }

  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  Cdialogbox* pDialogBox = pDoc->pParseur->pArchetype->getDialogBox(sLang) ;
	if (pDialogBox)
    dlgRect = getWindowRectFromDialogRect(pDialogBox->getX(),
                                          pDialogBox->getY(),
                                          pDialogBox->getW(),
                                          pDialogBox->getH()) ;

  //pDoc->SetTitle(sTitle.c_str()) ;
  //SetDocTitle(sTitle.c_str(), 0) ;
  ps = string("NSCQVue ") + string(szThis) + string(", leaving SetupWindow.") ;
  pContexte->getSuperviseur()->trace(&ps, 1) ;
}

void
NSCQWindowsView::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectangleAPeindre)
{
  int iAncDC = dc.SaveDC() ;

  NS_CLASSLIB::TColor archetypeBackgroundColor ;
  nsSkin* pArchetypeSkin = pContexte->getSkins()->donneSkin("Archetype") ;
	if (pArchetypeSkin && pArchetypeSkin->getBackColor())
  	archetypeBackgroundColor = *(pArchetypeSkin->getBackColor()) ;
  else
  	archetypeBackgroundColor = NS_CLASSLIB::TColor(240, 255, 240) ;

  OWL::TBrush Pinceau(archetypeBackgroundColor) ;

  dc.FillRect(RectangleAPeindre, Pinceau) ;

  dc.RestoreDC(iAncDC) ;

  NSBBMUEView::Paint(dc, false, RectangleAPeindre) ;
}

void
NSCQWindowsView::EvSetFocus(THandle hWndLostFocus)
{
	activateMUEViewMenu() ;

	TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;

	if (bSetupToolBar && (GetWindow() != pMyApp->GetToolBarWindow()))
	{
		SetupToolBar() ;
		pMyApp->SetToolBarWindow(GetWindow()) ;
	}

	NSMUEView::EvSetFocus(hWndLostFocus) ;
  pPaneSplitter->SetFrameTitle(getFunction(), sViewName) ;
}

void
NSCQWindowsView::EvClose()
{
	if (NSCQDocument::dpio == pDoc->iTypeDoc)
	{
		NSDPIO *pDPIO = pContexte->getSuperviseur()->getDPIO() ;
		if (pDPIO)
			pDPIO->fermeFormulaire((TWindow*) GetParent()) ;
	}
}

void
NSCQWindowsView::CmOk()
{
  // If Ok already activated, do nothing
  //
  if (bOkActivated)
    return ;

  if ((NULL == pBigBoss) || (NULL == pBBItem))
    return ;

  bOkActivated = true ;

  if (false == CanSave())
  {
    bCanClose = false ;
    bOkActivated = false ;
    return ;
  }

  executePreClosingFunctions() ;

  bool bRootArchetype = false ;
  if (pBBItem->ouvreArchetype())
  	bRootArchetype = true ;

  //
  // D�clenchement du calcul
  //
  if (bRootArchetype)
  {
  	CmBbkCalcul() ;

    // Form there on, the process is asynchronous, waiting for a KS to answer.
    // Once this KS has answered (or the process has been canceled),
    // CmOkFinalStep() is called
    //
    if (_bWaitingForKsAnswer)
      return ;
  }

  // If we are there, it means that no KS is involved, and that the application
  // is waiting for this user iterface's results.
  //
  if (false == pBBItem->okFermerDialogue(true, false /* bDetacheCtrls */))
  {
    bOkActivated = false ;
  	return ;
  }
  pBigBoss->MetTitre() ;

  executeClosingFunctions() ;

  _bWaitingForSystemAction = true ;
  pBBItem->pBigBoss->fermeBbkArchetype(IDOK, this) ;
}

void
NSCQWindowsView::CmOkFinalStep()
{
  // Update BigBoss's patpatho
  //
  if (false == pBBItem->okFermerDialogue(true, false /* bDetacheCtrls */))
  {
    bOkActivated = false ;
  	return ;
  }
  pBigBoss->MetTitre() ;

  executeClosingFunctions() ;

  if (pDoc->enregistre(false, false))
    pPaneSplitter->youCanCloseNow() ;
  else
    bOkActivated = false ;
}

void
NSCQWindowsView::CmCancel()
{
}

void
NSCQWindowsView::EvDestroy()
{
  //if (sFonction != "")
    //NSMUEView::RecordWindowPosit() ;

  if (NSCQDocument::dpio == pDoc->iTypeDoc)
	{
    if ((NULL != pPaneSplitter) && (NULL != pPaneSplitter->pMDIChild))
    {
      NSSuper *pSuper = pContexte->getSuperviseur() ;
      TWindow *pWinPtr = (TWindow *) pPaneSplitter->pMDIChild ;
      NSToDoTask* pTask = new NSToDoTask ;
      pTask->sWhatToDo = string("FermeDPIO") ;
      pTask->pPointer1 = (void*) pWinPtr ;

      pSuper->addToDo(pTask) ;
    }
  }
}

// -----------------------------------------------------------------------------// Document notifications// -----------------------------------------------------------------------------

bool
NSCQWindowsView::CanClose()
{
  if (false == bCanClose)
  {
    bCanClose = true ;
    return false ;
  }

  if ((true == _bWaitingForKsAnswer) || (true == _bWaitingForSystemAction))
    return false ;

  if (NULL == pContexte->getPatient())
    return true ;

  NSPatPathoArray PPt(pContexte) ;
  PPt = *(pDoc->pPatPathoArray) ;

  if (false == pBBItem->okFermerDialogue(true, false /* bDetacheCtrls */))
    return true ;

  TMyApp *pMyApp = pDoc->pContexte->getSuperviseur()->getApplication() ;

  if (false == PPt.estEgal(pDoc->pPatPathoArray))
  {
    int retVal ;

    char message[255] ;
    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    if (pDoc->pDocInfo)
    {
      sprintf(message, "Voulez-vous sauvegarder les modifications du document %s ?", pDoc->GetTitle()) ;
      retVal = MessageBox(message, sCaption.c_str(), MB_YESNOCANCEL) ;
    }
    else
    {
      sprintf(message, "Voulez-vous sauvegarder le document %s ?", pDoc->GetTitle()) ;
      retVal = MessageBox(message, sCaption.c_str(), MB_YESNOCANCEL) ;
    }

    if (IDCANCEL == retVal)
      return false ;
    if (IDYES == retVal)
    {
      if (false == pBBItem->okFermerDialogue(true, false /* bDetacheCtrls */))
        return false ;

      CmEnregistre() ;
      pMyApp->FlushControlBar() ;
      bSetupToolBar = false ;
      return true ;
    }
  }
  pDoc->SetDirty(false) ;
  pMyApp->FlushControlBar() ;
  bSetupToolBar = false ;

  return true ;
}

void
NSCQWindowsView::CmPublier()
{
}

void
NSCQWindowsView::CmVisualiser()
{
}

void
NSCQWindowsView::CmEnregistre()
{
  if ((NULL == pBigBoss) || (NULL == pBigBoss->pBBItem))
    return ;

  if (false == CanSave())
    return ;

  // Update BigBoss's patpatho
  //
  if (false == pBBItem->okFermerDialogue(true, false /* bDetacheCtrls */))
  	return ;
  pBigBoss->MetTitre() ;

  bool bNewDoc = false ;
  if (pDoc->pDocInfo == 0)
    bNewDoc = true ;

  if (pDoc->enregistre())
  {
    pDoc->SetDirty(false) ;

    if (bNewDoc && (pContexte->getSuperviseur()->isComptaAuto()) && (pDoc->ComptaAuto()))
    {
      string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
      int retVal = MessageBox("Il n'existe pas de fiche comptable pour ce document. Voulez-vous lancer la comptabilit� ?", sCaption.c_str(), MB_YESNO) ;
      if (IDYES == retVal)
        Compta() ;
    }
  }
  else
    pDoc->SetDirty(true) ;
}

void
NSCQWindowsView::CmFileClose()
{
}

// -----------------------------------------------------------------------------
// Appel automatique d'une fiche Compt � partir d'une consultation
// -----------------------------------------------------------------------------
void
NSCQWindowsView::Compta()
{
try
{
	if (pDoc->pPatPathoArray->empty())
	{
    erreur("Vous devez enregistrer le document avant de le comptabiliser.", warningError, 0, GetHandle()) ;
    return ;
  }

  string			  sCode = "", sExam = "", sSyn = "" ;
  string 			  sLibelleDoc = "", sDateDoc = "", sExtHosp = "" ;
  NSComptInfo   ComptInfo ;
  NSFse1610Info Fse1610Info ;

  if (!pDoc->pBigBoss)
    pDoc->pBigBoss = new NSSmallBrother(pContexte, pDoc->pPatPathoArray) ;

  // date de l'examen
  PatPathoIter iterPpt = pDoc->pPatPathoArray->begin() ;
  iterPpt++ ;
  if (iterPpt != pDoc->pPatPathoArray->end())
  	if ((*iterPpt)->getLexiqueSens(pContexte) == "KCHIR")
    	pDoc->pPatPathoArray->CheminDansPatpatho(0, "KCHIR", &sDateDoc) ;

	if (sDateDoc == "")
  	pDoc->pPatPathoArray->CheminDansPatpatho(pDoc->pBigBoss, "LADMI/KCHIR", &sDateDoc) ;

  if (sDateDoc == "")
  {
    if (pDoc->pDocInfo) // on prend la date de cr�ation (heure = 0)
    	sDateDoc = pDoc->pDocInfo->getCreDate() ;
    else // on prend la date et l'heure du jour
    {
    	NVLdVTemps tpsNow ;
    	tpsNow.takeTime() ;
    	sDateDoc = tpsNow.donneDate() ;
    }
  }

  string sDate = string(sDateDoc, 0, 8) ;
	string sHeure = string("0000") ;
	if (strlen(sDateDoc.c_str()) >= 12)
		sHeure = string(sDateDoc, 8, 4) ;

	strcpy(ComptInfo.pDonnees->date, sDate.c_str()) ;
	strcpy(ComptInfo.pDonnees->heure, sHeure.c_str()) ;
  // on cale la date de la Fse1610 sur celle de la fiche Compt
	strcpy(Fse1610Info.pDonnees->date, ComptInfo.pDonnees->date) ;
	strcat(Fse1610Info.pDonnees->date, ComptInfo.pDonnees->heure) ;

  // Externe / Hospitalis�
  pDoc->pPatPathoArray->CheminDansPatpatho(pDoc->pBigBoss, "LADMI/LCONT", &sExtHosp) ;
  if (sExtHosp != "")
    sExtHosp = string(sExtHosp, 0, 5) ;

  sCode = (*(pDoc->pPatPathoArray->begin()))->pDonnees->lexique ;
  if (sCode != "")
  {
    sExam = string(sCode, 0, 5) ;
    sSyn = string(sCode, 5, 1) ;
  }

  strcpy(ComptInfo.pDonnees->examen, sExam.c_str()) ;
  strcpy(ComptInfo.pDonnees->synonyme, sSyn.c_str()) ;
  strcpy(ComptInfo.pDonnees->contexte, sExtHosp.c_str()) ;

  NSPersonInfo personInfo(pContexte, pContexte->getPatient()->getNss()) ;

  // NSComptaPatient *pCompta = new NSComptaPatient(NSTreeWindow::pContexte, (NSPatInfo *) NSTreeWindow::pContexte->getPatient()) ;
  NSComptaPatient Compta(pContexte, &personInfo) ;
  Compta.CmFicheCompt(&ComptInfo, &Fse1610Info) ;
}
catch (...)
{
	erreur("Exception NSCQWindowsView::Compta", standardError, 0) ;
}
}

/*
bool
NSCQWindowsView::PreProcessMsg(MSG &msg)
{
  PreProcessMsg(msg) ;
  return true ;
}
*/

// -----------------------------------------------------------------------------
// Table de r�ponses de la classe NSCQVue
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE2(NSCQVue, TView, TWindow)
  EV_WM_SETFOCUS,
  EV_WM_CLOSE,
  EV_WM_DESTROY,
  //EV_WM_DESTROY,
  EV_COMMAND(CM_ENREGISTRE, CmEnregistre),
  //EV_COMMAND(CM_IMPRIME, 	  CmPublier),
  //EV_COMMAND(CM_VISUAL, 	  CmVisualiser),
  EV_COMMAND(CM_FILECLOSE,  EvClose),
END_RESPONSE_TABLE ;
NSCQVue::NSCQVue(NSCQDocument& doc, TWindow *parent)
        :NSMUEView(doc.pContexte, &doc, parent), pDoc(&doc)
{
	NSSuper *pSuper = pContexte->getSuperviseur() ;

	string ps = string("Entr�e dans le constructeur de NSCQVue") ;
	pSuper->trace(&ps, 1) ;

	initMUEViewMenu("menubar") ;

	pToolBar  = 0 ;
	pBigBoss  = 0 ;
	clientWin = 0 ;
	bSetupToolBar = true ;

	ps = string("Constructeur de NSCQVue, lancement de l'Archetype : ") + pDoc->sArchetype ;
	pSuper->trace(&ps, 1) ;
	lanceArchetype() ;
	ps = string("Sortie du constructeur de NSCQVue") ;
	pSuper->trace(&ps, 1) ;

  setViewName() ;
}

NSCQVue::~NSCQVue()
{
/*
    if (sFonction != "")
    {
        NS_CLASSLIB::TRect rectDlg = Parent->GetWindowRect() ;//coordonn�es par % � l'�cran
    int X, Y, W, H ;
    NS_CLASSLIB::TPoint point(rectDlg.X(), rectDlg.Y()) ;
    Parent->Parent->ScreenToClient(point) ;
    X = point.X() ;
  	Y = point.Y() ;
    W = rectDlg.Width() ;
    H = rectDlg.Height() ;

        if (Parent->IsIconic())
            return ;

        //string sUserId = string(pContexte->getUtilisateur()->pDonnees->indice) ;
    //NS_CLASSLIB::TRect  rect(X, Y, X + W, Y + H) ;
    //pContexte->getUtilisateur()->aWinProp.setProperty(sUserId, sFonction, rectDlg, pContexte->PathName("FGLO")) ;
  }
*/

  if (NULL != pDialog)
    delete pDialog ;

  if (pBigBoss)
    delete pBigBoss ;
}

void
NSCQVue::setViewName()
{
	sViewName = "" ;

	if (!pDoc->pDocInfo)
  {
    // Note : on fixe ici le titre du document avec le titre du dialogue
    // si le document est vierge (sinon le titre est fix� par NSNoyauDocument)
    // Il est inutile d'appeler la m�thode SetDocTitle, le TDocument::SetTitle suffit
    // car l'affichage du titre dans la vue est fait par la TMDIChild
    char far szTitle[256] ;
    int res = clientWin->GetWindowText(szTitle, 255) ;
    if (!res)
		{
    	sViewName = pContexte->getSuperviseur()->getText("archetypesManagement", "archetype") ;
			addConcernTitle() ;
		}
    else
    	sViewName = string(szTitle) ;
  }
  else
	{
	}
}

voidNSCQVue::lanceArchetype(){try{  if (pDoc->sArchetype == "")    return ;	// Ici on doit laisser les BBItem "pr�cocher" l'arch�type	// � partir de la patpatho du document et non par le blackboard
	//
	// En mode OB1, le document fixe la variable bInitFromBbk dans pDoc->pKSdescriptor
	//
	pBigBoss = new NSSmallBrother(pContexte, pDoc->pPatPathoArray) ;

  pBigBoss->pFenetreMere = pContexte->GetMainWindow() ;

	// clientWin = pBigBoss->lanceBbkArchetypeInView(pDoc->sArchetype, pDoc->pParseur, 0, pDoc->pKSdescriptor, false, (TWindow*)this) ;
  // if (!clientWin)
  //  return ;

  pDialog = clientWin;
  pDialog->bMereMUEView = true;

  clientWin->pView = this ;
  clientWin->GetWindowRect(dlgRect);

  if ((pDoc->pParseur) && (pDoc->pParseur->pArchetype))
    sFonction = pDoc->pParseur->pArchetype->getFunction() ;

	// pPaneSplitter->SetFrameTitle(getFunction(), sViewName) ;
}
catch (...)
{
  erreur("Exception NSCQVue::lanceArchetype.", standardError, 0) ;
}
}
TWindow
*NSCQVue::GetWindow()
{
  return (TWindow *) this ;
}


void
NSCQVue::SetupToolBar()
{
	// Ici pas de barre de boutons sp�cifique :
	// on se contente de virer la barre en cours
	// TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;
	// pMyApp->FlushControlBar() ;

  pPaneSplitter->FlushControlBar() ;

  if ((uButtonsStyle & MYWS_OK) == MYWS_OK)
		pPaneSplitter->Insert(*new TButtonGadget(IDC_OK_PANESPLIT,     IDC_OK_PANESPLIT,     TButtonGadget::Command)) ;
	if ((uButtonsStyle & MYWS_CANCEL) == MYWS_CANCEL)
  	pPaneSplitter->Insert(*new TButtonGadget(IDC_CANCEL_PANESPLIT, IDC_CANCEL_PANESPLIT, TButtonGadget::Command)) ;
	if ((uButtonsStyle & MYWS_HELP) == MYWS_HELP)
  	pPaneSplitter->Insert(*new TButtonGadget(IDC_HELP_PANESPLIT,   IDC_HELP_PANESPLIT,   TButtonGadget::Command)) ;
}


void
NSCQVue::PerformCreate(int menuOrId)
{
  string ps = string("NSCQVue, entr�e dans PerformCreate") ;
  pContexte->getSuperviseur()->trace(&ps, 1) ;

  char far szTitle[256] ;

  SetHandle(clientWin->GetHandle()) ;
  clientWin->GetWindowRect(dlgRect) ;

  clientWin->pView = (TWindowView *) this ;

  if (!pDoc->pDocInfo)
  {
    // Note : on fixe ici le titre du document avec le titre du dialogue
    // si le document est vierge (sinon le titre est fix� par NSNoyauDocument)
    // Il est inutile d'appeler la m�thode SetDocTitle, le TDocument::SetTitle suffit
    // car l'affichage du titre dans la vue est fait par la TMDIChild
    int res = clientWin->GetWindowText(szTitle, 255) ;
    if (!res)
      strcpy(szTitle, "Archetype") ;
    else
    	pPaneSplitter->SetFrameTitle(getFunction(), szTitle) ;
    // pDoc->SetTitle(szTitle) ;
  }

  ps = string("NSCQVue, sortie de PerformCreate") ;
  pContexte->getSuperviseur()->trace(&ps, 1) ;
}


void
NSCQVue::SetupWindow()
{
  string ps = string("NSCQVue, entr�e dans SetupWindow") ;
  pContexte->getSuperviseur()->trace(&ps, 1) ;

  TWindow::SetupWindow() ;

  //pDoc->SetTitle(sTitle.c_str()) ;
  //SetDocTitle(sTitle.c_str(), 0) ;
  ps = string("NSCQVue, sortie de SetupWindow") ;
  pContexte->getSuperviseur()->trace(&ps, 1) ;
}

void
NSCQVue::EvSetFocus(THandle hWndLostFocus)
{
	activateMUEViewMenu() ;

	TMyApp* pMyApp = pContexte->getSuperviseur()->getApplication() ;

	if (bSetupToolBar && (GetWindow() != pMyApp->GetToolBarWindow()))
	{
		SetupToolBar() ;
		pMyApp->SetToolBarWindow(GetWindow()) ;
	}

	NSMUEView::EvSetFocus(hWndLostFocus) ;
  pPaneSplitter->SetFrameTitle(getFunction(), sViewName) ;

  if (clientWin)
		clientWin->EvSetFocus(hWndLostFocus) ;
}

void
NSCQVue::EvClose()
{
	if (NSCQDocument::dpio == pDoc->iTypeDoc)
	{
		NSDPIO *pDPIO = pContexte->getSuperviseur()->getDPIO() ;
		if (pDPIO)
			pDPIO->fermeFormulaire((TWindow*) GetParent()) ;
	}
}

void
NSCQVue::CmOk()
{
  clientWin->CmOk() ;
}

void
NSCQVue::EvDestroy()
{
  //if (sFonction != "")
    //NSMUEView::RecordWindowPosit() ;
}

// -----------------------------------------------------------------------------
// Document notifications// -----------------------------------------------------------------------------
bool
NSCQVue::CanClose()
{
  return true ;
}


void
NSCQVue::CmPublier()
{
}


void
NSCQVue::CmVisualiser()
{
}


void
NSCQVue::CmEnregistre()
{
}


void
NSCQVue::CmFileClose()
{
}


bool
NSCQVue::PreProcessMsg(MSG &msg)
{
    clientWin->PreProcessMsg(msg) ;
    return true ;
}

// -----------------------------------------------------------------------------
// fin de nscqvue.cpp
// -----------------------------------------------------------------------------

