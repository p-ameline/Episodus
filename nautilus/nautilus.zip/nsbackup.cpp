// -----------------------------------------------------------------------------
// nsbackup.cpp
// -----------------------------------------------------------------------------
// $Revision: 1.2 $
// $Author: philippe $
// $Date: 2003/09/08 06:50:15 $
// -----------------------------------------------------------------------------
// FLP - aout 2003
// -----------------------------------------------------------------------------

#include <stdio.h>
#include <fstream.h>
#include <process.h>

#include "nautilus\nsbackup.h"
#include "partage\nsdivfct.h"    // fonction erreur
#include "nsepisod\nsldvuti.h"

bool    nsbackup()
{
  ifstream    inFile ;
	string      line ;
	string      sData       = "" ;
//  int         iLineNumber = 0 ;
  string      sFileName   = string("backup.dat") ;

  // on ouvre le fichier de configuration
  inFile.open(sFileName.c_str()) ;
  if (!inFile)
  {
    erreur("impossible d'ouvrir le fichier backup.dat", standardError, 0) ;
    return false ;
  }

  // on lit les param�tres de backup
	while (!inFile.eof())
	{
		getline(inFile, line) ;
    sData += line + "\n" ;
	}

  inFile.close() ;

  size_t      i           = 0 ;
  string      sNomAttrib  = "" ;
  string      sValAttrib  = "" ;
  string      sCmdLine    = "" ;
  int         iInterval   = 0 ;
  bool        bLastSave   = true ;
  bool        bInterval   = true ;
  NVLdVTemps  tLastSave ;
  NVLdVTemps  tNextSave ;

	while (i < strlen(sData.c_str()))
	{
		sNomAttrib = "" ;
		sValAttrib = "";

		while ((i < strlen(sData.c_str())) && (sData[i] != ' ') && (sData[i] != '\t'))
			sNomAttrib += pseumaj(sData[i++]) ;
		while ((i < strlen(sData.c_str())) && ((sData[i] == ' ') || (sData[i] == '\t')))
			i++ ;

		while ((i < strlen(sData.c_str())) && (sData[i] != '\n'))
			sValAttrib += sData[i++] ;

		i++ ;

		if 		((sNomAttrib == "CMD_LINE") && (sValAttrib != ""))
      sCmdLine = sValAttrib ;
		else if ((sNomAttrib == "LAST_SAVE") && (sValAttrib != ""))
		{
			for (size_t j = 0 ; j < strlen(sValAttrib.c_str()) ; j++)
				sValAttrib[j] = pseumaj(sValAttrib[j]) ;

			if ((sValAttrib == string("NEVER")) || (sValAttrib == string("JAMAIS")))
				bLastSave = false ;
      else
        tLastSave.initFromDateHeure(sValAttrib) ;
		}
		else if ((sNomAttrib == "INTERVAL_DAYS") && (sValAttrib != ""))
		{
			for (size_t j = 0 ; j < strlen(sValAttrib.c_str()) ; j++)
				sValAttrib[j] = pseumaj(sValAttrib[j]) ;

			if ((sValAttrib == string("NEVER")) || (sValAttrib == string("JAMAIS")))
				bInterval = false ;
      else
      {
        tNextSave = tLastSave ;
        iInterval = atoi(sValAttrib.c_str()) ;
        tNextSave.ajouteJours(iInterval) ;
      }
		}
	}

  NVLdVTemps  tNow ;
  tNow.takeTime() ;
  if (bInterval && (!bLastSave || tNextSave < tNow))
  {
    // calcul du nombre de jours depuis la derni�re sauvegarde
    // ouverture de la boite de dialogue
    char  pcCaption[128] ;
    if (bLastSave)
    {
      unsigned long iDays = tNow.daysBetween(tLastSave) + 1 ;
      sprintf(pcCaption, "La sauvegarde n'a pas �t� faite depuis %d jours. Voulez-vous la faire maintenant ?", iDays) ;
    }
    else
      sprintf(pcCaption, "La sauvegarde n'a jamais �t� faite ! Voulez-vous la faire maintenant ?") ;
    int iRetVal = MessageBox(0, pcCaption, "Sauvegarde", MB_YESNO) ;

    if (iRetVal == IDYES)
    {
      // exc�cution
      int iExecError = WinExec(sCmdLine.c_str(), SW_SHOWNORMAL) ;
      if (iExecError > 31)
      {
        // on doit remplacer la date de la derni�re sauvegarde dans le fichier backup.dat
        ofstream  outFile ;
        outFile.open(sFileName.c_str(), ios::out) ;
        char    outLine[1024] ;
        sprintf(outLine, "CMD_LINE %s\nLAST_SAVE %s\nINTERVAL_DAYS %d\n", sCmdLine.c_str(), tNow.donneDateHeure().c_str(), iInterval) ;
        outFile.write(outLine, strlen(outLine)) ;
        outFile.close() ;
        return true ;
      }
      else
      {
        switch (iExecError)
        {
          case 0                    : erreur("The system is out of memory or resources.", standardError, 0) ;
                                      break ;
          case ERROR_BAD_FORMAT     : erreur("The .EXE file is invalid (non-Win32 .EXE or error in .EXE image).", standardError, 0) ;
                                      break ;
          case ERROR_FILE_NOT_FOUND : erreur("The specified file was not found.", standardError, 0) ;
                                      break ;
          case ERROR_PATH_NOT_FOUND : erreur("The specified path was not found.", standardError, 0) ;
                                      break ;
          default                   : erreur("erreur inconnue lors de l'ex�cution de la sauvegarde.", standardError, 0) ;
        }
        return false ;
      }
    }
  }
  return true ;
}


