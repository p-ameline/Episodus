// -----------------------------------------------------------------------------
// nsprocessview.cpp
// -----------------------------------------------------------------------------
// $Revision: 1.30 $
// $Author: pameline $
// $Date: 2005/06/30 16:27:23 $
// -----------------------------------------------------------------------------
// gestion des process
// -----------------------------------------------------------------------------
// FLP - aout 2003
// -----------------------------------------------------------------------------

#include "nautilus\nsprocessview.h"
#include "nautilus\nsldvvar.h"
#include "nsbb\nspanesplitter.h"
#include "nautilus\nsldvgoal.h"
#include "nautilus\nshistdo.h"
#include "nssavoir\nsgraphe.h"
#include "nsbb\nsattvaltools.h"
#include "nsbb\nsbbsmal.h"

// -----------------------------------------------------------------------------
//
// Class NSProcessView
//
// -----------------------------------------------------------------------------

const int ID_ProcessList = 0x100 ;

// Table de r�ponses de la classe NSProcessView
DEFINE_RESPONSE_TABLE1(NSProcessView, NSMUEView)
  EV_VN_ISWINDOW,
  EV_LVN_GETDISPINFO(ID_ProcessList,  DispInfoListe),
  EV_WM_SIZE,
  EV_WM_SETFOCUS,
  EV_COMMAND(CM_PROCESS_NEW,          CmNouveau),
  EV_COMMAND(CM_PROCESS_STEP,         CmEtape),
  EV_COMMAND(CM_PROCESS_CHANGE,       CmModifier),
  EV_COMMAND(CM_PROCESS_STOP,         CmArreter),
//  EV_COMMAND(IDC_ORDONNANCE,          CmOrdonnance),
END_RESPONSE_TABLE;


// Constructeur
NSProcessView::NSProcessView(NSLdvDocument &doc, string sConcern)
  : NSMUEView(doc.pContexte, &doc, 0, string("ProcessManagement"), string("LdvDoc"), sConcern),
    aCurrentProcesses(&doc)
{
  pLdVDoc = &doc;
  pListeWindow = new NSProcessesPropertyWindow(this, ID_ProcessList, 0, 0, 0, 0);

	initMUEViewMenu("menubar_process") ;

  pToolBar = 0 ;
  bSetupToolBar = true ;

  // Initialisation des prescriptions en cours
  initCurentProcesses() ;

  setViewName() ;
}


// Destructeur
NSProcessView::~NSProcessView()
{
}


void
NSProcessView::setViewName()
{
	sViewName = pContexte->getSuperviseur()->getText("processManagement", "processViewTitle") ;

  addConcernTitle() ;
}


// GetWindow renvoie this (� red�finir car virtual dans TView)
TWindow
*NSProcessView::GetWindow()
{
  return (TWindow *) this ;
}


// Appel de la fonction de remplissage de la vuevoid
NSProcessView::SetupWindow()
{
  NSMUEView::SetupWindow() ;

  string sName = "Proc�dures en cours" ;

    if (sPreoccup != "")
    {
        ArrayConcern* pConcernArray = pLdVDoc->getConcerns() ;
        if (pConcernArray)
        {
            NSConcern* pConcern = pConcernArray->getConcern(sPreoccup) ;
            if (pConcern)
            {
                sName += string(" - ") + pConcern->sTitre;
            }
        }
    }

    Parent->SetCaption(sName.c_str()) ;

  SetupColumns() ;
  AfficheListe() ;
}


void
NSProcessView::CmNouveau()
{
	if (!(pContexte->userHasPrivilege(NSContexte::createProcess, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

	string sChoixProcess ;

	NSNewTrt  *pNewTrtDlg = new NSNewTrt(this, &sChoixProcess, sPreoccup, pContexte, "GDMEX1", "Type de proc�dure") ;

	if (pNewTrtDlg->Execute() == IDCANCEL)
		return ;

  	// on v�rifie qu'on a r�cup�r� un code lexique
	if (sChoixProcess == "")
    	return ;

	// anciennement dans NSNewTrt
	NSPatPathoArray *pPPT     = new NSPatPathoArray(pContexte) ;
#ifdef __OB1__
	NSSmallBrother  *pBigBoss = new NSSmallBrother(pContexte, pPPT, 0) ;
#else
	NSSmallBrother  *pBigBoss = new NSSmallBrother(pContexte, pPPT, 0, false /* initFromBbk */) ;
#endif
	pBigBoss->pFenetreMere    = pContexte->GetMainWindow() ;

	pBigBoss->lance12("GDMEX1", sChoixProcess) ;

	delete pBigBoss ;

	if (pPPT->empty())
	{
    	delete pPPT ;
    	return ;
	}

  	// on cr�� un document proc�dure
 	NSRefDocument *pDocNewProcess = new NSRefDocument(0, 0, 0, pContexte, false) ;
	*(pDocNewProcess->pPatPathoArray) = *pPPT ;

	// on r�f�rence le document proc�dure
	string  sTitleProcess ;
	if (sChoixProcess != string("�?????"))
		pContexte->getDico()->donneLibelle(pContexte->getUtilisateur()->donneLang(), &sChoixProcess, &sTitleProcess) ;
	if (!pDocNewProcess->Referencer("ZCQ00", string("Demande de " + sTitleProcess), "", "", true, true))
		erreur("proc�dure non r�f�renc�e", standardError, 0) ;

	pDocNewProcess->enregistrePatPatho() ;

	string sDocRoot = pContexte->getPatient()->getNss() + LocalPatient  + string("00000") ;

	// une fois qu'on a s�lectionn� notre prescription, on doit cr�er un lien "en
	// attente" entre le noeud patient racine et la prescription
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	pGraphe->etablirLien(sDocRoot, NSRootLink::processWaitingFor, (*pDocNewProcess->pDocInfo->pMeta->begin())->getNode()) ;

	pDocNewProcess->NSNoyauDocument::chargePatPatho() ;
	pContexte->getPatient()->pDocHis->Rafraichir(pDocNewProcess->pDocInfo, pDocNewProcess->pPatPathoArray) ;

	// si on traite les proc�dures au niveau des pr�occupations de la LdV, il faut faire un lien avec la pr�occupation
	if (sPreoccup != "")
    	pGraphe->etablirLien((*pDocNewProcess->pDocInfo->pMeta->begin())->getNode(), NSRootLink::problemRelatedTo, sPreoccup) ;

	delete pDocNewProcess ;
	delete pPPT ;

	displayChanges() ;
}


void
NSProcessView::CmEtape()
{
  // un process peut �tre dans un �tat o� il a des r�sultats partiels
  // voir comment l'on g�re ce cas avec les liens
  // NB : un process est une prescription (d'un examen, d'une analyse, ...) qui
  // est en attente de r�sultat
  // comment faire si un r�sultat est pr�sent mais qu'il n'est pas complet ?
  // plusieurs solutions :  * cr�er un nouveau type de liens
  //                        * garder le lien en attente, mais cr�er quand m�me
  //                          un lien r�sultat vers le r�sultat partiel
  // deuxi�me solution semble plus ad�quate
}


void
NSProcessView::CmModifier()
{
	if (!(pContexte->userHasPrivilege(NSContexte::modifyProcess, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

  // on r�cup�re l'index dans la processview de l'item � modifier
  int index = pListeWindow->IndexItemSelect() ;

  /*
  if (pConcern == 0)
  {
    erreur("Le m�dicament doit �tre rattach� � une pr�occupation particuli�re.", 0, 0) ;
    return ;
  }
  */

  if (index == -1)
  {
    erreur("Vous devez s�lectionner un process � modifier dans la liste des processes en cours.", standardError, 0) ;
    return ;
  }

  // on r�cup�re la r�f�rence du noeud de l'item s�lectionn�
  string  sNodeModif = (aCurrentProcesses[index])->getDocNoeud() ;

  if (pContexte->getPatient() && pContexte->getPatient()->pDocHis && !pContexte->getPatient()->pDocHis->VectDocument.empty())
  {
  	DocumentIter iterDoc = pContexte->getPatient()->pDocHis->VectDocument.begin() ;
	  for ( ; iterDoc != pContexte->getPatient()->pDocHis->VectDocument.end() ; iterDoc++)
    {
      // on r�cup�re le code du noeud document du document courant de
      // l'historique et on le compare avec celui de l'item s�lectionn�
      string  sCodeCurrentDoc = (*iterDoc)->getID() ;
      if (strncmp(sCodeCurrentDoc.c_str(), sNodeModif.c_str(), PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) == 0)
      {
        // on a trouv� le bon document, maintenant on veut ouvrir ce document
        // afin de pouvoir le modifier
        NSDocumentHisto *pDocument = static_cast<NSDocumentHisto *>(*iterDoc) ;
        if (!pDocument)
          return ;
        pContexte->getPatient()->pDocHis->AutoriserEdition(pDocument) ;
        return ;
      }
    }
  }
}

void
NSProcessView::CmArreter()
{
	if (!(pContexte->userHasPrivilege(NSContexte::modifyProcess, -1, -1, string(""), string(""), NULL, NULL)))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "insufficientRights") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return ;
	}

	// pour arreter un process, il faut lui attribuer un r�sultat
	// serait-il possible d'arreter un process sans qu'il est de r�sultat ?

	// on r�cup�re l'index du process � arr�ter
	int index = pListeWindow->IndexItemSelect() ;
	if (index == -1)
	{
		// il faut d'abord s�lectionner un process
		erreur("Vous devez s�lectionner un process � arreter dans la liste des processes en cours.", standardError, 0) ;
		return ;
	}

	// on r�cup�re la r�f�rence sur le noeud correspondant au process s�lectionn�
	string  sDocNode  = (aCurrentProcesses[index])->getDocNoeud() ;
	string  sMetaNode = (aCurrentProcesses[index])->getMetaNoeud() ;

	// on r�cup�re le noeud racine du patient
	string sDocRoot = pContexte->getPatient()->getNss() + string("_00000") ;

	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	pGraphe->detruireLien(sDocRoot, NSRootLink::processWaitingFor, sMetaNode) ;

/*
//  pContexte->getGraphe()->detruireLien(sDocRoot, NSGraphe::processWaitingFor, sNodeModif) ;
  if (pContexte->getPatient() && pContexte->getPatient()->pDocHis && !pContexte->getPatient()->pDocHis->VectDocument.empty())
  {
  	DocumentIter iterDoc = pContexte->getPatient()->pDocHis->VectDocument.begin() ;
	  for ( ; iterDoc != pContexte->getPatient()->pDocHis->VectDocument.end() ; iterDoc++)
    {
      // on r�cup�re le code du noeud document du document courant de
      // l'historique et on le compare avec celui de l'item s�lectionn�
      string  sCodeCurrentDoc = string((*iterDoc)->pDonnees->codePatient) + string((*iterDoc)->pDonnees->codeDocument) ;
      if (strncmp(sCodeCurrentDoc.c_str(), sNodeModif.c_str(), PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) == 0)
      {
        // on a trouv� le bon document, maintenant on veut ouvrir ce document
        // afin de pouvoir le r�cup�rer son code META
        NSDocumentHisto *pDocument = static_cast<NSDocumentHisto *>(*iterDoc) ;
        if ((pDocument) && (pDocument->pMeta != NULL) && (!pDocument->pMeta->empty()) && (pDocument->pMeta->begin()))
        {
          string  sCodeProcess =  string((*(pDocument->pMeta->begin()))->pDonnees->codePatient) +
                                  string((*(pDocument->pMeta->begin()))->pDonnees->codeDocument) +
                                  string((*(pDocument->pMeta->begin()))->pDonnees->noeud) ;
          pContexte->getGraphe()->detruireLien(sDocRoot, NSGraphe::processWaitingFor, sCodeProcess) ;
        }
      }
    }
  }
*/
  // pour arreter un process, on doit d�truire le lien processWaitingFor entre
  // le noeud racine du patient et la demande de process


  // on cloture la pr�c�dente prescription  //  pContexte->getPatient()->ArreterElement(sNodeModif, string(szDateJour)) ;

  initCurentProcesses() ;
  AfficheListe() ;
}


void
NSProcessView::CmOrdonnance()
{
// � voir - reflechir � comment faire une ordonnance
//  pContexte->getPatient()->CreeOrdonnance() ;
}


void
NSProcessView::displayChanges()
{
  initCurentProcesses() ;
  AfficheListe() ;
}


void
NSProcessView::initCurentProcesses()
{
	aCurrentProcesses.vider() ;

  	// la liste des processes n'est pas stock�e dans le LdvDoc
  	// donc tout ce qui suit n'est pas utile
	// r�cup�ration de la r�f�rence du noeud racine patient
	string sDocRoot = pContexte->getPatient()->getNss() + LocalPatient + string("00000"); ;

	// on recherche tous les noeuds avec lequel le patient � un lien processWaitingFor
	// ces noeuds correspondent aux PPT META des documents concernant les processes
  NSPersonGraphManager* pPersonGraph = pContexte->getPatient()->pGraphPerson ;
  NSLinkManager* pGraphe = pPersonGraph->pLinkManager ;

	VecteurString *pVecteurString = new VecteurString() ;
	pGraphe->TousLesVrais(sDocRoot, NSRootLink::processWaitingFor, pVecteurString) ;
  //recuperation process li�s au root par NSRootLink::processWaitingFor
 /*	if (pVecteurString->empty())
		return  ;    */
 	char    pcNode[PAT_NSS_LEN + DOC_CODE_DOCUM_LEN + PPD_NOEUD_LEN + 1] ;
  if (!pVecteurString->empty())
	{
  	for (EquiItemIter i = pVecteurString->begin() ; i != pVecteurString->end() ; i++)
		{
    	VecteurString *pVSprocess = new VecteurString() ;
			// on veut le noeud document donc on prend utilisateur + document
    	sprintf(pcNode, "%s", (*i)->c_str()) ;
    	pcNode[PAT_NSS_LEN + DOC_CODE_DOCUM_LEN] = 0 ;
    	pGraphe->TousLesVrais(pcNode, NSRootLink::docData, pVSprocess) ;

    	if (!pVSprocess->empty())
      {
      	for (EquiItemIter j = pVSprocess->begin() ; j != pVSprocess->end() ; j++)
        {
          NSPatPathoArray     *pTmp = new NSPatPathoArray(pContexte) ;
          string sRosace;
          pPersonGraph->getTree( pcNode, pTmp , &sRosace) ;
          if(!pTmp->empty())
          {
            PatPathoIter pptIt = pTmp->begin();
          	string sNode = (*pptIt)->getNode();
          	sprintf(pcNode, "%s", sNode.c_str()) ;
          }
          delete pTmp ;

          //string sDocument = string(sNoeud, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) ;
          // FAIRE DELETE pTmpPPT QUELQUE PART
          //
          NSPatPathoArray     *pTmpPPT = new NSPatPathoArray(pContexte) ;
          pContexte->getPatient()->DonneArray(pcNode, pTmpPPT) ;

          if (pTmpPPT->empty())
          {
          	delete pTmpPPT ;
            break ;
          }

          NSProcess *pNewProcess  = new NSProcess(pContexte) ;

          // on doit ajouter tous les noeuds qui ont un lien prescripWaitingFor � la
          // liste des processes courant (aCurrentProcesses)

          // on r�cup�re le code lexique, le noeud, et le titre
          initProcessFromPatho(pcNode, pNewProcess,  pTmpPPT, **i);
        	pGraphe->TousLesVrais(pNewProcess->getMetaNoeud(), NSRootLink::problemRelatedTo, &(pNewProcess->aConcerns)) ;

        	if ((sPreoccup == "") || (pNewProcess->isLinkedWithConcern(sPreoccup)))
          	aCurrentProcesses.push_back(new NSProcess(*pNewProcess)) ;

       		delete pNewProcess ;
      	} //for
			} //if
    } //for
  } //if
  else
  {
  	//recuperation des process li�s aux objectifs
    ArrayGoals  *pLdvGoals = pLdVDoc->getGoals() ;
    VecteurString *pObjProcessVect = new VecteurString() ;
    if (!pLdvGoals->empty())
    {
    	for (ArrayGoalIter iterGoal = pLdvGoals->begin(); iterGoal != pLdvGoals->end(); iterGoal++)
      	pGraphe->TousLesVrais((*iterGoal)->getNoeud(), NSRootLink::processWaitingFor, pObjProcessVect) ;
    }
    if (!pObjProcessVect->empty())
    {
    	for (EquiItemIter iterProc = pObjProcessVect->begin() ; iterProc != pObjProcessVect->end() ; iterProc++)
      {
      	// mainteant on veux un noeud qui correspond � une PPT

        NSPatPathoArray     *pTmpPPT = new NSPatPathoArray(pContexte) ;
        pContexte->getPatient()->DonneArray((*iterProc)->c_str(), pTmpPPT) ;

        if (pTmpPPT->empty())
        {
        	delete pTmpPPT ;
          break ;
        }

        NSProcess *pNewProcess  = new NSProcess(pContexte) ;
        // on r�cup�re le code lexique, le noeud, et le titre
        initProcessFromPatho(pcNode, pNewProcess,  pTmpPPT, (**iterProc));
        pGraphe->TousLesVrais(pNewProcess->getMetaNoeud(), NSRootLink::problemRelatedTo, &(pNewProcess->aConcerns)) ;
        //recuperation date de la demande
        VecteurString *pDocVect = new VecteurString() ;
        // strncpy(pcNode, (**iterProc).c_str(), PAT_NSS_LEN + DOC_CODE_DOCUM_LEN);
        string docId = string((**iterProc), 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN);
        pGraphe->TousLesVrais(docId, NSRootLink::docData, pDocVect, "ENVERS") ;
        if( !pDocVect->empty())              //7
        {
            for(EquiItemIter iterDoc = pDocVect->begin() ; iterDoc != pDocVect->end() ; iterDoc++)     //6
            {
              DocumentIter DocIt = pContexte->getPatient()->pDocHis->VectDocument.begin() ;							for ( ; DocIt != pContexte->getPatient()->pDocHis->VectDocument.end() ; DocIt++)   //5							{                if (((*DocIt)->pMeta != NULL) && (!(*DocIt)->pMeta->empty()))   //4        				{         					PatPathoIter pptIt = (*DocIt)->pMeta->begin() ;      						if ((*pptIt)->getDoc() == **iterDoc)     //3      						{        						for ( ; (pptIt != (*DocIt)->pMeta->end()) && ((*pptIt)->getLexique() != "KREDA1") ; pptIt++)          						;        						if (pptIt != (*DocIt)->pMeta->end())     //2        						{                  		pptIt++;                    	if (pptIt != (*DocIt)->pMeta->end())  //1                    	{                    		string sUnite  = "" ;												string sFormat = "" ;
                      	string sValeur = "" ;
                        string sTemp = "" ;

            						sTemp = (*pptIt)->getUnit() ;
            						pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
            						sTemp = (*pptIt)->getLexique() ;
            						pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
                      	sValeur = (*pptIt)->getComplement() ;

												if (sUnite == "2DA02")
                      		pNewProcess->tDateDemande.initFromDate(sValeur);
		               		}   //1        						}     //2      						}     //3
            		}      //4
              }      //5
        		}   //6
       	}     //7
        delete pDocVect ;
        aCurrentProcesses.push_back(new NSProcess(*pNewProcess)) ;
        delete pNewProcess ;
        delete pTmpPPT ;
      }   //for
    }    //if
    delete  pObjProcessVect ;

	}      //else

	delete pVecteurString ;
}


void
NSProcessView::initProcessFromPatho(char* sNode, NSProcess *pNewProcess,  NSPatPathoArray *pTmpPPT, string metaNode)
{
   if((!pNewProcess) || ( !pTmpPPT) || (pTmpPPT->empty()))
   	return ;
	// on r�cup�re le code lexique, le noeud, et le titre
  PatPathoIter  pptIter = pTmpPPT->begin() ;
	string        sLexiqProcess = (*pptIter)->pDonnees->lexique ;
  string        sTitleProcess = "" ;
  if (sLexiqProcess != string("�?????"))
  	pContexte->getDico()->donneLibelle(pContexte->getUtilisateur()->donneLang(), &sLexiqProcess, &sTitleProcess) ;

  // on les ins�re dans le process
  //pNewProcess->setDocNoeud(pcNode) ;       sNode
  //pNewProcess->setMetaNoeud(**i) ;        metaNode
  pNewProcess->setDocNoeud(sNode) ;
  pNewProcess->setMetaNoeud(metaNode) ;
  pNewProcess->setLexique(sLexiqProcess) ;
  pNewProcess->sTitre = sTitleProcess ;

  // on recherche la date d'ouverture
  int iColBase = (*pptIter)->pDonnees->getColonne() ;
  if (pptIter != pTmpPPT->end())
  	pptIter++ ;

  if ((pptIter != pTmpPPT->end()) && ((*pptIter)->pDonnees->getColonne() > iColBase))
  {
  	if ((*pptIter)->pDonnees->getColonne() == iColBase + 1)
    {
    	string sElemLex = string((*pptIter)->pDonnees->lexique) ;
      string sSens ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

      // Dates
      if (sSens == "KOUVR")
      {
      	pptIter++ ;
        int iLigneBase = (*pptIter)->pDonnees->getLigne() ;
        string sUnite  = "" ;
        string sFormat = "" ;
        string sValeur = "" ;
        string sTemp   = "" ;
        while (	(pptIter != pTmpPPT->end()) &&
										  ((*pptIter)->pDonnees->getLigne() == iLigneBase))
        {
					if (((*pptIter)->pDonnees->lexique)[0] == '�')
          {
          	sTemp   = (*pptIter)->getLexique() ;
            pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
            sValeur = (*pptIter)->getComplement() ;
            sTemp   = (*pptIter)->getUnit() ;
            pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
            break ;
          }
					pptIter++ ;
				}

        // sFormat est du type �D0;03
        if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) && (sValeur != ""))
        {
        	if (((sUnite == "2DA01") || (sUnite == "2DA02")) && (sSens == "KOUVR"))
          	pNewProcess->tDateOuverture.initFromDate(sValeur) ;
          else if (((sUnite == "2DA01") || (sUnite == "2DA01")) && (sSens == "KFERM"))
          	pNewProcess->tDateFermeture.initFromDate(sValeur) ;
        }

			}
		}
	}

}


// Initialisation des colonnes de la ListWindowvoid
NSProcessView::SetupColumns()
{
  pListeWindow->InsertColumn(0, TListWindColumn("Process",         150,   TListWindColumn::Left, 0)) ;
  pListeWindow->InsertColumn(1, TListWindColumn("Date de demande",  80,   TListWindColumn::Left, 1)) ;
  pListeWindow->InsertColumn(2, TListWindColumn("Date de d�but",    80,   TListWindColumn::Left, 2)) ;
  pListeWindow->InsertColumn(3, TListWindColumn("Date de fin",      80,   TListWindColumn::Left, 3)) ;
}


// Affichage des �l�ments de la listevoid
NSProcessView::AfficheListe()
{
  pListeWindow->DeleteAllItems() ;

  if (aCurrentProcesses.empty())
    return ;

  // Attention : insert ins�re au dessus ; il faut inscrire les derniers en premier
/*
  ProcessesIter itProcess = aCurrentProcesses.end() ;
  do
  {
    itProcess-- ;
    TListWindItem Item(((*itProcess)->sTitre).c_str(), 0) ;
    pListeWindow->InsertItem(Item) ;
  }
  while (itDg != aCurrentProcess.begin()) ;
*/
  for (ProcessesRIter itProcess = aCurrentProcesses.rbegin() ; itProcess != aCurrentProcesses.rend() ; itProcess++)
  {
    TListWindItem Item(((*itProcess)->sTitre).c_str(), 0) ;
    pListeWindow->InsertItem(Item) ;
  }
}


void
NSProcessView::DispInfoListe(TLwDispInfoNotify& dispInfo)
{
  const int       BufLen = 255 ;
  static char     buffer[BufLen] ;
  TListWindItem   &dispInfoItem = *(TListWindItem *)&dispInfo.item ;
  char            szDate[10] ;
  buffer[0] = '\0' ;

  int index = dispInfoItem.GetIndex() ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  // Affiche les informations en fonction de la colonne  switch (dispInfoItem.GetSubItem())
  {
    case 1 :  // date de demande
              strcpy(szDate, (aCurrentProcesses[index])->tDateDemande.donneDate().c_str()) ;
              donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;
    case 2 :  // date de d�but
              strcpy(szDate, (aCurrentProcesses[index])->tDateOuverture.donneDate().c_str()) ;
              donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;
    case 3 :  // date de fin
              strcpy(szDate, (aCurrentProcesses[index])->tDateFermeture.donneDate().c_str()) ;
              donne_date(szDate, buffer, sLang) ;
              dispInfoItem.SetText(buffer) ;
              break ;
  }
}


boolNSProcessView::VnIsWindow(HWND hWnd){
  return (HWindow == hWnd) ;
}


// fonction permettant de prendre toute la taille de TWindow par la TListWindowvoid
NSProcessView::EvSize(uint sizeType, ClassLib::TSize& size)
{
  TWindow::EvSize(sizeType, size) ;
  pListeWindow->MoveWindow(GetClientRect(), true) ;
}


// fonction EVSetFocusvoid
NSProcessView::EvSetFocus(HWND hWndLostFocus)
{
	activateMUEViewMenu() ;

  TMyApp *pMyApp = pContexte->getSuperviseur()->getApplication() ;
  NSMUEView::EvSetFocus(hWndLostFocus) ;
  if (bSetupToolBar && (GetWindow() != pMyApp->GetToolBarWindow()))
  {
    SetupToolBar() ;
    pMyApp->SetToolBarWindow(GetWindow()) ;
  }

  pPaneSplitter->SetFrameTitle(getFunction(), sViewName) ;
  pContexte->setAideIndex("") ;
  pContexte->setAideCorps("process.htm") ;
}


// SetupToolBarvoid
NSProcessView::SetupToolBar()
{
  TMyApp *pMyApp = pContexte->getSuperviseur()->getApplication() ;
  pMyApp->FlushControlBar() ;

	pMyApp->cb2->Insert(*new TButtonGadget(CM_PROCESS_NEW,     CM_PROCESS_NEW,     TButtonGadget::Command)) ;
  pMyApp->cb2->Insert(*new TButtonGadget(CM_PROCESS_STOP,    CM_PROCESS_STOP,    TButtonGadget::Command)) ;
  pMyApp->cb2->Insert(*new TButtonGadget(CM_PROCESS_CHANGE,  CM_PROCESS_CHANGE,  TButtonGadget::Command)) ;

  pMyApp->cb2->LayoutSession() ;
}

//***************************************************************************
//
//  					M�thodes de NSDrugsPropertyWindow//
//***************************************************************************
DEFINE_RESPONSE_TABLE1(NSProcessesPropertyWindow, TListWindow)  EV_WM_LBUTTONDBLCLK,
  EV_WM_KEYDOWN,
  EV_WM_SETFOCUS,
END_RESPONSE_TABLE ;

NSProcessesPropertyWindow::NSProcessesPropertyWindow(NSProcessView *parent, int id, int x, int y, int w, int h, TModule *module)
  : TListWindow((TWindow *) parent, id, x, y, w, h, module)
{
  pView   = parent ;
  iRes    = id ;
  Attr.Style |= LVS_REPORT | LVS_SHOWSELALWAYS ;
//  Attr.ExStyle |= WS_EX_NOPARENTNOTIFY ;
}

void
NSProcessesPropertyWindow::SetupWindow()
{
  ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;
  TListWindow::SetupWindow() ;
}

// -----------------------------------------------------------------------------
//  Fonction de r�ponse au double-click
// -----------------------------------------------------------------------------
void
NSProcessesPropertyWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
  TLwHitTestInfo info(point) ;
  HitTest(info) ;

  //if (info.GetFlags() & LVHT_ONITEM)  //  pDlg->CmModifier() ;
}

void
NSProcessesPropertyWindow::EvKeyDown(uint key, uint repeatCount, uint flags)
{
    if      (key == VK_DELETE)
        pView->CmArreter() ;
    else if (key == VK_INSERT)
    {
        if (GetKeyState(VK_SHIFT) < 0)
            pView->CmModifier() ;
        else
            pView->CmNouveau() ;
    }
    else if (key == VK_TAB)
    {
        if (GetKeyState(VK_SHIFT) < 0)
            pView->setFocusToPrevSplitterView() ;
        else
            pView->setFocusToNextSplitterView() ;
    }
    else
    	TListWindow::EvKeyDown(key, repeatCount, flags) ;
}

// -----------------------------------------------------------------------------//  Retourne l'index du premier item s�lectionn�
// -----------------------------------------------------------------------------
int
NSProcessesPropertyWindow::IndexItemSelect()
{
  int count = GetItemCount() ;
  int index = -1 ;

  for (int i = 0 ; i < count ; i++)    if (GetItemState(i, LVIS_SELECTED))
    {
      index = i ;
      break ;
    }

  return index ;}


void
NSProcessesPropertyWindow::EvSetFocus(HWND hWndLostFocus)
{
  pView->EvSetFocus(hWndLostFocus) ;
}

