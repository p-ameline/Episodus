// -----------------------------------------------------------------------------// Nssuper.cpp
// -----------------------------------------------------------------------------
// Impl�mentation des m�thodes du Superviseur.
// -----------------------------------------------------------------------------
// $Revision: 1.123 $
// $Author: pameline $
// $Date: 2005/07/18 08:43:28 $
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Copyright Nautilus, 2004
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � g�rer et traiter les
// informations de sant� d'une personne.
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to manage and process
// a person's health data.
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------

#define __NSSUPER

#include <owl\window.h>
#include <owl\applicat.h>
#include <owl\owlpch.h>
#include <stdio.h>
#include <bde.hpp>
#include <sysutils.hpp>

#include "nautilus\nsrechdl.h"    // Pour ouvrir un nouveau patient
#include "nautilus\nscrvue.h"     // Document / Vues CN (Compte-Rendu Nautilus)
#include "nautilus\nsttx.h" 	    // Document / Vues TTX
#include "nautilus\nsAcroRead.h" 	// Document / Vues PDF
#include "nautilus\nscsdoc.h"     // Document / Vues CS Consultation
#include "nautilus\nscsvue.h"     // Document / Vues CS Consultation
#include "nautilus\nscqvue.h"     // Document / Vues CQ Formulaires
#include "nautilus\nsvisual.h"	  // Document / Vues Visualisation#include "nssavoir\nstransa.h"    // Transactions#include "nautilus\nsmodhtm.h"    // Pour le HtmlCS
#include "nautilus\nsepicap.h"    // Episodus
#include "nssavoir\nsgraphe.h"    // Graphe + Gestion des archetypes
#include "nsoutil\nsoutdlg.h"
#include "nsoutil\nsepiout.h"
#include "nsoutil\nsfilgui.h"
#include "nsbb\ns_skins.h"
#include "nsbb\nsarc.h"
#include "nsbb\nsdefArch.h"
#include "nsbb\nsTipBrowser.h"
#include "ns_grab\nsgrabfc.h"
#include "nautilus\nsdocview.h"
#include "nautilus\nsbrowseSvce.h"
#include "nautilus\nshistdo.h"
#include "nautilus\nscaptview.h"
#include "nautilus\nscqdoc.h"

#include "nautilus\nsbackup.h"

#include "pilot\Pilot.hpp"
#include "pilot\NautilusPilot.hpp"
#include "pilot\JavaSystem.hpp"#ifndef __NSSUPER_H
# include "nautilus\nssuper.h"
#endif

#include "ns_ob1\nautilus-bbk.h"

#ifdef __EPIPUMP__
# include "EpiPump\IHEGlobal.h"
#endif

//#include "ns_bbk\TControler\Interface.h"

//***************************************************************************
// Impl�mentation des m�thodes de NSSuper
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur.
//
//  Cr�e une instance d'objet de la classe NSSuper.
//	 Cr�e un moteur Paradox et une database.
//	 Initialise statut.
//
//---------------------------------------------------------------------------
NSSuper::NSSuper(NSContexte* pCtx)
        :statut(0), hNSdb(NULL)
{
try
{
	sNumVersion         = string("5.05.0037") ;

	pSuperContext       = pCtx ;

  sHindex             = "" ;
	sHcorps             = "" ;
	pHelpTip            = 0 ;

  paSkins             = new skinArray(pCtx) ;
  pDico               = new NSDico(pCtx) ;
  pFilGuide           = new NSFilGuide(pCtx, GUIDE) ;
  pFilDecode          = new NSFilGuide(pCtx, DECODE) ;
  pBufDragDrop        = new NSCutPaste(pCtx) ;
  pBufCopie           = new NSCutPaste(pCtx) ;
  iTraceConsole       = trNone;
  iTrace              = trWarning  ;

  pEpisodus           = NULL ;
  pDPIO               = NULL ;

#ifndef __EPIPUMP__
  pEpisodus           = new NSEpisodus(pCtx) ;
# ifndef __EPIBRAIN__
  pDPIO               = new NSDPIO(pCtx) ;
  if (pDPIO && (pDPIO->sNomModule != ""))
  {
    sAppName = pDPIO->sNomModule ;
    if (pDPIO->sOEMModule != "")
      sAppName += string("/") + pDPIO->sOEMModule ;
  }
# endif // !__EPIBRAIN__
#endif // !__EPIPUMP__

  pLocalStrings       = new NSLocalChapterArray(pCtx) ;
  _PathDB             = new NSLocalChapterArray(pCtx) ;
  _typeMime           = new NSLocalChapterArray(pCtx) ;

  loadLocalisationString("") ;

  pArcManager         = new NSArcManager(pCtx) ;
	pPersonArray        = new NSPersonArray(pCtx) ;
  bDragAndDrop        = false ;
  offNode             = false ;
  DragDrop            = 0 ;
  pMainWindow         = 0 ;
  pDialogFont         = new TFont("MS Sans Serif", 8) ;

  parite              = 0 ;
  monnaieRef          = MONNAIE_EURO ;
  sigle               = "" ;
  bComptaAuto         = false ;
  bNoCCAMforReport    = false ;
  bNoCCAMforExam      = true ;
  indiceConsult       = "" ;
  bCodageAuto         = false ;
  sExport_dll         = "" ;
  sIppSite            = "" ;
  sOperationalSite    = "" ;

  sDemographicArchetypeId              = NAME_ARC_ADMIN ;
	sAddressArchetypeId                  = NAME_ARC_ADRESSE ;
	sSimpleAddressArchetypeId            = NAME_ARC_ADRSIMPLE ;
	sPatientAddressEditArchetypeId       = NAME_ARC_ADRPATEDIT ;
	sProfessionnalAddressEditArchetypeId = NAME_ARC_ADRCOREDIT ;
	sReferalProfessionnalArchetypeId     = NAME_ARC_CORRESP ;
	sReferalProfessionnalEditArchetypeId = NAME_ARC_COREDIT ;
	sTeamMemberArchetypeId               = NAME_ARC_NEWTEAM ;

  bModeClientGroup    = false ;
	bGroupInterfaceOnly = false ;
  bVerboseErrorMessages = true ;
  pGrabModule         = 0 ;  pMatrox             = 0 ;
	pNSApplication	    = 0 ;

	bToDoLocked         = false ;
	bBBKToDoLocked      = false ;

//  NSSuper *pSup = pFilGuide->pSuperContext->getSuperviseur() ;

#ifdef __OB1__
  blackboardInterface = NULL ;
#endif

	m_hStdOut						= NULL ;
}
catch (...)
{
  erreur("Exception NSSuper ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSSuper::NSSuper(NSSuper& srcNSSuper)
	:	statut(srcNSSuper.statut),
  	hNSdb(srcNSSuper.hNSdb),
    pDico(srcNSSuper.pDico),
    pFilGuide(srcNSSuper.pFilGuide),
    pMainWindow(srcNSSuper.pMainWindow),
		pEpisodus(srcNSSuper.pEpisodus),
    pDPIO(srcNSSuper.pDPIO),
		sExport_dll(srcNSSuper.sExport_dll),
    sIppSite(srcNSSuper.sIppSite),
		sOperationalSite(srcNSSuper.sOperationalSite),
    sDemographicArchetypeId(srcNSSuper.sDemographicArchetypeId),
		sAddressArchetypeId(srcNSSuper.sAddressArchetypeId),
		sSimpleAddressArchetypeId(srcNSSuper.sSimpleAddressArchetypeId),
		sPatientAddressEditArchetypeId(srcNSSuper.sPatientAddressEditArchetypeId),
		sProfessionnalAddressEditArchetypeId(srcNSSuper.sProfessionnalAddressEditArchetypeId),
		sReferalProfessionnalArchetypeId(srcNSSuper.sReferalProfessionnalArchetypeId),
		sReferalProfessionnalEditArchetypeId(srcNSSuper.sReferalProfessionnalEditArchetypeId),
		sTeamMemberArchetypeId(srcNSSuper.sTeamMemberArchetypeId),
    pGrabModule(srcNSSuper.pGrabModule),    pMatrox(srcNSSuper.pMatrox),    aSupportsArray(srcNSSuper.aSupportsArray){
  if (srcNSSuper.pDialogFont)
  	pDialogFont = new TFont(*(srcNSSuper.pDialogFont));

  bModeClientGroup      = srcNSSuper.bModeClientGroup ;
  bGroupInterfaceOnly   = srcNSSuper.bGroupInterfaceOnly ;
  bVerboseErrorMessages = srcNSSuper.bVerboseErrorMessages ;

	bToDoLocked    = false ;
	bBBKToDoLocked = false ;
}

//---------------------------------------------------------------------------//  Op�rateur =
//---------------------------------------------------------------------------
NSSuper&
NSSuper::operator=(NSSuper& srcNSSuper)
{
	if (this == &srcNSSuper)
		return *this ;

  statut            = srcNSSuper.statut ;
  hNSdb             = srcNSSuper.hNSdb ;
  pDico    		      = srcNSSuper.pDico ;
  pFilGuide   	    = srcNSSuper.pFilGuide ;
  pBufDragDrop      = srcNSSuper.pBufDragDrop ;
  pBufCopie         = srcNSSuper.pBufCopie ;
  bDragAndDrop      = srcNSSuper.bDragAndDrop ;
  offNode 		      = srcNSSuper.offNode ;
  DragDrop 		      = srcNSSuper.DragDrop ;
  pMainWindow       = srcNSSuper.pMainWindow ;

  pEpisodus         = NULL ;
  pDPIO             = NULL ;
#ifndef __EPIPUMP__
  pEpisodus         = srcNSSuper.pEpisodus ;
# ifndef __EPIBRAIN__
  pDPIO             = srcNSSuper.pDPIO ;
# endif // !__EPIBRAIN__
#endif // !__EPIPUMP__

  pDialogFont       = new TFont(*(srcNSSuper.pDialogFont)) ;
  sExport_dll       = srcNSSuper.sExport_dll ;
  sIppSite          = srcNSSuper.sIppSite ;
	sOperationalSite  = srcNSSuper.sOperationalSite ;
  iTraceConsole     = srcNSSuper.iTraceConsole ;
  iTrace            = srcNSSuper.iTrace ;

  sDemographicArchetypeId              = srcNSSuper.sDemographicArchetypeId ;
	sAddressArchetypeId                  = srcNSSuper.sAddressArchetypeId ;
	sSimpleAddressArchetypeId            = srcNSSuper.sSimpleAddressArchetypeId ;
	sPatientAddressEditArchetypeId       = srcNSSuper.sPatientAddressEditArchetypeId ;
	sProfessionnalAddressEditArchetypeId = srcNSSuper.sProfessionnalAddressEditArchetypeId ;
	sReferalProfessionnalArchetypeId     = srcNSSuper.sReferalProfessionnalArchetypeId ;
	sReferalProfessionnalEditArchetypeId = srcNSSuper.sReferalProfessionnalEditArchetypeId ;
  sTeamMemberArchetypeId               = srcNSSuper.sTeamMemberArchetypeId ;

  bModeClientGroup      = srcNSSuper.bModeClientGroup ;
  bGroupInterfaceOnly   = srcNSSuper.bGroupInterfaceOnly ;
  bVerboseErrorMessages = srcNSSuper.bVerboseErrorMessages ;
  pGrabModule       = srcNSSuper.pGrabModule ;  pMatrox           = srcNSSuper.pMatrox ;  aSupportsArray    = srcNSSuper.aSupportsArray ;
	bToDoLocked       = false ;
	bBBKToDoLocked    = false ;

  return (*this) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSSuper::~NSSuper()
{
#ifndef __EPIPUMP__
# ifndef __EPIBRAIN__
#  ifdef __OB1__
  closeBlackboard(pSuperContext) ;
#  endif
# endif // !__EPIBRAIN__
#endif // !__EPIPUMP__
  delete pDico ;
  pDico = 0 ;
  delete pFilGuide ;

	// D�truit l'utilisateur s'il existe encore.
	if (pSuperContext->getUtilisateur() != NULL)
  {
#ifndef __EPIPUMP__
# ifndef __EPIBRAIN__
    if (pEpisodus && pEpisodus->bAutoSave)
    {
      NSPrometheFile PrometCfg(pSuperContext) ;
      PrometCfg.EcrireFichier() ;
    }
# endif // !__EPIBRAIN__
#endif // !__EPIPUMP__

    delete pSuperContext->getUtilisateur() ;
    pSuperContext->setUtilisateur(0) ;
	}
  if(m_hStdOut)
  {
    FreeConsole();
    CloseHandle(m_hStdOut);
  }

	// D�truit le moteur IDAPI et la database.
	FermeDatabase() ;

#ifndef __EPIPUMP__
# ifndef __EPIBRAIN__

	pSuperContext->reallocateBaseDirectory() ;
  nsbackup() ;

	if (NULL != pHelpTip)
		delete pHelpTip ;

# endif // !__EPIBRAIN__
#endif // !__EPIPUMP__

  delete pBufDragDrop ;
  delete pBufCopie ;

#ifndef __EPIPUMP__
  delete pEpisodus ;
# ifndef __EPIBRAIN__
  delete pDPIO ;
# endif // !__EPIBRAIN__
#endif // !__EPIPUMP__

  // delete pGraphe ;
  delete pArcManager ;  delete pPersonArray ;  delete pDialogFont ;  delete paSkins ;
  if (pGrabModule)  {    delete pGrabModule ;    pGrabModule = 0 ;  }
  delete pLocalStrings ;
  delete (_PathDB);
  delete (_typeMime);
}
// -----------------------------------------------------------------------------// Fonction servant � initialiser les chemins et tles types
// -----------------------------------------------------------------------------
bool
NSSuper::InitialiseFileDatabase()
{
  // R�cup�ration du r�pertoire perso
 	string PathPerso = PathBase("BCHE") ;

  // Chargement des chemins
  ifstream CheminDB ;
  string pathCDB = PathPerso + "chemindb.dat" ;
  CheminDB.open(pathCDB.c_str(), ofstream::in) ;
  if (CheminDB.is_open())
  {
  	_PathDB->init(&CheminDB) ;
    CheminDB.close() ;
  }
  else
  {
    string error = "Le fichier " + pathCDB + " n'existe pas" ;
    erreur(error.c_str(), standardError, 0) ;
  }

  // chargemetn des types mymes
  ifstream Mime ;
  string pathMime = PathPerso + "TypeMime.dat" ;
  Mime.open(pathMime.c_str(), ofstream::in) ;
  if (Mime.is_open())
  {
  	_typeMime->init(&Mime) ;
    Mime.close() ;
  }
  else
  {
  	string error = "Le fichier " + pathMime + " n'existe pas" ;
    erreur(error.c_str(), standardError, 0) ;
  }
  return true ;
}


bool
NSSuper::chercheTypeMimeInfo(string sFichExt, NSTypeMimeInfo* pTypeMimeInfo)
{
	bool result = true ;

	string sLowerFichExt = string("") ;
  for (size_t i = 0; i < strlen(sFichExt.c_str()); i++)
  {
  	char cLow = tolower(sFichExt[i]) ;
		sLowerFichExt += string(1, cLow) ;
  }

	string typ = _typeMime->getLocalText(sLowerFichExt, string("$TYPE")) ;
  if (typ == "")
		return false ;

	string lib = _typeMime->getLocalText(sLowerFichExt, string("$LIBELLE")) ;
  string mime = _typeMime->getLocalText(sLowerFichExt, string("$MIME")) ;

	if (NULL != pTypeMimeInfo)
	{
  	strcpy(pTypeMimeInfo->pDonnees->extension, sLowerFichExt.c_str()) ;
  	strcpy(pTypeMimeInfo->pDonnees->libelle,   lib.c_str()) ;
  	strcpy(pTypeMimeInfo->pDonnees->mime,      mime.c_str()) ;
  	strcpy(pTypeMimeInfo->pDonnees->type,      typ.c_str()) ;
	}

  return result ;
}


// -----------------------------------------------------------------------------
// Fonction    : NSSuper::InitialiseDatabase()
// Description : Initialise un moteur IDAPI et une database. Initialise statut.
// Retour      : True : OK, False : Echec
// -----------------------------------------------------------------------------
bool
NSSuper::InitialiseDatabase(NSContexte* pCtx)
{
  if (NULL != pNSApplication)
  {
	  pNSApplication->sendMessageToSplash("Init database") ;
    pNSApplication->setSplashPercentDone(5) ;
  }

#ifdef __EPIPUMP__
# ifndef __EPIBRAIN__
  IHEGlobal::PrintReport("Database init - begin") ;
# endif
#endif
  string ps = string("Database init - begin") ;
  trace(&ps, 1, trSteps) ;

  // Ouverture de IDAPI
  // Initialise IDAPI

  bool bUseEnvironnement = false ;

  DBIEnv Environnement ;
  memset(&Environnement, 0, sizeof(DBIEnv));

  string sBdeParamsFileName = string(".\\bdeParams.dat") ;

  // This function requires VCL
  //
  // if (FileExists(AnsiString(sBdeParamsFileName.c_str())))
  // {
    ifstream inFile ;
	  // on ouvre le fichier de configuration
    inFile.open(sBdeParamsFileName.c_str()) ;

/*
    if (!inFile)
    {
  	  string sErrorMsg = getText("fileErrors", "errorOpeningInputFile") ;
      sErrorMsg += string(" ") + sBdeParamsFileName ;
      erreur(sErrorMsg.c_str(), warningError, 0) ;
    }
*/

    if (inFile)
    {
	    string sLine ;
      string sData = string("") ;
	    while (!inFile.eof())
	    {
		    getline(inFile, sLine) ;
        sData += sLine + "\n" ;
	    }

      inFile.close() ;

      size_t i = 0 ;

      string sNomAttrib ;
      string sValAttrib ;

	    while (i < strlen(sData.c_str()))
	    {
		    sNomAttrib = "" ;
		    sValAttrib = "" ;

		    while ((i < strlen(sData.c_str())) && (sData[i] != ' ') && (sData[i] != '\t'))
			    sNomAttrib += pseumaj(sData[i++]) ;
		    while ((i < strlen(sData.c_str())) && ((sData[i] == ' ') || (sData[i] == '\t')))
			    i++ ;

		    while ((i < strlen(sData.c_str())) && (sData[i] != '\n'))
			    sValAttrib += sData[i++] ;

		    i++ ;

		    if      ((sNomAttrib == "WORKDIR") && (sValAttrib != ""))
          strcpy(Environnement.szWorkDir, sValAttrib.c_str()) ;
        else if ((sNomAttrib == "INIFILE") && (sValAttrib != ""))
          strcpy(Environnement.szIniFile, sValAttrib.c_str()) ;
        else if ((sNomAttrib == "LANG") && (sValAttrib != ""))
          strcpy(Environnement.szLang, sValAttrib.c_str()) ;
        else if ((sNomAttrib == "CLIENTNAME") && (sValAttrib != ""))
          strcpy(Environnement.szClientName, sValAttrib.c_str()) ;
        else if ((sNomAttrib == "FORCELOCALINIT") && (sValAttrib != ""))
		    {
				  sValAttrib = pseumaj(sValAttrib) ;
          if ((string("TRUE") == sValAttrib) ||
              (string("YES") == sValAttrib)  ||
              (string("OUI") == sValAttrib)  ||
              (string("1") == sValAttrib))
            Environnement.bForceLocalInit = TRUE ;
          else
            Environnement.bForceLocalInit = FALSE ;
        }
      }
      bUseEnvironnement = true ;
    }
//	}

#ifdef __EPIPUMP__
# ifndef __EPIBRAIN__
  IHEGlobal::PrintReport("DBI Init") ;
# endif
#endif

  DBIResult Err_DBI ;

  if (bUseEnvironnement)
    Err_DBI = DbiInit(&Environnement) ;
  else
    Err_DBI = DbiInit(NULL) ;

  if (DBIERR_NONE != Err_DBI)
  {
    statut = 1 ;
#ifdef __EPIPUMP__
# ifndef __EPIBRAIN__
    IHEGlobal::PrintError("bdeError, cannotInitEngine") ;
# endif
#endif

    string sErreur = getText("bdeError", "cannotInitEngine") ;

    if (DBIERR_MULTIPLEINIT	== Err_DBI)
    {
      sErreur += string(": Illegal attempt to initialize BDE more than once.") ;
      Err_DBI = 0 ;
    }
    else if (DBIERR_NOCONFIGFILE	== Err_DBI)
    {
      sErreur += string(": No config file.") ;
      Err_DBI = 0 ;
    }

    trace(&sErreur, 1, NSSuper::trError) ;
    erreur(sErreur.c_str(), fatalError, Err_DBI) ;
    return false ;
  }

  // Utilisation du debugger
  // DbiDebugLayerOptions(DEBUGON | OUTPUTTOFILE | FLUSHEVERYOP, "trace.inf");

#ifdef __EPIPUMP__
# ifndef __EPIBRAIN__
  IHEGlobal::PrintReport("DBI OpenDatabase") ;
# endif
#endif

  // IDAPI est initialis�. Ouverture d'une database standard
  Err_DBI = DbiOpenDatabase(NULL, NULL, dbiREADWRITE, dbiOPENSHARED, NULL, 0, NULL, NULL, hNSdb) ;
  if (Err_DBI != DBIERR_NONE)
  {
    statut = 1 ;
#ifdef __EPIPUMP__
# ifndef __EPIBRAIN__
    IHEGlobal::PrintError("bdeError, cannotInitDatabase") ;
# endif
#endif
    string sErreur = getText("bdeError", "cannotInitDatabase") ;
    trace(&sErreur, 1, NSSuper::trError) ;
    erreur(sErreur.c_str(), fatalError, Err_DBI) ;
    return false ;
  }
  statut = 0 ;

#ifdef __EPIPUMP__
# ifndef __EPIBRAIN__
  IHEGlobal::PrintReport("InitPathBase") ;
# endif
#endif
  // On r�cup�re les chemins d'acc�s aux bases
  if (!InitPathBase(pCtx))
  {
#ifdef __EPIPUMP__
# ifndef __EPIBRAIN__
  	IHEGlobal::PrintError("InitPathBase failed") ;
# endif
#endif
    return false ;
  }

#ifdef __EPIPUMP__
# ifndef __EPIBRAIN__
  IHEGlobal::PrintReport("InitParite") ;
# endif
#endif
  // parite Franc / Euro
  if (!InitParite())
  {
#ifdef __EPIPUMP__
# ifndef __EPIBRAIN__
  	IHEGlobal::PrintError("InitParite failed") ;
# endif
#endif
    return false ;
  }

#ifdef __EPIPUMP__
# ifndef __EPIBRAIN__
  IHEGlobal::PrintReport("Database init - done") ;
# endif
#endif
  ps = string("Database init - done") ;
  trace(&ps, 1, trSteps) ;

  return true ;
}
bool
NSSuper::InitialiseJava(){  //  // First, make certain that error/warning messages won't be hidden by the
  // splash screen
  //
  HWND hWnd = 0 ;
	TSplashWindow* pSplashWin = pNSApplication->getSplashWindow() ;
	if (NULL != pSplashWin)
  	hWnd = pSplashWin->GetHandle() ;
	pNSApplication->sendMessageToSplash("Init java") ;  pNSApplication->setSplashPercentDone(10) ;	string ps = string("Java init - begin") ;	trace(&ps, 1, trSteps) ;	ps = string("Java init : opening file pilot.dat") ;	trace(&ps, 1, trSubSteps) ;	ifstream inFile ;	inFile.open("pilot.dat") ;	if (!inFile)
	{
		string sErreur = getText("pilotManagement", "cannotOpenPilot.dat") ;
    trace(&sErreur, 1, NSSuper::trError) ;
		erreur(sErreur.c_str(), standardError, 0, hWnd) ;
    bJavaOk = false ;
		return false ;
	}
	inFile.close() ;
	ps = string("Java init : JavaSystem::Init") ;	trace(&ps, 1, trSubSteps) ;	//=== Pilot initialisations
	char* propertyFile = NULL ; //by default Pilot.properties
	if (JavaSystem::Init(pSuperContext, "pilot.properties", false))
	{
		string sErreur = getText("pilotManagement", "cannotInitJavaMachine") ;
    trace(&sErreur, 1, NSSuper::trError) ;
		erreur(sErreur.c_str(), standardError, 0, hWnd) ;
    bJavaOk = false ;
		return false ;	}

	ps = string("Java init : Pilot::Init") ;
	trace(&ps, 1, trSubSteps) ;

	if (propertyFile)
  	ps = string("property file : ") + string(propertyFile) ;
	else
		ps = string("property file : NULL") ;
	trace(&ps, 1, trDetails) ;

	int stat = Pilot::Init(propertyFile) ;
	if (stat < 0)
	{
  	string sErreur = getText("pilotManagement", "cannotInitPilot") ;
    trace(&sErreur, 1, NSSuper::trError) ;
		erreur(sErreur.c_str(), standardError, 0, hWnd) ;
  	switch (stat)
    {
        case -1  : ps = string("Cannot locate the pilot/Pilot class. Exiting....") ; break ;
        case -2  : ps = string("Cannot locate the setParametersFromFile method. Exiting...") ; break ;
        case -3  : ps = string("Cannot locate the init method. Exiting...") ; break ;
        case -4  : ps = string("jenv is NULL. Exiting...") ; break ;
        default  : ps = string("Unknown error.") ;
    }
    trace(&ps, 1, trError) ;
    bJavaOk = false ;
		return false ;
	}

	char szInfo[33] ;
	itoa(stat, szInfo, 10) ;
	ps = string("Pilot init - nb of agents : ") + string(szInfo) ;
	trace(&ps, 1, trDetails) ;

	//use defaultServiceDirectory
	stat = Pilot::AddServicesFromDirectory(NULL) ;
	if (!stat)
	{
		string sErreur = getText("pilotManagement", "cannotAddServices") ;
    trace(&sErreur, 1, NSSuper::trError) ;
		erreur(sErreur.c_str(), standardError, 0, hWnd) ;
	}	itoa(stat, szInfo, 10) ;	ps = string("Pilot init - nb of services : ") + string(szInfo) ;
	trace(&ps, 1, trDetails) ;
	ps = string("Java init : NautilusPilot::Init") ;
	trace(&ps, 1, trSubSteps) ;

	stat = NautilusPilot::Init() ;
	if (stat)
	{
		itoa(stat, szInfo, 10) ;
		string sErreur = getText("pilotManagement", "cannotInitNautilusPilot") + string(" ") + szInfo ;
    trace(&sErreur, 1, NSSuper::trError) ;
		erreur(sErreur.c_str(), standardError, 0, hWnd) ;

		if ( stat < 0 )
		{
			string sErreur = getText("pilotManagement", "cannotInitPilot") ;
      trace(&sErreur, 1, NSSuper::trError) ;
      switch (stat)
      {
        case -1  : ps = string("Cannot locate the nautilus/NautilusPilot class. Exiting...") ; break ;
        case -2  : ps = string("Cannot locate the nautilus/NautilusGraph class. Exiting...") ; break ;
        case -3  : ps = string("Cannot locate the graphServer/Node class. Exiting...") ; break ;
        case -4  : ps = string("Cannot locate the graphServer/Mapping class. Exiting...") ; break ;
        case -5  : ps = string("Cannot locate the domlightwrapper/DOMElement class. Exiting...") ; break ;
        case -6  : ps = string("Cannot locate the NautilusPilot readGraph method. Exiting...") ; break ;
        case -7  : ps = string("Cannot locate the NautilusPilot writeGraph method. Exiting...") ; break ;
        case -8  : ps = string("Cannot locate the NautilusPilot invokeService method V1. Exiting...") ; break ;
        case -9  : ps = string("Cannot locate the NautilusPilot invokeService method V2. Exiting...") ; break ;
        case -10 : ps = string("Cannot locate the NautilusGraph constructor method. Exiting...") ; break ;
        case -11 : ps = string("Cannot locate the NautilusGraph getTreeId method. Exiting...") ; break ;
        case -12 : ps = string("Cannot locate the NautilusGraph getGraphId method. Exiting...") ; break ;
        case -13 : ps = string("Cannot locate the the java/lang/String class. Exiting...") ; break ;
        case -14 : ps = string("Cannot locate the NautilusPilot init method. Exiting...") ; break ;
        case -15 : ps = string("Cannot get FieldId for mnemo. Exiting...") ; break ;
        case -16 : ps = string("Cannot get FieldId for stack. Exiting...") ; break ;
        case -17 : ps = string("Cannot locate the DOMElement getChildrenElements method. Exiting...") ; break ;
        default  : ps = string("Unknown error.") ;
      }
      trace(&ps, 1, trError) ;

      erreur(sErreur.c_str(), standardError, 0, hWnd) ;
		}
	  bJavaOk = false ;
		return false ;
	}
  bJavaOk = true ;
	return true ;
}

// -----------------------------------------------------------------------------
// Function    : NSSuper::AppelUtilisateur()
// Description : Cr�e l'utilisateur principal.
// Retour      : Aucun
// -----------------------------------------------------------------------------
void
NSSuper::AppelUtilisateur()
{
try
{
	string sPreviousUserLanguage = string("") ;

  // Enregistrement des param�tres de l'utilisateur pr�c�dent
  if (pSuperContext->getUtilisateur() != 0)
  {
  	sPreviousUserLanguage = pSuperContext->getUtilisateur()->donneLang() ;

#ifndef __EPIPUMP__
    if (pEpisodus && pEpisodus->bAutoSave)
    {
      NSPrometheFile PrometCfg(pSuperContext) ;
      PrometCfg.EcrireFichier() ;
    }
#endif // !__EPIPUMP__
	}

  // new NSDataGraph
  // sLogin
  // sPassword
  //initilisation du dataGraph et login+password pour un nouveau utilisateur

  // Mise en place du nouvel utilisateur
  NSDataGraph*     pDataGraph = new NSDataGraph(pSuperContext, graphPerson) ;
  NSUtilisateurChoisi* nsUtil = new NSUtilisateurChoisi(pSuperContext, pDataGraph) ;

  int retour = UserLoginNTiersDialog(donneMainWindow(), pSuperContext, nsUtil).Execute() ;

  // Rustine provisoire pour pouvoir utiliser un administrateur
  /****************************************************
  if (nsUtil->sLogin == "")
    nsUtil->sLogin = string(nsUtil->pDonnees->login);
  if (nsUtil->sPasswd == "")
    nsUtil->sPasswd = string(nsUtil->pDonnees->code);
  nsUtil->sUserType = "UA";
  if (nsUtil->sPasswordType == "")
    nsUtil->sPasswordType = "F";
  ********************************************************/

  // cas du changement de mot de passe :
  bool bPwdOk = true ;
  if (nsUtil->pwdNeedChange())
    bPwdOk = nsUtil->changePassword() ;
  if (!bPwdOk)
    retour = IDCANCEL ;

  // Choix OK dans la boite de dialogue
  if (IDOK != retour)
  {
  	delete nsUtil ;
    delete pDataGraph ;
    return ;
	}

  // Destruction de l'utilisateur pr�c�dent
  // la transaction est ferm�e automatiquement
  // le patient est d�truit
  //
  // Putting out previous user
  // Current transaction is automatically closed, and current patient put out
  //
  if (pSuperContext->getUtilisateur() != 0)
  {
    delete pSuperContext->getUtilisateur() ;
    pSuperContext->setUtilisateur(0) ;
  }

  string ps ;

  // Mise en place du nouvel utilisateur
  // Putting new user in place
  //
  ps = string("Setting new user") ;
  trace(&ps, 1, trDetails) ;

  pSuperContext->setUtilisateur(nsUtil) ;
  pSuperContext->getDico()->UserChanged() ;

  ps = string("Getting localization strings for new user") ;
  trace(&ps, 1, trDetails) ;

  string sNewUserLanguage = pSuperContext->getUtilisateur()->donneLang() ;
  loadLocalisationString(sNewUserLanguage) ;

  ps = string("Initializing mail information for new user") ;
  trace(&ps, 1, trDetails) ;

  pSuperContext->getUtilisateur()->initMail() ;

  if (sPreviousUserLanguage != sNewUserLanguage)
  {
    HACCEL hAccelerator ;
    getApplication()->setMenu(string(""), &hAccelerator) ;
  }

  ps = string("Setting up tool bar for new user") ;
  trace(&ps, 1, trDetails) ;

  pSuperContext->getUtilisateur()->setupToolbar() ;
  bool bServiceMode = true ;

#ifndef __EPIPUMP__
  if (pEpisodus)
  {
    ps = string("UserChanged for Episodus") ;
    trace(&ps, 1, trDetails) ;

    pEpisodus->UserChanged() ;
  }

#ifndef __EPIBRAIN__
  if (pDPIO)
  {
    ps = string("UserChanged for Dpio") ;
    trace(&ps, 1, trDetails) ;

    pDPIO->UserChanged() ;
  }
#endif // !__EPIBRAIN__

  if (string("") != pEpisodus->sServiceUrl)
  {
    ps = string("Creating WebServices : ") + pEpisodus->sServiceUrl ;
    trace(&ps, 1, trDetails) ;

    pSuperContext->pWebServiceWindow = new NSWebServiceWindow(donneMainWindow(), pEpisodus->sServiceUrl, pSuperContext) ;
    pSuperContext->pWebServiceChild  = new NSWebServiceChild(pSuperContext, *(getApplication()->prendClient()), pEpisodus->sServiceTitle.c_str(), pSuperContext->pWebServiceWindow) ;
    pSuperContext->pWebServiceChild->Create() ;
  }
#endif // !__EPIPUMP__

  if (bInitInstance)
  {
    ps = string("Unlocking the console") ;
    trace(&ps, 1, trDetails) ;

    pSuperContext->getUtilisateur()->debloqueConsole() ;
    bInitInstance = false ;
  }

  /*
  if(pSuperContext->getUtilisateur()->sPasswordType == "T")
  {
    string sErrorText = pSuperContext->getSuperviseur()->getText("N_TIERS", "passwordMustBeChanged") ;
    if (sErrorText == "")
      sErrorText = "Il faut changer votre mot de passe" ;
    erreur(sErrorText.c_str(), 0, 0, 0) ;

    if (!pSuperContext->getUtilisateur()->Modifier(pSuperContext->GetMainWindow()))
      erreur("Erreur � la modification d'un nouvel utilisateur", 0, 0) ;
  }
  */

  // Appel du patient
  if ((bPwdOk) && (pSuperContext->getUtilisateur()->isUser()))
  {
    ps = string("Calling for a patient") ;
    trace(&ps, 1, trDetails) ;

    pSuperContext->getUtilisateur()->AppelPatient() ;
  }
}
catch (...)
{
	erreur("Exception NSSuper::AppelUtilisateur.", standardError, 0) ;
}
}

// -----------------------------------------------------------------------------
// Function     : NSSuper::FermeDatabase()
// -----------------------------------------------------------------------------
// Description  : Ferme le moteur IDAPI.
// -----------------------------------------------------------------------------
// Retour       : Aucun
// -----------------------------------------------------------------------------
void
NSSuper::FermeDatabase()
{
  // D�truit le moteur IDAPI et la database.
  erreur("", fatalError, DbiCloseDatabase(hNSdb)) ;
  DbiDebugLayerOptions(NULL, NULL) ;
  erreur("", fatalError, DbiExit()) ;
}

void
NSSuper::traceInstanceCounters()
{
	char msg[255] ;
  string sMsg[11] ;
  int i = 0 ;
  //
	// Counters from NautilusPilot.hpp
  //
	// NSBasicAttribute basicAttr ;
  // long l_NSBasicAttribute = basicAttr.ObjectCount - 1 ;
  sprintf(msg, "Count for NSBasicAttribute : %d", NSBasicAttribute::getNbInstance()) ;
  sMsg[i++] = string(msg) ;

  //NSBasicAttributeArray basicAttrArray ;
  //long l_NSBasicAttributeArray = basicAttrArray.lObjectCount - 1 ;
  sprintf(msg, "Count for NSBasicAttributeArray : %d", NSBasicAttributeArray::getNbInstance()) ;
  sMsg[i++] = string(msg) ;

  //NSPersonsAttributesArray personsAttrArray ;
  //long l_NSPersonsAttributesArray = personsAttrArray.lObjectCount - 1 ;
  sprintf(msg, "Count for NSPersonsAttributesArray : %d", NSPersonsAttributesArray::getNbInstance()) ;
  sMsg[i++] = string(msg) ;

  //
  // counters from nsmanager.h
  //
	//NSDataTree dataTree ;
  //long l_NSDataTree = dataTree.lObjectCount - 1 ;
  sprintf(msg, "Count for NSDataTree : %d", NSDataTree::getNbInstance()) ;
  sMsg[i++] = string(msg) ;

	//NSDataTreeArray dataTreeArray ;
  //long l_NSDataTreeArray = dataTreeArray.lObjectCount - 1 ;
  sprintf(msg, "Count for NSDataTreeArray : %d", NSDataTreeArray::getNbInstance()) ;
  sMsg[i++] = string(msg) ;

	//NSDataGraph dataGraph ;
  //long l_NSDataGraph = dataGraph.lObjectCount - 1 ;
  sprintf(msg, "Count for NSDataGraph : %d", NSDataGraph::getNbInstance()) ;
  sMsg[i++] = string(msg) ;

	//NSObjectGraphManager objectGraphManager ;
  //long l_NSObjectGraphManager = objectGraphManager.lObjectCount - 1 ;
  sprintf(msg, "Count for NSObjectGraphManager : %d", NSObjectGraphManager::getNbInstance()) ;
  sMsg[i++] = string(msg) ;

	//NSPersonGraphManager personGraphManager ;
  //long l_NSPersonGraphManager = personGraphManager.lObjectCount - 1 ;
  sprintf(msg, "Count for NSPersonGraphManager : %d", NSPersonGraphManager::getNbInstance()) ;
  sMsg[i++] = string(msg) ;

  //
  // counters from nspatpat.h
  //
	//NSPatPathoInfo patPathoInfo ;
  //long l_NSPatPathoInfo = patPathoInfo.lObjectCount - 1 ;
  sprintf(msg, "Count for NSPatPathoInfo : %d", NSPatPathoInfo::getNbInstance()) ;
  sMsg[i++] = string(msg) ;

	//NSPatPathoArray patPathoArray ;
  //long l_NSPatPathoArray = patPathoArray.lObjectCount - 1 ;
  sprintf(msg, "Count for NSPatPathoArray : %d", NSPatPathoArray::getNbInstance()) ;
  sMsg[i++] = string(msg) ;

	//NSVectPatPathoArray vectPatPathoArray ;
  //long l_NSVectPatPathoArray = vectPatPathoArray.lObjectCount - 1 ;
  sprintf(msg, "Count for NSVectPatPathoArray : %d", NSVectPatPathoArray::getNbInstance()) ;
  sMsg[i++] = string(msg) ;

  // trace
  trace(sMsg, i, trSubDetails) ;
}

// -----------------------------------------------------------------------------
// Fonction     : NSSuper::estEgal(string *pChaine, string *pModele)
// -----------------------------------------------------------------------------
// Description  : Teste l'�quivalence des deux chaines.
// -----------------------------------------------------------------------------
// Retour       :	true si les chaines sont �quivalentes, false sinon
// -----------------------------------------------------------------------------
bool
NSSuper::estEgal(string* pChaine, string* pModele)
{
  // Cas simple : �galit� stricte
  if (*pChaine == *pModele)
    return true ;

  // On compare les deux chaines de gauche � droite, jusqu'� trouver
  // un �l�ment du mod�le qui ne se ram�ne pas � un �l�ment de la chaine
  // par une relation "est un"
  string Chaine = *pChaine ;
  string Modele = *pModele ;

  // On "simplifie" les chaines en supprimant les redondances
  // (par exemple "ETT/Valve cardiaque/Mitrale" devient "ETT/Mitrale")
	return false ;
}


// -----------------------------------------------------------------------------
// Function     : NSSuper::InitParite()
// -----------------------------------------------------------------------------
// Arguments    : Aucun
// -----------------------------------------------------------------------------
// Description  : Initialise la parite Franc / Euro d'apres Euro.dat
// -----------------------------------------------------------------------------
// Returns      : True : Succ�s, False : Echec
// -----------------------------------------------------------------------------
bool
NSSuper::InitParite()
{
	// Attention : ne pas passer le Handle de la MainWindow aux fonctions erreur
	// dans InitParite car � ce stade, la MainWindow n'est pas encore instanci�e
	ifstream inFile ;
	string line ;
	string sData      = "" ;
	string sNomAttrib = "" ;
	string sValAttrib = "" ;
	size_t i = 0 ;
	string sOut = "" ;

	inFile.open("euro.dat");
	if (!inFile)
	{
		erreur("Erreur d'ouverture du fichier euro.dat.", standardError, 0) ;
    return false ;
	}

	while (!inFile.eof())
	{
  	getline(inFile,line) ;
    if (line != "")
    	sData += line + "\n" ;
	}

	inFile.close() ;

	// boucle de chargement des attributs de compta
	while (i < strlen(sData.c_str()))
	{
  	sNomAttrib = "" ;
    sValAttrib = "" ;

    while ((i < strlen(sData.c_str())) && (sData[i] != ' ') && (sData[i] != '\t'))
    	sNomAttrib += pseumaj(sData[i++]) ;

    while ((strlen(sData.c_str())) && ((sData[i] == ' ') || (sData[i] == '\t')))
    	i++ ;

    while ((strlen(sData.c_str())) && (sData[i] != '\n'))
    	sValAttrib += sData[i++] ;

    i++ ;

    if 		((sNomAttrib == "PARITE") && (sValAttrib != ""))
    {
    	// Parit� monnaie locale / euros
      parite = atof(sValAttrib.c_str()) ;

      if (parite == 0)
      {
      	erreur("La parit� Franc / Euro n'est pas initialis�e par euro.dat", standardError, 0) ;
        parite = 6.5596 ;
      }
    }
    else if ((sNomAttrib == "MONNAIE") && (sValAttrib != ""))
    {
    	if (sValAttrib == "EURO")
      	monnaieRef = MONNAIE_EURO ;
      else
      	monnaieRef = MONNAIE_LOCALE ;
    }
    else if ((sNomAttrib == "SIGLE") && (sValAttrib != ""))
    {
    	// sigle de la monnaie locale
      sigle = sValAttrib ;
    }
    else if ((sNomAttrib == "AUTO") && (sValAttrib != ""))
    {
    	// compta automatique
      if ((sValAttrib == string("oui")) || (sValAttrib == string("OUI")))
      	bComptaAuto = true ;
      else
      	bComptaAuto = false ;
    }
    else if ((sNomAttrib == "NOCCAMCR") && (sValAttrib != ""))
    {
    	// pas de CCAM pour les comptes rendus
      if ((sValAttrib == string("oui")) || (sValAttrib == string("OUI")))
      	bNoCCAMforReport = true ;
      else
      	bNoCCAMforReport = false ;
    }
    else if ((sNomAttrib == "NOCCAMCS") && (sValAttrib != ""))
    {
    	// pas de CCAM pour les consultations
      if ((sValAttrib == string("oui")) || (sValAttrib == string("OUI")))
      	bNoCCAMforExam = true ;
      else
      	bNoCCAMforExam = false ;
    }
    else if ((sNomAttrib == "INDICE") && (sValAttrib != ""))
    {
    	// indice de consultation
      indiceConsult = sValAttrib ;
    }
    else if ((sNomAttrib == "EXPORT") && (sValAttrib != ""))
    {
    	// dll d'exportation automatique � la sauvegarde
      sExport_dll = sValAttrib ;
    }
    else if ((sNomAttrib == "CODEAUTO") && (sValAttrib != ""))
    {
    	// compta automatique
      if ((sValAttrib == string("oui")) || (sValAttrib == string("OUI")))
      	bCodageAuto = true ;
      else
      	bCodageAuto = false ;
    }
    else if ((sNomAttrib == "NOM_MODULE") && (sValAttrib != ""))
    {
    	// nom officiel du module
      sNomModule = sValAttrib ;
    }
    else if ((sNomAttrib == "DIFFUSEUR") && (sValAttrib != ""))
    {
    	// nom officiel du module
      sDiffuseur = sValAttrib ;
    }
    else if ((sNomAttrib == "URL_DIFFUSEUR") && (sValAttrib != ""))
    {
    	// nom officiel du module
      sURLDiffuseur = sValAttrib ;
    }
    else if ((sNomAttrib == "IPP_SITE") && (sValAttrib != ""))
    {
    	// reference site for Patien's permanent identifier
      sIppSite = sValAttrib ;
    }
    else if ((sNomAttrib == "OPERATION_SITE") && (sValAttrib != ""))
    {
    	// operational site code
      sOperationalSite = sValAttrib ;
    }
    else if ((sNomAttrib == "DEMOGRAPHIC") && (sValAttrib != ""))
    {
    	// demographic archetype
      sDemographicArchetypeId = sValAttrib ;
    }
	}
	return true ;
}

//---------------------------------------------------------------------------------------//  Function: NSSuper::InitPathBase()
//  Arguments:	  Aucun
//  Description: Initialise le tableau sPathBase avec les chemins d'acc�s aux bases
//  Returns:     True : Succ�s, False : Echec
//---------------------------------------------------------------------------------------
bool
NSSuper::InitPathBase(NSContexte* pCtx)
{
try
{
	// Setting default values
  //
  iTrace        = trWarning ;
  iTraceConsole = trNone ;

	// Attention : ne pas passer le Handle de la MainWindow aux fonctions erreur
	// dans InitPathBase car � ce stade, la MainWindow n'est pas encore instanci�e

	// On initalise � vide sPathBase
	for (int k = 0; k < NB_CHEMINS_BASES; k++)		sPathBase[k] = "" ;

	// On r�cup�re d'abord le chemin de la base des chemins
	// NOTE : chemins.dat est obligatoirement � la racine
	// --- on ne doit pas pr�ciser de chemin pour ce fichier ---
  ifstream inFile ;
  inFile.open("chemins.dat") ;
  if (!inFile)
  {
  	erreur("Erreur d'ouverture du fichier chemins.dat.", standardError, 0) ;
    return false ;
	}

  string sFichierDat = string("") ;

  string line ;
	while (!inFile.eof())
	{
  	getline(inFile, line) ;
    if (line != "")
    	sFichierDat += line + "\n" ;
	}
	inFile.close() ;

  size_t i ;

	// num�ro de console
  //
  string sConsole = string("") ;
	for (i = 0; (i < strlen(sFichierDat.c_str())) && (sFichierDat[i] != '\n'); i++)
		sConsole += sFichierDat[i] ;

	if (strlen(sConsole.c_str()) <= 2)
	{
  	strcpy(noConsole, sConsole.c_str()) ;
    //
    // Num�ro de console flottant
    //
    if (sConsole[0] == '?')
    {
    	char chConsole = sConsole[1] ;
      chConsole++ ;
      if (chConsole < '0')
      	chConsole = '0' ;
      else if ((chConsole > '9') && (chConsole < 'A'))
      	chConsole = 'A' ;
      else if (chConsole > 'Z')
      	chConsole = '0' ;

      sFichierDat[1] = chConsole ;

      ofstream outFile ;
      outFile.open("chemins.dat", ios::out) ;
      if (!outFile)
      {
      	string sErrMess = string("Erreur d'ouverture en �criture du fichier chemins.dat") ;
        erreur(sErrMess.c_str(), standardError, 0) ;
      }
      else
      {
      	outFile.write(sFichierDat.c_str(), strlen(sFichierDat.c_str())) ;
        outFile.close() ;
      }
    }
  }
  else
  {
  	erreur("Num�ro de console erron� dans chemins.dat.", standardError, 0) ;
    return false;
	}

	// chemin de la base des chemins
	for (i = i+1; (i < strlen(sFichierDat.c_str())) && (sFichierDat[i] != '\n'); i++)
  	sPathBase[0] += sFichierDat[i] ;

	if (!strlen(sPathBase[0].c_str()))
  {
  	erreur("Chemin absent dans chemins.dat.", standardError, 0) ;
    return false;
	}

	// Mode trace : s'il y a un 'T'
  //
  string sModeTrace = string("") ;
	for (i = i+1; (i < strlen(sFichierDat.c_str())) && (sFichierDat[i] != '\n'); i++)
  	sModeTrace += sFichierDat[i] ;

	size_t iTraceStrLen = strlen(sModeTrace.c_str()) ;
	if ((iTraceStrLen > 0) && ((sModeTrace[0] == 'T') || (sModeTrace[0] == 't')))
	{
  	iTrace = trDetails ;
    if ((iTraceStrLen > 1) && (isdigit(sModeTrace[iTraceStrLen-1])))
    {
    	char szTraceLevel[2] ;
      szTraceLevel[0] = sModeTrace[iTraceStrLen-1] ;
      szTraceLevel[1] = '\0' ;
      int iLevel = atoi(szTraceLevel) ;
      switch(iLevel)
      {
        case 0  : iTrace = trError ;      break ;
        case 1  : iTrace = trWarning ;    break ;
        case 2  : iTrace = trSteps ;      break ;
        case 3  : iTrace = trSubSteps ;   break ;
        case 4  : iTrace = trDetails ;    break ;
        case 5  : iTrace = trSubDetails ; break ;
        default :
          if (iLevel > 5)
            iTrace = trSubDetails ;
          else
            iTrace = trNone ;
      }
    }
	}

	// Console trace : s'il y a un 'C'
  //
	string sConsoletrace = string("") ;
	for (i = i+1; (i < strlen(sFichierDat.c_str())) && (sFichierDat[i] != '\n'); i++)
		sConsoletrace += sFichierDat[i];

	size_t iTraceStrLenConsole = strlen(sConsoletrace.c_str()) ;
	if ((iTraceStrLenConsole > 0) && (sConsoletrace[0] == 'C'))
	{
  	iTraceConsole = trDetails ;
    if ((iTraceStrLenConsole > 1) && (isdigit(sModeTrace[iTraceStrLen-1])))
    {
    	char szTraceLevelC[2] ;
      szTraceLevelC[0] = sConsoletrace[iTraceStrLen-1] ;
      szTraceLevelC[1] = '\0' ;
      int iLevel = atoi(szTraceLevelC) ;
      switch(iLevel)
      {
        case 0  : iTraceConsole = trError ;      break ;
        case 1  : iTraceConsole = trWarning ;    break ;
        case 2  : iTraceConsole = trSteps ;      break ;
        case 3  : iTraceConsole = trSubSteps ;   break ;
        case 4  : iTraceConsole = trDetails ;    break ;
        case 5  : iTraceConsole = trSubDetails ; break ;
        default :
          if (iLevel > 5)
            iTraceConsole = trSubDetails ;
          else
            iTraceConsole = trNone ;
      }
    }
	}

	if (iTraceConsole != trNone)
  	StartDebugConsole(80, 20, "") ;

	if ((iTraceStrLenConsole > 0) && ((sConsoletrace[0] == 'G') || (sConsoletrace[0] == 'I')))
	{
  	bModeClientGroup    = true;
    if (sConsoletrace[0] == 'I')
    	bGroupInterfaceOnly = true ;
    else
    	bGroupInterfaceOnly = false ;
	}
	else
	{
  	// Mode Client Group : s'il y a un 'G'
    //
    string sClientGroup = string("") ;
    for (i = i+1; (i < strlen(sFichierDat.c_str())) && (sFichierDat[i] != '\n'); i++)
    	sClientGroup += sFichierDat[i] ;

    size_t iClientGroupStrLen = strlen(sClientGroup.c_str()) ;
    if ((iClientGroupStrLen > 0) && ((sClientGroup[0] == 'G') || (sClientGroup[0] == 'I')))
    {
    	bModeClientGroup = true ;
      if (sConsoletrace[0] == 'I')
      	bGroupInterfaceOnly = true ;
      else
      	bGroupInterfaceOnly = false ;
    }
  }

  string sCodeChemin[NB_CHEMINS_BASES - 1] = {"BGLO","BPAR","BPER","BCPT","BGUI"} ;
  InitialiseFileDatabase() ;
  for (int j = 1; j < NB_CHEMINS_BASES; j++)
  {
  	std::string key = std::string(sCodeChemin[j-1]);
    std::string support = _PathDB->getLocalText(key, std::string("$SUPPORT"));
    std::string chemin = _PathDB->getLocalText(key, std::string("$CHEMIN"));
    if (support != "")
    {
    	NSSupportsInfo SuppInfo ;
      if (chercheSupportsInfo(support, &SuppInfo, pCtx))
      	sPathBase[j] = SuppInfo.getRootPath() ;
      sPathBase[j] += chemin ;
    }
  }

	paSkins->init(pCtx->PathName("FSKN", 0, false /* verbose */)) ;

	return true ;
}
catch (...)
{
    erreur("Exception NSSuper::InitPathBase.", standardError, 0) ;
    return NULL;
}
}

//---------------------------------------------------------------------------------------
//  Function: NSSuper::PathNameType(string sTypeFichier, string& sLocalis, string& sUnite, string& sServeur)
//  Arguments:	  sTypeFichier : Type de fichier dont on veut trouver le chemin
//  Description: Retrouve le chemin correspondant au type + les infos de support
//  Returns:     Une string contenant le chemin RELATIF
//---------------------------------------------------------------------------------------
string
NSSuper::PathNameType(string sTypeFichier, string& sLocalis, string& sUnite, string& sServeur, NSContexte* pCtx)
{
try
{
	if (_PathDB->empty() )
  	return "" ;

	for (NSLocalChapterArrayIter iter = _PathDB->begin(); iter !=  _PathDB->end(); iter++)
  	if ( (*iter).second->getLocalText("$TYPE_DOC") ==   sTypeFichier)
    {
    	std::string support =  (*iter).second->getLocalText("$SUPPORT");
      NSSupportsInfo SuppInfo ;
      if (!chercheSupportsInfo(support, &SuppInfo, pCtx))
      {
      	erreur("echec de la fonction PathNameType", standardError, 0) ;
        return "" ;
      }
      sServeur    = SuppInfo.getRootPath() ;
      sUnite			= "" ;
      std::string sPath = (*iter).second->getLocalText("$CHEMIN") ;
      sLocalis =(*iter).first ;
      return sPath ;
    }

	return "";
}
catch (...)
{
	erreur("Exception NSSuper::PathNameType.", standardError, 0) ;
	return NULL ;
}
}

//---------------------------------------------------------------------------------------
//  Function: NSSuper::ReferenceTousArchetypes()
//  Description: Reference automatiquement les archetypes et les referentiels
//  Returns:     void
//---------------------------------------------------------------------------------------
void
NSSuper::ReferenceTousArchetypes()
{
try
{
	string ps = string("New Archetypes management - begin") ;
	trace(&ps, 1, trDetails) ;	string sSysImportPath = pSuperContext->PathName("INEW") ;
  if (sSysImportPath == "")
  {
  	ps = string("Can't find SysImport Path - exiting new Archetypes management") ;
		trace(&ps, 1, trWarning) ;
    return ;
  }

  string sPathName = pSuperContext->PathName("IXML") ;
  if (sPathName == "")
  {
  	ps = string("Can't find Archetypes Path - exiting new Archetypes management") ;
		trace(&ps, 1, trWarning) ;
    return ;
  }

  string sStatusMsg = getText("archetypesManagement", "automaticReferencing") ;  afficheStatusMessage((char*) sStatusMsg.c_str()) ;  string sStatusBase = getText("archetypesManagement", "referencingOf") ;  string sStatusString = "" ;  // Recherche des fichier .xml dans SysImport  // Looking for xml files in SysImport directory  char szMask[1024] ;  strcpy(szMask, sSysImportPath.c_str()) ;  strcat(szMask, "*.xml") ;
  WIN32_FIND_DATA FileData ;
  HANDLE hSearch = FindFirstFile(szMask, &FileData) ;
  if (hSearch == INVALID_HANDLE_VALUE)  {    sStatusMsg = getText("archetypesManagement", "noNewArchetype") ;    afficheStatusMessage((char*) sStatusMsg.c_str()) ;    ps = string("No new Archetype - exiting") ;		trace(&ps, 1, trSubDetails) ;    return ;  }
  pSuperContext->GetMainWindow()->SetCursor(0, IDC_WAIT) ;

  bool bFinish = false ;
  while (!bFinish)
  {    DWORD dwAttr = FileData.dwFileAttributes;
    if (!(dwAttr & FILE_ATTRIBUTE_DIRECTORY))
    {      string                sFileName = string(FileData.cFileName) ;      string                sXML = sSysImportPath + sFileName ;      string                sNomArc ;      NSArcManager::TYPEARC	iTypeArc ;      ps = string("File : ") + sFileName ;      trace(&ps, 1, trSubDetails) ;      if (!pArcManager->ExisteFichierArchetype(sFileName, sPathName, sNomArc, iTypeArc))      {      	nsarcParseur ArcParseur(pSuperContext, false) ;        if (ArcParseur.open(sXML))        {
          sStatusString = sStatusBase + sXML ;
          afficheStatusMessage((char*) sStatusString.c_str()) ;

          ps = string("- Referencing as Archetype with ID : ") + ArcParseur.pArchetype->getName() ;
      		trace(&ps, 1, trSubDetails) ;

          pArcManager->AjouteArchetype(NSArcManager::archetype, ArcParseur.pArchetype->getName(), sFileName, sPathName) ;
          ::MoveFile(sXML.c_str(), (sPathName + sFileName).c_str()) ;
        }
        else
        {
        	nsrefParseur RefParseur(pSuperContext, false) ;
         	if ((true == RefParseur.open(sXML)) && (NULL != RefParseur.pReferentiel))
        	{
          	sStatusString = sStatusBase + sXML ;
          	afficheStatusMessage((char*) sStatusString.c_str()) ;

            string sTypeName   = string("") ;
            string sDomainName = string("") ;
            Creferences* pRefRef = RefParseur.pReferentiel->getReference() ;
            if (NULL != pRefRef)
            {
            	Cconcern *pConcern = pRefRef->getFirstCconcern() ;
              if (NULL != pConcern)
              {
              	sTypeName   = pConcern->getCode() ;
                sDomainName = pConcern->getCategory() ;
              }
            }

            string sTitle = RefParseur.pReferentiel->getTitle() ;

            ps = string("- Referencing as Referential with ID : ") + RefParseur.pReferentiel->getName() ;
      			trace(&ps, 1, trSubDetails) ;

          	pArcManager->AjouteArchetype(NSArcManager::referentiel, RefParseur.pReferentiel->getName(), sFileName, sPathName, sTypeName, sDomainName, sTitle) ;
          	::MoveFile(sXML.c_str(), (sPathName + sFileName).c_str()) ;
          }
          else
          {
          	ps = string("- Neither an Archetype, nor a Referential") ;
      			trace(&ps, 1, trSubDetails) ;
          }
        }      }      else      {      	ps = string("- Already there : ignored (you might take it out)") ;        trace(&ps, 1, trSubDetails) ;      }    }
    if (!FindNextFile(hSearch, &FileData))    {      if (GetLastError() != ERROR_NO_MORE_FILES)      {      	ps = string("FindNextFile error - exiting") ;				trace(&ps, 1, trError) ;        sStatusMsg = getText("fileErrors", "cantGetNextFile") ;        sStatusMsg += string(" ") + sSysImportPath ;        trace(&sStatusMsg, 1, NSSuper::trError) ;        erreur(sStatusMsg.c_str(), standardError, 0) ;        return ;      }      bFinish = true ;    }  }

  ps = string("New Archetypes management - end") ;
	trace(&ps, 1, trDetails) ;
  afficheStatusMessage("") ;
  pSuperContext->GetMainWindow()->SetCursor(0, IDC_ARROW);
}
catch (...)
{
  erreur("Exception NSSuper::ReferenceTousArchetypes.", standardError, 0) ;
  return ;
}
}

//---------------------------------------------------------------------------------------
//  Function: NSSuper::ReferenceNewFilsGuides()
//  Description: Reference automatiquement les nouveaux fils guides
//  Returns:     void
//---------------------------------------------------------------------------------------
void
NSSuper::ReferenceNewFilsGuides()
{
try
{
	string ps = string("New Fils Guides management - begin") ;
	trace(&ps, 1, trDetails) ;	string sSysImportPath = pSuperContext->PathName("INEW") ;
  if (sSysImportPath == "")
  {
  	ps = string("Can't find SysImport Path - exiting new Fils Guides management") ;
		trace(&ps, 1, trWarning) ;
    return ;
  }

  string sStatusMsg = getText("filsGuidesManagement", "automaticReferencing") ;
  afficheStatusMessage((char*) sStatusMsg.c_str()) ;  string sStatusBase = getText("filsGuidesManagement", "referencingOf") ;  string sStatusString = "" ;  // Recherche des fichier .xml dans SysImport  // Looking for xml files in SysImport directory  char szMask[1024] ;  strcpy(szMask, sSysImportPath.c_str()) ;  strcat(szMask, "*.nsg") ;
  WIN32_FIND_DATA FileData ;
  HANDLE hSearch = FindFirstFile(szMask, &FileData) ;
  if (hSearch == INVALID_HANDLE_VALUE)  {    sStatusMsg = getText("filsGuidesManagement", "noNewFilsGuidesFile") ;    afficheStatusMessage((char*) sStatusMsg.c_str()) ;    ps = string("No new Fils guides file - exiting") ;		trace(&ps, 1, trSubDetails) ;    return ;  }
  pSuperContext->GetMainWindow()->SetCursor(0, IDC_WAIT) ;

  bool bFinish = false ;
  while (!bFinish)
  {    DWORD dwAttr = FileData.dwFileAttributes;
    if (!(dwAttr & FILE_ATTRIBUTE_DIRECTORY))
    {      string	sFileName = string(FileData.cFileName);      string	sNSG = sSysImportPath + sFileName;      ps = string("File : ") + sFileName ;      trace(&ps, 1, trSubDetails) ;      NSGuidesManager guidesManager(pSuperContext) ;      guidesManager.setImportFile(sNSG) ;      if (false == guidesManager.isHeaderValid())      {				ps = string("- Bad header, skipping") ;        trace(&ps, 1, trSubDetails) ;      }      if (false == guidesManager.isSystemGroup())      {				ps = string("- This function only works for system groups, skipping") ;        trace(&ps, 1, trSubDetails) ;      }      else      {      	string sGroup = guidesManager.getGroup() ;        string sGroupDate ;        bool   bError ;        if (guidesManager.doesGroupExist(sGroup, bError, sGroupDate))        	guidesManager.deleteGroup(sGroup) ;      	string sFilGuideLabel = guidesManager.getLabel() ;        sStatusString = sStatusBase + string(" ") + sFilGuideLabel ;        afficheStatusMessage((char*) sStatusString.c_str()) ;      	bool bSuccess = guidesManager.importGroup() ;        if (false == bSuccess)        	ps = string("- Import failed for ") + sFilGuideLabel ;        else        {        	bSuccess = guidesManager.referenceGroup() ;          if (false == bSuccess)        		ps = string("- Import succeeded but referencing failed for ") + sFilGuideLabel ;          else        		ps = string("- Import succeeded for ") + sFilGuideLabel ;          ::DeleteFile(sNSG.c_str()) ;        }
        trace(&ps, 1, trSubDetails) ;      }    }
    if (!FindNextFile(hSearch, &FileData))    {      if (GetLastError() != ERROR_NO_MORE_FILES)      {      	ps = string("FindNextFile error - exiting") ;				trace(&ps, 1, trError) ;        sStatusMsg = getText("fileErrors", "cantGetNextFile") ;        sStatusMsg += string(" ") + sSysImportPath ;        trace(&sStatusMsg, 1, NSSuper::trError) ;        erreur(sStatusMsg.c_str(), standardError, 0) ;        return ;      }      bFinish = true ;    }  }

  ps = string("New Fils guides management - end") ;
	trace(&ps, 1, trDetails) ;
  afficheStatusMessage("") ;
  pSuperContext->GetMainWindow()->SetCursor(0, IDC_ARROW);
}
catch (...)
{
  erreur("Exception NSSuper::ReferenceNewFilsGuides.", standardError, 0) ;
  return ;
}
}

// -----------------------------------------------------------------------------
// Function    : NSSuper::PurgeImpression()
// Description : d�truit automatiquement les fichiers temporaires d'impression
// Returns     : void
// -----------------------------------------------------------------------------
void
NSSuper::PurgeImpression()
{
try
{
	string sUtil = pSuperContext->getUtilisateur()->getNss() ;
	string sTemp = pSuperContext->PathName("FPER") + string("tempo.dat") ;
	string sRes ;

	if (!lireParam(sUtil, sTemp, "KillTmp", sRes))
		return ;

    if (sRes != string("non"))
        return;

    WIN32_FIND_DATA FileData;
    HANDLE          hSearch;    char            szMask[255];    bool            bFinish = false;    size_t          pos;    string          sPathName, sFileName, sExtension;    string          sHTML;    DWORD           dwAttr;    afficheStatusMessage("Purge du r�pertoire d'impression.");    pSuperContext->GetMainWindow()->SetCursor(0, IDC_WAIT);    sPathName = pSuperContext->PathName("SHTM");    strcpy(szMask, sPathName.c_str());    strcat(szMask, "*.*");
    hSearch = FindFirstFile(szMask, &FileData);
    if (hSearch == INVALID_HANDLE_VALUE)        return;    while (!bFinish)    {        dwAttr = FileData.dwFileAttributes;

        if (!(dwAttr & FILE_ATTRIBUTE_DIRECTORY))        {            sFileName = string(FileData.cFileName);            // R�cup�ration de l'extension            pos = sFileName.find(".");        }
        if ((!(dwAttr & FILE_ATTRIBUTE_DIRECTORY)) && (pos != NPOS))        {   	        sExtension = string(sFileName, pos+1, strlen(sFileName.c_str())-pos-1);
            if ((sExtension == "htm") || (sExtension == "HTM"))            {                sHTML = sPathName + sFileName;                if (!DeleteFile(sHTML.c_str()))   		            erreur("Pb de destruction du fichier temporaire d'impression.", standardError, 0) ;
            }        }
        if (!FindNextFile(hSearch, &FileData))        {            if (GetLastError() == ERROR_NO_MORE_FILES)                bFinish = true ;            else            {                erreur("Impossible de trouver le fichier suivant dans le r�pertoire d'impression.", standardError, 0) ;                return ;            }        }    }

    afficheStatusMessage("") ;
    pSuperContext->GetMainWindow()->SetCursor(0, IDC_ARROW);
}
catch (...)
{
    erreur("Exception NSSuper::PurgeImpression.", standardError, 0) ;
    return;
}
}

// -----------------------------------------------------------------------------// Function     : NSSuper::OuvreDocument(NSDocumentInfo& Document)// 				        appelee par ChoixChemiseDialog (NSRechdl)
// -----------------------------------------------------------------------------
// Arguments    :	Document � ouvrir
// -----------------------------------------------------------------------------
// Description  : Attache le document au mod�le Document/Visualisation
// -----------------------------------------------------------------------------
// Returns      : pDocNoy si on peut ouvrir le document, 0 sinon
// -----------------------------------------------------------------------------
NSNoyauDocument
*NSSuper::OuvreDocument(NSDocumentInfo& Document, NSContexte *pCtx, bool bReadOnly)
{
  NSDocumentInfo  *pDocument = &Document ;
  NSDocumentInfo  *pDocHtml  = 0 ;
  NSNoyauDocument *pDocNoy   = 0 ;

	string sTypeDoc = Document.getType() ;

  if (typeDocument(sTypeDoc, NSSuper::isTree))
  {
  	if      (sTypeDoc == "ZCN00")
    	pDocNoy = OuvreDocumentCR(pDocument, pDocHtml, pCtx, bReadOnly) ;
    else if (sTypeDoc == "ZCS00")
    	pDocNoy = OuvreDocumentCS(pDocument, pDocHtml, pCtx, bReadOnly) ;
    else if (sTypeDoc == "ZCQ00")
    	pDocNoy = OuvreDocumentCQ(pDocument, pDocHtml, pCtx, bReadOnly) ;
  }
  else if (typeDocument(sTypeDoc, NSSuper::isText))
  {
  	if     ((sTypeDoc == "ZTRTF") || (sTypeDoc == "ZTHTM"))
    	pDocNoy = OuvreDocumentRTF(pDocument,pDocHtml, pCtx, bReadOnly) ;
    else if (sTypeDoc == "ZTTXT")
    	pDocNoy = OuvreDocumentTXT(pDocument,pDocHtml, pCtx, bReadOnly) ;
    else if (sTypeDoc == "ZTPDF")
    	pDocNoy = OuvreDocumentPDF(pDocument,pDocHtml, pCtx, bReadOnly) ;
  }
  else if (typeDocument(sTypeDoc, NSSuper::isHTML)) // cas des html statiques
  {
  	if ((sTypeDoc == "ZSHTM") || (sTypeDoc == "ZIHTM"))
    	pDocNoy = OuvreDocumentHTML(pDocument, pDocHtml, pCtx, bReadOnly) ;
  }
  else if (typeDocument(sTypeDoc, NSSuper::isImage))
  {
  	// cas des images : g�n�rique pour tous les types d'image
    // y compris les images anim�es (vid�os)
    pDocNoy = OuvreDocumentIMG(pDocument, pDocHtml, pCtx, bReadOnly) ;
  }

  return pDocNoy ;
}


// -----------------------------------------------------------------------------
// Function     : NSSuper::OuvreDocumentCR(NSDocumentInfo Document)
// -----------------------------------------------------------------------------
// Arguments    :	Document � ouvrir
// -----------------------------------------------------------------------------
// Description  : Attache le document au mod�le Document/Visualisation
// -----------------------------------------------------------------------------
// Returns      : true si on peut ouvrir le document, false sinon
// -----------------------------------------------------------------------------
NSNoyauDocument*
NSSuper::OuvreDocumentCR(NSDocumentInfo *pDocument, NSDocumentInfo *pDocHtml, NSContexte *pCtx, bool bReadOnly)
{
try
{
	if (NULL == pDocument)
		return 0 ;

	NSCRDocument *DocVisuDoc = new NSCRDocument(0, pDocument, pDocHtml, pCtx, "", bReadOnly) ;
	if (!DocVisuDoc->bDocumentValide)
	{
  	string sNomDoc  = pDocument->getDocName() ;
    string sCodeDoc = pDocument->getID() ;
    char   msg[255] ;

    sprintf(msg, "Le document %s (code = %s) n'est pas un document valide.", sNomDoc.c_str(), sCodeDoc.c_str()) ;
    erreur(msg, standardError, 0, pSuperContext->GetMainWindow()->GetHandle()) ;
    return 0 ;
	}

  // Avant de pouvoir visualiser un CR, on doit s'assurer qu'il
  // est bien d�cod� dans un fichier de d�codage (pour cr�er le Html)
  //
  if (!DocVisuDoc->IsDecode())
  {
  	if ((DocVisuDoc->decodeCR(&(DocVisuDoc->aCRPhrases))) != 0)
    {
    	erreur("Impossible de d�coder le compte-rendu.", standardError, 0, pSuperContext->GetMainWindow()->GetHandle()) ;
      return 0 ;
    }
	}

  DocVisuDoc->Visualiser() ;
  return DocVisuDoc ;
}
catch (...)
{
  erreur("Exception NSSuper::OuvreDocumentCR.", standardError, 0) ;
  return NULL ;
}
}


// -----------------------------------------------------------------------------
// Function     : NSSuper::OuvreDocumentCS(NSDocumentInfo *pDocument, NSDocumentInfo *pDocHtml)
// -----------------------------------------------------------------------------
// Arguments    : Document � ouvrir
// -----------------------------------------------------------------------------
// Description  : Attache le document au mod�le Document/Visualisation
// -----------------------------------------------------------------------------
// Returns      : true si on peut ouvrir le document, false sinon
// -----------------------------------------------------------------------------
NSNoyauDocument
*NSSuper::OuvreDocumentCS(NSDocumentInfo *pDocument, NSDocumentInfo *pDocHtml, NSContexte *pCtx, bool bReadOnly)
{
try
{
	if (NULL == pDocument)
		return 0 ;

	NSCSDocument *DocVisuDoc = new NSCSDocument(0, pDocument, pDocHtml, pCtx, "", bReadOnly) ;
  if (!DocVisuDoc->bDocumentValide)
  {
    string sNomDoc  = pDocument->getDocName() ;
    string sCodeDoc = pDocument->getID() ;
    char   msg[255] ;

    sprintf(msg, "Le document %s (code = %s) n'est pas un document valide.", sNomDoc.c_str(), sCodeDoc.c_str()) ;
    erreur(msg, standardError, 0, pSuperContext->GetMainWindow()->GetHandle()) ;
    return 0 ;
  }

  // Avant de pouvoir visualiser le document CS
  // on regarde s'il existe une vue d'�dition.
  // sinon, on en cr�e une fictive et on g�n�re le NodeArray pour
  // pouvoir cr�er le html.
  TView   *pView ;
  NSCsVue *pEditView ;

  pView = pSuperContext->getPatient()->pDocHis->ActiveFenetre(DocVisuDoc->pDocInfo, "NSCsVue") ;
  if (pView)
  {
    // en fait, ce cas ne se produit pas en th�orie car si le document est �dit�
    // on ne doit pas pouvoir l'ouvrir par NSSuper::OuvreDocument, on passe
    // directement par Visualiser...
    pEditView = dynamic_cast<NSCsVue *>(pView) ;
  }
  else
  {
    // on cr�e dans ce cas une vue artificielle (invisible)
    // pour cr�er le pNodeArray qui permet d'obtenir le pHtmlCS
    pEditView = new NSCsVue(*DocVisuDoc, pSuperContext->GetMainWindow()) ;
    pEditView->Create() ;
    pEditView->Show(SW_HIDE) ;
  }

  // DocVisuDoc est ici un nouveau document. On se sert de la vue
  // pour lui cr�er un pHtmlCS et on lance Visualiser()
  DocVisuDoc->pHtmlCS = new NSHtml(tCS) ;
	pEditView->InscrireHtml(DocVisuDoc->pHtmlCS) ;
  DocVisuDoc->Visualiser() ;

  // si la vue d'�dition vient d'�tre cr��e, on doit la d�truire ici
  // sinon elle emp�chera la destruction du document car il
  // existera toujours une vue en cours.
  // ATTENTION : il faut obligatoirement avoir au pr�alable
  // lanc� DocVisuDoc->Visualiser() pour cr�er avant une VisualView
  // sinon le document serait d�truit dans la foul�e (...)
  if (!pView)
    delete pEditView ;
  return DocVisuDoc ;
}
catch (...)
{
  erreur("Exception NSSuper::OuvreDocumentCS.", standardError, 0) ;
  return NULL ;
}
}

// -----------------------------------------------------------------------------
// Function     : NSSuper::OuvreDocumentCQ(NSDocumentInfo *pDocument, NSDocumentInfo *pDocHtml)
// -----------------------------------------------------------------------------
// Arguments    : Document � ouvrir
// -----------------------------------------------------------------------------
// Description  : Attache le document au mod�le Document/Visualisation
// -----------------------------------------------------------------------------
// Returns      : true si on peut ouvrir le document, false sinon
// -----------------------------------------------------------------------------
NSNoyauDocument*
NSSuper::OuvreDocumentCQ(NSDocumentInfo* pDocument, NSDocumentInfo* pDocHtml, NSContexte* pCtx, bool bReadOnly)
{
try
{
	if (NULL == pDocument)
		return 0 ;

	NSCQDocument *DocVisuDoc = new NSCQDocument(0, pDocument, pDocHtml, pCtx, bReadOnly) ;

	// on regarde si on a un fichier valide pour ce document
	if (!DocVisuDoc->bDocumentValide)
	{
  	string sNomDoc  = pDocument->getDocName() ;
    string sCodeDoc = pDocument->getID() ;
    char   msg[255] ;

    sprintf(msg, "Le document %s (code = %s) n'est pas un document valide.", sNomDoc.c_str(), sCodeDoc.c_str()) ;
    erreur(msg, standardError, 0, pSuperContext->GetMainWindow()->GetHandle()) ;
    return 0 ;
	}

	DocVisuDoc->Visualiser() ;
	return DocVisuDoc ;
}
catch (...)
{
    erreur("Exception NSSuper::OuvreDocumentCQ.", standardError, 0) ;
    return NULL ;
}
}

// -----------------------------------------------------------------------------
// Function     : NSSuper::OuvreDocumentRTF(NSDocumentInfo Document)
// -----------------------------------------------------------------------------
// Arguments    : Document � ouvrir
// -----------------------------------------------------------------------------
// Description  : Attache le document au mod�le Document/Visualisation
// -----------------------------------------------------------------------------
// Returns      : true si on peut ouvrir le document, false sinon
// -----------------------------------------------------------------------------
NSNoyauDocument
*NSSuper::OuvreDocumentRTF(NSDocumentInfo *pDocument, NSDocumentInfo *pDocHtml, NSContexte *pCtx, bool bReadOnly)
{
try
{
	if (NULL == pDocument)
		return 0 ;

  // on traite ici le cas des documents word
  // pour l'ouverture, on les associe � une VisualView (pour les visualiser en html)
  // pour l'�dition, on utilisera une AutoWordView (d�finie dans nsttx)
  NSTtxDocument *DocVisuDoc = new NSTtxDocument(0, bReadOnly, pDocument, pDocHtml, pCtx) ;

  // on regarde si on a un fichier valide pour ce document
  // (ValideFichier est lanc�e par Open du DocTtx)
  if (!DocVisuDoc->bDocumentValide)
  {
    string sNomDoc  = pDocument->getDocName() ;
    string sCodeDoc = pDocument->getID() ;
    char   msg[255] ;

    sprintf(msg, "Le document %s (code = %s) n'est pas un document valide.", sNomDoc.c_str(), sCodeDoc.c_str()) ;
    erreur(msg, standardError, 0, pSuperContext->GetMainWindow()->GetHandle()) ;
    return 0 ;
  }

  DocVisuDoc->Visualiser() ;
  return DocVisuDoc ;
}
catch (...)
{
  erreur("Exception NSSuper::OuvreDocumentRTF.", standardError, 0) ;
  return NULL ;
}
}


// -----------------------------------------------------------------------------
// Function     : NSSuper::OuvreDocumentHTML(NSDocumentInfo* pDocument, NSDocumentInfo* pDocHtml)
// -----------------------------------------------------------------------------
// Arguments    : Document � ouvrir
// -----------------------------------------------------------------------------
// Description  : Attache le document au mod�le Document/Visualisation (cf nsvisual.h)
// -----------------------------------------------------------------------------
// Returns      : true si on peut ouvrir le document, false sinon
// -----------------------------------------------------------------------------
NSNoyauDocument
*NSSuper::OuvreDocumentHTML(NSDocumentInfo *pDocument, NSDocumentInfo *pDocHtml, NSContexte *pCtx, bool bReadOnly)
{
try
{
	NSRefDocument   *pDocVisu = new NSRefDocument(0, pDocument, pDocHtml, pCtx, bReadOnly) ;

#ifndef __EPIPUMP__
  // on regarde si on a un fichier valide pour ce document
  pDocVisu->ValideFichier() ;
  if (!pDocVisu->bDocumentValide)
  {
    string sNomDoc  = pDocument->getDocName() ;
    string sCodeDoc = pDocument->getID() ;
    char   msg[255] ;

    sprintf(msg, "Le document %s (code = %s) n'est pas un document valide.", sNomDoc.c_str(), sCodeDoc.c_str()) ;
    erreur(msg, standardError, 0, pSuperContext->GetMainWindow()->GetHandle()) ;
    return 0 ;
  }

  string sLocalis = pDocument->getLocalis() ;
  if (sLocalis != "")
  {
    // cas des html statiques : la template associ�e au fichier est le fichier lui-meme
    pDocVisu->sTemplate = pSuperContext->PathName(sLocalis) ;

    pDocVisu->sTemplate += pDocument->getFichier() ;
  }
  else // cas des html externes
    pDocVisu->sTemplate = "" ;

	NSDocViewManager dvManager(pSuperContext) ;
	dvManager.createView(pDocVisu, "Visual Format") ;

#endif // !__EPIPUMP__
  return pDocVisu ;
}
catch (...)
{
  erreur("Exception NSSuper::OuvreDocumentHTML.", standardError, 0) ;
  return NULL ;
}
}

//---------------------------------------------------------------------------
//  Function: NSSuper::OuvreDocumentIMG(NSDocumentInfo* pDocument, NSDocumentInfo* pDocHtml)
//  Arguments:	  Document � ouvrir
//  Description: Attache le document au mod�le Document/Visualisation
//  Returns:     true si on peut ouvrir le document, false sinon
//---------------------------------------------------------------------------
NSNoyauDocument*
NSSuper::OuvreDocumentIMG(NSDocumentInfo* pDocument, NSDocumentInfo* pDocHtml, NSContexte* pCtx, bool bReadOnly)
{
try
{
	NSRefDocument*	pDocVisu = new NSRefDocument(0, pDocument, pDocHtml, pCtx, bReadOnly);

#ifndef __EPIPUMP__
	// on regarde si on a un fichier valide pour ce document
	pDocVisu->ValideFichier();

	if (!pDocVisu->bDocumentValide)
	{
		string sNomDoc  = pDocument->getDocName() ;
		string sCodeDoc = pDocument->getID() ;
		char   msg[1024];

		sprintf(msg, "Le document %s (code = %s) n'est pas un document valide.", sNomDoc.c_str(), sCodeDoc.c_str()) ;
		erreur(msg, standardError, 0, pSuperContext->GetMainWindow()->GetHandle()) ;
		return 0;
	}

	// cas des documents images : on passe pour le moment la template en dur
	pDocVisu->sTemplate = pSuperContext->PathName("NTPL") + string("docimage.htm");

	NSDocViewManager dvManager(pSuperContext) ;
	dvManager.createView(pDocVisu, "Visual Format") ;

#endif // !__EPIPUMP__
	return pDocVisu;
}
catch (...)
{
	erreur("Exception NSSuper::OuvreDocumentIMG.", standardError, 0) ;
	return NULL;
}
}

//---------------------------------------------------------------------------
//  Function: NSSuper::OuvreDocumentTXT(NSDocumentInfo* pDocument, NSDocumentInfo* pDocHtml)
//  Arguments:	  Document � ouvrir
//  Description: Attache le document au mod�le Document/Visualisation
//  Returns:     true si on peut ouvrir le document, false sinon
//---------------------------------------------------------------------------
NSNoyauDocument*
NSSuper::OuvreDocumentTXT(NSDocumentInfo* pDocument, NSDocumentInfo* pDocHtml, NSContexte* pCtx, bool bReadOnly)
{
try
{
	NSSimpleTxtDocument *DocVisuDoc = new NSSimpleTxtDocument(0, bReadOnly, pDocument, pDocHtml, pCtx) ;

	// on regarde si on a un fichier valide pour ce document
	// (ValideFichier est lanc�e par Open du DocTtx)
	if (!DocVisuDoc->bDocumentValide)
	{
		string sNomDoc  = pDocument->getDocName() ;
		string sCodeDoc = pDocument->getID() ;
		char   msg[1024] ;

		sprintf(msg, "Le document %s (code = %s) n'est pas un document valide.", sNomDoc.c_str(), sCodeDoc.c_str()) ;
		erreur(msg, standardError, 0, pSuperContext->GetMainWindow()->GetHandle()) ;
		return 0 ;
	}

	DocVisuDoc->Visualiser() ;
	return DocVisuDoc ;
}
catch (...)
{
	erreur("Exception NSSuper::OuvreDocumentTXT", standardError, 0) ;
	return NULL;
}
}

//---------------------------------------------------------------------------
//  Function: NSSuper::OuvreDocumentTXT(NSDocumentInfo* pDocument, NSDocumentInfo* pDocHtml)
//  Arguments:	  Document � ouvrir
//  Description: Attache le document au mod�le Document/Visualisation
//  Returns:     true si on peut ouvrir le document, false sinon
//---------------------------------------------------------------------------
NSNoyauDocument*
NSSuper::OuvreDocumentPDF(NSDocumentInfo* pDocument, NSDocumentInfo* pDocHtml, NSContexte* pCtx, bool bReadOnly)
{
try
{
	NSAcrobatDocument *DocVisuDoc = new NSAcrobatDocument(0, bReadOnly, pDocument, pDocHtml, pCtx) ;

	// on regarde si on a un fichier valide pour ce document
	// (ValideFichier est lanc�e par Open du DocTtx)
	if (!DocVisuDoc->bDocumentValide)
	{
		string sNomDoc  = pDocument->getDocName() ;
		string sCodeDoc = pDocument->getID() ;
		char   msg[1024] ;

		sprintf(msg, "Le document %s (code = %s) n'est pas un document valide.", sNomDoc.c_str(), sCodeDoc.c_str()) ;
		erreur(msg, standardError, 0, pSuperContext->GetMainWindow()->GetHandle()) ;
		return 0 ;
	}

	DocVisuDoc->Visualiser() ;
	return DocVisuDoc ;
}
catch (...)
{
	erreur("Exception NSSuper::OuvreDocumentPDF", standardError, 0) ;
	return NULL;
}
}

voidNSSuper::NavigationEncyclopedie(string sUrl, NSContexte* pCtx)
{
try
{
#ifndef __EPIPUMP__
	NSDocumentInfo* pDocument = new NSDocumentInfo(pCtx);
  pDocument->setFichier(sUrl) ;
  NSRefDocument   *pDocVisu = new NSRefDocument(0, pDocument, 0, pCtx, true) ;

	NSDocViewManager dvManager(pSuperContext) ;
	dvManager.createView(pDocVisu, "Visual Format") ;

#endif // !__EPIPUMP__
}
catch (...)
{
	erreur("Exception NavigationEncyclopedie.", standardError, 0) ;
}
}


// -----------------------------------------------------------------------------
// ATTENTION : Mettre ces fonctions inline pose des probl�mes dans les DLL
// -----------------------------------------------------------------------------
short
NSSuper::donneStatut()
{
  return statut ;
}


hDBIDb
NSSuper::PrendPDatabase()
{
	return hNSdb ;
}


/*
#if defined(_INCLUS)
void
NSSuper::EnableBWCC(bool enable, uint language)
{
  if (enable)
  {
    if (!BWCCModule)
    {
      try
      {
        BWCCModule = new TBwccDll() ;
        BWCCModule->IntlInit(language) ;
        TModule *pModule = pMainWindow->GetModule() ;
        BWCCModule->Register(pModule->GetInstance()) ;

        WARNX(OwlApp, BWCCModule->GetVersion() < BWCCVERSION, 0,  "Old version of BWCC DLL found") ;
      }
      catch (...)
      {
        TRACEX(OwlApp, 0, "Unable to create instance of TBwccDll") ;
        return ;
      }
    }
  }
  BWCCOn = enable ;
}
#endif
*/

vector<string>
NSSuper::getLocalTeams()
{
  string serviceName = NautilusPilot::SERV_SEARCH_OBJECT_HAVING_TRAITS ;
  vector<string> vRes ;

  NSPersonsAttributesArray ResultList ;
  NSBasicAttributeArray		 AttrArray ;
  AttrArray.push_back(new NSBasicAttribute("trait", LOCALTEAM)) ;

  bool listOk = pSuperContext->pPilot->objectList(serviceName.c_str(), &ResultList, &AttrArray) ;

  if ((!listOk) || (ResultList.empty()))
		return vRes ;

  for (NSPersonsAttributeIter personAttrIter = ResultList.begin() ; personAttrIter != ResultList.end() ; personAttrIter++)
  {
    if (!((*personAttrIter)->empty()))
    {
    	for (NSBasicAttributeIter basicAttrIter = (*personAttrIter)->begin() ; basicAttrIter != (*personAttrIter)->end() ; basicAttrIter++)
    	{
    		if ((*basicAttrIter)->getBalise() == OIDS)
      	{
      		string sObjectID = (*basicAttrIter)->getText() ;
        	vRes.push_back(sObjectID) ;
        }
      }
    }
  }

  return vRes ;
}

void
NSSuper::initInstanceCounters()
{
	// Counters from NautilusPilot.hpp
	NSBasicAttribute::initNbInstance() ;
	NSBasicAttributeArray::initNbInstance() ;
	NSPersonsAttributesArray::initNbInstance() ;

  // counters from nsmanager.h
	NSDataTree::initNbInstance() ;
	NSDataTreeArray::initNbInstance() ;
	NSDataGraph::initNbInstance() ;
	NSObjectGraphManager::initNbInstance() ;
	NSPersonGraphManager::initNbInstance() ;

  // counters from nspatpat.h
	NSPatPathoInfo::initNbInstance() ;
	NSPatPathoArray::initNbInstance() ;
	NSVectPatPathoArray::initNbInstance() ;
}

void
NSContexte::setMainCaption()
{
	if (!pSuper)
		return ;
	TWindow* pMainWindow = pSuper->donneMainWindow() ;
	if ((NULL == pMainWindow) || (!(pMainWindow->IsWindow())))
		return ;

	string sCaption = pSuper->sAppName ;
	if (NULL != pUtilisateur)
		sCaption += string(" : ") + pUtilisateur->donneSignature(this) ;

  string sLang = string("") ;
  if (NULL != pUtilisateur)
    sLang = pUtilisateur->donneLang() ;

	// si on a un patient ouvert, on ajoute la caption patient
	// sans cr�er de nouvelle contribution
	if (NULL != pPatient)
	{
    // on fabrique le nom long
    pPatient->fabriqueNomLong() ;

    // On ajoute le nom et l'age du patient au titre de l'application
    sCaption += string(" - ") + pPatient->getNomLong() ;

    string sPatientAge = pPatient->fabriqueAgeLabel(sLang) ;
    if (string("") != sPatientAge)
    	sCaption += string(" (") + sPatientAge + string(")") ;
	}

	pMainWindow->SetCaption(sCaption.c_str()) ;
}

boolNSContexte::captureData(NSCaptureArray *pCapture)
{
try
{
	if ((!pUtilisateur) || (pCapture->empty()))
		return false ;

	if (!(pUtilisateur->isUser()))
		return false ;

	// Si on n'a pas captur� le nom, on ajoute simplement les nouvelles donn�es
	// captur�es � l'array g�n�rale
	//
	string sNom       = string("") ;
	string sPatronyme = string("") ;
	if ((UINT(pCapture->trouveChemin(string("LNOM01"), &sNom))        == string::npos) &&
			(UINT(pCapture->trouveChemin(string("LPATR1"), &sPatronyme))  == string::npos))
	{
#ifndef __EPIPUMP__
		if (!(pSuper->getEpisodus()))
			return false ;

		// NSCaptureArray* pCaptureArray = &(pSuper->pEpisodus->CaptureArray) ;
		// pCaptureArray->append(pCapture) ;
		// pCapture->vider() ;

    pSuper->getEpisodus()->PutNewCaptureInTank(false /*bEmptyTankFirst*/, true /*bool bResetNew*/) ;
    pSuper->getEpisodus()->getCaptureDoc()->openView() ;

		return true ;
#else
		return false ;
#endif // !__EPIPUMP__
	}

	// TWindow *pMainWin = pSuper->donneMainWindow() ;

	// Si on a au moins captur� le nom, il est possible d'identifier/cr�er le patient
	//
	string sPrenom  = string("") ;
	pCapture->trouveChemin(string("LNOM21"), &sPrenom) ;

	// Patronyme : s�parer le nom et le pr�nom
	if (sPatronyme != "")
	{
		size_t i ;

		// Recherche de la premi�re lettre non majuscule
		for (i = 0 ; (i < strlen(sPatronyme.c_str())) && (sPatronyme[i] == pseumaj(sPatronyme[i])) ; i++)
        ;

		if (i < strlen(sPatronyme.c_str()))
		{
			if (i > 0)
			{
				for ( ; (i > 0) && (sPatronyme[i] != ' ') ; i--)
					;
				if (i > 0)
				{
					sNom    = string(sPatronyme, 0, i) ;
					sPrenom = string(sPatronyme, i + 1, strlen(sPatronyme.c_str()) - i - 1) ;
				}
				else
					sPrenom = sPatronyme ;
      }
			else
				sPrenom = sPatronyme ;
		}
		else
			sNom = sPatronyme ;
	}

	string sSexe    = string("") ;	string sNaiss   = string("") ;
	// On cherche les autres �l�ments administratifs : pr�nom, sexe, date de naissance	pCapture->trouveChemin(string("LSEXE1"), &sSexe);
	pCapture->trouveChemin(string("KNAIS1"), &sNaiss);

	// on enl�ve les blancs terminaux des nom et pr�nom
	strip(sNom, stripRight) ;
	strip(sPrenom, stripRight) ;

	char nomPat[PIDS_NOM_LEN + 1] ;
	char prenomPat[PIDS_PRENOM_LEN + 1] ;
	strcpy(nomPat, sNom.c_str()) ;
	strcpy(prenomPat, sPrenom.c_str()) ;

  if (!(pUtilisateur->pPatRech))
    pUtilisateur->pPatRech = new NSPatInfo(this) ;
  NSPatInfo* pPatEnCours = pUtilisateur->pPatRech ;

	char szInstance[3] ;
	int iInstance = getSuperviseur()->numInstance ;
	itoa(iInstance, szInstance, 10) ;

	// SetCursor(0, IDC_WAIT) ;
	string user = getUtilisateurID() ;

  bool bUseBirthdateAsTrait = true ;

	NSBasicAttributeArray AttrArray  ;

	AttrArray.push_back(new NSBasicAttribute(LAST_NAME,  string(nomPat))) ;
  AttrArray.push_back(new NSBasicAttribute(FIRST_NAME, string(prenomPat))) ;
  AttrArray.push_back(new NSBasicAttribute(BIRTHDATE,  sNaiss)) ;

  NSPersonsAttributesArray PatiensList ;

  bool bListOk = pPilot->personList((NautilusPilot::SERV_PERSON_LIST_FROM_TRAITS).c_str(), &PatiensList, &AttrArray) ;
	if (false == bListOk)
	{
		std::string tempMessage = pPilot->getWarningMessage() ;
		std::string tempError   = pPilot->getErrorMessage() ;
		if( tempMessage != "")
			::MessageBox(GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
		if( tempError != "")
			::MessageBox(GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
		return false ;
	}

  if (PatiensList.size() > 1)
	{
  	pUtilisateur->AppelPatient() ;
    return true ;
	}

  // Nobody found... searching without birthdate as a trait
  //
	if (true == PatiensList.empty())
	{
  	AttrArray.vider() ;
  	AttrArray.push_back(new NSBasicAttribute(LAST_NAME,  string(nomPat))) ;
  	AttrArray.push_back(new NSBasicAttribute(FIRST_NAME, string(prenomPat))) ;

  	NSPersonsAttributesArray PatiensList ;

  	bool bListOk = pPilot->personList((NautilusPilot::SERV_PERSON_LIST_FROM_TRAITS).c_str(), &PatiensList, &AttrArray) ;
		if (false == bListOk)
		{
			std::string tempMessage = pPilot->getWarningMessage() ;
			std::string tempError   = pPilot->getErrorMessage() ;
			if( tempMessage != "")
				::MessageBox(GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
			if( tempError != "")
				::MessageBox(GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK) ;
			return false ;
		}

    // Nobody or several persons found: let the user digg
    //
    if ((true == PatiensList.empty()) || (PatiensList.size() > 1))
		{
  		pUtilisateur->AppelPatient() ;
    	return true ;
		}

    bUseBirthdateAsTrait = false ;
	}

	// This Service must only be called when there is only one person that fits
  // provided traits - or the Pilot will crash!
  //
  AttrArray.vider() ;
  AttrArray.push_back(new NSBasicAttribute(LAST_NAME,  string(nomPat))) ;
  AttrArray.push_back(new NSBasicAttribute(FIRST_NAME, string(prenomPat))) ;
  if (bUseBirthdateAsTrait)
  	AttrArray.push_back(new NSBasicAttribute(BIRTHDATE, sNaiss)) ;
	AttrArray.push_back(new NSBasicAttribute(OPERATOR,   user)) ;
	AttrArray.push_back(new NSBasicAttribute(CONSOLE,    string(getSuperviseur()->noConsole))) ;
	AttrArray.push_back(new NSBasicAttribute(INSTANCE,   string(szInstance))) ;
  NSPersonsAttributesArray List ;
  bool res = pPilot->searchPatient(NautilusPilot::SERV_SEARCH_PATIENT_FROM_TRAITS.c_str(),
                                    pPatEnCours->pGraphPerson->pDataGraph, &List, &AttrArray) ;
  if (!res)
  {
  	string tempMessage = pPilot->getWarningMessage() ;
    ::MessageBox(GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK) ;
    return false ;
	}

  if ((!pPatEnCours->pGraphPerson->pDataGraph) ||
  		  (!pPatEnCours->pGraphPerson->graphPrepare()))
  	return false ;

  pPatEnCours->pGraphPerson->bNeedUnlock = false ;
  pPatEnCours->pGraphPerson->bReadOnly = true ;

  //
  // Personne ne correspond aux traits, ou plusieurs personnes correspondent
  // Nobody - or several persons - share these traits
  //
  if (List.empty() || (pPatEnCours->pGraphPerson->pDataGraph->getGraphID() == ""))
  {
  	pUtilisateur->AppelPatient() ;
    return true ;
	}

  string sIsLocked = List.getAttributeValue("locked") ;
  if (sIsLocked == "ok")
  	pPatEnCours->pGraphPerson->bNeedUnlock = true ;
  string sOperationType	= List.getAttributeValue("operationType") ;
  if (sOperationType == "readWrite")
  	pPatEnCours->pGraphPerson->bReadOnly = false ;

  AttrArray.push_back(new NSBasicAttribute(PERSON , pPatEnCours->pGraphPerson->getPersonID())) ;
  pPatEnCours->pGraphPerson->setInfoPids(&AttrArray) ;
  pPatEnCours->pGraphPerson->pDataGraph->setLastTree() ;

	string sCodePat = pPatEnCours->pGraphPerson->getRootTree() ;
	// NSDataGraph* pGraph = pPatEnCours->pGraphPerson->pDataGraph ;

	// SetCursor(0, IDC_ARROW) ;

	pUtilisateur->ChangePatientChoisi() ;
	pUtilisateur->pPatRech = 0 ;
	pPatient->Initialisation() ;
	return true ;
}
catch (...)
{
  erreur("Exception NSContexte::captureData.", standardError, 0) ;
  return false ;
}
}

void
NSContexte::creePilot()
{
try
{
	pSuper->getApplication()->sendMessageToSplash("Create Pilot") ;
  pSuper->getApplication()->setSplashPercentDone(15) ;

#ifndef __EPIPUMP__
	string sVerNum = pSuper->sNumVersion ;
	string ps = string("Starting, release : ") + sVerNum ;
  pSuper->trace(&ps, 1) ;
#endif

  pPilot = new NautilusPilot(this) ;

#ifndef __EPIPUMP__
  pPilot->setEpisodusVersion(sVerNum) ;
  //pPilot->markIncorrectAgents() ;
  pSuper->getApplication()->sendMessageToSplash("Init agent list") ;
  pSuper->getApplication()->setSplashPercentDone(17) ;

  pPilot->initAgentList() ;

  pSuper->getApplication()->sendMessageToSplash("Set services list") ;
  pSuper->getApplication()->setSplashPercentDone(20) ;

  pPilot->setServiceList() ;
#endif
}
catch (...)
{
  erreur("Exception NSContexte::creePilot.", standardError, 0) ;
  return ;
}
}

void
NSContexte::setUtilisateur(NSUtilisateurChoisi* pUti)
{
	pUtilisateur = pUti ;

#ifndef __EPIPUMP__
	// reset captured informations
  if (pSuper->getEpisodus())
	{
  	pSuper->getEpisodus()->deleteCaptureDoc() ;

    if (pUti)
    	pSuper->getEpisodus()->createCaptureDoc() ;
	}
#endif
}

