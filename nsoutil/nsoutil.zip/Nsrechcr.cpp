#include <string.h>#include <cstring.h>
#include <stdio.h>
#include <owl\gauge.h>

#include "nautilus\nssuper.h"
#include "nsoutil\nsrechcr.h"
#include "nsoutil\nsoutil.h"
#include "nsoutil\nsoutil.rh"
#include "nsoutil\nsfilgui.h"
#include "nssavoir\nsguide.h"
#include "nssavoir\nsfilgd.h"
#include "nssavoir\nsgraphe.h"
#include "dcodeur\decoder.h"
#include "dcodeur\nsdkd.h"
#include "nsbb\nsednum.h"
#include "nsbb\tagNames.h"
#include "nsepisod\nsldvuti.h"

/*****************************************************************************//******                 OUTIL DE GESTION DES REQUETES                   ******/
/*****************************************************************************/

NSRequestResult::NSRequestResult(NSRequestResult& src)
{
	copyValues(&src) ;
}

void
NSRequestResult::reinitForNewSearch()
{
	_aVectDocumentResults.vider() ;
	_aVectPatientResults.vider() ;

	_nbPatResult = 0 ;
	_nbDocResult = 0 ;

	_bNouveauPatResult = true ;
}

void
NSRequestResult::copyValues(NSRequestResult* pSrc)
{
	if (false == pSrc->_aVectDocumentResults.empty())
		for (DocumentIter i = pSrc->_aVectDocumentResults.begin(); i != pSrc->_aVectDocumentResults.end(); i++)
			_aVectDocumentResults.push_back(new NSDocumentHisto(*(*i))) ;

	if (false == pSrc->_aVectPatientResults.empty())
  	for (PatientIter i = pSrc->_aVectPatientResults.begin(); i != pSrc->_aVectPatientResults.end(); i++)
    	_aVectPatientResults.push_back(new NSPatInfo(*(*i))) ;

	_nbPatResult = pSrc->_nbPatResult ;
	_nbDocResult = pSrc->_nbDocResult ;

	_bNouveauPatResult = pSrc->_bNouveauPatResult ;

  _sRequestName         = pSrc->_sRequestName ;
	_sRequestBooleanLabel = pSrc->_sRequestBooleanLabel ;
}

NSRequestResult&
NSRequestResult::operator=(NSRequestResult src)
{
	if (this == &src)
		return *this ;

	reinitForNewSearch() ;
	copyValues(&src) ;

	return *this ;
}

// -----------------------------------------------------------------////  M�thodes de NSRequeteWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSRequeteWindow, TListWindow)    EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

NSRequeteWindow::NSRequeteWindow(NSRequeteDialog* pere, int resId) : TListWindow(pere, resId){
	pDlg = pere ;
}

NSRequeteWindow::~NSRequeteWindow(){}voidNSRequeteWindow::SetupWindow(){	ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;
	TListWindow::SetupWindow() ;}//---------------------------------------------------------------------------//  Description: Fonction de r�ponse au double click
//---------------------------------------------------------------------------
void
NSRequeteWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TListWindow::EvLButtonDown(modKeys, point) ;

	TLwHitTestInfo info(point) ;
	HitTest(info) ;

	if (info.GetFlags() & LVHT_ONITEM)
		pDlg->CmInsererChemin() ;
}

//---------------------------------------------------------------------------//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSRequeteWindow::IndexItemSelect()
{
	int count = GetItemCount() ;
	int index = -1 ;

	for (int i = 0; i < count; i++)
		if (GetItemState(i, LVIS_SELECTED))
		{
    	index = i ;
			break ;
		}

	return index ;
}

// -----------------------------------------------------------------
////  M�thodes de NSBooleanRequestsWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSBooleanRequestsWindow, TListWindow)    EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

NSBooleanRequestsWindow::NSBooleanRequestsWindow(NSRequeteDialog* pere, int resId)                        :TListWindow(pere, resId){
	pDlg = pere ;
}

NSBooleanRequestsWindow::~NSBooleanRequestsWindow(){}voidNSBooleanRequestsWindow::SetupWindow(){	ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;
	TListWindow::SetupWindow() ;}//---------------------------------------------------------------------------//  Description: Fonction de r�ponse au double click
//---------------------------------------------------------------------------
void
NSBooleanRequestsWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TListWindow::EvLButtonDown(modKeys, point) ;

	TLwHitTestInfo info(point) ;
	HitTest(info) ;

	if (info.GetFlags() & LVHT_ONITEM)
		pDlg->CmPutRequestInEditControl() ;
}

//---------------------------------------------------------------------------//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSBooleanRequestsWindow::IndexItemSelect()
{
	int count = GetItemCount() ;
	int index = -1 ;

	for (int i = 0; i < count; i++)
		if (GetItemState(i, LVIS_SELECTED))
		{
    	index = i ;
			break ;
		}

	return index ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSRequeteDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSRequeteDialog, NSUtilDialog)
  EV_BN_CLICKED(IDC_REQ_NEWREQ, CmNouveau),
  EV_BN_CLICKED(IDC_REQ_OPEN, CmOuvrir),
  EV_BN_CLICKED(IDC_REQ_SAVE, CmEnregistrer),
  EV_BN_CLICKED(IDC_REQ_NEW, CmNewReq),
  EV_BN_CLICKED(IDC_REQ_MOD, CmModReq),
  EV_BN_CLICKED(IDC_REQ_DEL, CmDelReq),
  EV_BN_CLICKED(IDC_REQ_DUP, CmDupReq),
  EV_BN_CLICKED(IDC_REQ_CRITPAT, CmCriteresPatient),
  EV_BN_CLICKED(IDC_REQ_CRITDOC, CmCriteresDocument),
  EV_BN_CLICKED(IDC_REQ_OUVRANTE, CmOuvrante),
  EV_BN_CLICKED(IDC_REQ_ET, CmET),
  EV_BN_CLICKED(IDC_REQ_OU, CmOU),
  EV_BN_CLICKED(IDC_REQ_FERMANTE, CmFermante),
  EV_BN_CLICKED(IDC_REQ_MODPAT, CmModePat),
  EV_BN_CLICKED(IDC_REQ_MODDOC, CmModeDoc),
  EV_BN_CLICKED(IDC_REQ_LANCER, CmLancement),
  EV_BN_CLICKED(IDC_REQ_FERMER, CmFermer),
  EV_LVN_GETDISPINFO(IDC_REQ_LW, LvnGetDispInfo),
  EV_BN_CLICKED(IDC_REQ_REQ_NEW, CmAddRequest),
  EV_BN_CLICKED(IDC_REQ_REQ_MOD, CmEditRequest),
  EV_BN_CLICKED(IDC_REQ_REQ_DEL, CmDeleteRequest),
  EV_BN_CLICKED(IDC_REQ_REQ_DUP, CmDuplicateRequest),
  EV_LVN_GETDISPINFO(IDC_REQ_BOOL_LW, LvnGetSearchDispInfo),
END_RESPONSE_TABLE;

NSRequeteDialog::NSRequeteDialog(TWindow* pere, NSContexte* pCtx)                :Document(pCtx), Patient(pCtx), NSUtilDialog(pere, pCtx, "IDD_REQUETE", pNSResModule)
{
	bDirty = false ;

  pNomReq       = new NSUtilEdit2(pContexte, this, IDC_REQ_NOM, 80) ;
  pListeChem    = new NSRequeteWindow(this, IDC_REQ_LW) ;
  pRequestsList = new NSBooleanRequestsWindow(this, IDC_REQ_BOOL_LW) ;
  pChemArray    = new NSEltArray ;
  nbChem = 0;
  pEditReq      = new NSUtilEdit2(pContexte, this, IDC_REQ_EDIT, 255) ;
  pEditReqLabel = new NSUtilEdit2(pContexte, this, IDC_REQ_NAME_EDIT, 255) ;
  //pMode =         new TGroupBox(this, IDC_REQ_MOD) ;
  pModePat      = new TRadioButton(this, IDC_REQ_MODPAT /*, pMode */) ;
  pModeDoc      = new TRadioButton(this, IDC_REQ_MODDOC /*, pMode */) ;
  pCritPatBox   = new TCheckBox(this, IDC_REQ_CRITPAT) ;
  pCritDocBox   = new TCheckBox(this, IDC_REQ_CRITDOC) ;
  pCritPat      = new NSCritReqPatient() ;
  pCritDoc      = new NSCritReqDocum() ;
  pLanceur      = new NSLanceReqDialog(this, pCtx, pNSResModule) ;
  pPersonList   = 0 ;
  sLibReq       = "" ;
  bReqModeDoc   = true ;
  bReqEnCours   = false ;
  bCritPat      = false ;
  bCritDoc      = false ;
  bCherchePatient  = false ;
  bChercheDocument = false ;
  sFileName     = "" ;
}

NSRequeteDialog::~NSRequeteDialog()
{
  delete pNomReq ;
  delete pListeChem ;
  delete pRequestsList ;
  delete pChemArray ;
  delete pEditReq ;
  delete pEditReqLabel ;
  // delete pMode ;
  delete pModePat ;
  delete pModeDoc ;
  delete pCritPatBox ;
  delete pCritDocBox ;
  delete pCritPat ;
  delete pCritDoc ;
  delete pLanceur ;

  if (pPersonList)  	delete pPersonList ;}

voidNSRequeteDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

	InitListeChem() ;
	AfficheListeChem() ;     // pour le cas o� on r�affiche des chemins existants

  InitSearchList() ;
	DisplaySearchList() ;

	// La recherche est en mode document par d�faut
	if (bReqModeDoc)
		pModeDoc->Check() ;
	else
		pModePat->Check() ;

	// on check les criteres	if (bCritPat)
		pCritPatBox->Check() ;
	if (bCritDoc)
		pCritDocBox->Check() ;

	// on replace le libell�
	if (sLibReq != "")
		pEditReq->SetText(sLibReq.c_str()) ;
	if (sFileName != "")
		pNomReq->SetText(sFileName.c_str()) ;

	// Setting various titles
	//
  setTextForControl(IDC_REQ_STEP1_TXT, "searchingRequestForm", "stepOneDefinePatientsCriteria") ;
  setTextForControl(IDC_REQ_STEP2_TXT, "searchingRequestForm", "stepTwoDefineDocumentsCriteria") ;
  setTextForControl(IDC_REQ_STEP3_TXT, "searchingRequestForm", "stepThreeDefineClinicalCriteria") ;
  setTextForControl(IDC_REQ_STEP4_TXT, "searchingRequestForm", "stepFourDefineClinicalRequests") ;
  setTextForControl(IDC_REQ_STEP5_TXT, "searchingRequestForm", "stepFiveDefineHowToValidate") ;
  setTextForControl(IDC_REQ_STEP6_TXT, "searchingRequestForm", "stepSixRun") ;


/************************
    if (InitChemArray())
        AfficheListeChem();
    else
        erreur("Impossible d'afficher la liste des chemins.",0,0);
************************/
}

voidNSRequeteDialog::InitListeChem()
{
	string sLocalText = pContexte->getSuperviseur()->getText("searchingRequestForm", "pathNum") ;
  TListWindColumn colNum((char*) sLocalText.c_str(), 20, TListWindColumn::Left, 0) ;
  pListeChem->InsertColumn(0, colNum) ;

  sLocalText = pContexte->getSuperviseur()->getText("searchingRequestForm", "path") ;
  TListWindColumn colChem((char*) sLocalText.c_str(), 1000, TListWindColumn::Left, 1) ;
  pListeChem->InsertColumn(1, colChem) ;
}

voidNSRequeteDialog::AfficheListeChem()
{
	char elt[10] ;

	pListeChem->DeleteAllItems() ;

	for (int i = nbChem - 1; i >= 0; i--)
	{
		sprintf(elt, "%d", i+1) ;
    TListWindItem Item(elt, 0) ;
    pListeChem->InsertItem(Item) ;
	}
}

voidNSRequeteDialog::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
	const int BufLen = 1024 ;
	static char buffer[BufLen] ;
	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;

	int index = dispInfoItem.GetIndex() ;

	// Affiche les informations en fonction de la colonne

	switch (dispInfoItem.GetSubItem())
	{
		case 1: 	// chemin
    	sprintf(buffer, "%s", (((*pChemArray)[index])->libelle).c_str()) ;
      dispInfoItem.SetText(buffer) ;
      break ;
	}
}

void
NSRequeteDialog::InitSearchList()
{
	string sLocalText = pContexte->getSuperviseur()->getText("searchingRequestForm", "searchName") ;
  TListWindColumn colName((char*) sLocalText.c_str(), 150, TListWindColumn::Left, 0) ;
  pRequestsList->InsertColumn(0, colName) ;

  sLocalText = pContexte->getSuperviseur()->getText("searchingRequestForm", "searchLabel") ;
  TListWindColumn colText((char*) sLocalText.c_str(), 1000, TListWindColumn::Left, 1) ;
  pRequestsList->InsertColumn(1, colText) ;
}

void
NSRequeteDialog::DisplaySearchList()
{
	pRequestsList->DeleteAllItems() ;

	if (true == _aRequestResults.empty())
		return ;

	for (NSRequestResultIter it = _aRequestResults.begin() ; _aRequestResults.end() != it ; it++)
	{
		string sSearchName = (*it)->getRequestName() ;
    TListWindItem Item(sSearchName.c_str(), 0) ;
    pRequestsList->InsertItem(Item) ;
	}
}

void
NSRequeteDialog::LvnGetSearchDispInfo(TLwDispInfoNotify& dispInfo)
{
	const int BufLen = 1024 ;
	static char buffer[BufLen] ;
	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;

	int index = dispInfoItem.GetIndex() ;

	// Affiche les informations en fonction de la colonne

	switch (dispInfoItem.GetSubItem())
	{
		case 1: 	// chemin
    	sprintf(buffer, "%s", ((_aRequestResults[index])->getRequestLabel()).c_str()) ;
      dispInfoItem.SetText(buffer) ;
      break ;
	}
}

//// Note : Ce TrouveLibElement appelle la fonction GlobalDkd::decodeNoeud
// pour chaque noeud (�l�ment) du chemin, les noeuds �tant s�par�s par des '|'
// Pour les libell�s des chemins de requete, on doit donc passer le chemin de
// recherche, qui a d�j� d�cal� les �l�ments en +00+00
//

voidNSRequeteDialog::TrouveLibElement(string sElement, string& sLibElement)
{
	string sCode, sLibelle;
	string sCodeLex;

	string sLang = "";
	if ((NULL != pContexte) && (NULL != pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;

	// on remet � "" sLibElement
	sLibElement = "" ;

	size_t pos1 = 0 ;
	size_t pos2 = sElement.find('|') ;

	bool bContinue = true ;
	while (bContinue)
	{
  	if (NPOS != pos2)
    	sCode = string(sElement, pos1, pos2-pos1) ;
    else
    	sCode = string(sElement, pos1, strlen(sElement.c_str())-pos1) ;

    // cas particuliers des codes vides et jokers
    if (string("") == sCode)
    	sLibelle = "" ;
    else if ('~' == sCode[0])
    	sLibelle = string(sCode, 3, 2) ;
    else
    {
    	// cas g�n�ral d'un noeud � d�coder : on doit former une PatPatho
      // qui contient uniquement ce noeud
      NSPatPathoArray PatPatho(pContexte) ;

      // cas des valeurs chiffr�es : trait� � part
      if ('2' == sCode[0])
      {
      	string sUnite, sFormat, sValeur ;
        // on doit ici faire une patpatho avec deux �l�ments
        NSPatPathoInfo UniteData ;
        UniteData.setLocalisation(string(BASE_LOCALISATION_LEN, '0')) ;

        NSPatPathoInfo ValeurData ;        ValeurData.setLocalisation("00010000") ;
        size_t pos3 = sCode.find('/') ;        if (NPOS != pos3)
        {
        	sUnite = string(sCode, 0, pos3) ;
          size_t pos4 = sCode.find('/', pos3+1) ;
          if (NPOS != pos4)
          {
          	sFormat = string(sCode, pos3+1, pos4-pos3-1) ;            // attention, on skippe le '$' pour r�cup�rer la valeur
            sValeur = string(sCode, pos4+2, strlen(sCode.c_str())-pos4-2) ;
          }
          else
          {
          	sFormat = string(sCode, pos3+1, strlen(sCode.c_str())-pos3-1) ;
            sValeur = "" ;
          }
        }
        else
        {
        	sUnite  = sCode ;
          sFormat = "" ;
          sValeur = "" ;
        }

        UniteData.setLexique(sUnite) ;
        PatPatho.push_back(new NSPatPathoInfo(UniteData)) ;

        if (string("") != sFormat)        {
        	ValeurData.setLexique(sFormat) ;
          // ici on tronque sur la taille du champ complement
          if (strlen(sValeur.c_str()) > BASE_COMPLEMENT_LEN)
          {
          	string sComplement = string(sValeur, 0, BASE_COMPLEMENT_LEN) ;
            ValeurData.setComplement(sComplement) ;
          }
          else
          	ValeurData.setComplement(sValeur) ;
          PatPatho.push_back(new NSPatPathoInfo(ValeurData)) ;
        }
      }      else
      {
      	// on parse le noeud pour former la patpatho
        NSPatPathoInfo Data ;
        Data.setLocalisation(string(BASE_LOCALISATION_LEN, '0')) ;

        bool bParse = true ;
        size_t pos3 = 0 ;
        size_t pos4 = sCode.find('/') ;

        while (bParse)
        {
        	if (pos4 != NPOS)
          	sCodeLex = string(sCode, pos3, pos4-pos3) ;          else
          	sCodeLex = string(sCode, pos3, strlen(sCode.c_str())-pos3) ;

          if (("WPLUR" == string(sCodeLex, 0, 5)) || ("WPLUS" == string(sCodeLex, 0, 5)))
          	Data.setPluriel(sCodeLex) ;
          else if (string(sCodeLex,0,3) == "WCE")
          	Data.setCertitude(sCodeLex) ;          else
          	Data.setLexique(sCodeLex) ;

          if ((NPOS == pos4) || (strlen(sCode.c_str())-1 == pos4))
          	bParse = false ;
          else
          {
          	pos3 = pos4 + 1 ;
            pos4 = sCode.find('/', pos3) ;
          }
        }

        PatPatho.push_back(new NSPatPathoInfo(Data)) ;
      }

      // On d�code le noeud contenu dans pPatPatho :
      // dans ce cas on passe un chemin (contextuel) vide
      GlobalDkd Dcode(pContexte, sLang, "", &PatPatho) ;
      Dcode.decodeNoeud() ;
      sLibelle = *(Dcode.sDcodeur()) ;
    }

    if (sLibElement != "")
    	sLibElement += "/" ;
    sLibElement += sLibelle ;

    if ((pos2 == NPOS) || (pos2 == (strlen(sElement.c_str())-1)))
    	bContinue = false ;
    else
    {
    	pos1 = pos2 + 1 ;
      pos2 = sElement.find('|', pos1) ;
    }
  }
}

// fonction laiss�e pour une utilisation future// (quand on r�cup�rera des requ�tes sur disque)
bool
NSRequeteDialog::InitChemArray()
{
    pChemArray->vider();
    nbChem = 0;

    return true;
}

void
NSRequeteDialog::CmNouveau()
{
    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
    int idRet = MessageBox("Etes-vous s�rs de vouloir prendre une nouvelle requ�te ?", sCaption.c_str(), MB_YESNO);

    if (idRet == IDNO)
        return;

    // Dans ce cas, on remet tout � z�ro sans aucune piti�...
    sLibReq = "";
    pEditReq->SetText("");
    bReqModeDoc = true;
    pModeDoc->Check();
    pModePat->Uncheck();
    bReqEnCours = false;
    bCritPat = false;
    pCritPat->metAZero();
    pCritPatBox->Uncheck();
    bCritDoc = false;
    pCritDoc->metAZero();
    pCritDocBox->Uncheck();
    bCherchePatient = false;
    bChercheDocument = false;
    sFileName = "";
    pNomReq->SetText("");

    pChemArray->vider();
    nbChem = 0;
    pListeChem->DeleteAllItems();
    VectPatResultat.vider();
    VectDocResultat.vider();
    nbPatTotal = 0; nbPatCritPat = 0; nbPatCritDoc = 0; nbPatResult = 0;
    nbDocCritPat = 0; nbDocCritDoc = 0; nbDocResult = 0;
}

bool
NSRequeteDialog::ChargerRequete(string sNomFichier)
{
	if (string("") == sNomFichier)
		return false ;

	ifstream inFile ;
  inFile.open(sNomFichier.c_str()) ;
	if (!inFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    sErrorText += string(" (") + sNomFichier + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
    return false ;
	}

	string header, line ;
	string sParam[6] = {"","","","","",""} ;

	// on r�cup�re le header du fichier
	if (inFile.eof())
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("searchingRequestFormWarnings", "emptyResearchFile") ;
    sErrorText += string(" (") + sNomFichier + string(")") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
		return false ;
	}

  getline(inFile, header) ;

	if (string("") == header)
  {
    string sErrorText = pContexte->getSuperviseur()->getText("searchingRequestFormWarnings", "emptyResearchFileHeader") ;
    sErrorText += string(" (") + sNomFichier + string(")") ;
		erreur(sErrorText.c_str(), warningError, 0) ;
    return false;	}

	size_t i = 0, k = 0 ;

	while (i < strlen(header.c_str()))
	{
		if (header[i] == '\"')
    {
    	k++ ;

      // les headers de requete comportent 3 param�tres
      if (3 == k)
      {
      	string sErrorText = pContexte->getSuperviseur()->getText("searchingRequestFormWarnings", "badResearchFileHeader") ;
    		sErrorText += string(" (") + sNomFichier + string(")") ;
				erreur(sErrorText.c_str(), warningError, 0) ;
        return false ;
      }
    }
    else
    	sParam[k] += header[i] ;

    i++ ;
  }

  // mode de la requete
  if (sParam[2] == "1")
    bReqModeDoc = true ;
  else
    bReqModeDoc = false ;

  // au cas o�...
  pChemArray->vider() ;
  _aRequestResults.vider() ;
  nbChem = 0 ;

  // boucle de chargement de la requete
  while (!inFile.eof())
  {
    getline(inFile,line) ;

    if (strlen(line.c_str()) >= 3)
    {
      string sType = string(line, 0, 3) ;

      size_t pos2 = line.find('\"') ;
      if (NPOS == pos2)
        continue ;

      string sValues = string(line, pos2 + 1, strlen(line.c_str()) - pos2 - 1) ;

      if (sType == "pat")
        ChargerRequeteCritPat(sValues) ;
      else if (sType == "doc")
        ChargerRequeteCritDoc(sValues) ;
      else if (sType == "lib")
      	ChargerRequeteCritLib(sValues, sParam[0]) ;
      else if (sType == "req")
      	ChargerRequeteCritReq(sValues) ;
    }
  } // fin du while

	inFile.close() ;

	AfficheListeChem() ;
  DisplaySearchList() ;

	if (bReqModeDoc)
	{
		pModeDoc->Check() ;
		pModePat->Uncheck() ;
	}
	else
	{
		pModePat->Check() ;
		pModeDoc->Uncheck() ;
	}

	// on check les criteres
	if (bCritPat)
		pCritPatBox->Check() ;
  else
  	pCritPatBox->Uncheck() ;

	if (bCritDoc)
		pCritDocBox->Check() ;
  else
  	pCritDocBox->Uncheck() ;

	bDirty = false ;

	return true;
}

bool
NSRequeteDialog::ChargerRequeteCritPat(string sLib)
{
	// crit�res patient
	pCritPat->metAZero() ;
	bCritPat = true ;

	size_t pos1 = 0 ;
	size_t pos2 = sLib.find('\"', pos1) ;
  if (NPOS == pos2)
		return false ;

	int iIndice = 0 ;

	bool bKeepTurning = true ;
	while (bKeepTurning)
	{
		string sData = string(sLib, pos1, pos2 - pos1) ;

		switch(iIndice)
    {
    	case 0 : strcpy(pCritPat->nom,       sData.c_str()) ; break ;
      case 1 : strcpy(pCritPat->prenom,    sData.c_str()) ; break ;
      case 2 : strcpy(pCritPat->sexe,      sData.c_str()) ; break ;
      case 3 : strcpy(pCritPat->dateN1,    sData.c_str()) ; break ;
      case 4 : strcpy(pCritPat->dateN2,    sData.c_str()) ; break ;
      case 5 : strcpy(pCritPat->sitfam,    sData.c_str()) ; break ;
      case 6 : strcpy(pCritPat->code_post, sData.c_str()) ; break ;
      case 7 : strcpy(pCritPat->ville,     sData.c_str()) ; break ;
    }

		pos1 = pos2 + 1 ;
		pos2 = sLib.find('\"', pos1) ;
		if (NPOS == pos2)
			bKeepTurning = false ;
    else
    	iIndice++ ;
	}

	if (7 == iIndice)
		return true ;
	else
  	return false ;
}

bool
NSRequeteDialog::ChargerRequeteCritDoc(string sLib)
{
	pCritDoc->metAZero() ;
	bCritDoc = true ;

	size_t pos1 = 0 ;
	size_t pos2 = sLib.find('\"', pos1) ;
  if (NPOS == pos2)
		return false ;

	int iIndice = 0 ;

	bool bKeepTurning = true ;
	while (bKeepTurning)
	{
		string sData = string(sLib, pos1, pos2 - pos1) ;

		switch(iIndice)
    {
    	case 0 : pCritDoc->sCodeAuteur  = sData ; break ;
      case 1 : pCritDoc->sTitreAuteur = sData ; break ;
      case 2 : pCritDoc->sCodeRoot    = sData ; break ;
      case 3 : pCritDoc->sDate1       = sData ; break ;
      case 4 : pCritDoc->sDate2       = sData ; break ;
    }

		pos1 = pos2 + 1 ;
		pos2 = sLib.find('\"', pos1) ;
		if (NPOS == pos2)
			bKeepTurning = false ;
    else
    	iIndice++ ;
	}

	if (4 == iIndice)
		return true ;
	else
  	return false ;
}

bool
NSRequeteDialog::ChargerRequeteCritLib(string sLib, string sVerNum)
{
  size_t pos1 = 0 ;
  size_t pos2 = sLib.find('\"', pos1) ;
  if (NPOS == pos2)
    return false ;
  string sData = string(sLib, pos1, pos2 - pos1) ;

  NSRequestResult* pRR = new NSRequestResult ;
  pRR->setRequestLabel(sData) ;

  if (string("1.0") == sVerNum)
    pRR->setRequestName(string("?")) ;
  else  {
    // libell� de requete
    pos1 = pos2 + 1 ;
    pos2 = sLib.find('\"', pos1) ;
    if (NPOS == pos2)
    	pRR->setRequestName(string("?")) ;
    else
    {
    	sData = string(sLib, pos1, pos2 - pos1) ;
    	pRR->setRequestName(sData) ;
    }
  }

  _aRequestResults.push_back(pRR) ;

  return true ;
}

bool
NSRequeteDialog::ChargerRequeteCritReq(string sLib)
{
	string sCheminBrut, sLibelle, sCheminRech;

	// chemin de requete
	size_t pos1 = 0 ;
  size_t pos2 = sLib.find('\"', pos1) ;
  if (pos2 == NPOS)
  	return false ;

  sCheminBrut = string(sLib, pos1, pos2 - pos1) ;

  NSEditReqDialog* pEditReqDlg =
                        new NSEditReqDialog(this, pContexte, pNSResModule) ;

  // on charge le tableau Pere avec le chemin brut
  pEditReqDlg->ParsingChemin(sCheminBrut, true) ;
  // On reconstitue le chemin de recherche �quivalent  // grace au dialogue NSEditReqDialog
  pEditReqDlg->ComposeChemin(sCheminRech, pEditReqDlg->pPereArray, true) ;
  delete pEditReqDlg ;

  // on forme enfin le libell�
  TrouveLibElement(sCheminRech, sLibelle) ;
  pChemArray->push_back(new NSElement(sCheminBrut, sLibelle, sCheminRech)) ;
  nbChem++ ;

	return true ;
}

void
NSRequeteDialog::CmOuvrir()
{
	char path[1024] ;
	// on choisi d'abord le r�pertoire par d�faut des requetes (NREQ)
	strcpy(path, (pContexte->PathName("NREQ")).c_str()) ;

	TFileOpenDialog::TData initData(OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
                                  "Tous fichiers (*.NRQ)|*.nrq|",
                                  0, path, "NRQ") ;

	int iUserChoice = TFileOpenDialog(pContexte->GetMainWindow(), initData).Execute() ;

	pContexte->reallocateBaseDirectory() ;

	if (IDOK != iUserChoice)
		return ;

	sFileName = string(initData.FileName);

	if (!ChargerRequete(sFileName))
	{
		erreur("Impossible de charger le fichier requete sp�cifi�.", standardError, 0, GetHandle()) ;
		return;
	}

	size_t pos = sFileName.find_last_of('\\') ;
	if (pos != NPOS)
		sFileName = string(sFileName, pos+1, strlen(sFileName.c_str())-pos-1) ;

	pNomReq->SetText(sFileName.c_str()) ;
}

void
NSRequeteDialog::EcrireRequete(string& sOut)
{
	struct date dateSys;
	char dateJour[10];

	getdate(&dateSys) ;
	sprintf(dateJour, "%4d%02d%02d", dateSys.da_year, dateSys.da_mon, dateSys.da_day) ;

	// on �crit d'abord le header (1�re ligne) dans sOut
	sOut += string("2.0") + "\"" ;      // num�ro de version
	sOut += string(dateJour) + "\"" ;   // date du jour
	if (bReqModeDoc)
		sOut += "1\n" ;
	else
		sOut += "2\n" ;

	// on �crit les crit�res patient
	if (bCritPat)
	{
		sOut += string("pat") + "\"" ;
    sOut += string(pCritPat->nom) + "\"" ;
    sOut += string(pCritPat->prenom) + "\"" ;
    sOut += string(pCritPat->sexe) + "\"" ;
    sOut += string(pCritPat->dateN1) + "\"" ;
    sOut += string(pCritPat->dateN2) + "\"" ;
    sOut += string(pCritPat->sitfam) + "\"" ;
    sOut += string(pCritPat->code_post) + "\"" ;
    sOut += string(pCritPat->ville) + "\"" ;
    sOut += "$\n" ;
	}

	// on �crit les crit�res document
	if (bCritDoc)
	{
  	sOut += string("doc") + "\"" ;
    sOut += pCritDoc->sCodeAuteur + "\"" ;
    sOut += pCritDoc->sTitreAuteur + "\"" ;
    sOut += pCritDoc->sCodeRoot + "\"" ;
    sOut += pCritDoc->sDate1 + "\"" ;
    sOut += pCritDoc->sDate2 + "\"" ;
    sOut += "$\n" ;
	}

	// on �crit tous les chemins bruts de la requete
  int k = 1 ;  char numChem[5] ;

	if (false == pChemArray->empty())
	{
  	for (NSEltIter i = pChemArray->begin(); i != pChemArray->end(); i++)
    {
    	sprintf(numChem, "%d", k) ;
      sOut += "req" + string(numChem) + "\"" ;
      sOut += (*i)->code + "\"" ;
      sOut += "$\n" ;
      k++ ;
    }
	}

  if (false == _aRequestResults.empty())
	{
  	NSRequestResultIter it = _aRequestResults.begin() ;
    for (; _aRequestResults.end() != it; it++)
    {
      // on �crit le libell� de requ�te
      sOut += string("lib") + string(" \"") ;
      sOut += (*it)->_sRequestBooleanLabel + "\"" ;
      sOut += (*it)->_sRequestName + "\"" ;
      sOut += "$\n" ;
    }
  }
}

voidNSRequeteDialog::CmEnregistrer()
{
	string sFichierRequete = "" ;
	ofstream outFile ;

	// (on r�cup�re la derni�re version du libell� de la requete)	// pEditReq->GetText(sLibReq) ;

	NSNomGdDialog* pNomGdDlg =		new NSNomGdDialog(this, pContexte->PathName("NREQ"), sFileName, "nrq", pContexte) ;

	if (IDOK != pNomGdDlg->Execute())	{
  	delete pNomGdDlg ;
    return ;
	}

	// on peut enregistrer sous le nom de fichier propos�
	string sNomFichier = pNomGdDlg->sFichier ;
  delete pNomGdDlg ;

	if (string("") == sNomFichier)
		return ;

	EcrireRequete(sFichierRequete) ;

	outFile.open(sNomFichier.c_str()) ;
	if (!outFile)
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningOutputFile") ;
    sErrorText += string(" (") + sNomFichier + string(")");
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
  }

	for (size_t i=0; i < strlen(sFichierRequete.c_str()); i++)
		outFile.put(sFichierRequete[i]) ;

	outFile.close() ;

  bDirty = false ;

	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
  string sText    = pContexte->getSuperviseur()->getText("searchingRequestForm", "researchSavedOnFile") ;
	MessageBox(sText.c_str(), sCaption.c_str(), MB_OK) ;

	size_t pos = sNomFichier.find_last_of('\\') ;
	if (pos != NPOS)
		sFileName = string(sNomFichier, pos+1, strlen(sNomFichier.c_str())-pos-1) ;
	else
		sFileName = sNomFichier ;

	pNomReq->SetText(sFileName.c_str()) ;
}

voidNSRequeteDialog::CmNewReq()
{
	if (bReqEnCours)
		return ;

	NSEditReqDialog* pEditReqDlg =
        new NSEditReqDialog(this, pContexte, pNSResModule) ;

	if (pEditReqDlg->Execute() == IDOK)	{
  	string sCode     = pEditReqDlg->sCheminPere ;
    string sLibelle  = "" ;
    string sChemRech = pEditReqDlg->sCheminRechPere ;
    int     lastIndex ;
    TrouveLibElement(sChemRech, sLibelle) ;
    // Note : � ce niveau, la variable d�calage est utilis�e
    // pour stocker le chemin de recherche (car on est dans une requete et non un �l�ment)
    pChemArray->push_back(new NSElement(sCode, sLibelle, sChemRech)) ;
    nbChem++ ;
    AfficheListeChem() ;
    lastIndex = pListeChem->GetItemCount() - 1 ;
    pListeChem->SetFocus() ;
    pListeChem->SetSel(lastIndex, true) ;

    bDirty = true ;
	}

	delete pEditReqDlg ;
}

voidNSRequeteDialog::CmModReq()
{
	if (bReqEnCours)
		return ;

	int eltChoisi = pListeChem->IndexItemSelect() ;

	if (-1 == eltChoisi)
	{
		erreur("Vous devez s�lectionner un chemin � modifier.", standardError, 0) ;
		return ;
	}

	NSEditReqDialog* pEditReqDlg =
        new NSEditReqDialog(this, pContexte, pNSResModule) ;

	// on charge le tableau Pere
	// (la donnee code contient le chemin brut avec les codes sens et les d�calages)
	pEditReqDlg->ParsingChemin(((*pChemArray)[eltChoisi])->code, true) ;

	if (pEditReqDlg->Execute() == IDOK)
	{
		string sCode = pEditReqDlg->sCheminPere ;
    string sLibelle = "" ;
    string sChemRech = pEditReqDlg->sCheminRechPere ;

    TrouveLibElement(sChemRech, sLibelle) ;
    ((*pChemArray)[eltChoisi])->code = sCode ;
    ((*pChemArray)[eltChoisi])->libelle = sLibelle ;
    ((*pChemArray)[eltChoisi])->decalage = sChemRech ;
    AfficheListeChem() ;
    pListeChem->SetFocus() ;
    pListeChem->SetSel(eltChoisi, true) ;

    bDirty = true ;
	}

	delete pEditReqDlg ;
}

voidNSRequeteDialog::CmDelReq()
{
	if ((true == bReqEnCours) || (true == pChemArray->empty()))
		return ;

	int eltChoisi = pListeChem->IndexItemSelect() ;
	if (eltChoisi == -1)
	{
		string sWarningText = pContexte->getSuperviseur()->getText("searchingRequestFormWarnings", "aPathMustBeSelected") ;
		erreur(sWarningText.c_str(), warningError, 0) ;		return ;
	}

	NSEltIter i;
	int j;
	for (i = pChemArray->begin(), j = 0; i != pChemArray->end(); i++, j++)
	{
		if (j == eltChoisi)
		{
    	delete *i ;
			pChemArray->erase(i) ;
			nbChem -= 1 ;
      bDirty = true ;
			break ;
		}
	}

	AfficheListeChem() ;
}

voidNSRequeteDialog::CmDupReq()
{
	if ((true == bReqEnCours) || (true == pChemArray->empty()))
		return ;

	int eltChoisi = pListeChem->IndexItemSelect() ;	if (eltChoisi == -1)
	{
		string sWarningText = pContexte->getSuperviseur()->getText("searchingRequestFormWarnings", "aPathMustBeSelected") ;
		erreur(sWarningText.c_str(), warningError, 0) ;
		return ;
	}

	NSElement ElementSource = *((*pChemArray)[eltChoisi]) ;
	pChemArray->push_back(new NSElement(ElementSource)) ;	nbChem++ ;
  bDirty = true ;

	AfficheListeChem() ;}

voidNSRequeteDialog::CmCriteresPatient()
{
	if (bReqEnCours)
	{
		if (bCritPat)
			pCritPatBox->Check() ;
		else
			pCritPatBox->Uncheck() ;

		return ;	}

	NSCritReqPatDialog* pCritPatDlg = new NSCritReqPatDialog(this, pContexte, pNSResModule);	if (bCritPat)
		*(pCritPatDlg->pData) = *pCritPat ;

	if (pCritPatDlg->Execute() == IDOK)	{
		*pCritPat = *(pCritPatDlg->pData) ;
		if (pCritPatDlg->bEffacer)
		{
			pCritPatBox->Uncheck() ;
			bCritPat = false ;
		}
		else
		{
			pCritPatBox->Check() ;
			bCritPat = true ;
		}
    bDirty = true ;
	}
	else
	{
		if (bCritPat)
			pCritPatBox->Check() ;
		else
			pCritPatBox->Uncheck() ;
	}

	delete pCritPatDlg ;}

voidNSRequeteDialog::CmCriteresDocument()
{
	if (bReqEnCours)
	{
  	if (bCritDoc)
    	pCritDocBox->Check() ;
    else
    	pCritDocBox->Uncheck() ;
    return ;
	}

	NSCritReqDocDialog* pCritDocDlg = new NSCritReqDocDialog(this, pContexte, pNSResModule) ;
	if (bCritDoc)
		*(pCritDocDlg->pData) = *pCritDoc ;

	if (pCritDocDlg->Execute() == IDOK)
	{
  	*pCritDoc = *(pCritDocDlg->pData) ;
    if (pCritDocDlg->bEffacer)
    {
    	pCritDocBox->Uncheck() ;
      bCritDoc = false ;
    }
    else
    {
    	pCritDocBox->Check() ;
      bCritDoc = true ;
    }
    bDirty = true ;
	}
  else
  {
  	if (bCritDoc)
    	pCritDocBox->Check() ;
    else
    	pCritDocBox->Uncheck() ;
	}

	delete pCritDocDlg ;
}

voidNSRequeteDialog::CmModePat()
{
	if (!bReqEnCours)
	{
  	if (pModePat->GetCheck() == BF_CHECKED)
    	bReqModeDoc = false;
    else
    	bReqModeDoc = true;
	}

	if (bReqModeDoc)	{
  	pModeDoc->Check();
    pModePat->Uncheck();
	}
	else
	{
		pModeDoc->Uncheck();
		pModePat->Check();
	}

  bDirty = true ;
}
voidNSRequeteDialog::CmModeDoc()
{
	if (!bReqEnCours)
	{
  	if (pModeDoc->GetCheck() == BF_CHECKED)
    	bReqModeDoc = true ;
    else
    	bReqModeDoc = false ;
	}

	if (bReqModeDoc)
	{
  	pModeDoc->Check() ;
    pModePat->Uncheck() ;
	}
  else
  {
  	pModeDoc->Uncheck() ;
    pModePat->Check() ;
	}
  bDirty = true ;
}

void
NSRequeteDialog::CmOuvrante()
{
	if (bReqEnCours)
		return ;

	pEditReq->GetText(sLibReq) ;
	sLibReq += string("(") ;
	pEditReq->SetText(sLibReq.c_str()) ;
}

voidNSRequeteDialog::CmET()
{
	if (bReqEnCours)
		return ;

	pEditReq->GetText(sLibReq) ;	sLibReq += string(" * ") ;
	pEditReq->SetText(sLibReq.c_str()) ;
}

voidNSRequeteDialog::CmOU()
{
	if (bReqEnCours)
		return ;

	pEditReq->GetText(sLibReq) ;	sLibReq += string(" + ") ;
	pEditReq->SetText(sLibReq.c_str()) ;
}

voidNSRequeteDialog::CmFermante()
{
	if (bReqEnCours)
		return ;

	pEditReq->GetText(sLibReq) ;
	sLibReq += string(")") ;
	pEditReq->SetText(sLibReq.c_str()) ;
}

voidNSRequeteDialog::CmInsererChemin()
{
	if (bReqEnCours)
		return ;

	int numReq = pListeChem->IndexItemSelect() + 1 ;
	char cNumReq[10] = "" ;
	sprintf(cNumReq, "%d", numReq) ;
	pEditReq->GetText(sLibReq) ;
	sLibReq += string(cNumReq) ;
	pEditReq->SetText(sLibReq.c_str()) ;
}

intNSRequeteDialog::CherchePatientSuivant(NSPersonsAttributeIter& iterPatient, NSPatInfo* pPatInfo){	if (NULL == pPatInfo)		return 0 ;	if (iterPatient == NULL)  	iterPatient = pPersonList->begin() ;  else  	iterPatient++ ;  if (iterPatient == pPersonList->end())  	return 0 ;	*pPatInfo = NSPatInfo(*iterPatient, pContexte) ;	return 1 ;}int
NSRequeteDialog::ChercheDocumentSuivant(DocumentIter& iterDoc, NSDocumentHisto* pDocHisto)
{
	if (NULL == iterDoc)
		iterDoc = VectDocument.begin() ;	else		iterDoc++ ;	if (iterDoc == VectDocument.end())		return 0 ;

	VecteurString VectString ;
	NSLinkManager* pLink = Patient.pGraphPerson->pLinkManager ;

	(*iterDoc)->pPatPathoArray->vider() ;
	bool bOk = false ;

	// On remonte le lien data du m�ta-document
	pLink->TousLesVrais((*iterDoc)->sCodeDocMeta, NSRootLink::docData, &VectString) ;
	if (false == VectString.empty())
	{
		string sCodeDocData = *(*(VectString.begin())) ;
    string sCodePat = string(sCodeDocData, 0, PAT_NSS_LEN) ;
    string sCodeDoc = string(sCodeDocData, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;

    (*iterDoc)->setPatient(sCodePat) ;
    (*iterDoc)->setDocument(sCodeDoc) ;

    if (((*iterDoc)->ParseMetaDonnees()) &&
            ((*iterDoc)->DonnePatPatho((*iterDoc)->pPatPathoArray, &Patient)))
    	bOk = true ;
	}
  else
  {
  	// m�ta-document sans lien data
    // NOTE : pour ce type de documents on met dans pDonnees le code document du Meta
    // cela permet de les retrouver dans l'historique

    string sCodePat = string((*iterDoc)->sCodeDocMeta, 0, PAT_NSS_LEN) ;
    string sCodeDoc = string((*iterDoc)->sCodeDocMeta, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;

    (*iterDoc)->setPatient(sCodePat) ;
    (*iterDoc)->setDocument(sCodeDoc) ;

    if ((*iterDoc)->ParseMetaDonnees())
    {
    	(*iterDoc)->pPatPathoArray->ajoutePatho("ZDOCU1", 0) ;
      bOk = true ;
    }
	}

	//probl�me de r�cup�ration de la patpatho (ou de parsing) : le document
	//ne figure pas dans l'historique

	if (false == bOk)		return -1 ;

	*pDocHisto = *(*iterDoc) ;
	return 1 ;
}


// Fonction qui compare deux valeurs selon le format du champ complement// on a soit une valeur exacte, et on v�rifie si val1 == val2,
// soit un intervalle, et on v�rifie si val2 est inclus dans val1
// Note : les string ne contiennent ici que la valeur, non le '$'
// les unit�s sont trait�es en amont pour l'instant. Ici les deux valeurs
// sont consid�r�es de m�me unit�
bool
NSRequeteDialog::ValeurEquivalente(string sVal1, string sVal2)
{
	string sLang = "" ;
	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;

  gereNum num1 = gereNum(pContexte, sLang) ;
  gereNum num2 = gereNum(pContexte, sLang) ;
  string  sUnit1 = "", sFmt1 = ""; // valeurs bidon pour pouvoir instancier les gereNum
  string  sUnit2 = "", sFmt2 = ""; // valeurs bidon pour pouvoir instancier les gereNum

  num1.instancier(&sVal1, &sUnit1, &sFmt1) ;
  num2.instancier(&sVal2, &sUnit2, &sFmt2) ;

  if (num1.estExact())
	{
  	if (num2.estExact())
    {
    	if (num1.getValeur() == num2.getValeur())
      	return true ;
      else
      	return false ;
    }
    else if (num2.estInfEgal() && num2.estSupEgal())
    {
    	// cas de l'intervalle qui repr�sente une valeur exacte...
      if ((num1.getValeur() == num2.getValeurInf()) &&
          (num1.getValeur() == num2.getValeurSup()))
      	return true ;
      else
      	return false ;
    }
    else
    	return false ;
	}
  else if (num1.estInf() && num1.estSup())
  {
  	// Ici si num2 n'a pas une borne inf ET une borne sup
    // il n'est forc�ment pas inclus dans num1
    if (num2.estInf() && num2.estSup())
    {
    	if ((num1.getValeurInf() <= num2.getValeurInf()) &&
          (num1.getValeurSup() >= num2.getValeurSup()))
      {
      	// cas de la borne inf
        if (num1.getValeurInf() == num2.getValeurInf())
        	if ((!num1.estInfEgal()) && (num2.estInfEgal()))
          	return false;

        // cas de la borne sup
        if (num1.getValeurSup() == num2.getValeurSup())
        	if ((!num1.estSupEgal()) && (num2.estSupEgal()))
          	return false ;

        return true ;
    	}
      else
      	return false ;
    }
    else if (num2.estExact())
    {
    	// cas de la valeur entre les bornes
      if ((num1.getValeurInf() < num2.getValeur()) &&
          (num1.getValeurSup() > num2.getValeur()))
      	return true ;
      // cas de la valeur �gale � la borne inf
      else if ((num1.getValeurInf() == num2.getValeur()) &&
               (num1.estInfEgal()))
      	return true ;
      // cas de la valeur �gale � la borne sup
      else if ((num1.getValeurSup() == num2.getValeur()) &&
               (num1.estSupEgal()))
      	return true ;
      // valeur en dehors
      else
      	return false ;
    }
    else
    	return false ;
  }
  else if (num1.estInf())
  {
  	if (num2.estInf())
    {
    	// l'intervalle ou la borne num2 doit etre au-dessus de la borne num1
      if (num1.getValeurInf() <= num2.getValeurInf())
      {
      	// cas de la borne inf
        if (num1.getValeurInf() == num2.getValeurInf())
        	if ((!num1.estInfEgal()) && (num2.estInfEgal()))
          	return false ;

        return true ;
      }
      else
      	return false ;
    }
    else if (num2.estExact())
    {
    	// la valeur num2 doit etre au-dessus de la borne num1
      if (num1.getValeurInf() <= num2.getValeur())
      {
      	// cas de la borne inf
        if ((num1.getValeurInf() == num2.getValeur()) &&        	  (!num1.estInfEgal()))
        	return false ;

        return true;
      }
      else
      	return false ;
    }
    else
    	return false ;
	}
	else if (num1.estSup())
  {
  	if (num2.estSup())
    {
    	// l'intervalle ou la borne num2 doit etre en-dessous de la borne num1
      if (num1.getValeurSup() >= num2.getValeurSup())
      {
      	// cas de la borne sup
        if (num1.getValeurSup() == num2.getValeurSup())
        	if ((!num1.estSupEgal()) && (num2.estSupEgal()))
          	return false ;

        return true ;
      }
      else
      	return false ;
    }
    else if (num2.estExact())
    {
    	// la valeur num2 doit etre en-dessous de la borne num1
      if (num1.getValeurSup() >= num2.getValeur())
      {
      	// cas de la borne sup
        if ((num1.getValeurSup() == num2.getValeur()) && (!num1.estSupEgal()))
        	return false ;

        return true ;
      }
      else
      	return false ;
    }
    else
    	return false ;
	}

	// pour les cas impossibles...
	return false ;
}

// Fonction qui cherche le chemin de num�ro numChem// dans la PatPatho du document en cours (variable globale Document)
bool
NSRequeteDialog::CheminDansDocument(int numChemin)
{
	bool   bRes = false ;
	size_t pos ;

	if ((numChemin < 1) || (numChemin > nbChem))    {
        // on laisse les messages d'erreur de 1er niveau
        erreur("Num�ro de chemin erronn� dans le libell� de requete.", standardError, 0, GetHandle()) ;
        return false;
    }

	string sChemRech = ((*pChemArray)[numChemin - 1])->decalage ;

	// on ne signale pas les patpatho vides pour �viter trop de messages d'erreur
	if (false == Document.pPatPathoArray->empty())
	{
  	string sLastElt ;
    // on extrait d'abord le dernier �l�ment du chemin
    pos = sChemRech.find_last_of(cheminSeparationMARK) ;
    if (pos != NPOS)
    	sLastElt = string(sChemRech, pos+1, strlen(sChemRech.c_str())-pos-1) ;
    else // cas en pratique impossible
    	sLastElt = sChemRech ;

    // on traite le cas des valeurs chiffr�es
    if ((sLastElt != "") && (sLastElt[0] == '2'))
    {
    	string sValeurElt, sUniteElt ;
      string sValeurDoc = "", sUniteDoc = "" ;
      size_t pos1, pos2 ;

      // on reprend le chemin sans le dernier �l�ment
      if (NPOS != pos)
      	sChemRech = string(sChemRech, 0, pos) ;
      else
      	sChemRech = "" ;

      // on extrait l'unit� et la valeur recherch�e
      pos1 = sLastElt.find(intranodeSeparationMARK) ;
      if (NPOS == pos1)
      {
      	// on laisse les messages d'erreur de 1er niveau
        erreur("Valeur chiffr�e sans format dans un chemin de recherche.", standardError, 0, GetHandle()) ;
        return false ;
      }

      sUniteElt = string(sLastElt, 0, pos1);
      pos2 = sLastElt.find(intranodeSeparationMARK, pos1+1);
      if (NPOS == pos2)
      {
      	erreur("Valeur chiffr�e non instanci�e dans un chemin de recherche.", standardError, 0, GetHandle()) ;
        return false ;
      }

      sValeurElt = string(sLastElt, pos2+1, strlen(sLastElt.c_str())-pos2-1) ;
      if ((sValeurElt == "") || (sValeurElt[0] != '$'))
      {
      	// on laisse les messages d'erreur de 1er niveau
        erreur("Valeur chiffr�e incorrecte dans un chemin de recherche.", standardError, 0, GetHandle()) ;
        return false ;
      }
      // on enl�ve le '$' pour pouvoir comparer avec la valeur du complement
      sValeurElt = string(sValeurElt, 1, strlen(sValeurElt.c_str())-1) ;

      bRes = Document.pPatPathoArray->CheminDansPatpatho(0, sChemRech, &sValeurDoc, &sUniteDoc) ;

    	// si on a trouv� une valeur apr�s sChemRech, on v�rifie si
      // elle correspond � la valeur recherch�e
      if (bRes)
      {
      	if (sUniteElt == sUniteDoc)
        	bRes = ValeurEquivalente(sValeurElt, sValeurDoc) ;
        else
        	bRes = false ;
      }
    }
    else // cas classique
    	bRes = Document.pPatPathoArray->CheminDansPatpatho(sChemRech) ;
	}

	return bRes ;
}

// Fonction qui v�rifie si le patient en cours correspond aux crit�res patientbool
NSRequeteDialog::PatientVerifieCriteres()
{
	if (strcmp(pCritPat->sexe, ""))
  	if (strcmp(pCritPat->sexe, Patient.getszSexe()))
    	return false ;

	if (strcmp(pCritPat->nom, ""))
  	if (strcmp(pCritPat->nom, Patient.getszNom()))
    	return false ;

	if (strcmp(pCritPat->prenom, ""))		if (strcmp(pCritPat->prenom, Patient.getszPrenom()))
			return false ;

	if ((strcmp(pCritPat->dateN1, "")) || (strcmp(pCritPat->dateN2, "")))  {  	string sBirthDate = Patient.getNaissance() ;    NVLdVTemps tpsBirthDate ;
    tpsBirthDate.initFromDate(sBirthDate) ;    if (strcmp(pCritPat->dateN1, ""))    {    	NVLdVTemps tpsDateN1 ;    	tpsDateN1.initFromDate(string(pCritPat->dateN1)) ;    	if (tpsBirthDate < tpsDateN1)
      	return false ;
    }
    if (strcmp(pCritPat->dateN2, ""))    {
    	NVLdVTemps tpsDateN2 ;
    	tpsDateN2.initFromDate(string(pCritPat->dateN2)) ;
      if (tpsBirthDate > tpsDateN2)
      	return false ;
    }
	}
	if ((strcmp(pCritPat->sitfam, "")) && (strcmp(pCritPat->sitfam, "I")))
	{
  	if (strcmp(pCritPat->sitfam, Patient.getszSitfam()))
    	return false ;
	}
	return true ;
}

// Fonction qui v�rifie si le document en cours correspond aux crit�res documentbool
NSRequeteDialog::DocumentVerifieCriteres()
{
	if (string("") != pCritDoc->sCodeAuteur)
		if (pCritDoc->sCodeAuteur != Document.getCreator())
    	return false ;

	if (string("") != pCritDoc->sCodeRoot)
	{
  	// �videmment on doit ici comparer les codes sens !!!
    string sCodeLexique1, sCodeSens1, sCodeLexique2, sCodeSens2 ;

    sCodeLexique1 = pCritDoc->sCodeRoot ;
    pContexte->getSuperviseur()->getDico()->donneCodeSens(&sCodeLexique1, &sCodeSens1) ;
    if ((NULL == Document.pPatPathoArray) || (true == Document.pPatPathoArray->empty()))
    	return false ;

    sCodeSens2 = (*(Document.pPatPathoArray->begin()))->getLexiqueSens(pContexte) ;

		if (sCodeSens1 != sCodeSens2)    	return false ;
	}

	if ((string("") != pCritDoc->sDate1) || (string("") != pCritDoc->sDate2))
  {
  	string sDateDoc = Document.GetDateDoc() ;
    NVLdVTemps tpsDateDoc ;
    tpsDateDoc.initFromDate(sDateDoc) ;

    if (string("") != pCritDoc->sDate1)
		{
    	NVLdVTemps tpsDate1 ;
			tpsDate1.initFromDate(pCritDoc->sDate1) ;
      if (tpsDateDoc < tpsDate1)
      	return false ;
    }

    if (string("") != pCritDoc->sDate2)
    {
    	NVLdVTemps tpsDate2 ;
			tpsDate2.initFromDate(pCritDoc->sDate2) ;
      if (tpsDateDoc > tpsDate2)
      	return false ;
    }
  }

	return true ;
}

// Fonction qui r�initialise les r�sultats de requete en fonction du modevoid
NSRequeteDialog::ReinitResults(bool bModeDoc)
{
	if (true == pChemArray->empty())
		return ;

	for (NSEltIter i = pChemArray->begin(); pChemArray->end() != i; i++)
	{
		if (bModeDoc)
			(*i)->result = -1 ;
    else
    {
    	// en mode patient, on ne remet que les false � -1
      if (0 == (*i)->result)
      	(*i)->result = -1;
    }
	}
}

// V�rifie si le chemin numReq appartient au document en cours,// si le r�sultat n'est pas d�j� dans chemin.result
// => si chemin.result vaut -1, on r��value le r�sultat par CheminDansDocument
//    sinon on renvoie directement chemin.result
int
NSRequeteDialog::Interprete(int numReq)
{
	int iRes;

	if ((numReq < 1) || (numReq > nbChem))	{
		// on laisse les messages d'erreur de 1er niveau
		erreur("Num�ro de chemin erronn� dans le libell� de requete.", standardError, 0, GetHandle()) ;
		return -1 ;
	}

	iRes = ((*pChemArray)[numReq - 1])->result ;
	if (-1 == iRes)	{
  	// on r��value la requete numReq sur le document en cours
    if (CheminDansDocument(numReq))
    {
    	((*pChemArray)[numReq - 1])->result = 1 ;
      iRes = 1 ;
    }
    else
    {
    	((*pChemArray)[numReq - 1])->result = 0 ;      iRes = 0 ;
    }
	}

	return iRes ;
}

// Fonction d'�valuation du libell� de requete// renvoie 0 ou 1 dans le cas normal, -1 si erreur
// La chaine vide est consid�r�e comme vraie (1)
// pour que l'on puisse chercher uniquement en fonction des crit�res
int
NSRequeteDialog::Interprete(string sReq, size_t& cc)
{
	int  result = 1 ;
	int  result1 ;
	char oper = ' ' ;

	while (cc < strlen(sReq.c_str()))
	{
		result1 = 1 ;

    while ((cc < strlen(sReq.c_str())) && (sReq[cc] == ' '))
    	cc++ ;

    // on �value l'op�rande en cours
    if (cc < strlen(sReq.c_str()))
    {
    	// on doit avoir ici une '(' ou un num�ro de requete
      if ((sReq[cc] >= '0') && (sReq[cc] <= '9'))
      {
      	string sNumReq = "" ;

        while ((cc < strlen(sReq.c_str())) && (sReq[cc] >= '0') && (sReq[cc] <= '9'))
        {
        	sNumReq += string(1, sReq[cc]) ;
          cc++ ;
        }

        if (string("") != sNumReq)
        	result1 = Interprete(atoi(sNumReq.c_str())) ;
      }
      else if ('(' == sReq[cc])
      {
      	cc++ ;
        result1 = Interprete(sReq, cc) ;
      }
      else
      {
      	// on laisse les messages d'erreur de 1er niveau
        erreur("Erreur de syntaxe dans le libell� de la requete.", standardError, 0, GetHandle()) ;
        return -1 ;
      }
    }

    // cas erreur � l'�valuation de l'op�rande
    if (-1 == result1)
    	return -1 ;

    // on calcule le r�sultat selon l'op�rateur en cours
    if      (' ' == oper)
    	result = result1 ;
    else if ('+' == oper)
    	result = result || result1 ;
    else if ('*' == oper)
    	result = result && result1 ;

    // on avance � nouveau
    while ((cc < strlen(sReq.c_str())) && (' ' == sReq[cc]))
    	cc++ ;

    // on �value l'op�rateur
    if (cc < strlen(sReq.c_str()))
    {
    	// on doit avoir ici une ')' ou un op�rateur
      if (('+' == sReq[cc]) || ('*' == sReq[cc]))
      {
      	oper = sReq[cc] ;
        cc++ ;
      }
      else if (')' == sReq[cc])
      {
      	cc++ ;
        return result ;
      }
      else
      {
      	// on laisse les messages d'erreur de 1er niveau
        erreur("Erreur de syntaxe dans le libell� de la requete.", standardError, 0, GetHandle()) ;
        return -1 ;
      }
    }
	}

	return result ; 
}
boolNSRequeteDialog::InitPersonList(){	string sLocalText = pContexte->getSuperviseur()->getText("searchingRequestForm", "loadingPatientsList") ;	pLanceur->displayStatusMessage(sLocalText) ;	const char* serviceName = (NautilusPilot::SERV_PATIENT_LIST).c_str() ;	if (NULL == pPersonList)  	pPersonList = new NSPersonsAttributesArray() ;  NSBasicAttributeArray AttrArray ;
	AttrArray.push_back(new NSBasicAttribute(ROLE, PATIENT_ROLE)) ;  AttrArray.push_back(new NSBasicAttribute(TRAIT, FIRST_NAME)) ;	AttrArray.push_back(new NSBasicAttribute(TRAIT, LAST_NAME)) ;
	AttrArray.push_back(new NSBasicAttribute(TRAIT, SEX)) ;
	AttrArray.push_back(new NSBasicAttribute(TRAIT, BIRTHDATE)) ;  bool listOk = pContexte->pPilot->personList(serviceName, pPersonList, &AttrArray) ;	//if ((!res) || (pPatiensList->empty()))
	if (!listOk)
	{
		std::string tempMessage = pContexte->pPilot->getWarningMessage();
		std::string tempError = pContexte->pPilot->getErrorMessage();
		if( tempMessage != "")
			::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK);
		if( tempError != "")
			::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK);
		return false;
	}


    /**********************************************
  if (!(pPatiensList->empty()))
		for (NSPersonsAttributeIter iterPatient = pPatiensList->begin(); iterPatient != pPatiensList->end(); iterPatient++)
		{
			NSPatInfo *pPatientEnCours = new NSPatInfo(*iterPatient, pContexte) ;
			pPatientsArray->push_back(pPatientEnCours) ;
		}  **************************************************/	return true ;}boolNSRequeteDialog::ChargeGraphePatient(){	char szPerson[PAT_NSS_LEN + 1] ;	strcpy(szPerson, Patient.getszNss()) ;

    /**********************************************
    if ((szPerson[0] != LocalPatient) && (pContexte->getUtilisateur()->haveGlobalSessionPassword() == false))
    {
    	LogPassInterface* getGlobPassword = new LogPassInterface(this,pContexte);
      getGlobPassword->Execute();
      delete  getGlobPassword;
    }
    **************************************************/

	char szInstance[3] ;
	int iInstance = pContexte->getSuperviseur()->getInstance() ;
	itoa(iInstance, szInstance, 10) ;

	SetCursor(0, IDC_WAIT) ;
	string user = pContexte->getUtilisateurID() ;

	NSBasicAttributeArray    AttrArray ;
	NSPersonsAttributesArray List ;

	// ouverture standard
	AttrArray.push_back(new NSBasicAttribute(PERSON,   string(szPerson))) ;
	AttrArray.push_back(new NSBasicAttribute(OPERATOR, user)) ;
	AttrArray.push_back(new NSBasicAttribute(CONSOLE,  string(pContexte->getSuperviseur()->getConsole()))) ;
	AttrArray.push_back(new NSBasicAttribute(INSTANCE, string(szInstance))) ;

	bool res = pContexte->pPilot->searchPatient(NautilusPilot::SERV_SEARCH_PATIENT.c_str(),
                                    Patient.pGraphPerson->pDataGraph, &List, &AttrArray) ;
	if (!res)
	{
        /***********************************
         std::string tempMessage = pContexte->pPilot->getWarningMessage();
         std::string tempError = pContexte->pPilot->getErrorMessage();
         if( tempMessage != "")
            ::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempMessage.c_str(), "Message Nautilus", MB_OK);
         if( tempError != "")
            ::MessageBox(pContexte->GetMainWindow()->GetHandle(), tempError.c_str(), "Message Nautilus", MB_OK);
         ***********************************/
		return false;
	}

	if ((!Patient.pGraphPerson->pDataGraph) ||
    	(!Patient.pGraphPerson->graphPrepare()))
	{
		return false;
	}

	Patient.pGraphPerson->bNeedUnlock	= false ;
	Patient.pGraphPerson->bReadOnly 	= true ;

	if (false == List.empty())
	{
		string sIsLocked = List.getAttributeValue("locked") ;
		if (sIsLocked == "ok")
			Patient.pGraphPerson->bNeedUnlock = true ;
		string sOperationType	= List.getAttributeValue("operationType") ;
		if (sOperationType == "readWrite")
			Patient.pGraphPerson->bReadOnly = false ;
	}

	Patient.pGraphPerson->setInfoPids(&AttrArray);
	Patient.pGraphPerson->pDataGraph->setLastTree();

	string sRootTree = Patient.pGraphPerson->getRootTree();
	// NSDataGraph* pGraph = Patient.pGraphPerson->pDataGraph;

	SetCursor(0, IDC_ARROW) ;

	// On pr�pare maintenant le VectDocument en le remplissant	// avec les m�tas	VectDocument.vider();	VecteurString VectString ;	NSLinkManager* pLink = Patient.pGraphPerson->pLinkManager ;	// chargement de l'index de sant�	pLink->TousLesVrais(sRootTree, NSRootLink::personHealthIndex, &VectString) ;
	if (false == VectString.empty())
	{
  	string sCodeDocIndex = *(*(VectString.begin())) ;
    NSDocumentHisto* pNSDocumentHisto = new NSDocumentHisto(new NSDocumentInfo(sCodeDocIndex, pContexte, &Patient)) ;
    VectDocument.push_back(pNSDocumentHisto) ;
	}

	// chargement de la synth�se
	VectString.vider() ;
	pLink->TousLesVrais(sRootTree, NSRootLink::personSynthesis, &VectString) ;
	if (false == VectString.empty())
	{
  	string sCodeDocSynth = *(*(VectString.begin())) ;
    NSDocumentHisto* pNSDocumentHisto = new NSDocumentHisto(new NSDocumentInfo(sCodeDocSynth, pContexte, &Patient)) ;
    VectDocument.push_back(pNSDocumentHisto) ;
	}

	// chargement de la fiche administrative
	VectString.vider();
	pLink->TousLesVrais(sRootTree, NSRootLink::personAdminData, &VectString) ;
  if (false == VectString.empty())
  {
  	string sCodeDocAdmin = *(*(VectString.begin())) ;
    NSDocumentHisto* pNSDocumentHisto = new NSDocumentHisto(new NSDocumentInfo(sCodeDocAdmin, pContexte, &Patient)) ;
    VectDocument.push_back(pNSDocumentHisto) ;
  }

  // fabTODO
  // chargement de l'Equipe de Sant�
  // Loading HealthTeam
  VectString.vider() ;
  pLink->TousLesVrais(sRootTree, NSRootLink::personHealthTeam, &VectString) ;
  if (false == VectString.empty())
	{
  	string sCodeDocHealthTeam = *(*(VectString.begin())) ;
    NSDocumentHisto *pNSDocumentHisto = new NSDocumentHisto(new NSDocumentInfo(sCodeDocHealthTeam, pContexte, &Patient)) ;
    VectDocument.push_back(pNSDocumentHisto) ;
  }

	// chargement de tous les documents
	VectString.vider() ;
  pLink->TousLesVrais(sRootTree, NSRootLink::personDocument, &VectString) ;
  if (false == VectString.empty())
  {
  	for (EquiItemIter i = VectString.begin(); i != VectString.end(); i++)
    {
    	NSDocumentHisto* pNSDocumentHisto = new NSDocumentHisto(new NSDocumentInfo(*(*i), pContexte, &Patient)) ;
      VectDocument.push_back(pNSDocumentHisto) ;
    }
  }	return true ;}
voidNSRequeteDialog::CmLancement()
{
	pLanceur->Create() ;
}

voidNSRequeteDialog::CmLancer()
{
	if (true == bReqEnCours)
		return ;

	bReqEnCours = true ;

  setModeFileErr(true) ;
	SetCursor(0, IDC_WAIT) ;

  // Reseting research results
  //
	if (false == _aRequestResults.empty())
	{
  	NSRequestResultIter it = _aRequestResults.begin() ;
  	for (; _aRequestResults.end() != it; it++)
    	(*it)->reinitForNewSearch() ;
  }

  int nbTrouves = 0 ;

	nbPatTotal = 0 ; nbPatCritPat = 0 ; nbPatCritDoc = 0 ; nbPatResult = 0 ;
	nbDocCritPat = 0 ; nbDocCritDoc = 0 ; nbDocResult = 0 ;

	bCherchePatient = true ;
	string sLocalText = pContexte->getSuperviseur()->getText("searchingRequestForm", "researchProcessOnDuty") ;
	pLanceur->displayStatusMessage(sLocalText) ;
	pContexte->getSuperviseur()->getApplication()->PumpWaitingMessages() ;
	InitPersonList() ;
	NSPersonsAttributeIter iterPatient = NULL ;
	DocumentIter iterDoc = NULL ;

  iPersonListSize = pPersonList->size() ;
	iCurrentPatient = 0 ;
  pLanceur->displayProgress(0) ;

  sLocalText = pContexte->getSuperviseur()->getText("searchingRequestForm", "numberOfPatientsLoaded") ;
  sLocalText += string(" ") + IntToString(iPersonListSize) ;
	pLanceur->displayStatusMessage(sLocalText) ;

  string  sCodeDocum, sNssPat;

	// on r�cup�re la derni�re version du libell� de la requete
	//pEditReq->GetText(sLibReq);

	while (bCherchePatient)	{
		int ret = CherchePatientSuivant(iterPatient, &Patient) ;

  	if (-1 == ret)    {
    	string sErrorText = pContexte->getSuperviseur()->getText("searchingRequestFormErrors", "errorAccessingNextPatient") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
      break ;
    }
    else if (0 == ret)
    {
    	// fin de la base...
      bCherchePatient = false ;
      break ;
    }

    iCurrentPatient++ ;
    pLanceur->displayProgress(100 * iCurrentPatient / iPersonListSize) ;

    sLocalText = pContexte->getSuperviseur()->getText("searchingRequestForm", "analysingPatient") ;
		sLocalText += string(" ") + IntToString(iCurrentPatient) + string(" / ") + IntToString(iPersonListSize) ;
    string sFoundText = pContexte->getSuperviseur()->getText("searchingRequestForm", "found") ;
    sLocalText += sFoundText + string(" -> ") + IntToString(nbTrouves) ;
		pLanceur->displayStatusMessage(sLocalText) ;

    // on lance la recherche sur les documents du patient    // Document est initialis� au premier document du patient
    pLanceur->pEditPat->SetText(Patient.getszNss()) ;

    pContexte->getSuperviseur()->getApplication()->PumpWaitingMessages() ;

    nbPatTotal++ ;
    bool bNouveauPatient   = true ;    bool bNouveauPatResult = true ;

    if (false == _aRequestResults.empty())
		{
  		NSRequestResultIter it = _aRequestResults.begin() ;
  		for (; _aRequestResults.end() != it; it++)
    		(*it)->_bNouveauPatResult = true ;
  	}

    // s�lection des crit�res du patient    if (pLanceur->bAvecPat && bCritPat)
    	bChercheDocument = PatientVerifieCriteres() ;
    else
    	bChercheDocument = true ;

    if (bChercheDocument)
    	bChercheDocument = ChargeGraphePatient() ;

    if (bChercheDocument)    {
    	nbPatCritPat++ ;

      iterDoc = NULL ;

    	// en mode patient, on n'oublie pas de r�initialiser      // pour chaque nouveau patient

      if (!bReqModeDoc)      	ReinitResults() ;
    }

    while (bChercheDocument)    {
    	ret = ChercheDocumentSuivant(iterDoc, &Document) ;

      if (-1 == ret)      {
      	// on laisse les messages d'erreur de 1er niveau
        string sErrorText = pContexte->getSuperviseur()->getText("searchingRequestFormErrors", "errorAccessingNextDocument") ;
        sErrorText += string(" : codeDoc = ") + (*iterDoc)->getID() ;
      	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
        SetCursor(0, IDC_ARROW) ;
        erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
        setModeFileErr(false) ;
        bReqEnCours = false ;
        return ;
      }
      else if (0 == ret)
      {
      	// fin du dossier patient
        bChercheDocument = false ;
        break ;
      }

      // on lance la requete sur le document
      pLanceur->pEditDoc->SetText(Document.getDocument().c_str()) ;      pContexte->getSuperviseur()->getApplication()->PumpWaitingMessages() ;
      nbDocCritPat++ ;
      bool bDocumOK = true ;

      // s�lection des crit�res du document
      if (pLanceur->bAvecDoc && bCritDoc)      	bDocumOK = DocumentVerifieCriteres() ;

      if (bDocumOK)      {
      	nbDocCritDoc++ ;

        // on compte le nombre de patients correspondants        if (bNouveauPatient)
        {
        	nbPatCritDoc++ ;
          bNouveauPatient = false ;
        }

        if ((true == pLanceur->bAvecLib) && (false == _aRequestResults.empty()))        {
        	ret = 0 ;

        	ReinitResults(bReqModeDoc) ;

          NSRequestResultIter it = _aRequestResults.begin() ;
          for ( ; _aRequestResults.end() != it; it++)
          {
          	size_t pos = 0 ; // � ne pas oublier : remettre au d�but de la string !!!
          	int iResult = Interprete((*it)->getRequestLabel(), pos) ;
            if (1 == iResult)
            {
            	ret = 1 ;

            	if (true == bReqModeDoc)
              {
              	(*it)->_nbDocResult++ ;

              	(*it)->_aVectDocumentResults.push_back(new NSDocumentHisto(*(*iterDoc))) ;
                // on compte le nombre de patients correspondants
          			if ((*it)->_bNouveauPatResult)
          			{
          				(*it)->_nbPatResult++ ;
            			(*it)->_bNouveauPatResult = false ;
          			}
                // pour l'instant, on charge les patients correspondants avec doublons
          			// en attendant de trouver mieux pour l'affichage des r�sultats
          			(*it)->_aVectPatientResults.push_back(new NSPatInfo(*iterPatient, pContexte)) ;
              }
              else
              {
              	(*it)->_nbPatResult++ ;
              	(*it)->_aVectPatientResults.push_back(new NSPatInfo(*iterPatient, pContexte)) ;
              }
            }
            pContexte->getSuperviseur()->getApplication()->PumpWaitingMessages() ;
          }
        }
        else
        	ret = 1 ;
      }
      else
      	ret = 0 ;

      if (-1 == ret)      {
      	// on laisse les messages d'erreur de 1er niveau
        string sErrorText = pContexte->getSuperviseur()->getText("searchingRequestFormErrors", "requestCannotBeTested") ;
        pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
        erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
        SetCursor(0, IDC_ARROW) ;
        string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName() ;
        sErrorText = pContexte->getSuperviseur()->getText("searchingRequestFormWarnings", "searchProcessStopped") ;
        MessageBox(sErrorText.c_str(), sCaption.c_str(), MB_OK) ;
        setModeFileErr(false) ;
        bReqEnCours = false ;
        return ;
      }
      else if (1 == ret)
      {
      	char cStatus[255] ;

        nbTrouves++ ;        sprintf(cStatus, "Trouv�s : %d", nbTrouves) ;

        pLanceur->displayStatusMessage(cStatus) ;
        pContexte->getSuperviseur()->getApplication()->PumpWaitingMessages() ;
        if (true == bReqModeDoc)        {
        	nbDocResult++ ;

          // on compte le nombre de patients correspondants          if (bNouveauPatResult)
          {
          	nbPatResult++ ;
            bNouveauPatResult = false ;
          }

          // Note : on a pris un NSDocHistoArray pour les r�sultats          // car cela permet d'utiliser la date de cr�ation du document.
          // cependant on ne charge pas ici la PatPatho, pour ne pas
          // encombrer la m�moire
          VectDocResultat.push_back(new NSDocumentHisto(*(*iterDoc))) ;
          // pour l'instant, on charge les patients correspondants avec doublons          // en attendant de trouver mieux pour l'affichage des r�sultats
          VectPatResultat.push_back(new NSPatInfo(*iterPatient, pContexte)) ;
        }        else
        {
        	nbPatResult++ ;

          // Dans ce cas, on passe directement au patient suivant          VectPatResultat.push_back(new NSPatInfo(*iterPatient, pContexte)) ;          bChercheDocument = false ;
          break ;
        }
      }
    } // fin du while(bChercheDocument)
	} // fin du while(bCherchePatient)

	// fin de la requete : on ferme le lanceur	pLanceur->CloseWindow(IDCANCEL) ;
	SetCursor(0, IDC_ARROW) ;
	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName() ;
	MessageBox("Recherche termin�e.", sCaption.c_str(), MB_OK) ;

	// on lance la liste des r�sultats si nbTrouves > 0	if (0 == nbTrouves)
	{
		char cMode[30] = "" ;
    char cMsg[255] = "" ;

    if (bReqModeDoc)    	strcpy(cMode, "Document") ;
    else
    	strcpy(cMode, "Patient") ;

    sprintf(cMsg, "Aucun %s ne correspond � la requ�te.", cMode) ;    MessageBox(cMsg, "Resultat de la requ�te", MB_OK) ;
    return ;
	}

	setModeFileErr(false) ;	bReqEnCours = false ;

	// on renvoie IDOK pour lancer l'affichage des r�sultats	NSUtilDialog::CmOk() ;
}

voidNSRequeteDialog::CmFermer()
{
	if (bReqEnCours)
	{
		string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    string sWarningText = pContexte->getSuperviseur()->getText("searchingRequestFormWarnings", "areYouSureYouWantToStopTheProcess") ;
		int idRet = MessageBox(sWarningText.c_str(), sCaption.c_str(), MB_YESNO) ;
		if (IDNO == idRet)
			return ;
	}
  else if (true == bDirty)
  {
  	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
		string sWarningText = pContexte->getSuperviseur()->getText("searchingRequestFormWarnings", "areYouSureYouWantToQuitWithoutSaving") ;
		int idRet = MessageBox(sWarningText.c_str(), sCaption.c_str(), MB_YESNO) ;
		if (IDNO == idRet)
			return ;
  }

	// on mettra ici une sauvegarde automatique de la requete	// et des r�sultats obtenus

	// on renvoie IDCANCEL pour sortir de la boucle dans Nautilus.cpp	NSUtilDialog::CmCancel();
}

voidNSRequeteDialog::CmAddRequest(){	if (true == bReqEnCours)		return ;	pEditReq->GetText(sLibReq) ;	if (string("") == sLibReq)		return ;	string sReqName ;  pEditReqLabel->GetText(sReqName) ;  if (string("") == sReqName)		return ;	NSRequestResult* pRR = new NSRequestResult ;  pRR->setRequestLabel(sLibReq) ;  pRR->setRequestName(sReqName) ;	_aRequestResults.push_back(pRR) ;  bDirty = true ;	DisplaySearchList() ;}void
NSRequeteDialog::CmEditRequest()
{
	if ((true == bReqEnCours) || (true == _aRequestResults.empty()))
		return ;

	pEditReq->GetText(sLibReq) ;
	if (string("") == sLibReq)		return ;	string sReqName ;  pEditReqLabel->GetText(sReqName) ;  if (string("") == sReqName)		return ;

	int eltChoisi = pRequestsList->IndexItemSelect() ;
	if (eltChoisi == -1)
	{
		string sWarningText = pContexte->getSuperviseur()->getText("searchingRequestFormWarnings", "aRequestMustBeSelected") ;
		erreur(sWarningText.c_str(), warningError, 0) ;
		return ;
	}

	NSRequestResult* pSelectedRequestResult = _aRequestResults[eltChoisi] ;
	pSelectedRequestResult->setRequestLabel(sLibReq) ;
  pSelectedRequestResult->setRequestName(sReqName) ;

  bDirty = true ;

	DisplaySearchList() ;
}

void
NSRequeteDialog::CmDeleteRequest()
{
	if ((true == bReqEnCours) || (true == _aRequestResults.empty()))
		return ;

	int eltChoisi = pRequestsList->IndexItemSelect() ;	if (eltChoisi == -1)
	{
		string sWarningText = pContexte->getSuperviseur()->getText("searchingRequestFormWarnings", "aRequestMustBeSelected") ;
		erreur(sWarningText.c_str(), warningError, 0) ;
		return ;
	}

	NSRequestResultIter it = _aRequestResults.begin() ;
	int j;
	for (j = 0 ; (_aRequestResults.end() != it) && (j < eltChoisi) ; it++, j++) ;
	if (it == _aRequestResults.end())
		return ;

	delete *it ;
	_aRequestResults.erase(it) ;

  bDirty = true ;

  DisplaySearchList() ;
}

voidNSRequeteDialog::CmDuplicateRequest(){	if ((true == bReqEnCours) || (true == _aRequestResults.empty()))		return ;

	int eltChoisi = pRequestsList->IndexItemSelect() ;	if (eltChoisi == -1)
	{
		string sWarningText = pContexte->getSuperviseur()->getText("searchingRequestFormWarnings", "aRequestMustBeSelected") ;
		erreur(sWarningText.c_str(), warningError, 0) ;
		return ;
	}

	NSRequestResult* pSelectedRequestResult = _aRequestResults[eltChoisi] ;
  NSRequestResult* pNewRequestResult = new NSRequestResult ;
  pNewRequestResult->setRequestLabel(pSelectedRequestResult->getRequestLabel()) ;
  pNewRequestResult->setRequestName(pSelectedRequestResult->getRequestName()) ;

	_aRequestResults.push_back(pNewRequestResult) ;
  bDirty = true ;

	DisplaySearchList() ;}
void
NSRequeteDialog::CmPutRequestInEditControl()
{
	int eltChoisi = pRequestsList->IndexItemSelect() ;
	if (eltChoisi == -1)
		return ;
	NSRequestResult* pSelectedRequestResult = _aRequestResults[eltChoisi] ;
  pEditReq->SetText(pSelectedRequestResult->getRequestLabel().c_str()) ;
  pEditReqLabel->SetText(pSelectedRequestResult->getRequestName().c_str()) ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSLanceReqDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSLanceReqDialog, NSUtilDialog)    EV_WM_CLOSE,
    EV_BN_CLICKED(IDC_LR_AVECLIB, CmCheckLib),
    EV_BN_CLICKED(IDC_LR_AVECPAT, CmCheckPat),
    EV_BN_CLICKED(IDC_LR_AVECDOC, CmCheckDoc),
    EV_COMMAND(IDC_LR_START, CmDemarrer),
    EV_COMMAND(IDC_LR_STOP, CmArreter),
END_RESPONSE_TABLE;

NSLanceReqDialog::NSLanceReqDialog(NSRequeteDialog* pere, NSContexte* pCtx, TModule* mod)
                 :NSUtilDialog(pere, pCtx, "IDD_LANCEREQ", mod)
{
	// Initialisation des donnees
	pReqDlg 	  = pere ;

	// Cr�ation de tous les "objets de contr�le"	// on laisse le groupe pour le fun...
  pCritGroup = new TGroupBox(this, IDC_LR_GROUP) ;

  pCritLib	 = new TRadioButton(this, IDC_LR_AVECLIB) ;  pCritPat   = new TRadioButton(this, IDC_LR_AVECPAT) ;
  pCritDoc   = new TRadioButton(this, IDC_LR_AVECDOC) ;
  pStatus    = new TStatic(this, IDC_LR_STATUS) ;
  pProgress  = new OWL::TGauge(this, "%d%%", IDC_PROGRESSGRAV, 18, 253, 252, 20) ;
  pProgress->SetRange(0, 100) ;
  pProgress->SetNativeUse(nuNever) ;

  pEditPat	 = new NSUtilEdit(pContexte, this, IDC_LR_EDITPAT, PAT_NSS_LEN) ;  pEditDoc   = new NSUtilEdit(pContexte, this, IDC_LR_EDITDOC, DOC_CODE_DOCUM_LEN) ;

  bAvecLib = false ;  bAvecPat = false ;
  bAvecDoc = false ;
}

NSLanceReqDialog::~NSLanceReqDialog(){
  delete pCritGroup ;
  delete pCritLib ;
  delete pCritPat ;
  delete pCritDoc ;
  delete pStatus ;
  delete pEditPat ;
  delete pEditDoc ;
}

void
NSLanceReqDialog::SetupWindow()
{
	TDialog::SetupWindow() ;

	pCritLib->Uncheck() ;	pCritPat->Uncheck() ;
	pCritDoc->Uncheck() ;

	// on positionne les choix par d�faut
	if (false == pReqDlg->_aRequestResults.empty())
  	pCritLib->Check() ;

	if (pReqDlg->bCritPat)
  	pCritPat->Check() ;

	if (pReqDlg->bCritDoc)
  	pCritDoc->Check() ;
}

// traitement de radiobutton non exclusifs (ils ne sont pas AUTO)void
NSLanceReqDialog::CmCheckLib()
{
	if (pCritLib->GetCheck() == BF_CHECKED)
		pCritLib->Uncheck() ;
	else
		pCritLib->Check() ;
}

// traitement de radiobutton non exclusifs (ils ne sont pas AUTO)
void
NSLanceReqDialog::CmCheckPat()
{
	if (pCritPat->GetCheck() == BF_CHECKED)
		pCritPat->Uncheck() ;
	else
		pCritPat->Check() ;
}

// traitement de radiobutton non exclusifs (ils ne sont pas AUTO)
void
NSLanceReqDialog::CmCheckDoc()
{
	if (pCritDoc->GetCheck() == BF_CHECKED)
		pCritDoc->Uncheck() ;
	else
		pCritDoc->Check() ;
}

voidNSLanceReqDialog::CmDemarrer()
{
	if ((pCritLib->GetCheck() != BF_CHECKED) &&
      (pCritPat->GetCheck() != BF_CHECKED) &&
      (pCritDoc->GetCheck() != BF_CHECKED))
	{
  	char cMode[30] ;
    char cMsg[255] ;

    if (pReqDlg->bReqModeDoc)
    	strcpy(cMode, "Document") ;
    else
    	strcpy(cMode, "Patient") ;

    sprintf(cMsg, "Attention, vous allez r�cup�rer tous les %ss !! Voulez-vous continuer ?", cMode) ;

    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    int idRet = MessageBox(cMsg, sCaption.c_str(), MB_YESNO) ;
    if (IDNO == idRet)
    	return ;
	}

  if (pCritLib->GetCheck() == BF_CHECKED)  	bAvecLib = true ;
  else
  	bAvecLib = false ;

  if (pCritPat->GetCheck() == BF_CHECKED)
  	bAvecPat = true ;
  else
  	bAvecPat = false ;

  if (pCritDoc->GetCheck() == BF_CHECKED)
  	bAvecDoc = true ;
  else
  	bAvecDoc = false ;

  pReqDlg->CmLancer() ;
}

voidNSLanceReqDialog::CmArreter()
{
	if (!pReqDlg->bReqEnCours)
	{
		CloseWindow(IDCANCEL) ;
    return ;
	}

  string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
  int idRet = MessageBox("Etes-vous s�rs de vouloir interrompre la recherche ?", sCaption.c_str(), MB_YESNO) ;
  if (idRet == IDNO)
  	return ;

  // on force la sortie de la requete
  pReqDlg->bCherchePatient = false ;
  pReqDlg->bChercheDocument = false ;
}

void
NSLanceReqDialog::EvClose()
{
	CmArreter() ;
}

void
NSLanceReqDialog::displayStatusMessage(string sMessage)
{
	pStatus->SetText(sMessage.c_str()) ;
}

void
NSLanceReqDialog::displayProgress(int iProgressPercent)
{
	pProgress->SetValue(iProgressPercent) ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSEditReqWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSEditReqWindow, TListWindow)
    EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

//---------------------------------------------------------------------------
//  Function: NSEditReqWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
//
//  Arguments:	  les modKeys et le point click�
//
//  Description: Fonction de r�ponse au click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSEditReqWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
	TListWindow::EvLButtonDown(modKeys, point) ;

	TLwHitTestInfo info(point) ;
	HitTest(info) ;

	if (info.GetFlags() & LVHT_ONITEM)
	{
  	if (iRes == IDC_EDITREQ_LWPERE)
    	pDlg->CmModifier() ;
    else if (iRes == IDC_EDITREQ_LWFILS)
    	pDlg->CmAjouter() ;
	}
}


//---------------------------------------------------------------------------
//  Function: NSEditReqWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSEditReqWindow::IndexItemSelect()
{
    int count = GetItemCount();
    int index = -1;

    for (int i = 0; i < count; i++)
   	    if (GetItemState(i, LVIS_SELECTED))
        {
      	    index = i;
            break;
        }

    return index;
}

// -----------------------------------------------------------------
//
//  M�thodes de NSEditReqDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSEditReqDialog, NSUtilDialog)
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),

    EV_COMMAND(IDC_EDITREQ_INS, CmInserer),
    EV_COMMAND(IDC_EDITREQ_MOD, CmModifier),
    EV_COMMAND(IDC_EDITREQ_DEL, CmDetruire),
    EV_COMMAND(IDC_EDITREQ_AJOUTER, CmAjouter),
END_RESPONSE_TABLE;

NSEditReqDialog::NSEditReqDialog(TWindow* pere, NSContexte* pCtx, TModule* mod)
                         :NSUtilDialog(pere, pCtx, "IDD_EDITREQ", mod)
{
    pListePere     = new NSEditReqWindow(this, IDC_EDITREQ_LWPERE);
    pListeFils     = new NSEditReqWindow(this, IDC_EDITREQ_LWFILS);
    pPereArray     = new NSEltArray;
    pFilsArray     = new NSEltArray;
    nbPere = 0;
    nbFils = 0;
    sCheminPere = "";
    sCheminRechPere = "";
}

NSEditReqDialog::~NSEditReqDialog()
{
    delete pListePere;
    delete pListeFils;
    delete pPereArray;
    delete pFilsArray;
}

void
NSEditReqDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow();

    InitListePere();
    InitListeFils();

    AfficheListePere();
}

void
NSEditReqDialog::InitListePere()
{
	TListWindColumn colElt("P�re", 500, TListWindColumn::Left, 0);
  	pListePere->InsertColumn(0, colElt);
}

void
NSEditReqDialog::InitListeFils()
{
	TListWindColumn colFils("Fils", 500, TListWindColumn::Left, 0);
  	pListeFils->InsertColumn(0, colFils);
}

void
NSEditReqDialog::AfficheListePere()
{
    char elt[255];
    NSEltArray* pRechArray;
    NSEltArray* pLastEltArray;
    string sCheminRech, sCodeSens;
    BBItemData bbGuideData;

    // on remet toujours la liste � z�ro
    pListePere->DeleteAllItems();

    if (!nbPere)
    {
        pListeFils->DeleteAllItems();
        return;
    }

	for (int i = nbPere - 1; i >= 0; i--)
    {
   	    sprintf(elt, "%s", (((*pPereArray)[i])->libelle).c_str());
   	    TListWindItem Item(elt, 0);
        pListePere->InsertItem(Item);
    }

    // on r�initialise le tableau fils
    pFilsArray->vider();
    nbFils = 0;

    // pour la recherche : on doit d'abord constituer le chemin pere
    // sans le dernier �l�ment, qui est stock� � part
    pRechArray = new NSEltArray(*pPereArray);
    NSEltIter k = pRechArray->end();
    k--;    // end() est apr�s le dernier �l�ment
    NSElement lastElt(*(*k));
    delete *k;
    pRechArray->erase(k);

    // on utilise ComposeChemin pour r�cup�rer le code sens (avec pluriel, etc.)
    pLastEltArray = new NSEltArray;
    pLastEltArray->push_back(new NSElement(lastElt));
    ComposeChemin(sCodeSens, pLastEltArray);

    // on construit le chemin de recherche (sans le dernier �l�ment)
    // et on trouve les fils par la recherche s�mantique
    // cas particulier : le pere n'a qu'un seul �l�ment (ammorce)
    if (nbPere == 1)
    {
        string sFils;
        string sDecal;
        // cas du chemin vide
        RechercheFilsAmmorce(sCodeSens, sFils, sDecal);
        if (sFils != "")
            ParsingChemin(sFils, false, sDecal);
    }
    else
    {
        // le chemin contiendra au moins l'ammorce
        ComposeChemin(sCheminRech, pRechArray);

        // on fabrique un vecteur "fils" contenant le dernier �l�ment
        VecteurRechercheSelonCritere* pVecteurFils = new VecteurRechercheSelonCritere(GUIDE);
        pVecteurFils->AjouteEtiquette(sCodeSens);

        // on lance la recherche proprement dite
        bool trouve;
        pContexte->getSuperviseur()->afficheStatusMessage("Recherche des fils...");
        pContexte->getSuperviseur()->getFilGuide()->chercheCheminReseau(&sCheminRech, pVecteurFils);
        pVecteurFils->SetData(sCodeSens, &trouve, &bbGuideData);
        delete pVecteurFils;

        // on reconstruit maintenant le tableau fils
        if ((trouve) && (strcmp(bbGuideData.fils, "")))
            ParsingChemin(string(bbGuideData.fils), false, string(bbGuideData.decalageNiveau));
    }

    AfficheListeFils();

    delete pLastEltArray;
    delete pRechArray;
}

void
NSEditReqDialog::AfficheListeFils()
{
    char elt[255];

	pListeFils->DeleteAllItems();

    for (int i = nbFils - 1; i >= 0; i--)
    {
        sprintf(elt, "%s", (((*pFilsArray)[i])->libelle).c_str());
        TListWindItem Item(elt, 0);
        pListeFils->InsertItem(Item);
    }

    pListeFils->SetFocus();
}

void
NSEditReqDialog::RechercheFilsAmmorce(string sAmmorce, string& sFils, string& sDecal)
{
    sFils = "";
    sDecal = "";

    //
    // Cr�ation d'un BBFiche
    //
    BBFiche* pBBFiche = new BBFiche(pContexte);
    pBBFiche->lastError = pBBFiche->open();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
   	    erreur("Il est impossible d'ouvrir le fichier des Guides.", standardError, pBBFiche->lastError);
        delete pBBFiche;
        return;
    }

    // recherche de l'ammorce
    pBBFiche->lastError = pBBFiche->chercheClef(&sAmmorce,
                                                "CHEMIN",
                                                NODEFAULTINDEX,
                                                keySEARCHEQ,
                                                dbiWRITELOCK);

    if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_RECNOTFOUND))
    {
        erreur("Erreur � la recherche dans le fichier des Guides.", standardError, pBBFiche->lastError);
        pBBFiche->close();
        delete pBBFiche;
        return;
    }
    else if (pBBFiche->lastError == DBIERR_RECNOTFOUND)
    {
        // cas ammorce non trouv�e => on renvoie sFils == ""
        pBBFiche->close();
        delete pBBFiche;
        return;
    }

    pBBFiche->lastError = pBBFiche->getRecord();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
        erreur("Erreur � la lecture d'une fiche Guides.", standardError, pBBFiche->lastError);
        pBBFiche->close();
        delete pBBFiche;
        return;
    }

    // on caste � cause de la structure de BBFiche (voir nsguide.cpp)
    sFils = string((static_cast<BBItemData*>(pBBFiche->pDonnees))->fils);
    sDecal = string((static_cast<BBItemData*>(pBBFiche->pDonnees))->decalageNiveau);

    pBBFiche->lastError = pBBFiche->close();
   	if (pBBFiche->lastError != DBIERR_NONE)
		erreur("Erreur de fermeture de la base des Guides.", standardError, pBBFiche->lastError);

	delete pBBFiche;
}

////////////////////////////////////////////////////////////////////////////////
// Fonction : TrouveLibelle(string sCode, string& sLibelle, bool bPere)
// En entr�e : un code lexique ou un ensemble de codes lexiques s�par�s par '/'
// En sortie : le libell� ou l'ensemble de libell�s correspondant
// Note : Cette fonction traite toujours un seul �l�ment, avec ses attributs �ventuels
// Elle ne tient pas compte du d�calage, qui est trait� � part.
////////////////////////////////////////////////////////////////////////////////
void
NSEditReqDialog::TrouveLibelle(string sCode, string& sLibelle, bool bPere)
{
    size_t pos1, pos2;
    bool bContinue = true;
    string sCode1, sLibelle1;
    string sCode2, sLibelle2;

    // on remet � "" sLibelle
    sLibelle = "";

    pos1 = 0;
    pos2 = sCode.find('/');
    if (pos2 != NPOS)
    {
        while (bContinue)
        {
            if (pos2 != NPOS)
                sCode1 = string(sCode, pos1, pos2-pos1);
            else
                sCode1 = string(sCode, pos1, strlen(sCode.c_str())-pos1);

            TrouveLibelle(sCode1, sLibelle1, bPere);
            if (sLibelle == "")
                sLibelle = sLibelle1;
            else
                sLibelle += string("/") + sLibelle1;

            if ((pos2 == NPOS) || (pos2 == (strlen(sCode.c_str())-1)))
                bContinue = false;
            else
            {
                pos1 = pos2+1;
                pos2 = sCode.find('/', pos1);
            }
        }

        return;
    }

    string sLang = "";
    if ((pContexte) && (pContexte->getUtilisateur()))
        sLang = pContexte->getUtilisateur()->donneLang();

    // on traite d'abord les jokers (codes peres)
    if (bPere && (sCode == "~????1"))
        sLibelle = "Tout �l�ment (??)";
    else if (bPere && (sCode == "~~***1"))
        sLibelle = "Toute s�quence (**)";
    else if (bPere && (sCode != "") && (sCode[0] == '~'))
        sLibelle = string("Joker (") + string(sCode,3,2) + string(")");
    else    // cas des codes commun aux fils et aux peres (codes lexiques)
    {
        if (sCode == "")
            sLibelle = "[Vide]";
        else
        {
            if (strlen(sCode.c_str()) == BASE_LEXI_LEN)
            {
                sCode2 = sCode; sLibelle2 = "";
                if (pContexte->getDico()->donneLibelle(sLang, &sCode2, &sLibelle2))
                {
                    // pour les codes syst�me
                    if (sLibelle2 == "")
                    {
                        pContexte->getDico()->donneLibelleLexique(sLang, &sCode2, &sLibelle2);

                        // pour les cas non trait�s
                        if (sLibelle2 == "")
                            sLibelle = sCode;
                        else
                            sLibelle = sLibelle2;
                    }
                    else // cas normal
                        sLibelle = sLibelle2;
                }
                else // cas d'erreur : code introuvable
                    sLibelle = sCode;
            }
            else // cas d'erreur : code trop long ou trop court
                sLibelle = sCode;
        }
    }
}
voidNSEditReqDialog::TrouveLibelleValeur(string sCode, string& sLibelle, bool bPere)
{
    string sUnite, sFormat, sValeur, sLibUnite ;
    size_t pos1 = sCode.find('/') ;
    size_t pos2, pos3 ;

    string sLang = "" ;
    if ((pContexte) && (pContexte->getUtilisateur()))
        sLang = pContexte->getUtilisateur()->donneLang() ;

    if (pos1 != NPOS)
    {
        sUnite = string(sCode, 0, pos1) ;

        if (strlen(sUnite.c_str()) == BASE_LEXI_LEN)
            pContexte->getDico()->donneLibelle(sLang, &sUnite, &sLibUnite) ;
        else
        {
            erreur("Valeur chiffr�e avec unit� incorrecte.", standardError, 0, GetHandle()) ;
            sLibelle = sCode ;
            return ;
        }

        pos2 = sCode.find('/', pos1+1) ;
        if (pos2 != NPOS)
        {
            sFormat = string(sCode, pos1+1, pos2-pos1-1) ;
            sValeur = string(sCode, pos2+1, strlen(sCode.c_str())-pos2-1) ;
        }
        else
        {
            sFormat = string(sCode, pos1+1, strlen(sCode.c_str())-pos1-1) ;
            sValeur = "" ;
        }

        // analyse du format
        if (sFormat[0] != '�')
        {
            erreur("Valeur chiffr�e avec un format incorrect.", standardError, 0, GetHandle()) ;
            sLibelle = sCode;
            return;
        }

        if (bPere)  // cas des valeurs pere (instanci�es)
        {
            string sVal1, sVal2, sVal, sValBrut;
            size_t    pos;

            // on ne traite que les valeurs num�riques
            if (sFormat[1] != 'N')
            {
                erreur("Valeur chiffr�e avec format non trait�.", standardError, 0, GetHandle()) ;
                sLibelle = sCode;
                return;
            }

            // on doit obligatoirement avoir une valeur
            if (sValeur == "")
            {
                erreur("Valeur chiffr�e non instanci�e dans un chemin de recherche.", standardError, 0, GetHandle()) ;
                sLibelle = sCode;
                return;
            }
            else if (sValeur[0] != '$')
            {
                erreur("Valeur chiffr�e incorrecte dans un chemin de recherche.", standardError, 0, GetHandle()) ;
                sLibelle = sCode;
                return;
            }

            // cas x < a
            if ((sValeur.find('<') != NPOS) && (sValeur.find("<<") == NPOS) &&
                (sValeur.find("<[") == NPOS) && (sValeur.find("[<") == NPOS))
            {
                pos3 = sValeur.find('<');

                sValBrut = string(sValeur, pos3+1, strlen(sValeur.c_str())-pos3-1);
                pos = sValBrut.find_first_not_of('0');
                if (pos != NPOS)
                    sVal2 = string(sValBrut, pos, strlen(sValBrut.c_str())-pos);
                else
                    sVal2 = sValBrut;

                sVal = "[< " + sVal2 + "]";
            }
            // cas x <= a
            else if ((sValeur.find('[') != NPOS) && (sValeur.find("[[") == NPOS) &&
                     (sValeur.find("[<") == NPOS) && (sValeur.find("<[") == NPOS))
            {
                pos3 = sValeur.find('[');

                sValBrut = string(sValeur, pos3+1, strlen(sValeur.c_str())-pos3-1);
                pos = sValBrut.find_first_not_of('0');
                if (pos != NPOS)
                    sVal2 = string(sValBrut, pos, strlen(sValBrut.c_str())-pos);
                else
                    sVal2 = sValBrut;

                sVal = "[<= " + sVal2 + "]";
            }
            // cas x > a
            else if (sValeur.find('>') != NPOS)
            {
                pos3 = sValeur.find('>');

                sValBrut = string(sValeur, pos3+1, strlen(sValeur.c_str())-pos3-1);
                pos = sValBrut.find_first_not_of('0');
                if (pos != NPOS)
                    sVal2 = string(sValBrut, pos, strlen(sValBrut.c_str())-pos);
                else
                    sVal2 = sValBrut;

                sVal = "[> " + sVal2 + "]";
            }
            // cas x >= a
            else if (sValeur.find(']') != NPOS)
            {
                pos3 = sValeur.find(']');

                sValBrut = string(sValeur, pos3+1, strlen(sValeur.c_str())-pos3-1);
                pos = sValBrut.find_first_not_of('0');
                if (pos != NPOS)
                    sVal2 = string(sValBrut, pos, strlen(sValBrut.c_str())-pos);
                else
                    sVal2 = sValBrut;

                sVal = "[>= " + sVal2 + "]";
            }
            // cas x entre a et b
            else if ((sValeur.find("<<") != NPOS) || (sValeur.find("<[") != NPOS) ||
                     (sValeur.find("[<") != NPOS) || (sValeur.find("[[") != NPOS))
            {
                string sBorne1, sBorne2;

                // cas a < x < b
                if ((pos3 = sValeur.find("<<")) != NPOS)
                {
                    sBorne1 = "]";
                    sBorne2 = "[";
                }
                // cas a < x <= b
                else if ((pos3 = sValeur.find("<[")) != NPOS)
                {
                    sBorne1 = "]";
                    sBorne2 = "]";
                }
                // cas a <= x < b
                else if ((pos3 = sValeur.find("[<")) != NPOS)
                {
                    sBorne1 = "[";
                    sBorne2 = "[";
                }
                // cas a <= x <= b
                else if ((pos3 = sValeur.find("[[")) != NPOS)
                {
                    sBorne1 = "[";
                    sBorne2 = "]";
                }

                // on extrait les deux valeurs brutes
                sValBrut = string(sValeur, 1, pos3-1);
                pos = sValBrut.find_first_not_of('0');
                if (pos != NPOS)
                    sVal1 = string(sValBrut, pos, strlen(sValBrut.c_str())-pos);
                else
                    sVal1 = sValBrut;

                sValBrut = string(sValeur, pos3+2, strlen(sValeur.c_str())-pos3-2);
                pos = sValBrut.find_first_not_of('0');
                if (pos != NPOS)
                    sVal2 = string(sValBrut, pos, strlen(sValBrut.c_str())-pos);
                else
                    sVal2 = sValBrut;

                sVal = sBorne1 + sVal1 + " ; " + sVal2 + sBorne2;
            }
            else // valeur exacte
            {
                sValBrut = string(sValeur, 1, strlen(sValeur.c_str())-1);
                pos = sValBrut.find_first_not_of('0');
                if (pos != NPOS)
                    sVal = string(sValBrut, pos, strlen(sValBrut.c_str())-pos);
                else
                    sVal = sValBrut;
            }

            sLibelle = sVal + " " + sLibUnite;
        }
        else // cas des valeurs fils (consid�r�es non instanci�es)
        {
            if (sFormat[1] == 'N')
            {
                sLibelle = "[Valeur";
                if (sLibUnite != "")
                    sLibelle += " en " + sLibUnite;
                sLibelle += "]";
            }
            else if ((sFormat[1] == 'D') || (sFormat[1] == 'T'))
            {
                sLibelle = "[Date";
                if (sLibUnite != "")
                    sLibelle += " (" + sLibUnite + ")";
                sLibelle += "]";
            }
            else if (sFormat[1] == 'H')
            {
                sLibelle = "[Heure";
                if (sLibUnite != "")
                    sLibelle += " (" + sLibUnite + ")";
                sLibelle += "]";
            }
            else
            {
                erreur("Valeur chiffr�e avec un format non trait�.", standardError, 0, GetHandle()) ;
                sLibelle = sCode;
            }
        }
    }
    else
    {
        erreur("Valeur chiffr�e sans format.", standardError, 0, GetHandle()) ;
        sLibelle = sCode;
    }
}

// Cette fonction traite aussi le d�calage// pour les fils, on utilise la valeur de sDecal
// pour les p�res, le d�calage est contenu dans les �l�ments du chemin
void
NSEditReqDialog::ParsingChemin(string sChem, bool bPere, string sDecal)
{
	string sUnitesDistinctes = "" ;  // pour traiter les fils valeurs chiffr�es
	char   sep = '|' ;         // s�parateur de blocs pour les p�res et les fils

	// bool bVide = true;
	size_t pos1 = 0 ;	size_t pos2 = sChem.find(sep) ;

	bool bParsing = true ;
	while (bParsing)	{
		string sCode = ""  ;
    string sLibelle = "" ;

    if (NPOS != pos2)
    	sCode = string(sChem, pos1, pos2-pos1) ;
    else
    	sCode = string(sChem, pos1, strlen(sChem.c_str())-pos1) ;

    if (bPere)
    {
    	// cas d'un code p�re : on doit aussi extraire le d�calage
      size_t pos3 = sCode.find(':') ;  // Note : le ':' est le s�parateur de d�calage
      if (NPOS != pos3)
      {
      	// pour �viter les cas d'erreur on met decal � '1' par d�faut
        char decal = '1' ;

        if (strlen(sCode.c_str()) == (pos3 + 2))
        	decal = sCode[pos3 + 1] ;

        if ('0' == decal)
        	sDecal = "+00+00" ;
        else
        	sDecal = "+01+01" ;

        // on remet le code avec le code sens uniquement (sans le d�calage)
        sCode = string(sCode, 0, pos3) ;
      }
    }

    // on retrouve le libell� correspondant
    if (bPere)
    {
    	if ((string("") != sCode) && ('2' == sCode[0]))
      	TrouveLibelleValeur(sCode, sLibelle, bPere) ;
      else
      	TrouveLibelle(sCode, sLibelle, bPere) ;

      pPereArray->push_back(new NSElement(sCode, sLibelle, sDecal)) ;
      nbPere++ ;
    }
    else
    {
    	if ((string("") != sCode) && ('2' == sCode[0]))
      {
      	// cas des fils valeurs chiffr�es : on extrait l'unit�
        string sUnite ;
        size_t pos = sCode.find('/') ;
        if (NPOS != pos)
        	sUnite = string(sCode, 0, pos) ;
        else
        	sUnite = sCode ;

        // si l'unit� existe d�j�, on ne traite pas l'�l�ment
        if (sUnitesDistinctes.find(sUnite) == NPOS)
        {
        	// cas d'une nouvelle unit� : on ajoute aux fils
          sUnitesDistinctes += sUnite + "|" ;
          TrouveLibelleValeur(sCode, sLibelle, bPere) ;
          pFilsArray->push_back(new NSElement(sCode, sLibelle, sDecal)) ;
          nbFils++ ;
        }
      }
      else
      {
      	TrouveLibelle(sCode, sLibelle, bPere) ;
        pFilsArray->push_back(new NSElement(sCode, sLibelle, sDecal)) ;
        nbFils++ ;
      }
    }

    // condition d'arret : on traite aussi le cas du '|' � la fin du chemin
    if ((NPOS == pos2) || (strlen(sChem.c_str()) - 1 == pos2))
    	bParsing = false ;
    else
    {
    	pos1 = pos2+1 ;
      pos2 = sChem.find(sep, pos1) ;
    }
  }
}


// Constitution d'un chemin de recherche :
// Fonction qui reconstitue un chemin de codes sens � partir d'un array d'�l�ments
// Si bRequete == true, la fonction fait un chemin d'�l�ments (ensemble de blocs
// compos�s de un ou plusieurs codes lexique) - Dans les deux cas, le d�calage est
// pris en compte : les �l�ments en +00+00 �crasent leur p�re. Le d�calage n'est pas
// en revanche contenu dans le chemin comme dans ::ComposeCheminBrut
void
NSEditReqDialog::ComposeChemin(string& sChemin, NSEltArray* pArray, bool bRequete)
{
    string sBoutChemin;
    string sCodeCompose;
    string sCodeLexique;
    string sCodeUtile;
    size_t pos, pos1, pos2, pos3;
    bool bContinue;
    NSSuper* pSuper = pContexte->getSuperviseur();

    sChemin = "";

    if (!(pArray->empty()))
    {
    	// On reconstitue la string sChemin � partir de l'array source
    	for (NSEltIter i = pArray->begin(); i != pArray->end(); i++)
    	{
        	// chaque code �l�ment est �ventuellement compos� d'une certitude et d'un pluriel
        	sCodeCompose = (*i)->code;

        	if (bRequete)
            	sBoutChemin = sCodeCompose;
        	else
        	{
            	// cas des chemins de recherche "Fil Guides" : on constitue sBoutChemin
            	// � partir des codes sens de l'�l�ment (sCodeCompose)
            	sBoutChemin = "";
            	bContinue = true;
            	pos1 = 0;
            	pos2 = sCodeCompose.find('/');

            	while (bContinue)
            	{
                	if (pos2 != NPOS)
                    	sCodeLexique = string(sCodeCompose, pos1, pos2-pos1);
                	else
                    	sCodeLexique = string(sCodeCompose, pos1, strlen(sCodeCompose.c_str())-pos1);

                	pSuper->getDico()->donneCodeSens(&sCodeLexique, &sCodeUtile);
                	if (sBoutChemin != "")
                    	sBoutChemin += "/";
                	sBoutChemin += sCodeUtile;

                	// condition d'arret : on traite aussi le cas du '/' � la fin du chemin
                	if ((pos2 == NPOS) || (pos2 == (strlen(sCodeCompose.c_str()) - 1)))
                    	bContinue = false;
                	else
                	{
                    	pos1 = pos2+1;
                    	pos2 = sCodeCompose.find('/', pos1);
                	}
            	}
        	}

        	// on ajoute chaque boutchemin (�l�ment) au chemin global (ensemble des �l�ments)
        	// on �crase alors le p�re (�l�ment pr�c�dent) si l'�l�ment courant est en +00+00
        	if (((*i)->decalage) == string("+00+00"))
        	{
            	int nbCarsEltPere;
            	pos3 = sChemin.find_last_of('|');

            	if (pos3 != NPOS)
            	{
                	// l'�l�ment fils (courant) �crase l'�l�ment pere (pr�c�dent)
                	nbCarsEltPere = strlen(sChemin.c_str()) - pos3 - 1;
                	sChemin.replace(pos3 + 1, nbCarsEltPere, sBoutChemin);
            	}
            	else    // cas d'un �l�ment +00+00 en premier ou en second (�crase le premier)
                	sChemin = sBoutChemin;
        	}
        	else // cas normal (+01+01)
        	{
            	if (sChemin != "")
                	sChemin += "|";
            	sChemin += sBoutChemin;
        	}
        }
    }

    // cas des chemins "Fil Guide" : on remplace maintenant tous les '|' par des '/'
    // pour pouvoir chercher un chemin dans la base des guides
    if (!bRequete)
    {
        pos = sChemin.find('|');
        while (pos != NPOS)
        {
            sChemin.replace(pos, 1, "/");
            pos = sChemin.find('|', pos+1);
        }
    }
}

// cas du chemin brut : pour garder toutes les infos dans une string
// les �l�ments sont des blocs de codes lexiques avec un d�calage (:0 ou :1)
void
NSEditReqDialog::ComposeCheminBrut(string& sChemin, NSEltArray* pArray)
{
    string sCodeCompose;

    sChemin = "";

    if (pArray->empty())
    	return;

    // On reconstitue la string sChemin � partir de l'array source
    for (NSEltIter i = pArray->begin(); i != pArray->end(); i++)
    {
        // chaque code �l�ment est �ventuellement compos� d'une certitude et d'un pluriel
        sCodeCompose = (*i)->code;

        // on ajoute chaque boutchemin (�l�ment) au chemin global (ensemble des �l�ments)
        // on concat�ne la valeur du d�calage
        if (((*i)->decalage) == string("+00+00"))
            sCodeCompose += ":0";
        else // cas normal (+01+01)
            sCodeCompose += ":1";

        if (sChemin != "")
            sChemin += "|";
        sChemin += sCodeCompose;
    }
}

bool
NSEditReqDialog::CalculeValeur(string& sCode)
{
    string sLang = "";
    if ((pContexte) && (pContexte->getUtilisateur()))
        sLang = pContexte->getUtilisateur()->donneLang();

    size_t     pos1, pos2;
    string  sValeur;
    gereNum num = gereNum(pContexte, sLang);
    string  sUnit = "", sFmt = ""; // valeurs bidon pour pouvoir instancier le gereNum
    NSValeurChiffreeDialog* pVCDlg;

    pVCDlg = new NSValeurChiffreeDialog(this, 255, pContexte, pNSResModule);

    // on transmet l'unit� et la valeur donn�e
    pos1 = sCode.find('/');
    if (pos1 != NPOS)
    {
        pVCDlg->sUnite = string(sCode, 0, pos1);
        pos2 = sCode.find('/', pos1+1);
        if (pos2 != NPOS)
        {
            if (strlen(sCode.c_str()) > (pos2 + 2))
            {
                // car on doit au moins avoir "$x" comme valeur
                sValeur = string(sCode, pos2+2, strlen(sCode.c_str())-pos2-2);
                num.instancier(&sValeur, &sUnit, &sFmt);

                // on instancie la valeur
                if (num.estExact())
                {
                    pVCDlg->sValeurExacte = num.getNum();
                }
                else
                {
                    if (num.estInf())
                    {
                        pVCDlg->sValeurInf = num.getNumInf();
                        if (num.estInfEgal())
                            pVCDlg->bAvecInf = true;
                    }

                    if (num.estSup())
                    {
                        pVCDlg->sValeurSup = num.getNumSup();
                        if (num.estSupEgal())
                            pVCDlg->bAvecSup = true;
                    }
                }
            }
            else // cas valeur bidon
                erreur("Code comportant une valeur incorrecte.", standardError, 0, GetHandle()) ;
        }
    }
    else // normalement cas d'erreur
        pVCDlg->sUnite = sCode;

    if (pVCDlg->Execute() == IDCANCEL)
    {
        delete pVCDlg;
        return false;
    }

    // on remplace l'unit� et on enl�ve les �ventuelles valeurs ($XXXXX) du code
    if (pos1 != NPOS)
    {
        sCode.replace(0, pos1, pVCDlg->sUnite);
        // on garde le format sans la valeur
        pos2 = sCode.find('/', pos1+1);
        if (pos2 != NPOS)
            sCode = string(sCode, 0, pos2);
    }
    else // cas d'erreur : on met un format bidon
        sCode = pVCDlg->sUnite + "�NXXXX";

    // on rajoute la valeur au code
    if (pVCDlg->sValeurExacte != "")
    {
        sCode += "/$" + pVCDlg->sValeurExacte;      // x == a
    }
    else if ((pVCDlg->sValeurInf != "") && (pVCDlg->sValeurSup == ""))
    {
        if (pVCDlg->bAvecInf)
            sCode += "/$]" + pVCDlg->sValeurInf;    // x >= a
        else
            sCode += "/$>" + pVCDlg->sValeurInf;    // x > a
    }
    else if ((pVCDlg->sValeurInf == "") && (pVCDlg->sValeurSup != ""))
    {
        if (pVCDlg->bAvecSup)
            sCode += "/$[" + pVCDlg->sValeurSup;    // x <= a
        else
            sCode += "/$<" + pVCDlg->sValeurSup;    // x < a
    }
    else // cas des intervalles avec deux bornes
    {
        if ((pVCDlg->bAvecInf) && (pVCDlg->bAvecSup))   // a <= x <= b
            sCode += "/$" + pVCDlg->sValeurInf + "[[" + pVCDlg->sValeurSup;
        else if (pVCDlg->bAvecInf)                      // a <= x < b
            sCode += "/$" + pVCDlg->sValeurInf + "[<" + pVCDlg->sValeurSup;
        else if (pVCDlg->bAvecSup)                      // a < x <= b
            sCode += "/$" + pVCDlg->sValeurInf + "<[" + pVCDlg->sValeurSup;
        else                                            // a < x < b
            sCode += "/$" + pVCDlg->sValeurInf + "<<" + pVCDlg->sValeurSup;
    }

    delete pVCDlg;
    return true;
}

// ************** Controles
void
NSEditReqDialog::CmInserer()
{
    // Insertion en queue d'un nouvel �l�ment
    NSModifFilGuideDialog* pModDlg =
        new NSModifFilGuideDialog(this, "", pContexte, pNSResModule);

    if (pModDlg->Execute() == IDOK)
    {
        string sCode = pModDlg->sCode;
        string sLibelle;

        TrouveLibelle(sCode, sLibelle, true);

        pPereArray->push_back(new NSElement(sCode, sLibelle));
        nbPere++;
        AfficheListePere();
    }

    delete pModDlg;
}

void
NSEditReqDialog::CmModifier()
{
    int eltChoisi = pListePere->IndexItemSelect();

    if (eltChoisi == -1)
    {
        erreur("Vous devez s�lectionner un �l�ment � modifier.", standardError, 0) ;
        return;
    }

    NSElement* pElement = new NSElement();
    *pElement = *((*pPereArray)[eltChoisi]);

    if ((pElement->code != "") && (pElement->code[0] == '2'))
    {
        // cas de la modification d'une valeur chiffr�e
        if (CalculeValeur(pElement->code))
        {
            // on recalcule le nouveau libelle avec bPere == true
            TrouveLibelleValeur(pElement->code, pElement->libelle, true);

            // on replace l'�l�ment
            *((*pPereArray)[eltChoisi]) = *pElement;
            AfficheListePere();
        }
    }
    else
    {
        NSModifFilGuideDialog* pModDlg =
            new NSModifFilGuideDialog(this, pElement->code, pContexte, pNSResModule);

        if (pModDlg->Execute() == IDOK)
        {
            string sCode = pModDlg->sCode;
            string sLibelle;

            TrouveLibelle(sCode, sLibelle, true);

            pElement->code = sCode;
            pElement->libelle = sLibelle;
            *((*pPereArray)[eltChoisi]) = *pElement;
            AfficheListePere();
        }

        delete pModDlg;
    }

    delete pElement;
}

void
NSEditReqDialog::CmDetruire()
{
    NSEltIter i;
    int j;
    int eltChoisi = pListePere->IndexItemSelect();

    if (eltChoisi == -1)
    {
        erreur("Vous devez s�lectionner un �l�ment � d�truire.", standardError, 0) ;
        return;
    }

    if (!(pPereArray->empty()))
    {
    	for (i = pPereArray->begin(), j = 0; i != pPereArray->end(); i++, j++)
    	{
        	if (j == eltChoisi)
        	{
            	delete *i;
            	pPereArray->erase(i);
            	nbPere -= 1;
            	break;
        	}
        }
    }

    AfficheListePere();
}
voidNSEditReqDialog::CmAjouter()
{
	int eltChoisi = pListeFils->IndexItemSelect() ;
	if (-1 == eltChoisi)
	{
		erreur("Vous devez s�lectionner un fils � ajouter.", standardError, 0) ;
    return ;
	}

	string sCodeFils  = ((*pFilsArray)[eltChoisi])->code ;
	string sDecalFils = ((*pFilsArray)[eltChoisi])->decalage ;
	string sLibFils ;

	if ((string("") != sCodeFils) && ('2' == sCodeFils[0]))	{
		// cas de l'ajout d'une valeur chiffr�e : on doit instancier la valeur
    if (CalculeValeur(sCodeFils))
    {
    	// on recalcule le nouveau libelle avec bPere == true
      TrouveLibelleValeur(sCodeFils, sLibFils, true) ;

      // on push_back l'�l�ment
      NSElement eltValeur ;
      eltValeur.code     = sCodeFils ;
      eltValeur.libelle  = sLibFils ;
      eltValeur.decalage = sDecalFils ;
      pPereArray->push_back(new NSElement(eltValeur)) ;
      nbPere++ ;
      AfficheListePere() ;
    }
  }
	else
	{
  	pPereArray->push_back(new NSElement(*((*pFilsArray)[eltChoisi]))) ;
    nbPere++ ;
    AfficheListePere() ;
	}
}

voidNSEditReqDialog::CmOk()
{
    string sFils = "";

    // On reconstitue le chemin pere final
    ComposeCheminBrut(sCheminPere, pPereArray);

    // On reconstitue �galement le chemin de recherche �quivalent
    ComposeChemin(sCheminRechPere, pPereArray, true);

    // On constitue la string sFils � partir de l'array Fils
    if (!(pFilsArray->empty()))
    {
    	for (NSEltIter i = pFilsArray->begin(); i != pFilsArray->end(); i++)
    	{
        	if (sFils != "")
            	sFils += "|";
        	sFils += (*i)->code;
        }
    }

    TDialog::CmOk();
}

voidNSEditReqDialog::CmCancel()
{
	TDialog::CmCancel() ;
}


/*****************************************************************************/
/*                      GESTION DES CRITERES DE REQUETES                     */
/*****************************************************************************/

NSCritReqPatient::NSCritReqPatient()
{
    metAZero();
}

NSCritReqPatient::~NSCritReqPatient()
{
}

void
NSCritReqPatient::metAZero()
{
    strcpy(nom, "");
    strcpy(prenom, "");
    strcpy(sexe, "");
    strcpy(dateN1, "");
    strcpy(dateN2, "");
    strcpy(sitfam, "");
    strcpy(code_post, "");
    strcpy(ville, "");
}

NSCritReqPatient&
NSCritReqPatient::operator=(NSCritReqPatient src)
{
	strcpy(nom, 		src.nom);
	strcpy(prenom, 	    src.prenom);
	strcpy(sexe,        src.sexe);
	strcpy(dateN1,      src.dateN1);
    strcpy(dateN2,      src.dateN2);
    strcpy(sitfam, 	    src.sitfam);
	strcpy(code_post, 	src.code_post);
	strcpy(ville,       src.ville);

	return *this;
}

//
// Dialogue de saisie des crit�res Patient
//
DEFINE_RESPONSE_TABLE1(NSCritReqPatDialog, NSUtilDialog)
    EV_WM_CLOSE,
    EV_BN_CLICKED(IDC_CRITREQPAT_SEXE1, CmSexe),
    EV_BN_CLICKED(IDC_CRITREQPAT_SEXE2, CmSexe),
    EV_BN_CLICKED(IDC_CRITREQPAT_CEL, CmSitFam),
    EV_BN_CLICKED(IDC_CRITREQPAT_VEU, CmSitFam),
    EV_BN_CLICKED(IDC_CRITREQPAT_MAR, CmSitFam),
    EV_BN_CLICKED(IDC_CRITREQPAT_CCB, CmSitFam),
    EV_BN_CLICKED(IDC_CRITREQPAT_DIV, CmSitFam),
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_COMMAND(IDC_CRITREQPAT_EFFACER, CmEffacer),
END_RESPONSE_TABLE;
NSCritReqPatDialog::NSCritReqPatDialog(TWindow* pere, NSContexte* pCtx, TModule* mod)                   :NSUtilDialog(pere, pCtx, "IDD_CRITREQPAT", mod)
{
  // Initialisation des donnees
  pData 		= new NSCritReqPatient ;
  bEffacer  = false ;

  // Cr�ation de tous les "objets de contr�le"  pSexe		  = new TGroupBox(this, IDC_CRITREQPAT_SEXE) ;
  iSexe     = 0 ;
  pSitFam		= new TGroupBox(this, IDC_CRITREQPAT_SITFAM) ;
  iSitFam   = 0 ;

	pNom 	    = new NSUtilEdit(pContexte, this, IDC_CRITREQPAT_NOM, PAT_NOM_LEN) ;
	pPrenom   = new NSUtilEdit(pContexte, this, IDC_CRITREQPAT_PRENOM, PAT_PRENOM_LEN) ;
  pSexeM		= new TRadioButton(this, IDC_CRITREQPAT_SEXE1, pSexe) ;
  pSexeF    = new TRadioButton(this, IDC_CRITREQPAT_SEXE2, pSexe) ;

  // par d�faut la date de naissance reste en 00/00/1900 (b2000 == false)
  pDateN1		= new NSUtilEditDate(pContexte, this, IDC_CRITREQPAT_DATEN1, 10, false) ;
  pDateN2		= new NSUtilEditDate(pContexte, this, IDC_CRITREQPAT_DATEN2, 10, false) ;

  pCodePost	= new NSUtilEdit(pContexte, this, IDC_CRITREQPAT_CODEPOST, ADR_CODE_POST_LEN) ;
  pVille    = new NSUtilEdit(pContexte, this, IDC_CRITREQPAT_VILLE, ADR_VILLE_LEN) ;

  pCel		  = new TRadioButton(this, IDC_CRITREQPAT_CEL, pSitFam) ;
  pVeu		  = new TRadioButton(this, IDC_CRITREQPAT_VEU, pSitFam) ;
  pMar		  = new TRadioButton(this, IDC_CRITREQPAT_MAR, pSitFam) ;
  pCcb		  = new TRadioButton(this, IDC_CRITREQPAT_CCB, pSitFam) ;
  pDiv		  = new TRadioButton(this, IDC_CRITREQPAT_DIV, pSitFam) ;
  pNbEnf		= new NSEditNum(pContexte, this, IDC_CRITREQPAT_NBENF, 2, 0) ;
}

NSCritReqPatDialog::~NSCritReqPatDialog(){
  delete pNbEnf;
  delete pDiv;
  delete pCcb;
  delete pMar;
  delete pVeu;
  delete pCel;
	delete pVille;
  delete pCodePost;
  delete pDateN2;
  delete pDateN1;
  delete pSexeF;
  delete pSexeM;
  delete pPrenom;
  delete pNom;
  delete pSitFam;
  delete pSexe;
  delete pData;
}


void
NSCritReqPatDialog::SetupWindow()
{
	TDialog::SetupWindow();

    pNom->SetText(pData->nom);
    pPrenom->SetText(pData->prenom);

    if (strlen(pData->sexe))
    {
        if (pData->estMasculin())
        {
   	        pSexeM->Check();
            iSexe = 1;
        }
        if (pData->estFeminin())
        {
   	        pSexeF->Check();
            iSexe = 2;
        }
    }

    pDateN1->setDate(string(pData->dateN1));
    pDateN2->setDate(string(pData->dateN2));
    pCodePost->SetText(pData->code_post);
    pVille->SetText(pData->ville);

    if (strlen(pData->sitfam))
    switch(pData->sitfam[0])
    {
   	    case 'C':
      	    pCel->Check();
            iSitFam = 1;
            break;
        case 'V':
      	    pVeu->Check();
            iSitFam = 2;
            break;
        case 'M':
      	    pMar->Check();
            iSitFam = 3;
            break;
        case 'B':
      	    pCcb->Check();
            iSitFam = 4;
            break;
        case 'D':
      	    pDiv->Check();
            iSitFam = 5;
            break;
    }

    if (strlen(pData->sitfam) > 1)
        pNbEnf->SetText(&(pData->sitfam[1]));
    else
        pNbEnf->SetText("");
}

// m�thode qui marche avec des autoradiobutton type borland
void
NSCritReqPatDialog::CmSexe()
{
    if (pSexeM->GetCheck() == BF_CHECKED)
    {
        if (iSexe == 1)
        {
            pSexeM->Uncheck();
            iSexe = 0;
        }
        else
            iSexe = 1;
    }

    if (pSexeF->GetCheck() == BF_CHECKED)
    {
        if (iSexe == 2)
        {
            pSexeF->Uncheck();
            iSexe = 0;
        }
        else
            iSexe = 2;
    }
}

// m�thode qui marche avec des autoradiobutton type borland
void
NSCritReqPatDialog::CmSitFam()
{
    if (pCel->GetCheck() == BF_CHECKED)
    {
        if (iSitFam == 1)
        {
            pCel->Uncheck();
            iSitFam = 0;
        }
        else
            iSitFam = 1;
    }

    if (pVeu->GetCheck() == BF_CHECKED)
    {
        if (iSitFam == 2)
        {
            pVeu->Uncheck();
            iSitFam = 0;
        }
        else
            iSitFam = 2;
    }

    if (pMar->GetCheck() == BF_CHECKED)
    {
        if (iSitFam == 3)
        {
            pMar->Uncheck();
            iSitFam = 0;
        }
        else
            iSitFam = 3;
    }

    if (pCcb->GetCheck() == BF_CHECKED)
    {
        if (iSitFam == 4)
        {
            pCcb->Uncheck();
            iSitFam = 0;
        }
        else
            iSitFam = 4;
    }

    if (pDiv->GetCheck() == BF_CHECKED)
    {
        if (iSitFam == 5)
        {
            pDiv->Uncheck();
            iSitFam = 0;
        }
        else
            iSitFam = 5;
    }
}

void
NSCritReqPatDialog::CmEffacer()
{
    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
    int idRet = MessageBox("Etes-vous s�rs de vouloir effacer tous les crit�res Patient ?", sCaption.c_str(), MB_YESNO);
    if (idRet == IDNO)
        return;

    bEffacer = true;
    pData->metAZero();
    TDialog::CmOk();
}

void
NSCritReqPatDialog::CmOk()
{
    char far nom[PAT_NOM_LEN + 1];
    pNom->GetText(nom, PAT_NOM_LEN + 1);
    string sNom = string(nom);
    strip(sNom);
    strcpy(pData->nom, sNom.c_str());

    char far prenom[PAT_PRENOM_LEN + 1];
    pPrenom->GetText(prenom, PAT_PRENOM_LEN + 1);
    string sPrenom = string(prenom);
    strip(sPrenom);
    strcpy(pData->prenom, sPrenom.c_str());

    if (pSexeM->GetCheck() == BF_CHECKED)
   	    strcpy(pData->sexe, "1");

    if (pSexeF->GetCheck() == BF_CHECKED)
   	    strcpy(pData->sexe, "2");

    string sDateN1;
    pDateN1->getDate(&sDateN1);
    strcpy(pData->dateN1, sDateN1.c_str());

    string sDateN2;
    pDateN2->getDate(&sDateN2);
    strcpy(pData->dateN2, sDateN2.c_str());

    char far code_post[ADR_CODE_POST_LEN + 1];
    pCodePost->GetText(code_post, ADR_CODE_POST_LEN + 1);
    strcpy(pData->code_post, code_post);

    char far ville[ADR_VILLE_LEN + 1];
    pVille->GetText(ville, ADR_VILLE_LEN + 1);
    strcpy(pData->ville, ville);

    strcpy(pData->sitfam, "I");     // cf nombre d'enfants

    if (pCel->GetCheck() == BF_CHECKED)
   	    strcpy(pData->sitfam, "C");

    if (pVeu->GetCheck() == BF_CHECKED)
   	    strcpy(pData->sitfam, "V");

    if (pMar->GetCheck() == BF_CHECKED)
   	    strcpy(pData->sitfam, "M");

    if (pCcb->GetCheck() == BF_CHECKED)
   	    strcpy(pData->sitfam, "B");

    if (pDiv->GetCheck() == BF_CHECKED)
   	    strcpy(pData->sitfam, "D");

    char far nbenf[3];
    pNbEnf->GetText(nbenf, 3);
    if (strlen(nbenf) > 1)              // cas non pr�vu !!!
        strcat(pData->sitfam, "A");
    else if (nbenf[0] != '0')
        strcat(pData->sitfam, nbenf);

    TDialog::CmOk();
}

void
NSCritReqPatDialog::CmCancel()
{
    TDialog::CmCancel();
}

void
NSCritReqPatDialog::EvClose()
{
    CmCancel();
}

//
// Classe de Crit�res Document
//
NSCritReqDocum::NSCritReqDocum()
{
    metAZero();
}

NSCritReqDocum::~NSCritReqDocum()
{
}

void
NSCritReqDocum::metAZero()
{
    sCodeAuteur = "";
    sTitreAuteur = "";
    sCodeRoot = "";
    sDate1 = "";
    sDate2 = "";
}

NSCritReqDocum&
NSCritReqDocum::operator=(NSCritReqDocum src)
{
    sCodeAuteur = src.sCodeAuteur;
    sTitreAuteur = src.sTitreAuteur;
    sCodeRoot = src.sCodeRoot;
    sDate1 = src.sDate1;
    sDate2 = src.sDate2;

	return *this;
}
//// Dialogue de saisie des crit�res Document
//
DEFINE_RESPONSE_TABLE1(NSCritReqDocDialog, NSUtilDialog)
    EV_WM_CLOSE,
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_COMMAND(IDC_CRITREQDOC_AUTEUR, CmAuteur),
    EV_COMMAND(IDC_CRITREQDOC_EFFACER, CmEffacer),
END_RESPONSE_TABLE;

NSCritReqDocDialog::NSCritReqDocDialog(TWindow* pere, NSContexte* pCtx, TModule* mod)
                    :NSUtilDialog(pere, pCtx, "IDD_CRITREQDOC", mod)
{
  // Initialisation des donnees
  pData     = new NSCritReqDocum ;
  bEffacer  = false ;

	// Cr�ation de tous les "objets de contr�le"
  pAuteur   = new TStatic(this, IDC_CRITREQDOC_AUTEUR) ;
	pCodeRoot = new NSUtilLexique(pContexte, this, IDC_CRITREQDOC_TYPE, pContexte->getDico()) ;

  // par d�faut la date document est en 00/00/2000 (b2000 == true)
  pDate1    = new NSUtilEditDate(pContexte, this, IDC_CRITREQDOC_DATE1, 10, true);
  pDate2    = new NSUtilEditDate(pContexte, this, IDC_CRITREQDOC_DATE2, 10, true);
}

NSCritReqDocDialog::~NSCritReqDocDialog(){
  delete pDate2 ;
  delete pDate1 ;
  delete pCodeRoot ;
  delete pAuteur ;
  delete pData ;
}

void
NSCritReqDocDialog::SetupWindow()
{
  TDialog::SetupWindow() ;

  sCodeAuteur = pData->sCodeAuteur ;
  sTitreAuteur = pData->sTitreAuteur ;
  if (sCodeAuteur != "")
    pAuteur->SetCaption(sTitreAuteur.c_str()) ;
  pCodeRoot->setLabel(pData->sCodeRoot) ;
  pDate1->setDate(pData->sDate1) ;
  pDate2->setDate(pData->sDate2) ;
}

voidNSCritReqDocDialog::CmAuteur()
{
	NSReqListUtilDialog* pListeUtilDlg ;

	pListeUtilDlg = new NSReqListUtilDialog(this, pContexte, pNSResModule) ;

	if ((pListeUtilDlg->Execute() == IDOK) && (pListeUtilDlg->UtilChoisi >= 0))
	{
		sCodeAuteur = pListeUtilDlg->pUtilSelect->getNss() ;
    sTitreAuteur = pListeUtilDlg->pUtilSelect->donneTitre(pContexte) ;    pAuteur->SetCaption(sTitreAuteur.c_str()) ;
  }

	delete pListeUtilDlg ;
}

voidNSCritReqDocDialog::CmEffacer()
{
	string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
	int idRet = MessageBox("Etes-vous s�rs de vouloir effacer tous les crit�res Document ?", sCaption.c_str(), MB_YESNO) ;
	if (IDNO == idRet)
		return ;

	bEffacer = true ;
	pData->metAZero() ;
	TDialog::CmOk() ;
}


void
NSCritReqDocDialog::CmOk()
{
    char far code[255];

    pCodeRoot->GetText(code, 255);
    if (!strcmp(code, ""))
    {
        pData->sCodeRoot = "";
    }
    else
    {
        pData->sCodeRoot = pCodeRoot->getCode();
        if (pData->sCodeRoot == "�?????")
        {
            erreur("Attention vous ne pouvez pas entrer le type document en texte libre...", standardError, 0) ;
            return;
        }
    }

    pData->sCodeAuteur = sCodeAuteur;
    pData->sTitreAuteur = sTitreAuteur;

    pDate1->getDate(&(pData->sDate1));
    pDate2->getDate(&(pData->sDate2));

    TDialog::CmOk();
}

void
NSCritReqDocDialog::CmCancel()
{
    TDialog::CmCancel();
}

void
NSCritReqDocDialog::EvClose()
{
    CmCancel();
}

// -----------------------------------------------------------------
//
//  M�thodes de NSReqListUtilDialog
//
// -----------------------------------------------------------------

// ---------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NSReqListUtilDialog, NSUtilDialog)
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_LVN_GETDISPINFO(IDC_LISTUTI_LW, LvnGetDispInfo),
END_RESPONSE_TABLE;

NSReqListUtilDialog::NSReqListUtilDialog(TWindow* pere, NSContexte* pCtx, TModule* mod)
                         :NSUtilDialog(pere, pCtx, "IDD_LISTUTI", mod)
{
    pListeUtil = new NSReqListUtilWindow(this, IDC_LISTUTI_LW);
    pUtilArray = new NSUtiliArray;
    pUtilSelect = new NSUtiliInfo(pContexte);
}

NSReqListUtilDialog::~NSReqListUtilDialog()
{
	delete pUtilSelect;
    delete pUtilArray;
    delete pListeUtil;
}

void
NSReqListUtilDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow();

    InitUtilArray();
    InitListe();
    AfficheListe();
}
boolNSReqListUtilDialog::InitUtilArray()
{
	pUtilArray->vider() ;
	nbUtil = 0 ;
	return true ;
}


void
NSReqListUtilDialog::InitListe()
{
	TListWindColumn colNom("Nom", 100, TListWindColumn::Left, 0);
  	pListeUtil->InsertColumn(0, colNom);
    TListWindColumn colPrenom("Prenom", 100, TListWindColumn::Left, 1);
  	pListeUtil->InsertColumn(1, colPrenom);
}
voidNSReqListUtilDialog::AfficheListe()
{
	char nom[255] ;

	pListeUtil->DeleteAllItems() ;

	for (int i = nbUtil - 1; i >= 0; i--)
	{
  	sprintf(nom, "%s", ((*pUtilArray)[i])->getNom().c_str()) ;
    TListWindItem Item(nom, 0) ;
    pListeUtil->InsertItem(Item) ;
	}
}

voidNSReqListUtilDialog::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
	const int BufLen = 255 ;
	static char buffer[BufLen] ;
	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;

	int index = dispInfoItem.GetIndex() ;

	// Affiche les informations en fonction de la colonne	switch (dispInfoItem.GetSubItem())
	{
  	case 1: 	// pr�nom
    	sprintf(buffer, "%s", ((*pUtilArray)[index])->getPrenom().c_str()) ;
      dispInfoItem.SetText(buffer) ;
      break ;
	}
}

voidNSReqListUtilDialog::CmOk()
{
	UtilChoisi = pListeUtil->IndexItemSelect();
	if (UtilChoisi >= 0)
		*pUtilSelect = *((*pUtilArray)[UtilChoisi]) ;
	else
	{
  	erreur("Vous devez choisir un utilisateur.", standardError, 0, GetHandle()) ;
    return ;
	}

	NSUtilDialog::CmOk() ;
}


void
NSReqListUtilDialog::CmCancel()
{
	UtilChoisi = -1;
    NSUtilDialog::CmCancel();
}

// -----------------------------------------------------------------
//
//  M�thodes de NSReqListUtilWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSReqListUtilWindow, TListWindow)
    EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

//---------------------------------------------------------------------------
//  Function: NSReqListUtilWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
voidNSReqListUtilWindow::EvLButtonDblClk(uint /* modKeys */, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point) ;

	HitTest(info) ;

	if (info.GetFlags() & LVHT_ONITEM)
  	pDlg->CmOk() ;
}


//---------------------------------------------------------------------------
//  Function: NSReqListUtilWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSReqListUtilWindow::IndexItemSelect()
{
    int count = GetItemCount();
    int index = -1;

    for (int i = 0; i < count; i++)
   	    if (GetItemState(i, LVIS_SELECTED))
        {
      	    index = i;
            break;
        }

    return index;
}

// -----------------------------------------------------------------//
//  M�thodes de NSValeurChiffreeDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSValeurChiffreeDialog, NSUtilDialog)
    EV_BN_CLICKED(IDC_VALEUR_AVECINF, CmAvecInf),
    EV_BN_CLICKED(IDC_VALEUR_AVECSUP, CmAvecSup),
    EV_BN_CLICKED(IDC_VALEUR_EFF, CmEffacer),
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

NSValeurChiffreeDialog::NSValeurChiffreeDialog(TWindow* pere, int MaxEntree,
                                                NSContexte* pCtx, TModule* mod)
                       :NSUtilDialog(pere, pCtx, "IDD_VALEUR", mod)
{
  sValeurExacte = "" ;
  sValeurSup    = "" ;
  sValeurInf    = "" ;
  sUnite        = "" ;
  bAvecInf      = false ;
  bAvecSup      = false ;
  MaxInPut      = MaxEntree ;
	//
	// Cr�ation de tous les "objets de contr�le"
	//
  pValeurExacte = new NSUtilEdit(pContexte, this, IDC_VALEUR_EDITION, MaxInPut) ;
  pValeurSup 	  = new NSUtilEdit(pContexte, this, IDC_VALEUR_SUP, MaxInPut) ;
  pValeurInf 	  = new NSUtilEdit(pContexte, this, IDC_VALEUR_INF, MaxInPut) ;
  pUnite        = new NSUtilLexique(pContexte, this, IDC_VALEUR_UNITE, pCtx->getDico()) ;
  pAvecInf      = new TRadioButton(this, IDC_VALEUR_AVECINF) ;
  pAvecSup      = new TRadioButton(this, IDC_VALEUR_AVECSUP) ;
}

NSValeurChiffreeDialog::~NSValeurChiffreeDialog(){
  delete pValeurExacte ;
  delete pValeurInf ;
  delete pValeurSup ;
  delete pUnite ;
  delete pAvecInf ;
  delete pAvecSup ;
}

void
NSValeurChiffreeDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow() ;

  pValeurExacte->SetText(sValeurExacte.c_str()) ;
  pValeurSup->SetText(sValeurSup.c_str()) ;
  pValeurInf->SetText(sValeurInf.c_str()) ;
  if (bAvecInf)
    pAvecInf->Check() ;
  if (bAvecSup)
    pAvecSup->Check() ;
  pUnite->setLabel(sUnite) ;
}


void
NSValeurChiffreeDialog::CmAvecInf()
{
    if (bAvecInf)
    {
        bAvecInf = false;
        pAvecInf->Uncheck();
    }
    else
    {
        bAvecInf = true;
        pAvecInf->Check();
    }
}

void
NSValeurChiffreeDialog::CmAvecSup()
{
    if (bAvecSup)
    {
        bAvecSup = false;
        pAvecSup->Uncheck();
    }
    else
    {
        bAvecSup = true;
        pAvecSup->Check();
    }
}

void
NSValeurChiffreeDialog::CmEffacer()
{
    // on ne touche pas � l'unit�
    pValeurExacte->SetText("");
    sValeurExacte = "";
    pValeurSup->SetText("");
    sValeurSup = "";
    pAvecSup->Uncheck();
    bAvecSup = false;
    pValeurInf->SetText("");
    sValeurInf = "";
    pAvecInf->Uncheck();
    bAvecInf = false;
}
voidNSValeurChiffreeDialog::CmOk()
{
  size_t pos;
  char far* edition1 = new char[MaxInPut + 1];
  pValeurExacte->GetText(edition1, MaxInPut + 1);
  sValeurExacte = string(edition1);
  pos = sValeurExacte.find(",");
  if (pos != NPOS)
      sValeurExacte.replace(pos, 1, ".");
  delete[] edition1;

  char far* edition2 = new char[MaxInPut + 1];  pValeurSup->GetText(edition2, MaxInPut + 1);
  sValeurSup = string(edition2);
  pos = sValeurSup.find(",");
  if (pos != NPOS)
      sValeurSup.replace(pos, 1, ".");
  delete[] edition2;

  char far* edition3 = new char[MaxInPut + 1];
  pValeurInf->GetText(edition3, MaxInPut + 1);
  sValeurInf = string(edition3);
  pos = sValeurInf.find(",");
  if (pos != NPOS)
      sValeurInf.replace(pos, 1, ".");
  delete[] edition3;

  if ((sValeurExacte != "") && ((sValeurSup != "") || (sValeurInf != "")))
  {
  	erreur("Il faut choisir la valeur exacte ou l'intervalle", standardError, 0) ;
    pValeurExacte->SetFocus() ;
    return ;
  }

  if (sValeurExacte == "")
  {
      if (pAvecInf->GetCheck() == BF_CHECKED)
          bAvecInf = true;
      else
          bAvecInf = false;

      if (pAvecSup->GetCheck() == BF_CHECKED)
          bAvecSup = true;
      else
          bAvecSup = false;
  }

  char far* unite = new char[MaxInPut + 1];
  pUnite->GetText(unite, MaxInPut + 1);
  if (!strcmp(unite, ""))
  {
      sUnite = "200001";
  }
  else
  {
      sUnite = pUnite->getCode();
      if (sUnite == "�?????")
      {
          erreur("L'unit� doit �tre choisie � partir du lexique, et non en texte libre.", standardError, 0, GetHandle()) ;
          delete[] unite;
          return;
      }
  }
  delete[] unite;

	NSUtilDialog::CmOk();
}


void
NSValeurChiffreeDialog::CmCancel()
{
	NSUtilDialog::CmCancel();
}

// fin de nsrechcr.cpp
////////////////////////////////////////////////////////////////////////////////////

