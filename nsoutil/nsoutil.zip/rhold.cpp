//
//
//
#define OUTILS				100
#define DOCUMENT_EDIT 	101
#define IDC_EDITSEM 		102
#define IDC_CONVERT 		103
#define IDD_VF				104
#define IDD_PV				105
#define IDD_TV				106

#define IDC_VF				107
#define IDC_PV				108
#define IDC_TV				109


//VRAI FAUX
#define IDC_VFITEM1			110
#define IDC_VFREL				111
#define IDC_VFITEM2			112

//Premier vrai
#define IDC_PVITEM			113
#define IDC_PVREL				114

//Tous les vrais
#define IDC_TVITEM			115
#define IDC_TVREL				116

