#include <string.h>#include <cstring.h>
#include <stdio.h>
#include <sysutils.hpp>

#include "nautilus\nssuper.h"
#include "nsoutil\nsfilgui.h"
#include "nsoutil\nsoutil.h"
#include "nsoutil\nsoutil.rh"
#include "nssavoir\nsguide.h"
#include "nsbb\nsednum.h"

// *********************************
// D�finition de la classe NSElement
// *********************************

NSElement::NSElement(){
  code     = "" ;
  libelle  = "" ;
  decalage = "" ;
  result   = -1 ;
}

NSElement::NSElement(string sCode, string sLibelle, string sDecalage)
{
	code     = sCode ;
	libelle  = sLibelle ;
	decalage = sDecalage ;
	result   = -1 ;
}

NSElement::~NSElement(){
}

NSElement::NSElement(NSElement& rv)
{
  code     = rv.code ;
  libelle  = rv.libelle ;
  decalage = rv.decalage ;
  result   = rv.result ;
}

NSElement&
NSElement::operator=(NSElement src)
{
	if (this == &src)
		return *this ;

  code     = src.code ;
  libelle  = src.libelle ;
  decalage = src.decalage ;
  result   = src.result ;

	return *this ;
}

intNSElement::operator==(NSElement& o)
{
  if ((code == o.code) &&
      (libelle == o.libelle) &&
      (decalage == o.decalage))
		return 1 ;
  else
		return 0 ;
}

// **********************************
// D�finition de la classe NSEltArray
// **********************************

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSEltArray::NSEltArray(NSEltArray& rv) : NSEltVector()
{
	if (!rv.empty())
		for (NSEltIter i = rv.begin(); i != rv.end(); i++)
			push_back(new NSElement(*(*i))) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
void
NSEltArray::vider()
{
	if (!empty())
		for (NSEltIter i = begin(); i != end(); )
    {
    	delete *i ;
    	erase(i) ;
    }
}

NSEltArray::~NSEltArray(){
	vider() ;
}

// -----------------------------------------------------------------//
//  M�thodes de NSModifFilGuideDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSModifFilGuideDialog, NSUtilDialog)    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_BN_CLICKED(IDC_MODFG_SEQUENCE, CmTouteSequence),
    EV_BN_CLICKED(IDC_MODFG_ELEMENT, CmToutElement),
    EV_BN_CLICKED(IDC_MODFG_PLUR1, CmMajCode),
    EV_BN_CLICKED(IDC_MODFG_PLUR2, CmMajCode),
    EV_BN_CLICKED(IDC_MODFG_PLURSANS, CmMajCode),
    EV_BN_CLICKED(IDC_MODFG_CERT00, CmMajCode),
    EV_BN_CLICKED(IDC_MODFG_CERT25, CmMajCode),
    EV_BN_CLICKED(IDC_MODFG_CERT50, CmMajCode),
    EV_BN_CLICKED(IDC_MODFG_CERT75, CmMajCode),
    EV_BN_CLICKED(IDC_MODFG_CERT100, CmMajCode),
    EV_BN_CLICKED(IDC_MODFG_CERTSANS, CmMajCode),
END_RESPONSE_TABLE;

NSModifFilGuideDialog::NSModifFilGuideDialog(TWindow* pere, string code, NSContexte* pCtx,                                                TModule* mod, bool bDialoguePere)
                         :NSUtilDialog(pere, pCtx, "IDD_MODFG", mod)
{
    pEdit           = new NSUtilLexique(pContexte, this, IDC_MODFG_EDIT, pContexte->getDico());
    pTouteSequence  = new TRadioButton(this, IDC_MODFG_SEQUENCE);
    pToutElement    = new TRadioButton(this, IDC_MODFG_ELEMENT);

    // GroupBox pour la certitude
    pCertitude      = new TGroupBox(this, IDC_MODFG_CERTGROUP);
    pCertSans       = new TRadioButton(this, IDC_MODFG_CERTSANS, pCertitude);
    pCert00         = new TRadioButton(this, IDC_MODFG_CERT00, pCertitude);
    pCert25         = new TRadioButton(this, IDC_MODFG_CERT25, pCertitude);
    pCert50         = new TRadioButton(this, IDC_MODFG_CERT50, pCertitude);
    pCert75         = new TRadioButton(this, IDC_MODFG_CERT75, pCertitude);
    pCert100        = new TRadioButton(this, IDC_MODFG_CERT100, pCertitude);

    // GroupBox pour le pluriel
    pPluriel        = new TGroupBox(this, IDC_MODFG_PLURGROUP);
    pPlur1          = new TRadioButton(this, IDC_MODFG_PLUR1, pPluriel);
    pPlur2          = new TRadioButton(this, IDC_MODFG_PLUR2, pPluriel);
    pSingulier      = new TRadioButton(this, IDC_MODFG_PLURSANS, pPluriel);

    sCode = code;
    bPere = bDialoguePere;
}

NSModifFilGuideDialog::~NSModifFilGuideDialog()
{
    delete pEdit;
    delete pTouteSequence;
    delete pToutElement;
    delete pCertSans;
    delete pCert00;
    delete pCert25;
    delete pCert50;
    delete pCert75;
    delete pCert100;
    delete pCertitude;
    delete pPlur1;
    delete pPlur2;
    delete pSingulier;
    delete pPluriel;
}

void
NSModifFilGuideDialog::SetupWindow()
{
	string sText ;

	NSUtilDialog::SetupWindow() ;

  if (sCode == "")
  {
    pSingulier->Check() ;
    pCertSans->Check() ;
    pEdit->setLabel("") ;
    pEdit->SetFocus() ;
    return ;
  }
  else if (sCode == "~????1")
  {
    CmToutElement() ;
    return ;
  }
  else if (sCode == "~~***1")
  {
    CmTouteSequence() ;
    return ;
  }
  else if (sCode[0] == '~')
    sText = string("Joker (") + string(sCode, 3, 2) + string(")") ;
  else
    sText = "" ;

  // on doit initialiser le pluriel et la certitude
  size_t pos1, pos2 ;
  string sRacine ;
  string sCompl ;

  pos1 = sCode.find('/') ;
  if (pos1 != string::npos)
  {
    sRacine = string(sCode, 0, pos1) ;
    pCertSans->Check() ;
    pSingulier->Check() ;

    while (pos1 != string::npos)
    {
      pos2 = sCode.find('/', pos1+1) ;
      if (pos2 != string::npos)
      	sCompl = string(sCode, pos1+1, pos2-pos1-2) ;
      else
      	sCompl = string(sCode, pos1+1, strlen(sCode.c_str())-pos1-2) ;

      if (sCompl == "")
      {
        erreur("Cet �l�ment comporte un attribut vide.", standardError, 0) ;
      }
      else if (sCompl[0] == '$')
      {
        erreur("Cet �l�ment comporte un attribut compl�ment.", standardError, 0) ;
      }
      else if (sCompl == "WPLUR")
      {
        pSingulier->Uncheck() ;
        pPlur1->Check() ;
      }
      else if (sCompl == "WPLUS")
      {
        pSingulier->Uncheck() ;
        pPlur2->Check() ;
      }
      else if (string(sCompl, 0, 3) == "WCE")
      {
        sCompl = string(sCompl, 3, 2) ;
        pCertSans->Uncheck() ;

        if (sCompl == "00")
        	pCert00->Check() ;
        else if (sCompl == "25")
        	pCert25->Check() ;
        else if (sCompl == "50")
        	pCert50->Check() ;
        else if (sCompl == "75")
        	pCert75->Check() ;
        else if (sCompl == "A0")
        	pCert100->Check() ;
        else
        	erreur("Cet �l�ment comporte un attribut de certitude incorrect.", standardError, 0) ;
      }
      else
        erreur("Cet �l�ment comporte un attribut inconnu.", standardError, 0) ;

      pos1 = pos2 ;
    }
  }
  else
  {
    sRacine = sCode ;
    pCertSans->Check() ;
    pSingulier->Check() ;
  }

  pEdit->setLabel(sRacine, sText) ;
  pEdit->SetFocus() ;
}

void
NSModifFilGuideDialog::UncheckAll()
{
    pCert00->Uncheck();
    pCert25->Uncheck();
    pCert50->Uncheck();
    pCert75->Uncheck();
    pCert100->Uncheck();
    pCertSans->Uncheck();
    pPlur1->Uncheck();
    pPlur2->Uncheck();
    pSingulier->Uncheck();
}

voidNSModifFilGuideDialog::CmTouteSequence()
{
	if (bPere)
  {
  	if (pTouteSequence->GetCheck() == BF_CHECKED)
    {
    	pTouteSequence->Uncheck() ;
      pEdit->setLabel("") ;
    }
    else
    {
    	pTouteSequence->Check() ;
      pToutElement->Uncheck() ;
      UncheckAll() ;
      pSingulier->Check() ;
      pCertSans->Check() ;
      pEdit->setLabel("~~***1", "Toute S�quence (**)") ;
    }
  }

  pEdit->SetFocus() ;
}

voidNSModifFilGuideDialog::CmToutElement()
{
    if (bPere)
    {
        if (pToutElement->GetCheck() == BF_CHECKED)
        {
            pToutElement->Uncheck();
            pEdit->setLabel("");
        }
        else
        {
            pToutElement->Check();
            pTouteSequence->Uncheck();
            UncheckAll();
            pSingulier->Check();
            pCertSans->Check();
            pEdit->setLabel("~????1", "Tout �l�ment (??)");
        }
    }

    pEdit->SetFocus();
}

voidNSModifFilGuideDialog::CmMajCode()
{
    string sCodelex = pEdit->getCode();

    if ((pToutElement->GetCheck() == BF_CHECKED) ||
        (pTouteSequence->GetCheck() == BF_CHECKED) ||
        (sCodelex == "") || (sCodelex == "�?????"))
    {
        // on laisse dans l'�tat : sans certitude et sans pluriel
        UncheckAll();
        pCertSans->Check();
        pSingulier->Check();
    }

    pEdit->SetFocus();
}

voidNSModifFilGuideDialog::CmOk()
{
    string sCompl1, sCompl2;

    sCode = pEdit->getCode();
    if (sCode == "�?????")
    {
        erreur("Attention vous ne pouvez pas ins�rer du texte libre...", standardError, 0) ;
        return;
    }

    // Compl�ment Pluriel
    if (pPlur1->GetCheck() == BF_CHECKED)
        sCompl1 = "/WPLUR1";
    else if (pPlur2->GetCheck() == BF_CHECKED)
        sCompl1 = "/WPLUS1";
    else
        sCompl1 = "";

    // Compl�ment Certitude
    if (pCert00->GetCheck() == BF_CHECKED)
        sCompl2 = "/WCE001";
    else if (pCert25->GetCheck() == BF_CHECKED)
        sCompl2 = "/WCE251";
    else if (pCert50->GetCheck() == BF_CHECKED)
        sCompl2 = "/WCE501";
    else if (pCert75->GetCheck() == BF_CHECKED)
        sCompl2 = "/WCE751";
    else if (pCert100->GetCheck() == BF_CHECKED)
        sCompl2 = "/WCEA01";
    else
        sCompl2 = "";

    // note : on laisse la possibilit� d'avoir un code vide en sortie
    sCode = sCode + sCompl1 + sCompl2;

    TDialog::CmOk();
}

void
NSModifFilGuideDialog::CmCancel()
{
    TDialog::CmCancel();
}

// -----------------------------------------------------------------
//
//  M�thodes de NSListFGWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSListFGWindow, TListWindow)
    EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

//---------------------------------------------------------------------------
//  Function: NSListFGWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
//
//  Arguments:	  les modKeys et le point click�
//
//  Description: Fonction de r�ponse au click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListFGWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
    TListWindow::EvLButtonDown(modKeys, point);

    TLwHitTestInfo info(point);
    HitTest(info);

    if (info.GetFlags() & LVHT_ONITEM)
    {
        if (iRes == IDC_LW_PERE)
            pDlg->CmModPere();
        else if (iRes == IDC_LW_FILS)
            pDlg->CmModFils();
    }
}

//---------------------------------------------------------------------------
//  Function: NSListFGWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListFGWindow::IndexItemSelect()
{
    int count = GetItemCount();
    int index = -1;

    for (int i = 0; i < count; i++)
   	    if (GetItemState(i, LVIS_SELECTED))
        {
      	    index = i;
            break;
        }

    return index;
}

// -----------------------------------------------------------------
//
//  M�thodes de NSEditFilGuideDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSEditFilGuideDialog, NSUtilDialog)
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_COMMAND(IDC_EDIT_CHOIXGD, ChoixGroupe),

    EV_COMMAND(IDC_HAUT_PERE, CmHautPere),
    EV_COMMAND(IDC_BAS_PERE, CmBasPere),
    EV_COMMAND(IDC_INS_PERE, CmInsPere),
    EV_COMMAND(IDC_MOD_PERE, CmModPere),
    EV_COMMAND(IDC_DEL_PERE, CmDelPere),

    EV_COMMAND(IDC_HAUT_FILS, CmHautFils),
    EV_COMMAND(IDC_BAS_FILS, CmBasFils),
    EV_COMMAND(IDC_INS_FILS, CmInsFils),
    EV_COMMAND(IDC_MOD_FILS, CmModFils),
    EV_COMMAND(IDC_DEL_FILS, CmDelFils),
END_RESPONSE_TABLE;

NSEditFilGuideDialog::NSEditFilGuideDialog(TWindow* pere, NSContexte* pCtx,
                                            string codeGroupe, string codeFilGuide)
                         :NSUtilDialog(pere, pCtx, "IDD_EDITFG", pNSResModule)
{
    pEditComment   = new NSUtilEdit(pContexte, this, IDC_EDIT_COMMENT, BB_COMMENTAIRE_LEN);
    pEditGroupe    = new TStatic(this, IDC_EDIT_CHOIXGD);
    pListePere     = new NSListFGWindow(this, IDC_LW_PERE);
    pListeFils     = new NSListFGWindow(this, IDC_LW_FILS);
    pPereArray     = new NSEltArray;
    pFilsArray     = new NSEltArray;
    nbPere = 0;
    nbFils = 0;

    sCodeGroupe = codeGroupe;
    sCodeFilGuide = codeFilGuide;
    sCheminPere = "";

    // si le groupe n'est pas pr�cis�, on autorise le choix d'un groupe
    if (sCodeGroupe == "")
        bChoixGroupe = true;
    else
        bChoixGroupe = false;
}

NSEditFilGuideDialog::~NSEditFilGuideDialog()
{
    delete pEditComment;
    delete pEditGroupe;
    delete pListePere;
    delete pListeFils;
    delete pPereArray;
    delete pFilsArray;
}

void
NSEditFilGuideDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow();

    InitListePere();
    InitListeFils();
    AfficheNomGroupe();

    if (sCodeFilGuide != "")
    {
        if (ChargeFilGuide())
        {
            AfficheListePere();
            AfficheListeFils();
        }
        else
            erreur("Impossible de charger le fil guide recherch�.",standardError, 0) ;
    }
    else
    {
        AfficheListePere();
        AfficheListeFils();
    }
}

voidNSEditFilGuideDialog::InitListePere()
{
	TListWindColumn colElt("P�re", 500, TListWindColumn::Left, 0);
  	pListePere->InsertColumn(0, colElt);
}

void
NSEditFilGuideDialog::InitListeFils()
{
	TListWindColumn colFils("Fils", 500, TListWindColumn::Left, 0);
  	pListeFils->InsertColumn(0, colFils);
}

void
NSEditFilGuideDialog::AfficheListePere()
{
    char elt[255];

	pListePere->DeleteAllItems();

	for (int i = nbPere - 1; i >= 0; i--)
    {
   	    sprintf(elt, "%s", (((*pPereArray)[i])->libelle).c_str());
   	    TListWindItem Item(elt, 0);
        pListePere->InsertItem(Item);
    }

    pListePere->SetFocus();
}

void
NSEditFilGuideDialog::AfficheListeFils()
{
    char elt[255];

	pListeFils->DeleteAllItems();

	for (int i = nbFils - 1; i >= 0; i--)
    {
   	    sprintf(elt, "%s", (((*pFilsArray)[i])->libelle).c_str());
   	    TListWindItem Item(elt, 0);
        pListeFils->InsertItem(Item);
    }

    pListeFils->SetFocus();
}


// -----------------------------------------------------------------------------
// Fonction  : TrouveLibelle(string sCode, string& sLibelle, bool bPere)
// En entr�e : un code lexique ou un ensemble de codes lexiques s�par�s par '/'
// En sortie : le libell� ou l'ensemble de libell�s correspondant
// -----------------------------------------------------------------------------
void
NSEditFilGuideDialog::TrouveLibelle(string sCode, string& sLibelle, bool bPere)
{
  size_t pos1, pos2 ;
  bool bContinue = true ;
  string sCode1, sLibelle1 ;
  string sCode2, sLibelle2 ;

  // on remet � "" sLibelle
  sLibelle = "" ;

  pos1 = 0 ;
  pos2 = sCode.find('/') ;
  if (pos2 != string::npos)
  {
    while (bContinue)
    {
      if (pos2 != string::npos)
        sCode1 = string(sCode, pos1, pos2 - pos1) ;
      else
        sCode1 = string(sCode, pos1, strlen(sCode.c_str()) - pos1) ;

      TrouveLibelle(sCode1, sLibelle1, bPere) ;
      if (sLibelle == "")
        sLibelle = sLibelle1 ;
      else
        sLibelle += string("/") + sLibelle1 ;

      if ((pos2 == string::npos) || (pos2 == (strlen(sCode.c_str()) - 1)))
        bContinue = false ;
      else
      {
        pos1 = pos2 + 1 ;
        pos2 = sCode.find('/', pos1) ;
      }
    }
    return ;
  }

  string sLang = "" ;
  if ((pContexte) && (pContexte->getUtilisateur()))
  	sLang = pContexte->getUtilisateur()->donneLang() ;

  // on traite d'abord les jokers (codes peres)
  if (bPere && (sCode == "~????1"))
    sLibelle = "Tout �l�ment (??)" ;
  else if (bPere && (sCode == "~~***1"))
    sLibelle = "Toute s�quence (**)" ;
  else if (bPere && (sCode != "") && (sCode[0] == '~'))
    sLibelle = string("Joker (") + string(sCode,3,2) + string(")") ;
  else    // cas des codes commun aux fils et aux peres (codes lexiques)
  {
    if (sCode == "")
      sLibelle = "[Vide]" ;
    else
    {
      if (strlen(sCode.c_str()) == BASE_LEXI_LEN)
      {
        sCode2 = sCode ;
        sLibelle2 = "" ;
        if (pContexte->getDico()->donneLibelle(sLang, &sCode2, &sLibelle2))
        {
          // pour les codes syst�me
          if (sLibelle2 == "")
          {
            pContexte->getDico()->donneLibelleLexique(sLang, &sCode2, &sLibelle2) ;

            // pour les cas non trait�s
            if (sLibelle2 == "")
              sLibelle = sCode ;
            else
              sLibelle = sLibelle2 ;
          }
          else // cas normal
          	sLibelle = sLibelle2 ;
        }
        else // cas d'erreur : code introuvable
        	sLibelle = sCode ;
      }
      else // cas d'erreur : code trop long
      	sLibelle = sCode ;
    }
  }
}


// -----------------------------------------------------------------------------
// Fonction    : ParsingChemin(string sChem, bool bPere)
// En entr�e   : un chemin de codes lexiques ou de codes sens et un bool�en
// Description : charge l'array des codes p�re ou fils avec les �l�ments du chemin
// -----------------------------------------------------------------------------
void
NSEditFilGuideDialog::ParsingChemin(string sChem, bool bPere)
{
  string sCode, sCodeElt ;
  string sLibelle, sLibelleElt ;
  size_t pos1, pos2 ;
  char sep ;
  bool bVide = true ;
  bool bParsing = true ;

  if (bPere)
    sep = '/' ;
  else
    sep = '|' ;

  sCodeElt = "" ;
  sLibelleElt = "" ;

  pos1 = 0 ;
  pos2 = sChem.find(sep) ;

  while (bParsing)
  {
    sCode = "" ;
    sLibelle = "" ;

    if (pos2 != string::npos)
      sCode = string(sChem, pos1, pos2 - pos1) ;
    else
      sCode = string(sChem, pos1, strlen(sChem.c_str()) - pos1) ;

    // Chaque sElement r�cup�r� peut �tre un code sens
    // => on le transforme en code lexique
    if ((sCode != "") && (strlen(sCode.c_str()) < BASE_LEXI_LEN))
    	pContexte->getSuperviseur()->getDico()->donneCodeComplet(sCode) ;

    TrouveLibelle(sCode, sLibelle, bPere) ;

    // cas des attributs
    if ((sCode[0] == '$') || (string(sCode, 0, 3) == "WCE") || (string(sCode, 0, 4) == "WPLU"))
    {
      // on stocke alors le code et le libelle
      // dans l'�l�ment en cours
      if (bVide)
      {
        sCodeElt = sCode ;
        sLibelleElt = sLibelle ;
        bVide = false ;
      }
      else
      {
        sCodeElt += string("/") + sCode ;
        sLibelleElt += string("/") + sLibelle ;
      }
    }
    else
    {
      if (!bVide)
      {
        if (bPere)
        {
          pPereArray->push_back(new NSElement(sCodeElt, sLibelleElt)) ;
          nbPere++ ;
        }
        else
        {
          pFilsArray->push_back(new NSElement(sCodeElt, sLibelleElt)) ;
          nbFils++ ;
        }
      }
      sCodeElt = sCode ;
      sLibelleElt = sLibelle ;
      bVide = false ;
    }

    // condition d'arret : on traite aussi le cas du '/' � la fin du chemin
    if ((pos2 == string::npos) || (pos2 == (strlen(sChem.c_str()) - 1)))
    {
      bParsing = false ;
    }
    else
    {
      pos1 = pos2 + 1 ;
      pos2 = sChem.find(sep, pos1) ;
    }
  }

  // on traite le dernier �l�ment (�ventuellement : chemin vide)
  if (bPere)
  {
    pPereArray->push_back(new NSElement(sCodeElt, sLibelleElt)) ;
    nbPere++ ;
  }
  else
  {
    pFilsArray->push_back(new NSElement(sCodeElt, sLibelleElt)) ;
    nbFils++ ;
  }
}


bool

NSEditFilGuideDialog::ChargeFilGuide()
{

    string sChemin;
    string sFils;
    string sCode;

    //
    // On r�cup�re le fil guide de code sCodeFilGuide
    // Cr�ation d'un BBFiche
    //
    BBFiche* pBBFiche = new BBFiche(pContexte);
    pBBFiche->lastError = pBBFiche->open();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
        erreur("Il est impossible d'ouvrir le fichier des Guides.", standardError, pBBFiche->lastError) ;
        delete pBBFiche;
        return false;
    }

    // On cherche les fils guides de groupe sCode
    sCode = sCodeGroupe + sCodeFilGuide;
    pBBFiche->lastError = pBBFiche->chercheClef(&sCode,
                                        "",
                                        0,
                                        keySEARCHEQ,
                                        dbiWRITELOCK);

    if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_RECNOTFOUND))
    {
        erreur("Erreur � la recherche dans le fichier des Guides.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }
    else if (pBBFiche->lastError == DBIERR_RECNOTFOUND)
    {
        erreur("Impossible de trouver le fil guide recherch� dans la base des guides.", standardError, 0) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }

    // on est sur le bon fil guide
    pBBFiche->lastError = pBBFiche->getRecord();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
        erreur("Erreur � la lecture d'une fiche Guides.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }

    // On affiche le champ commentaire
    pEditComment->SetText((static_cast<BBItemData*>(pBBFiche->pDonnees))->commentaire);

    // On r�cup�re ici le chemin du fil guide et ses fils
    sChemin = string((static_cast<BBItemData*>(pBBFiche->pDonnees))->chemin);
    sFils = string((static_cast<BBItemData*>(pBBFiche->pDonnees))->fils);

    // on charge d'abord le tableau Pere
    ParsingChemin(sChemin, true);

    // on charge maintenant le tableau Fils
    ParsingChemin(sFils, false);

    // on ferme la base des guides
    pBBFiche->lastError = pBBFiche->close();
    if (pBBFiche->lastError != DBIERR_NONE)
        erreur("Erreur de fermeture de la base des Guides.", standardError, pBBFiche->lastError) ;

    delete pBBFiche;
    return true;
}

// ************** Controles de la boite Pere

void
NSEditFilGuideDialog::CmBasPere()
{
    int eltChoisi = pListePere->IndexItemSelect();

    if (eltChoisi == -1)
    {
        erreur("Vous devez s�lectionner un �l�ment � d�placer.", standardError, 0) ;
        return;
    }

    if (eltChoisi == (nbPere - 1))
        return;

    NSElement* pElement = new NSElement(*((*pPereArray)[eltChoisi]));

    *((*pPereArray)[eltChoisi]) = *((*pPereArray)[eltChoisi + 1]);
    *((*pPereArray)[eltChoisi + 1]) = *pElement;

    AfficheListePere();
    pListePere->SetSel(eltChoisi + 1, true);
    delete pElement;
}

void
NSEditFilGuideDialog::CmHautPere()
{
    int eltChoisi = pListePere->IndexItemSelect();

    if (eltChoisi == -1)
    {
        erreur("Vous devez s�lectionner un �l�ment � d�placer.", standardError, 0) ;
        return;
    }

    if (eltChoisi == 0)
        return;

    NSElement* pElement = new NSElement(*((*pPereArray)[eltChoisi]));

    *((*pPereArray)[eltChoisi]) = *((*pPereArray)[eltChoisi - 1]);
    *((*pPereArray)[eltChoisi - 1]) = *pElement;

    AfficheListePere();
    pListePere->SetSel(eltChoisi - 1, true);
    delete pElement;
}

void
NSEditFilGuideDialog::CmInsPere()
{
    // Insertion en queue d'un nouvel �l�ment
    NSModifFilGuideDialog* pModDlg =
        new NSModifFilGuideDialog(this, "", pContexte, pNSResModule);

    if (pModDlg->Execute() == IDOK)
    {
        string sCode = pModDlg->sCode;
        string sLibelle;

        TrouveLibelle(sCode, sLibelle, true);

        pPereArray->push_back(new NSElement(sCode, sLibelle));
        nbPere++;
        AfficheListePere();
    }

    delete pModDlg;
}

void
NSEditFilGuideDialog::CmModPere()
{
    int eltChoisi = pListePere->IndexItemSelect();

    if (eltChoisi == -1)
    {
        erreur("Vous devez s�lectionner un �l�ment � modifier.", standardError, 0) ;
        return;
    }

    NSElement* pElement = new NSElement();
    *pElement = *((*pPereArray)[eltChoisi]);

    NSModifFilGuideDialog* pModDlg =
        new NSModifFilGuideDialog(this, pElement->code, pContexte, pNSResModule);

    if (pModDlg->Execute() == IDOK)
    {
        string sCode = pModDlg->sCode;
        string sLibelle;

        TrouveLibelle(sCode, sLibelle, true);

        pElement->code = sCode;
        pElement->libelle = sLibelle;
        *((*pPereArray)[eltChoisi]) = *pElement;
        AfficheListePere();
    }

    delete pModDlg;
    delete pElement;
}

void
NSEditFilGuideDialog::CmDelPere()
{
    NSEltIter i;
    int j;
    int eltChoisi = pListePere->IndexItemSelect();

    if (eltChoisi == -1)
    {
        erreur("Vous devez s�lectionner un �l�ment � d�truire.", standardError, 0) ;
        return;
    }

    for (i = pPereArray->begin(), j = 0; i != pPereArray->end(); i++, j++)
    {
        if (j == eltChoisi)
        {
            delete *i;
            pPereArray->erase(i);
            nbPere -= 1;
            break;
        }
    }

    AfficheListePere();
}

// ******************** Controles de la boite fils

void
NSEditFilGuideDialog::CmBasFils()
{
    int eltChoisi = pListeFils->IndexItemSelect();

    if (eltChoisi == -1)
    {
        erreur("Vous devez s�lectionner un �l�ment � d�placer.", standardError, 0) ;
        return;
    }

    if (eltChoisi == (nbFils - 1))
        return;

    NSElement* pElement = new NSElement(*((*pFilsArray)[eltChoisi]));

    *((*pFilsArray)[eltChoisi]) = *((*pFilsArray)[eltChoisi + 1]);
    *((*pFilsArray)[eltChoisi + 1]) = *pElement;

    AfficheListeFils();
    pListeFils->SetSel(eltChoisi + 1, true);
    delete pElement;
}

void
NSEditFilGuideDialog::CmHautFils()
{
    int eltChoisi = pListeFils->IndexItemSelect();

    if (eltChoisi == -1)
    {
        erreur("Vous devez s�lectionner un �l�ment � d�placer.", standardError, 0) ;
        return;
    }

    if (eltChoisi == 0)
        return;

    NSElement* pElement = new NSElement(*((*pFilsArray)[eltChoisi]));

    *((*pFilsArray)[eltChoisi]) = *((*pFilsArray)[eltChoisi - 1]);
    *((*pFilsArray)[eltChoisi - 1]) = *pElement;

    AfficheListeFils();
    pListeFils->SetSel(eltChoisi - 1, true);
    delete pElement;
}

void
NSEditFilGuideDialog::CmInsFils()
{
    // Insertion en queue d'un nouvel �l�ment
    NSModifFilGuideDialog* pModDlg =
        new NSModifFilGuideDialog(this, "", pContexte, pNSResModule, false);

    if (pModDlg->Execute() == IDOK)
    {
        string sCode = pModDlg->sCode;
        string sLibelle;

        TrouveLibelle(sCode, sLibelle, false);

        pFilsArray->push_back(new NSElement(sCode, sLibelle));
        nbFils++;
        AfficheListeFils();
    }

    delete pModDlg;
}

void
NSEditFilGuideDialog::CmModFils()
{
    int eltChoisi = pListeFils->IndexItemSelect();

    if (eltChoisi == -1)
    {
        erreur("Vous devez s�lectionner un �l�ment � modifier.", standardError, 0) ;
        return;
    }

    NSElement* pElement = new NSElement();
    *pElement = *((*pFilsArray)[eltChoisi]);

    NSModifFilGuideDialog* pModDlg =
        new NSModifFilGuideDialog(this, pElement->code, pContexte, pNSResModule, false);

    if (pModDlg->Execute() == IDOK)
    {
        string sCode = pModDlg->sCode;
        string sLibelle;

        TrouveLibelle(sCode, sLibelle, false);

        pElement->code = sCode;
        pElement->libelle = sLibelle;
        *((*pFilsArray)[eltChoisi]) = *pElement;
        AfficheListeFils();
    }

    delete pModDlg;
    delete pElement;
}

void
NSEditFilGuideDialog::CmDelFils()
{
    NSEltIter i;
    int j;
    int eltChoisi = pListeFils->IndexItemSelect();

    if (eltChoisi == -1)
    {
        erreur("Vous devez s�lectionner un �l�ment � d�truire.", standardError, 0) ;
        return;
    }

    for (i = pFilsArray->begin(), j = 0; i != pFilsArray->end(); i++, j++)
    {
        if (j == eltChoisi)
        {
            delete *i;
            pFilsArray->erase(i);
            nbFils -= 1;
            break;
        }
    }

    AfficheListeFils();
}

void
NSEditFilGuideDialog::ChoixGroupe()
{
    if (!bChoixGroupe)
    {
        string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
        MessageBox("Le groupe n'est pas modifiable.", sCaption.c_str(), MB_OK);
        return;
    }

    // Choix du groupe o� placer ce fil guide (en mode utilOnly)
    NSChoixGdDialog* pChoixGdDlg = new NSChoixGdDialog(this, pContexte, true);

    if (pChoixGdDlg->Execute() == IDOK)
    {
        int index = pChoixGdDlg->GroupChoisi;
        if (index == -1)
        {
            delete pChoixGdDlg;
            return;
        }

        NSGroupGdInfo* pGroupeChoisi = (*(pChoixGdDlg->pGroupArray))[index];
        sCodeGroupe = string(pGroupeChoisi->pDonnees->groupe);
        AfficheNomGroupe();
    }

    delete pChoixGdDlg;
}

void
NSEditFilGuideDialog::AfficheNomGroupe()
{
  if (sCodeGroupe == "")
    return ;

  // on v�rifie l'existence du code groupe dans la base.
  // s'il existe, on affiche son nom sur le bouton de choix
  NSGroupGd* pGroup = new NSGroupGd(pContexte) ;
  pGroup->lastError = pGroup->open() ;
  if (pGroup->lastError != DBIERR_NONE)
  {
    erreur("Impossible d'ouvrir la base GroupGd.db", standardError, pGroup->lastError) ;
    delete pGroup ;
    return ;
  }

  pGroup->lastError = pGroup->chercheClef(&sCodeGroupe, "", 0, keySEARCHEQ, dbiWRITELOCK) ;
  if ((pGroup->lastError != DBIERR_NONE) && (pGroup->lastError != DBIERR_RECNOTFOUND))
  {
    erreur("Erreur � la recherche dans la base GroupGd.db", standardError, pGroup->lastError) ;
    pGroup->close() ;
    delete pGroup ;
    return ;
  }
  else if (pGroup->lastError == DBIERR_NONE)  // cas o� le code existe
  {
    pGroup->lastError = pGroup->getRecord() ;
    if (pGroup->lastError != DBIERR_NONE)
    {
      erreur("Erreur � la lecture dans la base GroupGd.db", standardError, pGroup->lastError) ;
      pGroup->close() ;
      delete pGroup ;
      return ;
    }

    pEditGroupe->SetText(pGroup->pDonnees->libelle) ;
  }
  else // le code n'existe pas
  {
    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    MessageBox("Code groupe incorrect. Vous devez choisir un autre groupe.", sCaption.c_str(), MB_OK) ;
    sCodeGroupe = "" ;
  }

  // on ferme la base
  pGroup->lastError = pGroup->close() ;
  if (pGroup->lastError != DBIERR_NONE)
    erreur("Erreur � la fermeture dans la base GroupGd.db", standardError, pGroup->lastError) ;

  delete pGroup ;
}


void
NSEditFilGuideDialog::CmOk()
{
  string sBoutChemin ;
  string sCodeCompose ;
  string sCodeLexique ;
  string sCodeUtile ;
  string sCode ;
  size_t pos1, pos2 ;
  bool bContinue ;
  string sFils = "" ;
  NSSuper* pSuper = pContexte->getSuperviseur() ;

  if (sCodeGroupe == "")
  {
    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    MessageBox("Vous devez choisir un groupe pour pouvoir enregistrer votre fil guide.", sCaption.c_str(), MB_OK) ;
    return ;
  }

  // On constitue la string sChemin � partir de l'array P�re
  for (NSEltIter i = pPereArray->begin() ; i != pPereArray->end() ; i++)
  {
    sCodeCompose = (*i)->code ;

    sBoutChemin = "" ;
    bContinue = true ;
    pos1 = 0 ;
    pos2 = sCodeCompose.find('/') ;

    while (bContinue)
    {
      if (pos2 != string::npos)
        sCodeLexique = string(sCodeCompose, pos1, pos2 - pos1) ;
      else
        sCodeLexique = string(sCodeCompose, pos1, strlen(sCodeCompose.c_str()) - pos1) ;

      pSuper->getDico()->donneCodeSens(&sCodeLexique, &sCodeUtile) ;
      if (sBoutChemin != "")
        sBoutChemin += "/" ;
      sBoutChemin += sCodeUtile ;

      // condition d'arret : on traite aussi le cas du '/' � la fin du chemin
      if ((pos2 == string::npos) || (pos2 == (strlen(sCodeCompose.c_str()) - 1)))
      {
        bContinue = false ;
      }
      else
      {
        pos1 = pos2 + 1 ;
        pos2 = sCodeCompose.find('/', pos1) ;
      }
    }

    if (sCheminPere != "")
      sCheminPere += "/" ;
    sCheminPere += sBoutChemin ;
  }

  // On constitue la string sFils � partir de l'array Fils
  for (NSEltIter i = pFilsArray->begin() ; i != pFilsArray->end() ; i++)
  {
    if (sFils != "")
    	sFils += "|" ;
    sFils += (*i)->code ;
  }

  //
  // Cr�ation d'un BBFiche
  //
  BBFiche* pBBFiche = new BBFiche(pContexte) ;
  pBBFiche->lastError = pBBFiche->open() ;
  if (pBBFiche->lastError != DBIERR_NONE)
  {
    erreur("Il est impossible d'ouvrir le fichier des Guides.", standardError, pBBFiche->lastError) ;
    delete pBBFiche ;
    return ;
  }

  if (sCodeFilGuide != "")
  {
    // cas de la modification
    sCode = sCodeGroupe + sCodeFilGuide ;
    pBBFiche->lastError = pBBFiche->chercheClef(&sCode, "", 0, keySEARCHEQ, dbiWRITELOCK) ;
    if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_RECNOTFOUND))
    {
      erreur("Erreur � la recherche dans le fichier des Guides.", standardError, pBBFiche->lastError) ;
      pBBFiche->close() ;
      delete pBBFiche ;
      return ;
    }
    else if (pBBFiche->lastError == DBIERR_RECNOTFOUND)
    {
      erreur("Le fil guide � modifier n'existe pas dans la base des guides.", standardError, pBBFiche->lastError);
      pBBFiche->close();
      delete pBBFiche;
      return;
    }

    pBBFiche->lastError = pBBFiche->getRecord();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
      erreur("Erreur � la lecture d'une fiche Guides.", standardError, pBBFiche->lastError) ;
      pBBFiche->close();
      delete pBBFiche;
      return;
    }

        // on caste � cause de la structure de BBFiche (voir nsguide.cpp)
        char far commentaire[BB_COMMENTAIRE_LEN + 1];
        pEditComment->GetText(commentaire, BB_COMMENTAIRE_LEN + 1);

        strcpy((static_cast<BBItemData*>(pBBFiche->pDonnees))->chemin, sCheminPere.c_str());
        strcpy((static_cast<BBItemData*>(pBBFiche->pDonnees))->commentaire, commentaire);
        strcpy((static_cast<BBItemData*>(pBBFiche->pDonnees))->fils, sFils.c_str());

        pBBFiche->lastError = pBBFiche->modifyRecord(TRUE);
        if (pBBFiche->lastError != DBIERR_NONE)
        {
            erreur("Erreur � la modification du fil guide.", standardError, pBBFiche->lastError) ;
            pBBFiche->close();
            delete pBBFiche;
            return;
        }
    }
    else
    {
        // cas de la cr�ation d'un nouveau fil guide
        // on cherche d'abord s'il existe des fils guide utilisateur
        // appartenant au m�me groupe
        string sCodePrecedent = "000000";
        string sCompteur;

        sCode = sCodeGroupe + string(CH_CODE_LEN, ' ');
        pBBFiche->lastError = pBBFiche->chercheClef(&sCode,
                                                "",
                                                0,
                                                keySEARCHGEQ,
                                                dbiWRITELOCK);

        if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_EOF))
        {
            erreur("Erreur � la recherche dans le fichier des Guides.", standardError, pBBFiche->lastError) ;
            pBBFiche->close();
            delete pBBFiche;
            return;
        }

        // on cherche le dernier fil guide du groupe pour incr�menter le code
        while (pBBFiche->lastError != DBIERR_EOF)
        {
            pBBFiche->lastError = pBBFiche->getRecord();
            if (pBBFiche->lastError != DBIERR_NONE)
            {
                erreur("Erreur � la lecture d'une fiche Guides.", standardError, pBBFiche->lastError) ;
                pBBFiche->close();
                delete pBBFiche;
                return;
            }

            // Condition d'arret
            if (!(sCodeGroupe == string(pBBFiche->pDonnees->auteur)))
                break;

            sCodePrecedent = string(pBBFiche->pDonnees->code);

            pBBFiche->lastError = pBBFiche->suivant(dbiWRITELOCK);
            if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_EOF))
            {
                erreur("Erreur d'acc�s � la fiche Guides suivante.", standardError, pBBFiche->lastError) ;
                pBBFiche->close();
                delete pBBFiche;
                return;
            }
        } // fin du while

        sCompteur = sCodePrecedent;
        if (!(pBBFiche->IncrementeCode(&sCompteur)))
        {
            erreur("Erreur � l'attribution du code pour le nouveau fil guide.", standardError, 0) ;
            pBBFiche->close();
            delete pBBFiche;
            return;
        }

        sCodeFilGuide = sCompteur;

        // on copie les valeurs dans le nouveau fil guide
        // on caste � cause de la structure de BBFiche (voir nsguide.cpp)
        char far commentaire[BB_COMMENTAIRE_LEN + 1];
        pEditComment->GetText(commentaire, BB_COMMENTAIRE_LEN + 1);
        (static_cast<BBItemData*>(pBBFiche->pDonnees))->metAZero();
        strcpy((static_cast<BBItemData*>(pBBFiche->pDonnees))->code, sCodeFilGuide.c_str());
        strcpy((static_cast<BBItemData*>(pBBFiche->pDonnees))->auteur, sCodeGroupe.c_str());
        strcpy((static_cast<BBItemData*>(pBBFiche->pDonnees))->chemin, sCheminPere.c_str());
        strcpy((static_cast<BBItemData*>(pBBFiche->pDonnees))->commentaire, commentaire);
        strcpy((static_cast<BBItemData*>(pBBFiche->pDonnees))->ouvreDialogue, "N");
        strcpy((static_cast<BBItemData*>(pBBFiche->pDonnees))->decalageNiveau, "+01+01");
        strcpy((static_cast<BBItemData*>(pBBFiche->pDonnees))->fils, sFils.c_str());

        pBBFiche->lastError = pBBFiche->appendRecord();
        if (pBBFiche->lastError != DBIERR_NONE)
        {
            erreur("Erreur � l'ajout du nouveau fil guide.", standardError, pBBFiche->lastError) ;
            pBBFiche->close();
            delete pBBFiche;
            return;
        }
    } // fin du else (cr�ation)

	pBBFiche->lastError = pBBFiche->close() ;
	if (pBBFiche->lastError != DBIERR_NONE)
		erreur("Erreur de fermeture de la base des Guides.", standardError, pBBFiche->lastError) ;

	delete pBBFiche ;

  TDialog::CmOk() ;
}

void
NSEditFilGuideDialog::CmCancel()
{
	TDialog::CmCancel() ;
}


/*****************************************************************************/
/***                    GESTION DES FICHIERS DE FILS GUIDES                ***/
/*****************************************************************************/

NSGuidesManager::NSGuidesManager(NSContexte* pCtx)                :NSRoot(pCtx){	sFile = string("") ;	init() ;}
NSGuidesManager::~NSGuidesManager()
{
}

void
NSGuidesManager::setImportFile(string sNewFile)
{
	sFile = sNewFile ;
	init() ;
}

void
NSGuidesManager::init()
{
	bValidHeader = false ;

	sFileVersion = string("") ;
	sGroup       = string("") ;
	sLabel       = string("") ;
	sGroupDate   = string("") ;
	sUser        = string("") ;

	if (string("") != sFile)
		readHeader() ;
}

bool
NSGuidesManager::doesGroupExist(string sCode, bool& bError, string& sDate)
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

  NSGroupGd Group(pContexte) ;
  Group.lastError = Group.open() ;
  if (Group.lastError != DBIERR_NONE)
  {
  	string sErrLabel = pSuper->getText("filsGuidesManagement", "cannotOpenFilsGuidesGroupsTable") ;
    erreur(sErrLabel.c_str(), standardError, Group.lastError) ;
    bError = true ;
    return false ;
  }

  Group.lastError = Group.chercheClef(&sCode, "", 0, keySEARCHEQ, dbiWRITELOCK) ;  if ((Group.lastError != DBIERR_NONE) && (Group.lastError != DBIERR_RECNOTFOUND))
  {
  	string sErrLabel = pSuper->getText("filsGuidesManagement", "searchErrorInGuidesGroupsTable") ;
    erreur(sErrLabel.c_str(), standardError, Group.lastError) ;
    Group.close() ;
    bError = true ;
    return false ;
  }
  else if (Group.lastError == DBIERR_NONE)  // cas o� le code existe
  {
    Group.lastError = Group.getRecord() ;
    if (Group.lastError != DBIERR_NONE)
    {
    	string sErrLabel = pSuper->getText("filsGuidesManagement", "readErrorInGuidesGroupsTable") ;
    	erreur(sErrLabel.c_str(), standardError, Group.lastError) ;
      Group.close() ;
      bError = true ;
      return true ;
    }

    string sLang = "" ;
		if (pContexte->getUtilisateur())
			sLang = pContexte->getUtilisateur()->donneLang() ;

		char dateGroupe[11] ;
    donne_date(Group.pDonnees->date, dateGroupe, sLang) ;
    sDate = string(dateGroupe) ;
  }
  else // le code n'existe pas
  {
    sDate = "" ;
    Group.lastError = Group.close() ;
    bError = false ;
    return false ;
  }

  // on ferme la base
  Group.lastError = Group.close() ;
  bError = false ;
  return true ;
}

//---------------------------------------------------------------------------
//  Description: Remove the group from Fils Guides groups' file
//               Remove all Fils Guides from the table
//               Returns false in case of database error
//---------------------------------------------------------------------------
bool
NSGuidesManager::deleteGroup(string sGroupName)
{
	bool bSuccess = deleteGuidesFromGroup(sGroupName) ;
  if (true == bSuccess)
  	bSuccess == unreferenceGroup(sGroupName) ;

	return bSuccess ;
}

bool
NSGuidesManager::deleteGuidesFromGroup(string sGroupName)
{
	if (string("") == sGroupName)
		return false ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;

  //
  // Cr�ation d'un BBFiche
  //
  BBFiche Fiche(pContexte) ;
  Fiche.lastError = Fiche.open() ;
  if (Fiche.lastError != DBIERR_NONE)
  {
		string sErrLabel = pSuper->getText("filsGuidesManagement", "cannotOpenFilsGuidesTable") ;
		erreur(sErrLabel.c_str(), standardError, Fiche.lastError) ;
    return false ;
  }

  // Looking for Fils Guides of this group to delete them  //  string sCodeFG = sGroupName + string(CH_CODE_LEN, ' ') ;
	Fiche.lastError = Fiche.chercheClef(&sCodeFG,
                                      "",
                                      0,
                                      keySEARCHGEQ,
                                      dbiWRITELOCK) ;

  if ((Fiche.lastError != DBIERR_NONE) && (Fiche.lastError != DBIERR_EOF))
  {
  	string sErrLabel = pSuper->getText("filsGuidesManagement", "searchErrorInGuidesTable") ;
		erreur(sErrLabel.c_str(), standardError, Fiche.lastError) ;
    Fiche.close() ;
		return false ;
  }

  // on boucle pour d�truire tous les fils guides de type sCode
  while (Fiche.lastError != DBIERR_EOF)
  {
  	Fiche.lastError = Fiche.getRecord() ;
    if (Fiche.lastError != DBIERR_NONE)
    {
    	string sErrLabel = pSuper->getText("filsGuidesManagement", "readErrorInGuidesTable") ;
			erreur(sErrLabel.c_str(), standardError, Fiche.lastError) ;
      Fiche.close() ;
      return false ;
    }

    // Condition d'arret
    if (Fiche.pDonnees->getGroupID() != sGroupName)
    	break ;


    Fiche.lastError = Fiche.deleteRecord() ;    if (Fiche.lastError != DBIERR_NONE)    {
    	string sErrLabel = pSuper->getText("filsGuidesManagement", "deleteErrorInGuidesTable") ;
			erreur(sErrLabel.c_str(), standardError, Fiche.lastError) ;
      Fiche.close() ;
      return false ;
    }

    Fiche.lastError = Fiche.suivant(dbiWRITELOCK);
    if ((Fiche.lastError != DBIERR_NONE) && (Fiche.lastError != DBIERR_EOF))
    {
    	string sErrLabel = pSuper->getText("filsGuidesManagement", "errorAccessingNextGuideInTable") ;
			erreur(sErrLabel.c_str(), standardError, Fiche.lastError) ;
      Fiche.close() ;
      return false ;
    }
	}

	Fiche.lastError = Fiche.close() ;

	return true ;
}

bool
NSGuidesManager::unreferenceGroup(string sGroupName)
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	NSGroupGd Group(pContexte) ;
	Group.lastError = Group.open() ;
	if (Group.lastError != DBIERR_NONE)
	{
		string sErrLabel = pSuper->getText("filsGuidesManagement", "cannotOpenFilsGuidesGroupsTable") ;
    erreur(sErrLabel.c_str(), standardError, Group.lastError) ;
    return false ;
	}

	Group.lastError = Group.chercheClef(&sGroupName,
                                      "",
                                      0,
                                      keySEARCHEQ,
                                      dbiWRITELOCK) ;

	if ((Group.lastError != DBIERR_NONE) && (Group.lastError != DBIERR_RECNOTFOUND))
	{
		string sErrLabel = pSuper->getText("filsGuidesManagement", "searchErrorInGuidesGroupsTable") ;
    erreur(sErrLabel.c_str(), standardError, Group.lastError) ;
    Group.close() ;
    return false ;
	}
	else if (Group.lastError == DBIERR_NONE)  // cas o� le code existe
  {
		Group.lastError = Group.deleteRecord() ;
    if (Group.lastError != DBIERR_NONE)
    {
    	string sErrLabel = pSuper->getText("filsGuidesManagement", "deleteErrorInGuidesGroupsTable") ;
    	erreur(sErrLabel.c_str(), standardError, Group.lastError) ;
      Group.close() ;
      return false ;
    }
  }
  else // le code n'existe pas
  {
		string sErrLabel = pSuper->getText("filsGuidesManagement", "thisGroupDoesNotExistInGroupsTable") ;
    erreur(sErrLabel.c_str(), standardError, 0) ;
	}

	// on ferme la base
	Group.lastError = Group.close() ;

	return true ;
}


bool
NSGuidesManager::readHeader()
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	ifstream inFile;
	inFile.open(sFile.c_str()) ;
	if (!inFile)
  {
  	string sErrLabel = pSuper->getText("fileErrors", "errorOpeningInputFile") ;
    sErrLabel += string(" (") + sFile + string(")") ;
  	erreur(sErrLabel.c_str(), standardError, 0) ;
    return false ;
  }

	string sParam[6] = {"","","","","",""} ;

  // on r�cup�re le header du fichier groupe
  if (!inFile.eof())
	{
		string sHeader ;
		getline(inFile, sHeader) ;

		if (string("") != sHeader)
  	{
			size_t i = 0, k = 0 ;

			while (i < strlen(sHeader.c_str()))
			{
				if ('\"' == sHeader[i])
					k++ ;
				else
				{
    			if (k < 6)
      			sParam[k] += sHeader[i] ;
      		else
      			break ;      	}

      	i++ ;
    	}
      if (5 == k)
				bValidHeader = true ;
  	}
  }
  inFile.close() ;

	if (false == bValidHeader)
	{
  	string sErrLabel = pSuper->getText("fileErrors", "corruptedFile") ;
    sErrLabel += string(" (") + sFile + string(")") ;
  	erreur(sErrLabel.c_str(), standardError, 0) ;
    return false ;
	}

	sFileVersion = sParam[0] ;
	sGroup       = sParam[2] ;
	sLabel       = sParam[3] ;
	sGroupDate   = sParam[4] ;
	sUser        = sParam[5] ;

	return true ;
}

bool
NSGuidesManager::importGroup(string sFileCompletePath)
{
	if (string("") != sFileCompletePath)
		setImportFile(sFileCompletePath) ;

	if ((string("") == sFile) || (false == bValidHeader))
		return false ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	ifstream inFile;
	inFile.open(sFile.c_str()) ;
	if (!inFile)
  {
  	string sErrLabel = pSuper->getText("fileErrors", "errorOpeningInputFile") ;
    sErrLabel += string(" (") + sFile + string(")") ;
  	erreur(sErrLabel.c_str(), standardError, 0) ;
    return false ;
  }
  if (inFile.eof())
  {
  	inFile.close() ;
		return false ;
	}

	// Skip header
	//
	string sHeader ;
	getline(inFile, sHeader) ;

  if (inFile.eof())
	{
		inFile.close() ;
		return false ;
	}

	//	// Create records in Fils Guides table
	//
	BBFiche Fiche(pContexte) ;
	Fiche.lastError = Fiche.open() ;

	if (Fiche.lastError != DBIERR_NONE)	{
  	string sErrLabel = pSuper->getText("filsGuidesManagement", "cannotOpenFilsGuidesTable") ;
		erreur(sErrLabel.c_str(), standardError, Fiche.lastError) ;
		inFile.close() ;
		return false ;
	}

	string sData, sLine ;
  string sParam[18] ;

	while (!inFile.eof())	{
		getline(inFile, sLine) ;
		if (string("") != sLine)
		{
			for (int i = 0 ; i < 18 ; i++)
				sParam[i] = string("") ;

      size_t i = 0, k = 0 ;
      while (i < strlen(sLine.c_str()))
      {
        if ('\"' == sLine[i])
          k++ ;
        else
        {
          if (k < 18)
            sParam[k] += sLine[i] ;
          else
            break ;        }

        i++ ;
      }

      if (18 == k)
			{
				(static_cast<BBItemData*>(Fiche.pDonnees))->metAZero() ;

				strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->code,            sParam[0].c_str()) ;				strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->auteur,          sParam[1].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->chemin,          sParam[2].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->commentaire,     sParam[3].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->fichierDialogue, sParam[4].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->nomDialogue,     sParam[5].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->ouvreDialogue,   sParam[6].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->fichierFonction, sParam[7].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->nomFonction,     sParam[8].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->decalageNiveau,  sParam[9].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->fils,            sParam[10].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->exclusion,       sParam[11].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->automatique,     sParam[12].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->actif_vide,      sParam[13].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->unicite_lesion,  sParam[14].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->impose,          sParam[15].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->tri,             sParam[16].c_str()) ;
        strcpy((static_cast<BBItemData*>(Fiche.pDonnees))->scenario,        sParam[17].c_str()) ;

        Fiche.lastError = Fiche.appendRecord() ;

				if (Fiche.lastError != DBIERR_NONE)				{
        	string sErrLabel = pSuper->getText("filsGuidesManagement", "addErrorInGuidesTable") ;
					erreur(sErrLabel.c_str(), standardError, Fiche.lastError) ;
					Fiche.close() ;
          inFile.close() ;
          return false ;
				}
			}
		}
	}

	inFile.close() ;

	Fiche.lastError = Fiche.close() ;  return true ;}

bool
NSGuidesManager::referenceGroup()
{
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	NSGroupGd Group(pContexte) ;

	Group.lastError = Group.open() ;	if (Group.lastError != DBIERR_NONE)
	{
  	string sErrLabel = pSuper->getText("filsGuidesManagement", "cannotOpenFilsGuidesGroupsTable") ;
    erreur(sErrLabel.c_str(), standardError, Group.lastError) ;
    return false ;
	}

	strcpy(Group.pDonnees->groupe,  sGroup.c_str()) ;	strcpy(Group.pDonnees->libelle, sLabel.c_str()) ;
	strcpy(Group.pDonnees->date,    sGroupDate.c_str()) ;
	strcpy(Group.pDonnees->util,    sUser.c_str()) ;

	Group.lastError = Group.appendRecord() ;	if (Group.lastError != DBIERR_NONE)
	{
  	string sErrLabel = pSuper->getText("filsGuidesManagement", "addErrorInGuidesGroupsTable") ;
    erreur(sErrLabel.c_str(), standardError, Group.lastError) ;
    Group.close() ;
    return false ;
	}

	Group.lastError = Group.close() ;  	return true ;
}
/***************************************************************************************//***                        GESTION DES GROUPES DE FILS GUIDES                       ***/
/***************************************************************************************/

DEFINE_RESPONSE_TABLE1(NSGroupGdDialog, NSUtilDialog)
	EV_CHILD_NOTIFY(IDC_GROUPGD_IMPORT, BN_CLICKED, CmImport),
	EV_CHILD_NOTIFY(IDC_GROUPGD_EXPORT, BN_CLICKED, CmExport),
	EV_CHILD_NOTIFY(IDC_GROUPGD_DESTROY, BN_CLICKED, CmDestroy),
	EV_CHILD_NOTIFY(IDC_GROUPGD_LISTFG, BN_CLICKED, CmGestion),
	EV_COMMAND(IDOK, CmOk),
	EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

//---------------------------------------------------------------------------//  Constructeur
//---------------------------------------------------------------------------
NSGroupGdDialog::NSGroupGdDialog(TWindow* pere, NSContexte* pCtx)
				  :NSUtilDialog(pere, pCtx, "IDD_GROUPGD", pNSResModule)
{
	pImport  = new TButton(this, IDC_GROUPGD_IMPORT) ;
	pExport  = new TButton(this, IDC_GROUPGD_EXPORT) ;
	pDestroy = new TButton(this, IDC_GROUPGD_DESTROY) ;
	pGestion = new TButton(this, IDC_GROUPGD_LISTFG) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSGroupGdDialog::~NSGroupGdDialog()
{
	//
	// Suppression de tous les objets
	//
	delete pImport ;
	delete pExport ;
	delete pDestroy ;
	delete pGestion ;
}

//---------------------------------------------------------------------------//  Fonction :   NSGroupGdDialog::SetupWindow()
//
//  Description: Initialise la boite de dialogue
//---------------------------------------------------------------------------
void
NSGroupGdDialog::SetupWindow()
{
	// fichiers d'aide
	sHindex = "" ;
	sHcorps = "Fils_guides.html" ;
	NSUtilDialog::SetupWindow() ; 
}

// -----------------------------------------------------------------------------
// Fonction    : NSGroupGdDialog::ExisteCode(string sCode, bool& bExiste, string& sDate)
// Description : V�rifie l'existence d'un code dans la base des groupes
//               Si le code existe, renvoie la date associ�e
//               Retourne false en cas d'erreur de base, true sinon
//---------------------------------------------------------------------------
bool
NSGroupGdDialog::ExisteCode(string sCode, bool& bExiste, string& sDate)
{
  char dateGroupe[11] ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  NSGroupGd Group(pContexte) ;
  Group.lastError = Group.open() ;
  if (Group.lastError != DBIERR_NONE)
  {
   	erreur("Impossible d'ouvrir la base GroupGd.db", standardError, Group.lastError) ;
    return false ;
  }

  Group.lastError = Group.chercheClef(&sCode, "", 0, keySEARCHEQ, dbiWRITELOCK) ;  if ((Group.lastError != DBIERR_NONE) && (Group.lastError != DBIERR_RECNOTFOUND))
  {
    erreur("Erreur � la recherche dans la base GroupGd.db", standardError, Group.lastError) ;
    Group.close() ;
    return false ;
  }
  if (Group.lastError == DBIERR_NONE)  // cas o� le code existe
  {
    Group.lastError = Group.getRecord() ;
    if (Group.lastError != DBIERR_NONE)
    {
      erreur("Erreur � la lecture dans la base GroupGd.db", standardError, Group.lastError) ;
      Group.close() ;
      return false ;
    }

    donne_date(Group.pDonnees->date, dateGroupe, sLang) ;
    sDate = string(dateGroupe) ;
    bExiste = true ;
  }
  else // le code n'existe pas
  {
    sDate = "" ;
    bExiste = false ;
  }

  // on ferme la base
  Group.lastError = Group.close() ;
  if (Group.lastError != DBIERR_NONE)
    erreur("Erreur � la fermeture dans la base GroupGd.db", standardError, Group.lastError) ;

  return true ;
}


//---------------------------------------------------------------------------
//  Fonction :   NSGroupGdDialog::ExisteLibelle(string sLibelle, bool& bExiste, string& sDate)
//
//  Description: V�rifie l'existence d'un libelle dans la base des groupes
//               Si le libelle existe, renvoie la date associ�e
//               Retourne false en cas d'erreur de base, true sinon
//---------------------------------------------------------------------------
bool
NSGroupGdDialog::ExisteLibelle(string sLibelle, bool& bExiste, string& sDate)
{
	char libelle1[80], libelle2[80] ;
  char dateGroupe[11] ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  strcpy(libelle1, sLibelle.c_str()) ;
  ote_blancs(libelle1) ;
  pseumaj(libelle1) ;
  bExiste = false ;

  NSGroupGd Group(pContexte) ;
  Group.lastError = Group.open() ;
  if (Group.lastError != DBIERR_NONE)
  {
  	erreur("Impossible d'ouvrir la base GroupGd.db", standardError, Group.lastError) ;
    return false ;
  }

	Group.lastError = Group.debut(dbiWRITELOCK) ;
  if ((Group.lastError != DBIERR_NONE) && (Group.lastError != DBIERR_BOF))
	{
		erreur("Erreur de positionnement dans la base GroupGd.db", standardError, Group.lastError) ;
		Group.close() ;
		return false ;
	}

	if (Group.lastError == DBIERR_BOF)
	{
  	// cas de la base vide : on renvoie true en laissant bExiste � false
    Group.close() ;
		return true ;
  }

	do
	{
  	Group.lastError = Group.getRecord() ;
		if (Group.lastError != DBIERR_NONE)
		{
			erreur("Erreur de lecture dans la base GroupGd.db", standardError, Group.lastError) ;
			Group.close() ;
			return false ;
		}

    strcpy(libelle2, Group.pDonnees->libelle) ;
    ote_blancs(libelle2) ;
    pseumaj(libelle2) ;

    // Si le libelle existe
    if (!strcmp(libelle1, libelle2))
    {
    	donne_date(Group.pDonnees->date, dateGroupe, sLang) ;
      sDate = string(dateGroupe) ;
      bExiste = true ;
      break ;
    }
    // on se positionne sur le groupe suivant
    Group.lastError = Group.suivant(dbiWRITELOCK) ;
		if ((Group.lastError != DBIERR_NONE) && (Group.lastError != DBIERR_EOF))
    {
    	erreur("Erreur d'acc�s � la fiche groupe suivante.", standardError, Group.lastError);
      Group.close() ;
			return false;
    }
  }
	while (Group.lastError != DBIERR_EOF);

	Group.lastError = Group.close() ;
  if (Group.lastError != DBIERR_NONE)
		erreur("Erreur de fermeture de la base GroupGd.db", standardError, Group.lastError) ;

	return true ;
}

//---------------------------------------------------------------------------//  Fonction :   NSGroupGdDialog::DetruireGroupe(string sCode)
//
//  Description: Enleve le groupe de code donn� de la base des groupes
//               et les fils guides li�s au groupe de GUIDE.Db
//               Retourne false en cas d'erreur de base, true sinon
//---------------------------------------------------------------------------
bool
NSGroupGdDialog::DetruireGroupe(string sCode)
{
  //
  // Cr�ation d'un BBFiche
  //
  BBFiche cBBFiche(pContexte) ;
  cBBFiche.lastError = cBBFiche.open() ;
  if (cBBFiche.lastError != DBIERR_NONE)
  {
    erreur("Il est impossible d'ouvrir le fichier des Guides.", standardError, cBBFiche.lastError) ;
    return false ;
  }

  // On cherche les fils guides de groupe sCode  // pour pouvoir les supprimer  string sCodeFG = sCode + string(CH_CODE_LEN, ' ') ;
  cBBFiche.lastError = cBBFiche.chercheClef(&sCodeFG,
                                      "",
                                      0,
                                      keySEARCHGEQ,
                                      dbiWRITELOCK) ;

  if ((cBBFiche.lastError != DBIERR_NONE) && (cBBFiche.lastError != DBIERR_EOF))
  {
    erreur("Erreur � la recherche dans le fichier des Guides.", standardError, cBBFiche.lastError) ;
    cBBFiche.close() ;
    return false ;
  }

  // on boucle pour d�truire tous les fils guides de type sCode
  while (cBBFiche.lastError != DBIERR_EOF)
  {
    cBBFiche.lastError = cBBFiche.getRecord() ;
    if (cBBFiche.lastError != DBIERR_NONE)
    {
      erreur("Erreur � la lecture d'une fiche Guides.", standardError, cBBFiche.lastError) ;
      cBBFiche.close() ;
      return false ;
    }

    // Condition d'arret
    if (strcmp(cBBFiche.pDonnees->auteur, sCode.c_str()))
      break ;


    cBBFiche.lastError = cBBFiche.deleteRecord() ;    if (cBBFiche.lastError != DBIERR_NONE)    {
      erreur("Erreur � la destruction d'une fiche Guides.", standardError, cBBFiche.lastError) ;
      cBBFiche.close() ;
      return false ;
    }

    cBBFiche.lastError = cBBFiche.suivant(dbiWRITELOCK) ;
    if ((cBBFiche.lastError != DBIERR_NONE) && (cBBFiche.lastError != DBIERR_EOF))
    {
      erreur("Erreur d'acc�s � la fiche Guides suivante.", standardError, cBBFiche.lastError) ;
      cBBFiche.close() ;
      return false ;
    }
  }

  cBBFiche.lastError = cBBFiche.close() ;
  if (cBBFiche.lastError != DBIERR_NONE)
    erreur("Erreur de fermeture de la base des Guides.", standardError, cBBFiche.lastError) ;

  // on enl�ve maintenant le groupe associ� de la base des groupes
  NSGroupGd Group(pContexte) ;
  Group.lastError = Group.open() ;
  if (Group.lastError != DBIERR_NONE)
  {
    erreur("Impossible d'ouvrir la base GroupGd.db", standardError, Group.lastError) ;
    return false ;
  }

  Group.lastError = Group.chercheClef(&sCode,
                                      "",
                                      0,
                                      keySEARCHEQ,
                                      dbiWRITELOCK) ;

  if ((Group.lastError != DBIERR_NONE) && (Group.lastError != DBIERR_RECNOTFOUND))
  {
    erreur("Erreur � la recherche dans la base GroupGd.db", standardError, Group.lastError) ;
    Group.close() ;
    return false ;
  }

  if (Group.lastError == DBIERR_NONE)  // cas o� le code existe
  {
    Group.lastError = Group.deleteRecord() ;
    if (Group.lastError != DBIERR_NONE)
    {
      erreur("Erreur � la suppression dans la base GroupGd.db", standardError, Group.lastError) ;
      Group.close() ;
      return false ;
    }
  }
  else // le code n'existe pas
    erreur("Le groupe comportant le code sp�cifi� n'existe pas dans GroupGd.db", standardError, 0) ;

  // on ferme la base
  Group.lastError = Group.close() ;
  if (Group.lastError != DBIERR_NONE)
    erreur("Erreur � la fermeture dans la base GroupGd.db", standardError, Group.lastError) ;

  return true ;
}


//---------------------------------------------------------------------------
//  Fonction :   NSGroupGdDialog::CodeDispo(string& sCode)
//
//  Description: Recherche le premier code disponible parmi
//               les fils guides utilisateurs
//               Retourne false en cas d'erreur de base, true sinon
//---------------------------------------------------------------------------
bool
NSGroupGdDialog::CodeDispo(string& sCode)
{
    string sCodePrec, sCodeSuiv = "001";

    // On doit d'abord se placer apr�s les groupes de
    // fils guides syst�me (en $XX)
    NSGroupGd* pGroup = new NSGroupGd(pContexte);
    pGroup->lastError = pGroup->open();
    if (pGroup->lastError != DBIERR_NONE)
    {
        erreur("Impossible d'ouvrir la base GroupGd.db", standardError, pGroup->lastError);
        delete pGroup;
        return false;
    }

    pGroup->lastError = pGroup->debut(dbiWRITELOCK);
   	if ((pGroup->lastError != DBIERR_NONE) && (pGroup->lastError != DBIERR_BOF))
	{
		erreur("Erreur de positionnement dans la base GroupGd.db", standardError, pGroup->lastError);
		pGroup->close();
		delete pGroup;
		return false;
	}

    if (pGroup->lastError == DBIERR_BOF)
    {
        // cas de la base vide
        sCode = sCodeSuiv;
        pGroup->close();
		delete pGroup;
		return true;
    }

   	do
   	{
   		pGroup->lastError = pGroup->getRecord();
		if (pGroup->lastError != DBIERR_NONE)
		{
			erreur("Erreur de lecture dans la base GroupGd.db", standardError, pGroup->lastError);
			pGroup->close();
			delete pGroup;
			return false;
		}

        // condition d'arret
        if (pGroup->pDonnees->groupe[0] != '$')
            break;

      	// on se positionne sur le groupe suivant
      	pGroup->lastError = pGroup->suivant(dbiWRITELOCK);
		if ((pGroup->lastError != DBIERR_NONE) && (pGroup->lastError != DBIERR_EOF))
      	{
			erreur("Erreur d'acc�s � la fiche groupe suivante.", standardError, pGroup->lastError);
         	pGroup->close();
			delete pGroup;
			return false;
      	}

    }
   	while (pGroup->lastError != DBIERR_EOF);

    // on boucle jusqu'� trouver le premier trou
    // dans les codes groupe utilisateur
    while (pGroup->lastError != DBIERR_EOF)
    {
        sCodePrec = string(pGroup->pDonnees->groupe);
        sCodeSuiv = sCodePrec;
        pGroup->IncrementeCode(&sCodeSuiv);

        // on se positionne sur le groupe suivant
      	pGroup->lastError = pGroup->suivant(dbiWRITELOCK);
		if ((pGroup->lastError != DBIERR_NONE) && (pGroup->lastError != DBIERR_EOF))
      	{
			erreur("Erreur d'acc�s � la fiche groupe suivante.", standardError, pGroup->lastError);
         	pGroup->close();
			delete pGroup;
			return false;
      	}

        if (pGroup->lastError != DBIERR_EOF)
        {
            pGroup->lastError = pGroup->getRecord();
		    if (pGroup->lastError != DBIERR_NONE)
		    {
			    erreur("Erreur de lecture dans la base GroupGd.db", standardError, pGroup->lastError);
			    pGroup->close();
			    delete pGroup;
			    return false;
		    }

            // condition d'arret : il existe un trou
            if (string(pGroup->pDonnees->groupe) > sCodeSuiv)
                break;
        }
    } // fin while

    // on renvoie le dernier code libre
    sCode = sCodeSuiv;

    // on ferme la base
    pGroup->lastError = pGroup->close();
    if (pGroup->lastError != DBIERR_NONE)
        erreur("Erreur � la fermeture dans la base GroupGd.db", standardError, pGroup->lastError);

    delete pGroup;
    return true;
}
voidNSGroupGdDialog::CmImport()
{
  char 	path[256];
  string  sGroupe;
  string  sLibelle;
  string  sDateGroupe, sDateBase;
  string  sUtil;
  ifstream inFile;
  string   header, line;
  string   sParam[6] = {"","","","","",""};
  bool     bInterne;

  // on choisi d'abord le r�pertoire par d�faut d'importation (IHTM)
  strcpy(path,(pContexte->PathName("IHTM")).c_str());

  TFileOpenDialog::TData initData(OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
                      "Tous fichiers (*.NSG)|*.nsg|",
                                          0,path,"NSG");

	int iUserChoice = TFileOpenDialog(pContexte->GetMainWindow(), initData).Execute() ;

	pContexte->reallocateBaseDirectory() ;

  if (IDOK != iUserChoice)
		return ;

  string sFileName = string(initData.FileName);

  inFile.open(sFileName.c_str());
	if (!inFile)
  {
  	erreur("Impossible d'ouvrir le fichier groupe � importer.", standardError, 0) ;
    return ;
  }

  // on r�cup�re le header du fichier groupe
  if (!inFile.eof())
  	getline(inFile, header) ;
  else
  {
  	erreur("Le fichier groupe est vide.", standardError, 0) ;
    inFile.close() ;
    return ;
  }

	if (header != "")
  {
  	size_t i = 0, k = 0 ;

    while (i < strlen(header.c_str()))
    {
    	if (header[i] == '\"')
      	k++ ;
      else
      {
      	if (k < 6)
        	sParam[k] += header[i] ;
        else
        {        	erreur("Le header du fichier groupe est incorrect.", standardError, 0) ;
          return ;
        }
      }

      i++ ;
    }
  }
  else
  {
  	erreur("Le header du fichier groupe est vide.", standardError, 0) ;
    inFile.close() ;
    return ;
  }

  sGroupe = sParam[2] ;
  sLibelle = sParam[3] ;
  sDateGroupe = sParam[4] ;
  sUtil = sParam[5] ;

  if ('$' != sGroupe[0])  {
    int retVal ;
    bool bExiste = false ;

    // On v�rifie s'il existe un groupe utilisateur de m�me nom    // Si c'est le cas, on interrompt l'importation.
    if (!ExisteLibelle(sLibelle, bExiste, sDateBase))
    {
      erreur("L'importation est interrompue.", standardError, 0) ;
      inFile.close() ;
      return ;
    }

    if (bExiste)
    {
      string sMsg = "Il existe d�j� un groupe de m�me libell�, dat� du " + sDateBase ;
      erreur(sMsg.c_str(), standardError, 0) ;
      inFile.close() ;
      return ;
    }

    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
    retVal = ::MessageBox(pContexte->GetMainWindow()->GetHandle(), "Ce groupe de fils guides a-t-il �t� cr�� sur votre site ?", sCaption.c_str(), MB_YESNO) ;
    if (retVal == IDYES)
      bInterne = true ;
    else
      bInterne = false ;

    if (false == CodeDispo(sGroupe))
    {
      erreur("Impossible de trouver un nouveau code pour le groupe � importer.", standardError, 0) ;
      inFile.close() ;
      return ;
    }
  }
  else
  {
    bool bExiste = false ;

    // On v�rifie s'il existe un groupe systeme de m�me code
    // Si c'est le cas, soit on le d�truit et on importe,
    // soit on interrompt l'importation.
    if (!ExisteCode(sGroupe, bExiste, sDateBase))
    {
      erreur("L'importation est interrompue.", standardError, 0) ;
      inFile.close() ;
      return ;
    }

    if (bExiste)
    {
      int retVal ;
      string sMsg = "Ce groupe syst�me existe d�j� � la date du " + sDateBase + ". Voulez-vous le remplacer ?" ;

      string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
      retVal = ::MessageBox(pContexte->GetMainWindow()->GetHandle(), sMsg.c_str(), sCaption.c_str(), MB_YESNO) ;
      if (retVal == IDYES)
      {
        if (!DetruireGroupe(sGroupe))
        {
          erreur("L'importation a �chou�.", standardError, 0) ;
          inFile.close() ;
          return ;
        }
      }
      else
        return ;
    }
    bInterne = false ;
  }

  // Controle de la version
  if (sParam[0] == "1.0")
  {
    string sData ;
    //
    // Cr�ation d'un BBFiche
    //
    BBFiche cBBFiche(pContexte) ;    cBBFiche.lastError = cBBFiche.open() ;
    if (cBBFiche.lastError != DBIERR_NONE)
    {
      erreur("Il est impossible d'ouvrir le fichier des Guides.", standardError, cBBFiche.lastError) ;
      inFile.close() ;
      return ;
    }

    while (!inFile.eof())
    {
      getline(inFile, line) ;
      if (string("") != line)
      {
        size_t pos1 = 0 ;
        (static_cast<BBItemData*>(cBBFiche.pDonnees))->metAZero() ;
        size_t pos2 = line.find_first_of('\"', pos1) ;
        sData = string(line, pos1, pos2 - pos1) ;
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->code, sData.c_str()) ;

        pos1 = pos2 + 1;        pos2 = line.find_first_of('\"', pos1);
        // on transmet ici le nouveau code groupe
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->auteur, sGroupe.c_str());

        pos1 = pos2 + 1;        pos2 = line.find_first_of('\"', pos1);        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->chemin, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->commentaire, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->fichierDialogue, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->nomDialogue, sData.c_str());
        pos1 = pos2 + 1;        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->ouvreDialogue, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->fichierFonction, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->nomFonction, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->decalageNiveau, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->fils, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->exclusion, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->automatique, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->actif_vide, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->unicite_lesion, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->impose, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->tri, sData.c_str());

        pos1 = pos2 + 1;
        pos2 = line.find_first_of('\"', pos1);
        sData = string(line, pos1, pos2 - pos1);
        strcpy((static_cast<BBItemData*>(cBBFiche.pDonnees))->scenario, sData.c_str());

        cBBFiche.lastError = cBBFiche.appendRecord() ;
        if (cBBFiche.lastError != DBIERR_NONE)
        {
          erreur("Erreur � l'ajout du nouveau fil guide.", standardError, cBBFiche.lastError) ;
          cBBFiche.close() ;
          inFile.close() ;
          return ;
        }
      }
    }

    cBBFiche.lastError = cBBFiche.close() ;
    if (cBBFiche.lastError != DBIERR_NONE)
      erreur("Erreur de fermeture de la base des Guides.", standardError, cBBFiche.lastError) ;
  }
  else
  {
    erreur("La version de ce groupe de fils guides n'est pas g�r�e.",standardError, 0) ;
    inFile.close() ;
    return;
  }

  inFile.close() ;

  // on ajoute maintenant le groupe associ� � la base des groupes
  NSGroupGd Group(pContexte) ;
  Group.lastError = Group.open() ;
  if (Group.lastError != DBIERR_NONE)
  {
    erreur("Impossible d'ouvrir la base GroupGd.db", standardError, Group.lastError) ;
    return ;
  }

  strcpy(Group.pDonnees->groupe,  sGroupe.c_str()) ;
  strcpy(Group.pDonnees->libelle, sLibelle.c_str()) ;
  strcpy(Group.pDonnees->date,    sDateGroupe.c_str()) ;
  strcpy(Group.pDonnees->util,    sUtil.c_str()) ;

  Group.lastError = Group.appendRecord() ;
  if (Group.lastError != DBIERR_NONE)
  {
    erreur("Erreur � l'ajout dans la base GroupGd.db", standardError, Group.lastError) ;
    Group.close() ;
    return ;
  }

  // on ferme la base
  Group.lastError = Group.close() ;
  if (Group.lastError != DBIERR_NONE)
    erreur("Erreur � la fermeture dans la base GroupGd.db", standardError, Group.lastError) ;

  string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str() ;
  ::MessageBox(pContexte->GetMainWindow()->GetHandle(), "Importation du groupe de fils guides termin�e.", sCaption.c_str(), MB_OK) ;
}

void
NSGroupGdDialog::CmExport()
{
    string sOut = "";
    string sCodeGroupe;
    int    nbfg;
    ofstream outFile;
    NSChoixGdDialog* pChoixGdDlg = new NSChoixGdDialog(this, pContexte);

    if (pChoixGdDlg->Execute() == IDOK)
    {
        int index = pChoixGdDlg->GroupChoisi;
        if (index == -1)
            return;

        NSGroupGdInfo* pGroupeChoisi = (*(pChoixGdDlg->pGroupArray))[index];

        // On �crit d'abord le header dans sOut
        sOut += string("1.0") + "\"";   // Num�ro de version
        sOut += string("    ") + "\"";  // CRC (pour + tard)
        sOut += string(pGroupeChoisi->pDonnees->groupe) + "\"";
        sOut += string(pGroupeChoisi->pDonnees->libelle) + "\"";
        sOut += string(pGroupeChoisi->pDonnees->date) + "\"";
        sOut += string(pGroupeChoisi->pDonnees->util) + "\n";

        sCodeGroupe = string(pGroupeChoisi->pDonnees->groupe);
        //
        // On �crit maintenant tous les fils guides appartenant � ce groupe
        // Cr�ation d'un BBFiche
        //
        BBFiche* pBBFiche = new BBFiche(pContexte);
        pBBFiche->lastError = pBBFiche->open();
        if (pBBFiche->lastError != DBIERR_NONE)
        {
   	        erreur("Il est impossible d'ouvrir le fichier des Guides.", standardError, pBBFiche->lastError) ;
            delete pBBFiche;

            return;
        }

        // On cherche les fils guides de groupe sCode
        // pour pouvoir les exporter
        string sCodeFG = sCodeGroupe + string(CH_CODE_LEN, ' ');
        pBBFiche->lastError = pBBFiche->chercheClef(&sCodeFG,
                                        "",
                                        0,
                                        keySEARCHGEQ,
                                        dbiWRITELOCK);

        if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_EOF))
        {
            erreur("Erreur � la recherche dans le fichier des Guides.", standardError, pBBFiche->lastError) ;
            pBBFiche->close();
            delete pBBFiche;
            return;
        }

        // on boucle pour exporter tous les fils guides de type sCodeGroupe
        nbfg = 0;

        while (pBBFiche->lastError != DBIERR_EOF)
        {
            pBBFiche->lastError = pBBFiche->getRecord();
            if (pBBFiche->lastError != DBIERR_NONE)
            {
                erreur("Erreur � la lecture d'une fiche Guides.", standardError, pBBFiche->lastError) ;
                pBBFiche->close();
                delete pBBFiche;
                return;
            }

            // Condition d'arret : on n'est plus sur le bon code groupe
            if (strcmp(pBBFiche->pDonnees->auteur, sCodeGroupe.c_str()))
                break;

            // On �crit ici les donn�es du fil guide dans sOut
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->code) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->auteur) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->chemin) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->commentaire) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->fichierDialogue) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->nomDialogue) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->ouvreDialogue) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->fichierFonction) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->nomFonction) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->decalageNiveau) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->fils) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->exclusion) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->automatique) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->actif_vide) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->unicite_lesion) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->impose) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->tri) + "\"";
            sOut += string((static_cast<BBItemData*>(pBBFiche->pDonnees))->scenario) + "\"";
            sOut += "\n";

            nbfg++;

            // On passe au fil guide suivant
            pBBFiche->lastError = pBBFiche->suivant(dbiWRITELOCK);
            if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_EOF))
            {
                erreur("Erreur d'acc�s � la fiche Guides suivante.", standardError, pBBFiche->lastError) ;
                pBBFiche->close();
                delete pBBFiche;
                return;
            }
        }

        pBBFiche->lastError = pBBFiche->close();
   	    if (pBBFiche->lastError != DBIERR_NONE)
		    erreur("Erreur de fermeture de la base des Guides.", standardError, pBBFiche->lastError) ;

	    delete pBBFiche;

        if (nbfg == 0)
        {
            erreur("Aucun fil guide n'existe avec le code groupe sp�cifi�", standardError, 0) ;
            return;
        }

        NSNomGdDialog* pNomGdDlg = new NSNomGdDialog(this, pContexte->PathName("IHTM"), "", "nsg", pContexte);
        if (pNomGdDlg->Execute() == IDOK)
        {
            // on peut enregistrer sous le nom de fichier propos�
            string sFichier = pNomGdDlg->sFichier;

            outFile.open(sFichier.c_str());
            if (outFile)
            {
                for (size_t i=0; i < strlen(sOut.c_str()); i++)
                    outFile.put(sOut[i]);

	            outFile.close();
            }
            else
            {
   	            erreur("Impossible de cr�er le fichier � exporter", standardError, 0) ;
                return;
            }
        }
        else
        {
            erreur("L'exportation du groupe est annul�e",standardError, 0) ;
            return;
        }

        delete pNomGdDlg;

        string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
        ::MessageBox(pContexte->GetMainWindow()->GetHandle(), "Exportation du groupe de fils guides termin�e.", sCaption.c_str(), MB_OK);
    }

    delete pChoixGdDlg;
}

void
NSGroupGdDialog::CmDestroy()
{
    string sCodeGroupe;
    string sMsg;
    NSChoixGdDialog* pChoixGdDlg = new NSChoixGdDialog(this, pContexte);

    if (pChoixGdDlg->Execute() == IDOK)
    {
        int index = pChoixGdDlg->GroupChoisi;
        if (index == -1)
            return;

        NSGroupGdInfo* pGroupeChoisi = (*(pChoixGdDlg->pGroupArray))[index];
        sCodeGroupe = string(pGroupeChoisi->pDonnees->groupe);

        sMsg = "Etes vous s�r de vouloir d�truire le groupe ";
        if (sCodeGroupe[0] == '$')
            sMsg += "syst�me : ";
        else
            sMsg += "utilisateur : ";
        sMsg += string(pGroupeChoisi->pDonnees->libelle);
        sMsg += ", ainsi que tous les fils guides associ�s � ce groupe ?";

        string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
        int retVal = ::MessageBox(pContexte->GetMainWindow()->GetHandle(), sMsg.c_str(), sCaption.c_str(), MB_YESNO);
        if (retVal == IDYES)
        {
            if (!DetruireGroupe(sCodeGroupe))
                erreur("La destruction de ce groupe a �chou�.", standardError, 0) ;
            else
                ::MessageBox(pContexte->GetMainWindow()->GetHandle(), "Destruction termin�e.", sCaption.c_str(), MB_OK);
        }
    }

    delete pChoixGdDlg;
}

void
NSGroupGdDialog::CmGestion()
{
    NSListChemDialog* pListChemDlg = new NSListChemDialog(this, pContexte, pNSResModule);
    pListChemDlg->Execute();
    delete pListChemDlg;
}

void
NSGroupGdDialog::CmOk()
{
    NSUtilDialog::CmOk();
}

void
NSGroupGdDialog::CmCancel()
{
    NSUtilDialog::CmCancel();
}

// -----------------------------------------------------------------
//
//  M�thodes de NSChoixGdDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSChoixGdDialog, NSUtilDialog)
	EV_CHILD_NOTIFY_AND_CODE(IDC_CHOIXGD_LIST, LBN_SELCHANGE, CmSelectGroup),
	EV_CHILD_NOTIFY_AND_CODE(IDC_CHOIXGD_LIST, LBN_DBLCLK, CmGroupDblClk),
    EV_BN_CLICKED(IDC_CHOIXGD_FGSYS, FilGuideSys),
    EV_BN_CLICKED(IDC_CHOIXGD_FGUTIL, FilGuideUtil),
    EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

NSChoixGdDialog::NSChoixGdDialog(TWindow* pere, NSContexte* pCtx, bool utilOnly)
                    :NSUtilDialog(pere, pCtx, "IDD_CHOIXGD", pNSResModule)
{
	pGroupBox       = new OWL::TListBox(this, IDC_CHOIXGD_LIST);
	pGroupArray     = new NSGroupGdArray;
    GroupChoisi     = -1;

    pFGGB           = new OWL::TGroupBox(this, IDC_CHOIXGD_GB);
    pFGSys          = new OWL::TRadioButton(this, IDC_CHOIXGD_FGSYS, pFGGB);
    pFGUtil         = new OWL::TRadioButton(this, IDC_CHOIXGD_FGUTIL, pFGGB);
    bUtilOnly       = utilOnly;
}

NSChoixGdDialog::~NSChoixGdDialog()
{
	delete pGroupBox;
	delete pGroupArray;
    delete pFGGB;
    delete pFGSys;
    delete pFGUtil;
}

void
NSChoixGdDialog::SetupWindow()
{
  	NSUtilDialog::SetupWindow();

    if (bUtilOnly)
    {
        bFGSys = false;
        pFGSys->Uncheck();
        pFGUtil->Check();
    }
    else
    {
        bFGSys = true;
        pFGSys->Check();
        pFGUtil->Uncheck();
    }

    InitListe();
}

bool
NSChoixGdDialog::InitListe()
{
    //
	// Remplissage de GroupBox avec les libelles des fichiers de groupe
	//
	NSGroupGd* pGroup = new NSGroupGd(pContexte);
	//
	// Ouverture du fichier
	//
	pGroup->lastError = pGroup->open();
	if (pGroup->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture de la base GroupGd.db.", standardError, pGroup->lastError);
		delete pGroup;
		return false;
	}

   	pGroup->lastError = pGroup->debut(dbiWRITELOCK);
   	if ((pGroup->lastError != DBIERR_NONE) && (pGroup->lastError != DBIERR_BOF))
	{
		erreur("Erreur de positionnement dans la base GroupGd.db.", standardError, pGroup->lastError);
		pGroup->close();
		delete pGroup;
		return false;
	}

    if (pGroup->lastError == DBIERR_BOF)
    {
        erreur("La base GroupGd est vide.", standardError, 0) ;
		pGroup->close();
		delete pGroup;
		return false;
    }

   	do
   	{
   		pGroup->lastError = pGroup->getRecord();
		if (pGroup->lastError != DBIERR_NONE)
		{
			erreur("Erreur de lecture dans la base GroupGd.db.", standardError, pGroup->lastError);
			pGroup->close();
			delete pGroup;
			return false;
		}

      	// On remplit la GroupBox et le GroupArray avec les groupes de fils guides
        // de type utilisateur ou les groupes de fils guides syst�me

      	if ((bFGSys && (pGroup->pDonnees->groupe[0] == '$')) ||
            ((!bFGSys) && (pGroup->pDonnees->groupe[0] != '$')))
      	{
      		pGroupBox->AddString(pGroup->pDonnees->libelle);
			pGroupArray->push_back(new NSGroupGdInfo(pGroup));
      	}

      	// on se positionne sur la template suivante

      	pGroup->lastError = pGroup->suivant(dbiWRITELOCK);
		if ((pGroup->lastError != DBIERR_NONE) && (pGroup->lastError != DBIERR_EOF))
      	{
			erreur("Erreur d'acc�s au groupe suivant.", standardError, pGroup->lastError);
         	pGroup->close();
			delete pGroup;
			return false;
      	}

    }
   	while (pGroup->lastError != DBIERR_EOF);

	pGroup->lastError = pGroup->close();
   	if (pGroup->lastError != DBIERR_NONE)
		erreur("Erreur de fermeture de la base des groupes.", standardError, pGroup->lastError);

	delete pGroup;
    return true;
}

void NSChoixGdDialog::FilGuideSys()
{
    if (bUtilOnly)
    {
        pFGSys->Uncheck();
        pFGUtil->Check();
        return;
    }

    bFGSys = true;
    pGroupBox->ClearList();
    pGroupArray->vider();
    InitListe();
}

void NSChoixGdDialog::FilGuideUtil()
{
    bFGSys = false;
    pGroupBox->ClearList();
    pGroupArray->vider();
    InitListe();
}

void NSChoixGdDialog::CmNewGroup()
{
    string sCode;

    if (bFGSys)
    {
        string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
        MessageBox("Fonction non disponible pour les groupes syst�me.", sCaption.c_str(), MB_OK);
        return;
    }

    NSGroupGd* pGroup = new NSGroupGd(pContexte);
    pGroup->lastError = pGroup->open();
    if (pGroup->lastError != DBIERR_NONE)
    {
        erreur("Impossible d'ouvrir la base GroupGd.db", standardError, pGroup->lastError);
        delete pGroup;
        return;
    }

    pGroup->lastError = pGroup->fin(dbiWRITELOCK);
    if (pGroup->lastError != DBIERR_NONE)
    {
        erreur("Erreur au positionnement dans la base GroupGd.db", standardError, pGroup->lastError);
        pGroup->close();
        delete pGroup;
        return;
    }

    pGroup->lastError = pGroup->getRecord();
    if (pGroup->lastError != DBIERR_NONE)
    {
        erreur("Erreur � la lecture dans la base GroupGd.db", standardError, pGroup->lastError);
        pGroup->close();
        delete pGroup;
        return;
    }

    if (pGroup->pDonnees->groupe[0] != '$')
    {
        sCode = string(pGroup->pDonnees->groupe);
        if (!pGroup->IncrementeCode(&sCode))
        {
            erreur("Erreur � l'attribution d'un nouveau code groupe.", standardError, 0) ;
            pGroup->close();
            delete pGroup;
            return;
        }
    }
    else    // cas du premier groupe utilisateur
        sCode = string("000");

    NSCreateGdDialog* pDlg = new NSCreateGdDialog(this, pContexte, pNSResModule);
    strcpy(pDlg->pData->groupe, sCode.c_str());

    if (pDlg->Execute() == IDCANCEL)
    {
        delete pDlg;
        pGroup->close();
        delete pGroup;
        return;
    }

    // le code n'existe pas encore => on ajoute la fiche groupe
    *(pGroup->pDonnees) = *(pDlg->pData);

    pGroup->lastError = pGroup->appendRecord();
    if (pGroup->lastError != DBIERR_NONE)
    {
        erreur("Erreur � l'ajout dans la base GroupGd.db", standardError, pGroup->lastError);
        pGroup->close();
        delete pGroup;
        delete pDlg;
        return;
    }

    // !!! on met � jour la GroupBox s'il s'agit d'un nouveau groupe utilisateur
    // ce test n'est plus n�c�ssaire mais on le garde pour m�moire
    if (pGroup->pDonnees->groupe[0] != '$')
    {
        pGroupBox->AddString(pGroup->pDonnees->libelle);
        pGroupArray->push_back(new NSGroupGdInfo(pGroup));
        pGroupBox->SetSelIndex(pGroupBox->GetCount() - 1);
        GroupChoisi = pGroupBox->GetSelIndex();
    }

    // on ferme la base
    pGroup->lastError = pGroup->close();
    if (pGroup->lastError != DBIERR_NONE)
        erreur("Erreur � la fermeture dans la base GroupGd.db", standardError, pGroup->lastError);

    delete pGroup;
    delete pDlg;
}

void NSChoixGdDialog::CmModGroup()
{
    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();

    if (GroupChoisi == -1)
    {
        MessageBox("Vous devez s�lectionner un groupe � modifier.", sCaption.c_str(), MB_OK);
        return;
    }

    if (bFGSys)
    {
        MessageBox("Fonction non disponible pour les groupes syst�me.", sCaption.c_str(), MB_OK);
        return;
    }

    // on passe les data au dialogue de modification des groupes
    NSGroupGdInfo* pGroupeChoisi = (*pGroupArray)[GroupChoisi];
    NSCreateGdDialog* pDlg = new NSCreateGdDialog(this, pContexte, pNSResModule);
    *(pDlg->pData) = *(pGroupeChoisi->pDonnees);

    if (pDlg->Execute() == IDCANCEL)
    {
        delete pDlg;
        return;
    }

    string sCode = string(pDlg->pData->groupe);

    // on regarde si le code existe bien
    // avant de modifier la nouvelle fiche groupe
    NSGroupGd* pGroup = new NSGroupGd(pContexte);
    pGroup->lastError = pGroup->open();
    if (pGroup->lastError != DBIERR_NONE)
    {
        erreur("Impossible d'ouvrir la base GroupGd.db", standardError, pGroup->lastError);
        delete pGroup;
        delete pDlg;
        return;
    }

    pGroup->lastError = pGroup->chercheClef(&sCode,
                                               "",
											   0,
											   keySEARCHEQ,
											   dbiWRITELOCK);

    if ((pGroup->lastError != DBIERR_NONE) && (pGroup->lastError != DBIERR_RECNOTFOUND))
    {
        erreur("Erreur � la recherche dans la base GroupGd.db", standardError, pGroup->lastError);
        pGroup->close();
        delete pGroup;
        delete pDlg;
        return;
    }
    else if (pGroup->lastError == DBIERR_RECNOTFOUND)  // cas o� le code n'existe plus
    {
        erreur("Impossible de retrouver le groupe � modifier dans GroupGd.db",standardError, 0) ;
        pGroup->close();
        delete pGroup;
        delete pDlg;
        return;
    }

    // on est sur le bon Record => on modifie la fiche groupe
    *(pGroup->pDonnees) = *(pDlg->pData);

    pGroup->lastError = pGroup->modifyRecord(TRUE);
    if (pGroup->lastError != DBIERR_NONE)
    {
        erreur("Erreur � la modification dans la base GroupGd.db", standardError, pGroup->lastError);
        pGroup->close();
        delete pGroup;
        delete pDlg;
        return;
    }

    // on ferme la base
    pGroup->lastError = pGroup->close();
    if (pGroup->lastError != DBIERR_NONE)
        erreur("Erreur � la fermeture dans la base GroupGd.db", standardError, pGroup->lastError);

    delete pGroup;
    delete pDlg;
}

void NSChoixGdDialog::CmGroupDblClk(WPARAM /* Cmd */){
	GroupChoisi = pGroupBox->GetSelIndex() ;
	NSUtilDialog::CmOk() ;
}

void NSChoixGdDialog::CmSelectGroup(WPARAM /* Cmd */){
	//
	// R�cup�ration de l'indice du groupe s�lectionn�
	//
	GroupChoisi = pGroupBox->GetSelIndex();
}

void NSChoixGdDialog::CmCancel(){
	GroupChoisi = -1;
	TDialog::CmCancel();
}

// -----------------------------------------------------------------//
//  M�thodes de NSNomGdDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSNomGdDialog, NSUtilDialog)
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

NSNomGdDialog::NSNomGdDialog(TWindow* pere, string sDir, string sNom, string sExt, NSContexte* pCtx)
                    :NSUtilDialog(pere, pCtx, "IDD_NOMGD", pNSResModule)
{
  sPath = sDir ;

  size_t pos = sNom.find('.') ;
  if (pos != NPOS)
  	sFichier = string(sNom, 0, pos) ;
  else
  	sFichier = sNom ;
  sExtension = sExt ;
  
  pText = new TStatic(this, IDC_NOMGD_TEXT) ;
  pNom  = new NSUtilEdit(pContexte, this, IDC_NOMGD_EDIT, 80) ;
}

NSNomGdDialog::~NSNomGdDialog(){
  delete pNom;
}

voidNSNomGdDialog::SetupWindow()
{
  char far lib[100] ;
  string sLib;

  NSUtilDialog::SetupWindow() ;
    pText->GetText(lib, 100);    sLib = string(lib) + string(" ") + sExtension;
    pText->SetText(sLib.c_str());
    string sFileName = sFichier + "." + sExtension;
    pNom->SetText(sFileName.c_str());
    pNom->SetFocus();
    // Le SetSelection ne marche pas...
    // pNom->SetSelection(0, strlen(sFichier.c_str()));
}


void NSNomGdDialog::CmOk()
{
    char far nom[80];
    char msg[255];
    size_t  pos;

    pNom->GetText(nom, 80);
    if (!strcmp(nom, ""))
    {
        erreur("Vous devez indiquer un nom de fichier.", standardError, 0) ;
        return;
    }

    sFichier = string(nom);
    sprintf(msg, "Le nom de fichier doit comporter l'extension .%s", sExtension.c_str());

    pos = sFichier.find('.');
    if (pos == NPOS)
    {
        erreur(msg, standardError, 0, GetHandle());
        return;
    }

    string sExt = string(sFichier, pos+1, strlen(sFichier.c_str())-pos-1);
    if (!(sExt == sExtension))
    {
        erreur(msg, standardError, 0, GetHandle());
        return;
    }

    sFichier = sPath + sFichier;
    if (FileExists(AnsiString(sFichier.c_str())))
    {
        string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
        int idRet = MessageBox("Ce fichier existe d�j�. Voulez-vous le remplacer ?", sCaption.c_str(), MB_YESNO);
        if (idRet == IDNO)
            return;
    }

	NSUtilDialog::CmOk();
}

void NSNomGdDialog::CmCancel()
{
	NSUtilDialog::CmCancel();
}

/*****************************************************************************/
/******             OUTIL DE GESTION DES FILS GUIDES                    ******/
/*****************************************************************************/

// -----------------------------------------------------------------
//
//  M�thodes de NSListChemWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSListChemWindow, TListWindow)
    EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

//---------------------------------------------------------------------------
//  Function: NSListChemWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
//
//  Arguments:	  les modKeys et le point click�
//
//  Description: Fonction de r�ponse au click
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void
NSListChemWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
    TListWindow::EvLButtonDown(modKeys, point);

    TLwHitTestInfo info(point);
    HitTest(info);

    if (info.GetFlags() & LVHT_ONITEM)
    {
        pDlg->CmModFG();
    }
}

//---------------------------------------------------------------------------
//  Function: NSListChemWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListChemWindow::IndexItemSelect()
{
    int count = GetItemCount();
    int index = -1;

    for (int i = 0; i < count; i++)
   	    if (GetItemState(i, LVIS_SELECTED))
        {
      	    index = i;
            break;
        }

    return index;
}

// -----------------------------------------------------------------
//
//  M�thodes de NSListChemDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSListChemDialog, NSUtilDialog)
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_CBN_SELCHANGE(IDC_LISTFG_GROUPE, EvGroupChange),
    EV_BN_CLICKED(IDC_LISTFG_NEW, CmNewFG),
    EV_BN_CLICKED(IDC_LISTFG_MOD, CmModFG),
    EV_BN_CLICKED(IDC_LISTFG_DUP, CmDupFG),
    EV_BN_CLICKED(IDC_LISTFG_DEL, CmDelFG),
    EV_BN_CLICKED(IDC_LISTFG_UP, CmHaut),
    EV_BN_CLICKED(IDC_LISTFG_DOWN, CmBas),
    EV_BN_CLICKED(IDC_LISTFG_NEWGP, CmNewGP),
    EV_BN_CLICKED(IDC_LISTFG_MODGP, CmModGP),
END_RESPONSE_TABLE;

NSListChemDialog::NSListChemDialog(TWindow* pere, NSContexte* pCtx, TModule* mod)
                         :NSUtilDialog(pere, pCtx, "IDD_LISTFG", mod)
{
    pGroupBox =     new TComboBox(this, IDC_LISTFG_GROUPE);
    pListeChem =    new NSListChemWindow(this, IDC_LISTFG_LW);
    pChemArray =    new NSEltArray;
    nbChem = 0;
    pGroupArray =   new NSGroupGdArray;
}

NSListChemDialog::~NSListChemDialog()
{
    delete pGroupBox;
    delete pListeChem;
    delete pChemArray;
    delete pGroupArray;
}

void
NSListChemDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow();

    InitListeChem();

    if (InitGroupBox())
    {
        GroupChoisi = 0;
        pGroupBox->SetSelIndex(0);

        if (InitChemArray())
            AfficheListeChem();
        else
            erreur("Impossible d'afficher le groupe initial.",standardError, 0) ;
    }
    else
        erreur("Impossible d'obtenir la liste des groupes.",standardError, 0) ;
}

bool
NSListChemDialog::InitGroupBox()
{
    //
	// Remplissage de GroupBox avec les libelles des fichiers de groupe
    // Note : pour ce dialogue, on n'autorise que les fils guides utilisateurs
	//
	NSGroupGd* pGroup = new NSGroupGd(pContexte);
	//
	// Ouverture du fichier
	//
	pGroup->lastError = pGroup->open();
	if (pGroup->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture de la base GroupGd.db.", standardError, pGroup->lastError);
		delete pGroup;
		return false;
	}

   	pGroup->lastError = pGroup->debut(dbiWRITELOCK);
   	if ((pGroup->lastError != DBIERR_NONE) && (pGroup->lastError != DBIERR_BOF))
	{
		erreur("Erreur de positionnement dans la base GroupGd.db.", standardError, pGroup->lastError);
		pGroup->close();
		delete pGroup;
		return false;
	}

    if (pGroup->lastError == DBIERR_BOF)
    {
        erreur("La base GroupGd est vide.", standardError, 0) ;
		pGroup->close();
		delete pGroup;
		return false;
    }

   	do
   	{
   		pGroup->lastError = pGroup->getRecord();
		if (pGroup->lastError != DBIERR_NONE)
		{
			erreur("Erreur de lecture dans la base GroupGd.db.", standardError, pGroup->lastError);
			pGroup->close();
			delete pGroup;
			return false;
		}

      	// On remplit la GroupBox et le GroupArray avec les groupes de fils guides
        // de type utilisateur
      	if (pGroup->pDonnees->groupe[0] != '$')
      	{
      		pGroupBox->AddString(pGroup->pDonnees->libelle);
			pGroupArray->push_back(new NSGroupGdInfo(pGroup));
      	}

      	// on se positionne sur le groupe suivant
      	pGroup->lastError = pGroup->suivant(dbiWRITELOCK);
		if ((pGroup->lastError != DBIERR_NONE) && (pGroup->lastError != DBIERR_EOF))
      	{
			erreur("Erreur d'acc�s au groupe suivant.", standardError, pGroup->lastError);
         	pGroup->close();
			delete pGroup;
			return false;
      	}

    }
   	while (pGroup->lastError != DBIERR_EOF);

	pGroup->lastError = pGroup->close();
   	if (pGroup->lastError != DBIERR_NONE)
		erreur("Erreur de fermeture de la base des groupes.", standardError, pGroup->lastError);

	delete pGroup;
    return true;
}

void
NSListChemDialog::InitListeChem()
{
    TListWindColumn colChem("Chemin", 1000, TListWindColumn::Left, 0);
  	pListeChem->InsertColumn(0, colChem);
}

void
NSListChemDialog::AfficheListeChem()
{
    char elt[255];

	pListeChem->DeleteAllItems();

	for (int i = nbChem - 1; i >= 0; i--)
    {
   	    sprintf(elt, "%s", (((*pChemArray)[i])->libelle).c_str());
   	    TListWindItem Item(elt, 0);
        pListeChem->InsertItem(Item);
    }
}

void
NSListChemDialog::EvGroupChange()
{
    GroupChoisi = pGroupBox->GetSelIndex();

    // On recalcule le tableau de chemins � afficher
    if (InitChemArray())
        AfficheListeChem();
    else
        erreur("Impossible d'afficher la liste des chemins.",standardError, 0) ;
}

void
NSListChemDialog::TrouveLibElement(string sElement, string& sLibElement)
{
    size_t pos1, pos2;
    bool bContinue = true;
    bool bPremier = true;
    string sCode1, sLibelle1;
    string sCode2, sLibelle2;

    // on remet � "" sLibElement
    sLibElement = "";

    pos1 = 0;
    pos2 = sElement.find('/');
    if (pos2 != NPOS)
    {
        while (bContinue)
        {
            if (pos2 != NPOS)
                sCode1 = string(sElement, pos1, pos2-pos1);
            else
                sCode1 = string(sElement, pos1, strlen(sElement.c_str())-pos1);

            TrouveLibElement(sCode1, sLibelle1);
            if (bPremier)
            {
                sLibElement = sLibelle1;
                bPremier = false;
            }
            else
                sLibElement += string("/") + sLibelle1;

            if ((pos2 == NPOS) || (pos2 == (strlen(sElement.c_str())-1)))
                bContinue = false;
            else
            {
                pos1 = pos2+1;
                pos2 = sElement.find('/', pos1);
            }
        }

        return;
    }

    string sLang = "";
    if ((pContexte) && (pContexte->getUtilisateur()))
        sLang = pContexte->getUtilisateur()->donneLang();

    // on traite les jokers � part
    if (sElement == "")
        sLibElement = "";
    else if (sElement[0] == '~')
        sLibElement = string(sElement, 3, 2);
    else
    {
        sCode2 = sElement; sLibelle2 = "";
        if (strlen(sCode2.c_str()) < BASE_LEXI_LEN)        	pContexte->getSuperviseur()->getDico()->donneCodeComplet(sCode2) ;
        if (pContexte->getDico()->donneLibelle(sLang, &sCode2, &sLibelle2))
        {
            // pour les codes syst�me
            if (sLibelle2 == "")
            {
                pContexte->getDico()->donneLibelleLexique(sLang, &sCode2, &sLibelle2);

                // pour les cas non trait�s
                if (sLibelle2 == "")
                    sLibElement = sElement;
                else
                    sLibElement = sLibelle2;
            }
            else // cas normal
                sLibElement = sLibelle2;
        }
        else // cas d'erreur
            sLibElement = sElement;
    }
}

bool
NSListChemDialog::InitChemArray()
{
    string sCode;
    string sChemin;
    string sLibelle;

    pChemArray->vider();
    nbChem = 0;

    NSGroupGdInfo* pGroupeChoisi = (*pGroupArray)[GroupChoisi];
    string sCodeGroupe = string(pGroupeChoisi->pDonnees->groupe);

    //
    // On stocke les chemins des fils guides appartenant � ce groupe
    // Cr�ation d'un BBFiche
    //
    BBFiche* pBBFiche = new BBFiche(pContexte);
    pBBFiche->lastError = pBBFiche->open();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
        erreur("Il est impossible d'ouvrir le fichier des Guides.", standardError, pBBFiche->lastError) ;
        delete pBBFiche;
        return false;
    }

    // On cherche les fils guides de groupe sCodeGroupe
    string sCodeFG = sCodeGroupe + string(CH_CODE_LEN, ' ');
    pBBFiche->lastError = pBBFiche->chercheClef(&sCodeFG,
                                        "",
                                        0,
                                        keySEARCHGEQ,
                                        dbiWRITELOCK);

    if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_EOF))
    {
        erreur("Erreur � la recherche dans le fichier des Guides.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }

    // on boucle pour r�cup�rer tous les fils guides de type sCodeGroupe
    while (pBBFiche->lastError != DBIERR_EOF)
    {
        pBBFiche->lastError = pBBFiche->getRecord();
        if (pBBFiche->lastError != DBIERR_NONE)
        {
            erreur("Erreur � la lecture d'une fiche Guides.", standardError, pBBFiche->lastError) ;
            pBBFiche->close();
            delete pBBFiche;
            return false;
        }

        // Condition d'arret : on n'est plus sur le bon code groupe
        if (strcmp(pBBFiche->pDonnees->auteur, sCodeGroupe.c_str()))
            break;

        // On r�cup�re ici le chemin du fil guide (en clair)
        sCode = string((static_cast<BBItemData*>(pBBFiche->pDonnees))->code);
        sChemin = string((static_cast<BBItemData*>(pBBFiche->pDonnees))->chemin);
        sLibelle = "";

        TrouveLibElement(sChemin, sLibelle);

        pChemArray->push_back(new NSElement(sCode, sLibelle));
        nbChem++;

        // On passe au fil guide suivant
        pBBFiche->lastError = pBBFiche->suivant(dbiWRITELOCK);
        if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_EOF))
        {
            erreur("Erreur d'acc�s � la fiche Guides suivante.", standardError, pBBFiche->lastError) ;
            pBBFiche->close();
            delete pBBFiche;
            return false;
        }
    }

    pBBFiche->lastError = pBBFiche->close();
    if (pBBFiche->lastError != DBIERR_NONE)
        erreur("Erreur de fermeture de la base des Guides.", standardError, pBBFiche->lastError) ;

    delete pBBFiche;
    return true;
}

bool
NSListChemDialog::PermuteFG(int indexInf)
{
    BBItemInfo* fg1;
    BBItemInfo* fg2;
    string      sCodeFG, sCode;

    NSGroupGdInfo* pGroupeChoisi = (*pGroupArray)[GroupChoisi];
    string sCodeGroupe = string(pGroupeChoisi->pDonnees->groupe);

    //
    // On enregistre les deux fils guide
    //
    BBFiche* pBBFiche = new BBFiche(pContexte);
    pBBFiche->lastError = pBBFiche->open();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
   	    erreur("Il est impossible d'ouvrir le fichier des Guides.", standardError, pBBFiche->lastError) ;
        delete pBBFiche;
        return false;
    }

    sCodeFG = sCodeGroupe + ((*pChemArray)[indexInf])->code;
    pBBFiche->lastError = pBBFiche->chercheClef(&sCodeFG,
                                        "",
                                        0,
                                        keySEARCHEQ,
                                        dbiWRITELOCK);

    if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_RECNOTFOUND))
    {
        erreur("Erreur � la recherche dans le fichier des Guides.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }
    else if (pBBFiche->lastError == DBIERR_RECNOTFOUND)
    {
        erreur("Le fil guide sp�cifi� n'existe pas dans la base des guides.", standardError, 0) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }

    pBBFiche->lastError = pBBFiche->getRecord();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
        erreur("Erreur � la lecture d'une fiche Guides.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }

    fg1 = new BBItemInfo(pBBFiche);
    sCode = fg1->pDonnees->code;

    sCodeFG = sCodeGroupe + ((*pChemArray)[indexInf+1])->code;
    pBBFiche->lastError = pBBFiche->chercheClef(&sCodeFG,
                                        "",
                                        0,
                                        keySEARCHEQ,
                                        dbiWRITELOCK);

    if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_RECNOTFOUND))
    {
        erreur("Erreur � la recherche dans le fichier des Guides.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }
    else if (pBBFiche->lastError == DBIERR_RECNOTFOUND)
    {
        erreur("Le fil guide sp�cifi� n'existe pas dans la base des guides.", standardError, 0) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }

    pBBFiche->lastError = pBBFiche->getRecord();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
        erreur("Erreur � la lecture d'une fiche Guides.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }

    fg2 = new BBItemInfo(pBBFiche);

    // on permute uniquement les codes avant de refaire un modifyRecord
    strcpy(fg1->pDonnees->code, fg2->pDonnees->code);
    strcpy(fg2->pDonnees->code, sCode.c_str());

    *(static_cast<BBItemData*>(pBBFiche->pDonnees)) = *(fg1->pDonnees);

    pBBFiche->lastError = pBBFiche->modifyRecord(TRUE);
    if (pBBFiche->lastError != DBIERR_NONE)
    {
        erreur("Erreur � la modification du fil guide.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }

    sCodeFG = sCodeGroupe + sCode;
    pBBFiche->lastError = pBBFiche->chercheClef(&sCodeFG,
                                        "",
                                        0,
                                        keySEARCHEQ,
                                        dbiWRITELOCK);

    if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_RECNOTFOUND))
    {
        erreur("Erreur � la recherche dans le fichier des Guides.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }
    else if (pBBFiche->lastError == DBIERR_RECNOTFOUND)
    {
        erreur("Le fil guide sp�cifi� n'existe pas dans la base des guides.", standardError, 0) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }

    *(static_cast<BBItemData*>(pBBFiche->pDonnees)) = *(fg2->pDonnees);

    pBBFiche->lastError = pBBFiche->modifyRecord(TRUE);
    if (pBBFiche->lastError != DBIERR_NONE)
    {
        erreur("Erreur � la modification du fil guide.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return false;
    }

    pBBFiche->lastError = pBBFiche->close();
   	if (pBBFiche->lastError != DBIERR_NONE)
		erreur("Erreur de fermeture de la base des Guides.", standardError, pBBFiche->lastError) ;

	delete pBBFiche;
    return true;
}

void
NSListChemDialog::CmNewFG()
{
    NSGroupGdInfo* pGroupeChoisi = (*pGroupArray)[GroupChoisi];
    string sCodeGroupe = string(pGroupeChoisi->pDonnees->groupe);

    NSEditFilGuideDialog* pEditFGDlg =
        new NSEditFilGuideDialog(this, pContexte, sCodeGroupe);

    if (pEditFGDlg->Execute() == IDOK)
    {
        string sCode = pEditFGDlg->sCodeFilGuide;
        string sLibelle = "";
        int lastIndex;
        TrouveLibElement(pEditFGDlg->sCheminPere, sLibelle);
        pChemArray->push_back(new NSElement(sCode, sLibelle));
        nbChem++;
        AfficheListeChem();
        lastIndex = pListeChem->GetItemCount() - 1;
        pListeChem->SetFocus();
        pListeChem->SetSel(lastIndex, true);
        pListeChem->EnsureVisible(lastIndex, true);
    }

    delete pEditFGDlg;
}

void
NSListChemDialog::CmModFG()
{
    NSGroupGdInfo* pGroupeChoisi = (*pGroupArray)[GroupChoisi];
    string sCodeGroupe = string(pGroupeChoisi->pDonnees->groupe);

    int fgChoisi = pListeChem->IndexItemSelect();

    if (fgChoisi == -1)
    {
        erreur("Vous devez s�lectionner un fil guide � modifier.", standardError, 0) ;
        return;
    }

    string sCodeFG = ((*pChemArray)[fgChoisi])->code;

    NSEditFilGuideDialog* pEditFGDlg =
        new NSEditFilGuideDialog(this, pContexte, sCodeGroupe, sCodeFG);

    if (pEditFGDlg->Execute() == IDOK)
    {
        string sLibelle = "";
        TrouveLibElement(pEditFGDlg->sCheminPere, sLibelle);
        ((*pChemArray)[fgChoisi])->libelle = sLibelle;
        AfficheListeChem();
        pListeChem->SetFocus();
        pListeChem->SetSel(fgChoisi, true);
        pListeChem->EnsureVisible(fgChoisi, true);
    }

    delete pEditFGDlg;
}

void
NSListChemDialog::CmDupFG()
{
    BBItemInfo* fg1;
    int fgChoisi = pListeChem->IndexItemSelect();

    if (fgChoisi == -1)
    {
        erreur("Vous devez s�lectionner un fil guide � dupliquer.", standardError, 0) ;
        return;
    }

    // cas de la duplication d'un fil guide
    // on commence par lire le fil guide source
    NSGroupGdInfo* pGroupeChoisi = (*pGroupArray)[GroupChoisi];
    string sCodeGroupe = string(pGroupeChoisi->pDonnees->groupe);
    string sCodeFG = sCodeGroupe + ((*pChemArray)[fgChoisi])->code;

    //
    // Cr�ation d'un BBFiche
    //
    BBFiche* pBBFiche = new BBFiche(pContexte);
    pBBFiche->lastError = pBBFiche->open();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
   	    erreur("Il est impossible d'ouvrir le fichier des Guides.", standardError, pBBFiche->lastError) ;
        delete pBBFiche;
        return;
    }

    pBBFiche->lastError = pBBFiche->chercheClef(&sCodeFG,
                                        "",
                                        0,
                                        keySEARCHEQ,
                                        dbiWRITELOCK);

    if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_RECNOTFOUND))
    {
        erreur("Erreur � la recherche dans le fichier des Guides.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return;
    }
    else if (pBBFiche->lastError == DBIERR_RECNOTFOUND)
    {
        erreur("Le fil guide sp�cifi� n'existe pas dans la base des guides.", standardError, 0) ;
        pBBFiche->close();
        delete pBBFiche;
        return;
    }

    pBBFiche->lastError = pBBFiche->getRecord();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
        erreur("Erreur � la lecture d'une fiche Guides.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return;
    }

    fg1 = new BBItemInfo(pBBFiche);

    // on cherche maintenant la premi�re place disponible
    // pour ins�rer ce fil guide dans le m�me groupe
    string sCodePrecedent = fg1->pDonnees->code;
    string sCompteur, sCode;

    while (pBBFiche->lastError != DBIERR_EOF)
    {
        sCompteur = sCodePrecedent;

        if (!(pBBFiche->IncrementeCode(&sCompteur)))
        {
            erreur("Erreur � l'attribution du code pour le nouveau fil guide.", standardError, 0) ;
            pBBFiche->close();
            delete pBBFiche;
            return;
        }

        sCode = sCodeGroupe + sCompteur;
        pBBFiche->lastError = pBBFiche->chercheClef(&sCode,
                                                "",
                                                0,
                                                keySEARCHGEQ,
                                                dbiWRITELOCK);

        if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_EOF))
        {
            erreur("Erreur � la recherche dans le fichier des Guides.", standardError, pBBFiche->lastError) ;
            pBBFiche->close();
            delete pBBFiche;
            return;
        }

        pBBFiche->lastError = pBBFiche->getRecord();
        if (pBBFiche->lastError != DBIERR_NONE)
        {
            erreur("Erreur � la lecture d'une fiche Guides.", standardError, pBBFiche->lastError) ;
            pBBFiche->close();
            delete pBBFiche;
            return;
        }

        // Condition d'arret : il existe un trou ou fin de groupe
        if ((!(string(pBBFiche->pDonnees->auteur) == sCodeGroupe)) ||
            (string(pBBFiche->pDonnees->code) > sCompteur))
            break;

        pBBFiche->lastError = pBBFiche->suivant(dbiWRITELOCK);
        if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_EOF))
        {
            erreur("Erreur d'acc�s � la fiche Guides suivante.", standardError, pBBFiche->lastError) ;
            pBBFiche->close();
            delete pBBFiche;
            return;
        }

        pBBFiche->lastError = pBBFiche->getRecord();
        if (pBBFiche->lastError != DBIERR_NONE)
        {
            erreur("Erreur � la lecture d'une fiche Guides.", standardError, pBBFiche->lastError) ;
            pBBFiche->close();
            delete pBBFiche;
            return;
        }

        sCodePrecedent = string(pBBFiche->pDonnees->code);
    } // fin du while

    // sCompteur correspond au premier code valide :
    // on le stocke dans fg1 et on stocke les donnees dans BBFiche
    strcpy(fg1->pDonnees->code, sCompteur.c_str());
    *(static_cast<BBItemData*>(pBBFiche->pDonnees)) = *(fg1->pDonnees);

    // on enregistre...
    pBBFiche->lastError = pBBFiche->appendRecord();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
        erreur("Erreur � l'ajout du nouveau fil guide.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return;
    }

    pBBFiche->lastError = pBBFiche->close();
   	if (pBBFiche->lastError != DBIERR_NONE)
		erreur("Erreur de fermeture de la base des Guides.", standardError, pBBFiche->lastError) ;

	delete pBBFiche;

    // on reporte, at last, la modif dans la liste
    // Note : dans la liste, l'�l�ment sera ins�r� en queue
    // il faudra recharger le tableau pour l'avoir � sa place d�finitive
    NSElement ElementDuplique = *((*pChemArray)[fgChoisi]);
    ElementDuplique.code = sCompteur;

    pChemArray->push_back(new NSElement(ElementDuplique));
    nbChem++;

    AfficheListeChem();
    int lastIndex = pListeChem->GetItemCount() - 1;
    pListeChem->SetFocus();
    pListeChem->SetSel(lastIndex, true);
    pListeChem->EnsureVisible(lastIndex, true);
}

void
NSListChemDialog::CmDelFG()
{
    NSEltIter i;
    int j;
    int fgChoisi = pListeChem->IndexItemSelect();

    if (fgChoisi == -1)
    {
        erreur("Vous devez s�lectionner un fil guide � d�truire.", standardError, 0) ;
        return;
    }

    string sCaption = string("Message ") + pContexte->getSuperviseur()->getAppName().c_str();
    int retVal = ::MessageBox(pContexte->GetMainWindow()->GetHandle(), "Etes-vous s�r de vouloir d�truire le fil guide s�lectionn� ?", sCaption.c_str(), MB_YESNO);
    if (retVal == IDNO)
        return;

    NSGroupGdInfo* pGroupeChoisi = (*pGroupArray)[GroupChoisi];
    string sCodeGroupe = string(pGroupeChoisi->pDonnees->groupe);
    string sCodeFG = sCodeGroupe + ((*pChemArray)[fgChoisi])->code;

    //
    // Cr�ation d'un BBFiche
    //
    BBFiche* pBBFiche = new BBFiche(pContexte);
    pBBFiche->lastError = pBBFiche->open();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
   	    erreur("Il est impossible d'ouvrir le fichier des Guides.", standardError, pBBFiche->lastError) ;
        delete pBBFiche;
        return;
    }

    // On cherche les fils guides de groupe sCode
    // pour pouvoir les supprimer
    pBBFiche->lastError = pBBFiche->chercheClef(&sCodeFG,
                                        "",
                                        0,
                                        keySEARCHEQ,
                                        dbiWRITELOCK);

    if ((pBBFiche->lastError != DBIERR_NONE) && (pBBFiche->lastError != DBIERR_RECNOTFOUND))
    {
        erreur("Erreur � la recherche dans le fichier des Guides.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return;
    }
    else if (pBBFiche->lastError == DBIERR_RECNOTFOUND)
    {
        erreur("Le fil guide sp�cifi� n'existe pas dans la base des guides.", standardError, 0) ;
        pBBFiche->close();
        delete pBBFiche;
        return;
    }

    pBBFiche->lastError = pBBFiche->deleteRecord();
    if (pBBFiche->lastError != DBIERR_NONE)
    {
        erreur("Erreur � la destruction d'une fiche Guides.", standardError, pBBFiche->lastError) ;
        pBBFiche->close();
        delete pBBFiche;
        return;
    }

    pBBFiche->lastError = pBBFiche->close();
   	if (pBBFiche->lastError != DBIERR_NONE)
		erreur("Erreur de fermeture de la base des Guides.", standardError, pBBFiche->lastError) ;

	delete pBBFiche;

    // on enl�ve le fil guide de pChemArray
    for (i = pChemArray->begin(), j = 0; i != pChemArray->end(); i++, j++)
    {
        if (j == fgChoisi)
        {
            delete *i;
            pChemArray->erase(i);
            nbChem -= 1;
            break;
        }
    }

    AfficheListeChem();
}

void
NSListChemDialog::CmHaut()
{
    int fgChoisi = pListeChem->IndexItemSelect();

    if (fgChoisi == -1)
    {
        erreur("Vous devez s�lectionner un fil guide � d�placer.", standardError, 0) ;
        return;
    }

    if (fgChoisi == 0)
        return;

    string sChemin = ((*pChemArray)[fgChoisi])->libelle;

    if (!PermuteFG(fgChoisi-1))
    {
        erreur("Echec dans la permutation de deux fils guide.",standardError, 0) ;
        return;
    }

    ((*pChemArray)[fgChoisi])->libelle = ((*pChemArray)[fgChoisi-1])->libelle;
    ((*pChemArray)[fgChoisi-1])->libelle = sChemin;

    AfficheListeChem();
    pListeChem->SetFocus();
    pListeChem->SetSel(fgChoisi-1, true);
    pListeChem->EnsureVisible(fgChoisi-1, true);
}

void
NSListChemDialog::CmBas()
{
    int fgChoisi = pListeChem->IndexItemSelect();

    if (fgChoisi == -1)
    {
        erreur("Vous devez s�lectionner un fil guide � d�placer.", standardError, 0) ;
        return;
    }

    if (fgChoisi == nbChem - 1)
        return;

    string sChemin = ((*pChemArray)[fgChoisi])->libelle;

    if (!PermuteFG(fgChoisi))
    {
        erreur("Echec dans la permutation de deux fils guide.",standardError, 0) ;
        return;
    }

    ((*pChemArray)[fgChoisi])->libelle = ((*pChemArray)[fgChoisi+1])->libelle;
    ((*pChemArray)[fgChoisi+1])->libelle = sChemin;

    AfficheListeChem();
    pListeChem->SetFocus();
    pListeChem->SetSel(fgChoisi+1, true);
    pListeChem->EnsureVisible(fgChoisi+1, true);
}

void
NSListChemDialog::CmNewGP()
{
    string sCode;

    NSGroupGd* pGroup = new NSGroupGd(pContexte);
    pGroup->lastError = pGroup->open();
    if (pGroup->lastError != DBIERR_NONE)
    {
        erreur("Impossible d'ouvrir la base GroupGd.db", standardError, pGroup->lastError);
        delete pGroup;
        return;
    }

    pGroup->lastError = pGroup->fin(dbiWRITELOCK);
    if (pGroup->lastError != DBIERR_NONE)
    {
        erreur("Erreur au positionnement dans la base GroupGd.db", standardError, pGroup->lastError);
        pGroup->close();
        delete pGroup;
        return;
    }

    pGroup->lastError = pGroup->getRecord();
    if (pGroup->lastError != DBIERR_NONE)
    {
        erreur("Erreur � la lecture dans la base GroupGd.db", standardError, pGroup->lastError);
        pGroup->close();
        delete pGroup;
        return;
    }

    if (pGroup->pDonnees->groupe[0] != '$')
    {
        sCode = string(pGroup->pDonnees->groupe);
        if (!pGroup->IncrementeCode(&sCode))
        {
            erreur("Erreur � l'attribution d'un nouveau code groupe.", standardError, 0) ;
            pGroup->close();
            delete pGroup;
            return;
        }
    }
    else    // cas du premier groupe utilisateur
        sCode = string("000");

    NSCreateGdDialog* pDlg = new NSCreateGdDialog(this, pContexte, pNSResModule);
    strcpy(pDlg->pData->groupe, sCode.c_str());

    if (pDlg->Execute() == IDCANCEL)
    {
        delete pDlg;
        pGroup->close();
        delete pGroup;
        return;
    }

    // le code n'existe pas encore => on ajoute la fiche groupe
    *(pGroup->pDonnees) = *(pDlg->pData);

    pGroup->lastError = pGroup->appendRecord();
    if (pGroup->lastError != DBIERR_NONE)
    {
        erreur("Erreur � l'ajout dans la base GroupGd.db", standardError, pGroup->lastError);
        pGroup->close();
        delete pGroup;
        delete pDlg;
        return;
    }

    // !!! on met � jour la GroupBox s'il s'agit d'un nouveau groupe utilisateur
    // ce test n'est plus n�c�ssaire mais on le garde pour m�moire
    if (pGroup->pDonnees->groupe[0] != '$')
    {
        pGroupBox->AddString(pGroup->pDonnees->libelle);
        pGroupArray->push_back(new NSGroupGdInfo(pGroup));
        pGroupBox->SetSelIndex(pGroupBox->GetCount() - 1);
        EvGroupChange();
    }

    // on ferme la base
    pGroup->lastError = pGroup->close();
    if (pGroup->lastError != DBIERR_NONE)
        erreur("Erreur � la fermeture dans la base GroupGd.db", standardError, pGroup->lastError);

    delete pGroup;
    delete pDlg;
}

void
NSListChemDialog::CmModGP()
{
  // on passe les data au dialogue de modification des groupes
  NSGroupGdInfo* pGroupeChoisi = (*pGroupArray)[GroupChoisi] ;
  NSCreateGdDialog* pDlg = new NSCreateGdDialog(this, pContexte, pNSResModule) ;
  *(pDlg->pData) = *(pGroupeChoisi->pDonnees) ;

  if (pDlg->Execute() == IDCANCEL)
  {
    delete pDlg ;
    return ;
  }

  string sCode = string(pDlg->pData->groupe) ;

  // on regarde si le code existe bien
  // avant de modifier la nouvelle fiche groupe
  NSGroupGd* pGroup = new NSGroupGd(pContexte) ;
  pGroup->lastError = pGroup->open() ;
  if (pGroup->lastError != DBIERR_NONE)
  {
    erreur("Impossible d'ouvrir la base GroupGd.db", standardError, pGroup->lastError) ;
    delete pGroup ;
    delete pDlg ;
    return ;
  }

  pGroup->lastError = pGroup->chercheClef(&sCode, "", 0, keySEARCHEQ, dbiWRITELOCK) ;
  if ((pGroup->lastError != DBIERR_NONE) && (pGroup->lastError != DBIERR_RECNOTFOUND))
  {
    erreur("Erreur � la recherche dans la base GroupGd.db", standardError, pGroup->lastError) ;
    pGroup->close() ;
    delete pGroup ;
    delete pDlg ;
    return ;
  }
  else if (pGroup->lastError == DBIERR_RECNOTFOUND)  // cas o� le code n'existe plus
  {
    erreur("Impossible de retrouver le groupe � modifier dans GroupGd.db", standardError, 0) ;
    pGroup->close() ;
    delete pGroup ;
    delete pDlg ;
    return ;
  }

  // on est sur le bon Record => on modifie la fiche groupe
  *(pGroup->pDonnees) = *(pDlg->pData);

  pGroup->lastError = pGroup->modifyRecord(TRUE) ;
  if (pGroup->lastError != DBIERR_NONE)
  {
    erreur("Erreur � la modification dans la base GroupGd.db", standardError, pGroup->lastError) ;
    pGroup->close() ;
    delete pGroup ;
    delete pDlg ;
    return ;
  }

  // on ferme la base
  pGroup->lastError = pGroup->close() ;
  if (pGroup->lastError != DBIERR_NONE)
  	erreur("Erreur � la fermeture dans la base GroupGd.db", standardError, pGroup->lastError) ;
  delete pGroup ;
  delete pDlg ;
}


void

NSListChemDialog::CmOk()
{
    NSUtilDialog::CmOk();
}

void
NSListChemDialog::CmCancel()
{
    NSUtilDialog::CmCancel();
}
// -----------------------------------------------------------------
//
//  M�thodes de NSCreateGdDialog
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSCreateGdDialog, NSUtilDialog)
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

NSCreateGdDialog::NSCreateGdDialog(TWindow* pere, NSContexte* pCtx, TModule* mod)
                    :NSUtilDialog(pere, pCtx, "IDD_CREATEGD", mod)
{
  // fichiers d'aide
  sHindex = "" ;
  sHcorps = "Utilisateur.html" ;

  // Initialisation des donnees  pData 		  = new NSGroupGdData ;
	// Cr�ation de tous les "objets de contr�le"	pCodeGd 	  = new NSUtilEdit(pContexte, this, IDC_CREATEGD_CODE, GRPGD_GROUPE_LEN) ;
	pLibelleGd  = new NSUtilEdit(pContexte, this, IDC_CREATEGD_LIBELLE, GRPGD_LIBELLE_LEN) ;
  pUtilGd		  = new NSUtilEdit(pContexte, this, IDC_CREATEGD_UTIL, GRPGD_UTIL_LEN) ;
  pDateGd		  = new NSUtilEditDate(pContexte, this, IDC_CREATEGD_DATE) ; // d�faut 00/00/2000
}

NSCreateGdDialog::~NSCreateGdDialog(){
  delete pDateGd ;
  delete pCodeGd ;
  delete pLibelleGd ;
  delete pUtilGd ;
  delete pData ;
}

//----------------------------------------------------------------------------


void
NSCreateGdDialog::SetupWindow()
{
	NSUtilDialog::SetupWindow();

    pCodeGd->SetText(pData->groupe);
    pLibelleGd->SetText(pData->libelle);
    pUtilGd->SetText(pData->util);
    pDateGd->setDate(string(pData->date));
}

//----------------------------------------------------------------------------

void
NSCreateGdDialog::CmOk()
{
  bool bCode = false ;
  bool bLib = false ;

  // en th�orie, le code groupe ne peut pas changer, mais bon...
  if (strcmp(pData->groupe, ""))
    bCode = true ;

  char far libelle[GRPGD_LIBELLE_LEN + 1] ;
  pLibelleGd->GetText(libelle, GRPGD_LIBELLE_LEN + 1) ;
  strcpy(pData->libelle, libelle) ;
  if (strcmp(pData->libelle, ""))
    bLib = true ;

  char far util[GRPGD_UTIL_LEN + 1] ;
  pUtilGd->GetText(util, GRPGD_UTIL_LEN + 1) ;
  strcpy(pData->util, util) ;

  string sDateGd ;
  pDateGd->getDate(&sDateGd) ;
  strcpy(pData->date, sDateGd.c_str()) ;

  if (!bCode)
    erreur("Le champ [Code groupe] est obligatoire.", standardError, 0, GetHandle()) ;
  else if (!bLib)
  	erreur("Le champ [Libell� groupe] est obligatoire.", standardError, 0, GetHandle()) ;
  else
  	NSUtilDialog::CmOk() ;
}


//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
void
NSCreateGdDialog::CmCancel()
{
    NSUtilDialog::CmCancel();
}

// fin de nsfilgui.cpp
/////////////////////////////////////////////////////////////////////////////

