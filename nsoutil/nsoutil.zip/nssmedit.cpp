#include <dir.h>#include <string.h>
#include <cstring.h>
#include <stdio.h>

#include "nsoutil\nssmedit.h"#include "nssavoir\ns_fic.h"
#include "partage\nsdivfct.h"
#include "nautilus\nautilus.rh"
#include "nsoutil\nsoutil.h"
#include "nsoutil\nsoutil.rh"

DEFINE_RESPONSE_TABLE1(NSsmEditeur, TPaneSplitter)    EV_LVN_GETDISPINFO(ID_LIST, LvnGetDispInfo),
    EV_COMMAND(CM_ENREGISTRE, CmEnregistre),
    EV_WM_CLOSE,
END_RESPONSE_TABLE;

NSsmEditeur::NSsmEditeur(TWindow* parent, NSContexte* pCtx, string sLexiquePilot)            : TPaneSplitter(parent), NSRoot(pCtx)
{
    string sCodeSens ;
    pContexte->getDico()->donneCodeSens(&sLexiquePilot, &sCodeSens) ;
    sLexiquePilote = sCodeSens ;
    pPatPathoArray = new NSPatPathoArray(pCtx) ;
    initPatPatho() ;
    pSavoirArray = new NSSavoirArray ;
    initSavoir() ;

    pBigBoss = new NSSmallBrother(pCtx, pPatPathoArray) ;
    Attr.Style |= (WS_CLIPSIBLINGS | WS_CLIPCHILDREN) ;
    //    // Create pNSTreeWindowow
    //
    pNSTreeWindow = new NSTreeWindow(this, pCtx, ID_TREE, 0, 0, 0, 0) ;
    pNSTreeWindow->Attr.Style   |= WS_VISIBLE | TVS_HASLINES |
                            TVS_HASBUTTONS | TVS_LINESATROOT ;
    pNSTreeWindow->Attr.ExStyle |= WS_EX_CLIENTEDGE ;

    //    // Create pListWindow
    //
    pListWind = new NSPaneListWindow(this, ID_LIST, 10, 10, 100, 100) ;
    pListWind->Attr.Style   |= LVS_REPORT | LVS_SORTASCENDING | LVS_EDITLABELS ;
    pListWind->Attr.ExStyle |= WS_EX_CLIENTEDGE ;
}

////
//
NSsmEditeur::~NSsmEditeur(){
  delete pBigBoss ;
  delete pSavoirArray ;
  delete pPatPathoArray ;

  pNSTreeWindow->LibereBBitemLanceur() ;
  delete pNSTreeWindow ;
  delete pListWind ;
}

//
//
//
void
NSsmEditeur::SetupWindow()
{
    // Initialize base class
    //
    //
    //mettre sLexiquePilote � vide pour ne pas �craser la patpatho dans
    //lanceConsult
    //
    if (!pPatPathoArray->empty())
        pBigBoss->lanceConsult("", pNSTreeWindow) ;
    else
  	    pBigBoss->lanceConsult(sLexiquePilote, pNSTreeWindow) ;

    TPaneSplitter::SetupWindow() ;
    pNSTreeWindow->SetupWindow() ;
    SplitPane(pNSTreeWindow, pListWind, psVertical) ;

    //dispatcher la patpatho
    pNSTreeWindow->DispatcherPatPatho(pPatPathoArray, 0, 0, "") ;

    if (!pBigBoss->getPatPatho()->empty())
		pBigBoss->MetTitre() ;

    // Initialize pListWind
    //
    TListWindColumn Lien("Lien s�mantique", 100) ;
    pListWind->InsertColumn(0, Lien) ;
    TListWindColumn Equivalent("Equivalent s�mantique", 150) ;
    pListWind->InsertColumn(1, Equivalent) ;

    // Remplis la ListWind
    //
    AfficheListe() ;
}

//
//
//
void
NSsmEditeur::CleanupWindow()
{
    // Cleanup the base class
    //
    TPaneSplitter::CleanupWindow() ;
}

void
NSsmEditeur::EvClose()
{
    TPaneSplitter::EvClose();
}

voidNSsmEditeur::initPatPatho()
{
    pPatPathoArray->vider() ;
    // char chAffiche[200], dateAffiche[20] ;
    //
	// Cr�ation d'un objet d'acc�s au fichier CR
	//
	NSSavFiche* pCR = new NSSavFiche(pContexte) ;
	//
	// Ouverture du fichier
	//
	pCR->lastError = pCR->open() ;
	if (pCR->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier de donn�es.", 0, pCR->lastError) ;
		delete pCR ;
		return ;
	}
    //
    // Recherche de la premi�re fiche
    //
    string cle = sLexiquePilote + string(BASE_LOCALISATION_LEN, ' ') ;

    pCR->lastError = pCR->chercheClef(  &cle,
                                        "",
                                        0,
                                        keySEARCHGEQ,
                                        dbiWRITELOCK) ;
    if (pCR->lastError != DBIERR_NONE)
	{
        erreur("Il n'existe pas de fiche pour cet �l�ment.", 0, pCR->lastError) ;
        pCR->close() ;
		delete pCR ;
		return ;
	}
    pCR->lastError = pCR->getRecord() ;
    if (pCR->lastError != DBIERR_NONE)
	{
		erreur("Le fichier de donn�es est d�fectueux.", 0, pCR->lastError) ;
        pCR->close();
		delete pCR;
		return;
	}
    if (strcmp(sLexiquePilote.c_str(), pCR->pDonnees->sens) != 0)
    {
        erreur("Il n'existe pas de fiche pour cet �l�ment.", 0, pCR->lastError);
        pCR->close();
		delete pCR;
		return;
    }
    //
    // On avance dans le fichier tant que les fiches trouv�es appartiennent
    // � ce compte rendu
    //
    while ((pCR->lastError != DBIERR_EOF) &&
   		 (strcmp(sLexiquePilote.c_str(), pCR->pDonnees->sens) == 0))
    {
        pPatPathoArray->push_back(new NSPatPathoInfo(pCR));
        pCR->lastError = pCR->suivant(dbiWRITELOCK);
        if ((pCR->lastError != DBIERR_NONE) && (pCR->lastError != DBIERR_EOF))
        {
            erreur("Pb d'acces a la fiche suivante.", 0, pCR->lastError);
      	    pCR->close();
			delete pCR;
			return;
		}

        if (pCR->lastError != DBIERR_EOF)
        {
   		    pCR->lastError = pCR->getRecord();
   		    if (pCR->lastError != DBIERR_NONE)
			{
                erreur("Le fichier de donn�es est d�fectueux.", 0, pCR->lastError);
      		    pCR->close();
				delete pCR;
				return;
            }
        }
    }
    //
    // Fermeture du fichier
    //
    pCR->close();
    delete pCR;

	return;
}

voidNSsmEditeur::CmEnregistre()
{
   pNSTreeWindow->okFermerDialogue();
   pNSTreeWindow->EnregistrePatPatho(pBigBoss);
   if (!pBigBoss->getPatPatho()->empty())
		pBigBoss->MetTitre();
	enregPatPatho();
}

boolNSsmEditeur::enregPatPatho()
{
    bool existeInfo = true;
	//
	// Cr�ation d'un objet d'acc�s au fichier CR
	//
	NSSavFiche* pCR = new NSSavFiche(pContexte);
	//
	// Ouverture du fichier
	//
	pCR->lastError = pCR->open();
	if (pCR->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier de fiches.", 0, pCR->lastError);
		delete pCR;
		return false;
	}
    //
	// On efface d'abord les anciennes donn�es
	//
    string cle = sLexiquePilote + string(BASE_LOCALISATION_LEN, ' ');
    bool effacer = true;
    while (effacer)
    {
   	    effacer = false;
        pCR->lastError = pCR->chercheClef(&cle,
                                            "",
                                            0,
                                            keySEARCHGEQ,
                                            dbiWRITELOCK);
        if (pCR->lastError == DBIERR_NONE)
        {
      	    pCR->lastError = pCR->getRecord();
            if (pCR->lastError == DBIERR_NONE)
         	    if (strcmp(sLexiquePilote.c_str(), pCR->pDonnees->sens) == 0)
            	    effacer = true;
        }
        if (effacer)
        {
      	    pCR->lastError = pCR->deleteRecord();
            if (pCR->lastError != DBIERR_NONE)
         	    effacer = false;
        }
    }
    //
    // Stockage de la PatPathoArray dans la base
    //
    for (PatPathoIter iJ = pPatPathoArray->begin(); iJ != pPatPathoArray->end(); iJ++)
    {
   	    *((NSPathoBaseData*)pCR->pDonnees) = *((NSPathoBaseData*)(*iJ)->pDonnees);
        strcpy(pCR->pDonnees->sens, sLexiquePilote.c_str());

        pCR->lastError = pCR->appendRecord();
        if (pCR->lastError != DBIERR_NONE)
        {
      	    erreur("Erreur � la sauvegarde des donn�es.", 0, pCR->lastError);
            delete pCR;
            return false;
        }
    }
    //
    // Fermeture de la base
    //
    pCR->close();
    delete pCR;
    return existeInfo;
}

voidNSsmEditeur::initSavoir()
{
	pSavoirArray->vider();
    // char chAffiche[200], dateAffiche[20];
    //
	// Cr�ation d'un objet d'acc�s au fichier CR
	//
	NSSavoir* pSavoir = new NSSavoir(pContexte);
	//
	// Ouverture du fichier
	//
	pSavoir->lastError = pSavoir->open();
	if (pSavoir->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du r�seau s�mantique.", 0, pSavoir->lastError);
		delete pSavoir;
		return;
	}
    //
    // Recherche de la premi�re fiche
    //
    CURProps curProps;
    pSavoir->lastError = DbiGetCursorProps(pSavoir->PrendCurseur(), curProps);

    Byte* pIndexRec = new Byte[curProps.iRecBufSize];
    memset(pIndexRec, 0, curProps.iRecBufSize);

    string sLienBlanc = string(SAVOIR_LIEN_LEN, ' ');
    DbiPutField(pSavoir->PrendCurseur(), SAVOIR_LIEN_FIELD, pIndexRec,(Byte*)(sLienBlanc.c_str()));
    DbiPutField(pSavoir->PrendCurseur(), SAVOIR_QUALIFIE_FIELD , pIndexRec, (Byte*)(sLexiquePilote.c_str()));

    pSavoir->lastError = pSavoir->chercheClefComposite("FLECHE",
														NODEFAULTINDEX,
                                          				keySEARCHGEQ,
                                          				dbiWRITELOCK,
                                          				pIndexRec);

    if (pSavoir->lastError != DBIERR_NONE)
	{
        erreur("Il n'existe pas de fiche s�mantique pour cet �l�ment.", 0, pSavoir->lastError);
        pSavoir->close();
        delete[] pIndexRec;
		delete pSavoir;
		return;
    }
    pSavoir->lastError = pSavoir->getRecord();
    if (pSavoir->lastError != DBIERR_NONE)
	{
        erreur("Le fichier de r�seau s�mantique est d�fectueux.", 0, pSavoir->lastError);
        pSavoir->close();
        delete[] pIndexRec;
		delete pSavoir;
		return;
    }
    if (strcmp(sLexiquePilote.c_str(), pSavoir->pDonnees->qualifie) != 0)
    {
        erreur("Il n'existe pas de fiche s�mantique pour cet �l�ment.", 0, pSavoir->lastError);
        pSavoir->close();
        delete[] pIndexRec;
		delete pSavoir;
		return;
    }
    //
    // On avance dans le fichier tant que les fiches trouv�es appartiennent
    // � ce compte rendu
    //
    while ((pSavoir->lastError != DBIERR_EOF) &&
   		 (strcmp(sLexiquePilote.c_str(), pSavoir->pDonnees->qualifie) == 0))
	{
        pSavoirArray->push_back(new NSSavoirInfo(pSavoir));
        pSavoir->lastError = pSavoir->suivant(dbiWRITELOCK);
        if ((pSavoir->lastError != DBIERR_NONE) && (pSavoir->lastError != DBIERR_EOF))
		{
            erreur("Pb d'acces a la fiche suivante du r�seau s�mantique.", 0, pSavoir->lastError);
      	    pSavoir->close();
            delete[] pIndexRec;
			delete pSavoir;
			return;
        }

        if (pSavoir->lastError != DBIERR_EOF)
        {
   		    pSavoir->lastError = pSavoir->getRecord();
   		    if (pSavoir->lastError != DBIERR_NONE)
			{
                erreur("Le fichier de donn�es du r�seau s�mantique est d�fectueux.", 0, pSavoir->lastError);
      		    pSavoir->close();
                delete[] pIndexRec;
				delete pSavoir;
				return;
            }
        }
    }
    //
    // Fermeture du fichier
    //
    pSavoir->close();
    delete[] pIndexRec;
    delete pSavoir;

	return;
}

//---------------------------------------------------------------------------//  Description: Affiche le tableau de patients dans la liste
//---------------------------------------------------------------------------
void
NSsmEditeur::AfficheListe()
{
    pListWind->DeleteAllItems();
    for (SavInfoIter iJ = pSavoirArray->begin(); iJ != pSavoirArray->end(); iJ++)    {
        string sEtiquette;
        string sQualificatif = (*iJ)->pDonnees->lien;
        string sQualifie		= (*iJ)->pDonnees->qualifiant;
        donneRelation(&sQualificatif, &sQualifie, &sEtiquette);
   	    TListWindItem Item(sEtiquette.c_str(), 0);
        pListWind->InsertItem(Item);
    }
}

//
// Callback notification to handle additional column information
// for each item.
// Dans ce cas, ajoute le qualifiant
//
void
NSsmEditeur::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
  	const int BufLen = 255;
  	static char buffer[BufLen];
  	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item;

  	int index = dispInfoItem.GetIndex();  	string sQualif 	= "";
  	string sLibelle = "";
  	int 	iGenre = 0;

  	// Affiche les informations en fonction de la colonne
  	switch (dispInfoItem.GetSubItem())
  	{
  		case 1: 	// qualifiant
            string sLang = "";
            if ((pContexte) && (pContexte->getUtilisateur()))
                sLang = pContexte->getUtilisateur()->donneLang();

      	    sQualif = string(((*pSavoirArray)[index])->pDonnees->qualifiant) + string("1");
        	pContexte->getDico()->donneLibelle(sLang, &sQualif, &sLibelle, NSDico::affiche, &iGenre);
        	sprintf(buffer, "%s", sLibelle.c_str());
        	dispInfoItem.SetText(buffer);
        	break;
  	}
}

void
NSsmEditeur::donneRelation(string* pQualificatif, string* pQualifie, string* pEtiquette)
{
	char cQualif = (*pQualifie)[0];
    char cPilote = sLexiquePilote[0];

    if (*pQualificatif == "ES")
    {
   	    *pEtiquette = "est un";
        return;
    }

    if (*pQualificatif == "ME")
    {
   	    switch (cPilote)
   	    {
   		    case 'V' :
      		    switch (cQualif)
         	    {
         		    case '2' : *pEtiquette = "se mesure en"; break;
         	    }
      		    break;
            case 'G' :
      		    switch (cQualif)
         	    {
         		    case 'V' : *pEtiquette = "sert � mesurer"; break;
         	    }
      		    break;
            case 'O' :
      		    switch (cQualif)
         	    {
         		    case 'G' : *pEtiquette = "instrument de mesure de"; break;
         	    }
      		    break;
            case 'B' :
      		    switch (cQualif)
         	    {
         		    case 'V' : *pEtiquette = "sert � mesurer"; break;
         	    }
      		    break;
        }
        return;
    }

    if (*pQualificatif == "AT")
    {
   	    switch (cPilote)
   	    {
   		    case 'P' :
      		    switch (cQualif)
         	    {
         		    case 'A' : *pEtiquette = "atteint"; break;
                    case 'H' : *pEtiquette = "atteint"; break;
         	    }
      		    break;
            case 'G' :
      		    switch (cQualif)
         	    {
         		    case 'P' : *pEtiquette = "s'applique �"; break;
                    case 'A' : *pEtiquette = "s'effectue sur"; break;
         	    }
      		    break;
            case 'A' :
      		    switch (cQualif)
         	    {
                    case 'A' : *pEtiquette = "est une partie de"; break;
         	    }
      		    break;
        }
        return;
    }
}

//***************************************************************************
//
//  		  M�thodes de NSProposEdit//
//***************************************************************************
NSProposEdit::NSProposEdit(Cproposition* prop)
{
    Val_iter ival;

    name = prop->getStringAttribute(ATTRIBUT_PROP_NOM);
    group = prop->getStringAttribute(ATTRIBUT_PROP_GROUPE);
    pTreeArray = new NSVectPatPathoArray();
    nbTrees = 0;

    for (ival = prop->getValArray()->begin(); ival != prop->getValArray()->end(); ival++)
    {
        if ((*ival)->sLabel == LABEL_VALIDITE)
        {
            // en principe il n'y a qu'une seule clause validite (sans attributs)
            // on r�cup�re la string de validite telle quelle
            validity = (*ival)->sValue;
        }
        else if ((*ival)->sLabel == LABEL_TREE)
        {
            Ctree* pCtree = dynamic_cast<Ctree*>((*ival)->pObject);
            pTreeArray->push_back(new NSPatPathoArray(*(pCtree->pPatPathoArray)));
            nbTrees++;
        }
    }
}

NSProposEdit::NSProposEdit()
{
    name = "";
    group = "";
    validity = "";
    pTreeArray = new NSVectPatPathoArray();
    nbTrees = 0;
}

NSProposEdit::~NSProposEdit()
{
    delete pTreeArray;
}

NSProposEdit::NSProposEdit(NSProposEdit& rv)
{
    name = rv.name;
    group = rv.group;
    validity = rv.validity;
    pTreeArray = new NSVectPatPathoArray(*(rv.pTreeArray));
    nbTrees = rv.nbTrees;
}

NSProposEdit&
NSProposEdit::operator=(NSProposEdit src)
{
    name = src.name;
    group = src.group;
    validity = src.validity;
    pTreeArray = new NSVectPatPathoArray(*(src.pTreeArray));
    nbTrees = src.nbTrees;

    return *this;
}

// Classe NSProposEditArray
////////////////////////////////////////////////////

//---------------------------------------------------------------------------
//  Constructeur copie//---------------------------------------------------------------------------
NSProposEditArray::NSProposEditArray(NSProposEditArray& rv) : NSProposEditVector(){    if (!rv.empty())	    for (NSProposEditIter i = rv.begin(); i != rv.end(); i++)   	        push_back(new NSProposEdit(*(*i)));}
NSProposEditArray&
NSProposEditArray::operator=(NSProposEditArray src)
{    if (!src.empty())	    for (NSProposEditIter i = src.begin(); i != src.end(); i++)   	        push_back(new NSProposEdit(*(*i)));    return *this;}

//---------------------------------------------------------------------------//  Destructeur//---------------------------------------------------------------------------
voidNSProposEditArray::vider(){    if (!empty())	    for (NSProposEditIter i = begin(); i != end(); )        {   	        delete *i;            erase(i);        }}
NSProposEditArray::~NSProposEditArray(){	vider();}


//***************************************************************************
//
//  		  M�thodes de NSListPropWindow//
//***************************************************************************
DEFINE_RESPONSE_TABLE1(NSListPropWindow, TListWindow)   EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

//---------------------------------------------------------------------------//  Function: NSListPropWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------

voidNSListPropWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
    TLwHitTestInfo info(point);

    HitTest(info);
    if (info.GetFlags() & LVHT_ONITEM)        pDlg->CmEditProp();
}

//---------------------------------------------------------------------------//  Function: NSListPropWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------

intNSListPropWindow::IndexItemSelect()
{
    int count = GetItemCount();
    int index = -1;

    for (int i = 0; i < count; i++)   	    if (GetItemState(i, LVIS_SELECTED))
        {
      	    index = i;
            break;
        }

    return index;}

//***************************************************************************//
//  M�thodes de NSRefEditeur
//
//***************************************************************************

DEFINE_RESPONSE_TABLE1(NSRefEditeur, NSUtilDialog)
    EV_LV_DISPINFO_NOTIFY(IDC_RE_LVIEW, LVN_GETDISPINFO, DispInfoListeProp),
    EV_COMMAND(IDC_RE_NEWREF, CmReferentiel),
    EV_COMMAND(IDC_RE_PROPHAUT, CmHaut),
    EV_COMMAND(IDC_RE_PROPBAS, CmBas),
    EV_COMMAND(IDC_RE_ADDPROP, CmAjouter),
    EV_COMMAND(IDC_RE_DELPROP, CmSupprimer),
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

NSRefEditeur::NSRefEditeur(TWindow* pere, NSContexte* pCtx)
                :NSUtilDialog(pere, pCtx, "IDD_REFEDIT", pNSResModule)
{
    pRefName = new TEdit(this, IDC_RE_REFNAME);
    pListProp = new NSListPropWindow(this, IDC_RE_LVIEW);
    pPropArray = new NSProposEditArray;
    pParseur = 0;
    bIsModif = false;
    nbProp = 0;
}

NSRefEditeur::~NSRefEditeur()
{
    delete pRefName;
    delete pListProp;
    delete pPropArray;
    if (pParseur)
        delete pParseur;
}

void
NSRefEditeur::SetupWindow()
{
    NSUtilDialog::SetupWindow();
    InitListeProp();
}

void
NSRefEditeur::InitListeProp()
{
    TListWindColumn colName("Nom", 280, TListWindColumn::Left, 0);
  	pListProp->InsertColumn(0, colName);

    TListWindColumn colGroup("Groupe", 200, TListWindColumn::Left, 1);  	pListProp->InsertColumn(1, colGroup);
}

void
NSRefEditeur::AfficheListeProp()
{
    pListProp->DeleteAllItems();

	for (int i = nbProp - 1; i >= 0; i--)    {
        TListWindItem Item((((*pPropArray)[i])->name).c_str(), 0);
        pListProp->InsertItem(Item);
    }
}

void
NSRefEditeur::DispInfoListeProp(TLwDispInfoNotify& dispInfo)
{
    const int 	    BufLen = 255;
    static char     buffer[BufLen];
    TListWindItem&  dispInfoItem = *(TListWindItem*)&dispInfo.item;
    int 			index;

    index = dispInfoItem.GetIndex();
    // Affiche les informations en fonction de la colonne    switch (dispInfoItem.GetSubItem())
    {
   	    case 1: // groupe
         strcpy(buffer, (((*pPropArray)[index])->group).c_str());
         dispInfoItem.SetText(buffer);
         break;
    }
}

void
NSRefEditeur::EcrireTree(NSPatPathoArray* pPatPathoArray, string& sOut)
{
    int col, colPrec, k, j;

    // on prend pour l'instant un arbre d'objectif par d�faut
    sOut += string("<") + string(LABEL_TREE) + string(" localisation = \"ZPOMR/0OBJE\">\n");
    colPrec = -1;

    for (PatPathoIter i = pPatPathoArray->begin(); i != pPatPathoArray->end(); i++)
    {
        col = (*i)->pDonnees->getColonne();
        for (k = 0; k < col; k++)
            sOut += string("\t");

        // fermer les blocs pr�c�dents
        if (col <= colPrec)
        {
            for (k = colPrec; k >= col; k--)
            {
                for (j = 0; j < k; j++)
                    sOut += string("\t");

                sOut += string("</") + string(LABEL_NODE) + string(">\n");
            }
        }

        sOut += string("<") + string(LABEL_NODE) + string(" ");

        // donnees obligatoires
        sOut += string(ATTRIBUT_NODE_LOC) + string(" = \"") + string((*i)->pDonnees->codeLocalisation) + string("\" ");
        if (strcmp((*i)->pDonnees->type, ""))
            sOut += string(ATTRIBUT_NODE_TYPE) + string(" = \"") + string((*i)->pDonnees->type) + string("\" ");
        sOut += string(ATTRIBUT_NODE_LEXIQUE) + string(" = \"") + texteHtml(string((*i)->pDonnees->lexique)) + string("\" ");

        // textes libres ou complement
        if (!strcmp((*i)->pDonnees->lexique, "�?????"))
        {
            sOut += string(ATTRIBUT_NODE_COMPLEMENT) + string(" = \"");
            string sTexteLibre = (*i)->pDonnees->getTexteLibre();
            sOut += texteHtml(sTexteLibre) + string("\" ");
        }
        else if (strcmp((*i)->pDonnees->complement, ""))
        {
            sOut += string(ATTRIBUT_NODE_COMPLEMENT) + string(" = \"");
            sOut += texteHtml(string((*i)->pDonnees->complement)) + string("\" ");
        }

        // donnees annexes
        if (strcmp((*i)->pDonnees->certitude, ""))
        {
            sOut += string(ATTRIBUT_NODE_CERTITUDE) + string(" = \"");
            sOut += texteHtml(string((*i)->pDonnees->certitude)) + string("\" ");
        }

        if (strcmp((*i)->pDonnees->interet, ""))
        {
            sOut += string(ATTRIBUT_NODE_INTERET) + string(" = \"");
            sOut += texteHtml(string((*i)->pDonnees->interet)) + string("\" ");
        }

        if (strcmp((*i)->pDonnees->pluriel, ""))
        {
            sOut += string(ATTRIBUT_NODE_PLURIEL) + string(" = \"");
            sOut += texteHtml(string((*i)->pDonnees->pluriel)) + string("\" ");
        }

        sOut += string(">\n");

        colPrec = col;
    }

    // fermer les derniers blocs jusqu'� la colonne 0
    for (k = colPrec; k >= 0; k--)
    {
        for (j = 0; j < k; j++)
            sOut += string("\t");

        sOut += string("</") + string(LABEL_NODE) + string(">\n");
    }

    sOut += string("</") + string(LABEL_TREE) + string(">\n");
}

void
NSRefEditeur::CmReferentiel()
{
	if (true == bIsModif)
	{
		string sCaption = string("Message ") + pContexte->getSuperviseur()->sAppName.c_str() ;
		int idRet = MessageBox("Attention un r�f�rentiel est d�j� ouvert et a �t� modifi�. Voulez-vous le sauvegarder ?", sCaption.c_str(), MB_YESNO);
		if (idRet == IDYES)
			CmSauvegarde() ;
	}

	char path[1024] ;
	strcpy(path, (pContexte->PathName("IXML")).c_str()) ;

	TFileOpenDialog::TData initData(OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,                                  "Tous fichiers (*.XML)|*.xml|",
                                  0, path, "XML") ;

	int iUserChoice = TFileOpenDialog(pContexte->GetMainWindow(), initData).Execute() ;
	pContexte->reallocateBaseDirectory() ;

	if (IDOK != iUserChoice)
		return ;

	sFileName = string(initData.FileName) ;
	if (pParseur)
		delete pParseur ;

	pParseur = new nsrefParseur(pContexte) ;

	if (!pParseur->open(sFileName))
	{
		string sCaption = string("Message ") + pContexte->getSuperviseur()->sAppName.c_str();
    MessageBox("Erreur de parsing du r�f�rentiel", sCaption.c_str(), MB_OK);
    return;
	}

	pPropArray->vider() ;
	nbProp = 0 ;

	if (false == pParseur->pReferentiel->getValArray()->empty())
	{
		Val_iter ival;
		// on instancie l'ensemble des propositions
		for (ival = pParseur->pReferentiel->getValArray()->begin(); ival != pParseur->pReferentiel->getValArray()->end(); ival++)
		{
  		if ((*ival)->sLabel == LABEL_PROPOSITION)
    	{    		Cproposition* pCprop = dynamic_cast<Cproposition*>((*ival)->pObject);      	pPropArray->push_back(new NSProposEdit(pCprop));      	nbProp++;    	}		}
	}

	AfficheListeProp() ;
	pRefName->SetText(sFileName.c_str()) ;
}

void
NSRefEditeur::CmEditProp()
{
    int propChoisie = pListProp->IndexItemSelect();

    if (propChoisie == -1)
    {
        erreur("Vous devez s�lectionner une proposition � �diter.", 0, 0);
        return;
    }

    NSPropEditeur* pDlg = new NSPropEditeur(this, pContexte, (*pPropArray)[propChoisie]);
    int idRet = pDlg->Execute();

    if (idRet == IDOK)
    {
        if (!bIsModif)
            bIsModif = pDlg->bIsModif;

        if (bIsModif)
            *((*pPropArray)[propChoisie]) = *(pDlg->pPropos);

        AfficheListeProp();
    }

    delete pDlg;
}

void
NSRefEditeur::CmHaut()
{
    int propChoisie = pListProp->IndexItemSelect();

    if (propChoisie == -1)
    {
        erreur("Vous devez s�lectionner une proposition � d�placer.", 0, 0);
        return;
    }

    if (propChoisie == 0)
        return;

    NSProposEdit propos = *((*pPropArray)[propChoisie]);
    *((*pPropArray)[propChoisie]) = *((*pPropArray)[propChoisie - 1]);
    *((*pPropArray)[propChoisie - 1]) = propos;

    AfficheListeProp();

    pListProp->SetFocus();
    pListProp->SetSel(propChoisie-1, true);
    pListProp->EnsureVisible(propChoisie-1, true);
}

void
NSRefEditeur::CmBas()
{
    int propChoisie = pListProp->IndexItemSelect();

    if (propChoisie == -1)
    {
        erreur("Vous devez s�lectionner une proposition � d�placer.", 0, 0);
        return;
    }

    if (propChoisie == nbProp - 1)
        return;

    NSProposEdit propos = *((*pPropArray)[propChoisie]);
    *((*pPropArray)[propChoisie]) = *((*pPropArray)[propChoisie + 1]);
    *((*pPropArray)[propChoisie + 1]) = propos;

    AfficheListeProp();

    pListProp->SetFocus();
    pListProp->SetSel(propChoisie+1, true);
    pListProp->EnsureVisible(propChoisie+1, true);
}

void
NSRefEditeur::CmAjouter()
{
    // on prend une proposition vierge
    NSProposEdit* prop = new NSProposEdit();

    NSPropEditeur* pDlg = new NSPropEditeur(this, pContexte, prop);
    int idRet = pDlg->Execute();

    if (idRet == IDOK)
    {
        if (!bIsModif)
            bIsModif = pDlg->bIsModif;

        if (bIsModif)
        {
            pPropArray->push_back(new NSProposEdit(*(pDlg->pPropos)));
            nbProp++;
        }

        AfficheListeProp();
    }

    delete pDlg;
    delete prop;
}

void
NSRefEditeur::CmSupprimer()
{
    int propChoisie = pListProp->IndexItemSelect();
    int index = 0;

    if (propChoisie == -1)
    {
        erreur("Vous devez s�lectionner une proposition � supprimer.", 0, 0);
        return;
    }

    if (!pPropArray->empty())
    for (NSProposEditIter i = pPropArray->begin(); i != pPropArray->end(); i++)
    {
        if (index == propChoisie)
        {
            delete (*i);
            pPropArray->erase(i);
            nbProp--;
            break;
        }

        index++;
    }

    AfficheListeProp();
}

void
NSRefEditeur::CmSauvegarde()
{
    char filename[256];
    ofstream outFile;
    string sOut = "";

    pRefName->GetText(filename, 255);
    if (sFileName != string(filename))
        sFileName = string(filename);

    sOut += string("<") + string(LABEL_REFERENTIEL) + string(">\n");

    if (!pPropArray->empty())
    for (NSProposEditIter i = pPropArray->begin(); i != pPropArray->end(); i++)
    {
        sOut += string("<") + string(LABEL_PROPOSITION) + string(" ");
        sOut += string(ATTRIBUT_PROP_NOM) + string(" = \"") + texteHtml((*i)->name) + string("\"");

        if ((*i)->group != "")
        {
            sOut += string(" ") + string(ATTRIBUT_PROP_GROUPE) + string(" = \"");
            sOut += texteHtml((*i)->group) + string("\"");
        }

        sOut += string(">\n");

        // clause de validit�
        if ((*i)->validity != "")
        {
            sOut += string("<") + string(LABEL_VALIDITE) + string(">\n");
            sOut += (*i)->validity + string("\n");
            sOut += string("</") + string(LABEL_VALIDITE) + string(">\n");
        }

        if (!((*i)->pTreeArray->empty()))
        {
            for (PatPathoIterVect k = (*i)->pTreeArray->begin(); k != (*i)->pTreeArray->end(); k++)
            {
                // (*k) est un pPatPathoArray
                if (!((*k)->empty()))
                    EcrireTree(*k, sOut);
            }
        }

        sOut += string("</") + string(LABEL_PROPOSITION) + string(">\n");
    }

    sOut += string("</") + string(LABEL_REFERENTIEL) + string(">\n");

    // �criture sur disque
    outFile.open(sFileName.c_str());
    if (!outFile)
    {
        erreur("Impossible de cr�er le fichier r�f�rentiel � sauvegarder", 0, 0);
        return;
    }

    for (size_t i = 0; i < strlen(sOut.c_str()); i++)
        outFile.put(sOut[i]);

	outFile.close();
}

void
NSRefEditeur::CmOk()
{
    if (bIsModif)
    {
        string sCaption = string("Message ") + pContexte->getSuperviseur()->sAppName.c_str();
        int idRet = MessageBox("Le r�f�rentiel a �t� modifi�. Voulez-vous le sauvegarder ?", sCaption.c_str(), MB_YESNO);
        if (idRet == IDYES)
            CmSauvegarde();
    }

    TDialog::CmOk();
}

void
NSRefEditeur::CmCancel()
{
    TDialog::CmCancel();
}

//***************************************************************************
//
//  M�thodes de NSPropEditeur
//
//***************************************************************************

DEFINE_RESPONSE_TABLE1(NSPropEditeur, NSUtilDialog)
    EV_COMMAND(IDC_PE_NEXTTREE, CmSuivant),
    EV_COMMAND(IDC_PE_PREVTREE, CmPrecedent),
    EV_COMMAND(IDC_PE_ADDTREE, CmAjouter),
    EV_COMMAND(IDC_PE_DELTREE, CmSupprimer),
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

NSPropEditeur::NSPropEditeur(TWindow* pere, NSContexte* pCtx, NSProposEdit* prop)
                :NSUtilDialog(pere, pCtx, "IDD_PROPEDIT", pNSResModule)
{
    pPropName = new TEdit(this, IDC_PE_PROPNAME);
    pPropGroup = new TEdit(this, IDC_PE_GROUPNAME);
    pTreeNum = new TEdit(this, IDC_PE_NUMTREE);
    pPropos = new NSProposEdit(*prop);
    noTree = 0;
    sPropName = prop->name;
    sPropGroup = prop->group;
    bIsModif = false;

    // Attr.Style |= (WS_CLIPSIBLINGS | WS_CLIPCHILDREN);
    pPatPathoArray = new NSPatPathoArray(pCtx);
    pBigBoss = 0;
    pNSTreeWindow = new NSTreeWindow(this, pCtx, IDC_PE_TVIEW, pNSResModule);
    // pNSTreeWindow->Attr.Style   |= WS_VISIBLE | TVS_HASLINES | TVS_HASBUTTONS | TVS_LINESATROOT;    // pNSTreeWindow->Attr.ExStyle |= WS_EX_CLIENTEDGE;
}

NSPropEditeur::~NSPropEditeur()
{
    delete pPropName;
    delete pPropGroup;
    delete pTreeNum;
    delete pPropos;
    delete pBigBoss;
    delete pPatPathoArray;

    pNSTreeWindow->LibereBBitemLanceur();    delete pNSTreeWindow;
}

void
NSPropEditeur::SetupWindow()
{
    char szIdTree[10];

    initPatPatho(0);

    TDialog::SetupWindow();

    pNSTreeWindow->DispatcherPatPatho(pPatPathoArray, 0, 0, "");

    pPropName->SetText(sPropName.c_str());    pPropGroup->SetText(sPropGroup.c_str());    sprintf(szIdTree, "1/%d", pPropos->nbTrees);    pTreeNum->SetText(szIdTree);}
void
NSPropEditeur::initPatPatho(int idTree)
{
    char szIdTree[10];

    pPatPathoArray->vider();

    if (pPropos->nbTrees > 0)
    {
        // r�cup�rer l'arbre n�idTree de la proposition
        *pPatPathoArray = *((*(pPropos->pTreeArray))[idTree]);

        // affichage de l'indice tree
        itoa(idTree+1, szIdTree, 10);
        sprintf(szIdTree, "%d/%d", idTree+1, pPropos->nbTrees);
        pTreeNum->SetText(szIdTree);
    }
    else // pas d'arbre => patpatho vide
        pTreeNum->SetText("1/1");

    if (pBigBoss)
        delete pBigBoss;
    pBigBoss = new NSSmallBrother(pContexte, pPatPathoArray);

    if (!pPatPathoArray->empty())
    {
        // ins�rer la racine "objectif" fictive ("titre" de l'arbre)
        strcpy(pBigBoss->lexiqueModule, "0OBJE1");
        // strcpy(pBigBoss->noeudModule, "");
        pBigBoss->MetTitre();
        pBigBoss->lanceConsult("", pNSTreeWindow);
        bWithTitle = true;
    }
    else // cas �dition patpatho vide : on passe un sLexiqueModule � lanceConsult
    {
        pBigBoss->lanceConsult("0OBJE1", pNSTreeWindow);
        bWithTitle = false;
    }
}

void
NSPropEditeur::rechargerPatPatho()
{
    // vider la patpatho affich�e
    pNSTreeWindow->SortieEditionDico();
    if (pNSTreeWindow->pEditDico)
    {
   	    delete pNSTreeWindow->pEditDico;
   	    pNSTreeWindow->pEditDico = 0;
    }
    pNSTreeWindow->SupprimerTousNoeuds();
    pNSTreeWindow->LibereBBitemLanceur();
    pNSTreeWindow->DeleteAllItems();

    // recharger la nouvelle en fonction de l'index tree
    initPatPatho(noTree);
    pNSTreeWindow->SetupWindow();
    pNSTreeWindow->DispatcherPatPatho(pPatPathoArray, 0, 0, "");
}

void
NSPropEditeur::sauverPatPatho()
{
    // stocker les modifs de la patpatho
    pNSTreeWindow->okFermerDialogue();

    // if (bWithTitle)
    // retirer la racine fictive
    pBigBoss->EnleverTitre();

    // on sauvegarde l'arbre en cours
    if (pPropos->nbTrees > 0)
        *((*(pPropos->pTreeArray))[noTree]) = *pPatPathoArray;
    else
    {
        // on sauve le nouvel arbre de proposition
        pPropos->pTreeArray->push_back(new NSPatPathoArray(*pPatPathoArray));
        pPropos->nbTrees++;
        noTree = 0;
    }
}

void
NSPropEditeur::CmSuivant()
{
    sauverPatPatho();

    if (pPropos->nbTrees <= 1)
        return;

    if (noTree < (pPropos->nbTrees - 1))
        noTree++;
    else
        noTree = 0;

    rechargerPatPatho();
}

void
NSPropEditeur::CmPrecedent()
{
    sauverPatPatho();

    if (pPropos->nbTrees <= 1)
        return;

    if (noTree > 0)
        noTree--;
    else
        noTree = pPropos->nbTrees - 1;

    rechargerPatPatho();
}

void
NSPropEditeur::CmAjouter()
{
    if (pPropos->nbTrees == 0)
    {
        string sCaption = string("Message ") + pContexte->getSuperviseur()->sAppName.c_str();
        MessageBox("Pour saisir le premier arbre de la proposition, clickez dans la fenetre d'�dition. Pour les suivants, clickez d'abord sur Ajouter.", sCaption.c_str(), MB_OK);
        return;
    }

    sauverPatPatho();

    pPatPathoArray->vider();
    pPropos->pTreeArray->push_back(new NSPatPathoArray(*pPatPathoArray));
    pPropos->nbTrees++;
    noTree = pPropos->nbTrees - 1;

    rechargerPatPatho();
}

void
NSPropEditeur::CmSupprimer()
{
    int index = 0;

    if (pPropos->nbTrees == 0)
        return;

    for (PatPathoIterVect i = pPropos->pTreeArray->begin(); i != pPropos->pTreeArray->end(); i++)
    {
        if (index == noTree)
        {
            delete (*i);
            pPropos->pTreeArray->erase(i);
            pPropos->nbTrees--;
            if (noTree > 0)
                noTree--;
            break;
        }

        index++;
    }

    pNSTreeWindow->okFermerDialogue();
    rechargerPatPatho();
}

void
NSPropEditeur::CmOk()
{
    char text[256];

    sauverPatPatho();

    pPropName->GetText(text, 255);
    if (string(text) != sPropName)
        pPropos->name = string(text);

    pPropGroup->GetText(text, 255);
    if (string(text) != sPropGroup)
        pPropos->group = string(text);

    bIsModif = true;
    TDialog::CmOk();
}

void
NSPropEditeur::CmCancel()
{
    bIsModif = false;
    TDialog::CmCancel();
}

//***************************************************************************
//
//  		  M�thodes de NSVarTag//
//***************************************************************************
NSVarTag::NSVarTag(string sName, string sValue)
{
    name = sName;
    value = sValue;
}

NSVarTag::~NSVarTag()
{
}

NSVarTag::NSVarTag(NSVarTag& rv)
{
    name = rv.name;
    value = rv.value;
}

NSVarTag&
NSVarTag::operator=(NSVarTag src)
{
    name = src.name;
    value = src.value;

    return *this;
}

// Classe NSVarTagArray
////////////////////////////////////////////////////

//---------------------------------------------------------------------------
//  Constructeur copie//---------------------------------------------------------------------------
NSVarTagArray::NSVarTagArray(NSVarTagArray& rv) : NSVarTagVector(){    if (!rv.empty())	for (NSVarTagIter i = rv.begin(); i != rv.end(); i++)   	    push_back(new NSVarTag(*(*i)));}
NSVarTagArray&
NSVarTagArray::operator=(NSVarTagArray src)
{    if (!src.empty())	for (NSVarTagIter i = src.begin(); i != src.end(); i++)   	    push_back(new NSVarTag(*(*i)));    return *this;}

//---------------------------------------------------------------------------//  Destructeur//---------------------------------------------------------------------------
voidNSVarTagArray::vider(){    if (!empty())	for (NSVarTagIter i = begin(); i != end(); )    {   	    delete *i;        erase(i);    }}
NSVarTagArray::~NSVarTagArray(){	vider();}

//***************************************************************************
//
//  		  M�thodes de NSEnTeteEditWindow//
//***************************************************************************
DEFINE_RESPONSE_TABLE1(NSEnTeteEditWindow, TListWindow)   EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

//---------------------------------------------------------------------------//  Function: NSEnTeteEditWindow::EvLButtonDblClk(uint modKeys, TPoint& point)
//
//  Arguments:	  les modKeys et le point double-click�
//
//  Description: Fonction de r�ponse au double-click
//
//  Returns:     Rien
//---------------------------------------------------------------------------

voidNSEnTeteEditWindow::EvLButtonDblClk(uint modKeys, NS_CLASSLIB::TPoint& point)
{
    TLwHitTestInfo info(point);

    HitTest(info);
    if (info.GetFlags() & LVHT_ONITEM)        pDlg->CmEditVarTag();
}

//---------------------------------------------------------------------------//  Function: NSEnTeteEditWindow::IndexItemSelect()
//
//  Arguments:	  Aucun
//
//  Description: Retourne l'index du premier item s�lectionn�
//
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------

intNSEnTeteEditWindow::IndexItemSelect()
{
    int count = GetItemCount();
    int index = -1;

    for (int i = 0; i < count; i++)   	    if (GetItemState(i, LVIS_SELECTED))
        {
      	    index = i;
            break;
        }

    return index;}

//***************************************************************************
//
//  M�thodes de NSEnTeteEditDialog
//
//***************************************************************************

DEFINE_RESPONSE_TABLE1(NSEnTeteEditDialog, NSUtilDialog)
    EV_LV_DISPINFO_NOTIFY(IDC_ENTETE_LW, LVN_GETDISPINFO, DispInfoListeVar),
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
    EV_COMMAND(IDHELP, CmHelp),
END_RESPONSE_TABLE;

NSEnTeteEditDialog::NSEnTeteEditDialog(TWindow* pere, NSContexte* pCtx, string filename)
                :NSUtilDialog(pere, pCtx, "IDD_ENTETE_EDIT", pNSResModule)
{
    pVarArray = new NSVarTagArray;
    nbVar = 0;
    sFileName = filename;
    pListeVar = new NSEnTeteEditWindow(this, IDC_ENTETE_LW);

    bParseOK = ParseModele();

    sHindex = "" ;
    sHcorps = "Edition_d_en_tete.html" ;
}

NSEnTeteEditDialog::~NSEnTeteEditDialog()
{
    delete pListeVar;
    delete pVarArray;
}

void
NSEnTeteEditDialog::SetupWindow()
{
    NSUtilDialog::SetupWindow();
    InitListeVar();
    AfficheListeVar();

    pContexte->setAideIndex(sHindex);
    pContexte->setAideCorps(sHcorps);
}

bool
NSEnTeteEditDialog::ParseModele()
{
    ifstream html_file;
	string  tmp_html_string;
    string  commentaire, name, tag, value;
    size_t  pos1, pos2;
    size_t  deb_tag, fin_tag, deb_val, fin_val;

	html_file.open(sFileName.c_str());

    if (!html_file)
    {
        string sErreur = string("Impossible d'ouvrir le fichier html (") +
                         sFileName + string(")");
        erreur(sErreur.c_str(), 0, 0);
        return false;
    }

	while (getline (html_file, tmp_html_string))
		html_string += tmp_html_string + '\n';
	html_file.close ();

    pos1 = html_string.find("<!--");

    while (pos1 != NPOS)
    {
        pos2 = html_string.find("-->", pos1 + 4);
        if (pos2 == NPOS)
        {
            erreur("Commentaire non ferm� dans le mod�le d'en-tete.", 0, 0);
            return false;
        }

        commentaire = string(html_string, pos1 + 4, pos2 - pos1 - 4);
        deb_tag = commentaire.find("$");
        if (deb_tag != NPOS)
        {
            fin_tag = commentaire.find("$", deb_tag + 1);
            if (fin_tag == NPOS)
            {
                erreur("Tag non ferm� dans le mod�le d'en-tete.", 0, 0);
                return false;
            }

            name = string(commentaire, deb_tag + 1, fin_tag - deb_tag - 1);

            // recherche du commentaire suivant, contenant la fin du tag name
            // (on r�cup�re au passage la valeur de la variable)
            pos1 = html_string.find("<!--", pos2 + 3);
            if (pos1 == NPOS)
            {
                erreur("Variable non referm�e dans le mod�le d'en-tete.", 0, 0);
                return false;
            }

            deb_val = pos2 + 3;
            fin_val = pos1;

            value = string(html_string, deb_val, fin_val - deb_val);
            tag = string("$/") + name + string("$");

            pos2 = html_string.find("-->", pos1 + 4);
            if (pos2 == NPOS)
            {
                erreur("Commentaire non ferm� dans le mod�le d'en-tete.", 0, 0);
                return false;
            }

            commentaire = string(html_string, pos1 + 4, pos2 - pos1 - 4);
            if (commentaire.find(tag) == NPOS)
            {
                erreur("Tag de fin de variable incorrect dans le mod�le d'en-tete.", 0, 0);
                return false;
            }

            // Ici la variable est correcte
            pVarArray->push_back(new NSVarTag(name, texteCourant(value)));
            nbVar++;
        }

        pos1 = html_string.find("<!--", pos2 + 3);
    }

    return true;
}

void
NSEnTeteEditDialog::InitListeVar()
{
    TListWindColumn colName("Nom de la variable", 150, TListWindColumn::Left, 0);
  	pListeVar->InsertColumn(0, colName);

    TListWindColumn colValue("Valeur dans l'en-tete", 350, TListWindColumn::Left, 1);  	pListeVar->InsertColumn(1, colValue);
}

void
NSEnTeteEditDialog::AfficheListeVar()
{
    pListeVar->DeleteAllItems();

	for (int i = nbVar - 1; i >= 0; i--)    {
        TListWindItem Item((((*pVarArray)[i])->name).c_str(), 0);
        pListeVar->InsertItem(Item);
    }
}

void
NSEnTeteEditDialog::DispInfoListeVar(TLwDispInfoNotify& dispInfo)
{
    const int 	    BufLen = 255;
    static char     buffer[BufLen];
    TListWindItem&  dispInfoItem = *(TListWindItem*)&dispInfo.item;
    int 			index;

    index = dispInfoItem.GetIndex();
    // Affiche les informations en fonction de la colonne    switch (dispInfoItem.GetSubItem())
    {
   	    case 1: // groupe
         strcpy(buffer, (((*pVarArray)[index])->value).c_str());
         dispInfoItem.SetText(buffer);
         break;
    }
}

void
NSEnTeteEditDialog::CmEditVarTag()
{
    int     varChoisie = pListeVar->IndexItemSelect();
    size_t  pos, deb_val, fin_val;

    if (varChoisie == -1)
    {
        erreur("Vous devez s�lectionner une variable � �diter.", 0, 0);
        return;
    }

    NSVarTagEditDialog* pDlg = new NSVarTagEditDialog(this, pContexte, (*pVarArray)[varChoisie]);
    int idRet = pDlg->Execute();

    if (idRet == IDOK)
    {
        string name = pDlg->pVarTag->name;
        string value = pDlg->pVarTag->value;
        string tagname = string("$") + name + string("$");

        pos = html_string.find(tagname);
        if (pos == NPOS)
        {
            erreur("Impossible de remplacer la variable dans le mod�le.", 0, 0);
            return;
        }

        deb_val = html_string.find("-->", pos + strlen(tagname.c_str()));
        if (deb_val == NPOS)
        {
            erreur("Impossible de remplacer la variable dans le mod�le.", 0, 0);
            return;
        }

        deb_val += 3;
        fin_val = html_string.find("<!--", deb_val);
        if (fin_val == NPOS)
        {
            erreur("Impossible de remplacer la variable dans le mod�le.", 0, 0);
            return;
        }

        // remplacement de la variable
        html_string.replace(deb_val, fin_val - deb_val, texteHtml(value));

        AfficheListeVar();
    }

    delete pDlg;
}

void
NSEnTeteEditDialog::CmOk()
{
    ofstream outFile;

    if (bParseOK)
    {
        string fichier = pContexte->PathName("NTPL") + string("entete_") +
                        string(pContexte->getUtilisateur()->pDonnees->indice) + string(".htm");

        outFile.open(fichier.c_str());        if (!outFile)
        {
   	        erreur("Erreur d'�criture du fichier d'en-tete.", 0, 0);            return;        }
        for (size_t i = 0; i < strlen(html_string.c_str()); i++)            outFile.put(html_string[i]);

        outFile.close();    }    NSUtilDialog::CmOk();
}

void
NSEnTeteEditDialog::CmCancel()
{
    NSUtilDialog::CmCancel();
}

void
NSEnTeteEditDialog::CmHelp()
{
    // Les valeurs de sHindex et sHcorps sont d�j� fix�es dans le contexte (SetupWindow)
    pContexte->NavigationAideEnLigne();
}

//***************************************************************************
//
//  M�thodes de NSVarTagEditDialog
//
//***************************************************************************

DEFINE_RESPONSE_TABLE1(NSVarTagEditDialog, NSUtilDialog)
    EV_COMMAND(IDOK, CmOk),
    EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

NSVarTagEditDialog::NSVarTagEditDialog(TWindow* pere, NSContexte* pCtx, NSVarTag* pVar)
                :NSUtilDialog(pere, pCtx, "IDD_VARTAG_EDIT", pNSResModule)
{
    pVarTag = pVar;
    pEditName = new TEdit(this, IDC_VARTAG_EDITNAME);
    pEditValue = new TEdit(this, IDC_VARTAG_EDITVALUE);
}

NSVarTagEditDialog::~NSVarTagEditDialog()
{
    delete pEditName;
    delete pEditValue;
}

void
NSVarTagEditDialog::SetupWindow()
{
    NSUtilDialog::SetupWindow();
    pEditName->SetText((pVarTag->name).c_str());
    pEditValue->SetText((pVarTag->value).c_str());
    pEditValue->SetFocus();
}

void
NSVarTagEditDialog::CmOk()
{
    char text[256];

    pEditName->GetText(text, 255);
    if (string(text) != pVarTag->name)
    {
        erreur("Vous ne pouvez pas modifier le nom de la variable.", 0, 0);
        return;
    }

    pEditValue->GetText(text, 255);
    if (string(text) != pVarTag->value)
        pVarTag->value = string(text);

    NSUtilDialog::CmOk();
}

void
NSVarTagEditDialog::CmCancel()
{
    NSUtilDialog::CmCancel();
}


//***************************************************************************
//
//  M�thodes de NSLexiqEditeur
//
//***************************************************************************

DEFINE_RESPONSE_TABLE1(NSLexiqEditeur, NSUtilDialog)
    EV_COMMAND(IDC_LEX_AJOUT, CmAjouter),
END_RESPONSE_TABLE;

NSLexiqEditeur::NSLexiqEditeur(TWindow* pere, NSContexte* pCtx, string* pAmmorce, string sLibel)
                :NSUtilDialog(pere, pCtx, "IDD_LEXEDIT", pNSResModule)
{
    pLexiLibelle    = new TEdit(this, IDC_LEX_LIBEL) ;
    pLexiType       = new TComboBox(this, IDC_LEX_TYPE) ;
    pLexiGrammaire  = new TComboBox(this, IDC_LEX_GRAM) ;
    pLexiListe      = new TListWindow(this, IDC_LEX_LIST) ;

    pAdd            = new TButton(this, IDC_LEX_AJOUT) ;
    // pReplace        = new TButton(this, IDC_LEX_REMPLACE) ;
    // pDelete         = new TButton(this, IDC_LEX_SUPPR) ;

    psAmmorce = pAmmorce ;

    sPartLib = sLibel ;
}

NSLexiqEditeur::~NSLexiqEditeur()
{
    delete pLexiLibelle ;
    delete pLexiType ;
    delete pLexiGrammaire ;
    delete pLexiListe ;

    delete pAdd ;
    // delete pReplace ;
    // delete pDelete ;
}

void
NSLexiqEditeur::SetupWindow()
{
    NSUtilDialog::SetupWindow();

    pLexiType->InsertString("2 - Unit�", 0) ;
    pLexiType->InsertString("1 - Adjectif", 0) ;
    pLexiType->InsertString("Z - Document", 0) ;
    pLexiType->InsertString("Y - Psy", 0) ;
    pLexiType->InsertString("V - Donn�e chiffr�e", 0) ;
    pLexiType->InsertString("U - Lieu", 0) ;
    pLexiType->InsertString("T - Examen de labo", 0) ;
    pLexiType->InsertString("S - Sympt�me", 0) ;
    pLexiType->InsertString("R - Bestiole", 0) ;
    pLexiType->InsertString("Q - Physiologie", 0) ;
    pLexiType->InsertString("P - Pathologie", 0) ;
    pLexiType->InsertString("O - Mat�riel", 0) ;
    pLexiType->InsertString("N - Traitement", 0) ;
    pLexiType->InsertString("M - Mouvement, position", 0) ;
    pLexiType->InsertString("L - Administratif", 0) ;
    pLexiType->InsertString("K - Temps", 0) ;
    pLexiType->InsertString("J - Grades", 0) ;
    pLexiType->InsertString("I - M�dicament", 0) ;
    pLexiType->InsertString("H - Personne", 0) ;
    pLexiType->InsertString("G - Geste", 0) ;
    pLexiType->InsertString("F - Malformation", 0) ;
    pLexiType->InsertString("E - Etat", 0) ;
    pLexiType->InsertString("D - Professionel de sant�", 0) ;
    pLexiType->InsertString("B - Biologie", 0) ;
    pLexiType->InsertString("A - Anatomie", 0) ;

    pLexiGrammaire->InsertString("MP  - Nom Masculin pluriel", 0) ;
    pLexiGrammaire->InsertString("MS  - Nom Masculin singulier", 0) ;
    pLexiGrammaire->InsertString("FP  - Nom F�minin pluriel", 0) ;
    pLexiGrammaire->InsertString("FS  - Nom F�minin singulier", 0) ;
    pLexiGrammaire->InsertString("INV - Invariable", 0) ;
    pLexiGrammaire->InsertString("ADJ - Adjectif", 0) ;

    pLexiLibelle->SetText(sPartLib.c_str()) ;

    initSynonymsList() ;
}

void
NSLexiqEditeur::CmAjouter()
{
    if (!psAmmorce || (*psAmmorce == ""))
    {
        trouveAmmorce() ;
        if (!psAmmorce || (*psAmmorce == ""))
            return ;
    }

    char text[256] ;

    pLexiLibelle->GetText(text, 255);
    if (text[0] == '\0')
    {
        erreur("Avec un libell�, c'est mieux (non mais !)", 0, 0) ;
        return ;
    }
    if (strlen(text) > PATHO_LIBELLE_LEN)
    {
        erreur("Le texte est trop long (ben oui !).", 0, 0) ;
        return ;
    }
    string sLibelle = string(text) ;
    strip(sLibelle, stripBoth) ;

    string sGramm = "" ;
    pLexiGrammaire->GetText(text, 255) ;
    if (text[0] != '\0')
    {
        //sGramm = string(text) ;
        sGramm = string(text, 0, 3) ;
    }

    string sLang = "" ;
	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;

    NSPathologData* pData = new NSPathologData ;
    NSSuper* pSuper = pContexte->getSuperviseur() ;

    string sCodeSens ;
    pContexte->getDico()->donneCodeSens(psAmmorce, &sCodeSens) ;

    string  sCod = sCodeSens ;
    char    syno = '1' ;
    bool    tourner = true ;
    while ((tourner) && (sCod[0] != '\0'))
	{
        sCod = sCodeSens + string(1, syno) ;
		bool trouve = pSuper->pDico->trouvePathologData(sLang, &sCod, pData, false) ;
		if (trouve)
        {
		    syno++ ;
		    if 	  ((syno > '9') && (syno < 'A'))
			    syno = 'A' ;
		    else if (syno > 'Z')
            {
                erreur("Le compteur de synonymes est satur� (!)", 0, 0) ;
			    tourner = false ;
            }
        }
        else
            tourner = false ;
	}

    delete pData ;

    NSPatholog* pPathoLexique = pSuper->pDico->donnePatholog(sLang, &sCod) ;

    strcpy(pPathoLexique->pDonnees->libelle,    sLibelle.c_str()) ;
	strcpy(pPathoLexique->pDonnees->code, 	    sCod.c_str()) ;
	strcpy(pPathoLexique->pDonnees->grammaire,  sGramm.c_str()) ;
	strcpy(pPathoLexique->pDonnees->freq,       "") ;

    pPathoLexique->lastError = pPathoLexique->appendRecord();
    if (pPathoLexique->lastError != DBIERR_NONE)
    {
        erreur("L'ajout dans le Lexique a rat� (zut !)", 0, pPathoLexique->lastError);
        return;
    }
    initSynonymsList() ;
}

void
NSLexiqEditeur::trouveAmmorce()
{
    char text[256] ;
    pLexiType->GetText(text, 255) ;
    if (text[0] == '\0')
    {
        erreur("Pas de type, pas d'insertion dans le Lexique (�a ne se discute pas !)", 0, 0) ;
        return ;
    }
    string  sCod = string(1, text[0]) + "ZZ001" ;

    NSSuper* pSuper = pContexte->getSuperviseur() ;
    string sLang = "" ;
	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang() ;

    NSPatholog* pPathoLexique = pSuper->pDico->donnePatholog(sLang, &sCod) ;
    if (!pPathoLexique)
        return ;

    NSPathologData* pData = new NSPathologData ;
    bool    tourner = true ;
    while ((tourner) && (sCod[0] != '\0'))
	{
		bool trouve = pSuper->pDico->trouvePathologData(sLang, &sCod, pData, false) ;
		if (trouve)
        {
            if (sCod[4] != 'Z')
            {
		        sCod[4]++ ;
		        if 	  ((sCod[4] > '9') && (sCod[4] < 'A'))
			        sCod[4] = 'A' ;
            }
            else
            {
                sCod[4] = '0' ;
                if (sCod[3] != 'Z')
                {
		            sCod[3]++ ;
		            if 	  ((sCod[3] > '9') && (sCod[3] < 'A'))
			            sCod[3] = 'A' ;
                }
                else
                {
                    sCod[3] = '0' ;
                    sCod[4] = '0' ;
                    if (sCod[2] != '0')
                    {
		                sCod[2]-- ;
		                if 	  ((sCod[2] > '9') && (sCod[2] < 'A'))
			                sCod[2] = '9' ;
                    }
                    else
                    {
                        sCod[2] = 'Z' ;
                        if (sCod[1] != '0')
                        {
		                    sCod[1]-- ;
		                    if 	  ((sCod[1] > '9') && (sCod[1] < 'A'))
			                    sCod[1] = '9' ;
                        }
                        else
                        {
                            tourner = false ;
                            sCod = "" ;
                        }
                    }
                }
            }
        }
        else
            tourner = false ;
	}
    delete pData ;

    if (sCod != "")
        *psAmmorce = sCod ;
    else
        *psAmmorce = "" ;
}

void
NSLexiqEditeur::initSynonymsList()
{
    pLexiListe->DeleteAllItems();

    if (*psAmmorce == "")
        return ;

    string sCodeSens ;
    pContexte->getDico()->donneCodeSens(psAmmorce, &sCodeSens) ;

    VecteurString aListTerms = TrouverListeSynonimes(sCodeSens) ;
    if (! aListTerms.empty())
        for (EquiItemIter iter = aListTerms.begin();  iter != aListTerms.end() ; iter++)
        {
            TListWindItem Item((*iter)->c_str(), 0);
            pLexiListe->InsertItem(Item);
        }
}

VecteurString
NSLexiqEditeur::TrouverListeSynonimes(string sCodeTerm)
{
	NSPathologData* pData = new NSPathologData;
    VecteurString aListTerms;

  	bool trouve;
	bool tourner = true;
	char syno = '0';
	string sCod;
	NSSuper* pSuper = pContexte->getSuperviseur();

	string sLang = "";
	if ((pContexte) && (pContexte->getUtilisateur()))
		sLang = pContexte->getUtilisateur()->donneLang();

	while ((tourner)&& (sCodeTerm[0] != '\0'))
	{
		sCod = sCodeTerm + string(1, syno);
		trouve = pSuper->pDico->trouvePathologData(sLang, &sCod, pData, false);
		if (trouve)
			//pSynTermTitle->AddString(pData->libelle);
            aListTerms.push_back(new string(pData->libelle));

		syno++;
		if 	  ((syno > '9') && (syno < 'A'))
			syno = 'A';
		else if (syno > 'Z')
			tourner = false;
	}
	delete pData;
    return aListTerms;
}


// fin de nssmedit.cpp
//////////////////////////////////////////

