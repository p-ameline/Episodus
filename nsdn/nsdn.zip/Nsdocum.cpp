//---------------------------------------------------------------------------//    NSDOCUM.CPP
//    PA   juillet 94
//  Impl�mentation des objets document de NAUTILUS
//---------------------------------------------------------------------------

//
// Exig� par la version 5.01 du compilateur
//
// Dans BC5/INCLUDE/OCF/AUTODEFS.H
// #if !defined(_OLECTL_H_)
//		# if defined(__BIVBX_H) && !defined(NO_VBX_PICTURES)
//			#   error BIVBX.H's LPPICTURE is incompatible with OLECTL.H - define NO_VBX_PICTURES
//
#define  NO_VBX_PICTURES

#include <windows.h>
#include <mem.h>

#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "nsdn\nsdocdlg.h"

#include "nsdn\nsdocum.h"

//***************************************************************************
// Impl�mentation des m�thodes NSDocument
//
// Les m�thodes de NSDocumentData et NSDocumentInfo sont dans NSDOCINF.CPP
//***************************************************************************


//***************************************************************************// Impl�mentation des m�thodes NSChemise
//***************************************************************************

//---------------------------------------------------------------------------
//  Function:		NSChemiseData::metAZero()
//  Description:	Initialise les champs de donn�es � z�ro.
//  Retour:			Aucun
//---------------------------------------------------------------------------
void NSChemiseData::metAZero()
{
  // Met les champs de donn�es � z�ro
  memset(code,			  0, CHE_CODE_LEN + 1);
  memset(nom, 			  0, CHE_NOM_LEN + 1);
  memset(creation, 	  0, CHE_CREATION_LEN + 1);
  memset(acces, 		  0, CHE_ACCES_LEN + 1);
  memset(createur, 	  0, CHE_CREATEUR_LEN + 1);
  memset(commentaire,  0, CHE_COMMENTAIRE_LEN + 1);
}

//---------------------------------------------------------------------------
//  Fonction:  	NSChemiseData::donneIntitule(char *intitule)
//  Description:	Renvoie dans une chaine l'intitul� de la chemise
//  Retour:			Rien
//---------------------------------------------------------------------------
void NSChemiseData::donneIntitule(char *intitule, string sLang)
{
	char dateAffiche[20] ;

	strcpy(intitule, nom);
	ote_blancs(intitule);
	if (strcmp(creation, "        ") != 0)
	{
		strcat(intitule, " du ") ;
		donne_date(creation, dateAffiche, sLang) ;
		strcat(intitule, dateAffiche) ;
	}
}

//---------------------------------------------------------------------------
//  Fonction:		NSChemiseData::NSChemiseData(NSChemiseData& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSChemiseData::NSChemiseData(NSChemiseData& rv)
{	strcpy(code,		  rv.code);
	strcpy(nom,			  rv.nom);
	strcpy(creation, 	  rv.creation);
	strcpy(acces, 		  rv.acces);
	strcpy(createur, 	  rv.createur);
	strcpy(commentaire, rv.commentaire);
}

//---------------------------------------------------------------------------
//  Fonction:		NSChemiseData::operator=(NSChemiseData src)
//  Description:	Op�rateur d'affectation
//  Retour:			Rien
//---------------------------------------------------------------------------
NSChemiseData& NSChemiseData::operator=(NSChemiseData src)
{
	strcpy(code,		  src.code);
	strcpy(nom,			  src.nom);
	strcpy(creation, 	  src.creation);
	strcpy(acces, 		  src.acces);
	strcpy(createur, 	  src.createur);
	strcpy(commentaire, src.commentaire);
	return *this;
}

//---------------------------------------------------------------------------
//  Fonction:		NSChemiseData::operator==(const NSChemiseData& o)
//  Description:	Op�rateur de comparaison
//  Retour:			Rien
//---------------------------------------------------------------------------
int NSChemiseData::operator==(const NSChemiseData& o)
{
	 if ((strcmp(code,		  o.code)		  == 0) &&
		  (strcmp(nom,			  o.nom) 		  == 0) &&
		  (strcmp(creation, 	  o.creation)	  == 0) &&
		  (strcmp(acces, 		  o.acces)		  == 0) &&
		  (strcmp(createur, 	  o.createur)	  == 0) &&
		  (strcmp(commentaire, o.commentaire) == 0))
		  return 1;
	 else
		  return 0;
}

//---------------------------------------------------------------------------//  Fonction:		NSChemiseInfo::NSChemiseInfo()
//  Description:	Constructeur par d�faut
//  Retour:			Rien
//---------------------------------------------------------------------------
NSChemiseInfo::NSChemiseInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSChemiseData() ;
	sNodeChemise = "" ;
}

//---------------------------------------------------------------------------
//  Function:		NSChemiseInfo::~NSChemiseInfo()
//  Description:	Destructeur.
//  Retour:			Aucun
//---------------------------------------------------------------------------
NSChemiseInfo::~NSChemiseInfo()
{
  // D�truit l'objet de donn�es
  delete pDonnees ;
  pDonnees = 0 ;
}

//---------------------------------------------------------------------------
//  Function:		NSChemiseInfo::donneIntitule(char *intitule)
//  Description:	Donne l'intitul� de la chemise.
//  Retour:			Aucun
//---------------------------------------------------------------------------
void
NSChemiseInfo::donneIntitule(char *intitule, string sLang)
{
	pDonnees->donneIntitule(intitule, sLang) ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSChemiseInfo::NSChemiseInfo(NSChemiseInfo& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSChemiseInfo::NSChemiseInfo(NSChemiseInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSChemiseData() ;
	//
	// Initialise les donn�es � partir de celles de la source
	//
	*pDonnees = *(rv.pDonnees) ;
	sNodeChemise = rv.sNodeChemise ;
}

//---------------------------------------------------------------------------//  Fonction:		NSChemiseInfo::operator=(NSChemiseInfo src)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSChemiseInfo& NSChemiseInfo::operator=(NSChemiseInfo src)
{
	if (this == &src)
		return *this ;

	*pDonnees = *(src.pDonnees) ;
	sNodeChemise = src.sNodeChemise ;

	return *this ;
}

int NSChemiseInfo::operator == ( const NSChemiseInfo& o )
{
	 return (*pDonnees == *(o.pDonnees));
}

//***************************************************************************
// Impl�mentation des m�thodes NSSejour
//***************************************************************************

//---------------------------------------------------------------------------
//  Initialise les champs de donn�es � z�ro.
//---------------------------------------------------------------------------
void NSSejourData::metAZero()
{
  sTreeID  = "" ;
  sNumero  = "" ;
  sDateDeb = "" ;
  sDateFin = "" ;
  sUnit    = "" ;
}

//---------------------------------------------------------------------------
//  Renvoie dans une chaine l'intitul� de la chemise
//---------------------------------------------------------------------------
void NSSejourData::donneIntitule(char *intitule)
{
/*
	char dateAffiche[20];	strcpy(intitule, nom);
	ote_blancs(intitule);
	if (strcmp(creation, "        ") != 0)
	{
		strcat(intitule, " du ");
		donne_date(creation, dateAffiche, sLang);
		strcat(intitule, dateAffiche);
	} */
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSSejourData::NSSejourData(NSSejourData& rv)
{
	sTreeID  = rv.sTreeID ;
	sNumero  = rv.sNumero ;
	sDateDeb = rv.sDateDeb ;
	sDateFin = rv.sDateFin ;
	sUnit    = rv.sUnit ;
}

//---------------------------------------------------------------------------//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSSejourData& NSSejourData::operator=(NSSejourData src)
{
	if (this == &src)
		return *this ;

  sTreeID  = src.sTreeID ;
  sNumero  = src.sNumero ;
  sDateDeb = src.sDateDeb ;
  sDateFin = src.sDateFin ;
  sUnit    = src.sUnit ;

  return *this ;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSSejourData::operator==(const NSSejourData& o)
{
	if ((sTreeID == o.sTreeID) &&
      (sNumero == o.sNumero) &&
      (sDateDeb == o.sDateDeb) &&
      (sDateFin == o.sDateFin) &&
      (sUnit == o.sUnit))
		return 1 ;
	else
  	return 0 ;
}

//---------------------------------------------------------------------------
//  Constructeur par d�faut
//---------------------------------------------------------------------------
NSSejourInfo::NSSejourInfo()
{
    // Cr�e l'objet de donn�es
	pDonnees = new NSSejourData();
}

//---------------------------------------------------------------------------
//  Destructeur.
//---------------------------------------------------------------------------
NSSejourInfo::~NSSejourInfo()
{
    // D�truit l'objet de donn�es
    delete pDonnees;
}

//---------------------------------------------------------------------------
//  Donne l'intitul� du s�jour.
//---------------------------------------------------------------------------
void
NSSejourInfo::donneIntitule(char *intitule)
{
	pDonnees->donneIntitule(intitule);
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSSejourInfo::NSSejourInfo(NSSejourInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSSejourData() ;
	//
	// Initialise les donn�es � partir de celles de la source
	//
	*pDonnees = *(rv.pDonnees) ;
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSSejourInfo& NSSejourInfo::operator=(NSSejourInfo src)
{
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}

int NSSejourInfo::operator == ( const NSSejourInfo& o ){
	return (*pDonnees == *(o.pDonnees)) ;
}

//***************************************************************************// Impl�mentation des m�thodes NSChemDoc
//***************************************************************************

//---------------------------------------------------------------------------
//  Function:		NSChemDocData::NSChemDocData()
//  Description:	Constructeur.
//  Retour:			Aucun
//---------------------------------------------------------------------------
NSChemDocData::NSChemDocData()
{
  // Met les champs de donn�es � z�ro
  memset(chemise,	 0, CDO_CHEMISE_LEN + 1);
  memset(ordre,	 0, CDO_ORDRE_LEN + 1);
  memset(document, 0, CDO_DOCUMENT_LEN + 1);
}

//---------------------------------------------------------------------------
//  Description:	Op�rateur d'affectation
//  Retour:			Rien
//---------------------------------------------------------------------------
NSChemDocData& NSChemDocData::operator=(NSChemDocData src)
{
	strcpy(chemise ,	src.chemise);
	strcpy(ordre   ,	src.ordre);
	strcpy(document, 	src.document);
	return *this;
}

//---------------------------------------------------------------------------
//  Description:	Op�rateur de comparaison
//  Retour:			Rien
//---------------------------------------------------------------------------
int NSChemDocData::operator==(const NSChemDocData& o)
{
	 if ((strcmp(chemise,  o.chemise) == 0) &&
		  (strcmp(ordre,	  o.ordre) 	 == 0) &&
		  (strcmp(document, o.document)	 == 0))
		  return 1;
	 else
		  return 0;
}

//---------------------------------------------------------------------------
//  Constructeur par d�faut
//---------------------------------------------------------------------------
NSChemDocInfo::NSChemDocInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSChemDocData() ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSChemDocInfo::NSChemDocInfo(NSChemDocInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSChemDocData() ;
	//
	// Initialise les donn�es � partir de celles de la source
	//
	*pDonnees = *(rv.pDonnees) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSChemDocInfo::~NSChemDocInfo()
{
  // D�truit l'objet Donn�es
  delete pDonnees ;
  pDonnees = 0 ;
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSChemDocInfo& NSChemDocInfo::operator=(NSChemDocInfo src)
{
	if (this == &src)
		return *this ;

	*pDonnees = *(src.pDonnees) ;

	return *this;
}

int NSChemDocInfo::operator == ( const NSChemDocInfo& o )
{
	return (*pDonnees == *(o.pDonnees)) ;
}


