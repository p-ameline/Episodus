#include <owl\olemdifr.h>#include <owl\applicat.h>
#include <owl\dialog.h>
#include <owl\edit.h>
#include <bde.hpp>
#include <stdio.h>
#include <string.h>

#include "partage\nsdivfct.h"#include "nautilus\nssuper.h"#include "nautilus\nsannexe.h"

#include "nautilus\nsresour.h"
#include "nautilus\nshistdo.h"
#include "nautilus\nsdochis.h"
#include "nssavoir\nsgraphe.h"
#include "nsbb\nsbbtran.h"
#include "nsdn\nsdn.h"
#include "nsdn\nsdocnoy.h"
#include "nsdn\nsdocdlg.h"
#include "nsdn\nsdocdlg.rh"

// -----------------------------------------------------------------------------
//
//  M�thodes de EnregDocDialog
//
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(EnregDocDialog, TDialog)
  EV_COMMAND(IDOK,              CmOk),
  EV_COMMAND(IDCANCEL,          CmCancel),
  EV_COMMAND(IDC_NWDOC_CHGCHEM, CmNouvChem),
  EV_BN_CLICKED(IDC_NWDOC_HISTOR, CmHistorique),
  EV_CHILD_NOTIFY(IDC_DOC0P, BN_CLICKED, TraitementInteret0P),
  EV_CHILD_NOTIFY(IDC_DOC1P, BN_CLICKED, TraitementInteret1P),
  EV_CHILD_NOTIFY(IDC_DOC2P, BN_CLICKED, TraitementInteret2P),
  EV_CHILD_NOTIFY(IDC_DOC3P, BN_CLICKED, TraitementInteret3P),
  EV_CHILD_NOTIFY(IDC_DOC4P, BN_CLICKED, TraitementInteret4P),
  EV_WM_PAINT,
END_RESPONSE_TABLE ;

// -----------------------------------------------------------------------------// Function     : EnregDocDialog::EnregDocDialog()
// Description  : Constructeur
// -----------------------------------------------------------------------------
EnregDocDialog::EnregDocDialog(TWindow *pere, NSDocumentData *pDocuDonnees, char *CodeChemi, string sRights, NSContexte *pCtx)
               :NSUtilDialog(pere, pCtx, "ID_LDV_NWDOC", pNSResModule)
{
try
{
	pDocData 	        = pDocuDonnees ;
	pCodeChemiseChoisie = CodeChemi ;

	NSHealthTeamMandate* pMdt = NULL ;

  NSHealthTeam* pHT = pCtx->getPatient()->pHealthTeam ;
  if (pHT)
  {
    NSHealthTeamMember* pHTMember = pHT->getUserAsMember(pCtx) ;
  	if (pHTMember)
    {
    	NSHTMMandateArray aMandates ;
      pHTMember->getActiveMandates(&aMandates) ;
    	if (!(aMandates.empty()))
      {
      	NSHTMMandateIter mandateIter = aMandates.begin() ;
        pMdt = *mandateIter ;
        //
        // We have to empty aMandates in order to avoid mandates deletion
        //
        for ( ; mandateIter != aMandates.end() ; )
        	aMandates.erase(mandateIter) ;
      }
    }
  }

	sRightsString 		= sRights ;
	if (sRightsString == "")
		pRosace = new NSRosace(pCtx, pMdt) ;
	else
		pRosace = new NSRosace(pCtx, sRightsString, pMdt) ;

  pNomDoc        = new TEdit(this, IDC_NWDOC_NOM, 1024) ;
  pDateCreation  = new NSUtilEditDateHeure(pContexte, this,  IDC_NWDOC_CREATION) ;

  pHistorique    = new TRadioButton(this, IDC_NWDOC_HISTOR) ;
	pChemiseBox    = new TComboBox(this, IDC_NWDOC_CHEM, 1024) ;

	pInteretGroup  = new TGroupBox(this, IDC_NWDOC_INTGRP) ;	pImportance    = new TVSlider(this,  IDC_DOCIMPORTANCE) ; //inter�t
  pNSSlider0P    = new TButton(this,   IDC_DOC0P) ;
  pNSSlider1P    = new TButton(this,   IDC_DOC1P) ;
  pNSSlider2P    = new TButton(this,   IDC_DOC2P) ;
  pNSSlider3P    = new TButton(this,   IDC_DOC3P) ;
  pNSSlider4P    = new TButton(this,   IDC_DOC4P) ;

	pRosaceGroup   = new NSRosaceGroupBox(pContexte, this, IDC_ROSACE, pRosace) ;
	_synchro_check = new TCheckBox(this, IDC_SYNCHRO); // Checkbox pour dire que l'objet est synchronisable
  _note_check    = new TCheckBox(this, IDC_NOTE);

	// pCommentaire        = new TEdit(this,           IDC_NWDOC_COMMENT) ;

	pChemisesArray = new NSChemiseArray ;}catch (...){
  erreur("Exception EnregDocDialog ctor.", standardError, 0) ;
}}


// -----------------------------------------------------------------------------
// Function     : EnregDocDialog::~EnregDocDialog()
// Description  : Destructeur, enregistre le document
// -----------------------------------------------------------------------------
EnregDocDialog::~EnregDocDialog()
{
  // Suppression de tous les objets
  delete pNomDoc ;
  delete pDateCreation ;
  delete pHistorique ;
	delete pChemiseBox ;
	delete pInteretGroup ;
  delete pImportance ;
	delete pNSSlider0P ;
  delete pNSSlider1P ;
  delete pNSSlider2P ;
  delete pNSSlider3P ;
  delete pNSSlider4P ;
	delete pRosaceGroup	;
 	delete _synchro_check ;
  delete _note_check ;
	// delete pCommentaire ;
	delete pChemisesArray ;
}

// -----------------------------------------------------------------------------
// Function     : EnregDocDialog::SetupWindow()
// Arguments    :	Aucun
// Description  : Initialise la boite de dialogue
// Returns      :	Rien
// -----------------------------------------------------------------------------
void
EnregDocDialog::SetupWindow()
{
	TDialog::SetupWindow() ;

	// Mise du nom du document dans le contr�le Edit
	if (strspn(pDocData->sNom.c_str(), " ") < strlen(pDocData->sNom.c_str()))
		pNomDoc->SetText(pDocData->sNom.c_str()) ;
	else
		pNomDoc->SetText("") ;

	// Date de cr�ation
	pDateCreation->setDate(pDocData->sDateCreation) ;

	// Ajout � l'historique
  if (true == pDocData->estVisible())
  	pHistorique->Check() ;
  else
  	pHistorique->Uncheck() ;

	// Initialisation de l'importance
  pImportance->SetRange(0, 4) ;
  pImportance->SetRuler(1, false) ;

  int iImpo = 0 ;
  if (string("") != pDocData->sInteret)
  {
  	switch (pDocData->sInteret[0])
  	{
    	case 'E'  : iImpo = 4 ; break ;
    	case 'D'  : iImpo = 3 ; break ;
    	case 'C'  : iImpo = 2 ; break ;
    	case 'B'  : iImpo = 1 ; break ;
    	case 'A'  : iImpo = 0 ; break ;
		}
  }

	pImportance->SetPosition(iImpo) ;

	RemplirChemises() ;
	InitChemisesBox() ;

	// Si il n'y a pas de droit, on pr�coche le checkbox synchro uniquement si c'est un patient global
	if ((sRightsString == "") && (pContexte->getPatient()->IsGlobal()))
  	_synchro_check->Check() ;
  else    // Sinon on initialise en fonction de la rosace
  {
  	if (pRosace->IsPersonnalNote())
    	_note_check->Check() ;
    if (pRosace->IsSynchronisable())
    	_synchro_check->Check() ;
  }
}

/*
void
EnregDocDialog::EvPaint()
{
	DefaultProcessing();
    return;

	NSUtilDialog::EvPaint();

#ifdef N_TIERS

	TPaintDC Dc(*this);
    NS_CLASSLIB::TRect& rect = *(NS_CLASSLIB::TRect*)&Dc.Ps.rcPaint;
    Paint(Dc, true, rect);

#endif
}


void
EnregDocDialog::Paint(TDC& dc, bool erase, NS_CLASSLIB::TRect& RectAPeindre)
{
	NSUtilDialog::Paint(dc, erase, RectAPeindre) ;
#ifdef N_TIERS
	NS_CLASSLIB::TRect dialogRect = GetWindowRect() ;
    NS_CLASSLIB::TRect rosaceRect = pRosaceGroup->GetWindowRect() ;
    ::MapWindowPoints(HWND_DESKTOP, *this, (LPPOINT)&rosaceRect, 2);
    // if (rosaceRect.Touches(RectAPeindre))
    	pRosace->draw(&dc, &rosaceRect) ;
#endif
}
*/

// -----------------------------------------------------------------------------
// Function     : EnregDocDialog::RemplirChemises()
// Description  : Initialise la ChemiseBox
// Returns      :	Rien
// -----------------------------------------------------------------------------
void
EnregDocDialog::RemplirChemises()
{
try
{
	if ((NULL == pContexte->getPatient()) || (NULL == pContexte->getPatient()->pDocHis))
		return ;

	NSDocumentHisto* pLibChem = pContexte->getPatient()->pDocHis->pLibChem ;
  if ((NULL == pLibChem) || (NULL == pLibChem->pPatPathoArray) ||
      (true == pLibChem->pPatPathoArray->empty()))
  	return ;

  string sElemLex, sSens, sType;
  string sNodeChem = "";
  string sNom = "", sDate = "";

	// on doit parcourir la librairie pour charger l'array des chemises
	PatPathoIter iter = pLibChem->pPatPathoArray->begin() ;
  int iColBase = (*iter)->getColonne() ;
  iter++ ;

	while ((pLibChem->pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColBase))
	{
  	string sSens = (*iter)->getLexiqueSens(pContexte) ;

    if (string("0CHEM") == sSens)
    {
    	sNodeChem = (*iter)->getNode() ;
      sNom = "" ;
      sDate = "" ;
      iter++ ;

      // on charge les donn�es de la chemise
      while ((pLibChem->pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColBase+1))
      {
      	sSens = (*iter)->getLexiqueSens(pContexte) ;

        // nom de la chemise
        if (string("0INTI") == sSens)
        {
        	iter++ ;

          while ((pLibChem->pPatPathoArray->end() != iter) && ((*iter)->getColonne() > iColBase+2))
          {
          	// on cherche ici un texte libre
            string sElemLex = (*iter)->getLexique() ;

            if (string("�?????") == sElemLex)
            	sNom = (*iter)->getTexteLibre() ;

            iter++ ;
          }
        }
        // Dates
        else if (string("KOUVR") == sSens)
        {
        	iter++ ;
          int iLigneBase = (*iter)->getLigne() ;

          // gereDate* pDate = new gereDate(pContexte);
          string sUnite  = "";
          string sFormat = "";
          string sValeur = "";
          string sTemp   = "";

          while ((pLibChem->pPatPathoArray->end() != iter) &&
                           ((*iter)->getLigne() == iLigneBase))
          {
          	if (((*iter)->pDonnees->lexique)[0] == '�')
            {
            	sFormat = (*iter)->getLexiqueSens(pContexte) ;
              sValeur = (*iter)->getComplement() ;
              sUnite  = (*iter)->getUnitSens(pContexte) ;

              iter++ ;
              break ;
            }

            iter++ ;
          }

          // sFormat est du type �D0;03
          if ((sFormat != "") && ((sFormat[1] == 'D') || (sFormat[1] == 'T')) &&
            		        (sValeur != ""))
          {
          	if (sUnite == "2DA02")
            	sDate = sValeur ;
          }
        }
        else
        	iter++ ;
      }

      if (string("") != sNom)
      {
      	NSChemiseInfo ChemInfo ;
        ChemInfo.sNodeChemise = sNodeChem ;
        strcpy(ChemInfo.pDonnees->nom, sNom.c_str()) ;
        strcpy(ChemInfo.pDonnees->creation, sDate.c_str()) ;

        pChemisesArray->push_back(new NSChemiseInfo(ChemInfo)) ;
      }
    }
    else
    	iter++ ;
  }
}
catch (...)
{
  erreur("Exception RemplirChemises.", standardError, 0) ;
}
}

void
EnregDocDialog::InitChemisesBox()
{
	if (pChemisesArray->empty())
		return ;

	ChemInfoIter iter ;
	char 	       chAffiche[200] ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	for (iter = pChemisesArray->begin() ; iter != pChemisesArray->end() ; iter++)
	{
  	(*iter)->pDonnees->donneIntitule(chAffiche, sLang) ;

		// Ajout de la chemise � la ChemiseBox
		pChemiseBox->AddString(chAffiche) ;
	}

	// En MUE, on s�lectionne la chemise du document s'il en a une
	// (le codeDocument doit etre dans EnregDocDialog celui du meta)
	// sinon, on s�lectionne par d�faut la derni�re chemise du patient
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;

	VecteurString VectString ;
	string codeDocument = pDocData->getID() ;
	string sNodeChemise ;

	pGraphe->TousLesVrais(codeDocument, NSRootLink::docFolder, &VectString, "ENVERS") ;

	if (false == VectString.empty())
	{
  	sNodeChemise = *(*(VectString.begin())) ;

    for (iter = pChemisesArray->begin(); pChemisesArray->end() != iter; iter++)
    {
    	if ((*iter)->sNodeChemise == sNodeChemise)
      {
      	(*iter)->pDonnees->donneIntitule(chAffiche, sLang) ;
        pChemiseBox->SetSelString(chAffiche, 0) ;
        break ;
      }
    }
	}
	else // cas par d�faut : s�lection de la derni�re chemise du patient.
	{
  	((*pChemisesArray)[pChemisesArray->size() - 1])->pDonnees->donneIntitule(chAffiche, sLang) ;
    pChemiseBox->SetSelString(chAffiche, 0) ;
	}
}

void
EnregDocDialog::CmHistorique()
{
  if (pDocData->estVisible())
  {
    pDocData->rendInvisible() ;
    pHistorique->Uncheck() ;
  }
  else
  {
    pDocData->rendVisible() ;
    pHistorique->Check() ;
  }
}

// -----------------------------------------------------------------------------
// Function     : EnregDocDialog::CmOk()
// Description  : R�ponse au bouton OK
// Returns      :	Rien
// -----------------------------------------------------------------------------
void
EnregDocDialog::CmOk()
{
	char NomDocu[1025] ;

	// V�rifie qu'un nom de document a bien �t� saisi
	pNomDoc->Transfer(NomDocu, tdGetData) ;
	if ((NomDocu[0] == '\0') || (strspn(NomDocu, " ") == strlen(NomDocu)))
	{
    string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "youMustProvideANameForTheDocument") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
		return ;
	}

	// Transf�re le nom dans DocumentInfo
	pDocData->sNom = NomDocu ;

  // Transf�re la date de cr�ation dans DocumentInfo
  string sDateCreation ;
  pDateCreation->getDate(&sDateCreation) ;
  pDocData->sDateCreation = sDateCreation ;

	// R�cup�re le code de la chemise s�lectionn�e
	ChemiseChoisie = pChemiseBox->GetSelIndex();

  if ((ChemiseChoisie < 0) || (size_t(ChemiseChoisie) >= pChemisesArray->size()))
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "youMustSelectAFolderToStoreTheDocument") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
		return ;
	}

	if (ChemiseChoisie == 0)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "noDocumentCanBeStoredInTheRecycleBin") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1) ;
    erreur(sErrorText.c_str(), standardError, 0, GetHandle()) ;
    return ;
	}

	NSChemiseInfo *Chemise = (*pChemisesArray)[ChemiseChoisie] ;

	strcpy(pCodeChemiseChoisie, (Chemise->sNodeChemise).c_str()) ;

	// R�cup�re l'information concernant l'Int�ret
  int iImpo = pImportance->GetPosition() ;
  switch (iImpo)
  {
    case 4  : pDocData->sInteret = string("E") ; break ;
    case 3  : pDocData->sInteret = string("D") ; break ;
    case 2  : pDocData->sInteret = string("C") ; break ;
    case 1  : pDocData->sInteret = string("B") ; break ;
    default : pDocData->sInteret = string("A") ;
	}

	if ((_note_check->GetCheck()) == BF_CHECKED)    // On verifie que c'est une note personnelle
		pRosaceGroup->pRosace->setPersonnalNote(true) ;
	else
  	pRosaceGroup->pRosace->setPersonnalNote(false) ;

	if ((_synchro_check->GetCheck()) == BF_CHECKED)   // On verifie que le document est synchronisable
		pRosaceGroup->pRosace->setSynchronalisable(true) ;
	else
		pRosaceGroup->pRosace->setSynchronalisable(false) ;

	pDocData->sRights = pRosaceGroup->getRigthsString() ;

	// Effectue le CmOk
	TDialog::CmOk() ;
}

// -----------------------------------------------------------------------------
// Function     : EnregDocDialog::CmCancel()
// Description  : R�ponse au bouton Cancel
// Returns      :	Rien
// -----------------------------------------------------------------------------
void
EnregDocDialog::CmCancel()
{
	string sRights = pRosaceGroup->getRigthsString() ;

	TDialog::CmCancel() ;
}

// -----------------------------------------------------------------------------
//  Function: EnregDocDialog::CmNouvChem()
//  Description: Cr�ation d'une nouvelle chemise par d�faut
//  Returns:	  Rien
// -----------------------------------------------------------------------------
void
EnregDocDialog::CmNouvChem()
{
  string sNomChem ;

  NomChemiseDialog  *pNomChemDlg = new NomChemiseDialog(pContexte->GetMainWindow(), pContexte) ;
  if (pNomChemDlg->Execute() == IDCANCEL)
  {
    delete pNomChemDlg ;
    return ;
  }
  sNomChem = pNomChemDlg->sNomChem ;
  delete pNomChemDlg ;

	// En MUE on constitue un docnoy � partir du document pLibChem
	// pour modifier sa patpatho. On doit ensuite remettre pLibChem � jour
  NVLdVTemps tpsNow ;
  tpsNow.takeTime() ;

  if ((NULL == pContexte->getPatient()->pDocHis) || (NULL == pContexte->getPatient()->pDocHis->pLibChem))
    return ;

	NSDocumentInfo Docum(pContexte) ;
	*(Docum.getData()) = *(pContexte->getPatient()->pDocHis->pLibChem->getData()) ;

	NSNoyauDocument Noyau(0, &Docum, 0, pContexte, false) ;
	NSPatPathoArray* pPpt = Noyau.pPatPathoArray ;
  *pPpt = *(pContexte->getPatient()->pDocHis->pLibChem->pPatPathoArray) ;

	// constitution de la patpatho correspondant � la nouvelle chemise
	NSPatPathoArray PatPatho(pContexte) ;

	// ajout de la nouvelle chemise
	PatPatho.ajoutePatho("0CHEM1", 0) ;

	// Intitul� : nom de la chemise
	PatPatho.ajoutePatho("0INTI1", 1) ;
	Message Msg ;
	Msg.SetTexteLibre(sNomChem.c_str()) ;
	PatPatho.ajoutePatho("�?????", &Msg, 2) ;

	// Date d'ouverture
	PatPatho.ajoutePatho("KOUVR1", 1) ;
	Msg.Reset() ;
	Msg.SetUnit("2DA021") ;
	Msg.SetComplement(tpsNow.donneDateHeure()) ;
	PatPatho.ajoutePatho("�T0;19", &Msg, 2) ;

  // If the Folder Library is empty, we have to set the root concept
  if (true == pPpt->empty())
    pPpt->ajoutePatho("0LIBC1", 0) ;

  // Insertion en queue (iter doit �tre ici egal � end())
  pPpt->InserePatPatho(pPpt->end(), &PatPatho, 1) ;

	// Enregistrement du document modifi�
	Noyau.enregistrePatPatho() ;

	// Mise � jour de l'historique
	/*bool bReload =*/ Noyau.chargePatPatho() ;
	pPpt = Noyau.pPatPathoArray ;

	// on rafraichit en m�moire le document pLibChem
	*(pContexte->getPatient()->pDocHis->pLibChem->pPatPathoArray) = *pPpt;

  // on vide la liste si elle contient des items
  if (pChemiseBox->GetCount())
    pChemiseBox->ClearList() ;

  // on vide le tableau
  pChemisesArray->vider() ;

  RemplirChemises() ;

  if (pChemisesArray->empty())
    return ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  char 	        chAffiche[200] ;
  ChemInfoIter  iter ;
  for (iter = pChemisesArray->begin(); iter != pChemisesArray->end(); iter++)
  {
		(*iter)->pDonnees->donneIntitule(chAffiche, sLang) ;

		// Ajout de la chemise � la ChemiseBox
		pChemiseBox->AddString(chAffiche) ;
  }

  // On s�lectionne par d�faut la derni�re chemise (la nouvelle)
  pChemiseBox->SetSelString(chAffiche, 0) ;
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
void
EnregDocDialog::TraitementInteret0P()
{
	pImportance->SetPosition(0) ;
}

void
EnregDocDialog::TraitementInteret1P()
{
	pImportance->SetPosition(1) ;
}

void
EnregDocDialog::TraitementInteret2P()
{
	pImportance->SetPosition(2) ;
}

void
EnregDocDialog::TraitementInteret3P()
{
	pImportance->SetPosition(3) ;
}

void
EnregDocDialog::TraitementInteret4P()
{
	pImportance->SetPosition(4) ;
}

// -----------------------------------------------------------------------------
//
//  M�thodes de NomChemiseDialog
//
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(NomChemiseDialog, TDialog)
  EV_BN_CLICKED(IDC_NOMCHEM_DEFAUT, CmClickChemDefaut),
  EV_BN_CLICKED(IDC_NOMCHEM_NEW,    CmClickChemNew),
  EV_EN_CHANGE(IDC_NOMCHEM_EDIT, CmChangeNomChem),
  EV_COMMAND(IDOK,      CmOk),
  EV_COMMAND(IDCANCEL,  CmCancel),
END_RESPONSE_TABLE ;


NomChemiseDialog::NomChemiseDialog(TWindow *pere, NSContexte *pCtx)
  : NSUtilDialog(pere, pCtx, "IDD_NOMCHEM")
{
  pNomChem 	  = new TEdit(this, IDC_NOMCHEM_EDIT, CHE_NOM_LEN) ;
  pChemDefaut = new TRadioButton(this, IDC_NOMCHEM_DEFAUT, 0) ;
  pChemNew 	  = new TRadioButton(this, IDC_NOMCHEM_NEW, 0) ;
  sNomChem    = "" ;
}


NomChemiseDialog::~NomChemiseDialog()
{
  delete pNomChem ;
  delete pChemDefaut ;
  delete pChemNew ;
}


void
NomChemiseDialog::SetupWindow()
{
  TDialog::SetupWindow() ;
  pChemDefaut->Uncheck() ;
  pChemNew->Check() ;
  pNomChem->SetFocus() ;
}


void
NomChemiseDialog::CmClickChemNew()
{
  pChemDefaut->Uncheck() ;
}


void
NomChemiseDialog::CmClickChemDefaut()
{
  pChemNew->Uncheck() ;
}


void
NomChemiseDialog::CmChangeNomChem()
{
	pChemNew->Check() ;
  pChemDefaut->Uncheck() ;
}


void
NomChemiseDialog::CmOk()
{
	char far cfNomChem[CHE_NOM_LEN + 1] ;

  pNomChem->GetText(cfNomChem,CHE_NOM_LEN) ;
	sNomChem = string(cfNomChem) ;

	if ((pChemNew->GetCheck()) == BF_CHECKED)
  {
    if (sNomChem == "")
    {
      MessageBox("Erreur : Vous n'avez pas saisi de nom pour la nouvelle chemise.") ;
      return ;
    }
  }

  if ((pChemDefaut->GetCheck()) == BF_CHECKED)
    sNomChem = "d�faut" ;

  TDialog::CmOk() ;
}


void
NomChemiseDialog::CmCancel()
{
  TDialog::CmCancel() ;
}



// -----------------------------------------------------------------------------
//
//  M�thodes de Cr�erSejourDialog
//
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(CreerSejourDialog, TDialog)
  EV_COMMAND(IDOK,      CmOk),
  EV_COMMAND(IDCANCEL,  CmCancel),
END_RESPONSE_TABLE ;


CreerSejourDialog::CreerSejourDialog(TWindow *pere, NSContexte *pCtx, string sNumero)
                  :NSUtilDialog(pere, pCtx, "IDD_CREAT_SEJOUR")
{
try
{
  pNumSejour = new TEdit(this, IDC_SEJ_NUM,  CSEJ_NUMERO_LEN) ;
  pNumUF     = new TEdit(this, IDC_SEJ_UF,   CSEJ_UNITE_LEN) ;
  pDateDeb   = new NSUtilEditDate(pContexte, this, IDC_SEJ_DEBUT, 10, false) ;
  pDateFin   = new NSUtilEditDate(pContexte, this, IDC_SEJ_FIN,   10, false) ;

  sNumUF = "2091" ;
  sPrevNum = sNumero ;
  sPrevCode = "" ;
}
catch (...)
{
  erreur("Exception (new CreerSejourDialog)", standardError, 0) ;
}
}


CreerSejourDialog::~CreerSejourDialog()
{
	delete pNumSejour ;
  delete pNumUF ;
  delete pDateDeb ;
  delete pDateFin ;
}


void
CreerSejourDialog::SetupWindow()
{
  TDialog::SetupWindow() ;

  if (sPrevNum == "")
	{
  	pNumUF->SetText(sNumUF.c_str()) ;
  	pNumSejour->SetFocus() ;

  	char szDateJour[9] ;
		donne_date_duJour(szDateJour) ;

		pDateDeb->setDate(szDateJour) ;
		pDateFin->setDate(szDateJour) ;

    return ;
  }

#ifndef N_TIERS

  //
  // R�cup�ration du s�jour
  //
  bool bSejourSearch = true ;
	NSSejour *pSejour = new NSSejour(pContexte) ;

	// Ouverture du fichier
	pSejour->lastError = pSejour->open() ;
	if (pSejour->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier des s�jours.", standardError, pSejour->lastError) ;
		delete pSejour ;
    return ;
	}

	string  codeSejour ;
	char    PremOrdre[CSEJ_CODE_LEN + 1] ;

	// Pr�paration du compteur maxi
	int i ;
	for (i = 0 ; i < CSEJ_CODE_LEN ; i++)
		PremOrdre[i] = ' ' ;
	PremOrdre[i] = '\0' ;

	codeSejour = string(pContexte->getPatient()->pDonnees->nss) + string(PremOrdre) ;

	pSejour->lastError = pSejour->chercheClef(&codeSejour, "", 0, keySEARCHGEQ, dbiWRITELOCK) ;
	// Fin de fichier -> pas de s�jour
	if (pSejour->lastError == DBIERR_EOF)
	{
		erreur("Impossible de retrouver le s�jour - fichier vide.", standardError, pSejour->lastError) ;
		delete pSejour ;
    return ;
	}
	// Toute autre erreur est anormale
	else if (pSejour->lastError != DBIERR_NONE)
	{
		erreur("Le fichier des s�jours est endommag�.", standardError, pSejour->lastError) ;
		delete pSejour ;
    return ;
	}

	// On r�cup�re l'enregistrement
	pSejour->lastError = pSejour->getRecord() ;
	if (pSejour->lastError != DBIERR_NONE)
	{
		erreur("Le fichier des s�jours est endommag�.", standardError, pSejour->lastError) ;
		delete pSejour ;
    return ;
	}

	// Tant que le s�jour trouv� appartient au patient, on remplit la liste
	while ( (pSejour->lastError == DBIERR_NONE) &&
          (strcmp(pSejour->pDonnees->nss, pContexte->getPatient()->pDonnees->nss) == 0))
	{
  	if (string(pSejour->pDonnees->numero) == sPrevNum)
      break ;

		pSejour->lastError = pSejour->suivant(dbiWRITELOCK) ;

    if (pSejour->lastError == DBIERR_NONE)
    {
			pSejour->lastError = pSejour->getRecord() ;
      if (pSejour->lastError != DBIERR_NONE)
      {
        erreur("Le fichier des s�jours est endommag�.", standardError, pSejour->lastError) ;
        delete pSejour ;
    		return ;
      }
    }
    else if (pSejour->lastError != DBIERR_EOF)
    {
      erreur("Le fichier des s�jours est endommag�.", standardError, pSejour->lastError) ;
      delete pSejour ;
    	return ;
    }
  }

  if (string(pSejour->pDonnees->numero) != sPrevNum)
  {
  	erreur("Il est impossible de retrouver le s�jour.", standardError, 0) ;
    delete pSejour ;
		return ;
  }

	pNumUF->SetText(pSejour->pDonnees->unite) ;
	pNumSejour->SetText(pSejour->pDonnees->numero) ;

	pDateDeb->setDate(pSejour->pDonnees->debut) ;
	pDateFin->setDate(pSejour->pDonnees->fin) ;

  sPrevCode = pSejour->pDonnees->code ;

  delete pSejour ;

#endif
}


void
CreerSejourDialog::CmOk()
{
try
{
	char far cfNumSejour[CSEJ_NUMERO_LEN + 1] ;

  pNumSejour->GetText(cfNumSejour, CSEJ_NUMERO_LEN) ;
	string sNumSej = string(cfNumSejour) ;

  if (sNumSej == "")
  {
    MessageBox("Erreur : Vous n'avez pas saisi de num�ro de s�jour.") ;
    return ;
  }

#ifndef N_TIERS

  NSSejour *pSejour = new NSSejour(pContexte) ;

	// Ouverture du fichier
	pSejour->lastError = pSejour->open() ;
	if (pSejour->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier des s�jours.", standardError, pSejour->lastError, GetHandle()) ;
		delete pSejour ;
		return ;
	}

  // R�cup�ration du nouveau code du S�jour
  char szNewCode[CSEJ_CODE_LEN + 1] ;

  if (!(pSejour->DonneNouveauCode(szNewCode)))
	{
		erreur("Cr�ation du s�jour impossible.", standardError, pSejour->lastError, GetHandle()) ;
		delete pSejour ;
		return ;
	}

  strcpy(pSejour->pDonnees->nss,      pContexte->getPatient()->pDonnees->nss) ;
  strcpy(pSejour->pDonnees->code,     szNewCode) ;  strcpy(pSejour->pDonnees->numero,   sNumSej.c_str()) ;
  strcpy(pSejour->pDonnees->unite,    sNumUF.c_str()) ;

  string sDateDeb ;
  pDateDeb->getDate(&sDateDeb) ;
  strcpy(pSejour->pDonnees->debut, sDateDeb.c_str()) ;
  string sDateFin ;
  pDateFin->getDate(&sDateFin) ;
  strcpy(pSejour->pDonnees->fin, sDateFin.c_str()) ;

  // Ajout de l'enregistrement au fichier
	pSejour->lastError = pSejour->appendRecord() ;
	if (pSejour->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ajout du nouveau s�jour.", standardError, pSejour->lastError, GetHandle()) ;
		delete pSejour ;
		return ;
	}
  delete pSejour ;

  // Cr�ation de la chemise
  string sNomChem = "S�jour " + sNumSej ;

  if (!pContexte->getPatient()->CreeChemiseDefaut(sNomChem))
    erreur("Impossible de cr�er une nouvelle chemise pour le patient.", standardError, 0, GetHandle()) ;

#endif

  TDialog::CmOk() ;
}
catch (...)
{
  erreur("Exception (CreerSejourDialog::CmOk)", standardError, 0) ;
}
}


void
CreerSejourDialog::CmCancel()
{
  TDialog::CmCancel() ;
}



// -----------------------------------------------------------------------------
//
//      M�thodes de ListeSejoursDialog
//
// -----------------------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(ListeSejoursDialog, NSUtilDialog)
  EV_COMMAND(IDC_SEJOURS_SUPPR, CmSupprimer),
  EV_COMMAND(IDC_SEJOURS_CREER, CmCreer),
  EV_COMMAND(IDC_SEJOURS_MODIF, CmModifier),
  EV_COMMAND(IDOK,              CmOk),
  EV_COMMAND(IDCANCEL,          CmCancel),
  EV_LBN_SELCHANGE(IDC_SEJOURS_LISTE, CmSelectSejour),
	EV_LBN_DBLCLK(IDC_SEJOURS_LISTE, CmSejourDblClk),
END_RESPONSE_TABLE ;


ListeSejoursDialog::ListeSejoursDialog(TWindow *pere, NSContexte *pCtx, TModule *module)
  : NSUtilDialog(pere, pCtx, "IDD_SEJOURS", module)
{
try
{
	pListe 	= new TListBox(this, IDC_SEJOURS_LISTE, module) ;
  sEnCours = "" ;
}
catch (...)
{
  erreur("Exception (new ListeSejoursDialog)", standardError, 0) ;
}
}


ListeSejoursDialog::~ListeSejoursDialog()
{
  delete pListe ;
}


void
ListeSejoursDialog::SetupWindow()
{
	TDialog::SetupWindow() ;
  AfficheListe() ;
}


void
ListeSejoursDialog::AfficheListe()
{
try
{
  // on vide la liste si elle contient des items
  if (pListe->GetCount())
    pListe->ClearList() ;

#ifndef N_TIERS

  // On passe en revue tous les s�jours du patient
  NSSejour *pSejour = new NSSejour(pContexte) ;

	// Ouverture du fichier
	pSejour->lastError = pSejour->open() ;
	if (pSejour->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier des s�jours.", standardError, pSejour->lastError, GetHandle()) ;
		delete pSejour ;
		return ;
	}

  string  codeSejour ;
	char    PremOrdre[CSEJ_CODE_LEN + 1] ;

	// Pr�paration du compteur maxi
  int i ;
  for (i = 0 ; i < CSEJ_CODE_LEN ; i++)
    PremOrdre[i] = ' ' ;
	PremOrdre[i] = '\0' ;

  codeSejour = string(pContexte->getPatient()->pDonnees->nss) + string(PremOrdre) ;

	pSejour->lastError = pSejour->chercheClef(&codeSejour, "", 0, keySEARCHGEQ, dbiWRITELOCK) ;
	// Fin de fichier -> pas de s�jour
	if (pSejour->lastError == DBIERR_EOF)
  {
    delete pSejour ;
		return ;
  }

	// Toute autre erreur est anormale
	if (pSejour->lastError != DBIERR_NONE)
	{
		erreur("Le fichier des s�jours est endommag�.", standardError, pSejour->lastError) ;
		delete pSejour ;
		return ;
	}

	// On r�cup�re l'enregistrement
	pSejour->lastError = pSejour->getRecord() ;
	if (pSejour->lastError != DBIERR_NONE)
	{
		erreur("Le fichier des s�jours est endommag�.", standardError, pSejour->lastError) ;
		delete pSejour ;
		return ;
	}

	// Tant que le s�jour trouv� appartient au patient, on remplit la liste
	while ( (pSejour->lastError == DBIERR_NONE) &&
          (strcmp(pSejour->pDonnees->nss, pContexte->getPatient()->pDonnees->nss) == 0))
	{
    pListe->AddString(pSejour->pDonnees->numero) ;

		pSejour->lastError = pSejour->suivant(dbiWRITELOCK) ;

    if (pSejour->lastError == DBIERR_NONE)
    {
			pSejour->lastError = pSejour->getRecord() ;
      if (pSejour->lastError != DBIERR_NONE)
      {
        erreur("Le fichier des s�jours est endommag�.", standardError, pSejour->lastError) ;
        delete pSejour ;
        return ;
      }
    }
    else if (pSejour->lastError != DBIERR_EOF)
    {
      erreur("Le fichier des s�jours est endommag�.", standardError, pSejour->lastError) ;
      delete pSejour ;
      return ;
    }
  }
  delete pSejour ;

#endif

  return ;
}
catch (...)
{
  erreur("Exception (AfficheListe)", standardError, 0) ;
}
}


void
ListeSejoursDialog::CmSelectSejour()
{
  char szNumero[CSEJ_NUMERO_LEN + 1] ;
  int iSel = pListe->GetSelString(szNumero, CSEJ_NUMERO_LEN) ;
  if (iSel > 0)
    sEnCours = string(szNumero) ;
  else
    sEnCours = "" ;
}


void
ListeSejoursDialog::CmSejourDblClk()
{
	char szNumero[CSEJ_NUMERO_LEN + 1] ;
  int iSel = pListe->GetSelString(szNumero, CSEJ_NUMERO_LEN) ;
  if (iSel > 0)
  {
    sEnCours = string(szNumero) ;
    CmModifier() ;
  }
  else
    sEnCours = "" ;
}


void
ListeSejoursDialog::CmOk()
{
  TDialog::CmOk() ;
}


void
ListeSejoursDialog::CmCancel()
{
  TDialog::CmCancel() ;
}


void
ListeSejoursDialog::CmSupprimer()
{
  AfficheListe() ;
}


void
ListeSejoursDialog::CmCreer()
{
  CreerSejourDialog *pCreerSejour = new CreerSejourDialog(this, pContexte) ;
  if (pCreerSejour->Execute() == IDOK)
    AfficheListe() ;
  delete pCreerSejour ;
}


void
ListeSejoursDialog::CmModifier()
{
    AfficheListe();
}


/*

// -----------------------------------------------------------------------------
//
//  M�thodes de EnregChemDialog
//
// -----------------------------------------------------------------------------
DEFINE_RESPONSE_TABLE1(EnregChemDialog, TDialog)
	EV_COMMAND(IDOK, CmOk),
END_RESPONSE_TABLE ;


// -----------------------------------------------------------------------------
// Function     : EnregChemDialog::EnregChemDialog()
// Description  : Constructeur
// -----------------------------------------------------------------------------
EnregChemDialog::EnregChemDialog(TWindow *pere, NSChemiseData *pChemDonnees, char *CodeArmoi, NSContexte *pCtx)
  : NSUtilDialog(pere, pCtx, "IDD_NWCHEM")
{
try
{
	pChemData 	        = pChemDonnees ;

	pCodeArmoireChoisie = CodeArmoi ;
	pNomChem 	       	= new TEdit(this, IDC_NWCHEM_NOM, 35) ;
	pArmoireBox         = new TComboBox(this, IDC_NWCHEM_ARMOI, 35) ;
	pCommentaire        = new TEdit(this, IDC_NWCHEM_COMMENT) ;
}
catch (...)
{
    erreur("Exception EnregChemDialog ctor", standardError, 0);
    return false ;
}
}


// -----------------------------------------------------------------------------
// Function     : EnregChemDialog::~EnregChemDialog()
// Description  : Destructeur, enregistre le document
// -----------------------------------------------------------------------------
EnregChemDialog::~EnregChemDialog()
{
	// Suppression de tous les objets
	delete pNomChem ;
	delete pArmoireBox ;
	delete pCommentaire ;
}


// -----------------------------------------------------------------------------
// Function     : EnregChemDialog::SetupWindow()
// Arguments    :	Aucun
// Description  : Initialise la boite de dialogue
// Returns      :	Rien
// -----------------------------------------------------------------------------
void
EnregChemDialog::SetupWindow()
{
	char 	chAffiche[200], dateAffiche[20], *test ;

	TDialog::SetupWindow() ;

	// Mise du nom du document dans le contr�le Edit
	if (strspn(pChemData->nom, " ") < strlen(pChemData->nom))
		pNomChem->Transfer(pChemData->nom, tdSetData) ;
	else
		pNomChem->Transfer("", tdSetData) ;

	// Remplissage de ArmoireBox avec les armoires
	NSArmoire *pArmoire = new NSArmoire(pContexte) ;

	// Ouverture du fichier
	pArmoire->lastError = pArmoire->open() ;
	if (pArmoire->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier des armoires.", standardError, pArmoire->lastError, GetHandle()) ;
		delete pArmoire ;
    pArmoire = 0 ;
		return ;
	}

	// Recherche de la premi�re armoire du patient
	char codeArmoire[ARM_CODE_LEN + 1] ;
	memset(codeArmoire, ' ', ARM_CODE_LEN) ;
	pArmoire->lastError = pArmoire->chercheClef((unsigned char *)codeArmoire, "", 0, keySEARCHGEQ, dbiWRITELOCK) ;
	if (pArmoire->lastError != DBIERR_NONE)
	{
		erreur("Erreur � la recherche de la 1�re armoire.", standardError, pArmoire->lastError, GetHandle()) ;
		pArmoire->close() ;
		delete pArmoire ;
    pArmoire = 0 ;
		return ;
	}
	pArmoire->lastError = pArmoire->getRecord() ;
	if (pArmoire->lastError != DBIERR_NONE)
	{
		erreur("Erreur � la lecture de la 1�re armoire.", standardError, pArmoire->lastError, GetHandle()) ;
		pArmoire->close() ;
		delete pArmoire ;
    pArmoire = 0 ;
		return ;
	}
	while (pArmoire->lastError == DBIERR_NONE)
	{
		// Ajout de l'armoire � la ArmoireBox
		pArmoireBox->AddString(pArmoire->pDonnees->nom) ;
//		pArmoiresArray->Add(*new NSArmoireInfo(pArmoire)) ;
		pArmoiresArray->push_back(new NSArmoireInfo(pArmoire)) ;

		// Prise de l'armoire suivante
		pArmoire->lastError = pArmoire->suivant(dbiWRITELOCK) ;
		if ((pArmoire->lastError != DBIERR_NONE) && (pArmoire->lastError != DBIERR_EOF))
			erreur("Erreur � l'acc�s � l'armoire suivante.", standardError, pArmoire->lastError, GetHandle()) ;
		else
		{
			pArmoire->lastError = pArmoire->getRecord() ;
			if (pArmoire->lastError != DBIERR_NONE)
				erreur("Erreur � la lecture de l'armoire.", standardError, pArmoire->lastError, GetHandle()) ;
		}
	}
	pArmoire->close() ;
	delete pArmoire ;
  pArmoire = 0 ;
	if (creation)
   	return ;

	// Affichage de l'armoire contenant la chemise
	NSArmChem *pArmChem = new NSArmChem(pContexte) ;
	pArmChem->lastError = pArmChem->open() ;
	if (pArmChem->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier Chem/Doc.", standardError, pArmChem->lastError, GetHandle()) ;
		delete pArmChem ;
		return ;
	}

	// Recherche du document
	//char codeChemise[ACH_CHEMISE_LEN + 1];
	string codeChemise = string(pChemData->code) ;
	pArmChem->lastError = pArmChem->chercheClef(&codeChemise, "CHEMISE", NODEFAULTINDEX, keySEARCHEQ, dbiWRITELOCK) ;
	if (pArmChem->lastError != DBIERR_NONE)
	{
		erreur("Erreur � la recherche de la chemise dans Arm/Chem.", standardError, pArmChem->lastError, GetHandle()) ;
		pArmChem->close() ;
		delete pArmChem ;
		return ;
	}
	pArmChem->lastError = pArmChem->getRecord() ;
	if (pArmChem->lastError != DBIERR_NONE)
	{
		erreur("Erreur � la lecture dans Arm/Chem.", standardError, pArmChem->lastError, GetHandle()) ;
		pArmChem->close() ;
		delete pArmChem ;
		return ;
	}

	// Recherche dans pChemisesArray de la chemise correspondante

	NSArmoireInfo *pArm ;
  int				    i ;
	pArm = &((*pArmoiresArray)[0]) ;
	for (i = 0 ; (i < pArmoiresArray->ArraySize()) && (strcmp(pArm->pDonnees->code, pArmChem->pDonnees->chemise) != 0) ; i++)
    pArm = &((*pArmoiresArray)[i]) ;
	if (i < pArmoiresArray->ArraySize())
		pArmoireBox->SetSelString(pArm->pDonnees->nom, 0) ;


  ArmoiInfoIter   iter, pArm ;
	pArm = pArmoiresArray->begin() ;
  for (iter = pArmoiresArray->begin() ; (iter != pArmoiresArray->end()) && (strcmp((*pArm)->pDonnees->code, pArmChem->pDonnees->chemise) != 0) ; iter++)
  {
    if ( iter != pArmoiresArray->end())
    {
      (*iter)->pDonnees->donneIntitule(chAffiche) ;
      pArmoireBox->SetSelString((*iter)->pDonnees->nom, 0) ;
    }
   }

}


// -----------------------------------------------------------------------------
// Function     : EnregChemDialog::CmOk()
// Description  : R�ponse au bouton OK
// Returns      :	Rien
// -----------------------------------------------------------------------------
void
EnregChemDialog::CmOk()
{
    char 	NomChem[36], *test, Interet[2] ;

	// V�rifie qu'un nom de chemise a bien �t� saisi
	pNomChem->Transfer(NomChem, tdGetData) ;
	if ((NomChem[0] == '\0') || (strspn(NomChem, " ") == strlen(NomChem)))
	{
		erreur("Vous devez saisir un nom de chemise.", warningError, 0, GetHandle()) ;
		return ;
	}

	// Transf�re le nom dans DocumentInfo
	strcpy(pChemData->nom, NomChem) ;

	// R�cup�re le code de l'armoire s�lectionn�e
	ArmoireChoisie = pArmoireBox->GetSelIndex() ;
	if ((ArmoireChoisie < 0) || (size_t(ArmoireChoisie) >= pArmoiresArray->size()))
	{
		erreur("Vous devez choisir une armoire pour abriter cette chemise.", warningError, 0, GetHandle()) ;
		return ;
	}
	NSArmoireInfo *Armoire = (*pArmoiresArray)[ArmoireChoisie] ;
	strcpy(pCodeArmoireChoisie, Armoire->pDonnees->code) ;

	// Effectue le CmOk
	TDialog::CmOk() ;
}

*/

