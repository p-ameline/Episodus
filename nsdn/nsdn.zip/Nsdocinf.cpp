//---------------------------------------------------------------------------//    NSANNEXE.CPP
//    PA   juillet 94
//  Impl�mentation des objets annexes de NAUTILUS
//---------------------------------------------------------------------------
#include <cstring.h>
#include <windows.h>
#include <mem.h>

#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"

#include "nsbb\nsbbtran.h"
#include "nsbb\nspatpat.h"
#include "nsdn\nsdocnoy.h"
#include "nsdn\nsdocum.h"
#include "nsdn\nsdocdlg.h"

#include "nssavoir\nsgraphe.h"

//***************************************************************************
// Impl�mentation des m�thodes NSDocumentData
//***************************************************************************

//---------------------------------------------------------------------------
//  Function:		NSDocumentData::metAZero()
//  Description:	Initialise les champs de donn�es � z�ro.
//  Retour:			Aucun
//---------------------------------------------------------------------------
void NSDocumentData::metAZero()
{
/*
	// Met les champs de donn�es � z�ro
	memset(codePatient,	 0, PAT_NSS_LEN + 1) ;
	memset(codeDocument, 0, DOC_CODE_DOCUM_LEN + 1) ;
	memset(nom, 	   	   0, DOC_NOM_LEN + 1) ;
	memset(creation,   	 0, DOC_CREATION_LEN + 1) ;
	memset(acces, 		   0, DOC_ACCES_LEN + 1) ;
	memset(createur,   	 0, DOC_CREATEUR_LEN + 1) ;
	memset(type, 	   	   0, DOC_TYPE_LEN + 1) ;
	memset(localisation, 0, DOC_LOCALISATION_LEN + 1) ;
	memset(fichier,   	 0, DOC_FICHIER_LEN + 1) ;
	memset(entete,		   0, DOC_ENTETE_LEN + 1) ;
*/

  sCodePatient  = "" ;
	sCodeDocument = "" ;
	sNom          = "" ;
	sDateCreation = "" ;
	sAcces        = "" ;
	sCreateur     = "" ;
	sAuteur       = "" ;
	sDestinataire = "" ;
	sType         = "" ;
	sLocalisation = "" ;
	sFichier         = "" ;  sTemplate        = "" ;  sEnTete          = "" ;  sTypeContenu     = "" ;  sTypeContenuSens = "" ;  sDateExamen      = "" ;  sEmplacement  = "" ;	sInteret      = "" ;
	sCommentaire  = "" ;
	sVisible      = "" ;
	sTranNew      = "" ;
	sTranDel      = "" ;
	sCRC          = "" ;/*	memset(emplacement,	0, DOC_EMPLACEMENT_LEN + 1) ;
  memset(interet,   	0, DOC_INTERET_LEN + 1) ;
  memset(commentaire,	0, DOC_COMMENTAIRE_LEN + 1) ;
  memset(visible,		  0, DOC_VISIBLE_LEN + 1) ;
  memset(tranNew,		  0, DOC_TRAN_LEN + 1) ;
  memset(tranDel,		  0, DOC_TRAN_LEN + 1) ;
  memset(crc,			    0, DOC_CRC_LEN + 1) ;
*/

	sRights = "" ;}

//---------------------------------------------------------------------------//  Fonction:  	NSDocumentData::donneDateCreation()
//  Description:	renvoie la date de cr�ation du document
//  Retour:			string date
//---------------------------------------------------------------------------
string
NSDocumentData::donneDateCreation(string sLang)
{
	string dateCreation = "" ;

	if ((string("") == sDateCreation) || (strlen(sDateCreation.c_str()) < 8))
		return string("") ;

	char szMessage[11] ;
	donne_date((char*) sDateCreation.c_str(), szMessage, sLang) ;

	return string(szMessage) ;
}

//---------------------------------------------------------------------------//  Fonction:		NSDocumentData::NSDocumentData(NSDocumentData& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSDocumentData::NSDocumentData(NSDocumentData& rv)
{
/*
	strcpy(codePatient,	 rv.codePatient) ;
  strcpy(codeDocument, rv.codeDocument) ;	strcpy(nom,			  	 rv.nom) ;
	strcpy(creation, 	   rv.creation) ;
	strcpy(acces, 		   rv.acces) ;
	strcpy(createur, 	   rv.createur) ;
	strcpy(type,		  	 rv.type) ;
  strcpy(localisation, rv.localisation) ;
	strcpy(fichier,			 rv.fichier) ;
  strcpy(entete,			 rv.entete) ;
*/

	sCodePatient  = rv.sCodePatient ;
	sCodeDocument = rv.sCodeDocument ;
	sNom          = rv.sNom ;
	sDateCreation = rv.sDateCreation ;
	sAcces        = rv.sAcces ;
	sCreateur     = rv.sCreateur ;
	sAuteur       = rv.sAuteur ;
	sDestinataire = rv.sDestinataire ;
	sType         = rv.sType ;
	sLocalisation = rv.sLocalisation ;

  sFichier         = rv.sFichier ;  sTemplate        = rv.sTemplate ;  sEnTete          = rv.sEnTete ;  sTypeContenu     = rv.sTypeContenu ;  sTypeContenuSens = rv.sTypeContenuSens ;  sDateExamen      = rv.sDateExamen ;  sEmplacement  = rv.sEmplacement ;	sInteret      = rv.sInteret ;
	sCommentaire  = rv.sCommentaire ;
	sVisible      = rv.sVisible ;
	sTranNew      = rv.sTranNew ;
	sTranDel      = rv.sTranDel ;
	sCRC          = rv.sCRC ;/*	strcpy(emplacement,	rv.emplacement) ;
	strcpy(interet,			rv.interet) ;
	strcpy(commentaire, rv.commentaire) ;
  strcpy(visible,			rv.visible) ;
  strcpy(tranNew,			rv.tranNew) ;
  strcpy(tranDel,			rv.tranDel) ;
  strcpy(crc,				  rv.crc) ;
*/

	sRights = rv.sRights ;}

//---------------------------------------------------------------------------//  Fonction:		NSDocumentData::operator=(NSDocumentData src)
//  Description:	Op�rateur =
//  Retour:			R�f�rence sur l'objet cible
//---------------------------------------------------------------------------
NSDocumentData& NSDocumentData::operator=(NSDocumentData src)
{
	if (this == &src)
		return *this ;

/*
	strcpy(codePatient,	 src.codePatient) ;
  strcpy(codeDocument, src.codeDocument) ;	strcpy(nom,			  	 src.nom) ;
	strcpy(creation, 	   src.creation) ;
	strcpy(acces, 		   src.acces) ;
	strcpy(createur, 	   src.createur) ;
	strcpy(type,		  	 src.type) ;
  strcpy(localisation, src.localisation) ;
	strcpy(fichier,			 src.fichier) ;  strcpy(entete,			 src.entete) ;
*/

	sCodePatient  = src.sCodePatient ;
	sCodeDocument = src.sCodeDocument ;
	sNom          = src.sNom ;
	sDateCreation = src.sDateCreation ;
	sAcces        = src.sAcces ;
	sCreateur     = src.sCreateur ;
	sAuteur       = src.sAuteur ;
	sDestinataire = src.sDestinataire ;
	sType         = src.sType ;
	sLocalisation = src.sLocalisation ;

  sFichier         = src.sFichier ;  sTemplate        = src.sTemplate ;  sEnTete          = src.sEnTete ;  sTypeContenu     = src.sTypeContenu ;  sTypeContenuSens = src.sTypeContenuSens ;  sDateExamen      = src.sDateExamen ;  sEmplacement  = src.sEmplacement ;	sInteret      = src.sInteret ;
	sCommentaire  = src.sCommentaire ;
	sVisible      = src.sVisible ;
	sTranNew      = src.sTranNew ;
	sTranDel      = src.sTranDel ;
	sCRC          = src.sCRC ;/*	strcpy(emplacement,	src.emplacement) ;	strcpy(interet,			src.interet) ;
	strcpy(commentaire, src.commentaire) ;
  strcpy(visible,			src.visible) ;
  strcpy(tranNew,			src.tranNew) ;
  strcpy(tranDel,			src.tranDel) ;
	strcpy(crc,				  src.crc) ;
*/

	sRights = src.sRights ;
	return *this;
}

//---------------------------------------------------------------------------//  Fonction:		NSDocumentData::operator==( const NSDocumentData& o )
//  Description:	Op�rateur de comparaison
//  Retour:			0 ou 1
//---------------------------------------------------------------------------
int NSDocumentData::operator == ( const NSDocumentData& o )
{
	if ((sCodePatient  == o.sCodePatient)  &&
	    (sCodeDocument == o.sCodeDocument) &&
	    (sNom          == o.sNom)          &&
	    (sDateCreation == o.sDateCreation) &&
	    (sAcces        == o.sAcces)        &&
	    (sCreateur     == o.sCreateur)     &&
	    (sAuteur       == o.sAuteur)       &&
	    (sDestinataire == o.sDestinataire) &&
	    (sType         == o.sType)         &&
	    (sLocalisation == o.sLocalisation) &&

/*
  (strcmp(codePatient,	o.codePatient)	== 0) &&
      (strcmp(codeDocument,	o.codeDocument)	== 0) &&
		  (strcmp(nom,			 	  o.nom) 		  	 	== 0) &&
		  (strcmp(creation, 	 	o.creation)	 		== 0) &&
		  (strcmp(acces, 		 		o.acces)		 	  == 0) &&
		  (strcmp(createur, 	 	o.createur)	 		== 0) &&
		  (strcmp(type,		  	 	o.type)			 	  == 0) &&
      (strcmp(localisation,	o.localisation)	== 0) &&
		  (strcmp(fichier,		 	o.fichier)		 	== 0) &&
      (strcmp(entete,				o.entete)			  == 0) &&
*/
      (sFichier     == o.sFichier) &&      (sTemplate    == o.sTemplate) &&      (sEnTete      == o.sEnTete) &&      (sTypeContenu == o.sTypeContenu) &&      (sTypeContenuSens == o.sTypeContenuSens) &&      (sDateExamen  == o.sDateExamen) &&      (sRights      == o.sRights) &&/*		  (strcmp(emplacement, o.emplacement) == 0) &&		  (strcmp(interet,		 o.interet)		 	== 0) &&
		  (strcmp(commentaire, o.commentaire) == 0) &&
      (strcmp(visible,     o.visible)			== 0) &&
      (strcmp(tranNew,		 o.tranNew)			== 0) &&
      (strcmp(tranDel,		 o.tranDel)			== 0) &&
      (strcmp(crc,				 o.crc)				  == 0))
*/
	    (sEmplacement  == o.sEmplacement) &&
      (sInteret      == o.sInteret)     &&
	    (sCommentaire  == o.sCommentaire) &&
	    (sVisible      == o.sVisible)     &&
	    (sTranNew      == o.sTranNew)     &&
	    (sTranDel      == o.sTranDel)     &&
	    (sCRC          == o.sCRC))
		return 1 ;
	else
		return 0 ;
}

void
NSDocumentData::setID(string sId)
{
  if (strlen(sId.c_str()) != PAT_NSS_LEN + DOC_CODE_DOCUM_LEN)
    return ;

  sCodePatient  = string(sId, 0, PAT_NSS_LEN) ;
  sCodeDocument = string(sId, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;
}

//---------------------------------------------------------------------------//  Fonction:		NSDocumentInfo::NSDocumentInfo(NSSuper* pSuper)
//  Description:	Constructeur avec superviseur (pour l'acc�s � la base des chemins)
//  Retour:			Rien
//---------------------------------------------------------------------------
NSDocumentInfo::NSDocumentInfo(NSContexte* pCtx) : NSRoot(pCtx)
{
try
{
	// Cr�e l'objet de donn�es
	pDonnees		= new NSDocumentData() ;
	pMeta 			= new NSPatPathoArray(pCtx) ;	pPres       = new NSPatPathoArray(pCtx) ;	sCodeDocMeta = "" ;	sCodeDocPres = "" ;}catch (...)
{
	erreur("Exception NSDocumentInfo ctor", standardError, 0) ;
}
}
NSDocumentInfo::NSDocumentInfo(string sMeta, NSContexte* pCtx, NSPatInfo* pPatInfo)
               :NSRoot(pCtx){try{	// Cr�e l'objet de donn�es	pDonnees		 = new NSDocumentData() ;
	pMeta 			 = new NSPatPathoArray(pCtx) ;
	pPres        = new NSPatPathoArray(pCtx) ;
	sCodeDocMeta = sMeta ;
	sCodeDocPres = "" ;

	if (pPatInfo == 0)
  	pPatInfo = pContexte->getPatient() ;

	if (!ChargeDocMeta(pPatInfo))
  {
  	char msg[255];
    sprintf(msg, "Impossible de charger le m�ta-document n�%s.", sCodeDocMeta.c_str());
    erreur(msg, standardError, 0) ;
  }
}
catch (...)
{
	erreur("Exception NSDocumentInfo ctor(sMeta)", standardError, 0) ;
}
}
//---------------------------------------------------------------------------//  Function:		NSDocumentInfo::~NSDocumentInfo()
//  Description:	Constructeur.
//  Retour:			Aucun
//---------------------------------------------------------------------------
NSDocumentInfo::~NSDocumentInfo()
{
	// D�truit l'objet de donn�es

	if (NULL != pDonnees)
		delete pDonnees ;
  if (pMeta)
  	delete pMeta ;
  if (pPres)
  	delete pPres ;
}
//---------------------------------------------------------------------------//  Fonction:		NSDocumentInfo::NSDocumentInfo(NSDocumentInfo& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSDocumentInfo::NSDocumentInfo(NSDocumentInfo& rv) : NSRoot(rv.pContexte)
{
try
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSDocumentData() ;
	//
	// Copie les valeurs du NSDocumentInfo d'origine
	//
	*pDonnees = *(rv.pDonnees) ;

	if (rv.pMeta)
  	pMeta = new NSPatPathoArray(*(rv.pMeta)) ;
  else
  	pMeta = new NSPatPathoArray(rv.pContexte) ;

	if (rv.pPres)
  	pPres = new NSPatPathoArray(*(rv.pPres)) ;
  else
  	pPres = new NSPatPathoArray(rv.pContexte) ;

	sCodeDocMeta = rv.sCodeDocMeta ;
	sCodeDocPres = rv.sCodeDocPres ;
}
catch (...)
{
	erreur("Exception NSDocumentInfo copy ctor", standardError, 0) ;
}
}
//---------------------------------------------------------------------------//  Fonction:  	NSDocumentInfo::getNomFichier(sNomFichier)
//  Description:	Renvoie le nom de fichier MSDOS correspondant au document
//  Retour:			false si vide, true si �a a march�
//---------------------------------------------------------------------------
bool NSDocumentInfo::getNomFichier(string& sNomFichier)
{
	string sLocalis = "" ;
	string sPath = "" ;

	// les noms de fichier complets sont inscrits dans la base
	sNomFichier = "" ;

	if (pDonnees->sFichier == "")
  	return false ;

	sLocalis = pDonnees->sLocalisation ;

	// Si le fichier est r�f�renc�, on r�cup�re son PathName
	if (string("") != sLocalis)
	{
  	if (pContexte == 0)
    {
    	erreur("Erreur dans la fonction getNomFichier : Le contexte n'est pas initialis�.", standardError, 0) ;
      return false ;
    }
    else
    	sPath = pContexte->PathName(sLocalis) ;
  }

	sNomFichier = sPath + pDonnees->sFichier ;

	return true ;
}

//---------------------------------------------------------------------------//  Fonction:		NSDocumentInfo::operator=(NSDocumentInfo src)
//  Description:	Op�rateur d'affectation
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
NSDocumentInfo& NSDocumentInfo::operator=(NSDocumentInfo src)
{
	if (this == &src)
		return *this ;

	*pDonnees 	 = *(src.pDonnees) ;
	*pMeta 			 = *(src.pMeta) ;	*pPres       = *(src.pPres) ;	sCodeDocMeta = src.sCodeDocMeta ;	sCodeDocPres = src.sCodeDocPres ;	pContexte 	 = src.pContexte ;
	return *this;}

//---------------------------------------------------------------------------//  Fonction:		NSDocumentInfo::operator == ( const NSDocumentInfo& o )
//  Description:	Op�rateur de comparaison
//  Retour:			0 ou 1
//---------------------------------------------------------------------------
int NSDocumentInfo::operator == ( const NSDocumentInfo& o )
{
	return (*pDonnees == *(o.pDonnees)) ;
}

bool
NSDocumentInfo::LoadMetaAndData(NSPatInfo* pPatInfo)
{
  if (string("") == sCodeDocMeta)
    return false ;

  // First, get the tree containing document's metadata
  //
  if (false == ChargeDocMeta(pPatInfo))
    return false ;

  // Then init meta information
  //
  ParseMetaDonnees() ;

  // Last step: get data information
  //
  return GetDataInformation(pPatInfo) ;
}

//--------------------------------------------------------------------------//recup�rer la patpatho d'un document
//--------------------------------------------------------------------------
bool
NSDocumentInfo::DonnePatPatho(NSPatPathoArray* pPatPathoArray, NSPatInfo* pPatInfo)
{
	if (NULL == pPatPathoArray)
		return false ;
try
{
	pPatPathoArray->vider() ;

	if (NULL == pPatInfo)
		pPatInfo = pContexte->getPatient() ;

	if (pContexte->typeDocument(getType(), NSSuper::isTree))
	{
  	string sCodeDocC = getID() ;
    string sRosace   = "" ;
    /* resultat = */ pPatInfo->pGraphPerson->getTree(sCodeDocC, pPatPathoArray, &sRosace) ;
  }
  else if (pContexte->typeDocument(getType(), NSSuper::isText))
  	// pour tous les types de texte
    pPatPathoArray->ajoutePatho("PXXX51", 0) ;
  else if (pContexte->typeDocument(getType(), NSSuper::isHTML))
  	// pour tous les types d'html statiques (HD trait� plus haut)
    pPatPathoArray->ajoutePatho("PTRIQ3", 0) ;
  else if (pContexte->typeDocument(getType(), NSSuper::isImage))
  	// cas des images : g�n�rique pour tous les types d'image
    // y compris les images anim�es (vid�os)
    pPatPathoArray->ajoutePatho("ZIMA01", 0) ;

/*
	//
	// passer une copie de this pour ne pas deleter pDocInfo
	//
	NSDocumentInfo* pDocument = new NSDocumentInfo(*this) ;
	// NSDocumentInfo* pDocHtml = 0 ;
  // bool resultat;

	if (NULL == pPatInfo)
		pPatInfo = pContexte->getPatient() ;

	if (pContexte->typeDocument(pDocument->getType(), NSSuper::isTree))
	{
  	string sCodeDocC = pDocument->getID() ;
    string sRosace = "" ;
    pPatInfo->pGraphPerson->getTree(sCodeDocC, pPatPathoArray, &sRosace);
  }
  else if (pContexte->typeDocument(pDocument->getType(), NSSuper::isText))
  	// pour tous les types de texte
    pPatPathoArray->ajoutePatho("PXXX51", 0,0) ;
  else if (pContexte->typeDocument(pDocument->getType(), NSSuper::isHTML))
  	// pour tous les types d'html statiques (HD trait� plus haut)
    pPatPathoArray->ajoutePatho("PTRIQ3", 0,0) ;
  else if (pContexte->typeDocument(pDocument->getType(), NSSuper::isImage))
  	// cas des images : g�n�rique pour tous les types d'image
    // y compris les images anim�es (vid�os)
    pPatPathoArray->ajoutePatho("ZIMA01", 0,0) ;
*/

	return true ;
}
catch (...)
{
	erreur("Exception NSDocumentInfo::DonnePatPatho", standardError, 0) ;
	return false ;
}
}

//--------------------------------------------------------------------------
//
// get document's label tree
// charger la patpatho du m�ta-document//
//--------------------------------------------------------------------------bool
NSDocumentInfo::ChargeDocMeta(NSPatInfo* pPatInfo)
{
try
{
	pMeta->vider() ;

  if (NULL == pPatInfo)
		pPatInfo = pContexte->getPatient() ;

  if ((NULL == pPatInfo) || (NULL == pPatInfo->pGraphPerson))
    return false ;

	string sRosace = "" ;
	if (false == pPatInfo->pGraphPerson->getTree(sCodeDocMeta, pMeta, &sRosace))
    return false ;

	pDonnees->sRights = sRosace ;

  // R�cup�ration des donn�es de pr�sentation li�es au m�ta
  VecteurString aVecteurString ;
  pPatInfo->pGraphPerson->pLinkManager->TousLesVrais(sCodeDocMeta, NSRootLink::docComposition, &aVecteurString) ;
  if (aVecteurString.empty())
    return true ;

  sCodeDocPres = *(*(aVecteurString.begin())) ;
  sRosace = "" ;
  bool resultat = pPatInfo->pGraphPerson->getTree(sCodeDocPres, pPres, &sRosace) ;
  //
  // Si on ne les a pas r�cup�r�es, ce n'est pas consid�r� comme anormal
  // si l'arbre est collectif ou groupe (et qu'il provient d'un autre site)
  //
  if (false == resultat)
  {
    string sMetaTreeID = getTreeIDFromID(sCodeDocMeta) ;
    GRAPHELEMTYPE elemType = getGraphElementTypeFromID(sMetaTreeID) ;
    if ((isCollectiveID == elemType) || (isGroupID == elemType))
      resultat = true ;
	}

	return resultat ;
}
catch (...)
{
	erreur("Exception NSDocumentInfo::ChargeDocMeta.", standardError, 0);
	return false ;
}
}
//--------------------------------------------------------------------------//
// parser les donn�es du m�ta-document pour remplir les pDonnees//
//--------------------------------------------------------------------------
boolNSDocumentInfo::ParseMetaDonnees(){	if ((NULL == pMeta) || pMeta->empty())		return false ;  string sElemLex, sSens ;  string sNom, sOper, sType, sTypeSens, sLocalis ;
  string sFichier, sTemplate, sEnTete, sTypeCont ;

  string sTemp = "" ;

  PatPathoIter iter = pMeta->begin() ;

  pDonnees->sInteret = (*iter)->getInteret() ;
  pDonnees->sVisible = (*iter)->getVisible() ;

  int iColBase = (*iter)->getColonne() ;
  iter++ ;

  while ((pMeta->end() != iter) && ((*iter)->getColonne() > iColBase))
  {
  	sElemLex = (*iter)->getLexique() ;
    sSens    = (*iter)->getLexiqueSens(pContexte) ;

    // nom du document
    if (string("0INTI") == sSens)
    {
    	iter++ ;
      sNom = "" ;
      while ((pMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (sElemLex == string("�?????"))
          pDonnees->sNom = (*iter)->getTexteLibre() ;

        iter++ ;
      }
    }
    // op�rateur
    else if (string("DOPER") == sSens)
    {
    	iter++ ;
      sOper = "" ;
      while ((pMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	sElemLex = (*iter)->getLexique() ;
        if (string("�SPID1") == sElemLex)
          pDonnees->sCreateur = (*iter)->getComplement() ;

        iter++ ;
      }
    }
    // auteur
    else if (string("DAUTE") == sSens)
    {
    	iter++ ;
      sOper = "" ;
      while ((pMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	sElemLex = (*iter)->getLexique() ;
        if (string("�SPID1") == sElemLex)
          pDonnees->sAuteur = (*iter)->getComplement() ;

        iter++ ;
      }
    }
    // destinataire
    else if (string("DDEST") == sSens)
    {
    	iter++ ;
      sOper = "" ;
      while ((pMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	sElemLex = (*iter)->getLexique() ;
        if (string("�SPID1") == sElemLex)
          pDonnees->sDestinataire = (*iter)->getComplement() ;

        iter++ ;
      }
    }
    // type
    else if (string("0TYPE") == sSens)
    {
    	iter++ ;
      if ((pMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	pDonnees->sType = (*iter)->getLexiqueSens(pContexte) ;
      	iter++ ;
      }
    }
    // localisation
    else if (string("0LFIC") == sSens)
    {
      pDonnees->sLocalisation = (*iter)->getComplement() ;
      iter++ ;
    }
    // nom de fichier (pour les fichiers statiques)
    else if (string("0NFIC") == sSens)
    {
    	iter++ ;
      sFichier = "" ;
      while ((pMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (string("�?????") == sElemLex)
          pDonnees->sFichier = (*iter)->getTexteLibre() ;
        
        iter++ ;
      }
    }
    // date de r�daction
    else if (string("KREDA") == sSens)
    {
    	iter++ ;
      // int iLigneBase = (*iter)->pDonnees->getLigne() ;

			string sUnite  = (*iter)->getUnitSens(pContexte) ;
			string sFormat = (*iter)->getLexiqueSens(pContexte) ;
			string sValeur = (*iter)->getComplement() ;

			if (string("2DA02") == sUnite)
      {
      	if (strlen(sValeur.c_str()) > DOC_CREATION_LEN)
        	sValeur = string(sValeur, 0, DOC_CREATION_LEN) ;

				pDonnees->sDateCreation = sValeur ;
      }

      iter++ ;
    }
    // date d'examen
    else if (string("KCHIR") == sSens)
    {
    	iter++ ;

			string sUnite  = (*iter)->getUnitSens(pContexte) ;
			string sFormat = (*iter)->getLexiqueSens(pContexte) ;
			string sValeur = (*iter)->getComplement() ;

			if (sUnite == "2DA02")
      {
      	if (strlen(sValeur.c_str()) > 8)
        	sValeur = string(sValeur, 0, 8) ;

				pDonnees->sDateExamen = sValeur ;
      }

      iter++ ;
    }
    // type de contenu (code lexique)
    else if (string("0TYPC") == sSens)
    {
    	iter++ ;
      sTypeCont = "" ;
      while ((pMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        pDonnees->sTypeContenu     = (*iter)->getLexique() ;
        pDonnees->sTypeContenuSens = (*iter)->getLexiqueSens(pContexte) ;
        iter++ ;
      }
    }
    else
    	iter++ ;
  }  // Parsing des donn�es de pr�sentation : template et en-tete  if (!pPres->empty())  {  	iter = pPres->begin() ;    iColBase = (*iter)->pDonnees->getColonne() ;    iter++ ;    while ((iter != pPres->end()) && ((*iter)->pDonnees->getColonne() > iColBase))    {
    	sElemLex = string((*iter)->pDonnees->lexique) ;
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

      // template
      if (sSens == string("0TPL0"))
      {
      	iter++ ;
        sTemplate = "" ;
        while ((iter != pPres->end()) && ((*iter)->pDonnees->getColonne() > iColBase+1))
        {
        	// on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (sElemLex == string("�?????"))
          {
          	sTemplate = (*iter)->pDonnees->getTexteLibre() ;
            pDonnees->sTemplate = sTemplate ;
          }
          iter++ ;
        }
      }
      // en-tete
      else if (sSens == string("0ENTE"))
      {
      	iter++ ;
        sEnTete = "" ;
        while ((iter != pPres->end()) && ((*iter)->pDonnees->getColonne() > iColBase+1))
        {
        	// on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (sElemLex == string("�?????"))
          {
          	sEnTete = (*iter)->pDonnees->getTexteLibre() ;
            pDonnees->sEnTete = sEnTete ;
          }
          iter++ ;
        }
      }
      else
      	iter++ ;
    }  }	return true ;}boolNSDocumentInfo::GetDataInformation(NSPatInfo* pPatInfo){  if (string("") == sCodeDocMeta)    return false ;  if (NULL == pPatInfo)		pPatInfo = pContexte->getPatient() ;

  if ((NULL == pPatInfo) || (NULL == pPatInfo->pGraphPerson))
    return false ;  VecteurString aVecteurString ;  pPatInfo->pGraphPerson->pLinkManager->TousLesVrais(sCodeDocMeta, NSRootLink::docData, &aVecteurString) ;
  if (aVecteurString.empty())
    return false ;

  string sCodeDocData = *(*(aVecteurString.begin())) ;
  setID(sCodeDocData) ;

  return true ;
}
//--------------------------------------------------------------------------//
// enregistrer un nouveau m�ta-document � partir des pDonnees//
//--------------------------------------------------------------------------boolNSDocumentInfo::CommitMetaDonnees(){try{	// NOTE : En N_TIERS on prend simplement un pointeur sur la pMeta pour la mettre � jour.	// (Le fait de passer par un pDocNoy �tait auparavant obligatoire pour la mise � jour)
  //
	NSPatPathoArray* pPptMeta = pMeta ;

  if ((NULL == pPptMeta) || (true == pPptMeta->empty()))
		return true ;

	int iColBase;

	string sLexique ;
	string sNom, sOper, sType, sLocalis ;
	string sFichier, sTemplate, sEnTete, sTypeCont ;
	string sDateReda, sDateExam ;
	bool bExisteDateExam = false ;
	bool bExisteTypeCont = false ;
  bool bExisteAuthor   = false ;

	string sTemp = "" ;

	PatPathoIter iter = pPptMeta->begin() ;
  // interet
  string sInteret = (*iter)->getInteret() ;
  if (sInteret != pDonnees->sInteret)
		(*iter)->setInteret(pDonnees->sInteret) ;
  // visible
  string sVisible = (*iter)->getVisible() ;
  if (sVisible != pDonnees->sVisible)
  	(*iter)->setVisible(pDonnees->sVisible) ;

  iColBase = (*iter)->getColonne() ;
  iter++ ;

	while ((pPptMeta->end() != iter) && ((*iter)->getColonne() > iColBase))
  {
  	string sElemLex = (*iter)->getLexique() ;
    string sSens    = (*iter)->getLexiqueSens(pContexte) ;

    // nom du document
    if (string("0INTI") == sSens)
    {
    	iter++ ;
      sNom = "" ;
      while ((pPptMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (string("�?????") == sElemLex)
        {
        	sNom = (*iter)->getTexteLibre() ;
          if (sNom != pDonnees->sNom)
          	(*iter)->setTexteLibre(pDonnees->sNom) ;
        }
        iter++ ;
      }
    }
    // op�rateur
    else if (string("DOPER") == sSens)
    {
    	iter++ ;
      sOper = "" ;
      while ((pPptMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	sElemLex = (*iter)->getLexique() ;
        if (string("�SPID1") == sElemLex)
        {
        	sOper = (*iter)->getComplement() ;
          if (sOper != pDonnees->sCreateur)
          	(*iter)->setComplement(pDonnees->sCreateur) ;
        }
        iter++ ;
      }
    }
    // auteur
    else if (string("DAUTE") == sSens)
    {
    	iter++ ;
      sOper = "" ;
      while ((pPptMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	sElemLex = (*iter)->getLexique() ;
        if (string("�SPID1") == sElemLex)
        {
        	sOper = (*iter)->getComplement() ;
          if (sOper != pDonnees->sAuteur)
          	(*iter)->setComplement(pDonnees->sAuteur) ;

          bExisteAuthor = true ;
        }
        iter++ ;
      }
    }
    // destinataire
    else if (string("DDEST") == sSens)
    {
    	iter++ ;
      sOper = "" ;
      while ((pPptMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	sElemLex = (*iter)->getLexique() ;
        if (string("�SPID1") == sElemLex)
        {
        	sOper = (*iter)->getComplement() ;
          if (sOper != pDonnees->sDestinataire)
          	(*iter)->setComplement(pDonnees->sDestinataire) ;

          bExisteAuthor = true ;
        }
        iter++ ;
      }
    }
    // type
    else if (string("0TYPE") == sSens)
    {
    	sType = (*iter)->getComplement() ;
      if (sType != pDonnees->sType)
      	(*iter)->setComplement(pDonnees->sType) ;
      iter++ ;
    }
    // localisation
    else if (string("0LFIC") == sSens)
    {
    	sLocalis = (*iter)->getComplement() ;
      if (sLocalis != pDonnees->sLocalisation)
      	(*iter)->setComplement(pDonnees->sLocalisation) ;
      iter++ ;
    }
    // nom de fichier (pour les fichiers statiques)
    else if (string("0NFIC") == sSens)
    {
    	iter++ ;
      sFichier = "" ;
      while ((pPptMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (string("�?????") == sElemLex)
        {
        	sFichier = (*iter)->getTexteLibre() ;
        	if (sFichier != pDonnees->sFichier)
          	(*iter)->setTexteLibre(pDonnees->sFichier) ;
        }
        iter++ ;
      }
    }
    // template
    else if (string("0TPL0") == sSens)
    {
    	iter++ ;
      sTemplate = "" ;
      while ((pPptMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (string("�?????") == sElemLex)
        {
        	sTemplate = (*iter)->getTexteLibre() ;
          if (sTemplate != pDonnees->sTemplate)
          	(*iter)->setTexteLibre(pDonnees->sTemplate) ;
        }
        iter++ ;
      }
    }
    // en-tete
    else if (string("0ENTE") == sSens)
    {
    	iter++ ;
      sEnTete = "";
      while ((pPptMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = (*iter)->getLexique() ;
        if (string("�?????") == sElemLex)
        {
        	sEnTete = (*iter)->getTexteLibre() ;
          if (sEnTete != pDonnees->sEnTete)
          (*iter)->setTexteLibre(pDonnees->sEnTete) ;
        }
        iter++ ;
      }
    }
    // date de r�daction
    else if (string("KREDA") == sSens)
    {
    	iter++ ;
      // int iLigneBase = (*iter)->pDonnees->getLigne() ;

			string sUnite  = (*iter)->getUnitSens(pContexte) ;
			string sFormat = (*iter)->getLexiqueSens(pContexte) ;
			string sValeur = (*iter)->getComplement() ;

			if (string("2DA02") != sUnite)
      	(*iter)->setUnit("2DA021") ;

      if ((sFormat == "") || (sFormat[0] != '�') || ((sFormat[1] != 'D') && (sFormat[1] != 'T')))
      	(*iter)->setLexique("�T0;10") ;

      if (strlen(sValeur.c_str()) > 8)
      	sValeur = string(sValeur, 0, 8) ;

      if (sValeur != pDonnees->sDateCreation)
      {
      	sDateReda = pDonnees->sDateCreation ;
        if (strlen(sDateReda.c_str()) == 8)
        	sDateReda += string("000000") ;
        (*iter)->setComplement(sDateReda) ;
      }

      iter++ ;
    }
    // date d'examen
    else if (string("KCHIR") == sSens)
    {
    	iter++ ;
      // int iLigneBase = (*iter)->pDonnees->getLigne() ;
      bExisteDateExam = true ;

			string sUnite  = (*iter)->getUnitSens(pContexte) ;
			string sFormat = (*iter)->getLexiqueSens(pContexte) ;
			string sValeur = (*iter)->getComplement() ;

			if (string("2DA02") != sUnite)
      	(*iter)->setUnit("2DA021") ;

      if ((sFormat == "") || (sFormat[0] != '�') || ((sFormat[1] != 'D') && (sFormat[1] != 'T')))
      	(*iter)->setLexique("�T0;10") ;

      if (strlen(sValeur.c_str()) > 8)
      	sValeur = string(sValeur, 0, 8) ;

      if (sValeur != pDonnees->sDateExamen)
      {
      	sDateExam = pDonnees->sDateExamen ;
        if (strlen(sDateExam.c_str()) == 8)
        	sDateExam += string("000000") ;
        (*iter)->setComplement(sDateExam) ;
      }

      iter++ ;
    }
    // type de contenu (code lexique)
    else if (string("0TYPC") == sSens)
    {
    	iter++ ;
      bExisteTypeCont = true ;
      sTypeCont = "" ;

      while ((pPptMeta->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
      	// on cherche ici un texte libre
        sTypeCont = (*iter)->getLexique() ;
        if (sTypeCont != pDonnees->sTypeContenu)
        	(*iter)->setLexique(pDonnees->sTypeContenu) ;

        iter++ ;
      }
    }
    else
    	iter++ ;
  }

  // Pour les informations d�pendantes des donn�es (pPatPathoArray)
	// on doit rajouter les infos manquantes au m�ta
  if ((false == bExisteDateExam) && (string("") != pDonnees->sDateExamen))
  {
    pPptMeta->ajoutePatho("KCHIR2", 1) ;
    sDateExam = pDonnees->sDateExamen ;
    sDateExam += string("000000") ;
    Message Msg ;
    Msg.SetUnit("2DA021") ;
    Msg.SetComplement(sDateExam.c_str()) ;
    pPptMeta->ajoutePatho("�T0;19", &Msg, 2) ;
  }

  if ((false == bExisteTypeCont) && (string("") != pDonnees->sTypeContenu))
  {
  	pPptMeta->ajoutePatho("0TYPC1", 1) ;
    pPptMeta->ajoutePatho(pDonnees->sTypeContenu, 2) ;
  }

	if ((false == bExisteAuthor) && (string("") != pDonnees->sAuteur))
  {
    pPptMeta->ajoutePatho("DAUTE1", 1) ;
    Message Msg ;
    Msg.SetComplement(pDonnees->sAuteur) ;
    pPptMeta->ajoutePatho("�SPID1", &Msg, 2) ;
  }

  // mise � jour des donn�es de pr�sentation
  if (!pPres->empty())
  {
  	iter = pPres->begin() ;
    iColBase = (*iter)->getColonne() ;
    iter++ ;

    while ((pPres->end() != iter) && ((*iter)->getColonne() > iColBase))
    {
    	string sElemLex = (*iter)->getLexique() ;
      string sSens    = (*iter)->getLexiqueSens(pContexte) ;

      // template
      if (string("0TPL0") == sSens)
      {
      	iter++ ;
        sTemplate = "" ;
        while ((pPres->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
        {
        	// on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (sElemLex == string("�?????"))
          {
          	sTemplate = (*iter)->getTexteLibre() ;
            if (sTemplate != pDonnees->sTemplate)
            	(*iter)->setTexteLibre(pDonnees->sTemplate) ;
          }
          iter++ ;
        }
      }
      // en-tete
      else if (sSens == string("0ENTE"))
      {
      	iter++ ;
        sEnTete = "" ;
        while ((pPres->end() != iter) && ((*iter)->getColonne() > iColBase + 1))
        {
        	// on cherche ici un texte libre
          sElemLex = (*iter)->getLexique() ;
          if (sElemLex == string("�?????"))
          {
          	sEnTete = (*iter)->getTexteLibre() ;
            if (sEnTete != pDonnees->sEnTete)
            	(*iter)->setTexteLibre(pDonnees->sEnTete) ;
          }
          iter++ ;
        }
      }
      else
      	iter++ ;
    }
  }

	return true ;
}
catch (...)
{
	erreur("Exception NSDocumentInfo::CommitMetaDonnees.", standardError, 0) ;
	return false ;
}}boolNSDocumentInfo::InitDocumentBrut(NSDocumentInfo** ppDocument){try{
	if (true == ParseMetaDonnees())
	{
		*ppDocument = new NSDocumentInfo(*this) ;
    return true ;
	}
	return false ;
}
catch (...)
{
	erreur("Exception NSDocumentInfo::InitDocumentBrut.", standardError, 0) ;
	return false ;
}}stringNSDocumentInfo::getDocTitleWithDate(){	string sLang = "" ;  if (pContexte->getUtilisateur())
  	sLang = pContexte->getUtilisateur()->donneLang() ;

	string sDocName = getDocName() ;
  if (string("") == sDocName)
  {
  	string sContent = getContent() ;
    if (string("") != sContent)
  		pContexte->getDico()->donneLibelle(sLang, &sContent, &sDocName) ;
    if (string("") == sDocName)
  		sDocName = string("?") ;
  }  if (string("") != getDateExm())  {
  	char dateAffiche[20] ;
    donne_date((char*)getDateExm().c_str(), dateAffiche, sLang) ;
    sDocName += string(" - ") + string(dateAffiche) ;
  }  return sDocName ;}
void
NSDocumentInfo::setContent(string sCo)
{
	if (string("") == sCo)
	{
  	pDonnees->sTypeContenu     = string("") ;
    pDonnees->sTypeContenuSens = string("") ;
  }

	string sCoSens = pContexte->getDico()->donneCodeSens(&sCo) ;
  if (sCoSens == sCo)
  {
  	pDonnees->sTypeContenuSens = sCo ;
    pDonnees->sTypeContenu     = sCo ;
    pContexte->getDico()->donneCodeComplet(pDonnees->sTypeContenu) ;
  }
  else
  {
		pDonnees->sTypeContenu     = sCo ;
    pDonnees->sTypeContenuSens = sCoSens ;
  }
}

// fin de nsdocinf.cpp
