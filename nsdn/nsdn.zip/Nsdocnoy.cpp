//----------------------------------------------------------------------------// NSNoyauDocument : P�re des documents NAUTILUS, il permet de leur attacher un
//						 pointeur sur un DocumentInfo.
//----------------------------------------------------------------------------
#define __NSDOCNOY_CPP

#include <owl\docmanag.h>
#include <stdio.h>
#include <classlib\filename.h>
#include <sysutils.hpp>

#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "partage\nsperson.h"
#include "nautilus\nshistdo.h"
#include "nautilus\nsbasimg.h"
#include "nsdn\nsdocnoy.h"
#include "nsdn\nsintrad.h"
#include "nsdn\nsdn_dlg.h"
#include "nsdn\nsdn.h"
#include "nsdn\nsdocdlg.h"
#include "nsbb\nstlibre.h"
#include "nsbb\nsbbtran.h"
#include "nssavoir\nsgraphe.h"
#include "nautilus\nsanxary.h"

#include "pilot\NautilusPilot.hpp"
#include "nsbb\tagnames.h"
// Classe des param�tres d'impression
// pour WebBrowserPrint
NSPrintParams::NSPrintParams()
{
    reset();
}

NSPrintParams::NSPrintParams(NSPrintParams& rv)
{
    // Page Setup dialog settings
    sPaperSize      = rv.sPaperSize;
    sPaperSource    = rv.sPaperSource;
    sHeader         = rv.sHeader;
    sFooter         = rv.sFooter;
    sOrientation    = rv.sOrientation;
    sfLeftMargin    = rv.sfLeftMargin;
    sfTopMargin     = rv.sfTopMargin;
    sfRightMargin   = rv.sfRightMargin;
    sfBottomMargin  = rv.sfBottomMargin;

    // Print dialog settings
    sPrinterName    = rv.sPrinterName;
    sbPrintToFile   = rv.sbPrintToFile;
    sPrintRange     = rv.sPrintRange;
    slPrintRangePagesFrom = rv.slPrintRangePagesFrom;
    slPrintRangePagesTo = rv.slPrintRangePagesTo;
    sbCollate       = rv.sbCollate;
    sPrintFrames    = rv.sPrintFrames;
    sbPrintLinks    = rv.sbPrintLinks;
    sbPrintLinkTable = rv.sbPrintLinkTable;
}

NSPrintParams::~NSPrintParams()
{
}

NSPrintParams&
NSPrintParams::operator=(NSPrintParams src)
{
    // Page Setup dialog settings
    sPaperSize      = src.sPaperSize;
    sPaperSource    = src.sPaperSource;
    sHeader         = src.sHeader;
    sFooter         = src.sFooter;
    sOrientation    = src.sOrientation;
    sfLeftMargin    = src.sfLeftMargin;
    sfTopMargin     = src.sfTopMargin;
    sfRightMargin   = src.sfRightMargin;
    sfBottomMargin  = src.sfBottomMargin;

    // Print dialog settings
    sPrinterName    = src.sPrinterName;
    sbPrintToFile   = src.sbPrintToFile;
    sPrintRange     = src.sPrintRange;
    slPrintRangePagesFrom = src.slPrintRangePagesFrom;
    slPrintRangePagesTo = src.slPrintRangePagesTo;
    sbCollate       = src.sbCollate;
    sPrintFrames    = src.sPrintFrames;
    sbPrintLinks    = src.sbPrintLinks;
    sbPrintLinkTable = src.sbPrintLinkTable;

    return *this;
}

/******************
intNSPrintParams::operator==(NSPrintParams& o){}********************/void
NSPrintParams::reset()
{
    // Page Setup dialog settings : initialisation � vide (prise de la valeur par d�faut)
    sPaperSize = "", sPaperSource = "", sHeader = "", sFooter = "";
    sOrientation = "", sfLeftMargin = "", sfTopMargin = "", sfRightMargin = "", sfBottomMargin = "";

    // Print dialog settings : initialisation � vide (prise de la valeur par d�faut)
    sPrinterName = "", sbPrintToFile = "", sPrintRange = "";
    slPrintRangePagesFrom = "", slPrintRangePagesTo = "", sbCollate = "";
    sPrintFrames = "", sbPrintLinks = "", sbPrintLinkTable = "";
}

// --------------------------------------------------------------------------// --------------------- METHODES DE NSNoyauDocument --------------------------
// --------------------------------------------------------------------------

//---------------------------------------------------------------------------
//  Constructeur
//
//  parent 	  	   : TDocument parent (?)
//	 pDocumentInfo : pointeur sur l'objet NSDocumentInfo qui
//						  permet de r�f�rencer le NSDocument
//	 pSuper		   : pointeur sur le superviseur
//---------------------------------------------------------------------------
NSNoyauDocument::NSNoyauDocument(TDocument* parent, NSDocumentInfo* pDocumentInfo,
                                 NSDocumentInfo* pDocHtmlInfo, NSContexte* pCtx, bool bROnly)
                :TDocument(parent), NSRoot(pCtx)
{
try
{
  bReadOnly = bROnly ;

	// on duplique le pDocumentInfo pour �viter sa destruction par
	// la ListBox des documents (ce qui n'est pas le cas du pDocHtmlInfo
	// qui est instanci� par le superviseur)

	if (NULL != pDocumentInfo)
		pDocInfo = new NSDocumentInfo(*pDocumentInfo);
	else
		pDocInfo = 0;

	pHtmlInfo = pDocHtmlInfo;

	pPatPathoArray  = new NSPatPathoArray(pContexte);
	// pDonneesArray   = new NSPatPaDatArray(pContexte);
	// pLocalisArray   = new NSPatPaLocArray(pContexte);
	pArcNodeArray   = new NSArcNodeArray();
	sNomDocHtml     = "";	sTemplate       = "";	sEnTete         = "";
	sBaseImages     = "";
	sBaseCompo      = "";
	sBaseTemp       = "";
	bConserveBase   = false;
	bEnregEnCours   = false;

	sCodeDocMeta    = "";
	sCodeDocPres    = "";
	bCreerMetaLien  = false;
	bEnregPresentation = false;

	if (pDocInfo)
	{
  	if (pContexte->typeDocument(pDocInfo->getType(), NSSuper::isTree))
    {
    	// En N_TIERS, on r�cup�re en g�n�ral la patpatho depuis l'historique
      string sCodeDoc = pDocInfo->getID() ;
			NSPatPathoArray* pPatPathoSource = pContexte->getPatient()->pDocHis->DonnePatPathoDocument(sCodeDoc) ;
			if (pPatPathoSource != NULL)
			{
				*pPatPathoArray = *pPatPathoSource ;
				bDocumentValide = true ;
			}
			else
				bDocumentValide = false ;
    }
  }

	// on met � jour le titre
	SetTitreDoc() ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument ctor.", standardError, 0) ;
}
}

NSNoyauDocument::NSNoyauDocument(TDocument* parent, NSContexte* pCtx)
                :TDocument(parent), NSRoot(pCtx)
{
try
{
	bReadOnly = true ;

	pDocInfo = 0;
	pHtmlInfo = 0;

	pPatPathoArray  = new NSPatPathoArray(pContexte);
	// pDonneesArray   = new NSPatPaDatArray(pContexte);
	// pLocalisArray   = new NSPatPaLocArray(pContexte);
	pArcNodeArray   = new NSArcNodeArray();
  sNomDocHtml     = "" ;  sTemplate       = "" ;  sEnTete         = "" ;
  sBaseImages     = "" ;
  sBaseCompo      = "" ;
  sBaseTemp       = "" ;
  bConserveBase   = false ;
  bEnregEnCours   = false ;

	sCodeDocMeta    = "";
	sCodeDocPres    = "";
	bCreerMetaLien  = false;
	bEnregPresentation = false;

	bDocumentValide = true;
}
catch (...)
{
	erreur("Exception NSNoyauDocument ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//   Destructeur
//---------------------------------------------------------------------------
NSNoyauDocument::~NSNoyauDocument()
{
try
{
	NSBaseImages* pBase ;

	if (pDocInfo)
		delete pDocInfo ;
	if (pHtmlInfo)
		delete pHtmlInfo ;

  if (pPatPathoArray)
      delete pPatPathoArray ;
  // if (pDonneesArray)
  //    delete pDonneesArray ;
  // if (pLocalisArray)
  //    delete pLocalisArray ;
  if (pArcNodeArray)
      delete pArcNodeArray ;

  // destruction de la base d'images et de la base temporaire
  if ((!bConserveBase) && (sBaseImages != "")) // si la base a �t� initialis�e
  {
  	pBase = new NSBaseImages(sBaseImages) ;
    pBase->lire() ;
    pBase->detruire() ;
    delete pBase ;
  }

  if (sBaseTemp != "")		// si la base a �t� initialis�e
  {
  	pBase = new NSBaseImages(sBaseTemp) ;
    pBase->lire() ;
    pBase->detruire() ;
    delete pBase ;
  }
}
catch (...)
{
	erreur("Exception NSNoyauDocument destructor.", standardError, 0) ;
}
}

// Constructeur copieNSNoyauDocument::NSNoyauDocument(NSNoyauDocument& rv)
                :TDocument(rv.GetParentDoc()), NSRoot(rv.pContexte)
{
try
{
  bReadOnly = rv.bReadOnly ;

	if (rv.pDocInfo)
  	pDocInfo = new NSDocumentInfo(*(rv.pDocInfo)) ;
	else
		pDocInfo = 0 ;

	if (rv.pHtmlInfo)
		pHtmlInfo = new NSDocumentInfo(*(rv.pHtmlInfo)) ;
	else
		pHtmlInfo = 0 ;

	pPatPathoArray  = new NSPatPathoArray(*(rv.pPatPathoArray)) ;
	bDocumentValide = rv.bDocumentValide ;

	sCodeDocMeta = rv.sCodeDocMeta ;
    sCodeDocPres = rv.sCodeDocPres ;
	bCreerMetaLien = rv.bCreerMetaLien ;
    bEnregPresentation = rv.bEnregPresentation ;

	sNomDocHtml = rv.sNomDocHtml ;
	sTemplate   = rv.sTemplate ;
	sEnTete     = rv.sEnTete ;
	sBaseImages = "" ;
	sBaseCompo  = "" ;
	sBaseTemp   = "" ;
	bConserveBase = false ;
	bEnregEnCours = false ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument copy ctor.", standardError, 0) ;
}
}

// Operateur =// Pb : comment affecter le document parent destination ?????????????????
NSNoyauDocument&
NSNoyauDocument::operator=(NSNoyauDocument src)
{
try
{
	if (this == &src)
		return *this ;

	bReadOnly = src.bReadOnly ;

	pContexte = src.pContexte ;

	if (src.pDocInfo)
  	pDocInfo = new NSDocumentInfo(*(src.pDocInfo)) ;
	else
  	pDocInfo = 0 ;

	if (src.pHtmlInfo)
		pHtmlInfo = new NSDocumentInfo(*(src.pHtmlInfo)) ;
	else
  	pHtmlInfo = 0 ;

	pPatPathoArray = new NSPatPathoArray(*(src.pPatPathoArray)) ;
	bDocumentValide = src.bDocumentValide ;

	sCodeDocMeta = src.sCodeDocMeta ;
    sCodeDocPres = src.sCodeDocPres ;
	bCreerMetaLien = src.bCreerMetaLien ;
    bEnregPresentation = src.bEnregPresentation ;

	sNomDocHtml = src.sNomDocHtml ;
	sTemplate   = src.sTemplate ;
	sEnTete     = src.sEnTete ;
	sBaseImages = "" ;
	sBaseCompo  = "" ;
	sBaseTemp   = "" ;
	bConserveBase = false ;
	bEnregEnCours = false ;

	return *this ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument = operator.", standardError, 0) ; return *this;
}
}

// Fonction de maj du titre du document en fonction du pDocInfo//// MODIFIER//void
NSNoyauDocument::SetTitreDoc()
{
try
{
	char chAffiche[300], dateAffiche[20], dateDoc[20] ;
	bool bIsDocPermanent = false ;
	string sDate = "" ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	strcpy(chAffiche, "") ;

	if (!pPatPathoArray->empty())
	{
		PatPathoIter iter = pPatPathoArray->begin() ;
    string sCodeSens = (*iter)->getLexiqueSens(pContexte) ;
    if ((sCodeSens == "ZSYNT") || (sCodeSens == "ZADMI"))
    	bIsDocPermanent = true ;
	}

	if (pDocInfo != 0)
	{
		strcpy(chAffiche, pDocInfo->getDocName().c_str()) ;

		if (chAffiche[0] != '\0')
    {
    	ote_blancs(chAffiche) ;

      if (!bIsDocPermanent)
      {
      	// si la patpatho n'est pas vide, on stocke dans le titre la date patpatho
        if (!pPatPathoArray->empty())
        {
        	// First, check if first element is a KCHIR
    			//
  				PatPathoIter iterPpt = pPatPathoArray->begin() ;
    			iterPpt++ ;
    			if (iterPpt != pPatPathoArray->end())
    				if ((*iterPpt)->getLexiqueSens(pContexte) == "KCHIR")
      				pPatPathoArray->CheminDansPatpatho(0, "KCHIR", &sDate) ;

    			if (sDate == "")
        		pPatPathoArray->CheminDansPatpatho(0, "LADMI/KCHIR", &sDate) ;

          if (sDate != "")
          	strcpy(dateDoc, sDate.c_str()) ;
          else
          	strcpy(dateDoc, pDocInfo->getCreDate().c_str()) ;

        }
        else // sinon on prend la date de creation
        	strcpy(dateDoc, pDocInfo->getCreDate().c_str()) ;

        // la date est concat�n�e au nom du document
        if (strlen(dateDoc) > 0)
				{
					strcat(chAffiche, " du ") ;
					donne_date(dateDoc, dateAffiche, sLang) ;
					strcat(chAffiche, dateAffiche) ;
        }
      }
		}
    //
    // En mode navigation web, le cr�ateur du document est vide
    //
    if ((!bIsDocPermanent) && (string("") != pDocInfo->getCreator()))
    {
    	string sNss = pDocInfo->getCreator() ;
      NSPersonInfo* pUtil = pContexte->getPersonArray()->getPerson(sNss, pidsUtilisat) ;
      string sCreateur = pUtil->sCivilite ;
      strcat(chAffiche, " - ") ;
      strcat(chAffiche, sCreateur.c_str()) ;
    }
	}

	//
	// Instancie la donnee Title de TDocument
	//
	SetTitle(chAffiche) ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument SetTitreDoc.", standardError, 0) ;
}
}

// Fonction qui renvoie la date stock�e dans la PatPatho des datas en MUE
// au format jj/mm/aaaa ou au format Nautilus (aaaammjj) selon bDateClaire
string
NSNoyauDocument::GetDateExamen(bool bDateClaire)
{
try
{
	string sDate = "";
	string sMessage;
	string sIntro;

	if (!pPatPathoArray->empty())
  {
  	// First, check if first element is a KCHIR
    //
  	PatPathoIter iterPpt = pPatPathoArray->begin() ;
    iterPpt++ ;
    if (iterPpt != pPatPathoArray->end())
    	if ((*iterPpt)->getLexiqueSens(pContexte) == "KCHIR")
      	pPatPathoArray->CheminDansPatpatho(0, "KCHIR", &sDate) ;

    if (sDate == "")
			pPatPathoArray->CheminDansPatpatho(0, "LADMI/KCHIR", &sDate) ;
	}

	if ((!bDateClaire) || (sDate == ""))
		return sDate ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	donne_date_claire(sDate, &sMessage, &sIntro, sLang) ;

	if (sIntro != "")
		sDate = sIntro + " " + sMessage ;
	else
		sDate = sMessage ;

	return sDate ;
}
catch (...)
{
	erreur("Exception GetDateExamen.", standardError, 0) ;
	return "" ;
}
}

// Fonction qui remet � jour la pDocInfo en fonction des donn�es
// issues de la patpatho du document (aujourd'hui date d'examen et type de contenu)
// Si la pDocInfo est remise � jour, renvoie true, false sinon.
bool
NSNoyauDocument::DocInfoModified()
{
	bool bIsModified = false ;

	// date examen valide
	string sDateExamen = GetDateExamen(false) ;
  // Type de contenu : analyse de la patpatho en cours
  string sLexique = string("") ;

  if (!pPatPathoArray->empty())
  {
		PatPathoIter iter = pPatPathoArray->begin() ;
    sLexique = (*iter)->getLexique() ;
  }
  else if (string("") != pDocInfo->getType())
  {
  	switch ((pDocInfo->getType())[0])
    {
    	// dans les 3 cas qui restent, les document n'ont pas patpatho, on leur
      // en cr�e une qui contient seulent le code lexique correspondant :
      // ZIMA01 pour image
      // PXXX51 : code bidon pour texte
      // PTRIQ3 : pour HTML

      case 'T' :  // pour tous les types de texte
      	sLexique = string("PXXX51") ;
        break ;

      case 'H' :  // pour tous les types d'html statiques (HD trait� plus haut)
      	sLexique = string("PTRIQ3") ;
        break ;

      case 'I' :  // cas des images : g�n�rique pour tous les types d'image
         			    // y compris les images anim�es (vid�os)
      	sLexique = string("ZIMA01") ;
        break ;
    }
  }

	if ((string("") != sDateExamen) && (pDocInfo->getDateExm() != sDateExamen))
  {
		pDocInfo->setDateExm(sDateExamen) ;
    bIsModified = true ;
	}

	if ((string("") != sLexique) && (pDocInfo->getContent() != sLexique))
	{
		pDocInfo->setContent(sLexique) ;
    bIsModified = true ;
	}

	return bIsModified ;
}

//  +-----------------------------------------------------------------+//  �                    Calcul de l'�ge du patient                   �
//  +-----------------------------------------------------------------+
//  Cr�� le 17/07/1995 Derni�re mise � jour 17/07/1995
int
NSNoyauDocument::donne_age(char *datex)
{
	unsigned int i, j;
	signed   int age;
	unsigned int mois_nais, mois_jour, jour_nais, jour_jour;
	char 		 dateNaiss[9];
	//
	// On ne calcule l'�ge que si on a la date de naissance
	//
	if (!pContexte->getPatient()->donneNaissance(dateNaiss))
		return -1;
	if (strcmp(dateNaiss, "00000000") == 0)
		return -1;
	//
	// Ann�e de l'examen
	//
	i = 10 * donneDigit(datex[0]) + donneDigit(datex[1]);
	i = (i - 18) * 100;
	i += 10 * donneDigit(datex[2]) + donneDigit(datex[3]);
	//
	// Ann�e de naissance du patient
	//
	j = 10 * donneDigit(dateNaiss[0]) + donneDigit(dateNaiss[1]);
	j = (j - 18) * 100;
	j += 10 * donneDigit(dateNaiss[2]) + donneDigit(dateNaiss[3]);
	//
	// Age qu'aura le patient dans l'ann�e
	//
	age = i - j;
	//
	// Correctifs en fonction de mois et jour
	//
	mois_nais = 10 * donneDigit(dateNaiss[4]) + donneDigit(dateNaiss[5]);
	jour_nais = 10 * donneDigit(dateNaiss[6]) + donneDigit(dateNaiss[7]);
	mois_jour = 10 * donneDigit(datex[4]) + donneDigit(datex[5]);
	jour_jour = 10 * donneDigit(datex[6]) + donneDigit(datex[7]);
	if ((mois_jour < mois_nais) ||
		 ((mois_jour == mois_nais) && (jour_jour < jour_nais)))
		age--;
	if ((age < 0) || (age > 150))
		return -1;
	return age;
}

//  +-----------------------------------------------------------------+
//  �              Donne l'intitul� (Monsieur, Madame...)             �
//  +-----------------------------------------------------------------+
//  Cr�� le 17/07/1995 Derni�re mise � jour 17/07/1995
//
// MODIFIER
//
void
NSNoyauDocument::donne_intitule_patient(string *intitule, int age)
{
	if (pContexte->getPatient()->estFeminin())
		*intitule = "Madame ";
	else
		*intitule = "Monsieur ";
	//
	// Correctifs en fonction de l'age
	//
	if ((age < 0) || (age > 150)) return ;
	if (age <= 15)
	{
		*intitule = "l'enfant ";
		return;
	}

	if ((pContexte->getPatient()->estFeminin()) && (age < 18))
		*intitule = "Mademoiselle ";
}

////////////////////////////////////////////////////////////////bool
NSNoyauDocument::CanClose()
{
	if (bEnregEnCours)
	{
		erreur("Ce document est en cours d'enregistrement.", standardError, 0) ;
		return false ;
	}
	else
		return (!IsDirty()) ;
}

// ---------------------------------------------------------------------------//   Instancie pPatPathoArray
//
//   Va chercher les donn�es dans PATPADAT et les localisations correspondant
//	  � la transaction la plus r�cente dans PATPALOC
//	  Reconstitue la patpatho � partir de ces deux arrays
// ---------------------------------------------------------------------------
bool
NSNoyauDocument::chargePatPatho()
{
try
{
	// Note importante : dans un document on utilise obligatoirement le graphe du patient
  //
  NSPersonGraphManager* pGraphManager = pContexte->getPatient()->pGraphPerson ;
  string sCodeDoc = pDocInfo->getID() ;
  if (sCodeDoc == "")
  {
  	erreur("Code document vide dans chargePatPatho().", standardError, 0) ;
		return false ;
	}

	string sRosace = "" ;
	return pGraphManager->getTree(sCodeDoc, pPatPathoArray, &sRosace) ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument::chargePatPatho.", standardError, 0) ;
	return false ;
}
}

bool
NSNoyauDocument::enregistrePatPatho()
{
try
{
	string ps2 = "NSNoyauDocument::enregistrePatPatho : begin" ;
	pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

	if (bReadOnly)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("privilegeManagement", "readOnlyDoc") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return false ;
	}

	if ((NULL == pPatPathoArray) || (pPatPathoArray->empty()))
		return true ;

	// Note importante : dans un document on utilise obligatoirement le graphe du patient
	NSPersonGraphManager* pGraphManager = pContexte->getPatient()->pGraphPerson ;
	NSLinkManager*        pLink         = pGraphManager->pLinkManager ;

  ps2 = pContexte->getSuperviseur()->getText("documentManagementStatus", "documentBeingSaved") ;
	pContexte->getSuperviseur()->afficheStatusMessage((char*)ps2.c_str()) ;

	// Phase de remise � jour des m�ta-donn�es :
	// Si on a une patpatho non vide, on v�rifie si il faut updater les metas
	// en testant pDocInfo->sCodeDocMeta
	if ((pDocInfo->sCodeDocMeta != "") && (DocInfoModified()))
		pDocInfo->CommitMetaDonnees() ;

	//
	// On �tablit ici le lien des donn�es (patpatho en cours) avec le m�ta-document s'il existe	//	if ((bCreerMetaLien) && (sCodeDocMeta != ""))	{  	string sNodeMeta = sCodeDocMeta ;		string sNodeData = pDocInfo->getID() ;		if (!pLink->etablirLien(sNodeMeta, NSRootLink::docData, sNodeData))		{
			erreur("Impossible d'initialiser le lien vers le document data.", standardError, 0) ;
			return false ;
		}		bCreerMetaLien = false ;	}  /******************************** travail fait maintenant par signChanges	else if (sCodeDocMeta != "")	{		// Note : le lien contributionModified ne peut s'�tablir que la deuxi�me fois		// qu'on enregistre les donn�es, car la premi�re fois bCreerMetaLien est true.		string sNodeMeta = sCodeDocMeta;		string sContribution = pContexte->getPatient()->getContribution();		if (!pLink->existeLien(sNodeMeta, NSRootLink::contributionModified, sContribution))		{			// lien du m�ta vers la contribution en cours			if (!pLink->etablirLien(sNodeMeta, NSRootLink::contributionModified, sContribution))				erreur("Impossible d'initialiser le lien du document vers la contribution en cours du patient.", standardError, 0) ;		}	}
    ********************************************************************************/

  // on doit r�cup�rer les traits du patient dans la patpatho, qui a pu changer
  // et non dans le patient en cours, qui est mis � jour par la suite.
  string sNom, sPrenom, sCode, sSexe, sNaissance, sCivilite ;
  if ((false == pPatPathoArray->empty()) && ((*(pPatPathoArray->begin()))->getLexique() == "ZADMI1"))
  	pGraphManager->ChargeDonneesAdmin(pPatPathoArray, sNom, sPrenom, sCode, sSexe, sNaissance, sCivilite) ;
  else
  {
  	sNom       = pContexte->getPatient()->getNom() ;
    sPrenom    = pContexte->getPatient()->getPrenom() ;
    sSexe      = pContexte->getPatient()->getSexe() ;
    sNaissance = pContexte->getPatient()->getNaissance() ;
  }

  // Modification des traits
  pGraphManager->setAdminAttrArray(NSPersonGraphManager::attribsChange, sNom, sPrenom, sSexe, sNaissance) ;

  // Vecteur d'update contenant la patpatho en cours et �ventuellement les m�tas
	NSVectPatPathoArray VectUpdate ;

	// on stocke maintenant le document dans le vecteur d'update avec ses metas
	// et on envoie le tout au pilote
	if (sCodeDocMeta != "")
  	VectUpdate.push_back(new NSPatPathoArray(*(pDocInfo->pMeta))) ;

	// On redonne aux noeuds leurs informations de patient et document
	for (PatPathoIter i = pPatPathoArray->begin(); i != pPatPathoArray->end(); i++)
	{
		(*i)->setPerson(pDocInfo->getPatient()) ;
		(*i)->setDocum(pDocInfo->getDocument()) ;
	}

	VectUpdate.push_back(new NSPatPathoArray(*pPatPathoArray)) ;

  ps2 = "NSNoyauDocument::enregistrePatPatho : before updateTrees" ;
  pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

  string sTreeID ;
	pGraphManager->updateTrees(&VectUpdate, &sTreeID, &sCodeDocMeta, pidsPatient) ;

	if (sTreeID == "")
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "failedToSave") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return false ;
	}

  // commit de l'arbre de pr�sentation (one-shot)
  // sCodeDocPres est comme sCodeDocMeta une variable de la classe NoyauDocument
  if (bEnregPresentation)
  {
  	pGraphManager->commitGraphTree(sCodeDocPres) ;
    pDocInfo->sCodeDocPres = sCodeDocPres ;
    string sRightsPres ;
    pGraphManager->getTree(sCodeDocPres, pDocInfo->pPres, &sRightsPres) ;
    bEnregPresentation = false ;
  }

	pGraphManager->setAdminAttrArray(NSPersonGraphManager::attribsUpdate, sNom, sPrenom, sSexe, sNaissance) ;

	ps2 = "NSNoyauDocument::enregistrePatPatho : before getTree" ;
  pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

	// Remise � jour des patpatho m�ta et data
	string sRightsMeta, sRightsData ;
	if (sCodeDocMeta != "")
	{
		pDocInfo->sCodeDocMeta = sCodeDocMeta ;
		pGraphManager->getTree(sCodeDocMeta, pDocInfo->pMeta, &sRightsMeta) ;
	}
	pGraphManager->getTree(sTreeID, pPatPathoArray, &sRightsData) ;

	// Remise � jour de la pDocInfo
	pDocInfo->setPatient(string(sTreeID, 0, PAT_NSS_LEN)) ;
	pDocInfo->setDocument(string(sTreeID, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN)) ;

  ps2 = pContexte->getSuperviseur()->getText("documentManagementStatus", "documentSaved") ;
	pContexte->getSuperviseur()->afficheStatusMessage((char*)ps2.c_str()) ;

  if (NULL != pContexte->getSuperviseur()->getBBinterface())
		pContexte->getSuperviseur()->getBBinterface()->signalThatPatpathoWasSaved(pPatPathoArray, false) ;

	ps2 = "NSNoyauDocument::enregistrePatPatho : done" ;
  pContexte->getSuperviseur()->trace(&ps2, 1, NSSuper::trDetails) ;

	return true ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument::enregistrePatPatho.", standardError, 0) ;
	return false ;
}
}

boolNSNoyauDocument::DocumentInvisible(string sCodeMeta)
{
try
{
  if ((NULL == pPatPathoArray) || (pPatPathoArray->empty()))
    return false ;

  PatPathoIter iterDoc = pPatPathoArray->begin() ;
  (*iterDoc)->setVisible("0") ;  return enregistrePatPatho() ;}
catch (...)
{
	erreur("Exception NSNoyauDocument::DocumentInvisible.", standardError, 0) ;
	return false ;
}
}

bool
NSNoyauDocument::DocumentVisible(string sCodeMeta)
{
try
{
	if ((NULL == pPatPathoArray) || (pPatPathoArray->empty()))
    return false ;

  PatPathoIter iterDoc = pPatPathoArray->begin() ;
  (*iterDoc)->setVisible("1") ;  return enregistrePatPatho() ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument::DocumentVisible.", standardError, 0) ;
	return false ;
}
}

//---------------------------------------------------------------------------
//  Fonction:		NSRefDocument::CreeDocument()
//  Description:	Cr�e et r�f�rence un document en mode N_TIERS
//  Retour:			True si �a r�ussit, False sinon
//---------------------------------------------------------------------------
bool
NSNoyauDocument::CreeDocument(NSDocumentInfo* pDoc, int typeLink,
                            string* psCodeChemise, bool bVerbose,
                            NSPersonGraphManager* pGraphManager)
{
try
{
  if (NULL == pDoc)
    return false ;

	// on r�cup�re en MUE un node chemise
	char NumChemise[PATLINK_QUALIFIE_LEN + 1] ;
	memset(NumChemise, 0, PATLINK_QUALIFIE_LEN + 1);

	int retVal;

	// NOTE : En MUE, CreeDocument ne sert qu'� lier une chemise au document
	// la cr�ation du document est faite plus tard, lorsqu'on enregistre la patpatho
	// dans Referencer. Cas particulier : les documents Root ne sont li�s � aucune
	// chemise. On consid�re que les chemises ne contiennent que les nouveaux documents

	//le rootDoc pour la racine du graphe patient
	string sRootDocGraph = string(1, INMEMORY_CHAR) + string("00000") ;
	if ((pDoc->getDocument() == sRootDocGraph) ||
        (typeLink == NSRootLink::personHealthIndex) ||
        (typeLink == NSRootLink::personRiskManager) ||
        (typeLink == NSRootLink::personSynthesis) ||
        (typeLink == NSRootLink::personAdminData) ||
        (typeLink == NSRootLink::personFolderLibrary) ||
        (typeLink == NSRootLink::personIdentifiers) ||
        (typeLink == NSRootLink::personHealthTeam))
		return true ;

	string sRights = pDoc->getRights() ;

	//	// Appel de la boite de dialogue de r�f�rencement
	//
	if (bVerbose)
	{
		EnregDocDialog* pEnregDocDlg =
		    new EnregDocDialog(pContexte->GetMainWindow(), pDoc->getData(),
                                                        NumChemise, sRights, pContexte) ;

		retVal = pEnregDocDlg->Execute() ;
		delete pEnregDocDlg ;

		if (retVal == IDCANCEL)			return false ;
	}
	else
	{
		EnregDocDialog* pEnregDocDlg =
		        new EnregDocDialog(0, pDoc->getData(), NumChemise, sRights, pContexte) ;

		//
		// Valeurs par d�faut : Derni�re chemise et importance de base
		// Default values : Last filer and basic interest
		//
		pEnregDocDlg->RemplirChemises() ;

		if (!(pEnregDocDlg->pChemisesArray->empty()))		{
			NSChemiseInfo* pChemInfo = pEnregDocDlg->pChemisesArray->back() ;
			strcpy(NumChemise, (pChemInfo->sNodeChemise).c_str()) ;
		}
		pDoc->setInteret(string("A")) ;
		delete pEnregDocDlg ;	}

	//	// V�rification de la pr�sence des �l�ments obligatoires
	//
	if ((string("") == pDoc->getDocName()) ||
		  (string(strlen(pDoc->getDocName().c_str()), ' ') == pDoc->getDocName()))
		return false ;

	if ((NumChemise[0] == '\0') ||		(strspn(NumChemise, " ") == strlen(NumChemise)))
		return false ;

	// on conserve le code chemise choisi pour l'importation de fichiers	if (psCodeChemise)
		*psCodeChemise = string(NumChemise) ;

	//	// La recherche du code � attribuer � ce nouveau document
	// est faite apr�s CreeDocument (on lie ici le m�ta � la chemise s�lectionn�e)

	// Remarque : � ce niveau, le code document est celui du m�ta-document (cf referencer)
	// on �tablit le lien entre la chemise et le nouveau document	// la chemise-corbeille ne peut pas �tre s�lectionn�e par construction (cf EnregDocDialog)	NSLinkManager* pLink = pGraphManager->pLinkManager ;	bool bRet = pLink->etablirLien(string(NumChemise), NSRootLink::docFolder, sCodeDocMeta) ;	return bRet;}catch(TWindow::TXWindow& e){
  string sErr = string("Exception NSNoyauDocument::CreeDocument : ") + e.why() ;
  erreur(sErr.c_str(), standardError, 0) ;
  return false ;
}catch (...)
{
  erreur("Exception NSNoyauDocument::CreeDocument.", standardError, 0) ;
  return false ;
}
}

// ---------------------------------------------------------------------------
//   Inscrit le document dans le fichier DOCUMENT
//
//   Lance la boite de dialogue de r�f�rencement (choix du titre,
//	 de la chemise, de l'importance du document)
//
//	  Sauvegarde le document dans DOCUMENT//	  Cr�e un enregistrement dans CHEMDOC pour le ranger dans sa chemise
// ---------------------------------------------------------------------------

// Referencement d'un document dans la base des documents en mode N_TIERS
// (on travaille avec un graphManager qui par d�faut est le graphe du patient)// ---------------------------------------------------------------------------bool
NSNoyauDocument::Referencer(string typeDoc, string nomDoc, string nomFichier,
                          string cheminDoc, bool bDocVisible, bool bVerbose,
                          string sCodeDoc, NSRootLink::NODELINKTYPES typeLink,
                          NSPersonGraphManager* pGraphManager,
                          string sAuthorId, string tmplDoc, string enteteDoc,
                          string sDestinataire, string sContent,
                          string sMasterDoc, NSRootLink::NODELINKTYPES masterLink)
{
try
{
	string sType, sTemplate = "", sEnTete = "";
	char creation[DOC_CREATION_LEN + 1];

	donne_date_duJour(creation);	char heure[7] ;	donne_heure(heure) ;
	strcat(creation, heure) ;
	// Initialisation du GraphManager	if (pGraphManager == 0)		pGraphManager = pContexte->getPatient()->pGraphPerson;	//	// Cr�ation d'une fiche Document (comme objet d'interface)
	//

	NSDocumentInfo* pNewDocument = new NSDocumentInfo(pContexte) ;
	// Niveau de s�curit� pour l'acc�s : Celui de l'utilisateur	// strcpy(pNewDocument->pDonnees->acces, pContexte->getUtilisateur()->pDonnees->groupe);
	// Cr�ateur : Utilisateur en cours	pNewDocument->setCreator(pContexte->getUtilisateurID()) ;
  pNewDocument->setDestinat(sDestinataire) ;
  if ((string("_User_") != sAuthorId) && ((string("") != sAuthorId)))
  	pNewDocument->setAuthor(sAuthorId) ;

	// Type de document : Compte rendu	pNewDocument->setType(typeDoc) ;

	// Int�ret 5 = moyen	pNewDocument->setInteret(string("5")) ;

	// Date de creation = date du jour	pNewDocument->setCreDate(creation);

	// visible est � 1 quand on r�f�rence un document (sauf pour les images)	if ('I' == typeDoc[1])
		pNewDocument->rendInvisible() ;
	else
	{
		if (bDocVisible)
			pNewDocument->rendVisible() ;
		else
			pNewDocument->rendInvisible() ;
	}	// on fixe la template et l'en-tete des CN et des CS, sauf pour les documents root	string sRootDocGraph = string(1, INMEMORY_CHAR) + string("00000") ;
	NSPatPathoArray* pPatPathoPresent = 0 ;

	if (((sCodeDoc != sRootDocGraph) && (typeLink == NSRootLink::personDocument)) &&
        ((pContexte->typeDocument(typeDoc, NSSuper::isTree)) || (pContexte->typeDocument(typeDoc, NSSuper::isText)) ||          (typeDoc == "ZIHTM")) && (typeDoc != "ZTPDF"))	{
		if ((string("") == tmplDoc) && (string("") == enteteDoc))
  	{
    	// on r�cup�re les donn�es en fonction de l'utilisateur
      if (!TemplateCompo(typeDoc, sTemplate, sEnTete))
      	erreur("Impossible de fixer la template et l'en-t�te du document", standardError, 0, pContexte->GetMainWindow()->GetHandle()) ;
      else
      {
      	pNewDocument->setTemplate(sTemplate) ;
        pNewDocument->setEnTete(sEnTete) ;
      }
    }
    else
    {
    	sTemplate = tmplDoc;
      sEnTete = enteteDoc;
      pNewDocument->setTemplate(sTemplate) ;
      pNewDocument->setEnTete(sEnTete) ;
    }

    pPatPathoPresent = new NSPatPathoArray(pContexte) ;
    Message Msg ;
    pPatPathoPresent->ajoutePatho("ZPRES1", &Msg, 0) ;

    // Template
    pPatPathoPresent->ajoutePatho("0TPL01", 1) ;
    Msg.Reset() ;
    Msg.SetTexteLibre(sTemplate.c_str()) ;
    pPatPathoPresent->ajoutePatho("�?????", &Msg, 2) ;

    // En-tete
    pPatPathoPresent->ajoutePatho("0ENTE1", 1);
    Msg.Reset() ;
    Msg.SetTexteLibre(sEnTete.c_str()) ;
    pPatPathoPresent->ajoutePatho("�?????", &Msg, 2) ;
	}

	// le chemin et le nom de fichier sont vides pour les documents dynamiques
	pNewDocument->setLocalisa(cheminDoc) ;
	pNewDocument->setFichier(nomFichier) ;

	//
	// Demande de cr�ation et r�f�rencement du document
	//

	// Copie du nom du document par d�faut	pNewDocument->setNom(nomDoc) ;

	//
	// Calcul du code document des m�ta-donn�es
	//
	if (sCodeDoc == "") // cas g�n�ral
	{
		sCodeDocMeta = pGraphManager->pDataGraph->getNextTreeID();		pNewDocument->setPatient(string(sCodeDocMeta, 0, PAT_NSS_LEN)) ;		pNewDocument->setDocument(string(sCodeDocMeta, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN)) ;	}	else // cas o� on passe le code m�ta root notament	{		pNewDocument->setPatient(pGraphManager->getPersonID()) ;		pNewDocument->setDocument(sCodeDoc) ;
		sCodeDocMeta = pGraphManager->getPersonID() + sCodeDoc;	}	//	// NOTE : Il s'agit ici n�c�ssairement d'un NOUVEAU document
	// et le bool�en bCreerMetaLien est l� pour ne pas oublier
	// d'enregistrer ult�rieurement (dans enregistrePatPatho en principe)
	// les datas � travers le graphe, ainsi que de cr�er le lien m�ta-data.
	//
	bCreerMetaLien = true;

  string sCodeChemise ;
	// Lancement du dialogue de r�f�rencement
	bool documentCree = CreeDocument(pNewDocument, typeLink, &sCodeChemise, bVerbose, pGraphManager);

	if (!documentCree)
		return false;

	//
	// On cr�e maintenant une patpatho sp�cifique pour enregistrer les m�ta-donn�es
	//
	NSPatPathoArray* pPatPathoMeta = new NSPatPathoArray(pContexte);

	// noeud racine
	Message Msg ;
	// pMessage->SetLexique("ZDOCU1");
	Msg.SetInteret(pNewDocument->getInteret()) ;
	Msg.SetVisible(pNewDocument->getVisible()) ;
	pPatPathoMeta->ajoutePatho("ZDOCU1", &Msg, 0) ;

	// Intitul� : nom du document
	pPatPathoMeta->ajoutePatho("0INTI1", 1) ;
  Msg.Reset() ;
	Msg.SetTexteLibre(pNewDocument->getDocName()) ;
	pPatPathoMeta->ajoutePatho("�?????", &Msg, 2) ;

	if (string("") != pNewDocument->getCreator())
	{
  	pPatPathoMeta->ajoutePatho("DOPER1", 1) ;
		Msg.Reset() ;
		Msg.SetComplement(pNewDocument->getCreator()) ;
		pPatPathoMeta->ajoutePatho("�SPID1", &Msg, 2) ;
	}

	// cr�ateur != op�rateur
	if ((string("_User_") != sAuthorId) && (string("") != sAuthorId))
	{
		pPatPathoMeta->ajoutePatho("DAUTE1", 1) ;
		Msg.Reset() ;
    if (string("") != pNewDocument->getAuthor())
    	Msg.SetComplement(pNewDocument->getAuthor()) ;
    else
			Msg.SetComplement(sAuthorId) ;
		pPatPathoMeta->ajoutePatho("�SPID1", &Msg, 2) ;
	}

  // Destinataire
  //
  if (string("") != pNewDocument->getDestinat())
	{
  	pPatPathoMeta->ajoutePatho("DDEST1", 1) ;
		Msg.Reset() ;
		Msg.SetComplement(pNewDocument->getDestinat()) ;
		pPatPathoMeta->ajoutePatho("�SPID1", &Msg, 2) ;
	}

	// Type : code lexique
	string sTypeDocum = pNewDocument->getType() ;
  pContexte->getSuperviseur()->getDico()->donneCodeComplet(sTypeDocum) ;
	pPatPathoMeta->ajoutePatho("0TYPE1", 1) ;
	pPatPathoMeta->ajoutePatho(sTypeDocum, 2) ;

	// Localisation : champ complement
	Msg.Reset() ;
	Msg.SetComplement(pNewDocument->getLocalis()) ;
	pPatPathoMeta->ajoutePatho("0LFIC1", &Msg, 1) ;

  // Nom de fichier (pour les fichiers statiques)
	pPatPathoMeta->ajoutePatho("0NFIC1", 1) ;
	Msg.Reset() ;
	Msg.SetTexteLibre(pNewDocument->getFichier()) ;
	pPatPathoMeta->ajoutePatho("�?????", &Msg, 2) ;

	/*********** La template et l'en-tete sont maintenant dans l'arbre "pr�sentation"
    // Template
    pPatPathoMeta->ajoutePatho("0TPL01", 1, 1);
    pMessage = new Message("", "", "", "A", "", "", "");
    pMessage->SetTexteLibre(sTemplate.c_str());
    pPatPathoMeta->ajoutePatho("�?????", pMessage, 2, 1);
    delete pMessage;

    // En-tete
    pPatPathoMeta->ajoutePatho("0ENTE1", 1, 1);
    pMessage = new Message("", "", "", "A", "", "", "");
    pMessage->SetTexteLibre(sEnTete.c_str());
    pPatPathoMeta->ajoutePatho("�?????", pMessage, 2, 1);
    delete pMessage;
	********************************************************************************/

	// Date de r�daction
	pPatPathoMeta->ajoutePatho("KREDA1", 1) ;
	string sDateCreation = pNewDocument->getCreDate() ;
	if (strlen(sDateCreation.c_str()) == 8)
		sDateCreation += string("000000") ;
	Msg.Reset() ;
	Msg.SetUnit("2DA021") ;
	Msg.SetComplement(sDateCreation) ;
	pPatPathoMeta->ajoutePatho("�T0;19", &Msg, 2) ;

	// Date du document
	string sDateExam = GetDateExamen(false) ;
	if (sDateExam != "")
	{
		pNewDocument->setDateExm(sDateExam) ;
		pPatPathoMeta->ajoutePatho("KCHIR2", 1) ;
    if (strlen(sDateExam.c_str()) == 8)
    	sDateExam += string("000000") ;
    Msg.Reset() ;
    Msg.SetUnit("2DA021") ;
    Msg.SetComplement(sDateExam) ;
    pPatPathoMeta->ajoutePatho("�T0;19", &Msg, 2) ;
	}

	// Type de contenu : analyse de la patpatho en cours
	string sLexique = "" ;
	if (false == pPatPathoArray->empty())
	{
  	PatPathoIter iter = pPatPathoArray->begin() ;
    sLexique = (*iter)->getLexique() ;
	}
	else
	{
  	//dans les 3 cas qui restent, les document n'ont pas patpatho, on leur
    //en cr�e une qui contient seulent le code lexique correspondant :
    //ZIMA01 pour image
    //PXXX51 : code bidon pour texte
    //PTRIQ3 : pour HTML

    if (pContexte->typeDocument(typeDoc, NSSuper::isText))
    	// pour tous les types de texte
      sLexique = string("PXXX51") ;
    else if (pContexte->typeDocument(typeDoc, NSSuper::isHTML))
    	// pour tous les types d'html statiques (HD trait� plus haut)
      sLexique = string("PTRIQ3") ;
    else if (pContexte->typeDocument(typeDoc, NSSuper::isImage))
    	// cas des images : g�n�rique pour tous les types d'image
      // y compris les images anim�es (vid�os)
      sLexique = string("ZIMA01") ;
	}

	if (sLexique != "")
	{
  	pNewDocument->setContent(sLexique) ;
    pPatPathoMeta->ajoutePatho("0TYPC1", 1) ;
    pPatPathoMeta->ajoutePatho(sLexique, 2) ;
	}

	//
  // Cr�ation des pDocInfo du document en cours avec les nouvelles informations
  //
  pDocInfo = new NSDocumentInfo(*pNewDocument) ;
	// On place ici l'arbre des m�ta-donn�es dans le graphe  pGraphManager->setTree(pPatPathoMeta, pNewDocument->getRights(), sCodeDocMeta) ;	// On conserve la patpatho m�ta et le sCodeMeta dans la pDocInfo du document en cours	*(pDocInfo->pMeta) = *(pPatPathoMeta) ;	pDocInfo->sCodeDocMeta = sCodeDocMeta ;	delete pPatPathoMeta ;	//	// On cr�e la liaison du m�ta-document avec le document root	//	string sNodeRoot = pGraphManager->getRootTree() ;	string sNodeMeta = sCodeDocMeta ;	NSLinkManager* pLink = pGraphManager->pLinkManager ;	if (sNodeMeta != sNodeRoot)	{  	if (!pLink->etablirLien(sNodeRoot, typeLink, sNodeMeta))    {
      string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "cannotEstablishALinkWithTheRoot") ;
    	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
			erreur(sErrorText.c_str(), standardError, 0) ;
      return false ;
    }    // lien du m�ta vers la contribution en cours : fait maintenant par signChanges()    // if (!pLink->etablirLien(sNodeMeta, NSRootLink::contributionAdded, pContexte->getPatient()->getContribution()))    //     erreur("Impossible d'initialiser le lien du document vers la nouvelle contribution du patient.", standardError, 0) ;
  }

  //
  // If there is a "master document", we create a link with it
  //
  if (string("") != sMasterDoc)
  {
  	if (!pLink->etablirLien(sNodeMeta, masterLink, sMasterDoc))
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "cannotEstablishALinkWithTheDocument") ;
    	pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
			erreur(sErrorText.c_str(), standardError, 0) ;
      return false ;
    }
  }

	// On cr�e ici l'arbre de pr�sentation dans le graphe
  // (il sera enregistr� dans enregistrePatPatho)
  if (pPatPathoPresent != 0)
  {
  	sCodeDocPres = pGraphManager->pDataGraph->getNextTreeID() ;
    // On place ici l'arbre de pr�sentation dans le graphe
    pGraphManager->setTree(pPatPathoPresent, "", sCodeDocPres) ;
    // On cr�e directement le lien du m�ta vers son arbre de pr�sentation
    // car on a d�j� plac� sa patpatho dans le graphe - � la diff�rence des datas
    if (!pLink->etablirLien(sNodeMeta, NSRootLink::docComposition, sCodeDocPres))
    	erreur("Impossible d'initialiser le lien du document vers ses donn�es de pr�sentation.", standardError, 0) ;

    pDocInfo->sCodeDocPres = sCodeDocPres ;

    bEnregPresentation = true ;
	}

	// On recalcule un nouveau code document pour la partie donn�es
  // SAUF pour les documents statiques qui n'ont justement pas de datas  // Dans ce cas, le codeDocument de pDocInfo reste celui du Meta  if (!pContexte->typeDocument(typeDoc, NSSuper::isFile))  {  	string sCodeDocData = pGraphManager->pDataGraph->getNextTreeID() ;    // remise � jour du pDocInfo    pDocInfo->setPatient(string(sCodeDocData, 0, PAT_NSS_LEN)) ;    pDocInfo->setDocument(string(sCodeDocData, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN)) ;	}
	// on met � jour le titre	SetTitreDoc() ;

	// ajout d'un nouveau document type fichier :  // remise � jour de l'historique ...
  // Les documents de type global 'C' (CS ou CN)
  // appelle Rafraichir dans leur fonction enregistrer pour
  // pouvoir passer la patpatho

	if (pContexte->typeDocument(typeDoc, NSSuper::isFile))	{
		// Pour les documents qui n'ont pas de patpatho, il faut penser
    // � commiter l'arbre des m�tas et de pr�sentation maintenant car
    // on ne passe pas dans ce cas par ::enregistrePatPatho
    string sDroits ;
    pGraphManager->commitGraphTree(pDocInfo->sCodeDocMeta) ;
    pGraphManager->getTree(pDocInfo->sCodeDocMeta, pDocInfo->pMeta, &sDroits) ;
    sCodeDocMeta = pDocInfo->sCodeDocMeta ;

    // remise � jour du pDocInfo
    pDocInfo->setPatient(string(sCodeDocMeta, 0, PAT_NSS_LEN)) ;    pDocInfo->setDocument(string(sCodeDocMeta, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN)) ;

    if (pPatPathoPresent != 0)
    {
    	pGraphManager->commitGraphTree(pDocInfo->sCodeDocPres) ;
      pGraphManager->getTree(pDocInfo->sCodeDocPres, pDocInfo->pPres, &sDroits) ;
      sCodeDocPres = pDocInfo->sCodeDocPres ;
    }

    // if (pContexte->getPatient()->pDocHis)
    //	pContexte->getPatient()->pDocHis->Rafraichir(pDocInfo, 0, this) ;	}
	return true ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument::Referencer.", standardError, 0) ;
	return false ;
}
}

bool
NSNoyauDocument::ReferencerHtml(string typeDoc, string nomDoc, string tempDoc, string enteteDoc, bool bIsVisible)
{
try
{
	return false ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument::ReferencerHtml.", standardError, 0) ;
  return false ;
}
}

boolNSNoyauDocument::TemplateCompo(string typeDoc, string& tempDoc, string& enteteDoc)
{
try
{
	string sIdGlobal = "";
	string sIdRoot = "";
	string sIdUtil = "";
	string sIdRootUtil = "";
	string sCodeRootDoc = "",  sCodeSensDoc = "";
	string sCodeRootTmpl,      sCodeSensTmpl;
	string sVoid = string("9VOID1");
	VecteurString VectTermeEquivalentRoot;
	int    degreTermeRoot = -1, degreTermeRootUtil = -1;
	bool   trouve = false;

	// s'il existe une patpatho non vide, on r�cup�re le code root
	// et son array d'�quivalents s�mantiques
	if (!pPatPathoArray->empty())
	{
		sCodeSensDoc = (*(pPatPathoArray->begin()))->getLexiqueSens(pContexte) ;
		// on r�cup�re le vecteur d'�quivalents
		pContexte->getSuperviseur()->getFilGuide()->chercheEquivalent(sCodeSensDoc, &VectTermeEquivalentRoot, "ES");
	}

	// on appelle ici le pilote pour chercher la liste des template par d�faut de type "typeDoc"
	// -----------------------------------------------------------------------------------------
	NSDataGraph Graph(pContexte, graphObject) ;

	//Il faut creer la variable sTraitName = "_" + nomObjet + "_" + typeobjet
	string sTraitType = string("_0OTPL_0TYPE");
	string sTraitDefa = string("_0OTPL_0DEFA");
	// On transmet le code lexique pour le type
	string sTypeDoc = typeDoc ;
  pContexte->getSuperviseur()->getDico()->donneCodeComplet(sTypeDoc) ;

	NSPersonsAttributesArray ObjList ;
	NSBasicAttributeArray AttrList ;
	AttrList.push_back(new NSBasicAttribute(sTraitType,  sTypeDoc)) ;
	AttrList.push_back(new NSBasicAttribute(sTraitDefa,  string("WCEA01"))) ;

	bool res = pContexte->pPilot->invokeService(NautilusPilot::SERV_SEARCH_OBJECT.c_str(),
                                                &Graph, &ObjList, &AttrList);

	if ((!res) || (ObjList.empty()))
	{
		string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "defaultTemplateNotFound");
    sErrorText += string(" (Doc= ") + sTypeDoc + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return false ;
	}

	for (NSPersonsAttributeIter k = ObjList.begin(); k != ObjList.end(); k++)
	{
		string sUtil = (*k)->getAttributeValue("_0OTPL_DOPER");
		string sCons = (*k)->getAttributeValue("_0OTPL_LNUCO");
		string sCodeRootTmpl = (*k)->getAttributeValue("_0OTPL_0TYPC");

		if ((sUtil == pContexte->getUtilisateurID()) ||
            (sCons == pContexte->getSuperviseur()->getConsole()))
		{
			if ((string("") != sCodeRootTmpl) && (sCodeRootTmpl != sVoid))
			{
      	int degreTermeTmpl = -1 ;
        bool termeExiste = false ;

        pContexte->getSuperviseur()->getDico()->donneCodeSens(&sCodeRootTmpl, &sCodeSensTmpl) ;
        for (EquiItemIter i = VectTermeEquivalentRoot.begin(); i != VectTermeEquivalentRoot.end(); i++)
        {
        	degreTermeTmpl++ ;

          if (sCodeSensTmpl == (*(*i)))
          {
          	termeExiste = true ;
            break ;
          }
        }

        if (termeExiste)
        {
        	if ((degreTermeRootUtil < 0) || (degreTermeRootUtil > degreTermeTmpl))
          {
          	sIdRootUtil = (*k)->getAttributeValue(OIDS) ;
            degreTermeRootUtil = degreTermeTmpl ;
            trouve = true ;
          }
        }
      }
      else
      {
      	sIdUtil = (*k)->getAttributeValue(OIDS) ;
        trouve = true ;
      }
    }
    else if (sUtil == sVoid)
    {
    	if ((sCodeRootTmpl != string("")) && (sCodeRootTmpl != sVoid))
      {
      	int degreTermeTmpl = -1 ;
        bool termeExiste = false ;

        pContexte->getSuperviseur()->getDico()->donneCodeSens(&sCodeRootTmpl, &sCodeSensTmpl) ;
        for (EquiItemIter i = VectTermeEquivalentRoot.begin(); i != VectTermeEquivalentRoot.end(); i++)
        {
        	degreTermeTmpl++ ;

          if (sCodeSensTmpl == (*(*i)))
          {
          	termeExiste = true ;
            break ;
          }
        }

        if (termeExiste)
        {
        	if ((degreTermeRoot < 0) || (degreTermeRoot > degreTermeTmpl))
          {
          	sIdRoot = (*k)->getAttributeValue(OIDS) ;
            degreTermeRoot = degreTermeTmpl ;
            trouve = true ;
          }
        }
      }
      else
      {
      	sIdGlobal = (*k)->getAttributeValue(OIDS) ;
        trouve = true ;
			}
		}
	}

	string sObjectId ;

	if (trouve)
	{    // on prend la template trouv�e par ordre de priorit�
    if (sIdRootUtil != "")
    {
        sObjectId = sIdRootUtil;
    }
    else if (sIdRoot != "")
    {
        sObjectId = sIdRoot;
    }
    else if (sIdUtil != "")
    {
        sObjectId = sIdUtil;
    }
    else
    {
        sObjectId = sIdGlobal;
    }

    // Appel du pilote pour retrouver la template en fonction de l'ObjectId
    // --------------------------------------------------------------------
    Graph.graphReset() ; // au cas o� le graphe �tait d�j� rempli
    NSBasicAttributeArray AttrArray ;
    //pAttrArray->push_back(new NSBasicAttribute("graphID" , sObjectId));
    AttrArray.push_back(new NSBasicAttribute(OBJECT , sObjectId));
    bool res = pContexte->pPilot->invokeService(NautilusPilot::SERV_SEARCH_OBJECT_FROM_ID.c_str(),
                                    &Graph,  &AttrArray);
    if (!res)
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "templateNotFound") ;
      sErrorText += string(" (ObjectID= ") + sObjectId + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      erreur(sErrorText.c_str(), standardError, 0) ;
      return "" ;
    }

    NSPatPathoArray TplPatPathoArray(pContexte, graphObject) ;
    NSDataTreeIter iterTree;
    PatPathoIter iter, iterEnd;
    int iColTpl;
    string sElemLex, sSens, sType, sTypeLex;
    string sFichierTpl = "", sEnTeteTpl = "";

    if (Graph.aTrees.ExisteTree("0OTPL1", pContexte, &iterTree))
    {
    	(*iterTree)->getPatPatho(&TplPatPathoArray) ;
      iter = TplPatPathoArray.begin() ;
    }
    else
			return false ;

		iterEnd = TplPatPathoArray.end() ;

    // Parsing de la template.......
    if ((iter != NULL) && (iter != iterEnd))
    {
    	sSens = (*iter)->getLexiqueSens(pContexte) ;

      if (string("0OTPL") == sSens)
      {
      	iColTpl = (*iter)->getColonne() ;
        iter++ ;

        // on charge les donn�es de l'archetype
        while ((iter != iterEnd) && ((*iter)->getColonne() > iColTpl))
        {
        	sSens = (*iter)->getLexiqueSens(pContexte) ;

          // identifiant (unique)
          if (string("0ENTE") == sSens)
          {
          	iter++ ;
            sEnTeteTpl = "" ;

            while ((iter != iterEnd) && ((*iter)->getColonne() > iColTpl+1))
            {
            	// on cherche ici un texte libre
              sElemLex = (*iter)->getLexique() ;

              if (string("�?????") == sElemLex)
              	sEnTeteTpl = (*iter)->getTexteLibre() ;

              iter++ ;
            }
          }
          // nom du fichier (unique)
          else if (string("0TPL0") == sSens)
          {
          	iter++ ;
            sFichierTpl = "" ;

            while ((iter != iterEnd) && ((*iter)->getColonne() > iColTpl+1))
            {
            	// on cherche ici un texte libre
              sElemLex = (*iter)->getLexique() ;

              if (string("�?????") == sElemLex)
              	sFichierTpl = (*iter)->getTexteLibre() ;

              iter++ ;
            }
          }
          else
          	iter++ ;
        }

        if ((sEnTeteTpl != "") && (sFichierTpl != ""))
        {
        	tempDoc = sFichierTpl ;
          enteteDoc = sEnTeteTpl ;
        }
      }
      else
      {
      	erreur("Le noeud template est mal positionn� dans ::TemplateCompo().", standardError, 0) ;
        return false ;
      }
    }
    else
    {
    	erreur("Le noeud template est incorrect dans ::TemplateCompo().", standardError, 0) ;
      return false ;
    }

		return true ;
	}

	char msg[255] ;
	sprintf(msg, "Pas de template de composition par defaut pour le type %s.", typeDoc.c_str()) ;
	MessageBox(0, msg, 0, MB_OK) ;
	return false ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument::TemplateCompo.", standardError, 0) ;
	return false ;
}
}

// Pour r�cup�rer la template du document sans le pathstringNSNoyauDocument::TemplateInfoBrut(bool bCompo){	string fichTmpl ;	if (bCompo)  	fichTmpl = pHtmlInfo->getTemplate() ;  else  	fichTmpl = pDocInfo->getTemplate() ;	size_t pos = fichTmpl.find_last_of('\\') ;	if (pos != NPOS)  	fichTmpl = string(fichTmpl, pos+1, strlen(fichTmpl.c_str())-pos-1) ;	return fichTmpl ;}// Pour r�cup�rer l'en-tete du document sans le pathstringNSNoyauDocument::EnTeteInfoBrut(bool bCompo){	string enteteTmpl ;	if (bCompo)  	enteteTmpl = pHtmlInfo->getEntete() ;  else  	enteteTmpl = pDocInfo->getEntete() ;	size_t pos = enteteTmpl.find_last_of('\\') ;	if (pos != NPOS)  	enteteTmpl = string(enteteTmpl, pos+1, strlen(enteteTmpl.c_str())-pos-1) ;	return enteteTmpl ;}
boolNSNoyauDocument::ChemiseAvecImages(bool& bResult)
{
try
{
	NSLinkManager* pGraphe = pContexte->getPatient()->pGraphPerson->pLinkManager ;
	VecteurString aVecteurString ;
	string sNodeChemise ;
	bool   chemiseAvecImages = false ;

	// on r�cup�re d'abord la chemise (folder) du document
	pGraphe->TousLesVrais(pDocInfo->sCodeDocMeta, NSRootLink::docFolder, &aVecteurString, "ENVERS") ;
	if (aVecteurString.empty())
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "currentDocumentDoesNotBelongToAFolder") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
    bResult = false ;
    return false ;
  }

  sNodeChemise = *(*(aVecteurString.begin())) ;

  // on r�cup�re maintenant la liste de tous les documents de cette chemise
	aVecteurString.vider() ;
  pGraphe->TousLesVrais(sNodeChemise, NSRootLink::docFolder, &aVecteurString) ;

  if (aVecteurString.empty())
  {
  	bResult = chemiseAvecImages ;
    return true ;
  }

  NSDocumentArray aDocusArray ;

  for (EquiItemIter i = aVecteurString.begin(); aVecteurString.end() != i; i++)
  	aDocusArray.push_back(new NSDocumentInfo(*(*i), pContexte)) ;

  if (aDocusArray.empty())
  {
  	bResult = chemiseAvecImages ;
    return true ;
  }

  // R�cup�ration des informations des documents
  DocInfoIter iterDoc = aDocusArray.begin() ;
  bool bOk ;

  while ((NULL != iterDoc) && (aDocusArray.end() != iterDoc))  {
  	aVecteurString.vider() ;
    bOk = false ;

    string sCodePat = string((*iterDoc)->sCodeDocMeta, 0, PAT_NSS_LEN) ;
    string sCodeDoc = string((*iterDoc)->sCodeDocMeta, PAT_NSS_LEN, DOC_CODE_DOCUM_LEN) ;

    (*iterDoc)->setPatient(sCodePat) ;
    (*iterDoc)->setDocument(sCodeDoc) ;

    if ((*iterDoc)->ParseMetaDonnees())
    {
    	if (pContexte->typeDocument((*iterDoc)->getType(), NSSuper::isImage))
      {
      	chemiseAvecImages = true ;
        break ;
      }
      bOk = true ;
    }

    // probl�me de r�cup�ration de la patpatho (ou de parsing) : le document
    // ne figure pas dans la liste
    if (!bOk)
    {
    	string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "cannotAccessDocument") ;
      sErrorText += string(" (") + (*iterDoc)->getID() + string(")") ;
      pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
      erreur(sErrorText.c_str(), standardError, 0) ;
      delete *iterDoc ;
      aDocusArray.erase(iterDoc) ;
    }
    else
    	iterDoc++ ;
	}

	bResult = chemiseAvecImages ;
	return true ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument::ChemiseAvecImages.", standardError, 0) ;
	return false ;
}
}

boolNSNoyauDocument::DonneNouveauCodeDocument(string /* sPatient */, string& /* sCodeDoc */){	return true ;}

voidNSNoyauDocument::IncrementeCode(string& code)
{
  bool tourner = true ;
  int  i = strlen(code.c_str()) ;

  while ((tourner) && (i > 0))
  {
    i-- ;
    if (((code[i] >= '0') && (code[i] < '9')) ||
        ((code[i] >= 'A') && (code[i] < 'Z')))
    {
      code[i] = char(code[i] + 1) ;
      tourner = false ;
    }
    else if ('9' == code[i])
    {
      code[i] = 'A' ;
      tourner = false ;
    }
    else if ('Z' == code[i])
      code[i] = '0' ;
  }

  if (tourner)	// dans ce cas le code ne contient que des z�ros
    code = string("1") + code ;
}

stringNSNoyauDocument::nomSansDoublons(string serveur, string unite, string pathRef,
                                                        string nom, string ext)
{
	string sCompteur = string("") ;

	string nomComplet ;
	string sNomFichier ;

	// Attention pathRef est ici un chemin Relatif	// et non un chemin absolu comme dans NSModHtml
  bool exist = true ;
	while (exist)
	{
		IncrementeCode(sCompteur) ;
		nomComplet = nom + sCompteur ;

		if (string("") != serveur)    	sNomFichier = serveur + pathRef + nomComplet + string(".") + ext ;
    else
    	sNomFichier = unite + pathRef + nomComplet + string(".") + ext ;

		exist = FileExists(AnsiString(sNomFichier.c_str())) ;	}

	// tant que le compteur ne d�passe pas ZZ on obtiendra un nom dos � 8 + 3
	if (string("") != nomComplet)
  	nomComplet = nomComplet + string(".") + ext ;

	return nomComplet ;}

//
// Met � jour le booleen bDocumentValide pour les documents de type fichier
//
void
NSNoyauDocument::ValideFichier(string* psNomFichier)
{
try
{
	string sNomFichier ;

	if (pDocInfo)
	{
  	if (!pDocInfo->getNomFichier(sNomFichier))
    	bDocumentValide = false ;
    else
    {
    	bDocumentValide = FileExists(AnsiString(sNomFichier.c_str())) ;

      if (bDocumentValide && psNomFichier)
      	*psNomFichier = sNomFichier ;
    }
  }
  else
  	bDocumentValide = false ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument::ValideFichier.", standardError, 0) ;
}
}

boolNSNoyauDocument::RetrouveHtmlInfo()
{
try
{
	return false ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument::RetrouveHtmlInfo.", standardError, 0) ;
	return false;
}
}

boolNSNoyauDocument::MajTemplate()
{
try
{
	return false ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument::MajTemplate.", standardError, 0) ;
	return false ;
}
}

bool
NSNoyauDocument::DetruireComposants(NSPatPathoArray* pPatPatho)
{
	if ((NULL == pPatPatho) || (pPatPatho->empty()))
		return false ;
try
{
  NSLinkManager* pLink = pContexte->getPatient()->pGraphPerson->pLinkManager ;
  int iColBase = (*(pPatPatho->begin()))->getColonne() ;

  VecteurString aVecteurString ;

  // Suppression de tous les �l�ments TAG, de leurs liens et de leurs fils
  string sElemLex = string("0TAG01") ;
  string sSens ;
  pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

  // on supprime tous les fils de code sSens dans pPPTEnCours
  PatPathoIter iterCourant = pPatPatho->ChercherItem(sSens) ;
  // PatPathoIter iterLast    = NULL ;

  while ((NULL != iterCourant) && (pPatPatho->end() != iterCourant))
  {
  	if ((*iterCourant)->getColonne() == iColBase + 1)
    {
    	string sNodeTag = (*iterCourant)->getNode() ;
      aVecteurString.vider() ;
      pLink->TousLesVrais(sNodeTag, NSRootLink::compositionTag, &aVecteurString) ;
      if (false == aVecteurString.empty())
      {
      	string sCodeDocImage = *(*(aVecteurString.begin())) ;
        pLink->detruireLien(sNodeTag, NSRootLink::compositionTag, sCodeDocImage) ;
      }

      pPatPatho->SupprimerFils(iterCourant) ;
      pPatPatho->SupprimerItem(iterCourant) ;

      // iterLast = iterCourant ;

      if ((NULL == iterCourant) || (pPatPatho->end() == iterCourant))
      	break ;

      if ((*iterCourant)->getLexique() != sElemLex)
      	iterCourant = pPatPatho->ChercherItem(sSens, true, iterCourant) ;
    }
    else // cas item trouv� ailleurs qu'en colonne 1
    	iterCourant = pPatPatho->ChercherItem(sSens, true, iterCourant) ;
  }

  return true ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument::DetruireComposants", standardError, 0) ;
	return false ;
}
}

bool
NSNoyauDocument::EcrireComposants(NSPatPathoArray* pPatPatho)
{
try
{
	if (NULL == pPatPatho)
		return false ;

	char cIndexComp[4] ;
	string sCodeImage ;
	string sTypeImage ;

	// on r�cup�re la base d'image pour ins�rer les composants image
	// (on suppose ici qu'on a d�truit les composants s'il existaient d�j�)

	if (string("") == sBaseCompo)		return false ;
	NSBaseImages BaseImages(sBaseCompo) ;
	if (false == BaseImages.lire()) // charge la base d'images
		return false ;

	for (int i = 0; i < BaseImages.nbImages; i++)	{
		if (BaseImages.tableSelect[i]) // si l'image a �t� s�lectionn�e
    {
    	// Les images et les vid�os ont un type composant diff�rent
      // mais elles font partie de la meme base d'images pour un
      // fichier html donn�

			string sTypeImage = BaseImages.tableTypImg[i] ;      sprintf(cIndexComp, "%03d", BaseImages.tableSelect[i]) ;
      string sCodeImage = BaseImages.tableCompos[i] ;

      if (pContexte->typeDocument(sTypeImage, NSSuper::isImage))      {      	pPatPatho->ajoutePatho("0TAG01", 1) ;
        pPatPatho->ajoutePatho("0TYPC1", 2) ;
        pPatPatho->ajoutePatho("ZIMA01", 3) ;

        pPatPatho->ajoutePatho("VNUMT1", 2) ;
        Message Msg ;
        Msg.SetComplement(string(cIndexComp)) ;
        pPatPatho->ajoutePatho("�N0;03", &Msg, 3) ;
      }    }
  }

	// On remet ici l'arbre de pr�sentation dans le graphe
	// afin d'obtenir des num�ros de noeud pour les tags
	pContexte->getPatient()->pGraphPerson->setTree(pPatPatho, "", pDocInfo->sCodeDocPres) ;

	// On doit maintenant retrouver les tags image pour ins�rer leurs liens
	// avec les documents images
  string sDroits ;
  pContexte->getPatient()->pGraphPerson->getTree(pDocInfo->sCodeDocPres, pPatPatho, &sDroits) ;

  // on doit parcourir la librairie pour charger l'array des chemises
  PatPathoIter iter = pPatPatho->begin() ;
  int iColBase = (*iter)->getColonne() ;
  iter++ ;

	while ((iter != pPatPatho->end()) && ((*iter)->getColonne() > iColBase))
	{
  	string sSens = (*iter)->getLexiqueSens(pContexte) ;

    if (string("0TAG0") == sSens)
    {
    	string sNodeTag = (*iter)->getNode() ;
      string sIndex = string("") ;
      iter++ ;

      // on charge l'index du tag
      while ((iter != pPatPatho->end()) && ((*iter)->getColonne() > iColBase+1))
      {
      	sSens = (*iter)->getLexiqueSens(pContexte) ;

        // tag number
        if (string("VNUMT") == sSens)
        {
        	iter++ ;
          while ((iter != pPatPatho->end()) && ((*iter)->getColonne() > iColBase+2))
          {
          	// on cherche ici un texte libre
            string sElemLex = (*iter)->getLexique() ;
            if (string(sElemLex, 0, 2) == string("�N"))
            	sIndex = (*iter)->getComplement() ;

            iter++ ;
          }
        }
        // Tag type
        else if (string("0TYPC") == sSens)
        	iter++ ;
        else
        	iter++ ;
      }

      if (sIndex != "")
      {
      	for (int i = 0; i < BaseImages.nbImages; i++)
        {
        	if (BaseImages.tableSelect[i] == atoi(sIndex.c_str()))
          {
          	// on retrouve le code du m�ta associ� au composant image
            sCodeImage = BaseImages.tableCompos[i] ;

            NSLinkManager* pLink = pContexte->getPatient()->pGraphPerson->pLinkManager ;
            if (!pLink->etablirLien(sNodeTag, NSRootLink::compositionTag, sCodeImage))
            	erreur("Impossible d'initialiser le lien du document vers un �l�ment de pr�sentation.", standardError, 0) ;
            break ;
          }
        }
      }
    }
    else
    	iter++ ;
	}

	BaseImages.detruire() ;

	if (string("") != sBaseTemp) // si la base a �t� initialis�e	{
  	NSBaseImages BaseTemp(sBaseTemp) ;
    BaseTemp.lire() ;
    BaseTemp.detruire() ;
	}

	// on conserve l'ancienne base pour pouvoir d�truire les anciennes images	// et on remet la base � z�ro pour la recharger � la prochaine op�ration
	// (on garde la base compo pour l'instant)

	sBaseTemp = sBaseImages ;	sBaseImages = "" ;

	return true ;
}
catch (...)
{
	erreur("Exception NSNoyauDocument::EcrireComposants", standardError, 0) ;
	return false ;
}
}

//---------------------------------------------------------------------------//  Fonctions de gestion des propri�t�s de NSNoyauDocument
//---------------------------------------------------------------------------

static char* PropNames[] = { "FichierInfo" };	// Fichier de pDocInfo

static int PropFlags[] = { pfGetText };

const char*
NSNoyauDocument::PropertyName(int index)
{
	if (index <= PrevProperty)
		return TDocument::PropertyName(index) ;
	else if (index < NextProperty)
		return PropNames[index-PrevProperty-1] ;
	else
		return 0 ;
}

intNSNoyauDocument::PropertyFlags(int index)
{
	if (index <= PrevProperty)
		return TDocument::PropertyFlags(index) ;
	else if (index < NextProperty)
		return PropFlags[index-PrevProperty-1] ;
	else
		return 0 ;
}

intNSNoyauDocument::FindProperty(const char far* name)
{
	for (int i=0; i < NextProperty-PrevProperty-1; i++)
		if (!strcmp(PropNames[i], name))
			return i+PrevProperty+1 ;

	return 0 ;}

intNSNoyauDocument::GetProperty(int index, void far *dest, int textlen)
{
	switch (index)
	{
		case FichierInfo:
    {
			bool bNomOk = false;
			string nomFichier;

			if (pDocInfo != 0)				bNomOk = pDocInfo->getNomFichier(nomFichier) ;

      if (bNomOk)			{
      	strcpy((char far *) dest, nomFichier.c_str()) ;
        return strlen(nomFichier.c_str()) ;
      }
      else
      {
      	strcpy((char far *) dest, "") ;
        return 0 ;
      }
    }
	}

   return TDocument::GetProperty(index, dest, textlen) ;}

bool
NSNoyauDocument::createGraphRoot(NSPersonGraphManager* pGraphManager)
{
  if (NULL == pGraphManager)
    return false ;

  string sRootObject = pContexte->getSuperviseur()->getText("rootManagement", "rootObject") ;
  if (string("") == sRootObject)
    sRootObject = string("Root object") ;

  // Ici on cr�e l'embryon du graphe patient auquel on rattache la fiche admin
  // l'identifiant PIDS in memoire
  string sNss          = string(1, INMEMORY_CHAR) + string("000000") ;
  string sRootDocGraph = string(1, INMEMORY_CHAR) + string("00000") ;
  string sRootGraph    = sNss + sRootDocGraph ;

  pPatPathoArray->vider() ;
  pPatPathoArray->ajoutePatho("HHUMA3", 0) ;

  if (false == Referencer("ZCS00", sRootObject, "", "", false, false, sRootDocGraph, NSRootLink::personDocument, pGraphManager, ""))
  	return false ;

  string sRootDocData = pGraphManager->pDataGraph->getLastTree() ;
  pGraphManager->setTree(pPatPathoArray, "", sRootDocData) ;

  return etablirLiensTree(sRootDocData, pGraphManager) ;
}

bool
NSNoyauDocument::createFoldersLibrary(NSPersonGraphManager* pGraphManager)
{
  if (NULL == pGraphManager)
    return false ;

  string sFoldersLibrary = pContexte->getSuperviseur()->getText("folderManagement", "foldersLibrary") ;
  string sDefaultFolder  = pContexte->getSuperviseur()->getText("folderManagement", "defaultFolder") ;
  string sTrashFolder    = pContexte->getSuperviseur()->getText("folderManagement", "trashFolder") ;

  if (string("") == sFoldersLibrary)
    sFoldersLibrary = string("Folders Library") ;
  if (string("") == sDefaultFolder)
    sDefaultFolder = string("Default") ;
  if (string("") == sTrashFolder)
    sTrashFolder = string("Trash") ;

  char szDateJour[10] ;
  donne_date_duJour(szDateJour) ;

  pPatPathoArray->vider() ;

  pPatPathoArray->ajoutePatho("0LIBC1", 0) ;

	// ajout de la chemise corbeille
  // Note : cette chemise doit �tre cr��e en premier afin que la chemise par d�faut
  // soit s�lectionn�e plus tard dans EnregDocDialog (on s�lectionne la derni�re chemise)
	pPatPathoArray->ajoutePatho("0CHEM1", 1) ;

	// Intitul� : nom de la chemise
  pPatPathoArray->ajoutePatho("0INTI1", 2) ;
  Message Msg ;
  Msg.SetTexteLibre(sTrashFolder) ;
  pPatPathoArray->ajoutePatho("�?????", &Msg, 3) ;

  // Date d'ouverture
  pPatPathoArray->ajoutePatho("KOUVR1", 2) ;
  string sDateCreation = string(szDateJour) + string("000000") ;
  Message Msg2 ;
  Msg2.SetUnit("2DA021") ;
  Msg2.SetComplement(sDateCreation.c_str()) ;
  pPatPathoArray->ajoutePatho("�T0;19", &Msg2, 3) ;

  // ajout de la chemise par d�faut
	pPatPathoArray->ajoutePatho("0CHEM1", 1) ;

	// Intitul� : nom de la chemise
  pPatPathoArray->ajoutePatho("0INTI1", 2) ;
  Message Msg3 ;
  Msg3.SetTexteLibre(sDefaultFolder) ;
  pPatPathoArray->ajoutePatho("�?????", &Msg3, 3) ;

  // Date d'ouverture
  pPatPathoArray->ajoutePatho("KOUVR1", 2) ;
  Message Msg4 ;
  Msg4.SetUnit("2DA021") ;
  Msg4.SetComplement(sDateCreation.c_str()) ;
  pPatPathoArray->ajoutePatho("�T0;19", &Msg4, 3) ;

  if (false == Referencer("ZCS00", sFoldersLibrary, "", "", true, false, "", NSRootLink::personFolderLibrary, pGraphManager, ""))
  	return false ;

  string sRootDocData = pGraphManager->pDataGraph->getLastTree() ;
  if (string("") == sRootDocData)
    return false ;
  pGraphManager->setTree(pPatPathoArray, "", sRootDocData) ;

  return etablirLiensTree(sRootDocData, pGraphManager) ;
}

bool
NSNoyauDocument::createLdvFrame(NSPersonGraphManager* pGraphManager)
{
  if (NULL == pGraphManager)
    return false ;

  string sHealthIndex = pContexte->getSuperviseur()->getText("LigneDeVieManagement", "healthIndex") ;
  if (string("") == sHealthIndex)
    sHealthIndex = string("Health index") ;

  pPatPathoArray->vider() ;

  pPatPathoArray->ajoutePatho("ZPOMR1", 0) ;

	// ajout des pr�occupations de Sant� dans l'index de Sant�
	pPatPathoArray->ajoutePatho("0PRO11", 1) ;

	// ajout des objectifs de Sant� dans l'index de Sant�
	pPatPathoArray->ajoutePatho("0OBJE1", 1) ;

  // ajout des traitements dans l'index de Sant�
	pPatPathoArray->ajoutePatho("N00001", 1) ;

	if (false == Referencer("ZCS00", sHealthIndex, "", "", true, false, "", NSRootLink::personHealthIndex, pGraphManager, ""))
		return false ;

  string sRootDocData = pGraphManager->pDataGraph->getLastTree() ;
  pGraphManager->setTree(pPatPathoArray, "", sRootDocData) ;

  return etablirLiensTree(sRootDocData, pGraphManager) ;
}

bool
NSNoyauDocument::createRiskFrame(NSPersonGraphManager* pGraphManager)
{
  if (NULL == pGraphManager)
    return false ;

  string sRiskFollowup = pContexte->getSuperviseur()->getText("riskManagement", "riskFollowup") ;
  if (string("") == sRiskFollowup)
    sRiskFollowup = string("Risks index") ;

  pPatPathoArray->vider() ;

  pPatPathoArray->ajoutePatho("ORISK1", 0) ;

	if (false == Referencer("ZCS00", sRiskFollowup, "", "", true, false, "", NSRootLink::personRiskManager, pGraphManager, ""))
		return false ;

  string sRootDocData = pGraphManager->pDataGraph->getLastTree() ;
  pGraphManager->setTree(pPatPathoArray, "", sRootDocData) ;

  return etablirLiensTree(sRootDocData, pGraphManager) ;
}

bool
NSNoyauDocument::createSynthesisFrame(NSPersonGraphManager* pGraphManager)
{
  if (NULL == pGraphManager)
    return false ;

  string sSynthesisForm = pContexte->getSuperviseur()->getText("synthesisManagement", "synthesisForm") ;
  if (string("") == sSynthesisForm)
    sSynthesisForm = string("Synthesis form") ;

  pPatPathoArray->vider() ;

  pPatPathoArray->ajoutePatho("ZSYNT1", 0) ;

	if (false == Referencer("ZCS00", sSynthesisForm, "", "", true, false, "", NSRootLink::personSynthesis, pGraphManager, ""))
		return false ;

  string sRootDocData = pGraphManager->pDataGraph->getLastTree() ;
  pGraphManager->setTree(pPatPathoArray, "", sRootDocData) ;

  return etablirLiensTree(sRootDocData, pGraphManager) ;
}

bool
NSNoyauDocument::createIdentifiersFrame(NSPersonGraphManager* pGraphManager)
{
  if (NULL == pGraphManager)
    return false ;

  string sIdentifiersLibrary = pContexte->getSuperviseur()->getText("identifiersManagement", "identifiersLibrary") ;
  if (string("") == sIdentifiersLibrary)
    sIdentifiersLibrary = string("Identifiers library") ;

  pPatPathoArray->vider() ;

  pPatPathoArray->ajoutePatho("0LIBI1", 0) ;

	if (false == Referencer("ZCS00", sIdentifiersLibrary, "", "", true, false, "", NSRootLink::personIdentifiers, pGraphManager, ""))
		return false ;

  string sRootDocData = pGraphManager->pDataGraph->getLastTree() ;
  pGraphManager->setTree(pPatPathoArray, "", sRootDocData) ;

  return etablirLiensTree(sRootDocData, pGraphManager) ;
}

bool
NSNoyauDocument::etablirLiensTree(string sNodeData, NSPersonGraphManager* pGraphManager)
{
  if ((NULL == pGraphManager) || (string("") == sNodeData))
    return false ;

  if (bCreerMetaLien)
  {
  	NSLinkManager Link(pContexte, pGraphManager->pDataGraph) ;
    if (false == Link.etablirLien(sCodeDocMeta, NSRootLink::docData, sNodeData))    {
    	erreur("Impossible de faire le lien vers le document data.", standardError, 0) ;
      return false ;
    }    bCreerMetaLien = false ;
  }
  else if (string("") != sCodeDocMeta)
  {  	// Note : le lien contributionModified ne peut s'�tablir que la deuxi�me fois    // qu'on enregistre les donn�es, car la premi�re fois bCreerMetaLien est true.    string sContribution = pContexte->getPatient()->getContribution() ;    NSLinkManager Link(pContexte, pGraphManager->pDataGraph) ;    if (false == Link.existeLien(sCodeDocMeta, NSRootLink::contributionModified, sContribution))    {    	// lien du m�ta vers la contribution en cours      if (false == Link.etablirLien(sCodeDocMeta, NSRootLink::docData, sNodeData))      {
      	string sErrorText = pContexte->getSuperviseur()->getText("documentManagementErrors", "cannotEstablishALinkWithTheContribution") ;
        pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
        erreur(sErrorText.c_str(), standardError, 0) ;
        return false ;
      }    }  }
  return true ;
}

// Fin de NsdocNoy.cpp////////////////////////////////////////////////////////////////////////

