//---------------------------------------------------------------------------//    NS_FIC.CPP
//    KRZISCH PH.   janvier 92
//  Impl�mentation des objets de gestion des fiches descriptives
//---------------------------------------------------------------------------
#include <utility.h>
#include <mem.h>
#include <string.h>
#include <cstring.h>

//using namespace std;

#include "nautilus\nssuper.h"
#include "nautilus\nsrechdl.h"
#include "partage\nsdivfct.h"
#include "nsbb\nspatpat.h"
#include "nssavoir\ns_fic.h"

//***************************************************************************
// Impl�mentation des m�thodes NSSavFiche
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSSavFicheData::NSSavFicheData()
{
	metAZero() ;
}

//---------------------------------------------------------------------------
//  Fonction : NSSavFicheData::metAZero()
//  Met les champs de donn�es � z�ro
//---------------------------------------------------------------------------
void
NSSavFicheData::metAZero()
{
	memset(sens, 0, FICHE_SENS_LEN + 1) ;
	NSPathoBaseData::metAZero() ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSSavFicheData::NSSavFicheData(NSSavFicheData& rv)
{
	strcpy(sens, 			       rv.sens) ;
	strcpy(codeLocalisation, rv.codeLocalisation) ;
	strcpy(type, 			       rv.type) ;
	strcpy(lexique,   	     rv.lexique) ;
	strcpy(complement, 	     rv.complement) ;
	strcpy(unit, 	           rv.unit) ;
	strcpy(certitude, 	     rv.certitude) ;
	strcpy(interet, 		     rv.interet) ;
	strcpy(pluriel,   	     rv.pluriel) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSSavFicheData::~NSSavFicheData()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSSavFicheData&
NSSavFicheData::operator=(NSSavFicheData src)
{
	if (this == &src)
		return *this ;

	strcpy(sens, 			       src.sens) ;
	strcpy(codeLocalisation, src.codeLocalisation) ;
	strcpy(type, 			       src.type) ;
	strcpy(lexique,   	     src.lexique) ;
	strcpy(complement, 	     src.complement) ;
  strcpy(unit, 	           src.unit) ;
	strcpy(certitude, 	     src.certitude) ;
	strcpy(interet, 		     src.interet) ;
	strcpy(pluriel,   	     src.pluriel) ;

	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSSavFicheData::operator == (const NSSavFicheData& o)
{
	if ((strcmp(sens, 		  o.sens) 			== 0) &&
		 (strcmp(codeLocalisation, o.codeLocalisation) == 0))
		return 1 ;
	else
		return 0 ;
}

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSSavFiche::NSSavFiche(NSContexte* pCtx)
           :NSFiche(pCtx)
{
	//
	// Cr�e un objet de donn�es
	//
	pDonnees = new NSSavFicheData() ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSSavFiche::NSSavFiche(NSSavFiche& rv)
           :NSFiche(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSSavFicheData() ;
	//
	// Copie les valeurs du NSSavFicheInfo d'origine
	//
	*pDonnees = *(rv.pDonnees) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSSavFiche::~NSSavFiche()
{
	delete pDonnees ;
}

//---------------------------------------------------------------------------
//  Fonction : NSSavFiche::alimenteFiche()
//
//  Transf�re le contenu de pRecBuff dans les variables de la fiche
//---------------------------------------------------------------------------
void
NSSavFiche::alimenteFiche()
{
	alimenteChamp(pDonnees->sens, 		        FICHE_SENS_FIELD, 			  FICHE_SENS_LEN) ;
	alimenteChamp(pDonnees->codeLocalisation, FICHE_LOCALISATION_FIELD, BASE_LOCALISATION_LEN) ;
	alimenteChamp(pDonnees->type, 		        FICHE_TYPE_FIELD, 			  BASE_TYPE_LEN) ;
	alimenteChamp(pDonnees->lexique, 	        FICHE_LEXIQUE_FIELD, 		  BASE_LEXIQUE_LEN) ;
	alimenteChamp(pDonnees->complement,       FICHE_COMPLEMENT_FIELD, 	BASE_COMPLEMENT_LEN) ;
  alimenteChamp(pDonnees->unit,             FICHE_UNIT_FIELD,         BASE_UNIT_LEN) ;
	alimenteChamp(pDonnees->certitude, 	      FICHE_CERTITUDE_FIELD, 	  BASE_CERTITUDE_LEN) ;
	alimenteChamp(pDonnees->interet, 	        FICHE_INTERET_FIELD, 		  BASE_INTERET_LEN) ;
	alimenteChamp(pDonnees->pluriel, 	        FICHE_PLURIEL_FIELD, 		  BASE_PLURIEL_LEN) ;
}

//---------------------------------------------------------------------------
//  Fonction : NSSavFiche::videFiche()
//
//  Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSSavFiche::videFiche()
{
	videChamp(pDonnees->sens, 		  	    FICHE_SENS_FIELD, 			  FICHE_SENS_LEN) ;
	videChamp(pDonnees->codeLocalisation, FICHE_LOCALISATION_FIELD, BASE_LOCALISATION_LEN) ;
	videChamp(pDonnees->type, 		  	    FICHE_TYPE_FIELD, 			  BASE_TYPE_LEN) ;
	videChamp(pDonnees->lexique, 	  	    FICHE_LEXIQUE_FIELD, 		  BASE_LEXIQUE_LEN) ;
	videChamp(pDonnees->complement,       FICHE_COMPLEMENT_FIELD, 	BASE_COMPLEMENT_LEN) ;
  videChamp(pDonnees->unit,             FICHE_UNIT_FIELD,         BASE_UNIT_LEN) ;
	videChamp(pDonnees->certitude, 	      FICHE_CERTITUDE_FIELD, 	  BASE_CERTITUDE_LEN) ;
	videChamp(pDonnees->interet, 	  	    FICHE_INTERET_FIELD, 		  BASE_INTERET_LEN) ;
	videChamp(pDonnees->pluriel, 	  	    FICHE_PLURIEL_FIELD, 		  BASE_PLURIEL_LEN) ;
}

//---------------------------------------------------------------------------
//  Fonction :  	NSSavFiche::getRecord()
//
//  Prend l'enregistrement en cours et assigne la valeur des
//  champs aux variables membres de la classe.
//
//  Returns:   	PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSSavFiche::getPatRecord()
{
	//
	// La table est-elle ouverte ?
	//
	if (!isOpen)
		return(lastError = ERROR_TABLENOTOPEN) ;
	//
	// Appel de la classe de base pour r�cup�rer l'enregistrement.
	//
	lastError = getDbiRecord(dbiWRITELOCK) ;

	return(lastError) ;
}

//---------------------------------------------------------------------------//  Fonction : NSSavFiche::open()
//
//  Ouvre la table primaire et les index secondaires
//
//  Retour :	PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSSavFiche::open()
{
	char tableName[] = "NSM_FICHES.DB" ;
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_PARTAGE_GLOBAL) ;
	return(lastError) ;
}

//---------------------------------------------------------------------------
//  Function:  NSSavFiche::Create()
//
//---------------------------------------------------------------------------
bool
NSSavFiche::Create()
{
	return true ;
}

//---------------------------------------------------------------------------
//  Function:  NSSavFiche::Modify()
//
//---------------------------------------------------------------------------
bool
NSSavFiche::Modify()
{
	return true ;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSSavFiche&
NSSavFiche::operator=(NSSavFiche src)
{
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSSavFiche::operator == ( const NSSavFiche& o )
{
	return (*pDonnees == *(o.pDonnees)) ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSSavFicheInfo::NSSavFicheInfo()
//
//  Description:	Constructeur par d�faut
//---------------------------------------------------------------------------
NSSavFicheInfo::NSSavFicheInfo()
{
    // Cr�e l'objet de donn�es
	pDonnees = new NSSavFicheData() ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSSavFicheInfo::NSSavFicheInfo(NSSavFiche*)
//
//  Description:	Constructeur � partir d'un NSSavFiche
//---------------------------------------------------------------------------
NSSavFicheInfo::NSSavFicheInfo(NSSavFiche* pPatho)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSSavFicheData() ;
	//
	// Copie les valeurs du NSDocument
	//
	*pDonnees = *(pPatho->pDonnees) ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSSavFicheInfo::NSSavFicheInfo(NSSavFicheInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSSavFicheData() ;
	//
	// Copie les valeurs du NSSavFicheInfo d'origine
	//
	*pDonnees = *(rv.pDonnees) ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSSavFicheInfo::~NSSavFicheInfo()
{
	delete pDonnees ;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSSavFicheInfo&
NSSavFicheInfo::operator=(NSSavFicheInfo src)
{
	if (this == &src)
		return *this ;

	*pDonnees = *(src.pDonnees) ;
	return *this ;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSSavFicheInfo::operator == ( const NSSavFicheInfo& o )
{
	return (*pDonnees == *(o.pDonnees));
}

//***************************************************************************
// Impl�mentation des m�thodes NSFicheManager
//***************************************************************************

NSFicheManager::NSFicheManager(NSContexte* pCtx)
               :NSRoot(pCtx)
{
	pCurseur = new NSSavFiche(pCtx) ;
	//
	// Ouverture du fichier
	//
	pCurseur->lastError = pCurseur->open() ;
	if (pCurseur->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier de fiches.", standardError, pCurseur->lastError) ;
		delete pCurseur ;
	}
}

NSFicheManager::NSFicheManager(NSFicheManager& rv)
               :NSRoot(rv.pContexte)
{
	pCurseur = new NSSavFiche(pContexte) ;
	//
	// Ouverture du fichier
	//
	pCurseur->lastError = pCurseur->open() ;
	if (pCurseur->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier de fiches.", standardError, pCurseur->lastError) ;
		delete pCurseur ;
	}
}

NSFicheManager::~NSFicheManager()
{
	if (pCurseur)
	{
		pCurseur->close() ;
		delete pCurseur ;
	}
}

bool
NSFicheManager::getFiche(string sSens, NSPatPathoArray* pPPTarray, bool bVerbose)
{
	if ((!pPPTarray) || (sSens == ""))
		return false ;

	pPPTarray->vider() ;

	//
	// Recherche de la premi�re fiche
	//
	string cle = sSens + string(BASE_LOCALISATION_LEN, ' ') ;

	pCurseur->lastError = pCurseur->chercheClef(    &cle,
                                                    "",
                                                    0,
                                                    keySEARCHGEQ,
                                                    dbiWRITELOCK) ;
	if (pCurseur->lastError != DBIERR_NONE)
	{
  	if (bVerbose)
    	erreur("Il n'existe pas de fiche pour cet �l�ment.", standardError, pCurseur->lastError) ;
		return false ;
	}

	pCurseur->lastError = pCurseur->getRecord() ;
	if (pCurseur->lastError != DBIERR_NONE)
	{
		erreur("Le fichier de fiches est d�fectueux.", standardError, pCurseur->lastError) ;
		return false ;
	}
	if (strcmp(sSens.c_str(), pCurseur->pDonnees->sens) != 0)
	{
  	if (bVerbose)
    	erreur("Il n'existe pas de fiche pour cet �l�ment.", standardError, pCurseur->lastError) ;
		return false ;
	}
  //
  // On avance dans le fichier tant que les fiches trouv�es appartiennent
  // � ce compte rendu
  //
	while ((pCurseur->lastError != DBIERR_EOF) &&
   		            (strcmp(sSens.c_str(), pCurseur->pDonnees->sens) == 0))
	{
  	pPPTarray->push_back(new NSPatPathoInfo(pCurseur)) ;
    pCurseur->lastError = pCurseur->suivant(dbiWRITELOCK) ;
    if ((pCurseur->lastError != DBIERR_NONE) && (pCurseur->lastError != DBIERR_EOF))
    {
    	erreur("Pb d'acces a la fiche suivante.", standardError, pCurseur->lastError) ;
			return false ;
		}

    if (pCurseur->lastError == DBIERR_NONE)
    {
    	pCurseur->lastError = pCurseur->getRecord() ;
      if (pCurseur->lastError != DBIERR_NONE)
			{
      	erreur("Le fichier de fiches est d�fectueux.", standardError, pCurseur->lastError) ;
				return false ;
      }
    }
  }
  return true ;
}

bool
NSFicheManager::setFiche(string sSens, NSPatPathoArray* pPPTarray)
{
	//
	// On efface d'abord les anciennes donn�es
	//
	string cle = sSens + string(BASE_LOCALISATION_LEN, ' ') ;
	bool effacer = true ;
	while (effacer)
	{
		effacer = false ;
    pCurseur->lastError = pCurseur->chercheClef(&cle,
                                                    "",
                                                    0,
                                                    keySEARCHGEQ,
                                                    dbiWRITELOCK) ;
    if (pCurseur->lastError == DBIERR_NONE)
    {
    	pCurseur->lastError = pCurseur->getRecord() ;
      if (pCurseur->lastError == DBIERR_NONE)
      	if (strcmp(sSens.c_str(), pCurseur->pDonnees->sens) == 0)
        	effacer = true ;
    }
    if (effacer)
    {
    	pCurseur->lastError = pCurseur->deleteRecord() ;
      if (pCurseur->lastError != DBIERR_NONE)
      	effacer = false ;
    }
  }

	if ((!pPPTarray) || (pPPTarray->empty()))
  	return true ;

	//
	// Stockage de la PatPathoArray dans la base
	//
	for (PatPathoIter iJ = pPPTarray->begin(); iJ != pPPTarray->end(); iJ++)
	{
		*((NSPathoBaseData*)pCurseur->pDonnees) = *((NSPathoBaseData*)(*iJ)->pDonnees) ;
    strcpy(pCurseur->pDonnees->sens, sSens.c_str()) ;

    pCurseur->lastError = pCurseur->appendRecord() ;
    if (pCurseur->lastError != DBIERR_NONE)
  	{
    	erreur("Erreur � la sauvegarde des donn�es.", standardError, pCurseur->lastError) ;
      return false ;
    }
  }
  //
  // Fermeture de la base
  //
  return true ;
}

void
NSFicheManager::updateFiche(NSPatPathoArray* pFiche, string sChapter, string sSubChapter, NSPatPathoArray* pPPTvalues)
{
	if (NULL == pFiche)
		return ;

	//
	// Fiche vide : on ajoute simplement
	//
	if (pFiche->empty())
	{
  	if ((NULL == pPPTvalues) || (pPPTvalues->empty()))
    	return ;

    int iCol = 0 ;
    if (sChapter != "")
    {
    	pFiche->ajoutePatho(sChapter, iCol++) ;
      if (sSubChapter != "")
      	pFiche->ajoutePatho(sSubChapter, iCol++) ;
      pFiche->InserePatPatho(pFiche->end(), pPPTvalues, iCol++) ;
    }
    return ;
  }
  //
  // Fiche non vide : on supprime les anciennes valeurs, puis on ajoute les nouvelles
  //
  if (sChapter != "")
  {
  	string sSepar = string("/") ;
    string sCodeSens ;
    pContexte->getSuperviseur()->getDico()->donneCodeSens(&sChapter, &sCodeSens) ;
    string sChem = sCodeSens ;
    if (sSubChapter != "")
    {
    	pContexte->getSuperviseur()->getDico()->donneCodeSens(&sSubChapter, &sCodeSens) ;
      sChem += sSepar + sCodeSens ;
    }
    string sLoca ;
    //
    // Recherche de la chaine...
    //
    PatPathoIter pptIter = pFiche->ChaineDansPatpatho(sChem, &sLoca, sSepar) ;
    //
    // Chaine enti�rement trouv�e
    //
    if ((pptIter) && (pptIter != pFiche->end()) && (sLoca == sChem))
    {
    	if ((pPPTvalues) && (!(pPPTvalues->empty())))
      {
      	pFiche->SupprimerFils(pptIter) ;
        pFiche->InserePatPathoFille(pptIter, pPPTvalues) ;
      }
      else
      	pFiche->SupprimerItem(pptIter) ;
    }
    else if (sSubChapter != "")
    {
    	if ((pPPTvalues) && (!(pPPTvalues->empty())))
      {
      	// On cherche le chapitre tout seul
        //
        pContexte->getSuperviseur()->getDico()->donneCodeSens(&sChapter, &sCodeSens) ;
        sChem = sCodeSens ;
        PatPathoIter pptIter = pFiche->ChaineDansPatpatho(sChem, &sLoca, sSepar) ;
        //
        // Chapitre trouv�
        //
        if ((pptIter) && (pptIter != pFiche->end()) && (sLoca == sChem))
        {
        	NSPatPathoArray NewPpt(pContexte) ;
          NewPpt.ajoutePatho(sSubChapter, 0) ;
          NewPpt.InserePatPatho(NewPpt.end(), pPPTvalues, 1) ;
          pFiche->InserePatPathoFille(pptIter, &NewPpt) ;
        }
      }
    }
    //
    // Le chapitre n'existe pas et le sous-chapitre est vide
    //
    else if ((pPPTvalues) && (!(pPPTvalues->empty())))
    {
    	pFiche->ajoutePatho(sChapter, 0) ;
      pFiche->InserePatPatho(pFiche->end(), pPPTvalues, 1) ;
    }
  }
  else
  {
  	pFiche->vider() ;

    if ((!pPPTvalues) || (pPPTvalues->empty()))
    	return ;

    *pFiche = *pPPTvalues ;
	}
}

