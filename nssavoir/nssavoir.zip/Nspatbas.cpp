//---------------------------------------------------------------------------//    NSPERSON.CPP
//    KRZISCH PH.   janvier 92
//  Impl�mentation de objets NAUTILUS
//---------------------------------------------------------------------------
#include <utility.h>
#include <mem.h>
#include <string.h>
#include <cstring.h>

//using namespace std;

#include "partage\nsdivfct.h"
#include "nssavoir\nspatbas.h"

//***************************************************************************
// Impl�mentation des m�thodes NSPathoBaseData
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSPathoBaseData::NSPathoBaseData()
{
	metAZero();
}

//---------------------------------------------------------------------------
//  Fonction : NSPathoBaseData::metAZero()
//  Met les champs de donn�es � z�ro
//---------------------------------------------------------------------------
void
NSPathoBaseData::metAZero()
{
   memset(codeLocalisation, 0, BASE_LOCALISATION_LEN + 1) ;
   memset(type, 		    0, BASE_TYPE_LEN + 1) ;
   memset(lexique, 		    0, BASE_LEXIQUE_LEN + 1) ;
   memset(complement, 	    0, BASE_COMPLEMENT_LEN + 1) ;
   memset(unit,             0, BASE_UNIT_LEN + 1) ;
   memset(certitude,        0, BASE_CERTITUDE_LEN + 1) ;
   memset(interet,          0, BASE_INTERET_LEN + 1) ;
   memset(pluriel,          0, BASE_PLURIEL_LEN + 1) ;
   memset(visible,          0, BASE_VISIBLE_LEN + 1) ;
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSPathoBaseData::NSPathoBaseData(NSPathoBaseData& rv)
{
    metAZero() ;

	strcpy(codeLocalisation,    rv.codeLocalisation) ;
	strcpy(type, 			    rv.type) ;
	strcpy(lexique,   	        rv.lexique) ;
    strcpy(complement, 	        rv.complement) ;
    strcpy(unit, 	            rv.unit) ;
	strcpy(certitude, 	        rv.certitude) ;
	strcpy(interet, 		    rv.interet) ;
	strcpy(pluriel,   	        rv.pluriel) ;
    strcpy(visible,   	        rv.visible) ;
}

//---------------------------------------------------------------------------//  Destructeur
//---------------------------------------------------------------------------
NSPathoBaseData::~NSPathoBaseData()
{
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSPathoBaseData&
NSPathoBaseData::operator=(NSPathoBaseData src)
{
    metAZero() ;

	strcpy(codeLocalisation,    src.codeLocalisation) ;
	strcpy(type,                src.type) ;
	strcpy(lexique,             src.lexique) ;
    strcpy(complement,          src.complement) ;
    strcpy(unit,                src.unit) ;
	strcpy(certitude,           src.certitude) ;
	strcpy(interet,             src.interet) ;
	strcpy(pluriel,             src.pluriel) ;
    strcpy(visible,             src.visible) ;

	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSPathoBaseData::operator == (const NSPathoBaseData& o)
{
	//
	// Le champ "visible", qui n'est pas � proprement parler un champ
	// de donn�es est exclus de la comparaison
	//
	if ((strcmp(codeLocalisation,   o.codeLocalisation) == 0) &&
   	   (strcmp(type, 		        o.type) 			== 0) &&
       (strcmp(lexique,             o.lexique) 		    == 0) &&
       (strcmp(complement,          o.complement) 	    == 0) &&
       (strcmp(unit,                o.unit) 	        == 0) &&
       (strcmp(certitude, 	        o.certitude) 	    == 0) &&
       (strcmp(interet, 	        o.interet) 		    == 0) &&
       (strcmp(pluriel, 	        o.pluriel) 		    == 0) &&
       (strcmp(visible, 	        o.visible) 		    == 0)
       )
		return 1;
	else
		return 0;
}

bool
NSPathoBaseData::sameContent(const NSPathoBaseData& o)
{
	//
  // Le champ "codeLocalisation" est exclu de la comparaison
  //
	// Le champ "visible", qui n'est pas � proprement parler un champ
	// de donn�es est exclu de la comparaison
	//
	if ((strcmp(type, 		   	o.type) 					== 0) &&
       (strcmp(lexique,    	o.lexique) 		    == 0) &&
       (strcmp(complement,	o.complement) 		== 0) &&
       (strcmp(unit,       	o.unit) 	        == 0) &&
       (strcmp(certitude,  	o.certitude) 	    == 0) &&
       (strcmp(interet, 		o.interet) 		    == 0) &&
       (strcmp(pluriel, 		o.pluriel) 		    == 0) &&
       (strcmp(visible, 	 	o.visible) 		    == 0)
       )
		return true ;
	else
		return false ;
}

