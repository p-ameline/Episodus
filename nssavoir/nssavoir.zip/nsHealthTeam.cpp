// -----------------------------------------------------------------------------
// nsHealthTeam.cpp
// -----------------------------------------------------------------------------
// Gestion l'Equipe de Sant�
// -----------------------------------------------------------------------------
// $Revision: 1.42 $
// $Author: fabrice $
// $Date: 2005/06/28 16:21:20 $
// -----------------------------------------------------------------------------
// FLP - juin 2004
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// Copyright Nautilus, 2004
// http://www.nautilus-info.com
// -----------------------------------------------------------------------------
// Ce logiciel est un programme informatique servant � g�rer et traiter les
// informations de sant� d'une personne.
//
// Ce logiciel est r�gi par la licence CeCILL soumise au droit fran�ais et
// respectant les principes de diffusion des logiciels libres. Vous pouvez
// utiliser, modifier et/ou redistribuer ce programme sous les conditions de la
// licence CeCILL telle que diffus�e par le CEA, le CNRS et l'INRIA sur le site
// "http://www.cecill.info".
//
// En contrepartie de l'accessibilit� au code source et des droits de copie, de
// modification et de redistribution accord�s par cette licence, il n'est offert
// aux utilisateurs qu'une garantie limit�e. Pour les m�mes raisons, seule une
// responsabilit� restreinte p�se sur l'auteur du programme, le titulaire des
// droits patrimoniaux et les conc�dants successifs.
//
// A cet �gard  l'attention de l'utilisateur est attir�e sur les risques
// associ�s au chargement, � l'utilisation, � la modification et/ou au
// d�veloppement et � la reproduction du logiciel par l'utilisateur �tant donn�
// sa sp�cificit� de logiciel libre, qui peut le rendre complexe � manipuler et
// qui le r�serve donc � des d�veloppeurs et des professionnels avertis
// poss�dant des connaissances informatiques approfondies. Les utilisateurs sont
// donc invit�s � charger et tester l'ad�quation du logiciel � leurs besoins
// dans des conditions permettant d'assurer la s�curit� de leurs syst�mes et ou
// de leurs donn�es et, plus g�n�ralement, � l'utiliser et l'exploiter dans les
// m�mes conditions de s�curit�.
//
// Le fait que vous puissiez acc�der � cet en-t�te signifie que vous avez pris
// connaissance de la licence CeCILL, et que vous en avez accept� les termes.
// -----------------------------------------------------------------------------
// This software is a computer program whose purpose is to manage and process
// a person's health data.
//
// This software is governed by the CeCILL  license under French law and abiding
// by the rules of distribution of free software. You can use, modify and/ or
// redistribute the software under the terms of the CeCILL license as circulated
// by CEA, CNRS and INRIA at the following URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy, modify
// and redistribute granted by the license, users are provided only with a
// limited warranty and the software's author, the holder of the economic
// rights, and the successive licensors have only limited liability.
//
// In this respect, the user's attention is drawn to the risks associated with
// loading, using, modifying and/or developing or reproducing the software by
// the user in light of its specific status of free software, that may mean that
// it is complicated to manipulate, and that also therefore means that it is
// reserved for developers and experienced professionals having in-depth
// computer knowledge. Users are therefore encouraged to load and test the
// software's suitability as regards their requirements in conditions enabling
// the security of their systems and/or data to be ensured and, more generally,
// to use and operate it in the same conditions as regards security.
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL license and that you accept its terms.
// -----------------------------------------------------------------------------


#include "nssavoir\nsHealthTeam.h"
//#include "nssavoir\nsRightsManager.h"
#include "nssavoir\GraphicHealthTeam.h"
#include "nsbb\nsbbtran.h"

#include "nautilus\nssuper.h"
#include "nsepisod\nsldvuti.h"


// -----------------------------------------------------------------------------
// classe NSTeam
// -----------------------------------------------------------------------------
// classe repr�sentant une Equipe
// --
// class that represents a Team
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// default constructor // only for type == moralPerson
// -----------------------------------------------------------------------------
NSTeam::NSTeam(teamType aType)
{
	pTeamMembers	= new NSHealthTeamMemberArray() ;
  type					= aType ;
}


// -----------------------------------------------------------------------------
// constructeur copie
// --
// copy constructor
// -----------------------------------------------------------------------------
NSTeam::NSTeam(NSTeam& src)
{
	pTeamMembers		= new NSHealthTeamMemberArray(*(src.pTeamMembers)) ;
  type						= src.type ;
}


// -----------------------------------------------------------------------------
// destructeur
// --
// destructor
// -----------------------------------------------------------------------------
NSTeam::~NSTeam()
{
	delete pTeamMembers ;
}


// -----------------------------------------------------------------------------
// donne la liste des Person IDs des membres de l'Equipe de Sant�.
// --
// get the person IDs list of HealthTeam member
// -----------------------------------------------------------------------------
// modification by FLP on 02/03/2005 :
// we check if the member is a person before insering it in the list we return.
// -----------------------------------------------------------------------------
VecteurString *
NSTeam::getPIDs()
{
	VecteurString	*pPIDs = new VecteurString() ;
	if (pTeamMembers != NULL)
	{
		for (NSHealthTeamMemberIter memberIter = pTeamMembers->begin() ; memberIter != pTeamMembers->end() ; memberIter++)
    	if ((*memberIter)->getType() == NSHealthTeamMember::person)
				pPIDs->push_back(new string((*memberIter)->getID())) ;
	}
	return pPIDs ;
}


// -----------------------------------------------------------------------------
// op�rateur =
// --
// operator =
// -----------------------------------------------------------------------------
NSTeam&
NSTeam::operator=(NSTeam& src)
{
	if (this == &src)
		return *this ;

	pTeamMembers->vider() ;
	delete pTeamMembers ;

	pTeamMembers = new NSHealthTeamMemberArray(*(src.pTeamMembers)) ;
  type         = src.type ;

	return (*this) ;
}


bool
NSTeam::createTree(NSPatPathoArray *pPPT, int iCol)
{
	if ((pTeamMembers != NULL) && (!pTeamMembers->empty()))
  {
  	for (NSHealthTeamMemberIter memberIter = pTeamMembers->begin() ; memberIter != pTeamMembers->end() ; memberIter++)
    	if (!(*memberIter)->createTree(pPPT, iCol))
      	return false ;
  }
  return true ;
}



// -----------------------------------------------------------------------------
// ajoute un membre dans l'Equipe de Sant�.
// --
// add a member in the HealthTeam.
// -----------------------------------------------------------------------------
void
NSTeam::addMember(NSHealthTeamMember *pMember, NSHealthTeamMember::memberType mType, NSPatPathoArray *pPPT)
{
	// fabTODO
	// on met par d�faut un membre dans la colonne 1 (�quipe de sant� en colonne 0)
  pMember->setType(mType) ;
	pMember->createTree(pPPT, 1) ;
	pTeamMembers->push_back(pMember) ;
}


// -----------------------------------------------------------------------------
// modifie un membre de l'Equipe de Sant�.
// --
// modify a member in the HealthTeam.
// -----------------------------------------------------------------------------
void
NSTeam::modMember(NSContexte *pCtx, NSHealthTeamMember *pMember, NSPatPathoArray *pPPT)
{
	// retrouver l'item dans la liste
	NSHealthTeamMemberIter	memberIter = NULL ;

	for (memberIter = pTeamMembers->begin() ; memberIter != pTeamMembers->end() ; memberIter++)
	{
		if ((*memberIter) == pMember)
			break ;
	}

	if ((memberIter == NULL) || (memberIter == pTeamMembers->end()))
	{
		// erreur
		return ;
	}

	// fabTODO
	// v�rification de son sous-arbre (voir modifier)
	// verification of subtree (perhaps modify)
	// fabTODO
	// on met par d�faut un membre dans la colonne 1 (�quipe de sant� en colonne 0)
	pMember->modifyTree(pCtx, pPPT, 1) ;
}


// -----------------------------------------------------------------------------
// supprime un membre de l'Equipe de Sant�.
// --
// delete a member in the HealthTeam.
// -----------------------------------------------------------------------------
void
NSTeam::delMember(NSHealthTeamMember *pMember, NSPatPathoArray *pPPT)
{
	// retrouver l'item dans la liste
	NSHealthTeamMemberIter	memberIter = NULL ;
	for (memberIter = pTeamMembers->begin() ; memberIter != pTeamMembers->end() ; memberIter++)
		if ((*memberIter) == pMember)
			break ;

	if ((memberIter == NULL) || (memberIter == pTeamMembers->end()))
		// erreur
		return ;

	// supprimer l'�l�ment et son sous arbre
  // delete item and its subtree in the tree
  //
  PatPathoIter pMemberRootIter = NULL ;
  if (pMember->sNodeID != string(""))
  	pMemberRootIter = pPPT->ChercherNoeud(pMember->sNodeID) ;
	else
  	pMemberRootIter = pMember->pptNode ;

  if (NULL != pMemberRootIter)
		pPPT->SupprimerItem(pMemberRootIter) ;

	// effacer l'item - deleting item
	delete pMember ;
	pTeamMembers->erase(memberIter) ;
}


bool
NSTeam::isMemberP(string personId)
{
  if (pTeamMembers->empty())
    return false ;
    
	for (NSHealthTeamMemberIter mIter = pTeamMembers->begin() ; mIter != pTeamMembers->end() ; mIter++)
  {
  	if ((*mIter)->getID() == personId)
			return true ;
  }
  return false ;
}


bool
NSTeam::isActiveMember(string personId)
{
  if (pTeamMembers->empty())
    return false ;

  for (NSHealthTeamMemberIter mIter = pTeamMembers->begin() ; mIter != pTeamMembers->end() ; mIter++)
  {
    if ((*mIter)->getID() == personId)
    {
      NSHTMMandateArray mMandates ;
      (*mIter)->getActiveMandates(&mMandates) ;
      if (!mMandates.empty())
        return true ;
    }
  }
  return false ;
}


NSHealthTeamMember *
NSTeam::getMember(string id)
{
	// fabFIXME
  // il faudrait g�rer le cas o� un m�me membre est pr�sent plusieurs fois au sein d'une Equipe
	for (NSHealthTeamMemberIter memberIter = pTeamMembers->begin() ; memberIter != pTeamMembers->end() ; memberIter++)
  {
  	if ((*memberIter)->getID() == id)
			return (*memberIter) ;
  }

  return NULL ;
}


void
NSTeam::closeAllMandates(NSContexte *pCtx, NSHealthTeamMember *pMe, NSPatPathoArray *pPPT)
{
  pMe->closeAllMandates(pCtx, pPPT) ;
}


void
NSTeam::closeAllMandates(NSContexte *pCtx, string sPersonId, NSPatPathoArray *pPPT)
{
  for (NSHealthTeamMemberIter mIter = pTeamMembers->begin() ; mIter != pTeamMembers->end() ; mIter++)
  {
    if ((*mIter)->getID() == sPersonId)
      (*mIter)->closeAllMandates(pCtx, pPPT) ;
  }
}



// -----------------------------------------------------------------------------
// class NSHealthTeam
//
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// constructor from tree (patpatho)
// -----------------------------------------------------------------------------
NSHealthTeam::NSHealthTeam(NSPatPathoArray *pPPT)
{
	pTeam		= new NSTeam(NSTeam::healthTeam) ;
  ppt			= new NSPatPathoArray(*pPPT) ;
  initFromPatho() ;
}


// -----------------------------------------------------------------------------
// copy constructor
// -----------------------------------------------------------------------------
NSHealthTeam::NSHealthTeam(NSHealthTeam& src)
{
  pTeam		= new NSTeam(NSTeam::healthTeam) ;
  ppt			= new NSPatPathoArray(*(src.ppt)) ;
  initFromPatho() ;
}


// -----------------------------------------------------------------------------
// destructor
// -----------------------------------------------------------------------------
NSHealthTeam::~NSHealthTeam()
{
	delete pTeam ;
  delete ppt ;
}


// -----------------------------------------------------------------------------
// operator =
// -----------------------------------------------------------------------------
NSHealthTeam&
NSHealthTeam::operator=(NSHealthTeam& src)
{
	if (this == &src)
		return *this ;

	if (pTeam != NULL)
  	delete pTeam ;
  if (ppt != NULL)
  	delete ppt ;

  pTeam		= new NSTeam(NSTeam::healthTeam) ;
  ppt			= new NSPatPathoArray(*(src.ppt)) ;
  initFromPatho() ;

  return (*this) ; 
}


// -----------------------------------------------------------------------------
// get member that corresponds to current user
// -----------------------------------------------------------------------------
NSHealthTeamMember *
NSHealthTeam::getUserAsMember(NSContexte *pCtx)
{
	// Can we work ?
	if (!pCtx)
  	return NULL ;

  string sUserId = pCtx->getUtilisateurID() ;
  if (sUserId == "")
  	return NULL ;

  NSHealthTeamMember *pMember = pTeam->getMember(sUserId) ;
  return (pMember) ;
}


bool
NSHealthTeam::initFromPatho()
{
try
{
  pptNode = NULL ;
  sNodeID = string("") ;

	pTeam->getMembers()->vider() ;

	if ((ppt == NULL) || (ppt->empty()))
  	return false ;

  PatPathoIter pptIter = ppt->begin() ;

	// traitement du type de l'Equipe - processing team type
	if ((*pptIter)->getLexique() != HEALTHTEAM)
		// cet arbre ne correspond pas � une Equipe de Sant�
		return false ;

  pptNode = pptIter ;
  sNodeID = (*pptIter)->getNode() ;

	int		iColBase = (*pptIter)->getColonne() ;
	pptIter++ ;

	while ((pptIter != ppt->end()) && ((*pptIter)->getColonne() > iColBase))
	{
		if 			((*pptIter)->getLexique() == HTMEMBER)
		{
			NSHealthTeamMember *pNewMember = new NSHealthTeamMember() ;
			if ((pNewMember->initFromPatho(ppt, &pptIter)) && (pNewMember->isActive()))
				pTeam->getMembers()->push_back(pNewMember) ;
      else
      	delete pNewMember ;
		}
		else
		{
			// erreur - on devrait �tre sur un item correspondant � un membre de l'Equipe de Sant�
			return false ;
		}
	}

	return true ;
}
catch (...)
{
	erreur("Exception NSHealthTeam::initFromPatho.", standardError, 0) ;
  return false ;
}
}


// -----------------------------------------------------------------------------
// Function     : bool isMemberP(string)
// Arguments    : sPersonId : ID of person to check if he is present in the Team
// Description  : Does user identified by sPersonId be present in this Team ?
// Returns      : true if he is present, false if he is not
// -----------------------------------------------------------------------------
/*
bool
NSHealthTeam::isMemberP(string sPersonId)
{
  // TODO FIXME -- FLP

  // Attention aux membres qui se trouvent plusieurs fois dans l'equipe
  // normalement pas d'incidence ici

  return (pTeam->isMemberP(sPersonId)) ;
}
*/


/*
bool
NSHealthTeam::createTree()
{
	// cette fonction n'est valable que s'il n'y a pas de ppt d�j� remplie
	if ((ppt == NULL) || (!(ppt->empty())) || (pTeam->getType() != NSTeam::moralPerson))
  	return false ;

  int	iCol = 0 ;
	ppt->ajoutePatho(HEALTHTEAM, iCol, 0) ;

	PatPathoIter pptIter = ppt->end() ;
	pptIter-- ;

	if (((*pptIter)->getLexique() != HEALTHTEAM) || ((*pptIter)->getColonne() != iCol))
  {
		// erreur
		return false ;
	}

	pptNode = pptIter ;

  return (pTeam->createTree(ppt, iCol + 1)) ;
}
*/


// -----------------------------------------------------------------------------
//
// class NSMoralPerson
//
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// constructor
// -----------------------------------------------------------------------------
NSMoralPerson::NSMoralPerson(NSContexte *pCtx)
{
	pTeam				= new NSTeam(NSTeam::moralPerson) ;
  ppt					= new NSPatPathoArray(pCtx) ;
  teamId			= "" ;
  sLabel			= "" ;
  sSpeciality	= "" ;
}

NSMoralPerson::NSMoralPerson(NSContexte *pCtx, string id, string label, string speciality)
{
	pTeam				= new NSTeam(NSTeam::moralPerson) ;
  ppt					= new NSPatPathoArray(pCtx) ;
  teamId			= id ;
  sLabel			= label ;
  sSpeciality	= speciality ;
}

NSMoralPerson::NSMoralPerson(NSPatPathoArray *pPPT)
{
 	pTeam				= new NSTeam(NSTeam::moralPerson) ;

  if (NULL != pPPT)
  	ppt	= new NSPatPathoArray(*pPPT) ;
  else
  	ppt = NULL ;

  teamId			= "" ;
  sLabel			= "" ;
  sSpeciality	= "" ;

  initFromPatho() ;
}

NSMoralPerson::NSMoralPerson(NSMoralPerson& src)
{
	pTeam				= new NSTeam(NSTeam::moralPerson) ;
  ppt					= new NSPatPathoArray(*(src.getPatho())) ;
  teamId			= src.getID() ;
  sLabel			= src.getLabel() ;
  sSpeciality	= src.getSpeciality() ;

  initFromPatho() ;
}

NSMoralPerson::~NSMoralPerson()
{
	if (NULL != pTeam)
		delete pTeam ;
  if (NULL != ppt)
		delete ppt ;
}

bool
NSMoralPerson::initFromPatho()
{
	pptNode = NULL ;
  sNodeID = string("") ;

	if ((NULL == ppt) || (ppt->empty()))
  	return false ;

  PatPathoIter pptIter = ppt->begin() ;

	// traitement du type de l'Equipe - processing team type
	if ((*pptIter)->getLexique() != HTTEAM)
		// cet arbre ne correspond pas � une Equipe de personnes
		return false ;

  pptNode = pptIter ;
  sNodeID = (*pptIter)->getNode() ;

	int iColBase = (*pptIter)->getColonne() ;
	pptIter++ ;

	while ((pptIter != ppt->end()) && ((*pptIter)->getColonne() > iColBase))
	{
		if 			((*pptIter)->getLexique() == HTMEMBER)
		{
			NSHealthTeamMember *pNewMember = new NSHealthTeamMember() ;
			if (pNewMember->initFromPatho(ppt, &pptIter))
				pTeam->getMembers()->push_back(pNewMember) ;
      else
      {
      	delete pNewMember ;
        return false ;
      }
		}
		else if ((*pptIter)->getLexique() == TEAMADMIN)
    {
    	int	iColAdminBase = (*pptIter)->getColonne() ;
      pptIter++ ;

    	while ((pptIter != ppt->end()) && ((*pptIter)->getColonne() > iColAdminBase))
      {
      	if			((*pptIter)->getLexique() == TEAMLABEL)
        {
			   	pptIter++ ;
      		if ((*pptIter)->getLexique() == HTTEAMFREETEXT)
		      {
    				setLabel((*pptIter)->getTexteLibre()) ;
        		pptIter++ ;
        	}
        }
        else if ((*pptIter)->getLexique() == TEAMSPEC)
        {
        	pptIter++ ;

          // when we process a team creation with an archetype, we have a
          // freetext node that appears, and the lexical that we search code is
          // on its son
          if ((*pptIter)->getLexique() == HTTEAMLEXIVAL)
          	pptIter++ ;

          setSpeciality((*pptIter)->getLexique()) ;
          pptIter++ ;
        }
        else if ((*pptIter)->getLexique() == TEAMADDRS)
        {
        }
        else
        {
        	// erreur noeud inconnu � la racine de l'arbre administratif d'une Equipe de Personnes
          return false ;
        }
      }
    }
    else
		{
			// erreur - noeud inconnu � la racine de l'arbre d'une Equipe de Personnes
			return false ;
		}
	}

	return true ;
}

bool
NSMoralPerson::createTree()
{
	// cette fonction n'est valable que s'il n'y a pas de ppt d�j� remplie
	if ((NULL == ppt) || (!(ppt->empty())) || (pTeam->getType() != NSTeam::moralPerson))
  	return false ;

  int	iCol = 0 ;
	ppt->ajoutePatho(HTTEAM, iCol) ;

	PatPathoIter pptIter = ppt->end() ;
	pptIter-- ;

	if (((*pptIter)->getLexique() != HTTEAM) || ((*pptIter)->getColonne() != iCol))
		// erreur
		return false ;

  if ((getLabel() != "") || (getSpeciality() != ""))
  {
  	ppt->ajoutePatho(TEAMADMIN, iCol + 1) ;
  	if (getLabel() 			!= "")
    {
    	ppt->ajoutePatho(TEAMLABEL, iCol + 2) ;
      Message Msg ;
      Msg.SetTexteLibre(getLabel()) ;
      ppt->ajoutePatho(HTTEAMFREETEXT, &Msg, iCol + 3) ;
    }
    if (getSpeciality()	!= "")
    {
    	ppt->ajoutePatho(TEAMSPEC, iCol + 2) ;
      ppt->ajoutePatho(getSpeciality(), iCol + 3) ;
    }
  }

  // fabFIXME il reste les adresses

	pptNode = pptIter ;
  sNodeID = string("") ;

  return (pTeam->createTree(ppt, iCol + 1)) ;
}


// -----------------------------------------------------------------------------
// Function     : bool isMemberP(string)
// Arguments    : sPersonId : ID of person to check if he is present in the Team
// Description  : Does user identified by sPersonId be present in this Team ?
// Returns      : true if he is present, false if he is not
// -----------------------------------------------------------------------------
/*
bool
NSMoralPerson::isMemberP(string sPersonId)
{
  // TODO FIXME -- FLP

  // Attention aux membres qui se trouvent plusieurs fois dans l'equipe
  // normalement pas d'incidence ici

  return (pTeam->isMemberP(sPersonId)) ;
}
*/


// -----------------------------------------------------------------------------
// Function     : bool addMember(string)
// Arguments    : sPersonId : ID of person to add to the team
// Description  : add a member if he is not already present in the team
// Returns      : true if member now in the team
// -----------------------------------------------------------------------------
bool
NSMoralPerson::addMember(NSContexte * /* pCtx */, string personId)
{
  // TODO FIXME -- FLP
  if (!isActiveMember(personId))
  {
    NVLdVTemps	ldvCurDate ;	ldvCurDate.takeTime() ;
    NVLdVTemps	ldvNoLimit ;	ldvNoLimit.setNoLimit() ;

    // ajout des mandats de l'utilisateur -- adding user mandate
    NSHTMMandateArray *pMandatesArray = new NSHTMMandateArray() ;
    pMandatesArray->push_back(new NSHealthTeamMandate(nearDist, 3, "", "", ldvCurDate.donneDateHeure(), ldvNoLimit.donneDateHeure(), "", "", NSHealthTeamMandate::user)) ;
    addMember(new NSHealthTeamMember(personId, NSHealthTeamMember::person, pMandatesArray), NSHealthTeamMember::person) ;
    delete pMandatesArray ;
  }

  if (isActiveMember(personId))
    return true ;

  return false ;
}


// -----------------------------------------------------------------------------
// Function     : bool delMember(string)
// Arguments    : sPersonId : ID of person to del from the team
// Description  : del a member if he is already present in the team
// Returns      : true if member is not present now in the team
// -----------------------------------------------------------------------------
bool
NSMoralPerson::delMember(NSContexte *pCtx, string personId)
{
  // TODO FIXME -- FLP

  // Attention aux membres qui se trouvent plusieurs fois dans l'equipe
  if (isMemberP(personId))
    pTeam->closeAllMandates(pCtx, personId, ppt) ;
  return true ;
}


NSMoralPersonManager&
NSMoralPersonManager::operator=(RosaceManager& src)
{
	pMPTeam = src.getMPTeam() ;

  return (*this) ;
}


NSHealthTeamManager&
NSHealthTeamManager::operator=(RosaceManager& src)
{
	pHTeam = src.getHTeam() ;

  return (*this) ;
}

