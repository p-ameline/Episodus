//---------------------------------------------------------------------------//    NSPERSON.CPP
//    KRZISCH PH.   janvier 92
//  Impl�mentation de objets NAUTILUS
//---------------------------------------------------------------------------

#include <utility.h>#include <mem.h>
#include <string.h>
#include <cstring.h>

//using namespace std;#include "nautilus\nssuper.h"
#include "nautilus\nsrechdl.h"
#include "partage\nsdivfct.h"

#include "nssavoir\nspatho.h"
// -----------------------------------------------------------------------------//// Impl�mentation des m�thodes NSPatholog
//
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------// Description: Constructeur.// -----------------------------------------------------------------------------
NSPathologData::NSPathologData()
{
	// Met les champs de donn�es � z�ro
	memset(libelle,   0, PATHO_LIBELLE_LEN + 1) ;
	memset(code, 	    0, PATHO_CODE_LEN + 1) ;
	memset(grammaire, 0, PATHO_GRAMMAIRE_LEN + 1) ;
	memset(freq, 	    0, PATHO_FREQ_LEN + 1) ;
}


// -----------------------------------------------------------------------------// Description:	Constructeur copie// -----------------------------------------------------------------------------
NSPathologData::NSPathologData(NSPathologData& rv)
{
	strcpy(libelle,   rv.libelle) ;
	strcpy(code, 	    rv.code) ;
	strcpy(grammaire, rv.grammaire) ;
	strcpy(freq,   	  rv.freq) ;
}

// -----------------------------------------------------------------------------
// Description:	Destructeur
// -----------------------------------------------------------------------------
NSPathologData::~NSPathologData()
{
}


// -----------------------------------------------------------------------------
// Description:	Op�rateur =
// -----------------------------------------------------------------------------
NSPathologData&
NSPathologData::operator=(NSPathologData src)
{
	if (this == &src)
		return *this ;

	strcpy(libelle,   src.libelle) ;
	strcpy(code, 	    src.code) ;
	strcpy(grammaire, src.grammaire) ;
	strcpy(freq,   	  src.freq) ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Description:	Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSPathologData::operator==(const NSPathologData& o)
{
	if ((strcmp(libelle, o.libelle) == 0) && (strcmp(code, o.code) == 0))
		return 1 ;
	else
		return 0 ;
}


// -----------------------------------------------------------------------------
// Description: Met � blanc les variables de la fiche
// -----------------------------------------------------------------------------
void
NSPathologData::metABlanc()
{
	// Met les champs de donn�es � blanc
	memset(libelle, 	' ', PATHO_LIBELLE_LEN) ;
	memset(code, 		  ' ', PATHO_CODE_LEN) ;
	memset(grammaire, ' ', PATHO_GRAMMAIRE_LEN) ;
	memset(freq, 	    ' ', PATHO_FREQ_LEN) ;
}


// -----------------------------------------------------------------------------
// Function     : NSPathologData::fabriqueNomLong()
// Description  : Initialise nom_long
// Returns      : Rien
// -----------------------------------------------------------------------------
void
NSPathologData::fabriqueLibelleLong()
{
  //	libelleLong = string(libelle);
}


// -----------------------------------------------------------------------------
//  Function    : NSPathologData::donneLibelleChoix(string* pLibelle)
// Description  : Donne le libell� affich� dans ChoixPathoDialogue
// -----------------------------------------------------------------------------
void
NSPathologData::donneLibelleChoix(string* pLibelle)
{
  // le libell� est du type 	Crohn [maladie][de]{d�tails}
  // qui donne 					Crohn (maladie){d�tails}
  //
  // Les indications d'orthographe au pluriel sont entre ||,
  // il faut les enlever
  string sLibelle = "" ;

  bool dansPluriel = false ;
  for (int k = 0 ; (k < PATHO_LIBELLE_LEN) && (libelle[k] != '\0') ; k++)
	{
    if      (libelle[k] == '|')
    {
      if (dansPluriel)
        dansPluriel = false ;
      else
        dansPluriel = true ;
    }
    else if (!dansPluriel)
      sLibelle += libelle[k] ;
  }

  int  niveau_crochet = -1 ;

  string qualifiant[2] ;
  string mot_debut  = "" ;
  string mot_fin	  = "" ;
  qualifiant[0]     = "" ;
  qualifiant[1]     = "" ;

  // On s�pare le libell� sous la forme :
  // mot_debut 	  = "Crohn"
  // mot_fin   	  = "{d�tails}"
  // qualifiant[0] = "maladie"
  // qualifiant[1] = "de"
  int iLibLen = strlen(sLibelle.c_str()) ;
  for (int k = 0 ; k < iLibLen ; k++)
  {
    if (sLibelle[k] == '[')
    {
      niveau_crochet++ ;
      k++ ;
      
      while ((sLibelle[k] != ']') && (k < iLibLen))
      {
        qualifiant[niveau_crochet] += sLibelle[k] ;
        k++ ;
      }
    }
    else
    {
      if (niveau_crochet == -1)
        mot_debut += sLibelle[k] ;
      else
        mot_fin += sLibelle[k] ;
    }
  }

  // On assemble le nouveau libelle
  *pLibelle = mot_debut ;
  if (qualifiant[0] != "")
    *pLibelle += "(" + qualifiant[0] + ")" ;
  *pLibelle += mot_fin ;

  // On s'assure qu'il fait encore PATHO_LIBELLE_LEN caract�res
  if 	  (strlen(pLibelle->c_str()) < PATHO_LIBELLE_LEN)
    *pLibelle += string(PATHO_LIBELLE_LEN - strlen(pLibelle->c_str()), ' ') ;
  else if (strlen(pLibelle->c_str()) > PATHO_LIBELLE_LEN)
    (*pLibelle)[PATHO_LIBELLE_LEN-1] = '\0' ;


  // On supprime les blancs terminaux
  strip(*pLibelle, stripRight);

  // On v�rifie qu'il n'existe pas plusieurs blancs contigus
  size_t positBlanc = pLibelle->find(" ") ;
  size_t debut, fin, taille ;
  while (positBlanc != NPOS)
  {
    debut  = positBlanc ;

    taille = strlen(pLibelle->c_str()) ;
    if ((debut < taille - 1) && ((*pLibelle)[debut + 1] == ' '))
    {
      fin = debut + 1 ;
      while ((fin < taille - 1) && ((*pLibelle)[fin + 1] == ' '))
        fin++ ;

      *pLibelle = string(*pLibelle, 0, debut) + " " + string(*pLibelle, fin + 1, taille - fin - 1) ;
    }
    else
      fin = debut ;

    debut++ ;
    positBlanc = pLibelle->find(" ", debut) ;
  }
}


// -----------------------------------------------------------------------------
//  Function    : NSPathologData::donneLibelleAffiche(string* pLibelle)
//  Description : Donne le "beau" libell�
//                La variable GenreMaitre sert � donner un genre aux adjectifs
// -----------------------------------------------------------------------------
void
NSPathologData::donneLibelleAffiche(string* pLibelle, int iDeclinaison)
{
  *pLibelle = "";

  // le libell� est du type 	"Crohn [maladie][de]{d�tails}"
  // qui donne 					"maladie de Crohn"
  //
  // Les indications de d�clinaison sont entre ||, s�par�s par des /
  // ex : "disjoint|t/te/ts/tes|"
  //
  // Trois cas sont possibles :
  // 1) Pas de || : mot invariable
  // 2) Un seul �l�ment entre || (ex test|s|) qui donne la premi�re
  //    d�clinaison lorsque la racine est constitu�e du mot entier
  // 3) Plusieurs �l�ments entre || (ex animal|al/aux|), le premier
  //    �l�ment (0) permet de d�finir la racine, les autres donnent les
  //    d�clinaisons (1, 2...)

  int niveau_crochet  = -1 ;
  string mot_debut 	  = "" ;
  string mot_fin	  	= "" ;
  string orthographe  = "" ;
  string qualifiant[2] ;
  qualifiant[0]       = "" ;
  qualifiant[1]       = "" ;

  // On s�pare le libell� sous la forme :
  // mot_debut 	  = "Crohn"
  // mot_fin   	  = "{d�tails}"
  // qualifiant[0] = "maladie"
  // qualifiant[1] = "de"

  for (int k = 0 ; (k < PATHO_LIBELLE_LEN) && (libelle[k] != '\0') ; k++)
  {
    if (libelle[k] == '[')
    {
      niveau_crochet++ ;
      k++ ;
      while ((libelle[k] != ']') && (k < PATHO_LIBELLE_LEN) && (libelle[k] != '\0'))
      {
        if (libelle[k] == '|')
        {
          orthographe = "" ;
          k++ ;
          while ((libelle[k] != '|') && (k < PATHO_LIBELLE_LEN) && (libelle[k] != '\0'))
          {
            orthographe += libelle[k] ;
            k++ ;
          }
          if ((k < PATHO_LIBELLE_LEN) && (libelle[k] == '|'))
            traiteOrthographe(&qualifiant[niveau_crochet], &orthographe, iDeclinaison) ;
          else
            return ;
        }
        else
          qualifiant[niveau_crochet] += libelle[k] ;
        k++ ;
      }
    }
    else
    {
      if      ((libelle[k] == '{') && (k < PATHO_LIBELLE_LEN + 1) && (libelle[k+1] == '|'))
      {
        while ((libelle[k] != '}') && (k < PATHO_LIBELLE_LEN) && (libelle[k] != '\0'))
          k++ ;
      }
      else if (libelle[k] == '|')
      {
        k++ ;
        orthographe = "" ;
        while ((libelle[k] != '|') && (k < PATHO_LIBELLE_LEN) && (libelle[k] != '\0'))
        {
          orthographe += libelle[k] ;
          k++ ;
        }
        if ((k < PATHO_LIBELLE_LEN) && (libelle[k] == '|'))
        {
          if (niveau_crochet == -1)
            traiteOrthographe(&mot_debut, &orthographe, iDeclinaison) ;
          else
            traiteOrthographe(&mot_fin, &orthographe, iDeclinaison) ;
        }
        else
          return ;
      }
      else
      {
        if (niveau_crochet == -1)
          mot_debut += libelle[k] ;
        else
          mot_fin   += libelle[k] ;
      }
    }
  }

  // On assemble le nouveau libelle
  char dernCar = '\0' ;
  char premCar = '\0' ;

  if (!(mot_debut == ""))
    strip(mot_debut, stripBoth) ;

  if (!(mot_fin == ""))
    strip(mot_fin, stripBoth) ;

  *pLibelle = qualifiant[0] ;
  if (qualifiant[0] != "")
    dernCar = qualifiant[0][strlen(qualifiant[0].c_str())-1] ;

  if (qualifiant[1] != "")
  {
    premCar = qualifiant[1][0] ;

    if ((premCar != ' ') && (dernCar != '-') && (dernCar != '\'') && (dernCar != ' '))
      *pLibelle += " " ;

    *pLibelle += qualifiant[1] ;

    dernCar = qualifiant[1][strlen(qualifiant[1].c_str()) - 1] ;
  }


  if (mot_debut != "")
  {
    premCar = mot_debut[0] ;

    if (*pLibelle != "" )
      if ((premCar != ' ') && (dernCar != '-') && (dernCar != '\'') && (dernCar != ' '))
        *pLibelle += " " ;

    *pLibelle += mot_debut ;
  }

  // On supprime les blancs terminaux
  strip(*pLibelle, stripRight);

  size_t positionAccolades = pLibelle->find("{") ;
  size_t positionVideAccolades = pLibelle->find(" {") ;
  if      (positionVideAccolades != NPOS)
    *pLibelle = string(*pLibelle, 0, positionVideAccolades) ;
  else if (positionAccolades != NPOS)
    *pLibelle = string(*pLibelle, 0, positionAccolades) ;

  // On v�rifie qu'il n'existe pas plusieurs blancs contigus
  size_t positBlanc = pLibelle->find(" ") ;
  size_t debut, fin, taille ;
  while (positBlanc != NPOS)
  {
    debut  = positBlanc ;

    taille = strlen(pLibelle->c_str()) ;
    if ((debut < taille - 1) && ((*pLibelle)[debut + 1] == ' '))
    {
      fin = debut + 1 ;
      while ((fin < taille - 1) && ((*pLibelle)[fin + 1] == ' '))
        fin++ ;

      *pLibelle = string(*pLibelle, 0, debut) + " " + string(*pLibelle, fin + 1, taille - fin - 1) ;
    }
    else
      fin = debut ;

    debut++ ;
    positBlanc = pLibelle->find(" ", debut) ;
  }

  // On supprime les blancs terminaux
  strip(*pLibelle, stripRight) ;
}


// -----------------------------------------------------------------------------
// NSPathologData::traiteOrthographe(string* pMot, string* pOrthographe, int GenreMaitre)
//
// Description  : Donne le "beau" libell�
//                La variable GenreMaitre sert � donner un genre aux adjectifs
// -----------------------------------------------------------------------------
void
NSPathologData::traiteOrthographe(string* pMot, string* pOrthographe, int iDeclinaison)
{
  // simple pr�caution
  strip(*pMot, stripRight, ' ') ;

  // Si on demande la d�clinaison 0, il n'y a rien � faire
  if (iDeclinaison == 0)
    return ;

  int iLen = strlen(pOrthographe->c_str());

  // Cas simple, pas de d�clinaisons, on ne fait rien
  if (iLen == 0)
    return ;

  // distribution des d�clinaisons dans les diff�rentes cases d'un vecteur
  vector<string>            vOrthographe ;
  vector<string>::iterator  ivOrtho ;

  int iNbElmnt  = 0 ;
  string sOrtho = "" ;
  for (int i = 0 ; i < iLen ; i++)
  {
    if ((*pOrthographe)[i] == '/')
    {
      vOrthographe.push_back(string(sOrtho, 0, strlen(sOrtho.c_str()))) ;
      sOrtho = "" ;
      iNbElmnt++ ;
    }
    else
      sOrtho += (*pOrthographe)[i] ;
  }

  vOrthographe.push_back(string(sOrtho, 0, strlen(sOrtho.c_str()))) ;
  iNbElmnt++ ;

  // Cas o� il n'existe qu'une seule d�clinaison :
  //
  //      si iDeclinaison == 0, rien � faire
  //      si iDeclinaison == 1, on ajoute la d�clinaison au mot
  if (iNbElmnt == 1)
  {
    if (iDeclinaison == 1)
      *pMot = *pMot + *(vOrthographe.begin()) ;
    return ;
  }

  // Cas o� il existe plusieurs d�clinaisons :
  //      on d�termine la racine � partir de la d�clinaison 0
  //      puis on ajoute la d�clinaison demand�e

  // Recherche de la iDeclinaisoni�me d�clinaison

  int i;
  for (ivOrtho = vOrthographe.begin(), i = 0 ; (i < iDeclinaison) && (ivOrtho != vOrthographe.end()) ; i++, ivOrtho++)
    ;

  // On v�rifie quand m�me qu'elle existe
  if ((i < iDeclinaison) || (ivOrtho == vOrthographe.end()))
    return ;

  int iRaciLen = strlen(pMot->c_str()) - strlen(vOrthographe.begin()->c_str()) ;
  if (iRaciLen <= 0)
  {
    *pMot = *ivOrtho ;
    return ;
  }

  *pMot = string(*pMot, 0, iRaciLen) + *ivOrtho ;
}


// -----------------------------------------------------------------------------
//  Function:    NSPathologData::donneGenre(int *pGenre)
//
//  Description: Donne le "beau" libell�
// -----------------------------------------------------------------------------
void
NSPathologData::donneGenre(int *pGenre)
{
  if (!pGenre)
    return ;

  string sGenre = string(grammaire) ;

  strip(sGenre) ;

  if 	    (sGenre == "FS")
    *pGenre = genreFS ;
  else if (sGenre == "MS")
    *pGenre = genreMS ;
  else if (sGenre == "NS")
    *pGenre = genreNS ;
  else if (sGenre == "FP")
    *pGenre = genreFP ;
  else if (sGenre == "MP")
    *pGenre = genreMP ;
  else if (sGenre == "NP")
    *pGenre = genreNP ;
  else
    *pGenre = 0 ;
}


voidNSPathologData::donneGenrePluriel(int *pGenre)
{
  if 	  (*pGenre == genreFS)
    *pGenre = genreFP ;
  else if (*pGenre == genreMS)
    *pGenre = genreMP ;
  else if (*pGenre == genreNS)
    *pGenre = genreNP ;
}


void
NSPathologData::donneGenreSingulier(int *pGenre)
{
  if 	  (*pGenre == genreFP)
    *pGenre = genreFS ;
  else if (*pGenre == genreMP)
    *pGenre = genreMS ;
  else if (*pGenre == genreNP)
    *pGenre = genreNS ;
}


// -----------------------------------------------------------------------------
// Function : NSPathologData::chercheGrammaire(string sAChercher)
//
// Cherche dans le libelle le commentaire grammatical ( {|__} ) commencant par
// sAChercher, et le renvoie.
// -----------------------------------------------------------------------------
string
NSPathologData::chercheGrammaire(string sAChercher)
{
  string sLibelleBrut = string(libelle) ;

  size_t positionAccolades = sLibelleBrut.find("{|") ;
  if (positionAccolades == string::npos)
    return "" ;
  size_t finAccolades = sLibelleBrut.find("}", positionAccolades + 1) ;
  if ((finAccolades == string::npos) || (finAccolades-positionAccolades < 4))
    return "" ;

  // On recupere dans sGrammaire le contenu entre {| et }
  // On analysera par la suite sGrammaire
  string sGrammaire = string(sLibelleBrut, positionAccolades + 2, finAccolades-positionAccolades - 2) ;
  size_t pos = sGrammaire.find(sAChercher) ;
  size_t len = strlen(sAChercher.c_str()) ;

  if (string::npos == pos)
    return "" ;

  // On recherche la fin de la string cherchee
  // Puis on renvoie la string cherchee
  if (pos == strlen(sGrammaire.c_str()))
    return string(sGrammaire, pos, 1) ;

  size_t posfin = sGrammaire.find("/", pos + 1) ;
  if (posfin == string::npos)
    return string(sGrammaire, pos, strlen(sGrammaire.c_str()) - pos) ;

  return string(sGrammaire, pos, posfin - pos) ;
}

boolNSPathologData::estReel()
{
  return true ;
}

// -----------------------------------------------------------------------------// Constructeur// -----------------------------------------------------------------------------
NSPatholog::NSPatholog(NSContexte* pCtx, string sLang)
           :NSFiche(pCtx)
{
  sLangue = sLang ;
  if      (sLangue == "")
    sNomFichier = "LEXIQUE.DB" ;
  else if (sLangue == "fr")
    sNomFichier = "LEXIQUE.DB" ;
  else
    sNomFichier = string("LEXIQ_") + sLangue + string(".DB") ;

	// Cr�e un objet de donn�es
	pDonnees = new NSPathologData() ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSPatholog::NSPatholog(NSPatholog& rv)
           :NSFiche(rv.pContexte)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSPathologData() ;

	// Copie les valeurs du NSPathologInfo d'origine
	*pDonnees   = *(rv.pDonnees) ;
  sLangue     = rv.sLangue ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSPatholog::~NSPatholog()
{
	delete pDonnees ;
}


// -----------------------------------------------------------------------------
// Fonction     : NSPatholog::alimenteFiche()
// Description  : Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSPatholog::alimenteFiche()
{
  alimenteChamp(pDonnees->libelle,    PATHO_LIBELLE_FIELD,   PATHO_LIBELLE_LEN) ;
  alimenteChamp(pDonnees->code, 	    PATHO_CODE_FIELD, 	   PATHO_CODE_LEN) ;
	alimenteChamp(pDonnees->grammaire,  PATHO_GRAMMAIRE_FIELD, PATHO_GRAMMAIRE_LEN) ;
  alimenteChamp(pDonnees->freq, 	    PATHO_FREQ_FIELD, 	   PATHO_FREQ_LEN) ;

	pDonnees->fabriqueLibelleLong() ;
}


// -----------------------------------------------------------------------------
//  Fonction    : NSPatholog::videFiche()
// Description  : Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSPatholog::videFiche()
{
	videChamp(pDonnees->libelle,   PATHO_LIBELLE_FIELD,   PATHO_LIBELLE_LEN) ;
  videChamp(pDonnees->code, 	   PATHO_CODE_FIELD, 	    PATHO_CODE_LEN) ;
	videChamp(pDonnees->grammaire, PATHO_GRAMMAIRE_FIELD, PATHO_GRAMMAIRE_LEN) ;
	videChamp(pDonnees->freq, 	   PATHO_FREQ_FIELD, 	    PATHO_FREQ_LEN) ;
}


// -----------------------------------------------------------------------------
// Fonction     : NSPatholog::getRecord()
// Description  : Prend l'enregistrement en cours et assigne la valeur des
//             	  champs aux variables membres de la classe.
// Returns      : PXERR_, s'il y a lieu
// -----------------------------------------------------------------------------
DBIResult
NSPatholog::getPatRecord()
{
	// La table est-elle ouverte ?
  if (!isOpen)
    return(lastError = ERROR_TABLENOTOPEN) ;

	// Appel de la classe de base pour r�cup�rer l'enregistrement.
	lastError = getDbiRecord(dbiWRITELOCK) ;

	return (lastError) ;
}


// -----------------------------------------------------------------------------
// Renvoie la fiche NSPathologData correspondant � ce code
// -----------------------------------------------------------------------------
bool
NSPatholog::trouvePathologData(string* pCode, NSPathologData* pData, bool afficheErreur)
{
  lastError = chercheClef(pCode, "CODE_INDEX", keySEARCHEQ, dbiWRITELOCK) ;

  if (lastError != DBIERR_NONE)
	{
    if (afficheErreur)
    {
    	string sErreurMsg = string("Erreur � la recherche du code [") + *pCode + string("]") ;
			erreur(sErreurMsg.c_str(), standardError, lastError) ;
    }
		return false ;
	}

	lastError = getRecord() ;
	if (lastError != DBIERR_NONE)
	{
		erreur("Erreur � la lecture du lexique.", standardError, lastError) ;
		return false ;
	}

  *pData = *pDonnees ;
	return true ;
}


// -----------------------------------------------------------------------------// Description  : Trouve la premi�re fiche dont le code convient//             	  Transf�re la fiche dans pDonnees
//
// Returns      : PXERR_, s'il y a lieu
// -----------------------------------------------------------------------------
DBIResult
NSPatholog::trouveCode(string* pCode, DBISearchCond searchMode, DBILockType Blocage, bool bErrMessage)
{
  lastError = chercheClef(pCode, "CODE_INDEX", searchMode, Blocage) ;
  if (lastError != DBIERR_NONE)
	{
    char msg[255] ;
    string sCode ;

    if ((*pCode) == "")
      sCode = "vide" ;
    else
      sCode = *pCode ;

    if (bErrMessage)
    {
      sprintf(msg, "Erreur � la recherche du code : [%s]", sCode.c_str()) ;
		  erreur(msg, standardError, lastError) ;
    }
		return lastError ;
	}
	lastError = getRecord() ;
	if (lastError != DBIERR_NONE)
	{
    if (bErrMessage)
		  erreur("Erreur � la lecture du lexique.", standardError, lastError) ;
		return lastError ;
	}
  
	return (lastError) ;
}

// -----------------------------------------------------------------------------
// Description  : Trouve la premi�re fiche dont le libell� convient
//             	  Transf�re la fiche dans pDonnees
// Returns      : PXERR_, s'il y a lieu
// -----------------------------------------------------------------------------
DBIResult
NSPatholog::trouveLibelle(string* pLibelle, DBISearchCond searchMode, DBILockType Blocage)
{
  lastError = chercheClef((unsigned char *)pLibelle->c_str(), "", 0, searchMode, Blocage) ;
  if (lastError != DBIERR_NONE)
	{
		erreur("Erreur � la recherche de l'ammorce.", standardError, lastError) ;
		return lastError ;
	}

	lastError = getRecord() ;
	if (lastError != DBIERR_NONE)
	{
		erreur("Erreur � la lecture du lexique.", standardError, lastError) ;
		return lastError ;
	}

	return (lastError) ;
}


// -----------------------------------------------------------------------------
// Fonction     : NSPatient::open()
// Description  : Ouvre la table primaire et les index secondaires
// Returns      : PXERR_, s'il y a lieu
// -----------------------------------------------------------------------------
DBIResult
NSPatholog::open()
{
	//char tableName[] = "LEXIQUE.DB" ;

	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	lastError = NSFiche::open(/*tableName*/sNomFichier.c_str(), NSF_GUIDES) ;
	return (lastError) ;
}


// -----------------------------------------------------------------------------
// Function     : NSPatholog::Create()
// -----------------------------------------------------------------------------
bool
NSPatholog::Create()
{
	return true ;
}


// -----------------------------------------------------------------------------
// Function     : NSPatholog::Modify()
// -----------------------------------------------------------------------------
bool
NSPatholog::Modify()
{
	return true ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSPatholog&
NSPatholog::operator=(NSPatholog src)
{
	*pDonnees = *(src.pDonnees) ;
  sLangue   = src.sLangue ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSPatholog::operator==(const NSPatholog& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
// Fonction     : NSPathologInfo::NSPathologInfo()
// Description  : Constructeur par d�faut
// -----------------------------------------------------------------------------
NSPathologInfo::NSPathologInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSPathologData() ;
}


// -----------------------------------------------------------------------------
// Fonction     : NSPathologInfo::NSPathologInfo(NSPatholog *)
// Description  : Constructeur � partir d'un NSPatient
// -----------------------------------------------------------------------------
NSPathologInfo::NSPathologInfo(NSPatholog* pPatho)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSPathologData() ;

	// Copie les valeurs du NSDocument
	*pDonnees = *(pPatho->pDonnees) ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSPathologInfo::NSPathologInfo(NSPathologInfo& rv)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSPathologData() ;

	// Copie les valeurs du NSPathologInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}


// -----------------------------------------------------------------------------
// Destructeur
// -----------------------------------------------------------------------------
NSPathologInfo::~NSPathologInfo()
{
	delete pDonnees ;
}

// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSPathologInfo&
NSPathologInfo::operator=(NSPathologInfo src)
{
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSPathologInfo::operator==(const NSPathologInfo& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------
//
// Impl�mentation des m�thodes NSSavoir
//
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Function     : NSSavoirData::NSSavoirData()
// Description  : Constructeur.
// -----------------------------------------------------------------------------
NSSavoirData::NSSavoirData()
{
	// Met les champs de donn�es � z�ro
	memset(code, 		    0, SAVOIR_CODE_LEN + 1) ;
  memset(qualifie, 	  0, SAVOIR_QUALIFIE_LEN + 1) ;
  memset(lien, 		    0, SAVOIR_LIEN_LEN + 1) ;
  memset(qualifiant,  0, SAVOIR_QUALIFIANT_LEN + 1) ;
  memset(classe, 	    0, SAVOIR_CLASSE_LEN + 1) ;
  memset(degre, 	 	  0, SAVOIR_DEGRE_LEN + 1) ;
  memset(scenario, 	  0, SAVOIR_SCENARIO_LEN + 1) ;
}


// -----------------------------------------------------------------------------
// Fonction     : NSPathologData::NSSavoirData(NSSavoirData& rv)
// Description  : Constructeur copie
// Retour       : Rien
// -----------------------------------------------------------------------------
NSSavoirData::NSSavoirData(NSSavoirData& rv)
{
	strcpy(code, 		    rv.code) ;
  strcpy(qualifie, 	  rv.qualifie) ;
  strcpy(lien, 		    rv.lien) ;
  strcpy(qualifiant,  rv.qualifiant) ;
  strcpy(degre, 	 	  rv.degre) ;
  strcpy(classe, 	    rv.classe) ;
  strcpy(scenario, 	  rv.scenario) ;
}


// -----------------------------------------------------------------------------
// Fonction     :	NSSavoirData::~NSSavoirData()
// Description  : Destructeur
// -----------------------------------------------------------------------------
NSSavoirData::~NSSavoirData()
{
}


// -----------------------------------------------------------------------------
// Fonction     : NSSavoirData::operator=(NSSavoirData src)
// Description  : Op�rateur =
// Retour       : R�f�rence sur l'objet cible
// -----------------------------------------------------------------------------
NSSavoirData&
NSSavoirData::operator=(NSSavoirData rv)
{
	strcpy(code, 		    rv.code) ;
  strcpy(qualifie, 	  rv.qualifie) ;
  strcpy(lien, 		    rv.lien) ;
  strcpy(qualifiant,  rv.qualifiant) ;
  strcpy(degre, 	 	  rv.degre) ;
  strcpy(classe, 	    rv.classe) ;
  strcpy(scenario, 	  rv.scenario) ;

	return *this ;
}


// -----------------------------------------------------------------------------
// Fonction     :	NSSavoirData::operator=(NSSavoirData src)
// Description  : Op�rateur de comparaison
// Retour       : 0 ou 1
// -----------------------------------------------------------------------------
int
NSSavoirData::operator==(const NSSavoirData& o)
{
	if ((strcmp(code, o.code) == 0))
		return 1 ;
	else
		return 0 ;
}


// -----------------------------------------------------------------------------
// Function     : NSSavoirData::metABlanc()
// Description  : Met � blanc les variables de la fiche
// Returns      : Rien
// -----------------------------------------------------------------------------
void
NSSavoirData::metABlanc()
{
	// Met les champs de donn�es � blanc
	memset(code, 		    ' ', SAVOIR_CODE_LEN) ;
  memset(qualifie, 	  ' ', SAVOIR_QUALIFIE_LEN) ;
  memset(lien, 		    ' ', SAVOIR_LIEN_LEN) ;
  memset(qualifiant,  ' ', SAVOIR_QUALIFIANT_LEN) ;
  memset(degre, 	 	  ' ', SAVOIR_DEGRE_LEN) ;
  memset(classe, 	    ' ', SAVOIR_CLASSE_LEN) ;
  memset(scenario, 	  ' ', SAVOIR_SCENARIO_LEN) ;
}


// -----------------------------------------------------------------------------
// Function     : NSSavoir::NSSavoir(NSSuper* pSuper)
// Description  : Constructeur.
// -----------------------------------------------------------------------------
NSSavoir::NSSavoir(NSContexte* pCtx)
  : NSFiche(pCtx)
{
	// Cr�e un objet de donn�es
	pDonnees = new NSSavoirData() ;
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSSavoir::NSSavoir(NSSavoir& rv)
  : NSFiche(rv.pContexte)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSSavoirData() ;

	// Copie les valeurs du NSSavoirInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}


// -----------------------------------------------------------------------------
// Function     : NSSavoir::~NSSavoir()
// Description  : Destructeur.
// -----------------------------------------------------------------------------
NSSavoir::~NSSavoir()
{
	delete pDonnees ;
}


// -----------------------------------------------------------------------------
// Fonction     : NSSavoir::alimenteFiche()
// Description  : Transf�re le contenu de pRecBuff dans les variables de la fiche
// -----------------------------------------------------------------------------
void
NSSavoir::alimenteFiche()
{
	alimenteChamp(pDonnees->code, 		  SAVOIR_CODE_FIELD, 	  	 SAVOIR_CODE_LEN) ;
  alimenteChamp(pDonnees->qualifie, 	SAVOIR_QUALIFIE_FIELD, 	 SAVOIR_QUALIFIE_LEN) ;
  alimenteChamp(pDonnees->lien, 		  SAVOIR_LIEN_FIELD, 	  	 SAVOIR_LIEN_LEN) ;
  alimenteChamp(pDonnees->qualifiant, SAVOIR_QUALIFIANT_FIELD, SAVOIR_QUALIFIANT_LEN) ;
  alimenteChamp(pDonnees->degre, 	  	SAVOIR_DEGRE_FIELD,   	 SAVOIR_DEGRE_LEN) ;
  alimenteChamp(pDonnees->classe, 	  SAVOIR_CLASSE_FIELD,   	 SAVOIR_CLASSE_LEN) ;
  alimenteChamp(pDonnees->scenario, 	SAVOIR_SCENARIO_FIELD,   SAVOIR_SCENARIO_LEN) ;
}


// -----------------------------------------------------------------------------
// Fonction     : NSSavoir::videFiche()
// Description  : Transf�re le contenu des valeurs de la fiche dans pRecBuff
// -----------------------------------------------------------------------------
void
NSSavoir::videFiche()
{
	videChamp(pDonnees->code, 		  SAVOIR_CODE_FIELD, 	  	  SAVOIR_CODE_LEN) ;
  videChamp(pDonnees->qualifie,   SAVOIR_QUALIFIE_FIELD, 	  SAVOIR_QUALIFIE_LEN) ;
  videChamp(pDonnees->lien, 		  SAVOIR_LIEN_FIELD, 	  	  SAVOIR_LIEN_LEN) ;
  videChamp(pDonnees->qualifiant, SAVOIR_QUALIFIANT_FIELD,  SAVOIR_QUALIFIANT_LEN) ;
  videChamp(pDonnees->degre, 	    SAVOIR_DEGRE_FIELD,   	  SAVOIR_DEGRE_LEN) ;
  videChamp(pDonnees->classe, 	  SAVOIR_CLASSE_FIELD,   	  SAVOIR_CLASSE_LEN) ;
  videChamp(pDonnees->scenario,   SAVOIR_SCENARIO_FIELD,    SAVOIR_SCENARIO_LEN) ;
}


// -----------------------------------------------------------------------------
// Fonction     : NSSavoir::getRecord()
// Description  : Prend l'enregistrement en cours et assigne la valeur des
//             	  champs aux variables membres de la classe.
// Returns      : PXERR_, s'il y a lieu
// -----------------------------------------------------------------------------
DBIResult
NSSavoir::getPatRecord()
{
	// La table est-elle ouverte ?
	if (!isOpen)
	  return (lastError = ERROR_TABLENOTOPEN) ;

	// Appel de la classe de base pour r�cup�rer l'enregistrement.
	lastError = getDbiRecord(dbiWRITELOCK) ;

	return (lastError) ;
}


// -----------------------------------------------------------------------------
// Description  : Ouvre la table primaire et les index secondaires
// Returns      : PXERR_, s'il y a lieu
// -----------------------------------------------------------------------------
DBIResult
NSSavoir::open()
{
	char tableName[] = "SAVOIR.DB" ;

	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	lastError = NSFiche::open(tableName, NSF_GUIDES) ;
	return (lastError) ;
}

// -----------------------------------------------------------------------------// Function     : NSSavoir::Create()// -----------------------------------------------------------------------------
bool
NSSavoir::Create()
{
	return true ;
}


// -----------------------------------------------------------------------------
// Function     : NSSavoir::Modify()
// -----------------------------------------------------------------------------
bool
NSSavoir::Modify()
{
	return true ;
}


// -----------------------------------------------------------------------------// Op�rateur d'affectation// -----------------------------------------------------------------------------
NSSavoir&
NSSavoir::operator=(NSSavoir src)
{
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------// Op�rateur de comparaison// -----------------------------------------------------------------------------
int
NSSavoir::operator==(const NSSavoir& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------// Constructeur par d�faut// -----------------------------------------------------------------------------
NSSavoirInfo::NSSavoirInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSSavoirData() ;
}


// -----------------------------------------------------------------------------// Constructeur � partir d'un NSPatient// -----------------------------------------------------------------------------
NSSavoirInfo::NSSavoirInfo(NSSavoir* pPatho)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSSavoirData() ;

	// Copie les valeurs du NSDocument
	*pDonnees = *(pPatho->pDonnees) ;
}


// -----------------------------------------------------------------------------// Constructeur copie// -----------------------------------------------------------------------------
NSSavoirInfo::NSSavoirInfo(NSSavoirInfo& rv)
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSSavoirData() ;

	// Copie les valeurs du NSSavoirInfo d'origine
	*pDonnees = *(rv.pDonnees) ;
}


// -----------------------------------------------------------------------------
// Destructeur.
// -----------------------------------------------------------------------------
NSSavoirInfo::~NSSavoirInfo()
{
  delete pDonnees ;
}


// -----------------------------------------------------------------------------
// Op�rateur d'affectation
// -----------------------------------------------------------------------------
NSSavoirInfo&
NSSavoirInfo::operator=(NSSavoirInfo src)
{
	*pDonnees = *(src.pDonnees) ;
	return *this ;
}


// -----------------------------------------------------------------------------
// Op�rateur de comparaison
// -----------------------------------------------------------------------------
int
NSSavoirInfo::operator==(const NSSavoirInfo& o)
{
  return (*pDonnees == *(o.pDonnees)) ;
}


// -----------------------------------------------------------------------------//// BASE DES MEDICAMENTS//// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Constructeur
// -----------------------------------------------------------------------------
NSLexiMed::NSLexiMed(NSContexte* pCtx, string sLangue)
  : NSPatholog(pCtx, sLangue)
{
}


// -----------------------------------------------------------------------------
// Constructeur copie
// -----------------------------------------------------------------------------
NSLexiMed::NSLexiMed(NSLexiMed& rv)
  : NSPatholog(rv.pContexte, rv.sLangue)
{
}


// -----------------------------------------------------------------------------// Destructeur// -----------------------------------------------------------------------------
NSLexiMed::~NSLexiMed()
{
}


DBIResultNSLexiMed::open()
{
	char tableName[] = "LEXI_MED.DB" ;

	// Appelle la fonction open() de la classe de base pour ouvrir l'index primaire
	lastError = NSFiche::open(tableName, NSF_GUIDES) ;

	return (lastError) ;
}

