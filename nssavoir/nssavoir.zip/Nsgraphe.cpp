// -----------------------------------------------------------------------------
// nsgraphe.cpp
// -----------------------------------------------------------------------------
// $Revision: 1.79 $
// $Author: consuela $
// $Date: 2005/03/02 13:44:17 $
// -----------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------
// FLP - aout 2003 - ajout des liens pour les pr�occupations
// ...
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
//
//  		Impl�mentation des m�thodes du graphe entre noeuds d'arbres
//
// -----------------------------------------------------------------------------

#include <stdio.h>
#include <classlib\filename.h>
#include <sysutils.hpp>

#include "partage\nsdivfct.h"
#include "nssavoir\nsgraphe.h"
#include "partage\nsglobal.h"
#include "nautilus\nssuper.h"
#include "nsbb\nsbbtran.h"
#include "nsbb\nstlibre.h"
#include "nsbb\ns_objs.h"

#include "pilot\Pilot.hpp"
#include "pilot\NautilusPilot.hpp"
#include "pilot\JavaSystem.hpp"#include "nsbb\tagNames.h"
// -----------------------------------------------------------------------------
// Impl�mentation des m�thodes NSRootLink
// -----------------------------------------------------------------------------
NSRootLink::NSRootLink()
{
}


NSRootLink::~NSRootLink()
{
}

/*

// -----------------------------------------------------------------------------
// Retourne le code qui correspond � une relation
// Return the code that represents that link
// -----------------------------------------------------------------------------
string
NSRootLink::donneString(NODELINKTYPES iRelation)
{
	switch (iRelation)
	{
		case problemRelatedTo       : return "PB" ;
		case problemContactElement  : return "PE" ;
		case soapRelatedTo          : return "SO" ;
		case problemGoals	        	: return "PG" ;
    case goalOpener             : return "GO" ;
    case goalReseter            : return "GR" ;
    case goalAlarm              : return "GA" ;
    case goalCloser             : return "GC" ;
		case archetype	            : return "AR" ;
    case refCreator	            : return "RC" ;
    case referentialOf          : return "RR" ;
		case drugOf	                : return "DG" ;
    case treatmentOf	        	: return "TT" ;
    case personHealthIndex      : return "HH" ;
    case personSynthesis        : return "HS" ;
    case personAdminData        : return "HA" ;
    case personDocument         : return "HD" ;
    case personFolderLibrary    : return "HF" ;
    case personHealthProData    : return "HP" ;
    case personHealthTeam				: return "HT" ;
    case docData                : return "ZA" ;
    case docFolder              : return "ZF" ;
    case docPilot              	: return "ZP" ;
    case personContribution     : return "HC" ;
    case contribElement         : return "ZC" ;
    case docComposition         : return "ZO" ;
    case compositionTag         : return "ZT" ;
    case processWaitingFor      : return "QW" ;
    case processResultFrom      : return "QR" ;
    case objectIn               : return "OI" ;
    case hiddenBy               : return "MH" ;
    case contributionAdded      : return "CA" ;
    case contributionModified   : return "CM" ;
    case contributionOpened			: return "CO" ;
    case copyOf									: return "YO" ;
		case fonctionalUnitStay     : return "JR" ;
		case stayContribution       : return "JC" ;
		case personIdentifiers      : return "HI" ;
  }

  return "" ;
}


// -----------------------------------------------------------------------------
// Retourne la relation qui correspond � un code
// Return the link represented by that code
// -----------------------------------------------------------------------------
NSRootLink::NODELINKTYPES
NSRootLink::donneRelation(string sRelation)
{
	if (strlen(sRelation.c_str()) < 2)
  	return badLink ;

	switch (sRelation[0])
  {
  	// ARCHETYPE related
    case 'A' :  switch (sRelation[1])
    						{
                	case 'R'	: return archetype ;
                }
                break ;

    // CONTRIBUTION related
    case 'C' :	switch (sRelation[1])
    						{
                	case 'A'	: return contributionAdded ;
                  case 'M'	: return contributionModified ;
                  case 'O'	: return contributionOpened ;
                }
                break ;

    // DRUG related
    case 'D' :  switch (sRelation[1])
    						{
    							case 'G'	: return drugOf ;
    						}
    						break ;

    // GOAL related
    case 'G' :  switch (sRelation[1])
    						{
                  case 'A'	: return goalAlarm ;
                  case 'C'	: return goalCloser ;
                	case 'O'	: return goalOpener ;
                  case 'R'	: return goalReseter ;
                }
                break ;

    // HUMAN/PERSON related
    case 'H' :  switch (sRelation[1])
    						{
                  case 'A'	: return personAdminData ;
                	case 'D'	: return personDocument ;
                  case 'C'	: return personContribution ;
                  case 'F'	: return personFolderLibrary ;
                  case 'H'	: return personHealthIndex ;
                  case 'I'  : return personIdentifiers ;
                  case 'P'	: return personHealthProData ;
                  case 'S'	: return personSynthesis ;
                  case 'T'	: return personHealthTeam ;
                }
                break ;

    // "s�jour" related
    case 'J' :  switch (sRelation[1])
    						{
                	case 'C'  : return stayContribution ;
                  case 'R'  : return fonctionalUnitStay ;
                }
                break ;

    // internal MANAGEMENT related
    case 'M' :  switch (sRelation[1])
    						{
                	case 'H'	: return hiddenBy ;
                }
                break ;

    // Object related
    case 'O' :	switch (sRelation[1])
    						{
                	case 'I'	: return objectIn ;
                }
                break ;

    // POMR related
    case 'P' :  switch (sRelation[1])
    						{
                	case 'B'	: return problemRelatedTo ;
                  case 'E'	: return problemContactElement ;
                  case 'G'	: return problemGoals ;
                }
                break ;

    // Prescription related (P is already used, so we use Q here
    case 'Q'  : switch (sRelation[1])
    						{
                  case 'R'	: return processResultFrom ;
                	case 'W'	: return processWaitingFor ;
                }
                break ;

    // REFERENCE related
    case 'R' :  switch (sRelation[1])
    						{
                	case 'C'	: return refCreator ;
                  case 'R'	: return referentialOf ;
                }
                break ;

    // SOAP related
    case 'S' :  switch (sRelation[1])
    						{
                	case 'O'	: return soapRelatedTo ;
                }
                break ;

    // TREATMENT related
    case 'T' :  switch (sRelation[1])
    						{
                	case 'T'	: return treatmentOf ;
                }
                break ;

    // miscellanous
    case 'Y' :  switch (sRelation[1])
    						{
                	case 'O'	: return copyOf ;
                }
                break ;

    // DOCUMENT related
    case 'Z' :  switch (sRelation[1])
    						{
                	case 'A'	: return docData ;
                  case 'C'	: return contribElement ;
                  case 'F'	: return docFolder ;
                  case 'O'	: return docComposition ;
                  case 'P'	: return docPilot ;
                  case 'T'	: return compositionTag ;
                }
                break ;
	}

	return badLink ;
}

*/

// -----------------------------------------------------------------------------
// Retourne le code qui correspond � une relation
// Return the code that represents that link
// -----------------------------------------------------------------------------
string
NSRootLink::donneString(NODELINKTYPES iRelation)
{
	switch (iRelation)
	{
  	case problemRelatedTo				: return "0PRO1" ;
		case problemContactElement	: return "0PREL" ;
		case soapRelatedTo					: return "0PRCL" ;
		case problemGoals						: return "0OBJE" ;
		case goalOpener							: return "0OJOP" ;
		case goalReseter						: return "0OJRE" ;
		case goalAlarm							: return "0OJAL" ;
		case goalCloser							: return "0OJCL" ;
		case archetype							: return "0ARCH" ;
		case refCreator							: return "0DOCR" ;
		case referentialOf					: return "0RECR" ;
		case drugOf									: return "N0000" ;
		case treatmentOf						: return "GTRAI" ;
    case prescriptionElement    : return "0SOA3" ;
		case personHealthIndex			: return "ZPOMR" ;
		case personSynthesis				: return "ZSYNT" ;
		case personAdminData				: return "ZADMI" ;
		case personDocument					: return "ZDOCU" ;
		case personFolderLibrary		: return "0LIBC" ;
		case personHealthProData		: return "DPROS" ;
    case personRiskManager      : return "ORISK" ;
		case personHealthTeam				: return "LEQUI" ;
		case docData								: return "ZDATA" ;
		case docFolder              : return "0CHEM" ;
		case docPilot               : return "OSERV" ;
		case personContribution     : return "LCTRI" ;
		case contribElement         : return "" ; // non utilis�
		case docComposition         : return "ZPRES" ;
		case compositionTag         : return "0TAGC" ;
		case processWaitingFor      : return "0PRWA" ;
		case processResultFrom      : return "0PRRE" ;
		case objectIn               : return "OCOMP" ;
		case hiddenBy               : return "" ; // non utilis�
		case contributionAdded      : return "0CTCR" ;
		case contributionModified   : return "0CTMO" ;
		case contributionOpened     : return "0CTCO" ;
		case copyOf                 : return "0COPY" ;
		case fonctionalUnitStay     : return "LSEJO" ;
		case stayContribution       : return "0CTSE" ;
		case personIdentifiers      : return "0LIBI" ;
    case OCRizedDocument        : return "ZDOCR" ;
    case semantizedDocument     : return "ZDSEM" ;
    case viewOfDocument         : return "ZDODE" ;
    case letterOfDocument       : return "ZLETT" ;
  }

  return "" ;
}


// -----------------------------------------------------------------------------
// Retourne la relation qui correspond � un code
// Return the link represented by that code
// -----------------------------------------------------------------------------
NSRootLink::NODELINKTYPES
NSRootLink::donneRelation(string sRelation)
{
	if (strlen(sRelation.c_str()) != 5)
  	return badLink ;

	if (sRelation == string("0PRO1")) return problemRelatedTo ;
	if (sRelation == string("0PREL"))	return problemContactElement ;
	if (sRelation == string("0PRCL"))	return soapRelatedTo ;
	if (sRelation == string("0OBJE"))	return problemGoals ;
	if (sRelation == string("0OJOP"))	return goalOpener	;
	if (sRelation == string("0OJRE"))	return goalReseter ;
	if (sRelation == string("0OJAL"))	return goalAlarm ;
	if (sRelation == string("0OJCL"))	return goalCloser	;
	if (sRelation == string("0ARCH"))	return archetype ;
	if (sRelation == string("0DOCR"))	return refCreator	;
	if (sRelation == string("0RECR"))	return referentialOf ;
	if (sRelation == string("N0000"))	return drugOf	;
	if (sRelation == string("GTRAI"))	return treatmentOf ;
  if (sRelation == string("0SOA3"))	return prescriptionElement ;
	if (sRelation == string("ZPOMR"))	return personHealthIndex ;
	if (sRelation == string("ZSYNT"))	return personSynthesis ;
	if (sRelation == string("ZADMI"))	return personAdminData ;
	if (sRelation == string("ZDOCU"))	return personDocument	;
	if (sRelation == string("0LIBC"))	return personFolderLibrary ;
	if (sRelation == string("DPROS"))	return personHealthProData ;
  if (sRelation == string("ORISK"))	return personRiskManager ;
	if (sRelation == string("LEQUI"))	return personHealthTeam	;
	if (sRelation == string("ZDATA"))	return docData ;
	if (sRelation == string("0CHEM"))	return docFolder ;
	if (sRelation == string("OSERV"))	return docPilot ;
	if (sRelation == string("LCTRI"))	return personContribution ;
	if (sRelation == string("ZPRES"))	return docComposition ;
	if (sRelation == string("0TAGC"))	return compositionTag ;
	if (sRelation == string("0PRWA"))	return processWaitingFor ;
	if (sRelation == string("0PRRE"))	return processResultFrom ;
	if (sRelation == string("OCOMP"))	return objectIn ;
	if (sRelation == string("0CTCR"))	return contributionAdded ;
	if (sRelation == string("0CTMO"))	return contributionModified ;
	if (sRelation == string("0CTCO"))	return contributionOpened ;
	if (sRelation == string("0COPY"))	return copyOf ;
	if (sRelation == string("LSEJO"))	return fonctionalUnitStay ;
	if (sRelation == string("0CTSE"))	return stayContribution ;
	if (sRelation == string("0LIBI"))	return personIdentifiers ;
  if (sRelation == string("ZDOCR"))	return OCRizedDocument ;
  if (sRelation == string("ZDSEM"))	return semantizedDocument ;
  if (sRelation == string("ZDODE"))	return viewOfDocument ;
  if (sRelation == string("ZLETT"))	return letterOfDocument ;

	return badLink ;
}

///////////////////////////////////////////////////////////////
//
// Classe NSLinkManager
//
///////////////////////////////////////////////////////////////

// Constructeur et destructeur
NSLinkManager::NSLinkManager(NSContexte *pCtx, NSDataGraph* pDataGraph)
              :NSRootLink(), NSRoot(pCtx)
{
    pGraph = pDataGraph;
    setTypeGraphe(pGraph->getGraphType());
}

NSLinkManager::~NSLinkManager()
{
}

NSLinkManager::NSLinkManager(NSLinkManager& rv)
	:  NSRootLink(), NSRoot(rv.pContexte)
{
    pGraph = rv.pGraph;
    setTypeGraphe(pGraph->getGraphType());
}

NSLinkManager&
NSLinkManager::operator=(NSLinkManager src)
{
	if (&src == this)
  	return *this ;

	pGraph = src.pGraph ;
  setTypeGraphe(pGraph->getGraphType()) ;

	return *this ;
}

// savoir si sCode1 et sCode2 sont li�s par sRelation
// note : le lien inverse est donn� par sensCle = "ENVERS"
bool
NSLinkManager::VraiOuFaux(string sNoeud1, NODELINKTYPES iRelation, string sNoeud2, DBITBLNAME sensCle)
{
	if ((sNoeud1 == "") || (sNoeud2 == ""))
		return false ;

	bool bOk = false ;

	VecteurString VecteurString ;
	TousLesVrais(sNoeud1, iRelation, &VecteurString, sensCle) ;

	// sNoeud2 fait il partie de pVecteurString ?
	// does sNoeud2 belong to pVecteurString ?

	if ((!(VecteurString.empty())) &&
			(VecteurString.ItemDansUnVecteur(sNoeud2)))
		bOk = true ;

	return bOk ;
}

// mettre tous les items li�s � sCode1 par sRelation dans pVecteurString ou pLinkArray
// note : le lien inverse est donn� par sensCle = "ENVERS"
void
NSLinkManager::TousLesVrais(string sNoeud, NODELINKTYPES iRelation, VecteurString *pVecteurString, DBITBLNAME sensCle)
{
	if ((sNoeud == "") || (!pVecteurString))
		return ;

  if (true == pGraph->aLinks.empty())
    return ;

	// Recherche du code qui correspond � ce lien
	string sLien = donneString(iRelation) ;
	if (sLien == "")
		return ;

	for (NSPatLinkIter i = pGraph->aLinks.begin(); i != pGraph->aLinks.end(); i++)
	{
  	if (((*i)->getLien() == sLien) &&
        (((strcmp(sensCle, "FLECHE") == 0) && ((*i)->getQualifie() == sNoeud)) ||
         ((strcmp(sensCle, "ENVERS") == 0) && ((*i)->getQualifiant() == sNoeud)))
       )
    {
    	// V�rifier que l'�l�ment n'appartient pas au vecteur
      // Checking if we have not already found that node
      if ((strcmp(sensCle, "FLECHE") == 0) &&
          (pVecteurString->ItemDansUnVecteur((*i)->getQualifiant()) == false))
      	pVecteurString->push_back(new string((*i)->getQualifiant())) ;

      if ((strcmp(sensCle, "ENVERS") == 0) &&
          (pVecteurString->ItemDansUnVecteur((*i)->getQualifie()) == false))
      	pVecteurString->push_back(new string((*i)->getQualifie())) ;
    }
  }
}

void
NSLinkManager::TousLesVraisDocument(string sDocRoot, NODELINKTYPES iRelation, VecteurString *pVecteurString, DBITBLNAME sensCle)
{
	if ((sDocRoot == "") || (!pVecteurString))
		return ;

	TousLesVrais(sDocRoot, iRelation, pVecteurString, sensCle) ;

  string sMeta = giveMetaDataRoot(sDocRoot) ;

  TousLesVrais(sMeta, iRelation, pVecteurString, sensCle) ;
}

void
NSLinkManager::TousLesVrais(string sNoeud, NODELINKTYPES iRelation, NSPatLinkArray *pLinkArray, DBITBLNAME sensCle)
{
	if ((NULL == pLinkArray) || (sNoeud == ""))
		return ;

  if (true == pGraph->aLinks.empty())
    return ;

	// Recherche du code qui correspond � ce lien
	string sLien = donneString(iRelation) ;
	if (sLien == "")
		return ;

  VecteurString VecteurString ;

  for (NSPatLinkIter i = pGraph->aLinks.begin(); i != pGraph->aLinks.end(); i++)
  {
  	if (((*i)->getLien() == sLien) &&
        (((strcmp(sensCle, "FLECHE") == 0) && ((*i)->getQualifie() == sNoeud)) ||
         ((strcmp(sensCle, "ENVERS") == 0) && ((*i)->getQualifiant() == sNoeud))))
    {
    	// V�rifier que l'�l�ment n'appartient pas au vecteur
			// Checking if we have not already found that node
			if ((strcmp(sensCle, "FLECHE") == 0) &&
					(VecteurString.ItemDansUnVecteur((*i)->getQualifiant()) == false))
      {
				VecteurString.push_back(new string((*i)->getQualifiant())) ;
        pLinkArray->push_back(new NSPatLinkInfo(*(*i))) ;
      }

			if ((strcmp(sensCle, "ENVERS") == 0) &&
					(VecteurString.ItemDansUnVecteur((*i)->getQualifie()) == false))
      {
      	VecteurString.push_back(new string((*i)->getQualifie())) ;
        pLinkArray->push_back(new NSPatLinkInfo(*(*i))) ;
      }
    }
  }
}

// mettre tous les items li�s par iRelation dans pNoeudParam et leurs noeuds li�s dans pNoeudResult
void
NSLinkManager::TousLesVrais(string sTreeID, NODELINKTYPES iRelation, VecteurString *pNoeudParam, VecteurString *pNoeudResult, DBITBLNAME sensCle)
{
	if ((sTreeID == "") || (NULL == pNoeudParam) || (NULL == pNoeudResult))
		return ;

  if (true == pGraph->aLinks.empty())
    return ;

  if (strlen(sTreeID.c_str()) != OBJECT_ID_LEN)
  {
  	erreur("Erreur de format du treeID dans NSLinkManager::TousLesVrais(...)", standardError, 0) ;
    return ;
  }

	// Recherche du code qui correspond � ce lien
	string sLien = donneString(iRelation) ;
	if (sLien == "")
		return ;

  size_t lenTree = OBJECT_ID_LEN ;

  for (NSPatLinkIter i = pGraph->aLinks.begin(); i != pGraph->aLinks.end(); i++)
  {
  	if (((*i)->getLien() == sLien) &&
        (((strcmp(sensCle, "FLECHE") == 0) && (string((*i)->getQualifie(), 0, lenTree) == sTreeID)) ||
         ((strcmp(sensCle, "ENVERS") == 0) && (string((*i)->getQualifiant(), 0, lenTree) == sTreeID))))
    {
    	if (strcmp(sensCle, "FLECHE") == 0)
      {
				pNoeudResult->push_back(new string((*i)->getQualifiant())) ;
        pNoeudParam->push_back(new string((*i)->getQualifie())) ;
      }

			if (strcmp(sensCle, "ENVERS") == 0)
    	{
				pNoeudResult->push_back(new string((*i)->getQualifie())) ;
        pNoeudParam->push_back(new string((*i)->getQualifiant())) ;
      }
    }
  }
}

void
NSLinkManager::TousLesVrais(string sPatientID, NSPatLinkArray *pLinkArray, DBITBLNAME sensCle)
{
	if ((sPatientID == "") || (NULL == pLinkArray))
		return ;

  if (true == pGraph->aLinks.empty())
    return ;

	if (strlen(sPatientID.c_str()) != PAT_NSS_LEN)
  {
  	erreur("Erreur de format du PatientID dans NSLinkManager::TousLesVrais(...)", standardError, 0) ;
    return ;
  }

	// string sLien = string("  ");

  VecteurString VecteurString ;

  size_t lenNss = PAT_NSS_LEN ;

  for (NSPatLinkIter i = pGraph->aLinks.begin(); i != pGraph->aLinks.end(); i++)
  {
  	if (((strcmp(sensCle, "FLECHE") == 0) && (string((*i)->getQualifie(), 0, lenNss) == sPatientID)) ||
        ((strcmp(sensCle, "ENVERS") == 0) && (string((*i)->getQualifiant(), 0, lenNss) == sPatientID)))
    {
    	// V�rifier que l'�l�ment n'appartient pas au vecteur
			// Checking if we have not already found that node
			if ((strcmp(sensCle, "FLECHE") == 0) &&
          (VecteurString.ItemDansUnVecteur((*i)->getQualifiant()) == false))
      {
				VecteurString.push_back(new string((*i)->getQualifiant())) ;
        pLinkArray->push_back(new NSPatLinkInfo(*(*i))) ;
      }

			if ((strcmp(sensCle, "ENVERS") == 0) &&
          (VecteurString.ItemDansUnVecteur((*i)->getQualifie()) == false))
      {
      	VecteurString.push_back(new string((*i)->getQualifie())) ;
        pLinkArray->push_back(new NSPatLinkInfo(*(*i))) ;
      }
    }
  }
}

bool
NSLinkManager::etablirLien(string sQualifie, NODELINKTYPES iRelation, string sQualifiant)
{
	// Recherche du code qui correspond � ce lien
  //
	string sLien = donneString(iRelation) ;
	if (string("") == sLien)
		return false ;

  return etablirLien(sQualifie, sLien, sQualifiant) ;
}

bool
NSLinkManager::etablirLien(string sQualifie, string sLink, string sQualifiant)
{
try
{
	if ((string("") == sQualifie) || (string("") == sLink) || (string("") == sQualifiant))
		return false ;

	if ((strlen(sQualifie.c_str())   > PATLINK_QUALIFIE_LEN) ||
			(strlen(sQualifiant.c_str()) > PATLINK_QUALIFIANT_LEN) ||
      (strlen(sLink.c_str())      != BASE_SENS_LEN))
		return false ;

  NSPatLinkInfo* pLinkInfo = new NSPatLinkInfo() ;

  pLinkInfo->setQualifie(sQualifie) ;
  pLinkInfo->setLien(sLink) ;
	pLinkInfo->setQualifiant(sQualifiant) ;

  // on signale le lien pour sauvegarder le document attach� � la fermeture du patient
  //
  pLinkInfo->setDirty(true) ;

    /********* La transaction n'est g�r�e que pour les enregistrements en base
    if ((strncmp(pLinkInfo->pDonnees->qualifie, "_------", PAT_NSS_LEN) == 0) &&
        (strncmp(pLinkInfo->pDonnees->qualifiant, "_------", PAT_NSS_LEN) == 0))
        strcpy(pLinkInfo->pDonnees->tranNew, (pContexte->getTransactionSysteme()).c_str());
    else
        strcpy(pLinkInfo->pDonnees->tranNew, (pContexte->getTransaction()).c_str());
    *********************************************************************************/

  pGraph->aLinks.push_back(pLinkInfo) ;

	return true ;
}
catch (...)
{
	erreur("Exception NSLinkManager::etablirLien.", standardError, 0) ;
  return false ;
}
}

// This function establishes a link to the meta-data tree instead of the data tree
//
bool
NSLinkManager::etablirLienDocument(string sQualifie, NODELINKTYPES iRelation, string sQualifiant)
{
	if ((sQualifie == "") || (sQualifiant == ""))
		return false ;

	string sNewQualifie   = sQualifie ;
  string sNewQualifiant = sQualifiant ;

	if (strlen(sQualifie.c_str()) < PATLINK_QUALIFIE_LEN)
  {
  	string sMetaQualifie = giveMetaDataRoot(sQualifie) ;
    if (sMetaQualifie != string(""))
    	sNewQualifie = sMetaQualifie ;
  }

  if (strlen(sQualifiant.c_str()) < PATLINK_QUALIFIE_LEN)
  {
  	string sMetaQualifiant = giveMetaDataRoot(sQualifiant) ;
    if (sMetaQualifiant != string(""))
    	sNewQualifiant = sMetaQualifiant ;
  }

	return etablirLien(sNewQualifie, iRelation, sNewQualifiant) ;
}

bool
NSLinkManager::detruireTousLesLiens(string sQualifie, NODELINKTYPES iRelation)
{
  if (true == pGraph->aLinks.empty())
    return true ;

	if (sQualifie == "")
		return false ;

	if (strlen(sQualifie.c_str()) > PATLINK_QUALIFIE_LEN)
		return false ;

	// Recherche du code qui correspond � ce lien
	string sLien = donneString(iRelation) ;
	if (sLien == "")
		return false ;

  // on d�truit tous les liens qualifie + relation (sens "FLECHE" et "ENVERS")
  for (NSPatLinkIter i = pGraph->aLinks.begin(); i != pGraph->aLinks.end(); )
  {
  	if (((*i)->getLien() == sLien) &&
        (((*i)->getQualifie() == sQualifie) || ((*i)->getQualifiant() == sQualifie)))
    {
    	delete (*i) ;
      pGraph->aLinks.erase(i) ;
    }
    else
    	i++ ;
  }

  return true ;
}

bool
NSLinkManager::detruireTousLesLiensDocument(string sDocRoot, NODELINKTYPES iRelation)
{
	if (sDocRoot == "")
		return false ;

	if (!detruireTousLesLiens(sDocRoot, iRelation))
		return false ;

	string sMetaRoot = giveMetaDataRoot(sDocRoot) ;
  if (sMetaRoot == string(""))
  	return true ;

  return detruireTousLesLiens(sMetaRoot, iRelation) ;
}


bool
NSLinkManager::detruireTousLesLiens(string sNoeud)
{
	if (sNoeud == "")
		return false ;

  if (true == pGraph->aLinks.empty())
    return true ;

	// on d�truit tous les liens o� sNoeud est qualifie ou qualifiant
	for (NSPatLinkIter i = pGraph->aLinks.begin(); i != pGraph->aLinks.end(); )
	{
		if (strlen(sNoeud.c_str()) == PATLINK_QUALIFIE_LEN)
		{
			if (((*i)->getQualifie() == sNoeud) ||
                ((*i)->getQualifiant() == sNoeud))
			{
				delete (*i) ;
				pGraph->aLinks.erase(i) ;
			}
			else
				i++ ;
		}
		else if (strlen(sNoeud.c_str()) == OBJECT_ID_LEN)
		{
			if (((*i)->getQualifie() == sNoeud) ||
                ((*i)->getQualifiant() == sNoeud))
			{
				delete (*i);
				pGraph->aLinks.erase(i);
			}
			else
				i++ ;
		}
		else
			i++ ;
	}

	return true ;
}

bool
NSLinkManager::detruireTousLesLiens()
{
	pGraph->aLinks.vider() ;
  return true ;
}

bool
NSLinkManager::detruireLien(string sQualifie, NODELINKTYPES iRelation, string sQualifiant)
{
  if (true == pGraph->aLinks.empty())
    return true ;

	// ---------------------------------------------------------------------------
	// les param�tres sont-ils correct ?
	// ---------------------------------------------------------------------------

	if (sQualifie == "")
		return false ;

	if (strlen(sQualifie.c_str()) > PATLINK_QUALIFIE_LEN)
		return false ;

	// Recherche du code qui correspond � ce lien
	string sLien = donneString(iRelation) ;
	if (sLien == "")
		return false ;

	if (sQualifiant == "")
		return false ;

	if (strlen(sQualifiant.c_str()) > PATLINK_QUALIFIANT_LEN)
		return false ;

	// on d�truit tous les liens qualifie + relation + qualifiant
	for (NSPatLinkIter i = pGraph->aLinks.begin(); i != pGraph->aLinks.end(); )
	{
		if (((*i)->getLien()       == sLien) &&
        ((*i)->getQualifie()   == sQualifie) &&
        ((*i)->getQualifiant() == sQualifiant))
		{
    	delete (*i) ;
      pGraph->aLinks.erase(i) ;
    }
    else
    	i++ ;
  }

	return true ;
}

bool
NSLinkManager::existeLien(string sQualifie, NODELINKTYPES iRelation, string sQualifiant)
{
  if (true == pGraph->aLinks.empty())
    return false ;

	// ---------------------------------------------------------------------------
	// les param�tres sont-ils correct ?
	// ---------------------------------------------------------------------------

	if (sQualifie == "")
		return false ;

	if (strlen(sQualifie.c_str()) > PATLINK_QUALIFIE_LEN)
		return false ;

	// Recherche du code qui correspond � ce lien
	string sLien = donneString(iRelation) ;
	if (sLien == "")
		return false ;

	if (sQualifiant == "")
  	return false ;

	if (strlen(sQualifiant.c_str()) > PATLINK_QUALIFIANT_LEN)
  	return false ;

	bool trouve = false ;

	// on cherche un lien qualifie + relation + qualifiant
	for (NSPatLinkIter i = pGraph->aLinks.begin(); i != pGraph->aLinks.end(); i++)
	{
		if (((*i)->getLien()       == sLien) &&
        ((*i)->getQualifie()   == sQualifie) &&
        ((*i)->getQualifiant() == sQualifiant))
    {
    	trouve = true ;
      break ;
    }
	}

	return trouve ;
}

bool
NSLinkManager::swapLiens(string sOldNode, NSPatPathoInfo* pNewPpt)
{
  if ((string("") == sOldNode) || (NULL == pNewPpt))
    return false ;

  if (true == pGraph->aLinks.empty())
    return true ;

  // Qualifie - fl�che -> Qualifiant
  //

  for (NSPatLinkIter i = pGraph->aLinks.begin(); i != pGraph->aLinks.end(); i++)
	{
    // We also reconnect links like contributionAdded and contributionModified
    // to somehow "track" history
    //
    if ((*i)->getQualifie() == sOldNode)
    {
      NSRootLink::NODELINKTYPES iLkType = donneRelation((*i)->getLien()) ;
      pNewPpt->addTemporaryLink((*i)->getQualifiant(), iLkType, dirFleche) ;
    }

    if ((*i)->getQualifiant() == sOldNode)
    {
      NSRootLink::NODELINKTYPES iLkType = donneRelation((*i)->getLien()) ;
      pNewPpt->addTemporaryLink((*i)->getQualifie(), iLkType, dirEnvers) ;
    }
  }

	return true ;
}

string
NSLinkManager::nextDocToSave()
{
  if (true == pGraph->aLinks.empty())
    return string("") ;

	string sDocum, sNextDoc = "";
  int    maxLinks = 0;
  int    numLinks;

  VecteurString VecteurString ;

  // A FAIRE : Etablir une priorit� en cas de lien d'un document vers l'index de sant�
  // pour enregistrer le document de pr�f�rence � l'index de sant�
  for (NSPatLinkIter i = pGraph->aLinks.begin(); i != pGraph->aLinks.end(); i++)
  {
  	if ((*i)->getDirty())
    {
    	sDocum = string((*i)->getQualifie(), 0, OBJECT_ID_LEN) ;
      if (VecteurString.ItemDansUnVecteur(sDocum) == false)
      {
      	VecteurString.push_back(new string(sDocum)) ;
        numLinks = numberDirtyLinksToDoc(sDocum) ;
        if (numLinks > maxLinks)
        {
        	sNextDoc = sDocum ;
          maxLinks = numLinks ;
        }
      }

      sDocum = string((*i)->getQualifiant(), 0, OBJECT_ID_LEN) ;
      if (VecteurString.ItemDansUnVecteur(sDocum) == false)
      {
      	VecteurString.push_back(new string(sDocum)) ;
        numLinks = numberDirtyLinksToDoc(sDocum) ;
        if (numLinks > maxLinks)
        {
        	sNextDoc = sDocum ;
          maxLinks = numLinks ;
        }
      }
    }
  }

	return sNextDoc ;
}

int
NSLinkManager::numberDirtyLinksToDoc(string sTreeID)
{
  if (true == pGraph->aLinks.empty())
    return 0 ;

	int cpt = 0 ;

	for (NSPatLinkIter i = pGraph->aLinks.begin(); i != pGraph->aLinks.end(); i++)
	{
  	if ((*i)->getDirty())
    {
    	if (string((*i)->getQualifie(), 0, OBJECT_ID_LEN) == sTreeID)
      	cpt += 1 ;

      if (string((*i)->getQualifiant(), 0, OBJECT_ID_LEN) == sTreeID)
      	cpt += 1 ;
    }
  }

	return cpt ;
}

string
NSLinkManager::giveMetaDataRoot(string sDocRoot)
{
	VecteurString aVecteurString ;
  TousLesVrais(sDocRoot, NSRootLink::docData, &aVecteurString, "ENVERS") ;
  if (aVecteurString.empty())
  	return string("") ;

	return **(aVecteurString.begin()) ;
}

///////////////////////////////////////////////////////////////
//
// Classe NSArcNode
//
///////////////////////////////////////////////////////////////

NSArcNode::NSArcNode(string sNode, string sArc, int iEtat)
{
    node = sNode;
    arc = sArc;
    etat = iEtat;
}

NSArcNode::~NSArcNode()
{
}

NSArcNode::NSArcNode(NSArcNode& rv)
{
    node = rv.node;
    arc = rv.arc;
    etat = rv.etat;
}

NSArcNode&
NSArcNode::operator=(NSArcNode src)
{
	if (&src == this)
  	return *this ;

	node = src.node ;
  arc  = src.arc ;
  etat = src.etat ;

  return *this ;
}

// Classe NSArcNodeArray
//////////////////////////////////////////

//---------------------------------------------------------------------------
//  Constructeur copie//---------------------------------------------------------------------------
NSArcNodeArray::NSArcNodeArray(NSArcNodeArray& rv) : NSArcNodeVector(){try{	if (!rv.empty())  	for (NSArcNodeIter i = rv.begin(); i != rv.end(); i++)    	push_back(new NSArcNode(*(*i))) ;}catch (...)
{
	erreur("Exception NSArcNodeArray copy ctor.", standardError, 0) ;
  return ;
}}
NSArcNodeArray&
NSArcNodeArray::operator=(NSArcNodeArray src)
{try{	if (&src == this)  	return *this ;	if (!src.empty())  	for (NSArcNodeIter i = src.begin(); i != src.end(); i++)    	push_back(new NSArcNode(*(*i))) ;	return *this ;}catch (...)
{
	erreur("Exception NSArcNodeArray = operator.", standardError, 0) ;
  return *this ;
}}

//---------------------------------------------------------------------------//  Destructeur//---------------------------------------------------------------------------
voidNSArcNodeArray::vider(){	if (!empty())		for (NSArcNodeIter i = begin(); i != end(); )		{    	delete *i ;      erase(i) ;    }}
NSArcNodeArray::~NSArcNodeArray(){	vider() ;}

///////////////////////////////////////////////////////////////
//
// Classe NSArcManager
//
///////////////////////////////////////////////////////////////

NSArcManager::NSArcManager(NSContexte* pCtx)
             :NSRoot(pCtx)
{
	// NSSuper *pLocalSup = pContexte->getSuperviseur() ;
}


NSArcManager::NSArcManager(NSArcManager& src)
             :NSRoot(src.pContexte)
{
	aModelArray = src.aModelArray ;
}


NSArcManager::~NSArcManager()
{
}


NSArcManager&
NSArcManager::operator=(NSArcManager& src)
{
	if (this == &src)
  	return (*this) ;

	aModelArray	= src.aModelArray ;

	return (*this) ;
}


bool
NSArcManager::OuvreLibrairie()
{
try
{
	erreur("Fonction NSArcManager::OuvreLibrairie non impl�ment�e dans le mode N_TIERS.", standardError, 0) ;
	return false ;
}
catch (...)
{
	erreur("Exception NSArcManager::OuvreLibrairie.", standardError, 0) ;
	return false ;
}}

string
NSArcManager::DonneNomArchetypeLie(TYPEARC type, string sNode)
{
try
{
	string sNodeArc = "" ;

	// En N_TIERS sNodeArc repr�sente le model_object_id
  NSDataGraph* pGraph = pContexte->getPatient()->pGraphPerson->pDataGraph ;
  if (pGraph->aArchs.empty())
  	return string("") ;

	string sTypeLink ;
	if (type == NSArcManager::archetype)
		sTypeLink = pContexte->getPatient()->pGraphPerson->pLinkManager->donneString(NSRootLink::archetype) ;
	else if (type == NSArcManager::referentiel)
		sTypeLink = pContexte->getPatient()->pGraphPerson->pLinkManager->donneString(NSRootLink::referentialOf) ;

  for (NSArcLinkIter i = pGraph->aArchs.begin(); i != pGraph->aArchs.end(); i++)
  {
  	if ((sNode == ((*i)->getFullNode())) && (sTypeLink == (*i)->type))
    {
    	sNodeArc = (*i)->model_object_id ;
      break ;
    }
  }

  if (string("") == sNodeArc)
  	return string("") ;

	return DonneNomArchetypeDansLibrairie(type, sNodeArc) ;
}
catch (...)
{
	erreur("Exception NSArcManager::DonneNomArchetypeLie.", standardError, 0) ;
  return "" ;
}
}

string
NSArcManager::DonneNomArchetypeDansLibrairie(TYPEARC type, string sNodeArc)
{
try
{
	PatPathoIter iter, iterEnd ;
	int iColArc ;
	string sElemLex, sSens, sType, sTypeLex ;
	string sNomArc = "", sFichArc = "" ;
	bool bNomTrouve = false ;

	if (type == NSArcManager::archetype)
	{
		sTypeLex = string("0ARCH1") ;
		sType = string("0ARCH") ;
	}
	else if (type == NSArcManager::referentiel)
	{
		sTypeLex = string("0REFE1") ;
		sType = string("0REFE") ;
	}
	else
	{
		erreur("Type inconnu dans ::DonneNomArchetypeDansLibrairie.", standardError, 0) ;
		return "" ;
	}

	// en N_TIERS on cherche d'abord en m�moire, sinon on fait un appel au pilote
	// Remarque : ici sNodeArc repr�sente l'object_id du modele
	NSDataTreeIter iterTree ;
	if (aModelArray.ExisteTreeID(sNodeArc, &iterTree))
		return (*iterTree)->sModelName ;

	// ------------ Appel du pilote
	//
	NSDataGraph     Graph(pContexte, graphObject) ;
	NSPatPathoArray PatPathoArray(pContexte, graphObject) ;
	//
	//Il faut creer la variable sTraitName = "_" + nomObjet + "_" + typeobjet
	string sTraitName;
	if (type == NSArcManager::archetype)
		sTraitName = "_0ARCH_0ARID" ;
	else
		sTraitName = "_0REFE_0ARID" ;


	NSBasicAttributeArray AttrArray ;
	AttrArray.push_back(new NSBasicAttribute(OBJECT, sNodeArc)) ;

	bool res = pContexte->pPilot->invokeService(NautilusPilot::SERV_SEARCH_OBJECT_FROM_ID.c_str(),
                                    &Graph, &AttrArray) ;
	if (!res)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "modelNotFound") + string(" ") + sNodeArc ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0) ;
		return "" ;
	}

	if (Graph.aTrees.ExisteTree(sTypeLex, pContexte, &iterTree))
	{
		(*iterTree)->getPatPatho(&PatPathoArray) ;
		iter = PatPathoArray.begin() ;
	}
	else
		return "" ;

	iterEnd = PatPathoArray.end() ;

	if ((iter != NULL) && (iter != iterEnd))
	{
		sElemLex = string((*iter)->pDonnees->lexique) ;
		pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

		if (sSens == sType)
		{
			iColArc = (*iter)->pDonnees->getColonne() ;
			iter++ ;

			// on charge les donn�es de l'archetype
			while ((iter != iterEnd) && ((*iter)->pDonnees->getColonne() > iColArc))
			{
				sElemLex = string((*iter)->pDonnees->lexique) ;
				pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

				// identifiant (unique)
				if (sSens == string("0ARID"))
				{
					iter++ ;
					sNomArc = "" ;

					while ((iter != iterEnd) && ((*iter)->pDonnees->getColonne() > iColArc+1))
					{
						// on cherche ici un texte libre
						sElemLex = string((*iter)->pDonnees->lexique) ;

						if (sElemLex == string("�?????"))
						{
							sNomArc = (*iter)->pDonnees->getTexteLibre() ;
							bNomTrouve = true ;
						}

						iter++ ;
					}
				}
				// nom du fichier (unique)
				else if (sSens == string("0NFIC"))
				{
					iter++ ;

					while ((iter != iterEnd) && ((*iter)->pDonnees->getColonne() > iColArc+1))
					{
						// on cherche ici un texte libre
						sElemLex = string((*iter)->pDonnees->lexique) ;

						if (sElemLex == string("�?????"))
							sFichArc = (*iter)->pDonnees->getTexteLibre() ;

						iter++ ;
					}
				}
				else
					iter++ ;
			}

			if (bNomTrouve)
			{
				(*iterTree)->sModelName = sNomArc ;
				(*iterTree)->sModelFileName = sFichArc ;
				aModelArray.push_back(new NSDataTree(*(*iterTree))) ;
				return sNomArc ;
			}
		}
		else
		{
			erreur("Le noeud archetype est mal positionn� dans ::DonneNomArchetypeDansLibrairie().", standardError, 0) ;
			return "" ;
		}
	}
	else
	{
		erreur("Le noeud archetype est incorrect dans ::DonneNomArchetypeDansLibrairie().", standardError, 0) ;
		return "" ;
	}

	return "" ;
}
catch (...)
{
	erreur("Exception NSArcManager::DonneNomArchetypeDansLibrairie.", standardError, 0) ;
  return "" ;
}
}

string
NSArcManager::DonneFichierArchetypeParNom(TYPEARC type, string sNomArc, bool bAvecChemin)
{
try
{
	PatPathoIter iter, iterEnd ;
  int iColArc ;
  string sElemLex, sSens, sType, sTypeLex ;
  string sNodeArc = "", sFichArc = "" ;
  string sNomTrouve = "", sFichierTrouve = "", sCheminTrouve = "" ;

  VecteurString Chemin ;

	if (type == NSArcManager::archetype)
  {
  	sTypeLex = string("0ARCH1") ;
    sType = string("0ARCH") ;
  }
  else if (type == NSArcManager::referentiel)
  {
  	sTypeLex = string("0REFE1") ;
    sType = string("0REFE") ;
  }
  else
  {
  	erreur("Type inconnu dans ::DonneFichierArchetypeParNom.", standardError, 0) ;
    return "" ;
  }

	// en N_TIERS on cherche d'abord en m�moire, sinon on fait un appel au pilote
	// on doit parcourir l'array des mod�les
	NSDataTreeIter iterTree ;
	string sPathName = "" ;

	if (!aModelArray.empty())
		for (iterTree = aModelArray.begin() ; iterTree != aModelArray.end() ; iterTree++)
		{
			if (sNomArc == (*iterTree)->sModelName)
			{
				if (bAvecChemin)
					sPathName = pContexte->PathName("IXML") + (*iterTree)->sModelFileName ;
				else
					sPathName = (*iterTree)->sModelFileName ;

				return sPathName ;
			}
		}

	// ------------ Appel du pilote
	NSDataGraph     Graph(pContexte, graphObject) ;
	NSPatPathoArray PatPathoArray(pContexte, graphObject) ;

	//Il faut creer la variable sTraitName = "_" + nomObjet + "_" + typeobjet
	string  sTraitName ;

	if (type == NSArcManager::archetype)
		sTraitName = "_0ARCH_0ARID" ;
	else
		sTraitName = "_0REFE_0ARID" ;

	char szTraitName[13];
	strcpy(szTraitName,sTraitName.c_str());

	//appel invokeService pour la recherche d'un graph

	NSPersonsAttributesArray ObjList ;
	NSBasicAttributeArray    AttrList ;
	AttrList.push_back(new NSBasicAttribute(sTraitName, sNomArc)) ;

	bool res = pContexte->pPilot->invokeService(NautilusPilot::SERV_SEARCH_OBJECT.c_str(),
                                    &Graph, &ObjList, &AttrList) ;

	if (!res)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "modelNotFound") ;
    sErrorText += string(" (") + sNomArc + string(")") ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
  	return "";
	}

	if (!(Graph.aTrees.ExisteTree(sTypeLex, pContexte, &iterTree)))
  	return "" ;

  (*iterTree)->getPatPatho(&PatPathoArray);
  iter = PatPathoArray.begin();
  iterEnd = PatPathoArray.end();

	if (iter == iterEnd)
  {
  	erreur("Le noeud du modele est incorrect dans ::DonneFichierArchetypeParNom().", standardError, 0) ;
		return "" ;
	}

  sElemLex = string((*iter)->pDonnees->lexique);
  pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

  if (sSens != sType)
  {
  	erreur("Le noeud du modele est mal positionn� dans ::DonneFichierArchetypeParNom().", standardError, 0) ;
    return "" ;
  }

  iColArc = (*iter)->pDonnees->getColonne() ;
  iter++ ;

  // on charge les donn�es de l'archetype
  while ((iter != iterEnd) && ((*iter)->pDonnees->getColonne() > iColArc))
  {
  	sElemLex = string((*iter)->pDonnees->lexique) ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    // nom du fichier (unique)
    if (sSens == string("0NFIC"))
    {
    	iter++ ;

      while ((iter != iterEnd) && ((*iter)->pDonnees->getColonne() > iColArc+1))
      {
      	// on cherche ici un texte libre
        sElemLex = string((*iter)->pDonnees->lexique) ;

        if (sElemLex == string("�?????"))
        	sFichArc = (*iter)->pDonnees->getTexteLibre() ;

        iter++;
      }
    }
    else
    	iter++ ;
  }

  (*iterTree)->sModelName = sNomArc ;
  (*iterTree)->sModelFileName = sFichArc ;
  aModelArray.push_back(new NSDataTree(*(*iterTree))) ;

  if (bAvecChemin)
  	sPathName = pContexte->PathName("IXML") + (*iterTree)->sModelFileName ;
  else
  	sPathName = (*iterTree)->sModelFileName ;

  return sPathName ;
}
catch (...)
{
	erreur("Exception NSArcManager::DonneFichierArchetypeParNom.", standardError, 0) ;
	return "" ;
}
}

bool
NSArcManager::ExisteFichierArchetype(string sFichArc, string sPathArc, string& /* sNomArc */, TYPEARC& /* type */)
{
try
{
  string sPathName = sPathArc ;

	if (sPathName[strlen(sPathName.c_str())-1] != '\\')
  	sPathName += string("\\") ;

  sPathName += sFichArc ;

  if (FileExists(AnsiString(sPathName.c_str())))
  	return true ;

	return false ;
}
catch (...)
{
	erreur("Exception NSArcManager::ExisteFichierArchetype.", standardError, 0) ;
	return true ;
}
}

string
NSArcManager::AjouteArchetype(TYPEARC type, string sNomArc, string sFichArc, string sPathArc, string sType, string sCategory, string sLabel)
{
try
{
	string ps = string("-- Adding to the library - begin") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

  if (sNomArc == string(""))
  {
  	string ps = string("-- Bad parameters (empty ID) - exiting") ;
  	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
    return string("") ;
  }

  if (sFichArc == string(""))
  {
  	string ps = string("-- Bad parameters (empty File name) - exiting") ;
  	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
    return string("") ;
  }

	// On doit ici ajouter un nouvel archetype
	// En N_TIERS un archetype comprend identifiant et nom de fichier
	// (par convention tous les archetypes sont dans IXML. Ajout d'Url � voir + tard
	NSPatPathoArray PatPatho(pContexte, graphObject) ;
	string sLexique ;
	string sObjectID = "" ;

	// Ajout d'un nouveau segment d'arbre
	if      (NSArcManager::archetype == type)
		sLexique = string("0ARCH1") ;
	else if (NSArcManager::referentiel == type)
		sLexique = string("0REFE1") ;
  else
  {
  	string ps = string("-- Bad parameters (type) - exiting") ;
  	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
  	return string("") ;
  }

	PatPatho.ajoutePatho(sLexique, 0) ;

	PatPatho.ajoutePatho("0ARID1", 1) ;
	Message Msg ;
	Msg.SetLexique("�?????") ;
	Msg.SetTexteLibre(sNomArc) ;
	PatPatho.ajoutePatho("�?????", &Msg, 2) ;

	PatPatho.ajoutePatho("0NFIC1", 1) ;
	Msg.Reset() ;
	Msg.SetLexique("�?????") ;
	Msg.SetTexteLibre(sFichArc) ;
	PatPatho.ajoutePatho("�?????", &Msg, 2) ;

  if (string("") != sLabel)
  {
  	// libell�
		PatPatho.ajoutePatho("LNOMA1", 1) ;
  	Msg.Reset() ;
    Msg.SetLexique("�?????") ;
		Msg.SetTexteLibre(sLabel) ;
		PatPatho.ajoutePatho("�?????", &Msg, 2) ;
  }

  if (string("") != sType)
  {
  	// libell�
		PatPatho.ajoutePatho("LTYPA1", 1) ;
    PatPatho.ajoutePatho(sType, 2) ;
  }

  if (string("") != sCategory)
  {
  	// libell�
		PatPatho.ajoutePatho("LDOMA1", 1) ;
    PatPatho.ajoutePatho(sCategory, 2) ;
  }

	NSObjectGraphManager GraphObject(pContexte) ;
	string sRootId = GraphObject.setTree(&PatPatho, "") ;
	GraphObject.setRootObject(sRootId) ;
	// Appel du pilote
	NSDataGraph* pGraph = GraphObject.pDataGraph ;
	//pObectsList la liste d'objects qui correspondent a ces criteres
	NSPersonsAttributesArray ObjectsList ;
	string user = "_000000" ;
	if (pContexte->getUtilisateur()!= NULL)
		user = pContexte->getUtilisateurID() ;
	string sCodeSens ;
	pContexte->getDico()->donneCodeSens(&sLexique, &sCodeSens) ;
	string sTraitName = string("_") + sCodeSens + "_" + string("0ARID") ;
	/* char szTraitName[12];
    strcpy(szTraitName,sTraitName.c_str()); */

	NSBasicAttributeArray AttrList ;
	AttrList.push_back(new NSBasicAttribute(sTraitName, sNomArc)) ;
	AttrList.push_back(new NSBasicAttribute("user",  user)) ;

  if (string("") != sType)
  {
  	string sTypeSens ;
		pContexte->getDico()->donneCodeSens(&sType, &sTypeSens) ;
    string sTraitName = string("_") + sCodeSens + "_" + string("LTYPA") ;
    AttrList.push_back(new NSBasicAttribute(sTraitName, sTypeSens)) ;
  }
  if (string("") != sCategory)
  {
    string sTypeSens ;
		pContexte->getDico()->donneCodeSens(&sType, &sTypeSens) ;
    string sTraitName = string("_") + sCodeSens + "_" + string("LDOMA") ;
    AttrList.push_back(new NSBasicAttribute(sTraitName, sCategory)) ;
  }
  if (string("") != sLabel)
  {
    string sTraitName = string("_") + sCodeSens + "_" + string("LNOMA") ;
    AttrList.push_back(new NSBasicAttribute(sTraitName, sLabel)) ;
  }

	pContexte->pPilot->createPersonOrObject(NautilusPilot::SERV_CREATE_OBJECT.c_str(),
                        pGraph, &ObjectsList, &AttrList, OBJECT_TYPE, false) ;

	if (!pGraph)
  {
  	string ps = string("-- The Pilot didn't create the new object - exiting") ;
  	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
		return "" ;
  }

	NSDataTreeIter iter;
	if (pGraph->aTrees.ExisteTree(sLexique, pContexte, &iter))
	{
		sObjectID = (*iter)->getTreeID() ;
		aModelArray.push_back(new NSDataTree(*(*iter))) ;

    ps = string("-- The Pilot has created the new object : ") + sObjectID ;
  	pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;
	}

  ps = string("-- Adding to the library - end") ;
  pContexte->getSuperviseur()->trace(&ps, 1, NSSuper::trSubDetails) ;

	return sObjectID ;
}
catch (...)
{
	erreur("Exception NSArcManager::AjouteArchetype.", standardError, 0) ;
	return "" ;
}
}

void
NSArcManager::AjouteIdentifiantArchetype(TYPEARC /* type */, string /* sNomArc */, string /* sFichArc */)
{
try
{
	erreur("Fonction NSArcManager::AjouteIdentifiantArchetype non impl�ment�e en mode N_TIERS", standardError, 0) ;
}
catch (...)
{
	erreur("Exception NSArcManager::AjouteIdentifiantArchetype.", standardError, 0) ;
	return ;
}
}

string
NSArcManager::DonneNoeudArchetype(TYPEARC type, string sNomArc)
{
try
{
  PatPathoIter iter, iterEnd;
  int iColArc;
  string sElemLex, sSens, sType, sTypeLex;
  string sNodeArc = "";
  string sFichArc;
  string sNomTrouve = "";

	if (type == NSArcManager::archetype)
	{
  	sTypeLex = string("0ARCH1") ;
    sType = string("0ARCH") ;
  }
  else if (type == NSArcManager::referentiel)
  {
  	sTypeLex = string("0REFE1") ;
    sType = string("0REFE") ;
  }
  else
  {
  	erreur("Type inconnu dans ::DonneNoeudArchetype.", standardError, 0) ;
    return "" ;
  }

	// en N_TIERS on cherche d'abord en m�moire, sinon on fait un appel au pilote
	// on doit parcourir l'array des mod�les
	NSDataTreeIter iterTree ;
	if (!aModelArray.empty())
		for (iterTree = aModelArray.begin() ; iterTree != aModelArray.end() ; iterTree++)
		{
			if (sNomArc == (*iterTree)->sModelName)
				return (*iterTree)->getTreeID() ;
		}

	// ------------ Appel du pilote
	NSDataGraph     Graph(pContexte, graphObject) ;
	NSPatPathoArray PatPathoArray(pContexte, graphObject) ;

	string sTraitName;
	if (type == NSArcManager::archetype)
		sTraitName = "_0ARCH_0ARID" ;
	else
		sTraitName = "_0REFE_0ARID" ;

   /* char szTraitName[12];
    strcpy(szTraitName,sTraitName.c_str());

    bool res = pContexte->pPilot->invokeService(NautilusPilot::SERV_SEARCH_OBJECT.c_str(),
                                    pGraph,
                                    szTraitName,       sNomArc.c_str(),
                                    NULL);    */
	NSPersonsAttributesArray ObjList ;
	NSBasicAttributeArray    AttrArray ;
	AttrArray.push_back(new NSBasicAttribute(sTraitName, sNomArc)) ;

	bool res = pContexte->pPilot->invokeService(NautilusPilot::SERV_SEARCH_OBJECT.c_str(),
                                    &Graph, &ObjList, &AttrArray);
	if (!res)
	{
		string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "modelNotFound") ;
    sErrorText += string(" ") + sNomArc ;
    pContexte->getSuperviseur()->trace(&sErrorText, 1, NSSuper::trError) ;
		erreur(sErrorText.c_str(), standardError, 0, 0) ;
		return "";
	}

	if (!(Graph.aTrees.ExisteTree(sTypeLex, pContexte, &iterTree)))
  	return "" ;

	(*iterTree)->getPatPatho(&PatPathoArray) ;
  iter = PatPathoArray.begin() ;
  iterEnd = PatPathoArray.end() ;

	if (iter == iterEnd)
  {
  	erreur("Le noeud archetype est incorrect dans ::DonneNoeudArchetype().", standardError, 0) ;
		return "" ;
	}

  sElemLex = string((*iter)->pDonnees->lexique) ;
  pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

  if (sSens != sType)
  {
  	erreur("Le noeud archetype est mal positionn� dans ::DonneNoeudArchetype().", standardError, 0) ;
    return "" ;
	}

	iColArc = (*iter)->pDonnees->getColonne() ;
  iter++ ;

  // on charge les donn�es de l'archetype
  while ((iter != iterEnd) && ((*iter)->pDonnees->getColonne() > iColArc))
  {
  	sElemLex = string((*iter)->pDonnees->lexique) ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    // nom du fichier (unique)
    if (sSens == string("0NFIC"))
    {
    	iter++ ;

      while ((iter != iterEnd) && ((*iter)->pDonnees->getColonne() > iColArc+1))
      {
      	// on cherche ici un texte libre
        sElemLex = string((*iter)->pDonnees->lexique) ;

        if (sElemLex == string("�?????"))
        	sFichArc = (*iter)->pDonnees->getTexteLibre() ;

        iter++ ;
      }
    }
    else
    	iter++ ;
  }

	(*iterTree)->sModelName = sNomArc ;
  (*iterTree)->sModelFileName = sFichArc ;
  aModelArray.push_back(new NSDataTree(*(*iterTree))) ;

  string rootTree = (*iterTree)->getTreeID() ;

	return rootTree ;
}
catch (...)
{
	erreur("Exception NSArcManager::DonneNoeudArchetype.", standardError, 0) ;
	return "" ;
}
}

// -----------------------------------------------------------------------------
//
//  		Utility functions for Archetypes
//
// -----------------------------------------------------------------------------

string ArchetypeGetProperty(NSContexte *pContexte, NSDataTree *pTree, string sType, string sPropSens)
{
	if (!pTree || !pContexte)
		return string("") ;

	NSPatPathoArray PatPathoArray(pContexte, graphObject) ;
  pTree->getPatPatho(&PatPathoArray) ;

  if (PatPathoArray.empty())
  	return string("") ;

  // Checking that the root is of the proper type
  //
	PatPathoIter iter = PatPathoArray.begin() ;
  string sElemLex = string((*iter)->pDonnees->lexique) ;
  string sSens ;
  pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

  if (sSens != sType)
  	return string("") ;

	int iColArc = (*iter)->pDonnees->getColonne() ;
  iter++ ;

  string sResult = string("") ;

  // on charge les donn�es de l'archetype
  while ((iter != PatPathoArray.end()) &&
         ((*iter)->pDonnees->getColonne() > iColArc))
  {
  	sElemLex = string((*iter)->pDonnees->lexique) ;
    pContexte->getDico()->donneCodeSens(&sElemLex, &sSens) ;

    // nom du fichier (unique)
    if (sSens == sPropSens)
    {
    	iter++ ;

      while ((iter != PatPathoArray.end()) && ((*iter)->pDonnees->getColonne() > iColArc + 1))
      {
      	// on cherche ici un texte libre
        sElemLex = string((*iter)->pDonnees->lexique) ;

        if (sElemLex == string("�?????"))
        	sResult = (*iter)->pDonnees->getTexteLibre() ;

        iter++ ;
      }
    }
    else
    	iter++ ;
  }

  return sResult ;
}

string ArchetypeGetID(NSContexte *pContexte, NSDataTree *pTree, string sType)
{
	if (!pTree || !pContexte)
		return string("") ;

	return ArchetypeGetProperty(pContexte, pTree, sType, string("0ARID")) ;
}

string ArchetypeGetFile(NSContexte *pContexte, NSDataTree *pTree, string sType)
{
	if (!pTree || !pContexte)
		return string("") ;

	return ArchetypeGetProperty(pContexte, pTree, sType, string("0NFIC")) ;
}

bool
ArchetypeSortByIDInf(NSDataTree *pTree1, NSDataTree *pTree2)
{
  string sT1 = pTree1->sModelName ;
  pseumaj(&sT1) ;
  string sT2 = pTree2->sModelName ;
  pseumaj(&sT2) ;
	return (strcmp(sT1.c_str(), sT2.c_str()) > 0) ;
}

bool
ArchetypeSortByIDSup(NSDataTree *pTree1, NSDataTree *pTree2)
{
  string sT1 = pTree1->sModelName ;
  pseumaj(&sT1) ;
  string sT2 = pTree2->sModelName ;
  pseumaj(&sT2) ;
	return (strcmp(sT1.c_str(), sT2.c_str()) < 0) ;
}

bool
ArchetypeSortByFileInf(NSDataTree *pTree1, NSDataTree *pTree2)
{
  string sT1 = pTree1->sModelFileName ;
  pseumaj(&sT1) ;
  string sT2 = pTree2->sModelFileName ;
  pseumaj(&sT2) ;
	return (strcmp(sT1.c_str(), sT2.c_str()) > 0) ;
}

bool
ArchetypeSortByFileSup(NSDataTree *pTree1, NSDataTree *pTree2)
{
  string sT1 = pTree1->sModelFileName ;
  pseumaj(&sT1) ;
  string sT2 = pTree2->sModelFileName ;
  pseumaj(&sT2) ;
	return (strcmp(sT1.c_str(), sT2.c_str()) < 0) ;
}

// fin de nsgraphe.cpp
/////////////////////////////////////////////////

