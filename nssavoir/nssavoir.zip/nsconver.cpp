//    NSCV.CPP//    PA ao�t 97
//    Conversion d'une unit� dans une autre et calcul de formules
//---------------------------------------------------------------------------
#include <cstring.h>
#include <windows.h>
#include <mem.h>
#include <bde.hpp>

#include <stdio.h>
#include <io.h>
#include <fcntl.h>

#include "nautilus\nssuper.h"
#include "nssavoir\NSConver.h"
#include "nautilus\nshistdo.h"

//************************************************************************
// classe CodeStructure
//************************************************************************
CodeStructure::CodeStructure(const CodeStructure& src)
{
	dValeur = src.dValeur;
	sCode 	= src.sCode;
	sUnite 	= src.sUnite;
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
CodeStructure& CodeStructure::operator= (CodeStructure src)
{
	dValeur = src.dValeur;
	sCode 	= src.sCode;
	sUnite 	= src.sUnite;
	return *this;
}

CodeStructure::CodeStructure(string sChaine , double dVal, string sUnit)
{
	dValeur = dVal ;
	sCode  	= sChaine;
	sUnite 	= sUnit;
}

//**************************************************************************
//								structure contenant un code lexique et une valeur
//												chiffr�e
//									  Exemple (VPOIDS, 70)
//**************************************************************************

VectorCodeStructure::~VectorCodeStructure()
{
	vider();
}

VectorCodeStructure::VectorCodeStructure()
                   :vectClass()
{}

void
VectorCodeStructure::vider()
{
	if (empty())
		return ;

	iterCode i = begin() ;
	while (i != end())
	{
		delete *i ;
		erase(i) ;
	}
}

VectorCodeStructure&
VectorCodeStructure::operator=(VectorCodeStructure src)
{
  if (this == &src)
    return *this ;

	vider() ;
	if (!(src.empty()))
		for (iterCode i = src.begin(); i != src.end(); i++)
			push_back(new CodeStructure(*(*i))) ;

	return *this ;
}

VectorCodeStructure::VectorCodeStructure(VectorCodeStructure& src)
{
	if (!(src.empty()))
		for (iterCode i = src.begin(); i != src.end(); i++)
			push_back(new CodeStructure(*(*i))) ;
}

//-----------------------------------------------------------------
//savoir s'il existe une structure dont le code est sItem, retourner
//dValeur sinon -11111111
//-----------------------------------------------------------------
double
VectorCodeStructure::donneValeur(string sItem)
{
	if (!(empty()))
		for (iterCode i = begin(); i != end(); i++)
			if (sItem == (*i)->sCode)
				return (*i)->dValeur ;

	return -11111111 ;
}

//-----------------------------------------------------------------
//savoir s'il existe une structure dont le code est sItem
//-----------------------------------------------------------------
bool
VectorCodeStructure::Appartient(string sItem, CodeStructure* pResultat)
{
	if (!(empty()))
	{
		for (iterCode i = begin(); i != end(); i++)
		{
			if (sItem == (*i)->sCode)
			{
				*pResultat = *(*i) ;
				return true ;
			}
    }
	}
	return false ;
}

//***************************************************************************
// 				  Impl�mentation des m�thodes NSCVData
//***************************************************************************

//---------------------------------------------------------------------------
//  Fonction:		NSPatientData::NSPatientData(NSPatientData& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCVData::NSCVData(NSCVData& rv)
{
	strcpy(resultat,  rv.resultat) ;
	strcpy(operation, rv.operation) ;
	strcpy(apartir,   rv.apartir) ;
	strcpy(quantite,  rv.quantite) ;

	strcpy(formule,   rv.formule) ;
	strcpy(methode,   rv.methode) ;
	strcpy(unite,	 		rv.unite) ;
}

NSCVData::~NSCVData(){}

//---------------------------------------------------------------------------//  Fonction :		NSCVData::operator=(NSCVData src)
//  Description :	Op�rateur =
//  Retour :		R�f�rence sur l'objet cible
//---------------------------------------------------------------------------
NSCVData&
NSCVData::operator=(NSCVData rv)
{
	if (this == &rv)
		return *this ;

	strcpy(resultat,  rv.resultat) ;
	strcpy(operation, rv.operation) ;
	strcpy(apartir,   rv.apartir) ;
	strcpy(quantite,  rv.quantite) ;

	strcpy(formule,   rv.formule) ;
	strcpy(methode,   rv.methode) ;
	strcpy(unite,	    rv.unite) ;

	return *this ;
}

//---------------------------------------------------------------------------//  Fonction :		NSCVData::operator==(NSCVData& o)
//  Description :	Op�rateur de comparaison
//  Retour :		0 ou 1
//---------------------------------------------------------------------------
int
NSCVData::operator == ( const NSCVData& rv )
{
	if((strcmp(resultat,  rv.resultat)  == 0) &&
     (strcmp(operation, rv.operation) == 0) &&
     (strcmp(apartir,   rv.apartir)   == 0) &&
     (strcmp(quantite,  rv.quantite)  == 0) &&
     (strcmp(formule,   rv.formule)   == 0) &&
     (strcmp(unite, 	  rv.unite)     == 0)
    )
		return 1 ;
	else
		return 0 ;
}

//---------------------------------------------------------------------------//  Function:    NSCVData::metAZero()
//
//  Description: Met � 0 les variables.
//---------------------------------------------------------------------------
void
NSCVData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset( resultat,   0, CV_RESULTAT_LEN ) ;
	memset( operation,  0, CV_OPERATION_LEN ) ;
	memset( apartir,    0, CV_APARTIRDE_LEN ) ;
	memset( quantite,   0, CV_LIEALAQUANTITE_LEN ) ;
	memset( formule,    0, CV_FORMULE_LEN ) ;
	memset( methode,    0, CV_METHODE_LEN  ) ;
	memset( unite,      0, CV_UNITE_LEN  ) ;
}

//---------------------------------------------------------------------------//  Function:    NSCVData::metABlanc()
//
//  Description: Met � blanc les variables.
//---------------------------------------------------------------------------
void
NSCVData::metABlanc()
{
	//
	// Met les champs de donn�es � blanc
	//
   memset( resultat, 	' ',CV_RESULTAT_LEN    );
   memset( operation,   ' ',CV_OPERATION_LEN    );
   memset( apartir,     ' ',CV_APARTIRDE_LEN         );
   memset( quantite,    ' ',CV_LIEALAQUANTITE_LEN     );
   memset( formule,     ' ',CV_FORMULE_LEN           );
   memset( methode,     ' ',CV_METHODE_LEN           );
   memset( unite, 	   ' ',CV_UNITE_LEN           );
}

//***************************************************************************
// 				Impl�mentation des m�thodes NSCVInfo
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur par d�faut
//---------------------------------------------------------------------------
NSCVInfo::NSCVInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSCVData() ;
}

//---------------------------------------------------------------------------
//  Constructeur � partir d'un NSPatPatho
//---------------------------------------------------------------------------
NSCVInfo::NSCVInfo(NSCV* pCVcursor)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCVData(*(pCVcursor->pDonnees)) ;
}

//---------------------------------------------------------------------------//  Constructeur copie
//---------------------------------------------------------------------------
NSCVInfo::NSCVInfo(NSCVInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCVData() ;
	//
	// Copie les valeurs du NSCVInfo d'origine
	//
	*pDonnees = *(rv.pDonnees) ;
}

//destructeur
NSCVInfo::~NSCVInfo()
{
	if (pDonnees)
		delete pDonnees ;
}

//---------------------------------------------------------------------------//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSCVInfo&
NSCVInfo::operator=(NSCVInfo src)
{
	if (this == &src)
		return *this ;

	*pDonnees = *(src.pDonnees) ;

	return *this ;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int NSCVInfo::operator == ( const NSCVInfo& o )
{
	return (*pDonnees == *(o.pDonnees)) ;
}

//***************************************************************************
//							 Impl�mentation des m�thodes NSCV
//***************************************************************************
//---------------------------------------------------------------------------
//  Function:    NSCV::NSCV(NSSuper* pSuper)
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSCV::NSCV(NSContexte* pCtx) : NSFiche(pCtx)
{
	pDonnees = new NSCVData() ;
}

//---------------------------------------------------------------------------
//  Function:    NSCV::~NSCV()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSCV::~NSCV()
{
	if (pDonnees)
		delete pDonnees ;
}

//---------------------------------------------------------------------------//  Function :  	NSCV::alimenteFiche()
//
//  Description : Transf�re le contenu de pRecBuff dans les variables de
//             	la fiche
//---------------------------------------------------------------------------
void
NSCV::alimenteFiche()
{
	alimenteChamp(pDonnees->resultat,   CV_RESULTAT_FIELD,CV_RESULTAT_LEN ) ;
	alimenteChamp(pDonnees->operation,  CV_OPERATION_FIELD,CV_OPERATION_LEN ) ;
	alimenteChamp(pDonnees->apartir,    CV_APARTIRDE_FIELD,CV_APARTIRDE_LEN ) ;
	alimenteChamp(pDonnees->quantite,   CV_LIEALAQUANTITE_FIELD,CV_LIEALAQUANTITE_LEN ) ;
	alimenteChamp(pDonnees->formule,    CV_FORMULE_FIELD,CV_FORMULE_LEN) ;
	alimenteChamp(pDonnees->methode,    CV_METHODE_FIELD,CV_METHODE_LEN ) ;
	alimenteChamp(pDonnees->unite,      CV_UNITE_FIELD, CV_UNITE_LEN ) ;
}

//---------------------------------------------------------------------------//  Fonction :  	NSCV::videFiche()
//
//  Description :	Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSCV::videFiche()
{
	videChamp(pDonnees->resultat,   CV_RESULTAT_FIELD,CV_RESULTAT_LEN ) ;
	videChamp(pDonnees->operation,  CV_OPERATION_FIELD,CV_OPERATION_LEN ) ;
	videChamp(pDonnees->apartir,    CV_APARTIRDE_FIELD,CV_APARTIRDE_LEN ) ;
	videChamp(pDonnees->quantite,   CV_LIEALAQUANTITE_FIELD,CV_LIEALAQUANTITE_LEN ) ;
	videChamp(pDonnees->formule,    CV_FORMULE_FIELD,CV_FORMULE_LEN) ;
	videChamp(pDonnees->methode,    CV_METHODE_FIELD,CV_METHODE_LEN ) ;
	videChamp(pDonnees->unite,      CV_UNITE_FIELD, CV_UNITE_LEN ) ;
}

//---------------------------------------------------------------------------//  Function :  	NSCV::open()
//
//  Description : Ouvre la table primaire
//
//  Retour :		PXERR_, s'il y a lieu
//---------------------------------------------------------------------------
DBIResult
NSCV::open()
{
	char tableName[] = "CONVERT.DB" ;
	//
	// Appelle la fonction open() de la classe de base pour ouvrir
	// l'index primaire
	//
	lastError = NSFiche::open(tableName, NSF_GUIDES) ;
	return(lastError) ;
}

//---------------------------------------------------------------------------
//chercher dans Convert.db si sLexique possede une formule et si
//tous les param�tres sont instanci�s faire le cacul et mettre � jour
//pLabel
//---------------------------------------------------------------------------
void
NSCV::CalculValeur(string sLexique, string* pLabel, string* pUnite,
                   string* pMethodeCalcul, NSPatPathoArray* pPathoDocEnCours)
{
try
{
	if (sLexique == "")
		return ;

	//
  // R�cup�ration de la formule de calcul
  //

	string sCode ;
	string sCodeSens ;
	NSSuper* pSuper = pContexte->getSuperviseur() ;

	pSuper->getDico()->donneCodeSens(&sLexique, &sCodeSens) ;
	sCode = sCodeSens + "FO" ; //acc�der � la formule

	lastError = chercheClef(&sCode,
                            "",
                            0,
                            keySEARCHGEQ,
                            dbiWRITELOCK
                            );
	if (lastError != DBIERR_NONE)
		return ;

	lastError = getRecord() ;
	if (lastError != DBIERR_NONE)
	{
		erreur("Le fichier de conversion semble endommag�.", standardError, lastError) ;
		return ;
	}
	string sResultat = pDonnees->resultat ;

	if (!(sResultat == sCodeSens))
		return ;

	string sFormule = pDonnees->formule ;
	VectorCodeStructure Vector ;
	size_t debut = 0 ;
  size_t Crochet = sFormule.find("[") ;
	string sItem ;
	string sUnite ;
	string sUnitSens ;

	//
  // R�cup�ration des donn�es disponibles
  //

	CodeStructure CodeStruct("") ;

	//patpatho de la synth�se
	NSPatPathoArray PathoSynthese(pContexte) ;

	while (Crochet != NPOS)
	{
		sItem = string(sFormule, Crochet + 1, BASE_LEXI_LEN - 1) ;
		if (!Vector.Appartient(sItem, &CodeStruct))
		{
			string sValeur  = pSuper->getDico()->SetData(sItem, &sUnite, pPathoDocEnCours) ;
			if (sValeur == "")
			{
				bool continuer = true ;
				//chercher dans le document synth�se
				//pSuper->pUtilisateur->pPatient->pDocHis->DonnePathoSynthese(pPathoSynthese);
				DocumentIter iterDoc = pContexte->getPatient()->pDocHis->VectDocument.begin() ;

				while ((iterDoc != pContexte->getPatient()->pDocHis->VectDocument.end()) &&
                        continuer )
				{
        	if (((*iterDoc)->pPatPathoArray) && (!((*iterDoc)->pPatPathoArray->empty())))
					{
						PatPathoIter iter = (*iterDoc)->pPatPathoArray->begin() ;
						if (strcmp((*iter)->pDonnees->lexique, "ZSYNT1") == 0)
						{
            	PathoSynthese = *((*iterDoc)->pPatPathoArray) ;
							continuer = false ;
						}
						else
							iterDoc++ ;
					}
          else
							iterDoc++ ;
        }
				if (PathoSynthese.empty())
					return ;

				sValeur = pSuper->getDico()->SetData(sItem, &sUnite, &PathoSynthese) ;
				if (sValeur == "")
					return ;
			}
			double dVal = StringToDouble(sValeur) ;
			pSuper->getDico()->donneCodeSens(&sUnite, &sUnitSens) ;
			Vector.push_back(new CodeStructure(sItem, dVal, sUnitSens)) ;
		}
		debut = Crochet + 1 + BASE_LEXI_LEN  ;
		Crochet = sFormule.find("[", debut) ;
	}

	//
  // Calcul � partir des donn�es disponibles
  //

	// 100 niveaux de piles
	double val[100] ;
	string ope[100] ;
	int	   nbNiv = 100 ;

	for (int j = 0; j < nbNiv; j++)
	{
		val[j] = 0 ;
		ope[j] = "" ;
	}

	size_t i = 0 ;
	int    pileur = 0 ;
	bool   tourner = true ;
	while (tourner)
	{
  	// Parenth�se ouvrante : on empile
    //
    if (sFormule[i] == '(')
    {
    	for (int j = nbNiv - 1; j > pileur; j--)
      {
      	val[j] = val[j-1] ;
        ope[j] = ope[j-1] ;
      }
      val[pileur] = 0 ;
      ope[pileur] = "" ;
      i++ ;
    }
    //
    // Op�rateurs + - * / ^x, etc
    //
    else if (isOperator(sFormule[i]))
    {
    	ope[pileur] = string(1, sFormule[i]) ;
      i++ ;
    }
    //
    // Parenth�se fermante : on d�pile
    //
    else if (sFormule[i] == ')')
    {
    	while (ope[pileur+1] != "")
      {
      	val[pileur] = Operation(val[pileur+1], val[pileur], ope[pileur+1]) ;
        for (int j = pileur+1; j < nbNiv-1; j++)
        {
        	val[j] = val[j+1] ;
          ope[j] = ope[j+1] ;
        }
        val[nbNiv-1] = 0 ;
        ope[nbNiv-1] = "" ;
      }
      i++ ;
    }
    //
    // Crochet : valeur � convertir
    //
    else if (sFormule[i] == '[')
    {
    	i++ ;
      string sCode = "" ;
      string sUnit = "" ;
      bool bUnite = false ;
      while ((i < strlen(sFormule.c_str())) && (sFormule[i] != ']'))
      {
      	if (sFormule[i] == '|')
        	bUnite = true ;
        else if (bUnite)
        	sUnit += string(1, sFormule[i]) ;
        else
        	sCode += string(1, sFormule[i]) ;
        i++ ;
      }
      if (sFormule[i] == ']')
      	i++ ;
      else
      	return ;

      // On retrouve la donn�e souhait�e donn�e
      if (!(Vector.Appartient(sCode, &CodeStruct)))
      	return ;

      double dValeur = CodeStruct.dValeur ;

      if (CodeStruct.sUnite != sUnit)
      {
      	if (!ConvertirUnite(&dValeur, sUnit, CodeStruct.sUnite, sCode))
        	return ;
      }

      if (ope[pileur] != "")
      	val[pileur] = Operation(val[pileur], dValeur, ope[pileur]) ;
      else
      	val[pileur] = dValeur ;
    }
    else if ((sFormule[i] >= '0') && (sFormule[i] <= '9'))
    {
    	string sNbre = string(1, sFormule[i]) ;
      i++ ;
      while ((i < strlen(sFormule.c_str())) &&
              (((sFormule[i] >= '0') && (sFormule[i] <= '9')) ||
                   	(sFormule[i] == '.')))
      {
      	sNbre += string(1, sFormule[i]) ;
        i++ ;
      }
      double dNbre = StringToDouble(sNbre) ;
      if (ope[pileur] != "")
      	val[pileur] = Operation(val[pileur], dNbre, ope[pileur]) ;
      else
      	val[pileur] = dNbre ;
    }
    else
    	i++ ;

    if (i >= strlen(sFormule.c_str()))
    	tourner = false ;
	}
	val[pileur] ;

  if (NULL != pLabel)
		*pLabel         = DoubleToString(&(val[pileur]), 0, 4) ;
  if (NULL != pUnite)
		*pUnite         = pDonnees->unite ;
  if (NULL != pMethodeCalcul)
		*pMethodeCalcul = pDonnees->methode ;

	//AnalyseurSyntaxique(sFormule,&dValeur);
}
catch (...)
{
	erreur("Exception NSCV::CalculValeur", standardError, 0) ;
}
}

//-------------------------------------------------------------------------//analyser le formule
//-------------------------------------------------------------------------
void
NSCV::AnalyseurSyntaxique(string sFormule, double* pValeur)
{
}

//-------------------------------------------------------------------------//convertir sResultat (� partir de son unite sUnite) mettre � jour pValeur
//exemple  pValeur = 25 cm -> pValeur = 0.25 m
//
// Peut se faire sp�cifiquement en fonction d'une donn�e (par exemple
// la covertion de mmol/l en mg/l d�pend de la mol�cule concern�e
//-------------------------------------------------------------------------
bool
NSCV::ConvertirUnite(double* pValeur, string sResultat, string sUnite, string sLieA)
{
	if (NULL == pValeur)
		return false ;

	if (sResultat == sUnite)
		return true ;

	string sCode ;

	NSSuper* pSuper = pContexte->getSuperviseur() ;

	string sCodeSens ;
	pSuper->getDico()->donneCodeSens(&sResultat, &sCodeSens) ;
	string sUnitSens ;
	pSuper->getDico()->donneCodeSens(&sUnite, &sUnitSens) ;

	if (sCodeSens == sUnitSens)
		return true ;

	string sLieASens ;
	pSuper->getDico()->donneCodeSens(&sLieA, &sLieASens) ;

	bool bTrouve = false ;
	//
	// On regarde si c'est li� � une donn�e particuli�re
	//
	if (sLieA != "")
	{
		sCode = sCodeSens + "CV" + sUnitSens + sLieASens ;
		lastError = chercheClef(&sCode,
                            "",
                            0,
                            keySEARCHEQ,
                            dbiWRITELOCK
                           		);
		if (lastError == DBIERR_NONE)
    	bTrouve = true ;
	}
	if (!bTrouve)
	{
		sCode = sCodeSens + "CV" + sUnitSens ;
		lastError = chercheClef(&sCode,
                            "",
                            0,
                            keySEARCHGEQ,
                            dbiWRITELOCK
                            	);
    if (lastError == DBIERR_NONE)
    	bTrouve = true ;
	}
	if (!bTrouve)
		return false ;

	lastError = getRecord() ;
	if (lastError != DBIERR_NONE)
	{
		erreur("Le fichier de conversion semble endommag�.", standardError, lastError) ;
    return false ;
	}

	// Good record ?
  if ((string(pDonnees->resultat) != sCodeSens) ||
  		(string(pDonnees->operation) != "CV") ||
      (string(pDonnees->apartir) != sUnitSens) ||
			((string(pDonnees->quantite) != sLieASens) && (string(pDonnees->quantite) != "")))
		return false ;


	// 100 niveaux de piles
	double val[100] ;
	string ope[100] ;
	int	   nbNiv = 100 ;
	for (int j = 0; j < nbNiv; j++)
	{
  	val[j] = 0 ;
    ope[j] = "" ;
	}

	string sFormule = pDonnees->formule ;
	size_t  i = 0 ;
	int     pileur = 0 ;
	bool tourner = true ;
	while (tourner)
	{
		// Parenth�se ouvrante : on empile
    //
    if (sFormule[i] == '(')
    {
    	for (int j = nbNiv - 1; j > pileur; j++)
      {
      	val[j] = val[j-1] ;
				ope[j] = ope[j-1] ;
      }
      val[pileur] = 0 ;      ope[pileur] = "" ;
      i++ ;
    }
    //
    // Op�rateurs + - * / ^x, etc
    //
    else if (isOperator(sFormule[i]))
    {
    	ope[pileur] = string(1, sFormule[i]) ;
      i++ ;
    }
    //
    // Parenth�se fermante : on d�pile
    //
    else if (sFormule[i] == ')')
    {
    	while (ope[pileur+1] != "")
      {
      	val[pileur] = Operation(val[pileur+1], val[pileur], ope[pileur+1]) ;
        for (int j = pileur+1; j < nbNiv-1; j++)
        {
        	val[j] = val[j+1] ;
          ope[j] = ope[j+1] ;
        }
        val[nbNiv-1] = 0 ;
        ope[nbNiv-1] = "" ;
      }
      i++ ;
    }
    //
    // Crochet : valeur � convertir
    //
    else if (sFormule[i] == '[')
    {
    	i++ ;
      string sCode = "" ;
      while ((i < strlen(sFormule.c_str())) && (sFormule[i] != ']'))
      {
      	sCode += string(1, sFormule[i]) ;
        i++ ;
      }
      if (sFormule[i] == ']')
      	i++ ;
      else
      	return false ;

      if (sCode != sUnitSens)
      	return false ;

      if (ope[pileur] != "")
      	val[pileur] = Operation(val[pileur], *pValeur, ope[pileur]) ;
      else
      	val[pileur] = *pValeur ;
    }
    else if ((sFormule[i] >= '0') && (sFormule[i] <= '9'))
    {
    	string sNbre = string(1, sFormule[i]) ;
      i++ ;
      while ((i < strlen(sFormule.c_str())) &&
            	   (((sFormule[i] >= '0') && (sFormule[i] <= '9')) ||
                   	(sFormule[i] == '.')))
      {
      	sNbre += string(1, sFormule[i]) ;
        i++ ;
      }
      double dNbre = StringToDouble(sNbre) ;
      if (ope[pileur] != "")
      	val[pileur] = Operation(val[pileur], dNbre, ope[pileur]) ;
      else
      	val[pileur] = dNbre ;
    }
    else
    	i++ ;

    if (i >= strlen(sFormule.c_str()))
    	tourner = false ;
  }
  
  *pValeur = val[pileur] ;
	return true ;
}

double
NSCV::Operation(double dOperande, double dOperateur, string sOperation)
{
	if 		(sOperation == string("+"))
		return dOperande + dOperateur ;
	if (sOperation == string("-"))
		return dOperande - dOperateur ;
	if (sOperation == string("*"))
		return dOperande * dOperateur ;
	if (sOperation == string("/"))
		return dOperande / dOperateur ;
	if (sOperation == string("^"))
		return pow(dOperande, dOperateur) ;
  if (sOperation == string("�"))
  {
    if (double(10) == dOperande)
      return log10(dOperateur) ;
  }
	return 0 ;
}

bool
NSCV::isOperator(char cChar)
{
  switch (cChar)
  {
    case '+' :
    case '-' :
    case '*' :
    case '/' :
    case '^' :
    case '�' :
      return true ;
  }
  return false ;
}
