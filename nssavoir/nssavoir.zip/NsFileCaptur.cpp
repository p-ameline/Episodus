// -----------------------------------------------------------------------------// NsCaptur.cpp// -----------------------------------------------------------------------------
// Impl�mentation des m�thodes de capture
// 1�re version : PA Septembre 2001    Derni�re modif : Septembre 2001
// -----------------------------------------------------------------------------
#include "nautilus\nssuper.h"
#include "nautilus\nsepicap.h"
#include "partage\nsdivfct.h"
#include "nssavoir\nsfilecaptur.h"
#include "nssavoir\nssavoir.h"
#include "nsepisod\nsclasser.h"
#include "nsbb\nsbbtran.h"

NSCaptureFromHPRIM::NSCaptureFromHPRIM(NSContexte* pCtx)
                   :NSRoot(pCtx)
{
	sFileName    = string("") ;
	sFileContent = string("") ;
}

NSCaptureFromHPRIM::~NSCaptureFromHPRIM()
{
}

/*
bool
NSCaptureFromHPRIM::importHPRIM2(NSCaptureArray* pCaptureArray, NSPatPathoArray* pPPT)
{
	if (sFileName == string(""))
		return false ;

	ifstream inFile ;
	string sLine ;
	string sText = "" ;

	inFile.open(sFileName.c_str());	if (!inFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
    return false ;
	}

  parseHPRIM1header(&inFile, pCaptureArray, pPPT) ;

  NSEpiFlechiesDB flechiesDB(pContexte) ;

  bool bFinFound = false ;
  bool bFinFichierFound = false ;

  bool bValueWelcomed = false ;

  bool bLabTagFound = false ;

  // On saute tout jusqu'� la balise LAB
  //
  while (!inFile.eof() && !bLabTagFound)
	{
  	getline(inFile, sLine) ;

    string sStripLine = sLine ;
    strip(sStripLine, stripBoth) ;

    if (sStripLine == string("****LAB****"))
    	bLabTagFound = true ;
	}

  // no LAB tag : not HPRIM2
  //
  if (!bLabTagFound)
  {
  	inFile.close() ;
    return false ;
  }

  string sConcept   = string("") ;
  string sResType   = string("") ;
	string sNormality = string("") ;
  string sResStatus = string("") ;
  string sValue     = string("") ;
  string sUnit      = string("") ;
  string sNormInf   = string("") ;
  string sNormSup   = string("") ;
  string sValue2    = string("") ;
  string sUnit2     = string("") ;
  string sNormInf2  = string("") ;
  string sNormSup2  = string("") ;

	while (!inFile.eof())
	{
  	getline(inFile, sLine) ;

    string sStripLine = sLine ;
    strip(sStripLine, stripBoth) ;

    if (sStripLine == string("****FIN****"))
    	bFinFound = true ;
    else if (sStripLine == string("****FINFICHIER****"))
    	bFinFichierFound = true ;
    else if ((sStripLine != string("")) && (strlen(sStripLine.c_str()) > 4))
    {
      NSPatPathoArray PPTnum(pContexte) ;

    	// text: we try to analyze it
      //
      if (string(sStripLine, 0, 4) == string("TEX|"))
      {
      	sStripLine = string(sStripLine, 4, strlen(sStripLine.c_str()) - 4) ;

    		// What is it ?
      	string sPattern = string("") ;

      	// Title ?
      	string sResult = flechiesDB.getCodeLexiq(sStripLine, 'T') ;
  			if (sResult == string(""))
      		sResult = flechiesDB.getCodeLexiq(sStripLine, 'G') ;
      	if (sResult == string(""))
      		sResult = flechiesDB.getCodeLexiq(sStripLine, 'Z') ;

      	// value
      	if (sResult == string(""))
      	{
      		analysedCapture aCapt(pContexte, sStripLine, 0) ;
      		ParseElemArray aRawParseResult ;
      		ParseElemArray aSemanticParseResult ;
      		aCapt.getSemanticParseElemArray(&aRawParseResult, &aSemanticParseResult) ;
        	//
        	// We only use the information if it has been fully recognized
        	// elsewhere, it can lead to much stupid behaviour
        	//
        	bool bFullSuccess ;
      		sPattern = aCapt.getNumPattern(&aRawParseResult, &aSemanticParseResult, &bFullSuccess) ;
        	if (sPattern != string(""))
          {
          	// We try to get the concept here, because sometimes, the RES
            // information only contains sender specific codes
            //
          	string sResult = aCapt.getElementByTagInNumPattern(sPattern, 'V') ;
            if (sResult != string(""))
            	sConcept = sResult ;

        		if (!bFullSuccess)
          		bValueWelcomed = false ;
          	else
          	{
        			if (sConcept != "")
          			bValueWelcomed = true ;
          	}
        	}
        }

      	int iCol = 0 ;
      	if (sResult != string(""))
      		iCol = 0 ;
      	else
      	{
      		if (!PPTnum.empty())
        	{
        		size_t posValue = sPattern.find("[V") ;
          	if (posValue != NPOS)
          		iCol = 0 ;
          	else
          		iCol = 1 ;
        	}
      	}

    		// Pushing the text
      	//
    		Message theMessage("", "", "", "A", "", "", "") ;
      	theMessage.SetTexteLibre(sStripLine) ;
      	pPPT->ajoutePatho("�?????", &theMessage, iCol) ;
      }
      //
      // RES: structured part
      //
      else if (string(sStripLine, 0, 4) == string("RES|"))
      {
      	// RES-01 Type de segment RES
				// RES-02 Libell� de l'analyse         En texte clair
				// RES-03 Code de l'analyse D�fini par le m�decin ou selon codification retenue par la commission technique HPRIM
				// RES-04 Type de r�sultat             A pour num�rique, N pour num�rique, C pour code
				// RES-05 R�sultat 1                   Les r�sultats num�riques doivent �tre transmis sans espace ni virgule.
        //                                     Le s�parateur d�cimal est le point.
        //                                     Un r�sultat num�rique peut �tre pr�c�d� de son signe + ou -
				// RES-06 Unit� 1                      Les unit�s sont exprim�es en syst�me MKSA
				// RES-07 Valeur normale inf�rieure 1
				// RES-08 Valeur normale sup�rieure 1
				// RES-09 Indicateur d'anormalit�      L  inf�rieur � la normale
				//                                     H  sup�rieur � la normale
				//                                     LL inf�rieur � la valeur panique basse
				//                                     HH sup�rieur � la valeur panique haute
				//                                     N  normal
				// RES-10 Statut du r�sultat           F  valid�
        //                                     R  non valid�
				//                                     C  modifi�, corrig�
				// RES-11 R�sultat 2                   Ce  champ et les 3 suivants permettent de communiquer le r�sultat dans une deuxi�me unit�
				// RES-12 Unit� 2
				// RES-13 Valeur normale inf�rieure 2
				// RES-14 Valeur normale sup�rieure 2

      	sStripLine = string(sStripLine, 4, strlen(sStripLine.c_str()) - 4) ;

        int    iNumInfo = 0 ;
        int    iNumSerie = 0 ;

        while (sStripLine != string(""))
        {
        	size_t posPipe = sStripLine.find("|") ;

        	if (posPipe > 0)
          {
          	string sResData ;

          	if (posPipe == NPOS)
            	sResData = sStripLine ;
            else
          		sResData = string(sStripLine, 0, posPipe) ;

            string sResult = string("") ;

            switch (iNumInfo)
            {
              case 0 :
              	sResult = flechiesDB.getCodeLexiq(sResData, 'V') ;
                if (sResult != string(""))
                	sConcept = sResult ;
                break ;
              case 1 :
              	sResult = flechiesDB.getCodeLexiq(sResData, 'V') ;
                if (sResult != string(""))
                	sConcept = sResult ;
                break ;
              case 2 :
              	sResType = sResData ;
                break ;
              case 3 :
              	sValue = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                break ;
              case 4 :
              	sResult = flechiesDB.getCodeLexiq(sResData, '2') ;
                if (sResult != string(""))
                	sUnit = sResult ;
                break ;
              case 5 :
              	sNormInf = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                break ;
              case 6 :
              	sNormSup = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                break ;
              case 7 :
              	sNormality = sResData ;
                break ;
              case 8 :
              	sResStatus = sResData ;
                break ;
              case 9 :
              	sValue2 = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                break ;
              case 10 :
              	sResult = flechiesDB.getCodeLexiq(sResData, '2') ;
                if (sResult != string(""))
                	sUnit2 = sResult ;
                break ;
              case 11 :
              	sNormInf2 = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                break ;
              case 12 :
              	sNormSup2 = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                break ;
          	}

          	if (posPipe < strlen(sStripLine.c_str()) - 1)
          		sStripLine = string(sStripLine, posPipe + 1, strlen(sStripLine.c_str()) - posPipe - 1) ;
            else
            	sStripLine = string("") ;
          }
          //
          // Empty entry
          //
          else
          {
						sStripLine = string(sStripLine, 1, strlen(sStripLine.c_str()) - 1) ;
            if      (iNumInfo == 4)
            	sUnit  = "200001" ;
            else if (iNumInfo == 10)
            	sUnit2 = "200001" ;
          }

          iNumInfo++ ;
        }

        if (sConcept != string(""))
        {
        	pPPT->ajoutePatho(sConcept, 1, 1) ;

          bool bValuesFound = false ;

        	if ((sValue != string("")) && (sUnit != string("")))
          {
          	bValuesFound = true ;

          	Message theMessage("", "", "", "A", "", "", "") ;
      			theMessage.SetComplement(sValue) ;
            theMessage.SetUnit(sUnit) ;
            pPPT->ajoutePatho("�N0;03", &theMessage, 2, 1) ;

          	if (sNormInf != string(""))
          	{
          		pPPT->ajoutePatho("VNOMI1", 2, 1) ;

            	Message theMessage("", "", "", "A", "", "", "") ;
      				theMessage.SetComplement(sNormInf) ;
            	theMessage.SetUnit(sUnit) ;
            	pPPT->ajoutePatho("�N0;03", &theMessage, 3, 1) ;
          	}
          	if (sNormSup != string(""))
          	{
          		pPPT->ajoutePatho("VNOMS1", 2, 1) ;

            	Message theMessage("", "", "", "A", "", "", "") ;
      				theMessage.SetComplement(sNormSup) ;
            	theMessage.SetUnit(sUnit) ;
            	pPPT->ajoutePatho("�N0;03", &theMessage, 3, 1) ;
          	}
          }
          if ((sValue2 != string("")) && (sUnit2 != string("")))
          {
          	bValuesFound = true ;

          	Message theMessage("", "", "", "A", "", "", "") ;
      			theMessage.SetComplement(sValue2) ;
            theMessage.SetUnit(sUnit2) ;
            pPPT->ajoutePatho("�N0;03", &theMessage, 2, 1) ;

          	if (sNormInf2 != string(""))
          	{
          		pPPT->ajoutePatho("VNOMI1", 2, 1) ;

            	Message theMessage("", "", "", "A", "", "", "") ;
      				theMessage.SetComplement(sNormInf2) ;
            	theMessage.SetUnit(sUnit2) ;
            	pPPT->ajoutePatho("�N0;03", &theMessage, 3, 1) ;
          	}
          	if (sNormSup2 != string(""))
          	{
          		pPPT->ajoutePatho("VNOMS1", 2, 1) ;

            	Message theMessage("", "", "", "A", "", "", "") ;
      				theMessage.SetComplement(sNormSup2) ;
            	theMessage.SetUnit(sUnit2) ;
            	pPPT->ajoutePatho("�N0;03", &theMessage, 3, 1) ;
          	}
          }
          if (bValuesFound)
          {
          	PatPathoIter iterPere = pPPT->end() ;
          	iterPere-- ;
          	pPPT->InserePatPathoFille(iterPere, &PPTnum) ;
          }
        }

      	sConcept   = string("") ;
        sResType   = string("") ;
				sNormality = string("") ;
				sResStatus = string("") ;
				sValue     = string("") ;
				sUnit      = string("") ;
				sNormInf   = string("") ;
				sNormSup   = string("") ;
				sValue2    = string("") ;
				sUnit2     = string("") ;
				sNormInf2  = string("") ;
				sNormSup2  = string("") ;
      }
    }
  }

	inFile.close() ;

  if (!bFinFound || !bFinFichierFound)
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("hprimManagement", "endOfFileMarkupsNotFound") ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
  }

  return true ;
}
*/

bool
NSCaptureFromHPRIM::importHPRIM2(NSCaptureArray* pCaptureArray, NSPatPathoArray* pPPT, int* iAlertLevel, string* pLogMessage, bool *pbValidHeader)
{
	if (sFileName == string(""))
		return false ;

	ifstream inFile ;
	string sLine ;
	string sText = "" ;

	inFile.open(sFileName.c_str());	if (!inFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
    return false ;
	}

  // Parse header
  //
  string sLabName = string("") ;
  string sDocName = string("") ;
  bool bHeaderValidity = parseHPRIM1header(&inFile, pCaptureArray, pPPT, pLogMessage, &sLabName, &sDocName) ;
  if (NULL != pbValidHeader)
    *pbValidHeader = bHeaderValidity ;

  // Parse text
  //
  bool bLabTagFound = false ;
  bool bGoodParsing = parseHPRIM1text(&inFile, pPPT, &bLabTagFound) ;

  // no LAB tag : not HPRIM2
  //
  if (!bLabTagFound)
  {
  	inFile.close() ;
    return false ;
  }

  NSEpiFlechiesDB flechiesDB(pContexte) ;

  bool bFinFound = false ;
  bool bFinFichierFound = false ;

  bool bValueWelcomed = false ;

  string sConcept   = string("") ;
  string sResType   = string("") ;
	string sNormality = string("") ;
  string sResStatus = string("") ;
  string sValue     = string("") ;
  string sUnit      = string("") ;
  string sNormInf   = string("") ;
  string sNormSup   = string("") ;
  string sValue2    = string("") ;
  string sUnit2     = string("") ;
  string sNormInf2  = string("") ;
  string sNormSup2  = string("") ;

  string sLogText   = string("") ;

  PatPathoIter iterReference = NULL ;
  bool bTextFound = false ;

  bool bTextTagExist = false ;

	while (!inFile.eof())
	{
  	getline(inFile, sLine) ;

    string sStripLine = sLine ;
    strip(sStripLine, stripBoth) ;

    if (sStripLine == string("****FIN****"))
    	bFinFound = true ;
    else if (sStripLine == string("****FINFICHIER****"))
    	bFinFichierFound = true ;
    else if ((sStripLine != string("")) && (strlen(sStripLine.c_str()) > 4))
    {
      NSPatPathoArray PPTnum(pContexte) ;

    	// text: we try to analyze it
      //
      if (string(sStripLine, 0, 4) == string("TEX|"))
      {
      	bTextTagExist = true ;

      	sStripLine = string(sStripLine, 4, strlen(sStripLine.c_str()) - 4) ;
        strip(sStripLine, stripBoth) ;

        iterReference = findStringInPatPatho(sStripLine, pPPT) ;
        if ((iterReference != NULL) && (iterReference != pPPT->end()))
        	bTextFound = true ;
      }
      //
      // RES: structured part
      //
      else if (string(sStripLine, 0, 4) == string("RES|"))
      {
      	// RES-01 Type de segment RES
				// RES-02 Libell� de l'analyse         En texte clair
				// RES-03 Code de l'analyse D�fini par le m�decin ou selon codification retenue par la commission technique HPRIM
				// RES-04 Type de r�sultat             A pour num�rique, N pour num�rique, C pour code
				// RES-05 R�sultat 1                   Les r�sultats num�riques doivent �tre transmis sans espace ni virgule.
        //                                     Le s�parateur d�cimal est le point.
        //                                     Un r�sultat num�rique peut �tre pr�c�d� de son signe + ou -
				// RES-06 Unit� 1                      Les unit�s sont exprim�es en syst�me MKSA
				// RES-07 Valeur normale inf�rieure 1
				// RES-08 Valeur normale sup�rieure 1
				// RES-09 Indicateur d'anormalit�      L  inf�rieur � la normale
				//                                     H  sup�rieur � la normale
				//                                     LL inf�rieur � la valeur panique basse
				//                                     HH sup�rieur � la valeur panique haute
				//                                     N  normal
				// RES-10 Statut du r�sultat           F  valid�
        //                                     R  non valid�
				//                                     C  modifi�, corrig�
				// RES-11 R�sultat 2                   Ce  champ et les 3 suivants permettent de communiquer le r�sultat dans une deuxi�me unit�
				// RES-12 Unit� 2
				// RES-13 Valeur normale inf�rieure 2
				// RES-14 Valeur normale sup�rieure 2

      	sStripLine = string(sStripLine, 4, strlen(sStripLine.c_str()) - 4) ;
        strip(sStripLine, stripBoth) ;

        int    iNumInfo = 0 ;

        while (string("") != sStripLine)
        {
        	size_t posPipe = sStripLine.find("|") ;

        	if (posPipe > 0)
          {
          	string sResData ;

          	if (posPipe == NPOS)
            	sResData = sStripLine ;
            else
          		sResData = string(sStripLine, 0, posPipe) ;

            strip(sResData, stripBoth) ;

            string sResult = string("") ;

            switch (iNumInfo)
            {
              case 0 :
              	sResult = flechiesDB.getCodeLexiq(sResData, 'V') ;
                if (sResult != string(""))
                	sConcept = sResult ;
                else
                {
                	sLogText = pContexte->getSuperviseur()->getText("fileImport", "warningUnknownConcept") ;
									*pLogMessage += sLogText + string(": ") + sResData + string("\r\n") ;
                }
                break ;
              case 1 :
              	sResult = string("") ;
              	if (string("") != sLabName)
                	sResult = flechiesDB.getCodeLexiq(sLabName + string(".") + sResData, 'V') ;
                if (string("") == sResult)
              		sResult = flechiesDB.getCodeLexiq(sResData, 'V') ;
                if (sResult != string(""))
                	sConcept = sResult ;
                else
                {
                	sLogText = pContexte->getSuperviseur()->getText("fileImport", "warningUnknownConcept") ;
									*pLogMessage += sLogText + string(": ") + sResData + string("\r\n") ;
                }
                break ;
              case 2 :
              	sResType = sResData ;
                break ;
              case 3 :
              	sValue = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                break ;
              case 4 :
              	sResult = flechiesDB.getCodeLexiq(sResData, '2') ;
                if (sResult != string(""))
                	sUnit = sResult ;
                else
                {
                	sLogText = pContexte->getSuperviseur()->getText("fileImport", "warningUnknownUnit") ;
									*pLogMessage += sLogText + string(": ") + sResData + string("\r\n") ;
                }
                break ;
              case 5 :
              	sNormInf = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                break ;
              case 6 :
              	sNormSup = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                break ;
              case 7 :
              	sNormality = sResData ;
                if (((sResData == string("LL")) || (sResData == string("HH"))) &&
                    (*iAlertLevel < 2))
                	*iAlertLevel = 2 ;
                else if (((sResData == string("L")) || (sResData == string("H"))) &&
                    (*iAlertLevel < 1))
                	*iAlertLevel = 1 ;
                break ;
              case 8 :
              	sResStatus = sResData ;
                break ;
              case 9 :
              	sValue2 = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                break ;
              case 10 :
              	sResult = flechiesDB.getCodeLexiq(sResData, '2') ;
                if (sResult != string(""))
                	sUnit2 = sResult ;
                else
                {
                	sLogText = pContexte->getSuperviseur()->getText("fileImport", "warningUnknownSecondUnit") ;
									*pLogMessage += sLogText + string(": ") + sResData + string("\r\n") ;
                }
                break ;
              case 11 :
              	sNormInf2 = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                break ;
              case 12 :
              	sNormSup2 = getEpisodusNumValueFromRawCapturedNum(sResData) ;
                break ;
          	}

          	if (posPipe < strlen(sStripLine.c_str()) - 1)
          		sStripLine = string(sStripLine, posPipe + 1, strlen(sStripLine.c_str()) - posPipe - 1) ;
            else
            	sStripLine = string("") ;
          }
          //
          // Empty entry
          //
          else
          {
						sStripLine = string(sStripLine, 1, strlen(sStripLine.c_str()) - 1) ;
            if      (iNumInfo == 4)
            	sUnit  = "200001" ;
            else if (iNumInfo == 10)
            	sUnit2 = "200001" ;
          }

          iNumInfo++ ;
        }

        if (string("") != sConcept)
        {
        	PPTnum.ajoutePatho(sConcept, 0) ;

          bool bValuesFound = false ;

        	if ((string("") != sValue) && (string("") != sUnit))
          {
          	bValuesFound = true ;

          	Message theMessage ;
      			theMessage.SetComplement(sValue) ;
            theMessage.SetUnit(sUnit) ;
            PPTnum.ajoutePatho("�N0;03", &theMessage, 1) ;

            if ((sNormInf == string("0")) && (sNormSup == string("0")))
            {
            	sNormInf = string("") ;
              sNormSup = string("") ;
            }

          	if (sNormInf != string(""))
          	{
          		PPTnum.ajoutePatho("VNOMI1", 1) ;

            	Message theMessage ;
      				theMessage.SetComplement(sNormInf) ;
            	theMessage.SetUnit(sUnit) ;
            	PPTnum.ajoutePatho("�N0;03", &theMessage, 2) ;
          	}
          	if (sNormSup != string(""))
          	{
          		PPTnum.ajoutePatho("VNOMS1", 1) ;

            	Message theMessage ;
      				theMessage.SetComplement(sNormSup) ;
            	theMessage.SetUnit(sUnit) ;
            	PPTnum.ajoutePatho("�N0;03", &theMessage, 2) ;
          	}
          }
          else
        	{
        		sLogText = pContexte->getSuperviseur()->getText("fileImport", "errorMissingValueOrUnit") ;
          	*pLogMessage += sLogText + string("\r\n") ;
        	}

          if ((sValue2 != string("")) && (sUnit2 != string("")))
          {
          	bValuesFound = true ;

          	Message theMessage ;
      			theMessage.SetComplement(sValue2) ;
            theMessage.SetUnit(sUnit2) ;
            PPTnum.ajoutePatho("�N0;03", &theMessage, 1) ;

            if ((sNormInf2 == string("0")) && (sNormSup2 == string("0")))
            {
            	sNormInf2 = string("") ;
              sNormSup2 = string("") ;
            }

          	if (sNormInf2 != string(""))
          	{
          		PPTnum.ajoutePatho("VNOMI1", 1) ;

            	Message theMessage ;
      				theMessage.SetComplement(sNormInf2) ;
            	theMessage.SetUnit(sUnit2) ;
            	PPTnum.ajoutePatho("�N0;03", &theMessage, 2) ;
          	}
          	if (sNormSup2 != string(""))
          	{
          		PPTnum.ajoutePatho("VNOMS1", 1) ;

            	Message theMessage ;
      				theMessage.SetComplement(sNormSup2) ;
            	theMessage.SetUnit(sUnit2) ;
            	PPTnum.ajoutePatho("�N0;03", &theMessage, 2) ;
          	}
          }
          else
        	{
        		sLogText = pContexte->getSuperviseur()->getText("fileImport", "errorMissingSecondValueOrUnit") ;
          	*pLogMessage += sLogText + string("\r\n") ;
        	}

          if (bValuesFound)
          {
          	if (iterReference == NULL)
            	iterReference = pPPT->end() ;

            // If the same concept is already there, we kill it
            //
            string sConceptSens = pContexte->getSuperviseur()->getDico()->donneCodeSens(&sConcept) ;
            PatPathoIter iterConcept = pPPT->begin() ;
            for ( ; iterConcept != pPPT->end() ; iterConcept++)
            	if ((*iterConcept)->getLexiqueSens(pContexte) == sConceptSens)
              	break ;

            // Same concept found: merging
            //
						if (iterConcept != pPPT->end())
            {
            	NSPatPathoArray pptValues(pContexte) ;
            	PPTnum.ExtrairePatPatho(PPTnum.begin(), &pptValues) ;

              pPPT->mergePatpatho(&pptValues, &iterConcept) ;
            }
            // Same concept not found: adding
            //
            else
            {
            	// If reference is at end, we take the last father as reference
            	//
          		if (iterReference == pPPT->end())
            	{
          			iterReference-- ;
              	// int iRefColEnd = (*iterReference)->getColonne() ;
              	while ((iterReference != pPPT->begin()) &&
                     ((*iterReference)->getColonne() != 0))
              		iterReference-- ;
            	}
              // Inserting the structured values
            	//
          		pPPT->InserePatPathoFille(iterReference, &PPTnum) ;
            }

            if (!bTextTagExist)
            	iterReference = NULL ;
          }
        }
        else
        {
        	sLogText = pContexte->getSuperviseur()->getText("fileImport", "errorUnknownConcept") ;
          *pLogMessage += sLogText + string("\r\n") ;
        }

      	sConcept   = string("") ;
        sResType   = string("") ;
				sNormality = string("") ;
				sResStatus = string("") ;
				sValue     = string("") ;
				sUnit      = string("") ;
				sNormInf   = string("") ;
				sNormSup   = string("") ;
				sValue2    = string("") ;
				sUnit2     = string("") ;
				sNormInf2  = string("") ;
				sNormSup2  = string("") ;
      }
    }
  }

	inFile.close() ;

  if (!bFinFound || !bFinFichierFound)
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("hprimManagement", "endOfFileMarkupsNotFound") ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
  }

  return true ;
}

bool
NSCaptureFromHPRIM::importHPRIM1(NSCaptureArray* pCaptureArray, NSPatPathoArray* pPPT, string* pLogMessage, bool *pbValidHeader)
{
	if (sFileName == string(""))
		return false ;

	ifstream inFile ;
	string sLine ;
	string sText = "" ;

	inFile.open(sFileName.c_str());	if (!inFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
    return false ;
	}

  bool bHeaderValidity = parseHPRIM1header(&inFile, pCaptureArray, pPPT, pLogMessage) ;
  if (NULL != pbValidHeader)
    *pbValidHeader = bHeaderValidity ;

  bool bLabReached ;
  bool bGoodParsing = parseHPRIM1text(&inFile, pPPT, &bLabReached) ;

	inFile.close() ;

  if (!bGoodParsing)
  {
  	string sErrorText = pContexte->getSuperviseur()->getText("hprimManagement", "endOfFileMarkupsNotFound") ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
  }

  return true ;
}

bool
NSCaptureFromHPRIM::importTextContent(NSCaptureArray* pCaptureArray)
{
  if (NULL == pCaptureArray)
    return false ;

  ifstream inFile ;
	inFile.open(sFileName.c_str());
	if (!inFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
    return false ;
	}

  string sLine ;
	string sText = "" ;
  while (false == inFile.eof())
	{
    getline(inFile, sLine) ;
    if (string("") != sText)
      sText += string(" ") ;
    sText += sLine ;
  }

  return true ;
}

ImportedFileType
NSCaptureFromHPRIM::importHPRIMheader(NSCaptureArray* pCaptureArray, string* pLogMessage)
{
	if (sFileName == string(""))
		return FILETYPE_UNKNOWN ;

	ifstream inFile ;
	string sLine ;
	string sText = "" ;

	inFile.open(sFileName.c_str());	if (!inFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
    return FILETYPE_UNKNOWN ;
	}

  NSPatPathoArray* pPPT = NULL ;
	bool bGoodHeader = parseHPRIM1header(&inFile, pCaptureArray, pPPT, pLogMessage) ;

  if (!bGoodHeader)
  {
  	inFile.close() ;
    return FILETYPE_UNKNOWN ;
	}

	bool bFinFound        = false ;
  bool bFinFichierFound = false ;
  bool bLabTagFound     = false ;
  bool bMultiFile       = false ;

	while (!inFile.eof())
	{
  	getline(inFile, sLine) ;

    string sStripLine = sLine ;
    strip(sStripLine, stripBoth) ;

    if (sStripLine == string("****FIN****"))
    	bFinFound = true ;
    else if (sStripLine == string("****FINFICHIER****"))
    	bFinFichierFound = true ;
    else if (sStripLine == string("****LAB****"))
    	bLabTagFound = true ;
    else
    {
    	if ((sStripLine != string("")) && bFinFound)
      	bMultiFile = true ;
    }
	}
  inFile.close() ;

  if (bFinFound && bFinFichierFound)
  {
  	if (bLabTagFound)
    {
    	if (bMultiFile)
      	return FILETYPE_HPRIM2_MULTI ;
      else
    		return FILETYPE_HPRIM2 ;
    }
    else
    {
    	if (bMultiFile)
      	return FILETYPE_HPRIM1_MULTI ;
      else
      	return FILETYPE_HPRIM1 ;
    }
  }
  // Since header is good, we cannot return FILETYPE_UNKNOWN 
	return FILETYPE_HPRIM1 ;
}

string
NSCaptureFromHPRIM::getHPRIMBody()
{
	if (sFileName == string(""))
		return string("") ;

	ifstream inFile ;
	string sLine ;
	string sText = "" ;

	inFile.open(sFileName.c_str());	if (!inFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
    return string("") ;
	}

  // Skip header
  //
  size_t iNumLine = 0 ;
  while (!inFile.eof() && (iNumLine < HPRIMHEADER_LINESNB))
  {
  	getline(inFile, sLine) ;
    iNumLine++ ;
  }

	// Get body
  //
  string sResult = string("") ;

  bool bContinue = true ;
  while (!inFile.eof() && bContinue)
	{
  	getline(inFile, sLine) ;

    string sStripLine = sLine ;
    strip(sStripLine, stripBoth) ;

    if ((sStripLine == string("****FIN****")) ||
        (sStripLine == string("****FINFICHIER****")) ||
        (sStripLine == string("****LAB****")))
    	bContinue = false ;
    else
    	sResult += sLine + string("\n") ;
	}

  inFile.close() ;

  return sResult ;
}

bool
NSCaptureFromHPRIM::parseHPRIM1header(ifstream* pInFile, NSCaptureArray* pCaptureArray, NSPatPathoArray* pPPT, string* pLogMessage, string* pLabName, string* pDocName)
{
	if (!pInFile || !pCaptureArray)
		return false ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	// HPRIM Format
	// line 1 Patient ID (num or name + surname)
	//      2 Patient Familly name
	//      3 Patient name
	//      4 Adresse 1
	//      5 Adresse 2
	//      6 Code Postal / Ville
	//      7 Date Naissance
	//      8 No SS
	//      9 Code ?
	//     10 Date Examen
	//     11 Identifiant Labo
	//     12 Identifiant M�decin

  string asHeaderTable[HPRIMHEADER_LINESNB] ;
  size_t iCurrentSlotToFill = 0 ;

  for (int i = 0 ; i < HPRIMHEADER_LINESNB; i++)
  	asHeaderTable[i] = string("") ;

	// First step: loading header table 12 lines
  //
  // Notice: if we encouter a ****FIN**** we empty the header table and start
  //         filling it from line 0
  //
  string sLine ;

	string sLogText = pContexte->getSuperviseur()->getText("fileImport", "analysingHprimHeader") ;
  *pLogMessage += sLogText + string("\r\n") ;

  bool bSatisfied = false ;

  while (!pInFile->eof() && (!bSatisfied))
	{
    // Process a file line
    //
  	getline(*pInFile, sLine) ;

    strip(sLine, stripBoth) ;

    // Finding a FIN -> reseting headers lines
    //
    if (sLine == string("****FIN****"))
    {
			for (int i = 0 ; i < HPRIMHEADER_LINESNB; i++)
				asHeaderTable[i] = string("") ;
    	iCurrentSlotToFill = 0 ;
    }
    else if (sLine == string("****FINFICHIER****"))
    {
    	sLogText = pContexte->getSuperviseur()->getText("fileImport", "errorFinFichierTagEncountered") ;
			*pLogMessage += sLogText + string("\r\n") ;
    	return false ;
    }
    else
    {
    	asHeaderTable[iCurrentSlotToFill] = sLine ;
      iCurrentSlotToFill++ ;
    }

    // If header table is full, we check if it sounds good
    //
    if (iCurrentSlotToFill >= HPRIMHEADER_LINESNB)
    {
    	// If first line is empty, then check if
      //
    	if (asHeaderTable[0] == string(""))
      {
      	if ((asHeaderTable[1] == string("")) ||
            ((asHeaderTable[9] != string("")) && (asHeaderTable[9].find("/") == string::npos)))
        {
        	for (int i = 0 ; i < HPRIMHEADER_LINESNB - 1; i++)
						asHeaderTable[i] = asHeaderTable[i+1] ;
          iCurrentSlotToFill = HPRIMHEADER_LINESNB - 1 ;
        }
      	else
        	bSatisfied = true ;
      }
      else
      	bSatisfied = true ;
    }
	}

  // Second step: process the header table
  //
  for (int i = 0; i < HPRIMHEADER_LINESNB; i++)
	{
  	if (asHeaderTable[i] != string(""))
    {
    	string sPathString      = string("") ;
    	string sUnitString      = string("") ;
    	string sClassifString   = string("") ;
    	string sInformationDate = string("") ;

    	switch(i)
      {
      	case 1 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM01", asHeaderTable[i], sClassifString, sUnitString, sInformationDate)) ;
          sLogText = pContexte->getSuperviseur()->getText("fileImport", "hprimSurname") ;
          *pLogMessage += sLogText + string(": ") + asHeaderTable[i] + string("\r\n") ;
          break ;
        case 2 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM21", asHeaderTable[i], sClassifString, sUnitString, sInformationDate)) ;
          sLogText = pContexte->getSuperviseur()->getText("fileImport", "hprimFirstName") ;
          *pLogMessage += sLogText + string(": ") + asHeaderTable[i] + string("\r\n") ;
          break ;
        case 3 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LCOOR1/LADRE1/LADL11", asHeaderTable[i], sClassifString, sUnitString, sInformationDate)) ;
          sLogText = pContexte->getSuperviseur()->getText("fileImport", "hprimAddressFirstLine") ;
          *pLogMessage += sLogText + string(": ") + asHeaderTable[i] + string("\r\n") ;
          break ;
        case 4 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LCOOR1/LADRE1/LADL21", asHeaderTable[i], sClassifString, sUnitString, sInformationDate)) ;
          sLogText = pContexte->getSuperviseur()->getText("fileImport", "hprimAddressSecondLine") ;
          *pLogMessage += sLogText + string(": ") + asHeaderTable[i] + string("\r\n") ;
          break ;
        case 5 :
        	{
          	size_t blkPos = asHeaderTable[i].find(" ") ;
            if (blkPos != NPOS)
            {
            	string sZip  = string(asHeaderTable[i], 0, blkPos) ;
              string sCity = string(asHeaderTable[i], blkPos + 1, strlen(asHeaderTable[i].c_str()) - blkPos - 1) ;
              strip(sCity, stripBoth) ;
              pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LCOOR1/LADRE1/LVILL1/LZIP01", sZip, sClassifString, sUnitString, sInformationDate)) ;
              sLogText = pContexte->getSuperviseur()->getText("fileImport", "hprimZipCode") ;
							*pLogMessage += sLogText + string(": ") + sZip + string("\r\n") ;
              pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LCOOR1/LADRE1/LVILL1/LCOMU1", sCity, sClassifString, sUnitString, sInformationDate)) ;
              sLogText = pContexte->getSuperviseur()->getText("fileImport", "hprimCity") ;
							*pLogMessage += sLogText + string(": ") + sCity + string("\r\n") ;
            }
          }
          break ;
        //
        // Birthdate
        //
        case 6 :
        	{
          	string sDate = string("") ;

            string sBirthDate = asHeaderTable[i] ;

            if (strlen(sBirthDate.c_str()) >= 5)
            {                                      
              string sMonth = string(sBirthDate, 3, 2) ;

              // Warning : when the date comes from the french NIR, the month can indicate
              //           that this date is not known exactly :
              //           Le mois de naissance peut aussi �tre compris entre 30 et 42,
              //           entre 50 et 99 ou �gal � 20 ou 99 ; pour les personnes dont
              //           on ne conna�t pas le mois de naissance du fait d�absence
              //           de registre d��tat civil dans certains pays �trangers.
              //
              int iMonth = atoi(sMonth.c_str()) ;
              if (iMonth > 12)
              {
            	  if ((iMonth == 20) || (iMonth == 99) || ((iMonth >= 30) && (iMonth <= 42)) || ((iMonth >= 50) && (iMonth <= 99)))
                {
              	  sBirthDate[3] = '0' ;
                  sBirthDate[4] = '1' ;

                  sLogText = pContexte->getSuperviseur()->getText("fileImport", "hprimBirthDateAdapted") ;
								  *pLogMessage += sLogText + string(": ") + asHeaderTable[i] + string(" -> ") + sBirthDate + string("\r\n") ;
							  }
              }
            }
          	//
          	// JJ/MM/AA
            //
          	if (strlen(sBirthDate.c_str()) == 8)
            {
          		NVLdVTemps currentDate ;
            	currentDate.takeTime() ;
            	string sCurrentDate = currentDate.donneDate() ;
            	string sTreshold = string(sCurrentDate, 2, 2) ;

            	sDate = getDateFromHPRIM1date(sBirthDate, sTreshold) ;
            }
            //
            // JJ/MM/AAAA
            //
            else if (strlen(sBirthDate.c_str()) == 10)
            	donne_date_inverse(sBirthDate, sDate, sLang) ;

            if (sDate != string(""))
            {
            	pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/KNAIS1", sDate, sClassifString, "2DA011", sInformationDate)) ;
              sLogText = pContexte->getSuperviseur()->getText("fileImport", "hprimBirthDate") ;
							*pLogMessage += sLogText + string(": ") + sDate + string("\r\n") ;
            }
            else
            {
            	sLogText = pContexte->getSuperviseur()->getText("fileImport", "errorInvalidBirthDate") ;
							*pLogMessage += sLogText + string(": ") + asHeaderTable[i] + string("\r\n") ;
            	return false ;
            }
          }
          break ;
        //
        // NSS (get gender from it)
        //
        case 7 :
        {
        	string sNIR    = string("") ;
          string sNIRkey = string("") ;

          size_t blkPos = asHeaderTable[i].find(" ") ;
          if (blkPos != NPOS)
          {
          	sNIR    = string(asHeaderTable[i], 0, blkPos) ;
            sNIRkey = string(asHeaderTable[i], blkPos + 1, strlen(asHeaderTable[i].c_str()) - blkPos - 1) ;
            strip(sNIRkey, stripBoth) ;
          }
          else
          	sNIR = asHeaderTable[i] ;

          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LFRAN1/LFRAB1", sNIR, sClassifString, sUnitString, sInformationDate)) ;
          sLogText = pContexte->getSuperviseur()->getText("fileImport", "hprimNir") ;
          *pLogMessage += sLogText + string(": ") + sNIR + string("\r\n") ;

          if      (sNIR[0] == '1')
          	pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LSEXE1", "HMASC2", sClassifString, sUnitString, sInformationDate)) ;
          else if (sNIR[0] == '2')
          	pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LSEXE1", "HFEMI2", sClassifString, sUnitString, sInformationDate)) ;


          if (sNIRkey != string(""))
          {
          	pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LFRAN1/LFRAV1", sNIRkey, sClassifString, sUnitString, sInformationDate)) ;
            sLogText = pContexte->getSuperviseur()->getText("fileImport", "hprimNirKey") ;
          	*pLogMessage += sLogText + string(": ") + sNIR + string("\r\n") ;
          }
        }
        	break ;

        //
        // Document's date (warning, it can be something like "M-5128-23/10/06")
        //
        // No (understandable) document date means bad header
        //
        case 9 :
        	{
          	// First, find the date inside the string
            size_t iPos = asHeaderTable[i].find("/") ;
            if (iPos == string::npos)
            {
            	sLogText = pContexte->getSuperviseur()->getText("fileImport", "errorDocumentDateWithoutSlash") ;
							*pLogMessage += sLogText + string(": ") + asHeaderTable[i] + string("\r\n") ;
            	return false ;
            }

            size_t iPos2 = asHeaderTable[i].find("/", iPos + 1) ;
            if (iPos2 != iPos + 3)
            {
            	sLogText = pContexte->getSuperviseur()->getText("fileImport", "errorDocumentDateIllSeparatedSlash") ;
							*pLogMessage += sLogText + string(": ") + asHeaderTable[i] + string("\r\n") ;
            	return false ;
            }

            size_t iLength = strlen(asHeaderTable[i].c_str()) ;
            if ((iPos + 6 <= iLength))
            {
            	string sRawDate = string(asHeaderTable[i], iPos-2, 8) ;
              //
              // 8 or 10 digits date means that 8 first digit are a valid date
              //
          		string sDate = getDateFromHPRIM1date(sRawDate, "") ;
              if (sDate == string(""))
              {
              	sLogText = pContexte->getSuperviseur()->getText("fileImport", "errorDocumentDateIsInvalid") ;
								*pLogMessage += sLogText + string(": ") + sRawDate +  string("\r\n") ;
              	return false ;
              }

              // Check if it is not a 10 digits date
              if ((iPos + 8 <= iLength) && (isdigit(asHeaderTable[i][iPos + 6])) && (isdigit(asHeaderTable[i][iPos + 7])))
              {
              	sRawDate = string(asHeaderTable[i], iPos-2, 10) ;
            		donne_date_inverse(sRawDate, sDate, sLang) ;
              }

            	if (sDate != string(""))
            	{
              	if (NULL != pPPT)
              	{
            			pPPT->ajoutePatho("KCHIR2", 0) ;
									Message theMessage ;
    							theMessage.SetUnit("2DA011") ;
									theMessage.SetComplement(sDate) ;
									pPPT->ajoutePatho("�D0;10", &theMessage, 1) ;
              	}
              	else
                {
              		pCaptureArray->ajouter(new NSCapture(pContexte, "KCHIR2", sDate, sClassifString, "2DA011", sInformationDate)) ;
                  sLogText = pContexte->getSuperviseur()->getText("fileImport", "hprimDocumentDate") ;
          				*pLogMessage += sLogText + string(": ") + sDate + string("\r\n") ;
          			}
            	}
              else
              {
              	sLogText = pContexte->getSuperviseur()->getText("fileImport", "errorDocumentDateWithoutSlash") ;
								*pLogMessage += sLogText + string(": ") + asHeaderTable[i] + string("\r\n") ;
              	return false ;
              }
            }
          }
        //
        // Lab's name
        //
        case 10 :
          	if (NULL != pLabName)
            	*pLabName = asHeaderTable[i] ;
          	break ;
        //
        // Doctor's name
        //
        case 12 :
          	if (NULL != pDocName)
            	*pDocName = asHeaderTable[i] ;
          	break ;
      }
    }
	}
  sLogText = pContexte->getSuperviseur()->getText("fileImport", "goodHprimHeader") ;
  *pLogMessage += sLogText + string("\r\n") ;
  return true ;
}

/*
bool
NSCaptureFromHPRIM::parseHPRIM1header(ifstream* pInFile, NSCaptureArray* pCaptureArray, NSPatPathoArray* pPPT)
{
	if (!pInFile || !pCaptureArray)
		return false ;

	string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

	// HPRIM Format
	// line 1 Patient ID (num or name + surname)
	//      2 Patient Familly name
	//      3 Patient name
	//      4 Adresse 1
	//      5 Adresse 2
	//      6 Code Postal / Ville
	//      7 Date Naissance
	//      8 No SS
	//      9 Code ?
	//     10 Date Examen
	//     11 Identifiant Labo
	//     12 Identifiant M�decin

	// Loading header
  //
  size_t iNumLine = 0 ;
  string sLine ;

  while (!pInFile->eof() && (iNumLine < HPRIMHEADER_LINESNB))
	{
  	getline(*pInFile, sLine) ;

    string sPathString      = string("") ;
    string sUnitString      = string("") ;
    string sClassifString   = string("") ;
    string sInformationDate = string("") ;

    strip(sLine, stripBoth) ;

    if (sLine != string(""))
    {
    	switch(iNumLine)
      {
      	case 1 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM01", sLine, sClassifString, sUnitString, sInformationDate)) ;
          break ;
        case 2 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LNOM21", sLine, sClassifString, sUnitString, sInformationDate)) ;
          break ;
        case 3 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LCOOR1/LADRE1/LADL11", sLine, sClassifString, sUnitString, sInformationDate)) ;
          break ;
        case 4 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LCOOR1/LADRE1/LADL21", sLine, sClassifString, sUnitString, sInformationDate)) ;
          break ;
        case 5 :
        	{
          	size_t blkPos = sLine.find(" ") ;
            if (blkPos != NPOS)
            {
            	string sZip  = string(sLine, 0, blkPos) ;
              string sCity = string(sLine, blkPos + 1, strlen(sLine.c_str()) - blkPos - 1) ;
              strip(sCity, stripBoth) ;
              pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LCOOR1/LADRE1/LVILL1/LZIP01", sZip, sClassifString, sUnitString, sInformationDate)) ;
              pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LCOOR1/LADRE1/LVILL1/LCOMU1", sCity, sClassifString, sUnitString, sInformationDate)) ;
            }
          }
          break ;
        //
        // Birthdate
        //
        case 6 :
        	{
          	string sDate = string("") ;
          	//
          	// JJ/MM/AA
            //
          	if (strlen(sLine.c_str()) == 8)
            {
          		NVLdVTemps currentDate ;
            	currentDate.takeTime() ;
            	string sCurrentDate = currentDate.donneDate() ;
            	string sTreshold = string(sCurrentDate, 2, 2) ;

            	sDate = getDateFromHPRIM1date(sLine, sTreshold) ;
            }
            //
            // JJ/MM/AAAA
            //
            else if (strlen(sLine.c_str()) == 10)
            	donne_date_inverse(sLine, sDate, sLang) ;

            if (sDate != string(""))
            	pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/KNAIS1", sDate, sClassifString, "2DA011", sInformationDate)) ;
          }
          break ;
        //
        // NSS (get gender from it)
        //
        case 7 :
          pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LFRAN1/LFRAB1", sLine, sClassifString, sUnitString, sInformationDate)) ;
          if      (sLine[0] == '1')
          	pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LSEXE1", "HMASC2", sClassifString, sUnitString, sInformationDate)) ;
          else if (sLine[0] == '2')
          	pCaptureArray->ajouter(new NSCapture(pContexte, "ZADMI1/LIDET1/LSEXE1", "HFEMI2", sClassifString, sUnitString, sInformationDate)) ;
          break ;
        //
        // Document's date
        //
        case 9 :
        	{
          	string sDate = string("") ;

          	// JJ/MM/AA
          	if (strlen(sLine.c_str()) == 8)
            	sDate = getDateFromHPRIM1date(sLine, "") ;
            // JJ/MM/AAAA
            else if (strlen(sLine.c_str()) == 10)
            	donne_date_inverse(sLine, sDate, sLang) ;

            M-5128-23/10/06

            if (sDate != string(""))
            {
              if (NULL != pPPT)
              {
            		pPPT->ajoutePatho("KCHIR2", 0) ;
								Message theMessage("", "", "", "A", "", "", "") ;
    						theMessage.SetUnit("2DA011") ;
								theMessage.SetComplement(sDate) ;
								pPPT->ajoutePatho("�D0;10", &theMessage, 1, 1) ;
              }
              else
              	pCaptureArray->ajouter(new NSCapture(pContexte, "KCHIR2", sDate, sClassifString, "2DA011", sInformationDate)) ;
            }
          }
      }
    }
    iNumLine++ ;
  }
  return true ;
}
*/

bool
NSCaptureFromHPRIM::parseHPRIM1text(ifstream* pInFile, NSPatPathoArray* pPPT, bool* pbStoppedOnLab)
{
	if (!pInFile || !pPPT)
		return false ;

	NSEpiFlechiesDB flechiesDB(pContexte) ;

  bool bLabFound = false ;
  bool bFinFound = false ;
  bool bFinFichierFound = false ;

  bool bValueWelcomed = false ;

  string sLine ;

	while (!(pInFile->eof()) && !bLabFound)
	{
  	getline(*pInFile, sLine) ;

    string sStripLine = sLine ;
    strip(sStripLine, stripBoth) ;

    if (sStripLine == string("****FIN****"))
    	bFinFound = true ;
    else if (sStripLine == string("****FINFICHIER****"))
    	bFinFichierFound = true ;
    else if (sStripLine == string("****LAB****"))
    	bLabFound = true ;
    else if (sStripLine != string(""))
    {
      // We have better remove the '*' char, because it sometimes means "abnormal" value
      //
      size_t iStarCharPos = sStripLine.find("*") ;
      while (iStarCharPos != NPOS)                         
      {
      	sStripLine = string(sStripLine, 0, iStarCharPos) + string(sStripLine, iStarCharPos+1, strlen(sStripLine.c_str()) - iStarCharPos - 1) ;
      	iStarCharPos = sStripLine.find("*") ;
      }

    	// What is it ?
      string sPattern = string("") ;

      // Title ?
      string sResult = flechiesDB.getCodeLexiq(sStripLine, 'T') ;
  		if (sResult == string(""))
      	sResult = flechiesDB.getCodeLexiq(sStripLine, 'G') ;
      if (sResult == string(""))
      	sResult = flechiesDB.getCodeLexiq(sStripLine, 'Z') ;

      NSPatPathoArray PPTnum(pContexte) ;
      bValueWelcomed = false ;

      // value
      if (sResult == string(""))
      {
      	analysedCapture aCapt(pContexte, sStripLine, 0) ;
      	ParseElemArray aRawParseResult ;
      	ParseElemArray aSemanticParseResult ;
      	aCapt.getSemanticParseElemArray(&aRawParseResult, &aSemanticParseResult) ;
        //
        // We only use the information if it has been fully recognized
        // elsewhere, it can lead to much stupid behaviour
        //
        bool bFullSuccess ;
      	sPattern = aCapt.getNumPattern(&aRawParseResult, &aSemanticParseResult, &bFullSuccess) ;
        if (sPattern != string(""))
        {
        	if (!bFullSuccess)
          	bValueWelcomed = false ;
          else
          {
        		aCapt.numPatternToTree(&sPattern, &PPTnum) ;

            // If there are 2 values with same unit (or second with no unit)
            // then the second one is a "previous value"; we must delete it
            //
            if (!(PPTnum.empty()))
            {
            	PatPathoIter iterPPT = PPTnum.begin() ;    // concept
              PatPathoIter iFirstData = PPTnum.ChercherPremierFils(iterPPT) ;
              if ((iFirstData != NULL) && (iFirstData != PPTnum.end()))
              {
              	if ((*iFirstData)->getLexiqueSens(pContexte) == string("�N0"))
                {
                	string sUnitSens = (*iFirstData)->getUnitSens(pContexte) ;
                  PatPathoIter iBrothData = PPTnum.ChercherFrere(iFirstData) ;
                  while ((iBrothData != NULL) && (iBrothData != PPTnum.end()))
                  {
                  	if ((*iBrothData)->getLexiqueSens(pContexte) == string("�N0"))
                    {
                    	string sBrothUnitSens = (*iBrothData)->getUnitSens(pContexte) ;
                      if ((sBrothUnitSens == sUnitSens) ||
                          (sBrothUnitSens == string("")) ||
                          (sBrothUnitSens == string("20000")))
                      {
                      	PPTnum.SupprimerItem(iBrothData) ;
                        iBrothData = PPTnum.ChercherFrere(iFirstData) ;
                      }
                      else
                      	iBrothData = PPTnum.ChercherFrere(iBrothData) ;
                    }
                  }
                }
              }
            }

            size_t posValue = sPattern.find("[V") ;

            // Warning: if there is a concept alone, don't store structured data
            //
          	if ((posValue != NPOS) && (PPTnum.size() > 1))
          		bValueWelcomed = true ;
          }
        }
      }

      int iCol = 0 ;
      if (sResult != string(""))
      	iCol = 0 ;
      else
      {
      	if (false == PPTnum.empty())
        {
        	size_t posValue = sPattern.find("[V") ;
          if (posValue != NPOS)
          	iCol = 0 ;
          else
          	iCol = 1 ;
        }
      }

    	// Pushing the text
      //
    	Message theMessage ;
      theMessage.SetTexteLibre(sLine) ;
      pPPT->ajoutePatho("�?????", &theMessage, iCol) ;

      if (sResult != string(""))
      	pPPT->ajoutePatho(sResult, iCol+1) ;
      else
      {
      	if (bValueWelcomed && !PPTnum.empty())
        {
        	PatPathoIter iterPere = pPPT->end() ;
          iterPere-- ;
          // int iRefColEnd = (*iterPere)->getColonne() ;
          while ((iterPere != pPPT->begin()) &&
                 ((*iterPere)->getColonne() != 0))
          	iterPere-- ;

          size_t posValue = sPattern.find("[V") ;
          if (posValue == NPOS)
          {
          	while ((iterPere != pPPT->begin()) && ((*iterPere)->getLexique() == string("�?????")))
            	iterPere-- ;
            while ((iterPere != pPPT->begin()) && (((*iterPere)->getLexique())[0] != 'V'))
            	iterPere-- ;
          }

        	pPPT->InserePatPathoFille(iterPere, &PPTnum) ;
        }
      }
    }
  }

  if (pbStoppedOnLab)
  {
  	if (bLabFound)
    	*pbStoppedOnLab = true ;
    else
    	*pbStoppedOnLab = false ;
  }

  if (!bFinFound && bLabFound)
  	return false ;

	return true ;
}

PatPathoIter
NSCaptureFromHPRIM::findStringInPatPatho(string sRef, NSPatPathoArray* pPPT)
{
	if ((sRef == string("")) || !pPPT || (pPPT->empty()))
		return NULL ;

	PatPathoIter itPPT = pPPT->begin() ;
  for ( ; (itPPT != pPPT->end()) && ((*itPPT)->getTexteLibre() != sRef) ; itPPT++)
  	;

	return itPPT ;
}

bool
NSCaptureFromHPRIM::explodeMultipleMessagesFile()
{
	if (sFileName == string(""))
		return false ;

	// First step: parse file name

  string sFileDirectory = string("") ;
  string sLocalFileName = string("") ;
  string sFileExtension = string("") ;

  size_t pos1 = sFileName.find_last_of(".") ;
  if (pos1 == NPOS)
  	sLocalFileName = sFileName ;
  else
  {
  	sLocalFileName = string(sFileName, 0, pos1) ;
    sFileExtension = string(sFileName, pos1+1, strlen(sFileName.c_str())-1) ;
  }

  pos1 = sLocalFileName.find_last_of("\\") ;
  if (pos1 != NPOS)
  {
  	sFileDirectory = string(sLocalFileName, 0, pos1+1) ;
    sLocalFileName = string(sLocalFileName, pos1+1, strlen(sLocalFileName.c_str())-1) ;
  }

  // Open master file for reading

	ifstream inFile ;

  inFile.open(sFileName.c_str());
	if (!inFile)
	{
  	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningInputFile") ;
    sErrorText += string(" ") + sFileName ;
    erreur(sErrorText.c_str(), standardError, 0, 0) ;
    return false ;
	}

	string sLine ;
	string sText = "" ;

  getline(inFile, sLine) ;

  bool bKeepOnRunning = true ;  while (bKeepOnRunning && !inFile.eof())  {    // First, skip empty lines and detect end tag    string sStripLine = sLine ;    strip(sStripLine, stripBoth) ;

/*  Don't do that because empty lines may be usefull at the begining of the message

    while ((sStripLine == string("")) && !inFile.eof())
    {
    	getline(inFile, sLine) ;
    	sStripLine = sLine ;    	strip(sStripLine, stripBoth) ;
    }
*/

    // Here, we are at end of file without reaching the end tag
    //
    if (inFile.eof())
    {
    	inFile.close() ;
    	return false ;
    }

		if (sStripLine == string("****FINFICHIER****"))
    {
    	inFile.close() ;
    	return true ;
    }

  	// Starting the new message; first create a new file    string sNewFileName = sFileDirectory + nomSansDoublons(sFileDirectory, sLocalFileName, sFileExtension) ;    ofstream outFile ;  	outFile.open(sNewFileName.c_str());
  	if (!outFile)
  	{
    	string sErrorText = pContexte->getSuperviseur()->getText("fileErrors", "errorOpeningOutputFile") ;
      sErrorText += string(" ") + sNewFileName ;
    	erreur(sErrorText.c_str(), standardError, 0, 0) ;
    	inFile.close() ;
    	return false ;
  	}    bool bGotEndOfMessageTag = false ;
  	while (!inFile.eof() && (!bGotEndOfMessageTag))
  	{
      outFile << (sLine + string("\n")) ;

      strip(sLine, stripBoth) ;
    	if (sLine == string("****FIN****"))
      {
      	outFile << (string("****FINFICHIER****") + string("\n")) ;
        bGotEndOfMessageTag = true ;
        getline(inFile, sLine) ;
      }
      else if (sLine == string("****FINFICHIER****"))
      {
      	outFile << (string("****FINFICHIER****") + string("\n")) ;
        bGotEndOfMessageTag = true ;
      }
      else
      	getline(inFile, sLine) ;
		}

    outFile.close() ;
  }

  inFile.close() ;

  return false ;
}

string
NSCaptureFromHPRIM::getDateFromHPRIM1date(string sHPRIMdate, string s2kTreshold)
{
	if (strlen(sHPRIMdate.c_str()) != 8)
		return string("") ;

	if ((sHPRIMdate[2] != '/') || (sHPRIMdate[5] != '/'))
		return string("") ;

  string sYear  = string(sHPRIMdate, 6, 2) ;
  string sMonth = string(sHPRIMdate, 3, 2) ;
  string sDay   = string(sHPRIMdate, 0, 2) ;
  string sCent  = string("20") ;

  // Year ?
  if (s2kTreshold == string(""))
  	sCent = string("20") ;
  else
  {
  	int iTreshold = atoi(s2kTreshold.c_str()) ;
    int iYear     = atoi(sYear.c_str()) ;
    if (iYear > iTreshold)
    	sCent = string("19") ;
    else
    	sCent = string("20") ;
  }

  string sDateFr = sDay + string("/") + sMonth + string("/") + sCent + sYear ;
  
  string sReturnDate = string("") ;
  donne_date_inverse(sDateFr, sReturnDate, "fr") ;
  return sReturnDate ;
}

