//---------------------------------------------------------------------------
//    NSPERSON.CPP
//    KRZISCH PH.   janvier 92
//  Impl�mentation de objets NAUTILUS
//---------------------------------------------------------------------------

#include <owl\olemdifr.h>
#include <mem.h>
#include <stdio.h>
#include <string.h>
#include <cstring.h>

#include "nautilus\nssuper.h"
// #include "nautilus\nsrechdl.h"
#include "partage\nsdivfct.h"
#include "nautilus\nspatdlg.h"
#include "nautilus\nsanxary.h"
#include "nsdn\nsdocum.h"
#include "nautilus\nsepicap.h"
#include "nsbb\nsmanager.h"
#include "nsbb\nsbbtran.h"
#include "nssavoir\nsgraphe.h"
#include "nssavoir\nsHealthTeam.h"
#include "nssavoir\nsguide.h"
#include "nautilus\nsTeamDocView.h"
#include "nautilus\nshistdo.h"
#include "dcodeur\nsgen.h"

#ifndef __NSPERSON_H
# include "partage\nsperson.h"
#endif

#include "pilot\NautilusPilot.hpp"
#include "nsbb\tagNames.h"


//***************************************************************************
// Impl�mentation des m�thodes NSPatient
//***************************************************************************

//---------------------------------------------------------------------------
//  Function:    NSPatientData::NSPatientData()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSPatientData::NSPatientData(NSContexte* pCtx)
              :NSRoot(pCtx)
{
}

//---------------------------------------------------------------------------
//  Fonction:		NSPatientData::NSPatientData(NSPatientData& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSPatientData::NSPatientData(NSPatientData& rv)
              :NSRoot(rv.pContexte)
{
	sNss           = rv.sNss ;
	sNom           = rv.sNom ;
	sPrenom        = rv.sPrenom ;
	sCode          = rv.sCode ;
	sConvoc        = rv.sConvoc ;
	sSexe          = rv.sSexe ;
	sAdresse       = rv.sAdresse ;
	sNaissance     = rv.sNaissance ;
	sTelepor       = rv.sTelepor ;
	sTelebur       = rv.sTelebur ;
	sSitfam        = rv.sSitfam ;
	sLang          = rv.sLang ;
	sCivilite      = rv.sCivilite ;
	sNomLong       = rv.sNomLong ;
	sIpp           = rv.sIpp ;
	sMergedWith    = rv.sMergedWith ;
	sNomJeuneFille = rv.sNomJeuneFille ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSPatientData::operator=(NSPatientData src)
//  Description:	Op�rateur =
//  Retour:			R�f�rence sur l'objet cible
//---------------------------------------------------------------------------
NSPatientData&
NSPatientData::operator=(NSPatientData src)
{
	if (this == &src)
		return *this ;

	sNss           = src.sNss ;
  sNom           = src.sNom ;
  sPrenom        = src.sPrenom ;
  sCode          = src.sCode ;
  sConvoc        = src.sConvoc ;
  sSexe          = src.sSexe ;
  sAdresse       = src.sAdresse ;
  sNaissance     = src.sNaissance ;
  sTelepor       = src.sTelepor ;
  sTelebur       = src.sTelebur ;
  sSitfam        = src.sSitfam ;
  sLang          = src.sLang ;
  sCivilite      = src.sCivilite ;
  sNomLong       = src.sNomLong ;
  sIpp           = src.sIpp ;
  sMergedWith    = src.sMergedWith ;
  sNomJeuneFille = src.sNomJeuneFille ;

	return *this ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSPatientData::operator==(NSPatientData src)
//  Description:	Op�rateur de comparaison
//  Retour:			0 ou 1
//---------------------------------------------------------------------------
int
NSPatientData::operator == ( NSPatientData& o )
{
  if ((sNss == o.sNss)                &&
      (sNom == o.sNom)                &&
      (sPrenom == o.sPrenom)          &&
      (sCode == o.sCode)              &&
      (sConvoc == o.sConvoc)          &&
      (sSexe == o.sSexe)              &&
      (sAdresse == o.sAdresse)        &&
      (sNaissance == o.sNaissance)    &&
      (sTelepor == o.sTelepor)        &&
      (sTelebur == o.sTelebur)        &&
      (sSitfam == o.sSitfam)
      )
      return 1 ;
  else
      return 0 ;
}

//---------------------------------------------------------------------------
//  Function:    NSPatientData::fabriqueNomLong()
//
//  Description: Initialise nom_long
//
//  Note : on suppose que les donn�es naissance, nom, prenom et sexe
//  sont deja initialis�es
//
//  Returns:     Rien
//---------------------------------------------------------------------------
void NSPatientData::fabriqueNomLong(string sLang)
{
	if (sLang == "")
		sLang = pContexte->getUtilisateur()->donneLang() ;

	// calcul de l'age du patient
	bool bEnfant = false ;
	char szDateJour[10] ;

	if ((sNaissance != string("")) && (sNaissance != string("00000000")))
	{
		char szNaissance[PAT_NAISSANCE_LEN + 1] ;
		strcpy(szNaissance, sNaissance.c_str()) ;
		donne_date_duJour(szDateJour) ;
		int age = donne_age(szDateJour, szNaissance) ;

		if (age <= 14)
			bEnfant = true ;
	}

	if (sLang == "fr")
	{
		if (bEnfant)
			sNomLong = string("Enfant ") ;
		else
		{
			if (sSexe[0] == '2')
				sNomLong = string("Mme ") ;
			else
				sNomLong = string("M. ") ;
		}
	}

	if (sLang == "en")
	{
		if (bEnfant)
			sNomLong = string("Child ");
		else
		{
			if (sSexe[0] == '2')
				sNomLong = string("Ms ");
			else
				sNomLong = string("Mr ");
		}
	}

	sNomLong += sNom;
	sNomLong += string(" ");
	sNomLong += sPrenom;
}

string
NSPatientData::fabriqueCivilite(bool /* bShort */, string sLang)
{
	if (sLang == "")
		sLang = pContexte->getUtilisateur()->donneLang() ;

	if (sCivilite != "")
	{
		string sLibelleTrouve ;
    pContexte->getDico()->donneLibelle(sLang, &sCivilite, &sLibelleTrouve) ;
    if (sLibelleTrouve != "")
    {
    	sLibelleTrouve += string(" ") ;
      return sLibelleTrouve ;
    }
  }

	return string("") ;
}


/*
// cette fonction a �t� mise dans nsperson.h --> on en a besoin dans CalculAgeKS
//---------------------------------------------------------------------------
//  Function:    NSPatientData::donneNaissance(char *dateNaiss)
//
//  Description: Retourne dans dateNaiss la date de naissance du patient
//					  au format AAAAMMJJ
//					  Si le champ existe mais n'a pas �t� renseign�,
//					  retourne "00000000"
//
//  Returns:     1 si OK, 0 si date de naissance n'est pas un champ du fichier
//---------------------------------------------------------------------------
int
NSPatientData::donneNaissance(char *dateNaiss)
{
	strcpy(dateNaiss, naissance);
	if ((dateNaiss[0] == '\0') ||
			(strcmp(dateNaiss, "        ") == 0) ||
			(strcmp(dateNaiss, "19000000") == 0))
		strcpy(dateNaiss, "00000000");
	return 1;
}
*/

//---------------------------------------------------------------------------
//  Function:    NSPatientData::setNbEnfants(int nbenf)
//
//  Description: ajoute le nb d'enfants � sitfam
//---------------------------------------------------------------------------
void NSPatientData::setNbEnfants(int nbenf)
{
	char sitfam[3] ;

	if (nbenf < 0)
	{
		erreur("Le nombre d'enfants est fix� � une valeur incorrecte.", standardError, 0) ;
		sitfam[1] = '0' ;
		sitfam[2] = '\0' ;
		return;
	}

	if (nbenf <= 9)
		sprintf(&sitfam[1], "%1d", nbenf);
	else
		if (nbenf <= 35)
		{
			// on repr�sente la valeur sous forme d'un caract�re entre 'A' et 'Z'
			nbenf += 55;
			sitfam[1] = (char) (nbenf);
			sitfam[2] = '\0';
		}
		else // cas nbenf > 35
		{
			sitfam[1] = '*';
            sitfam[2] = '\0';
        }

	sSitfam = string(sitfam) ;
}

//---------------------------------------------------------------------------
//  Function:    NSPatientData::getNbEnfants()
//
//  Description: retourne le nb d'enfants d'apr�s sitfam[1]
//---------------------------------------------------------------------------
int NSPatientData::getNbEnfants()
{
	char sitfam[3] ;
	strcpy(sitfam, sSitfam.c_str()) ;

	// on s'assure que sitfam[2] est NULL
	sitfam[2] = '\0';
	// on ne consid�re que le premier caract�re
	char c;
	if (strlen(sitfam) == 2)
		c = sitfam[1];
	else
		return 0;

	if ((c >= '0') && (c <= '9'))
		return atoi(&sitfam[1]);
	else
		if ((c >= 'A') && (c <= 'Z'))
			return (((int) c) - 55);

	// cas nb d'enfants > 35
  return -1;
}

//---------------------------------------------------------------------------
//  Function:    NSPatientData::donneSitFam()
//
//  Description: Retourne la string d�crivant la situation familiale
//---------------------------------------------------------------------------
string NSPatientData::donneSitFam(string sLang)
{
	string sSitFam ;

	if (sLang == "")
		sLang = pContexte->getUtilisateur()->donneLang() ;

	switch (sSitfam[0])
	{
		case 'C' :	sSitFam = "C�libataire";
								break;

		case 'V' :	if (estMasculin())
									sSitFam = "Veuf";
								else
									sSitFam = "Veuve";
            		break;

		case 'B' :	if (estMasculin())
									sSitFam = "Concubin";
								else
									sSitFam = "Concubine";
            		break;

		case 'M' :	if (estMasculin())
									sSitFam = "Mari�";
								else
									sSitFam = "Mari�e";
								break;

		case 'D' :	if (estMasculin())
									sSitFam = "Divorc�";
								else
									sSitFam = "Divorc�e";
								break;

		default :		sSitFam = "";
	}

  return sSitFam;
}

//---------------------------------------------------------------------------
//  Function:    NSPatientData::donneNbEnfants()
//
//  Description: Retourne le nombre d'enfants
//---------------------------------------------------------------------------
string NSPatientData::donneNbEnfants()
{
	string sNbEnf;
	char cNbEnf[3];
	int nbenf = getNbEnfants();

	// cas nb enfants trop grand
	if (nbenf < 0)
		return string("nombreux enfants");

	// cas nb enfants entre 0 et max (max fix� � 35 pour l'instant !)
	switch (nbenf)
	{
		case 0 :	sNbEnf = "";
							break;
		case 1 :	sNbEnf = "1 enfant";
							break;
		default :	sprintf(cNbEnf, "%d", nbenf);
							sNbEnf = string(cNbEnf) + string(" enfants");
	}

	return sNbEnf;
}

//---------------------------------------------------------------------------
//  Function:    NSPatientData::donneDateNaiss()
//
//  Description: Retourne une string jj/mm/aaaa contenant la date de naissance
//---------------------------------------------------------------------------
string
NSPatientData::donneDateNaiss(string sLang)
{
  if (sNaissance == "")
		return "" ;

  string sFormat = pContexte->getSuperviseur()->getText("0localInformation", "dateFormat", sLang, pContexte) ;

  return getFormatedDate(sNaissance, sLang, sFormat) ;
}

//---------------------------------------------------------------------------
//  Function:    NSPatientData::donneTitre()
//
//  Description: Retourne une string correspondant � nom_long s'il existe
//               sinon refabrique le nom_long
//---------------------------------------------------------------------------
string NSPatientData::donneTitre(string sLang)
{
	if (sLang == "")
		sLang = pContexte->getUtilisateur()->donneLang() ;

	if (sNomLong == "")
		fabriqueNomLong() ;

	return sNomLong ;
}

//***************************************************************************
//
// Impl�mentation des m�thodes NSPatInfo
//
//***************************************************************************


// -----------------------------------------------------------------------------
// Fonction    : NSPatInfo::NSPatInfo(NSSuper* pSuper)
// Description : Constructeur avec superviseur (pour les acc�s aux bases)
// Retour      : Rien
// -----------------------------------------------------------------------------
NSPatInfo::NSPatInfo(NSContexte *pCtx)
          :NSRoot(pCtx)
{
	// Cr�e l'objet de donn�es
	pDonnees 	  	= new NSPatientData(pContexte) ;

  pGraphPerson  = new NSPersonGraphManager(pContexte) ;
  pGraphAdr     = new NSAddressGraphManager(pContexte) ;
  sChez         = "" ;
  pCorrespArray = new NSPidsArray ;

  pDocHis       = 0 ;

  pHealthTeam   = 0 ;
}


// -----------------------------------------------------------------------------
// Fonction    : NSPatInfo::NSPatInfo(NSBasicAttributeArray* pAttribute)
// Description : Constructeur avec NSBasicAttributeArray (pour les acc�s aux bases a l'aide du pilot)
// Retour      : Rien
// -----------------------------------------------------------------------------
NSPatInfo::NSPatInfo(NSBasicAttributeArray* pAttribute, NSContexte* pCtx)
          : NSRoot(pCtx)
{
	// Cr�e l'objet de donn�es
	pDonnees 	  	= new NSPatientData(pContexte) ;

  pCorrespArray = new NSPidsArray ;
  pGraphPerson  = new NSPersonGraphManager(pContexte) ;
  pGraphAdr     = new NSAddressGraphManager(pContexte) ;
  sChez         = "" ;

  pDocHis       = 0 ;

  pHealthTeam   = 0 ;

  NSBasicAttributeIter iter = pAttribute->begin() ;

  for(iter ; iter != pAttribute->end() ; iter++)
  {
    if      ((*iter)->getBalise() == FIRST_NAME)
    	pDonnees->sPrenom = (*iter)->getText() ;
    else if ((*iter)->getBalise() == LAST_NAME)
    	pDonnees->sNom = (*iter)->getText() ;
    else if ((*iter)->getBalise() == BIRTHDATE)
    	pDonnees->sNaissance = (*iter)->getText() ;
    else if ((*iter)->getBalise() == SEX)
    	pDonnees->sSexe = (*iter)->getText() ;
    else if ((*iter)->getBalise() == PIDS)
    	pDonnees->sNss = (*iter)->getText() ;
    else if ((*iter)->getBalise() == IPP)
    	pDonnees->sIpp = (*iter)->getText() ;
    else if ((*iter)->getBalise() == MERGE)
    	pDonnees->sMergedWith = (*iter)->getText() ;
    else if ((*iter)->getBalise() == LOCKED)
    	pDonnees->sLockedConsole = (*iter)->getText() ;
    else if ((*iter)->getBalise() == APPOINTMENT_DATE)
    	pDonnees->sConvoc = (*iter)->getText() ;
  }
}

// -----------------------------------------------------------------------------
// Fonction    : NSPatInfo::NSPatInfo(NSPatient*)
// Description : Constructeur � partir d'un NSPatient
// Retour      : Rien
// -----------------------------------------------------------------------------
NSPatInfo::NSPatInfo(NSPids *pPids)
          :NSRoot(pPids->NSPidsInfo::pContexte)
{
	// Cr�e l'objet de donn�es
	pDonnees 	   	= new NSPatientData(pContexte) ;

	pCorrespArray = new NSPidsArray ;
  pGraphPerson  = new NSPersonGraphManager(pContexte) ;
  pGraphAdr     = new NSAddressGraphManager(pContexte) ;
  sChez         = "" ;

  pDocHis       = 0 ;

  pHealthTeam   = 0 ;

	// Copie les donn�es du NSPids
  pDonnees->sNss = string(pPids->pDonnees->nss) ;
  pDonnees->sNom = string(pPids->pDonnees->nom) ;
  pDonnees->sPrenom = string(pPids->pDonnees->prenom) ;
  pDonnees->sCode = string(pPids->pDonnees->code) ;
  pDonnees->sSexe = string(pPids->pDonnees->sexe) ;
  pDonnees->sNaissance = string(pPids->pDonnees->naissance) ;
  pDonnees->fabriqueNomLong() ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSPatInfo::~NSPatInfo()
//  Description:	Destructeur
//  Retour:			Rien
//---------------------------------------------------------------------------
NSPatInfo::~NSPatInfo()
{
	delete pDonnees ;
	delete pCorrespArray ;
	delete pGraphPerson ;
	delete pGraphAdr ;

// Not possible here yet because of linking dependencies
//
//  if (NULL != pDocHis)
//    delete pDocHis ;

  if (NULL != pHealthTeam)
		delete pHealthTeam ;

  // pas de delete du pSuper
}


// -----------------------------------------------------------------------------
// Fonction    : NSPatInfo::NSPatInfo(NSPatInfo& rv)
// Description : Constructeur copie
// Retour      : Rien
// -----------------------------------------------------------------------------
NSPatInfo::NSPatInfo(NSPatInfo& rv)
          :NSRoot(rv.pContexte)
{
try
{
	// Cr�e l'objet de donn�es
	pDonnees      = new NSPatientData(*(rv.pDonnees)) ;

  pGraphPerson  = new NSPersonGraphManager(*(rv.pGraphPerson)) ;
  pGraphAdr     = new NSAddressGraphManager(*(rv.pGraphAdr)) ;
  sChez         = rv.sChez ;
  pCorrespArray = new NSPidsArray(*(rv.pCorrespArray)) ;

  pDocHis       = 0 ;
  pHealthTeam   = 0 ;
}
catch (...)
{
  erreur("Exception NSPatInfo copy ctor", standardError, 0) ;
}
}

void
NSPatInfo::fabriqueNomLong(string sLang)
{
	if (sLang == "")
		sLang = pContexte->getUtilisateur()->donneLang() ;

	if (initGraphs())
	{
  	// on fabrique dans ce cas le nom long � partir du graphe
    string sCivilite ;
    if (pGraphPerson->trouveCivilite(sCivilite, sLang))
    	pDonnees->sNomLong = sCivilite ;
    else
    	pDonnees->fabriqueNomLong(sLang) ;
  }
  else
  	// on fabrique le nom long � partir des pDonnees
    pDonnees->fabriqueNomLong(sLang) ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSPatInfo::initGraphs()
//  Description:	Initialise les graphes du patient.
//  Retour:			true->les graphes sont initialis�s false->echec
//---------------------------------------------------------------------------
bool NSPatInfo::initGraphs()
{
  return true;
}

//---------------------------------------------------------------------------
//  bloquer()
//
//  Efface le patient du fichier de blocage
//---------------------------------------------------------------------------
void
NSPatInfo::debloquer()
{
try
{
	if (!getADebloquer())
		return ;

	NSBasicAttributeArray BAttrArray ;
  char szInstance[128] ;
  sprintf(szInstance, "%d", pContexte->getSuperviseur()->getInstance()) ;
  BAttrArray.push_back(new NSBasicAttribute(CONSOLE,	string(pContexte->getSuperviseur()->getConsole()))) ;
  BAttrArray.push_back(new NSBasicAttribute(INSTANCE,	string(szInstance))) ;
  BAttrArray.push_back(new NSBasicAttribute(PERSON,		getNss())) ;
  if (!pContexte->pPilot->unlockPatient(NautilusPilot::SERV_UNLOCK.c_str(), &BAttrArray))
  {
    string sErrorText = pContexte->getSuperviseur()->getText("NTIERS", "unlockError") ;
    return ;
  }

	setADebloquer(false) ;
}
catch (...)
{
	erreur("Exception debloquer.", standardError, 0) ;
}
}

bool
NSPatInfo::ChercheChemin(string sChemin, NSSearchStruct* pSearchStruct, bool reinit_structure)
{	if ((NULL == pDocHis) || (pDocHis->VectDocument.empty()) || (NULL == pSearchStruct))		return false ;  if (true == reinit_structure)   // reinit the research struct    pSearchStruct->reinit() ;  DocumentIter DocItEnd = pDocHis->VectDocument.end() ;  // Preparing the documents iterator end  std::string  sDateDoc = string("") ;                   // Date du document  std::string  endDate  = string("") ;                   // Date a laquel la recherche doit s'arreter  std::string sCheminPatho = sChemin ;  // ComposeNoeudsChemin(sChemin, sCheminPatho) ;  //  // Recherche dans la synth�se  //  NSPatPathoArray patho_synthese(pContexte) ;   // Tempory patpath  DonnePathoSynthese(&patho_synthese) ;  PatPathoIter pptItBegin = patho_synthese.begin() ;  PatPathoIter pptIt      = patho_synthese.begin() ;   // Get an iterator	while (patho_synthese.CheminDansPatpatho(sCheminPatho, string(1, cheminSeparationMARK), &pptIt, &pptItBegin))	{    if ((pptIt != NULL) && (pptIt != patho_synthese.end()))    {			std::string date = patho_synthese.getNodeDate(pptIt) ;			if  ((date == "") && (pSearchStruct->accept_date(sDateDoc)))			{				char				sCurrentDate[9] ;				donne_date_duJour(sCurrentDate) ;				sDateDoc = std::string(sCurrentDate) ;				pSearchStruct->aFoundNodes.insert(sDateDoc, std::string((*pptIt)->getNode())) ;			}			else				if (pSearchStruct->accept_date(date))					pSearchStruct->aFoundNodes.insert(date, std::string((*pptIt)->getNode())) ;		}		if ((pptIt == NULL) || (pptIt == patho_synthese.end()))			break ;		pptItBegin = pptIt++ ;		if (pptItBegin == patho_synthese.end())			break ;	}	//	// Recherche dans l'Index de sant� - Searching in health index	//  NSPatPathoArray patho_index(pContexte);   // Tempory patpath  DonnePathoIndex(&patho_index) ;  pptItBegin = patho_index.begin() ;  // First case: the searched for pathway starts with ZPOMR -> standard search  //  if (string("ZPOMR") == string(sChemin, 0, 5))  {  	pptIt      = patho_index.begin() ;    // Get an iterator		while (patho_index.CheminDansPatpatho(sCheminPatho, string(1, cheminSeparationMARK), &pptIt, &pptItBegin))		{    	if ( (pptIt != NULL) && (pptIt != patho_index.end()))    	{				std::string date = patho_index.getNodeDate(pptIt);				if  ((date == "") && (pSearchStruct->accept_date(sDateDoc)))				{					char				sCurrentDate[9] ;					donne_date_duJour(sCurrentDate) ;					sDateDoc = std::string(sCurrentDate) ;					pSearchStruct->aFoundNodes.insert(sDateDoc, std::string((*pptIt)->getNode())) ;				}				else					if (pSearchStruct->accept_date(date))						pSearchStruct->aFoundNodes.insert(date, std::string((*pptIt)->getNode())) ;			}			if ((pptIt == NULL) || (pptIt == patho_index.end()))				break ;			pptItBegin = pptIt++ ;			if (pptItBegin == patho_index.end())				break ;		}  }  // Second case, the search is not oriented toward the health index, then take  // care of not searching in the "risk" or "goal" section unless explicitly  // specified  //  else  {    PatPathoIter pptItCol_1 = patho_index.ChercherPremierFils(pptItBegin) ;    bool bSearchInGoals = false ;    if ((strlen(sChemin.c_str()) > 5) && (string("0OBJE") == string(sChemin, 0, 5)))      bSearchInGoals = true ;          string sGoalBranch = string("ZPOMR") + string(1, cheminSeparationMARK) + string("0OBJE") ;    if ((strlen(sChemin.c_str()) > 11) && (string(sChemin, 0, 11) == sGoalBranch))      bSearchInGoals = true ;    bool bSearchInRisk = false ;    if ((strlen(sChemin.c_str()) > 5) && (string("ORISK") == string(sChemin, 0, 5)))      bSearchInRisk = true ;    string sRiskBranch = string("ZPOMR") + string(1, cheminSeparationMARK) + string("ORISK") ;    if ((strlen(sChemin.c_str()) > 11) && (string(sChemin, 0, 11) == sRiskBranch))      bSearchInRisk = true ;    // Just look in Goals and Risk if explicitely specified    while ((NULL != pptItCol_1) && (patho_index.end() != pptItCol_1))    {      string sChapter = (*pptItCol_1)->getLexiqueSens(pContexte) ;      if (((string("0OBJE") != sChapter) || bSearchInGoals) &&          ((string("ORISK") != sChapter) || bSearchInRisk))      {        pptItBegin = pptItCol_1 ;        while (patho_index.CheminDansPatpatho(sCheminPatho, string(1, cheminSeparationMARK), &pptIt, &pptItCol_1))        {          if ((pptIt != NULL) && (pptIt != patho_index.end()))          {            std::string date = patho_index.getNodeDate(pptIt);            if  ((date == "") && (pSearchStruct->accept_date(sDateDoc)))            {              char sCurrentDate[9] ;              donne_date_duJour(sCurrentDate) ;              sDateDoc = std::string(sCurrentDate) ;              pSearchStruct->aFoundNodes.insert(sDateDoc, std::string((*pptIt)->getNode())) ;            }            else              if (pSearchStruct->accept_date(date))                pSearchStruct->aFoundNodes.insert(date, std::string((*pptIt)->getNode())) ;          }          if ((pptIt == NULL) || (pptIt == patho_index.end()))            break ;          pptItBegin = pptIt++ ;          if ((pptItBegin == patho_index.end()) || ((*pptItBegin)->getColonne() == 1))            break ;        }      }      pptItCol_1 = patho_index.ChercherFrere(pptItCol_1) ;    }  }  //  // Recherche dans les autres documents  //	for (DocumentIter DocIt = pDocHis->VectDocument.begin(); (DocIt != DocItEnd); DocIt++)	{		sDateDoc = string((*DocIt)->dateDoc);  // Recupere la date du document		if ((pSearchStruct->sEndingDate != "") && (sDateDoc < pSearchStruct->sEndingDate)) // La date finale est passe			break ;		//LA seule facon d'etre sur quon a les n plus recents est de verifier qu'on a n reponse		// plus recents que le documents en cours		if (pSearchStruct->aFoundNodes.getNunberOfResultBeforeDate(sDateDoc) >= pSearchStruct->iNbNodes)   // si la date du document est superieur a la derniere date			break ;    std::string name = (*DocIt)->getContent() ;		if (((*DocIt)->pPatPathoArray) && (!((*DocIt)->pPatPathoArray->empty())) && (name != "ZSYNT1") && (name != "ZPOMR1"))		{			PatPathoIter pptIt      = (*DocIt)->pPatPathoArray->begin() ;			PatPathoIter pptItBegin = (*DocIt)->pPatPathoArray->begin() ;      // There is an infinite loop when what is asked is exactly the root node of the ppt      if ((*pptIt)->getNodeLabel() == sCheminPatho)        pSearchStruct->aFoundNodes.insert(sDateDoc, std::string((*pptIt)->getNode())) ;      else      {        while ((*DocIt)->pPatPathoArray->CheminDansPatpatho(sCheminPatho, string(1, cheminSeparationMARK), &pptIt, &pptItBegin))        {          std::string info_date = (*DocIt)->pPatPathoArray->getNodeDate(pptIt); // recupere l'information sur la date          if (info_date == "")            info_date =  sDateDoc ;          if ((pptIt != NULL) && (pptIt != (*DocIt)->pPatPathoArray->end()) && (pSearchStruct->accept_date(info_date)))            pSearchStruct->aFoundNodes.insert(sDateDoc, std::string((*pptIt)->getNode())) ;          if ((pptIt == NULL) || (pptIt == (*DocIt)->pPatPathoArray->end()))            break ;          pptItBegin = pptIt++ ;          if (pptItBegin == (*DocIt)->pPatPathoArray->end())            break ;        }      }		}		else if (((*DocIt)->pMeta) && (!((*DocIt)->pMeta->empty())))		{			// on v�rifie au pr�alable qu'il existe un chapitre "donn�es de suivi"      PatPathoIter pptItBegin = (*DocIt)->pMeta->ChercherItem("9SUIV") ;			PatPathoIter pptIt ;      if ((pptItBegin != (*DocIt)->pMeta->end()) && (pptItBegin != NULL))			{				while ((*DocIt)->pMeta->CheminDansPatpatho(sCheminPatho, string(1, cheminSeparationMARK), &pptIt, &pptItBegin))				{					std::string info_date = (*DocIt)->pMeta->getNodeDate(pptIt); // recupere l'information sur la date					if (info_date == "")						info_date =  sDateDoc ;					if ((pptIt != NULL) && (pptIt != (*DocIt)->pMeta->end()) && (pSearchStruct->accept_date(info_date)))						pSearchStruct->aFoundNodes.insert(sDateDoc, std::string((*pptIt)->getNode())) ;					if ((pptIt == NULL) || (pptIt == (*DocIt)->pMeta->end()))						break ;					pptItBegin = pptIt++ ;					if (pptItBegin == (*DocIt)->pMeta->end())						break ;				}			}		}	}	pSearchStruct->create_result() ;	return true ;}

bool
NSPatInfo::getReadOnly()
{
  return pGraphPerson->bReadOnly ;
}

bool
NSPatInfo::getADebloquer()
{
  return pGraphPerson->bNeedUnlock ;
}

void
NSPatInfo::setReadOnly(bool bRO)
{
  pGraphPerson->bReadOnly = bRO ;
}

void
NSPatInfo::setADebloquer(bool bAD)
{
  pGraphPerson->bNeedUnlock = bAD ;
}

NSDocumentHisto*
NSPatInfo::GetDocument(string sRootSens)
{
  if ((NULL == pDocHis) || (pDocHis->VectDocument.empty()))
		return 0 ;

  if (string("") == sRootSens)
    return 0 ;

  DocumentReverseIter iterReverseDocEnd = pDocHis->VectDocument.rend() ;
	for (DocumentReverseIter iterReverseDoc = pDocHis->VectDocument.rbegin(); iterReverseDoc != iterReverseDocEnd; iterReverseDoc++)
	{
    if (NULL != (*iterReverseDoc)->pPatPathoArray)
    {
      PatPathoIter iter = (*iterReverseDoc)->pPatPathoArray->begin() ;
      string sDocRootSens = (*iter)->getLexiqueSens(pContexte) ;

      if (sDocRootSens == sRootSens)
        return *iterReverseDoc ;
		}
	}

  return 0 ;
}

void
NSPatInfo::GetDocPatho(NSPatPathoArray *pPatho, string sRootSens)
{
  if (NULL == pPatho)
		return ;

  pPatho->vider() ;

  NSDocumentHisto* pDoc = GetDocument(sRootSens) ;
  if (NULL == pDoc)
    return ;

  *pPatho = *(pDoc->pPatPathoArray) ;
}

// -----------------------------------------------------------------------------
// Renvoie la patpatho fille du noeud
// -----------------------------------------------------------------------------
// ajout fab - 2003/08/13 -- on cherche �galement dans la patpatho META
// -----------------------------------------------------------------------------
bool
NSPatInfo::DonneSousArray(string sNoeud, NSPatPathoArray *pPPT)
{  if (NULL == pPPT)    return false ;	if ((NULL == pDocHis) || (pDocHis->VectDocument.empty()))		return false ;  if (strlen(sNoeud.c_str()) != PAT_NSS_LEN + DOC_CODE_DOCUM_LEN + PPD_NOEUD_LEN)    return false ;	string sDocument = string(sNoeud, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) ;	DocumentIter DocIt = pDocHis->VectDocument.begin() ;	for ( ; DocIt != pDocHis->VectDocument.end() ; DocIt++)	{		if (((*DocIt)->pPatPathoArray) && (!((*DocIt)->pPatPathoArray->empty())))		{			PatPathoIter pptIt = (*DocIt)->pPatPathoArray->begin() ;      if ((*pptIt)->getDoc() == sDocument)      {        for ( ; (pptIt != (*DocIt)->pPatPathoArray->end()) && (sNoeud != (*pptIt)->getNode()) ; pptIt++)          ;        if (pptIt != (*DocIt)->pPatPathoArray->end())        {          (*DocIt)->pPatPathoArray->ExtrairePatPatho(pptIt, pPPT) ;          return true ;        }      }      else      {        if (((*DocIt)->pMeta != NULL) && (!(*DocIt)->pMeta->empty()))        {          PatPathoIter pptMetaIter = (*DocIt)->pMeta->begin() ;          if ((*pptMetaIter)->getDoc() == sDocument)          {            for ( ; (pptMetaIter != (*DocIt)->pMeta->end()) && (sNoeud != (*pptMetaIter)->getNode()) ; pptMetaIter++)              ;            if (pptMetaIter != (*DocIt)->pMeta->end())            {              (*DocIt)->pMeta->ExtrairePatPatho(pptMetaIter, pPPT) ;              return true ;            }          }        }      }		}	}	return false ;}

// -----------------------------------------------------------------------------
// Renvoie une patpatho qui contient le noeud, sa fille et les m�me donn�es
// pour les fr�res du noeud qui lui sont identiques
// -----------------------------------------------------------------------------
// ajout fab - 2003/08/13 -- on cherche �galement dans la patpatho META
// -----------------------------------------------------------------------------
bool
NSPatInfo::DonneArray(string sNoeud, NSPatPathoArray *pPPT)
{  if (!pPPT)    return false ;	if ((!pDocHis) || (pDocHis->VectDocument.empty()))		return false ;  if (strlen(sNoeud.c_str()) != PAT_NSS_LEN + DOC_CODE_DOCUM_LEN + PPD_NOEUD_LEN)    return false ;	string sDocument = string(sNoeud, 0, PAT_NSS_LEN + DOC_CODE_DOCUM_LEN) ;	DocumentIter DocIt = pDocHis->VectDocument.begin() ;	for ( ; DocIt != pDocHis->VectDocument.end() ; DocIt++)	{		if (((*DocIt)->pPatPathoArray) && (!((*DocIt)->pPatPathoArray->empty())))		{			PatPathoIter pptIt = (*DocIt)->pPatPathoArray->begin() ;      if ((*pptIt)->getDoc() == sDocument)      {        for ( ; (pptIt != (*DocIt)->pPatPathoArray->end()) && (sNoeud != (*pptIt)->getNode()) ; pptIt++)          ;        if (pptIt != (*DocIt)->pPatPathoArray->end())        {          (*DocIt)->pPatPathoArray->ExtrairePatPathoFreres(pptIt, pPPT) ;          return true ;        }      }      else      {        if (((*DocIt)->pMeta != NULL) && (!(*DocIt)->pMeta->empty()))        {          PatPathoIter pptMetaIter = (*DocIt)->pMeta->begin() ;          if ((*pptMetaIter)->getDoc() == sDocument)          {            for ( ; (pptMetaIter != (*DocIt)->pMeta->end()) && (sNoeud != (*pptMetaIter)->getNode()) ; pptMetaIter++)              ;            if (pptMetaIter != (*DocIt)->pMeta->end())            {              (*DocIt)->pMeta->ExtrairePatPathoFreres(pptMetaIter, pPPT) ;              return true ;            }          }        }      }		}	}	return false ;}
//---------------------------------------------------------------------------
//  Fonction:		NSPatInfo::initCorrespArray()
//  Description:	Recherche les correspondants du patient.
//  Retour:			true->le tableau des corresp est initialis� false->echec
//---------------------------------------------------------------------------
bool
NSPatInfo::initCorrespArray(NSPatPathoArray* pPatPathoArray)
{
	if ((!pPatPathoArray) || (pPatPathoArray->empty()))
  	return false ;

  pCorrespArray->vider() ;
  //
  // On part du principe que les donn�es qui nous int�ressent sont dans un
  // sous chapitre LCTAC (contacts)
  //
  // We suppose that the values we need are in a sub-chapter LCTAC (contact)
  //
  PatPathoIter    iter ;
  string          sElemLex, sSens, sType ;
  bool            bCorresp;

  string          sFonction = "" ;
  string          sCode     = "" ;

  string          sTemp   = "" ;

  iter = pPatPathoArray->begin();
  int iColBase = (*iter)->pDonnees->getColonne();
  iter++;

  while ((iter != pPatPathoArray->end()) && ((*iter)->pDonnees->getColonne() > iColBase))
  {
      sElemLex = string((*iter)->pDonnees->lexique);
      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

      // Chapitre "contacts" / Contact chapter
      if (sSens == string("LCTAC"))
      {
          int iColContact = (*iter)->pDonnees->getColonne() ;
          iter++ ;

          while ((iter != pPatPathoArray->end()) && ((*iter)->pDonnees->getColonne() > iColContact))
          {
              sElemLex = string((*iter)->pDonnees->lexique);
              pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

              // Liste des correspondants
              if (sSens == string("LCORR"))
              {
                  iter++;
                  while ((iter != pPatPathoArray->end()) && ((*iter)->pDonnees->getColonne() > iColContact + 1))
                  {
                      sElemLex = string((*iter)->pDonnees->lexique);
                      pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

                      // Correspondant : comprend fonction et person_id
                      if (sSens == string("DCORR"))
                      {
                          iter++;
                          bCorresp = false;
                          sFonction = "";
                          sCode = "";

                          while ((iter != pPatPathoArray->end()) && ((*iter)->pDonnees->getColonne() > iColContact + 2))
                          {
                              sElemLex = string((*iter)->pDonnees->lexique);
                              pContexte->getDico()->donneCodeSens(&sElemLex, &sSens);

                              // Correspondant : comprend fonction et person_id
                              if (sSens == string("LFONC"))
                              {
                                  iter++;
                                  while ((iter != pPatPathoArray->end()) && ((*iter)->pDonnees->getColonne() > iColContact + 3))
                                  {
                                      // on cherche ici un texte libre
                                      sElemLex = (*iter)->getLexique() ;
                                      if (string(sElemLex, 0, 3) == string("�CL"))
                                      {
                                          sFonction = (*iter)->pDonnees->getTexteLibre();
                                      }
                                      iter++;
                                  }
                              }
                              else if (sSens == string("HHUMA"))
                              {
                                  iter++;
                                  while ((iter != pPatPathoArray->end()) && ((*iter)->pDonnees->getColonne() > iColContact + 3))
                                  {
                                      // on cherche ici un texte libre
                                      sElemLex = (*iter)->getLexique() ;
                                      if (string(sElemLex, 0, 5) == string("�SPID"))
                                      {
                                          sCode = string((*iter)->pDonnees->complement);
                                          bCorresp = true;
                                      }
                                      iter++;
                                  }
                              }
                              else
                                  iter++;
                          }

                          if (bCorresp)
                          {
                              NSPidsInfo* pPidsInfo = new NSPidsInfo(pContexte);
                              initCorrespPIDS(pPidsInfo, sCode);
                              pPidsInfo->sFonction = sFonction;

                              pCorrespArray->push_back(new NSPidsInfo(*pPidsInfo));
                              delete pPidsInfo;
                          }
                      }
                      else
                          iter++;
                  }
              }
              else
                  iter++;
          }
      }
      else
          iter++;
  }

	return true ;
}

bool
NSPatInfo::getFoldersPatho(NSPatPathoArray* pPatPathoArray)
{
  if (NULL == pPatPathoArray)
    return false ;

  pPatPathoArray->vider() ;

  if ((NULL != pDocHis) && (NULL != pDocHis->pLibChem))
  {
    *pPatPathoArray = *(pDocHis->pLibChem->pPatPathoArray) ;
    return true ;
  }

  string sDocRoot = pGraphPerson->getRootTree() ;
  NSLinkManager* pGraphe = pGraphPerson->pLinkManager ;
  VecteurString aVecteurString ;
  pGraphe->TousLesVrais(sDocRoot, NSRootLink::personFolderLibrary, &aVecteurString) ;
  if (aVecteurString.empty())
    return false ;

  string sCodeDocLibChem = *(*(aVecteurString.begin())) ;
  NSDocumentInfo docInf(sCodeDocLibChem, pContexte, this) ;
  docInf.LoadMetaAndData(this) ;
  docInf.DonnePatPatho(pPatPathoArray, this) ;

  return true ;
}

bool
NSPatInfo::getFoldersArray(NSChemiseArray* pChemisesArray)
{
  if (NULL == pChemisesArray)
    return false ;

  NSPatPathoArray FoldersArray(pContexte) ;

  if (false == getFoldersPatho(&FoldersArray))
    return false ;

  if (FoldersArray.empty())
    return false ;

  PatPathoIter iter = FoldersArray.begin() ;
  int iColBase = (*iter)->getColonne() ;
  iter++ ;

  string sNodeChem = "" ;
  string sNom      = "" ;
  string sDate     = "" ;

  string sLang = "" ;
	if (pContexte->getUtilisateur())
		sLang = pContexte->getUtilisateur()->donneLang() ;

  while ((FoldersArray.end() != iter) && ((*iter)->getColonne() > iColBase))
  {
    string sSens = (*iter)->getLexiqueSens(pContexte) ;

    if (string("0CHEM") == sSens)
    {
      string sNodeChem = (*iter)->getNode() ;
      sNom  = "" ;
      sDate = "" ;
      iter++ ;

      // on charge les donn�es de la chemise
      while ((FoldersArray.end() != iter) && ((*iter)->getColonne() > iColBase + 1))
      {
        sSens = (*iter)->getLexiqueSens(pContexte) ;

        // Folder name
        //
        if (string("0INTI") == sSens)
        {
          iter++ ;

          while ((FoldersArray.end() != iter) && ((*iter)->getColonne() > iColBase + 2))
          {
            // must be a free text
            string sElemLex = (*iter)->getLexique() ;

            if (string("�?????") == sElemLex)
              sNom = (*iter)->getTexteLibre() ;

            iter++ ;
          }
        }
        // Dates
        else if (string("KOUVR") == sSens)
        {
          iter++ ;
          int iLigneBase = (*iter)->getLigne() ;
          // gereDate* pDate = new gereDate(pContexte);
          string sUnite  = "" ;
          string sFormat = "" ;
          string sValeur = "" ;
          string sTemp   = "" ;

          while ((iter != FoldersArray.end()) &&
                         ((*iter)->getLigne() == iLigneBase))
          {
            if (((*iter)->pDonnees->lexique)[0] == '�')
            {
              sTemp   = (*iter)->getLexique() ;
              pContexte->getDico()->donneCodeSens(&sTemp, &sFormat) ;
              sValeur = (*iter)->getComplement() ;
              sTemp   = (*iter)->getUnit() ;
              pContexte->getDico()->donneCodeSens(&sTemp, &sUnite) ;
              iter++ ;
              break ;
            }

            iter++ ;
          }

          // sFormat est du type �D0;03
          if ((sFormat != "") && (sFormat[1] == 'T') &&
                      (sValeur != ""))
          {
            if (sUnite == "2DA02")
              sDate = string(sValeur, 0, 8);
          }
        }
        else
          iter++ ;
      }

      if (string("") != sNom)
      {
        NSChemiseInfo ChemInfo ;
        ChemInfo.sNodeChemise = sNodeChem ;
        strcpy(ChemInfo.pDonnees->nom, sNom.c_str()) ;
        strcpy(ChemInfo.pDonnees->creation, sDate.c_str()) ;

        // Pr�paration de l'intitul� de la chemise
        char chAffiche[200] ;
        ChemInfo.donneIntitule(chAffiche, sLang) ;

        pChemisesArray->push_back(new NSChemiseInfo(ChemInfo)) ;      }
    }
    else
      iter++ ;
  }
  return true ;
}

bool
NSPatInfo::CreeContribution(bool bInitiale)
{
try
{
	char szDateJour[15] ;
	char szHeure[7] ;

	donne_date_duJour(szDateJour) ;
	donne_heure(szHeure) ;
	strcat(szDateJour, szHeure) ;
	string sPidsUtil = pContexte->getUtilisateurID() ;

	// Construction de la patpatho de la nouvelle contribution
	NSPatPathoArray PatPathoArray(pContexte) ;

	PatPathoArray.ajoutePatho("LCTRI1", 0) ;

  Message Msg ;

	// Utilisateur
	PatPathoArray.ajoutePatho("HUTIL1", 1) ;
	Msg.SetComplement(sPidsUtil.c_str()) ;
	PatPathoArray.ajoutePatho("�SPID1", &Msg, 2) ;

  Msg.Reset() ;

	// Date d'ouverture
	PatPathoArray.ajoutePatho("KOUVR1", 1) ;
	Msg.SetUnit("2DA021") ;
	Msg.SetComplement(szDateJour) ;
	PatPathoArray.ajoutePatho("�T0;19", &Msg, 2) ;

	//
	// On cr�e la liaison de la contribution avec le document root	//	// La contribution initiale est enregistr�e dans ::createPatient	string sNodeRoot = pGraphPerson->getRootTree() ;	sContribution = pGraphPerson->setTree(&PatPathoArray, "") ;	NSLinkManager Link(pContexte, pGraphPerson->pDataGraph) ;	Link.etablirLien(sNodeRoot, NSRootLink::personContribution, sContribution) ;	if (!bInitiale)	{		// pour les contributions ult�rieures on update directement		NSVectPatPathoArray VectU ;		VectU.push_back(new NSPatPathoArray(PatPathoArray)) ;
		bool bContribCreated = pGraphPerson->updateTrees(&VectU, &sContribution) ;		if (!bContribCreated)		{			sContribution = "" ;			return false ;		}		// sContribution = pGraphPerson->pDataGraph->getLastContribution();	}	return true ;}
catch (...)
{
	erreur("Exception NSPatInfo::CreeContribution.", standardError, 0) ;
	return false;
}
}

bool
NSPatInfo::FermeContribution()
{
try
{
  char szDateJour[15] ;
  char szHeure[7] ;

  donne_date_duJour(szDateJour) ;
  donne_heure(szHeure) ;
  strcat(szDateJour, szHeure) ;

  //
  // on charge l'arbre qui correspond � la contribution en cours
  //
  NSPatPathoArray PatPathoArray(pContexte) ;
  string sRosace = "" ;
  if (false == pGraphPerson->getTree(sContribution, &PatPathoArray, &sRosace))
    return false ;

  NSPatPathoArray PatPatho(pContexte) ;
  PatPatho.ajoutePatho("KFERM1", 0) ;
  Message	Msg ;
  Msg.SetUnit("2DA021") ;
  Msg.SetComplement(szDateJour) ;
  PatPatho.ajoutePatho("�T0;19", &Msg, 1) ;

  PatPathoArray.InserePatPatho(PatPathoArray.end(), &PatPatho, 1) ;

  NSVectPatPathoArray VectU ;
  VectU.push_back(new NSPatPathoArray(PatPathoArray)) ;
  string sNewTreeId ;
  if (false == pGraphPerson->updateTrees(&VectU, &sNewTreeId))
    return false ;

  sContribution = "";

  return true ;
}
catch (...)
{
	erreur("Exception NSPatInfo::FermeContribution.", standardError, 0) ;
	return false ;
}
}

bool
NSPatInfo::initCorrespPIDS(NSPidsInfo* pPidsInfo, string sPersonID)
{
	//
	// Cr�ation d'une fiche d'acc�s au fichier PIDS
	//
	NSPids* pPids = new NSPids(pContexte, pidsCorresp) ;
	//
	// Ouverture du fichier
	//
	pPids->lastError = pPids->open() ;
	if (pPids->lastError != DBIERR_NONE)
	{
		erreur("Il est impossible d'ouvrir le fichier des PIDS.", standardError, pPids->lastError) ;
		delete pPids ;
		return false ;
	}

    pPids->lastError = pPids->chercheClef(&sPersonID,
                                                "",
                                                0,
                                                keySEARCHEQ,
                                                dbiWRITELOCK);

    if (pPids->lastError != DBIERR_NONE)
    {
        erreur("Impossible de trouver le PIDS du correspondant en cours.", standardError, pPids->lastError) ;
        pPids->close() ;
        delete pPids;
        return false;
    }

    //
    // On r�cup�re l'enregistrement
    //
    pPids->lastError = pPids->getRecord();

    if (pPids->lastError != DBIERR_NONE)
    {
        erreur("Le fichier des PIDS correspondants est endommag�.", standardError, pPids->lastError) ;
        pPids->close() ;
        delete pPids;
        return false;
    }

    // Chargement des donn�es du nouveau PIDS (qui garde les m�mes NSS et RootDoc)
    strcpy(pPidsInfo->pDonnees->nss,        pPids->pDonnees->nss);
    strcpy(pPidsInfo->pDonnees->rootdoc,    pPids->pDonnees->rootdoc);
    strcpy(pPidsInfo->pDonnees->nom,        pPids->pDonnees->nom) ;
    strcpy(pPidsInfo->pDonnees->prenom,     pPids->pDonnees->prenom) ;
    strcpy(pPidsInfo->pDonnees->code,       pPids->pDonnees->code) ;
    strcpy(pPidsInfo->pDonnees->sexe,       pPids->pDonnees->sexe) ;
    strcpy(pPidsInfo->pDonnees->naissance,  pPids->pDonnees->naissance) ;

    pPids->close() ;
    delete pPids ;

    return true ;
}

string
NSPatInfo::getIPPEnCours(string sSite, string* psOuvre, string* psFerme)
{
	if (NULL != psOuvre)
		*psOuvre = string("") ;
  if (NULL != psFerme)
		*psFerme = string("") ;

	// Get IDs Library
	//
  NSPatPathoArray pptIdent(pContexte) ;
	if (false == pGraphPerson->getLibIDsPpt(&pptIdent))
		return string("") ;

	string sCurrentIpp ;
	bool bExistIPP = pGraphPerson->IPPEnCours(&pptIdent, sSite, &sCurrentIpp, psOuvre, psFerme) ;
	if (false == bExistIPP)
  	return string("") ;

	return sCurrentIpp ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSPatInfo::operator=(NSPatInfo src)
//  Description:	Op�rateur d'affectation
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
NSPatInfo&
NSPatInfo::operator=(NSPatInfo src)
{
	if (this == &src)
		return *this ;

	*pDonnees 	   = *(src.pDonnees);
	*pCorrespArray = *(src.pCorrespArray);
	pContexte      = src.pContexte;

	*pGraphPerson  = *(src.pGraphPerson);
	*pGraphAdr     = *(src.pGraphAdr);
	sChez          = src.sChez;

/*
  if (NULL != pDocHis)
  {
    delete pDocHis ;
    pDocHis = 0 ;
  }
  if (NULL != src.pDocHis)
    pDocHis = new NSHISTODocument(*(src.pDocHis)) ;
*/

  if (NULL != pHealthTeam)
  {
    delete pHealthTeam ;
    pHealthTeam = 0 ;
  }
  if (NULL != src.pHealthTeam)
    pHealthTeam = new NSHealthTeam(*(src.pHealthTeam)) ;

	return *this ;
}

string
NSPatInfo::fabriqueAgeLabel(string sLang)
{
  if (string("") == pDonnees->sNaissance)
    return string("") ;

  NVLdVTemps tNaissance ;
  if (false == tNaissance.initFromDate(pDonnees->sNaissance))
    return string("") ;

  NVLdVTemps tNow ;
  tNow.takeTime() ;

  unsigned long lDaysOfLife = tNow.daysBetween(tNaissance) ;

  if (lDaysOfLife < 3)
    return fabriqueAgeLabelHours(sLang) ;
  if (lDaysOfLife < 90)
    return fabriqueAgeLabelDays(sLang) ;
  if (lDaysOfLife < 700)
    return fabriqueAgeLabelMonths(sLang) ;

  return fabriqueAgeLabelYears(sLang) ;
}

string
NSPatInfo::fabriqueAgeLabelYears(string sLang)
{
  if (string("") == pDonnees->sNaissance)
    return string("") ;

  char szCurrentDate[9] ;
  donne_date_duJour(szCurrentDate) ;

  int iCurrentAge = donne_age(szCurrentDate, (char *)(pDonnees->sNaissance.c_str())) ;
  if (iCurrentAge <= 0)
    return string("") ;

  // Get the lib of "year(s)"
  //
  string sCodeLexAn = string("2DAT33") ;
  NSPathologData Data ;
  if (false == pContexte->getDico()->trouvePathologData(sLang, &sCodeLexAn, &Data))
    return string("") ;

  int iGenre ;
  Data.donneGenre(&iGenre) ;
  if (iCurrentAge > 1)
    Data.donneGenrePluriel(&iGenre) ;
  string sLibel ;
  NSGenerateur* pGene = pContexte->getDico()->pGenerateur ;
  pGene->donneLibelleAffiche(&sLibel, &Data, iGenre) ;

  char szAge[4] ;
  string sTitre = string(itoa(iCurrentAge, szAge, 10)) + string(" ") + sLibel ;

  return sTitre ;
}

string
NSPatInfo::fabriqueAgeLabelMonths(string sLang)
{
  if (string("") == pDonnees->sNaissance)
    return string("") ;

  char szCurrentDate[9] ;
  donne_date_duJour(szCurrentDate) ;

  int iCurrentAge = donne_age_mois(szCurrentDate, (char *)(pDonnees->sNaissance.c_str())) ;
  if (iCurrentAge <= 0)
    return string("") ;

  // Get the lib of "month(s)"
  //
  string sCodeLexAn = string("2DAT21") ;
  NSPathologData Data ;
  if (false == pContexte->getDico()->trouvePathologData(sLang, &sCodeLexAn, &Data))
    return string("") ;

  int iGenre ;
  Data.donneGenre(&iGenre) ;
  if (iCurrentAge > 1)
    Data.donneGenrePluriel(&iGenre) ;
  string sLibel ;
  NSGenerateur* pGene = pContexte->getDico()->pGenerateur ;
  pGene->donneLibelleAffiche(&sLibel, &Data, iGenre) ;

  char szAge[4] ;
  string sTitre = string(itoa(iCurrentAge, szAge, 10)) + string(" ") + sLibel ;

  return sTitre ;
}

string
NSPatInfo::fabriqueAgeLabelDays(string sLang)
{
  NVLdVTemps tNaissance ;
  if (false == tNaissance.initFromDate(pDonnees->sNaissance))
    return string("") ;

  NVLdVTemps tNow ;
  tNow.takeTime() ;

  unsigned long lDaysOfLife = tNow.daysBetween(tNaissance) ;
  if (lDaysOfLife <= (unsigned long)0)
    return string("") ;

  // Get the lib of "day(s)"
  //
  string sCodeLexAn = string("2DAT01") ;
  NSPathologData Data ;
  if (false == pContexte->getDico()->trouvePathologData(sLang, &sCodeLexAn, &Data))
    return string("") ;

  int iCurrentAge = int(lDaysOfLife) ;

  int iGenre ;
  Data.donneGenre(&iGenre) ;
  if (iCurrentAge > 1)
    Data.donneGenrePluriel(&iGenre) ;
  string sLibel ;
  NSGenerateur* pGene = pContexte->getDico()->pGenerateur ;
  pGene->donneLibelleAffiche(&sLibel, &Data, iGenre) ;

  char szAge[10] ;
  string sTitre = string(itoa(iCurrentAge, szAge, 10)) + string(" ") + sLibel ;

  return sTitre ;
}

string
NSPatInfo::fabriqueAgeLabelHours(string sLang)
{
  return string("") ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSPatInfo::operator==(NSPatInfo src)
//  Description:	Op�rateur de comparaison
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
int NSPatInfo::operator == ( NSPatInfo& o )
{
	int egal = 1;

	if (!(*pDonnees 			== *(o.pDonnees)))
		egal = 0;
	if (!(*pCorrespArray 	== *(o.pCorrespArray)))
		egal = 0;

  return egal;
}

//***************************************************************************
//
// Fonction globale StringTitre (utilis�e par NSUtilisateur et NSCorrespondant)
// -> Renvoie la string titre en fonction du type (caract�re)
//
//***************************************************************************

string StringTitre(NSContexte* pContexte, string sTypeTitre, string sLang)
{
	string titre("");

	if (string("") == sTypeTitre)
		return titre ;

	pContexte->getDico()->donneLibelle(sLang, &sTypeTitre, &titre) ;
  titre[0] = pseumaj(titre[0]) ;
  titre += string(" ") ;

/*
  if ((string("") == sLang) || (string("fr") == string(sLang, 0, 2)))
	{
		switch (typeTitre[0])
		{
			case 'O':	titre = string("Docteur ");
								break;

			case 'P':	titre = string("Professeur ");
								break;

			case '1':	titre = string("M. le Docteur ");
								break;

			case '2':	titre = string("Mme le Docteur ");
								break;

			case 'R':	titre = string("M. le Professeur ");
								break;

			case 'M':	titre = string ("Mme le Professeur ");
								break;
		}
	}
	else
		if (sLang == "en")
		{
			switch (typeTitre[0])
			{
				case 'O':	titre = string("Doctor ");
									break;

				case 'P':	titre = string("Professor ");
									break;

				case '1':	titre = string("M. the Doctor ");
									break;

				case '2':	titre = string("Mrs the Doctor ");
									break;

				case 'R':	titre = string("M. the Professor ");
									break;

				case 'M':	titre = string ("Mrs the Professor ");
									break;
				}
    }
*/

	return titre ;
}

//***************************************************************************
//
// Fonction globale StringAvantTitre (utilis�e par NSUtilisateur et NSCorrespondant)
// -> Renvoie la string avant titre en fonction du type (caract�re)
//
//***************************************************************************

string StringAvantTitre(string sTypeTitre, string sLang)
{
	string avant("") ;

	if (string("") == sTypeTitre)
		return avant ;

	if ((string("") == sLang) || (string("fr") == string(sLang, 0, 2)))
	{
  	if ((string("HDOCT1") == sTypeTitre) ||
        (string("HPROF1") == sTypeTitre))
    	avant = string("au") ;
		else
    	avant = string("�") ;
	}
  else if (string("en") == string(sLang, 0, 2))
  {
  	avant = string("to") ;
  }

	return avant;
}

//***************************************************************************
//
// Impl�mentation des m�thodes NSUtilisateurData
//
//***************************************************************************

//---------------------------------------------------------------------------
//  Function:    NSUtilisateurData::NSUtilisateurData()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSUtilisateurData::NSUtilisateurData()
{
	metAZero();
}

//---------------------------------------------------------------------------
//  Fonction:		NSUtilisateurData::NSUtilisateurData(NSUtilisateurData& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSUtilisateurData::NSUtilisateurData(NSUtilisateurData& rv)
{
	_sNss        = rv._sNss ;
	_sLogin      = rv._sLogin ;
	_sCode       = rv._sCode ;
	_sSexe       = rv._sSexe ;
	_sNom        = rv._sNom ;
	_sPrenom     = rv._sPrenom ;
	_sType       = rv._sType ;
	_sMessagerie = rv._sMessagerie ;
	_sLang       = rv._sLang ;
	_sMetier     = rv._sMetier ;
	_sSpecialite = rv._sSpecialite ;
	_sVille      = rv._sVille ;
}

//---------------------------------------------------------------------------
//  Met � z�ro les variables de la fiche
//---------------------------------------------------------------------------
void
NSUtilisateurData::metAZero()
{
	_sNss        = string("") ;
	_sLogin      = string("") ;
	_sCode       = string("") ;
	_sSexe       = string("") ;
	_sNom        = string("") ;
	_sPrenom     = string("") ;
	_sType       = string("") ;
	_sMessagerie = string("") ;
	_sLang       = string("") ;
	_sMetier     = string("") ;
	_sSpecialite = string("") ;
	_sVille      = string("") ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSUtilisateurData::operator=(NSUtilisateurData src)
//  Description:	Op�rateur =
//  Retour:			R�f�rence sur l'objet cible
//---------------------------------------------------------------------------
NSUtilisateurData&
NSUtilisateurData::operator=(NSUtilisateurData src)
{
	if (this == &src)
		return *this ;

	_sNss        = src._sNss ;
	_sLogin      = src._sLogin ;
	_sCode       = src._sCode ;
	_sSexe       = src._sSexe ;
	_sNom        = src._sNom ;
	_sPrenom     = src._sPrenom ;
	_sType       = src._sType ;
	_sMessagerie = src._sMessagerie ;
	_sLang       = src._sLang ;
	_sMetier     = src._sMetier ;
	_sSpecialite = src._sSpecialite ;
	_sVille      = src._sVille ;

	return *this ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSUtilisateurData::operator==(NSUtilisateurData& o)
//  Description:	Op�rateur de comparaison
//  Retour:			0 ou 1
//---------------------------------------------------------------------------
int
NSUtilisateurData::operator == ( NSUtilisateurData& o )
{
	return (_sNss == o._sNss) ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSUtilisateurData::donneTitre()
//  Description:	renvoie le titre de l'utilisateur en fonction des donnees
//  Retour:			la string contenant le titre
//---------------------------------------------------------------------------
string
NSUtilisateurData::donneTitre(NSContexte* pContexte, string sLang)
{
	string titre("") ;

	if ((string("") == sLang) || (string("fr") == string(sLang, 0, 2)))
	{
  	if ((string("HDOCT1") == _sType) ||
        (string("HPROF1") == _sType))
			titre = string("le ") ;
	}

	titre += StringTitre(pContexte, _sType, sLang) ;

	if (string("") != _sPrenom)
  	titre += _sPrenom + string(" ") ;

	titre += _sNom ;

  return titre ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSUtilisateurData::donneAvantTitre()
//  Description:	renvoie l'avant-titre (au ou �) de l'utilisateur en fonction des donnees
//  Retour:			la string contenant l'avant-titre
//---------------------------------------------------------------------------

string
NSUtilisateurData::donneAvantTitre(string sLang)
{
	return StringAvantTitre(_sType, sLang) ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSUtilisateurData::donneSignature()
//  Description:	renvoie le titre de l'utilisateur en fonction des donnees
//  Retour:			la string contenant le titre signature
//---------------------------------------------------------------------------

string
NSUtilisateurData::donneSignature(NSContexte* pContexte, string sLang)
{
	string titre("") ;

	titre = StringTitre(pContexte, _sType, sLang) ;

	if (string("") != _sPrenom)
  	titre += _sPrenom + string(" ") ;

	titre += _sNom ;

  return titre ;
}

//***************************************************************************
//
// Impl�mentation des m�thodes NSUtiliInfo
//
//***************************************************************************

//---------------------------------------------------------------------------
//  Constructeur par d�faut
//---------------------------------------------------------------------------
NSUtiliInfo::NSUtiliInfo(NSContexte* pCtx)
            :NSCorrespondantInfo(pCtx)
{
	// Cr�e l'objet de donn�es
	pDonnees   	 = new NSUtilisateurData() ;
	pGraphPerson = new NSPersonGraphManager(pContexte) ;

	_sTitre                = "" ;
	_sCivilProf            = "" ;
	_sCivil                = "" ;

	_sLogin                = "" ;
	_sPasswd               = "" ;
	_sUserType             = "" ;
	_sPasswordType         = "" ;
	_sDatePasswordCreation = "" ;
	_sValidityDuration     = "" ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSUtiliInfo::NSUtiliInfo(NSBasicAttributeArray* pAttribute)
//  Description:	Constructeur avec NSBasicAttributeArray
//                  (pour les acc�s aux bases a l'aide du pilot)
//  Retour:			Rien
//---------------------------------------------------------------------------
NSUtiliInfo::NSUtiliInfo(NSBasicAttributeArray* pAttribute, NSContexte* pCtx)
            :NSCorrespondantInfo(pCtx)
{
	// Cr�e l'objet de donn�es
	pDonnees 	   = new NSUtilisateurData() ;
	pGraphPerson = new NSPersonGraphManager(pContexte) ;

  _sTitre                = "" ;
  _sCivilProf            = "" ;
  _sCivil                = "" ;
  _sLogin                = "" ;
  _sPasswd               = "" ;
  _sUserType             = "" ;
  _sPasswordType         = "" ;
  _sDatePasswordCreation = "" ;
  _sValidityDuration     = "" ;

  if ((NULL != pAttribute) && (false == pAttribute->empty()))
  {
		NSBasicAttributeIter iter = pAttribute->begin() ;

		for (iter; iter != pAttribute->end(); iter++)
		{
    	if      ((*iter)->getBalise() == FIRST_NAME)
    		pDonnees->_sPrenom = (*iter)->getText() ;
    	else if ((*iter)->getBalise() == LAST_NAME)
    		pDonnees->_sNom    = (*iter)->getText() ;
    	else if((*iter)->getBalise() == SEX)
    		pDonnees->_sSexe   = (*iter)->getText() ;
    	else if((*iter)->getBalise() == PIDS)
    		pDonnees->_sNss    = (*iter)->getText() ;
    	else if((*iter)->getBalise() == TITLE_CODE)
    	{
    		pDonnees->_sType = (*iter)->getText() ;
/*
    	string sCivilite = (*iter)->getText() ;

      if      (sCivilite == string("HDOCT1"))
      	pDonnees->_sType = string("O") ;
      else if (sCivilite == string("HPROF1"))
      	pDonnees->_sType = string("P") ;
      else if (sCivilite == string("HMOND1"))
      	pDonnees->_sType = string("1") ;
      else if (sCivilite == string("HMADD1"))
      	pDonnees->_sType = string("2") ;
      else if (sCivilite == string("HMONF1"))
      	pDonnees->_sType = string("R") ;
      else if (sCivilite == string("HMADP1"))
      	pDonnees->_sType = string("M") ;
      else if (sCivilite == string("HMONP1"))
      	pDonnees->_sType = string("A") ;
      else if (sCivilite == string("HMADR1"))
      	pDonnees->_sType = string("B") ;
      else if (sCivilite == string("HMADE1"))
      	pDonnees->_sType = string("C") ;
*/
    	}
    	else if ((*iter)->getBalise() == PROFESSION)
    		pDonnees->_sMetier     = (*iter)->getText() ;
    	else if ((*iter)->getBalise() == SPECIALITY)
    		pDonnees->_sSpecialite = (*iter)->getText() ;
    	else if ((*iter)->getBalise() == CITY_PRO)
    		pDonnees->_sVille      = (*iter)->getText() ;
		}
	}
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSUtiliInfo::NSUtiliInfo(NSUtiliInfo& rv)
            :NSCorrespondantInfo(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees 	  	= new NSUtilisateurData() ;
	//
	// Copie les valeurs du NSUtiliInfo d'origine
	//
	*pDonnees     = *(rv.pDonnees) ;

	pGraphPerson  = new NSPersonGraphManager(*(rv.pGraphPerson)) ;

  _sTitre                  = rv._sTitre ;
  _sCivilProf              = rv._sCivilProf ;
  _sCivil                  = rv._sCivil ;
  _sLogin                  = rv._sLogin ;
  _sPasswd                 = rv._sPasswd ;
  _sUserType               = rv._sUserType ;
  _sPasswordType           = rv._sPasswordType ;
  _sDatePasswordCreation   = rv._sDatePasswordCreation ;
  _sValidityDuration       = rv._sValidityDuration ;
}

//---------------------------------------------------------------------------
//  Constructeur � partir d'un NSUtilisateurChoisi*
//---------------------------------------------------------------------------
NSUtiliInfo::NSUtiliInfo(NSUtilisateurChoisi* pUtilChoisi)
						:NSCorrespondantInfo(pUtilChoisi->NSUtiliInfo::pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees 	  = new NSUtilisateurData() ;
	//
	// Copie les valeurs du NSUtilisateur
	//
  if (NULL != pUtilChoisi)
  {
		*pDonnees     = *(pUtilChoisi->getData()) ;

		pGraphPerson = new NSPersonGraphManager(*(pUtilChoisi->pGraphPerson)) ;

  	_sTitre                = pUtilChoisi->_sTitre ;
  	_sCivilProf            = pUtilChoisi->_sCivilProf ;
  	_sCivil                = pUtilChoisi->_sCivil ;
  	_sLogin                = pUtilChoisi->_sLogin ;
  	_sPasswd               = pUtilChoisi->_sPasswd ;
  	_sUserType             = pUtilChoisi->_sUserType ;
  	_sPasswordType         = pUtilChoisi->_sPasswordType ;
  	_sDatePasswordCreation = pUtilChoisi->_sDatePasswordCreation ;
  	_sValidityDuration     = pUtilChoisi->_sValidityDuration ;
	}
  else
  {
  	pGraphPerson = 0 ;

  	_sTitre                = string("") ;
  	_sCivilProf            = string("") ;
  	_sCivil                = string("") ;
  	_sLogin                = string("") ;
  	_sPasswd               = string("") ;
  	_sUserType             = string("") ;
  	_sPasswordType         = string("") ;
  	_sDatePasswordCreation = string("") ;
  	_sValidityDuration     = string("") ;
  }
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSUtiliInfo::~NSUtiliInfo()
{
}

//---------------------------------------------------------------------------
//  Fonction:		NSUtiliInfo::initAdresseInfo()
//  Description:	Recherche l'adresse de l'utilisateur.
//  Retour:			true->l'adresse est initialis�e false->echec
//---------------------------------------------------------------------------
bool
NSUtiliInfo::initAdresseInfo()
{
	return true ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSUtiliInfo::operator=(NSUtiliInfo src)
//  Description:	Op�rateur d'affectation
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
NSUtiliInfo&
NSUtiliInfo::operator=(NSUtiliInfo src)
{
	if (this == &src)
		return *this ;

	*pDonnees 	  = *(src.pDonnees) ;
	*pGraphPerson = *(src.pGraphPerson) ;

  _sTitre                = src._sTitre ;
  _sCivilProf            = src._sCivilProf ;
  _sCivil                = src._sCivil ;
  _sLogin                = src._sLogin ;
  _sPasswd               = src._sPasswd ;
  _sUserType             = src._sUserType ;
  _sPasswordType         = src._sPasswordType ;
  _sDatePasswordCreation = src._sDatePasswordCreation ;
  _sValidityDuration     = src._sValidityDuration ;

  pContexte = src.pContexte ;

	return *this ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSUtiliInfo::operator==(NSUtiliInfo src)
//  Description:	Op�rateur de comparaison
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
int NSUtiliInfo::operator == ( NSUtiliInfo& o )
{
	int egal = 1 ;

	if (!(*pDonnees == *(o.pDonnees)))
  	egal = 0 ;

	return egal ;
}

bool
NSUtiliInfo::pwdNeedChange()
{
	if      ("T" == _sPasswordType)
		return true ;
	else if ("F" == _sPasswordType)
		return false ;
	else if ("J" == _sPasswordType)
	{
    // Calcul de la date du jour et de la date d'expiration
    char   szDateJour[10] ;
    string sDateExpiration ;

    donne_date_duJour(szDateJour) ;
    sDateExpiration = _sDatePasswordCreation ;

    for (int i = 0; i < atoi(_sValidityDuration.c_str()); i++)
    	incremente_date(sDateExpiration) ;

    if (sDateExpiration < string(szDateJour))
    	return true ;

    return false ;
	}

	return false ;
}

bool
NSUtiliInfo::changePassword()
{
	char szDateJour[10] ;
	donne_date_duJour(szDateJour) ;

	::MessageBox(0, "Votre mot de passe a expir�. Vous devez saisir un nouveau mot de passe.", "Message Nautilus", MB_OK) ;

    /********************************************
    // modification d'un code utilisateur
    // on ne contr�le pas l'ancien mot de passe pour l'administrateur
    // Saisie du nouveau mot de passe
    CodeUtilisateurDialog *pCodeDlg = new CodeUtilisateurDialog(this, "", pContexte) ;

    if (pCodeDlg->Execute() == IDCANCEL)
    {
        delete pCodeDlg ;
        return false;
    }

    sPasswd = pCodeDlg->sCodeUtil ;
    sDatePasswordCreation = string(szDateJour);
    delete pCodeDlg ;
    **********************************************/

	return true ;
}

//***************************************************************************
//
// Impl�mentation des m�thodes NSCorrespondantData
//
//***************************************************************************

/*
//---------------------------------------------------------------------------
//  Function:    NSCorrespondantData::NSCorrespondantData()
//
//  Description: Constructeur.
//---------------------------------------------------------------------------
NSCorrespondantData::NSCorrespondantData()
{
	//
	// Met les champs de donn�es � z�ro
	//
	metAZero() ;
}


//---------------------------------------------------------------------------
//  Function:    NSCorrespondantData::metABlanc()
//
//  Description: Met � blanc les variables.
//---------------------------------------------------------------------------
void NSCorrespondantData::metAZero()
{
	_sNss        = string("") ;
  _sCode       = string("") ;
  _sNom        = string("") ;
  _sPrenom     = string("") ;
  _sSexe       = string("") ;
  _sAdress     = string("") ;
  _sDocteur    = string("") ;
  _sTelePor    = string("") ;
  _sTeleBur    = string("") ;
  _sNbExemp    = string("") ;
  _sMessagerie = string("") ;
  _sFonction   = string("") ;
  _sActif      = string("") ;
 	_sLang       = string("") ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCorrespondantData::NSCorrespondantData(NSCorrespondantData& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCorrespondantData::NSCorrespondantData(NSCorrespondantData& rv)
{
	_sNss        = rv._sNss ;
  _sCode       = rv._sCode ;
  _sNom        = rv._sNom ;
  _sPrenom     = rv._sPrenom ;
  _sSexe       = rv._sSexe ;
  _sAdress     = rv._sAdress ;
  _sDocteur    = rv._sDocteur ;
  _sTelePor    = rv._sTelePor ;
  _sTeleBur    = rv._sTeleBur ;
  _sNbExemp    = rv._sNbExemp ;
  _sMessagerie = rv._sMessagerie ;
  _sFonction   = rv._sFonction ;
  _sActif      = rv._sActif ;
 	_sLang       = rv._sLang ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCorrespondantData::operator=(NSCorrespondantData src)
//  Description:	Op�rateur =
//  Retour:			R�f�rence sur l'objet cible
//---------------------------------------------------------------------------
NSCorrespondantData&
NSCorrespondantData::operator=(NSCorrespondantData src)
{
	if (this == &src)
		return *this ;

	_sNss        = src._sNss ;
  _sCode       = src._sCode ;
  _sNom        = src._sNom ;
  _sPrenom     = src._sPrenom ;
  _sSexe       = src._sSexe ;
  _sAdress     = src._sAdress ;
  _sDocteur    = src._sDocteur ;
  _sTelePor    = src._sTelePor ;
  _sTeleBur    = src._sTeleBur ;
  _sNbExemp    = src._sNbExemp ;
  _sMessagerie = src._sMessagerie ;
  _sFonction   = src._sFonction ;
  _sActif      = src._sActif ;
 	_sLang       = src._sLang ;

	return *this ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCorrespondantData::operator==(NSCorrespondantData& o)
//  Description:	Op�rateur de comparaison
//  Retour:			0 ou 1
//---------------------------------------------------------------------------
int
NSCorrespondantData::operator == ( NSCorrespondantData& o )
{
	if ((strcmp(code,   	  	o.code) 			== 0) &&
			(strcmp(nom, 		  		o.nom) 				== 0) &&
			(strcmp(prenom, 	  	o.prenom) 		== 0) &&
			(strcmp(sexe, 	  		o.sexe) 			== 0) &&
			(strcmp(adresse,   		o.adresse) 		== 0) &&
			(strcmp(docteur,   		o.docteur) 		== 0) &&
			(strcmp(telepor,   		o.telepor) 		== 0) &&
			(strcmp(telebur,   		o.telebur) 		== 0) &&
			(strcmp(nb_exemp,  		o.nb_exemp) 	== 0) &&
			(strcmp(messagerie,		o.messagerie)	== 0) &&
			(strcmp(fonction,  		o.fonction)		== 0) &&
			(strcmp(actif,  	  	o.actif)			== 0)
			)
		return 1;
	else
		return 0;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCorrespondantData::donneTitre()
//  Description:	renvoie le titre du correspondant en fonction des donnees
//  Retour:			la string contenant le titre
//---------------------------------------------------------------------------
string
NSCorrespondantData::donneTitre(string sLang)
{
	string titre("") ;

	titre = StringTitre(docteur, sLang) ;

	if (string("") != _sPrenom)
		titre = titre + _sPrenom + string(" ") ;

	titre += _sNom ;

	return titre ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCorrespondantData::donneAvantTitre()
//  Description:	renvoie l'avant-titre (au ou �) du corresp en fonction des donnees
//  Retour:			la string contenant l'avant-titre
//---------------------------------------------------------------------------
string
NSCorrespondantData::donneAvantTitre(string sLang)
{
  return StringAvantTitre(docteur, sLang) ;
}
*/

//***************************************************************************
//
// Impl�mentation des m�thodes NSCorrespondantInfo
//
//***************************************************************************

//---------------------------------------------------------------------------
//  Fonction:		NSCorrespondantInfo::NSCorrespondantInfo(NSSuper* pSuper)
//  Description:	Constructeur avec superviseur pour l'acc�s aux bases
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCorrespondantInfo::NSCorrespondantInfo(NSContexte* pCtx)
                    :NSRoot(pCtx)
{
	// Cr�e l'objet de donn�es
	pDonnees     = new NSUtilisateurData() ;
	pGraphPerson = new NSPersonGraphManager(pContexte) ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCorrespondantInfo::~NSCorrespondantInfo()
//  Description:	Destructeur
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCorrespondantInfo::~NSCorrespondantInfo()
{
	delete pDonnees ;
	delete pGraphPerson ;
	// pas de delete de pSuper
}

//---------------------------------------------------------------------------
//  Fonction:		NSCorrespondantInfo::NSCorrespondantInfo(NSCorrespondantInfo& rv)
//  Description:	Constructeur copie
//  Retour:			Rien
//---------------------------------------------------------------------------
NSCorrespondantInfo::NSCorrespondantInfo(NSCorrespondantInfo& rv)
                    :NSRoot(rv.pContexte)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees 	   = new NSUtilisateurData() ;
	pGraphPerson = new NSPersonGraphManager(pContexte) ;
	//
	// Copie les valeurs du NSCorrespondantInfo d'origine
	//
	*pDonnees 		= *(rv.pDonnees) ;
	*pGraphPerson = *(rv.pGraphPerson) ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCorrespondantInfo::initAdresseInfo()
//  Description:	Recherche l'adresse du Correspondant.
//  Retour:			true->l'adresse est initialis�e false->echec
//---------------------------------------------------------------------------
bool NSCorrespondantInfo::initAdresseInfo()
{
	return false ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCorrespondantInfo::operator=(NSCorrespondantInfo src)
//  Description:	Op�rateur d'affectation
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
NSCorrespondantInfo&
NSCorrespondantInfo::operator=(NSCorrespondantInfo src)
{
	if (this == &src)
		return *this ;

	*pDonnees 	  = *(src.pDonnees) ;
	*pGraphPerson = *(src.pGraphPerson) ;
	pContexte     = src.pContexte ;

	return *this ;
}

//---------------------------------------------------------------------------
//  Fonction:		NSCorrespondantInfo::operator==(NSCorrespondantInfo src)
//  Description:	Op�rateur de comparaison
//  Retour:			R�f�rence de l'objet cible
//---------------------------------------------------------------------------
int
NSCorrespondantInfo::operator == ( NSCorrespondantInfo& o )
{
	int egal = 1 ;

	if (!(*pDonnees == *(o.pDonnees)))
		egal = 0 ;

	return egal ;
}

bool
NSCorrespondantInfo::GetDataFromGraph(NSPatPathoArray* pPPT)
{
	PatPathoIter iter ;
	string       sElemLex, sSens, sType, sTemp ;
	string       lang = "" ;

	NSPatPathoArray PatPathoArray(pContexte) ;

	if (NULL != pPPT)
	{
		if (pPPT->empty())
			return false ;

		PatPathoArray = *pPPT ;
	}
	else
	{
		// on initialise la patpatho � partir du graphe
		NSDataTreeIter iterTree ;
		NSDataGraph* pDataGraph = pGraphPerson->pDataGraph ;

    if (pDataGraph->aTrees.ExisteTree("ZADMI1", pContexte, &iterTree))
    	(*iterTree)->getPatPatho(&PatPathoArray) ;
    else
    {
    	char msg[255] ;
      strcpy(msg, "Impossible de trouver l'arbre [ZADMI1] dans le graphe administratif.") ;
      erreur(msg, standardError, 0) ;
      return false ;
    }

    if (pDataGraph->aTrees.ExisteTree("DPROS1", pContexte, &iterTree))
    {
    	NSPatPathoArray PatPathoPDS(pContexte) ;
      (*iterTree)->getPatPatho(&PatPathoPDS) ;
      PatPathoArray.InserePatPatho(PatPathoArray.end(), &PatPathoPDS, 0, true) ;
    }
  }

	if (PatPathoArray.empty())
		return false ;

	//=============================================================================
	//il faut recuperer la langue d'utilisateur de la base ou de l'interface
	//Voir dans la racine du DPROS!!!!
	//=============================================================================
  string sLang = string("") ;
  if (NULL != pContexte->getUtilisateur())
		sLang  = pContexte->getUtilisateur()->donneLang() ;

	string sNom    = "" ,  sPrenom = "" , sSexe   = "" ;
	string sCivilite = "", sEMail = "";
	string sMetier = "",   sSpecialite = "", sVille = string("") ;

	iter = PatPathoArray.begin() ;
	int iColBase = (*iter)->getColonne() ;

	while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() >= iColBase))
	{
  	sSens = (*iter)->getLexiqueSens(pContexte) ;

    if (string("ZADMI") == sSens)
    {
    	iter++ ;

      while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColBase))
      {
      	sSens = (*iter)->getLexiqueSens(pContexte) ;

        // Chapitre "identit�" / Identity chapter
        if (string("LIDET") == sSens)
        {
        	int iColIdentity = (*iter)->getColonne() ;
          iter++ ;

          while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColIdentity))
          {
          	sSens = (*iter)->getLexiqueSens(pContexte) ;

            // Nom de l'utilisateur
            if ((string("LNOM0") == sSens) && (string("") == sNom))
            {
            	iter++ ;
              while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColIdentity+1))
              {
              	// on cherche ici un texte libre
                sElemLex = (*iter)->getLexique() ;
                if (string(sElemLex, 0, 3) == string("�CL"))
                	sNom = (*iter)->getTexteLibre() ;
                iter++ ;
              }
              if (string("") != sNom)
              	pDonnees->_sNom = sNom ;
            }
            // Pr�nom de l'utilisateur
            else if ((string("LNOM2") == sSens) && (sPrenom == ""))
            {
            	iter++ ;
              while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColIdentity+1))
              {
              	// on cherche ici un texte libre
                sElemLex = (*iter)->getLexique() ;
                if (string(sElemLex, 0, 3) == string("�CL"))
                	sPrenom = (*iter)->pDonnees->getTexteLibre();
                iter++ ;
              }

              if (string("") != sPrenom)
              	pDonnees->_sPrenom = sPrenom ;
            }
            // Sexe de l'utilisateur
            else if (string("LSEXE") == sSens)
            {
            	iter++ ;
              while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColIdentity+1))
              {
              	// on cherche ici un code lexique
                sTemp = (*iter)->getLexiqueSens(pContexte) ;

                if      (string("HMASC") == sTemp)
                	pDonnees->metMasculin() ;
                else if (string("HFEMI") == sTemp)
                	pDonnees->metFeminin() ;

                iter++ ;
              }
            }
            else
            	iter++ ;
          }
        }
        else
        	iter++ ;
      } // while
    } // if (sSens == string("ZADMI"))
    else if (string("DPROS") == sSens)
    {
    	iter++ ;

      while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColBase))
      {
      	sSens = (*iter)->getLexiqueSens(pContexte) ;

 /*=============================================================================
  A ajouter!!!!!
  - le code pour la langue d'utilisateur (non la langue maternelle)
                 if (sSens == string("........"))
                 {
                    sLang = string((*iter)->pDonnees->lexique) ;
                 }
                 else
 =============================================================================*/
 				//la langue par defaut = "fr"
        lang = "fr" ;

        // Chapitre "Comp�tences" / Competence chapter
        if (string("LCOMP") == sSens)
        {
        	int iColCompetences = (*iter)->getColonne() ;
          iter++ ;

          while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColCompetences))
          {
          	sSens = (*iter)->getLexiqueSens(pContexte) ;

            // metier
            if ((string("LMETI") == sSens) && (string("") == sMetier))
            {
            	// on cherche ici un edit lexique (ayant comme fils un code lexique)
              iter++ ;
              sElemLex = (*iter)->getLexique() ;
              if (string("") != sElemLex)
              	if (string(sElemLex, 0, 3) == string("�C;"))
                {
                	iter++ ;
                  while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColCompetences+2))
                  {
                  	// on cherche ici un code lexique pour un libelle
                    string sCode = (*iter)->getLexique() ;
                    pContexte->getDico()->donneLibelle(sLang, &sCode, &sMetier) ;

                    iter++ ;
                  }
                }
                else
                {
                	sMetier = (*iter)->getLexique() ;
                  if (PatPathoArray.end() != iter)
                  	iter++ ;
                }
              else
              	iter++ ;

              if (string("") != sMetier)
              	pDonnees->_sMetier = sMetier ;
            }
            // Specilit� de l'utilisateur
            else if ((string("LSPEC") == sSens) && (string("") == sSpecialite))
            {
            	// on cherche ici un edit lexique (ayant comme fils un code lexique)
              iter++ ;
              sElemLex = (*iter)->getLexique() ;
              if (string("") != sElemLex)
              	if (string(sElemLex, 0, 3) == string("�C;"))
                {
                	iter++ ;
                  while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColCompetences+2))
                  {
                  	// on cherche ici un code lexique pour un libelle
                    string sCode = (*iter)->getLexique() ;
                    pContexte->getDico()->donneLibelle(sLang, &sCode, &sSpecialite) ;

                    iter++ ;
                  }
                }
              	else
              	{
              		sSpecialite = (*iter)->getLexique() ;
                	if (PatPathoArray.end() != iter)
                		iter++ ;
              	}
            	else    //si "" on avanse
              	iter++ ;

              if (string("") != sSpecialite)
              	pDonnees->_sSpecialite = sSpecialite ;
            }
            else
            	iter++ ;
          }
 				}
        // Chapitre "civilit�"
        else if (string("HCIVO") == sSens)
        {
        	int iColCivilite = (*iter)->getColonne() ;
          iter++ ;
          while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColCivilite))
          {
          	// on cherche ici un code lexique pour un libelle
            sCivilite = string((*iter)->pDonnees->lexique) ;
            // pContexte->getDico()->donneLibelle(sLang, &sCodeLex, &sCivilite) ;

            iter++ ;
          }

          if (sCivilite != "")
          {
          	pDonnees->_sType = sCivilite ;
/*
          	if (sCivilite == string("HDOCT1"))
            	pDonnees->_sType = string("O") ;
            else if (sCivilite == string("HPROF1"))
            	pDonnees->_sType = string("P") ;
            else if (sCivilite == string("HMOND1"))
            	pDonnees->_sType = string("1") ;
            else if (sCivilite == string("HMADD1"))
            	pDonnees->_sType = string("2") ;
            else if (sCivilite == string("HMONF1"))
            	pDonnees->_sType = string("R") ;
            else if (sCivilite == string("HMADP1"))
            	pDonnees->_sType = string("M") ;
            else if (sCivilite == string("HMONP1"))
            	pDonnees->_sType = string("A") ;
            else if (sCivilite == string("HMADR1"))
            	pDonnees->_sType = string("B") ;
            else if (sCivilite == string("HMADE1"))
            	pDonnees->_sType = string("C") ;
*/
          }
        }
        // Chapitre "lieu d'exercice"
        else if (sSens == string("ULIEX"))
        {
        	int iColLiex = (*iter)->getColonne() ;
          iter++ ;

          while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColLiex))
          {
          	sSens = (*iter)->getLexiqueSens(pContexte) ;

            // Adresse mail
            if ((string("LMAIL") == sSens) && (string("") == sEMail))
            {
            	iter++ ;
              while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColLiex+1))
              {
              	// on cherche ici un texte libre
                sElemLex = (*iter)->getLexique() ;
                if (string(sElemLex, 0, 3) == string("�CL"))
                	sEMail = (*iter)->getTexteLibre() ;
                iter++ ;
              }

              if (sEMail != "")
              	pDonnees->_sMessagerie = sEMail ;
            }
            // Adresse
						else if (sSens == string("LADRE"))
						{
            	int iColAdr = (*iter)->getColonne() ;
							iter++ ;
              while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColAdr))
							{
								sSens = (*iter)->getLexiqueSens(pContexte) ;

								// Adresse
								if (sSens == string("LVILL"))
								{
                	int iColVille = (*iter)->getColonne() ;
									iter++ ;
              		while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColVille))
									{
										sSens = (*iter)->getLexiqueSens(pContexte) ;

										// Adresse
										if (sSens == string("LCOMU"))
                    {
                    	iter++ ;
          						while ((PatPathoArray.end() != iter) && ((*iter)->getColonne() > iColVille + 1))
          						{
            						// on cherche ici un texte libre
            						sElemLex = (*iter)->getLexique() ;
            						if (string(sElemLex, 0, 3) == string("�CL"))
              						sVille = (*iter)->getTexteLibre() ;

            						iter++ ;
          						}

                      if (string("") != sVille)
                      	pDonnees->_sVille = sVille ;
                    }
                    else
            					iter++ ;
                  }
                }
                else
            			iter++ ;
              }
            }
            else
            	iter++ ;
          } // while
        }
        else
        	iter++ ;
 			} // while
		} // else if (sSens == string("DPROS"))
		else
			iter++ ;
	} // while de base

	return true ;
}

//////////////////////// fin de nsperson.cpp //////////////////////////////////

