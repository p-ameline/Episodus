//---------------------------------------------------------------------------//    NSMATFIC.CPP
//    PA   juillet 95
//  Impl�mentation des objets materiel
//---------------------------------------------------------------------------
#include <owl\applicat.h>
#include <owl\decmdifr.h>
#include <owl\docmanag.h>
#include <owl\olemdifr.h>

#include <owl\applicat.h>
#include <owl\window.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <cstring.h>

#include "dcodeur\nsdecode.h"#include "partage\nsglobal.h"
#include "nautilus\nssuper.h"
#include "partage\nsdivfct.h"
#include "partage\nscim10.h"
#include "partage\nscim10.rh"
#include "partage\nsmatfic.rh"

// **************************************************************************
//  M�thodes de NSCim10Data
// **************************************************************************

//---------------------------------------------------------------------------
//  Met � vide les variables de la fiche
//---------------------------------------------------------------------------
void
NSCim10Data::metAZero()
{
	//
  // Met les champs de donn�es � z�ro
  //
  memset(code,    0, CIM_CODE_LEN + 1) ;
  memset(libelle, 0, CIM_LIBELLE_LEN + 1) ;
  memset(module,  0, CIM_MODULE_LEN + 1) ;
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCim10Data::NSCim10Data(NSCim10Data& rv)
{
	strcpy(code,    rv.code) ;
	strcpy(libelle, rv.libelle) ;
	strcpy(module,  rv.module) ;
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSCim10Data&
NSCim10Data::operator=(NSCim10Data src)
{
	strcpy(code,    src.code) ;
	strcpy(libelle, src.libelle) ;
  strcpy(module,  src.module) ;

	return *this ;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCim10Data::operator == (const NSCim10Data& o)
{
	if ((strcmp(module,	o.module)  == 0) &&
		 (strcmp(code, 	o.code)	  == 0) &&
		 (strcmp(libelle, o.libelle) == 0))
		return 1;
	else
		return 0;
}

// **************************************************************************
//  M�thodes de NSCim10
// **************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSCim10::NSCim10(NSContexte* pCtx) : NSFiche(pCtx)
{
	//
  // Cr�e un objet de donn�es
  //
  pDonnees = new NSCim10Data() ;
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCim10::~NSCim10()
{
	delete pDonnees ;
}

//---------------------------------------------------------------------------
//  Transf�re le contenu de pRecBuff dans les variables de la fiche
//---------------------------------------------------------------------------
void
NSCim10::alimenteFiche()
{
	alimenteChamp(pDonnees->code, 	 CIM_CODE_FIELD, 	CIM_CODE_LEN) ;
  alimenteChamp(pDonnees->libelle, CIM_LIBELLE_FIELD, CIM_LIBELLE_LEN) ;
	alimenteChamp(pDonnees->module,  CIM_MODULE_FIELD,  CIM_MODULE_LEN) ;
}

//---------------------------------------------------------------------------
//  Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSCim10::videFiche()
{
	videChamp(pDonnees->code, 	 CIM_CODE_FIELD, 	CIM_CODE_LEN) ;
  videChamp(pDonnees->libelle, CIM_LIBELLE_FIELD, CIM_LIBELLE_LEN) ;
  videChamp(pDonnees->module,  CIM_MODULE_FIELD,  CIM_MODULE_LEN) ;
}

//---------------------------------------------------------------------------
//  Ouvre la table primaire et les index secondaires
//---------------------------------------------------------------------------
DBIResult
NSCim10::open()
{
	char tableName[] = "CIM10.DB" ;
  //
  // Appelle la fonction open() de la classe de base pour ouvrir
  // l'index primaire
  //
  lastError = NSFiche::open(tableName, NSF_PARTAGE_PARAMS) ;
  return(lastError) ;
}

// **************************************************************************
//  M�thodes de NSCim10Info
// **************************************************************************

//---------------------------------------------------------------------------
//  Constructeur par d�faut
//---------------------------------------------------------------------------
NSCim10Info::NSCim10Info()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSCim10Data();
}

//---------------------------------------------------------------------------
//  Constructeur � partir d'un NSCim10
//---------------------------------------------------------------------------
NSCim10Info::NSCim10Info(NSCim10* pCim)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCim10Data();
	//
	// Copie les valeurs du NSMateriel
	//
	*pDonnees = *(pCim->pDonnees);
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCim10Info::NSCim10Info(NSCim10Info& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCim10Data();
	//
	// Copie les valeurs du NSMaterielInfo d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSCim10Info&
NSCim10Info::operator=(NSCim10Info src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCim10Info::operator==(const NSCim10Info& o)
{
	return (*pDonnees == *(o.pDonnees));
}

// **************************************************************************//  M�thodes de ChoixCIM10Dialog
// **************************************************************************
DEFINE_RESPONSE_TABLE1(ChoixCIM10Dialog, TDialog)
	EV_CHILD_NOTIFY_AND_CODE(IDC_MATERIELBOX, LBN_SELCHANGE, CmSelectMateriel),
	EV_CHILD_NOTIFY_AND_CODE(IDC_MATERIELBOX, LBN_DBLCLK, 	CmMaterielDblClk),
END_RESPONSE_TABLE;

ChoixCIM10Dialog::ChoixCIM10Dialog(TWindow* pere, NSContexte* pCtx,
                                   string* pModu, NSCim10Info* pCodeChoix)
                 :TDialog(pere, "IDD_CIM10", pNSDLLModule), NSRoot(pCtx)
{
try
{
	pMatBox 	= new TListBox(this, IDC_CIM10BOX);
  CodeChoisi  = 0;
	pCodeChoisi = pCodeChoix;

	pModule		= pModu;
}
catch (...)
{
	erreur("Exception ChoixCIM10Dialog ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Destructeur.
//---------------------------------------------------------------------------
ChoixCIM10Dialog::~ChoixCIM10Dialog()
{
	//
	// Si un mat�riel a �t� choisi
	//
	if ((CodeChoisi > 0) && pCodeChoisi)
		*pCodeChoisi = *((*pMatArray)[CodeChoisi - 1]);

	delete pMatBox;
	delete pMatArray;
}

//---------------------------------------------------------------------------//  Initialise la boite de liste des mat�riels
//---------------------------------------------------------------------------
void
ChoixCIM10Dialog::SetupWindow()
{
try
{
	TDialog::SetupWindow();
	//
	// Remplissage de MaterielBox avec le mat�riel idoine
	//
	pMatArray = new NSCim10Array;
	NSCim10* pBase = new NSCim10(pContexte);
	//
	// Ouverture du fichier
	//
	pBase->lastError = pBase->open();
	if (pBase->lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier des codes CIM10.", standardError, pBase->lastError);
		delete pBase;
		return;
	}
	//
	// Recherche des codes correspondant au module
	//
    pBase->lastError = pBase->chercheClef(pModule,
                                          "MODULE_INDEX",
                                          NODEFAULTINDEX,
                                          keySEARCHEQ,
                                          dbiWRITELOCK);
	if (pBase->lastError != DBIERR_NONE)
	{
		erreur("Il n'existe pas de code pour cet examen.", standardError, pBase->lastError);
		pBase->close();
		delete pBase;
		return;
	}
	pBase->lastError = pBase->getRecord();
	if (pBase->lastError != DBIERR_NONE)
	{
		erreur("Erreur � la lecture du 1er code.", standardError, pBase->lastError);
		pBase->close();
		delete pBase;
		return;
	}

    string sLibelleAffiche = "";

	while ((pBase->lastError == DBIERR_NONE) &&
			 (string(pBase->pDonnees->module) == *pModule))
	{
		//
		// Ajout du mat�riel � la MatBox
		//
        sLibelleAffiche = pBase->pDonnees->code;
        if (pBase->pDonnees->libelle[0] != '\0')
            sLibelleAffiche += string(" : ") + pBase->pDonnees->libelle;

		pMatBox->AddString(sLibelleAffiche.c_str());
		pMatArray->push_back(new NSCim10Info(pBase));
		//
		// Prise du code suivant
		//
		pBase->lastError = pBase->suivant(dbiWRITELOCK);
		if ((pBase->lastError != DBIERR_NONE) &&
			 (pBase->lastError != DBIERR_EOF))
			erreur("Erreur � l'acc�s au code CDAM suivant.", standardError, pBase->lastError);
		else if(pBase->lastError == DBIERR_NONE)
		{
			pBase->lastError = pBase->getRecord();
			if (pBase->lastError != DBIERR_NONE)
				erreur("Erreur � la lecture du fichier CDAM.", standardError, pBase->lastError);

		}
	}
	pBase->close();
	delete pBase;
	//
	// Si un code avait d�j� �t� s�lectionn�, on le coche
	//
    if ((pCodeChoisi->pDonnees->code[0] != '\0') && (!(pMatArray->empty())))
	{
        int iNumApp = 0;
        CimIter i = pMatArray->begin();
   	    for ( ; (i != pMatArray->end()) &&
      		(strcmp((*i)->pDonnees->code, pCodeChoisi->pDonnees->code) != 0);
       		i++, iNumApp++);
        if (i != pMatArray->end())
      	    pMatBox->SetSelIndex(iNumApp);
	}
}
catch (...)
{
    erreur("Exception ChoixCIM10Dialog::SetupWindow.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  R�ponse � selChanged
//  Prend acte de la s�lection du mat�riel
//---------------------------------------------------------------------------
void
ChoixCIM10Dialog::CmSelectMateriel(WPARAM /* Cmd */)
{
	//
	// R�cup�ration de l'indice de la chemise s�lectionn�e
	//
	CodeChoisi = pMatBox->GetSelIndex() + 1;
}

//---------------------------------------------------------------------------
//  R�ponse au double click
//  S�lectionne un mat�riel et effectue CmOk
//---------------------------------------------------------------------------
void
ChoixCIM10Dialog::CmMaterielDblClk(WPARAM /* Cmd */)
{
	CodeChoisi = pMatBox->GetSelIndex() + 1;
	TDialog::CmOk();
}

//---------------------------------------------------------------------------
//  Bouton Cancel
//  Annule MaterielChoisi et appelle Cancel()
//---------------------------------------------------------------------------
void
ChoixCIM10Dialog::CmCancel()
{
	CodeChoisi = 0;
	TDialog::CmCancel();
}


// **************************************************************************
//  M�thodes de NSCcamData
// **************************************************************************

//---------------------------------------------------------------------------
//  Met � vide les variables de la fiche
//---------------------------------------------------------------------------
void
NSCcamData::metAZero()
{
	//
	// Met les champs de donn�es � z�ro
	//
	memset(code,    0, CCAM_CODE_LEN + 1);
	memset(libelle, 0, CCAM_LIBELLE_LEN + 1);
	memset(module,  0, CCAM_MODULE_LEN + 1);
	memset(prix,    0, CCAM_PRIX_LEN + 1);
	memset(frequence, 0, CCAM_FREQ_LEN + 1);
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCcamData::NSCcamData(NSCcamData& rv)
{
	strcpy(code,    rv.code);
	strcpy(libelle, rv.libelle);
	strcpy(module,  rv.module);
	strcpy(prix,    rv.prix);
	strcpy(frequence, rv.frequence);
}

//---------------------------------------------------------------------------
//  Op�rateur =
//---------------------------------------------------------------------------
NSCcamData&
NSCcamData::operator=(NSCcamData src)
{
	strcpy(code,    src.code);
	strcpy(libelle, src.libelle);
	strcpy(module,  src.module);
	strcpy(prix,    src.prix);
	strcpy(frequence, src.frequence);

	return *this;
}

//---------------------------------------------------------------------------//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCcamData::operator == (const NSCcamData& o)
{
	if ((strcmp(module,	o.module)  == 0) &&
		 (strcmp(code, 	o.code)	  == 0) &&
		 (strcmp(libelle, o.libelle) == 0) &&
         (strcmp(prix, o.prix) == 0) &&
         (strcmp(frequence, o.frequence) == 0)
         )
		return 1;
	else
		return 0;
}

// **************************************************************************
//  M�thodes de NSCim10
// **************************************************************************

//---------------------------------------------------------------------------
//  Constructeur
//---------------------------------------------------------------------------
NSCcam::NSCcam(NSContexte* pCtx) : NSFiche(pCtx)
{
	//
	// Cr�e un objet de donn�es
	//
	pDonnees = new NSCcamData();
}

//---------------------------------------------------------------------------
//  Destructeur
//---------------------------------------------------------------------------
NSCcam::~NSCcam()
{
	delete pDonnees;
}

//---------------------------------------------------------------------------
//  Transf�re le contenu de pRecBuff dans les variables de la fiche
//---------------------------------------------------------------------------
void
NSCcam::alimenteFiche()
{
	alimenteChamp(pDonnees->code, 	   CCAM_CODE_FIELD, 	 CCAM_CODE_LEN) ;
	alimenteChamp(pDonnees->libelle,   CCAM_LIBELLE_FIELD, CCAM_LIBELLE_LEN) ;
	alimenteChamp(pDonnees->module,    CCAM_MODULE_FIELD,  CCAM_MODULE_LEN) ;
	alimenteChamp(pDonnees->prix,      CCAM_PRIX_FIELD,    CCAM_PRIX_LEN) ;
	alimenteChamp(pDonnees->frequence, CCAM_FREQ_FIELD,    CCAM_FREQ_LEN) ;
}

//---------------------------------------------------------------------------
//  Transf�re le contenu des valeurs de la fiche dans pRecBuff
//---------------------------------------------------------------------------
void
NSCcam::videFiche()
{
	videChamp(pDonnees->code, 	   CCAM_CODE_FIELD, 	 CCAM_CODE_LEN) ;
	videChamp(pDonnees->libelle,   CCAM_LIBELLE_FIELD, CCAM_LIBELLE_LEN) ;
	videChamp(pDonnees->module,    CCAM_MODULE_FIELD,  CCAM_MODULE_LEN) ;
	videChamp(pDonnees->prix,      CCAM_PRIX_FIELD,    CCAM_PRIX_LEN) ;
	videChamp(pDonnees->frequence, CCAM_FREQ_FIELD,    CCAM_FREQ_LEN) ;
}

//---------------------------------------------------------------------------
//  Ouvre la table primaire et les index secondaires
//---------------------------------------------------------------------------
DBIResult
NSCcam::open()
{
	char tableName[] = "CCAM.DB" ;
  //
  // Appelle la fonction open() de la classe de base pour ouvrir
  // l'index primaire
  //
  lastError = NSFiche::open(tableName, NSF_PARTAGE_PARAMS) ;
  return(lastError) ;
}

DBIResult
NSCcam::getRecordByCode(string sCode, NSCcamInfo* pResult, bool bOpenClose, bool bVerbose)
{
	if (!pResult || (sCode == string("")))
  	return DBIERR_NONE ;

  pResult->pDonnees->metAZero() ;

	// Opening the table
	//
  if (bOpenClose)
  {
		lastError = open() ;
		if (lastError != DBIERR_NONE)
		{
  		if (bVerbose)
				erreur("Erreur � l'ouverture du fichier CCAM.", standardError, lastError) ;
    	return lastError ;
  	}
  }
	//
	// Recherche du libelle dont le code est dans le champ compl�ment
	//
	lastError = chercheClef(&sCode,
                          "",
                          0,
                          keySEARCHEQ,
                          dbiWRITELOCK) ;
	if (lastError != DBIERR_NONE)
	{
  	DBIResult dbError = lastError ;
  	if (bVerbose)
    {
    	string sError = string("Erreur � la recherche du code CCAM : ") + sCode ;
			erreur(sError.c_str(), standardError, lastError) ;
		}
    if (bOpenClose)
    	close() ;
		return dbError ;
	}
  //
  // Getting the record from table
  //
	lastError = getRecord() ;
	if (lastError != DBIERR_NONE)
	{
  	DBIResult dbError = lastError ;
  	if (bVerbose)
    {
    	string sError = string("Erreur � la lecture du code CCAM : ") + sCode ;
			erreur(sError.c_str(), standardError, lastError) ;
		}
    if (bOpenClose)
    	close() ;
		return dbError ;
	}
	//
	// Si tout a bien march�, on met � jour pMatInfo
	//
	*(pResult->pDonnees) = *pDonnees ;

  if (bOpenClose)
		close() ;

	return DBIERR_NONE ;
}

// **************************************************************************
//  M�thodes de NSCim10Info
// **************************************************************************

//---------------------------------------------------------------------------
//  Constructeur par d�faut
//---------------------------------------------------------------------------
NSCcamInfo::NSCcamInfo()
{
	// Cr�e l'objet de donn�es
	pDonnees = new NSCcamData();
}

//---------------------------------------------------------------------------
//  Constructeur � partir d'un NSCcam
//---------------------------------------------------------------------------
NSCcamInfo::NSCcamInfo(NSCcam* pCcam)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCcamData();
	//
	// Copie les valeurs du NSMateriel
	//
	*pDonnees = *(pCcam->pDonnees);
}

//---------------------------------------------------------------------------
//  Constructeur copie
//---------------------------------------------------------------------------
NSCcamInfo::NSCcamInfo(NSCcamInfo& rv)
{
	//
	// Cr�e l'objet de donn�es
	//
	pDonnees = new NSCcamData();
	//
	// Copie les valeurs du NSCcamInfo d'origine
	//
	*pDonnees = *(rv.pDonnees);
}

//---------------------------------------------------------------------------
//  Op�rateur d'affectation
//---------------------------------------------------------------------------
NSCcamInfo&
NSCcamInfo::operator=(NSCcamInfo src)
{
	*pDonnees = *(src.pDonnees);
	return *this;
}

//---------------------------------------------------------------------------
//  Op�rateur de comparaison
//---------------------------------------------------------------------------
int
NSCcamInfo::operator==(const NSCcamInfo& o)
{
	return (*pDonnees == *(o.pDonnees));
}

bool
CcamSortByCodeInf(NSCcamInfo *pCCAM1, NSCcamInfo *pCCAM2)
{
	return (strcmp(pCCAM1->pDonnees->code, pCCAM2->pDonnees->code) > 0) ;
}


bool
CcamSortByCodeSup(NSCcamInfo *pCCAM1, NSCcamInfo *pCCAM2)
{
	return (strcmp(pCCAM1->pDonnees->code, pCCAM2->pDonnees->code) < 0) ;
}

bool
CcamSortByLibelleInf(NSCcamInfo *pCCAM1, NSCcamInfo *pCCAM2)
{
	return (strcmp(pCCAM1->pDonnees->libelle, pCCAM2->pDonnees->libelle) > 0) ;
}


bool
CcamSortByLibelleSup(NSCcamInfo *pCCAM1, NSCcamInfo *pCCAM2)
{
	return (strcmp(pCCAM1->pDonnees->libelle, pCCAM2->pDonnees->libelle) < 0) ;
}

bool
CcamSortByPrixInf(NSCcamInfo *pCCAM1, NSCcamInfo *pCCAM2)
{
	return (atoi(pCCAM1->pDonnees->prix) > atoi(pCCAM2->pDonnees->prix)) ;
}


bool
CcamSortByPrixSup(NSCcamInfo *pCCAM1, NSCcamInfo *pCCAM2)
{
  return (atoi(pCCAM1->pDonnees->prix) < atoi(pCCAM2->pDonnees->prix)) ;
}

bool
CcamSortByFreqInf(NSCcamInfo *pCCAM1, NSCcamInfo *pCCAM2)
{
	return (strcmp(pCCAM1->pDonnees->frequence, pCCAM2->pDonnees->frequence) > 0) ;
}


bool
CcamSortByFreqSup(NSCcamInfo *pCCAM1, NSCcamInfo *pCCAM2)
{
	return (strcmp(pCCAM1->pDonnees->frequence, pCCAM2->pDonnees->frequence) < 0) ;
}


// **************************************************************************//  M�thodes de ChoixCcamDialog
// **************************************************************************
DEFINE_RESPONSE_TABLE1(ChoixCcamDialog, TDialog)
	EV_CHILD_NOTIFY_AND_CODE(IDC_MATERIELBOX, LBN_SELCHANGE, CmSelectMateriel),
	EV_CHILD_NOTIFY_AND_CODE(IDC_MATERIELBOX, LBN_DBLCLK, 	CmMaterielDblClk),
  EV_LVN_GETDISPINFO(IDC_CIM10BOX, LvnGetDispInfo),
  EV_LVN_COLUMNCLICK(IDC_CIM10BOX, LVNColumnclick),
  EV_WM_SIZE,
  EV_COMMAND(IDOK, CmOk),
  EV_COMMAND(IDCANCEL, CmCancel),
END_RESPONSE_TABLE;

ChoixCcamDialog::ChoixCcamDialog(TWindow* pere, NSContexte* pCtx,
                                   string* pModu, NSCcamInfo* pCodeChoix)
                 :TDialog(pere, "IDD_CCAM", pNSDLLModule), NSRoot(pCtx)
{
try
{
	pMatBox 	  = new NSListeCCAMWindow(this, IDC_CIM10BOX) ;
	CodeChoisi  = 0 ;
	pCodeChoisi = pCodeChoix ;

  pMatArray   = new NSCcamArray ;
  nbMat       = 0 ;

	pModule		  = pModu ;

  bNaturallySorted = true ;
	iSortedColumn    = 0 ;
}
catch (...)
{
	erreur("Exception ChoixCIM10Dialog ctor.", standardError, 0) ;
}
}

//---------------------------------------------------------------------------//  Destructeur.
//---------------------------------------------------------------------------
ChoixCcamDialog::~ChoixCcamDialog()
{
	//
	// Si un mat�riel a �t� choisi
	//
	if ((CodeChoisi > 0) && pCodeChoisi)
		*pCodeChoisi = *((*pMatArray)[CodeChoisi - 1]);

	delete pMatBox ;
	delete pMatArray ;
}

//---------------------------------------------------------------------------//  Initialise la boite de liste des codes CCAM
//---------------------------------------------------------------------------
void
ChoixCcamDialog::SetupWindow()
{
try
{
	TDialog::SetupWindow() ;

  InitListe() ;

  if ((!InitCCAMArray()) || (pMatArray->empty()))
		return ;

	AfficheListe() ;

	//
	// Si un code avait d�j� �t� s�lectionn�, on le coche
	//
	if (pCodeChoisi->pDonnees->code[0] == '\0')
	{
  	pMatBox->SetItemState(0, LVIS_FOCUSED | LVIS_SELECTED, LVIS_SELECTED) ;
    return ;
  }

	int iNumApp = 0;
	CcamIter i = pMatArray->begin() ;
	for ( ; (i != pMatArray->end()) &&
      		(strcmp((*i)->pDonnees->code, pCodeChoisi->pDonnees->code) != 0);
       		i++, iNumApp++) ;

	if (i != pMatArray->end())
  	pMatBox->SetItemState(iNumApp, LVIS_FOCUSED | LVIS_SELECTED, LVIS_SELECTED) ;
}
catch (...)
{
	erreur("Exception ChoixCcamDialog::SetupWindow.", standardError, 0) ;
}
}

void
ChoixCcamDialog::EvSize(uint sizeType, ClassLib::TSize& size)
{
	TDialog::EvSize(sizeType, size) ;

	if (sizeType != SIZE_MINIMIZED)
	{
  	int LEFT_OFFSET  = 8 ;
    int TOP_OFFSET   = 8 ;
    int WIDTH_OFFSET = 24 ;

		ClassLib::TRect rect      = GetWindowRect() ;
    ClassLib::TRect list_rect = pMatBox->GetWindowRect() ;
		pMatBox->SetWindowPos(0, LEFT_OFFSET, TOP_OFFSET,
										rect.Width() - WIDTH_OFFSET, list_rect.Height(),
      							SWP_NOZORDER ) ;
	}
}

bool
ChoixCcamDialog::InitCCAMArray()
{
try
{
	pMatArray->vider() ;
	nbMat = 0 ;

	//
	// Remplissage de MaterielBox avec le mat�riel idoine
	//
	NSCcam Base(pContexte) ;
	//
	// Ouverture du fichier
	//
	Base.lastError = Base.open() ;
	if (Base.lastError != DBIERR_NONE)
	{
		erreur("Erreur � l'ouverture du fichier des codes CCAM.", standardError, Base.lastError) ;
		return false ;
	}
	//
	// Recherche des codes correspondant au module
	//
	Base.lastError = Base.chercheClef(pModule,
                                    "MODULE_INDEX",
                                    NODEFAULTINDEX,
                                    keySEARCHEQ,
                                    dbiWRITELOCK) ;
	if (Base.lastError != DBIERR_NONE)
	{
		erreur("Il n'existe pas de code pour cet examen.", standardError, Base.lastError) ;
		Base.close() ;
		return false ;
	}

	Base.lastError = Base.getRecord();
	if (Base.lastError != DBIERR_NONE)
	{
		erreur("Erreur � la lecture du 1er code.", standardError, Base.lastError) ;
		Base.close() ;
		return false ;
	}

	string sLibelleAffiche = "" ;

	while ((Base.lastError == DBIERR_NONE) &&
			 (string(Base.pDonnees->module) == *pModule))
	{
		//
		// Ajout du mat�riel � l'array
		//
    // sLibelleAffiche = pBase->pDonnees->code;
    // if (pBase->pDonnees->libelle[0] != '\0')
    // 	sLibelleAffiche += string(" : ") + pBase->pDonnees->libelle;

		// pMatBox->AddString(sLibelleAffiche.c_str());
		pMatArray->push_back(new NSCcamInfo(&Base)) ;
    nbMat++ ;
		//
		// Prise du code suivant
		//
		Base.lastError = Base.suivant(dbiWRITELOCK) ;
		if ((Base.lastError != DBIERR_NONE) && (Base.lastError != DBIERR_EOF))
			erreur("Erreur � l'acc�s au mat�riel suivant.", standardError, Base.lastError) ;
		else if (Base.lastError == DBIERR_NONE)
		{
			Base.lastError = Base.getRecord() ;
			if (Base.lastError != DBIERR_NONE)
				erreur("Erreur � la lecture du mat�riel.", standardError, Base.lastError) ;
		}
	}
	Base.close() ;

	return true ;
}
catch (...)
{
	erreur("Exception ChoixCcamDialog::InitCCAMArray.", standardError, 0) ;
  return false ;
}
}

//---------------------------------------------------------------------------//  R�ponse � selChanged
//  Prend acte de la s�lection du mat�riel
//---------------------------------------------------------------------------
void
ChoixCcamDialog::CmSelectMateriel(WPARAM /* Cmd */)
{
	//
	// R�cup�ration de l'indice de la chemise s�lectionn�e
	//
	CodeChoisi = pMatBox->IndexItemSelect() + 1;
}

//---------------------------------------------------------------------------
//  R�ponse au double click
//  S�lectionne un mat�riel et effectue CmOk
//---------------------------------------------------------------------------
void
ChoixCcamDialog::CmMaterielDblClk(WPARAM /* Cmd */)
{
	CodeChoisi = pMatBox->IndexItemSelect() + 1;
	TDialog::CmOk();
}

void
ChoixCcamDialog::CmOk()
{
 	int iSelected = pMatBox->IndexItemSelect()  ;
  if (iSelected == -1)
  	return ;

  CodeChoisi = iSelected + 1 ;
	TDialog::CmOk();
}

//---------------------------------------------------------------------------
//  Bouton Cancel
//  Annule MaterielChoisi et appelle Cancel()
//---------------------------------------------------------------------------
void
ChoixCcamDialog::CmCancel()
{
	CodeChoisi = 0;
	TDialog::CmCancel();
}

void
ChoixCcamDialog::InitListe()
{
	TListWindColumn colCode("Code", 80, TListWindColumn::Left, 0) ;
	pMatBox->InsertColumn(0, colCode) ;
	TListWindColumn colLibelle("Libelle", 400, TListWindColumn::Left, 1) ;
	pMatBox->InsertColumn(1, colLibelle) ;
	TListWindColumn colType("Prix", 80, TListWindColumn::Right, 2) ;
	pMatBox->InsertColumn(2, colType) ;
	TListWindColumn colActif("Freq", 20, TListWindColumn::Left, 3) ;
	pMatBox->InsertColumn(3, colActif) ;
}

void
ChoixCcamDialog::AfficheListe()
{
	char libelle[255] ;

	pMatBox->DeleteAllItems() ;

	for (int i = nbMat - 1; i >= 0; i--)
	{
		sprintf(libelle, "%s", ((*pMatArray)[i])->pDonnees->code) ;
    TListWindItem Item(libelle, 0) ;
    pMatBox->InsertItem(Item) ;
	}
}

void
ChoixCcamDialog::LvnGetDispInfo(TLwDispInfoNotify& dispInfo)
{
	TListWindItem& dispInfoItem = *(TListWindItem*)&dispInfo.item ;
	int index = dispInfoItem.GetIndex() ;
  if (index < 0)
		return ;

  if ((size_t)index > pMatArray->size())
  	return ;

  string sBuffer ;
  size_t iLen ;

	// Affiche les informations en fonction de la colonne

	switch (dispInfoItem.GetSubItem())
	{
		case 1 : // Libelle
    	dispInfoItem.SetText(((*pMatArray)[index])->pDonnees->libelle) ;
      break ;
		case 2 : // Prix
    	sBuffer = string(((*pMatArray)[index])->pDonnees->prix) ;
      iLen = strlen(sBuffer.c_str()) ;
      if (iLen > 2)
      	sBuffer = string(sBuffer, 0, iLen - 2) + string(",") + string(sBuffer, iLen-2, 2) ;
    	dispInfoItem.SetText(sBuffer.c_str()) ;
      break ;
    case 3 : // Prix
    	dispInfoItem.SetText(((*pMatArray)[index])->pDonnees->frequence) ;
      break ;
	}
}

void
ChoixCcamDialog::LVNColumnclick(TLwNotify& lwn)
{
  switch ( lwn.iSubItem )
  {
    case 0  : sortByCode() ;    break ;
    case 1  : sortByLibelle() ; break ;
    case 2  : sortByPrice() ;   break ;
    case 3  : sortByFreq() ;    break ;
  }
}

void
ChoixCcamDialog::swapSortOrder(int iColumn)
{
  if (iSortedColumn == iColumn)
  {
    if (bNaturallySorted)
      bNaturallySorted = false ;
    else
      bNaturallySorted = true ;
  }
  else
  {
    iSortedColumn = iColumn ;
    bNaturallySorted = true ;
  }
}

void
ChoixCcamDialog::sortByCode()
{
	swapSortOrder(0) ;

  if (pMatArray->empty())
    return ;

  if (bNaturallySorted)
    sort(pMatArray->begin(), pMatArray->end(), CcamSortByCodeInf) ;
  else
    sort(pMatArray->begin(), pMatArray->end(), CcamSortByCodeSup) ;

  AfficheListe() ;
}

void
ChoixCcamDialog::sortByLibelle()
{
	swapSortOrder(1) ;

  if (pMatArray->empty())
    return ;

  if (bNaturallySorted)
    sort(pMatArray->begin(), pMatArray->end(), CcamSortByLibelleInf) ;
  else
    sort(pMatArray->begin(), pMatArray->end(), CcamSortByLibelleSup) ;

  AfficheListe() ;
}

void
ChoixCcamDialog::sortByPrice()
{
	swapSortOrder(2) ;

  if (pMatArray->empty())
    return ;

  if (bNaturallySorted)
    sort(pMatArray->begin(), pMatArray->end(), CcamSortByPrixInf) ;
  else
    sort(pMatArray->begin(), pMatArray->end(), CcamSortByPrixSup) ;

  AfficheListe() ;
}

void
ChoixCcamDialog::sortByFreq()
{
	swapSortOrder(3) ;

  if (pMatArray->empty())
    return ;

  if (bNaturallySorted)
    sort(pMatArray->begin(), pMatArray->end(), CcamSortByFreqInf) ;
  else
    sort(pMatArray->begin(), pMatArray->end(), CcamSortByFreqSup) ;

  AfficheListe() ;
}


// -----------------------------------------------------------------
//
//  M�thodes de NSListeMatWindow
//
// -----------------------------------------------------------------

DEFINE_RESPONSE_TABLE1(NSListeCCAMWindow, TListWindow)
	EV_WM_LBUTTONDBLCLK,
END_RESPONSE_TABLE;

void
NSListeCCAMWindow::SetupWindow()
{
  ListView_SetExtendedListViewStyle(this->HWindow, LVS_EX_FULLROWSELECT) ;
  TListWindow::SetupWindow() ;
}

//---------------------------------------------------------------------------
//  Description: Fonction de r�ponse au double-click
//---------------------------------------------------------------------------
void
NSListeCCAMWindow::EvLButtonDblClk(uint /* modKeys */, NS_CLASSLIB::TPoint& point)
{
	TLwHitTestInfo info(point) ;

	HitTest(info) ;

  if (info.GetFlags() & LVHT_ONITEM)
  	pDlg->CmOk() ;
}

//---------------------------------------------------------------------------
//  Description: Retourne l'index du premier item s�lectionn�
//  Returns:     index si item est s�lectionn�, -1 sinon
//---------------------------------------------------------------------------
int
NSListeCCAMWindow::IndexItemSelect()
{
	int count = GetItemCount();
	int index = -1;

	for (int i = 0; i < count; i++)
		if (GetItemState(i, LVIS_SELECTED))
    {
    	index = i ;
      break ;
    }

	return index ;
}

